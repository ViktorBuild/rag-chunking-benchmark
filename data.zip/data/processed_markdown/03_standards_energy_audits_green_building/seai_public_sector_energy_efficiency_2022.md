---
document_id: seai_public_sector_2022
title: "Annual Report 2022 on Public Sector Energy Efficiency Performance"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2022
original_file: "seai_public_sector_energy_efficiency_2022.pdf"
tables_detected: 401
converted_with: "Docling v2.32 (TableFormer)"
---

## Annual Report 2022 on Public Sector Energy Performance

An SEAI Report prepared for the Department of the Environment, Climate &amp; Communications

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Contents

| 1.                                 | Executive Summary                                      |   2 |
|------------------------------------|--------------------------------------------------------|-----|
| 2                                  | Background and Context                                 |   5 |
| 2.1                                | Policy and legislative requirements                    |   5 |
| 2.2                                | The monitoring and reporting (M&R) process             |   7 |
| 2.3                                | Analysis of reporting by public sector organisations   |   8 |
| 3.                                 | Energy Consumption and Emissions                       |   9 |
| 3.1                                | Total energy consumption and emissions                 |   9 |
| 3.2                                | Energy consumption and emissions by energy type        |  10 |
| 3.3                                | Energy consumption and emissions by end-use            |  12 |
| 3.4                                | Energy consumption and emissions by subsector and mode |  13 |
| 3.5                                | Main energy consumers                                  |  14 |
| 3.6                                | Change in energy consumption and emissions since 2020  |  14 |
| 4.                                 | Energy Efficiency Target                               |  16 |
| 4.1                                | Progress towards 2030 energy efficiency target         |  16 |
| 4.2                                | Energy efficiency by subsector                         |  16 |
| 5.                                 | Greenhouse Gas Emissions Targets                       |  18 |
| 5.1                                | Two 2030 targets                                       |  18 |
| 5.2                                | Progress towards non-electricity emissions target      |  18 |
| 5.3                                | Progress towards total emissions target                |  20 |
| 5.4                                | Business travel                                        |  22 |
| Making Progress                    | Making Progress                                        |  24 |
| 6.                                 | Towards 2030                                           |  26 |
| 6.1                                | Departmental groups performance results                |  26 |
| 6.2                                | Performance of public bodies                           |  27 |
| Appendix 1 - Departmental Groups   | Appendix 1 - Departmental Groups                       |  53 |
| Appendix 2 - Reporting Methodology | Appendix 2 - Reporting Methodology                     |  55 |
| Appendix 3 - Glossary              | Appendix 3 - Glossary                                  |  56 |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 1. Executive Summary

This is the ninth annual report on the energy efficiency performance of Government Departments and public bodies in Ireland, as defined by SI 426 of 2014  . It is set in the 1 context of Ireland's EU and national commitments and wider energy and climate change goals, as captured in the recently published Climate Action Plan (2023) , the 2 National Energy &amp; Climate Plan (2020) and the Programme for Government (2020).

The public sector is taking a leadership role in delivering on national energy and climate objectives by targeting new efficiencies and by showing the steps that can be taken on climate action and energy saving, in wider societal context, to reduce Ireland's greenhouse gas (GHG) emissions by 51% by 2030, and to become climate neutral no later than 2050.

The Climate Action Plan (2021) contained a commitment to prepare a new Public Sector Climate Action Strategy and this over-arching public sector strategy will provide consistency in climate action activity across the public sector. The Strategy will run to 2025, to align with the end of the first Carbon Budgets period. It will focus on governance, which has been identified as a key pillar in supporting the leadership role that public sector decarbonisation and energy efficiency must play in the broader nation-wide net-zero transition. The Strategy will be submitted for Government approval and be published early in 2023.

Additionally, a Public Sector Climate Action Mandate was agreed in 2022 and this mandate supports public bodies in leading by example on climate action. All public bodies, with the exception of local authorities, commercial semi state bodies and the school sector , must take action on and report 3 on the actions set out in the Mandate. Public bodies must also prepare Climate Action Roadmaps that set out their plans for implementing the Mandate. Guidance for the first iteration of the Roadmaps has been prepared by the EPA and the SEAI and is now available on the SEAI website 4.

1 Regulation 4 of SI 426 2014 sets out the definition of a 'public body' .

2 The Climate Action Plan 2023 was published in December 2022.

3 Sector-specific mandates apply for these sectors

4 www.seai.ie/publications/Public\_Sector\_Bodies\_Climate\_Action\_Roadmaps\_Guidance.pdf

5 An additional 173 schools attempted to submit reports, but their data was incomplete and is not included in this report.

To report their annual energy efficiency and greenhouse gas emissions performance data, over 99% of public bodies and 79% of schools are using the online energy monitoring and reporting (M&amp;R) system developed by the SEAI and DECC. This M&amp;R system provides an important record and dataset as to how the public sector is performing against a baseline period and the system is being redeveloped to monitor and track energy efficiency and decarbonisation targets to 2030 and other national and EU reporting requirements.

Data from the M&amp;R system for 2021 shows overall public sector energy efficiency gains of 31.5%. The detailed data in this report for 2021 should not be compared on a like for like basis to the data for previous years due to the impact of COVID-19 and because the overall number of public bodies and schools reporting changes from year to year.

- · or 2021, 348 public bodies were requested to report data F to SEAI, of which 345 submitted complete reports by the reporting deadline.
- · n addition, 3,669 standalone schools were requested to I report data, of which 2,898  submitted complete reports. 5

This report analyses the data submitted by these organisations on energy consumption and GHG emissions for 2021, and compares their progress against 2030 efficiency and emissions targets. It is clear, from the data, that efficiency gains are being achieved through the implementation of thousands of diverse projects, ranging from structured energy management, building and facility upgrades, retrofits, changes in transportation, better energy procurement and through behavioural change in organisations.

Public bodies are obliged to report annual data on business travel to SEAI from 2021 onwards. It is not however, within the scope of the 2030 public sector targets.

## Current Position

<!-- image -->

## Key findings from the analysis of the data reported by 345 public bodies and 2,898 schools for 2021:

- · Their combined total primary energy consumption was 9,787 GWh and, their total energy-related GHGs was 1,782 ktCO2 and their total energy spend was €728 million.

The cumulative avoided primary energy saving since energy efficiency baseline amount to 33,389 GWh, while the cumulative value of energy savings over the same period is €2,187 million.

- · This is estimated to represent 99% of the energy consumption of the sector.
- · The improvement in energy efficiency amounts to 31.5% on business as usual, this improvement is equivalent to 4,353 GWh of avoided primary energy consumption, representing €307 million in cost savings for the sector.
- · Non-electricity greenhouse gas emissions had decreased by 2.7% since the greenhouse gas baseline, while total emissions had decreased by 14.1%.

Reporting compliance by public sector organisations continues to be very strong at 99.1% in 2021 (excluding standalone schools).

Standalone schools are recognised as a separate category. Although 3,669 schools were requested to report, they account for just a small proportion (some 5%) of overall public sector energy consumption. Their circumstances and energy use profiles are significantly different to other public bodies (more limited capacity to invest, with building usage profiles that mean building fabric investments of any scale have very long payback periods). The compliance rates for public bodies and for schools are therefore reported separately.

<!-- image -->

<!-- image -->

The reporting compliance rate for standalone schools for 2021 was 79%, which is an increase on the 76% compliance rate the previous year.

Overall, based on the data reported, the 31.5 % improvement in energy efficiency performance achieved by 2021 is a good result, when the rebound in energy consumption following the lifting of some COVID-19 restrictions, and other factors related to the efficiency of Ireland's electricity system in 2021 are taken into account.

€

## Key Findings for 2021

€

## 9,787 GWh €

Between now and the end of the decade, it is clear that continued, proactive engagement by all public bodies, and their Energy Performance Officers, through the existing governance structures and supports that are in place, will be essential in ensuring that the public sector's 2030 energy and emissions targets are met.

The annual M&amp;R process continues to be an enabling tool, providing public bodies, their Energy Performance Officers and key stakeholders with the performance information that enables strategic decision-making and actions to facilitate further progress and achievement of the national targets

WHICH AMOUNTED TO A TOTAL ENERGY SPEND OF

COMBINED ENERGY CONSUMPTION OF THE 345 PUBLIC BODIES AND 2,898 SCHOOLS THAT REPORTED €

## FOR 2021, THE ENERGY EFFICIENCY SAVINGS ACHIEVED WERE:

<!-- image -->

<!-- image -->

4,353 GWh

€ 31.5%

ANNUAL PRIMARY ENERGY SAVINGS €

€

ENERGY EFFICIENCY IMPROVEMENT ON BUSINESS AS USUAL

FOR 2021, THE GREENHOUSE GAS EMISSIONS REDUCTION WAS:

€ 2.7% NON-ELECTRICITY GHG EMISSIONS

<!-- image -->

<!-- image -->

<!-- image -->

€

€

728m

<!-- image -->

ENERGY SPEND SAVINGS FOR PUBLIC BODIES &amp; SCHOOLS €

€ €307m

€

14.1%

TOTAL GHG EMISSIONS

<!-- image -->

<!-- image -->

## 2. Background and Context

## 2.1 Policy and legislative requirements

The Energy Efficiency Directive (EED) (2012/27/EU) 7 amended by Directive (EU) 2019/2002, sets out a more ambitious new EU-wide energy efficiency target of at least 32.5% by 2030. The EED sets out the exemplar role that the public sector has in contributing to this EU energy target.

The Energy Performance of Buildings Directive (EPBD) (2010/31/EU) 8 amended by Directive 2018/844/EU sets requirements for Member States to improve the energy performance of buildings and make an important contribution to the reduction of greenhouse gas emissions.

The EU's Fit for 55 package is proposing more ambitious targets together with other EU energy and climate rules, to ensure that the 2030 target of reducing greenhouse gas emission by at least 55% (compared to 1990 levels) can be met. As part of this process EU countries are working on reviewing and updating legislation to achieve this goal and make the EU climate neutral by 2050.

In July 2021 the European Commission published a proposal to recast the EED as part of its revision of its climate, energy and transport-related legislation under the package. The negotiation of the recast EED is continuing into early 2023. It will underline the importance of the leadership role for the public sector in contributing to delivery of our EU energy and climate targets and will set new energy saving and renovation sub targets for the public sector. The new EED will also set a much more challenging energy saving national target for each member state. As things stand in the negotiations it is already clear that Ireland will be required to reduce national energy consumption - from all sources by at least 18.6% compared to national energy use in 2019. The size of the reduction needed could be higher when the negotiations conclude as the European Parliament want a more ambitious target. All sectors will therefore need to intensify their energy saving contributions up to 2030 to ensure the new target is met.

Work continues on the revision of the EPBD to make buildings in the EU more energy efficient by 2030 and beyond. It is proposing even greater ambitious targets for the public sector and its building stock. The main objectives of the new rules are that all new buildings should be zero-emission buildings by 2030, all existing buildings should be transformed into zero-emission buildings by 2050, the acceleration of energy-efficient renovations in the worst performing 15% of EU buildings and the setting of minimum energy performance standards. The recast of the EPBD is expected to be finalised by mid-2023.

commits to a clear pathway for all sectors (including the public sector) to become less reliant on fossil fuels.

It also sets more ambitious targets for the public sector including a 50% energy efficiency target and a 51% emissions reduction target, which were subsequently introduced in the Climate Action Plan 2021.

The strategic importance of public sector energy efficiency is underlined not only in the Programme for Government but also Ireland's National Energy &amp; Climate Plan (2021- 2030) and Ireland's Long Term Renovation Strategy (2020).

Given the ongoing situation in relation to energy prices and supply, and the forthcoming more challenging energy saving targets under the EED there is now a concerted effort across the public sector to continue this leadership role in reducing energy use and promoting the reduction of heating and electricity usage in workplaces and public sector buildings. Delivered to public bodies by the SEAI and the OPW, the 'Reduce Your Use' energy efficiency initiative provides a structured programme of energy saving activities during the winter months and offers energy saving advice for the public sector.

Public bodies that have the capacity to contribute to energy efficiency retrofit of buildings projects will be prioritised for support under the Pathfinder Retrofit Programme. This is a co-funded programme aimed at testing retrofit approaches and developing a model that can be replicated across the wider public sector. Funds are administered by SEAI for pathfinder projects across a number of large sectors such as central government, education, health and local authorities. It is planned to expand the existing partnerships and introduce new partnerships. From 2017 to 2021, 370 retrofit projects were supported with total DECC funding of over €51 million provided. With ambitious public sector targets to 2030, the programme will prioritise deeper retrofits with renewable heat solutions to meet the required level of emission reduction.

## Targets

Improved energy efficiency and decarbonisation continue to be national imperatives and are key enablers in Ireland meeting its national and international energy and climate goals and objectives.

An overarching Public Sector Climate Action Strategy will be published early in 2023, in fulfilment of Action 53b of the Climate Action Plan 2021 and, it will provide consistency in climate action activity across the public sector. This Strategy will run to 2025, to align with the end of the first Carbon Budgets period.

The Programme for Government (2020) sets out a commitment to an average 7% per annum reduction in overall greenhouse gas emissions from 2021 to 2030 (a 51% reduction over the decade) and to achieving net zero emissions by 2050. It also

The focus of this Strategy will be on leadership and governance. Leadership, underpinned by strong governance at all levels, is essential for the achievement of our 2030

7 This has been transposed into Irish legislation under SI 426 of 2014 European Union (Energy Efficiency) Regulations

8 This has been transposed into Irish legislation under SI 183 of 2019 European Union (Energy Performance of Buildings) Regulations

<!-- image -->

<!-- image -->

emissions reduction and energy efficiency targets. Given that the total emissions from the public sector make up a small percentage of national emissions, the role of public sector will be to catalyse the overall transition to a decarbonised society. Public sector leadership will involve transforming operations and supply chains by promoting new workforce behaviours, including green considerations in public-sector procurement decisions, and embedding climate considerations in the budgeting process.

## Climate Action Plan 2023

The public sector will play a leadership role in driving farreaching climate action across its buildings, transport, waste, and energy usage, as well as wider society. To achieve this, the public sector will:

- · Strengthen climate governance frameworks in public sector bodies
- · ncrease climate literacy in the public sector I
- · Procure only Zero Emission Vehicles
- · Retrofit public sector buildings
- · ully implement green public procurement in the public F sector

By 2025, the public sector will achieve the buildings and retrofitting targets laid out in the Public Sector Climate Action Mandate and in chapter 14 of Climate Action Plan 2023.

By 2030, the public sector will:

- · Reduce greenhouse gas emissions from the public sector by 51%
- · ncrease the improvement in energy efficiency in the I public sector from the 33% target in 2020 to 50% by 2030

The public sector will also implement and review the Public Sector Climate Action Mandate annually. The 2021 Public Sector Mandate received Government approval on 4 July 2021. An updated Climate Action Mandate can be found in chapter 10 of Climate Action Plan 2023.

- · mplement policies to decarbonise the public sector I vehicle fleet

Further details on these targets and commitments are set out in chapter 10 of Climate Action Plan 2023.

## FIG. 1: ENERGY EFFICIENCY &amp; REPORTING PROGRESS BY PUBLIC BODIES AND SCHOOLS

<!-- image -->

## 2.2 The monitoring and reporting (M&amp;R) process

Since 2010, public sector organisations bodies have been required by Irish statute to report on their energy usage and actions taken to reduce consumption. There are two key obligations for public sector organisations:

- · Requirement - under the provisions of SI 426 of 2014 to report energy management and performance data directly to SEAI each year in order to track progress towards the targets.
- · Requirement to publish an annual statement on energy performance. This statement must describe 'the actions it is taking, or has taken, to improve its energy efficiency and an assessment of the energy savings arising from those actions' .

The reporting methodology is illustrated below in Figure 2 and summarised in Appendix 2.

A comprehensive description of the methodologies used to track progress towards the energy efficiency target and greenhouse gas reduction targets is provided in SEAI's M&amp;R-2030 methodology guidance document. One notable difference between the approaches used for tracking energy efficiency and greenhouse gas emissions relates to the treatment of changes in activity level in public sector organisations:

- · or energy efficiency, an organisation's energy F performance is tracked using an energy performance indicator . This indicator accounts for changes in the 9 organisation's activity level, so that fluctuations in activity that have an impact on energy consumption are taken into account in determining energy performance (energy efficiency).
- · or energy-related greenhouse gas emissions, the F organisation's emissions are tracked on an absolute basis, i.e. there is no adjustment for changes in activity levels, capacity, organisational structure, service levels or demographics.

Progress towards the energy efficiency and greenhouse gas targets are both tracked against a baseline period, so improvements can be measured and assessed. The baseline periods used for energy efficiency and greenhouse gas emissions are different.

SEAI is re-developing the M&amp;R process, as well as enhancing the online system, in order to meet the requirement to track 2030 public sector targets as set out in the Climate Action Plan and the Programme for Government. The system will be able to provide a platform for public bodies to track their energy performance and their carbon footprint, among other reporting requirements, including those set out under the EU Clean Vehicles Directive.

## FIG. 2: HOW PUBLIC BODIES REPORT

<!-- image -->

<!-- image -->

<!-- image -->

## 2.3 Analysis of reporting by public sector organisations

In Ireland the definition of the public sector is broad and encompasses a wide range of organisations, including the civil service, local authorities, non-commercial state bodies/ agencies, commercial state bodies and organisations in the health, justice, defence and education sectors.

348 10 public bodies and 3,669 standalone schools were requested to report data to SEAI through the 2021 reporting cycle. The public bodies and schools that were requested to report during the 2021 reporting cycle are broken down as follows:

- · 348 public bodies, including 16 Education &amp; Training Boards (ETBs) 11 , were requested to report energy performance data using SEAI's online reporting system and to report data on their business travel via a spreadsheetbased reporting template.
- · Another 3,669 schools were requested to report energy performance data via the online system as standalone entities. They were not requested to report data on business travel.

By the reporting deadline, 346 public bodies and 3,071 standalone schools had submitted energy performance data to SEAI. Some of these submissions were not fully complete and are not taken into account in the analysis of the data presented in this report. The data presented in this report is an analysis of 345 complete submissions from public bodies and 2,898 from standalone schools. The 345 complete submissions made by public bodies represents a compliance rate of 99.1%. SEAI estimates that the consumption of all of the organisations that reported represents over 99% of total public sector energy consumption.

By the reporting deadline, 283 public bodies had also submitted data on their business travel to SEAI.

Figure 3 shows the number of complete reports submitted from each subsector as a proportion of the total number of organisations in each subsector. The charts show the proportion of organisations that submitted both reports (i.e. energy and business travel) and the proportion that submitted energy reports only.

SEAI estimates that the consumption of all of the organisations that reported represents over 99% of total public sector energy consumption

## FIGURE 3: BREAKDOWN OF SUBMISSIONS BY SUBSECTOR

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Civil Service                          | Civil Service                          | 34 /uniF6AE 22+12/uniF6AF OUTOF 34   |
|----------------------------------------|----------------------------------------|--------------------------------------|
| Commercial State Bodies                | Commercial State Bodies                | 28 /uniF6AE 25+3/uniF6AF OUTOF 28    |
| Education (excl. schools and ETBs)     | Education (excl. schools and ETBs)     | 51 /uniF6AE 40+11/uniF6AF OUTOF 52   |
| ETBs                                   | ETBs                                   | 16 OUTOF 16                          |
| Health                                 | Health                                 | 67 /uniF6AE 54+13/uniF6AF OUTOF 68   |
| Justice and Defence                    | Justice and Defence                    | 6 /uniF6AE 5+1/uniF6AF OUTOF 6       |
| Local Authorities and Water Services   | Local Authorities and Water Services   | 32 /uniF6AE 31+1/uniF6AF OUTOF 32    |
| Non-commercial State Body/State Agency | Non-commercial State Body/State Agency | 111 /uniF6AE 90+21/uniF6AF OUTOF 112 |
| Standalone Schools                     | Standalone Schools                     | 2,898 OUTOF 3,669                    |
| Bothreports                            | Energyreportonly                       | Noreport                             |

<!-- image -->

<!-- image -->

- 10 The number of public sector organisations that are required to report in Ireland may change each year due to organisational changes in line with government policy and legislation.
- 11 The facilities under the aegis of the ETBs, including over 250 schools, were requested to report via their ETBs.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 3. Energy Consumption and Emissions

The data presented in section 3 is based on the complete reports submitted by 345 public bodies and 2,898 schools 12 .

## Final energy and primary energy

## 3.1 Total energy consumption and emissions

The total energy consumption reported for 2021 was 7,107 GWh of final energy, which was equivalent to 9,787 GWh of primary energy.

This energy consumption gave rise to 1,782,000 tonnes of energy-related GHG 13 emissions in 2021, expressed as 1,782 kilotonnes of CO2 (ktCO2). SEAI estimates that the public sector energy spend amounted to €728 million in 2021.

The subsectoral breakdowns of these totals are shown in Table 1 and the breakdown of final energy consumption is shown in Figure 4.

Final energy consumption or total final consumption (TFC) is the energy used by public sector organisations and other final consuming sectors of the economy, e.g. industry, transport, residential, etc. It excludes the energy used in the energy sector, e.g. for electricity generation, oil refining, etc.

Primary energy or total primary energy requirement (TPER) accounts for energy that is consumed and/or lost in transformation, transmission and distribution processes. It is calculated by applying primary energy conversion factors, which vary by fuel type, to final energy consumption values.

Previous iterations of this report focussed on primary energy only because the 2020 energy efficiency target was tracked on the basis of primary energy. The 2030 energy efficiency target is also tracked on this basis.

This report presents final and primary energy data, with all tables and charts being labelled final or primary. The reason for the inclusion of final energy is to make the interpretation of greenhouse gas emissions data more intuitive, when evaluated alongside energy consumption data.

## TABLE 1: BREAKDOWN OF 2021 ENERGY USE BY SUBSECTOR

|                                          | Final energy consumption   | Primary energy consumption   | Total energy-related GHGs   | Energy spend total   |
|------------------------------------------|----------------------------|------------------------------|-----------------------------|----------------------|
| Subsector                                | GWh                        | GWh                          | ktCO2                       | €M                   |
| Civil Service                            | 244                        | 357                          | 67                          | 24                   |
| Commercial State Body                    | 2,450                      | 3,024                        | 501                         | 280                  |
| Education (excl. Schools & ETBs)         | 490                        | 714                          | 131                         | 42                   |
| Health                                   | 1,349                      | 1,826                        | 350                         | 109                  |
| Justice & Defence                        | 411                        | 532                          | 108                         | 40                   |
| Local Authorities &Water Services        | 1,343                      | 2,191                        | 402                         | 159                  |
| Non-commercial State Body / State Agency | 284                        | 409                          | 80                          | 31                   |
| Schools & ETBs                           | 536                        | 733                          | 142                         | 44                   |
| Total                                    | 7,107                      | 9,787                        | 1,782                       | 728                  |

- 12 All of the values presented in this report for energy (GWh), expenditure (€ millions) and GHG emissions (ktCO₂) have been rounded. There are minor rounding differences in some of the tabular data.
- 13 All greenhouse gas emissions data presented in this report are energy-related emissions.

<!-- image -->

<!-- image -->

## FIGURE 4: BREAKDOWN OF 2021 FINAL ENERGY CONSUMPTION BY SUBSECTOR

<!-- image -->

- Civil Service
- Commercial State Body
- Local Authorities &amp; Water Services
- Education (excl. Schools &amp; ETBs)
- Health
- Justice &amp; Defence
- Non-commercial State Body/State Agency
- Schools &amp; ETBs

## 3.2 Energy consumption and emissions by energy type

Breakdowns of the 2021 final energy consumption, the 2021 primary energy consumption and the 2021 greenhouse gas emissions by energy type are provided in Table 2. These breakdowns are also illustrated in Figure 5 (final energy), Figure 6 (primary energy) and Figure 7 (energy-related emissions).

While the three charts show broadly similar breakdowns, there are several notable differences between them:

- · Electricity accounted for one third of final energy consumption in 2021, but 46% of primary energy and 47% of GHG emissions. This is because the amount of primary energy required to supply an average unit of final energy and the amount of greenhouse gas emissions per unit of final energy were both proportionately higher for electricity than for other energy types. This has been the case for electricity for many decades. However, the primary energy intensity and greenhouse gas intensity of electricity have both been trending generally downwards since the late 1990s and are expected to continue to do so as Ireland decarbonises its electricity system in accordance with climate targets for 2030 and beyond.
- · Renewable heat and renewable transport fuels accounted for 11% of final energy consumption in 2021, but because their use does not give rise to greenhouse gas emissions, they did not account for any of the emissions shown in Figure 7.
- · Oil (transport fuels and heating oils) accounted for a similar proportion of final energy consumption (31%) and GHG emissions (32%) in 2021, whereas natural gas accounted for 24% of consumption but only 19% of emissions. This is because the use of diesel and heating oils give rise to more emissions per unit of energy than natural gas does.

The primary energy intensity and greenhouse gas intensity of electricity have both been trending generally downwards since the late 1990s and are expected to continue to do so as Ireland decarbonises its electricity system in accordance with climate targets for 2030 and beyond

## TABLE 2: BREAKDOWN OF 2021 ENERGY USE BY ENERGY TYPE

| Subsector                   | Final energy consumption GWh   | Primary energy consumption GWh   | Total energy- related GHGs ktCO2   |
|-----------------------------|--------------------------------|----------------------------------|------------------------------------|
| Electricity                 | 2,334                          | 4,498                            | 828                                |
| Natural gas                 | 1,676                          | 1,863                            | 343                                |
| LPG                         | 103                            | 116                              | 24                                 |
| Heating oils                | 436                            | 488                              | 114                                |
| Solid fossil fuels          | 0                              | 0                                | 0                                  |
| Renewable heat              | 700                            | 778                              | 0                                  |
| Transport fuels (fossil)    | 1,795                          | 1,974                            | 455                                |
| Transport fuels (renewable) | 63                             | 69                               | 0                                  |
| Total                       | 7,107                          | 9,787                            | 1,764                              |

## FIGURE 5: BREAKDOWN OF 2021 FINAL ENERGY CONSUMPTION BY ENERGY TYPE

<!-- image -->

## FIGURE 6: BREAKDOWN OF 2021 PRIMARY ENERGY CONSUMPTION BY ENERGY TYPE

<!-- image -->

## FIGURE 7: BREAKDOWN OF 2021 ENERGYRELATED GHGS BY ENERGY TYPE

<!-- image -->

<!-- image -->

<!-- image -->

## 3.3 Energy consumption and emissions by end-use

Further breakdowns of final energy consumption, primary energy consumption and greenhouse gas emissions in 2021 are provided in Table 3. The breakdown of the 7,107 GWh of final energy consumption by end-use is also illustrated in Figure 8. These breakdowns are not definitive because unlike all other breakdowns provided in this report, they are not solely based on data directly reported to SEAI by public bodies and schools 14 .

Altogether, buildings accounted for 44-50% of the energy consumed 15 , with transport accounting for 28%.

## FIGURE 8: BREAKDOWN OF 2021 FINAL ENERGY CONSUMPTION BY END USE

<!-- image -->

- Office buildings
- Water services
- Healthcare buildings
- School buildings
- Third level &amp; other eduction buildings
- Other or unknown buildings
- Heating (unknown application)
- Industrial processes &amp; specialised applications
- Electricity (unkown application)
- Rail transport
- Marine transport

Air transport

- Plant &amp; machinery
- Public lighting
- Road transport

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## TABLE 3: ESTIMATED BREAKDOWN OF 2021 ENERGY USE BY END-USE

|                                                 | Final energy consumption   | Primary energy consumption   | Total energy- related GHGs   |
|-------------------------------------------------|----------------------------|------------------------------|------------------------------|
| End-use                                         | GWh                        | GWh                          | ktCO2                        |
| Office buildings                                | 445                        | 699                          | 128                          |
| Healthcare buildings                            | 1,241                      | 1,705                        | 324                          |
| School buildings                                | 528                        | 721                          | 140                          |
| Third level & other eduction buildings          | 414                        | 609                          | 112                          |
| Other or unknown buildings                      | 496                        | 717                          | 132                          |
| Heating (unknown application)                   | 207                        | 225                          | 34                           |
| Public lighting                                 | 185                        | 360                          | 66                           |
| Water services                                  | 489                        | 926                          | 170                          |
| Industrial processes & specialised applications | 931                        | 1,220                        | 96                           |
| Electricity (unknown application)               | 215                        | 381                          | 75                           |
| Rail transport                                  | 540                        | 667                          | 144                          |
| Marine transport                                | 69                         | 76                           | 18                           |
| Air transport                                   | 48                         | 52                           | 12                           |
| Plant & machinery                               | 133                        | 147                          | 35                           |
| Road transport                                  | 1,165                      | 1,282                        | 297                          |
| Total                                           | 7,107                      | 9,787                        | 1,782                        |

## 3.4 Energy consumption and emissions by subsector and mode

The energy consumption patterns in the different subsectors are illustrated in Table 4 and Figure 9

## TABLE 4: BREAKDOWN OF 2021 FINAL ENERGY CONSUMPTION BY SUBSECTOR &amp; MODE

|                                          | Final energy consumption   | Final energy consumption   | Final energy consumption   |
|------------------------------------------|----------------------------|----------------------------|----------------------------|
| Subsector                                | Thermal GWh                | Transport GWh              | Electricity GWh            |
| Civil Service                            | 100                        | 41                         | 103                        |
| Commercial State Body                    | 790                        | 1,251                      | 409                        |
| Education (excl. Schools & ETBs)         | 282                        | 3                          | 206                        |
| Health                                   | 877                        | 80                         | 391                        |
| Justice & Defence                        | 153                        | 163                        | 94                         |
| Local Authorities &Water Services        | 271                        | 219                        | 853                        |
| Non-commercial State Body / State Agency | 72                         | 98                         | 114                        |
| Schools & ETBs                           | 372                        | 2                          | 163                        |
| Total                                    | 2,916                      | 1,858                      | 2,334                      |

## FIGURE 9: BREAKDOWN OF 2021 FINAL ENERGY CONSUMPTION BY SUBSECTOR &amp; MODE

<!-- image -->

The greenhouse gas emissions arising from the energy consumption in these subsectors is illustrated in Table 5 and Figure 10.

## TABLE 5: BREAKDOWN OF 2021 GREENHOUSE GAS EMISSIONS BY SUBSECTOR &amp; MODE

|                                          | GHGs          | GHGs            | GHGs              |
|------------------------------------------|---------------|-----------------|-------------------|
| Subsector                                | Thermal ktCO2 | Transport ktCO2 | Electricity ktCO2 |
| Civil Service                            | 20            | 11              | 37                |
| Commercial State Body                    | 36            | 320             | 145               |
| Education (excl. Schools & ETBs)         | 58            | 1               | 73                |
| Health                                   | 191           | 20              | 139               |
| Justice & Defence                        | 33            | 42              | 33                |
| Local Authorities &Water Services        | 44            | 55              | 303               |
| Non-commercial State Body / State Agency | 15            | 25              | 41                |
| Schools & ETBs                           | 84            | 0               | 58                |
| Total                                    | 481           | 473             | 828               |

## FIGURE 10: BREAKDOWN OF 2021 GREENHOUSE GAS EMISSIONS BY SUBSECTOR &amp; MODE

<!-- image -->

<!-- image -->

<!-- image -->

## 3.5 Main energy consumers

Altogether, the total final energy consumption in 2021 of the ten largest energy consumers was 3,933 GWh, which accounted for 55% of total reported consumption. The 100 largest energy consumers that reported accounted for 88% of the total reported consumption.

## FIGURE 11: BREAKDOWN OF MAIN ENERGY CONSUMERS IN 2021

<!-- image -->

## 3.6 Change in energy consumption and emissions since 2020

Overall, final energy consumption in the public sector increased by 234 GWh, or 3%, between 2020 and 2021, with thermal energy increasing by 4%, transport by 5% and electricity by 1%. This followed a 7% reduction in consumption between 2019 and 2020, which was by far the largest annual change in aggregate consumption recorded by SEAI since it began tracking energy use via the M&amp;R process. It is likely that the increase in 2021 was due, at least in part, to a rebound in consumption following the lifting of some COVID-19 restrictions 16 .

Figure 12 shows the changes in final electricity, thermal and transport consumption between 2020 and 2021, broken down by subsector. Final consumption increased in all subsectors except for non-commercial state bodies / state agencies, which decreased by 1%.

Final energy consumption increased by 3% across the public sector between 2020 and 2021

<!-- image -->

- 16 Although COVID-19 caused reductions in energy use in most public bodies, it is important to note that the pandemic affected the underlying drivers of energy use differently in different organisations.

Greenhouse gas emissions also increased between 2020 and 2021, with thermal emissions increasing by 2% and transport emissions by 6%. Even though electricity consumption only increased by 1%, electricity emissions increased by 21%, because the emission intensity of Ireland's electricity system increased by 19% between 2020 and 2021 17 . Together, thermal and transport emissions - or non-electricity emissions - increased by 4%.

Figure 13 shows the changes in greenhouse gas emissions arising from electricity, thermal and transport consumption between 2020 and 2021 in the different subsectors. Nonelectricity emissions increased in all subsectors except for health and non-commercial state bodies / state agencies, which both decreased by 1%. Electricity emissions and total emissions increased in all subsectors.

Electricity emissions increased by 21%, even though electricity consumption only increased by 1%, because the emission intensity of Ireland's electricity system increased by 19% between 2020 and 2021.

## FIGURE 13: CHANGE IN GREENHOUSE GAS EMISSIONS BY SUBSECTOR 2020-2021

<!-- image -->

<!-- image -->

<!-- image -->

## 4. Energy Efficiency Target

## 4.1 Progress towards 2030 energy efficiency target

The combined improvement in energy efficiency in 2021 of the public bodies and schools that submitted complete reports is equivalent to 31% 18 . This is the primary indicator used for tracking the sector's performance against the 50%-by-2030 energy efficiency target. This improvement is equivalent to 4,353 GWh of avoided primary energy consumption 19 .

The graph in Figure 14 tracks how the total savings achieved in each year since 2009 compare to the 2030 target 20 . It shows how the result for 2021 (31%) is a deterioration from 2020 (34%). Contributory factors to this include a rebound in energy consumption following the lifting of some COVID-19 restrictions and a significant increase in Ireland's primary energy conversion factor for electricity between 2020 and 2021 17 .

## FIGURE 14: IMPROVEMENT IN ENERGY EFFICIENCY

<!-- image -->

## 4.2 Energy efficiency by subsector

The breakdown of avoided energy consumption (primary) and percentage improvement in energy efficiency by subsector is set out in Table 6. The bar chart in Figure 15 illustrates percentage savings for each subsector.

## TABLE 6: ENERGY EFFICIENCY BY SUBSECTOR

| Subsector                                | Avoided energy consumption (primary) GWh   | Change in energy performance indicator %   | Gap to target %   |
|------------------------------------------|--------------------------------------------|--------------------------------------------|-------------------|
| Civil Service                            | 229                                        | -39%                                       | -11%              |
| Commercial State Body                    | 1,257                                      | -29%                                       | -21%              |
| Education (excl. Schools & ETBs)         | 572                                        | -44%                                       | -6%               |
| Health                                   | 434                                        | -19%                                       | -31%              |
| Justice & Defence                        | 180                                        | -25%                                       | -25%              |
| Local Authorities &Water Services        | 1,190                                      | -38%                                       | -12%              |
| Non-commercial State Body / State Agency | 256                                        | -40%                                       | -10%              |
| Schools & ETBs                           | 235                                        | -24%                                       | -26%              |
| Total                                    | 4,353                                      | -31%                                       | -19%              |

18 The calculation of these results incorporates adjustments to the business-as-usual consumption for local authorities to account for the transition of water services to Irish Water.

19 Calculated by subtracting each organisation's actual 2021 primary energy consumption from its business-as-usual primary energy consumption. The business-as-usual consumption is the amount that each public body would have consumed in 2021 had it not made the reported efficiency gains since its energy efficiency baseline.

20 This chart, and other equivalent charts in this report, present improvements in energy efficiency as reductions in an energy performance indicator, i.e. negative values indicate savings. Previous iterations of this report adopted the opposite convention. The reason for the change to presenting improvements as negative values is to make the interpretation of results for energy efficiency more intuitive, when combined with the greenhouse gas emissions savings shown elsewhere in the report. Emissions savings are all shown as reductions.

## FIGURE 15: PROGRESS TOWARDS ENERGY EFFICIENCY TARGET BY SUBSECTOR

<!-- image -->

Improvement since baseline

Target

<!-- image -->

<!-- image -->

## 5. Greenhouse Gas Emissions Targets

## 5.1 Two 2030 targets

The energy consumption reported for the public sector for 2021 was equivalent to 1,782 ktCO2 of energy-related greenhouse gas emissions. This comprised 954 ktCO2 of nonelectricity emissions and 828 ktCO2 of electricity emissions.

Every public sector organisation has two greenhouse gas emissions reduction targets for 2030 - a non-electricity emissions target and a total emissions target. Both are summarised in the boxed text.

## 5.2 Progress towards non-electricity emissions target

Figure 16 shows the actual non-electricity emissions from the sector since 2013, split between thermal and transport. The emissions profile has shown little change since 2013.

The chart also shows the non-electricity emissions baseline calculated for the sector, which is 981 ktCO2. On this basis, the public sector must reduce its non-electricity emissions by 500 ktCO2 from its baseline to achieve a 2030 target of 481 ktCO2 22 . By 2021, the sector's non-electricity emissions had only decreased by just 27 ktCO2, or 3%, since the baseline.

## 2030 greenhouse gas emissions targets key methodology points

- · Every public sector organisation has two emissions reduction targets for 2030.
- · Both are calculated on the basis of absolute reductions in emissions from an organisation's greenhouse gas baseline period, i.e. there is no adjustment for changes in activity levels, service levels or demographics.
- · The baseline period for both emissions targets is 2016-2018 (average).
- · The first target applies to the organisation's nonelectricity emissions: every organisation must reduce its non-electricity emissions by 51% by 2030.
- · The second target applies to the organisation's total energy-related emissions: every organisation's total emissions target for 2030, in tonnes, equals its nonelectricity emissions target for 2030 plus its electricity emissions at its greenhouse gas baseline less the projected supply-side emissions reduction from electricity by 2030, in tonnes.

Each public body's emissions baselines and targets are included in section 6 21 . The calculations underpinning each public body's targets, and explanatory charts, are available to download by public bodies in spreadsheet format from the M&amp;R system.

The public sector must reduce its nonelectricity emissions by 500 ktCO2 from its baseline to achieve a 2030 target of 481 ktCO2. By 2021, the sector's non-electricity emissions had only decreased by just 27 ktCO2, or 3%, since the baseline.

This methodology is described in detail in SEAI's M&amp;R2030 methodology guidance document.

21 These baseline and target calculations are based on the data reported to SEAI during the 2021 reporting cycle.  The calculated values will be refined as better data becomes available.

22 This baseline and target calculation is based on the data reported to SEAI during the 2021 reporting cycle.  The calculated values will be refined as better data becomes available.

## FIGURE 16: NON-ELECTRICITY GREENHOUSE GAS EMISSIONS - SINCE 2013, GHG BASELINE AND TARGET

<!-- image -->

The distribution of changes in non-electricity emissions since the greenhouse gas baseline is shown in Figure 17. 171 of the 345 public bodies that reported data to SEAI 23 had reduced their emissions by 2021, with 142 having increased their emissions. 32 public bodies had zero non-electricity emissions at their greenhouse gas baselines 24 .

## FIGURE 17: NON-ELECTRICITY GREENHOUSE GAS EMISSIONS - DISTRIBUTION OF CHANGES SINCE GHG BASELINE

<!-- image -->

- 23 Schools are not shown in this chart.
- 24 These are typically smaller office-based organisations that only use electricity, including for heating.

<!-- image -->

<!-- image -->

Each subsector's progress towards the non-electricity emissions target is shown in Figure 18 as a percentage change in its non-electricity emissions since the greenhouse gas baseline.  The figure also shows each subsector's relative share of 2021 emissions.

## FIGURE 18: PROGRESS TOWARDS NON-ELECTRICITY EMISSIONS TARGET BY SUBSECTOR

<!-- image -->

## 5.3 Progress towards total emissions target

The second emissions target encompasses electricity emissions as well as non-electricity emissions. Figure 19 shows the actual total emissions since 2013, broken down between electricity, thermal and transport. The decrease in total emissions since 2013 is mainly due to the decarbonisation of Ireland's electricity supply, i.e. the reduction is because the electricity system has become ' cleaner' between the baseline period and 2021, although the emissions intensity of Ireland's electricity system increased significantly between 2020 and 2021.

The total emissions baseline calculated for the sector is 2,075 ktCO2. On this basis, the public sector must reduce its total emissions by 1,347 ktCO2, or approximately 65% 25 , from its baseline level to achieve its total emissions target of 728 ktCO2 by 2030. SEAI anticipates that electricity supply-side decarbonisation will result in a 847 ktCO2 reduction between the baseline and 2030 26 . By 2021, the sector's total emissions had decreased by 293 ktCO2, or 14%, since the baseline.

25 This is the aggregate percentage reduction for the entire public sector.  The percentage reduction required by each public sector organisation to achieve its total emissions target is dependent on the makeup of its energy use at its greenhouse gas baseline.  Each organisation's baseline and target calculation is available to download in spreadsheet format from the M&amp;R system.

26 SEAI estimates Ireland's electricity network could decarbonise by 77% between 2016-18 (average) and 2030 - as fossil fuels are phased out of power generation.

## FIGURE 19: TOTAL GREENHOUSE GAS EMISSIONS - SINCE 2013, GHG BASELINE AND TARGET

<!-- image -->

Each subsector's progress towards the total emissions target is shown in Figure 20 as a percentage change in its total emissions since the greenhouse gas baseline. The figure also shows each subsector's relative share of 2021 emissions.

The percentage reduction required by each subsector to achieve its aggregate total emissions target is different.

The percentage is dependent on the types of energy used by each subsector at the greenhouse gas baseline. This accounts for the fact that subsectors with higher proportions of baseline energy consumption from electricity can expect to benefit from more supply-side emissions reductions than those with higher proportions of fossil fuels, and vice versa 27 .

<!-- image -->

<!-- image -->

<!-- image -->

## 5.4 Business travel

The energy consumption associated with business travel 28 is not within the scope of the 2030 energy efficiency target or the 2030 emissions targets. However, public bodies are obliged to report annual data on business travel to SEAI for the years 2021 onwards.

The data presented in section 5.4 is based on submissions received from 283 public bodies.

Altogether, these public bodies reported over 185 million kilometres of business travel by private road vehicle in 2021. Figure 21 provides a breakdown of this travel by subsector.

## FIGURE 21: SECTORAL BREAKDOWN OF BUSINESS TRAVEL BY PRIVATE ROAD VEHICLE

<!-- image -->

- Civil Service
- Commercial State Body
- Local Authorities &amp; Water Services
- Education (excl. Schools &amp; ETBs)
- Health
- Non-commercial State Body/State Agency
- Schools &amp; ETBs
- Justice &amp; Defence

The 283 public bodies also reported 15,743 individual flight segments in 2021.  Figure 22 provides a breakdown of these flights by subsector.

## FIGURE 22: SECTORAL BREAKDOWN OF BUSINESS TRAVEL BY AIR (NO. FLIGHTS)

<!-- image -->

- Civil Service
- Commercial State Body
- Local Authorities &amp; Water Services
- Education (excl. Schools &amp; ETBs)
- Health
- Non-commercial State Body/State Agency
- Schools &amp; ETBs
- Justice &amp; Defence

Public bodies were also requested to report data on the number of kilometres travelled by different modes of commercial and public transport in 2021. Unlike data for travel by private road vehicle and commercial airline, which are generally recorded by public bodies for other purposes 29 , data on distances travelled by other forms of transport are not generally readily available to organisations. SEAI recognises that there is a trade-off between the level of effort required to gather this data and the value of the data. Public bodies are encouraged to focus on gathering robust data for the modes of travel by commercial and public transport that are likely to be most material to their organisation's emissions from business travel. For this reason, SEAI believes that the data reported by the 283 public bodies for travel by commercial and public transport in 2021 is likely to be an underestimate of actual travel.

28 Business travel occurs when people travel from one place of work to another place of work as part of their work duties.  It does not include travel to and from a person's normal place of work, i.e. commuting. This is a person's own private travel and is not a business journey.

29 For example, records of distances travelled by private road vehicle are retained for reimbursing staff expenses.

Figure 23 provides a breakdown of the travel that was reported, in passenger-kilometres, by subsector.

## FIGURE 23: SECTORAL BREAKDOWN OF BUSINESS TRAVEL BY COMMERCIAL &amp; PUBLIC TRANSPORT

<!-- image -->

- Civil Service
- Commercial State Body
- Local Authorities &amp; Water Services
- Education (excl. Schools &amp; ETBs)
- Health
- Justice &amp; Defence
- Non-commercial State Body/State Agency
- Schools &amp; ETBs

Figure 24 provides a breakdown of the same data by mode of public transport.

## FIGURE 24: MODE BREAKDOWN OF BUSINESS TRAVEL BY COMMERCIAL &amp; PUBLIC TRANSPORT

<!-- image -->

<!-- image -->

<!-- image -->

## Making Progress

The data submitted demonstrates savings achieved through the implementation of thousands of efficiency measures. 23% of the measures reported addressed lighting, 12% were heating projects, 9% upgraded building fabric and 12% related to structured energy management improvements. Projects in schools accounted for a further 23%. The projects illustrated on these pages are a selection of the 5,100 projects that were reported to SEAI in 2021. While the overall level of project reporting is improving, many of the measures are still relatively small scale.

## 137,000 kWh

## Technological University of the Shannon (TUS)

<!-- image -->

In 2021, as part of a wider energy efficiency upgrade project, TUS installed a 166 kWp solar photovoltaic (PV) system on the main building at its Moylish Campus, Limerick. The system generates renewable electricity on campus and reduces the demand from the grid by 137,000 kWh annually. A total of 370 PV panels were installed on a 10-degree tilted ballast mounting framework. The installation covers 740 m  across 2 7 roof sections of the building. The electricity generated by this renewable system provided up to 21% of total electricity consumption for the building during its peak generation month last August.

<!-- image -->

<!-- image -->

<!-- image -->

## 500,000 kgCO/uniF645

## ESB

The ESB carried out a deep retrofit on its Finglas depot in 2021. A new high efficiency direct expansion air conditioning system was installed, utilising heat pump technology. The works included replacement of all air handling units (AHUs), ductwork, electric heaters, batteries, and end of life variable air volume (VAV) units. The system is supplemented by new heating and cooling controls and incorporates the latest heat recovery technology. In addition, all internal and external luminaires were upgraded to more energy efficient LED lighting. The project is expected to deliver an annual 1,000,000 kWh energy reduction against a 2018 baseline, avoiding approximately 500,000 kgCO2 per annum.

<!-- image -->

## 69,000 kgCO/uniF645

## Wicklow County Council

A 300 kWp solar car port was installed in 2021 at Wicklow County Council's headquarters in Wicklow Town, generating renewable energy for use in the council's buildings. The innovative project makes use of the available space at the site and is the largest solar car port in Ireland, covering 107 car parking spaces and approximately 1,600 m 2 in surface area. The project has resulted in avoiding an equivalent of over 69,000 kgCO2 of emissions and is supporting the council in achieving its climate action targets.

<!-- image -->

<!-- image -->

## 34,000 kgCO/uniF645

National Transport Authority / Bus Éireann

In July 2021, three of the world's first double-decker hydrogen fuel-cell-electric buses were purchased by the National Transport Authority (NTA) and brought into service on Bus Éireann's route between Dublin and Ratoath, Co Meath. The three buses collectively completed over 40,000 km by the end of 2021, using just over 2,300 kg of hydrogen in the fuel cells to charge the main electric drivetrain batteries. Conventional diesel buses would have consumed approximately 13,000 litres of diesel to complete the same mileage on the same routes. This equates to approximately 34,000 kgCO2 of avoided emissions by the three buses in less than 5 months. During the pilot phase, the technology has proven to be extremely reliable, and the hydrogen consumption has remained within the expected consumption profile. Passenger and driver feedback have also been very positive with respect to the environmental benefits, lower noise levels, safety and performance of the buses.

<!-- image -->

## €98,000

## Dún Laoghaire-Rathdown County Council

Dún Laoghaire-Rathdown County Council facilitated dlr Leisure to sign an Energy Performance Contract (EPC) in 2021 for energy efficiency projects at Meadowbrook, Loughlinstown and Monkstown Leisure Centres. The works included the installation of a new combined heat and power (CHP) system, along with upgrades to existing external lighting and improved building management and heating, ventilation and pool filtration systems. The contract is intended to run for eight years, with projected energy savings of 1,500,000 kWh and 318,000 kgCO2 per annum, which represents 24% of total energy consumption. The total cost savings are expected to be over €98,000 per year, a cost reduction of 31%.

## Department of Social Protection

<!-- image -->

In June 2021, the Department of Social Protection became the first government department to achieve ISO 50001 certification for its energy management system. The Department has undertaken various projects to optimise energy performance, such as upgrading lighting systems to LEDs, installing more efficient heating and cooling systems, and retrofitting buildings. Where possible, office locations have been consolidated to reduce energy consumption. Green teams were also set up to promote staff awareness and educate on sustainability issues. Energy consumption decreased by 6% in 2021 with savings of over 1,398,000 kWh compared to 2020.

<!-- image -->

<!-- image -->

## 113,000 kWh

<!-- image -->

## Cornafulla National School

Cornafulla National School was selected through the 2021 Public Sector Pathfinder Programme to undergo a deep retrofit. The upgrades target a Building Energy Rating of B, 50% energy efficiency improvement, and 50% emissions reduction. The fabric works included pumped wall cavity, external wall and attic insulation, replacement of doors and windows and improved air tightness. New radiators were fitted throughout with room thermostats and a building management system (BMS) system provides high levels of control. Mechanical ventilation with heat recovery units were also installed. The heating system includes two new heat pumps with a supplementary gas boiler used as backup when required. The new LED lighting system includes occupancy and daylight control. Solar photovoltaic (PV) panels and electric vehicle charging points have also been installed. The project has estimated energy savings of 113,000 kWh per annum, equivalent to 29,000 kgCO2 emissions savings.

<!-- image -->

## St James's Hospital

In late 2020, St James's Hospital signed a new energy performance contract (EPC), supported by the Carbon and Energy Fund Ireland (CEFI). The contract will deliver €26 million in guaranteed energy and operational savings over 20 years, with an expected reduction of 6,000,000 kgCO2 emissions per annum. By the end of 2021, the EPC facilitated completion of a deep retrofit programme to include conversion of the thermal distribution from a steam-based system to a low temperature hot water (LTHW) heating scheme, installation of a new 2 MWe combined heat and power (CHP) system, 7.5 MWh of LTHW boilers, fibre optic building management system (BMS) with 80 outstations, 20 new air handling units (AHUs), 2 new central chillers, approximately 10,000 LED light conversions, 170 high efficiency pumps and 30 low energy air conditioning (AC) replacements. These works build the foundation for further de-carbonisation projects into the future.

<!-- image -->

<!-- image -->

## 6. Towards 2030

## 6.1 Departmental group performance

The analysis of the data reported by 345 public bodies and 2,898 schools shows that the annual energy efficiency savings at 2021 represents an overall efficiency gain of 31.5% since the energy efficiency baseline. By 2021, non-electricity greenhouse gas emissions had decreased by 2.7% since the greenhouse gas baseline, while total emissions had decreased by 14.1%.

Figure 25 illustrates the 2021 position of each departmental group with respect to the 2030 energy efficiency and greenhouse gas reduction targets.

## Additional detailed data

Additional detailed data for the departmental groups is provided in tabular format in Appendix 1.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 6.2 Performance of public bodies

SEAI recognises that building complete energy and emissions profiles for organisations is an iterative process that will take time as public bodies are in a better position to submit improved data each year. This work is ongoing.

SEAI continues to work with public bodies and schools to improve the quality of their data through the provision of guidance materials, training and bespoke support services.

The public bodies and schools are listed as follows:

## Public bodies (excluding standalone schools)

The 345 30 public bodies that made a complete submission to SEAI by the deadline are alphabetically listed in section 6.2.1. Each listing comprises the following elements:

- · The public body's energy consumption in 2021 and its energy performance result for 2021. The performance result is presented alongside the energy saving values for all years since the public body's energy efficiency baseline. This indicates the extent to which each public body's 2021 performance may have deviated from established trends arising from the impacts of the pandemic.
- · The public body's non-electricity greenhouse gas emissions at its GHG baseline and in 2021, its 2030 target value and its change in non-electricity emissions since its baseline 31 . The annual change in non-electricity emissions for all years since the public body's GHG baseline is also indicated.
- · The public body's total greenhouse gas emissions at its GHG baseline and in 2021, its 2030 target value and its change in total emissions since its baseline 31 . The annual change in total emissions for all years since the public body's GHG baseline is also indicated.
- · Additional SEAI notes on the data submitted.

30 Including ETBs but excluding standalone schools.

## Non-reporting Public Bodies

The public bodies that did not report are listed alphabetically in section 6.2.2.

## Standalone Schools

The 2,898 standalone schools that made complete submissions to SEAI by the deadline account for 5% of total reported energy consumption. They are listed in an annex to this report, which is available at www.seai.ie/ publicsectorreport.

## Additional Detailed Data

SEAI publishes public sector energy data online, including detailed organisation-level energy consumption and performance data, and a database of energy-saving projects. This is available at www.seai.ie/publicsectorreport.

## 6.2.1 Public bodies (excluding schools)

## LIST OF PUBLIC BODIES THAT REPORTED

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|--------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                      | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |
| Public Body                          | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             |                              | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |
| AbbeyTheatre                         | 1.5                     | 2.0                     | -50%                 | +25%                              | 167.9                        | 209.1                        | 82.3                         | +25%                         |                                   | 419.9                      | 370.4                      | 139.3                      | -12%                              |
| Ability West                         | 3.0                     | 3.9                     | -50%                 | -2%                               | 417.3                        | 593.4                        | 204.5                        | +42%                         |                                   | 613.4                      | 833.1                      | 248.0                      | +36%                              |
| Adoption Authority of Ireland        | <0.1                    | 0.2                     | -50%                 | -47%                              | 0.0                          | 0.0                          | 0.0                          |                              |                                   | 37.4                       | 31.7                       | 8.5                        | -15%                              |
| AHEAD                                | <0.1                    | <0.1                    | -50%                 | -47%                              | 0.9                          | 0.8                          | 0.4                          | -11%                         |                                   | 1.9                        | 1.3                        | 0.7                        | -30%                              |
| An Bord Pleanála                     | 0.5                     | 0.9                     | -50%                 | -53%                              | 0.0                          | 0.0                          | 0.0                          |                              |                                   | 215.0                      | 163.5                      | 48.7                       | -24%                              |
| An Foras Teanga -Foras na Gaeilge    | 0.4                     | 0.6                     | -50%                 | -30%                              | 46.6                         | 43.4                         | 22.8                         | -7%                          |                                   | 141.8                      | 115.2                      | 44.5                       | -19%                              |
| An Foras Teanga -Ulster Scots Agency | <0.1                    | <0.1                    | -50%                 | -39%                              | 0.0                          | 0.0                          | 0.0                          |                              |                                   | 15.8                       | 10.5                       | 3.6                        | -34%                              |
| An Garda Síochána                    | 143.2                   | 190.2                   | -50%                 | -29%                              | 24,763.1                     | 25,236.9                     | 12,133.9                     | +2%                          |                                   | 41,865.7                   | 38,706.4                   | 16,001.3                   | -8%                               |
| An Post                              | 132.9                   | 162.0                   | -50%                 | -31%                              | 24,273.3                     | 27,797.1                     | 11,893.9                     | +15%                         |                                   | 32,154.0                   | 34,351.5                   | 13,668.0                   | +7%                               |
| Arts Council 2                       | <0.1                    | 0.1                     | -50%                 |                                   | 0.0                          | 0.0                          | 0.0                          |                              |                                   | 96.3                       | 27.0                       | 21.8                       | -72%                              |
| Athlone Education Centre             | <0.1                    | 0.1                     | -50%                 | +30%                              | 5.5                          | 15.1                         | 2.7                          | +177%                        |                                   | 17.7                       | 22.5                       | 5.5                        | +27%                              |
| Athlone Institute of Technology      | 6.2                     | 9.5                     | -50%                 | -41%                              | 834.2                        | 678.7                        | 408.8                        | -19%                         |                                   | 2,480.2                    | 1,717.0                    | 780.3                      | -31%                              |
| Bantry Bay Port Company DAC          | <0.1                    | <0.1                    | -50%                 | -56%                              | 1.7                          | 0.7                          | 0.8                          | -60%                         |                                   | 8.9                        | 7.0                        | 2.5                        | -22%                              |
| Beaumont Hospital                    | 43.8                    | 63.2                    | -50%                 | -12%                              | 4,910.7                      | 5,309.4                      | 2,406.2                      | +8%                          |                                   | 12,365.2                   | 11,654.0                   | 4,090.1                    | -6%                               |

- Note 2: SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                           | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|-------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                           | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |
| Public Body                               | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |
| Blackrock Education Centre                | <0.1                    | 0.1                     | -50%                 | -47%                              | 19.1                         | 12.1                         | 9.4                          | -37%                              | 35.4                       | 20.7                       | 13.1                       | -42%                              |
| Bord Bia                                  | 0.1                     | 0.3                     | -50%                 | -80%                              | 1.7                          | 0.1                          | 0.8                          | -95%                              | 102.9                      | 49.5                       | 24.0                       | -52%                              |
| Bord Iascaigh Mhara                       | 2.6                     | 3.9                     | -50%                 | +9%                               | 260.3                        | 312.6                        | 127.5                        | +20%                              | 1,052.1                    | 774.3                      | 305.4                      | -26%                              |
| Bord na Móna plc 6                        | 62.5                    | 48.3                    | -50%                 | -56%                              | 14,888.1                     | 12,998.8                     | 7,295.2                      | -13%                              | 20,326.5                   | 17,068.3                   | 8,528.2                    | -16%                              |
| Broadcasting Authority of Ireland         | 0.2                     | 0.2                     | -50%                 | -46%                              | 19.3                         | 20.0                         | 9.5                          | +4%                               | 57.7                       | 40.7                       | 18.1                       | -29%                              |
| Brothers of Charity Services Ireland CLG  | 35.0                    | 42.7                    | -50%                 | -18%                              | 6,284.4                      | 7,714.8                      | 3,079.4                      | +23%                              | 8,160.0                    | 9,215.2                    | 3,504.4                    | +13%                              |
| Bus Éireann                               | 275.4                   | 307.1                   | -50%                 | -20%                              | 74,738.6                     | 70,377.3                     | 36,621.9                     | -6%                               | 77,025.1                   | 72,075.2                   | 37,138.3                   | -6%                               |
| Camphill Communities (Ireland)            | 6.4                     | 8.1                     | -50%                 | -19%                              | 1,098.9                      | 1,104.6                      | 538.5                        | +1%                               | 1,654.9                    | 1,514.8                    | 664.8                      | -8%                               |
| Cappagh National Orthopaedic Hospital     | 5.3                     | 7.5                     | -50%                 | -35%                              | 734.2                        | 689.3                        | 359.8                        | -6%                               | 1,578.4                    | 1,388.8                    | 550.4                      | -12%                              |
| Carlow County Council 3                   | 7.5                     | 11.4                    | -50%                 | -35%                              | 838.0                        | 863.9                        | 410.6                        | +3%                               | 2,808.7                    | 2,195.7                    | 855.7                      | -22%                              |
| Carrick-on-Shannon Education Centre       | <0.1                    | <0.1                    | -50%                 | -32%                              | 13.0                         | 11.2                         | 6.4                          | -14%                              | 23.2                       | 14.2                       | 8.7                        | -39%                              |
| Carriglea Cáirde Services                 | 2.8                     | 3.5                     | -50%                 | -29%                              | 559.3                        | 585.9                        | 274.1                        | +5%                               | 814.7                      | 754.9                      | 331.6                      | -7%                               |
| Cavan &Monaghan Education &Training Board | 6.7                     | 10.0                    | -50%                 | -36%                              | 793.2                        | 658.6                        | 388.6                        | -17%                              | 2,017.2                    | 1,680.3                    | 667.1                      | -17%                              |
| Cavan County Council 3, 6                 | 7.9                     | 12.5                    | -50%                 | -27%                              | 836.3                        | 903.2                        | 409.8                        | +8%                               | 3,219.9                    | 2,456.9                    | 948.6                      | -24%                              |

- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.
- Note 6: The scope of energy consumption counted for this public body's energy efficiency target differs from that counted for its total greenhouse gas emissions target. This is because of differences in the methodological treatment of certain electricity generation facilities for the purposes of the two targets. Any apparent inconsistencies between values shown for this public body are attributable to this.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                          | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                          | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |
| Public Body                              | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change since GHGbaseline good bad | GHG baseline tCO2          |                            | 2021 tCO2 target tCO2      | 2030                       | Change since GHGbaseline good bad |
| Central Bank of Ireland                  | 11.3                    | 17.0                    | -50%                 | -65%                              | 1,558.6                      | 1,207.4                      | 763.7                        | -23%                              | 5,520.5                    | 3,158.4                    | 1,648.8                    |                            | -43%                              |
| Central Remedial Clinic                  | 3.2                     | 4.2                     | -50%                 | -36%                              | 663.9                        | 562.6                        | 325.3                        | -15%                              | 1,148.2                    | 846.0                      | 434.8                      |                            | -26%                              |
| Central Statistics Office                | 1.9                     | 3.1                     | -50%                 | -49%                              | 192.6                        | 157.4                        | 94.4                         | -18%                              |                            | 853.0                      | 577.3                      | 242.9                      | -32%                              |
| Charities Regulator                      | <0.1                    | <0.1                    | -36%                 | -62%                              | 0.0                          | 0.0                          | 0.0                          |                                   |                            | 16.4                       | 8.6                        | 3.7                        | -47%                              |
| Cheeverstown House                       | 5.0                     | 6.4                     | -50%                 | -11%                              | 858.9                        | 862.2                        | 420.9                        | +0%                               | 1,310.0                    |                            | 1,218.4                    | 522.6                      | -7%                               |
| Cheshire Ireland                         | 4.5                     | 5.7                     | -50%                 | -19%                              | 989.3                        | 899.4                        | 484.8                        | -9%                               |                            | 1,448.1                    | 1,178.9                    | 587.9                      | -19%                              |
| Chief State Solicitor's Office           | 0.9                     | 1.4                     | -50%                 | -51%                              | 97.1                         | 105.1                        | 47.6                         | +8%                               | 351.1                      |                            | 252.9                      | 104.8                      | -28%                              |
| Children's Health Ireland (CHI)          | 36.1                    | 50.6                    | -50%                 | -5%                               | 4,730.1                      | 4,779.7                      | 2,317.7                      | +1%                               | 9,779.3                    |                            | 9,346.0                    | 3,459.5                    | -4%                               |
| Children's Sunshine Home/ Laura Lynn     | 0.8                     | 1.1                     | -50%                 | -31%                              | 147.8                        | 127.3                        | 72.4                         | -14%                              | 269.1 208.9                |                            |                            | 99.9                       | -22%                              |
| Citizens Information Board               | 0.5                     | 0.8                     | -50%                 | -35%                              | 32.7                         | 56.0                         | 16.0                         | +71%                              | 163.0                      |                            | 144.8                      | 45.8                       | -11%                              |
| City of Dublin Education &Training Board | 16.9                    | 23.8                    | -50%                 | -21%                              | 2,274.8                      | 2,234.0                      | 1,114.7                      | -2%                               | 5,558.5                    |                            | 4,439.3                    | 1,856.9                    | -20%                              |
| Clare County Council 3                   | 19.4                    | 29.3                    | -50%                 | -33%                              | 2,055.1                      | 2,262.9                      | 1,007.0                      | +10%                              | 6,645.6                    |                            | 5,616.4                    | 2,044.6                    | -15%                              |
| Clare Education Centre                   | <0.1                    | 0.1                     | -50%                 | -57%                              | 22.4                         | 17.2                         | 11.0                         | -23%                              | 38.9                       |                            | 22.6                       | 14.7                       | -42%                              |
| Cobh Community Hospital                  | 0.4                     | 0.5                     | -50%                 | +0%                               | 43.5                         | 49.0                         | 21.3                         | +13%                              | 95.7                       |                            | 94.2                       | 33.1 -1%                   |                                   |
| Coillte Teoranta                         | 879.3                   | 1,105.9                 | -50%                 | -18%                              | 30,495.0                     | 26,913.8                     | 14,942.6                     | -12%                              |                            | 95,489.1                   | 79,905.7                   | 29,631.4                   | -16%                              |
| Commission for Aviation Regulation       | 0.2                     | 0.2                     | -50%                 | -50%                              | 24.2                         | 23.6                         | 11.9                         | -2%                               |                            | 46.2                       | 36.6                       | 16.8                       | -21%                              |

<!-- image -->

<!-- image -->

<!-- image -->

|                                                                | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|----------------------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                                                | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |
| Public Body                                                    | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change                     |                            |
| Commission for Communications Regulation                       | 0.2                     | 0.4                     | -50%                 | -49%                              | 0.0                          | 0.0                          | 0.0                          |                                   | 125.1                      | 71.6                       | 28.2                       | -43%                       |                            |
| Commission for Railway Regulation                              | <0.1                    | <0.1                    | -50%                 | -76%                              | 6.2                          | 16.7                         | 3.1                          | +167%                             | 19.1                       | 16.7                       | 5.8                        | -13%                       |                            |
| Commission for the Regulation of Utilities                     | <0.1                    | 0.2                     | -50%                 | -84%                              | 0.0                          | 0.0                          | 0.0                          |                                   | 76.1                       | 30.2                       | 17.2                       | -60%                       |                            |
| Commissioners of Irish Lights                                  | 10.0                    | 12.0                    | -50%                 | -45%                              | 2,467.2                      | 2,299.5                      | 1,208.9                      | -7%                               | 3,093.2                    | 2,708.0                    | 1,350.0                    | -12%                       |                            |
| Companies Registration Office &Registrar of Friendly Societies | 0.2                     | 0.4                     | -50%                 | -58%                              | 57.1                         | 7.3                          | 28.0                         | -87%                              | 184.5                      | 74.7                       | 56.1                       | -60%                       |                            |
| Competition and Consumer Protection Commission                 | 0.2                     | 0.3                     | -50%                 | -75%                              | 22.4                         | 7.6                          | 11.0                         | -66%                              | 86.7                       | 51.9                       | 25.3                       | -40%                       |                            |
| CoombeWomen &Infants University Hospital                       | 7.2                     | 10.0                    | -50%                 | -4%                               | 959.0                        | 959.3                        | 469.9                        | +0%                               | 1,963.8                    | 1,839.7                    | 697.1                      | -6%                        |                            |
| Cope Foundation                                                | 12.3                    | 16.3                    | -50%                 | -22%                              | 2,133.5                      | 2,076.2                      | 1,045.4                      | -3%                               | 3,576.6                    | 3,130.6                    | 1,372.3                    | -12%                       |                            |
| Cork Airport                                                   | 7.5                     | 12.6                    | -50%                 | -66%                              | 806.3                        | 530.5                        | 395.1                        | -34%                              | 4,195.3                    | 2,308.9                    | 1,159.3                    | -45%                       |                            |
| Cork City Council 3, 6                                         | 34.1                    | 52.4                    | -50%                 | -54%                              | 4,052.4                      | 3,309.2                      | 1,985.7                      | -18%                              | 10,840.0                   | 10,076.1                   | 3,516.6                    | -7%                        |                            |
| Cork County Council 3                                          | 45.4                    | 70.0                    | -50%                 | -25%                              | 5,361.0                      | 5,458.6                      | 2,626.9                      | +2%                               | 19,097.6                   | 13,647.5                   | 5,726.7                    | -29%                       |                            |
| Cork Education &Training Board                                 | 13.6                    | 19.5                    | -50%                 | -24%                              | 1,994.6                      | 1,803.4                      | 977.3                        | -10%                              | 4,772.9                    | 3,655.2                    | 1,605.5                    | -23%                       |                            |
| Cork Education Support Centre                                  | <0.1                    | 0.1                     | -50%                 | +15%                              | 12.9                         | 11.4                         | 6.3                          | -12%                              | 37.1                       | 21.8                       | 11.8                       | -41%                       |                            |

- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.
- Note 6: The scope of energy consumption counted for this public body's energy efficiency target differs from that counted for its total greenhouse gas emissions target. This is because of differences in the methodological treatment of certain electricity generation facilities for the purposes of the two targets. Any apparent inconsistencies between values shown for this public body are attributable to this.

<!-- image -->

<!-- image -->

<!-- image -->

|                                                                    | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   |
|--------------------------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|----------------------------|
|                                                                    | 2021 energy consumption | 2021 energy consumption | Energy               | Energy                            | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |                            |
| Public Body                                                        | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |                            |
| CORU                                                               | 0.2                     | 0.3                     | -50%                 | -51%                              | 13.6                         | 31.2                         | 6.7                          | +129%                        | 40.7                       | 59.5                       | 12.9                       | +46%                              |                            |
| Courts Service                                                     | 23.0                    | 33.4                    | -50%                 | -26%                              | 2,671.8                      | 2,900.2                      | 1,309.2                      | +9%                          | 7,189.0                    | 6,242.1                    | 2,334.3                    | -13%                              |                            |
| Crawford Art Gallery Cork 1                                        | 1.1                     | 1.4                     | -50%                 |                                   | 93.6                         | 151.5                        | 45.9                         | +62%                         | 184.9                      | 263.3                      | 67.1                       | +42%                              |                            |
| daa plc 2                                                          | 83.6                    | 127.0                   | -50%                 | -53%                              | 9,335.1                      | 8,784.9                      | 4,574.2                      | -6%                          | 28,808.1                   | 23,573.5                   | 8,991.8                    | -18%                              |                            |
| Data Protection Commissioner                                       | 0.1                     | 0.2                     | -50%                 | -82%                              | 8.5                          | 6.2                          | 4.2                          | -28%                         | 57.8                       | 36.9                       | 15.5                       | -36%                              |                            |
| Daughters of Charity - Child &Family Services                      | 0.7                     | 0.9                     | -50%                 | +0%                               | 62.0                         | 107.2                        | 30.4                         | +73%                         | 141.5                      | 161.6                      | 48.4                       | +14%                              |                            |
| Daughters of Charity - Intellectual Disability Services            | 15.4                    | 19.9                    | -50%                 | -13%                              | 2,391.4                      | 2,520.5                      | 1,171.8                      | +5%                          | 3,976.7                    | 3,701.8                    | 1,529.5                    | -7%                               |                            |
| Defence Forces                                                     | 182.0                   | 224.5                   | -50%                 | -27%                              | 46,621.4                     | 36,913.0                     | 22,844.5                     | -21%                         | 60,596.4                   | 46,961.7                   | 26,001.7                   | -23%                              |                            |
| Dental Council                                                     | <0.1                    | <0.1                    | -50%                 | -41%                              | 3.3                          | 10.1                         | 1.6                          | +210%                        | 8.6                        | 10.2                       | 2.8                        | +18%                              |                            |
| Department of Agriculture, Food &the Marine                        | 31.9                    | 47.7                    | -50%                 | -38%                              | 3,575.7                      | 3,447.2                      | 1,752.1                      | -4%                          | 10,230.1                   | 8,725.6                    | 3,254.7                    | -15%                              |                            |
| Department of Children, Equality, Disability, Integration andYouth | 1.2                     | 1.8                     | -43%                 | -62%                              | 76.4                         | 142.8                        | 37.4                         | +87%                         | 277.5                      | 332.3                      | 83.7                       | +20%                              |                            |
| Department of Defence                                              | 2.0                     | 3.1                     | -50%                 | -34%                              | 175.9                        | 121.5                        | 86.2                         | -31%                         | 771.1                      | 496.5                      | 220.8                      | -36%                              |                            |
| Department of Education 7                                          | 4.8                     | 7.3                     | -50%                 | -39%                              | 521.1                        | 493.4                        | 255.4                        | -5%                          | 1,697.6                    | 1,344.4                    | 522.1                      | -21%                              |                            |
| Department of Enterprise, Trade and Employment                     | 1.9                     | 2.7                     | -50%                 | -62%                              | 240.0                        | 195.6                        | 117.6                        | -19%                         | 749.1                      | 449.8                      | 231.3                      | -40%                              |                            |

- Note 1: Public body submitted sufficient data to calculate a savings result for 2021; however the result lies beyond the expected range of probable energy performance and needs verification.
- Note 2: SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.
- Note 7: Includes performance for the Department of Further and Higher Education, Research, Innovation and Science.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                               | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS    | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|---------------------------------------------------------------|-------------------------|-------------------------|----------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------|----------------------------|----------------------------|----------------------------|
|                                                               | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions          | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |
| Public Body                                                   | Final GWh               | Primary GWh             | 2030 target          |                      | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change since                 | GHGbaseline good bad         | GHG baseline tCO2 2021 tCO2 | 2030 target tCO2           | Change                     |                            |
| Department of Finance                                         | 5.6                     | 10.4                    | -50%                 | +32%                 |                                   | 114.8                        | 117.1                        | 56.2                         | +2%                          |                              | 2,095.0 1,888.0             | 504.9                      | -10%                       |                            |
| Department of Foreign Affairs                                 | 4.6                     | 7.2                     | -50%                 | -48%                 |                                   | 350.0                        | 437.9                        | 171.5                        | +25%                         |                              | 1,654.1 1,321.9             | 465.9                      | -20%                       |                            |
| Department of Health                                          | 2.0                     | 3.1                     | -50%                 | -46%                 |                                   | 353.7                        | 204.1                        | 173.3                        | -42%                         |                              | 749.0 568.4                 | 263.4                      | -24%                       |                            |
| Department of Housing, Local Government and Heritage 2        | 3.5                     | 5.1                     | -50%                 | -31%                 |                                   | 288.9                        | 374.8                        | 141.6                        | +30%                         |                              | 1,033.8 920.4               | 309.2                      | -11%                       |                            |
| Department of Justice                                         | 6.0                     | 8.9                     | -50%                 | -43%                 |                                   | 677.2                        | 680.0                        | 331.8                        | +0%                          |                              | 2,133.5 1,617.8             | 660.5                      | -24%                       |                            |
| Department of Public Expenditure and Reform                   | 3.5                     | 5.7                     | -43%                 | -52%                 |                                   | 330.7                        | 235.1                        | 162.0                        | -29%                         |                              | 1,627.8 1,018.0             | 450.4                      | -37%                       |                            |
| Department of Rural & Community Development                   | 0.2                     | 0.3                     | -29%                 | -37%                 |                                   | 32.9                         | 34.4                         | 16.1                         | +5%                          |                              | 64.3 57.0                   | 24.3                       | -11%                       |                            |
| Department of Social Protection                               | 27.3                    | 43.3                    | -50%                 | -44%                 |                                   | 2,730.1                      | 2,694.9                      | 1,337.7                      | -1%                          |                              | 10,936.1 8,182.5            | 3,182.2                    | -25%                       |                            |
| Department of the Taoiseach                                   | 2.3                     | 3.3                     | -50%                 | -23%                 |                                   | 225.4                        | 170.6                        | 110.4                        | -24%                         |                              | 639.6 503.7                 | 204.5                      | -21%                       |                            |
| Department of the Environment, Climate and Communications     | 4.7                     | 5.9                     | -50%                 | -47%                 |                                   | 890.3                        | 949.2                        | 436.2                        | +7%                          | 1,364.5                      | 1,237.0                     | 542.8                      | -9%                        |                            |
| Department of Tourism, Culture, Arts, Gaeltacht, Sport &Media | 0.6                     | 1.0                     | -50%                 | -92%                 |                                   | 247.5                        | 46.4                         | 121.3                        | -81%                         |                              | 707.4 182.6                 | 225.3                      | -74%                       |                            |
| Department of Transport                                       | 28.8                    | 33.6                    | -50%                 | -29%                 |                                   | 5,727.3                      | 6,757.9                      | 2,806.4                      | +18%                         |                              | 6,877.6 7,571.9             | 3,065.8                    | +10%                       |                            |
| Design &Crafts Council Ireland                                | 0.2                     | 0.2                     | -50%                 | -36%                 |                                   | 33.9                         | 25.0                         | 16.6                         | -26%                         | 97.7                         | 49.6                        | 31.1                       | -49%                       |                            |
| Digital Hub Development Agency                                | 1.7                     | 2.7                     | -50%                 | -39%                 |                                   | 327.6                        | 181.5                        | 160.5                        | -45%                         |                              | 1,022.0 489.5               | 317.4                      | -52%                       |                            |

- Note 2: SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                    | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|----------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                                    | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |
| Public Body                                        | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | target tCO2                | 2030 Change                |                            |
| Donegal County Council 3                           | 24.8                    | 36.6                    | -50%                 | -45%                              | 4,402.5                      | 3,367.9                      | 2,157.2                      | -24%                              | 9,673.4                    | 7,234.8                    | 3,346.9                    | -25%                       |                            |
| Donegal Education & Training Board                 | 7.0                     | 9.8                     | -50%                 | -14%                              | 1,205.4                      | 1,163.0                      | 590.6                        | -4%                               | 2,311.5                    | 2,003.4                    | 840.4                      | -13%                       |                            |
| Donegal Education Centre                           | <0.1                    | <0.1                    | -50%                 | -29%                              | 0.0                          | 0.0                          | 0.0                          |                                   | 21.4                       | 16.7                       | 4.9                        | -22%                       |                            |
| Drogheda Port Company                              | 0.4                     | 0.6                     | -50%                 | -64%                              | 89.9                         | 73.7                         | 44.0                         | -18%                              | 156.1                      | 123.9                      | 59.1                       | -21%                       |                            |
| Drumcondra Education Centre                        | <0.1                    | 0.1                     | -50%                 | -54%                              | 9.9                          | 9.1                          | 4.9                          | -8%                               | 31.0                       | 17.6                       | 9.6                        | -43%                       |                            |
| Dublin &DúnLaoghaire Education &Training Board     | 23.3                    | 31.8                    | -50%                 | -39%                              | 3,049.6                      | 3,291.8                      | 1,494.3                      | +8%                               | 6,827.1                    | 5,877.5                    | 2,348.8                    | -14%                       |                            |
| Dublin Bus                                         | 239.3                   | 267.1                   | -50%                 | -24%                              | 75,147.0                     | 61,374.7                     | 36,822.0                     | -18%                              | 77,244.8                   | 62,997.5                   | 37,295.9                   | -18%                       |                            |
| Dublin City Council 3                              | 114.4                   | 165.0                   | -50%                 | -41%                              | 15,522.8                     | 14,624.6                     | 7,606.2                      | -6%                               | 38,326.1                   | 31,125.1                   | 12,748.5                   | -19%                       |                            |
| Dublin City University                             | 36.2                    | 53.2                    | -50%                 | -56%                              | 5,240.9                      | 4,151.4                      | 2,568.0                      | -21%                              | 14,587.0                   | 9,804.4                    | 4,676.3                    | -33%                       |                            |
| Dublin Dental Hospital &School                     | 1.3                     | 2.0                     | -50%                 | -32%                              | 140.5                        | 125.4                        | 68.8                         | -11%                              | 479.8                      | 369.4                      | 144.8                      | -23%                       |                            |
| Dublin Institute for Advanced Studies              | 0.8                     | 1.4                     | -50%                 | -46%                              | 54.8                         | 59.5                         | 26.8                         | +9%                               | 359.1                      | 264.3                      | 95.8                       | -26%                       |                            |
| Dublin Port Company                                | 10.7                    | 13.8                    | -50%                 | -36%                              | 2,451.1                      | 2,094.7                      | 1,201.0                      | -15%                              | 3,870.4                    | 2,961.9                    | 1,518.2                    | -23%                       |                            |
| Dublin West Education Centre                       | <0.1                    | 0.1                     | -50%                 | -44%                              | 10.4                         | 10.3                         | 5.1                          | -1%                               | 29.5                       | 20.8                       | 9.4                        | -29%                       |                            |
| Dún Laoghaire Institute of Art, Design &Technology | 3.6                     | 5.2                     | -50%                 | -23%                              | 443.8                        | 420.3                        | 217.5                        | -5%                               | 1,257.8                    | 954.2                      | 401.9                      | -24%                       |                            |
| Dún Laoghaire-Rathdown County Council 3            | 22.3                    | 36.3                    | -50%                 | -51%                              | 2,490.8                      | 1,790.0                      | 1,220.5                      | -28%                              | 11,061.8                   | 6,796.9                    | 3,151.4                    | -39%                       |                            |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                               | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|-----------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                               | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |                            |
| Public Body                                   | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change                     |                            |                            |
| Dundalk Institute of Technology               | 9.7                     | 12.7                    | -50%                 | -21%                              | 1,165.3                      | 1,217.0                      | 571.0                        | +4%                          | 2,687.9                    | 2,126.9                    | 915.8                      | -21%                       |                            |                            |
| Economic and Social Research Institute (ESRI) | 0.4                     | 0.7                     | -50%                 | -43%                              | 87.7                         | 38.0                         | 43.0                         | -57%                         | 279.2                      | 125.8                      | 86.1                       | -55%                       |                            |                            |
| Educampus Services 4                          | <0.1                    | <0.1                    | -33%                 | -75%                              | 0.0                          | 0.0                          | 0.0                          |                              | 18.2                       | 11.4                       | 4.2                        | -38%                       |                            |                            |
| Education Centre Tralee 1                     | <0.1                    | <0.1                    | -50%                 |                                   | 4.7                          | 6.1                          | 2.3                          | +31%                         | 16.6                       | 10.6                       | 5.0                        | -36%                       |                            |                            |
| EirGrid plc                                   | 3.1                     | 5.4                     | -50%                 | -49%                              | 164.5                        | 133.7                        | 80.6                         | -19%                         | 1,483.6                    | 997.7                      | 377.8                      | -33%                       |                            |                            |
| Electricity Supply Board                      | 70.5                    | 95.4                    | -50%                 | -47%                              | 13,524.0                     | 12,236.9                     | 6,626.7                      | -10%                         | 24,684.7                   | 19,746.2                   | 9,148.2                    | -20%                       |                            |                            |
| Enable Ireland                                | 6.8                     | 8.8                     | -50%                 | -71%                              | 951.4                        | 1,159.9                      | 466.2                        | +22%                         | 1,793.0                    | 1,725.0                    | 656.0                      | -4%                        |                            |                            |
| Enterprise Ireland                            | 2.4                     | 4.2                     | -50%                 | -65%                              | 200.9                        | 132.4                        | 98.5                         | -34%                         | 1,392.4                    | 768.0                      | 366.9                      | -45%                       |                            |                            |
| Environmental Protection Agency               | 2.6                     | 3.8                     | -50%                 | -57%                              | 315.7                        | 219.8                        | 154.7                        | -30%                         | 848.5                      | 612.7                      | 275.0                      | -28%                       |                            |                            |
| Fáilte Ireland                                | 1.0                     | 1.8                     | -50%                 | -69%                              | 98.3                         | 47.9                         | 48.2                         | -51%                         | 811.4                      | 335.4                      | 208.9                      | -59%                       |                            |                            |
| Financial Services and Pensions Ombudsman     | 0.3                     | 0.4                     | -50%                 | +43%                              | 18.1                         | 42.0                         | 8.9                          | +132%                        | 27.1                       | 75.0                       | 10.9                       | +177%                      |                            |                            |
| Fingal County Council 3                       | 29.2                    | 47.3                    | -50%                 | -42%                              | 2,743.8                      | 2,638.3                      | 1,344.5                      | -4%                          | 12,341.3                   | 9,032.3                    | 3,508.2                    | -27%                       |                            |                            |
| FOLD Ireland                                  | 1.3                     | 1.7                     | -50%                 | -16%                              | 199.7                        | 207.7                        | 97.8                         | +4%                          | 346.1                      | 319.9                      | 130.7                      | -8%                        |                            |                            |
| Food Safety Authority of Ireland              | <0.1                    | 0.2                     | -50%                 | -85%                              | 21.8                         | 0.0                          | 10.7                         | -100%                        | 177.4                      | 35.2                       | 44.5                       | -80%                       |                            |                            |

- Note 1: Public body submitted sufficient data to calculate a savings result for 2021; however the result lies beyond the expected range of probable energy performance and needs verification.
- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.
- Note 4: The result calculated for the public body lies beyond the expected range of probable energy performance. However, this could be because of exceptional circumstances arising from the impact of COVID-19 on energy performance.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   |
|------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|----------------------------|
|                                                | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |                            |
| Public Body                                    | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |                            |
| Forensic Science Laboratory                    | 1.0                     | 1.7                     | -50%                 | -36%                              | 49.4                         | 69.0                         | 24.2                         | +40%                         | 257.9                      | 316.8                      | 71.4                       | +23%                              |                            |
| Foyle, Carlingford and Irish Lights Commission | 0.3                     | 0.3                     | -50%                 | -51%                              | 90.8                         | 61.7                         | 44.5                         | -32%                         | 103.8                      | 68.1                       | 47.4                       | -34%                              |                            |
| Galway City Council 3                          | 13.3                    | 20.0                    | -50%                 | -40%                              | 1,432.5                      | 1,589.1                      | 701.9                        | +11%                         | 4,803.6                    | 3,800.2                    | 1,463.9                    | -21%                              |                            |
| Galway County Council 3                        | 16.5                    | 23.8                    | -50%                 | -41%                              | 2,866.3                      | 2,370.2                      | 1,404.5                      | -17%                         | 6,342.8                    | 4,728.9                    | 2,188.6                    | -25%                              |                            |
| Galway Education Centre                        | <0.1                    | <0.1                    | -50%                 | -51%                              | 24.8                         | 21.5                         | 12.2                         | -14%                         | 31.0                       | 21.5                       | 13.4                       | -31%                              |                            |
| Galway Mayo Institute of Technology            | 8.4                     | 11.9                    | -50%                 | -37%                              | 1,159.5                      | 1,154.1                      | 568.1                        | -0%                          | 2,896.1                    | 2,222.7                    | 959.7 -23%                 |                                   |                            |
| Galway Roscommon Education &Training Board     | 8.8                     | 12.7                    | -50%                 | -34%                              | 1,179.6                      | 1,254.9                      | 578.0                        | +6%                          | 2,853.8                    | 2,471.6                    | 956.9                      | -13%                              |                            |
| Garda Inspectorate                             | <0.1                    | <0.1                    | -50%                 | -51%                              | 12.1                         | 9.8                          | 5.9                          | -19%                         | 21.3                       | 13.7                       | 8.0                        | -36%                              |                            |
| Garda Ombudsman Commission                     | 0.7                     | 1.0                     | -50%                 | -56%                              | 98.2                         | 68.4                         | 48.1                         | -30%                         | 244.1                      | 199.5                      | 81.2                       | -18%                              |                            |
| Gas Networks Ireland                           | 6.2                     | 8.9                     | -50%                 | -52%                              | 892.7                        | 866.2                        | 437.4                        | -3%                          | 2,252.5                    | 1,748.2                    | 744.0                      | -22%                              |                            |
| Good Shepherd Cork                             | 0.3                     | 0.4                     | -50%                 | -27%                              | 27.2                         | 43.8                         | 13.3                         | +61%                         | 95.7                       | 72.7                       | 28.8                       | -24%                              |                            |
| Grangegorman Development Agency                | 0.1                     | 0.2                     | -50%                 | -89%                              | 26.6                         | 20.9                         | 13.0                         | -21%                         | 53.0                       | 28.6                       | 19.0                       | -46%                              |                            |
| Health &Safety Authority                       | 0.4                     | 0.9                     | -50%                 | -37%                              | 1.8                          | 0.3                          | 0.9                          | -81%                         | 188.5                      | 156.0                      | 43.3 -17%                  |                                   |                            |
| Health Products Regulatory Authority           | 0.7                     | 1.1                     | -50%                 | -63%                              | 59.5                         | 73.0                         | 29.2                         | +23%                         | 356.1                      | 199.1                      | 95.8 -44%                  |                                   |                            |
| Heritage Council                               | <0.1                    | <0.1                    | -50%                 | -72%                              | 21.6                         | 14.3                         | 10.6                         | -34%                         | 40.7                       | 14.3                       | 14.9                       | -65%                              |                            |

- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                   | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|---------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                                   | 2021 energy consumption | 2021 energy consumption | Energy               | Energy                            | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |
| Public Body                                       | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | since GHGbaseline good bad   | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |
| Higher Education Authority Irish Research Council | <0.1                    | 0.1                     | -50%                 | -80%                              | 15.3                         | 9.1                          | 7.5                          | -40%                         |                              | 67.9                       | 26.6                       | 19.6                       | -61%                              |
| Horseracing Ireland Ltd                           | 4.1                     | 5.4                     | -50%                 | -46%                              | 543.0                        | 662.0                        | 266.1                        | +22%                         |                              | 1,248.1                    | 1,053.5                    | 425.6                      | -16%                              |
| Houses of the Oireachtas Service                  | 7.6                     | 12.1                    | -50%                 | -39%                              | 502.6                        | 460.2                        | 246.3                        | -8%                          |                              | 2,658.8                    | 2,041.2                    | 734.0                      | -23%                              |
| Housing and Sustainable Communities Agency        | 0.2                     | 0.4                     | -38%                 | -66%                              | 0.0                          | 9.9                          | 0.0                          |                              |                              | 66.9                       | 69.8                       | 15.1 +4%                   |                                   |
| Housing Finance Agency                            | <0.1                    | <0.1                    | -50%                 | -54%                              | 0.0                          | 0.0                          | 0.0                          |                              |                              | 13.0                       | 6.9                        | 3.0 -47%                   |                                   |
| HSE                                               | 804.6                   | 1,094.6                 | -50%                 | -16%                              | 135,965.5                    | 127,521.6                    | 66,623.1                     | -6%                          |                              | 231,439.8                  | 211,259.0                  | 88,197.7 -9%               |                                   |
| Iarnród Éireann / Irish Rail                      | 520.5                   | 621.5                   | -50%                 | -29%                              | 116,776.3                    | 115,103.0                    | 57,220.4                     | -1%                          |                              | 144,346.6                  | 135,680.7                  | 63,453.5                   | -6%                               |
| IDA Ireland 2                                     | 3.3                     | 5.8                     | -50%                 | -37%                              | 162.0                        | 150.7                        | 79.4                         | -7%                          |                              | 1,436.4                    | 1,066.2                    | 368.1                      | -26%                              |
| Incorporated Orthopaedic Hospital of Ireland      | 2.0                     | 2.8                     | -50%                 | -35%                              | 278.2                        | 250.8                        | 136.3                        | -10%                         |                              | 605.8                      | 511.6                      | 210.4                      | -16%                              |
| Inland Fisheries Ireland                          | 5.2                     | 6.5                     | -50%                 | -39%                              | 1,234.7                      | 1,008.0                      | 605.0                        | -18%                         |                              | 1,763.0                    | 1,344.0                    | 724.6                      | -24%                              |
| Inspector of Prisons and Places of Detention      | <0.1                    | <0.1                    | -50%                 | -2%                               | 0.0                          | 0.0                          | 0.0                          |                              |                              | 10.1 6.2                   | 2.3                        | -39%                       |                                   |
| Institute of Public Administration                | 0.6                     | 0.9                     | -50%                 | -21%                              | 96.2                         | 94.3                         | 47.1                         | -2%                          |                              | 213.3                      | 160.3                      | 73.5 -25%                  |                                   |
| Institute of Public Health                        | <0.1                    | <0.1                    | -50%                 | -12%                              | 0.0                          | 0.0                          | 0.0                          |                              |                              | 18.4                       | 15.6                       | 4.3                        | -15%                              |
| Institute of Technology Carlow                    | 5.5                     | 8.2                     | -50%                 | -53%                              | 554.9                        | 649.9                        | 271.9                        | +17%                         |                              | 1,960.3                    | 1,502.3                    | 588.3 -23%                 |                                   |
| Institute of Technology Sligo                     | 4.9                     | 7.3                     | -50%                 | -49%                              | 893.3                        | 678.7                        | 437.7                        | -24%                         |                              | 2,266.3                    | 1,464.4                    | 746.3                      | -35%                              |

- Note 2: SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                            | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|--------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                            | 2021 energy consumption | 2021 energy consumption | Energy               | Energy                            | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |
| Public Body                                | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             |                              | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |
| InterTradeIreland                          | 0.2                     | 0.3                     | -50%                 | -55%                              | 36.2                         | 28.7                         | 17.7                         | -21%                         |                                   | 77.1                       | 53.3                       | 27.0                       | -31%                              |
| Irish Aviation Authority                   | 12.3                    | 21.2                    | -50%                 | -43%                              | 923.0                        | 754.4                        | 452.3                        | -18%                         |                                   | 4,959.3                    | 3,952.7                    | 1,363.0                    | -20%                              |
| Irish BloodTransfusion Service             | 9.0                     | 13.4                    | -50%                 | -35%                              | 934.7                        | 983.9                        | 458.0                        | +5%                          |                                   | 2,949.4                    | 2,473.0                    | 912.2                      | -16%                              |
| Irish Film Classification Office           | <0.1                    | 0.1                     | -50%                 | -8%                               | 0.0                          | 0.0                          | 0.0                          |                              |                                   | 39.9                       | 24.1                       | 9.0                        | -40%                              |
| Irish National Stud                        | 1.7                     | 2.4                     | -50%                 | -18%                              | 249.1                        | 295.4                        | 122.1                        | +19%                         |                                   | 507.6                      | 495.3                      | 180.1                      | -2%                               |
| Irish Prison Service                       | 82.1                    | 112.2                   | -50%                 | -10%                              | 11,068.4                     | 12,075.1                     | 5,423.5                      | +9%                          |                                   | 23,168.2                   | 20,984.9                   | 8,150.3                    | -9%                               |
| Irish Water 5                              | 641.6                   | 1,137.6                 | -50%                 | -30%                              | 10,477.4                     | 14,899.5                     | 5,133.9                      | +42%                         |                                   | 235,438.8                  | 199,195.9                  | 56,018.1                   | -15%                              |
| Irish Wheelchair Association               | 3.8                     | 4.8                     | -50%                 | -59%                              | 1,264.6                      | 772.9                        | 619.6                        | -39%                         |                                   | 1,749.2                    | 1,019.2                    | 728.5                      | -42%                              |
| KARE                                       | 1.9                     | 2.4                     | -50%                 | -29%                              | 320.8                        | 323.1                        | 157.2                        | +1%                          |                                   | 474.2                      | 433.6                      | 191.8                      | -9%                               |
| Kerry County Council 3, 6                  | 30.2                    | 41.3                    | -50%                 | -41%                              | 5,208.6                      | 5,072.7                      | 2,552.2                      | -3%                          |                                   | 9,963.7                    | 8,566.1                    | 3,624.9                    | -14%                              |
| Kerry Education &Training Board            | 4.0                     | 5.9                     | -50%                 | -29%                              | 509.0                        | 534.3                        | 249.4                        | +5%                          |                                   | 1,307.8                    | 1,160.6                    | 430.6                      | -11%                              |
| Kildare &Wicklow Education &Training Board | 11.2                    | 15.9                    | -50%                 | -10%                              | 1,231.2                      | 1,455.1                      | 603.3                        | +18%                         |                                   | 3,072.8                    | 2,964.7                    | 1,019.8 -4%                |                                   |
| Kildare County Council 3                   | 25.4                    | 42.0                    | -50%                 | -28%                              | 2,418.1                      | 2,057.0                      | 1,184.9                      | -15%                         |                                   | 9,566.2                    | 7,973.3                    | 2,799.4 -17%               |                                   |
| Kildare Education Support Centre           | 0.1                     | 0.2                     | -50%                 | -22%                              | 17.2                         | 22.3                         | 8.4                          | +30%                         |                                   | 29.0                       | 31.6                       | 11.1                       | +9%                               |

- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.
- Note 5: Irish Water's energy performance is calculated on the basis of the water services assets'  performance since 2009. These assets were owned and operated by local authorities up to the end of 2013, during which time the water services sector had improved its performance by 6.4%. The savings figure may be revised in future years as the local authorities, Irish Water and SEAI continue to work together to improve the quality and quantity of energy data, including historical data.
- Note 6: The scope of energy consumption counted for this public body's energy efficiency target differs from that counted for its total greenhouse gas emissions target. This is because of differences in the methodological treatment of certain electricity generation facilities for the purposes of the two targets. Any apparent inconsistencies between values shown for this public body are attributable to this.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                            | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|--------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                            | 2021 energy consumption | 2021 energy consumption | Energy               | Energy                            | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |                            |
| Public Body                                | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 2030 tCO2             | target Change              |                            |                            |
| Kilkenny &Carlow Education &Training Board | 4.2                     | 6.0                     | -50%                 | -37%                              | 508.6                        | 579.4                        | 249.2                        | +14%                         | 1,317.0                    | 1,143.5                    | 431.3 -13%                 |                            |                            |
| Kilkenny County Council 3                  | 15.1                    | 22.0                    | -50%                 | -37%                              | 1,571.5                      | 2,096.8                      | 770.0                        | +33%                         | 5,056.8                    | 4,342.8                    | 1,555.4 -14%               |                            |                            |
| Kilkenny Education Centre 2                | <0.1                    | 0.1                     | -50%                 | -35%                              | 16.0                         | 8.8                          | 7.9                          | -45%                         | 39.7                       | 24.2                       | 13.2 -39%                  |                            |                            |
| Labour Court                               | 0.2                     | 0.2                     | -50%                 | -47%                              | 31.7                         | 30.0                         | 15.6                         | -6%                          | 60.2                       | 45.6                       | 22.2 -24%                  |                            |                            |
| Laois &Offaly Education &Training Board    | 4.3                     | 6.1                     | -50%                 | -23%                              | 686.7                        | 655.8                        | 336.5                        | -4%                          | 1,437.8                    | 1,229.8                    | 505.9 -14%                 |                            |                            |
| Laois County Council 2, 3                  | 7.9                     | 13.0                    | -50%                 | -59%                              | 1,322.3                      | 635.7                        | 647.9                        | -52%                         | 4,088.8                    | 2,440.7 1,272.9            | -40%                       |                            |                            |
| Laois Education Centre                     | <0.1                    | 0.1                     | -50%                 | -27%                              | 3.8                          | 11.5                         | 1.9                          | +201%                        | 18.8                       | 19.7                       | 5.3 +5%                    |                            |                            |
| Law Reform Commission                      | <0.1                    | 0.1                     | -50%                 | -84%                              | 0.0                          | 11.3                         | 0.0                          |                              | 92.9                       | 19.4                       | 19.8 -79%                  |                            |                            |
| Léargas -TheExchange Bureau                | <0.1                    | <0.1                    | -50%                 | -52%                              | 15.4                         | 16.9                         | 7.5                          | +10%                         | 19.0                       | 18.4                       | 8.3 -3%                    |                            |                            |
| Legal Aid Board                            | 1.7                     | 3.0                     | -50%                 | -33%                              | 56.6                         | 61.2                         | 27.7                         | +8%                          | 732.4                      | 549.7                      | 180.7 -25%                 |                            |                            |
| Legal Services Regulatory Authority 2      | <0.1                    | <0.1                    | -31%                 | -72%                              | 3.7                          | 0.0                          | 1.8                          | -100%                        | 4.5                        | 10.5                       | 2.0 +133%                  |                            |                            |
| Leitrim County Council 2, 3                | 19.9                    | 25.3                    | -50%                 | +52%                              | 1,532.8                      | 3,845.7                      | 751.1                        | +151%                        | 3,438.0                    | 5,248.3 1,182.2            | +53%                       |                            |                            |
| Leopardstown Park Hospital                 | 2.8                     | 3.7                     | -50%                 | -33%                              | 451.7                        | 435.6                        | 221.3                        | -4%                          | 802.8                      | 693.9                      | 300.5 -14%                 |                            |                            |
| Letterkenny Institute of Technology        | 3.8                     | 5.4                     | -50%                 | -60%                              | 603.9                        | 609.7                        | 295.9                        | +1%                          | 1,418.6                    | 1,099.2                    | 479.4 -23%                 |                            |                            |
| Limerick &Clare Education &Training Board  | 12.2                    | 17.4                    | -50%                 | -29%                              | 1,565.7                      | 1,691.4                      | 767.2                        | +8%                          | 3,808.8                    | 3,342.2                    | 1,275.4 -12%               |                            |                            |

- Note 2: SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.
- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                               | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   |
|-----------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|----------------------------|
|                                               | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |                            |
| Public Body                                   | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |                            |
| Limerick City &County Council 3               | 23.6                    | 36.1                    | -50%                 | -40%                              | 2,566.1                      | 2,792.8                      | 1,257.4                      | +9%                          | 9,665.1                    | 7,035.2                    | 2,862.2                    | -27%                              |                            |
| Limerick Education Centre 1                   | 0.2                     | 0.3                     | -50%                 |                                   | 29.3                         | 2.8                          | 14.4                         | -91%                         | 92.0                       | 53.9                       | 28.4                       | -41%                              |                            |
| Limerick Institute of Technology              | 9.5                     | 13.5                    | -50%                 | -31%                              | 924.8                        | 1,172.2                      | 453.2                        | +27%                         | 2,793.9                    | 2,415.3                    | 874.9                      | -14%                              |                            |
| Local Government Management Agency            | 0.8                     | 1.2                     | -50%                 | -69%                              | 90.6                         | 80.3                         | 44.4                         | -11%                         | 382.8                      | 227.0                      | 110.1                      | -41%                              |                            |
| Longford &Westmeath Education &Training Board | 4.0                     | 5.8                     | -50%                 | -39%                              | 638.3                        | 578.6                        | 312.8                        | -9%                          | 1,477.1                    | 1,157.1                    | 502.7                      | -22%                              |                            |
| Longford County Council 3                     | 7.0                     | 10.4                    | -50%                 | -40%                              | 780.8                        | 786.9                        | 382.6                        | +1%                          | 2,303.2                    | 1,907.4                    | 726.2                      | -17%                              |                            |
| Louth &Meath Education &Training Board        | 13.2                    | 18.1                    | -50%                 | -27%                              | 1,631.1                      | 1,924.5                      | 799.2                        | +18%                         | 3,765.6                    | 3,434.2                    | 1,283.9                    | -9%                               |                            |
| Louth County Council 3, 6                     | 16.0                    | 23.9                    | -50%                 | -48%                              | 1,997.5                      | 1,707.2                      | 978.8                        | -15%                         | 6,101.9                    | 4,622.8                    | 1,903.5                    | -24%                              |                            |
| Marine Institute                              | 18.4                    | 22.2                    | -50%                 | -34%                              | 5,698.3                      | 4,183.0                      | 2,792.1                      | -27%                         | 6,857.2                    | 5,001.5                    | 3,052.7                    | -27%                              |                            |
| Marino Institute of Education                 | 2.7                     | 3.4                     | -50%                 | -63%                              | 554.0                        | 460.9                        | 271.5                        | -17%                         | 872.3                      | 621.4                      | 343.2                      | -29%                              |                            |
| Mary Immaculate College Limerick              | 6.3                     | 8.5                     | -50%                 | -33%                              | 977.2                        | 973.4                        | 478.8                        | -0%                          | 1,913.7                    | 1,573.8                    | 691.6                      | -18%                              |                            |
| Marymount University Hospital and Hospice     | 4.2                     | 5.5                     | -50%                 | -31%                              | 631.8                        | 662.1                        | 309.6                        | +5%                          | 957.9                      | 997.1                      | 383.4                      | +4%                               |                            |
| Mater Misericordiae University Hospital       | 56.0                    | 69.3                    | -50%                 | -28%                              | 5,079.6                      | 9,603.5                      | 2,489.0                      | +89%                         | 14,962.5                   | 12,828.1                   | 4,713.8                    | -14%                              |                            |
| Maynooth University, NUIM                     | 24.6                    | 33.5                    | -50%                 | -47%                              | 4,008.7                      | 3,479.7                      | 1,964.3                      | -13%                         | 7,757.1                    | 6,223.5                    | 2,810.7                    | -20%                              |                            |

- Note 1: Public body submitted sufficient data to calculate a savings result for 2021; however the result lies beyond the expected range of probable energy performance and needs verification.
- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.
- Note 6: The scope of energy consumption counted for this public body's energy efficiency target differs from that counted for its total greenhouse gas emissions target. This is because of differences in the methodological treatment of certain electricity generation facilities for the purposes of the two targets. Any apparent inconsistencies between values shown for this public body are attributable to this.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                               | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|-----------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                               | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |
| Public Body                                   | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             |                              | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |
| Mayo County Council 3                         | 22.0                    | 33.8                    | -50%                 | -33%                              | 2,988.0                      | 2,498.4                      | 1,464.1                      | -16%                         |                                   | 8,030.5                    | 6,490.9                    | 2,606.8                    | -19%                              |
| Mayo Education Centre                         | <0.1                    | 0.1                     | -50%                 | +30%                              | 17.4                         | 14.0                         | 8.5                          | -20%                         |                                   | 32.8                       | 20.7                       | 12.0                       | -37%                              |
| Mayo Sligo &Leitrim Education &Training Board | 6.5                     | 9.8                     | -50%                 | +2%                               | 1,209.2                      | 926.3                        | 592.5                        | -23%                         |                                   | 2,566.1                    | 1,953.7                    | 899.2                      | -24%                              |
| Meath County Council 3                        | 22.7                    | 34.4                    | -50%                 | -30%                              | 2,874.6                      | 2,594.5                      | 1,408.6                      | -10%                         |                                   | 8,218.6                    | 6,597.0                    | 2,615.6                    | -20%                              |
| Medical Bureau of Road Safety                 | 0.8                     | 1.3                     | -50%                 | -16%                              | 32.7                         | 53.5                         | 16.0                         | +64%                         |                                   | 200.0                      | 232.4                      | 54.1                       | +16%                              |
| Mental Health Commission                      | 0.1                     | 0.2                     | -50%                 | -65%                              | 23.2                         | 18.6                         | 11.4                         | -20%                         |                                   | 59.4                       | 37.6                       | 19.7                       | -37%                              |
| Mercy Hospital                                | 8.9                     | 13.1                    | -50%                 | -37%                              | 1,346.3                      | 1,051.6                      | 659.7                        | -22%                         |                                   | 2,923.2                    | 2,391.4                    | 1,015.4                    | -18%                              |
| Met Éireann                                   | 1.1                     | 1.8                     | -50%                 | -18%                              | 87.1                         | 103.3                        | 42.7                         | +19%                         |                                   | 420.3                      | 347.2                      | 117.9                      | -17%                              |
| Milford Care Centre                           | 4.6                     | 5.7                     | -50%                 | +85%                              | 726.8                        | 804.6                        | 356.1                        | +11%                         |                                   | 1,017.1                    | 1,050.3                    | 422.3                      | +3%                               |
| Monaghan County Council 3                     | 6.6                     | 9.9                     | -50%                 | -52%                              | 1,055.6                      | 845.9                        | 517.2                        | -20%                         |                                   | 3,160.4                    | 1,903.9                    | 991.4                      | -40%                              |
| Monaghan Education Centre                     | 0.1                     | 0.2                     | -50%                 | -5%                               | 21.3                         | 23.3                         | 10.4                         | +9%                          |                                   | 36.4                       | 33.1                       | 13.9                       | -9%                               |
| Muiriosa Foundation                           | 8.4                     | 10.0                    | -50%                 | -38%                              | 1,233.2                      | 1,912.2                      | 604.3                        | +55%                         |                                   | 1,771.3                    | 2,200.6                    | 725.2                      | +24%                              |
| Munster Technical University Kerry Campus     | 4.5                     | 6.7                     | -50%                 | -50%                              | 597.2                        | 633.5                        | 292.6                        | +6%                          |                                   | 1,466.9                    | 1,321.1                    | 489.7                      | -10%                              |
| Munster Technological University -Cork        | 15.5                    | 22.5                    | -50%                 | -53%                              | 1,784.0                      | 1,937.9                      | 874.2                        | +9%                          |                                   | 5,234.8                    | 4,107.0                    | 1,653.1                    | -22%                              |
| National Archives                             | 0.7                     | 1.0                     | -50%                 | -61%                              | 96.5                         | 87.8                         | 47.3                         | -9%                          |                                   | 240.6                      | 178.2                      | 79.8 -26%                  |                                   |
| National Cancer Registry Board                | <0.1                    | 0.1                     | -50%                 | -36%                              | 0.0                          | 0.0                          | 0.0                          |                              |                                   | 31.5                       | 19.9                       | 7.1                        | -37%                              |

<!-- image -->

<!-- image -->

<!-- image -->

|                                                 | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   |
|-------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|----------------------------|
|                                                 | 2021 energy consumption | 2021 energy consumption | Energy               | Energy                            | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |                            |
| Public Body                                     | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |                            |
| National College of Art and Design              | 2.7                     | 3.7                     | -50%                 | -50%                              | 459.6                        | 364.1                        | 225.2                        | -21%                         | 926.2                      | 676.6                      | 330.8                      | -27%                              |                            |
| National Council for Special Education 2        | 0.3                     | 0.4                     | -50%                 | -68%                              | 60.0                         | 38.5                         | 29.4                         | -36%                         | 152.2                      | 77.2                       | 50.2                       | -49%                              |                            |
| National Disability Authority                   | 0.2                     | 0.2                     | -50%                 | -70%                              | 45.0                         | 20.8                         | 22.1                         | -54%                         | 96.0                       | 40.1                       | 33.5                       | -58%                              |                            |
| National Economic and Social Development Office | 0.2                     | 0.3                     | -50%                 | -38%                              | 10.9                         | 12.8                         | 5.4                          | +17%                         | 57.3                       | 54.7                       | 15.8                       | -5%                               |                            |
| National Gallery                                | 8.5                     | 11.9                    | -50%                 | -49%                              | 891.9                        | 1,128.1                      | 437.0                        | +26%                         | 2,393.8                    | 2,189.7                    | 776.3                      | -9%                               |                            |
| National Library of Ireland                     | 1.9                     | 2.8                     | -50%                 | -47%                              | 285.1                        | 201.6                        | 139.7                        | -29%                         | 747.0                      | 520.7                      | 243.6 -30%                 |                                   |                            |
| National Maternity Hospital                     | 6.6                     | 10.2                    | -50%                 | -11%                              | 670.7                        | 653.4                        | 328.6                        | -3%                          | 2,068.7                    | 1,880.2                    | 644.7                      | -9%                               |                            |
| National Milk Agency                            | <0.1                    | <0.1                    | -50%                 | -44%                              | 0.7                          | 2.3                          | 0.3                          | +239%                        | 5.1                        | 3.2                        | 1.3 -37%                   |                                   |                            |
| National Museum of Ireland                      | 9.4                     | 13.5                    | -50%                 | -13%                              | 1,119.4                      | 1,229.4                      | 548.5                        | +10%                         | 2,822.7                    | 2,544.0                    | 933.8                      | -10%                              |                            |
| National Oil Reserves Agency                    | 0.2                     | 0.3                     | -50%                 | -49%                              | 0.0                          | 0.0                          | 0.0                          |                              | 47.5                       | 60.4                       | 10.7                       | +27%                              |                            |
| National Rehabilitation Hospital 1              | 11.3                    | 15.0                    | -50%                 |                                   | 946.4                        | 1,797.5                      | 463.8                        | +90%                         | 1,609.9                    | 2,869.5                    | 613.8 +78%                 |                                   |                            |
| National Shared Services Office                 | 1.9                     | 2.8                     | -29%                 | -19%                              | 217.2                        | 210.3                        | 106.4                        | -3%                          | 675.6                      | 527.9                      | 225.5 -22%                 |                                   |                            |
| National Transport Authority                    | 50.2                    | 55.6                    | -50%                 | -42%                              | 416.9                        | 12,380.5                     | 204.3                        | +2869%                       | 540.5                      | 12,563.2                   | 232.5 +2224%               |                                   |                            |
| National Treasury Management Agency             | 2.1                     | 3.0                     | -50%                 | -77%                              | 162.1                        | 294.9                        | 79.4                         | +82%                         | 987.0                      | 544.8                      | 265.1 -45%                 |                                   |                            |

- Note 1: Public body submitted sufficient data to calculate a savings result for 2021; however the result lies beyond the expected range of probable energy performance and needs verification.
- Note 2: SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                       | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|-------------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                                       | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |
| Public Body                                           | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             |                              | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since               |                            |
| National Treatment Purchase Fund                      | 0.2                     | 0.4                     | -50%                 | -30%                              | 24.9                         | 30.5                         | 12.2                         | +22%                         |                                   | 74.1                       | 64.8                       | 23.4                       | -13%                       |                            |
| National University of Ireland, Galway                | 26.1                    | 40.6                    | -50%                 | -52%                              | 3,635.5                      | 2,414.6                      | 1,781.4                      | -34%                         |                                   | 11,222.5                   | 7,331.1                    | 3,496.6                    | -35%                       |                            |
| Navan Education Centre 1                              | 0.1                     | 0.1                     | -50%                 |                                   | 12.7                         | 13.3                         | 6.2                          | +5%                          |                                   | 31.8                       | 26.6                       | 10.6                       | -16%                       |                            |
| NCCA (National Council for Curriculum and Assessment) | <0.1                    | 0.2                     | -50%                 | -67%                              | 13.9                         | 6.0                          | 6.8                          | +57%                         |                                   | 58.5                       | 29.6                       | 16.9                       | -49%                       |                            |
| Northern &Western Regional Assembly                   | <0.1                    | <0.1                    | -50%                 | -77%                              | 0.0                          | 0.0                          | 0.0                          |                              |                                   | 33.2                       | 10.5                       | 7.5                        | -68%                       |                            |
| NSAI                                                  | 1.8                     | 2.9                     | -50%                 | -46%                              | 261.3                        | 182.0                        | 128.0                        | -30%                         |                                   | 786.7                      | 526.3                      | 246.8                      | -33%                       |                            |
| Nursing and Midwifery Board of Ireland                | 0.3                     | 0.5                     | -50%                 | -28%                              | 26.1                         | 29.7                         | 12.8                         | +14%                         |                                   | 110.1                      | 84.6                       | 31.8                       | -23%                       |                            |
| Oberstown Children Detention Campus                   | 4.8                     | 6.8                     | -50%                 | -7%                               | 699.7                        | 718.0                        | 342.9                        | +3%                          |                                   | 1,557.4                    | 1,337.7                    | 536.4                      | -14%                       |                            |
| Offaly County Council 3                               | 10.9                    | 17.1                    | -50%                 | -37%                              | 1,341.3                      | 1,137.1                      | 657.2                        | -15%                         |                                   | 3,903.4                    | 3,284.2                    | 1,235.4                    | -16%                       |                            |
| Office of Public Works                                | 36.9                    | 50.0                    | -50%                 | -20%                              | 5,224.6                      | 5,666.1                      | 2,560.1                      | +8%                          |                                   | 10,990.9                   | 9,595.8                    | 3,862.8                    | -13%                       |                            |
| Office of the Attorney General                        | 0.8                     | 1.1                     | -50%                 | -54%                              | 75.2                         | 56.9                         | 36.8                         | -24%                         |                                   | 397.6                      | 173.0                      | 109.6                      | -56%                       |                            |
| Office of the Comptroller &Auditor General            | 0.5                     | 0.8                     | -50%                 | -50%                              | 54.7                         | 56.9                         | 26.8                         | +4%                          |                                   | 188.8                      | 145.4                      | 57.0                       | -23%                       |                            |
| Office of the Director of Corporate Enforcement       | 0.4                     | 0.6                     | -50%                 | -39%                              | 21.1                         | 26.0                         | 10.4                         | +23%                         |                                   | 85.2                       | 111.2                      | 24.9                       | +31%                       |                            |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

- Note 1: Public body submitted sufficient data to calculate a savings result for 2021; however the result lies beyond the expected range of probable energy performance and needs verification.
- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.

A

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                                | 2021 energy consumption | 2021 energy consumption | Energy               | Energy                            | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |                            |
| Public Body                                    | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change                     |                            |                            |
| Office of the Director of Public Prosecutions  | 1.1                     | 1.5                     | -50%                 | -52%                              | 140.9                        | 132.5                        | 69.0                         | -6%                          | 424.6                      | 277.6                      | 132.2                      | -35%                       |                            |                            |
| Office of the Ombudsman                        | 0.2                     | 0.3                     | -50%                 | -79%                              | 44.9                         | 0.0                          | 22.0                         | -100%                        | 187.5                      | 54.7                       | 54.4                       | -71%                       |                            |                            |
| Office of the Ombudsman for Children           | <0.1                    | 0.1                     | -50%                 | -23%                              | 0.0                          | 0.0                          | 0.0                          |                              | 35.3                       | 27.4                       | 8.0                        | -22%                       |                            |                            |
| Office of the Ombudsman for the Defence Forces | <0.1                    | <0.1                    | -50%                 | -45%                              | 1.7                          | 1.6                          | 0.8                          | -6%                          | 6.7                        | 4.6                        | 2.0                        | -32%                       |                            |                            |
| Office of the Planning Regulator               | <0.1                    | 0.1                     | -24%                 | +74%                              | 11.8                         | 16.4                         | 5.8                          | +39%                         | 12.0                       | 20.7                       | 5.9                        | +72%                       |                            |                            |
| Oifig an Choimisinéara Teanga                  | <0.1                    | 0.1                     | -50%                 | -28%                              | 0.0                          | 0.0                          | 0.0                          |                              | 27.5                       | 21.6                       | 6.2                        | -21%                       |                            |                            |
| Ordnance Survey Ireland                        | 2.2                     | 3.4                     | -50%                 | -18%                              | 322.5                        | 267.9                        | 158.0                        | -17%                         | 942.1                      | 642.8                      | 297.8                      | -32%                       |                            |                            |
| Our Lady's Hospice Harold's Cross Limited      | 10.2                    | 13.2                    | -50%                 | -19%                              | 1,483.5                      | 1,615.8                      | 726.9                        | +9%                          | 2,707.0                    | 2,434.5                    | 1,002.7                    | -10%                       |                            |                            |
| Peamount Hospital Newcastle                    | 8.1                     | 10.2                    | -50%                 | -35%                              | 1,294.6                      | 1,364.5                      | 634.4                        | +5%                          | 1,882.2                    | 1,901.7                    | 767.4                      | +1%                        |                            |                            |
| Personal Injuries Assessment Board             | 0.1                     | 0.3                     | -50%                 | -75%                              | 0.0                          | 0.0                          | 0.0                          |                              | 109.2                      | 52.7                       | 24.4                       | -52%                       |                            |                            |
| Pobal 4                                        | 0.2                     | 0.5                     | -50%                 | -85%                              | 0.0                          | 0.0                          | 0.0                          |                              | 169.9                      | 88.0                       | 38.6                       | -48%                       |                            |                            |
| Port of Cork Company                           | 22.1                    | 30.1                    | -50%                 | -31%                              | 2,993.3                      | 3,997.9                      | 1,466.7                      | +34%                         | 5,115.0                    | 6,444.0                    | 1,947.5                    | +26%                       |                            |                            |
| Port of Galway 3                               | 0.7                     | 1.0                     | -50%                 | -30%                              | 91.0                         | 99.3                         | 44.6                         | +9%                          | 257.9                      | 202.5                      | 82.1                       | -21%                       |                            |                            |
| Port of Waterford Company                      | 1.9                     | 3.5                     | -50%                 | +43%                              | 84.2                         | 92.0                         | 41.3                         | +9%                          | 633.4                      | 653.2                      | 165.9                      | +3%                        |                            |                            |

- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.
- Note 4: The result calculated for the public body lies beyond the expected range of probable energy performance. However, this could be because of exceptional circumstances arising from the impact of COVID-19 on energy performance.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                       | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|-------------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                                       | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |
| Public Body                                           | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |
| Pre-Hospital Emergency Care Council                   | <0.1                    | <0.1                    | -50%                 | -85%                              | 0.0                          | 0.0                          | 0.0                          |                                   | 13.5                       | 6.0                        | 3.0                        | -56%                              |
| President's Establishment                             | 1.4                     | 1.6                     | -50%                 | +14%                              | 313.4                        | 290.6                        | 153.6                        | -7%                               | 313.4                      | 290.6                      | 153.6                      | -7%                               |
| Private Security Authority                            | <0.1                    | 0.1                     | -50%                 | -43%                              | 22.5                         | 14.2                         | 11.0                         | -37%                              | 46.1                       | 27.6                       | 16.3                       | -40%                              |
| Probation Service Agency of Dept of Justice &Equality | 2.8                     | 4.4                     | -50%                 | -28%                              | 239.6                        | 280.7                        | 117.4                        | +17%                              | 983.6                      | 812.4                      | 285.6                      | -17%                              |
| Professional Development Service for Teachers         | <0.1                    | <0.1                    | -50%                 | -83%                              | 0.0                          | 0.0                          | 0.0                          |                                   | 26.3                       | 11.2                       | 5.8                        | -57%                              |
| Property Service Regulatory Authority                 | <0.1                    | 0.1                     | -50%                 | -81%                              | 14.3                         | 13.8                         | 7.0                          | -4%                               | 36.5                       | 24.1                       | 12.0                       | -34%                              |
| PSI -The Pharmacy Regulator                           | 0.4                     | 0.5                     | -50%                 | +61%                              | 50.9                         | 43.8                         | 24.9                         | -14%                              | 145.7                      | 98.9                       | 46.4                       | -32%                              |
| Public Appointment Service                            | 0.6                     | 1.0                     | -50%                 | -69%                              | 44.7                         | 42.2                         | 21.9                         | -6%                               | 312.6                      | 181.9                      | 82.9                       | -42%                              |
| Quality and Qualifications Ireland                    | 0.3                     | 0.4                     | -50%                 | +29%                              | 35.8                         | 42.7                         | 17.6                         | +19%                              | 95.2                       | 74.0                       | 31.0                       | -22%                              |
| Raidió Teilifís Éireann                               | 32.6                    | 56.8                    | -50%                 | -57%                              | 2,008.9                      | 1,619.2                      | 984.3                        | -19%                              | 15,047.1                   | 10,482.2                   | 3,925.7                    | -30%                              |
| Rásaíocht Con Éireann/ Greyhound Racing Ireland       | 2.9                     | 4.7                     | -50%                 | -61%                              | 414.1                        | 230.7                        | 202.9                        | -44%                              | 1,622.4                    | 872.5                      | 475.2                      | -46%                              |
| Regulator of the National Lottery                     | <0.1                    | <0.1                    | -36%                 | -14%                              | 3.2                          | 5.5                          | 1.6                          | +71%                              | 8.6                        | 7.5                        | 2.8                        | -13%                              |
| Residential Tenancies Board                           | 0.4                     | 0.6                     | -50%                 | -73%                              | 43.1                         | 56.2                         | 21.1                         | +30%                              | 176.5                      | 116.0                      | 51.5                       | -34%                              |
| Revenue Commissioners                                 | 30.6                    | 47.5                    | -50%                 | -31%                              | 3,515.8                      | 3,104.8                      | 1,722.7                      | -12%                              | 10,796.2                   | 8,900.7                    | 3,354.9                    | -18%                              |
| Road Safety Authority                                 | 1.5                     | 2.4                     | -50%                 | -10%                              | 168.3                        | 142.3                        | 82.4                         | -15%                              | 422.2                      | 451.8                      | 143.0                      | +7%                               |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                          | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                          | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |                            |
| Public Body                              | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change                     |                            |                            |
| Roscommon County Council 3               | 11.7                    | 16.4                    | -50%                 | -38%                              | 1,931.1                      | 1,832.5                      | 946.2                        | -5%                          | 3,933.3                    | 3,270.3                    | 1,398.3                    | -17%                       |                            |                            |
| Rotunda Hospital                         | 7.7                     | 11.0                    | -50%                 | -6%                               | 751.9                        | 966.3                        | 368.4                        | +29%                         | 1,942.5                    | 2,024.7                    | 637.5                      | +4%                        |                            |                            |
| Royal College of Surgeons in Ireland     | 11.5                    | 17.4                    | -50%                 | -38%                              | 856.8                        | 1,193.8                      | 419.8                        | +39%                         | 3,391.5                    | 3,206.3                    | 997.9                      | -5%                        |                            |                            |
| Royal Hospital                           | 6.2                     | 7.2                     | -50%                 | +43%                              | 936.5                        | 1,155.9                      | 458.9                        | +23%                         | 1,294.8                    | 1,343.1                    | 538.6                      | +4%                        |                            |                            |
| Royal Irish Academy                      | 0.2                     | 0.3                     | -50%                 | -54%                              | 30.5                         | 31.4                         | 15.0                         | +3%                          | 95.3                       | 50.4                       | 29.6                       | -47%                       |                            |                            |
| Royal Irish Academy of Music             | 0.2                     | 0.3                     | -50%                 | -69%                              | 67.3                         | 34.3                         | 33.0                         | -49%                         | 146.6                      | 58.1                       | 50.9                       | -60%                       |                            |                            |
| Royal Victoria Eye and Ear Hospital      | 3.0                     | 3.8                     | -50%                 | +59%                              | 484.0                        | 498.0                        | 237.2                        | +3%                          | 739.4                      | 702.9                      | 295.1                      | -5%                        |                            |                            |
| safefood                                 | 0.1                     | 0.2                     | -50%                 | -68%                              | 0.0                          | 0.0                          | 0.0                          |                              | 93.3                       | 35.6                       | 21.0                       | -62%                       |                            |                            |
| Saint John of God Community Services CLG | 34.4                    | 42.0                    | -50%                 | +5%                               | 5,728.9                      | 6,612.6                      | 2,807.2                      | +15%                         | 8,005.2                    | 8,314.2                    | 3,321.7                    | +4%                        |                            |                            |
| Science Foundation Ireland               | 0.1                     | 0.2                     | -50%                 | -84%                              | 24.2                         | 6.1                          | 11.9                         | -75%                         | 108.5                      | 34.8                       | 30.9                       | -68%                       |                            |                            |
| Screen Ireland                           | <0.1                    | <0.1                    | -50%                 | +82%                              | 0.0                          | 0.0                          | 0.0                          |                              | 4.2                        | 17.4                       | 1.0                        | +315%                      |                            |                            |
| Sea Fisheries Administration Division    | 2.7                     | 4.7                     | -50%                 | -35%                              | 134.1                        | 182.5                        | 65.7                         | +36%                         | 988.4                      | 901.9                      | 259.3                      | -9%                        |                            |                            |
| Sea Fisheries Protection Authority       | 0.7                     | 1.1                     | -50%                 | -51%                              | 225.0                        | 108.0                        | 110.2                        | -52%                         | 371.8                      | 224.7                      | 143.5                      | -40%                       |                            |                            |
| Shannon Airport Authority DAC            | 12.2                    | 19.2                    | -50%                 | -53%                              | 1,645.3                      | 1,163.1                      | 806.2                        | -29%                         | 6,045.0                    | 3,569.6                    | 1,797.2                    | -41%                       |                            |                            |
| Shannon Commercial Properties            | 0.4                     | 0.7                     | -50%                 | -63%                              | 23.2                         | 15.9                         | 11.4                         | -31%                         | 202.6                      | 124.2                      | 51.6                       | -39%                       |                            |                            |

- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.

<!-- image -->

<!-- image -->

<!-- image -->

|                                    | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                    | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |
| Public Body                        | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             |                              | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |
| Shannon Foynes Port Company        | 2.2                     | 3.0                     | -50%                 | -33%                              | 471.0                        | 400.6                        | 230.8                        | -15%                         |                                   | 742.8                      | 631.9                      | 292.3                      | -15%                              |
| Sligo County Council 3             | 11.1                    | 16.3                    | -50%                 | -24%                              | 1,345.5                      | 1,566.8                      | 659.3                        | +16%                         |                                   | 3,878.7                    | 3,288.2                    | 1,232.3                    | -15%                              |
| Sligo Education Centre             | <0.1                    | <0.1                    | -50%                 | -15%                              | 14.5                         | 14.9                         | 7.1                          | +3%                          |                                   | 27.6                       | 19.1                       | 10.1                       | -31%                              |
| SOLAS                              | 0.6                     | 1.0                     | -50%                 | -57%                              | 50.8                         | 21.5                         | 24.9                         | -58%                         |                                   | 409.3                      | 191.8                      | 105.5                      | -53%                              |
| SOS Kilkenny Ltd                   | 0.7                     | 0.9                     | -50%                 | -57%                              | 203.9                        | 120.9                        | 99.9                         | -41%                         |                                   | 314.4                      | 178.8                      | 124.6                      | -43%                              |
| South Dublin County Council 3      | 27.5                    | 44.3                    | -50%                 | -40%                              | 2,846.2                      | 2,411.5                      | 1,394.6                      | -15%                         |                                   | 11,908.5                   | 8,381.3                    | 3,441.5                    | -30%                              |
| South Infirmary -Victoria Hospital | 6.5                     | 10.5                    | -50%                 | +27%                              | 590.8                        | 639.7                        | 289.5                        | +8%                          |                                   | 2,065.6                    | 1,902.1                    | 622.1                      | -8%                               |
| Southern Regional Assembly         | <0.1                    | <0.1                    | -50%                 | -88%                              | 7.7                          | 4.5                          | 3.8                          | -42%                         |                                   | 44.8                       | 8.7                        | 11.8                       | -80%                              |
| Special EU Programmes Body         | <0.1                    | <0.1                    | -50%                 | -55%                              | 0.0                          | 0.0                          | 0.0                          |                              |                                   | 14.0                       | 8.3                        | 3.2                        | -41%                              |
| Sport Ireland 2                    | 20.0                    | 26.5                    | -50%                 |                                   | 3,570.4                      | 3,020.8                      | 1,749.5                      | -15%                         |                                   | 5,907.8                    | 4,904.4                    | 2,284.9                    | -17%                              |
| St. Josephs Foundation             | 3.5                     | 4.6                     | -50%                 | -48%                              | 619.1                        | 654.8                        | 303.4                        | +6%                          |                                   | 986.0                      | 928.5                      | 386.2                      | -6%                               |
| St. Angela's College Sligo         | 1.3                     | 1.8                     | -50%                 | -64%                              | 177.4                        | 193.6                        | 86.9                         | +9%                          |                                   | 414.0                      | 356.4                      | 140.3                      | -14%                              |
| St. Catherine's Association Ltd    | 0.9                     | 1.1                     | -50%                 | -18%                              | 133.8                        | 217.2                        | 65.6                         | +62%                         |                                   | 218.1                      | 240.1                      | 84.6                       | +10%                              |
| St. Christopher's Services Ltd     | 1.2                     | 1.6                     | -50%                 | -32%                              | 214.2                        | 245.3                        | 105.0                        | +15%                         |                                   | 346.3                      | 338.1                      | 135.0                      | -2%                               |
| St. Cronan's Association CLG       | 0.4                     | 0.5                     | -50%                 | -6%                               | 49.5                         | 67.7                         | 24.2                         | +37%                         |                                   | 109.3                      | 103.1                      | 37.8                       | -6%                               |
| St. Francis Hospice                | 3.9                     | 5.3                     | -50%                 | -23%                              | 495.1                        | 587.6                        | 242.6                        | +19%                         |                                   | 975.4                      | 973.8                      | 351.1                      | -0%                               |
| St. James's Hospital               | 56.3                    | 79.6                    | -50%                 | -20%                              | 7,813.4                      | 7,239.1                      | 3,828.6                      | -7%                          |                                   | 17,034.5                   | 14,698.6                   | 5,930.2                    | -14%                              |

- Note 2:
- SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.
- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                         | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   |
|-----------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|----------------------------|
|                                         | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions                |                            |
| Public Body                             | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad |                            |
| St. John's Hospital                     | 2.6                     | 3.7                     | -50%                 | -27%                              | 317.8                        | 332.0                        | 155.7                        | +4%                          | 783.6                      | 686.6                      | 260.8                      | -12%                              |                            |
| St. Michael's Hospital                  | 4.0                     | 5.5                     | -50%                 | -18%                              | 523.8                        | 557.5                        | 256.7                        | +6%                          | 1,091.8                    | 1,007.5                    | 385.2                      | -8%                               |                            |
| St. Michael's House                     | 9.1                     | 11.5                    | -50%                 | -32%                              | 1,702.1                      | 1,585.2                      | 834.0                        | -7%                          | 2,621.9                    | 2,243.6                    | 1,041.4                    | -14%                              |                            |
| St. Patrick's Centre Kilkenny           | 1.1                     | 1.3                     | -50%                 | -88%                              | 661.9                        | 249.6                        | 324.3                        | -62%                         | 905.6                      | 283.5                      | 378.7                      | -69%                              |                            |
| St. Vincent's Hospital Fairview         | 3.2                     | 4.1                     | -50%                 | +21%                              | 529.5                        | 492.3                        | 259.4                        | -7%                          | 851.2                      | 765.1                      | 332.3                      | -10%                              |                            |
| St. Vincent's University Hospital       | 33.4                    | 49.3                    | -50%                 | -38%                              | 3,441.2                      | 3,807.4                      | 1,686.2                      | +11%                         | 10,411.7                   | 9,078.1                    | 3,258.2                    | -13%                              |                            |
| State Examinations Commission           | 1.1                     | 1.6                     | -50%                 | -26%                              | 87.2                         | 126.5                        | 42.7                         | +45%                         | 348.4                      | 299.3                      | 101.6                      | -14%                              |                            |
| State Laboratory                        | 4.8                     | 7.2                     | -50%                 | -81%                              | 685.0                        | 524.2                        | 335.7                        | -23%                         | 1,740.8                    | 1,332.5                    | 575.5                      | -23%                              |                            |
| Stewarts Care Ltd                       | 12.8                    | 15.3                    | -50%                 | -50%                              | 2,209.5                      | 2,410.6                      | 1,082.6                      | +9%                          | 2,975.3                    | 2,921.3                    | 1,256.4                    | -2%                               |                            |
| Sunbeam House Services                  | 2.7                     | 3.4                     | -50%                 | -27%                              | 602.5                        | 565.0                        | 295.2                        | -6%                          | 822.3                      | 714.4                      | 345.1                      | -13%                              |                            |
| Sustainable Energy Authority of Ireland | 0.4                     | 0.7                     | -50%                 | -57%                              | 16.6                         | 39.3                         | 8.1                          | +137%                        | 81.0                       | 121.7                      | 22.7                       | +50%                              |                            |
| Tallaght University Hospital            | 29.3                    | 43.3                    | -50%                 | -22%                              | 3,167.0                      | 3,303.5                      | 1,551.8                      | +4%                          | 8,591.3                    | 7,990.5                    | 2,777.8                    | -7%                               |                            |
| Teaching Council 2                      | 0.3                     | 0.6                     | -50%                 |                                   | 1.6                          | 1.0                          | 0.8                          | -36%                         | 127.1                      | 102.3                      | 29.0                       | -20%                              |                            |
| Teagasc                                 | 27.9                    | 39.3                    | -50%                 | -22%                              | 3,553.2                      | 4,283.7                      | 1,741.1                      | +21%                         | 8,307.1                    | 7,813.6                    | 2,815.1 -6%                |                                   |                            |
| Technological University Dublin         | 27.9                    | 39.7                    | -50%                 | -45%                              | 3,993.2                      | 3,546.1                      | 1,956.6                      | -11%                         | 9,971.5                    | 7,340.0                    | 3,304.1                    | -26%                              |                            |
| TG4                                     | 1.3                     | 2.2                     | -50%                 | -50%                              | 93.8                         | 88.7                         | 45.9                         | -5%                          | 594.8                      | 411.8                      | 159.1                      | -31%                              |                            |

- Note 2: SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.

<!-- image -->

<!-- image -->

|                                                   | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|---------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                                   | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |                            |
| Public Body                                       | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change                       | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2 Change    |                            |                            |
| The Bessborough Centre                            | 0.6                     | 0.8                     | -50%                 | -45%                              | 75.6                         | 72.4                         | 37.0                         | -4%                          | 189.5                      | 168.0                      | 62.9 -11%                  |                            |                            |
| The Health Information & Quality Authority (HIQA) | 0.8                     | 1.3                     | -50%                 | -63%                              | 64.3                         | 65.2                         | 31.5                         | +1%                          | 306.1                      | 231.5                      | 86.2 -24%                  |                            |                            |
| The Health Insurance Authority 2                  | <0.1                    | 0.1                     | -50%                 | -14%                              | 3.5                          | 6.0                          | 1.7                          | +69%                         | 16.7                       | 22.1                       | 4.7 +32%                   |                            |                            |
| The Health Research Board                         | 0.2                     | 0.3                     | -50%                 | -55%                              | 11.4                         | 20.6                         | 5.6                          | +81%                         | 77.7                       | 59.9                       | 20.5 -23%                  |                            |                            |
| The Insolvency Service of Ireland                 | 0.5                     | 0.8                     | -38%                 | -35%                              | 62.9                         | 33.4                         | 30.8                         | -47%                         | 170.4                      | 142.5                      | 55.2 -16%                  |                            |                            |
| The Irish Museum of Modern Art                    | 4.0                     | 5.2                     | -50%                 | -24%                              | 682.7                        | 621.5                        | 334.5                        | -9%                          | 1,392.5                    | 969.2                      | 494.2 -30%                 |                            |                            |
| The Land Development Agency 2                     | 0.1                     | 0.1                     | -26%                 |                                   | 0.0                          | 15.5                         | 0.0                          |                              | 78.9                       | 25.1                       | 23.3 -68%                  |                            |                            |
| The Medical Council                               | 0.5                     | 0.8                     | -50%                 | -52%                              | 52.0                         | 58.1                         | 25.5                         | +12%                         | 190.3                      | 139.9                      | 56.5 -26%                  |                            |                            |
| The National Concert Hall                         | 1.6                     | 2.4                     | -50%                 | -46%                              | 148.5                        | 159.5                        | 72.8                         | +7%                          | 671.8                      | 436.9                      | 191.0 -35%                 |                            |                            |
| The Pensions Authority                            | 0.1                     | 0.2                     | -50%                 | -72%                              | 0.0                          | 0.0                          | 0.0                          |                              | 64.5                       | 44.9                       | 15.0 -30%                  |                            |                            |
| The Property Registration Authority               | 2.8                     | 3.9                     | -50%                 | -28%                              | 320.4                        | 311.7                        | 157.0                        | -3%                          | 768.8                      | 656.6                      | 258.1 -15%                 |                            |                            |
| Tipperary County Council 3                        | 28.8                    | 41.9                    | -50%                 | -42%                              | 3,390.4                      | 3,510.3                      | 1,661.3                      | +4%                          | 9,103.9                    | 7,771.7 2,950.2            | -15%                       |                            |                            |
| Tipperary Education & Training Board              | 5.7                     | 7.9                     | -50%                 | -28%                              | 787.6                        | 876.1                        | 385.9                        | +11%                         | 1,560.1                    | 1,526.3                    | 560.8 -2%                  |                            |                            |
| Tourism Ireland                                   | <0.1                    | 0.2                     | -50%                 | -67%                              | 0.0                          | 0.0                          | 0.0                          |                              | 62.1 33.4                  | 13.9                       | -46%                       |                            |                            |

- Note 2:
- SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.
- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                              | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |
|----------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|
|                                              | 2021 energy consumption | 2021 energy consumption | Energy               | Energy                            | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |
| Public Body                                  | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2            | 2021 tCO2                    | 2030 target tCO2             | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021 tCO2                  | target                     | 2030 tCO2 Change           |                            |
| Transport Infrastructure Ireland             | 84.0                    | 141.7                   | -50%                 | -26%                              | 5,415.6                      | 6,119.4                      | 2,653.7                      | +13%                              | 28,533.0                   | 26,978.1                   | 7,888.4                    | -5%                        |                            |
| Trinity College Dublin                       | 75.8                    | 110.6                   | -50%                 | -36%                              | 8,522.8                      | 8,900.4                      | 4,176.2                      | +4%                               | 24,689.2                   | 20,389.0                   | 7,830.1                    | -17%                       |                            |
| Údarás na Gaeltachta                         | 3.2                     | 5.1                     | -50%                 | -22%                              | 62.2                         | 28.4                         | 30.5                         | -54%                              | 822.3                      | 666.2                      | 201.2                      | -19%                       |                            |
| University College Cork                      | 58.2                    | 90.7                    | -50%                 | -44%                              | 6,980.7                      | 5,574.4                      | 3,420.5                      | -20%                              | 19,460.9                   | 16,567.3                   | 6,269.0                    | -15%                       |                            |
| University College Dublin                    | 72.0                    | 99.6                    | -50%                 | -47%                              | 10,911.6                     | 9,645.7                      | 5,346.7                      | -12%                              | 25,583.1                   | 18,207.3                   | 8,668.3                    | -29%                       |                            |
| University of Limerick                       | 41.7                    | 63.6                    | -50%                 | -37%                              | 4,818.5                      | 4,358.0                      | 2,361.1                      | -10%                              | 14,832.1                   | 11,692.8                   | 4,626.8                    | -21%                       |                            |
| Valuation Office                             | 0.4                     | 0.7                     | -50%                 | -32%                              | 33.0                         | 18.1                         | 16.2                         | -45%                              | 184.5                      | 123.7                      | 50.4                       | -33%                       |                            |
| Valuation Tribunal 2                         | <0.1                    | <0.1                    | -50%                 |                                   | 0.0                          | 0.0                          | 0.0                          |                                   | 12.4                       | 6.5                        | 2.7                        | -47%                       |                            |
| Voluntary Health Insurance Board             | 5.4                     | 9.1                     | -50%                 | -44%                              | 229.1                        | 325.0                        | 112.3                        | +42%                              | 1,920.8                    | 1,666.5                    | 494.8                      | -13%                       |                            |
| Water Safety Ireland                         | 0.1                     | 0.1                     | -50%                 | -49%                              | 46.4                         | 25.8                         | 22.8                         | -44%                              | 58.2                       | 30.4                       | 25.5                       | -48%                       |                            |
| Waterford &Wexford Education &Training Board | 7.7                     | 11.6                    | -50%                 | -49%                              | 897.2                        | 962.1                        | 439.6                        | +7%                               | 4,483.5                    | 2,232.4                    | 1,228.7                    | -50%                       |                            |
| Waterford City &County Council 3             | 24.6                    | 39.4                    | -50%                 | -23%                              | 3,374.4                      | 2,483.2                      | 1,653.5                      | -26%                              | 8,962.2                    | 7,488.0                    | 2,915.0                    | -16%                       |                            |
| Waterford Institute of Technology            | 9.2                     | 14.4                    | -50%                 | -55%                              | 1,207.3                      | 853.6                        | 591.6                        | -29%                              | 3,893.0                    | 2,619.7                    | 1,197.0                    | -33%                       |                            |
| Waterford Teachers' Centre                   | 0.1                     | 0.1                     | -50%                 | -18%                              | 14.7                         | 17.3                         | 7.2                          | +18%                              | 34.6                       | 26.9                       | 11.7                       | -22%                       |                            |
| Waterways Ireland                            | 5.9                     | 7.8                     | -50%                 | -1%                               | 944.0                        | 1,069.8                      | 462.6                        | +13%                              | 1,770.1                    | 1,623.4                    | 648.2                      | -8%                        |                            |

- Note 2:
- SEAI identified aspects of the data submitted at the reporting deadline that needed to be addressed. Public body may have addressed these aspects prior to calculation of the published savings result.
- Note 3: Each local authority's result includes the performance of water services assets up to and including 2013, but excludes water services since then.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                  | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS          |
|----------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|-----------------------------------|
|                                  | 2021 energy consumption | 2021 energy consumption | Energy               | Energy                            | Non-electricity            | Non-electricity            | Non-electricity            | Non-electricity                   | GHGemissions               | GHGemissions               | GHGemissions               | GHGemissions               | GHGemissions                      |
| Public Body                      | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline tCO2          | 2021 tCO2                  | 2030 target tCO2           | Change since GHGbaseline good bad | GHG baseline tCO2          | 2021                       | tCO2 target tCO2           | 2030                       | Change since GHGbaseline good bad |
| West Cork Education Centre       | <0.1                    | <0.1                    | -50%                 | -31%                              | 0.0                        | 0.0                        | 0.0                        |                                   | 24.4                       | 13.0                       | 5.5                        | -47%                       |                                   |
| Western Care Association         | 2.4                     | 2.9                     | -50%                 | -67%                              | 1,066.1                    | 520.3                      | 522.4                      | -51%                              | 1,211.8                    | 635.8                      | 555.4                      | -48%                       |                                   |
| Western Development Commission   | <0.1                    | <0.1                    | -50%                 | -60%                              | 13.4                       | 17.6                       | 6.6                        | +31%                              | 18.0                       |                            | 18.9                       | 7.6 +5%                    |                                   |
| Westmeath County Council 3       | 15.2                    | 22.5                    | -50%                 | -26%                              | 2,159.0                    | 1,996.1                    | 1,057.9                    | -8%                               |                            | 5,503.8                    | 4,347.5                    | 1,812.0                    | -21%                              |
| Wexford County Council 3         | 20.8                    | 28.9                    | -50%                 | -41%                              | 2,527.7                    | 2,990.1                    | 1,238.6                    | +18%                              | 7,089.0                    |                            | 5,534.3                    | 2,267.2                    | -22%                              |
| Wexford Education Support Centre | <0.1                    | <0.1                    | -50%                 | -56%                              | 14.0                       | 9.1                        | 6.8                        | -35%                              | 26.0                       | 13.1                       | 9.5                        | -50%                       |                                   |
| Wicklow County Council 3         | 19.5                    | 29.5                    | -50%                 | -28%                              | 2,849.8                    | 2,228.4                    | 1,396.4                    | -22%                              | 7,350.5                    |                            | 5,647.5 2,412.6            | -23%                       |                                   |
| Workplace Relations Commission   | 0.7                     | 0.9                     | -50%                 | -48%                              | 97.4                       | 96.9                       | 47.7                       | -1%                               | 313.3                      | 163.3                      |                            | 96.1                       | -48%                              |

## 6.2.2 Other public bodies

The number of public bodies that are required to report in their own right changes from year to year due to organisational changes within the sector. Some smaller organisations that were requested to report in the past did not report data in their own right for 2021, but their data was reported via 'parent' organisations, while others may no longer come under the definition of a public body, as set out in SI 426 of 2014. Such organisations are not listed here. These organisational changes are the subject of continual review by SEAI.

The following public bodies did not submit complete reports for 2021:

The following organisation will begin reporting as a public body in 2023:

Approved Housing Bodies Regulatory Authority (AHBRA)

## Non-reporting public bodies

Irish Human Rights &amp; Equality Commission

RehabGroup

Nua Healthcare Services

## Appendix 1 - Departmental Groups Performance Results

Each listing comprises the following elements:

- · The departmental group's energy consumption in 2021 and its energy performance result for 2021. The performance result is presented alongside the energy saving values for all years since 2009. This indicates the extent to which each group's 2021 performance may have deviated from established trends arising from the impacts of the pandemic.
- · The group's non-electricity greenhouse gas emissions at the GHG baseline and in 2021, its 2030 target value and its change in non-electricity emissions since the baseline 32 . The annual change in non-electricity emissions for all years since the GHG baseline is also indicated.

total emissions since the baseline 32 .  The annual change in total emissions for all years since the GHG baseline is also indicated.

- · Summary of the reporting status of the aegis bodies within each departmental group.
- · The group's total greenhouse gas emissions at the GHG baseline and in 2021, its 2030 target value and its change in
- 32 These baseline and target calculations are based on the data reported to SEAI during the 2021 reporting cycle. The calculated values will be refined as better data becomes available.

<!-- image -->

<!-- image -->

|                                                                       | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |                   |
|-----------------------------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|-------------------|
|                                                                       | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Total GHGemissions                | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |                            |                   |
| Departmental Group                                                    | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline ktCO2           | 2021 ktCO2                   | 2030 target ktCO2            |                              | Change since GHGbaseline good bad | GHG baseline ktCO2         | 2021 ktCO2                 | 2030 target ktCO2          | Change since good          | GHGbaseline bad            | Reports completed |
| Agriculture, Food &Marine                                             | 972.2                   | 1,237.6                 | -50%                 | -20%                              | 45.1                         | 40.6                         | 22.1                         | -10%                         |                                   | 126.8                      | 105.8                      | 40.6                       | -17%                       |                            | 12/12             |
| Children, Equality, Disability, Integration &Youth                    | 6.4                     | 9.2                     | -50%                 | -31%                              | 0.8                          | 0.9                          | 0.4                          | +7%                          |                                   | 2.0                        | 1.8                        | 0.7                        | -12%                       |                            | 5/6               |
| Defence                                                               | 184.0                   | 227.6                   | -50%                 | -28%                              | 46.8                         | 37.0                         | 22.9                         | -21%                         |                                   | 61.4                       | 47.5                       | 26.2                       | -23%                       |                            | 3/3               |
| Education / Further & Higher Education, Research, Innovation &Science | 627.8                   | 912.4                   | -50%                 | -42%                              | 82.8                         | 77.0                         | 40.5                         | -7%                          |                                   | 217.6                      | 168.9                      | 71.0                       | -22%                       |                            | 77/78             |
| Education -standalone schools                                         | 387.0                   | 520.9                   | -50%                 | -22%                              | 62.5                         | 63.6                         | 30.6                         |                              | +2%                               | 114.3                      | 101.8                      | 42.3                       | -11%                       |                            | 2,898/ 3,669      |
| Enterprise, Trade & Employment                                        | 12.0                    | 19.6                    | -50%                 | -53%                              | 1.2                          | 0.9                          |                              | 0.6                          | -24%                              | 5.6                        | 3.6                        | 1.6                        | -36%                       |                            | 13/13             |
| Environment, Climate &Communications                                  | 284.3                   | 331.8                   | -50%                 | -42%                              | 55.7                         | 55.6                         |                              | 27.3                         | 0%                                | 84.1                       | 76.2                       | 33.7                       | -9%                        |                            | 13/13             |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                 | ENERGY PERFORMANCE      | ENERGY PERFORMANCE      | ENERGY PERFORMANCE   | ENERGY PERFORMANCE                | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS     | GREENHOUSE GAS EMISSIONS          | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   | GREENHOUSE GAS EMISSIONS   |                   |
|-------------------------------------------------|-------------------------|-------------------------|----------------------|-----------------------------------|------------------------------|------------------------------|------------------------------|-----------------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|-------------------|
|                                                 | 2021 energy consumption | 2021 energy consumption | Energy performance   | Energy performance                | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions | Non-electricity GHGemissions      | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         | Total GHGemissions         |                            |                   |
| Departmental Group                              | Final GWh               | Primary GWh             | 2030 target          | Change since EE baseline good bad | GHG baseline ktCO2           | 2021 ktCO2                   | 2030 target ktCO2            | Change since GHGbaseline good bad | GHG baseline ktCO2         | 2021 ktCO2                 | 2030 target ktCO2          | Change since good          | GHGbaseline bad            | Reports completed |
| Finance                                         | 83.2                    | 131.6                   | -50%                 | -38%                              | 9.1                          | 7.8                          | 4.5                          | -15%                              | 36.7                       | 24.5                       | 10.7                       | -33%                       |                            | 8/8               |
| Foreign Affairs                                 | 4.6                     | 7.2                     | -50%                 | -48%                              | 0.3                          | 0.4                          | 0.2                          | +25%                              | 1.7                        | 1.3                        | 0.5                        | -20%                       |                            | 1/1               |
| Health                                          | 20.3                    | 31.8                    | -50%                 | -45%                              | 1.9                          | 1.9                          | 0.9                          | +1%                               | 7.3                        | 5.8                        | 2.2                        | -21%                       |                            | 19/19             |
| Health -HSE                                     | 1,351.1                 | 1,827.2                 | -50%                 | -19%                              | 212.3                        | 212.1                        | 104.0                        | 0%                                | 381.1                      | 350.3                      | 142.2                      | -8%                        |                            | 58/59             |
| Housing, Local Government &Heritage             | 666.0                   | 1,172.9                 | -50%                 | -31%                              | 13.5                         | 18.1                         | 6.6                          | +34%                              | 243.9                      | 205.9                      | 58.7                       | -16%                       |                            | 19/19             |
| Housing, Local Government &Heritage - CCMA      | 701.7                   | 1,053.8                 | -50%                 | -37%                              | 88.8                         | 84.3                         | 43.5                         | -5%                               | 256.5                      | 203.0                      | 81.4                       | -21%                       |                            | 32/32             |
| Justice                                         | 261.4                   | 356.4                   | -50%                 | -25%                              | 39.7                         | 41.4                         | 19.5                         | +4%                               | 77.0                       | 69.7                       | 27.9                       | -9%                        |                            | 16/16             |
| Public Expenditure, NDP Delivery &Reform        | 49.0                    | 68.7                    | -50%                 | -44%                              | 6.7                          | 6.8                          | 3.3                          | +1%                               | 16.1                       | 13.0                       | 5.3                        | -19%                       |                            | 10/10             |
| Rural &Community Development                    | 0.7                     | 1.1                     | -50%                 | -75%                              | 0.1                          | 0.1                          | 0.0                          | -16%                              | 0.3                        | 0.2                        | 0.1                        | -38%                       |                            | 5/5               |
| Social Protection                               | 28.0                    | 44.3                    | -50%                 | -44%                              | 2.8                          | 2.8                          | 1.4                          | 0%                                | 11.2                       | 8.4                        | 3.2                        | -25%                       |                            | 3/3               |
| Taoiseach                                       | 14.8                    | 22.9                    | -50%                 | -42%                              | 1.2                          | 1.1                          | 0.6                          | -11%                              | 5.5                        | 3.9                        | 1.6                        | -29%                       |                            | 8/8               |
| Tourism, Culture, Arts, Gaeltacht, Sport &Media | 88.3                    | 135.2                   | -50%                 | -52%                              | 9.6                          | 8.7                          | 4.7                          | -10%                              | 33.2                       | 24.7                       | 10.0                       | -25%                       |                            | 21/21             |
| Transport                                       | 1,364.1                 | 1,674.5                 | -50%                 | -31%                              | 299.7                        | 292.6                        | 146.9                        | -2%                               | 393.2                      | 365.7                      | 168.0                      | -7%                        |                            | 22/22             |

## Appendix 2 - Reporting Methodology

The key principles of the reporting methodology are:

- · Individual public sector organisations (public bodies and schools) report annually for the previous year. There is a defined reporting window during which public bodies must report and the cycle repeats annually.

for the energy efficiency target. Public bodies can choose whichever of the following baseline periods suits them best: 2001-2005 (averaged); 2006-2008 (averaged); 2009 (single year). 2009 is the default energy efficiency baseline period for public bodies. Schools can choose any of these baselines, or any single year up to and including 2013 (default).

- · Public sector organisations report all their energy consumption for all fuel types (electricity, thermal fuels and transport fuels) at an organisational level.
- · Public sector organisations report baseline data on a onceoff basis.
- · Public sector organisations then report their energy consumption annually for the previous year.
- · For electricity &amp; natural gas, public bodies submit their meter numbers once to SEAI (MPRNs &amp; GPRNs) and then validate them annually. SEAI accesses the energy consumption data corresponding to these meter numbers directly from the regulated meter operators (ESB Networks and Gas Networks Ireland) each year.
- · For all non-network-connected energy sources (e.g. heating oils, LPG, solid fuels, diesel), public sector organisations self-report their consumption subtotals directly to SEAI.
- · Each year, each organisation must self-report a value for an activity metric that best corresponds with its energy usage.
- · Each year, each public body must report data on its business travel.

## Energy performance, energy efficiency and energy savings

In order to quantify energy savings, changes in given parameters that are related to energy use must be measured. The SEAI system uses energy performance indicators (EnPIs) to measure each organisation's energy performance. This enables organisations to determine how efficiently they are using energy because it accounts for changes in the activity level related to the energy use - or 'activity metric'- of each organisation.

Each year, an EnPI is calculated by dividing the organisation's total primary energy requirement (TPER) by an activity metric.

The primary indicator for tracking each organisation's energy savings is the change in the organisation's EnPI each year and is expressed as a percentage saving between an energy efficiency baseline period and the current year. This is a workable methodology which accounts for an organisation's energy performance as well as its energy consumption and enables organisations to determine if energy is being used efficiently or not in accordance with the definitions of ' energy efficiency' and 'energy savings' used by the European Commission.

The progress made by an organisation in meeting its 2030 energy efficiency target is measured against an historical baseline. Organisations have a choice of baseline period

## Greenhouse gas emissions

Energy-related greenhouse gas emissions are calculated for each public sector organisation by SEAI by multiplying the final energy consumption reported by the organisations by energy-type-specific emission factors. The emission factors used for the calculations are set by SEAI and are generally 'tailpipe' , or 'tank-to-wheel' , emission factors, i.e. emission factors that account for the emissions that arise from burning the fuel at the point of use, e.g. in a boiler, in a vehicle, at a power station. This approach is aligned with methodologies for preparing Ireland's national energy balance and national emissions inventory.

The progress made by an organisation in meeting its 2030 greenhouse gas emissions targets is tracked from a greenhouse gas baseline period, which is 2016-2018. Both targets are calculated on the basis of absolute reductions in emissions from baseline levels, i.e. there is no adjustment for changes in activity levels, capacity, organisational structure, service levels or demographics.

## Data verification

The validity of submitted data is checked in two ways:

- · Automated data verification assessment (DVA), which consists of validation rules built into the reporting software and processes to check for errors.
- · DVAs undertaken by SEAI-appointed assessors, which entail assessments of specific aspects of submissions. A DVA of a public body's submission consists of direct interaction(s) between an SEAI assessor and the public body to verify that the data submitted falls within certain acceptability criteria.

The purpose of the data verification system is threefold:

- · To ensure, insofar as practical, that the data which is submitted is robust and verifiable.
- · To provide an incentive for organisations to submit accurate data.
- · To provide a means for supporting organisations in improving how they gather and submit M&amp;R data and for providing feedback on the M&amp;R system.

SEAI would like to thank the meter registration system operators of ESB Networks and Gas Networks Ireland for their continued support in providing the data required to measure and monitor energy efficiency.

<!-- image -->

<!-- image -->

## Appendix 3 - Glossary

## Activity metric

A measure of the activity that an organisation undertakes that should be directly relevant to what drives energy consumption in the organisation.

## Business travel

Business travel occurs when people travel from one place of work to another place of work as part of their work duties.

## Emission factor

An emission factor is a figure that is used to calculate the quantity of emissions per unit of energy consumption or activity. Different energy types (fuel types) have different emission factors, e.g. heating oil (gasoil) has a higher emission factor than natural gas does. The emission factors for some energy types remain largely unchanged over time. The factors for some energy types, especially electricity, change from year to year. These changes can have a material impact on total greenhouse gas emissions calculated via M&amp;R.

## Energy efficiency baseline

The period from which an organisation's progress towards the 2030 energy efficiency target is tracked. Most public bodies use a 2009 baseline, while most schools use a baseline of 2013.

## Energy performance indicator (EnPI)

An energy performance indicator (EnPI) is a way of measuring an organisation's energy performance. Each year, an EnPI is calculated by dividing the organisation's total primary energy consumption by an activity metric.

## Final energy consumption or total final consumption (TFC)

This is the energy used by public sector organisations and other final consuming sectors of the economy, e.g. industry, transport, residential, etc. It excludes the energy used in the energy sector, e.g. for electricity generation, oil refining, etc.

## GPRN

A gas point registration number is a unique reference number assigned to every gas point on the natural gas network.

## MPRN

A meter point reference number is a unique 11-digit number assigned to every single electricity connection and meter in the country.

## Non-electricity greenhouse gas emissions

Non-electricity emissions comprise thermal emissions and transport emissions. They arise from the combustion of fuels for heat and transport.

## Primary energy or total primary energy requirement (TPER)

Primary energy accounts for energy that is consumed and/ or lost in transformation, transmission and distribution processes. It is calculated by applying primary energy conversion factors, which vary by fuel type, to final energy consumption values.

## Primary energy conversion factors

These are factors for converting quantities of final energy consumption to quantities of primary energy. The conversion factors for thermal and transport fuels typically remain unchanged over time. The conversion factor for electricity changes from year to year as the efficiency of the electricity system changes. These changes can have a material impact on energy efficiency savings calculated via M&amp;R.

## Public bodies

Public sector organisations that are not standalone schools are referred to as public bodies.

## Public sector organisations

For the purposes of the target, public sector organisations are considered to encompass the Civil Service, commercial and non-commercial State Bodies, State-owned financial institutions, the Defence Forces, An Garda Síochána, Health Service Executive hospitals and other facilities, Local and Regional Authorities, schools and universities.

## Standalone schools

Schools that are not part of Education &amp; Training Boards (ETBs) are referred to as standalone schools.

## Thermal energy, thermal fuels &amp; thermal emissions

For the purposes of this report, thermal energy (thermal fuels) comprises all solid, liquid and gas fuels used for non-transport purposes. This includes both fossil and renewable fuels used in boilers, space &amp; process heating systems, catering, fuelbased electricity generators (on site), combined heat and power (CHP) and in all plant, equipment &amp; other non-roadmobile vehicles. Thermal greenhouse gas emissions are the emissions that arise from the combustion of thermal energy.

## Total greenhouse gas emissions

Total greenhouse gas emissions comprise non-electricity emissions and emissions arising from the consumption of electricity.

## Transport energy, transport fuels &amp; transport emissions

For the purposes of this report, transport energy (transport fuels) comprises all liquid fuels used for transport vehicles (road, rail, air, water). This includes both fossil and renewable fuels. The electricity used for transport (rail, electric vehicles) is included within the electricity totals in this report. Transport greenhouse gas emissions are the emissions that arise from the combustion of transport energy.

<!-- image -->

<!-- image -->

## Sustainable Energy Authority of Ireland

3 Park Place Hatch Street Upper Dublin 2 Ireland D02 FX65

t

+353 1 808 2100

f

+353 1 808 2002

e

info@seai.ie

w  www.seai.ie

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->