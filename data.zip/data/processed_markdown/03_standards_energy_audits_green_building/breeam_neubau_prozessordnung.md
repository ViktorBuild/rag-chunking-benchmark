---
document_id: breeam_neubau_gebuehren
title: "BREEAM Neubau: Gebührenordnung & Zertifizierungsprozess"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "BREEAM D-A-CH"
year: 2023
original_file: "breeam_neubau_prozessordnung.pdf"
tables_detected: 64
converted_with: "Docling v2.32 (TableFormer)"
---

Dok.Nr.:

<!-- image -->

GÜ100

## GÜ100 Gebührenordnung

## Prozessgebühren BREEAM AT / DE Neubau

Der TÜV SÜD ist exklusiver Lizenzpartner von BRE Global und somit Standardgeber, Zertifizierungsstelle und National Scheme  Operator  (NSO) für  die  auf  Deutschland,  Österreich  und  die  Schweiz  adaptierten  Systemversionen  des BREEAM-Standards. Die hinsichtlich von Neubauprojekten adaptierte Systemversion BREEAM AT / DE Neubau ist eine Bewertungsmethodik zur Überprüfung der Nachhaltigkeit von der Planung bis zur Fertigstellung von Neubauprojekten. Die Beurteilung zum Zweck der Zertifizierung kann sich dabei auf die Planung und / oder auf die Fertigstellung  eines  Neubauprojektes  beziehen.  Details  zur Bewertung  nach  BREEAM  AT  /  DE  Neubau  können im jeweiligen  technischen  Handbuch  (SD  BNBAT01b  /  SD  BNDET01)  und  im  Systemdokument  SD100  nachgelesen werden.

Die Gebühren in diesem Dokument umfassen folgende Leistungen:

| 1.     | Gebühren Ausbildung und Listung von BREEAM AT / DE Neubau APs (Accredited Professional) .........                                                                       |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1.1.   | Listung BREEAM Neubau AP ............................................................................................................................ 2                 |
| 2.     | Gebühren Ausbildung und Lizenzierung von BREEAM DE Neubau Assessoren ...................................... 3                                                           |
| 2.1.   | Lizenzen............................................................................................................................................................. 3 |
| 3.     | Gebühren Top-Up Schulung für BREEAM Internationale Experten .............................................................                                               |
| 3.1.   | BREEAM AT/DE Neubau AP .............................................................................................................................                    |
| 3.2.   | BREEAM AT/DE Neubau Assessor .................................................................................................................... 4                     |
| 4.     | Registrierungs-Gebühren BREEAM AT / DE Audit ........................................................................................ 5                                 |
| 5.     | Zertifizierungs-Gebühren BREEAM AT / DE Neubau Audit .......................................................................... 6                                       |
| 5.1.   | Gebühren Qualitätssicherungs-Audit (QA-Audit) und Zertifizierung in Deutschland........................................... 6                                            |
| 5.1.1. | Gebühren Qualitätssicherungs-Audit und Zertifizierung von Nichtwohngebäuden in Deutschland ....................                                                         |
| 5.1.2. | Gebühren Qualitätssicherungs-Audit und Zertifizierung von Wohngebäuden in Deutschland............................ 7                                                     |
| 5.2.   | Gebühren Qualitätssicherungs-Audit und Zertifizierung in Österreich................................................................ 8                                   |
| 5.2.1. | Gebühren Qualitätssicherungs-Audit und Zertifizierung von Nichtwohngebäuden in Österreich........................ 8                                                     |
| 5.2.2. | Gebühren Qualitätssicherungs-Audit und Zertifizierung von Wohngebäuden in Österreich............................... 9                                                   |
| 6.     | Allgemeine Hinweise ........................................................................................................................................ 9          |
| 6.1.   | Bitte beachten bei der Rechnungsstellung: ........................................................................................................ 9                    |
| 6.2.   | Bitte beachten bei einem Eigentümerwechsel oder einer Gebäudeumbenennung: ........................................... 9                                                 |
| 6.3.   | Bitte beachten bei einem Assessor-Wechsel: .................................................................................................. 10                        |
| 6.4.   | Bitte beachten bei der Anforderung eines beschleunigten QA-Audits:............................................................. 10                                      |
| 6.5.   | Sonstige Gebühren:.......................................................................................................................................... 10         |

Alle Gebühren verstehen sich exklusiv der gültigen Mehrwertsteuer.

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR

07/2024

Seite 1 von 10

Datei: GÜ100\_BREEAM Neubau Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst!

Copyright TÜV SÜD Industrie Service GmbH

## GÜ100 Gebührenordnung

Dok.Nr.: GÜ100

## Prozessgebühren BREEAM AT / DE Neubau

<!-- image -->

## 1. Gebühren Ausbildung und Listung von BREEAM AT / DE Neubau APs (Accredited Professional)

Die Ausbildung zum BREEAM AT / DE Neubau AP besteht aus einer zweitägigen Schulung, der eine Vorbereitung im Selbststudium  vorangestellt  ist,  das  sogenannte  Pre  Course  Work  (PCW).  Dies  wird  den  Teilnehmern  digital  zur Verfügung  gestellt  und  ist  vor Beginn  der  Schulung  zu  bearbeiten.  Der  Umfang  des  PCW  beträgt  ca.  20 Wochenstunden.

Die Ausbildung schließt mit einer Prüfung ab.

Für die Ausbildung zum BREEAM AT / DE Neubau AP werden folgende Gebühren erhoben:

| Ausbildungsgebühren BREEAM AT / DE Neubau AP                                    | Ausbildungsgebühren BREEAM AT / DE Neubau AP   |
|---------------------------------------------------------------------------------|------------------------------------------------|
| BREEAM AT / DE Neubau AP Ausbildung (3-Tages-Kurs mit Vorbereitung und Prüfung) | 1.500 ,00 €                                    |
| Wiederholung der BREEAM AT / DE Neubau AP Prüfung                               | 500,00 €                                       |

Ein Discount von 10 % auf die AP-Ausbildungsgebühren wird folgenden Fachleuten nach Vorlage der Qualifikation gewährt:

- · BREEAM DE, AT und CH Bestand Auditoren
- · BREEAM New Construction International Assessoren
- · BREEAM DE / AT Neubau Assessor
- · LEED Accredited Professionals
- · DGNB Registered Professionals, Consultants und Auditoren

## 1.1. Listung BREEAM Neubau AP

Die Gebühren für die Listung des BREEAM AT / DE Neubau APs, gültig 365 Tage nach Rechnungsstellung, auf der TÜV  SÜD  Webseite  (www.breeam.de)  und  Green  Book  Live  (www.greenbooklive.com)  belaufen  sich  auf  (für  die Listung  als  BREEAM  Neubau  AP  ist  keine  Unternehmenslizenz  notwendig):  Die  Gültigkeit  der  Listung  kann  nach Ablauf der 365 Tage durch die erneute Entrichtung der Listungsgebühr wiederum um 365 Tage verlängert werden.

## Listung AP

Listung BREEAM AT / DE Neubau AP (für beide Länder)

500 ,00 €

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR 07/2024

Seite 2 von 10

Datei: GÜ100\_BREEAM Neubau Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

## GÜ100 Gebührenordnung

Dok.Nr.: GÜ100

## Prozessgebühren BREEAM AT / DE Neubau

<!-- image -->

## 2. Gebühren Ausbildung und Lizenzierung von BREEAM DE Neubau Assessoren

Die Ausbildung zum BREEAM DE Neubau Assessor besteht aus einer dreitätigen Schulung.

Vorangestellt ist eine Vorbereitung im Selbststudium, das sogenannte Pre Course Work (PCW), das den Teilnehmern digital zur Verfügung gestellt wird und vor Beginn der Schulung zu bearbeiten ist. Der Umfang des PCW beträgt ca. 30 Wochenstunden.

Die Schulung schließt mit zwei Prüfungen ab.

Für die Ausbildung zum BREEAM AT / DE Neubau Assessor werden folgende Gebühren erhoben:

| Ausbildungsgebühren BREEAM AT / DE Neubau Assessor                                    | Ausbildungsgebühren BREEAM AT / DE Neubau Assessor   |
|---------------------------------------------------------------------------------------|------------------------------------------------------|
| BREEAM AT / DE Neubau Assessor Ausbildung (2-Tages-Kurs mit Vorbereitung und Prüfung) | 3.750 ,00 €                                          |
| Wiederholung der BREEAM AT / DE Neubau Assessor Prüfung                               | 550,00 €                                             |

## 2.1. Lizenzen

Die Lizenzgebühren für den BREEAM AT / DE Neubau Assessor setzen sich aus einer Unternehmens-Lizenzgebühr und der Assessor-Lizenzgebühr (personengebunden) zusammen. Die Gültigkeit beider Lizenzen ist auf 365 Tage nach Rechnungsstellung begrenzt.

Die  Unternehmenslizenz  ist  für  den  Standort  des  Unternehmens  zu  zahlen.  Die  Assessoren-Lizenzen  sind  für  das jeweilige Land, für das die Lizenz erworben wird, zu entrichten.

## Lizenzgebühr Unternehmen:

Die  Lizenzgebühren  für  die  Unternehmenslizenz  differieren  je  nach  Größe  des  Unternehmens,  dem  der  Assessor angehört. Die Lizenzgebühr für Unternehmen wird pro Land nur einmal erhoben und ist unabhängig von den darunter lizenzierten BREEAM DE/AT/CH Bestand Auditoren und BREEAM DE/AT Neubau Assessoren.

| Unternehmens-Lizenzen   | Unternehmens-Lizenzen   |
|-------------------------|-------------------------|
| 1-5 Mitarbeiter         | 500,00 €                |
| 6-25 Mitarbeiter        | 1.000,00 €              |
| 26-50 Mitarbeiter       | 2.000,00 €              |
| 51-150 Mitarbeiter      | 3.500,00 €              |
| >150 Mitarbeiter        | 5.500,00 €              |

## Lizenzgebühr BREEAM AT / DE Neubau Assessor (personenbezogen):

Eine personenbezogene Lizenz (Assessor und / oder Auditor Lizenz) setzt eine gültige Unternehmenslizenz voraus. Die personenbezogenen Lizenzgebühren sind abhängig von der Anzahl der Lizenzen pro Person in einem Land (z.B. BREEAM DE Bestand Auditor Lizenz, BREEAM DE Neubau Assessor Lizenz).

| Assessor-Lizenzen                     | Assessor-Lizenzen   |
|---------------------------------------|---------------------|
| 1. Lizenz in einem Land               | 1.200,00 €          |
| jede weitere Lizenz in demselben Land | 800,00 €            |

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR

07/2024

Seite 3 von 10

Datei: GÜ100\_BREEAM Neubau Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

## GÜ100 Gebührenordnung

Dok.Nr.: GÜ100

## Prozessgebühren BREEAM AT / DE Neubau

## 3. Gebühren Top-Up Schulung für BREEAM Internationale Experten

## 3.1. BREEAM AT / DE Neubau AP

Die Top-Up Schulung zum BREEAM AT / DE Neubau AP besteht aus einer dreistündigen Schulung.

Voraussetzung für die Teilnahme an der Schulung ist eine aktuelle Listung als BREEAM International New Construction AP  oder  BREEAM UK New Construction AP.  Die  Teilnahme  berechtigt zur Listung als BREEAM AT / DE Neubau AP.

Für die Ausbildung zum BREEAM AT / DE Neubau AP werden folgende Gebühren erhoben

| Ausbildungsgebühren BREEAM AT / DE Neubau AP   | Ausbildungsgebühren BREEAM AT / DE Neubau AP   |
|------------------------------------------------|------------------------------------------------|
| Ausbildung (3-Stunden-Kurs)                    | 750,00 €                                       |

Die Gebühren für die Listung sind unter 1.1 aufgeführten.

## 3.2. BREEAM AT / DE Neubau Assessor

Die Top-Up Schulung zum BREEAM AT / DE Neubau Assessor besteht aus einer dreistündigen Schulung.

Voraussetzung für die Teilnahme an der Schulung ist eine aktuelle Lizenz als BREEAM International New Construction Assessor. Die Schulung schließt mit einer mündlichen Prüfung ab.

Für die Ausbildung zum BREEAM AT / DE Neubau Assessor werden folgende Gebühren erhoben:

| Ausbildungsgebühren BREEAM AT / DE Neubau Assessor   | Ausbildungsgebühren BREEAM AT / DE Neubau Assessor   |
|------------------------------------------------------|------------------------------------------------------|
| Ausbildung (3-Stunden-Kurs) und mündliche Prüfung    | 1.250,00 €                                           |
| Wiederholung mündliche Prüfung                       | 500,00 €                                             |

Die Gebühren für die Lizenz sind unter 2.1 aufgeführten.

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR

07/2024

Seite 4 von 10

Datei: GÜ100\_BREEAM Neubau

Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst!

Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## GÜ100 Gebührenordnung

Dok.Nr.: GÜ100

## Prozessgebühren BREEAM AT / DE Neubau

## 4. Registrierungs-Gebühren BREEAM AT / DE Audit

Registrierungen  zu  einem  Audit  nach  BREEAM  AT  /  DE  Neubau  können  ausschließlich  über  das  Online-Tool durchgeführt werden.

Die  Registrierungsgebühr  wird  pro  Objekt  erhoben.  Die  Registrierungsgebühren  fallen  einmalig  für  das  Objekt  an, unabhängig  von  der  angestrebten  Zertifizierung  der  Planung  oder  der  Fertigstellung  eines  Neubauprojektes.  Der maximale Bearbeitungszeitraum eines Audits nach BREEAM AT / DE Neubau ist zeitlich auf maximal 3 Jahre nach Registrierung begrenzt.

Die Gebühren für die Registrierung eines Objektes zum Audit stellen sich wie folgt dar:

| Gebühren - Registrierung                                        | Gebühren - Registrierung   |
|-----------------------------------------------------------------|----------------------------|
| Registrierung des Neubauprojektes zur Durchführung eines Audits | 1.000,00 €                 |

Möchte  ein  Kunde  mehr  als  ein  Objekt  durch  einen  lizenzierten  BREEAM  AT  /  DE  Neubau  Assessor  registrieren lassen,  wird  ein  Mengenrabatt  entsprechend  untenstehender  Tabelle 'Gebühren Registrierung mehrerer Objekte' gewährt. Voraussetzung hierfür ist die Registrierung mehrerer Objekte am selben Tag mit Angabe eines Bestellers, der final auf der Zertifikatsurkunde ausgewiesen wird. Die reduzierte Gebühr bezieht sich jeweils auf die Gebühr des ersten Objektes bis zur Anzahl aller Objekte innerhalb der Rabattstufe.

| Gebühren - Registrierung mehrerer Objekte           | Gebühren - Registrierung mehrerer Objekte   |
|-----------------------------------------------------|---------------------------------------------|
| Registrierung zur onlinebasierten Zertifizierung ab | 850 ,00 € /Objekt                           |
| 5 Objekten                                          |                                             |
| Registrierung zur onlinebasierten Zertifizierung ab | 700 ,00 € /Objekt                           |
| 10 Objekten                                         |                                             |

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR

07/2024

Seite 5 von 10

Datei: GÜ100\_BREEAM Neubau

Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst!

Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## GÜ100 Gebührenordnung

Dok.Nr.: GÜ100

## Prozessgebühren BREEAM AT / DE Neubau

## 5. Zertifizierungs-Gebühren BREEAM AT / DE Neubau Audit

Für  Neubauprojekte,  die  in  Deutschland  oder  Österreich  zertifiziert  werden  sollen,  werden  unterschiedlich  hohe Gebühren erhoben.

## 5.1.  Gebühren Qualitätssicherungs-Audit (QA-Audit) und Zertifizierung in Deutschland

## 5.1.1. Gebühren Qualitätssicherungs-Audit und Zertifizierung von Nichtwohngebäuden in Deutschland

Die Gebühren zur Zertifizierung der Planung und / oder nach Fertigstellung werden auf Grundlage der Bruttogrundfläche Bereich A (BGFa) in m² des zu zertifizierenden Neubauprojektes erhoben. Parkflächen sind dabei nicht mit  einzubeziehen.  Die  eindeutige  Flächenberechnung  muss  zur  Erhebung  der  Gebühren  mit  eingereicht werden. Es gibt zwei Möglichkeiten zur Zertifizierung:

- 1. Zweistufige Zertifizierung - Zertifikat Planung + Zertifikat nach Fertigstellung
- 2. Einstufige Zertifizierung - Zertifikat nach Fertigstellung

## Zweistufige Zertifizierung für Nichtwohngebäude in Deutschland:

## Gebühren Qualitätssicherungs-Audit und Zertifizierung

| Phase               | m² BGFa    | m² BGFa        | m² BGFa         | m² BGFa         | m² BGFa     |
|---------------------|------------|----------------|-----------------|-----------------|-------------|
| Phase               | ≤ 7.500    | 7.501 - 15.000 | 15.001 - 27.500 | 27.501 - 45.000 | > 45.000    |
| Planung             | 4.500,00 € | 6.000,00 €     | 8.500,00 €      | 10.000,00 €     | 11.500,00 € |
| Nach Fertigstellung | 2.500,00 € | 3.500,00 €     | 4. 500,00 €     | 6.500,00 €      | 7.00000 €   |
| Gesamt              | 7.000,00 € | 9.500,00 €     | 13.000,00 €     | 16.500,00 €     | 18.500,00 € |

## Einstufige Zertifizierung für Nichtwohngebäude in Deutschland:

## Gebühren Qualitätssicherungs-Audit und Zertifizierung

| Phase               | m² BGFa    | m² BGFa        | m² BGFa         | m² BGFa         | m² BGFa     |
|---------------------|------------|----------------|-----------------|-----------------|-------------|
| Phase               | ≤ 7.500    | 7.501 - 15.000 | 15.001 - 27.500 | 27.501 - 45.000 | > 45.000    |
| Nach Fertigstellung | 7.000,00 € | 9.500,00 €     | 13.000,00 €     | 16.500,00 €     | 18.500,00 € |
| Gesam t             | 7.000,00 € | 9.500,00 €     | 13.000,00 €     | 16.500,00 €     | 18.500,00 € |

## Beispiel: Neubauprojekt 8.500 m² BGFa

Fall 1:

Einreichung zur Zertifizierung der Planung

6.000,00 €

Einreichung zur Zertifizierung nach Fertigstellung

3.500,00 €

Zertifizierungsgebühren gesamt

9.500,00 €

## Fall 2: Einreichung zur Zertifizierung nach Fertigstellung

ohne

vorangegangene Zertifizierung der Planung

9.500,00 €

Zertifizierungsgebühren gesamt

9.500,00 €

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR

07/2024

Seite 6 von 10

Datei: GÜ100\_BREEAM Neubau Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## GÜ100 Gebührenordnung

Dok.Nr.: GÜ100

<!-- image -->

## Prozessgebühren BREEAM AT / DE Neubau

## 5.1.2. Gebühren Qualitätssicherungs-Audit und Zertifizierung von Wohngebäuden in Deutschland

Die  Gebühren  zur  Zertifizierung  der  Planung  und  /  oder  nach  Fertigstellung  werden  auf  Grundlage  der  Anzahl  an Wohneinheiten  erhoben.  Die  eindeutige  Darstellung  der  Wohneinheiten  muss  zur  Erhebung  der  Gebühren  mit eingereicht werden. Es gibt zwei Möglichkeiten zur Zertifizierung:

- 1. Zweistufige Zertifizierung - Zertifikat Planung + Zertifikat nach Fertigstellung
- 2. Einstufige Zertifizierung - Zertifikat nach Fertigstellung

## Zweistufige Zertifizierung für Wohngebäude in Deutschland:

## Gebühren - Zertifizierung

|                     | Anzahl Wohneinheiten   | Anzahl Wohneinheiten   | Anzahl Wohneinheiten   | Anzahl Wohneinheiten   |
|---------------------|------------------------|------------------------|------------------------|------------------------|
| Phase               | 1                      | 2-5                    | 6-10                   | 11- ∞                  |
| Planung             | 1.500,00 €             | 300,00 €               | 150,00 €               | ---                    |
| Nach Fertigstellung | 1.000,00 €             | 200,00 €               | 50,00 €                | 50,00 €                |
| Gesamt              | 2.500,00 €             | 500,00 €               | 20 0,00 €              | 50,00 €                |

## Einstufige Zertifizierung für Wohngebäude in Deutschland:

## Gebühren - Zertifizierung

| Phase               | 1          | Anzahl 2-5   | Wohneinheiten 6-10   | 11- ∞   |
|---------------------|------------|--------------|----------------------|---------|
| Nach Fertigstellung | 2.500,00 € | 500,00 €     | 200,00 €             | 50,00 € |

Für  alle  Wohngebäude  gilt  zusätzlich:  Liegen  die  über  die  Wohneinheiten  ermittelten  Gebühren  oberhalb  der flächenbezogenen  Gebühren  für  Nichtwohngebäude,  so  sind  lediglich  die  Gebühren  für  Nichtwohngebäude  zu entrichten.

## Beispiel: Neubauprojekt Wohnungsbau 4 Wohneinheiten (WE) in Deutschland

Fall 1: Einreichung zur Zertifizierung der Planung Einreichung zur Zertifizierung nach Fertigstellung Zertifizierungsgebühren gesamt

1.500,00 €+3 WE x 300,00 €/WE = 2.400,00 € 1.000 ,00 €+3 WE x 200,00 €/WE = 1.600,00 € 4.000 ,00 €

Fall 2: Einreichung zur Zertifizierung nach Fertigstellung ohne vorangegangene Zertifizierung der Planung Zertifizierungsgebühren gesamt

2.500,00 €+3 WE x 500,00 €/WE = 4.000,00 € 4.000,00 €

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR

07/2024

Seite 7 von 10

Datei: GÜ100\_BREEAM Neubau Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst!

Copyright TÜV SÜD Industrie Service GmbH

## GÜ100 Gebührenordnung

Dok.Nr.: GÜ100

## Prozessgebühren BREEAM AT / DE Neubau

## 5.2.  Gebühren Qualitätssicherungs-Audit und Zertifizierung in Österreich

## 5.2.1. Gebühren Qualitätssicherungs-Audit und Zertifizierung von Nichtwohngebäuden in Österreich

Die Gebühren zur Zertifizierung der Planung und / oder nach Fertigstellung werden auf Grundlage der Bruttogrundfläche Bereich A (BGFa) in m² des zu zertifizierenden Neubauprojektes erhoben. Parkflächen sind dabei nicht mit  einzubeziehen.  Die  eindeutige  Flächenberechnung  muss  zur  Erhebung  der  Gebühren  mit  eingereicht werden. Es gibt zwei Möglichkeiten zur Zertifizierung:

- 1. Zweistufige Zertifizierung - Zertifikat Planung + Zertifikat nach Fertigstellung
- 2. Einstufige Zertifizierung - Zertifikat nach Fertigstellung

## Zweistufige Zertifizierung für Nichtwohngebäude in Österreich:

## Gebühren Qualitätssicherungs-Audit und Zertifizierung

| Phase               | m² BGFa     | m² BGFa        | m² BGFa         | m² BGFa         | m² BGFa      |
|---------------------|-------------|----------------|-----------------|-----------------|--------------|
| Phase               | ≤ 7.500     | 7.501 - 15.000 | 15.001 - 27.500 | 27.501 - 45.000 | > 45.000     |
| Planung             | 3.150 ,00 € | 4.200 ,00 €    | 5.950 ,00 €     | 7 .000,00 €     | 8.050 ,00 €  |
| Nach Fertigstellung | 1.75 0,00 € | 2.45 0,00 €    | 3.150 ,00 €     | 4.550 ,00 €     | 4.900,00 €   |
| Gesamt              | 4.900 ,00 € | 6.650 ,00 €    | 9.1 00,00 €     | 11.550 ,00 €    | 12.950 ,00 € |

## Einstufige Zertifizierung für Nichtwohngebäude in Österreich:

## Gebühren Qualitätssicherungs-Audit und Zertifizierung

|                     | m² BGFa     | m² BGFa        | m² BGFa         | m² BGFa         | m² BGFa      |
|---------------------|-------------|----------------|-----------------|-----------------|--------------|
| Phase               | ≤ 7.500     | 7.501 - 15.000 | 15.001 - 27.500 | 27.501 - 45.000 | > 45.000     |
| Nach Fertigstellung | 4.900 ,00 € | 6.650 ,00 €    | 9.1 00,00 €     | 11.550 ,00 €    | 12.950 ,00 € |
| Gesam t             | 4.900 ,00 € | 6.650 ,00 €    | 9.1 00,00 €     | 11.550, 00 €    | 12.950, 00 € |

## Beispiel: Neubauprojekt 8.500 m² BGFa

Fall 1:

Einreichung zur Zertifizierung der Planung

4.200,00 €

Einreichung zur Zertifizierung nach Fertigstellung

2.450 ,00 €

Zertifizierungsgebühren gesamt

6.650 ,00 €

Fall 2:

Einreichung zur Zertifizierung nach Fertigstellung

ohne vorangegangene Zertifizierung der Planung

6.650 ,00 €

Zertifizierungsgebühren gesamt

6.650 ,00 €

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR

07/2024

Seite 8 von 10

Datei: GÜ100\_BREEAM Neubau

Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## GÜ100 Gebührenordnung

Dok.Nr.: GÜ100

<!-- image -->

## Prozessgebühren BREEAM AT / DE Neubau

## 5.2.2. Gebühren Qualitätssicherungs-Audit und Zertifizierung von Wohngebäuden in Österreich

Die  Gebühren  zur  Zertifizierung  der  Planung  und/oder  nach  Fertigstellung  werden  auf  Grundlage  der  Anzahl  an Wohneinheiten  erhoben.  Die  eindeutige  Darstellung  der  Wohneinheiten  muss  zur  Erhebung  der  Gebühren  mit eingereicht werden. Es gibt zwei Möglichkeiten zur Zertifizierung:

- 1. Zweistufige Zertifizierung - Zertifikat Planung + Zertifikat nach Fertigstellung
- 2. Einstufige Zertifizierung -Zertifikat nach Fertigstellung

## Zweistufige Zertifizierung für Wohngebäude in Österreich:

## Gebühren - Zertifizierung

|                     | Anzahl Wohneinheiten   | Anzahl Wohneinheiten   | Anzahl Wohneinheiten   | Anzahl Wohneinheiten   |
|---------------------|------------------------|------------------------|------------------------|------------------------|
| Phase               | 1                      | 2-5                    | 6-10                   | 11- ∞                  |
| Planung             | 1.050 ,00 €            | 21 0,00 €              | 105 ,00 €              | ---                    |
| Nach Fertigstellung | 700 ,00 €              | 14 0,00 €              | 35 ,00 €               | 35 ,00 €               |
| Gesamt              | 1.750 ,00 €            | 35 0,00 €              | 140 ,00 €              | 35 ,00 €               |

## Einstufige Zertifizierung für Wohngebäude in Österreich:

| Gebühren - Zertifizierung   | Gebühren - Zertifizierung   | Gebühren - Zertifizierung   | Gebühren - Zertifizierung   | Gebühren - Zertifizierung   |
|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|
| Phase                       | 1                           | Anzahl 2-5                  | Wohneinheiten 6-10          | 11- ∞                       |
| Nach Fertigstellung         | 1.750 ,00 €                 | 350 ,00 €                   | 140 ,00 €                   | 35 ,00 €                    |

Für  alle  Wohngebäude  gilt  zusätzlich:  Liegen  die  über  die  Wohneinheiten  ermittelten  Gebühren  oberhalb  der flächenbezogenen  Gebühren  für  nicht  Wohngebäude,  so  sind  lediglich  die  Gebühren  für  Nichtwohngebäude  zu entrichten.

## Beispiel: Neubauprojekt Wohnungsbau 4 Wohneinheiten (WE) in Österreich

Fall 1: Einreichung zur Zertifizierung der Planung Einreichung zur Zertifizierung nach Fertigstellung Zertifizierungsgebühren gesamt

1.050,00 € +3 WE x 210 ,00 €/WE = 1.680 ,00 € 700 ,00 € +3 WE x 14 0,00 €/WE = 1.12 0,00 €

2.800 ,00 €

Fall 2: Einreichung zur Zertifizierung nach Fertigstellung ohne vorangegangene Zertifizierung der Planung Zertifizierungsgebühren gesamt

1.750 ,00 €+3 WE x 350 ,00 €/WE = 2.800, 00 € 2.800,00 €

## 6. Allgemeine Hinweise

## 6.1. Bitte beachten bei der Rechnungsstellung:

- · Die  Registrierungs-  und  Zertifizierungsgebühren  werden  dem  im  Online-Tool  als  Auftraggeber  angegebenen Unternehmen durch TÜV SÜD in Rechnung gestellt.

## 6.2. Bitte beachten bei einem Eigentümerwechsel oder einer Gebäudeumbenennung:

- · Sollte  während  eines  Auditprozesses  ein  Wechsel  des  Auftraggebers  /  Bestellers  stattfinden,  so  wird  eine einmalige  Bearbeitungsgebühr  von 250,00 € erhoben.  Des  Weiteren  ist  ein  offizielles Schreiben  des Auftraggebers / Bestellers bei TÜV SÜD vorzulegen, in dem der Kunde die Anpassungen bestätigt.

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR 07/2024

Seite 9 von 10

Datei: GÜ100\_BREEAM Neubau

Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

Dok.Nr.:

GÜ100

## GÜ100 Gebührenordnung

## Prozessgebühren BREEAM AT / DE Neubau

## 6.3. Bitte beachten bei einem Assessor-Wechsel:

- · Sollte während eines Auditprozesses ein Assessor-Wechsel stattfinden, so wird eine einmalige Bearbeitungsgebühr  von 250,00 € erhoben.  Des  Weiteren  ist  ein  offizielles  Schreiben  des  Auftraggebers  / Bestellers bei TÜV SÜD vorzulegen, in dem der Auftraggeber / Besteller die Freigabe und den Übergang der Nachweise  an  den  neuen  Assessor  bestätigt.  Zusätzlich  muss  der  bestehende  lizenzierte  Assessor  eine unterschriebene Bestätigung zur Übertragung des Audits an den neuen lizenzierten  Assessor bei TÜV SÜD einreichen.

## 6.4. Bitte beachten bei der Anforderung eines beschleunigten QA-Audits:

- · Die Bearbeitungszeit eines regulären QA-Audits beträgt 20 Werktage. Für die Durchführung eines beschleunigten QA-Audits durch die Zertifizierungsstelle werden zusätzliche Gebühren erhoben. Das beschleunigte  QA-Audit  dauert 10  Werktage und  wird  mit  einer  zusätzlichen  Gebühr  je  Einreichung  von 2.000,00 € berechnet. Ein beschleunigtes QA-Audit muss 20 Werktage vor Einreichung bei der Zertifizierungsstelle beantragt werden. Je nach Arbeitsaufkommen, kann ein beschleunigtes QA-Audit von der Zertifizierungsstelle nicht garantiert werden und wird vor Rechnungstellung dem Antragssteller mitgeteilt.

## 6.5. Sonstige Gebühren:

Wenn Beschwerden gegenüber einem Assessor erhoben werden, haftet der Assessor für die Kosten, die durch Überprüfungen durch TÜV  SÜD  entstehen  und  konsequenterweise für die Nachbesserung  und  ReZertifizierung,  wenn  die  Prüfung  ergibt,  dass  die  Arbeit  des  Assessors  nicht  korrekt  durchgeführt  wurde (vergleiche LI003 und SD100).

## Gebühren Beschwerdeprüfung

| Qualitätssicherung durch in Inaugenscheinnahme durch TÜV SÜD vor Ort je Arbeitstag (8 h) exklusive Reise-und Aufenthaltskosten, die dem Assessor zusätzlich in Rechnung gestellt werden   | 2.500,00 €   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------|
| Stornierungsgebühren der Qualitätssicherung:                                                                                                                                              |              |
| 0 - 14 Tage vor dem geplanten Vorort-Termin                                                                                                                                               | 2.000,00 €   |
| 15 - 28 Tage vor dem geplanten Vorort-Termin                                                                                                                                              | 1.000,00 €   |
| Mehr als 28 Tage vor dem geplanten Vorort-Termin                                                                                                                                          | 750,00 €     |
| Beschwerdeprüfung, Nachbesserung und Re-Zertifizierung je Arbeitstag (8 h)                                                                                                                | 5.000,00 €   |

erstellt/geändert:  IS-BT-DIFN FA

06/2024

freigegeben:

IS-BT-DIFN AR

07/2024

Seite 10 von 10

Datei: GÜ100\_BREEAM Neubau

Gebührenordnung.doc

Rev.-Stand:

06/2024

Gedruckte Exemplare unterliegen keinem Änderungsdienst!

Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->