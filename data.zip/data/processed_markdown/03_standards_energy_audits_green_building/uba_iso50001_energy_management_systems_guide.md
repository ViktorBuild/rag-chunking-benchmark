---
document_id: uba_iso50001_guide
title: "Energy Management Systems in Practice: ISO 50001 Implementation Guide"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "Umweltbundesamt (UBA) / BMU"
year: 2019
original_file: "uba_iso50001_energy_management_systems_guide.pdf"
tables_detected: 207
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

<!-- image -->

## Energy Management   Systems in Practice

ISO 50001: A Guide for Companies and Organisations

<!-- image -->

## Imprint

<!-- image -->

Publisher:

Federal Ministry for the Environment, Nature Conservation and Nuclear Safety (BMU) Division: ZG III 2 • 11055 Berlin, Germany Email: ZGIII2@bmu.bund.de • Internet: www.bmu.de

Federal Environment Agency (UBA) P.O. Box 1406 • 06844 Dessau-Rosslau, Germany E-Mail: info@umweltbundesamt.de • Internet: www.umweltbundesamt.de

Project support:

Annette Schmidt-Räntsch, Sahra Koep Division ZG III 2 Federal Ministry for the Environment, Nature Conservation and Nuclear Safety (BMU)

Reinhard Peglau Section I 1.4 Federal Environment Agency (UBA)

Authors:

Walter Kahlenborn, Sibylle Kabisch, Johanna Klein, Ina Richter, Silas Schürmann (adelphi research)

Design:

stoffers / steinicke • www.stoffers-steinicke.de

Photos:

Cover: BMU / Christoph Edelhoff

P. 4 BMU / Bernd Müller

P. 6 BMU / Thomas Härtrich

P. 9 BMU / Brigitte Hiss

P. 13 BMU / Brigitte Hiss

P. 40 BMU / Brigitte Hiss

P. 47 BMU / Brigitte Hiss

P. 51 BMU / Thomas Härtrich

P. 58 BMU / Bernd Müller

P. 68 BMU / Bernd Müller

P. 84 Thomas Imo / photothek.net

P. 104 BMU / Bernd Müller

As at:

June 2012

## TABLE OF CONTENTS

5

8

|                                                               | NAVIGATION                                                    | 7   |
|---------------------------------------------------------------|---------------------------------------------------------------|-----|
| 2                                                             | FOR WHOM IS THIS GUIDE MEANT?                                 |     |
| 3                                                             | ISO 50001: EMERGENCE OF AN INTERNATIONAL STANDARD             |     |
| 4                                                             | INTRODUCTION TO ENERGY MANAGEMENT SYSTEMS                     |     |
| 5                                                             | STEP-BY-STEP TOWARDS AN ENERGY MANAGEMENT SYSTEM              | 18  |
| A                                                             | PLAN                                                          | 24  |
| B                                                             | DO                                                            | 45  |
| C                                                             | CHECK & ACT                                                   | 60  |
| 6                                                             | CERTIFICATION, ASSESSMENT & EXTERNAL COMMUNICATION            | 67  |
| 7                                                             | BIBLIOGRAPHY                                                  | 70  |
| ANNEX A - ENERGY MANAGEMENT CHECKLIST                         | ANNEX A - ENERGY MANAGEMENT CHECKLIST                         | 73  |
| ANNEX B - COMPARATIVE TABLE ISO 50001:2011 AND ISO 14001:2009 | ANNEX B - COMPARATIVE TABLE ISO 50001:2011 AND ISO 14001:2009 | 85  |
| ANNEX C - COMPARATIVE TABLE ISO 50001:2011 AND EMAS III       | ANNEX C - COMPARATIVE TABLE ISO 50001:2011 AND EMAS III       | 105 |
| 8 LIST OF ABBREVIATIONS                                       | 8 LIST OF ABBREVIATIONS                                       | 112 |

<!-- image -->

## Introduction

By 2020, Germany aims to reduce its primary energy consumption by 20 per cent on 2008, and by 50 per cent by 2050.

It won't be possible to achieve this goal without a significant increase in energy efficiency.

Systematic energy management is an appropriate instrument for continually improving energy efficiency in companies and organisations. The cost reductions also help to strengthen the company's competitive edge on the market.

The ISO 50001 standard, which was published in June 2011 and replaces the European EN 16001 standard, defines the first international standards for an energy management system. The preceding European standard EN 16001 already contributed to significant energy savings in German companies.

These guidelines are an updated version of the EN 16001 guidelines previously published in five edi tions, newly adapted to ISO 50001. The guidelines are intended to support organisations of any type, size and sector in the implementation of an energy management system according to ISO 50001. It presents the content of the new standard and clearly highlights differences and similarities with the European environmental management system EMAS, as well as ISO 14001 which forms part of EMAS. The information shows that EMAS-certified companies often already meet all the requirements of an energy management system and that an energy management system also provides an excellent basis for the implementation of EMAS.

The authors and publishers would like to thank all those who helped to revise these proven guidelines. This updated version will hopefully also provide support for many companies and organisations and encourage them to introduce an energy management system.

<!-- image -->

## 1  NAVIGATION

For this guide, a navigation system has been developed to make it easier for you to find important information. The following navigation support is provided:

<!-- image -->

## Plan-Do-Check-Act:

This shows the stage of the Plan-Do-Check-Act cycle (Planning-Implementation-Monitoring-Action) that you are at.

<!-- image -->

## Practical examples:

Here, you will find practical examples from German and European companies who have already successfully introduced an energy management system, as well as useful tips for implementation.

To provide your organisation with information according to the awareness level and preconditions, the guide is divided into three levels:

## 1. Common part for ISO 50001:

This is the complete primary text of the guide, in particular Chapter 5. Use of ISO 14001  1  or EMAS  2  is not required. A checklist for the actual implementation status of your EnMS can be found in Annex A.

<!-- image -->

<!-- image -->

## 2. Comparison with ISO 14001:

This describes additional activities that need to be undertaken for introducing ISO 50001 if you have already implemented ISO 14001 in your organisation. A detailed overview can be found in Annex B.

## 3. Comparison with EMAS:

This describes additional activities that need to be undertaken for introducing ISO 50001 if you have already implemented EMAS in your organisation. The effort is once again reduced in comparison to ISO 14001. A detailed overview can be found in Annex C.

<!-- image -->

## Additional literature and links:

Here you will find literature tips and links to additional information.

- 1 ISO 14001:2004 and DIN EN ISO 14001:2005-06 respectively.
- 2 EMAS III - the requirements of ISO 50001 were adopted unaltered in the EMAS III regulation, which contains additional elements. For this reason, ISO 14001 (EMAS) will be referred to if there is a comparison between ISO 50001 and ISO 14001 or EMAS from now on. If the specific additional   value of EMAS needs to be mentioned, then this will be specifically highlighted.

## 2 FOR WHOM IS THIS GUIDE MEANT?

## A guide for all companies and organisations

ISO 50001 is a classical management system standard which is not specifically sector-oriented and can be adopted by different organisations, from small and medium-sized enterprises (SME) to the Federal Authority.  The standard lays down a framework within which 3 your individual involvement is required. The guide, as a   reflection of the standard, explains in simple terms how your company or organisation can develop a structured management system, regardless of the energy intensity of activities, size, branch et cetera This guide can thus, in principle, be adopted by organisations of any kind.

The guide is not only directed towards large companies / organisations  4 which have already introduced a management system or towards those which need to introduce an energy management system (EnMS) due to their energy intensity but also towards SMEs who want to first familiarise themselves with the subject.

guidelines in a targeted manner. At the same time, benefits are proposed for those companies which are already affected by the German Renewable Energy Sources Act (Erneuerbare Energien Gesetz, EEG) or for which the future development of the German Federal Government's integrated energy-climate programme is particularly relevant.

Chapter 5 provides a step-by-step guide to energy management which can be taken as a proposal and first input to introduce EnMS. Each individual step towards introducing an EnMS is explained in detail, and this helps to systematically approach the subject of energy management.

Special attention is paid to companies which are already ISO 14001 or EMAS - certified or those which use a similar management system. Even companies that claim energy tax exemption are subject to emissions trading or that are committed to the subject of sustainability and corporate social responsibility, respond to these

Since formal requirements in terms of functions and responsibilities naturally cover a wide spectrum, it is the task of the particular company to take what it needs from the diverse options for developing a management system, as described in ISO 50001,   according to individual requirements.

The guide follows a systematic and less technical approach. Where relevant, however, you will still find references to sector-specific technical support from nstitutions and other sector-specific guides. i

## Integration of EnMS according to ISO 50001 into other management systems in the company

ISO 50001 can be used by companies in all of the sectors and sizes. An EnMS that is based on ISO 50001 can be implemented irrespective of existing management systems or can be integrated into the ones   already in place.

ISO 50001 was designed in such a way that it can be combined with other management systems, primarily those   concerning quality and environmental management. As with DIN EN ISO 9001 or DIN EN ISO 14001 and EMAS, it is based on the Plan-Do-Check-Act cycle (PDCA). Accordingly, the various management systems can be easily consolidated or the company has the option of conforming to the existing management system with the aim of developing a management system in accordance with ISO 50001. 5

- 3 The guide looks at a wide spectrum of energy performance indicators (EnPI) for energy management; it does not focus on the energy management of buildings.
- 4 To maintain simplicity, from henceforth in the document, only companies will be referred to.
- 5 It may even be based on the already existing low-threshold environment management approaches. For more information, see BMU (2005).

<!-- image -->

## For integrating various management systems, see for example

<!-- image -->

- · Hessische Landesanstalt für Umwelt (1997): Leitfaden Integrierte Management systeme.
- · Bayerisches Staatsministerium für Wirtschaft, Infrastruktur, Verkehr und Technologie (2003): Integriertes Managementsystem.

An overview of various standards for management systems, as well as different management systems, can be found at: http://www.izu.bayern.de/download/pdf/managementsysteme\_2012.pdf

In Germany, over 50,000 companies and organisations have implemented the quality management standard DIN EN ISO 9001 and over 6,000 companies and organisations have implemented the requirements for environmental management according to DIN EN ISO 14001. In April 2012, 1,876 sites from 1,347 organisations were registered for EMAS. A large part of German industry is thus already familiar with the principles of ISO 50001 and an implementation of the standard is relatively easy. This has also been demonstrated by the organisations already certified under EN 16001 and ISO 50001. Worldwide, 462 organisations are certified under EN 16001 and 280 under ISO 50001 (according to the so-called 'Peglau Statistics', Status: 16.05.2012).

Besides the fact that implementation is easier for companies who have already put a management model into practice, it is also much more logical from the point of view of efficiency to integrate the requirements of various management systems instead of ntroducing them concurrently to one another. i

When integrating EnMS requirements into the already existing management systems, companies profit from a reduction in personnel, as well as in temporal and financial expenditure. The successful integration of EnMS requires a company's successful consolidation of responsibilities for energy, safety, quality and environmental protection. This is not self-evident as problems always occur when bringing together system accountabilities and, if required, inherent positions also need to be changed or even eliminated. According to the size of the company, it is a good idea for one person n-charge to be made accountable for all management i systems. Further clarity can be achieved if all the aspects are consolidated at a higher managerial level responsible for all management systems and corresponding department experts are made accountable for the individual technical aspects.

<!-- image -->

<!-- image -->

Since the requirements are derived from ISO 14001 (EMAS) to a standardised EnMS, Chapter 5 demonstrates the relationship between ISO 14001, EMAS and ISO 50001 respectively.

## Energy management systems in energy-intensive companies

The introduction of an EnMS is particularly important for energy-intensive companies. On the one hand, here lies the biggest potential for cost-saving, on the other, these companies are the ones who are, at present, profiting the most from the regulations of the German government. On 1 January 2012, an amendment to the Renewable Energy Sources Act (Erneuerbare-Energien-Gesetz EEG) came into effect. According to this, energy-intensive companies will profit under expanded terms from an equalisation scheme. The Federal Office of Economics and Export Control (Bundesamt für Wirtschaft und Ausfuhrkontrolle, BAFA) can partially subsidise the costs of energy-intensive companies from the manufacturing industry and railways in order to promote electricity produced from renewable energies. The companies who wish to apply for this from the Federal Office of Economics and Export Control (BAFA) must meet, among others, the following requirements:

- · The company must have drawn at least 1 gigawatt hour (GWh) of power in the last financial year from a utility company and have consumed it themselves.
- · The ratio of power costs and gross value added of the company should amount to more than 14 per cent.
- · Certification under EMAS or ISO 50001. This does not apply to companies with an energy consumption of less than 10 gigawatt hours. Certain transitional regulations apply to certification under ISO 14001 and DIN EN 16001.

## Additional literature regarding the equalisation scheme:

BAFA bulletins, e. g.:

II. A Merkblatt für Unternehmen des Produzierenden Gewerbes

II. A 1. UnterMerkblatt zur Zertifizierung des Energieverbrauchs und der Energieverbrauchsminderungspotentiale

(http://www.bafa.de/bafa/de/energie/besondere\_ausgleichsregelung\_eeg/merkblaetter/ index.html)

<!-- image -->

## 3 ISO 50001: EMERGENCE OF AN INTERNATIONAL STANDARD FOR ENERGY MANAGEMENT SYSTEMS

Systematic energy management is used worldwide in many companies. Good energy management identifies where the energy saving potential lies. Exploiting such a potential reduces administrative costs and increases one's own competitiveness. It was thus decided that a consensus needs to be found across sectors for the development of a standard which acts as a guide for effective energy management.

the standardisation of EnMS as an important step towards increasing energy efficiency in European industry, the EN 16001:2009 standard was published on 10 September 2009 under the leadership of Sweden.

In Europe, Denmark is considered a pioneer. By 2000, a common initiative of the Confederation of Danish Industries, the Danish Federation of Small and MediumSized Enterprises, the Danish Energy Agency, various scientific establishments, as well as other participants, drafted the first national standard. Many other European countries soon followed suit: in 2003, a Swedish standard was launched, followed by an Irish standard in 2005 and a Spanish one in 2007.

A high level of participation was required for the development of these standards as standards require the consent and consensus of all parties concerned. The response to the standards in certain countries ollowing their release was very high. f

The success of a national standard led to the formation of a working group of the European Committee for Standardization (CEN) in 2006 to address this topic. Supported by the European Commission, which sees

The European unification was followed, under American-Brazilian leadership, by work on an international consensus. In close cooperation with the countries of the European Union, and supported not least by the involvement of experts from the German mirror committee NA 172 00 09 AA 'Energy Efficiency and Energy Management', the Technical Committee (TC) ISO/TC 242 'Energy Management' of the International Organization for Standardization (ISO) prepared the ISO 50001 standard on the basis of EN ISO 16001:2009. The new internationally valid standard was published on 15 June 2011.

After a transitional period extending until 24 April 2013, certifications under the European standard will become invalid. Even before the official release of the new international energy management standard, the first companies conforming to ISO 50001:2011 were certified. In Germany, the first companies certified to the international standard were Kappelhoff Industrietechnik GmbH in Bottrop and the headquarters and main spare parts warehouse of Porsche AG in Stuttgart-Zuffenhausen and in Stuttgart near Sachsenheim.

<!-- image -->

## 4 INTRODUCTION TO ENERGY MANAGEMENT SYSTEMS

## Management systems

All organisations - whether big or small, complex or simple, profit or non-profit making - have a management system. This can be formal or informal: all systematic internal regulations for responsibilities and procedures in a company are considered a management system.

A management system should ensure that all significant objectives of the company are implemented in a systematic manner and can be assessed at every phase. Management systems which are used appropriately contribute towards the improvement of the operational and organisational structure of a company, in accordance with the requirements of the market, customers, investors, society and the country. Organisational measures like establishing responsibilities, authorities, operational procedures and monitoring systems form the basis of this system. By determining accountability in action plans (who does what, until when?) and assessing the system objectively either by internal employees or, if necessary, by external auditors, it can be monitored whether the objectives are being achieved in time or, if documented, who or what is responsible for any deviation.

8800 or the Occupational Health and Safety Assessment Series (OHSAS) 18001 as a management system for occupational safety, the Hazard Analysis and Critical Control Points-concept (HACCP) for hygiene management, EMAS and ISO 14001 for environmental management, as well as 9100 A and 9100 B for the American Petroleum Institute for Occupational Safety, Environmental Protection and Plant Safety.

The ISO 9000 et. seqq standard series is mainly a standard for Quality Management Systems (QMS). It is likewise possible to integrate an Environmental Management System (EMS) or security management system into a QMS. The ISO 14001 standard primarily concentrates on developing and upgrading a functioning EMS within an organisation. It is thus assumed that an active EMS improves the environmentally friendly character of a company. In various areas, EMAS goes much further than ISO 14001. In EMAS, the environmental management system functions to ensure, by means of organisational measures, that the environmental performance is always fully optimised.

The first standardised approaches for management systems were developed in the 1970s from Quality Management (QM). The first international standards for QM, the standard series ISO 9000 et. seqq, was then published in the 1980s. From the early 1990s onwards, more guidelines were introduced for specialised management systems, for example the British Standard BS

The standards for management systems should not be observed in isolation: The structure of the environment management standard ISO 14000 et. seqq complies with the structure of the quality management standard ISO 9000 et seqq. ISO 14001 served as the   basis for EMAS and is a part of it. The structure of the ISO 50001:2011 international energy management standard is heavily based on the ISO 14001:2009 standard.

<!-- image -->

## Energy management and energy management systems

Energy management includes all the measures that are planned and implemented to ensure minimum energy consumption for the current activity. 6

The energy management influences organisational and technical procedures, as well as behaviour patterns, in order to reduce the total operational energy consumption (thus also the energy required for the production), to use basic and additional materials economically and to continuously improve the energy efficiency in the company.

An EnMS encompasses all elements of an organisation that are necessary for creating an energy policy, and defining and achieving strategic objectives. It thus includes the organisational and informational structures required for implementing energy management, including resources. It formulates and implements the energy policy (including the strategic and operational objectives and the action plan), planning, introduction and operation, monitoring and measurement, control and correction, internal audits 7 , as well as a regular management review. 8

An Energy Management System (EnMS) systematically records the energy flux and serves as a basis mainly for investments in improving energy efficiency. A functioning EnMS helps a company to comply with the commitments made in its energy policy and to continuously and systematically improve its energy performance.

DIN EN 16001 specifies in form the requirements for an EnMS. It is thus structured towards the ISO 14001 (EMAS) environment management standard.

## Literature tip

<!-- image -->

The guide, as a reflection of the standard, does not concern itself with other alternatives, such as how energy management can be operated outside the standard. It does not address technical measures either. A guide from the German Energy Agency (Deutschen Energie-Agentur Dena) is thus recommended as it illustrates a gamut of organisational and technical measures.

Grahl, Andrea/Zoch, Immo/Streibel, Martin/Joest, Steffen 2009: Handbuch für betrieb  liches Energiemanagement. Systematisch Energiekosten senken. Pub. Deutsche   Energie-Agentur GmbH (dena), Berlin.

6 See, dena 2009b.

7 Internal audits should generally be conducted according to 'ISO 19011 - Audits for Quality Management and / or Environment Management Systems' standard.

8 For the purpose of ISO 9001 and ISO 14001 standards.

## R THE MOST IMPORTANT ASPECTS OF AN ENMS

<!-- image -->

<!-- image -->

<!-- image -->

For readers in a hurry, this guide provides an overview of the differences between ISO 14001 and ISO 50001, as well as between EMAS and ISO 50001. ISO 50001 is essentially oriented towards ISO 14001. At the end of every paragraph in Chapter 5, companies who have already implemented ISO 14001 will find an overview of relevant steps, which need to be additionally fulfilled to introduce ISO 50001. In Annex B, you will find a tabular overview.

As ISO 14001 is an important component of the EMAS regulation, the companies with an EMAS have the advantage of already fulfilling more aspects of ISO 50001 when compared with the companies certified according to ISO 14001. The few additional requirements that an EMAS registered company needs to additionally fulfil for ISO 50001 can be found in Chapter 5. A tabular overview can be found in Annex C.

## Advantages of an energy management system

The introduction of an EnMS essentially requires the systematisation of energy-saving methods. In the longterm, this results in measurable energy savings and cost-related improvements, as well as efficiency in processes. At the macro-level, it vastly contributes to improving the environmental situation. There are various advantages to introducing an EnMS. The main reasons are discussed below:

## 1. Cost reduction

Increasing energy costs reduce the overall profit - in almost every company, there is potential to reduce energy consumption. By introducing an EnMS, you can save up to 10 per cent of your energy costs in the initial years after implementation by systematically identifying the weak points in your energy consumption and addressing them with basic measures. Also, the investment in energy-efficient technologies is worthwhile: investments in compressed air systems and pump   systems, as well as in ventilation systems, refrigeration and materials handling technology, will see a 5 - 50 per cent reduction in power consumption 9 in an average payback time of less than two years.

## 2. Environmental protection

Climate change is already one of the main causes of natural catastrophes like floods and droughts. And even today, the consequences for humans and the environment are considerable. However, the aftermath of a more rampant increase in temperature is greater, for example flooding of coastal regions and low-lying island nations, increasing desert areas, melting of glaciers, et cetera. While climate change is taking place worldwide, climate protection must occur locally. Only when all households and companies are working together, the undesirable risks of climate change can be mitigated. An efficient energy management is therefore an important element as it can contribute considerably to reducing greenhouse gas emissions.

## 3. Sustainable management

Resource efficiency in all areas, and particularly with respect to energy, is a much discussed topic of our times. The reserves of fossil fuels are limited. Those who continue to rely on these resources are not preparing themselves for the future. Efficient energy management, new energy concepts and innovative energy technologies are key to operating successfully in the market in the coming years and decades.

## 4. Improvement of public image

With an ISO 50001:2011 certification, you can credibly show to the public that your company is operating sensibly with respect to energy-efficiency and thus protects the environment. Environmental requirements are increasingly an important factor in public proposals, including, among others, climate-friendly purchasing. Both from the perspective of the procurer and the supplier, an EnMS supports the measurement of CO -emissions. 2

## 5. Use of financial incentives

Since January 2009, energy management is a prerequisite for energy-intensive companies to be exempted from the Renewable Energy Sources Act (EEG) fee. For companies with an energy consumption over 10 gigawatt hours (GWh) per year and energy costs amounting to more than 14 per cent of the gross value added, certification according to ISO 50001 or alternatively to EMAS is required. 10

## 6. Projection of climate policies

- · Due to the large savings potential, energy management is of high importance in achieving the climate goals of the German government. This is clearly underlined in the Federal Government's energy concept. It provides that starting in 2013, tax benefits such as the peak equalisation within the energy and electricity tax will only be granted if the companies make a contribution to energy savings.

9 Compare, Austrian Energy Agency (www.energymanagement.at).

10 Compare, Federal Office of Economic and Export Control (BAFA), 2012 (http://www.bafa.de/bafa/de/energie/besondere\_ausgleichsregelung\_eeg/ merkblaetter/merkblatt\_iii.pdf).

## R PRACTICAL EXAMPLES ON ENERGY CONSERVATION IN COMPANIES FROM DIFFERENT SECTORS:

| Measures                                                         | Sectors                                                       | Investment in Euro               | Cost reduction in Euro per year   | Payback time (statistic)   | Savings in Mwh and tons of CO 2                              |
|------------------------------------------------------------------|---------------------------------------------------------------|----------------------------------|-----------------------------------|----------------------------|--------------------------------------------------------------|
| Installation of heat exchanging device at different locations    | Construction material industry/ Brick production (Schlagmann) | 925.000                          | around 450.000                    | around 2 years             | 3.225t CO 2                                                  |
| Checking the lighting situation in the furniture hall buildings  | Mail order selling (Baur)                                     | 0                                | 5.500                             | 0                          | 48 MWh and 30t CO 2                                          |
| New circulation pumps in swimming pools                          | Hospitality industry (Hotel St. Georg, Bad Aibling)           | 4.000                            | 3.200                             | 1,25 years                 | 20 MWh and 11 t CO 2                                         |
| Developing a new energy- saving synthetic paint finishing system | Car component industry (sector classification code)           | 133.000 (additional expenditure) | 255.000                           | 0,52 years                 | 219 MWh electrical 4080 MWh thermal 120t CO 2 + 1.224 t CO 2 |
| Optimising compressed air systems                                | Food industry (Brauerei Haus Cramer KG)                       | 62.500                           | 55.000                            | 1,1 years                  | 775 MWh 300t CO 2                                            |

Own illustration based on Infozentrum UmweltWirtschaft Bavaria (2009).

## 5 STEP-BY-STEP GUIDE TOWARDS AN ENERGY MANAGEMENT SYSTEM

## The PDCA cycle

Energy management according to ISO 50001 follows the PDCA (Plan, Do, Check, Act) cycle of other well known management systems like ISO 14001 and ISO 9001. If you have already introduced a management system into your company, then you can easily integrate energy management into the present structures.

The PDCA cycle provides a framework for the continuous improvement of processes or systems. It is a dynamic model - the results of one cycle form the basis for the next one. This structure enables you to continuously reassess and optimise the current energy consumption and to gradually reduce costs.

<!-- image -->

The individual steps of the PDCA cycle in energy management can be described as follows:

## 1. Plan

## 4. Act

Establishing energy-saving targets, determining the strategy, identifying measures and responsibilities, providing the necessary resources, preparing the action plan.

## 2. Do

Establishing management structures for maintaining a continuous process, undertaking improvement measures (for example efficient technologies/procedures).

## 3. Check

Reviewing the level of target achievement and the effectiveness of the EnMS, collecting new ideas via energy audits, if necessary, consulting an external expert.

Strategic optimisation by consolidating the current energy data, audit results and new information, evaluating the progress with the help of current energy market data, deriving new objectives.

Activities can take place in parallel; even the decision on which to begin an activity depends on the conditions in the respective company.

When compared to selective measures (ad-hoc energy management), continuous application of this process clearly reduces the energy-related costs of a company.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The management of energy use and consumption is an essential part of environmental management. ISO 14001 is based on the Plan-Do-Check-Act cycle and the process of continuous improvement, as well as the formal and structural requirements already present in the existing ISO 14001 in your company.

As an EMAS-company, you have the Plan-Do-Check-Act cycle, the process of   continuous improvement, as well as all formal and structural requirements, already firmly rooted in your company.

## Practical example (adapted):

A medium-sized company called 'Altpapieraufbereitung Oswald' decided to introduce an EnMS for tax-related purposes. To implement the EnMS, a continuous, objectively assessable improvement process should be present in the structures of the company.

The Head of the company initiated the process by including the objective of energy efficient management in the company philosophy, appointed an Energy Manager and provided him with the corresponding resources and responsibilities (Plan). The manager coordinates the documentation of all energy-related processes in the company.

The company 'Altpapieraufbereitung Oswald' has already taken other approaches for an environmental management system. However, it is not applied in a systemic manner because only certain processes in the company are controlled and directed by the system. To reflect the continuous improvement process, a structure is established for the introduction of an energy management which will make it possible to record and assess all energy flows and conduct improvement measures (Do).

The results of the measures are regularly assessed by the Energy Manager, new targets are set and the resultant reports are compiled (Check).

The newly defined targets and measures are implemented by the Energy Manager with the support of employees and an external energy advisor (Act).

## Determine responsibilities of the top management

For the long-term success of an EnMS, the motivation of the employees and the commitment shown for an EnMS are of major importance.

This includes all levels and functions of an organisation and begins at the highest management level of a company, the top management.

- · To appoint a management representative ('Energy Manager') with established responsibilities and powers for implementing an EnMS. This person should also be responsible for submitting the report on performance and the results of the system to the top management.

According to ISO 50001, the responsibilities of top management within the framework of an EnMS include above all:

- · To define and continually maintain an energy policy for the organisation.
- · To decide on further strategic energy management measures on the basis of documented results regarding the subject of energy in the internal audits.
- · To review the EnMS of the organisation at regular intervals to test it for results. This review should be recorded and maintained as part of management reviews.
- · To ensure the availability of required resources for introducing, attaining, maintaining, and improving the EnMS (personnel, special capacities, technical and financial resources).
- · To communicate the importance of the EnMS within the organisation.

## R A FEW REASONS WHY MANAGEMENT DOESN'T INTRODUCE AN ENMS

- · No one is responsible for energy matters
- · Energy costs are seen as fixed costs
- · Sub-systems within changing company structures are not transcendental
- · Employees regard 'their processes' as optimised and greet further analysis with scepticism

<!-- image -->

Clear responsibility of the top management is an important characteristic of ISO 50001. If you have already implemented ISO 14001 and your top management is familiar with energy-related problems, then the introduction of ISO 50001 should pose no additional costs for your top management.

Ensure that in the internal communication of the EnMS and the definition of objectives and energy indicators, the involvement of top management and the resulting obligations are guaranteed. Also ensure that the company's long-term planning takes energy performance into account.

EMAS requirements are in accordance with ISO 14001.

## Tip

By transferring the Energy Manager to the upper-most management level of the company, you are setting the best example for a successful implementation. For example, the Plant Manager can simultaneously lead the energy management team in the company.

<!-- image -->

<!-- image -->

## Define your energy policy

According to ISO 50001, the starting point for a functioning EnMS is the formulation of an energy   policy for your company. The energy policy that needs to be documented in hard copy is a statement in which your top management outlines the objectives of effective energy management. The document is the first step in a structured energy management process.

The energy policy sets out energy-related guidelines, operating principles and long-term overall objectives for your company. It is used, over time, as a measurement for the effectiveness of energy management.

According to ISO 50001, the statement expressing the energy policy of a company must contain the following points:

- · The commitment of top management to continuously increase the energy efficiency of your company, as well as to carefully handle energy, should be expressed.
- · It should state the obligation of your management to provide information and resources required for realising energy objectives and targets.
- · It should include the obligation to adhere to all legal obligations that affect the energy aspects of your company.
- · It should support the purchase of energy-efficient products and services.

<!-- image -->

## Comment

According to ISO 50001, it is not mandatory that the energy policy be made publicly accessible. However, it is advisable as it helps to portray a positive profile of your company. Additional information on this is available in Chapter 6 of this guide.

After developing and introducing your energy policy, it should be communicated to all people working directly or indirectly for the company. Your energy policy should also be regularly assessed and, if required, adapted to changing circumstances.

If there are already other policies in your company, like an environment or quality policy, then you can ntegrate your energy policy into this document. If i your company is working in several locations, then your energy policy can refer to either all activities or only the ones of specific locations. Pay attention to defining system boundaries in such a way that your objectives can be implemented within these.

While formulating your energy policy, ensure that it can be easily understood inside and outside of the company.

## R EXAMPLE OF AN ENERGY POLICY *

## Our Energy Policy

We, the company Samplename GmbH, hereby commit ourselves to the long-term reduction of our energy consumption and to the improvement of our energy efficiency in a continuous improvement process. To fulfill these objectives, we are implementing an energy management system according to the ISO 50001:2011 standard. We thereby ensure that all the requirements of this standard are correctly implemented and that there is a continuous improvement of all processes within this energy management system.

In addition, we will regularly review that

- · the required financial and structural preconditions are met;
- · all  employees are integrated into the implementation and operation of the energy management system and responsibilities are established;
- · relevant legal obligations and other requirements are taken into consideration;
- · a regular evaluation of energy efficiency, energy use and energy consumption takes place;
- · programmes promoting energy-efficiency are correctly introduced and conducted;
- · energy-efficient products and services are purchased that contribute to the improvement of energy performance;
- · the results are measured and evaluated by means of a  regular audit;
- · et cetera.
- * A few more points can be added to this rough example of an energy policy.

Date:

Place:

Name:

Position:

<!-- image -->

## Literature tip

Take inspiration from guides for other management systems when formulating your energy policy, e. g.:

- · Lackner, Petra / Holanek, Nicole (2007): BESS-Handbook
- · Engel, Heinz Werner (2009): EMAS 'easy' for Small and Medium Enterprises

The energy policy can easily be integrated into the environmental policy in accordance with ISO 14001. In order to meet the requirements of ISO 50001, the following aspects should be tak en into consideration:

- · Include an article in your energy policy that alludes to improved energy use, as well as im provement in energy efficiency.
- · Include a paragraph on ensuring the availability of information, as well as all the resources that are necessary for attaining the objectives.
- · Include a paragraph on regular reviews and updating of the EnMS.
- · Add information in support of the procurement of energy-efficient products and services.

For formulating an energy policy, EMAS-companies must add the term energy efficiency to their environmental policy and, where missing, include a paragraph on ensuring the availability of information, as well as all resources that are necessary for achieving the objectives.

<!-- image -->

<!-- image -->

<!-- image -->

When introducing an EnMS, all relevant areas of energy consumption in your organisation should be reviewed and illustrated in a specific structure that was defined by the organisation. From the clear and understandable illustration of the consolidated data, the sav- ings potential can be determined. This helps in defining short- and medium-term objectives. Additionally, the information gathered can be used for certification of the EnMS, as well as in communicating results inside and outside the company.

## Energy consumption - Energy conversion

In a physical sense, energy cannot be consumed; despite this, the following colloquial term of energy consumption is used instead of energy use or energy conversion.

## The following steps should be followed during the planning stages:

- 1. Identifying responsibilities
- 2. Including legal obligations
- 3. Reviewing the consumption, costs and production figures of energy
- 4. Processing and documenting the collected data
- 5.  Defining energy objectives and targets
- 6.  Formulating an energy management programme and an action plan

<!-- image -->

## 1. Identify responsibilities and form an energy-efficient team

## The Energy Manager

As a first step in the planning process, a management representative (Energy Manager) is appointed by the top management in your company for the implementation of the EnMS. He/she is the key person and responsible (if not solely) for compliance with the requirements of ISO 50001. His/her tasks and authority should be documented and communicated to the other employees. To be able to carry out his/her tasks, he/ she needs sufficient skills, motivation, the necessary competence and the full support of the top management. The Energy Manager is inter alia responsible for defining criteria and methods to ensure that the EnMS and monitoring thereof function effectively.

## The energy efficiency team

The first task of the Energy Manager is to put together an energy efficiency team and coordinate it. As energy efficiency affects almost all areas of your company, it is important that the Energy Manager works together with the officers in-charge of all relevant departments. During selection procedures, technical knowledge and motivation play a decisive role. For success, motivation is more important than technical knowledge as such knowledge, if required, can always be obtained by an external adviser.

Most medium and large companies have a 'quality and environment' department (that usually is responsible for implementing ISO 9001 und ISO 14001). This department should be integrated into the process as it is already working with the existing management systems in the company.

Furthermore, the employees that have an indirect, yet important, influence on the energy consumption (e. g. developers, trainers) are an asset for the energy efficiency team.

Another effective option is to consult external advisors at the time of introducing the EnMS. Due to their experience and an independent point of view on the procedures of the company, these experts are in a position to support and motivate the team in various areas. External funding can be requested under certain circumstances for the employment of external advisors.

In large enterprises, it makes particular sense to further train a few members for this role. This holds true particularly for departments whose personnel are not trained technically but make an important contribution towards energy consumption.

## R EXAMPLE OF AN INTERNAL JOB DESCRIPTION FOR AN ENERGY MANAGER

## Tasks

## Qualities

- · Setting up and leading the energy team in the company
- · Planning and implementing the projects (according to budget, time and quality)
- · Acquisition, processing and communication of energy-related information
- · Delegating tasks and setting time limits
- · Supporting the involvement and recognition of the top management
- · Attaining staff support beyond individual areas and functions
- · Regularly reporting to the top management on energy performance and the performance of the EnMS
- · Good knowledge of the operating procedures
- · Excellent capabilities in project management, in organisation and communication
- · Sound knowledge of ISO 50001
- · Basic technical understanding
- · Trust and respect of co-workers
- · Involvement and enthusiasm for the subject of energy management
- · Ability to listen to others who, in some cases, have a different opinion and other ideas

The Energy Manager shares responsibilities and tasks with the members of the team. Regular meetings should take place for coordination. The frequency of the meeting is based on demand; it must, however, take place once every quarter. The top management should be included at least once a year.

## The task of an energy efficiency team lies essentially in implementing and maintaining the EnMS. This includes:

- · Developing an effective organisational structure to integrate the EnMS into the operational organisation
- · Developing an energy management programme using a comprehensive data assessment and evaluation, as well as the development and implementation of measures to increase energy efficiency
- · Purchase and selling of energy
- · Consultation at the time of purchasing energy-related products, equipment and services
- · Contact point for employees and the public for enquiries relating to energy
- · Establishing and maintaining an energy information system for internal communication

<!-- image -->

It is recommended that the scope of application and the position of each person involved is recorded in hard copy.

## R EXAMPLARY POSITIONS AND RESPONSIBILITIES

| Position                               | Person-in-Charge incl. phone, e-mail                              | Description of tasks and authoring                                                                                                                      |
|----------------------------------------|-------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|
| Energy Manager                         | Uta Schmitz                                                       | Coordinating the energy efficiency team and officers in-charge of the EnMS, external contact person, training                                           |
| Contact person from company management | Hans Kloß                                                         | Facilitator between management interests and those interested in the implementation of EnMS                                                             |
| In-charge for the departments          | Development - Annemarie Hausmeier Production - Dr. Ulf Haueisen … | Supporting and communicating tasks between the team and the departments, contact person for the employees Assigning tasks like measuring or documenting |
| In-charge within the departments       | Production - Klaus Bender; Ella von Berghausen …                  | Responsible for data collection and documentation for electrical energy Responsible for data collection and documentation for heating and cooling       |
| External Advisors                      | Engineering company Wagenpfahl                                    | Supporting introduction and implementation of the EnMS, training                                                                                        |

In order for the energy efficiency team to be able to mplement measures, it will need its own budget and i should be able to utilize a fixed part of the savings for further activities.

Select employees with energy competence from the individual operation areas for the energy efficiency team. The individual employee can carry out his / her role in the energy efficiency team in addition to his / her normal duties. However, do remember that during the introductory phase of an EnMS significantly more time is required for the initial data collection.

<!-- image -->

## Tip

After the initial euphoria, it can happen that your employees find it difficult to continuously prioritise the EnMS. It is therefore important that the subject of EnMS is continuously emphasised by the Energy Manager and top management over the long term.

## 2. Include legal obligations

While implementing ISO 50001, all currently applicable and relevant laws, regulations and ordinances should be adhered to. This applies in particular to laws relating to energy consumption, energy use and energy efficiency. Particularly the following:

- · Energy Saving Regulation (EnEV)
- · Renewable Energy Sources Act (EEG)
- · Act on Energy Services and Energy Efficiency Measures(EDL-G)
- · Energy Saving Act (EnEG)
- · Federal Immission Control Act (BimSchV)
- · Energy-using Products Act (EuPA)
- · Best Available Techniques (BAT) - Energy Efficiency Information Leaflet  11

Also to be taken into account are other environmental laws, as well as the Operational Safety and Protective Labour Legislation. 12

## R SUPPORT PROGRAMMES - EXAMPLES

- · Energy efficiency advice for SMEs (KfW Bank Group)
- · Various support programmes of the Jülich research centre
- · Supporting emission-free heavy-duty commercial vehicles (KfW Bank Group)
- · KfW Bank Group - environment programme
- · Supporting measures for commercial refrigerating plants (BAFA)
- 11 Compare, Best Available Techniques (BAT) at http://www.bvt.umweltbundesamt.de/sevilla/kurzue.htm
- 12 Compare, e. g. www.gesetze-im-internet.de or www.umwelt-online.de, as well as (especially for EMAS) 'EMAS in Rechts- und   Verwaltungsvorschriften (as at: August 2011)' from the office of the German EMAS Advisory Board.

Make sure to also take into account other requirements to which your company has committed itself with regards to energy use, consumption and efficiency.

Companies maintain a register of legal obligations so that specific provisions are not forgotten. This contains all relevant laws and regulations which are necessary for operations. For smaller businesses a summary table is often sufficient, while a database is recommended for larger businesses. The individual legal provisions within this register are updated, as are the measures which must be undertaken for their compliance. A documentation of the process for identifying and implementing legal provisions in the company is important for the final certification.

The German Federal government clearly formulated its policy objectives with regard to a significant increase in energy efficiency in the Act on Energy Services and Energy Efficiency Measures (EDL-G) and the national Energy Efficiency Action Plan (EEAP). In order to achieve these goals, the government is also offering numerous funding programmes for medium-sized enterprises.

<!-- image -->

<!-- image -->

## Tip

Funding programmes are presented by the EnergyAgency.NRW at: http://www.energieagentur.nrw.de/foerderung/page.asp?RubrikID=2533

A brief overview is also provided by the German Energy Agency (dena): http://www.thema-energie.de/energie-im-ueberblick/foerderung-finanzierung/ foerderprogramme.html

KfW provides information for medium-sized companies at: http://www.kfw.de/kfw/de/Inlandsfoerderung/Foerderberater/Unternehmen\_erweit-ern\_und\_festigen/Qualifizierte\_Beratung/Energieeffizienzberatung/index.jsp

With an existing ISO 14001, ensure that you are complying with all relevant laws and legal obligations for the introduction of ISO 50001. Review once again if you are actually in compliance with all the energy-related laws and other commitments made by your organisation.

<!-- image -->

As an EMAS company, you are on the safe side here. You not only comply with all the relevant laws and legal obligations but have proven that already. Nonetheless, review once again if you have actually integrated all the energy-relevant laws in your EMAS and whether you are in compliance with all other requirements to which your company has committed itself with regards to energy use, consumption and efficiency.

## 3. Review consumption, costs and production of energy

You can't manage what you don't measure!

the staff members with a significant influence on the energy use of the organisation should also be known.

A systematic review and analysis of energy consumption forms the basis for an increase in energy efficiency. The higher the consumption the more detailed the measurement should be and, consequently, the easier it is to ascertain the savings potential.

These measurements are restricted by measurement costs, which should naturally not exceed the benefits. If you have localised big consumers, you can tighten the system boundaries of the analysis in order to obtain detailed information.

In addition to consumption data, there are other relevant factors which should be included in order for a comprehensive assessment of data to be possible. In order to maintain clarity, it makes sense to take into account the entire company, as well as individual areas (for example equipment, sites, facilities), systems and processes. However, system boundaries and operational conditions should always be determined. In addition,

## These can be, for example:

- · Measurement interval (time, duration) and measurement accuracy
- · Production stages, type of product, locations or even areas of building equipment and appliances (lighting, ventilation et cetera)

You should be able to explain irregularities. It is therefore recommended that you record data for production figures, turnover and breakdowns alongside energy consumption and use. During the review, age and visible defects of equipment and resources should also be identified.

In order to determine the savings potential and to identify changes, the complete energy flow of the company should be recorded and documented.

## R ENERGY FLOW WITHIN THE COMPANY

- ·   Electricity
- ·   Production sites
- ·   gas
- ·   heat
- ·   own sources
- ·   …
- ·   halls
- ·   machines
- ·   heating/ventilation
- ·   offices
- ·   lighting
- ·   process heat  /  process cooling
- ·   controls
- ·   transportation
- ·   …

Documentation should be easy to maintain and follow. Therefore, it is recommended that duration and areas of assessment, as well as type of data sources, are recorded. Error estimation and system boundaries also play a part here.

## To be able to achieve this, you require at least the following figures:

- · Type, quantity and costs of energy sources

## R INPUTS

| Measurement duration   | Measurement duration   | Area   | Energy source   | Quan- tity   | Consump- tion   | Costs   | Data sources          | Measu- rement errors   |
|------------------------|------------------------|--------|-----------------|--------------|-----------------|---------|-----------------------|------------------------|
| from                   | to                     |        |                 |              | MWh             | Euro    |                       |                        |
| 01.01.2012             | 31.12.2012             | Hall 2 | Electricity     |              |                 |         | Invoice Meter reading | 15.02.12 05.01.12      |
| 01.01.2012             | 31.12.2012             | Hall 2 | Gas             |              |                 |         | Invoice               | 15.02.12               |

- ·   Feed-in EEG
- ·   sale of district heat
- ·   sale of other energy carriers
- ·   production figures
- ·   turnover
- ·   …

- · Share of energy and cost of individual consumers in total consumption, the energy sources or the costs (areas, machines, production areas, departments, storeys, …)

## R CONSUMPTION

| Measurement duration   | Measurement duration   | Area            | Energy source   | Quan- tity   | Consump- tion   | Costs   | Data sources                     | Measu- rement errors   |
|------------------------|------------------------|-----------------|-----------------|--------------|-----------------|---------|----------------------------------|------------------------|
| from                   | to                     |                 |                 |              | MWh             | Euro    |                                  |                        |
| 01.10.2012             | 01.11.2012             | Drainage area   | Electricity     |              |                 |         | Electricity meter                |                        |
| 01.10.2012             | 01.11.2012             |                 | Oil             |              |                 |         | Estimation on tank filling level | 20 %                   |
| 03.01.2012             | 31.06.2012             | Office building | Electricity     |              |                 |         | Electricity meter                |                        |
| 01.07.2012             | 23.12.2012             | Office building | Electricity     |              |                 |         | Electricity meter                |                        |

- · Possible time differentiation (production step-, level-, daily-, weekly and yearly load profiles)
- · Data on production (quantity, turnover …)

## R PRODUCTION FIGURES

| Measurement duration   | Measurement duration   | Area   | Product   | Quantity   | Turnover   | Data source   |
|------------------------|------------------------|--------|-----------|------------|------------|---------------|
| from                   | to                     |        |           | Unit       | Euro       |               |

- · Apart from that, information on waste heat temperature levels, charges on district heating, supply of electricity from Combined Heat and Power (CHP)  13  or regenerative sources et cetera.

## R OUTPUTS

| Measurement duration   | Measurement duration   | Area            | Energy source                                      | Quantity       | Consumption                               | Revenue   | Data Sources           | Measu- rement errors   |
|------------------------|------------------------|-----------------|----------------------------------------------------|----------------|-------------------------------------------|-----------|------------------------|------------------------|
| from                   | to                     |                 |                                                    |                |                                           | Euro      |                        |                        |
|                        |                        | Produc- tion    | Waste heat 120°C                                   | Not known      | None                                      | None      | In-charge Area Manager |                        |
| 01.01.2012             | 31.12.2012             | Produc- tion    | Waste wood for producing pellets or wood briquette | 200 t, 0,8 MWh | Sales                                     | 20.000    | Administration         |                        |
| 01.01.2012             | 31.12.2012             | Office building | Electricity from photovoltaic                      | 13,2 MWh       | Supply acc. to the Renewable Energies Act | 6.336     | Administration         |                        |

You can use various sources for recording, such as energy bills, meter readings, energy reports from building management or information from administration.

The electricity supplier can normally provide a 15-minute load profile on demand. This can help you maintain the time series.

If you have little or no data for a separate illustration, you can make assumptions with the help of type / name tags, measuring devices, through operational hours, tank level, et cetera. However, extreme caution should be exercised here as error estimation must be traceable.

Above all, for big consumers you should consider nstalling more measurement devices. i

If there are no, or only a small number of specialists in your company who can take on these tasks, consult external consultants or provide your personnel with advanced training.

13 Combined Heat and Power (CHP) refers to generating power and heat from one fuel source during a single process.

<!-- image -->

## An overview of energy management software available on the market can be found at:

http://www.energieagentur.nrw.de/tools/emsmarktspiegel/default.asp?site=ea&amp;id=40082 3124042012http://www.perpendo.de/files/tga-1-2005.pdf

A software solution funded by the German Federal Ministry of Environment for implementing ISO 50001 can be found at:

www.modeem.de

The illustration depicted below is only a representative structure for recording data with the help of software. If you already have a computerised infrastructure for regulating and monitoring the plant technology, then it is worthwhile searching for relevant IT-supported solutions.

<!-- image -->

## 4. Process and evaluate all data

Documentation plays a central role in an EnMS. Therefore, during the introduction of documentation it is very important that a clear and traceable structure is developed from the beginning on. The objective of this step is the clear depiction of the energy flow and its documentation over a long period of time. The prepared data form the basis for the action plans and energy targets.

Therefore, attention should be paid to recording all data as described above (system boundaries) and that they are up to date, complete, easy to maintain, as well as accessible to those responsible.

Review of the data through illustration and generation of comparative key indicators has been proven of value.

When introducing an EnMS into your company, various key indicators (energy performance indicators EnPI) 14 must be generated which are representative of what you hope to achieve with your energy policy. Examples can be found in the table given overleaf. While determining these values, it is important to always establish system boundaries and operational conditions in order to avoid misrepresentation. Establish a reference period (energy baseline) in order to assess future changes with regard to energy consumption and use. This is a prominent requirement in the ISO 50001 standard. Use the results of your company's initial energy assessment when defining the reference period, and make sure to choose a reasonable period of time.

## Tip

<!-- image -->

In the EMAS internet portal (www.emas.de) under the heading Participation / Environmental Statement, you will find numerous examples of energy performance indicator indexes from the different branches as a first benchmark. 15  A few examples from this are depicted in the following table.

However, it is important that each company determines its own individual targets and measures its own progress.

Key data indicators for industry-specific unions and syndicates, which provide the ndividual branches with customised material, can serve as comparative values. i

| Industry           | Company                                                                             | Energy Performance/Consumption Index   |
|--------------------|-------------------------------------------------------------------------------------|----------------------------------------|
| Transport industry | Flughafen Friedrichshafen GmbH (2010)                                               | 5,4 kWh electricity/passenger          |
| Mining industry    | CEMEX GmbH Betriebsgemeinschaft Ost und West Zemen (2011)                           | 3555 kJ heat/t clinker                 |
| Health sector      | LVR-Klinikum Düsseldorf - Kliniken der Heinrich-Heine-Universität Düsseldorf (2011) | 6,86 kWh electricity/day of care       |

- 14 Energy performance indicators (EnPI) are quantitative, i.e. measurable values of energy performance, which were previously defined by the organisation.
- 15 Appendix IV to EMAS III also contains statements on key figures of companies (including energy efficiency).

## R OPERATIONAL ENVIRONMENT PERFORMANCE INDICATORS

| Key Data                                       | Description                                                             | Unit               |
|------------------------------------------------|-------------------------------------------------------------------------|--------------------|
| Total energy consumption                       | Absolute                                                                | kWh, MWh, Euro     |
| Specific energy consumption*                   | Total energy consumption [kWh] Production quantity/Units                | kWh / PQ, kWh / PU |
| Percentage of energy source                    | Consumption per energy source [kWh] Total energy consumption [kWh]      | %                  |
| Energy intensity                               | Energy of a process (field) [kWh] Total energy consumption [kWh]        | %                  |
| Percentage of energy from internal circuit     | Energy from internal heat recovery [kWh] Total energy consumption [kWh] | %                  |
| Percentage of renewable energy sources*        | Use of renewable energy [kWh] Total energy consumption [kWh]            | %                  |
| Total energy costs                             | Absolute                                                                | Euro               |
| Specific energy costs                          | Energy costs [kWh] Production costs [Euro]                              | %                  |
| Industry-specific energy performance indicator | Total energy consumption [kWh] Turnover [kEuro]                         | kWh/kEuro          |
| Specific costs per energy source               | Costs per energy source [Euro] ] Consumption per energy source [kWh]    | Euro/kWh           |
| Cost savings                                   | Absolute                                                                | Euro               |

Own illustration based on: BMU / UBA (1997)

* (Mandatory) EMAS core indicators

## R ENERGY CONVERSION FACTORS

|                | Net Calorific Value   | Gross Calorific Value   |
|----------------|-----------------------|-------------------------|
| Natural gas    | 10 kWh/m 2            | 12,66 kWh/kg            |
| Fuel oil light | 9,93 kWh/l            | 11,68 kWh/kg            |
| Fuel oil heavy | 10,27 kWh/l           | 11,17 kWh/kg            |
| Hard coal      |                       | approx. 8,14 kWh/kg     |
| Brown coal     |                       | approx. 5,35 kWh/kg     |

Author's own compilation

Using the spreadsheet calculation programmes available on the market, the data can be illustrated clearly in diagrams.

Other illustrations include, for example, cost / energy consumption distribution, time series, load profiles, energy flow diagrams, asset analysis, process analysis, long-term developments or tables.

One way of illustrating volume flows is to use a Sankey diagram. In this diagram, energy flows are illustrated in proportion to quantity using different widths and the direction of arrows making it easier to detect losses and 'hidden' consumers.

<!-- image -->

<!-- image -->

<!-- image -->

## Tip

Regularly announce energy consumption index developments and consumption values to the individual departments to motivate your employees. Celebrate success together!

## Examples of software for creating Sankey diagrams:

http://iwr.tuwien.ac.at/ressourcen/downloads/stan.html http://www.doka.ch/sankey.htm

http://www.stenum.at/en/?id=software/sankey/sankey-intro

An important objective of your EnMS is to save costs. This requires interface management: Outdated distribution formulae for energy costs often exist in the controlling of companies, something which should be regularly updated. Therefore, the Controller and the

<!-- image -->

Energy Manager should schedule regular meetings over a fixed time-period. In the long run, an updated distribution formula provides better incentives for those people in charge of the cost centres.

## Tip

Overall, it is important that the current figures (consumption, costs) are stored in the ERP (Enterprise Resource Planning) system (for example SAP) of your company. This data should be retrievable from Controlling &amp; Accounting, as well as the technical departments.

Given an existing ISO 14001, the following points should be considered when conducting the energy review:

- · Determine the current energy sources and evaluate the past and current energy consumption.
- · Determine the important equipment, processes and persons with regard to energy use and consumption.
- · Determine the relevant factors influencing energy use.
- · Determine the current energy consumption and use for the areas of significant energy use.
- · Estimate the future energy use and consumption.
- · Identify and prioritise opportunities to improve energy performance. Also ensure the determination of an appropriate reference period ('energy baseline').

With the current EMAS III, the review of past and present energy consumption has generally already been realised when taking into consideration the data from the environmental audit. If required, you must add the important factors influencing energy consumption.

Even the identification of areas with increased energy consumption has already been completed. If required, add an estimate of future consumption, a detailed representation and a facility-based assessment.

<!-- image -->

<!-- image -->

Additionally, you should make sure to prioritise opportunities to improve energy use and consumption, and determine an 'energy baseline'.

## 5. Energy objectives and targets

After stocktaking, you can develop global, long-term objectives consistent with your energy policy, which can then be achieved with short-term targets according to the PDCA principle.

The targets should be based on all influencing parameters that decisively impact the energy consumption. During their selection, ensure that the respective parameters are measurable. On the one hand, the targets should be ambitious, while on the other hand, they should be realistic enough to be achievable in the planned time period.

In the introduction and regular review of strategic and operational objectives, legal and other requirements must be taken into account, as well as opportunities to improve energy efficiency and consumption.

## Here are a few starting points:

- · Production processes (for example efficient use of compressed air, condensate, as well as switches and valves, use of automatic integrated systems, economic mode);

- · Motors and engines (for example increased usage of electronic controls, variable speed drive, integrated application programme, frequency converter, highly-efficient electric motors);
- · Ventilator, variable speed drive and ventilation (e. g. new devices / systems, using natural ventilation);
- · Demand management (for example load management,   servo-mechanism for peak load dismounting);
- · Highly efficient Combined Heat and Power (e. g. CHP plants)

In the identification and selection of operational objectives, rough cost-benefit estimates may be helpful. The selection can made using a weighted scoring system, whereby the following aspects should be considered: legal provisions, industry standards, cost of implementation, investment costs, pay-back time and environmental benefits.

<!-- image -->

The energy targets should generally be formulated as 'S.M.A.R.T.', for example:

Also, include the following while formulating your energy targets:

| S   | - specific    |
|-----|---------------|
| M   | - measurable  |
| A   | - appropriate |
| R   | - realistic   |
| T   | - time-bound  |

- · The area of consumption to which the targets correspond (for example pumps, lighting,…).
- · The quantitative reduction target. Use the ratio here (kWh/PU, kWh/k€,…) as the review is independent of production activity and other interfering factors.
- · The time period by when the target should be achieved.
- · The financial and ecological value (pay-back time, CO 2 eq  16 , …).
- · The measures and persons-in-charge necessary for implementation.
- · Estimated expenditure and costs (investment costs, production accidents, personnel costs, …).

16 CO 2 eq means 'CO  equivalent' and stands for the climate impact of all the greenhouse gases combined, whereby carbon dioxide serves as a 2 benchmark; the other greenhouse gases are correspondingly calculated per specific impact in ppm CO . 2

<!-- image -->

<!-- image -->

## Publications on energy efficiency in industry are available at:

- · 'Rationelle Energienutzung' (English 'Rational Energy Use') series by Vieweg Publishers (Vieweg Verlag)
- · http://www.industrie-energieeffizienz.de

For proposals on technical measures, you can refer to, for example, your state Energy Agency, 3,000 newly appointed energy coaches from the Chamber of Industry and Commerce (IHK), as well as the NRW (North Rhine-Westphalia) energy project:

- · An overview of the local energy agencies is provided by: www.energieagenturen.de
- · For energy coaches, you can contact the project office of the German Chamber of Industry and Commerce (DIHK) at http://www.dihk.de/klimaeffizient/ or your local Chamber of Industry and Commerce (IHK) respectively
- · The company pages of the Energy Agency NRW (North Rhine-Westphalia) http://www.energieagentur.nrw.de/unternehmen

The 'Modular Energy Efficiency Model' (Mod.EEM) pilot project with around 100 companies for introducing EnMS in NRW provides further ideas.

## R EXAMPLE FOR AN ENERGY OBJECTIVE TAKEN FROM AN EMAS ENVIRONMENTAL DECLARATION

| Objectives, Individual Objective                                                                                    | Implementation Status of Specified Measures                                                                                                         |
|---------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| Considerate Use of Resources                                                                                        |                                                                                                                                                     |
| Reduction of energy consumption in administration until 31.12.2010 by 5per cent in comparison to the previous year. | Replacing conventional lamps by energy saving lamps is continuously pursued.                                                                        |
|                                                                                                                     | The energy balance for the transparent building of the main administration was compiled. Measures were undertaken to reduce the energy consumption. |

www.emas.de/teilnahme/umwelterklaerungen/sammlung

<!-- image -->

While formulating strategic and operational energy objectives, you can turn to the environmental   objectives of ISO 14001. In order to meet the requirements of ISO 50001, the following aspects should also be considered:

- · Ensure that your objectives are also based on the improvement of energy efficiency and energy performance.
- · Regularly document and update your energy objectives, targets and programmes.

With an existing EMAS, some of these requirements have already been covered by you with the environmental statement. If required, you can extend these in order to ensure that the targets are measurable, documented and have a time frame.

<!-- image -->

## 6. Develop action plans

All the steps described so far should be consolidated and regularly updated in the action plans so that implementation is guaranteed and the internal and external control of EnMS is possible.

## Establish action plans

After you have established the operational objectives, action plans can be prepared which include concrete measures on how the objectives are to be achieved. For each objective and the relating work packages, responsibilities must be defined, a deadline established and resources for implementation provided. In addition, you must designate the manner by which you will later review whether the set objectives and corresponding improvements in energy use and consumption have been achieved, as well are what methods were used.

The individual measures should be developed parallel to energy objectives with the help of various factors such as the expenditure for implementation, investment costs and pay-back time. Develop measures jointly with your energy-efficiency team, as well as with the employees responsible, in order to get an overview of the feasibility of the various measures in your company (see '5. Document and monitor your EnMS').

## Documentation of the action plans

The action plans should be documented in order to simplify the implementation and to monitor effectiveness. A synopsis of the action plans should also be part of the energy report.

<!-- image -->

## Tip

As examples, three environmental programmes from the environmental statements of different organisations are given below:

## R NEW OBJECTIVES IN THE AREA OF GROUP-WIDE ENVIRONMENTAL PROTECTION OF BMW GROUP

| Strategic objectives                                                                                                                                                                   | Measures                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            | Deadline                                             |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------|
| Management of Resources and Environmental Protection                                                                                                                                   | Management of Resources and Environmental Protection                                                                                                                                                                                                                                                                                                                                                                                                                                                | Management of Resources and Environmental Protection |
| Breakthrough goal of a 30per cent reduction in energy consumption, VOC, water, process waste water and solid waste per manufactured vehicle between 2006 and 2012 (5per cent per year) | - More measures to raise employer awareness of energy saving potential - Integration of pilot project findings on consumption structures and energy flows in Munich in 2008 into all German locations - Full implementation of 'odour-free foundry' at the Landshut plant by 2010 and the subsequent continued reduction of VOC-emissions. - Decrease in drinking water consumption as a result of recycling in production and the use of other water categories such as near- surface ground water | 2010 2009/2010 2010 Ongoing                          |
| Increased application of renewable energies                                                                                                                                            | Evaluate and promote the option of using wind and geothermal energy at various locations                                                                                                                                                                                                                                                                                                                                                                                                            | 2010                                                 |
| Waste management                                                                                                                                                                       | Integrate the locations Goodwood and Rayong into the waste information system of the BMW group                                                                                                                                                                                                                                                                                                                                                                                                      | 2011                                                 |
| Nature conservation and biodiversity                                                                                                                                                   | Develop a biodiversity indicator for the entire network of the BMW group                                                                                                                                                                                                                                                                                                                                                                                                                            | 2011                                                 |
| Efficient transport logistics                                                                                                                                                          | Efficient transport logistics                                                                                                                                                                                                                                                                                                                                                                                                                                                                       | Efficient transport logistics                        |
| Increase percentage of low- emission transport modes                                                                                                                                   | Development of supply concepts from global procurement sources to the BMW group's production sites by taking into consideration sustainable, environmentally friendly transport modes                                                                                                                                                                                                                                                                                                               | 2009                                                 |
| Optimisation of transport volumes                                                                                                                                                      | Development of concepts on traffic reduction (load factor) and traffic relocation to more environmentally friendly carriers.                                                                                                                                                                                                                                                                                                                                                                        | 2009                                                 |

Environmental programme from the Environmental Statement 2008 of the BMW Group  7 1

17 Bayrische Motoren Werke (BMW) (ed.) (2008): Sustainable Value Report 2008. Munich. Available at http://www.upj.de/fileadmin/user\_upload/MAIN-dateien/Aktuelles/Nachrichten/bmw\_svr\_2008.pdf

## R EXCERPT FROM THE EMAS ENVIRONMENTAL STATEMENT 2008 OF THE FEDERAL ENVIRONMENT AGENCY  18

| Measures                                                                                                                                                                                                  | Outcome                                                          | Comple- ted on            | Loca- tions                | Respon- sible     | Details on Completion Status                                                                                                                                                                                          |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------|---------------------------|----------------------------|-------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Establishing regular information for employees on environmental performance of the locations (including review) at regular interval through an environ- mental statement (March) and report of EM (Sept.) | First-time publica- tion of environmen- tal statement and report | 30.09.08                  | DE, BP, MF, MN, CO, BE, LA | EM / location- EM | (Environmental Programme MF 1.1) According to the complied environmental statement, e-mail the employees on the basis of location.                                                                                    |
| Formulating a motivational leaflet for workers with advices concerning environmentally - friendly behavior (switching-off monitors, light, heat controls et cetera)                                       | Allocation                                                       | 30.10.08                  | DE, BP, MF, MN, CO, BE, LA | EM / Z5*          | Coordination is taking place between technical responsible OEs. In order to comply with the location specifi- cation, location versions should be compiled. These are then distributed via post to all the employees. |
| Clear and prompt demonstration of appropriate energy perfor- mance index in office buildings through information board in the entrance areas                                                              | Implementation (according to concept under 1.4.5)                | 01.09.08                  | DE, BP, MF, MN, CO, BE, LA | Z5                | There was an unsatisfactory attempt. A technical-optical acceptable solution is found, the transfer of data is following.                                                                                             |
| Developing an action-based measurement concept for recording the consumption of heat, electricity, cold and water mediums                                                                                 | 1.) Determining the measuring points 2.) Implementation          | 1.) 20.06.08 2.) 13.12.08 | MF                         | Z5                | (Environment programme MF 3.0.1) 1.) completed 2.) open                                                                                                                                                               |
| Decommissioning water heater in the toil. of FLC                                                                                                                                                          | Implementing Standard DG DE                                      | 04.09.08                  | DE                         | Z5/EM             | Measures were agreed upon between Z5 and UB after an inspection (refer to annotation UB).                                                                                                                             |
| Installation of a photovoltaic plant on the roof of FSA-hall                                                                                                                                              | Approval of resour- ces from 120 million programme of BR         | 30.09.08                  | MF                         | Z5                | (Environment programme MF 3.1.2); measures requested within the framework of 120-Mio-programme.                                                                                                                       |
| Assessing the improvement possibilities of structural heat insulation, particularly of the windows                                                                                                        | Decision on concrete measures                                    | 30.09.08                  | BP, MF                     | Z5                | BP: Decision on measures will be taken during the course of ES construction. MF: IR-Thermograph was conducted, small problems were resolved by the manufacturer, more thermograph planned for winter 08/09.           |
| Assessing the improvement possibilities in heat distribution                                                                                                                                              | Decision on concrete measures                                    | 30.09.08                  | BP                         | Z5                | Refer to 3.4.4 (Z5: new deadline at the end of 3.Q.´08 realised due to delay ES construction et cetera) A complete renovation/reformation of the heat distribution network.                                           |
| Installation of a plant for waste heat recovery from the discharged air of RLT-plant in new buildings.                                                                                                    | Energy saving                                                    | 31.12.08                  | MF                         | Z5                | Z5: Implementation from 120 Mio.- building refurbishment programme                                                                                                                                                    |

- * Division Z5: Administration
- 18 Federal Environmental Agency (UBA) (Ed.) (2008): EMAS-Environmental Statement of the Federal Environmental Agency for the locations DessauRosslau, Berlin-Bismarckplatz, Berlin-Marienfelde, Langen and House 23 in Berlin-Dahlem. Available at http://www.umweltdaten.de/publikationen/fpdf-l/3671.pdf

## R ENVIRONMENTAL STATEMENT 2009 OF THE IFA GROUP FOR LOCATIONS HALDENSLEBEN AND GARDELEGEN  19

| Environmental Objectives                                                                                                                                    | Environmental Programme 2006 to 2008                                                                                                                                                                                                                                                                                                                | Responsibilities Deadline                                              | Status of Completion as at 31. 12. 08        |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------|----------------------------------------------|
| Further development of the EM-system for IFA-AT and IFA-MB                                                                                                  | Optimising recycling of old cars by including EMS in the project planning for all new products and processes Cooperation of the IFA group in the Saxony-Anhalt environment alliance                                                                                                                                                                 | EM-officer F & E ongoing EM-officer ongoing                            | Implemented for 2007 Implemented for 2007    |
| Reduction of atmospheric pollution                                                                                                                          | While purchasing new company vehicles, it should be taken into consideration that they meet the requirements for low-emission E4 and that diesel vehicles are fitted with a particulate filter. In IFA-drive technology, the atmospheric pollution is further reduced by natural gas combustion for heating the office space using compressor heat. | EM/Procurement/ Commercial areas 12/2008 Plant management IFA-AT 01/06 | Implemented for 2007 Implemented             |
| Reduction of oil consumption                                                                                                                                | In investment activities, (machines and equipment) increased attention is paid to low oil consumption/dry processing, if technically possible.                                                                                                                                                                                                      | Engineering 01/01/06 to 31/12/08                                       | Implemented for 2008                         |
| Water conservation                                                                                                                                          | Reduction of water consumption in the entire plant as compared to 2006 per production ton of turnover, for e. g. by increasing the length of replacement cycles of the washing machine in the wheel flange production (based on turnover).                                                                                                          | Engineering and R&D 12/2008                                            | Implemented for 2008                         |
| Reduction of paper consumption                                                                                                                              | By introducing digital archiving, paper consumption should significantly reduce from an average 46,000 pages/month. (MB and AT)                                                                                                                                                                                                                     | Department manager 12/2008                                             | Implemented for 2008                         |
| Reduction of waste accumulation/person                                                                                                                      | Reduction of household waste/residual waste by 10per cent in comparison to 2006 by training of the employees.                                                                                                                                                                                                                                       | Department manager Annual balance sheet                                | Not implemented                              |
| Reduction of emissions, in particular the VOC (Volatile Organic Compounds) emis- sions, below the legally stipulated limits (31 of Federal Immision Control | Use of water soluble paints only · Developing a concept · Developing a technical solution · Implementing the solution                                                                                                                                                                                                                               | Engineering 2004 2005 2006                                             | Implemented Implemented Implemented for 2008 |
| Trainings                                                                                                                                                   | Conducting continuous internal environment information events for IFA-employees in group discussions and employ- ment services                                                                                                                                                                                                                      | Department manager Min. 1 x annually                                   | Implemented for 2006                         |
| Preventing soil pollution                                                                                                                                   | At IFA-Maschinenbau GmbH, the interim storage of emulsion- afflicted processed shavings should be improved (model                                                                                                                                                                                                                                   | Management Waste Management                                            | Implemented for 2008                         |

comparison)

Officer

Ltr. production 2008

20 IFA-Maschinenbau GmbH / IFA-Antriebstechnik GmbH (Ed.) (2009): Environmental Statement 2009 according to the Ordinance (EC) No.: 761 (EMAS).

## R PRACTICAL EXAMPLE FOR DEVELOPING AN ACTION PLAN

| Concerns/Subject                   | Lighting in office building                                                                                                                                               |
|------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Target                             | To reduce the energy consumption for lighting by 10per cent next year                                                                                                     |
| Parameters                         | Energy consumption for lighting per employee in [kWh/employee]                                                                                                            |
| Reference parameter                | Yearly consumption                                                                                                                                                        |
| Required investment                | 500 Euro                                                                                                                                                                  |
| Value of savings                   | Approx. 300 Euro/Year                                                                                                                                                     |
| Pay-back time                      | Approx. 1,5 years                                                                                                                                                         |
| Avoided CO 2 -emission             | 3.243 kg/year                                                                                                                                                             |
| Measures                           | 1. Building awareness of the user 2. Stocktaking - review of lighting power at work places 3. Using energy saving lamps and/or ballasts 4. Optimised positioning of lamps |
| Time frame                         | 1. Until October 2012 2. Until October 2012 3. Until November 2012 4. Until November 2012                                                                                 |
| Person responsible, amount of work | 1. Energy Manager - 0.5 day 2. Company Technician - 1.5 days 3. Company Technician - 1 day 4. Energy Manager - 0.5 days                                                   |
| Provision of expenditures          | By energy efficiency team budget                                                                                                                                          |
| Loss of work/production            | None                                                                                                                                                                      |
| Others                             | Reworking the lighting affects the working atmosphere positively The durability of energy lamps is higher than the traditional lighting devices                           |

## B DO

In order to achieve the maximum possible savings potential, the measures determined in the action plans should be prioritised and translated into a detailed work plan.

As well as including the responsibilities and timeframe for various activities, the work plan should always take into account the necessary resources. The stipulated energy objectives and targets can thus only be achieved if sufficient financial and technical resources are available. Furthermore, the Energy Manager should systematically record the success of measures and activities in order to make it easier for energy objectives and targets to be realised and a costbenefit analysis of the implemented measures to be conducted. Success indicators are cost savings and a reduction in environmental pollution, as well as a positive review by the press or positive feedback from the employees.

Maintain an energy savings register that records all the implemented measures with their savings potential.

After you have successfully planned your EnMS in Chapter 5A, it is now time for the actual implementation. During the implementation phase, the activities which were determined in the action plans are   implemented.

<!-- image -->

<!-- image -->

## The following steps must be considered to ensure an effective implementation of the EnMS:

- 1. Securing the necessary resources for implementing the EnMS and establishing the action plans
- 2.  Raising and building awareness
- 3.  Training the employees
- 4.  Communication of the EnMS
- 5.  Documentation of the EnMS and monitoring the documentation
- 6.    Operational control of all the relevant processes, including acquisition, purchase and maintenance

## Tip

Begin with the implementation of those measures that guarantee quick success and require very little or no investment. This leads to a distinct sense of achievement which makes it easy to communicate the advantages of energy management and to systematically tie the EnMS to the organisation.

Formulate the implementation of individual measures like a project in your company. This will simplify the implementation procedure for your employees.

## R EXAMPLE OF AN ENERGY-SAVING REGISTER  20

Electricity consumption in the reference year (kWh)

Gas consumption in the reference year (m ) 3

Primary sources of energy in the reference year (GJ)

| Energy-Saving Measures (Number and Description)   | Implementation year of the measure   | Actual savings in the 1 st year   | Actual savings in the 2 nd year   | Actual savings in the 3 rd year   | Actual savings in the 4 th year   | Actual savings in the 5 th year   | Investment costs/ employees/material   | Pay-off time period in years   | Savings in kwh per year   | Savings in m 3 natural gas per year   | Energy-saving (GJ/Year)   | Improvement in energy efficiency in %   | Eliminated CO 2 emissions per year   |
|---------------------------------------------------|--------------------------------------|-----------------------------------|-----------------------------------|-----------------------------------|-----------------------------------|-----------------------------------|----------------------------------------|--------------------------------|---------------------------|---------------------------------------|---------------------------|-----------------------------------------|--------------------------------------|
| Energy management and good business management    |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| 1) …                                              |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| 2)…                                               |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| …                                                 |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| Energy-saving projects in processes               |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| 1) …                                              |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| 2)…                                               |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| …                                                 |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| Energy-saving projects in plants and buildings    |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| 1) …                                              |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| 2)…                                               |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| …                                                 |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| Strategic projects                                |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| 1) …                                              |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| 2)…                                               |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| …                                                 |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |
| Total energy efficiency                           |                                      |                                   |                                   |                                   |                                   |                                   |                                        |                                |                           |                                       |                           |                                         |                                      |

20 According to Austrian Energy Agency (2007).

Measures without investment mostly refer to organisational changes, for example, establishing responsibilities, a systematic data acquisition, the switching-off of machines and devices when they are not being used, et cetera. Even adjusting energy supply contracts falls under this category.

of up to 50 per cent. 21 However, the problems during the   implementation process should not be underestimated and well-defined responsibilities should be determined.

Often, simple changes in the behaviour of the employees towards energy can lead to energy and cost savings

When undertaking measures that require investment, it is important to include suppliers and sub-contractors in order to realise the greatest possible savings potential.

## R SUCCESS CAN BE ACHIEVED DURING THE IMPLEMENTATION PHASE AS FOLLOWS

- · Build on what you have while simultaneously encouraging creative thought and new approaches.
- · Develop appropriate measures to be able to review and communicate progress.
- · Communicate what you do, what you need, and what the outcome is.
- · Use an improvement in your energy situation to motivate and encourage participation

<!-- image -->

## 1. Ensure the availability of required resources for the implementation of the EnMS

As already shown in Chapter 5A, it is necessary to form an energy efficiency team that is responsible for introducing, maintaining and improving the EnMS. Here, it is not sufficient to just appoint an Energy   Manager and other personnel who are part of the   energy team.

Top management must guarantee the availability of required technical and financial   resources which will ensure a smooth implementation of measures from the action plan. Additional human resources are of particular importance during the   introduction phase of your EnMS.

<!-- image -->

For more tips on forming an energy efficiency team, refer also to Chapter 5A. Identify the responsibilities and form an energy efficiency team.

<!-- image -->

<!-- image -->

The resources required for the implementation of ISO 50001 are also required for ISO 14001. Depending on the size of the company and sector, the Environment and   Energy Manager can be the same person or be in the same team.

EMAS requirements are in accordance with ISO 14001.

## 2. For a successful EnMS, focus on raising and building awareness

After you have decided who will make each statement, it is necessary to determine whether all affected employees possess the necessary knowledge and expertise in order to carry out their tasks in the area of energy management. This applies to the energy management team as well as all other relevant persons.

Raising and building awareness are important prerequisites for the success of the EnMS in your company.

Raising awareness can take place through a variety of different channels. Appropriate channels include, for example, information campaigns, flyers, info screen, articles in employee newsletters or the Intranet.

## R EMPLOYEES SHOULD BE AWARE OF:

- · The advantages of energy efficiency for the environment and for the company
- · The importance of compliance with the energy policy
- · The requirements of the EnMS
- · The consequences of noncompliance with the specifications of the EnMS
- · The potential impact of their own individual activities on energy consumption and achieving the energy objectives and targets
- · Their tasks, responsibilities and competencies in implementing the energy management according to ISO 150001

## Tip

<!-- image -->

Involve the intermediary management in identifying all the employees who you regard as important.

Simple steps for reducing energy consumption are a good initial approach to motivating the employees to save energy. This includes, for example switching-off lights and all electrical devices as soon as they are not being used, regulating air conditioners, et cetera. Here, the management has the function of a role model!

In any case, it is important to motivate the employees to participate. Provide tips on how one can easily and simply save energy, and communicate achievements which include environmental and the financial aspects.

Furthermore, it is important that top management sets a good example. Simple changes in attitude can be adopted much more easily if top management is committed and communicates this emphatically.

## 3. Facilitate employee trainings and professional development

After having defined responsibilities, it is necessary to find out whether all affected employees have the skills and competence required to conduct their tasks in the field of energy management.

Apart from concrete professional training measures for individual employees, you should prepare training programmes for the conscious use of energy in your company. The training material should thus be maintained on a regular basis.

Appropriate training leads to the establishment of the relevant and necessary competence in the company, as well as to creating awareness of the importance of energy management among individual employees.

Training features direct technical aspects, like introductory training for using a new technology. At the same time, it can also include training measures which are indirectly related to energy, for example professional   development for the Energy Manager in the field of communication or project management.

Training and creating awareness of the topic of energy management should not only be limited to your own company but should also include suppliers / contractors. You can expect that all persons working on behalf of the company are well-informed regarding the implementation of a successful energy management.

## Tip

Include your company's personnel development department so that energy management training becomes part of the development plan for the respective employees.

Training service portals can be found at: www.sophia24.com http://whoiswho.wissensportal-energie.de/

Even the local Chamber of Trade and Commerce offers certification courses for operational energy experts.

Furthermore, various certifiers and EMAS-environmental consultants conduct workshops and seminars on energy management in accordance with ISO 50001, as well as for operational energy experts.

## Practical example

The Volkswagen Group conducts a training programme for energy representatives in various departments. This training includes providing information on the most conventional energy sources to demonstrate energy saving potential in various areas. The training provides basic knowledge on the specific energy-saving options in the field of electricity (lighting and electrical machines), compressed air (6 bar and 12 bar), space heating / technical heating, water, incoming air/exhaust air, office, building envelope and organisation.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

ISO 14001 does not make a statement on the qualification of the energy management representative. Ensure that your energy management representative possesses the necessary expertise and skills.

Expand your spectrum of training measures with energy-relevant training:

All employees should be informed about the advantages of energy efficiency and energy management.

By involving all employees, EMAS-companies ensure that the employees are wellinformed when it comes to the various aspects of energy management.

In EMAS, no statements are made regarding the qualifications of the energy management representative. Review if he / she possesses the required expertise and qualifications. Expand your spectrum of training measures with energy-relevant training.

<!-- image -->

## 4. Communicate your EnMS in the company

While communicating your EnMS, you should differentiate between internal and external communication. According to ISO 50001, internal communication is obligatory and is closely related to raising the awareness of employees when it comes to implementing the EnMS. The external communication of your EnMS results is not mandatory; however, it helps to portray a positive profile of your company and positively affects your corporate image.

In order to continuously improve the EnMS, it is not only important to raise awareness among employees about the importance of energy management but also a company culture needs to be established, one that enables your colleagues to actively put forward suggestions for improvement and which motivates them on all levels. A separate process should be introduced and implemented for this purpose.

Effective internal communication is an important prerequisite for the successful implementation of your EnMS. Informing your employees about the EnMS on a regular basis increases their motivation to actively participate.

All comments collected and suggestions for improvement should be reviewed and answered. Appoint a person-in-charge and draft a plan for internal communication within the framework of energy management - this simplifies the information flow.

## R THE FOLLOWING ASPECTS OF THE ENMS SHOULD BE COMMUNICATED

- · The energy policy and the energy objectives and targets
- · The possibility of each individual to contribute towards energy management
- · Information on energy consumption and trends within the company
- · The conformance to legal and other requirements
- · Room for improvement
- · Financial and environmental advantages of energy management
- · Contact person for further details

<!-- image -->

## Tip

Build on established communication channels while preparing your communications plan. Develop the communications plan together with the department for internal communications and gain from their experience.

Apart from communicating to raise the general awareness of your employees, it is important to regularly communicate the most important aspects of the EnMS. Integrate the results of measurements and the energy indicators and aspects collected for the energy management into your internal controlling. This ensures regular internal communication of the EnMS results up to the top management.

Even if it is not compulsory communicate your activities externally, it remains important. If you decide in favour of external communication, then you must determine who will be responsible for it, what kind of information will be communicated and in which manner. You should be able to communicate distinctly and clearly to the public all possible measures and even the continuous improvement thereof according to the philosophy of ISO 50001.

## Tip

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Internal communication of your EnMS, its objectives and targets, as well as responsibilities, on a regular basis forms one of the most important aspects of a successful implementation. Especially in the initial phase, regular communication of the measures to be implemented is very important. This helps achieving a change of attitude amongst your colleagues.

External communication is not an obligation but you can take it as an opportunity to portray your company in public as being energy-conscious and environmentally friendly. It is becoming increasingly relevant in the face of the climate protection debate to portray individual efforts and to be placed positively on the market. A possibility for external communication is the integration of energy management into your sustainability report. Learn more about this aspect in Chapter 6 of this guide.

The requirements for internal communication are similar in ISO 14001 and ISO 50001. Focus your communication on energy aspects. Ensure that all employees are   informed about energy management and can actively take part. When you decide to communicate your energy management externally, prepare a communication plan, just as you do for internal communication.

EMAS users are already well-positioned with respect to communication. External communication and the involvement of employees is mandatory in EMAS. Additional requirements for internal communication are in accordance with ISO 14001.

## Tip

According to ISO 50001, energy management should be a cross-sectoral theme. Staff members from different departments such as procurement, controlling, building servic es, production and other areas with high energy consumption should regularly discuss this topic with each other. For example,   organise a 'round table' that brings together responsibilities concerning quality   management, environmental management, energy management, controlling and maintenance for the exchange of experiences and views.

## 5. Document and monitor your EnMS

All key elements of your EnMS should be captured either on paper or electronically and then be recorded. The documents should be easily accessible and therefore, preferably filed in a systematic manner. If you have already introduced a documentation system into your company, it is recommended that you use it for your EnMS also in order to save on effort and costs.

These key questions make it easier for you to prepare an easily understandable documentation system:

- · What is the subject of the documents?
- · Which part of the company is affected?
- · Which activities should be documented?
- · For whom is the documentation meant and who must work with it?

Ensure that anyone who is responsible for the documentation of one or more working areas has access to the documents. Ensure that the documentation system is monitored regularly and always kept up-to-date.

All processes related to energy must be documented. It is necessary to document the reasons for implementing a certain measure, as well as which areas of consumption and activities in the daily work routine are affected by a certain procedure.

The simpler the documents are maintained, the easier it is to implement the EnMS. Also, keeping your documents up to date enables you to monitor and measure your EnMS more easily.

## THE NECESSARY COMPONENTS OF THE DOCUMENTATION OF YOUR ENMS INCLUDE ABOVE ALL:

| EnMS Documents                                 | Necessary records concerning…                                           |
|------------------------------------------------|-------------------------------------------------------------------------|
| EnMS documentation                             | Appointment of an energy manager/energy team                            |
| Scope and boundaries of the EnMS               | Energy review                                                           |
| Energy policy                                  | Energy baseline                                                         |
| Energy planning process                        | Methodology for defining and updating your EnPIs                        |
| Methodology and criteria for the energy review | Training needs and measures                                             |
| Action plans                                   | Design results                                                          |
| Strategic and operational objectives           | Monitoring results and evaluation of 'key characteristics'              |
| Requirements for the purchasing of energy      | Calibration of measurement equipment and analogous measures             |
| Energy measurement plan                        | Results of investigation into significant deviations                    |
| Audit plan                                     | Results of evaluation of noncompliance with regulations and commitments |
|                                                | Results of audits                                                       |
|                                                | Corrective and preventative measures                                    |
|                                                | Proof of conformity of the EnMS                                         |
|                                                | Energy performance results                                              |
|                                                | Management review                                                       |

<!-- image -->

<!-- image -->

## Tip

Combine the responsibility for documents of the QMS and EMS with the EnMS. The general rule of thumb is that an integrated management system reduces expenditure by up to 30 per cent!

Documentation obligations in ISO 14001 (EMAS) and ISO 50001 differ only slightly. You already fulfil all the important prerequisites; however, ensure that all energy-relevant documents are available.

<!-- image -->

EMAS companies have already presented an externally validated document. No other requirements need to be met. Ensure that all the energy-relevant documents are available.

## Monitoring documentation

It is fundamentally important to make sure that all documents make the right statements before releasing them. In addition, all documents should regularly be monitored for being up-to-date and being accurate. Ensure that the latest documents are well-preserved from damage, loss or destruction. The relevant versions of applicable documents must be available where they are used. For legal reasons, a few obsolete documents need to be kept. However, ensure that these documents are clearly separated from the current versions, and thus that out-of-date and/or obsolete documents are not used unintentionally.

Also ensure that you identify and make available any external documents which are necessary for the planning and operation of the EnMS.

All documents can be kept in electronic form, as well as in hard copy.

<!-- image -->

There is no considerable difference in the monitoring of documentation between ISO 14001 and ISO 50001. Ensure that all important documents of the EnMS are ntegrated and make sure that all the documents are maintained in a manner i sufficient to implement the energy management system.

<!-- image -->

EMAS requirements in accordance with ISO 14001.

## 6. Include energy efficiency in processes, design and procurement

## Energy-conscious operational control:

Within the framework of your EnMS, you need to consider all the internal and also, to some extent, external processes of the company.

This includes the planning of procedures and processes, maintenance of facilities, installations and equipment, buildings, purchasing, procurement, as well as the energy consumption of all the commodities and assets used in your company.

Examine all processes to determine, for example, how much energy can be saved by switching off machines when they are not in use or by changing processes or working procedures.

<!-- image -->

## Tip

Do not only concentrate on the main processes. Studies have shown that a major amount of the energy in industrial establishments (up to 2/3) is consumed by ancillary activities! 22

<!-- image -->

Furthermore, the regular maintenance and upkeep of machines, equipment and facilities often leads to energy savings, for example because air conditioners are cleaned or failures are noticed more easily.

## R O ENSURE THAT MAINTENANCE AND REPAIR TAKE PLACE AT REGULAR INTERVALS, YOU MUST: T

- · Carry out operational and repair plans for machinery, equipment and plants.
- · Specify maintenance intervals for relevant facilities. This includes mentioning the type of maintenance.
- · Identify the departments and personnel who are responsible for the operation and repair of the equipment.
- · Have ready the time plans for reviewing the relevant facilities and the description on how the assessment should be conducted.

See Annex A of DIN EN 16001. ISO 50001 does not go into as much detail here.

## Energy-conscious design:

Attention must be paid to energy-efficient design, when designing, modifying or renovating plants, acilities and buildings. Those who ensure that energyf efficient alternatives, low energy standards or alternative energy sources are used within new facilities and utilities as well as new production lines will consequently save energy and costs.

When implementing energy-efficient designs, collaboration with an external consultant may be advisable. External consultants have the experience needed for estimating the cost-benefit effect of energyconscious design.

## R ENSURE IN THE CONTEXT OF ENERGY-CONSCIOUS DESIGN THAT:

- · an in-depth analysis of energy consumption is carried out in the very first phase of the development project;
- · an energy review is conducted in all relevant development steps (proposals, first detailed design, final design, selecting the equipment, delivery, commissioning, et cetera);
- · the responsibilities of the persons-in-charge concerning an energy-conscious design are established clearly.

See Annex A of DIN EN 16001. ISO 50001 does not go into as much detail here.

## Energy-conscious procurement:

Even when purchasing machinery, equipment, raw materials and services, a lot of energy can be saved. Make energy efficiency a criterion for evaluation in your procurement processes, and make sure that the entire lifecycle is always considered in the assessment of energy consumption and energy efficiency. Determine the criteria and calculation methods for this, such as the calculation of the pay-back period or alternative and potentially more useful methods (for example internal rate of return, net present value method).

<!-- image -->

Fundamentally, it is important to take the evaluation of cost-benefit aspects into account. In the case of high energy consumption, more complex evaluation procedures might be useful. In designing the evaluation procedure, the following points should be taken into account:

- · Exact definition of when a review will be carried out;
- · Definition of responsibilities for conducting of the evaluation, including review and approval;
- · Ensure the examination of economic and energy-efficient alternatives;
- · Definition of responsibilities with regard to deciding which option is the most reasonable;
- · In the purchasing of energy, aspects such as energy quality, availability, cost structure, environmental impacts and renewable energy should be taken into account.

<!-- image -->

## Literature tip

On the website of the Federal Environment Agency (UBA), you will find many helpful tips on environmentally friendly procurement.

http://www.umweltbundesamt.de/produkte/beschaffung/

The Federal Ministry of Economics and Technology (BMWi) has published various links for practical procurement help on their website, e. g. guides on how energy efficiency aspects can be integrated when awarding a contract, important energy consumption data and environmental key data, as well as online information systems http://www.bmwi.de/BMWi/Navigation/Energie/Energieeffizienz-und-Energieeinsparung/energieeffiziente-beschaffung,did=232292.html

In principle, the guidelines for energy-conscious procurement must not only be applicable to your company but also to your suppliers. Make energy efficiency a feature when selecting suppliers and consultants / subcontractors.

Training and raising employee awareness are the most important prerequisites for an energy-conscious design and procurement.

In the current ISO 14001, the control of your processes and procedures should be expanded by energy efficiency. With regard to procurement, you also need to consider additional energy-related requirements in the design of relevant equipment and processes. This includes inter alia the following aspects:

- · Determine criteria for the effective operation and maintenance of significant areas of energy use and other relevant areas.
- · Provide for the operation and maintenance of equipment, facilities and processes in accordance with the operational criteria.
- · Expand your communication in this regard to your personnel and all others who work on behalf of your company.
- · Include opportunities for improving energy performance in the design of facilities or processes.
- · Integrate energy efficiency and energy consumption as additional criteria for procurement.
- · Inform your suppliers that energy is an important criterion of your procurement policy.

As an EMAS company, you have much fewer additional aspects to consider. You have already integrated environmental impacts into your procurement. In addition, you only have to ensure that the energy aspect remains a relevant theme. Your employees are informed already.

If required, add criteria for operating and maintaining facilities, processes and equipment, as well as the review of energy consumption in the design of equipment, facilities and processes.

<!-- image -->

<!-- image -->

## C CHECK &amp; ACT

According to ISO 50001, an important aspect of energy management is the process of continuous improvement. In order to ensure this, you need to regularly check if you have achieved all energy objectives and targets and if the EnMS is functioning optimally.

<!-- image -->

<!-- image -->

If necessary, you may need to undertake corrective measures.

## The following aspects must be considered during a regular review:

- 1. Monitoring and measurement
- 2. Reviewing compliance with legal obligations
- 3. Internal audits
- 4. Nonconformity, corrective and preventive action
- 5. Planning and structuring records
- 6. Review by top management

## 1. Monitor and measure the results of your EnMS regularly

It is possible to detect inefficient energy consumption promptly if there is a frequent and regular comparison between the expected and actual energy consumption. In any case, the areas of significant energy use and the relevant factors for energy consumption must be monitored. Depending on the type of organisation, you would measure for example the energy consumption of processes, compressed air, heating or lighting. The typical time period depends on the type and size of the organisation and individual facilities. Measurements can be made as real-time measurements, or be carried out in monthly or even rarer intervals.

<!-- image -->

By frequently and regularly comparing the expected and actual energy consumption, it is possible for you to quickly detect inefficient use of energy. Also, you have the opportunity to analyse the energy consumption and to measure the achievement of objectives and targets.

<!-- image -->

## Tip

Use energy reports, meter readings, information from administration and accounts for monitoring and measuring. For this, your ERP system (for example SAP) should contain the most current data!

The purchase of measurement equipment and meters is often expensive and does not necessarily remain in proportion to the potential savings. Therefore, adjust the number of the required measurement devices to the type of your company and to the requirements of your EnMS. A comprehensive introduction of measurement devices is not necessary; a plan should be prepared to optimise the use of measurement devices and, if necessary, to procure new devices over a long period of time.

Generate energy performance indicators (EnPI) to measure energy consumption. This will help you compare the consumption of various plants or production lines. An example energy performance indicator is the energy consumption per production unit or m 2  of floor area (See also Chapter 5A).

## The following aspects should be part of the regular monitoring:

- · The consideration of relevant factors that influence energy consumption
- · Comparing current and expected energy consumption
- · Examination of significant areas of energy use
- · Updating of energy performance indicators
- · Reviewing the effectiveness of action plans

<!-- image -->

<!-- image -->

It should thereby be noted that the energy baseline must be adjusted as a reference value if significant changes have occurred in the operations or the previously specified EnPIs are no longer appropriate for measurement.

## Tip

Establish benchmarks with other parts of your company or other comparable companies in order to uncover potential for optimisation and define energy objectives.

## Important

The relation between energy factors and energy consumption must be assessed on a regular basis to ensure that consumption is assessed with the help of current bestpossible performance.

You must create an energy measurement plan. Its level of detail should depend on the particular requirements. Keep inter alia the following points in mind for the plan:

- · Scope of monitoring
- · Assignment of responsibilities

The requirements for monitoring and measurement are similar in ISO 14001 and ISO 50001. In order to meet the requirements of ISO 50001, you should additionally consider inter alia the following aspects:

- · Consider areas of significant energy use and the relevant factors influencing these areas.
- · Compare and assess the expected vs. actual energy consumption in fixed time periods.
- · Make sure to document the results of the energy performance monitoring.
- · Make sure to develop an energy measurement plan.
- · Make sure that you have defined the measurement requirements and review them regularly.
- · Be sure to investigate and document any significant nonconformities in energy performance

<!-- image -->

EMAS requirements are  in accordance with  ISO 14001.

## 2. Monitor and assess compliancy with legal obligations

You should regularly assess to what extent the legal obligations and other requirements of the company described in Chapter 5A have been complied with.

A written review is required here. You can use the review to keep your legal   register up-to-date.

<!-- image -->

With regard to monitoring and reviewing the compliance of legal obligations, no additional measures need to be taken in the current ISO 14001.

<!-- image -->

For companies with EMAS, the same requirements apply as those for ISO 14001. However, their legal compliance has, unlike within ISO 14001 certification requirements, been cross-checked by the responsible authorities, and can be proven by appropriate documentation (known as a clearance certificate of an environmental verifier).

<!-- image -->

- · Measurement intervals
- · Methods for measuring energy consumption
- · Maintenance of measurement instruments

## 3. Internal audits

You must regularly carry out internal audits, which includes a systematic review of your EnMS. In the run-up to an internal audit, it is advisable to clarify what it actually contains. For instance, it should not be taken as a:

- · Cost-benefit-calculation of individual measures
- · Calculation of economic efficiency for future projects
- · Analysis of technical aspects of the equipment purchased according to the action plan

The aim of the internal audit is to further develop the functionality of your EnMS, your energy management programmes, objectives and targets, et cetera, and to help develop new measures for optimising your energy management. 23  An audit is a systematic element of the

<!-- image -->

internal review of your EnMS and thus an important step for continuous improvement. Therefore, you should not see the internal audit as merely a control measure but as an opportunity to f  urther improve yourself and the company.

The internal audit should take place at least once a year. It can either be conducted by employees of your company who have the required skills and knowledge about your EnMS, the standard ISO 50001, as well as the aspects to be analysed but remain outside the direct management of the EnMS. Otherwise, you can consult an external auditor and have him / her carry it out. In this case, it is advisable to use the same auditor that is used for certification as it reduces effort and costs. In either case, the auditor should be qualified, experienced, impartial and independent of the area to be assessed in the organisation.

## Tip

When conducting internal audits through an employee, it is recommended to first consult the other management officers of your company to exchange advice.

Once you have decided on the auditor, you should then carefully plan the actual implementation of the audit. Think beforehand about which information sources you will use. These can be persons, documents or already existing energy reports. It is a good idea to collect the essential data for the internal audit before the audit itself. This will help to save time and cost and will give you a good opportunity to get more deeply involved in the analysis of possible causes.   Inform the relevant persons in time and gather   background information in the run-up to the audit.

Prepare audit checklists for guidance during the audit. In Appendix A, you will find an example checklist that will help you analyse the current status quo of your EnMS. Note the type of resources used, place and time of the audit taken, as well as the name of the persons responsible.

At the beginning of the audit, explain the objective of the internal audit to all employees directly connected to the EnMS elements which are to be audited. It is mportant that it is not about the performance of the i individual employee but about the effectiveness of the EnMS.

23 ISO 19011:2011 is the international audit standard. It functions as a guide for auditing quality and environment management systems and lists the qualifications of auditors.

## When conducting the internal audit, the auditor shall:

- · Determine the current energy performance
- · Assess the effectiveness of the EnMS, as well as its processes and systems
- · Compare the results with the energy objectives and targets
- · Provide information for benchmarking
- · Analyse problems and indentify their sources and weaknesses
- · Identify possibilities for continuous improvement

<!-- image -->

## Tip

It is advisable to present the final report to the top management, as well as to the   employees whose job area is affected by the internal audit. You thus get the opportunity to present outcomes, to explain deviations and non-conformity and to plan possible improvement measures.

## R EXAMPLE FOR PREPARING AN ENERGY REPORT (KEY POINTS)

|   Energy Report, Second Half-Year 2012 | Energy Report, Second Half-Year 2012                                    |
|----------------------------------------|-------------------------------------------------------------------------|
|                                      1 | Short company profile (incl. company processes & products)              |
|                                      2 | Energy sources & energy consumption (July - Dec. / 2012)                |
|                                      3 | Energy targets as of 31.12.2012 Achievement of targets as of 31.12.2012 |
|                                      4 | Identified measures for 2012 Achieved measures in 2012                  |
|                                      5 | Synopsis of energy management programme                                 |
|                                      6 | Required corrective measures                                            |
|                                      7 | Next steps                                                              |

The result of an internal audit should be an energy report in which all current energy data is present. Apart from the status quo of the energy management system, the report should also contain a description of follow-up activities, monitoring and measurement of results, as well as a description of responsibilities.

The report not only focuses on the improvement of the EnMS but also refers directly to energy efficiency. It compares the results of the activities with plans and energy targets of the energy management programme and determines by how much energy consumption and energy efficiency have actually improved.

<!-- image -->

The requirements of the internal audit of ISO 50001 widely conform to the requirements of ISO 14001. Ensure that your internal auditor has sufficient knowledge of energy management and energy efficiency. Furthermore, ensure that an audit plan and schedule are created under consideration of the results of earlier audits.

<!-- image -->

EMAS companies already fulfil all the prerequisites through the additional regulations on internal company auditing. However, ensure that your auditor has sufficient knowledge regarding energy management and energy efficiency.

## 4. Take action if the energy policy cannot be implemented:

<!-- image -->

If the requirements that ISO 50001 sets for your EnMS are not fulfilled, then you must take corrective action.

This is applicable, for instance, when the behaviour of employees or the development of the company are not conforming to the energy policy, the energy objectives and targets or to the energy programme.

You must identify deviations and their causes, as well as ensure that the problems do not repeat themselves. Deviations should be documented, but there are no guidelines on how you have to respond to them. However, an evaluation of the effectiveness of countermeasures is required.

## 5. Create a plan for your records

You must keep records of your energy-related activities. With these records, document the realisation of energy objectives and targets, energy programmes and action plans. The records depend on the company and must conform to the requirements of your EnMS. They should be traceable, legible and accessible and should be directly assigned to the relevant processes, activities or persons.

<!-- image -->

In comparison to ISO 14001, no substantial changes are necessary to the procedures for managing records.

<!-- image -->

As an EMAS user, you already fulfil all the prerequisites as you must regularly collect all information on your environmental performance for updated environmental statements.

## 6. Get your EnMS reviewed by the top management (Management Board)

A review of the EnMS should be undertaken by top management at regular intervals to evaluate the suitability and effectiveness of the energy policy, the objectives and targets, the indicators, as well as the general state of your energy management system.

The management review is not only an assessment of the EnMS status quo but also an important tool for the identification of possibilities for improving energy efficiency in your company.

In order to ensure that the suggestions given by top management are also taken into consideration, the review shall be documented, for instance, in the form of a protocol or action plan. Furthermore, follow-up measures and responsibilities for implementing the suggestions must be identified. Based on the results of the internal audit, an intensive review by the top management should take place at least once a year.

## Tip

<!-- image -->

<!-- image -->

<!-- image -->

Integrate the energy management obligations into your internal financial controlling in order for top management to be kept informed about the status quo of the energy indicators.

In order to organise the respective meeting of the top management for the review of your EnMS as effectively as possibly, preparations should be made well in advance (e.  g. preparation of a comprehensible consolidation of all important data and results of the EnMS).

The requirements for a review by the top management are almost identical in ISO 14001 and ISO 50001. Make sure to include energy performance indicators in the management review, as well as the planned energy performance.

The suggestions resulting from the review undertaken by top management must be completed with improvements achieved since the last review.

EMAS requirements are identical to those of ISO 14001.

## 6 CERTIFICATION, ASSESSMENT &amp; EXTERNAL COMMUNICATION

## Certification

If you have fully introduced an EnMS into your company, you have the option of getting it certified by an independent external certifier. By doing so, you ncrease the relevance of your management system i and can simultaneously improve your company's mage. When receiving the certificate, the company i has officially demonstrated that it has fulfilled the requirements of ISO 50001. Certifications are   carried out by an independent third party.

<!-- image -->

Certificates should be renewed on a regular basis. That includes conducting an audit in order to check if you are continuously improving your management system. Therefore, select your certification body very carefully as this business relationship is to last for a long time to come.

## Tip

If you have already introduced another management system, you should bear in mind that your certification body cannot only certify your EnMS but also other management systems (for example ISO 9001 or ISO 14001). Here, the effort required for an audit can be reduced and costs can be saved.

## Initial certification

Once you have decided on a certifier, a first pre-audit is usually carried out. Depending on the particular certifier, the pre-audit looks at the company's location, business strategies, requirements of the standard that your company has already fulfilled, et cetera. Based on these early assessments, the core points of the measures to be undertaken can be established. In a second step, the documentation of your management system is   reviewed to determine the extent to which you already comply with the requirements of the ISO 50001 standard.

which the functionality of the management system implemented fulfils the conditions of the standard in practice. It thus primarily deals with the agreement between the defined targets and the performance against these. The expenditure for this certification audit is dependent on the certification body you employ. Thus, apart from assessing the documents and the (energy) performance, effectiveness can be evaluated through additional appraisal interviews or by observing company processes.

During the actual certification audit (DIN EN ISO/IEC 17021:2011), the certifying auditors look at the extent to

<!-- image -->

If the auditors approve the compliance of your management system with the requirements of ISO 50001, then your company is awarded the certificate.

## Tip

Before starting the certification process, the EnMS should have run for at least three months so that the relevant data is available.

<!-- image -->

## Re-certification

To ensure continuous improvement of your management system, annual audits are conducted by the certifier. Performance is thus assessed systematically, enhanced and, if required, optimised. In this way, nonconformities can be detected at an early stage and relevant corrective measures are taken.

<!-- image -->

With a regular review audit by the certifier, you can re-certify your management system. Remember to conduct the re-certification in time and before the validity of your certificate expires.

## Literature tip

Additional information on certification can be found, for example, on the websites of the following organisations:

- · Deutsche Akkreditierungs- und Zulassungsgesellschaft für Umweltgutachter GmbH (DAU) http://www. dau-bonn-gmbh.de
- · Deutsche Akkreditierungsstelle http://www.dakks.de/content/verzeichnisse-akkreditierter-stellen

## External communication

Receiving the certificate signifies to your employees, business partners, clients and the wider public that you have successfully implemented an EnMS. To communicate this, you have various options of internal and external communication tools available. Thus, you can, for example, include your EnMS in the annual or

<!-- image -->

sustainability reports. It is further recommended to define target groups, identify communication media (like newsletters, professional journals, events, company website, et cetera) and to develop corresponding marketing strategies.

## Tip

A separate menu item on 'energy' or 'energy management' on your hompage can contribute towards underlining the importance of the topic for your company.

It is important to follow the DIN/ISO/CEN standardisations for any kind of external communication to prevent false statements.

credited. 'DIN EN ISO 50001:2011 certified' and 'DIN EN ISO 50001:2011 registered' can be used as synonyms. However, the use of 'DIN EN ISO 50001:2011 accredited' is false.

In the past, there have been instances in which companies have used logos of standardisation organisations like DIN, CEN or ISO. These logos are, however, registered as trademarks and are thus protected. Therefore, be careful not to use any such logos.

<!-- image -->

<!-- image -->

Pay particular attention to describing your certification correctly. If you have implemented an EnMS in your company and received the relevant certification, then you are certified according to ISO 50001:2011. Expressions like 'certified according to ISO' or 'ISO 50001 certified' are not precise. You should also be careful about the use of the terms certified, registered and ac-

<!-- image -->

The misconception that DIN EN ISO 50001:2011 is a product standard should be prevented. The standard does not refer to a product of your company but to processes that affect the energy efficiency and energy consumption of your company.

According to DIN EN ISO 50001:2011, external communication is not obligatory following a certification but remains the decision of each company. If a company decides against external communication, it should be able to give reasons for this decision. It is generally recommended that you use external communication as an opportunity to highlight the credibility of your company's energy policy.

## Literature tip

References to 'Good Practice' in the communication of the certification can be found in the guidebook from ISO, Genf:

ISO 2005: Publicising your ISO 9001:2000 or ISO 14001:2004 certification.

Available at http://www.iso.org/

DIN EN ISO 9001:2008 and DIN EN ISO 14001:2009 can easily be ordered online from the Beuth-Verlag website (http://www.beuth.de).

## 7 BIBLIOGRAPHY

## Standards

DIN EN ISO 9001:2008, Qualitätsmanagement- systeme - Anforderungen (ISO 9001:2008);  dreisprachige  Fassung EN ISO 9001:2008.

ISO 14001:2004, Environmental management systems - Requirements with guidance for use.

DIN EN ISO 14001:2009, Umweltmanagementsysteme - Anforderungen mit Anleitung zur Anwendung (ISO 14001:2004 + Cor. 1:2009); deutsche und englische Fassung EN ISO 14001:2004 + AC:2009.

DIN EN 16001:2009, Energiemanagementsysteme Anforderungen mit Anleitung zur Anwendung.

DIN EN ISO 19011:2002, Leitfaden für Audits von Qualitätsmanagement- und / oder Umweltmanagementsystemen (ISO 19011:2002); deutsche und englische Fassung EN ISO 19011:2002.

DIN EN ISO/IEC 17021:2011, Konformitätsbewertung Anforderungen an Stellen, die Managementsysteme auditieren und zertifizieren.

DIN EN ISO 50001:2011, Energiemanagementsysteme - Anforderungen mit Anleitung zur Anwendung.

ÖNORM M 7109, Ausgabe 2002-07-01, Begriffe der Energiewirtschaft - Energiehaushalten.

prEN ISO/IEC 17021-2:2009, Konformitätsbewertung Anforderungen an Stellen, die Managementsysteme auditieren und zertifizieren, und Anforderungen an Drittparteien-Zertifizierungsaudits von Managementsystemen - Teil 2: Anforderungen an DrittparteienZertifizierungsaudits von Managementsystemen.

Richtlinie VDI 4602 Blatt 1: 2007-10, Energiemanagement - Begriffe (Verein deutscher Ingenieure e. V.).

Senter Novem, Energy Management System - Specification with Guidance for Use, June 2004.

## Legal Framework

Bericht zur Umsetzung der in der Kabinettsklausur am 23./24.08.2007 in Meseberg beschlossenen Eckpunkte für ein Integriertes Energie- und Klimaprogramm, Berlin, 05.12.2007, verfügbar auf http://www.bmu.de/ klimaschutz/downloads/doc/39875.php.

Commission of the European Communities 2008: Proposal for a Regulation of the European Parliament and of the Council on the voluntary participation by organisations in a Community eco-management and audit scheme (EMAS), Brussels, verfügbar auf http:// ec.europa.eu/environment/emas/pdf/com\_2008\_402\_ draft.pdf.

Gesetz für den Vorrang Erneuerbarer Energien (Erneuerbare-Energien-Gesetz - EEG) vom 25. Oktober 2008 (BGBl. I S. 2074).

Richtlinie 2006/32/EG des Europäischen Parlaments und des Rates vom 5. April 2006 über Endenergie-effizienz und Energiedienstleistungen und zur Auf-hebung der Richtlinie 93/76/ EWG des Rates. (ABl.EG L 114 S. 64)

Verordnung (EG) Nr. 1221/2009 des Europäischen Parlaments und des Rates vom 25. November 2009 über die freiwillige Teilnahme von Organisationen an einem Gemeinschaftssystem für Umweltmanagement und Umweltbetriebsprüfung und zur Aufhebung der Verordnung (EG) Nr. 761/2001, sowie der Beschlüsse der Kommission 2001/681/EG und 2006/193/EG. (ABl. EG. L 342 S.1)

## Bibliographical References

Austrian Energy Agency 2007: Step by step guide for the implementation of energy management, Wien. http://energimyndigheten.se/Global/F%C3%B6retag/ bess.pdf

Bayerische Motoren Werke (BMW) (Hrsg.) 2008: Sustainable Value Report 2008, München, verfügbar auf http://www.upj.de/fileadmin/user\_upload/MAINdateien/Aktuelles/Nachrichten/bmw\_svr\_2008.pdf.

Bayerisches Staatsministerium für Wirtschaft, Infrastruktur, Verkehr und Technologie 2003: Integriertes Managementsystem. Ein Leitfaden für kleine und mittlere Unternehmen, München.

Bundesministerium für Umwelt, Naturschutz und Reaktorsicherheit (BMU) / Umweltbundesamt (UBA). 1997: Leitfaden Betriebliche Umweltkennzahlen, Bonn / Berlin.

Bundesministerium für Umwelt, Naturschutz und Reaktorsicherheit (BMU) / Umweltbundesamt (UBA) (Hrsg.) 2005: Umweltmanagementansätze in Deutschland, verfügbar auf http://www.bmu.de/wirtschaft\_ und\_umwelt/unternehmensverantwortung\_csr/emas/ doc/37543.php.

Bundesamt für Wirtschaft und Ausfuhrkontrolle (BAFA) 2012: II. A Merkblatt für Unternehmen des produzierenden Gewerbes, verfügbar auf http://www. bafa.de/bafa/de/energie/besondere\_ ausgleichsrege-lung\_eeg/merkblaetter/merkblatt\_ii\_a.pdf.

Deutsche Energie-Agentur 2009: Energiemanagement, verfügbar auf http://www.industrie-energieeffizienz.de/energiemanagement.html.

Doka, Gabor: Sankey Helper v2.2, verfügbar auf http:// www.doka.ch/sankey.htm.

Ebel, Bernd 2003: Qualitätsmanagement, Verlag Neue Wirtschafts-Briefe (nwb), Herne, Berlin.

EMAS-Registrierungen in Deutschland, aktuelle Anzahl aller Registrierungen, verfügbar auf http://www. emas-register.de.

Engel, Heinz Werner 2009: EMAS 'easy' for Small and Medium Enterprises, im Internet verfügbar: EMAS 'easy' for Small and Medium Enterprises.

Fraunhofer Institut für System- und Innovationsforschung (ISI), Forschungszentrum Jülich, Institut für Energieforschung - Systemforschung und Technologische Entwicklung (IEF-STE), Öko-Institut, Berlin, Dr. Hans-Joachim Ziesing, Berlin, CEPE/ETH Zürich 2008: Wirtschaftliche Bewertung von Maßnahmen des integrierten Energie- und Klimaprogramms (IEKP). Wirtschaftlicher Nutzen des Klimaschutzes. Kostenbetrachtung ausgewählter Einzelmaßnahmen der Meseberger Beschlüsse zum Klimaschutz, Hrsg. v. Umweltbundesamt, Dessau - Roßlau, verfügbar auf http:// www.umweltdaten.de/publikationen/fpdf-l/3517.pdf.

Hessische Landesanstalt für Umwelt 1997: Leitfaden Integrierte Managementsysteme, HLfU-Schriftenreihe, Heft 240, Fachverlag Moderne Wirtschaft, Wiesbaden.

Infozentrum UmweltWirtschaft Bayern d. Bayrischen Landesamts für Umwelt 2009: Praxisbeispiele, verfügbar auf http://www.izu.bayern.de/praxisbs/index\_prax-isbs.php?pid=1403010100.

ISO 2005: Publicizing your ISO 9001:2000 or ISO 14001:2004 certification, Genf, verfügbar auf http:// www.iso.org/iso/publications\_and\_e-products.htm.

Kahlenborn, Walter / Jutta Knopf / Ina Richter 2010: Energiemanagement als Erfolgsfaktor - International vergleichende Analyse von Energiemanagementnormen. Hg. Umweltbundesamt. UBA-Texteband 53. Dessau.

Lackner, Petra / Holanek, Nicole 2007: BESS-Handbook: Schritt für Schritt. Anleitung zur Einführung von Energiemanagementsytemen, Wien. Verfügbar unter http://www.energymanagement.at/fileadmin/elearning/Tools\_Startaktivitaeten/Energiemanagement\_ Handbuch\_ka\_eeb.pdf.

Meyer, Jörg 2005: EUTech Energie und Management, Branchenenergiekonzepte: Vom Energiecontrolling zum Energiemanagement, Vortrag zur IHK Bonn / Rhein-Sieg &amp; Energieagentur NRW &amp; KfW 'Energiekosten senken: Effizienter Energieeinsatz im produzierenden Gewerbe Bonn, 02. Dezember 2005, verfügbar auf http://www.branchenenergiekonzepte.de/pdf/ BEKPapier\_Vortrag\_Energiemanagement\_Meyer.pdf.

Österreichische Energieagentur: Nützliche Tools zur Implementierung von Energiemanagement. http://www.energymanagement.at/ Downloads.24.0.html.

SenterNovem 2004: Structural Attention for Energy Efficiency by Energy Management, June 2004, verfügbar auf http://energiezorg.st.novem.nl/instrumenten/271.pdf.

TU Wien, Fachbereich Abfallwirtschaft und Ressourcenmanagement 2009: Stan - Software für Stoffflussanalyse, verfügbar auf http://iwr.tuwien.ac.at/ressourcen/downloads/stan.html.

Umweltbundesamt (UBA) (Hrsg.) (2009): EMAS-Umwelterklärung des Umweltbundesamts für die Standorte Dessau-Roßlau, Berlin-Bismarckplatz, Berlin-Marienfelde, Langen und das Haus 23 in Berlin-Dahlem. 2008: EMAS-Umwelterklärung des Umweltbundesamts für die Standorte Dessau-Roßlau, Berlin-Bismarckplatz, Berlin-Marienfelde, Langen und das Haus 23 in BerlinDahlem.

Umweltgutachterausschuss 2009: 7 gute Gründe für ein Umweltmanagement nach EMAS. Berlin http:// www.uga.de/fileadmin/user\_upload/06\_service/PDFDateien/EMAS\_7\_Gute\_Gruende-Broschuere2009.pdf.

Wirtschaftskammer Österreich 2011: Energiemanagementsysteme nach ISO 50001. Tipps für die Umsetzung. WIFI-Schriftenreihe 348. Wien. Verfügbar unter http://portal.wko.at/wk/format\_detail.wk?stid=630205 &amp;dstid=6963&amp;angid=1

Wirtschaftskammer Österreich 2009: Energieeffizienz. Tipps für Unternehmen. WIFI-Schriftenreihe 340. Wien. Verfügbar unter http://portal.wko.at/wk/for-mat\_detail.wk?AngID=1&amp;StID=470979&amp;DstID=6963&amp;o pennavid=41356

## Further information

Bayrisches Landesamt für Umwelt: Verschiedene Branchenleitfäden zur Energieeinsparung. http:// www.izu.bayern.de/service/leitfaeden.php

Bundesministerium für Umwelt, Naturschutz und Reaktorsicherheit 2009: Energieeffizienz - die intelligente Energiequelle. Tipps für Industrie und Gewerbe. Berlin

Deutsche Energie-Agentur Publikationsliste zum Thema Energieeffizienz in der Industrie. Verschiedene Publikationen, verfügbar auf https://www.industrieenergieeffizienz.de/publikationen-service/publikationen.html.

Deutsche Energie-Agentur 2009: Referenzprojekte, verfügbar auf http://www.industrie-energieeffizienz. de/dena-referenzprojekte.html.

Energieagentur NRW. Diverse Informationen und Instrumente für Unternehmen: http://www.energieagen-tur.nrw.de/unternehmen/willkommen-auf-unserem-portal-fuer-unternehmen-3687.asp

IHK Regensburg (Hrsg.), 2012: Tagungsunterlagen 'Energiemanagement konsequent effizient' vom 28. Februar 2012, verfügbar unter: http://www.ihk-regensburg.de/content/121011d

International Organization for Standardization 2011: Win the energy challenge with ISO 50001. http:// www1.eere.energy.gov/energymanagement/pdfs/ iso\_50001\_energy.pdf

Österreichische Energieagentur: Nützliche Tools zur Implementierung von Energiemanagement. http:// www.energymanagement.at/Downloads.24.0.html.

US Department of Energy 2011: Guiding Principles for Successfully Implementing Industrial Energy Assessment Recommendations. Verfügbar unter: http:// www1.eere.energy.gov/manufacturing/pdfs/imple-mentation\_guidebook.pdf

## ANNEX A: ENERGY MANAGEMENT CHECKLIST

The energy management checklist is an important instrument for you to review, either when initiating the EnMS or when close to completing the implementation process, whether you have optimally introduced the EnMS according to the DIN EN ISO 50001:2011 standard.

The checklist includes a series of checkpoints which are formulated as questions. If you have implemented the EnMS correctly, you will be in a position to answer the questions with 'YES'. The checklist consists of 107 ques- tions. On the hand right side of the table, you will also find a column for comments on every individual point. Comments can, for example, be measures or references to some specific areas which require further attention. At the end of the checklist, you will find the summarised analysis of all the sub-questions. In this, note the number of questions answered with YES and NO per section. This will help you to quickly identify the areas that show an optimal implementation or, if necessary, those that need further improvement.

<!-- image -->

## Tip

Use the comments column during the review process. After auditing and certification, it serves as a good guideline for improvement and optimisation measures.

## R COMPANY DATA

This checklist has been prepared for the following company / organisation:

Address:

Zip Code and City (of Registration):

Telephone Number:

Fax:

E-mail:

Contact:

Telephone Number:

1.

2.

3.

Date of Review:

## R ENERGY MANAGEMENT SYSTEM CHECKLIST

## * No. analogical to the progression with regard to contents of DIN EN ISO 50001

| No.* o.*   | Required Elements Required Elements                                                                                                                     | Implementa-nta- tion Yes/No Impleme tion Yes / No   | Commentsents Comm   |
|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------|---------------------|
| A          | Management responsibility                                                                                                                               |                                                     |                     |
| A 1        | Top management                                                                                                                                          |                                                     |                     |
| 1          | Has the energy policy been established and implemented by top manage- ment?                                                                             |                                                     |                     |
| 2          | Has an energy manager been appointed by top management?                                                                                                 |                                                     |                     |
| 3          | Have the necessary resources been provided for the establishment and maintenance of the EnMS?                                                           |                                                     |                     |
| 4          | Have the scope and boundaries of the EnMS been defined?                                                                                                 |                                                     |                     |
| 5          | Has the importance of the EnMS for the company been made suffici- ently clear to employees?                                                             |                                                     |                     |
| 6          | Have strategic and operational objectives been established?                                                                                             |                                                     |                     |
| 7          | Has energy performance (measurable results with regard to energy efficiency, use and consumption) been taken into consideration in long- term planning? |                                                     |                     |
| A 2        | Management representative                                                                                                                               |                                                     |                     |
| 8          | Is top management reported to regarding the performance of the EnMS and energy performance?                                                             |                                                     |                     |
| 9          | Have the competencies and responsibilities under the EnMS been defined and communicated?                                                                |                                                     |                     |
| 10         | Have criteria and methods for ensuring the effective operation and monitoring of the EnMS been determined?                                              |                                                     |                     |
| B          | Energy policy                                                                                                                                           |                                                     |                     |
| 11         | Does the energy policy include a commitment to continually improve energy performance?                                                                  |                                                     |                     |
| 12         | Does it include a commitment to provide the information and resour- ces necessary for achieving the strategic and operational objectives?               |                                                     |                     |

| No.*   | Required Elements                                                                                                                              | Implementa- tion Yes / No   | Comments   |
|--------|------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|------------|
| 13     | Does it include the commitment to comply with all applicable legal and other requirements?                                                     |                             |            |
| 14     | Does the energy policy support the procurement of energy-efficient products and services?                                                      |                             |            |
| 15     | Was it documented and communicated throughout the company?                                                                                     |                             |            |
| 16     | Is it subject to regular review and updating?                                                                                                  |                             |            |
| C      | Energy planning                                                                                                                                |                             |            |
| C 1    | General                                                                                                                                        |                             |            |
| 17     | Has the company conducted and documented an energy planning pro- cess?                                                                         |                             |            |
| C 2    | Legal and other requirements                                                                                                                   |                             |            |
| 18     | Has the company identified and implemented all applicable legal and other requirements?                                                        |                             |            |
| 19     | Is a regular review of legal and other requirements conducted?                                                                                 |                             |            |
| C 3    | Energy review                                                                                                                                  |                             |            |
| 20     | Has the company conducted an energy review and documented the results, methodology and criteria?                                               |                             |            |
|        | Were the following aspects considered in the development of the energy review?                                                                 |                             |            |
| 21     | - Evaluation of energy use and consumption                                                                                                     |                             |            |
| 22     | - Identification of areas of significant energy use, important equip- ment, processes and persons, and relevant factors influencing energy use |                             |            |

## R ENERGY MANAGEMENT SYSTEM CHECKLIST

- * No. analogical to the progression with regard to contents of DIN EN ISO 50001

| No.*   | Required Elements                                                                                                                                                                 | Implementa- tion Yes / No   | Comments   |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|------------|
| 23     | - Determination of current and estimation of future energy perfor- mance                                                                                                          |                             |            |
| 24     | Have possibilities for improving energy performance been identified?                                                                                                              |                             |            |
| C 4    | Energy baseline                                                                                                                                                                   |                             |            |
| 25     | Has an energy baseline been established using information from the initial energy review, and is it further developed as necessary?                                               |                             |            |
| C 5    | Energy performance indicators                                                                                                                                                     |                             |            |
| 26     | Have appropriate energy performance indicators (EnPIs) been identified, and are they regularly reviewed?                                                                          |                             |            |
| C 6    | Energy objectives, energy targets and energy management action plans                                                                                                              |                             |            |
| 27     | Have strategic and operational objectives been established for fixed time-frames based on preliminary work?                                                                       |                             |            |
| 28     | Have action plans been established, along with the necessary resour- ces and time-frames for achieving the objectives, and the definition of responsibilities and review methods? |                             |            |
| 29     | Are the objectives and action plans documented and regularly updated?                                                                                                             |                             |            |
| D      | Implementation and operation                                                                                                                                                      |                             |            |
| D 1    | Competence, training and awareness                                                                                                                                                |                             |            |
| 30     | Have all employees and other relevant persons working for the company been sufficiently trained with regard to areas of significant energy use?                                   |                             |            |
|        | Do all employees and other relevant persons have knowledge of the following areas?                                                                                                |                             |            |

| No.*   | Required Elements                                                                        | Implementa- tion Yes / No   | Comments   |
|--------|------------------------------------------------------------------------------------------|-----------------------------|------------|
| 31     | - The importance of complying with the energy policy                                     |                             |            |
| 32     | - EnMS processes and requirements                                                        |                             |            |
| 33     | - Individual roles and responsibilities                                                  |                             |            |
| 34     | - The advantages of improved energy performance                                          |                             |            |
| 35     | - Their own potential impact on energy consumption and energy efficiency                 |                             |            |
| 36     | Have the training measures been documented?                                              |                             |            |
| D 2    | Communication                                                                            |                             |            |
| 37     | Are the energy performance and the EnMS internally communicated?                         |                             |            |
| 38     | Can all employees actively take part in improving the EnMS?                              |                             |            |
| 39     | Has the company also decided to communicate externally (and documen- ted this decision)? |                             |            |
| 40     | If yes, has a plan for external communication been developed and imple- mented?          |                             |            |
| D 3    | Documentation                                                                            |                             |            |
| D 3.1  | Documentation requirements                                                               |                             |            |
|        | Does the documentation of the EnMS include:                                              |                             |            |
| 41     | - Its core elements (items 4.2 to 4.5.3 of the standard)                                 |                             |            |

## R ENERGY MANAGEMENT SYSTEM CHECKLIST

- * No. analogical to the progression with regard to contents of DIN EN ISO 50001

| No.*   | Required Elements                                                                                | Implementa- tion Yes / No   | Comments   |
|--------|--------------------------------------------------------------------------------------------------|-----------------------------|------------|
| 42     | - The scope and boundaries of the EnMS                                                           |                             |            |
| 43     | - All other documents required by the standard                                                   |                             |            |
| D 3.2  | Control of documents                                                                             |                             |            |
|        | Is the following ensured with regard to documents?                                               |                             |            |
| 44     | - A review of the adequacy of documents prior to use                                             |                             |            |
| 45     | - Regular evaluation and updating                                                                |                             |            |
| 46     | - Clear indication of the revision status and traceability of changes                            |                             |            |
| 47     | - Good availability                                                                              |                             |            |
| 48     | - Legibility and identifiability                                                                 |                             |            |
| 49     | - Identification and distribution of external documents relevant to the EnMS                     |                             |            |
| 50     | - Prevention of the use of obsolete documents                                                    |                             |            |
| 51     | - Retention of relevant older documents as necessary                                             |                             |            |
| D 4    | Operational control                                                                              |                             |            |
|        | Were the following aspects taken into consideration when determining and planning the processes? |                             |            |
| 52     | - Determining criteria for the effective operation and maintenance of all relevant areas         |                             |            |

| No.*   | Required Elements                                                                                                                         | Implementa- tion Yes / No   | Comments   |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|------------|
| 53     | - Operation and maintenance of equipment and processes according to the criteria                                                          |                             |            |
| 54     | - Appropriate information provided to all employees and other rele- vant persons                                                          |                             |            |
| D 5    | Design                                                                                                                                    |                             |            |
| 55     | Are opportunities for improving energy performance taken into account in the design of new, altered or renovated equipment and processes? |                             |            |
| 56     | How is this documented?                                                                                                                   |                             |            |
| D 6    | Procurement of energy services, products, equipment and energy                                                                            |                             |            |
| 57     | Are suppliers informed that energy use, consumption and efficiency are relevant purchasing criteria?                                      |                             |            |
| 58     | Have energy-related purchasing criteria been developed?                                                                                   |                             |            |
| 59     | Is this documented?                                                                                                                       |                             |            |
| E      | Checking                                                                                                                                  |                             |            |
| E 1    | Monitoring, measurement and analysis                                                                                                      |                             |            |
|        | Are the following aspects taken into consideration in monitoring within the framework of the EnMS?                                        |                             |            |
| 60     | - The results of the energy review and areas of significant energy use                                                                    |                             |            |
| 61     | - Relevant influential factors                                                                                                            |                             |            |
| 62     | - The energy performance indicators                                                                                                       |                             |            |

## R ENERGY MANAGEMENT SYSTEM CHECKLIST

- * No. analogical to the progression with regard to contents of DIN EN ISO 50001

| No.*   | Required Elements                                                                                | Implementa- tion Yes / No   | Comments   |
|--------|--------------------------------------------------------------------------------------------------|-----------------------------|------------|
| 63     | - The effectiveness of action plans with regard to set objectives                                |                             |            |
| 64     | - Evaluation of actual energy consumption relative to expectations                               |                             |            |
| 65     | Was a plan drawn up to measure energy, and is this plan implemented?                             |                             |            |
| 66     | Are the requirements for measurement and the correct operation of measurement equipment ensured? |                             |            |
| 67     | Are significant deviations in energy performance investigated and responded to?                  |                             |            |
| 68     | Is this all documented?                                                                          |                             |            |
| E 2    | Evaluation of legal and other requirements                                                       |                             |            |
| 69     | Is compliance with legal and other relevant requirements regularly evalu- ated and documented?   |                             |            |
| E 3    | Internal audit of the EnMS                                                                       |                             |            |
| 70     | Are internal audits conducted regularly?                                                         |                             |            |
| 71     | Is there an audit plan?                                                                          |                             |            |
| 72     | Is the objectivity of the audit ensured in the selection of auditors?                            |                             |            |
| 73     | Are the results of the audit documented and reported to top manage- ment?                        |                             |            |
| E 4    | Nonconformities, correction, corrective action and preventive action                             |                             |            |
| 74     | Are nonconformities with the set objectives prevented and/or corrected?                          |                             |            |

| No.*   | Required Elements                                                                                                                                                         | Implementa- tion Yes / No   | Comments   |
|--------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------|------------|
|        | Are the following aspects taken into consideration thereby?                                                                                                               |                             |            |
| 75     | - Identification of nonconformities and their causes                                                                                                                      |                             |            |
| 76     | - Identification of the need for action, the implementation of neces- sary countermeasures (including necessary changes to the EnMS), and a review of their effectiveness |                             |            |
| 77     | - Documentation of these items                                                                                                                                            |                             |            |
| E 5    | Control of records                                                                                                                                                        |                             |            |
| 78     | Have records been established on the conformity of the EnMS with the requirements of the standard?                                                                        |                             |            |
| 79     | Is the legibility, identifiability and traceability of these records ensured?                                                                                             |                             |            |
| F      | Management review                                                                                                                                                         |                             |            |
| F 1    | General                                                                                                                                                                   |                             |            |
| 80     | Is the EnMS regularly reviewed by top management?                                                                                                                         |                             |            |
| 81     | Are all the introductory parameters noted in item 4.7.2 of the standard taken into consideration for the management review?                                               |                             |            |
| F 2    | Output from management review                                                                                                                                             |                             |            |
| 82     | Were all decisions and measures for improving the energy performance since the last review taken into consideration?                                                      |                             |            |
| 83     | Were all decisions and measures with regard to the energy policy, the strategic and operational objectives and the provision of resources taken into consideration?       |                             |            |

| No.*   | Required Elements                                                    | Number of questions answered with "yes"   | Number of questions answered with "no"   |
|--------|----------------------------------------------------------------------|-------------------------------------------|------------------------------------------|
| A      | Management responsibility                                            |                                           |                                          |
| A 1    | Top management                                                       |                                           |                                          |
| A 2    | Management representative                                            |                                           |                                          |
| B      | Energy policy                                                        |                                           |                                          |
| C      | Energy planning                                                      |                                           |                                          |
| C 1    | General                                                              |                                           |                                          |
| C 2    | Legal and other requirements                                         |                                           |                                          |
| C 3    | Energy review                                                        |                                           |                                          |
| C 4    | Energy baseline                                                      |                                           |                                          |
| C 5    | Energy performance indicators                                        |                                           |                                          |
| C 6    | Energy objectives, energy targets and energy management action plans |                                           |                                          |
| D      | Implementation and operation                                         |                                           |                                          |
| D 1    | Competence, training and awareness                                   |                                           |                                          |
| D 2    | Communication                                                        |                                           |                                          |
| D 3    | Documentation                                                        |                                           |                                          |
| D 3.1  | Documentation requirements                                           |                                           |                                          |
| D 3.2  | Control of documents                                                 |                                           |                                          |
| D 4    | Operational control                                                  |                                           |                                          |
| D 5    | Design                                                               |                                           |                                          |
| D 6    | Procurement of energy services, products, equipment and energy       |                                           |                                          |

| No.*   | Required Elements                                                      | Number of questions answered with "yes"   | Number of questions answered with "no"   |
|--------|------------------------------------------------------------------------|-------------------------------------------|------------------------------------------|
| E      | Checking                                                               |                                           |                                          |
| E 1    | Monitoring, measurement and analysis                                   |                                           |                                          |
| E 2    | Evaluation of legal and other requirements                             |                                           |                                          |
| E 3    | Internal audit of the EnMS                                             |                                           |                                          |
| E 4    | Nonconformities, correction, corrective action and preventi- ve action |                                           |                                          |
| E 5    | Control of records                                                     |                                           |                                          |
| F      | Management review                                                      |                                           |                                          |
| F 1    | General                                                                |                                           |                                          |
| F 2    | Output from management review                                          |                                           |                                          |

<!-- image -->

## ANNEX B: COMPARATIVE TABLE ISO 50001 AND ISO 14001

<!-- image -->

Since the requirements for an EnMS were substantially developed from ISO 14001 and ISO 14001 forms an important basis for ISO 50001, the following table illustrates the relationship between ISO 14001 and ISO 50001, respectively.

As energy manager and energy experts of your organisation, the table serves as an overview and orientation to review your operational situation with regards to the introduction of ISO 50001. Even the parts of the EnMS that are in principle already ful filled under ISO 14001 should once again be reviewed with reference to the special situation of each company. These parts should also be checked to ensure that they adequately reflect energy-related issues.

## The table consists of three main columns: 24

- 1) The requirements of ISO 50001
- 2) A comparison of these requirements with the relevant chapters of ISO 14001
- 3) Differences and necessary additions to ISO 14001

<!-- image -->

## Literature tip

EnMS can also be integrated into ISO 9001. Detailed information on this can be found on the website of the Austrian Energy Agency:

http://www.energymanagement.at/fileadmin/elearning/Tools\_Startaktivitaeten/ Uebereinstimmungslisten.pdf

| ISO 50001:2011   | ISO 50001:2011                                                                                                                                                  | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                                                                                        |         |
|------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------------------------|---------|
| Chapter          | Chapter                                                                                                                                                         | Chapter                       | Chapter                                                                                                                            | Chapter |
| 4.               | Energy management system requirements                                                                                                                           | 4.                            | Environmental management system requirements                                                                                       |         |
| 4.1.             | General requirements                                                                                                                                            | 4.1.                          | General requirements                                                                                                               |         |
|                  | Establishment, documentation, implementation and maintenance of the EnMS                                                                                        |                               | Establishment, documentation, implementation and maintenance of the EMS                                                            |         |
|                  | Definition and documentation of the scope and boundaries of the EnMS                                                                                            |                               | Definition and documentation of the scope of the EMS                                                                               |         |
|                  | Continual improvement of energy performance and the EnMS                                                                                                        |                               | Continual improvement of the EMS                                                                                                   |         |
| 4.2.             | Management responsibility                                                                                                                                       | 4.4.1 and 4.2                 | There is no exactly corresponding item; some provisions are nonetheless included in other items, in particular in 4.2 and 4.4.1    |         |
| 4.2.1.           | Top management                                                                                                                                                  |                               |                                                                                                                                    |         |
|                  | Top management is responsible for the definition, establishment, implementation and maintenance of the energy policy                                            |                               | Definition of the environmental policy by top ma- nagement                                                                         |         |
|                  | Responsibility for appointing an energy manage- ment representative and approving the energy management team                                                    |                               | Appointment of an EMS representative by top ma- nagement                                                                           | .       |
|                  | Responsibility for the provision of necessary resources for the establishment, implementati- on, maintenance and improvement of the EnMS and energy performance |                               | Top management must provide the necessary resources for the establishment, implementation, maintenance and improvement of the EMS. |         |
|                  | Responsibility for the definition of the scope and boundaries of the EnMS                                                                                       |                               | No requirements                                                                                                                    |         |
|                  | Responsibility for the internal communication of the importance of the EnMS                                                                                     |                               | No requirements                                                                                                                    |         |
|                  | Responsibility for the establishment of strategic and operational objectives regarding energy performance                                                       |                               | No requirements                                                                                                                    |         |
|                  | Responsibility for appropriate EnPIs                                                                                                                            |                               | No requirements                                                                                                                    |         |
|                  | Responsibility for taking energy performance into consideration in long-term planning                                                                           |                               | No requirements                                                                                                                    |         |
|                  | Responsibility for the execution of management reviews                                                                                                          |                               | Implicitly covered by the provisions on management review.                                                                         |         |
| 4.2.2.           | Management representative                                                                                                                                       |                               |                                                                                                                                    |         |

| What should additionally be done with an existing ISO 14001?                                                                                                                                                                     |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Energy must basically be defined as an important factor under ISO 14001.                                                                                                                                                         |
| Generally included                                                                                                                                                                                                               |
| Define the boundaries of your EMS.                                                                                                                                                                                               |
| In ISO 14001, an improvement of the EMS is expected, however it is not expected of environmental performance. Define the improve- ment of your energy performance as an important aspect and focus your activities on this area. |
| Generally included                                                                                                                                                                                                               |
| Covered in principle. Depending on the size of the organisation, the energy manager and the in-charge officer for environmental management can be one and the same person.                                                       |
| Generally included                                                                                                                                                                                                               |
| Generally this point is already included, although the defined boundaries of the EnMS must be taken into account (see also 4.1); it is important to ensure the involvement of top management.                                    |
| It is important to ensure the involvement of top management in internal communication of the EnMS; in general, this should already be the case.                                                                                  |
| It is important to ensure the involvement of top management in establishing the objectives; in general, this should already be the case.                                                                                         |
| It is important to ensure the involvement of top management.                                                                                                                                                                     |
| Ensure that energy performance is taken into consideration in long-term planning.                                                                                                                                                |
| Generally included                                                                                                                                                                                                               |

| ISO 50001:2011   | ISO 50001:2011                                                                                               | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                                                          |
|------------------|--------------------------------------------------------------------------------------------------------------|-------------------------------|------------------------------------------------------------------------------------------------------|
| Chapter          |                                                                                                              | Chapter                       |                                                                                                      |
|                  | Responsibility for ensuring the conformity of the EnMS with the standard                                     |                               | Responsibility for ensuring conformity of the EMS with the standard                                  |
|                  | Responsibility for forming an energy manage- ment team                                                       |                               | No requirements                                                                                      |
|                  | Reporting to top management on energy per- formance                                                          |                               | No requirements                                                                                      |
|                  | Reporting to top management on EnMS perfor- mance                                                            |                               | Reporting to top management on EMS performance                                                       |
|                  | Ensuring the appropriateness of the planning of energy management activities in support of the energy policy |                               | No requirements                                                                                      |
|                  | Definition and communication of competencies and responsibilities to support energy manage- ment             |                               | No requirements                                                                                      |
|                  | Determination of criteria and methods for ensuring the effective monitoring and operation of the EnMS        |                               | No requirements                                                                                      |
|                  | Promotion of awareness of the energy policy and strategic energy objectives                                  |                               | No requirements                                                                                      |
| 4.3.             | Energy policy                                                                                                | 4.2.                          | Environmental policy                                                                                 |
|                  | Appropriateness to the nature and scale of energy use and consumption                                        |                               | Appropriateness to the nature, scale and environ- mental impacts of activities and products/services |
|                  | Consideration of the commitment to continually improve energy performance                                    |                               | Consideration of the commitment to continual improvement                                             |
|                  | Consideration of the commitment to provide the information and resources necessary for achieving objectives  |                               | No requirements                                                                                      |
|                  | Consideration of the commitment to comply with all legal and other requirements                              |                               | Consideration of the commitment to comply with all applicable legal and other requirements           |
|                  | Establishment of a framework for the defini- tion and review of strategic and operational objectives         |                               | Establishment of a framework for the definition and review of environmental objectives               |
|                  | Promoting the purchase of energy-efficient products and services                                             |                               | No requirements                                                                                      |
|                  | Ensuring the documentation and internal com- munication of the energy policy                                 |                               | Ensuring documentation                                                                               |

| What should additionally be done with an existing ISO 14001?                                                                                                              |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Generally included                                                                                                                                                        |
| Ensure that the energy management representative appoints an energy management team.                                                                                      |
| Ensure that energy performance is also considered in the context of the reporting requirements.                                                                           |
| Generally included                                                                                                                                                        |
| Assign the appropriate responsibility to the energy management representative.                                                                                            |
| Assign the appropriate responsibility to the energy management representative.                                                                                            |
| Assign the appropriate responsibility to the energy management representative.                                                                                            |
| Assign the appropriate responsibility to the energy management representative.                                                                                            |
| Generally included                                                                                                                                                        |
| Generally included. Ensure that the commitment also specifically refers to the improvement of energy performance.                                                         |
| Ensure that the environmental policy includes corresponding commitments.                                                                                                  |
| Generally included                                                                                                                                                        |
| Generally included                                                                                                                                                        |
| Ensure that the environmental policy includes stipulations on the purchase of energy-efficient products and services.                                                     |
| Communication of the energy policy is already partly required due to the necessary training measures (see 4.2). Ensure that the energy policy is adequately communicated. |

| ISO 50001:2011   | ISO 50001:2011                                                                        | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                                                             |    |
|------------------|---------------------------------------------------------------------------------------|-------------------------------|---------------------------------------------------------------------------------------------------------|----|
| Chapter          | Chapter                                                                               | Chapter                       | Chapter                                                                                                 |    |
|                  | Ensuring regular review and needs-based updating                                      |                               | Implicitly included in requirements in other items                                                      |    |
| 4.4.             | Energy planning                                                                       | 4.3.                          | Planning                                                                                                |    |
| 4.4.1.           | General                                                                               |                               |                                                                                                         |    |
|                  | Commitment to conduct and document an ener- gy planning process                       |                               | Not explicitly asked                                                                                    |    |
|                  | Consideration in the energy planning of activi- ties that impact energy performance   |                               | Not explicitly asked                                                                                    | .  |
| 4.4.2.           | Legal and other requirements                                                          | 4.3.2.                        | Legal and other requirements                                                                            |    |
|                  | Identification and implementation of applicable legal and other requirements          |                               | Establishment and implementation of a procedure for identifying applicable legal and other requirements |    |
|                  | Consideration in the establishment and imple- mentation of the EnMS                   |                               | Consideration in the establishment and implementa- tion of the EMS                                      |    |
|                  | Regular review of legal and other requirements                                        |                               | -                                                                                                       |    |
| 4.4.3.           | Energy review                                                                         |                               | Partial correspondence to 4.3.1: Environmental aspects                                                  |    |
|                  | Conducting and maintenance of an energy review                                        |                               | Not explicitly asked                                                                                    |    |
|                  | Identification of energy sources and evaluation of energy use and consumption         |                               | Not explicitly asked                                                                                    |    |
|                  | Identification of areas of significant energy use based on certain preparations       |                               | Identification of environmental aspects with signifi- cant impact on the environment                    |    |
|                  | Identification and prioritisation of opportunities for improving energy performance   |                               | Not explicitly asked                                                                                    |    |
| 4.4.4.           | Energy baseline                                                                       |                               | Not included                                                                                            |    |
| 4.4.5.           | Energy performance indicators                                                         |                               | Not included                                                                                            |    |
| 4.4.6.           | Energy objectives, energy targets and energy management action plans                  | 4.3.3.                        | Objectives, targets and programme(s)                                                                    |    |
|                  | Establishment and implementation of documen- ted strategic and operational objectives |                               | Establishment and implementation of documented environmental objectives and targets                     |    |

| What should additionally be done with an existing ISO 14001?                                                                                                                                                                                         |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Generally included                                                                                                                                                                                                                                   |
| Ensure that you conduct and document an energy planning process.                                                                                                                                                                                     |
| Ensure that all important activities that impact energy performance are considered in the energy planning.                                                                                                                                           |
| Generally included. Ensure conformity with all energy-related laws.                                                                                                                                                                                  |
| Generally included                                                                                                                                                                                                                                   |
| Generally included                                                                                                                                                                                                                                   |
| In substance largely included in the regulations on review.                                                                                                                                                                                          |
| Ensure that an energy review is conducted regularly and document your methodology and criteria.                                                                                                                                                      |
| Generally this should already have been done, but make sure.                                                                                                                                                                                         |
| The requirements of ISO 50001 are considerably more detailed here. Take note of the inclusion of different points, such as the identifi- cation of relevant factors, the determination of energy performance or the estimation of future energy use. |
| Identify and prioritise opportunities for improving your energy performance.                                                                                                                                                                         |
| Ensure that you establish an energy baseline and adjust it as needed, and keep the necessary records of this.                                                                                                                                        |
| Ensure that you identify energy performance indicators, document your corresponding methodology and regularly review the data and compare it to the energy baseline.                                                                                 |
| Generally included. Ensure that your objectives are aimed at improving energy performance.                                                                                                                                                           |
| Generally included                                                                                                                                                                                                                                   |

| ISO 50001:2011   | ISO 50001:2011                                                                                                                             | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                                                                      |
|------------------|--------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------|
| Chapter          |                                                                                                                                            | Chapter                       |                                                                                                                  |
|                  | Consistency of the objectives with the energy policy                                                                                       |                               | Consistency of the objectives with the environmental policy                                                      |
|                  | Establishment and implementation of action plans including the identification of responsibili- ties, means, time-frames and review methods |                               | Establishment and implementation of programmes including the designation of responsibility, means and time-frame |
|                  | Documentation and updating of the action plans                                                                                             | 4.3.4.                        | Included in principle as part of the requirements for documentation                                              |
| 4.5.             | Implementation and operation                                                                                                               | 4.4.                          | Implementation and operation                                                                                     |
| 4.5.1.           | General                                                                                                                                    |                               |                                                                                                                  |
| 4.5.2.           | Competence, training and awareness                                                                                                         | 4.4.2.                        | Competence, training and awareness                                                                               |
|                  | Ensuring the necessary competence of emplo- yees and other relevant persons                                                                |                               | Ensuring the necessary qualification of all persons with a potentially significant environmental impact          |
|                  | Determination and documentation of training measures                                                                                       |                               | Identification and implementation of training measu- res; maintenance of relevant documentation                  |
|                  | Ensuring the knowledge of all employees and relevant persons of:                                                                           |                               | Establishment and implementation of a process to ensure that all relevant persons are aware of:                  |
|                  | - The importance of complying with the energy policy and EnMS requirements                                                                 |                               | - The importance of complying with the environmen- tal policy and EMS requirements                               |
|                  | - Individual roles and responsibilities with regard to the EnMS                                                                            |                               | - Individual roles and responsibilities with regard to ensuring compliance with the EMS requirements             |
|                  | - The advantages of improved energy perfor- mance                                                                                          |                               | - The advantages of improving their own perfor- mance                                                            |
|                  | - The actual and potential impact of their own activities on energy use and consumption                                                    |                               | - The actual or potential impact of their own activi- ties on important environmental aspects                    |
|                  | - Potential consequences of nonconformity with established procedures                                                                      |                               | - Potential consequences of nonconformity with established procedures                                            |
| 4.5.3.           | Communication                                                                                                                              | 4.4.3.                        | Communication                                                                                                    |
|                  | Internal communication of energy performance and the EnMS                                                                                  |                               | Internal communication of environmental aspects and the EMS                                                      |

| What should additionally be done with an existing ISO 14001?                                                                     |
|----------------------------------------------------------------------------------------------------------------------------------|
| Generally included                                                                                                               |
| Ensure that you also consider the review methods.                                                                                |
| Generally included; ensure that action plans are updated.                                                                        |
| Ensure that your organisation especially fulfils the energy requirements.                                                        |
| Generally included                                                                                                               |
| Generally included                                                                                                               |
| Generally included                                                                                                               |
| Generally included                                                                                                               |
| Ensure that the advantages of improved energy performance are generally known.                                                   |
| ISO 50001 specifies a bit further; ensure that employees are aware of their own contribution to achieving the energy objectives. |
| Generally included                                                                                                               |
| Generally included; ensure that energy performance is included.                                                                  |
| Ensure that you especially facilitate suggestions for improvement.                                                               |

| ISO 50001:2011   | ISO 50001:2011                                                         | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                            |
|------------------|------------------------------------------------------------------------|-------------------------------|------------------------------------------------------------------------|
| Chapter          |                                                                        | Chapter                       |                                                                        |
|                  | Facilitation of employees' suggestions for improvement                 |                               | Receipt and documentation of and response to exter- nal communication  |
|                  | Decision on external communication and docu- mentation of the decision |                               | Decision on external communication and documenta- tion of the decision |
|                  | If necessary, establishment of a method for external communication     |                               | If necessary, establishment of a method for external communication     |
| 4.5.4.           | Documentation                                                          | 4.4.4.                        | Documentation                                                          |
| 4.5.4.1          | Documentation requirements                                             |                               |                                                                        |
|                  | Implementation of documentation of the core elements of the EnMS       |                               |                                                                        |
|                  | Consideration of:                                                      |                               | The documentation of the EMS must include:                             |
|                  | - Scope and boundaries of the EnMS                                     |                               | - Description of the scope                                             |
|                  | - Energy policy                                                        |                               | - Environmental policy                                                 |
|                  | - Strategic/operational energy objectives and action plans             |                               | - Objectives and targets                                               |
|                  | - Other documents required by the standard                             |                               | - Documents required by the standard                                   |
|                  | - Other necessary documents                                            |                               | - Other necessary documents                                            |
| 4.5.4.2          | Control of documents                                                   | 4.4.5.                        | Control of documents                                                   |
|                  | Establishment and maintenance of a procedure for:                      |                               | Establishment and maintenance of a procedure for:                      |
|                  | - Reviewing the adequacy of documents prior to use                     |                               | - Approving the suitability of documents prior to use                  |
|                  | - Regular evaluation and updating of docu- ments                       |                               | - Evaluation and updating of documents as neces- sary                  |
|                  | - Indication of changes and the current revision status                |                               | - Indication of changes and the current revision status                |
|                  | - Availability of applicable documents where necessary                 |                               | - Ensuring the availability of documents                               |
|                  | - Legibility and identifiability of documents                          |                               | - Legibility and identifiability of documents                          |

| What should additionally be done with an existing ISO 14001?                 |
|------------------------------------------------------------------------------|
| Generally included                                                           |
| Generally included                                                           |
| Generally included; ensure that all energy-relevant documents are available. |
| Implicitly included                                                          |
| Generally included. Ensure that you consider the boundaries of the EnMS.     |
| Generally included                                                           |
| Generally included                                                           |
| Generally included                                                           |
| Generally included                                                           |
| Generally included                                                           |
| Generally included                                                           |
| Generally included                                                           |
| Generally included                                                           |
| Generally included                                                           |

| ISO 50001:2011   | ISO 50001:2011                                                                                                    | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                                                                      |
|------------------|-------------------------------------------------------------------------------------------------------------------|-------------------------------|------------------------------------------------------------------------------------------------------------------|
| Chapter          |                                                                                                                   | Chapter                       |                                                                                                                  |
|                  | - Identification and distribution of relevant external documents                                                  |                               | - Identification and distribution of relevant external documents                                                 |
|                  | - Prevention of the use of obsolete documents and retention of relevant older documents                           |                               | - Prevention of the use of obsolete documents and labelling if retained                                          |
| 4.5.5.           | Operational control                                                                                               | 4.4.6.                        | Operational control                                                                                              |
|                  | Identification and planning of relevant opera- tions and maintenance activities                                   |                               | Identification and planning of relevant operations                                                               |
|                  | Establishment of criteria for effective operation and maintenance in areas of significant energy use              |                               | Establishment and implementation of procedures to prevent deviation from the environmental policy and objectives |
|                  | Operation and maintenance according to the criteria                                                               |                               | Stipulation of operational criteria in the procedures                                                            |
|                  | Information on operational control provided to all employees and other relevant persons                           |                               | Documentation of procedures                                                                                      |
| 4.5.6.           | Design                                                                                                            |                               | No separate item                                                                                                 |
|                  | Consideration of opportunities for improving energy performance in the design of relevant equipment and processes |                               | No requirements                                                                                                  |
|                  | Consideration of the results of the energy performance evaluation in the design of relevant projects              |                               | No requirements                                                                                                  |
|                  | Documentation of the design results                                                                               |                               | No requirements                                                                                                  |
| 4.5.7.           | Procurement of energy services, products, equipment and energy                                                    |                               | No separate item                                                                                                 |
|                  | Informing of suppliers on energy-related purchasing criteria                                                      | 4.4.6.                        | Introduction and implementation of procedures for purchasing and the communication thereof to suppliers          |
|                  | Establishment and implementation of energy- related purchasing criteria                                           |                               | No specific requirements                                                                                         |
|                  | Definition and documentation of specifications for energy purchasing                                              |                               | No specific requirements                                                                                         |
| 4.6.             | Checking                                                                                                          | 4.5.                          | Checking                                                                                                         |

| What should additionally be done with an existing ISO 14001?                                                                                                               |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Generally included                                                                                                                                                         |
| Ensure that all relevant older documents are retained.                                                                                                                     |
| If necessary, broaden the control of your processes and procedures to include energy efficiency.                                                                           |
| Ensure that maintenance activities are included.                                                                                                                           |
| Generally included; ensure that maintenance activities are included.                                                                                                       |
| ISO 50001 places greater emphasis on communication in the context of operational control; expand your communication in this area all relevant employees and other persons. |
| Requirements not included in ISO 14001.                                                                                                                                    |
| Take note of the relevant requirements in ISO 50001.                                                                                                                       |
| Take note of the relevant requirements in ISO 50001.                                                                                                                       |
| Take note of the relevant requirements in ISO 50001.                                                                                                                       |
| ISO 50001 requirements are more detailed; ensure that energy is considered here in your EMS.                                                                               |
| Integrate energy efficiency and energy consumption as additional criteria into your purchasing procedures.                                                                 |
| Ensure to you define and document requirements for the purchasing of energy.                                                                                               |

| ISO 50001:2011   | ISO 50001:2011                                                                                                          | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                                                                                               |
|------------------|-------------------------------------------------------------------------------------------------------------------------|-------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------|
| Chapter          | Chapter                                                                                                                 | Chapter                       | Chapter                                                                                                                                   |
| 4.6.1.           | Monitoring, measurement and analysis                                                                                    | 4.5.1.                        | Monitoring and measurement                                                                                                                |
|                  | Regular monitoring and evaluation of key cha- racteristics that impact energy performance                               |                               | Regular monitoring of key characteristics of opera- tions                                                                                 |
|                  | Consideration of:                                                                                                       |                               | The procedure must include:                                                                                                               |
|                  | - Areas of significant energy use and the results of the energy review                                                  |                               | Not explicitly asked                                                                                                                      |
|                  | - Relevant influential factors in areas of signifi- cant energy use                                                     |                               | Not explicitly asked                                                                                                                      |
|                  | - EnPIs                                                                                                                 |                               | - Performance                                                                                                                             |
|                  | - The effectiveness of action plans with regard to strategic/operational objectives                                     |                               | - Conformity with objectives and targets                                                                                                  |
|                  | - Evaluation of actual energy consumption relative to expectations                                                      |                               | Not explicitly asked                                                                                                                      |
|                  | Documentation of the results of monitoring                                                                              |                               | - Documentation of the information                                                                                                        |
|                  | Definition and implementation of an energy measurement plan                                                             |                               | Not explicitly asked                                                                                                                      |
|                  | Definition of measurement needs and regular monitoring, including the review of measure- ment equipment and calibration |                               | - Ensuring the calibration and monitoring of measu- rement equipment                                                                      |
|                  | Investigation and documentation of any signifi- cant deviations in energy performance                                   |                               | Not explicitly asked                                                                                                                      |
| 4.6.2.           | Evaluation of legal and other requirements                                                                              | 4.5.2.                        | Evaluation of compliance                                                                                                                  |
|                  | Regular evaluation of compliance with legal and other relevant requirements                                             |                               | Regular evaluation of compliance with legal require- ments; evaluation of other relevant requirements                                     |
|                  | Maintenance of records of the results                                                                                   |                               | Maintenance of records of the results                                                                                                     |
| 4.6.3.           | Internal audit of the EnMS                                                                                              | 4.5.5.                        | Internal audit                                                                                                                            |
|                  | Conducting internal audits                                                                                              |                               | Conducting internal audits                                                                                                                |
|                  | Development of an audit plan and schedule un- der consideration of the results of earlier audits                        |                               | Establishment of an audit programme with require- ments for planning and implementation; considerati- on of the results of earlier audits |

| What should additionally be done with an existing ISO 14001?                                                         |
|----------------------------------------------------------------------------------------------------------------------|
| Ensure that monitoring also encompasses energy performance.                                                          |
| Generally included                                                                                                   |
| Implicitly covered, as well as in item A.3.1; make sure that this point is ensured.                                  |
| Take this into consideration in monitoring and measurement.                                                          |
| Generally included. Ensure that monitoring is based on the energy performance indicators.                            |
| Generally included                                                                                                   |
| Generally included. Ensure that you consider the results of monitoring of energy-related performance.                |
| Ensure that an energy measurement plan is developed.                                                                 |
| Largely covered; ensure that you have defined the measurement needs and review them regularly.                       |
| Be sure to investigate and document any significant deviations in energy performance.                                |
| Generally included                                                                                                   |
| Generally included                                                                                                   |
| Generally included; the objectives are somewhat more highly differentiated in ISO 50001.                             |
| Requirements are very similar; ensure that the plans are developed in accordance with the requirements of ISO 50001. |

| ISO 50001:2011   | ISO 50001:2011                                                                                                        | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                                       |
|------------------|-----------------------------------------------------------------------------------------------------------------------|-------------------------------|-----------------------------------------------------------------------------------|
| Chapter          |                                                                                                                       | Chapter                       |                                                                                   |
|                  | Selection of objective auditors                                                                                       |                               | Selection of objective auditors                                                   |
|                  | Documentation of the audit results                                                                                    |                               | Documentation of the audit results                                                |
| 4.6.4.           | Nonconformities, correction, corrective action and preventive action                                                  | 4.5.3.                        | Non-conformity, corrective action and preventive action                           |
|                  | Review of nonconformities                                                                                             |                               | Procedure for addressing nonconformities                                          |
|                  | Determination of causes                                                                                               |                               | Determination of causes                                                           |
|                  | Identification of the need for action, also with a view to preventing nonconformities or their potential reoccurrence |                               | Measures to prevent occurrence and reoccurrence                                   |
|                  | Determination and implementation of necessary countermeasures                                                         |                               | Identification and correction of nonconformities                                  |
|                  | Documentation of corrective and preventative measures                                                                 |                               | Documentation of the results of corrective and preventative measures              |
|                  | Reviewing effectiveness                                                                                               |                               | Reviewing effectiveness                                                           |
|                  | Ensuring the necessary changes to the EnMS                                                                            |                               | Ensuring the necessary changes to the EMS docu- mentation                         |
| 4.6.5.           | Control of records                                                                                                    | 4.5.4.                        | Control of records                                                                |
|                  | Establishment of records on conformity with the EnMS requirements and the standard                                    |                               | Establishment of records on conformity with the EMS requirements and the standard |
|                  | Documentation of energy performance achieve- ments                                                                    |                               | Documentation of results achieved                                                 |
|                  | Establishment of control mechanisms for iden- tifying, retrieving and retaining records                               |                               | Procedures for identifying, protecting and retrieving records                     |
|                  | Legibility, identifiability and traceability of records                                                               |                               | Legibility, identifiability and retrievability of records                         |
| 4.7.             | Management review                                                                                                     | 4.6.                          | Management review                                                                 |
| 4.7.1.           | General                                                                                                               |                               |                                                                                   |
|                  | Regular review of the EnMS by top management                                                                          |                               | Regular review of the EMS by top management                                       |
|                  | Documentation of the management review                                                                                |                               | Documentation of the management review                                            |

| What should additionally be done with an existing ISO 14001?                    |
|---------------------------------------------------------------------------------|
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| You may need to ensure that the necessary changes are made to the EMS yourself. |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |
| Generally included                                                              |

| ISO 50001:2011   | ISO 50001:2011                                                | Requirements ISO 14001:2009   | Requirements ISO 14001:2009                                  |
|------------------|---------------------------------------------------------------|-------------------------------|--------------------------------------------------------------|
| Chapter          |                                                               | Chapter                       |                                                              |
| 4.7.2.           | Input to management review                                    |                               |                                                              |
|                  | Follow-up activities                                          |                               | Follow-up activities                                         |
|                  | Energy policy review                                          |                               | Environmental policy review                                  |
|                  | Review of energy performance and EnPIs                        |                               | The organisation's environmental performance                 |
|                  | Conformity with legal and other requirements                  |                               | Conformity with legal and other requirements                 |
|                  | Degree of achievement of operational and strategic objectives |                               | Degree of achievement of objectives and targets              |
|                  | Results of internal audits                                    |                               | Results of internal audits                                   |
|                  | Status of corrective and preventative measures                |                               | Status of corrective and preventative measures               |
|                  | Predicted energy performance                                  |                               | Projected developments are not explicitly mentioned.         |
|                  | Recommendations                                               |                               | Suggestions for improvement                                  |
| 4.7.3.           | Output from management review                                 |                               | No specific sub-item but results arise from input parameters |

| What should additionally be done with an existing ISO 14001?                                          |
|-------------------------------------------------------------------------------------------------------|
| Generally included                                                                                    |
| Generally included                                                                                    |
| Generally included; you may need to add EnPIs.                                                        |
| Generally included                                                                                    |
| Generally included                                                                                    |
| Generally included                                                                                    |
| Generally included                                                                                    |
| Integrate planned energy use/consumption in your management review.                                   |
| Generally included                                                                                    |
| Generally included. Add the improvements made since the last management review to the results/output. |

<!-- image -->

## ANNEX C: COMPARATIVE TABLE  ISO 50001 AND EMAS

<!-- image -->

ISO 14001 is an essential part of the EMAS-regulation, but as the EMAS regulation goes beyond the regulations of ISO 14001, fewer additional requirements are necessary with an already existing EMAS-validation when introducing ISO 50001. The following table lists items that  EMAS-registered companies can build upon (beyond the additional requirements already indicated in the previous table) if they wish to be certified according to  ISO 50001. 25 In light of the many requirements that are already fulfilled, certification according to ISO 50001 is relatively easy for EMAS companies. In most cases it is only a matter of making adjustments with regard to specific terms for energy consumption and efficiency.

<!-- image -->

## Literature tip

The German EMAS-Advisory Board has prepared a brochure clearly presenting the differences between EMAS and ISO 50001:

http://www.emas.de/fileadmin/user\_upload/06\_service/PDF-Dateien/EMAS-und-DINEN-ISO-50001.pdf

| DIN EN ISO 50001   | DIN EN ISO 50001                                                                                                                                                                                               | EMAS    |                                                                                                                                                                                  |
|--------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chapter            |                                                                                                                                                                                                                | Chapter |                                                                                                                                                                                  |
| 4.1                | General requirements                                                                                                                                                                                           | A.1     | General requirements                                                                                                                                                             |
|                    | Continual improvement of energy performance and the EnMS.                                                                                                                                                      |         | Continual improvement of environmental perfor- mance; energy efficiency as the key indicator.                                                                                    |
| 4.2                | Management responsibility                                                                                                                                                                                      |         | No separate item                                                                                                                                                                 |
| 4.2.1              | Top Management                                                                                                                                                                                                 |         |                                                                                                                                                                                  |
|                    | Top management is responsible for:                                                                                                                                                                             |         | Top management (or simply 'management') is not addressed with its own item in EMAS. Requirements are to be found under various other items:                                      |
|                    | Appointing an energy management representati- ve and approving the energy management team. The 'team' may consist of a single person, for example the management representative (Terms and definitions, 3.10). |         | Corresponds to employee involvement (B.4)                                                                                                                                        |
|                    | Providing the necessary resources for the establishment, implementation, maintenance and improvement of the EnMS and energy performance.                                                                       |         | Commitment to continually improve environmental performance (B.3).                                                                                                               |
|                    | Internally communicating the importance of the EnMS.                                                                                                                                                           |         | Employee participation (B.4.2)                                                                                                                                                   |
|                    | Ensuring appropriate energy performance indicators (EnPIs).                                                                                                                                                    |         | Corresponds to Annex IV C. Energy efficiency required as a core indicator for environmental performance. Other indicators can be additionally used and reported on (Annex IV C). |
|                    | Taking energy performance into consideration in long-term planning.                                                                                                                                            |         | Not specifically required, but for the purpose of con- tinual improvement of environmental performance (B. 3.2).                                                                 |
|                    | Measuring results and reporting on them at fixed intervals.                                                                                                                                                    |         | Environmental reporting (Annex IV)                                                                                                                                               |
| 4.2.2              | Management representative                                                                                                                                                                                      |         | No separate item                                                                                                                                                                 |
|                    | Top management must appoint a sufficiently skilled and competent management represen- tative.                                                                                                                  |         | Appointment of an energy management representa- tive (A.4.1)                                                                                                                     |
|                    | The representative shall have the following responsibility and authority:                                                                                                                                      |         |                                                                                                                                                                                  |

| DIN EN ISO 50001   | DIN EN ISO 50001                                                                                                                                                                                                                                              | EMAS    |                                                                                                                                                                          |
|--------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chapter            |                                                                                                                                                                                                                                                               | Chapter |                                                                                                                                                                          |
|                    | Promoting awareness of the energy policy and objectives at all levels                                                                                                                                                                                         |         | Employee involvement                                                                                                                                                     |
| 4.3                | Energy policy                                                                                                                                                                                                                                                 | A.2     | Environmental policy                                                                                                                                                     |
|                    | To be defined by top management. Substantive criteria:                                                                                                                                                                                                        |         | To be defined by top management. Substantive criteria:                                                                                                                   |
|                    | Contains a commitment to continually improve energy performance.                                                                                                                                                                                              |         | Commitment to continually improve environmental performance (B.3)                                                                                                        |
|                    | Contains a commitment to ensure the provision of the information and resources necessary for reaching strategic and operational objectives.                                                                                                                   |         | Environmental statement as comprehensive informa- tion                                                                                                                   |
|                    | Promotes the purchase of energy-efficient products and services to improve energy per- formance.                                                                                                                                                              |         | Procurement must be taken into account in the EMAS management system (Annex I 2. b, 3. e).                                                                               |
| 4.4                | Energy planning                                                                                                                                                                                                                                               | A.3     | Planning                                                                                                                                                                 |
| 4.4.1              | General                                                                                                                                                                                                                                                       |         | No general item                                                                                                                                                          |
|                    | Conduct and document an energy planning process. The energy planning must be consistent with the energy policy and lead to activities for the con- tinuous improvement of energy performance. Energy-related activities of the organisation must be reviewed. |         | Environmental review; commitment to continually improve environmental performance                                                                                        |
| 4.4.2              | Legal and other requirements                                                                                                                                                                                                                                  | A.3.2   | Legal and other requirements                                                                                                                                             |
|                    | Identify, consider and regularly review legal requirements regarding energy use, consumpti- on and efficiency.                                                                                                                                                |         | Organisation must demonstrate compliance with all applicable environment-related legal requirements (Art.4.4 and Annex II B.2).                                          |
| 4.4.3              | Energy review                                                                                                                                                                                                                                                 | A.3.1   | Environmental aspects                                                                                                                                                    |
|                    | Development, documentation and maintenance of an energy review. Documentation of the methodology and criteria.                                                                                                                                                |         | Environmental review of direct and indirect en- vironmental aspects; evaluation criteria must be comprehensive, reproducible and made available to the public (Annex I): |
|                    | The energy review encompasses the following:                                                                                                                                                                                                                  |         |                                                                                                                                                                          |
|                    | Identify energy sources. Measure, analyse and evaluate energy use and consumption.                                                                                                                                                                            |         | Environmental review of direct environmental as- pects (Annex I, Annex II B.1)                                                                                           |

| DIN EN ISO 50001   | DIN EN ISO 50001                                                                                                                                                                                                                           | EMAS    |                                                                                                                                                                                                                                                                                                                                            |
|--------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chapter            |                                                                                                                                                                                                                                            | Chapter |                                                                                                                                                                                                                                                                                                                                            |
|                    | Identify areas of significant energy use (for ex- ample equipment, facilities, processes, influence of personnel). Define significant areas of energy use. Estimate future energy use and consumption.                                     |         | Environmental review; consideration of past, present and planned activities (Annex I)                                                                                                                                                                                                                                                      |
|                    | Identification and prioritisation of opportunities for improving energy performance.                                                                                                                                                       |         | Commitment to continually improve environmental performance, covered in substance by the internal environmental audit, environmental programme, objectives and management review                                                                                                                                                           |
|                    | Update energy review at fixed intervals and af- ter any major changes (for example in facilities, equipment, processes, et cetera).                                                                                                        |         | Environmental review after any substantial changes, as well as updating of all required EMS elements (Art. 8)                                                                                                                                                                                                                              |
| 4.4.4              | Energy baseline                                                                                                                                                                                                                            |         | Corresponds to EMAS environmental review                                                                                                                                                                                                                                                                                                   |
|                    | Establish energy baseline using information from the initial energy review and drawing upon data on energy use and consumption from an appropriate period of time. Changes in energy performance are to be measured against this baseline. |         | Initial environmental review as baseline (Annex I), updating after any substantial changes (Art. 8). Define core indicators of energy efficiency in the environmental statement (Annex IV).                                                                                                                                                |
| 4.4.5              | Energy performance indicators                                                                                                                                                                                                              |         | Corresponds to EMAS core indicators                                                                                                                                                                                                                                                                                                        |
|                    | Identify appropriate energy performance indicators (EnPIs) and review them regularly. Document and review your methodology.                                                                                                                |         | Core indicators of energy efficiency and other relevant environmental performance indicators in the environmental statement (Annex IV)                                                                                                                                                                                                     |
| 4.4.6              | Energy objectives, energy targets and action plans                                                                                                                                                                                         | A.3.3   | Objectives, targets and programme(s)                                                                                                                                                                                                                                                                                                       |
|                    | Energy objectives and action plans. Action plans must contain statements on the methodology for reviewing improvement of energy performance and confirming the results.                                                                    |         | Objectives associated with significant environmental aspects must be considered in the environmental statement; performance must be evaluated; commit- ment to improve environmental performance (B.3); core and other relevant indicators (Annex IV); yearly presentation in (updated) environmental statement (environmental programme). |
| 4.5                | Implementation and operation                                                                                                                                                                                                               | A.4     | Implementation and operation                                                                                                                                                                                                                                                                                                               |
| 4.5.2              | Competence, training and awareness                                                                                                                                                                                                         | A.4.2   | Competence, training and awareness                                                                                                                                                                                                                                                                                                         |
|                    | Competence and training with regard to energy.                                                                                                                                                                                             |         | Requires greater employee involvement (B.4).                                                                                                                                                                                                                                                                                               |
| 4.5.3              | Communication                                                                                                                                                                                                                              | A.4.3   | Communication                                                                                                                                                                                                                                                                                                                              |

| DIN EN ISO 50001   | DIN EN ISO 50001                                                                                                                                                                                                                                                                   | EMAS    |                                                                                                                                                                                                                                                   |
|--------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chapter            |                                                                                                                                                                                                                                                                                    | Chapter |                                                                                                                                                                                                                                                   |
|                    | Introduce processes to enable the submission of comments or suggestions for improving the EnMS.                                                                                                                                                                                    |         | Employees must be involved in process of continual improvement (B.4.3); use of appropriate forms of participation, for example suggestion systems, group work, environmental committees (B.4.4)                                                   |
|                    | Organisation makes a decision on the external communication of the energy policy, the EnMS and energy performance.                                                                                                                                                                 |         | Commitment to externally communicate and publish the environmental statement (B.5, Annex IV)                                                                                                                                                      |
| 4.5.5              | Operational control                                                                                                                                                                                                                                                                | A.4.6   | Operational control                                                                                                                                                                                                                               |
|                    | Appropriately communicate the operational controls.                                                                                                                                                                                                                                |         | Employee involvement at all levels                                                                                                                                                                                                                |
| 4.5.6              | Design                                                                                                                                                                                                                                                                             |         | No direct equivalent                                                                                                                                                                                                                              |
|                    | Opportunities for improving energy performance must be considered in the design of new, altered or renovated facilities, processes, et cetera that have a significant impact on energy performance. Consider the energy performance evaluation in relevant procurement activities. |         | Product life cycle related aspects should be considered as part of the environmental review. Environmental aspects must be taken into account in procurement (Annex I 2). New environmental review, et cetera after substantial changes (Art. 8). |
| 4.5.7              | Procurement of energy services, products, equipment and energy                                                                                                                                                                                                                     |         | No direct equivalent                                                                                                                                                                                                                              |
|                    | Procurement is to be based in part on energy performance. Suppliers are to be informed of this.                                                                                                                                                                                    |         | Environmental aspects of procurement must be taken into account. It is necessary to consider what measures can be taken to reduce the environmental impact (Annex I 2).                                                                           |
|                    | Requirements must be established for the purchasing of energy. Criteria on energy use, consumption and effici- ency must be established for the procurement of energy-using products, equipment and services.                                                                      |         |                                                                                                                                                                                                                                                   |
| 4.6                | Checking                                                                                                                                                                                                                                                                           | A.5     | Checking                                                                                                                                                                                                                                          |
| 4.6.1              | Monitoring, measurement and analysis                                                                                                                                                                                                                                               | A.5.1   | Monitoring and measurement                                                                                                                                                                                                                        |
|                    | Those characteristics that impact energy perfor- mance must be regularly monitored, measured and analysed, with documentation of the results.                                                                                                                                      |         | Operations with significant environmental impacts are to be monitored, measured and documented.                                                                                                                                                   |
|                    | Areas of significant energy use and the relevant influential factors, results of the energy review, energy performance indicators (EnPIs)                                                                                                                                          |         | Energy efficiency indicator                                                                                                                                                                                                                       |

| DIN EN ISO 50001   | DIN EN ISO 50001                                                                                                                                                | EMAS    | EMAS                                                                                                                                                                              |
|--------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Chapter            |                                                                                                                                                                 | Chapter |                                                                                                                                                                                   |
| 4.6.2              | Evaluation of legal and other requirements                                                                                                                      | A.5.2   | Evaluation of compliance                                                                                                                                                          |
|                    | Basically the same requirements as ISO 14001 (evaluate and document compliance with legal and other requirements).                                              |         | Organisations must demonstrate compliance with all applicable environmental regulations (Art.4.4). Non-conformity must be ruled out prior to the initial registration (Art. 4.4). |
| 4.6.3              | Internal audit of the EnMS                                                                                                                                      | A.5.5   | Internal audit                                                                                                                                                                    |
|                    | Requirements for the internal audit. Audit should be conducted of whether: • the EnMS is consistent with the energy objectives • energy performance is improved |         | Environmental audit requires an evaluation of envi- ronmental performance and whether the environ- mental objectives have been achieved (Annex III B).                            |
| 4.6.4              | Nonconformities, correction, corrective action and preventive action                                                                                            | A.5.3   | Non-conformity, corrective action and preventive action                                                                                                                           |
|                    | Regulations on non-conformities.                                                                                                                                |         | Non-conformity must be ruled out prior to the initial registration; participation of environmental authori- ties (Art. 32.5)                                                      |

| DIN EN ISO 50001   | DIN EN ISO 50001                                                                                                                           | EMAS    | EMAS                                                                                                                              |
|--------------------|--------------------------------------------------------------------------------------------------------------------------------------------|---------|-----------------------------------------------------------------------------------------------------------------------------------|
| Chapter            |                                                                                                                                            | Chapter |                                                                                                                                   |
| 4.6.5              | Control of records                                                                                                                         | A.5.4   | Control of records                                                                                                                |
|                    | Requirements for records. Documentation should also serve to demonstra- te the results of energy performance.                              |         | Environmental performance must be evaluated as part of the management review (B.3), and published in the environmental statement. |
| 4.7                | Management review                                                                                                                          | A.6     | Management review                                                                                                                 |
| 4.7.3              | Output from management review                                                                                                              |         |                                                                                                                                   |
|                    | Requirements for the results of the management review. Consideration of energy performance indicators (EnPIs) and allocation of resources. |         | Environmental performance must be evaluated (B.3.2), including the core indicators.                                               |

## 8 LIST OF ABBREVIATIONS:

| BAFA    | Federal Office of Economics and Export Control                                                                                                                                                                                 |
|---------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| BAT     | Best Available Techniques                                                                                                                                                                                                      |
| BimSchV | Federal Immission Control Act                                                                                                                                                                                                  |
| BMU     | Federal Ministry for the Environment, Nature Conservation and Nuclear Safety                                                                                                                                                   |
| BMW     | Bavarian Motor Works                                                                                                                                                                                                           |
| BMWi    | Federal Ministry of Economics and Technology                                                                                                                                                                                   |
| CEN     | European Committee for Standardization                                                                                                                                                                                         |
| CHP     | Combined Heat and Power                                                                                                                                                                                                        |
| CO 2    | Carbon dioxide                                                                                                                                                                                                                 |
| CO 2 eq | CO 2 equivalent; stands for the climate impact of all the greenhouse gases combined, whereby carbon dioxide serves as a benchmark; the other greenhouse gases are correspondingly calculated per specific impact in ppm CO 2 . |
| CSR     | Corporate Social Responsibility                                                                                                                                                                                                |
| DAU     | Deutsche Akkreditierungs- und Zulassungsgesellschaft für Umweltgutachter GmbH                                                                                                                                                  |
| dena    | German Energy Agency                                                                                                                                                                                                           |
| EDL-G   | Act on Energy Services and Energy Efficiency Measures                                                                                                                                                                          |
| EEAP    | Energy Efficiency Action Plan                                                                                                                                                                                                  |
| EEG     | Renewable Energy Sources Act                                                                                                                                                                                                   |
| EM      | Energy Manager                                                                                                                                                                                                                 |
| EMAS    | Eco-Management and Audit Scheme                                                                                                                                                                                                |
| EMS     | Environmental Management System                                                                                                                                                                                                |
| EnEG    | Energy Saving Act                                                                                                                                                                                                              |
| EnEV    | Energy Saving Regulation                                                                                                                                                                                                       |
| EnMS    | Energy management system(s)                                                                                                                                                                                                    |
| EnPI    | Energy performance indicator                                                                                                                                                                                                   |
| ERP     | Enterprise Resource Planning                                                                                                                                                                                                   |
| EuPA    | Energy-using Products Act                                                                                                                                                                                                      |
| GJ      | Gigajoule = 1 billion joules = 1,000,000,000 joules                                                                                                                                                                            |
| HACCP   | Hazard Analysis and Critical Control Point                                                                                                                                                                                     |
| IEF-STE | Forschungszentrum Jülich, Institut für Energieforschung - Systemforschung und Technologische Entwicklung                                                                                                                       |
| IHK     | Chamber of Industry and Commerce                                                                                                                                                                                               |

| ISO/TC   | Technical Committee (TC) of the International Organization for Standardization (ISO)   |
|----------|----------------------------------------------------------------------------------------|
| KfW      | Kreditanstalt für Wiederaufbau                                                         |
| kWh      | Kilowatt hour = 1,000 watts · hour                                                     |
| MWh      | Megawatt hour = 1,000,000 watt · hour                                                  |
| NAGUS    | Principles of the Environmental Protection Standards Committee                         |
| NRW      | North Rhine-Westphalia                                                                 |
| OHSAS    | Occupational Health and Safety Assessment Series                                       |
| PDCA     | Plan-Do-Check-Act                                                                      |
| PQ       | Production quantity                                                                    |
| PU       | Production unit                                                                        |
| QM       | Quality management                                                                     |
| QMS      | Quality management system                                                              |
| SAP      | Systeme Anwendungen Produkte Aktiengesellschaft                                        |
| SME      | Small and medium-sized enterprises                                                     |
| SMS      | Security management                                                                    |
| t        | Unit of weight: ton = 1,000 kg                                                         |
| UBA      | Federal Environment Agency                                                             |
| UGA      | German EMAS Advisory Board                                                             |
| VOC      | Volatile Organic Compounds                                                             |

## NOTES

## NOTES