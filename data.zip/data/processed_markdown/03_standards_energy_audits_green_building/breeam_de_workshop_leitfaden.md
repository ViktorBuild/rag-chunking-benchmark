---
document_id: breeam_workshop_guidance
title: "BREEAM Bestand: Auftakt- und Abschlussworkshop Leitfaden"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "BREEAM D-A-CH"
year: 2021
original_file: "breeam_de_workshop_leitfaden.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

Dok.Nr.: SD002-DE

## SD002-DE Systemdokument

## Prozess zum Auftakt- und Abschlussworkshop

<!-- image -->

## 1. ZIEL

Ziel dieses Prozesses ist es sicherzustellen, dass der Auftakt- und Abschlussworkshop, der wesentlicher Bestandteil des Auditprozesses ist, auf einheitliche und konsistente Weise durchgeführt wird.

## 2. UMFANG

Dieser  Prozess  umfasst  alle  Auftakt-  und  Abschlussworkshops,  die  durch  den  Auditor  während  des  Audits  zum Zertifikat oder Re-Zertifikat durchgeführt werden,

## 3. VERANTWORTLICHKEITEN

Auditoren sind verantwortlich dafür:

-  dass der Auftakt- und Abschlussworkshop nach den hier beschriebenen Prozessen durchgeführt wird;
-  dass Aspekte des Gesundheits- und Sicherheitsschutzes eingehalten werden; und
-  dass Protokolle der Workshops erstellt werden.

## 4. GESUNDHEIT UND SICHERHEIT

Das zu besichtigende Unternehmen ist verantwortlich  für den  sicheren  Zugang von  Räumlichkeiten, einschließlich, aber nicht begrenzt auf, die Bereitstellung von Informationen über alle Gefahren, die ein Risiko für die Gesundheit und Sicherheit darstellen können.

## 5. VORGEHENSWEISE

## 5.1 Auftaktworkshop

Ein Auftaktworkshop wird mit den Verantwortlichen des Unternehmens durchgeführt und soll Folgendes enthalten:

-  Einführung des Auditors und seiner Rolle
-  Inhalte des Audits und mögliches Ergebnis des Audits
-  Erläuterung der Inhalte des Begehungsprotokolls
-  Festlegung des Zeitrahmens der Begehung und des Abschlussworkshops
-  Definition von Zuständigkeiten
-  Klärung der Vertraulichkeit im Hinblick auf die gesamte Dokumentation und Informationssammlung während der Begehung;
-  Zugang zum Gebäude bei der Ortsbegehung
-  Zugang zu erforderlichen Dokumenten und Räumen
-  Abklärung der Sicherheits- und Gesundheitsaspekte bei der Begehung

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 1 von 2

Datei: SD002-DE\_BREEAM DE Bestand

Auftakt-Abschlussworkshop

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

Dok.Nr.: SD002-DE

## SD002-DE Systemdokument

## Prozess zum Auftakt- und Abschlussworkshop

## 5.2 Abschlussworkshop

Ein Abschlussworkshop wird mit den Verantwortlichen des Unternehmens durchgeführt:

-  Feedback zur Zusammenarbeit
-  Bestätigung, welche Bereiche während des Audits begangen wurden
-  Einfordern von fehlenden Unterlagen
-  Bestätigung,  dass  alle  notwendigen  Schritte  für  die  Verifizierung  unternommen  wurden  bzw.  Erläuterung, warum eine weitere Ortsbegehung notwendig ist;
-  Beantwortung von offenen Fragen und
-  Formale Beendigung des Audits.

## 6. BELEGE

Protokolle des Auftakt- und Abschlussworkshops müssen als Anlage zum Auditbericht eingereicht werden.

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 2 von 2

Datei: SD002-DE\_BREEAM DE Bestand

Auftakt-Abschlussworkshop

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->