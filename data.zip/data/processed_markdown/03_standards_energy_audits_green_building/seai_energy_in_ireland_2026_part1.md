---
document_id: seai_energy_in_ireland_2026_p1
title: "Energy in Ireland 2026: Part 1 - Macro Energy Balances"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2026
original_file: "seai_energy_in_ireland_2026_part1.pdf"
tables_detected: 7
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## ENERGY IN IRELAND 2026

Part  1  - Summary  and  Technical  Highlights

<!-- image -->

<!-- image -->

## - Summary &amp; Technical Highlights

## Energy in Ireland 2026 Part 1

## Energy in Ireland 2026

Part 1 - Summary &amp; Technical Highlights

October 2026

ID: EII-2026-P1-1.0

## Sustainable Energy Authority of Ireland

SEAI is Ireland's national energy authority investing in, and delivering, appropriate, effective and sustainable solutions to help Ireland's transition to a clean energy future. We work with the public, businesses, communities and the Government to achieve this, through expertise, funding, educational programmes, policy advice, research and the development of new technologies.

SEAI is funded by the Government of Ireland through the Department of Climate, Energy and the Environment.

© Sustainable Energy Authority of Ireland

Reproduction of the contents is permissible provided the source is acknowledged.

## Acknowledgements

SEAI gratefully acknowledges the continued cooperation and assistance of the organisations, agencies, energy suppliers, and distributors that provide data and respond to questionnaires throughout the year. Their timely contributions play a vital role in enabling the production of accurate, comprehensive, and high-quality energy statistics for Ireland.

## Foreword

Each year SEAI publishes this definitive report on Ireland's energy statistics. One year of data tells us a snapshot, but our ability to view these statistics over many years provides invaluable insights into Ireland's energy.  As I write this year's foreword, we are drawing close to the end of 2026.  A year that presented real challenges to energy costs for people in their homes and businesses as increasing risks to energy supply and security continued to realise due to global events.

This year's update to our energy scoreboard shows that while progress is being made, the pace of change remains far below what is required, and that matters for affordability and energy security as well as for our emissions.

<!-- image -->

Energy-related emissions continue to fall to a record low and renewable energy continued to grow. These are important achievements and demonstrate Ireland's transition is underway. Yet the pace isn't fast enough, and that is also because our energy demand continues to grow. Energy consumption is at the highest level since 2008, dependence on imported fossil fuels remains high, and Ireland continues to face significant challenges in meeting its climate and energy security objectives.

The evidence in this report points to a simple but uncomfortable truth: the energy transition cannot succeed if renewable deployment is running to stand still against rising demand.

We know the technologies needed to reduce emissions. Wind, solar, heat pumps, electric vehicles and energy efficiency are already delivering results. This report points to how that is happening now, with the right supports in place.  But Ireland's challenge is not simply a technology challenge. It is a systems challenge.

How we plan transport, deliver housing, build infrastructure, regulate energy markets and support a thriving society for all will determine our energy future. Decisions on the scale and location of major energy users, including large new electricity demands, such as data centres, must also be considered through the lens of energy security, affordability and climate objectives. Today's choices by government and society will shape energy demand, emissions, and energy security for decades to come.

People have shown they are willing to act when viable alternatives are available. The next phase requires faster delivery of infrastructure, with an enhanced policy package and investment to make sustainable energy the easiest and most affordable choice, while addressing rising energy demand and energy waste with urgency.

The benefits of moving faster are substantial. A more efficient Ireland powered increasingly by indigenous renewable energy would be more secure, more competitive and less exposed to international fossil fuel price shocks.

This report contributes to the evidence base for the decisions that need to be made. The message from this year's scoreboard is clear: Ireland is making progress, but progress is not the same as success. The gap between where we are and where we need to be is widening. Closing that gap will require decisive action, sustained investment and a renewed sense of urgency across the whole of government and society.

A widening gap will result in bigger challenges and greater costs in the long run.  If we move at the scale and speed required, the rewards are clear: a cleaner, more secure and more affordable energy future.

## Contents

| Acknowledgements................................................................................................................................................. 1          | Acknowledgements................................................................................................................................................. 1          | Acknowledgements................................................................................................................................................. 1          | Acknowledgements................................................................................................................................................. 1   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Foreword..................................................................................................................................................................   | Foreword..................................................................................................................................................................   | Foreword..................................................................................................................................................................   | 2                                                                                                                                                                     |
| Contents ................................................................................................................................................................... | Contents ................................................................................................................................................................... | Contents ................................................................................................................................................................... | 3                                                                                                                                                                     |
| Technical Highlights................................................................................................................................................         | Technical Highlights................................................................................................................................................         | Technical Highlights................................................................................................................................................         | 4                                                                                                                                                                     |
| 1                                                                                                                                                                            | Ireland's Key Energy Trends in 2025 and 2026.........................................................................................                                        | Ireland's Key Energy Trends in 2025 and 2026.........................................................................................                                        | 5                                                                                                                                                                     |
| 2                                                                                                                                                                            | Energy-Related Emissions ...........................................................................................................................                         | Energy-Related Emissions ...........................................................................................................................                         | 7                                                                                                                                                                     |
| 3                                                                                                                                                                            | Supply and Demand of Energy.................................................................................................................                                 | Supply and Demand of Energy.................................................................................................................                                 | 12                                                                                                                                                                    |
|                                                                                                                                                                              | 3.1                                                                                                                                                                          | Energy Supply Trends .....................................................................................................................                                   | 13                                                                                                                                                                    |
|                                                                                                                                                                              | 3.2                                                                                                                                                                          | Energy Demand Trends..................................................................................................................                                       | 16                                                                                                                                                                    |
|                                                                                                                                                                              | 3.3                                                                                                                                                                          | Supply and Demand of Electricity .................................................................................................                                           | 20                                                                                                                                                                    |
|                                                                                                                                                                              | 3.3.1 Electricity                                                                                                                                                            | 3.3.1 Electricity                                                                                                                                                            | Supply Trends.................................................................................................................20                                      |
|                                                                                                                                                                              | 3.3.2 Electricity                                                                                                                                                            | 3.3.2 Electricity                                                                                                                                                            | Demand Trends..............................................................................................................26                                         |
|                                                                                                                                                                              | 3.4                                                                                                                                                                          | Transport Energy Demand.............................................................................................................                                         | 28                                                                                                                                                                    |
|                                                                                                                                                                              | 3.5                                                                                                                                                                          | Heat Demand...................................................................................................................................                               | 31                                                                                                                                                                    |
|                                                                                                                                                                              | 3.5.1 Overall                                                                                                                                                                | 3.5.1 Overall                                                                                                                                                                | Heat Demand .....................................................................................................................31                                   |
|                                                                                                                                                                              | 3.5.2                                                                                                                                                                        | 3.5.2                                                                                                                                                                        | Residential Heat Demand...............................................................................................................33                              |
| 4                                                                                                                                                                            | Ireland's EU Energy Targets ......................................................................................................................                           | Ireland's EU Energy Targets ......................................................................................................................                           | 36                                                                                                                                                                    |
|                                                                                                                                                                              | 4.1                                                                                                                                                                          | Renewable Energy Directive Targets............................................................................................. 36                                           |                                                                                                                                                                       |
|                                                                                                                                                                              | 4.1.1                                                                                                                                                                        | 4.1.1                                                                                                                                                                        | Overall Renewable Energy Share (RES-Overall)............................................................................36                                            |
|                                                                                                                                                                              | 4.1.2                                                                                                                                                                        | 4.1.2                                                                                                                                                                        | Renewable Energy Share in Electricity (RES-E)..............................................................................37                                         |
|                                                                                                                                                                              | 4.1.3                                                                                                                                                                        | 4.1.3                                                                                                                                                                        | Renewable Energy Share in Transport (RES-T) .............................................................................38                                           |
|                                                                                                                                                                              | 4.1.4                                                                                                                                                                        | 4.1.4                                                                                                                                                                        | Renewable Energy Share in Heating (RES-H) ................................................................................39                                          |
| 4.2                                                                                                                                                                          | Energy Efficiency Directive Targets ...............................................................................................                                          | Energy Efficiency Directive Targets ...............................................................................................                                          | 40                                                                                                                                                                    |
| Appendix 1: Version control ................................................................................................................................                 | Appendix 1: Version control ................................................................................................................................                 | Appendix 1: Version control ................................................................................................................................                 | 41                                                                                                                                                                    |

## Technical Highlights

## Energy-related Emissions

- · Ireland's national energy-related emissions in 2025 were at their lowest level in over 30 years.
- · Energy-related emissions in 2025 were down 18.8% on 2018-levels, the carbon budget baseline.
- · Energy-related emissions in 2025 were 29.8 MtCO2eq, down 3.6% on 2024-levels.
- · Electricity accounted for 21.1% of energy emissions, transport for 38.9%, and heat for 40.0%.
- · 2025 electricity emissions were 6.3 MtCO2eq, the lowest on record, down 8.5% on 2024-levels.
- · 2025 transport emissions were 11.6 MtCO2eq, down 1.5% on 2024-levels.
- · 2025 heat emissions were 11.9 MtCO2eq, down 2.8% on 2024-levels.
- o Provisional analysis indicates 5% lower energy-related emissions in H1-2026 compared to H1-2025.
- o Analysis shows electricity and transport emissions in H1-2026 trending above their SEC allocations.

## Renewable Energy

- · 16.0% of Ireland's primary energy was renewable in 2025 - the highest value to date.
- · Ireland used 1.84 TWh more renewable energy in 2025 than in 2024.
- · Just under three-quarters of renewable energy in 2025 came from wind, biodiesel, and biomass.
- · Solar PV generation was up 50% and ambient heat capture from heat-pumps was up 18% in 2025.
- · In 2025, Ireland's RES-Overall result was 17.3%, up from 16.1% in 2024 - the highest value to date.
- · Ireland's RES-Overall result was 10.3 percentage points behind its 27.6% milestone target in 2025.

## Transport Energy

- · Fossil fuels accounted for 91.9% of energy consumed for transport in 2025.
- · The road and air modes accounted for 74.1% and 22.9% of transport energy demand, respectively.
- · Energy consumption in private cars in 2025 was the highest ever recorded.
- · Energy demand from HGV road freight increased by 10.5% in 2025 to the highest level since 2008.
- · 9.7% of energy in road diesel, and 6.5% in road petrol, came from renewable biofuels in 2025.
- o Provisional analysis indicates 10.7% higher aviation fuel demand in H1-2026 compared to H1-2025.

## Electricity Supply

- · Gas (40.0%), wind (32.1%), and net imports (16.3%) led Ireland's gross electricity supply in 2025.
- · The biggest increases came from net imports (+1.1 TWh), solar PV (+0.6 TWh) and wind (+0.4 TWh).
- · Fossil generation accounted for 41.9% of electricity supply in 2025 - the lowest value to date.
- · Ireland's 2025 RES-Electricity result was 41.8%, up half a percentage point from 2024.

## Electricity Demand

- · Electricity demand in Ireland was 34.1 TWh in 2025, up 3.7% on 2024-levels.
- · Commercial services, which includes the ICT sub-sector, accounted for 42.1% of electricity demand.
- · The residential sector accounted for 24.8% of electricity demand in 2025.
- · Data centres accounted for 22.5% of all electricity demand in 2025.
- · Data centres account for 78% of the net increase in Ireland's electricity between 2015 and 2025.

## Heat Demand

- · Heat demand accounted for 34.2% of Ireland's energy demand in 2025.
- · Ireland's heat demand in 2025 was 49.4 TWh, down 2.2% on 2024-levels.
- · The residential (43.6%) and industry (37.1%) sectors accounted for over 80% of heat demand.
- · In 2025, 88.6% of heat demand was satisfied using fossil fuels.
- · Ireland's residential heat demand in 2025 was 21.5 TWh, down 3.7% on the previous year.
- o Provisional analysis shows kerosene deliveries were 11% lower in H1-2026 compared to H1-2025.

## 1 Ireland's Key Energy Trends in 2025 and 2026

SEAI's Energy in Ireland 2026 report delivers a comprehensive statistical analysis of Ireland's energy system, covering supply, transformation, and end-use demand. It provides clear quantitative breakdowns of the fuels and economic sectors driving energy-related emissions, the composition of Ireland's energy mix, and the supply-streams satisfying our national energy requirements.

Figure 1.1: Key high-level insights on Ireland's greenhouse gas (GHG) emissions, the national energy mix, Ireland's energy import dependency, and the electrification of energy demand.

<!-- image -->

The publication of this year's Energy in Ireland report has been accelerated into October 2026 to better coincide with the publication of the National Energy Balance and the availability of provisional monthly energy and emission data from the first 6-months of 2026.

SEAI's Energy in Ireland report provides a strong evidence base for discussions and actions around key pillars of Ireland's energy transition:

- 1. National Carbon Budgets - December 2025 marked the end of Ireland's first national carbon budget (2021-2025), with clear sectoral emissions ceilings (SECs) for energy-related emissions in electricity, transport, built environment, etc.
- 2. Renewable Energy Directive Targets - The end of 2025 was the precise midpoint of the 20202030 decade in which Ireland has committed to raising its renewable energy share to 43.0%, in line with the requirements of the third EU Renewable Energy Directive (RED-III).
- 3. Energy Efficiency Directive Targets - Ireland has committed to make sincere cooperative efforts to limit its total final energy consumption to 10.451 Mtoe by 2030, under Article 4 of the EU Energy Efficiency Directive (EED) - achieving this will require 3% annual reductions for the next 5 years.

SEAI's Energy in Ireland 2026 report delivers both high-level summaries, detailed data, and technical appendices. For the reader's convenience, the report has been broken into three parts:

- · Part 1 -Summary &amp; Technical Highlights - Provides a summary of key energy trends and observations from 2025 and 2026, blending definitive annual data from the 2025 National Energy Balance with provisional monthly data from January to June 2026.
- · Part 2 -Monthly Energy Data to June 2026 - Provides timely data on monthly energy supply statistics (electricity, gas and oil), monthly estimates of energy quantities used in transformation processes, 'own use' and final demand, as well as monthly estimates of relevant energy-related emissions.
- · Part 3 -Annual Energy Statistics to 2025 - Provides detailed quantitative descriptions of Ireland's primary energy, energy transformations, final energy demand, energy-related emissions, as well as technical details on active energy targets and policy, and relevant appendices, glossaries, and conversion factors.

To ensure strong alignment between SEAI's reporting of energy-related emissions, the sectoral emissions ceilings (SECs) under Ireland's national carbon budgets, and the Environmental Protection Agency's (EPA) Greenhouse Gas Emissions (GHG) Inventory compiled in accordance with IPCC guidelines, the Energy in Ireland report presents energy-related emissions in terms of megatonnes of carbon dioxide equivalent (MtCO eq). ₂

Expressing emissions in MtCO eq provides a more comprehensive measure of climate impact than in ₂ MtCO  only, as it captures the global warming effects of methane and nitrous oxide alongside those of ₂ carbon dioxide.

## 2 Energy-Related Emissions

Ireland's national energy-related emissions in 2025 were 29.8 MtCO2eq, down 3.6% on the previous year. Ireland's national energy-related emissions, as reported in the EPA's Greenhouse Gas (GHG) Inventory and as used in the carbon budgets, do not include emissions associated with international aviation or international maritime transport 1 .

Ireland's national energy-related emissions in 2025 were at a record low - it is the first time on record they were below 30 MtCO2eq. Energy-related emissions in 2025 were down 18.8% on 2018 levels, the baseline year for the calculation of the national carbon budgets and Ireland's overall 2030 emission reduction target. Energy-related emissions in 2025 were down 34.6% on their peak 2005 levels.

Figure 2.1: Time-series of Ireland's national energy-related emissions since 1990

<!-- image -->

SEAI analysis of provisional monthly energy supply data indicates that national energy-related emissions were around 5% lower in the first half of 2026 compared to the same period in 2025. However, it is too early to draw conclusions about full-year emissions for 2026, as outcomes for the full year will depend on weather conditions and other factors influencing energy demand during the second half of the year. For more details on monthly energy-related emissions, see Part 2 - Section 5 .

Figure 2.2: Provisional monthly national energy-related emissions from January 2025

<!-- image -->

To gain deeper insights, the total energy-related emissions can be broken out into the high-level Climate Action Plan (CAP) sectors of transport emissions and electricity emissions (as those are defined

1 These international emissions are calculated and reported separately in accordance with guidance from United Nations Framework Convention on Climate Change (UNFCCC) and the Intergovernmental Panel on Climate Change (IPCC).

in the national Carbon Budgets ), and all other remaining 'heat' emissions 2 . While the transport and electricity sectors have well defined Sectoral Emission Ceilings (SECs) in the carbon budget framework, there are no explicit targets for national energy-related emissions or the heat emissions 3 .

Using the sector breakout, we see that the largest decrease in annual energy-related emissions between 2018 and 2025 came from electricity. Electricity sector emissions in 2025 were 6.3 MtCO eq, ₂ down 3.9 MtCO eq or 38.0% on 2018 levels. In contrast, the smallest decrease in annual energy-related ₂ emissions between 2018 and 2025 came from the transport sector. Transport emissions in 2025 were 11.6 MtCO eq, down 0.8 MtCO eq or 6.4% on 2018 levels. ₂ ₂

While overall energy-related emissions have fallen steadily in recent years, SEAI's National Energy Projections 2026 4 report indicates that the pace of these reductions is not sufficient to deliver on Ireland's legally binding carbon budgets, even under the most optimistic policy and measure scenarios considered by SEAI's modelling.

Figure 2.3: Waterfall plot showing 2018 to 2025 changes in national energy-related emissions

<!-- image -->

The high-level breakout of Ireland's national energy-related emissions in 2025 are 6.3 MtCO2eq (21.1%) from electricity, 11.6 MtCO2eq (38.9%) from transport, and 11.9 MtCO2eq (40.0%) from heat.

Figure 2.4: Breakout of 2025 national energy-related emissions across high-level sectors

<!-- image -->

In absolute terms, national energy-related emissions in 2025 were down 1.1 MtCO2eq on the previous year. All high-level energy sector emissions decreased in 2025. Electricity emissions decreased by 0.59 MtCO2eq (-8.5%), heat emissions decreased by 0.34 MtCO2eq (-2.8%) and transport emissions decreased by 0.17 MtCO2eq (-1.5%). For more details on energy-related emissions, see Part 3 - Section 6 .

Figure 2.5: Waterfall plot showing 2024 to 2025 changes in national energy-related emissions

<!-- image -->

The largest contributor to the reduction in energy-related emissions in 2025 was the decrease in emissions from the electricity sector. Despite increased electricity consumption in Ireland, electricity emissions fell to their lowest level on record due to a combination of factors:

- 1. Reduced generation of electricity from fossil fuels (-0.6 TWh)
- 2. Increased generation of electricity from renewable sources (+0.87 TWh)
- 3. Greater net imports of electricity via interconnectors with Northern Ireland and Great Britain emissions associated with internationally imported electricity are not counted towards Ireland's national emissions and carbon budgets.

Ireland's gross electricity supply, which is the electricity supply needed to satisfy end-user consumption of electricity, increased by 1.33 TWh or 3.7% in 2025. However, Ireland's net indigenous generation of electricity increased by just 0.26 TWh or 0.8% in 2025. Ireland continued to make use of increasing levels of net imports across international interconnectors (IC Electr.) to increase electricity supply in 2025. Net imports of electricity in 2025 were up 1.07 TWh or 21.1% on the previous year.

Figure 2.6: Waterfall plot showing 2024 to 2025 changes in Ireland's gross electricity supply

<!-- image -->

Ireland's electricity sector emissions for the national carbon budgets are officially determined by the EPA and based on data from the Greenhouse Gas (GHG) Inventory . The EPA have reported electricity SEC emissions of 9.8 MtCO2eq, 9.6 MtCO2eq, 7.5 MtCO2eq, 6.9 MtCO2eq, and 6.3 MtCO2eq for the five years of the first carbon budget (2021-2025), respectively. This data indicates an overshoot of 0.12 MtCO2eq for the electricity sector against its 40 MtCO2eq sectoral emission ceiling in the first carbon budget.

Figure 2.7: Reported electricity sector emissions in the first carbon budget

<!-- image -->

The EPA have reported transport SEC emissions of 11.2 MtCO2eq, 11.9 MtCO2eq, 11.9 MtCO2eq, 11.8 MtCO2eq, and 11.6 MtCO2eq for the five years of the first carbon budget (2021-2025), respectively. This data indicates an overshoot of 4.4 MtCO2eq for the transport sector against its 54 MtCO2eq sectoral emission ceiling in the first carbon budget.

Figure 2.8: Reported transport sector emissions in the first carbon budget

<!-- image -->

Further details on the national carbon budgets and SECs are provided in Part 3 - Section 7.1.2.

SEAI analysis of provisional monthly data can provide early estimates of electricity and transport sector emissions for the first half of 2026 - the first six months of Carbon Budget 2 (2026-2030). These emissions estimates can be compared with an equivalent monthly SEC allocation to make a simple assessment on whether emissions are tracking above or below their implied carbon budget pathways:

- · Electricity: 0.333 MtCO eq equivalent monthly allocation, based on a five-year SEC of 24 MtCO eq ₂ ₂ spread evenly across 60 months.
- · Transport: 0.617 MtCO eq equivalent monthly allocation, based on a five-year SEC of 37 MtCO eq ₂ ₂ spread evenly across 60 months.

This simple comparison assumes that each sector's SEC is distributed evenly across the 5-year duration of the carbon budget period. In practice, emissions are expected to reduce over time, as additional policies and measures take effect, meaning the actual emissions pathway is unlikely to be uniform. Nevertheless, this simple analysis provides a useful 'early indication' on whether electricity and

transport emissions are broadly tracking to the rate of reduction required to remain within their respective SECs under Carbon Budget 2.

SEAI estimates that the electricity sector emitted 2.8 MtCO eq during the first six months of 2026, ₂ approximately 39% above its equivalent six-month SEC allocation of 2.0 MtCO eq under the second ₂ carbon budget.

## Figure 2.9: Provisional monthly electricity sector emissions from January 2026

<!-- image -->

SEAI also estimates that the transport sector emitted 5.6 MtCO eq during the first six months of 2026, ₂ approximately 51% above its equivalent six-month SEC allocation (3.7 MtCO eq) under the second ₂ carbon budget.

## Figure 2.10: Provisional monthly transport sector emissions from January 2026

<!-- image -->

While this provisional analysis of the first six months of data provides an early indication of emissions trends, conclusions on 2026 energy-related emissions should await the publication of official full-year data. The EPA is the competent authority responsible for compiling and publishing Ireland's official greenhouse gas emissions estimates. For more details on monthly energy-related emissions, see Part 2 - Section 5 .

## 3 Supply and Demand of Energy

Ireland's total primary energy requirement in 2025 was 163.1 TWh, down 2.2% on the previous year. Total primary energy requirement can be thought of as Ireland's energy supply . It is the amount of 'raw' energy that Ireland needs to secure to satisfy down-stream end-user demand across the economy. It includes all the energy that goes directly to end-users, as well as crude oil that is first processed in Ireland into oil-products, like diesel and petrol used on our roads, and the natural gas and coal fed into power plants to generate electricity.

Ireland's total final energy consumption in 2025 was 144.6 TWh, up 0.6% on the previous year. This is the highest level of energy consumption recorded in Ireland since 2008 - the end of the Celtic Tiger period, immediately before the sharp economic contraction associated with the collapse of the property market and the onset of the global financial crisis.

Total final energy consumption can be thought of as Ireland's energy demand . It is the amount of energy directly consumed by end-users in the Irish economy. It excludes all transformation, distribution, and other losses associated with the processing and delivery of primary energy to final end-users.

Figure 3.1: Illustration of the relationship between Ireland's total primary energy requirement ( i.e. energy supply) and Ireland's total final energy consumption ( i.e. energy demand)

<!-- image -->

Understanding the distinction between energy supply and energy demand, and how they influence each other, helps interpret the dynamics of Ireland's energy system and provides a more complete picture of the national energy landscape.

## 3.1 Energy Supply Trends

Fossil fuels continued to dominate Ireland's energy supply in 2025, accounting for 79.1% of the 163.1 TWh total. However, the contribution of fossil fuels to the supply mix is falling slowly - down from 96.6% in 2005 and 90.8% in 2015.

In 2025, the three largest energy products contributing to the national energy supply were oil (47.2%), natural gas (29.8%), and renewable energy (16.0%).

Figure 3.2: Breakout of 2025 energy supply across energy products. The term 'NRW' stands for non-renewable wastes

<!-- image -->

Ireland's energy supply decreased by 3.61 TWh in 2025 relative to the previous year. Consumption of all major fossil fuels declined, including oil (-4.05 TWh), coal (-1.46 TWh) and natural gas (-1.02 TWh). These reductions were partly balanced by increased use of renewable energy (+1.84 TWh), higher net imports of electricity through international interconnectors (+1.07 TWh), and greater use of non-renewable wastes (NRW). For more detailed breakdowns of energy supply, see Part 3 - Section 2 .

Figure 3.3: Waterfall plot showing 2024 to 2025 changes in Ireland's energy supply. The term 'NRW' stands for non-renewable wastes, and 'IC Electr.' stands for net imports of electricity through international interconnectors

## 2024 to 2025 Changes in Total Primary Energy Requirement (TWh)

<!-- image -->

Ireland's renewable energy supply in 2025 was 26.1 TWh, up 7.6% on the previous year. Ireland's renewable energy supply in 2025 was the highest on record - both in absolute and relative terms. Since about 2004, Ireland has added an average of just under 1.1 TWh of renewable energy per year to its primary energy supply.

Figure 3.4: Time-series of Ireland's Renewable Primary Energy Requirement with a linear fit to the increases observed since 2004

<!-- image -->

Ireland's renewable energy supply in 2025 came from a broad portfolio of technologies and sustainable energy products. The three largest sources of renewable energy supply were wind generation (46.0%), the biodiesel blended into the 'road diesel' sold in garage forecourts (14.6%), and biomass combustion (12.3%). Together, these three sources accounted for almost three-quarters of all renewable energy used in Ireland in 2025.

Figure 3.5: Breakout of 2025 renewable energy supply across energy sub-products

<!-- image -->

7.7%

The national fleet of heat pumps and solar PV installations continue to expand rapidly. The renewable electricity generated by solar PV accounted for 6.3% of all renewable energy supplied in 2025. The renewable ambient heat captured by heat pumps accounted for another 5.5% of Ireland's renewable energy supply in 2025. Solar PV and ambient heat increased by 50% and 18% in 2025, respectively.

In absolute terms, Ireland's renewable energy supply increased by 1.84 TWh in 2025, compared with the previous year. There were increases in solar PV, wind, biodiesel, biomass, ambient heat capture, renewable waste combustion, and bioethanol. These increases were coupled with decreases in hydro generation, biogas, and landfill (LF) gas combustion.

## Figure 3.6: Waterfall plot showing 2024 to 2025 changes in Ireland's renewable energy supply

<!-- image -->

The largest renewable energy sub-product increase in 2025 came from solar PV, which was up by 0.55 TWh. The second largest increase came from wind generation, which was up by 0.38 TWh or 3.3%. Ireland's biodiesel supply increased by 0.36 TWh or 10.4% in 2025, driven by increased demand for road diesel and increased biofuel blending into that road diesel. For more detailed breakdowns on wind, solar, and other renewable energy supply streams, see Part 1 - Section 1.3 and Part 3 - Section 2 .

## 3.2 Energy Demand Trends

Ireland's total end-user energy demand of 144.6 TWh in 2025 can be broken out across different sectoral consumptions. In 2025, the three economic sectors with greatest energy consumption were transport (42.7%), residential (20.7%), and industry (17.5%). Combined, the top two sectors of transport and residential accounted for almost two-thirds of Ireland's energy consumption alone.

Figure 3.7: Breakout of 2025 energy demand across economic sectors

<!-- image -->

In absolute terms, Ireland's energy demand in 2025 increased by 0.80 TWh. There were increases in energy consumption from the transport, commercial services, and the agriculture &amp; fisheries sectors. These increases were coupled with decreases in energy demand from the residential, industry, and public service sectors.

In 2025, the largest sectoral increase in energy demand came from the transport sector, which increased by 0.83 TWh or 1.4% on the previous year. The second largest increase came from the commercial services sector, which increased by 0.72 TWh or 4.3% on the previous year.

Figure 3.8: Waterfall plot showing 2024 to 2025 changes in Ireland's energy demand by sector

2024 to 2025 Changes in Energy Consumption by Economic Sector (TWh)

<!-- image -->

In terms of energy-product breakout, just over half (53.7%) of energy consumed by end-users in 2025 was an oil product, mainly petrol, diesel, and heating oils. Electricity accounted for just under a quarter (23.6%) of end-user energy demand in 2025, followed by natural gas demand (13.8%). For more detailed breakdowns on energy demand by sector, see Part 3 - Section 4.2 .

Figure 3.9: Breakout of 2025 energy demand across energy products. The term 'NRW' stands for non-renewable wastes

<!-- image -->

As noted previously, Ireland's energy consumption in 2025 was 0.8 TWh higher than the previous year. At the energy-product level, there was increased end-user demand for electricity (+1.21 TWh), directuse renewable energy 5  (+1.01 TWh), and non-renewable wastes, coupled with decreased demand for natural gas (-0.68 TWh), oil (-0.52 TWh), and coal (-0.28 TWh). For more detailed breakdowns on energy demand by product, see Part 3 - Section 4.1 .

Figure 3.10: Waterfall plot showing 2024 to 2025 changes in Ireland's energy demand by product. The term 'NRW' stands for non-renewable wastes

<!-- image -->

Ireland's end-user demand for renewable energy is satisfied using both 'standalone' renewable energy products, like biomass ( e.g. wooden logs and wood pellets), and 'blended' renewable energy-products. Examples of blended energy-products include 'road diesel', which is the diesel fuel mix available for purchase at garage forecourts across the country, and our gross electricity supply, which comes from a mixture of fossil, renewable, and other sources of generation.

Road diesel in Ireland is a blend of 100% fossil-based petrochemical diesel and some fraction of sustainable biofuel components, including Fatty Acid Methyl Esters (FAME), Hydro-treated Vegetable Oil (HVO), and co-processed HVO. The biofuel blending of these sustainable compounds into road diesel helps reduce transport emissions by substituting-out some fraction of the fossil-based diesel.

5 Direct-use renewable energy refers to renewable energy sub-products that are directly consumed by an end-user, such biomass burned for heating in a home, or biodiesel used as fuel in a vehicle. It specifically excludes the renewable share of electricity consumed by end-users, as that is classified under renewable electricity supply rather than direct end-use of renewable energy.

Similarly, 'road petrol' in Ireland is a blend of fossil-based petrol and bioethanol. Small volumes of biomethane have also been injected into the national grid, and Sustainable Aviation Fuel (SAF) has now been blended into jet fuel supplies. These renewable fuel components help reduce the emissions intensity of the fuels consumed.

The fraction of renewable energy in key blended energy products in 2025 were:

- · 41.8% renewable energy share in electricity (RES-E)
- · 9.7% biodiesel in road diesel
- · 6.5% bioethanol in road petrol
- · 1.9% SAF in aviation fuel
- · 0.02% biomethane in the gas grid

## Figure 3.11: The fraction of renewable energy in key blended energy products in 2025

<!-- image -->

Biofuel blending into road diesel and road petrol has taken place for over a decade in Ireland, but the blending of SAF into aviation fuel, and biomethane into grid gas, is relatively new.

The REPowerEU -funded capital grants scheme, launched by the Department of Agriculture, Food, and the Marine in 2024, supported the construction of 7 biomethane plants with a combined capacity of 0.62 TWh of biomethane per annum. These plants have been commissioned and will be ramping up production throughout 2026. Three of the new plants will be connected directly to the gas network with the remainder trucking compressed gas to a central grid injection point near Mitchelstown, Co. Cork, which was commissioned in October 2026. It is expected that the biomethane produced will be purchased primarily by suppliers to meet their obligations under the upcoming Renewable Heat Obligation 6 .

SAF is currently being blended into aviation fuel supplied in Ireland to meet the requirements of the EU's ReFuelEU Aviation regulation. This regulation mandates a minimum 2% SAF share from 2025 and a 6% SAF share by 2030 (including 1.2% synthetic e-fuels).

6 www.gov.ie/en/department-of-climate-energy-and-the-environment/publications/renewable-heat-obligation/

The emission reductions achieved through blending renewable energy into fossil fuels are welcome. However, it is important to recognise that these blended fuels remain predominantly fossil fuel based. In 2025, road diesel in Ireland was more than 90% fossil fuel based, road petrol was more than 93% fossil fuel based, aviation fuel was more than 98% fossil fuel based, and the gas grid was more than 99.9% fossil fuel based. Therefore, consumption of these blended fuels continues to be a significant source of Ireland's energy-related emissions.

For more details on blended road diesel and road petrol, see Part 1 - Section 1.4 and Part 3 - 4.2.2 . For more details on biomethane in grid gas, see Part 3 - Section 3.4.1 .

## 3.3 Supply and Demand of Electricity

Electricity accounted for just under a quarter (23.6%) of Ireland's energy demand in 2025, with 41.0% of Ireland's gross electricity supply coming from renewable generation. Renewable electricity is by far the largest vector of renewable energy into Ireland's homes, offices, and businesses.

## 3.3.1 Electricity Supply Trends

Ireland's gross electricity supply in 2025 was 37.5 TWh, up 3.6% on 2024 levels. Gross electricity supply includes all electricity generation by utility-scale power plants (public thermal and CHP) as well as all micro-to-small scale electricity generation, including rooftop solar PV. Gross electricity supply includes the net-import of electricity across international interconnectors but excludes the transmission and distribution losses associated with transferring electricity across the national grid, and the cycle-losses incurred from energy storage, i.e. pumped or battery-storage.

In 2025, 40.0% of Ireland's gross electricity supply came from natural gas, followed by 32.1% from wind generation, and 16.3% from the net-import of electricity from Northern Ireland and Great Britain. Combined these three sources accounted for 88.4% of Ireland's electricity supply.

In total, fossil fuel generation accounted for 41.9% of the electricity supply in 2025 - the lowest level on record - with renewable generation accounting for 41.0% of electricity supply. Other sources, consisting of net-imports of electricity across international interconnectors and generation from the combustion of non-renewable wastes, accounted for the remaining 17.1%. On a percentage basis, Ireland's electricity supply has never had less fossil fuel generation or used more net-imported electricity.

Figure 3.12: Breakout of 2025 gross electricity supply by energy sub-products and type. The 'other' energy type includes non-fossil, non-renewable energy, like non-renewable wastes (NRW) and net imports of electricity across international interconnectors

<!-- image -->

In absolute terms, Ireland's gross electricity supply in 2025 was 1.33 TWh higher than the previous year. There was a significant increase in net imports across international interconnectors (IC Electr.), solar PV and wind generation, with smaller increases in generation from biomass, renewable waste, and biodiesel. These increases were coupled with decreased generation from coal, oil, hydro, natural gas, landfill gas (LF), wind, non-renewable wastes (NRW) and biogas.

Ireland's renewable electricity supply in 2025 increased by 0.87 TWh or 6.0%. This net increase in renewable electricity supply came mainly from increases in solar PV (+0.55 TWh), wind (+0.38 TWh), and biomass (+0.04 TWh), coupled with decreases from hydro (-0.12 TWh).

Figure 3.13: Waterfall plot showing 2024 to 2025 changes in gross electricity supply by subproduct. The term 'NRW' stands for non-renewable wastes

<!-- image -->

As noted above, a significant fraction of Ireland's gross electricity supply in 2025 came from netimported electricity across interconnectors. Provisional monthly data indicates that net imports of electricity in the first half of 2026 broadly match those from the corresponding period in 2025.

Figure 3.14: Monthly imports, exports, and net imports of electricity across international interconnectors with Northern Ireland and Great Britain

<!-- image -->

Ireland has three international interconnectors to Northern Ireland and Great Britain:

- · East-West interconnector
- · North-South interconnector 7
- · Greenlink interconnector

These interconnectors allow for international trade and balancing of electricity flows to-and-from Ireland and Northern Ireland (within the Integrated Single Electricity Market , or I-SEM) and mainland Great Britain (outside the I-SEM) 8 . In the 6-month period of January to June 2026, 44.6% of Ireland's net

7 The North-South interconnector is the aggregate of four circuits that connect the two systems.

8 The Moyle interconnector connects the I-SEM in Northern Ireland with the mainland Great Britain market. As the endpoints of this interconnector are not within the national boundary of the Republic of Ireland, electricity flows across this interconnector are not explicitly captured in Irish national statistics.

imports of electricity flowed across the Greenlink interconnector, with the remaining 30.4% and 25.0% of net imports flowing across the North-South and East-West interconnectors, respectively.

Figure 3.15: Monthly imports, exports, and net imports of electricity in 2025 and 2026 across the North-South, East-West, and Greenlink interconnectors

<!-- image -->

Trends in the relative contribution of net-imported electricity towards Ireland's electricity supply can be more fully explored using utility-scale gross electricity supply data, which is available monthly. Utilityscale gross supply covers electricity from large-scale grid-connected generators and accounts for approximately 95% of gross electricity supply, so it is an excellent proxy for total electricity supply.

Monthly data shows that Ireland has made consistent use of relatively high levels of net imports since Q1-2023. In every one of the last 24 calendar months (June 2024 to June 2026) Ireland has net imported at least 10% of its utility-scale gross electricity supply. In June 2025, net imports accounted for almost one quarter (23.7%) of Ireland's utility-scale gross electricity supply, and in May 2025, July 2026, and August 2026 net imports supplied more electricity than wind generation.

Figure 3.16: Monthly utility scale electricity supply in Ireland broken out by indigenous generation and net imports across international interconnectors

Monthly Utility Scale Electricity Supply Breakdown (TWh)

<!-- image -->

In the above figure, where the data shows values greater than 100%, this indicates that Ireland was a net-exporter of electricity to Northern Ireland and Great Britain in that month, i.e. on a net basis, it produced all its own electricity supply and more. For more details on monthly utility-scale generation and electricity imports and exports, see Part 2 - Section 2.1 .

## 3.3.1.1 Wind Supply

Ireland's wind generation comes from thousands of individual wind turbines installed across the country. Ireland's installed wind capacity in 2025 was 5.10 GW, up 3.3% on the previous year. Ireland missed its 2025 CAP target of 6 GW installed wind capacity by 0.9 GW. Ireland's 2030 CAP targets for onshore and offshore capacity are 9 GW and 5 GW, respectively. SEAI's National Energy Projections , under the With Additional Measures (WAM), scenario projects an installed capacity of 8.5 GW by the end of 2030. WAM is the most optimistic reporting scenario modelled and delivers a RES-E of 59% by 2030 9 .

Figure 3.17: Installed wind capacity with climate action plan (CAP) targets for 2025 and 2030, and 'with additional measures' (WAM) capacity projections

<!-- image -->

Over the last 5-years, Ireland has added wind capacity at an average rate of 0.16 GW per annum. To align to the pace of the WAM scenario, the roll-out rate of onshore wind capacity needs double, returning to a level previously achieved in the 2016-2019 period of installations. In addition, offshore wind projects delivering 1.35 GW of installed capacity need to be in place before the end of 2030. For more details on wind capacity, see Part 3 - Section 3.2.7 .

Figure 3.18: Year-to-year increases in installed wind capacity to 2025, and year-to-year increases in WAM capacity projections of capacity from 2025 to 2030

<!-- image -->

Ireland generated 12.0 TWh of renewable energy in 2025 from wind, up 3.3% on the previous year, setting a record high. However, annual wind generation over the last 4 years has been relatively level, increasing by just 5.6% from 2022 to 2025. For more details on wind generation, see Part 3 - Section 3.2.

9 https://www.seai.ie/sites/default/files/publications/National-Energy-Projections-2026.pdf

## Figure 3.19: Annual wind generation and dispatch down values

<!-- image -->

Multiple factors can impact the level of wind generation delivered each year - the installed capacity, the average quality of the wind, and the 'dispatch down' applied to wind generation due to constraint and curtailment on the local and national grid. While a nationally representative wind quality figure is difficult to determine, EirGrid provides precise monthly constraint and curtailment statistics 10  for wind generation, where:

- · Constraint is a reduction in allowed wind output due to local or network-specific grid limitations ( e.g. when part of the system cannot safely carry the wind power available, due to line, transformer, or node limits)
- · Curtailment is a reduction in allowed wind output due to system wide limitations ( e.g. when too much non-synchronous generation would be online relative to demand or stability limits, i.e. the safe system non-synchronous penetration level)

This data from EirGrid shows an approximately 50:50 split across constraint and curtailment contribution to dispatch down in the last 5 years, and a generally increasing trend in dispatch down. The average annual level of dispatch down for the last 5 years (2021 to 2025) was 9.2%, compared to 6.0% for the preceding 5 years (2016 to 2020).

Future levels of dispatch down may be reduced through upgrades and expansions of the electricity grid, increased flexibility in electricity demand-side management, and increased capacity for energy storage and deployment.

10 Renewable Dispatch-Down (Constraint and Curtailment) Report from EirGrid -

https://cms.eirgrid.ie/sites/default/files/publications/DD-Summary-Report-V22.xlsx

## 3.3.1.2 Solar PV Supply

Ireland generated 1.64 TWh of renewable energy from solar PV in 2025, up 50.4% on the previous record set in 2024. The rapid increase in solar PV generation since 2022 has come from a step-change increase in the connection of utility-scale 'solar farms' to the national grid, coupled with near exponential increases in embedded 'rooftop' solar PV on homes, businesses, and farms. In 2025, almost exactly two-thirds (66.9%) of Ireland's solar PV generation came from utility-scale solar-farms.

Figure 3.20: Time-series of Ireland's solar PV generation and a breakout of 2025 solar PV generation

<!-- image -->

The strong seasonal variation of solar PV is clearly apparent in the monthly generation data from utilityscale solar farms. The seasonal profile of solar PV is complementary to that of wind generation. Solar PV peaks during the summer months, when wind is at its lowest, and wind peaks during the winter months, when solar is at its lowest. A balanced blend of solar PV and wind capacity therefore acts to smooth the seasonal-level variations often associated with renewable electricity generation, reducing the need for dispatchable fossil fuel generation to meet seasonal gaps. For more details on solar PV capacity and generation, see Part 3 - Section 3.2.7 .

Figure 3.21: Monthly solar PV generation from utility-scale grid-connected solar farms. The blue line is a 12-month moving point average (MPA) to illustrate the average trend

<!-- image -->

SEAI analysis based on provisional monthly energy supply data indicates that utility-scale solar PV generation in the first half of 2026 was approximately 35% higher than that in the first half of 2025. For more details on monthly utility-scale electricity generation, see Part 2 - Section 2.1 .

## 3.3.2 Electricity Demand Trends

Ireland's electricity demand in 2025 was 34.1 TWh, up 3.7% on the previous year. The three leading demand sectors for electricity in 2025 were commercial services (42.1%), residential (24.8%), and industry (20.5%). Only 1.7% of electricity demand in 2025 came from the transport sector, i.e. the national fleet of Electric Vehicles (EVs), plus the LUAS , and DART commuter services.

Figure 3.22: Breakout of 2025 electricity demand across economic sectors

<!-- image -->

In absolute terms, Ireland's electricity demand in 2025 was 1.21 TWh higher than the previous year. There were increases in electricity demand from all economic sectors. The largest sectoral increase in electricity demand in 2025 came from commercial services, which increased by 0.78 TWh, up 5.7% on the previous year. The commercial services sector includes the Information and Communication Technologies (ICT) sub-sector, which includes Ireland's data centre demand.

Figure 3.23: Waterfall plot showing 2024 to 2025 changes in electricity demand by sector

<!-- image -->

Ireland's energy transition requires not only increasing renewable electricity generation but also expanding the role of electricity demand across the wider energy system. Electrification of transport, heating and industry can reduce direct fossil fuel consumption, improve energy efficiency, and support greater utilisation of renewable energy infrastructure.

In 2025, electrification of energy demand varied considerably across economic sectors. Electricity accounted for 81.3% of all energy demand in the commercial services sector, but less than 1% of demand in the transport sector. Overall, electricity met 23.6% of Ireland's final energy demand in 2025, highlighting the significant scope for further electrification across the economy.

## Figure 3.24: Electrification of Irish energy demand in 2025 by sector

<!-- image -->

Ireland's electricity demand has grown every year for the last 10 years. A key driver of this increased electricity demand has been energy consumption at Ireland's data centres. Data published by the Central Statistics Office (CSO) 11 shows that electricity demand from Ireland's data centre was 7.7 TWh in 2025, up 9.9% on the previous year. In 2025, data centres accounted for just over one-fifth (22.5%) of all electricity demand in Ireland. For reference, when it announced a new scheme for rating the sustainability of data centres in 2024, the European Commission noted that data centres accounted for approximately 3% of the EU's overall electricity demand.

Figure 3.25: Breakout of Ireland's electricity demand to illustrate the role of data centre (DC) electricity demand

<!-- image -->

Outside of data centres, the net electricity demand from all other sectors of the Irish economy has increased only slowly, up just 7.5% over the last 10 years. Comparing the change in annual electricity demand from 2015 12  to 2025, it is apparent that data centres were responsible for 78% of the net increase in electricity consumption across the Irish economy since 2015. For more details on electricity demand, see Part 3 - Section 4.1 and Part 3 - Section 5.4.

11 https://www.cso.ie/en/releasesandpublications/ep/p-dcmec/datacentresmeteredelectricityconsumption2025/keyfindings/

12 2015 is the first year for which the CSO publish metered electricity consumption of data centres.

## 3.4 Transport Energy Demand

Transport has the highest energy demand of any sector in the Irish economy. In 2025, the transport sector accounted for 42.7% of Ireland's energy demand, 38.9% of energy-related emissions, and 22.0% of Ireland's total GHG emissions 13 .

Private car use accounted for 41.3% of transport energy demand in 2025. International aviation accounted for a further 22.9% of transport energy demand, followed by Heavy Goods Vehicle (HGV) road freight demand at 17.9%. In total, 'road transport' accounted for just under three-quarters (74.1%) of Ireland's overall transport energy demand.

Figure 3.26: Breakout of 2025 transport demand by sub-sector 14  and type

<!-- image -->

Energy demand from the largest transport sub-sectors - private car use, international aviation, and HGV road freight - all increased in 2025. Energy demand from private car use increased by 1.4% to 25.0 TWh, the highest level on record. Energy demand from the national HGV fleet increased by 10.5% in 2025 to reach 11.1 TWh, the highest level recorded since 2008 - the end of the Celtic Tiger period.

Figure 3.27: Time-series of Ireland's energy demand for private car use and road freight

<!-- image -->

SEAI analysis of provisional monthly data indicates road petrol consumption in the first half of 2026 was 5.7% higher than in the corresponding period of 2025. However, it is too early to assess the fullyear change, as the 2026 outcome will depend on demand trends during the second half of the year.

Figure 3.28: Provisional monthly consumption of 'road petrol' from January 2025

<!-- image -->

Aviation energy demand increased by 8.5% in 2025 to reach 14.2 TWh, the highest level on record. SEAI analysis based on provisional monthly data indicates that jet fuel for aviation consumption in the first half of 2026 was 10.7% higher than in the corresponding period in 2025.

Figure 3.29: Monthly energy consumption of jet fuel for aviation. The blue line is a 12-month moving point average (MPA) to illustrate the average trend

<!-- image -->

For more details on monthly transport energy consumption, see Part 2 - Section 4.2 .

In terms of energy-product breakout, over half (53.9%) of transport energy demand in 2025 was satisfied using diesel. A further 22.5% of transport energy demand was satisfied using jet kerosene. Overall, 91.9% of Ireland's transport energy demand in 2025 was satisfied using fossil fuels, with renewable energy and electricity satisfying 7.2% and 0.9% of transport energy demand, respectively.

## Figure 3.30: Breakout of 2025 transport demand by energy sub-product and type

<!-- image -->

Most renewable energy in transport is delivered through the blending of Fatty Acid Methyl Esters (FAME), Hydro-treated Vegetable Oil (HVO), and co-processed HVO into petrochemical diesel, and bioethanol in petrochemical gasoline. The resulting blended products of 'road diesel' and 'road petrol' are the fuels available for purchase at garage forecourts across the country.

The blending of renewable biofuels into road transport fuels continued to increase in 2025. Biofuels accounted for 9.7% of the energy content of road diesel, up from 9.0% in 2024, while the biofuel blending into road petrol increased from 6.0% to 6.5%.

## Figure 3.31 Ireland's annual biofuel energy blending rates into road diesel and road petrol

<!-- image -->

SEAI analysis based on provisional monthly data indicates that biofuels accounted for 12.3% of the energy content of road diesel and 6.4% of the energy content of road petrol in the first six months of 2026. For more details on monthly biofuel supplies, see Part 2 - Section 2.3 .

While biofuel blending can help reduce transport emissions, it is only a partial solution. Internationally, there is limited availability of sustainable biofuel feedstock, and unchecked demand for biofuel production crops can act to displace crops needed for food production. Additionally, there are technical limits on the blend-rate of certain biofuels in standard road vehicles. For example, bioethanol is limited to 10% by volume in EN 228 gasoline, and conventional FAME-based biodiesel is limited to 7% by volume in EN 590 diesel. For more details on transport demand, see Part 3 - Section 4.2.2 and Part 3 Section 5.3.

## 3.5 Heat Demand

For the purposes of national energy statistics, and to align with European energy reporting requirements, heat demand is defined as total energy demand, less electricity demand, less transport demand. Heat demand accounted for 34.2% of Ireland's energy demand in 2025.

## 3.5.1 Overall Heat Demand

Ireland's heat demand in 2025 was 49.4 TWh, down 2.2% on the previous year. In 2025, the three economic sectors with greatest heat demand were residential (43.6%), industry (37.1%), and commercial services (6.7%). The residential and industry sectors alone accounted for approximately 80% of national heat demand.

Figure 3.32: Breakout of 2025 overall heat demand across economic sectors

<!-- image -->

In absolute terms, Ireland's heat demand in 2025 was 1.10 TWh lower than in the previous year. There were decreases in heat demand across all sectors of the economy, except for the agriculture &amp; fisheries sector. The most significant reduction in heat demand in 2025 was observed in the residential sector, where it decreased by 3.7% year-on-year.

Figure 3.33: Waterfall plot showing 2024 to 2025 changes in heat demand by sector

<!-- image -->

In terms of energy-product breakout, 42.8% of heat demand in 2025 was satisfied through end-user consumption of oil products like kerosene and gasoil. Natural gas accounted for a further 40.0% of heat demand in 2025. Only 9.6% of Ireland's heat demand was satisfied by the consumption of renewable energy in 2025.

## Figure 3.34: Breakout of 2025 overall heat demand across energy products

<!-- image -->

Ireland's heat demand remains dominated by fossil fuels. In 2025, 88.6% of heat demand was satisfied using fossil fuels. However, the proportion of heat demand satisfied by fossil fuels is falling slowly down from 92.8% in 2015.

Figure 3.35: Time-series breakout of Ireland's overall heat demand by energy type. The 'other' energy type includes non-fossil, non-renewable energy, like non-renewable wastes

<!-- image -->

Historically, most of the renewable energy used to satisfy Ireland's heat demand was biomass. In 2015, biomass accounted for 71.3% of all renewable energy used to satisfy heat demand. In 2025, biomass accounted for 41.1% of that renewable energy, with 30.2% of renewable heat coming from the ambient heat captured by heat pumps, and 17.4% coming from the combustion of renewable wastes. For more details on heat demand, see Part 3 - Section 5.2 .

Figure 3.36: Time-series breakout of Ireland's renewable heat demand by energy sub-type

<!-- image -->

## 3.5.2 Residential Heat Demand

Ireland's residential heat demand in 2025 was 21.5 TWh, down 3.7% on the previous year. Well over half (56.0%) of residential heat demand in 2025 was satisfied through the combustion of oil products, mainly kerosene. Natural gas accounted for just under one-quarter (24.6%) of residential heat demand in 2025, followed by direct consumption of renewable energy (7.6%).

Figure 3.37: Breakout of 2025 residential heat demand across energy products, and a breakout of residential electricity demand by consumption activity

<!-- image -->

Since heat demand is defined as total energy demand, less electricity demand, less transport demand, the residential heat demand value of 21.5 TWh excludes the 2025 residential electricity demand value of 8.5 TWh. Based on SEAI's modelling of energy end use in households, using the dwelling energy assessment procedure (DEAP) and CSO weightings of housing architypes, SEAI estimates that 22.5% of residential electricity demand goes to heating in 2025.

Renewable energy satisfied only 7.6% of residential heat demand in 2025. Ambient heat captured by heat pumps accounted for over two-thirds (67.4%) of the renewable energy used for residential heating in 2025. There were approximately 193,000 homes with heat pumps at the end of 2025, up from 153,000 at the end of 2024 15 . A further 22.8% of renewable heat demand in homes was satisfied through the combustion of biomass ( e.g. wood logs, wood pellets, etc.), with the remaining 9.8% coming from solar thermal heating.

As noted previously, Ireland's residential heat demand in 2025 was down 3.7% on the previous year. Annual changes in residential heat demand can be driven by many different interconnected factors:

- 1. Weather effects, particularly the length and average temperature of the winter season
- 2. The affordability of energy prices, particularly oil and natural gas
- 3. The impact of new builds and energy upgrades on the heating efficiency of the housing stock
- 4. Societal and behavioural shifts, such as the return-to-office vs. work-from-home balance
- 5. Demographic shifts in occupation of housing stock

15 Figures extracted from SEAI's BER database.

## Figure 3.38: Time-series of Ireland's residential heat demand

Residential Heat Demand

<!-- image -->

(TWh)

Weather conditions, especially during the winter heating season, are a major driver of short-term yearto-year changes in residential heat demand, because they influence how frequently, how long, and how intensively homes are heated. A simple indicator for national heating requirements is the number of heating degree days (HDDs) below 15.5°C recorded in a year. Monthly HDD data is published by Met Éireann based on observations from multiple weather stations across Ireland.

There is a very strong correlation between year-to-year changes in residential heat demand and yearto-year changes in the number of HDDs. For example, the percentage changes in the number of HDDs for 2024 and 2025 were +5.7% and -3.8%, respectively. Which matches very closely to the corresponding percentage changes in residential heat demand for 2024 and 2025, i.e. +6.3% and -3.7%, respectively.

Figure 3.39: Comparison of year-to-year changes in residential heat demand and year-to-year changes in the number of heating degree days (HDDs)

<!-- image -->

While year-to-year changes in residential heat demand are strongly correlated to the number of HDDs, the relationship is not exact, because a wide range of economic and societal factors can also influence residential energy use.

For example, while 2020 was only marginally colder than 2019 (with HDDs increasing by just 0.4%), residential heat demand rose by 9.7%. This was likely driven by the sudden shift to 'work from home' and 'schooling from home' patterns in response to the COVID-19 pandemic. Conversely, residential heat demand fell significantly by 14.6% in 2022, despite HDDs decreasing by only 6.8%. This likely reflected the impact of sharply higher energy prices during that period, as the cost of major residential heating fuels, including kerosene and natural gas, approximately doubled.

SEAI analysis based on provisional monthly data indicates that residential natural gas consumption in the first six months of 2026 was almost 5% higher than the corresponding period in 2025.

Figure 3.40: Provisional monthly residential natural gas consumption from January 2025

<!-- image -->

In contrast, kerosene consumption 16  in the first six months of 2026 was almost 11% lower than the corresponding period in 2025. These contrasting demand trends may partly be explained by the different price dynamics of natural gas and kerosene, with kerosene prices more immediately affected by the geopolitical developments in the first half of 2026 than hedged natural gas prices.

Figure 3.41: Provisional monthly kerosene consumption from January 2025

<!-- image -->

For more details on the seasonality of monthly oil and natural gas, see Part 2 - Section 2.2 and 2.3.

16 Approximately 95% of kerosene deliveries go to the residential market

## 4 Ireland's EU Energy Targets

Ireland has 2030 EU energy targets for both the share of renewable energy in its energy portfolio, and the total energy demand of that portfolio. These dual targets act together to motivate improvements in the quality of energy in Ireland, by increasing the share of renewable energy being used, and to reduce the quantity of energy needed in Ireland, by increasing efficient use of energy through better technology and behaviours.

## 4.1 Renewable Energy Directive Targets

Ireland's renewable energy share, and that of all EU member states, is calculated and monitored by the European Commission under different iterations of the Renewable Energy Directive ( RED). The renewable energy share of EU member states is monitored through four key metrics:

• RES-Overall Overall renewable energy share.

• RES-E Renewable energy share in electricity.

• RES-T Renewable energy share in transport.

• RES-H Renewable energy share in heating (and cooling).

The methodology for calculating the four RES results and setting their targets, which can include applying multipliers, limits, normalisations, and sustainability-checks on specific energy sub-products, is specified through the relevant iteration of the Directive for a given year. Ireland's RES-overall targets out to 2030 are specified in the National Energy Climate Plan (NECP), prepared under the EU Regulation on the Governance of the Energy Union , RED-II and RED-III. In addition to a 2020 'baseline' RES-Overall target of 16% in all years to 2030, Ireland has a series of reference points for specific milestone years:

• 2022 19.3% (RED-II).

• 2025 27.6% (RED-III).

• 2027 33.6% (RED-III).

• 2030 43.0% (RED-III).

## 4.1.1 Overall Renewable Energy Share (RES-Overall)

In 2025, Ireland's RES-Overall result reached a record high of 17.3%, up from 16.1% in 2024. However, this 2025 result was 10.3 percentage points below Ireland's 2025 milestone target of 27.6%. Despite recent improvements, Ireland's RES-Overall share remains well below the indicative trajectory set out in the NECP.

Figure 4.1: Ireland's overall renewable energy share (RES-Overall) results and targets

<!-- image -->

Based on provisional Eurostat data, Ireland ranked third-from-bottom among EU-27 member states in terms of its RES-Overall result in 2025.

Figure 4.2: Provisional 2025 RES-Overall results from EU-27 member states

<!-- image -->

## 4.1.2 Renewable Energy Share in Electricity (RES-E)

While Ireland does not have a formal binding target for RES-E at the EU-level, continued growth in renewable electricity generation is essential to achieving the country's binding 2030 RES-Overall target. To support this objective, the 2025 Climate Action Plan maintained Ireland's long-standing RES-E target of 80% by 2030.

In 2025, Ireland's RES-E result was 41.8%, up half a percentage point from 41.3% in 2024. Since 2020, Ireland's RES-E result has increased by just 2.8 percentage points, due to several factors:

- 1. A plateauing of wind generation - the largest contributor to Ireland's renewable electricity over the last 5 years.
- 2. Demand for electricity increasing faster than the roll-out rate of renewable generation capacity, i.e. increases in the numerator of the RES-E calculation (renewable electricity supply) being eroded by increases in the denominator of the RES-E calculation (total electricity supply).
- 3. A series of methodology changes to the RES-E calculation applied in 2021 under RED-II, and 2025 under RED-III, that introduced formal sustainability checks on specific renewable energy products, i.e . biomass and biogas.

## Figure 4.3: Ireland's renewable energy share of electricity (RES-E) results and target

<!-- image -->

Based on provisional Eurostat data, Ireland's RES-E result in 2025 is 8.1 percentage points below the EU27 member state average result of 49.9%.

Figure 4.4: Provisional 2025 RES-E results from EU-27 member states

<!-- image -->

## 4.1.3 Renewable Energy Share in Transport (RES-T)

Ireland had a RED-T target of 14% in 2030 under RED-II. This was increased to 29% under RED-III, with the option to instead target a 14.5% reduction in the greenhouse gas intensity of transport. Ireland has since secured a RES-T target of 24% in 2030, under Article 26.1 of RED-III, conditional on Ireland's fraction of crop-based biofuels being kept below 2% 17 .

Figure 4.5: Ireland's renewable energy share in transport (RES-T) results and target

<!-- image -->

Although the absolute quantity of renewable energy consumed in the transport sector increased in 2025, Ireland's RES-T result fell to 7.3% in 2025, down from 8.7% in 2024. Several factors contributed to this drop, including:

- 1. A change in the mix of biofuel feedstocks used between 2024 and 2025, with cap-less 'advanced' Part A feedstocks decreasing significantly in favor of capped Part B feedstocks ( i.e. , UCO and tallow category 1 and 2).
- 2. A methodological change in the calculation of the RES-T indicator between 2024 (RED-II) and 2025 (RED-III). Under RED-III, the denominator for the RES-T calculation now includes energy

17 https://assets.gov.ie/static/documents/Renewable\_Transport\_Fuel\_Policy\_2025-2027\_2.pdf

consumption across all transport modes, including international aviation and international marine bunkers, subject to caps on the aviation and maritime contributions.

## 4.1.4 Renewable Energy Share in Heating (RES-H)

Under RED-III, each EU member state, must increase its RES-H result by at least 0.8 percentage points per year from 2021 to 2025, and by at least 1.1 percentage points per year from 2026 to 2030 (as an annual average over those periods) from the starting value of the RES-H result achieved in 2020. For Ireland, this equates to a required RES-H trajectory with an indicative milestone target of 10.3% in 2025, and a final target of 15.8% in 2030.

Ireland's RES-H result in 2025 was 8.9%, 1.4 percentage points below its 10.3% indicative milestone target. Ireland continues to have one of the lowest RES-H results in Europe. Ireland's RES-H result in 2025 was one-third the value of the EU-27 member state's average result (27.4%).

Figure 4.6: Ireland's renewable energy share in heating (RES-H) results and target

<!-- image -->

For more details on Ireland's RES results and targets see Part 3 - Section 7.2 .

## 4.2 Energy Efficiency Directive Targets

Under Article 4 of the Energy Efficiency Directive (EED), the EU has set itself a binding target of reducing total final energy consumption by 763 million tonnes of oil equivalent (Mtoe) by 2030. In February 2024, the Irish government approved Ireland's Article 4 target under the EED and submitted this as part of Ireland's NECP. Under its approved Article 4 EED target, Ireland is required to make sincere cooperative efforts to limit its total final energy consumption 18  (TFEC-EED) to 10.451 Mtoe by 2030.

Ireland's TFEC-EED result in 2025 was 12.306 Mtoe, up 0.4% on the previous year. To achieve the 2030 TFEC-EED target, Ireland would need to reduce its TFEC-EED result by 15.1% over the next 5 years, which is equivalent to an average annual reduction of 3.0% for the next 5 years.

The 2030 TFEC-EED target requires Ireland to reduce its energy consumption to its lowest level in 25 years, that being below the TFEC-EED value observed in 2020, during the height of COVID-19 impacts on the Irish economy (11.182 Mtoe). Progress against Ireland's Article 4 EED target is subject to monitoring by the European Commission through Ireland's NECP.

## Figure 4.7: Ireland's total final energy consumption under the EU's energy efficiency directive (EED) and Ireland's 2030 Article 4 target

<!-- image -->

In addition to the Article 4 EED target, which seeks to reduce absolute energy demand, Article 8 of the EED requires member states to achieve 'new energy savings' targets each year that are equivalent to:

- · 2021-2023: 0.8% of TFEC
- · 2024-2025: 1.3% of TFEC
- · 2026-2027: 1.5% of TFEC
- · 2028-2030: 1.9% of TFEC

The Article 8 EED targets are binding on member states, and the measures and savings must achieve certain criteria to be deemed countable towards those targets:

- · Enduring - The energy saving must last over time.
- · Material - The measure employed reported must be the reason for the energy savings.
- · Additional - The measure must be over-and-above minimum standards required by EU law.
- · Verifiable - The measure and savings must be monitored and recorded.

18 The definition of the total final energy consumption used for Article 4 of the EED excludes the use of ambient heat captured by heat-pumps and so differs slightly from the total final energy consumption cited in other statistics.

## Appendix 1: Version control

|   Version | Date        | Notes                     |
|-----------|-------------|---------------------------|
|         1 | 21-OCT-2026 | Public release on website |

<!-- image -->

## Sustainable Energy Authority of Ireland

Three Park Place Hatch Street Upper Dublin 2 Ireland D02 FX65

e

info@seai.ie

w  www.seai.ie

t

+353 1 808 2100

<!-- image -->

<!-- image -->