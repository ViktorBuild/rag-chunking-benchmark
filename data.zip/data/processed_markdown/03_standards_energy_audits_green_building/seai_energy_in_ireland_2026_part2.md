---
document_id: seai_energy_in_ireland_2026_p2
title: "Energy in Ireland 2026: Part 2 - Sectoral Energy & Electricity Demand"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2026
original_file: "seai_energy_in_ireland_2026_part2.pdf"
tables_detected: 14
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## ENERGY IN IRELAND 2026

Part 2  - Monthly  Energy  Data  to  June  2026

<!-- image -->

## Energy in Ireland 2026

Part 2 - Monthly energy data to June 2026

October 2026

ID: EII-2026-P2-1.0

## Sustainable Energy Authority of Ireland

SEAI is Ireland's national energy authority investing in, and delivering, appropriate, effective and sustainable solutions to help Ireland's transition to a clean energy future. We work with the public, businesses, communities and the Government to achieve this, through expertise, funding, educational programmes, policy advice, research and the development of new technologies.

SEAI is funded by the Government of Ireland through the Department of Climate, Energy and the Environment.

© Sustainable Energy Authority of Ireland

Reproduction of the contents is permissible provided the source is acknowledged.

## Acknowledgements

SEAI gratefully acknowledges the continued cooperation and assistance of the organisations, agencies, energy suppliers, and distributors that provide data and respond to questionnaires throughout the year. Their timely contributions play a vital role in enabling the production of accurate, comprehensive, and high-quality energy statistics for Ireland.

## Contents

| 1                                                                                                                         | Background and Scope...................................................................................................                                             | 1                                                                                                                                                                   |
|---------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2                                                                                                                         | Monthly supply statistics - electricity, gas, oil and liquid biofuels .............................. 3                                                              | Monthly supply statistics - electricity, gas, oil and liquid biofuels .............................. 3                                                              |
| 2.1                                                                                                                       | Utility-Scale Electricity ............................................................................................................................... 4         | Utility-Scale Electricity ............................................................................................................................... 4         |
|                                                                                                                           | 2.1.1                                                                                                                                                               | Seasonality in utility scale monthly electricity supply ................................................................. 5                                         |
|                                                                                                                           | 2.1.2 Monthly utility scale electricity generated ..................................................................................                                | 10                                                                                                                                                                  |
|                                                                                                                           | 2.1.3 Monthly electricity imported and exported................................................................................15                                   |                                                                                                                                                                     |
| 2.2                                                                                                                       | Gas............................................................................................................................................................. 16 | Gas............................................................................................................................................................. 16 |
|                                                                                                                           | 2.2.1                                                                                                                                                               | Seasonality in monthly gas supply............................................................................................... 16                                 |
|                                                                                                                           | 2.2.2                                                                                                                                                               | Monthly gas supply ........................................................................................................................ 18                      |
| 2.3                                                                                                                       | Oil and liquid biofuels............................................................................................................................. 20             | Oil and liquid biofuels............................................................................................................................. 20             |
|                                                                                                                           | 2.3.1                                                                                                                                                               | Seasonality in monthly oil and liquid biofuel deliveries............................................................21                                              |
|                                                                                                                           | 2.3.2                                                                                                                                                               | Monthly oil and liquid biofuel supply in last 12 months...........................................................26                                                |
| 3                                                                                                                         | Monthly transformation estimates.............................................................................. 28                                                   | Monthly transformation estimates.............................................................................. 28                                                   |
| 3.1                                                                                                                       | Transformation inputs............................................................................................................................ 28                | Transformation inputs............................................................................................................................ 28                |
| 3.2                                                                                                                       | Public thermal power plant inputs........................................................................................................ 29                        | Public thermal power plant inputs........................................................................................................ 29                        |
| 4                                                                                                                         | Monthly final energy consumption estimates............................................................ 30                                                           | Monthly final energy consumption estimates............................................................ 30                                                           |
| 4.1                                                                                                                       | Total final energy consumption.............................................................................................................30                       | Total final energy consumption.............................................................................................................30                       |
| 4.2                                                                                                                       | Transport final energy consumption....................................................................................................31                            | Transport final energy consumption....................................................................................................31                            |
| 5                                                                                                                         | Monthly energy-related emissions estimates............................................................. 33                                                          | Monthly energy-related emissions estimates............................................................. 33                                                          |
| 5.1                                                                                                                       | Total fuel combustion............................................................................................................................. 33               | Total fuel combustion............................................................................................................................. 33               |
| 5.2                                                                                                                       | Total energy-related emissions ............................................................................................................. 34                     | Total energy-related emissions ............................................................................................................. 34                     |
| 5.3                                                                                                                       | National energy-related emissions....................................................................................................... 40                         | National energy-related emissions....................................................................................................... 40                         |
|                                                                                                                           | Appendix 1 Data & methodology ................................................................................. 42                                                  | Appendix 1 Data & methodology ................................................................................. 42                                                  |
| A1                                                                                                                        | Monthly supply statistics ........................................................................................................................ 42               | Monthly supply statistics ........................................................................................................................ 42               |
|                                                                                                                           | A1.1                                                                                                                                                                | Monthly electricity data................................................................................................................. 42                        |
|                                                                                                                           | A1.2                                                                                                                                                                | Monthly gas data............................................................................................................................ 42                     |
| A2                                                                                                                        | Monthly energy and emissions estimates ........................................................................................... 43                               | Monthly energy and emissions estimates ........................................................................................... 43                               |
|                                                                                                                           | A2.1                                                                                                                                                                | Monthly energy estimates............................................................................................................. 43                            |
|                                                                                                                           | A2.2 Monthly emissions                                                                                                                                              | estimates....................................................................................................... 43                                                 |
| Appendix 2 Table of figures .......................................................................................... 45 | Appendix 2 Table of figures .......................................................................................... 45                                           | Appendix 2 Table of figures .......................................................................................... 45                                           |

| Appendix 3   | Glossary of abbreviations ......................................................................... 46        |
|--------------|---------------------------------------------------------------------------------------------------------------|
| Appendix 4   | Glossary of terms....................................................................................... 48   |
| Appendix 5   | Version control........................................................................................... 50 |

## 1 Background and Scope

Insights from provisional monthly data are best regarded as useful early indications of shifts and trends in energy that will later be more fully quantified and verified by definitive annual data. The complementary use of both fast-provisional monthly data, and slower-definitive annual data, helps balance the competing needs of timeliness and authority in Ireland's energy data. The trends observed in provisional monthly data are not as definitive or as inclusive as those based on the annual energy data in SEAI's National Energy Balance, or the annual emissions data in EPA's National Greenhouse Gas Emissions Inventory. 1  But the trends in the monthly data can often be identified just a few weeks after the fact, providing timely and trusted data to inform evidence-led energy policy and determine the pace of progress against binding energy and climate targets.

This monthly data section of the Energy in Ireland report (part 2) emphasises quantitative reporting over descriptive reporting. It contains plots to quantify observed trends in energy and emissions, rather than speaking to the policy, behaviour, technology, or market forces that may have driven those trends. Fuller context and explanation for the trends identified can be found in the definitive annual data section of the Energy in Ireland report (part 3) , or in the National Energy Projections report. 2

The primary data sources for this section are SEAI's monthly energy web -updates 3  on electricity, gas, and oil and liquid biofuels products and the National Energy Balance, 4  which are based on Ireland's reporting obligations to the European Commission under the Energy Statistics Regulation No 1099/2008 . 5

Figure 1.1 shows a summary of the methodology used in energy consumption and energy-related emissions estimates. It shows data sources used and summarises how calculations were made. The relevant section numbers, where you can find the energy and emission outputs in this section of the report Energy in Ireland (part 2) , are also shown.

1 National Inventory Submissions (EPA): https://www.epa.ie/publications/monitoring--assessment/climate-change/airemissions/irelands-national-inventory-submissions-2026.php

2 National energy projections: https://www.seai.ie/data-and-insights/seai-statistics/key-publications/national-energy-projections

3 Monthly Energy Data webpages: https://www.seai.ie/data-and-insights/seai-statistics/monthly-energy-data

4 National Energy Balance: https://www.seai.ie/data-and-insights/seai-statistics/key-publications/national-energy-balance

5 Energy Statistics Regulation: https://eur-lex.europa.eu/eli/reg/2008/1099/oj/eng

## Figure 1.1: Overview of relevant sections and methodology used for energy consumption and related emissions estimates

<!-- image -->

## 2 Monthly supply statistics - electricity, gas, oil and liquid biofuels

SEAI collects and reports supply-side monthly statistics under the European Energy Statistics Regulation No 1099/2008 6 on electricity, gas, oil and liquid biofuels. This data is reported to Eurostat on a monthly basis and can also be found on the 'Monthly Energy Data' webpages within the energy statistics section of the SEAI website. 7

As explained in more detail in part 2 section 1 , these monthly supply statistics can be used in conjunction with annual data to act as an early indication of trends that will later be more fully quantified and verified by definitive annual data. The monthly data can also serve as a useful indication of short-term shocks which are not always identifiable in annual data. The different scopes of provisional monthly and definitive annual energy statistics are summarised in Figure 2.1 below.

Figure 2.1: Differences in scope between monthly and annual energy statistics

<!-- image -->

6 Energy Statistics Regulation: https://eur-lex.europa.eu/eli/reg/2008/1099/oj/eng

7 Monthly Energy Data webpages: https://www.seai.ie/data-and-insights/seai-statistics/monthly-energy-data

## 2.1 Utility-Scale Electricity

The monthly data currently available to SEAI on electricity supply covers only the utility scale supply of electricity, i.e. the electricity supplied by large-scale grid-connected sites, and through international interconnectors. As a result, the monthly data does not capture instances of mini- or micro-generation of electricity, for example the electricity generated by rooftop solar panels. The monthly data also does not capture electricity that is generated and consumed on the same site without entering the grid, referred to as autoproduction or autoconsumption .

<!-- image -->

Nonetheless, the fast-provisional total utility scale supply of electricity calculated from monthly data serves as an excellent proxy for identifying developing trends in Ireland's total electricity supply, and the total electricity demand driving that supply. The utility scale supply of electricity in recent years has accounted for approximately 95% of total electricity supply. Small-scale electricity generation, as well as transmission, distribution, and storage losses, are fully accounted for in SEAI's National Ene rgy Balance, which benefit from more definitive annual surveys and cross-agency reconciliations of data. The monthly data is provided by EirGrid in megawatt hours (MWh) in terms of a net electricity production basis and converted to terawatt hours (TWh) by SEAI.

## 2.1.1 Seasonality in utility scale monthly electricity supply

The bar chart in Figure 2.1.1 shows the utility scale electricity supply per month from January 2017 to June 2026. The black line shows a 12-month moving average of those monthly values and helps to identify underlying long-term trends. In June 2026, the 12-month moving average of utility scale electricity supply had increased by 4.1% when compared to June 2025. While the seasonality of electricity supply is somewhat apparent in this 'raw' monthly data, it can be made much clearer through cross-year averaging and normalisation for number of days in a given month, as shown in subsequent figures.

Figure 2.1.1: Monthly utility scale electricity supply -January 2017 to June 2026

<!-- image -->

Source: data from EirGrid

Figure 2.1.2 shows the utility scale electricity supply per month from January 2017 to June 2026, split into its renewable (green) and non-renewable (grey) components. The green and black lines show the 12-month moving averages of the renewable and non-renewable monthly values, respectively. In June 2026, the 12-month moving average of non-renewable utility scale electricity supply had decreased by 1.9% and the 12-month moving average of renewable utility scale electricity supply had increased by 13.1% when compared to June 2025.

Figure 2.1.2: Monthly renewable and non-renewable utility scale electricity supply -January 2017 to June 2026

<!-- image -->

Source: data from EirGrid

Figure 2.1.3 shows the average monthly utility scale electricity supply by month, where each month's value is the average of that month's electricity supply (total [top], renewable [middle] or non -renewable [bottom]), normalised for number of days in a month, over the previous 5 years. For example, the January value is the average of January in 2022, 2023, 2024, 2025 and 2026 and the July value is the average of July in 2021, 2022, 2023, 2024 and 2025. It shows the seasonality of the electricity supply, whereby the electricity supply is higher in the winter months and lower in the summer months. The renewable supply shows a pronounced seasonal variation, oscillating around an average value of approximately 1.1 TWh. It has a maximum of approximately 1.6 TWh from December to February, and a minimum of approximately 0.7 TWh from July to September. The seasonal variation of renewable electricity generation is therefore approximately ±27% of the annual average. This variation is largely driven by the strong seasonality of wind generation, which makes up a considerable fraction of our renewable electricity generation (see below for more details). The seasonality of renewable electricity generation matches the seasonality of our demand -the wind generation is highest in the winter months, and this is when energy demand for light and heat is highest. The non-renewable supply is relatively flat at approximately 1.7 TWh per month, but shows higher non-renewable electricity supply in the summer months, and lower non-renewable electricity supply in the winter months. Nonrenewable electricity supply is anti-correlated to renewable supply -when renewable supply is high, non-renewable electricity is low, and vice versa. This is most clearly illustrated by comparing the average values of February and July, where the particularly high and low renewable supply values match particularly low and high non-renewable supply values.

Figure 2.1.3: Average monthly utility scale electricity supply over last 5 years (normalised for number of days per month)

<!-- image -->

Source: data from EirGrid

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 2.1.4 shows utility scale monthly electricity supply ( i.e. total generation plus net imports) from July 2025 to June 2026, split by electricity supply from renewable generation and non-renewable sources. Although this value can be regarded as a leading indicator of Ireland's renewable share of energy in electricity (RES-E), it is not directly equivalent to the RES-E value because the methodology for the RES-E calculation additionally includes (1) mini- and micro- generation of renewable electricity, (2) the electricity generated by auto-producers (including CHP plants), (3) multi-year normalisation of wind and hydro generations, and (4) a formal accounting for the sustainability status of various biomass fuels.

Figure 2.1.4: Share of renewable and non-renewable sources in utility scale electricity supply -July 2025 to June 2026

Source: data from EirGrid

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

The bar chart in Figure 2.1.5 shows the share of utility scale monthly electricity supply, split by electricity supply from indigenous generation (green) and net imports (orange) between January 2017 to June 2026. In months with percentage shares above 100%, this represents periods when there was a net export of electricity outside of Ireland's national boundaries, across international interconnectors. The lines show two 12-month moving averages of the monthly data and help to identify underlying long-term trends in monthly indigenous electricity production (green) and electricity net imports (orange) data.

Figure 2.1.5: Share of utility scale electricity supply split by indigenous generation and net imports   July 2017 to June 2026 -

<!-- image -->

Source: data from EirGrid

## 2.1.2 Monthly utility scale electricity generated

The bar chart in Figure 2.1.6 shows utility scale electricity generated and exported to the grid per month from January 2017 to June 2026. The black line shows a 12-month moving average of monthly values and helps to identify underlying long-term trends. In June 2026, the 12-month moving average of utility scale electricity generation had increased by 2.8% when compared to June 2025.

Figure 2.1.6: Monthly utility scale electricity generation -July 2017 to June 2026

<!-- image -->

Source: data from EirGrid

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

The bar chart in Figure 2.1.7 shows the utility scale electricity supply per month from January 2017 to June 2026, split into its renewable (green) and non-renewable (grey) components. The green and black lines show the 12-month moving averages of the renewable and non-renewable monthly values, respectively, and help to identify underlying long-term trends in the two components. In June 2026, the 12-month moving average of non-renewable utility scale electricity supply had decreased by 6.5% and the 12-month moving average of renewable utility scale electricity supply had increased by 13.1% when compared to June 2025.

Figure 2.1.7: Monthly renewable and non-renewable utility scale electricity generation -January 2017 to June 2026

<!-- image -->

Source: data from EirGrid

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

The bar chart in Figure 2.1.8 shows the monthly electricity generation exported to the grid, from January 2017 to June 2026, split by generator type. The black line shows the 12-month moving average of the monthly totals, to help to identify underlying long-term trends. Note that this figure shows the electricity generated by each generator type, rather than the amount of energy required to generate the electricity. Also note that some generators may use secondary fuels in addition to their primary fuel type/generator type and therefore the electricity quantities in this graph are not completely reflective of the energy input type. For details on electricity generated by energy input source, see Figure 2.1.9.

Figure 2.1.8: Monthly utility scale electricity generation split by generator type -January 2017 to June 2026

<!-- image -->

Source: data from EirGrid

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 2.1.9 shows the monthly utility scale electricity generation over the 12-month period up to June 2026, broken down by input fuel or energy type. Note that this figure shows the electricity generated due to each fuel/energy input, rather than the quantity of fuel/energy needed to generate that electricity. The seasonal variations in electricity generated from wind and gas are visible, with wind accounting for 49% of utility scale electricity generation in both February and March 2026 or 42% and 41% of utility scale electricity supply in February and March 2026, respectively.

Figure 2.1.9: Monthly electricity generation by source -July 2025 to June 2026

<!-- image -->

Source: data from EirGrid

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 2.1.10 shows the breakdown of the electricity generated by input fuel or energy type, averaged over the last 12 calendar months, i.e. from July 2025 to June 2026. This 12-month approach is more appropriate than simply averaging over the year-to-date, because of seasonal renewable contributions to electricity generation. Natural gas (46.8%), wind (41.9%) and solar photovoltaic (4.4%) were the three largest contributors to electricity generation in the 12 months from July 2025 to June 2026.

Figure 2.1.10: Sources of electricity generation -July 2025 to June 2026

<!-- image -->

o r e

Natural gas

Wind

Solar photovoltaic

ydro

<!-- image -->

Source: data from EirGrid

<!-- image -->

iomass asoil

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

enewable waste

Non renewable waste iogas

<!-- image -->

<!-- image -->

uel oil iodiesel

## 2.1.3 Monthly electricity imported and exported

The bar chart in Figure 2.1.11 shows the import (orange) and export (grey) of electricity to-and-from Ireland through international interconnections each month. The resulting 'net import 'of electricity through the interconnections is shown by the black data points joined with a line to guide the eye. A positive net import value for a given month means that Ireland imported more electricity than it exported that month, while a negative net import value for a given month means that Ireland exported more electricity than it imported that month. In June 2026, the 12-month moving average of electricity net imports had increased by 10.9% when compared to the 12-month average in June 2025.

This net import value sums the import and export flows across:

- · The North-South interconnector to Northern Ireland, which consists of four circuits connecting the two systems and is within the integrated single electricity market of Ireland and Northern Ireland (SEM),
- · The EastWest interconnector to  reat  ritain's electricity market, and
- · The  reenlink interconnector to  reat  ritain's electricity market.

The  reenlink interconnector, connecting Wexford with Wales, entered its 'commercial operations' phase at the beginning of 2025, with capacity available through the implicit SEM'Intra Day Auction' from th January 2025.

Figure 2.1.11: Monthly imported and exported electricity (with net imports) -July 2017 to June 2026

<!-- image -->

Source: data from EirGrid

## 2.2 Gas

Ireland's national gas supply comes from the sum of indigenous production at the Corrib Gas Field and international imports from the UK through a pair of international interconnectors to Moffat in Scotland.

SEAI uses public data from the Gas Network Ireland (GNI) dashboard, and monthly survey returns from GNI and the  orrib  as  ield, to determine Ireland's national gas supply, and its split across indigenous production and imports flows.

The gas monthly data is expressed in terms of gross calorific value (   ), while SEAI's national Energy Balance expresses all energy in terms of net calorific value (NCV). The net calorific value can be calculated from the gross calorific value by multiplying by a factor of 0.902.

## 2.2.1 Seasonality in monthly gas supply

Figure 2.2.1 shows the monthly supply of grid gas over the last ten years, split into imported gas (orange), indigenous gas (green) and stock draw (blue). There was a large step-change increase in indigenous production in January 2016 due to the connection of the Corrib gas field to the national gas grid. Indigenous production peaked in 2017 and has been slowly decreasing since then, which is commensurate with the natural life cycle of a gas field. The sharp drops in indigenous production in September 2017, July 2021 and July-August 2023 correspond to periods of maintenance at the Corrib gas field or its connection to the grid. In these periods of low indigenous production, the gas interconnectors between Ireland and Scotland stepped-up delivery of imports to satisfy demand. The monthly supply of gas to the grid can be 'spikey' because a substantial fraction of total gas supply is used for electricity generation which backs intermittent wind generation. In periods of low wind, gas supply to gas-fired electricity plants needs to increase, and vice versa. In June 2026, the 12-month moving average of gas supply had increased by 0.5% when compared to June 2025.

Figure 2.2.1: Monthly gas supply trends -January 2017 to June 2026

Source: data from GNI &amp; SEAI

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 2.2.2 shows the total gas supply to the grid by month, where each month's value is the average value of that month's gas supply, normalised for number of days in a month, over the previous 5 years. For example, the January value is the average of January in 2022, 2023, 2024, 2025 and 2026 and the July value is the average of July in 2021, 2022, 2023, 2024 and 2025. While certain sectors have pronounced seasonal variations, particularly the residential sector's gas demand for space heating, the overall seasonal variation in total gas supply is relatively small. Market-shifts act to flatten the profile of monthly gas supply across the year. In winter months, gas supply to the residential sector is higher for heating, but gas supply to electricity generation is lower (because wind generation has a seasonal peak). Conversely, in summer months, gas supply to the residential sector is lower, but gas supply to electricity generation is higher (because wind generation has a seasonal low).

Figure 2.2.2: Average monthly gas supply over the last 5 years (normalised for number of days per month)

<!-- image -->

Source: data from GNI &amp; SEAI

## 2.2.2 Monthly gas supply

As currently collected, the monthly gas supply data shown in Figure 2.2.3 is broken down into indigenous gas and imported gas. In general, indigenous supply is relatively constant on a month-tomonth basis (outside of periodic maintenance and the long-term declining trend) and imported gas is adjusted to match demand patterns, especially those arising from gas-fired electricity generation plants stepping-up and -down to back renewable generation of electricity.

Figure 2.2.3: Monthly gas supply -July 2025 to June 2026

Source: data from GNI &amp; SEAI

<!-- image -->

Figure 2.2.4 shows the breakdown of monthly gas supply data in 2026 by indigenous gas and imported gas, averaged over the last 12 calendar months, i.e. from July 2025 to June 2026. This approach is more appropriate than simply averaging over the year-to-date to June 2026, because of seasonal renewable contributions to electricity generation. In the last 12-months, the proportion of gas supplied to the gas network was:

• Imported gas 83.6%

• Indigenous gas 16.4%

Figure 2.2.4: Source of gas supply -July 2025 to June 2026

<!-- image -->

## 2.3 Oil and liquid biofuels

Monthly data on the delivery of both oil products and biofuel products to the Irish market is made available to SEAI through its access to the national Oil Levy Application (OLA) database, which is maintained and operated by the Department of Climate, Energy and the Environment (DCEE). SEAI uses data from D EE's   A database to satisfy several of Ireland's energy reporting obligations to the European Commission under the Energy Statistics Regulation No 1099/2008 (European Union, 2008, as amended), and to populate the national Energy Balance for Ireland.

Relevant obligated parties, for example large oil and liquid biofuel suppliers operating in the Irish market, are required to make monthly submission to the OLA database. Despite occasional corrections and revisions by these suppliers, the running total of monthly gross inland deliveries provides an excellent fastprovisional proxy for identifying trends in Ireland's demand for oil products and biofuel blending.

Monthly oil and biofuel supply is captured in terms of gross inland deliveries ( IDs), or 'The observed delivery of finished petroleum products from primary sources ( e.g. refineries, blending plants etc. ) to the inland market' and published in terms of net calorific value (N  ).  ID is the quantity of oil and biofuel products flowing through the market from production to delivery, now ready for sale or consumption:

Gross Inland Delivery (Observed) = Total sales for consumption + own consumption - international marine bunkers

## 2.3.1 Seasonality in monthly oil and liquid biofuel deliveries

Figure 2.3.1 shows the sum of monthly oil and road liquid biofuel deliveries from road diesel (sand), road gasoline (purple), jet kerosene (grey), gas oil (teal), heating kerosene (red), road biodiesels (lime green) and road bioethanol (dark green), fuel oil (lilac), LPG (light red), aviation biofuel (light blue) and other liquid biofuels (olive green) from January 2017 to June 2026. The black line shows a 12-month moving average of the sum of those monthly values and helps to identify underlying long-term trends. In June 2026, the 12-month moving average of oil and liquid biofuels supply had decreased by 1.4% when compared to June 2025.

Figure 2.3.1: Oil and liquid biofuel supply trends -January 2017 to June 2026

Source: data from Dept. of Climate, Energy and the Environment and SEAI

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 2.3.2 to Figure 2.3.5 breakout the monthly delivery of different oil products to better show their seasonal variation. Figure 2.3.2 shows the monthly deliveries of heating kerosene. It has a strong seasonal pattern with demand peaking in the height of winter and falling to about 16% of peak values in the summer months. The black line shows a 12-month moving average of those monthly values and helps to identify underlying long-term trends. In June 2026, the 12-month moving average of heating kerosene supply had decreased by 9.0% when compared to June 2025.

Figure 2.3.2: Trend in heating kerosene -January 2017 to June 2026

<!-- image -->

Source: data from Dept. of Climate, Energy and the Environment and SEAI

Figure 2.3.3 shows the monthly deliveries of jet kerosene and aviation biofuel. Deliveries of jet kerosene show peaks in summer months, due to the high volume of flights to and from Ireland for holidays and tourism. The black line shows a 12-month moving average of those monthly values and helps to identify underlying long-term trends. In June 2026, the 12-month moving average of jet kerosene and aviation biofuel supply had increased by 11.3% when compared to June 2025.

Figure 2.3.3: Trend in jet kerosene and aviation biofuel -January 2017 to June 2026

<!-- image -->

Source: data from Dept. of Climate, Energy and the Environment and SEAI

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 2.3.4 shows the monthly deliveries of road gasoline and bioethanol. It shows a gradual, but noticeable decline from 2017 to 2020, before being disrupted by COVID impacts. More recently, there were step change increases to the monthly bioethanol blend rate into road gasoline between April 2023 and August 2024. Since then, the bioethanol blend rate has remained relatively constant. The black line shows a 12-month moving average of those monthly values and helps to identify underlying long-term trends. In June 2026, the 12-month moving average of road gasoline and bioethanol supply had increased by 5.9% when compared to June 2025.

Figure 2.3.4: Trend in road gasoline and road bioethanol -January 2017 to June 2026

<!-- image -->

Source: data from Dept. of Climate, Energy and the Environment and SEAI

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 2.3.5 shows the monthly deliveries of road diesel. However, in contrast to motor petrol, road diesel shows a gradual but noticeable increase from January 2017 to January 2020. Since 2019, on average, there has been an increase in the monthly biodiesels blend rate into road diesel. The black line shows a 12-month moving average of those monthly values and helps to identify underlying longterm trends. In June 2026, the 12-month moving average of road diesel and biodiesels supply had decreased by 1.8% when compared to June 2025.

Figure 2.3.5: Trend in road diesel and road biodiesels -January 2017 to June 2026

<!-- image -->

Source: data from Dept. of Climate, Energy and the Environment and SEAI

## 2.3.2 Monthly oil and liquid biofuel supply in the last 12 months

Figure 2.3.6 shows the breakdown of monthly major oil product and liquid biofuel deliveries, by type over the last 12 months between July 2025 and June 2026. The seasonal variations in heating kerosene and jet kerosene are visible and tend to compensate for each other in the total oil deliveries, i.e. deliveries of jet kerosene are highest in summer, when deliveries of heating kerosene are lowest.

Figure 2.3.6: Monthly oil and liquid biofuel supply -July 2025 to June 2026

Source: data from Dept. of Climate, Energy and the Environment and SEAI

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 2.3.7 shows the percentage breakdown of major monthly oil product and liquid biofuel deliveries over the last 12 months (July 2025-June 2026) by type:

• Road diesel

37.5%

• Jet kerosene

17.7%

• Gas oil

12.5%

• Road gasoline

11.7%

• Heating kerosene

11.0%

• Road biodiesels

4.9%

• LPG

2.8%

• Road bioethanol

0.8%

• Other liquid biofuels

0.5%

• Aviation biofuel

0.4%

• Fuel oil

0.3%

## Figure 2.3.7: Breakdown of oil and liquid biofuel supply -July 2025 to June 2026

Source: data from Dept. of Climate, Energy and the Environment and SEAI

<!-- image -->

## 3 Monthly transformation estimates

Energy transformation involves converting one energy type into another, such as the conversion of natural gas and other primary energy products into electricity in electricity generation. The energy inputs to transformation processes are usually higher than the corresponding energy outputs due to the energy required to make the transformations and transformation losses from those processes. In addition, some energy is also lost or used before it reaches the final consumer in final energy consumption, through own use by power plants and electricity use in refineries, energy storage losses and transmission and distribution losses.

The transformation processes shown in this section are relevant to combustion activities only, as energy involved in exchange and transfers between energy products ( e.g. oil refining or electricity generation from renewable technologies such as wind, solar PV and hydro), energy storage ( e.g. pumped and battery storage) or electricity consumption in power plants and oil refining is not shown.

## 3.1 Transformation inputs

Figure 3.1.1 shows the combustion of energy products in energy transformation processes and highlights that the majority of this corresponds to energy input to public thermal power plants. Energy input to utility scale generators is calculated based on the metered electricity generated and uses average heat rates per generator type to calculate the monthly energy inputs to the generator units. Data on energy input to smaller, non-utility scale generators and energy input to own use is not captured on a monthly basis and is therefore estimated by averaging the annual energy use in previous years. You can find further details on the methodology used in Appendix 1. The black line shows a 12month moving average of those monthly values and helps to identify underlying long-term trends. In June 2026, the 12-month moving average of the energy input to transformation combustion processes had decreased by 7.5% when compared to June 2025.

Figure 3.1.1: Monthly energy input to transformation combustion processes

<!-- image -->

## 3.2 Public thermal power plant inputs

Figure 3.2.1 shows the monthly energy input to public thermal power plants, broken down by aggregated energy type and shows that electricity generation in public thermal power plants is dominated by generation from natural gas, especially in recent years. The black line shows a 12-month moving average of those monthly values and helps to identify underlying long-term trends. In June 2026, the 12-month moving average of the energy input to public thermal power plants had decreased by 8.4% when compared to June 2025.

Figure 3.2.1: Monthly energy input to public thermal power plants by energy type

<!-- image -->

iquid biofuels

## 4 Monthly final energy consumption estimates

Final energy consumption is the energy used by the final consuming sectors of industry, transport, residential, services, agriculture and fisheries. It excludes the energy consumed in the energy sector such as electricity generation, oil refining, electrical transmission and distribution losses and storage losses because this energy is not available to the end user.

SEAI collects and reports supply-side monthly statistics (see part 2, section 2 ) under the European Energy Statistics Regulation No 1099/2008 . However, as monthly data on final energy demand lies outside of the scope of the regulation, it is not collected or reported by SEAI on a monthly timescale. Therefore, the information available in this section are estimates of final energy consumption. Where available, this section uses monthly energy supply data and its past relationship to energy demand and where monthly energy supply data is unavailable, estimates are made based on annual energy quantities available in previous years. More detail on the methodology used can be found in Appendix 1.

## 4.1 Total final energy consumption

Figure 4.1.1 shows the sum of monthly final energy consumption estimates by energy type from oil (dark grey), electricity (blue), natural gas (yellow), non-renewable solid fuels (light grey), liquid biofuels (green), biomass, biogas and renewable waste (sand), and ambient heat and solar thermal (orange) from January 2017 to June 2026. The black line shows a 12-month moving average of monthly values and helps to identify underlying long-term trends. Monthly estimates show that oil continues to dominate final energy consumption into 2026 and that in recent years, final energy consumption has been increasing, on average, with the 12-month moving average of monthly final energy consumption increasing by 1.1% in June 2026 vs June 2025.

Figure 4.1.1: Monthly final energy consumption by energy type - January 2017 to June 2026

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 4.1.2 shows the sum of monthly final energy consumption estimates by road transport (blue), other transport excluding international aviation ( i.e . rail, domestic aviation, pipeline transport and domestic navigation) (grey), international aviation (orange) and non-transport final energy consumption ( i.e. industry, services, agriculture, fisheries) (yellow). When aggregated together, all other sectors of final energy consumption outside of transport had the largest share of final energy consumption in a given month. Road transport had the second largest share in a given month, followed by international aviation and other transport.

Figure 4.1.2: Monthly final energy consumption by sector

<!-- image -->

## 4.2 Transport final energy consumption

Final energy consumption in the transport sector includes the energy used in all transport activities irrespective of the NACE category (economic sector) that the activity occurs in. Energy types used for heating and lighting at railway stations, bus stations, shipping piers and airports are included in the services sector and not in the transport sector. The transport sector includes: road, international aviation, rail, domestic navigation, pipeline transport and domestic aviation transport sub-sectors.

Figure 4.2.1 shows the sum of monthly transport final energy consumption estimates by energy subtype from January 2017 to June 2026. The black line shows the 12-month moving average of the total transport final energy use. Monthly transport final energy consumption is dominated by fossil fuels, in particular road diesel. In June 2026, the 12-month moving average of transport final energy consumption had increased by 2.6% when compared to June 2025.

## Figure 4.2.1: Monthly total transport final energy consumption by energy type

<!-- image -->

Figure 4.2.2 shows the sum of monthly road transport final energy use split by road diesel (sand), road gasoline (purple), road biodiesels (lime green), road bioethanol (dark green), electricity (blue), other (orange) and other liquid biofuels (olive green). The black line shows the 12-month rolling average of the road transport final energy use. In June 2026, the 12-month moving average of road transport final energy consumption had increased by 0.2% when compared to June 2025.

Figure 4.2.2: Monthly road transport final energy consumption by energy type

<!-- image -->

## 5 Monthly energy-related emissions estimates

Energy-related emissions are those which arise from the combustion of energy products and fugitive emissions which arise from their production, transport and distribution. In this section, greenhouse gas emission quantities from combustion of energy products have been calculated using the monthly energy quantity estimates in part 2 , sections 3 and 4 of this report, along with energy product and sector specific data from the EPA's National Inventory Submissions . 8 2026 fugitive emissions have been estimated by averaging the latest data available for recent years in the EPA's Provisional  reenhouse Gas Emissions 1990-2025. 9  More detail on the methodology used can be found in Appendix 1.

## 5.1 Total fuel combustion

While the majority of energy-related emissions arise from the direct combustion of energy products by the end user in final energy consumption, energy-related emissions also occur through combustion of energy products in energy transformation processes ( e.g. electricity generation by public thermal power plants and auto-producers, and through oil refining activities) and also in own use and distribution losses.

To help show the energy quantities behind the energy-related emissions estimates, Figure 5.1.1 shows the sum of monthly energy in fuel combustion activities by stream, split down into: final energy consumption excluding international aviation (blue), international aviation (orange), public thermal power plants (purple) and auto-producers, refining and own use (light blue). The black line shows a 12month moving average of monthly values and helps to identify underlying long-term trends. The 12month moving average of monthly energy in fuel combustion activities decreased by 1.9% in June 2026 vs June 2025.

Figure 5.1.1: Total monthly energy in fuel combustion activities by stream

<!-- image -->

tre

<!-- image -->

<!-- image -->

inal energy consumption (excl. int. aviation)

International aviation

<!-- image -->

Public thermal power plants

- Auto producers, re ning   own use

<!-- image -->

## 5.2 Total energy-related emissions

This section presents the emissions associated with energy-related combustion activities in final energy consumption, energy transformation processes and own use and distribution losses. For transport sector completeness, emissions associated with international aviation are also included in this section 10 , however, fugitive emissions are not included in this section.

Figure 5.2.1shows the total monthly energy-related emissions (including international aviation). The black line shows the 12-month rolling average values to help identify long term trends. The 12-month rolling average shows that in recent years, on average, the total monthly energy-related emissions, including those from international aviation have been decreasing over time, with the 12-month moving average of total monthly energy-related emissions (including international aviation) having decreased by 3.9% in June 2026 vs June 2025.

Figure 5.2.1: Total monthly energy-related emissions (including international aviation)

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 5.2.2 shows the sum of monthly energy-related emissions by stream, broken out into: final energy consumption excluding international aviation (blue), international aviation (orange), public thermal power plants (purple) and auto-producers, refining and own use (light blue). The lines show 12month moving averages of monthly values in each stream and help to identify underlying long-term trends in each. The graph shows that most energy-related emissions come from final energy consumption excluding international aviation, followed by public thermal power plants, international aviation and then auto-producers, refining and own use. The 12-month moving averages show that, in recent years, on average, there have been reductions in emissions across final energy consumption (excluding international aviation) and in electricity generation from public thermal power plants. The 12-month averages of emissions from public thermal power plants and final energy consumption (excluding international aviation) had decreased by 14.4% and 2.8%, respectively, in June 2026 vs June 2025. In contrast, the 12-month average of emissions from international aviation increased, up 8.9% in the same period.

Figure 5.2.2: Total monthly energy-related emissions by stream

<!-- image -->

- Public thermal power plants
- Auto producers, re ning   own use

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 5.2.3 shows the total monthly energy-related emissions by stream, broken out in more detail into: the transport sector excluding international aviation (grey), non-transport final energy consumption (yellow), international aviation (orange), public thermal power plants (purple) and autoproducers, refining and own use (light blue). This graph shows the seasonality of emissions arising from non-transport final energy consumption. The lines show 12-month moving averages of monthly values in each stream and help to identify underlying long-term trends in each. The graph shows that in recent years, most energy-related emissions come from transport (excluding international aviation), followed by non-transport final energy consumption, public thermal power plants, international aviation and then auto-producers, refining and own use. The 12-month moving averages show that, in recent years, on average, there have been reductions in emissions across both transport (excluding international aviation) and non-transport final energy consumption. The 12-month averages had decreased by 2.4% and 3.3%, respectively, in June 2026 vs June 2025.

Figure 5.2.3: Total monthly energy-related emissions by stream (including transport sector breakout)

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 5.2.4 shows the sum of total monthly energy-related emissions by energy type, broken out into oil (dark grey), natural gas (yellow), non-renewable solid fuels (light grey), biomass, biogas and renewable waste (sand) and liquid biofuels (green). The lines show 12-month moving averages of monthly values for each energy type and help to identify underlying long-term trends in each. The graph shows that oil dominates total monthly energy-related emissions (including international aviation), followed by natural gas and non-renewable solid fuels. The 12-month moving averages show that, in recent years, on average, there have been reductions in emissions from the combustion of oil and non-renewable solid fuels, while emissions from natural gas have remained relatively constant. The 12-month average emissions from non-renewable solid fuels had decreased by 25.1% in June 2026 vs June 2025, while the 12-month average emissions from oil had decreased by 3.7% in the same period.

Figure 5.2.4: Total monthly energy-related emissions by energy type

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 5.2.5 shows total monthly transport emissions (including international aviation) by transport energy sub-type, broken out into road diesel (sand), jet kerosene (grey), road gasoline (purple), gasoil (teal), other (orange), road biodiesels (lime green), road bioethanol (dark green), aviation biofuel (light blue) and other liquid biofuels (olive green). Upstream emissions associated with electricity consumption in transport are not shown in this graph. The black line shows the 12-month moving average of the total transport emissions from direct combustion. The graph shows that transport emissions are dominated by emissions from the combustion of road diesel, followed by jet kerosene emissions and road gasoline emissions. The 12-month moving average of total monthly transport emissions, including international aviation, increased by 0.2% in June 2026 vs June 2025.

Figure 5.2.5: Total monthly transport emissions by energy type

<!-- image -->

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Figure 5.2.6 shows total monthly road transport emissions by road transport energy sub-type, broken out into road diesel (sand), road gasoline (purple), road biodiesels (lime green), road bioethanol (dark green), other liquid biofuels (olive green) and other (orange). Upstream emissions associated with electricity consumption in transport are not shown in this graph. The black line shows the 12-month moving average of road transport emissions from direct combustion. The graph shows that road transport emissions are dominated by emissions from the combustion of road diesel and subsequently, from road gasoline. The 12-month moving average of road transport emissions, decreased by 2.2% in June 2026 vs June 2025.

Figure 5.2.6: Monthly road transport emissions by energy type

<!-- image -->

## 5.3 National energy-related emissions

This section presents national energy-related emissions. In line with international reporting guidance from the Intergovernmental panel on Climate Change (IPCC) and the United Nations Framework Convention on Climate Change (UNFCCC), 11  these national energy-related emissions do not include emissions associated with international bunker fuels used in international aviation and marine bunkers. Under the same guidelines, they do include fugitive emissions associated with oil refining/storage and natural gas production and distribution.

Figure 5.3.1 outlines the differences between 'total' and ' n ational' energy -related emissions within Part 2, Section 5 of this report.

## Figure 5.3.1 ry o   i  eren es  et een ' ot  '  n  ' t n tion  ' ener y -related emissions

<!-- image -->

Figure 5.3.2 shows the monthly national energy-related emissions as the sum of emissions associated with energy-related combustion activities in final energy consumption (excluding international aviation), energy transformation processes, and own use and distribution losses. The black line shows the 12-month rolling average to help identify long term trends. The 12-month rolling average shows that in recent years, on average, the monthly national energy-related emissions have been decreasing over time, with the 12-month moving average having decreased by 5.3% in June 2026 vs June 2025.

Figure 5.3.2: Monthly national energy-related emissions

<!-- image -->

These early emission estimates also summarise energy-related emissions in the context of the electricity 12 and transport 13  sectoral emissions ceilings. Figure 5.3.3 shows monthly national energyrelated emissions, broken out into Electricity (blue) and Transport (grey) sectoral emissions ceilings, with the remainer of energyrelated emissions included as ' eat and other energy' (red). The lines show 12-month moving averages of monthly values for each category and help to identify underlying longterm trends in each. The seasonality in heat and other energy emissions can be clearly observed. In addition, the graph shows that, on average, heat and other energy emissions and transport sectoral emissions ceiling emissions have been the 2 largest contributors to national energy-related emissions in recent years, followed by emissions in the electricity sectoral emissions ceiling. The 12-month averages of emissions in June 2026 vs June 2025 showed decreases across all three categories: down by 14.3%, 2.3% and 3.2%, for emissions in the electricity sectoral emissions ceiling, transport sectoral emissions ceiling and in heat and other energy-related emissions, respectively.

Figure 5.3.3: Monthly national energy-related emissions under the electricity and transport sectoral emissions ceilings, along with heat and other energy-related emissions

<!-- image -->

In July, the EPA published 'Ireland's Provisional Greenhouse Gas Emissions 1990-2025 14  and their definitive national emissions statistics for Ireland in the first carbon budget is expected to be published through Ireland's National Inventory Submissions in quarter 1 2027.

12 The 'Electricity' sectoral emission s ceiling includes emissions from 'Public electricity and heat production' (main activity electricity and heat production, IP   code  .A. .a), 'Manufacture of solid fuels and other energy industries' (IP   code  .A. 1.c) and ' ugitive emissions' (IPCC codes 1.B.1 and 1.B.2). An estimate of fugitive emissions in 2026 have been included based on an average of past greenhouse gas quantities from the EPA's 'Ireland's Provisional  reenhouse  as Emissions          ' -publication.

13 Emissions associated with international aviation are excluded from the 'Transport' sectoral emissions ceiling. The transport sectoral emissions ceiling also includes a portion of natural gas classified as own use and distribution losses in the National Energy alance as pipeline transport. The 'Transport' sectoral emission ceiling includes emissions from ' Domestic aviation  (IPCC ' 1.A.3.a), ' oad transportation  (IPCC 1.A.3.b) ' , ' ailways  (IPCC 1.A.3.c) ' , 'D omestic navigation  (IPCC 1.A.3.d) ' and ' ther transportation  (IPCC 1.A.3.e). '

14 Ireland's Provisional  reenhouse  as Emissions -2025 (EPA): https://www.epa.ie/publications/monitoring-assessment/climate-change/air-emissions/irelands-provisional-greenhouse-gas-emissions-1990-2025.php

## Appendix 1 Data &amp; methodology

Regulation (EC) No 1099/2008 on energy statistics, referred to as the Energy Statistics Regulation or ESR, is the key EU legislation that sets out the requirements for compiling and reporting annual and monthly national energy statistics.

## A1Monthly supply statistics

Energy supply statistics are collected by SEAI and reported to the European Commission on a monthly basis under the European Energy Statistics Regulation No 1099/2008 .

## A1.1 Monthly electricity data

SEAI receives utility scale supply of electricity, i.e. the electricity supplied by large-scale grid-connected sites, and through international interconnectors from EirGrid every month. While this utility scale data does not capture instances of mini- or micro-generation of electricity, or the relatively small quantity of auto-consumption 15  in Ireland, it acts as an excellent proxy for identifying trends in the supply and demand of electricity in Ireland.

## A1.2 Monthly gas data

SEAI uses public data from the Gas Network Ireland (GNI) dashboard, and monthly survey returns from GNI and the Corrib Gas Field , to determine Ireland's national gas supply, and its split across indigenous production and imports flows. The gas supply data used to satisfy international reporting obligations is expressed in terms of gross calorific value (GCV). The net calorific value (NCV) can be calculated from the gross calorific value (GCV) by multiplying by a factor of 0.902.

## A1.3 Monthly oil data

Monthly data on the inland delivery of oil and biofuel products to the Irish market is made available to SEAI through the national Oil Levy Application (OLA) database, which is maintained and operated by the Department of Climate, Energy and the Environment (DCEE). Relevant obligated parties, i.e. large oil suppliers operating in the Irish market, are required to make monthly submission to the OLA database.

As well as collecting data on oil and biofuel supplied to all sectors, the OLA database also collects data on the supply of natural gas and biomethane for use in road transport.

The gross inland delivery of oil and biofuel products correspond to the quantities of products flowing through the market from production, importation or storage and sold for consumption or consumed by the supplier itself ( i.e. own consumption). Refinery outputs, imports, and stock draws all act to increase gross inland delivery quantities. Exports, international marine bunkers ( i.e. products purchased for and consumed by vessels carrying out international shipping), and stock-builds all act to decrease gross inland delivery quantities. Inter-product transfers describe the reclassification of products and are therefore reported as a negative value for one product, compensated by a positive value for another product.

Oil and biofuel delivery data is sourced from the OLA database in units of volume ( i.e. litres) with SEAI making the conversion to units of energy. Monthly oil delivery data is published in terms of net calorific value (NCV).

15 Electricity that is generated and consumed on-site without being exported to the distribution or transmission system.

## A2 Monthly energy and emissions estimates

Disaggregated demand-side energy data is not collected and reported to the European Commission on a monthly basis as it lies outside of the scope of the European Energy Statistics Regulation No 1099/2008 . In part 2, section 5 of this report, SEAI uses the monthly supply-side data 16  and annual data from the National Energy Balance 17  to calculate monthly energy and emissions estimates.

## A2.1 Monthly energy estimates

SEAI calculates monthly estimates on the quantities of energy used in transformation, own use and final energy consumption processes using a combination of in-year monthly energy supply statistics and previous annual energy data from SEAI's National Energy  alance. The fuel input to utility scale electricity generation is calculated from the average heat rate, and fuel mix, per generator type, with the electricity generated taken from monthly supply statistics. Energy quantities of natural gas, oil products and liquid biofuels are modelled from previous supply-demand relationships using monthly supply statistics as an input. For energy types not covered by monthly energy statistics, estimates are calculated from the latest data available in the National Energy Balance. Where these energy products that are not covered by monthly energy statistics are used outside the industry sector, it is assumed that their consumption follows a seasonal pattern similar to that of residential natural gas, using data which is kindly provided by Gas Network Ireland.

## A2.2 Monthly emissions estimates

To calculate monthly greenhouse gas quantities derived from energy-related combustion activities, SEAI uses the monthly energy estimates outlined in section A2.1 above. The latest available sectoral and fuel specific greenhouse gas (implied) emission factors are then applied to estimate the quantity of greenhouse gases produced. These (implied) emission factors are available from the EPA's National Inventory Submissions 18  in units of t/TJ. The greenhouse gases covered in these estimates include carbon dioxide (CO2), methane (CH4) and nitrous oxide (N2O), each of which have different 100-year global warming potentials (GWP100), relevant to CO2. Therefore, to calculate total greenhouse gas quantities in terms of CO2eq, 100-year global warming potentials have been adapted from the IPCC Fifth Assessment Report (AR5), 19  following the approach taken by the EPA in their latest inventory submissions.

In the context of part 2, section 5 of this report, 'total' energy -related emissions refer to energy-related emissions from combustion. They include emissions from international aviation (for transport sector completeness and information), but exclude fugitive emissions. As outlined by the EPA in their National Inventory Document and in line with international reporting guidance from the Intergovernmental panel on Climate Change (IPCC) and the United Nations Framework Convention on Climate Change (UNFCCC),  n ' ational' energy -related emissions exclude emissions from international aviation (international bunkers), but include fugitive emissions.

16 Monthly Energy Data webpages: https://www.seai.ie/data-and-insights/seai-statistics/monthly-energy-data

17

National Energy Balance: https://www.seai.ie/data-and-insights/seai-statistics/key-publications/national-energy-balance

18 National Inventory Submissions (EPA): https://www.epa.ie/publications/monitoring--assessment/climate-change/airemissions/irelands-national-inventory-submissions-2026.php

19 olumn ' WP     year' in Table  .A.  of Appendix  .A of the report ' limate  hange       The Physical Science  asis. -ontribution of Working  roup I to the  ifth Assessment  eport of the Intergovernmental Panel on  limate  hange' .

## Energy in Ireland 2026: Part 2 - Monthly energy data to June 2026

Energy-related emissions estimates summarised in the context of the Electricity sectoral emissions ceilings 20 follows the EPA's approach to mapping Ireland's  reenhouse  as Inventory to the sectoral emissions ceiling sectors 21 .  This includes emissions from:

- · Public electricity and heat production (main activity electricity and heat production, IPCC code 1.A.1.a).
- · Manufacture of solid fuels and other energy industries (IPCC code 1.A.1.c).
- · Fugitive emissions (IPCC codes 1.B.1 and 1.B.2).

Similarly, energy-related emissions estimates summarised in the context of the Transport sectoral emissions ceilings takes a similar approach. This includes emissions from:

- · Domestic aviation (IPCC 1.A.3.a).
- · Road transportation (IPCC 1.A.3.b).
- · Railways (IPCC 1.A.3.c).
- · Domestic navigation (IPCC 1.A.3.d).
- · Other transportation (IPCC 1.A.3.e).

20 The government adopted sectoral emissions ceilings setting out the maximum amount of greenhouse gas emissions that are permitted in different sectors of the economy during the first two carbon budget periods (DCEE):

https://www.gov.ie/en/publication/76864-sectoral-emissions-ceilings/

21 Ireland's Provisional  reenhouse  as Emissions -2025 (EPA): https://www.epa.ie/publications/monitoring-assessment/climate-change/air-emissions/irelands-provisional-greenhouse-gas-emissions-1990-2025.php

## Appendix 2 Table of figures

| Figure 2.1.1: Monthly utility scale electricity supply - January 2017 to June 2026......................................... Figure 2.1.2: Monthly renewable and non-renewable utility scale electricity supply - January 2017 to                                             | 5                                                                                                                                                                           |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| June 2026..................................................................................................................................................................                                                                                                  | 6                                                                                                                                                                           |
| Figure 2.1.3: Average monthly utility scale electricity supply over last 5 years (normalised for number                                                                                                                                                                      | of                                                                                                                                                                          |
| days per month)......................................................................................................................................................                                                                                                        | 7                                                                                                                                                                           |
| Figure 2.1.4: Share of renewable and non-renewable sources in utility scale electricity supply - July                                                                                                                                                                        | 2025                                                                                                                                                                        |
| to June 2026.............................................................................................................................................................                                                                                                    | 8                                                                                                                                                                           |
| Figure 2.1.5: Share of utility scale electricity supply split by indigenous generation and net imports -                                                                                                                                                                     | July                                                                                                                                                                        |
| 2017 to June 2026 ...................................................................................................................................................                                                                                                        | 9                                                                                                                                                                           |
| Figure 2.1.6: Monthly utility scale electricity generation - July 2017 to June 2026.......................................10                                                                                                                                                 |                                                                                                                                                                             |
| Figure 2.1.7: Monthly renewable and non-renewable utility scale electricity generation - January 2017                                                                                                                                                                        | to                                                                                                                                                                          |
| June 2026................................................................................................................................................................                                                                                                    | 11                                                                                                                                                                          |
| 2.1.8: Monthly utility scale electricity generation split by generator type - January 2017 to                                                                                                                                                                                |                                                                                                                                                                             |
| Figure June 2026                                                                                                                                                                                                                                                             | ........................................................................................................................................................................ 12 |
| Figure 2.1.9: Monthly electricity generation by source - July 2025 to June 2026.........................................13                                                                                                                                                   |                                                                                                                                                                             |
| Figure 2.1.10: Sources of electricity generation - July 2025 to June 2026.....................................................14                                                                                                                                             |                                                                                                                                                                             |
| Figure 2.1.11: Monthly imported and exported electricity (with net imports) - July 2017 to June                                                                                                                                                                              | 2026...15                                                                                                                                                                   |
| Figure 2.2.1: Monthly gas supply trends - January 2017 to June 2026..........................................................                                                                                                                                                | 16                                                                                                                                                                          |
| Figure 2.2.2: Average monthly gas supply over the last 5 years (normalised for number of days per month).................................................................................................................................................................... | 17                                                                                                                                                                          |
| Figure 2.2.3: Monthly gas supply - July 2025 to June 2026..............................................................................                                                                                                                                      | 18                                                                                                                                                                          |
| Figure 2.2.4: Source of gas supply - July 2025 to June 2026............................................................................                                                                                                                                      | 19                                                                                                                                                                          |
| Figure 2.3.1: Oil and liquid biofuel supply trends - January 2017 to June 2026...........................................21                                                                                                                                                  |                                                                                                                                                                             |
| Figure 2.3.2: Trend in heating kerosene - January 2017 to June 2026 ..........................................................                                                                                                                                               | 22                                                                                                                                                                          |
| Figure 2.3.3: Trend in jet kerosene and aviation biofuel - January 2017 to June 2026 ...............................                                                                                                                                                         | 23                                                                                                                                                                          |
| Figure 2.3.4: Trend in road gasoline and road bioethanol - January 2017 to June 2026 ............................                                                                                                                                                            | 24                                                                                                                                                                          |
| Figure 2.3.5: Trend in road diesel and road biodiesels - January 2017 to June 2026..................................25                                                                                                                                                       |                                                                                                                                                                             |
| Figure 2.3.6: Monthly oil and liquid biofuel supply - July 2025 to June 2026................................................26                                                                                                                                               |                                                                                                                                                                             |
| Figure 2.3.7: Breakdown of oil and liquid biofuel supply - July 2025 to June 2026......................................27                                                                                                                                                    |                                                                                                                                                                             |
| Figure 3.1.1: Monthly energy input to transformation combustion processes............................................28                                                                                                                                                      |                                                                                                                                                                             |
| Figure 3.2.1: Monthly energy input to public thermal power plants by energy type ..................................                                                                                                                                                          | 29                                                                                                                                                                          |
| Figure 4.1.1: Monthly final energy consumption by energy type - January 2017 to June 2026..................30                                                                                                                                                                |                                                                                                                                                                             |
| Figure 4.1.2: Monthly final energy consumption by sector.............................................................................                                                                                                                                        | 31                                                                                                                                                                          |
| Figure 4.2.1: Monthly total transport final energy consumption by energy type ........................................                                                                                                                                                       | 32                                                                                                                                                                          |
| Figure 4.2.2: Monthly road transport final energy consumption by energy type ........................................                                                                                                                                                        | 32                                                                                                                                                                          |
| Figure 5.1.1: Total monthly energy in fuel combustion activities by stream ................................................                                                                                                                                                  | 33                                                                                                                                                                          |
| Figure 5.2.1: Total monthly energy-related emissions (including international aviation)...........................34                                                                                                                                                         |                                                                                                                                                                             |
| Figure 5.2.2: Total monthly energy-related emissions by stream..................................................................35                                                                                                                                           |                                                                                                                                                                             |
| Figure 5.2.3: Total monthly energy-related emissions by stream (including transport sector breakout)                                                                                                                                                                         | 36                                                                                                                                                                          |
| Figure 5.2.4: Total monthly energy-related emissions by energy type..........................................................                                                                                                                                                | 37                                                                                                                                                                          |
| Figure 5.2.5: Total monthly transport emissions by energy type................................................................... Figure 5.2.6: Monthly road transport emissions by energy                                                                                   | 38 type.................................................................... 39                                                                                              |
| igure . . Summary of differences between 'total' and 'national' energy -related emissions.................40                                                                                                                                                                 |                                                                                                                                                                             |
| Figure 5.3.2: Monthly national energy-related emissions ...............................................................................                                                                                                                                      | 40                                                                                                                                                                          |
| Figure 5.3.3: Monthly national energy-related emissions under the electricity and transport sectoral                                                                                                                                                                         |                                                                                                                                                                             |
| emissions ceilings, along with heat and other energy-related emissions.....................................................41                                                                                                                                                |                                                                                                                                                                             |

## Appendix 3 Glossary of abbreviations

| Abbreviation   | Explanation                                       |
|----------------|---------------------------------------------------|
| BEUS           | Business Energy Use Survey                        |
| CAP            | Climate action plan                               |
| CCGT           | Combined cycle gas turbine                        |
| CHP            | Combined heat and power                           |
| CO 2           | Carbon dioxide                                    |
| CO 2 eq        | Carbon dioxide equivalent                         |
| CSO            | Central Statistics Office                         |
| DART           | Dublin Area Rapid Transit                         |
| DCEE           | Department of Climate, Energy and the Environment |
| EPA            | Environmental Protection Agency                   |
| ETS            | EU Emission Trading Scheme                        |
| EV             | Electric vehicle                                  |
| FEC            | Final energy consumption                          |
| GCV            | Gross calorific value                             |
| GDP            | Gross domestic product                            |
| GFC            | Gross final consumption (of energy)               |
| GHG            | Greenhouse gas                                    |
| GNI*           | Modified gross national income                    |
| GNP            | Gross national product                            |
| goe            | Gramme of oil equivalent                          |
| GWh            | Gigawatt hour                                     |
| HGV            | Heavy goods vehicle                               |
| HVO            | Hydrotreated vegetable oil                        |
| ICT            | Information and communications technology         |
| IEA            | International Energy Agency                       |
| IP             | Intellectual property                             |
| IPCC           | Intergovernmental Panel on Climate Change         |
| ktoe           | Kilotonne of oil equivalent                       |
| LFG            | Landfill gas                                      |
| LNG            | Liquefied natural gas                             |

| Abbreviation   | Explanation                                                                                                 |
|----------------|-------------------------------------------------------------------------------------------------------------|
| MDD            | Modified domestic demand                                                                                    |
| NCT            | National Car Testing                                                                                        |
| NCV            | Net calorific value                                                                                         |
| NECP           | National Energy and Climate Plan                                                                            |
| NEDC           | New European Driving Cycle                                                                                  |
| NEEAP          | National energy efficiency action plan                                                                      |
| NORA           | National Oil Reserves Agency                                                                                |
| NREAP          | National renewable energy action plan                                                                       |
| NRW            | Non-renewable waste                                                                                         |
| OECD           | Organization for Economic Co-operation and Development                                                      |
| PV             | Photovoltaic                                                                                                |
| R&D            | Research and development                                                                                    |
| RED            | Renewable Energy Directive                                                                                  |
| RED I          | First Renewable Energy Directive - Directive 2009/28/EC                                                     |
| RED II         | Recast Renewable Energy Directive - Directive (EU) 2018/2001                                                |
| RED III        | Updated recast Renewable Energy Directive - Directive (EU) 2018/2001 as amended by Directive (EU) 2023/2413 |
| RES            | Renewable energy share                                                                                      |
| RES-E          | Renewable energy share in electricity                                                                       |
| RES-H          | Renewable energy share in heat                                                                              |
| RES-T          | Renewable energy share in transport                                                                         |
| SEAI           | Sustainable Energy Authority of Ireland                                                                     |
| TFC            | Total final energy consumption                                                                              |
| TJ             | Terajoule                                                                                                   |
| toe            | Tonne of oil equivalent                                                                                     |
| TPER           | Total primary energy requirement                                                                            |
| TWh            | Terawatt hour                                                                                               |
| UCO            | Used cooking oil                                                                                            |
| UNFCCC         | United Nations Framework Convention on Climate Change                                                       |
| VOC            | Volatile organic compounds                                                                                  |
| WLTP           | Worldwide Harmonised Light Vehicle Test Procedure                                                           |

## Appendix 4 Glossary of terms

Autoproducer: Regulation (EC) No 1099/2008 defines autoproducers as private or publicly owned producers that generate electricity and/or heat wholly or partly for their own use which supports their primary activity. Examples of autoproducers are rooftop solar PV on homes or CHP units at manufacturing sites. Autoproducers may or may not export electricity to the grid.

Biomass: Directive (EU) 2018/2001 defines biomass as the biodegradable fraction of products, waste and residues from biological origin from agriculture, including vegetal and animal substances, from forestry and related industries, including fisheries and aquaculture, as well as the biodegradable fraction of waste, including industrial and municipal waste of biological origin.

Carbon dioxide (CO2): A compound of carbon and oxygen formed when carbon is burned. Carbon dioxide is one of the main greenhouse gases. Units used in this report are t CO2 -tonnes of CO2, kt CO2 -kilotonnes of CO2 (10 3  tonnes) and MtCO2 -megatonnes of CO2 (10 6  tonnes).

Carbon dioxide equivalent (CO2eq): Used as a measure of the global warming impact of greenhouse gases on the basis of their global warming potential. Quantities of gases other than CO2 are converted into equivalent quantities of CO2 based on their global warming potential.

Carbon intensity (gCO2/kWh) : This is the amount of CO2 that will be released per kWh of energy of a given fuel. For most fossil fuels the value of this is almost constant, but in the case of electricity it will depend on the fuel mix used to generate the electricity and also on the efficiency of the technology employed.

Combined heat and power (CHP) plants : CHP refers to plants which are designed to produce both heat and electricity, for own use only or third-party owned and selling electricity and heat on site as well as exporting electricity to the grid.

Energy intensity : The amount of energy used per unit of activity. Examples of activity used in this report are gross domestic product (GDP), value added, number of households, employees, etc. Where possible, the monetary values used are in constant prices.

Gross and net calorific value (GCV and NCV) : The GCV gives the maximum theoretical heat release during combustion, including the latent heat of condensation of the water vapour produced during combustion. This water is produced by the combustion of the hydrogen in the fuel, or in some cases from the evaporation of water already present in the fuel. The NCV excludes this heat of condensation because it cannot be recovered in conventional boilers. For natural gas, the difference between GCV and NCV is about 10%, for oil it is approximately 5%.

Gross domestic product (GDP) : The GDP represents the total output of the economy over a period.

Gross electricity production: Gross electricity production is measured at the output terminals of the main generator or inverter; it therefore includes the energy taken by station auxiliaries and losses in transformers that are considered integral parts of the station. The difference between gross and net production is the amount of own use of electricity in the generation plants.

Gross final consumption (GFC) : Directive (EU) 2018/2001 defines gross final consumption of energy as ' the energy commodities delivered for energy purposes to industry, transport, households, services including public services, agriculture, forestry and fisheries, the consumption of electricity and heat by the energy branch for electricity and heat production, and losses of electricity and heat in distribution and transmission .'

Gross inland energy consumption : Sometimes abbreviated as gross inland consumption, is the total energy demand of a country or region. It represents the quantity of energy necessary to satisfy inland consumption of the geographical entity under consideration.

Heating degree days 'Degree days' is the measure or index used to take account of the severity of the weather when looking at energy use in terms of heating (or cooling) 'load' on a building. A degree day is an expression of how cold (or warm) it is outside, relative to a day on which little or no heating (or cooling) would be required. It is thus a measure of the cumulative temperature deficit (or surplus) of the outdoor temperature relative to a neutral target temperature (base temperature) at which no heating or cooling would be required.

Main activity producer: Regulation (EC) No 1099/2008 defines main activity producers as a privately or publicly owned producers that generate electricity and/or heat for sale to third parties as their principal activity.

Modified gross national income (GNI*) : Modified gross national income (or GNI*) was introduced by the CSO in 2017 to assess the level of activity in the Irish economy excluding the effects of globalisation that disproportionately affect the Irish economic results. GNI* is defined as GNI less the effects of the profits of re-domiciled companies and the depreciation of intellectual property products and aircraft leasing companies.

Nominal and real values : Nominal value refers to the current value expressed in money terms in a given year, whereas real value adjusts nominal value to remove effects of price changes and inflation to give the constant value over time indexed to a reference year.

Total final consumption (TFC) : This is the energy used by the final consuming sectors of industry, transport, residential, services, agriculture and fisheries. It excludes the energy sector: electricity generation, oil refining, etc. Also referred to as total final energy consumption.

Total primary energy requirement (TPER) : This is the total requirement for all uses of energy, including energy used to transform one energy form to another (such as burning fossil fuel to generate electricity) and energy used by the final consumer.

Value added : Value added is an economic measure of output. The value added of industry, for instance, is the additional value created by the production process through the application of labour and capital. It is defined as the value of industry's output of goods and services less the value of the intermediate consumptions of goods (raw materials, fuel, etc. ) and services.

Wastes (non-renewable) : The non-renewable portion of wastes used as an energy source.

Weather correction : Annual variations in weather affect the space heating requirements of occupied buildings. Weather correction involves adjusting the energy used for space heating by benchmarking the climate in a particular year with that of a long-term average measured in terms of number of degree days.

For additional appendices, please see part 3 of the report

## Appendix 5 Version control

|   Version | Date     | Description / Notes           |
|-----------|----------|-------------------------------|
|       0.1 | 27/08/26 | Energy statistics draft       |
|       0.2 | 14/10/26 | Energy statistics review      |
|       0.3 | 16/10/26 | Pre-release circulation       |
|       0.4 | 19/10/26 | Pre-release formatting review |
|       1   | 21/10/26 | Publication                   |

<!-- image -->

## Sustainable Energy Authority of Ireland

Three Park Place Hatch Street Upper Dublin 2 Ireland D02 FX65

e

info@seai.ie

w  www.seai.ie

t

+353 1 808 2100

<!-- image -->

<!-- image -->