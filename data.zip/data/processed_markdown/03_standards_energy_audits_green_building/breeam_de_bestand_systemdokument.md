---
document_id: breeam_de_systemdokument
title: "BREEAM DE Bestand: Systemdokument (System Standard)"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "BREEAM D-A-CH / DIFU"
year: 2022
original_file: "breeam_de_bestand_systemdokument.pdf"
tables_detected: 5
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## 1 EINLEITUNG

## 1.1 RAHMEN

Dieses  Dokument  regelt  die  Prozesse  der  Zertifizierung  nach  BREEAM  CH  Bestand  zwischen  TÜV  SÜD  Industrie Service GmbH (TÜV SÜD-DIFNI), den Kunden und Auditoren. Es ist anwendbar auf die Bewertung und Zertifizierung von BREEAM CH Bestand in der Schweiz.

Hinweis: Auditoren, die Projekte im BREEAM CH Bestand Online-Tool registrieren, bewerten diese nach TÜV SÜDDIFNIs BREEAM CH Bestand.

Professionelle Sachverständiger, Facility Manager und Gebäudetechnik-Inspektoren sind die Zielgruppe für die Auditor Rolle.

## 1.2 NATIONAL SCHEME OPERATOR (NSO)

BREEAM CH Bestand ist eine Adaption des BREEAM International In-Use Systems (im Besitz und betrieben von BRE Global). Ländervertretungen von BREEAM vertreiben länderspezifische Versionen des BREEAM Int. In-Use Systems. Generell gilt: Wenn eine Ländervertretung eine nationale Adaption zur Anwendung im jeweiligen Land vertreibt, ist diese anzuwenden.

Kunden mit Projekten in der Schweiz müssen diese durch den Auditor bei TÜV SÜD-DIFNI registrieren lassen und zur Zertifizierung BREEAM CH Bestand anwenden.

## 1.3 FRAGEN / BEDENKEN / BESCHWERDEN

Bei Unklarheiten bezüglich BREEAM CH Bestand wenden Sie sich bitte zunächst an die TÜV SÜD-DIFNI per Mail an info.difni@tuev-sued.de, damit diese schnellstmöglich beseitigt werden können.

TÜV SÜD-DIFNI handelt nach einer offiziellen Beschwerde Prozedur (LI-BE03-CH). Bei Anfragen oder Beschwerden nutzen Sie bitte die angegebene E-Mail-Adresse.

## 2 VERZEICHNIS DER VERWENDETEN BEGRIFFE

Beratung  auf  jedes  Unternehmen  anwendbare  allgemeine  Empfehlung.  Jede  Beratung  durch  den  Auditor  soll insoweit unspezifisch sein.

Bewertung - Überprüfung der Immobile des Kunden, des Gebäudemanagements und der Managementprozesse des Nutzers. Die Beurteilung zum Zwecke der Zertifizierung kann sich dabei auf alle oder einzelne der drei vorstehend beschriebenen Komponenten beziehen. Das Zertifikat kann jeweils von dem Unternehmen beantragt werden, das für die jeweilige Komponente (und damit den entsprechenden Teil der Zertifizierung) verantwortlich ist.

Immobilie -  der  Umfang  der  BREEAM  CH  Bestands-Bewertung  bestimmt  sich nach  den  räumlichen  Grenzen  der Immobilie. Eine Immobilie in diesem Sinne sind nicht nur Gebäude im Ganzen; sie kann auch einzelne Gebäudeteile beschreiben,  z.  B.  einzelne  Gebäudeetagen.  In  diesem  Fall  muss  die  BREEAM  CH  Bestands-Bewertung  alle relevanten  Bereiche  der  technischen  Ausstattung  miteinschließen.  Dies  gilt  auch  für  gemeinschaftliche  genutzte Servicebereiche.

Die zu bewertende Immobilie ist in der Regel ein Gebäude. Dies gilt ausnahmsweise nur dann nicht, wenn mehrere Gebäude miteinander verbunden sind und sich Infrastruktur/Haustechnik teilt.

Audit -  ist  die  systematische  Überprüfung  der  Kunden-Antworten  im  Fragenkatalog  auf  Übereinstimmung  mit  den System-Anforderungen.

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 1 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

Auditor - vorausgesetzt, dass er entsprechend trainiert und von TÜV-SÜD-DIFNI (NSO Schweiz) anerkannt ist, wird der Auditor Kunden bei der Vervollständigung von Bewertungen helfen und/oder sicherstellen, dass die Bewertungen ordnungsgemäß im Rahmen der System-Anforderungen durchgeführt  werden.  Der  Auditor  wird  die  Bewertung  zur Zertifizierung registrieren und das Audit durchführen.

Individuelle Beratung - spezielle und gezielte Beratung eines Unternehmens. Als Beispiel seien das Aufstellen von Prozessen und Qualitätsplänen genannt, ebenso die Beratung in Bezug auf spezielle Produktempfehlungen.

Kunde -  eine  Person  oder  ein  Unternehmen,  die/das  sich  registriert  hat  und  eine  BREEAM  CH  BestandsVorbewertung durchführt und/oder eine Immobilie mit Hilfe des Auditors registriert.

Pre-Assessment  Wird  benutzt  um  eine  vorab  Bewertung  der  Immobilie  zu  erhalten.  Diese  ist  jedoch  eine  nicht bestätigte Bewertung in Bezug auf die Gebäudeperformance, dem Gebäudemanagement und/oder dem Nutzer. Ein Pre-Assessment  kann  ohne  voriges  Training,  kostenfrei  mittels  dem  BREEAM  Bestand  Online-  Tool  durchgeführt werden. Die Registrierung für ein Pre-Assessment kann via www.difni.de getätigt werden.

Qualitätssicherungs-Audit - Wird durch TÜV SÜD-DIFNI durchgeführt, um sicherzustellen, dass Auditoren die nach BREEAM CH Bestand vorgeschriebenen Prozesse einhalten.

Bewertung -  eine  zusammenfassende  Bewertungsskala  mit  den  Noten  akzeptabel,  bestanden,  gut,  sehr  gut, exzellent  oder  herausragend,  die  zugeteilt  werden,  wenn  eine  entsprechende  Zahl  von  Punkten  in  der  jeweiligen Bewertungskategorie  erzielt  worden  ist.  Eine  Bewertung  nach  Sternen,  beginnend  mit  einem  Stern  bis  zu  sechs Sternen, wird neben der Bewertung nach akzeptabel bis herausragend erteilt.

Gewichtung -  ein System, wonach die Zahl der zugeteilten Punkte in der jeweiligen Bewertungskategorie nach der umweltbezogenen Bedeutung so gewichtet wird, dass sich aus der Addition eine Gesamtbewertung (Overall Rating) ergibt.

## 3 VERANTWORTLICHKEITEN

Im Folgenden werden die Verantwortlichkeiten und Rollenverständnisse verdeutlicht. Auditoren sollten sicherstellen, dass diese in den Verträgen mit Ihren Auftraggebern berücksichtigt werden.

## TÜV SÜD-DIFNI (NSO)

-  Entwickelt und aktualisiert BREEAM CH Bestand Dokumente,
-  Entwickelt und aktualisiert BREEAM CH Bestand Bewertungs-Tools,
-  Bietet Schulungen für Auditoren an,
-  Bietet Prüfungen an, um registrierter Auditor zu werden
-  Lizenzierung von Auditoren und Unternehmen,
-  Zeitnahe Beantwortung von Auditor-Anfragen in Bezug auf eine registrierte Projektbewertung
-  Durchführung von Qualitätsprüfungen von eingereichten Bewertungen und Qualitätsprüfung der Auditoren in Bezug auf die Bewertungsprozesse,
-  Ausstellung von Zertifikaten an den Auditor nach erfolgreich abgeschlossener Qualitätsprüfung
-  Datenbankpflege der lizenzierten Auditoren und Zertifikaten,
-  Veröffentlichung der BREEAM CH Bestand Auditoren und Unternehmen via www.difni.de ,
-  Veröffentlichung der BREEAM CH Bestand Zertifikate via www.difni.de

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 2 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

## BRE Global

-  Entwicklung  und  Pflege  des  International  Code  for  a  Sustainable  Built  Environment,  die  BREEAM Standards  und  alle  unterstützenden  Unterlagen,  Werkzeuge  und  Systeme,  Qualitätssicherung  der Prozessabläufe des TÜV SÜD-DIFNI
-  Lizenzierung von NSO, die als Zertifizierungsstelle tätig sind
-  Veröffentlichung der BREEAM CH Bestand Auditoren via www.greenbooklive.com
-  Veröffentlichung der BREEAM CH Bestand Zertifikate via www.greenbooklive.com

## BREEAM CH Bestand Auditor

-  Antragsstellung zur Registrierung von Projekten zur BREEAM CH Bestands-Zertifizierung bei der TÜV SÜD-DIFNI
-  Unterstützung des Kunden, der ein Audit für ein Zertifikat nach BREEAM CH Bestand wünscht
-  Koordination, Zusammenstellung von Projekt-/Gebäudeinformationen, die notwendig sind, eine Bewertung im Übereinstimmung mit den BREEAM  CH  Bestand  Anforderungen durchzuführen, Durchführung von Vor-Ort-Begehungen zur Verifizierung der Daten
-  Unabhängige Überprüfung der Dokumente
-  Erstellung von qualitativ hochwertigen, erläuternden Auditberichten,
-  Generelle Unterstützung des Kunden zur Verbesserung der Performance des Gebäudes oder Betriebs
-  Einreichung  der  Bewertungen  und  Belegen  an  TÜV  SÜD-DIFNI  zur  Qualitätsprüfung  und  ZertifizierEntscheidung  (mit  Unterstützung  der  von  TÜV  SÜD-DIFNI  zur  Verfügung  gestellten  Werkzeuge  und Online-Tool)
-  Durchführung  von  Korrekturen,  wenn  im  Qualitätsprüfungsprozess  durch  TÜV  SÜD-DIFNI  fehlende Übereinstimmungen mit den Anforderungen des Systems festgestellt werden
-  Zertifikatsübermittlung an den Kunden
-  Sicherstellung einer klaren und wirtschaftlichen Leistungserbringung für den Kunden
-  Darstellung und Umgang von möglichen Interessenskonflikte TÜV SÜD-DIFNI gegenüber
-  Schritte zu unternehmen, um sicherzustellen, dass alle Beschwerden fair und zeitnah behandelt werden.

## BREEAM CH Bestand Kunde

-  Sammeln  und  Zusammenstellen  der  erforderlichen  Unterlagen  /  Nachweisdokumente  zur  Bewertung nach BREEAM CH Bestand und zur Prüfung durch den Auditor,
-  Registrierung zum Pre-Assessment bei TÜV SÜD-DIFNI (Auditoren können diese Aufgabe stellvertretend übernehmen)
-  Beauftragung eines Auditors zur Projektregistrierung zur Zertifizierung,
-  Verpflichtung, den Auditor regelmäißig über Änderungen in Gebäude, Betrieb und Nutzung (Teil 1 und 2) zu informieren
-  Beauftragung eines Auditors für die Überprüfung der Bewertungen bei Ortsbegehungen.

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 3 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

## 4 SCHULUNG UND LIZENZEN

## 4.1 WEG ZUM BREEAM CH BESTAND AUDITOR

## 4.1.1 SCHULUNG UND PRÜFUNG

Antragsteller  zum  BREEAM  CH  Bestand  Auditor  müssen  erfolgreich  an  der  BREEAM  CH  Bestand  Schulung teilgenommen  haben,  in  der  Hintergrundwissen  und  relevante  Informationen  zum  Gebrauch  der  Bewertungs-Tools sowie zu den Bewertungskriterien vermittelt wird.

Im Rahmen der BREEAM CH Bestand Auditor Schulung erfolgt die Prüfung, in der das Wissen zur Anwendung von BREEAM CH Bestand geprüft wird.

Details zur Schulung und den Gebühren entnehmen Sie bitte der Homepage www.dinfi.de.

Bitte  beachten  Sie,  dass  für  die  Wiederholung  einer  nicht-bestandenen  Prüfung  zusätzliche  Gebühren  erhoben werden, die auch der Gebührenordnung (GÜ001-CH) auf der Webseite entnommen werden können.

Voraussetzung zum BREEAM CH Bestand Auditor sind 2 Jahre praktische Erfahrungen in einer oder mehrerer der folgenden Professionen:

-  Architekten und Ingenieure;
-  Facilitiy Manager;
-  Gebäudebewerter;
-  Gutachter;
-  Technische Professionen in Bezug auf Immobilien;

Vor der Teilnahme an einer BREEAM CH Bestand Schulung und/oder nach der Antragstellung für eine AuditorenLizenz kann TÜV SÜD-DIFNI die entsprechenden Nachweise zur Erfüllung der Anforderungen einfordern. Typische Nachweise  sind  die  Kopie  des  Lebenslaufs  (CV)  und/oder  Zeugnisse  entsprechender  Abschlüsse/Fortbildungen und/oder Arbeitszeugnisse vorheriger Arbeitgeber.

## 4.1.2 LIZENZIERUNG VON AUDITOREN

Um ein Audit für eine Zertifizierung  durchführen  zu  dürfen,  benötigt  der  Auditor  eine gültige  BREEAM  CH  Bestand Auditoren Lizenz. Der Antragsteller und sein Unternehmen haben die Lizenzvereinbarungen von TÜV SÜD-DIFNI zu akzeptieren.

Voraussetzung ist die Teilnahme an der BREEAM CH Bestand Schulung und das erfolgreiche Bestehen der Prüfung im Anschluss, um unter BREEAM CH Bestand als Auditor registriert zu sein. Mit dieser Voraussetzung kann die Lizenz über  den  Lizenzantrag  (LI-BE02-CH)  beantragt  werden.  Der  Antragsteller  und  sein  Unternehmen  stimmen  in  der Lizenzvereinbarung (LI-BE-01-CH) den AGBs der TÜV SÜD-DIFNI und den Zertifizierungsbedingungen zu.

TÜV SÜD-DIFNI bestätigt schriftlich den Lizenzantrag und stellt die Lizenzgebühren in Rechnung. Nach Eingang ist der Auditor und das lizenzierte Unternehmen befähigt, Projekte zu registrieren und für die Teile 1 (Gebäude), Teil 2 (Gebäudebetrieb) und Teil 3 (Nutzerverhalten) nach BREEAM CH Bestand durchzuführen.

Bitte beachten Sie folgendes in Bezug auf die Lizenzierung:

-  die BREEAM CH Bestand Auditor Lizenz muss innerhalb eines Jahres vom Tag der bestandenen Prüfung an beantragt werden,
-  die Lizenz  ist 1 Jahr  gültig und  verlängert  sich automatisch  um  ein  weiteres  Jahr,  hierzu  ist  die Lizenzvereinbarung (LI-BE01-CH) zu beachten,
-  TÜV SÜD-DIFNI wird den Auditor und sein Unternehmen über die anstehende Erneuerung informieren.
-  Die  Lizenz  besteht  aus  einer  Unternehmenslizenz  und  einer  individuellen  Auditoren  -Lizenz.  Nähere Informationen bezüglich der jährlichen Gebühren sind in der Gebührenordnung GÜ001-CH zu finden.

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 4 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

<!-- image -->

## SD001-CH

## Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

## 4.2 KUNDEN

Ein Kunde kann nur dann das BREEAM Bestand Online-Tool nutzen, wenn er die AGBs akzeptiert hat (BCH-OT001).

Bitte  beachten:  Pre-Assessments  sind  lediglich  vorläufige  Ergebnisse.  Sie  sind  durch  keinen  lizensierten  Auditor überprüft oder bestätigt.

Die Zertifizierung erfolgt durch einen lizenzierten Auditor, der vom Kunden beauftragt ist, die Verifizierung/Auditierung der  Daten  vorzunehmen.  Nach  der  Registrierung  eines  Projektes  kann  der  Auditor  Personen  benennen,  denen  im Rahmen der Bewertung ein personalisierter Zugang zur Bearbeitung des Projektes im BREEAM Bestand Online-Tool angelegt wird.

Es  liegt im  Verantwortungsbereich  des  Kunden,  den  Auditor  auf  Änderungen  der  Gebäudeperformance  und Betreiberprozesse hinzuweisen.

## 5 DER BEWERTUNGSPROZESS

## 5.1 WAS KANN MIT BREEAM CH BESTAND BERWERTET WERDEN

Tabelle 1 zeigt die Bereiche, nach denen nach BREEAM CH Bestand bewertet werden kann, welchen Kundenkreis die Bewertung anspricht und wie Gebäude mit mehreren Mietparteien bewertet werden können.

| Tabelle 1   |                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
|-------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Teil 1      | Gebäudeperformance Bewertet wird die Performance des Gebäudes basierend auf der Gebäudetypologie, der Konstruktion und der technischen Anlagen Adressat? Eigentümer / Nutzer. Wie findet die Bewertung des Audits bei mehreren Mietern in einem Gebäude statt? Zur Erfüllung der Bewertungskriterien werden bei der Gebäudebewertung Stichprobenüberprüfungen der einzelnen Mieter durchgeführt, um zu überprüfen ob es generelle Vorgaben des Vermieters gibt und diese auch umgesetzt werden. Hinweis: Die Proben sollten repräsentativ sein und eine Auswahl verschiedener Mieter enthalten. Grundsätzlich basieren die Stichproben auf der Quadratwurzel der Gesamtzahl der Mieter. Zum Beispiel werden bei 100 Mieter/Nutzer mindestens 10 Mieter durch Stichproben überprüft. |
| Teil 2      | Qualität des Gebäudebetriebs Bewertet Management-Grundsätze, Verfahren und Umsetzungen von Maßnahmen bezogen auf den Betrieb des Gebäudes, Verbräuche der wichtigen Ressourcen wie Energie und Wasser etc. andere Verbräuche, die Auswirkungen auf die Umwelt haben wie CO 2 und Abfälle. Adressat? Facility Management/Nutzer. Wie findet die Bewertung des Audits bei mehreren Mietern in einem Gebäude statt? Die Bewertung basiert auf den gemeinsam genutzten Bereichen, für die ein Facility Manager zuständig ist, oder die vom Besitzer verwalteten Bereiche des Gebäudes.                                                                                                                                                                                                  |

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 5 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

Teil 3

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

## Prozesse des Nutzers

Bewertet das Verständnis und die Umsetzung von Management-Grundsätzen, Verfahren und Umsetzung von Maßnahmen des Gebäudenutzers.

## Adressat?

Nutzer

## How could it be used to assess a multi-tenanted asset?

Teil  3  kann  ausschließlich  auf  Mieterebene  durchgeführt  werden.  Jeder  Mieter  eines Gebäudes  ist  durch  ein  separates  Audit  zu  bewerten,  da  die  Unternehmensrichtlinien individuell gestaltet sind.

## 5.2 BEWERTUNGSPROZESS ABLAUFDIAGRAMM

Das  Ablaufdiagramm  1  verdeutlicht  den  Bewertungs-  und  Auditprozess,  der  eingehalten  werden  muss  (Detaillierte Informationen entnehmen Sie bitte dem 'BREEAM Bestand Online-Tool Handbuch':

Registrierung Pre-Assessment durch den Kunden oder einen lizenzierten Auditor

Bewertung Pre-Assessment durch den Kunden im BREEAM Online-Tool

Auftaktworkshop zum Audit zwischen Kunden und lizenziertem Auditor

Registrierung des Projektes zum Audit ausschließlich durch einen lizenzierten Auditor

Bewertung der Kriterien im BREEAM Online-Tool durch den Kunden und Upload von geeigneten Nachweisdokumenten

Vor-Ort-Begehung, zur Verifizierung der vom Kunden gemachten Angaben und hinterlegten Nachweisdokumente im BREEAM Online-Tool, durch einen lizenzierten Auditor

Abschlussworkshop zum Audit zwischen Kunden und lizenziertem Auditor

Qualitätsprüfung der eingereichten Audits durch TÜV SÜD-DIFNI und Vergabe desZertifikats

Abbildung 1: BREEAM CH Bestand Zertifizierungsprozess

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 6 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## SD001-CH

## Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

## 5.3 GEBÜHREN

Die Gebühren,  die  mit  dem  System  BREEAM  CH  Bestand  inklusive  Auditoren-Schulung  und  Lizenzierung, Registrierung und Zertifizierung von Projekten können der Gebührenordnung (GÜ001-CH) entnommen werden.

## 5.4 REGISTRIERUNG ZUM PRE-ASSESSMENT

Die  Registrierung  eines  Pre-Assessments  erfolgt  über  ein  Online  Formular  auf  der  TÜV  SÜD-DIFNI  Webseite (www.difni.de). Für die Registrierung und die Bewertung eines Pre-Assessments werden keine Gebühren erhoben. Die Bewertung  kann  ohne  spezielle  Fachkenntnis  vom  Kunden  oder  durch  einen  Auditor,  im  Auftrag  des  Kunden durchgeführt werden. Es soll eine erste Einschätzung des Istzustandes nach dem Bewertungssystem BREEAM CH Bestand, Teil 1 (Gebäude), Teil 2 (Gebäudebetrieb) und/oder Teil 3 (Nutzerverhalten) aufzeigen. Um ein Projekt zum Pre-Assessment zu registrieren und Zugang zum Online-Tool zu erhalten, müssen die AGBs (BCH-OT001) akzeptiert werden.

## 5.5 BEWERTUNG MIT DEM BREEAM BESTAND ONLINE-TOOL

Die Bewertung über das BREEAM Bestand Online-Tool kann vom Kunden und vom lizenzierten Auditor durchgeführt werden. Im Online-Tool enthalten sind alle zur Nutzung des Tools relevanten Anleitungen und Berechnungsgrundlagen. Anleitungen erfolgen auf Fragenebene. Je mehr Fragen positiv beantwortet/bewertet werden und mit aktuellen und aussagekräftigen Nachweisdokument belegt werden, desto besser fällt die Gesamtbewertung des Projekts aus.

## 5.6 AUDITIERUNG DURCH DEN AUDITOR

Hat der Kunde eine Erstbewertung im Pre-Assessment durchgeführt und beabsichtigt ein Zertifikat zu erhalten, muss der Kunde für die Zertifizierung einen unabhängigen und lizenzierten BREEAM  CH  Bestand  Auditor zur Verifizierung/Auditierung  der  Bewertung  beauftragen.  Die  Listung  der  lizenzierten  BREEAM  CH  Bestand  Auditoren kann unter www.difni.de eingesehen werden.

Der lizenzierte BREEAM CH Bestand Auditor ist für die Begleichung aller mit der Zertifizierung verbundenen Gebühren verantwortlich.  Diese  staffeln  sich  in  Abhängigkeit  von  der  Anzahl  der  zu  zertifizierenden  Teile  und  Projekte entsprechend der Gebührenordnung (GÜ001-CH).

## 5.6.1 ORTSBEGEHUNG IM RAHMEN DES AUDITS - ÜBERPRÜFUNG DER ANGESTREBTEN BEWERTUNG

Um eine Zertifizierung zu erreichen muss der lizenzierte BREEAM CH Bestand Auditor eine Ortsbegehung zum Audit durchführen.  Der  Auditor  kann  ein  Audit  sowohl  von  der  ersten  Bewertung  (Durchführung  der  Bewertung  für  den Kunden) oder, wenn der Kunde bereits eine Bewertung vorgenommen hat, die Ergebnisse der Bewertung des Kunden verifizieren und auditieren.

Bei der Ortsbegehung prüft der Auditor die Belege, die vom Kunden zusammengestellt wurden. Entweder werden die Bewertungen und  Belege,  die  vorgenommen  und  zusammengestellt  wurden,  verifiziert  oder  der  Auditor  ändert  die Bewertung des Kunden auf Basis der ihm vorgelegten Belege.

Ein Audit im Rahmen einer Ortsbegehung beginnt mit einem Einführungs-Workshop. Teilnehmer des Workshops sind der  Auditor  und  die  Verantwortlichen  des  Kunden.  Inhalte  sind  die  Erläuterung  des  Umfangs  des  Audits,  der Anforderungen  an  die  Ortsbegehung,  Umfang  und  Zeitrahmen  sowie  Festlegungen  zum  Abschlussworkshop. Der Auditor  ist  verpflichtet,  die  Protokolle  des  Auftakt-  und  Abschlussworkshops  sowie  der  Ortsbegehung  zu erstellen.

Auditoren können generelle Hinweise zu Aspekten der Nachhaltigkeit im Rahmen des Audits geben und diese dem Kunden zur Verfügung stellen.

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 7 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

Im Verantwortlichkeitsbereich des Auditors liegen folgende Punkte:

-  Durchführung des Audits und/oder
-  Sicherstellung,  dass  die  Daten,  die  bei  der  Bewertung  in  das  BREEAM  Bestand  Online-Tool  eingegeben wurden, richtig sind, Korrekturen vorzunehmen, falls dies notwendig ist im Rahmen der Zertifizierung,
-  Verifizierung/Auditierung der Daten und Aspekte bei der Ortsbegehung

Am  Ende  der  Ortsbegehung  des  Audits  hält der Auditor einen Abschlussworkshop  ab,  bei dem  mit den Verantwortlichen des Kunden die Ergebnisse des Audits und der Ortsbegehung erläutert werden und ein vorläufiges Ergebnis dargestellt wird.

## 5.6.2 ORTSBEGEHUNG

Während der Ortsbegehung muss ein Verantwortlicher des Kunden den Auditor begleiten.

Der  vom  Kunden  benannte  Verantwortliche  ist  verantwortlich  dafür,  die  Sicherheit  während  der  Ortsbegehung sicherzustellen.

Auditoren ist es nicht erlaubt, technische Anlagen und Ausstattungen aktiv und selber zu betreiben, um Zugang zu entsprechenden Informationen zu erhalten. Wenn derartige Informationen eingeholt werden müssen, sind diese durch den Verantwortlichen des Kunden zugänglich zu machen und zur Verfügung zu stellen.

## 5.7 AUDITBERICHT

Der  Auditbericht  enthält  den  kompletten  verifizierten  und  auditierten  Fragenkatalog.  Alle  Richtlinien,  Prozesse, verbrauchsorientierter Energieausweis (oder alternatives Ermittlungsverfahren) und Verbrauchsabrechnungen bedürfen der Aktualität zum Zeitpunkt des Einreichens des Auditberichts bei TÜV SÜD-DIFNI.

Der Auditor hat eine Aufbewahrungspflicht aller Dokumente, die im Rahmen des  BREEAM CH Bestand Audits zur Qualitätsprüfung  bei  TÜV  SÜD-DIFNI  eingereicht  wurden,  von  mindestens  5  Jahren.  Die  Aufbewahrung  der Dokumente erfolgt entweder in digitaler oder Papierform.

## 5.8 POTENZIELLE INTERESSENSKONFLIKTE

BREEAM CH Bestand ist eine unabhängige Zertifizierung, die durch eine Dritte Partei durchgeführt wird. Auditoren ist es daher untersagt, ihr eigenes Gebäude oder Unternehmen bzw. Unternehmen, die sie beschäftigen, zu zertifizieren. Dies würde einen offensichtlichen Interessenkonflikt darstellen.

Wenn der  Auditor  für  eine  Tochtergesellschaft  des  Unternehmens  arbeitet,  das  zertifizieren  will,  muss  der  Auditor sicherstellen, dass kein Interessenskonflikt vorliegt sowie TÜV SÜD-DIFNI über die Strukturen und Beziehungen der beiden  Unternehmen  untereinander  informieren.  Dabei  muss  die  Abgrenzung  der  Unternehmensstrukturen  klar hervorgehen.  Informationen,  welche  Schritte  eingeleitet,  bzw.  gemanagt  werden,  wie  dieser  Konflikt  gelöst  wird, müssen  an  TÜV  SÜD-DIFNI  übermittelt  werden.  TÜV  SÜD-DIFNI  prüft  die  vorgeschlagene  Lösung  und  gibt  allen involvierten Parteien Rückmeldung, wie und ob die Objektivität und Unabhängigkeit des Auditors gewährleistet ist.

Der  Auditor  sollte  bereits  bei  der  Registrierung  TÜV  SÜD-DIFNI  auf  mögliche  Interessenskonflikte  hinweisen  oder wenn  während  des  Bewertungsprozesses  Interessenskonflikte  auftreten,  spätestens  jedoch  vor  Einreichung  der Unterlagen zur Qualitätsprüfung.

Auditoren  können  während  und  nach  dem  BREEAM  CH  Bestand  Audit  beratend  tätig  sein.  Allerdings  muss  die Beratung  einen generellen Charakter  aufweisen,  d.h.  sie  bezieht  sich  auf  die  Anforderungen  des  Systems  oder Erläuterungen  über  die  Inhalte  und  das  Verständnis  einzelner  Fragen  und  Antworten  innerhalb  des  Fragebogens. Auditoren können des Weiteren Kunden dahingehend beraten, wie auf Basis der Bewertung Optimierungen erfolgen können.

Auditoren  dürfen  während  eines  Audits  nicht  direkt  beratend  tätig  sein.  D.  h.  es  ist  Auditoren  nicht  gestattet Richtlinien/Pläne zu erstellen, Prozesse einzuführen oder Materialberatungen durchzuführen. Dies würde bedeuten, dass der Auditor eigene Leistungen auditiert, was einen klaren Interessenskonflikt darstellt. Wenn der Auditor mit der

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 8 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

direkten  Beratung  beauftragt  ist,  müssen  diese  Leistungen  durch  einen  anderen  lizenzierten  Auditor  verifiziert  und auditiert werden, dieser darf nicht im selben Unternehmen angestellt sein.

## 5.9 ZERTIFIZIERUNG

Das BREEAM Bestand Online-Tool berechnet die Bewertung des Projekts. Ein Zertifikat kann nur erreicht werden, wenn eine bestimmte minimale Punktzahl erreicht ist, die die Bewertungsstufe für mindestens 1 Stern erreicht.

| Tabelle 2 - Kategorien und Bewertung   | Tabelle 2 - Kategorien und Bewertung   | Tabelle 2 - Kategorien und Bewertung   |
|----------------------------------------|----------------------------------------|----------------------------------------|
| Erzielte Bewertung (%)                 | Bewertungsbezeichnung                  | Sternebewertung                        |
| < 10                                   | Nicht zertifiziert                     | -                                      |
| ≥ 10 bis <25                           | AUSREICHEND                            |                                       |
| ≥ 25 bis <40                           | BEFRIEDIGEND                           |                                      |
| ≥ 40 bis <55                           | GUT                                    |                                     |
| ≥ 55 bis <70                           | SEHR GUT                               |                                    |
| ≥ 70 bis <85                           | EXZELLENT                              |                                   |
| ≥85                                    | HERAUSRAGEND                           |                                  |

Hinweis: Teil  3  (Nutzer)  enthält  Mindestanforderungen,  die  erfüllt  werden  müssen,  um  eine jeweilige Bewertungsstufe zu erreichen.

Das  Zertifikat  und  der  Bericht  ermöglichen  es  dem  Eigentümer,  Betreiber  und/oder  Nutzer  die  Nachhaltigkeit  des Gebäudes darzustellen. Zertifikate können im Gebäude ausgehangen werden und/oder als Nachhaltigkeitsdarstellung des Unternehmens für die 'corporate social responsibility' herangezogen werden.

Zur  Aufrechterhaltung  einer  Zertifizierung  müssen  die  regelmäßigen  Audits  innerhalb  der  Zertifizierungszyklen eingehalten werden.

Gebäude können nach jedem der 3 Teile von BREEAM CH Bestand zertifiziert werden, gem. dem Handbuch.

Wenn das Audit zu einer Bewertung von 0 Sternen, 'nicht zertifiziert' führt, kann kein Zertifikat ausgestellt werden. Der Auditor  sollte  in  diesem  Fall  den  Kunden  über  das  Ergebnis  informieren,  die  Gründe  benennen  und  eine  weitere Bewertung empfehlen.

Nach positiv abgeschlossener Qualitätsprüfung ist TÜV SÜD-DIFNI verantwortlich für die Übermittlung des Zertifikats. Dieses  wird  von  TÜV  SÜD-DIFNI  in  digitaler  Form  an  den  Auditor  gesendet,  der  das  Zertifikat  an  den  Kunden weiterleitet.

Das Zertifikat enthält:

-  Name und Adresse des Gebäudes inklusive einer Beschreibung der Gebäudeart;
-  Name und Adresse des Auftraggebers;
-  Name und Lizenznummer des Auditors und seines Unternehmens;
-  zertifizierte Teile und deren Gesamtbewertung
-  prozentuale Bewertung je Kategorie je Teil
-  Ausstellungs- und Ablaufdatum des Zertifikats
-  Eine individuelle Zertifikatsnummer

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 9 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

## 5.10 QUALITÄTSSICHERUNG DER BREEAM CH BESTAND AUDITOREN BEI TÜV SÜD-DIFNI

TÜV SÜD-DIFNI kann die Arbeit der Auditoren wie folgt prüfen:

## 5.10.1 QUALITÄTSSICHERUNG /-PRÜFUNG

Ein hoher Standard in der Qualitätssicherung ist notwendig, um die Interessen aller zu wahren, die im Zusammenhang mit dem Audit stehen. Der Prozess der Qualitätssicherung wird unten aufgeführt. Die Ergebnisse des Audits durch den lizenzierten Auditor werden geprüft. Dies führt zu Benachrichtigungen des Auditors durch die DIFNI über die Qualität der eingereichten Unterlagen und zur Bitte um entsprechende Nachreichungen. Die Gebühren richten sich nach Art und  Umfang  der  Prüfungen  durch  DIFNI  und  Rückmeldungen  an  den  Auditor.  Die  Gebühren  sind  in  der Gebührenordnung aufgeführt (GÜ001-CH).

Die  Qualitätsprüfung  bezieht  sich  insbesondere  auf  die  Bereiche,  in  den  das  Risiko  besteht,  die  Qualität  einer BREEAM Zertifizierung zu mindern:

-  Erfahrungslevel des Auditors mit der Zertifizierung nach BREEAM
-  Professionelles Verhalten
-  Fachliche Kompetenz in der Beurteilung Energieeffizienz und Umweltverträglichkeit
-  Einhaltung von festgelegten Standards
-  Potenzielle Täuschungsversuche durch den Auditor oder seines Arbeitgebers

Diese Risiken sind im Wesentlichen mit dem Verhalten des Auditors verbunden. Eine kompetente, ausgebildete und ehrliche Person wird in der Mehrzahl der Fälle ein qualitativ hohes Level an Service bieten. Dies wird  des Weiteren durch  den  BREEAM  CH  Bestand  Qualitätsprüfungsprozess  sichergestellt,  wodurch  ebenfalls  ein  hohes  Maß  an Vertrauen, dass die Qualitätsstandards in möglichst kosteneffektiver Weise erhalten sind, hergestellt wird.

Die Anforderungen an die Qualitätsprüfung lauten:

-  Bestätigung für 100 % der überprüften Immobilien, dass das Verfahren ordnungsgemäß eingehalten wurde (inklusive,  aber  nicht  ausschließlich,  Prüfung  der  Dokumentation  von  Auftakt-  und  Abschlussworkshop, Protokoll der  Vor-Ort-Begehung,  Haftpflichtversicherung,  Gültigkeit  der  Auditoren-  und  UnternehmensLizenz), die Ausführung durch den Auditor und dessen Verhalten den erwarteten Standards entsprechen und die  Identifizierung  etwaiger  Anhaltspunkte  für  die  Notwendigkeit  einer  Überprüfung  der  abgeschlossenen Zertifizierung.
-  Die Prüfung der gültigen Haftpflichtversicherung des Auditors ist ebenfalls Bestandteil der Qualitätsprüfung. Dies erfolgt vor dem Hintergrund, dass schlussendlich der Auditor für die Richtigkeit seines Audits haftet.
-  Überprüfung  der  Immobilien  Beurteilung  der  Qualität  der  abgeschlossenen  Audits  durch  einen  TÜV  SÜDDIFNI  Qualitätssicherungs-Auditor.  Hierzu  wird  der  Auditor  aufgefordert,  TÜV  SÜD-DIFNI  Nachweise  und Anmerkungen zum durchgeführten Audit auszuhändigen.
-  Überprüfung  von  eventuell  im  Zusammenhang  des  Systems  entstehenden  Beschwerden  und  dessen Entschluss.  Beschwerden  und  Einsprüche  werden  gemäß  der  in  LI-BE03-CH  beschriebenen  Prozedur behandelt.

## 5.10.2 QUALITÄTSSICHERUNG DURCH TÜV SÜD-DIFNI BEZÜGLICH NICHT-KONFORMITÄT

Während  der  Qualitätsprüfung  sichtet  der  Prüfer  von  TÜV  SÜD-DIFNI  eine  Anzahl  von  Kriterien  und  zugehörigen Belegen,  um  die  Vollständigkeit  der  Bewertung  zu  beurteilen.  Wenn  in  der  Bewertung  bestimmter  Kriterien  NichtKonformitäten  auftauchten,  wird  dies  als  Nicht-Einhaltung  der  Anforderungen  des  BREEAM  CH  Bestand  Systems gewertet. In diesem Fall gilt die Bewertung für nicht abgeschlossen, bzw. hat die Qualitätsprüfung nicht bestanden. Seitens TÜV SÜD-DIFNI erhält der Auditor eine entsprechende Rückmeldung in einem Standardformular. Solange die identifizierten Punkte durch den Auditor nicht klargestellt werden, kann der Zertifizierungsprozess nicht abgeschlossen

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben: oebbe-th

Seite 10 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

werden. Erst nach Überarbeitung und entsprechender Korrekturen kann die Bewertung erneut über das Online-Tool zur weiteren Qualitätsprüfung eingereicht werden.

Typische Punkte für Nicht-Konformitäten sind:

-  ein Fehler / Unterlassung, der zu einer fehlerhaften / ungültigen Beurteilung führt,
-  keine oder falsche Dokumentation / Belege,
-  unangemessene / ungenaue Bezugnahme auf Dokumentation / Nachweise.

Grundsätzlich: wo Punkte im BREEAM  CH  Bestand  System  angestrebt werden und nicht klar aus der Bewertung/Dokumentation hervorgeht, dass das Projekt nach den System-Kriterien beurteilt wurde, also, wenn NichtKonformitäten bei der Einhaltung oder Fehler bei der Bewertung gemacht wurden, dann ist es sehr wahrscheinlich, dass  eine  Nicht-Konformität  vorliegt  und  die  Bewertung  die  Qualitätsprüfung  nicht  ohne  Korrekturmaßnahmen abgeschlossen werden kann.

## 5.10.3 HANDLUNGSSPIELRAUM VON TÜV SÜD-DIFNI BEI NICHT-KONFORMITÄT

Wenn Qualitätssicherungs-Audits durch TÜV SÜD-DIFNI vom Auditor verhindert werden, kann die Lizenz des Auditors aberkannt werden (LI-BE01-CH).

Wenn  die  Überprüfung  der  Berichte  oder  die  Art  der  Beschwerden  darauf  hinweist,  dass  die  Arbeiten  nicht ordnungsgemäß  durchgeführt  werden,  können  zusätzliche  Audits  oder  Neuschulungen  erforderlich  sein,  um  eine Zertifizierung zu erreichen.

Auditberichte  werden  individuell  geprüft  und  aufbewahrt.  Auditoren,  die  Auditberichte  mit  einer  hohen  Fehlerquote einreichen, werden intensiver geprüft. Dies kann zu zusätzlichen Kosten führen. Die Kosten können der Gebührenordnung entnommen werden.

Falls TÜV SÜD-DIFNI Qualitätsprüfung (und in letzter Instanz BRE Global) erhebliche und wiederholende Fehler im Auditbericht aufdeckt, können folgende Schritte eingeleitet werden:

-  Der Auditor muss an einer weiteren Schulung teilnehmen, auf eigene Kosten

## UND / ODER

-  Die Registrierung und die Lizenz des Unternehmens kann entzogen werden,

## ODER

-  Der Auditor kann von der Anwendung von BREEAM CH Bestand zurücktreten.

Wenn registrierte und lizenzierte Auditoren innerhalb von 3 Jahren kein Projekt zur Zertifizierung registriert haben oder zertifiziert haben oder die Auditberichte durchgehend von geringer Qualität sind, wird der Status Auditor überprüft und kann nur erhalten werden, wenn er an einer weiteren Schulung erfolgreich teilgenommen hat (LI-BE03-CH).

Wenn ein Einspruch gegenüber einem Auditor eingereicht wird, muss das Unternehmen, für das der Auditor tätig ist, für die  Kosten  der  Überprüfung  durch  TÜV  SÜD-DIFNI  sowie  die  Nachbesserung  und  die  Nachzertifizierung aufkommen,  wenn  die  Durchführung  des  Auditprozesses  durch  den  Auditor  fehlerhaft  durchgeführt  worden  ist  (LIBE03-CH).

Falls  DIFNI  feststellt,  dass  der  Auditor  eine  mangelnde  Kompetenz  bzgl.  der  BREEAM  CH  Bestand  Zertifizierung aufweist, können dem Auditor für weitere Prüfungen des Auditberichts durch TÜV SÜD-DIFNI Kosten entstehen, die der Auditor tragen muss (GÜ001-CH).

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 11 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## SD001-CH

## Systemdokument

## BREEAM CH Bestand Systemanwendung

## 5.11 ZERTIFIZIERUNG

## 5.11.1 GÜLTIGKEIT DES ZERTIFIKATS

Ausgestellte Zertifikate besitzen eine Gültigkeit von:

 Zertifikat Gebäude (Teil 1)

3 Jahr

 Zertifikat Betrieb (Teil 2)

3 Jahr

 Zertifikat Nutzer (Teil 3)

1 Jahr

Gültige  Zertifikate  werden  über  die  Homepage  www.difni.de  gelistet.  Ein  Monat  nach  Ablauf  des  Gültigkeitsdatums werden diese Zertifikate von der Homepage gelöscht.

Gültige Zertifikate werden durch TÜV SÜD-DIFNI zur Listung auf Greenbook Live weitergeleitet. Weitere Informationen können nicht über Greenbook Live dargestellt werden.

Es liegt im Verantwortlichkeitsbereich des Kunden, den Auditor auf Änderungen am Gebäude/technische Anlagen (Teil 1) oder in den Betreiberprozessen (Teil 2) hinzuweisen, die zu einer Veränderung der Bewertung führen. Der Auditor ist  dafür  verantwortlich,  diese  Änderungen  in  die  Bewertung  einfließen  zu  lassen  und  TÜV  SÜD-DIFNI  auf  diese hinzuweisen.

## 5.11.2 VERWALTUNG

Die Registrierung zum Zertifikat ist 1 Jahr gültig. Spätestens 1 Jahr nach Registrierung müssen alle Unterlagen zum Zertifikat durch den lizenzierten Auditor bei TÜV SÜD-DIFNI eingereicht werden. Für Re-Zertifizierungen des Objekts in regelmäßigen Zyklen fallen keine weiteren Registrierungsgebühren an.

Der  Kunde eines  Audits  und  der  daraus  resultierenden  Zertifizierung  nach  BREEAM  CH  Bestand  ist  selbst  für  die Einhaltung  der  Fristen  für  eine  Re-Zertifizierung  der  Zertifizierung  nach  BREEAM  CH  Bestand  verantwortlich.  Die vollständige Einreichung der durch TÜV  SÜD-DIFNI  geforderten Unterlagen für eine Re-Zertifizierung sind mindestens 2 Wochen vor Ablauf der Gültigkeit bei  der  TÜV-SÜD-DIFNI über das Onlineformular auf der DIFNI Webseite www.difni.de, durch einen lizenzierten BREEAM CH Bestand Auditor, einzureichen.

Wenn TÜV SÜD-DIFNI keine Rückmeldung des lizenzierten Auditors erhält, dass der Kunde eine Re-Zertifizierung wünscht, geht TÜV SÜD-DIFNI automatisch davon aus, dass der Kunde keine weitere Zertifizierung nach  BREEAM CH Bestand für das Projekt wünscht.

Gleichzeitig  erlischt  die  Listung  des  Zertifikats  auf  der  www.difni.de Webseite  und  dem  Green  Book  Live  innerhalb eines Monats.

Der  Zugang  zum  BREEAM  CH-Bestand  Onlinetool  wird  gesperrt  und  die  Auflistung  in  Green  Book  Live  und www.difni.de innerhalb von 1 Monat zurückgenommen, es sei denn, TÜV SÜD-DIFNI bekommt eine fristgerechte und schriftliche Bestätigung die den gegenteiligen Sachverhalt bestätigt.

Wünscht der Auftraggeber/Eigentümer nach Ablauf des Gültigkeitszeitraums eine erneute Zertifizierung des Projektes, fallen  entsprechend  der  Gebührenordnung  (GÜ001-CH)  erneut  Registrierungsgebühren  und  Zertifikatsgebühren  in voller Höhe an.

## 5.11.3 RE-ZERTIFIZIERUNG

Jedes ausgestellte Zertifikat (Erstoder Re-Zertifikat) ist für maximal drei Jahre gültig, auch wenn  keine Veränderungen in der Bewertung erfolgt sind.

Wenn der Auditor neue Belege vom Kunden erreicht, kann der Auditor die Re-Zertifizierung unter folgenden Szenarien auditieren:

-  Die Zertifizierung behält die ursprüngliche Bewertung, wenn der Auditor keine neuen Belege bei TÜV SÜDDIFNI zur Prüfung einreicht und das Ergebnis sich nicht verändert.

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 12 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

-  Eine neue Bewertung erfolgt auf Basis der neuen Belege, die durch TÜV SÜD-DIFNI geprüft werden, wenn die  neuen  Belege  inkl.  der  neuen  Bewertung  zur  Prüfung  bei  TÜV  SÜD-DIFNI  in  einem  Zeitraum  von frühestens 30 Tage und spätestens 14 Tage vor Ablauf des Zertifikats eingereicht werden.

Wenn  die  erreichte  Bewertung  nicht  mindestens  zu  1  Stern  führt,  kann  kein  Zertifikat  ausgestellt  werden  und  die Listung auf der BREEAM CH Webseite und dem Green Book Live wird gelöscht. Ebenfalls ist die Verwendung der Marke  BREEAM  CH  im  Zusammenhang  mit  dem  Objekt  untersagt.  Eine  neue  Zertifizierung  nach  BREEAM  CH Bestand  kann  nur  erfolgen,  wenn  das  Projekt  neu  registriert  wird,  ein  Audit  durch  einen  lizenzierten  Auditor durchgeführt und erfolgreich durch TÜV SÜD-DIFNI geprüft wurde

Wenn  ein  Kunde  keine  Re-Zertifizierung  wünscht,  kann  die  Re-Zertifizierung  durch  den  lizenzierten  Auditor  in schriftlicher  Form  aufgehoben  werden,  wenn  der  Auditor  von  TÜV  SÜD-DIFNI  die  Erinnerung  zur  Re-Zertifizierung erhält.

## 6 MARKETING

## 6.1 LISTUNG UND ZERTIFIZIERUNG

Wenn Auditoren das Audit erfolgreich abgeschlossen haben, eine Bewertung von wenigsten 1 Stern erzielt haben und die Qualitätsprüfung durch TÜV SÜD-DIFNI abgeschossen ist, werden die Details des Zertifikats und Gebäudes durch TÜV SÜD-DIFNI an BRE Global zur Listung im Green Book Live weitergeleitet. Die Zertifikatsdetails sind abrufbar unter  auf  der  TÜV  SÜD-DIFNI  Webseite  (www.difni.de).  Details  zu  lizenzierten  Auditoren  und  Unternehmen  sind ebenfalls o.g. Website zu entnehmen.

TÜV SÜD-DIFNI leitet die Informationen zu zertifizierten Projekten und lizenzierten Auditoren und Unternehmen an BRE Global weiter. Dies Informationen sind über das Greenbook Live unter www.greenbooklive.com abrufbar. Hinweis: Alle Bewertungen des Pre-Assessment des Kunden, die nicht durch einen Auditor verifiziert wurden, dürfen nicht als BREEAM CH Bestand Zertifikate oder als zertifiziert veröffentlicht werden.

## 6.2 LOGOS UND SIEGEL

Einem lizenzierten BREEAM CH Bestand Auditor wird eine individuelle Auditor-Lizenz-Nummer zugewiesen und kann das Auditor-Siegel oder das BREEAM CH Logo verwenden wie es im Dokument 'LM001-CH ' beschrieben ist.

Einer  Gebäudebewertung  nach  dem  BREEAM  CH  Bestand  System  wird  eine  individuelle  Zertifikats-Nummer zugewiesen  und  das  Zertifikats-Siegel  oder  das  BREEAM  CH  Logo  kann  verwendet  werden  wie  es  im  Dokument 'LM001-CH' beschrieben ist.

Alle Fragen bzgl. der Verwendung der Siegel und Logos können an info.difni@tuev-sued.de gerichtet werden.

## 7 BESCHWERDEVERFAHREN

TÜV SÜD-DIFNI hat ein formales Beschwerdeverfahren (LI-BE03-CH).

Sollten Fragen offenbleiben oder Anlass zu ernster Besorgnis erregen, können Kunden TÜV SÜD-DIFNI kontaktieren unter info.difni@tuev-sued.de, um eine formelle Beschwerde einzureichen.

Das  lizenzierte  Unternehmen,  bei  dem  der  Auditor  beschäftigt  ist,  trägt  die  ggf.  Kosten  für  die  Prüfung  der Beschwerde.

## 8 ÄNDERUNG VON AUDITOREN-DETAILS

Der lizenzierte und registrierte BREEAM CH Bestand Auditor ist verantwortlich dafür, TÜV SÜD-DIFNI in schriftlicher Form  über  Änderungen  aller  auf  dem  Zertifikat  veröffentlichten  Details,  z.B.  der  Rechtsform,  Titel,  Adresse  und Namen, zu informieren. Diese Bekanntmachung ist innerhalb von 30 Tagen vor Inkrafttreten an  TÜV SÜD-DIFNI zu übermitteln.

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 13 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH

<!-- image -->

## SD001-CH Systemdokument

## BREEAM CH Bestand Systemanwendung

<!-- image -->

Wenn die Änderungen von den Bedingungen, unter denen die Lizenz erteilt wurde, stark abweichen, soll der Auditor direkten Kontakt zu TÜV SÜD-DIFNI aufnehmen, um das weitere Vorgehen abzustimmen, um die Lizenz zu erhalten.

## 9 ANHANG 1 - LEITFADEN FÜR DEN AUDITOR

Eröffnungs- und Abschlussworkshops müssen nach den Anforderungen nach SD002 BREEAM CH Bestand AuftaktAbschlussworkshop  durchgeführt  werden.  SD002  BREEAM  CH  kann  der  Homepage  www.difni.de  entnommen werden.

-  Wenn  der  Kunde  eine  Frage  beantwortet  hat,  aber  nicht  den  entsprechenden  Beleg  vorlegen  kann.  Der Auditor kann diese Antwort/Bewertung nicht akzeptieren. Sobald ein entsprechender Nachweis nachgereicht wird, kann die Bewertung durch den Auditor aktualisiert werden.
-  Für die Bewertung von manchen Fragen sind als Belege Interviewprotokolle mit Mitarbeitern ausreichend, aus denen hervorgeht, dass z.B. eine entsprechende Richtlinie umgesetzt wird. Eine Angabe des Namens und der Position des Interviewpartners muss im Protokoll aufgeführt sein.
-  Alle Belege, müssen digital zusammengestellt werden und zur jeweiligen Frage im BREEAM Bestand OnlineTool  hinterlegt  werden.  Zusätzliche  Hinweise  zu  Nachweisdokumenten  sind  im  BREEAM  Bestand  OnlineTool hinterlegt
-  Eine  Frage  kann  durch  den  Auditor  nur  positiv  bewertet  werden,  wenn  diese  durch  einen  aktuellen  und aussagekräftigen Nachweis belegt ist.
-  Falls in unterschiedlichen Gebäuden ähnliche Qualitätsmanagementsysteme und entsprechende Dokumente vorhanden sind, können diese als Beleg für die entsprechenden Gebäude herangezogen werden.
-  Es  ist  die  Verantwortung  des  Auditors  alle  Bewertungen  zu  prüfen  und  wenn  notwendig  weitere  Belege einzufordern. Entsprechende Belege müssen vom Auditor eindeutig erläutert werden ('Auditor Kommentare). Wenn  TÜV  SÜD-DIFNI  der  Auffassung  ist,  dass  die  Belege  nicht  ausreichend  sind,  kann  der  Auditor aufgefordert werden, weitere Belege nachzureichen.
-  Auditoren  registrieren  Projekte  im  BREEAM  Bestand  Online-Tool.  Unter  BREEAM  CH  Bestand  ist  es Auditoren erlaubt, Bewertungen im Auftrag des Kunden zu vervollständigen.
-  Wenn die Gültigkeit des Zertifikats von 3 Jahren abläuft und eine Aktualisierung des Auditberichts erfolgt, wird dies als Re-Zertifizierung bezeichnet. Der Ablauf des Audits erfolgt nach den gleichen Regeln wie die erste Zertifizierung. Der Kunde hat die Pflicht, den Auditor über alle Änderungen, die Einfluss auf die Bewertung haben,  zu  informieren.  Der  Auditor  auditiert  die  Änderungen  im  Auditbericht,  bzw.  pflegt  gleichbleibende Bewertungen im Auditbericht ein. Dadurch wird für die Qualitätsprüfung durch TÜV SÜD-DIFNI ersichtlich, dass sowohl Änderungen als auch gleichbleibende Bewertungen auditiert wurden.

Hinweis:  Audits  im  Teil  3  Nutzer  und  das  Re-Zertifikat  in  den  Teilen  1  und  2  im  Jahr  3  erfordern  ein vollständiges Audit des gesamten Kriterienkatalogs in allen Kategorien inkl. Auftakt- und Abschlussworkshops sowie eine erneute Ortsbegehung.

<!-- image -->

erstellt/geändert:  IS-DIFNI-FRA

01.06.2017

freigegeben:

oebbe-th

Seite 14 von 14

Datei: SD001-CH\_BREEAM CH Bestand

Systemdokument

Rev.-Stand:

06/2017

Gedruckte Exemplare unterliegen keinem Änderungsdienst! Copyright TÜV SÜD Industrie Service GmbH