---
document_id: breeam_usa_in_use_v2
title: "BREEAM USA In-Use Technical Manual: Commercial Buildings (Version 2.0)"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "BRE Global / BREEAM"
year: 2019
original_file: "breeam_usa_in_use_technical_manual_v2.pdf"
tables_detected: 1013
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

<!-- image -->

## Terms and conditions

## Disclaimer

The content of this Program Document is the property of BRE Global Limited and is made publicly available for information  purposes  only.  Any  testing,  assessment,  certification  or  approval  activity  related  to  this  Program Document must be conducted in accordance with BRE Global Limited's approved processes, and such activity may only be undertaken by authorized employees, agents, and associates of BRE Global Limited, or approved parties ('Approved  Party(ies)').  Any  party  wishing  to  use  or  reproduce  this  Program  Document  to  offer  testing, assessment, certification or approval must apply to BRE Global Limited for training, assessment and an associated license, in order to qualify as an Approved Party; a fee will normally be charged to the party by BRE Global Limited. BRE Global Limited will not unreasonably refuse such applications. BRE Global Limited accepts no responsibility for any unauthorized use or distribution by others of this Program Document and may take legal action to prevent such unauthorized use or distribution.

## Copyright

The information and images contained in this document are the property of BRE Global Limited unless explicitly stated to the contrary and are protected by copyright laws. The information and images contained in this document may  be  downloaded  and  printed  without  requiring  specific  permission  but  remains  the  intellectual  property, technical know-how and copyrighted material of BRE Global Limited. Such material is not to be used in a derogatory manner, in a misleading context or for commercial purposes. Where such material is being issued to others, the source including the web address and copyright status must be acknowledged. We may require you to register your details before downloading certain information or documents.

## Trademarks

BRE, BRE Global, BREEAM are all trademarks owned by either BRE or BRE Global Limited and may not be used without written permission from BRE or BRE Global Limited.

Uncontrolled copy if printed. Valid on day of printing only.

<!-- image -->

<!-- image -->

## Table of Contents

| Terms and conditions.........................................................................................................................                                   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| List of tables........................................................................................................................................................... 10    |
| List of figures ......................................................................................................................................................... 11    |
| About the BRE Group....................................................................................................................... 12                                   |
| About this Program Document......................................................................................................... 13                                         |
| Changes to this BREEAM Program Document ................................................................................... 13                                                  |
| Introduction to BREEAM .................................................................................................................. 14                                    |
| BREEAM USA In-Use......................................................................................................................... 17                                   |
| Scope of BREEAM In-Use....................................................................................................................................... 21                |
| Scoring and rating of BREEAM USA In-Use assessed assets.................................................................................. 24                                    |
| Evidence requirements for BREEAM In-Use.......................................................................................................... 29                            |
| Issue and credit structure...................................................................................................................................... 36             |
| Building Details................................................................................................................................ 38                             |
| Asset ...................................................................................................................................................................... 38 |
| Basic Building Details............................................................................................................................................. 39          |
| Asset Dimensions................................................................................................................................................... 40          |
| Asset Type.............................................................................................................................................................. 42     |
| Part 1: Asset Performance................................................................................................................ 43                                    |
| Management ................................................................................................................................... 44                               |
| Health and Wellbeing....................................................................................................................... 44                                  |
| Asset Performance HEA 01 - Glazing .................................................................................................................... 45                      |
| Asset Performance HEA 02 - Glare control........................................................................................................... 46                          |
| Asset Performance HEA 03 - Thermal control...................................................................................................... 48                             |
| Asset Performance HEA 04 - Ventilation controls................................................................................................ 50                              |
| Asset Performance HEA 05 - Minimizing Legionella contamination risk.............................................................. 51                                            |
| Asset Performance HEA 06 - Drinking water provisions....................................................................................... 53                                  |
| Asset Performance HEA 07 - Indoor and/or outdoor space................................................................................. 55                                      |
| Asset Performance HEA 08 - Illuminance levels (Lux) .......................................................................................... 57                               |
| Asset Performance HEA 09 - Lighting control....................................................................................................... 58                           |
| Asset Performance HEA 10 - Inclusive design....................................................................................................... 60                           |

<!-- image -->

| Energy ............................................................................................................................................. 64      |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Asset Energy Calculator Guidance......................................................................................................................... 66 |
| Asset Performance ENE 01 - Heating, Ventilation and Air Conditioning (HVAC) ................................................. 71                             |
| Asset Performance ENE 02 - Ventilation strategy ................................................................................................ 73          |
| Asset Performance ENE 03 - Heat loss.................................................................................................................. 74    |
| Asset Performance ENE 04 - Building pressure/air leakage test .......................................................................... 75                  |
| Asset Performance ENE 05 - Heating.................................................................................................................... 77    |
| Asset Performance ENE 06 - Boiler efficiency ...................................................................................................... 79       |
| Asset Performance ENE 07 - Heat pump efficiency.............................................................................................. 80             |
| Asset Performance ENE 08 - Fuel usage for heat generation............................................................................... 81                  |
| Asset Performance ENE 09 - Heat distribution..................................................................................................... 82         |
| Asset Performance ENE 10 - Heat emitter type ................................................................................................... 83          |
| Asset Performance ENE 11 - Mechanical and electrical heating equipment ....................................................... 85                            |
| Asset Performance ENE 12 - Cooling system........................................................................................................ 87         |
| Asset Performance ENE 13 - Efficiency of cooling generator............................................................................... 89                 |
| Asset Performance ENE 14 - Cooling distribution ................................................................................................ 90          |
| Asset Performance ENE 15 - Air distributed cooling system................................................................................ 92                 |
| Asset Performance ENE 16 - Refrigerant cooling system..................................................................................... 93                |
| Asset Performance ENE 17 - Cooling emitter type............................................................................................... 94            |
| Asset Performance ENE 18 - Glazing .................................................................................................................... 96   |
| Asset Performance ENE 19 - Mechanical and electrical cooling equipment........................................................ 97                            |
| Asset Performance ENE 20 - Specific fan power................................................................................................... 98          |
| Asset Performance ENE 21 - Duct and air handling leakage tests........................................................................ 99                    |
| Asset Performance ENE 22 - Mechanical and electrical ventilation equipment................................................ 101                               |
| Asset Performance ENE 23 - Domestic water heating........................................................................................ 102                |
| Asset Performance ENE 24 - Domestic water heating energy sources .............................................................. 103                          |
| Asset Performance ENE 25 - High frequency ballast .......................................................................................... 104             |
| Asset Performance ENE 27 - Automatic lighting controls .................................................................................. 107                |
| Asset Performance ENE 28 - Occupancy sensors ............................................................................................... 108             |
| Asset Performance ENE 29 - Benchmarking....................................................................................................... 109           |
| Asset Performance ENE 30 - On-site renewables............................................................................................... 110             |
| Transport....................................................................................................................................... 113         |
| Asset Performance TRA 01 - Cyclist facilities......................................................................................................          |
| 114 Asset Performance TRA 02 - Proximity to public transport................................................................................ 117             |

<!-- image -->

| Asset Performance TRA 03 - Proximity to amenities..........................................................................................         |   119 |
|-----------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| Asset Performance TRA 04 - Pedestrian and cyclist safety.................................................................................           |   121 |
| Water ............................................................................................................................................  |   122 |
| Asset Performance WAT01 - Water metering ...................................................................................................        |   123 |
| Asset Performance WAT02 - Water efficient equipment: Toilets .....................................................................                  |   125 |
| Asset Performance WAT03 - Water efficient equipment: Urinals.....................................................................                   |   127 |
| Asset Performance WAT04 - Water efficient equipment: Hand washing sinks ................................................                            |   129 |
| Asset Performance WAT05 - Water efficient equipment: Showers..................................................................                      |   131 |
| Asset Performance WAT06 - Water efficient equipment: Appliances ..............................................................                      |   133 |
| Asset Performance WAT07 - Leak detection system.........................................................................................            |   135 |
| Asset Performance WAT08 - Leak prevention...................................................................................................        |   136 |
| Asset Performance WAT09 - Isolation valves ....................................................................................................     |   137 |
| Asset Performance WAT 10 - Reducing utility-supplied water consumption ....................................................                         |   139 |
| Materials .......................................................................................................................................   |   140 |
| Asset Performance MAT 01 - Condition survey..................................................................................................       |   141 |
| Asset Performance MAT 02 - Security advice.....................................................................................................     |   143 |
| Asset Performance MAT 03 - Intruder alarm system .........................................................................................          |   145 |
| Asset Performance MAT 04 - Alarm system monitoring ....................................................................................             |   146 |
| Asset Performance MAT 05 - Natural hazards....................................................................................................      |   147 |
| Asset Performance MAT 06 - Future adaptation................................................................................................        |   149 |
| Asset Performance MAT 07 - Designing for robustness.....................................................................................            |   150 |
| Waste............................................................................................................................................   |   151 |
| Asset Performance WST 01 - Storage of operational waste...............................................................................              |   152 |
| Land Use and Ecology.....................................................................................................................           |   154 |
| Asset Performance LE 01 - Planted area............................................................................................................. |   155 |
| Asset Performance LE 02 - Ecological features of planted area.........................................................................              |   157 |
| Pollution........................................................................................................................................   |   158 |
| Asset Performance POL 01 - Pollution prevention .............................................................................................       |   159 |
| Asset Performance POL 02 - Flood risk assessment ...........................................................................................        |   161 |
| Asset Performance POL 03 - Surface water runoff impact mitigation ...............................................................                   |   163 |
| Asset Performance POL 04 - Impact of refrigerants...........................................................................................        |   165 |
| Asset Performance POL 05 - Refrigerant leak detection systems ......................................................................                |   168 |
| Asset Performance POL 06 - NO x emissions .......................................................................................................   |   170 |
| Part 2: Building Management.........................................................................................................                |   171 |

<!-- image -->

| Management .................................................................................................................................        |   172 |
|-----------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| Building Management MAN01 - Building user guide.........................................................................................            |   173 |
| Building Management MAN02 - Building user education .................................................................................               |   175 |
| Building Management MAN03 - Building user information ..............................................................................                |   176 |
| Building Management MAN04 - Operation and maintenance manuals ...........................................................                           |   177 |
| Building Management MAN05 - Maintenance procedures...............................................................................                   |   179 |
| Building Management MAN06 - Maintenance policy........................................................................................              |   181 |
| Building Management MAN07 - Environmental policies and responsibilities ..................................................                          |   183 |
| Building Management MAN08 - Environmental policies...................................................................................               |   185 |
| Building Management MAN09 - Operating procedures: Energy reduction ......................................................                           |   187 |
| Building Management MAN10 - Ventilation system leak testing......................................................................                   |   189 |
| Building Management MAN11 - Green lease ....................................................................................................        |   190 |
| Building Management MAN12 - Building management system review............................................................                           |   192 |
| Building Management MAN13 - Functional adaptability ..................................................................................              |   193 |
| Health and Wellbeing.....................................................................................................................           |   194 |
| Building Management HEA 12 - Fresh air rates..................................................................................................      |   195 |
| Building Management HEA 13 - Operating temperature...................................................................................               |   197 |
| Building Management HEA 14 - Internal environment: CO 2 monitoring............................................................                      |   198 |
| Building Management HEA 15 - Internal environment: CO monitoring.............................................................                       |   199 |
| Building Management HEA 16 - Internal environment: NO x monitoring...........................................................                       |   201 |
| Building Management HEA 17 - Internal environment: Refurbishment/renovation/redecoration ..................                                         |   203 |
| Building Management HEA 18 - Volatile organic compounds............................................................................                 |   204 |
| Building Management HEA 19 - Control of chemicals........................................................................................           |   206 |
| Building Management HEA 20 - Acoustic conditions .........................................................................................          |   207 |
| Building Management HEA 21 - Deep cleaning..................................................................................................        |   209 |
| Building Management HEA 22 - Legionella management..................................................................................                |   210 |
| Building Management HEA 23 - Occupant satisfaction: Surveying ....................................................................                  |   212 |
| Building Management HEA 24 - Occupant satisfaction: Feedback.....................................................................                   |   214 |
| Energy ...........................................................................................................................................  |   215 |
| Operational Energy Calculator Guidance ............................................................................................................ |   216 |
| Building Management ENE 31 - Energy consumption start date .......................................................................                  |   218 |
| Building Management ENE 32 - Energy consumption end date.........................................................................                   |   219 |
| Building Management ENE 33 - Electricity consumption ...................................................................................            |   220 |
| Building Management ENE 34 - Natural gas consumption.................................................................................               |   221 |
| Building Management ENE 35 - Propane consumption .....................................................................................              |   222 |

<!-- image -->

| Building Management ENE 36 - Gas oil consumption ........................................................................................          |   223 |
|----------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| Building Management ENE 37 - Solid fossil fuel consumption...........................................................................              |   224 |
| Building Management ENE 38 - Biodiesel consumption ....................................................................................            |   225 |
| Building Management ENE 39 - Biogas consumption.........................................................................................           |   226 |
| Building Management ENE 40 - Wood/Waste wood consumption ...................................................................                       |   227 |
| Building Management ENE 41 - District heating consumption ..........................................................................               |   228 |
| Building Management ENE 42 - Carbon intensity district heating .....................................................................               |   230 |
| Building Management ENE 43 - District cooling consumption...........................................................................               |   231 |
| Building Management ENE 44 - Carbon intensity district cooling......................................................................               |   232 |
| Building Management ENE 45 - Electricity exported..........................................................................................        |   233 |
| Building Management ENE 46 - Non-standard energy uses...............................................................................               |   234 |
| Building Management ENE 47, 50, 53, 56 &59 - Non-standard energy use......................................................                         |   236 |
| Building Management ENE 48, 51, 54, 57 &60 - Non-standard energy consumption ......................................                                |   238 |
| Building Management ENE 49, 52, 55, 58 &61 - Non-standard energy consumption floor area......................                                      |   239 |
| Building Management ENE 62 - Energy consumption monitoring.....................................................................                    |   240 |
| Building Management ENE 63 - Energy consumption data use .........................................................................                 |   241 |
| Building Management ENE 64 - Sub-metering: Main energy sources................................................................                     |   242 |
| Building Management ENE 65 - Sub-metering: Other energy sources ..............................................................                     |   243 |
| Building Management ENE 66 - Sub-metering: Tenanted areas ........................................................................                 |   245 |
| Transport.......................................................................................................................................   |   246 |
| Water ............................................................................................................................................ |   246 |
| Building Management WAT 11 - Annual consumption ......................................................................................             |   247 |
| Building Management WAT 12 - Water consumption: Monitoring and reporting ............................................                              |   248 |
| Building Management WAT 13 - Drinking water provision ................................................................................             |   250 |
| Building Management WAT 14 - Refurbishment policy: Water efficiency.........................................................                       |   251 |
| Building Management WAT 15 - Water system maintenance strategy .............................................................                       |   252 |
| Building Management WAT 16 - Water recycling ..............................................................................................        |   253 |
| Building Management WAT 17 - Water extraction ............................................................................................         |   254 |
| Materials .......................................................................................................................................  |   255 |
| Building Management MAT 08 - Condition survey.............................................................................................         |   256 |
| Building Management MAT 09 - Sustainable procurement policy.....................................................................                   |   258 |
| Building Management MAT 10 - Sustainable procurement initiatives...............................................................                    |   260 |
| Building Management MAT 11 - Fire risk assessment........................................................................................          |   261 |
| Building Management MAT 12 - Fire risk management.....................................................................................             |   262 |

<!-- image -->

| Building Management MAT 13 - Emergency plan ..............................................................................................                                                               | 263                                                               |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------|
| Building Management MAT 14 - Natural hazard management..........................................................................                                                                         | 265                                                               |
| Waste............................................................................................................................................                                                        | 267                                                               |
| Land Use and Ecology.....................................................................................................................                                                                | 267                                                               |
| Building Management LE 03 - Ecology report ....................................................................................................                                                          | 268                                                               |
| Building Management LE 04 - Biodiversity action plan ......................................................................................                                                              | 270                                                               |
| Building Management LE 05 - External landscaping/maintenance....................................................................                                                                         | 272                                                               |
| Pollution........................................................................................................................................                                                        | 274                                                               |
| Building Management POL 07 - Night time light pollution.................................................................................                                                                 | 275                                                               |
| Building Management POL 08 - Chemical storage .............................................................................................                                                              | 277                                                               |
| Building Management POL 09 - Secondary containment...................................................................................                                                                    | 278                                                               |
| Building Management POL 10 - Light-liquid separators.....................................................................................                                                                | 279                                                               |
| Building Management POL 11 - Refrigerants .....................................................................................................                                                          | 280                                                               |
| Building Management POL 12 - Land contamination mitigation .......................................................................                                                                       | 282                                                               |
| Building Management POL 13 - Emergency preparedness and response..........................................................                                                                               | 284                                                               |
| Building Management POL 14 - Complaints procedure .....................................................................................                                                                  | 285                                                               |
| Part 3: Occupier Management........................................................................................................                                                                      | 286                                                               |
|                                                                                                                                                                                                          | 287                                                               |
| Management ................................................................................................................................. Occupier Management MAN14 - Environmental management policy | ............................................................. 288 |
| Occupier Management MAN15 - Environmental management issues .............................................................                                                                                | 290                                                               |
| Occupier Management MAN16 - Environmental management implementation.............................................                                                                                         |                                                                   |
|                                                                                                                                                                                                          | 292                                                               |
| Occupier Management MAN18 - Organizational performance review.............................................................                                                                               | 297                                                               |
| Occupier Management MAN19 - Sustainability report .....................................................................................                                                                  | 299                                                               |
| Occupier Management MAN20 - Green lease...................................................................................................                                                               | 301                                                               |
| Health and Wellbeing.....................................................................................................................                                                                | 302                                                               |
| Occupier Management HEA 25 - Occupier satisfaction......................................................................................                                                                 | 303                                                               |
| Occupier Management HEA 26 - Health and well-being management targets .................................................                                                                                  | 305                                                               |
| Occupier Management HEA 27 - Health and well-being management objectives ............................................                                                                                    | 308                                                               |
| Occupier Management HEA 28 - View out.........................................................................................................                                                           | 309                                                               |
| Occupier Management HEA 29 - Communal rest areas.....................................................................................                                                                    | 311                                                               |
| Energy ...........................................................................................................................................                                                       | 312                                                               |
| Occupier Management ENE 67 - Energy policy ..................................................................................................                                                            | 313                                                               |

<!-- image -->

| Occupier Management ENE 68 - Energy management arrangements...............................................................                         |   314 |
|----------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| Occupier Management ENE 69 - Trends in energy performance data...............................................................                      |   316 |
| Occupier Management ENE 70 - Energy objectives ...........................................................................................         |   317 |
| Occupier Management ENE 71 - Energy savings................................................................................................        |   318 |
| Transport.......................................................................................................................................   |   319 |
| Occupier Management TRA 05 - Transport requirements.................................................................................               |   320 |
| Occupier Management TRA 06 - Transport management arrangements..........................................................                           |   322 |
| Occupier Management TRA 07 - Local public transport.....................................................................................           |   324 |
| Occupier Management TRA 08 - Local amenities...............................................................................................        |   325 |
| Occupier Management TRA 09 - Transport objectives.......................................................................................           |   326 |
| Occupier Management TRA 10 - Transport impact of commuting ....................................................................                    |   327 |
| Occupier Management TRA 11 - Transport impact of business travel...............................................................                    |   329 |
| Occupier Management TRA 12 - Transport impact of goods delivery ...............................................................                    |   331 |
| Water ............................................................................................................................................ |   332 |
| Occupier Management WAT 18 - Water management: Staff engagement.......................................................                             |   333 |
| Occupier Management WAT 19 - Water monitoring &management ...............................................................                          |   334 |
| Occupier Management WAT 20 - Water management targets..........................................................................                    |   336 |
| Occupier Management WAT 21 - Water consumption......................................................................................               |   337 |
| Materials .......................................................................................................................................  |   338 |
| Occupier Management MAT 15 - Material procurement: Selection..................................................................                     |   339 |
| Occupier Management MAT 16 - Material procurement: Management arrangements ...................................                                     |   341 |
| Occupier Management MAT 17 - Supplier approval ..........................................................................................          |   344 |
| Occupier Management MAT 18 - Supplier quality policy...................................................................................            |   345 |
| Occupier Management MAT 19 - Supplier environmental management..........................................................                           |   347 |
| Occupier Management MAT 20 - Supplier quality management (third party certified)....................................                               |   349 |
| Occupier Management MAT 21 - Supplier environmental management (third party certified) .......................                                     |   351 |
| Occupier Management MAT 22 - Supplier responsible sourcing standard (third party certified).....................                                   |   352 |
| Occupier Management MAT 23 - Material procurement targets ......................................................................                   |   354 |
| Waste............................................................................................................................................  |   355 |
| Occupier Management WST 02 - Waste management: The waste hierarchy ...................................................                             |   356 |
| Occupier Management WST 03 - Waste management: Recycling and reclamation..........................................                                 |   358 |
| Occupier Management WST 04 - Waste management arrangements...............................................................                          |   360 |
| Occupier Management WST 05 - Waste monitoring..........................................................................................            |   362 |
| Occupier Management WST 06 - Waste performance.......................................................................................              |   363 |

<!-- image -->

| Occupier Management WST 07 - Waste management objectives.....................................................................                                         |   364 |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| Occupier Management WST 08 - Waste sent to landfill.....................................................................................                              |   365 |
| Occupier Management WST 09 - Waste diverted from landfill .........................................................................                                   |   366 |
| Occupier Management WST 10 - Waste sent for incineration...........................................................................                                   |   367 |
| Land Use and Ecology.....................................................................................................................                             |   368 |
| Occupier Management LE 06 - Ecology/biodiversity enhancement ..................................................................                                       |   369 |
| Pollution........................................................................................................................................                     |   370 |
| Occupier Management POL 15 - Pollution management...................................................................................                                  |   371 |
| Occupier Management POL 16 - Pollution prevention arrangements...............................................................                                         |   373 |
| Occupier Management POL 17 - Pollution prevention targets ..........................................................................                                  |   376 |
| Appendix A: Offices........................................................................................................................                           |   377 |
| Introduction......................................................................................................................................................... |   378 |
| HEA 26A - Health and Wellbeing ........................................................................................................................               |   379 |
| ENE 68A - Energy ................................................................................................................................................     |   380 |
| TRA 06A - Transport............................................................................................................................................       |   382 |
| WAT 19A - Water................................................................................................................................................       |   383 |
| MAT 16A - Materials...........................................................................................................................................        |   384 |
| WST 04A - Waste ................................................................................................................................................      |   385 |
| POL 16A - Pollution .............................................................................................................................................     |   387 |
| Schedule of changes to this BREEAM Program Document...............................................................                                                    |   388 |

<!-- image -->

<!-- image -->

## List of tables

| Table 1: BREEAM In-Use sustainability categories ................................................................................................... 17                 |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Table 2: Asset types that can be assessed using BREEAM USA In-Use ..................................................................... 21                              |
| Table 3: Client type that each BREEAM In-Use part is aimed at ............................................................................... 22                        |
| Table 4: BREEAM In-Use environmental category weightings.................................................................................. 24                           |
| Table 5: BREEAM In-Use rating benchmarks............................................................................................................. 25                |
| Table 6: BREEAM USA In-Use Part 3 minimum standards......................................................................................... 26                         |
| Table 7: Example BREEAM USA In-Use Part 2 calculation......................................................................................... 28                       |
| Table 8: BREEAM Evidence principles ....................................................................................................................... 32          |
| Table 9: Evidence types............................................................................................................................................. 34 |
| Table 10: Energy end use components and subcomponents ................................................................................... 66                            |
| Table 11: End use component weighting factors...................................................................................................... 69                  |
| Table 12:Water consumption baseline levels of appliances. .................................................................................. 133                        |

<!-- image -->

<!-- image -->

## List of figures

| Figure 1: BREEAM programs by built environment lifecycle stages..........................................................................                 |   19 |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------|------|
| Figure 2: Multi-tenanted asset with common area assessed only............................................................................                 |   23 |
| Figure 3: Multi-tenanted asset with common area and spaces B, D and E assessed................................................                            |   23 |
| Figure 4: Asset energy calculation flowchart ............................................................................................................ |   70 |

<!-- image -->

<!-- image -->

## About the BRE Group

## BRE Group

BRE was set up in 1921 as the Building Research Station (BRS). This became the Building Research Establishment (BRE) in 1972 and since being privatized in 1997, we have called ourselves simply 'BRE'.

BRE is a world leading building science center that generates new knowledge through research. This is used to create  products,  tools  and  standards  that  drive  positive  change  across  the  built  environment.    BRE  helps  its government and private sector clients meet the significant environmental, social and economic challenges they face in delivering homes, buildings and communities.

## BRE Global

BRE  Global  Limited  (incorporating  LPCB  &amp;  BREEAM)  is  an  independent  third-party  approvals  body  offering certification  of  fire,  security  and  sustainability  products  and  services  to  an  international  market.  BRE  Global's product testing and approvals are carried out by recognized experts in our world-renowned testing laboratories. BRE Global Limited is custodian of a number of world leading brands including:

-  LPCB for the approval of fire and security products and services, listed in the Red Books.
-  BREEAM the world's leading environmental assessment method for buildings, sets the standard for best practice in sustainable design and has become the de-facto measure of a building's environmental performance.

BRE Global Limited is an independent third-party approvals body that offers certification, training and licensing services for BREEAM rating systems to the USA market.

<!-- image -->

<!-- image -->

## About this Program Document

This document is the BREEAM USA In-Use Technical Manual. It describes an environmental performance standard against which existing, commercial assets can be assessed and achieve a BREEAM USA In-Use rating. The BREEAM USA In-Use  Technical  Manual  is  the  BREEAM  In-Use  International  program  that  has  been  adapted  to  reflect differences  in  US  standards,  units,  industry  practices  and  language.  This  ensures  that  the  international comparability of the program is maintained.

The Program Document and the information detailed within is intended for use by trained, qualified and licensed Assessors in accordance with the procedural and operational requirements of BREEAM USA (as described in the BREEAM USA Operations Manual (PD101)) and the terms and conditions of a BREEAM USA In-Use license. This document should be used by clients and those who are not licensed BREEAM USA In-Use Assessors for reference purposes only.

## Changes to this BREEAM Program Document

This document can be subject to change and can be re-released by BRE Global Ltd. A schedule of the publication date for each issue of this document is provided below.

It is important to note that in general a reissue does not result in changes, deletions or additions to the main assessment criteria or assessment issues.  Fundamental changes to assessment criteria are typically made as part of a formal program update, resulting in a new BREEAM program version.

A list of additions, deletions and alterations made to the previous issue is available in the Schedule of changes to this BREEAM Program Document section of this manual.

| Issue Type   | Issue No.     | Date of Issue   |
|--------------|---------------|-----------------|
| Launch       | 1.0           | August 1, 2016  |
| Reissue      | 1.1           | August 1, 2017  |
| Reissue      | 2.0 (current) | April 8, 2019   |

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Introduction to BREEAM

BREEAM (Building Research Establishment's Environmental Assessment Method) is the world's first sustainability rating program for the built environment and has contributed much to the focus globally on sustainability in building design, construction and use. BREEAM is now an international standard that is locally adapted, operated and  applied  through  a  network  of  international  operators,  Assessors  and  industry  professionals.  Through  its application and use BREEAM helps clients measure and reduce the environmental impacts of their buildings and in doing so create higher value, lower risk assets.

## Aims of BREEAM

-  To mitigate the life cycle impacts of buildings on the environment.
-  To enable buildings to be recognized according to their environmental benefits.
-  To provide a credible, environmental label for buildings.
-  To stimulate demand and create value for sustainable buildings, building products and supply chains.

## Objectives of BREEAM

-  To provide market recognition of buildings with a low environmental impact.
-  To  ensure  best  environmental  practice  is  incorporated  in  the  planning,  design,  construction  and operation of buildings and the wider built environment.
-  To define a robust, cost effective performance standard surpassing that required by regulations.
-  To challenge the market  to  provide  innovative,  cost effective solutions that minimize  the environmental impact of buildings.
-  To raise awareness amongst owners, occupants, designers and operators of the benefits and value of buildings with a reduced life cycle impact on the environment.
-  To allow organizations to demonstrate progress towards corporate environmental objectives.

BREEAM is developed and operated to meet the following underlying principles:

-  Ensure environmental quality through an accessible, holistic and balanced measure of environmental impacts.
-  Use quantified measures for determining environmental quality.
-  Adopt  a flexible  approach that  encourages  and  rewards  positive  outcomes,  avoiding  prescribed solutions.
-  Use robust science and best practice as the basis for quantifying and calibrating a cost effective and rigorous performance standard for defining environmental quality.
-  Reflect the social and economic benefits of meeting the environmental objectives covered.
-  Provide a common international framework of assessment that is tailored to meet the 'local' context including regulation, climate and sector.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

-  Integrate  building  professionals in  the  development  and  operational  processes  to  ensure  wide understanding and accessibility.
-  Adopt third party certification to ensure independence, credibility and consistency of the label.
-  Adopt existing industry  tools , practices  and  other  standards  wherever  possible  to  support developments in policy and technology, build on existing skills and understanding and minimize costs.
-  Align technically and operationally with relevant international standards.
-  Engage with a representative range of stakeholders to inform on-going development in accordance with  the  underlying  principles  and  the  pace  of  change  in  performance  standards  (accounting  for policy, regulation and market capability).

The  aims,  objectives  and  principles  of  BREEAM  are  embodied  within  a  Core  Technical  Standard  owned  and managed by BRE Global Limited. This is applied through a suite of BREEAM programs covering aspects of the built environment life cycle.   These programs are operated across a range of countries by BRE Global Limited, Licensees and select local operators, known as National Scheme Operators (NSOs). For a full list of BREEAM National Scheme Operators and Programs for countries other than the United States, please visit www.breeam.com.

## The BRE Global BREEAM Programs

BRE  Global  Limited  develops  and  operates  a  number  of  BREEAM  programs  (also  known  as  schemes),  each designed to assess the environmental performance of buildings at various stages in the life cycle, including:

-  BREEAM Communities for the master-planning of a larger community of buildings
-  BREEAM New Construction for new build, residential and commercial buildings
-  BREEAM In-Use for existing commercial buildings in-use
-  BREEAM Refurbishment and Fit-Out for residential and commercial buildings

Assessments undertaken in these programs outside of the United States and NSO territories are operated by BRE Global  Limited. For further information  on  how  to  get  certified against these programs,  please  visit www.breeam.com or contact BRE Global.

## BREEAM USA Programs

BRE Global Limited operates BREEAM In-Use in the United States, known as BREEAM USA In-Use.

Independent Assessors, trained, qualified and licensed by BRE Global Limited can undertake a BREEAM In-Use assessment using this Program Document and associated reporting and calculation tools for assets.

Once  an  assessment  is  complete  and  quality  assured,  BRE  Global  Limited  will  issue  a  BREEAM  USA  In-Use certificate. The BREEAM USA In-Use certificate provides formal verification that the Assessor has completed an assessment  for  an  asset  in  accordance  with  the  requirements  of  the  program  and  its  quality  standards  and procedures.

A BREEAM USA In-Use certificate provides assurance to any interested party that a BREEAM USA rating, at the time of certification, accurately reflects its performance against the BREEAM USA In-Use standard.

<!-- image -->

Version 2.0: 2016, April 2019

Anyone wishing to verify  the  BREEAM  USA  rating  of  an  asset  can  do  so  by  either  checking  its  BREEAM  USA certificate,  which  will  contain  the  certification  mark,  or  by  searching  the  BREEAM  buildings  listings  on GreenBookLive, the global database for all BREEAM assessments (www.greenbooklive.com).

Assessments against BREEAM Programs other than BREEAM In-Use can be carried out using the International versions of the applicable program. Please visit www.breeam.com for further information.

## Ensuring quality and consistency

All BREEAM programs are developed and operated by National Scheme Operators (NSOs) in accordance with the Code for a  Sustainable  Built  Environment.  The  Code  for  a  Sustainable  Built  Environment  is  a  set  of  strategic principles and requirements which define an integrated approach to the design, management, evaluation and certification of the environmental, social and economic impacts of the built environment.

The Code is interpreted through the BREEAM Core Process and Technical Standards. These linked documents set out the requirements that a compliant scheme must meet in order to be affiliated with the Code. The Standards ensure that a common scientific and performance basis is used by all compliant schemes operated by NSOs, while ensuring that these are relevant to local demands, standards and practices.

The Code and associated standards are developed and maintained by BRE Global Limited with direction from the BREEAM Strategy Board, under the auspices of the BRE Global Governing Board.

To ensure competence, impartiality and performance capability, all National Scheme Operators are required to maintain  scheme  operations  to  internationally  agreed  standards  and  seek  accreditation  from  a  national accreditation body.

BRE Global Limited is a United Kingdom Accreditation Service (UKAS) accredited certification body (No. 0007). The scope  of  our  accreditation  to  ISO/IEC  17065  'Conformity  assessment  -  Requirements  for  bodies  certifying products,  processes  and  services'  can  be  verified  on  the  UKAS  website,  and  includes  BREEAM  USA  PD100 'Environmental assessments of the built environment - certification of the process'.

BRE Global Ltd is also certified to ISO 9001 'Quality management systems - Requirements' for all its BREEAM related activities.

As an accredited certification body, BRE Global Limited maintains an open and accountable governance structure. The operation of BREEAM is overseen by an independent Governing Body and a Standing Panel for Peer &amp; Market Review.

The Governing Body represents stakeholder interests to ensure, amongst other things, that BREEAM operations are independent and impartial, processes operate correctly and customers are treated fairly.

The Standing Panel provides BRE Global Limited with access to a range of experts that can review the core BREEAM standards and programs to ensure their robustness from a scientific, technical and market perspective as well as ensuring the development of the standards and programs is open to greater external and independent scrutiny.

<!-- image -->

<!-- image -->

## BREEAM USA In-Use

The BREEAM USA In-Use program (referred to as BREEAM In-Use from this point onwards) is a performance-based assessment method and certification program for existing commercial buildings.

The primary aim of BREEAM In-Use is to mitigate the operational impacts of existing assets on the environment in a robust and cost-effective manner. The program provides a holistic approach that enables assets to be assessed and benchmarked across a large range of environmental issues  (management, health and wellbeing, energy, transport, water, materials, waste, land use and ecology, and pollution).

The BREEAM In-Use assessment process is broken down into three Parts:

-  Part 1 - Asset Performance: the performance of the asset's built form, construction, fixtures, fittings and installed services
-  Part 2 - Building Management: the management of the asset
-  Part 3 - Occupier Management: the management of building users and services

A Part 1 or Part 2 assessment can be conducted in isolation. A Part 3 assessment is recommended to be undertaken in combination with a Part 2 assessment as the score achieved for Part 2 feeds into the score for Part 3. Clients are, however encouraged to assess against all 3 Parts to assess the overall environmental impact of their asset.

The final outcome of a BREEAM In-Use assessment is a certified BREEAM In-Use rating for the Part against which an assessment is undertaken. This certified BREEAM In-Use rating reflects the asset's performance across the environmental categories  listed  in  Table  1.  It  enables  the  performance  of  the  asset  to  be  assessed  but  most importantly, the knowledge obtained from such a comprehensive assessment allows the asset's performance to be  optimized  through  informed  management  decisions.  By  enabling  on-going  assessments,  BREEAM  In-Use encourages continual improvement.

| Environmental Category   | Purpose                                                                                                                                                                                                            |
|--------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Management               | To encourage the adoption of sustainable management practices related to operational activities to ensure that robust sustainability objectives are set, monitored and regularly updated.                          |
| Health &Wellbeing        | To manage, monitor and increase the comfort and health and safety of asset occupants, visitors and other users within the asset.                                                                                   |
| Energy                   | To manage and monitor energy consumption and to encourage the use of equipment that supports the sustainable use and management of energy in the asset.                                                            |
| Transport                | To recognize the implementation of policies that record the impacts related to transport, the proximity of local amenities and improve the ability of stakeholders to utilize alternative means of transportation. |

<!-- image -->

Table 1:  BREEAM In-Use sustainability categories

<!-- image -->

| Environmental Category   | Purpose                                                                                                                                                                                            |
|--------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Water                    | To manage and monitor water consumption in the operation of the asset and its site to encourage sustainable water consumption.                                                                     |
| Materials                | To manage and monitor the environmental impact of procurement as well as recognizing the risks to the asset and its occupiers associated with security, fire and other naturally occurring events. |
| Waste                    | To encourage and recognize the implementation of policies and systems that reduces waste production and improve levels of segregation and recycling.                                               |
| Land Use & Ecology       | To manage and monitor the impact that activities undertaken on the asset's site have on the local environment and encourage sustainable land use, habitat protection and creation.                 |
| Pollution                | To prevent, manage, monitor and control pollution associated with the assets location and operation.                                                                                               |

## Relationship to other BREEAM programs

BREEAM In-Use assesses the In-Use phase of a building's lifecycle as outlined in Figure 1. The construction of new buildings, new infrastructure or community projects, and existing building refurbishment and fit-outs cannot be assessed under the BREEAM In-Use program. Projects in the United States requiring assessment during these life cycle  stages  should  be  assessed  under  the  relevant  international  BREEAM  program  indicated  in  Figure  1. Certification through the BREEAM International programs can be sought through BRE Global.

BREEAM In-Use  has  been  developed  with  3  distinct  parts,  each  addressing  a  different  aspect  of  an  existing building's performance. Once a building has been constructed, the asset performance can be assessed with Part 1  of  BREEAM  In-Use.  Undertaking  this  assessment  will  provide  the  Client  with  an  overview  of  the  actual performance of the asset's fixtures, services and built form and can be used to inform refurbishment and/or tuning and re-commissioning processes.

As the In-Use phase of buildings lasts for multiple years, BREEAM In-Use has been developed to assess the ongoing performance of existing buildings and identify opportunities for improvements in a continuous cycle. A BREEAM In-Use assessment can therefore be used to inform where and when refurbishments should be carried out and how these perform against the targets once completed. The BREEAM Refurbishment and Fit-out program can then be used to assess and certify the delivery of a sustainable refurbishment and fit-out.

<!-- image -->

Figure 1: BREEAM programs by built environment lifecycle stages

<!-- image -->

## How to apply the BREEAM USA In-Use program

This BREEAM USA In-Use program document is a technical manual which has been created to:

-  Enable  qualified  and  licensed  BREEAM  USA  In-Use  Assessors  to  complete  BREEAM  USA  In-Use assessments and determine a rating.
-  Enable BRE Global Limited to complete quality assurance reviews of a BREEAM USA In-Use licensed Assessor's  assessment  report,  in  accordance  with  the  standards  to  which  BRE  Global  Limited  has aligned operations.
-  As a reference for clients whose proposed asset/management practices are assessed against BREEAM USA In-Use.

The technical manual is split into five sections:

- The Scope section describes the types of assets and stages of assessment that this version of the BREEAM USA In-Use Program can be applied to. The Scope section can be used by clients and BREEAM USA In-Use Assessors to check whether this is the correct BREEAM program to use for their project.
- The Scoring and rating section illustrates how an asset's assessed performance is measured and rated. It outlines the BREEAM In-Use rating level benchmarks, the minimum standards for Part 3, and the BREEAM InUse environmental category weightings. Furthermore, this section includes a description of the BREEAM InUse assessment issues and 'credits' and how performance against these is calculated and expressed as a BREEAM In-Use rating. This unverified rating would need to be assessed by a licensed BREEAM USA In-Use Assessor for the asset to achieve formal certification.
- The Evidence for BREEAM USA In-Use section provides guidance to BREEAM USA In-Use Assessors on the various types and forms of evidence to demonstrate compliance with BREEAM In-Use issues. This section also includes a description of why BREEAM requires an auditable trail of evidence and a table of general types of evidence that are typically required and used as a form of compliance.
- The Building Details section includes an explanation of building and asset related data that must be completed prior to undertaking a BREEAM In-Use assessment. The data that is filled out within this section will assist in determining energy benchmarks and scores and will be used when a certificate is requested.

<!-- image -->

<!-- image -->

- The Assessment  criteria section includes the BREEAM  In-Use  assessment  issues,  categorized  in  9 environmental categories divided  over  the  three Parts.  Within  each  issue  the  levels  of  performance  (the available credits) against which the asset will be assessed are outlined.  By using the appropriate evidence, a corresponding number of available BREEAM In-Use credits can be awarded.

Several issues in Part 3 of the BREEAM USA In-Use assessment process have minimum standards. This means that  in  order  to  achieve  a  particular  BREEAM  In-Use  rating,  specific  credits  or  criteria  must  be  achieved (BREEAM In-Use minimum standards are outlined in the Scoring and rating BREEAM USA In-Use assessed assets section).

<!-- image -->

Version 2.0: 2016, April 2019

## Scope of BREEAM In-Use

The BREEAM USA In-Use program is used to assess the environmental performance of existing (in-use) commercial assets.

BREEAM USA In-Use has been developed for use in the United States only. Assets outside the United States (including Canada) must use BREEAM In-Use International or the country specific BREEAM rating system run by a National Scheme Operator (NSO).  For more information on how to assess assets outside of the United States, please visit www.breeam.com.

## Asset types that can be assessed

The asset types that can be assessed under each Part of the BREEAM USA In-Use standard are as follows:

Table 2: Asset types that can be assessed using BREEAM USA In-Use

| Part 1: Asset Performance   | All commercial asset types that meet eligibility criteria requirements   |
|-----------------------------|--------------------------------------------------------------------------|
| Part 3: Occupier Management | Offices only                                                             |

## Eligibility criteria

For all asset types that can be assessed using BREEAM USA In-Use, the eligibility criteria listed below must also be met:

## For an assessment of any Part:

-  The asset must be a complete and finished structure.
-  The asset must contain occupied space(s). Occupied space is a room/rooms or space within the asset that is likely to be continuously occupied for 30 minutes or more per day by a building user).
- For a Part 1 assessment that has not yet been occupied, the asset must contain space that is designated to be occupied.
-  An asset does not have to include the whole building; it could include just part of a building or a single floor. In such cases, the scope of the BREEAM In-Use assessment must include all relevant amenity and service areas.
-  An asset cannot normally include more than one building. The only exception is where several buildings meet the following criteria:
- o Connected to and share common services to meet the comfort and sanitary demands of the occupants (for example: heating, ventilation, cooling and hot water).
- o The buildings have the same building function, similar performance, are of the same design and age.
- o Building management and maintenance policies are the same across the buildings.
- o The buildings share the same building envelope specification (the physical separator between the interior and exterior of a building).

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

Where floor areas are shared by more than one organization, it must be assessed as one asset for Part 1 and Part 2. For a Part 3 assessment, each occupying organization would have to undertake an assessment.

-  The asset must comply with all relevant regulation/legislation in its location including (but not limited to): environmental and health and safety legislation.

## For an assessment of Part 2 and/or Part 3

-  The asset must have been occupied for at least one year prior to the start of the assessment.
-  Consumption data related to all spaces included in the assessment must be available for at least one year prior to the start of the assessment. This includes (but is not limited to): energy, water, plus transport and waste data for Part 3 assessments. For energy consumption, this must include both electrical and nonelectrical data. Please refer to the Part 2 Energy Section for further information.

## Multi-tenanted assessments

The client type each BREEAM In-Use Part is aimed at, and how these Parts can be assessed against within multitenanted assets is outlined in Table 3.

Table 3: Client type that each BREEAM In-Use part is aimed at

| Part                   | Client type                    | Multi-tenanted assessment                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         |
|------------------------|--------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1: Asset Performance   | Building owner                 | The rating can be based on: a. Commonareas* that a facility/building manager is responsible for OR b. Common areas AND tenanted areas within the asset that are managed by the asset's facility/building manager Where option b is selected: The Assessor needs to collate the required data from each space type and the final score would be determined by the space with the lowest score. The assessment must include evidence of a representative sample of the tenants to ensure that central management practices are in place and fully implemented in line with the assessment criteria. Note : The evidence provided for these samples must be representative of the asset and must include at least one sample of each type of space use within the asset. For example, where there are: shops, offices and food space uses within the asset, the sample must include evidence that central management practices are in place for a representative sample of each of these space uses. |
| 2: Building Management | Facility / building management | The rating can be based on: a. Commonareas* that a facility/building manager is responsible for OR b. Common areas AND tenanted areas within the asset that are managed by the asset's facility/building manager Where option b is selected: The Assessor needs to collate the required data from each space type and the final score would be determined by the space with the lowest score. The assessment must include evidence of a representative sample of the tenants to ensure that central management practices are in place and fully implemented in line with the assessment criteria. Note : The evidence provided for these samples must be representative of the asset and must include at least one sample of each type of space use within the asset. For example, where there are: shops, offices and food space uses within the asset, the sample must include evidence that central management practices are in place for a representative sample of each of these space uses. |
| 3: Occupier Management | Occupier                       | Multi-tenanted buildings cannot be assessed as a single asset under Part 3, as management practices are likely to differ for each tenant. Therefore, a Part 3 assessment must be undertaken for each tenant.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |

<!-- image -->

Version 2.0: 2016, April 2019

*Common areas are facilities and/or access that is not owned or controlled by any one individual tenant, but used by all. These common areas are typically managed and maintained by the development's owner, i.e. landlord or their managing agent. Examples of common areas include: an atrium, stairwells, main entrance foyers/reception and external landscaped areas.

## Example situations for multi-tenanted assets can be seen in Figure 2 and Figure 3.

(Assessed area in grey)

<!-- image -->

<!-- image -->

Figure 2: Multi-tenanted asset with common area assessed only.

(Assessed area in grey)

Figure 3: Multi-tenanted asset with common area and spaces B, D and E assessed.

## Data collection and use

Real estate owners, occupiers, developers and funders around the world are facing ever-increasing demands to address the demands of Corporate Social Responsibility and hence the need for greater sustainability of existing buildings they own, manage and occupy.

By  gathering,  analyzing  and  sharing  data  trends  related  to  the  environmental  performance  of  these  assets, BREEAM In-Use will help clients to develop a common understanding of how their assets perform, what measures can be taken to improve their performance and the cost benefit these measures give. Assessing an asset with BREEAM In-Use means a client can:

-  Set key performance indicators for energy, water, waste and greenhouse gas performance.
-  Understand the performance of assets within their portfolios.
-  Benchmark individual assets within portfolios against similar assets in the United States and in other territories.
-  Optimize the performance of their buildings through good management, maintenance and occupation policies and procedures.
-  Set performance improvement targets and measure progress over time.
-  Support  BRE  on  the  continuing  development  of  BREEAM  In-Use  by  identifying  and  improving  best environmental performance of existing buildings.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Scoring and rating of BREEAM USA In-Use assessed assets

There are four elements that determine the overall performance of an In-Use asset assessed using BREEAM USA In-Use:

- 1. The environmental category weightings
- 2. The BREEAM In-Use rating level benchmarks
- 3. For a Part 3 assessment: the BREEAM In-Use minimum standards
- 4. The BREEAM In-Use assessment issues and credits

The way in which these elements combine to produce a BREEAM USA In-Use rating is summarized below.

## Environmental category weightings

Environmental weightings are fundamental to any building environmental assessment method as they provide a means of defining, and therefore ranking, the relative impact of environmental issues. BREEAM uses an explicit weighting system derived from a combination of consensus-based weightings and ranking by a panel of experts. The outputs from this exercise are then used to determine the relative value of the environmental categories used in BREEAM and their contribution to the overall BREEAM score.

This weighting system is defined in greater detail within the BRE Global Core Process Standard (BES 5301) and it's supporting procedural documents. These form part of the overarching BREEAM Standard.

The weightings for each of the nine environmental categories included in the BREEAM In-Use program are outlined in Table 4.

Table 4: BREEAM In-Use environmental category weightings

|                        | Weighting   | Weighting   | Weighting   |
|------------------------|-------------|-------------|-------------|
| Environmental Category | Part 1      | Part 2      | Part 3      |
| Management             | -           | 15%         | 12%         |
| Health &Wellbeing      | 17%         | 15%         | 15%         |
| Energy                 | 26.5%       | 31.5%       | 19.5%       |
| Transport              | 11.5%       | -           | 18.5%       |
| Water                  | 8%          | 5.5%        | 3.5%        |
| Materials              | 8.5%        | 7.5%        | 4.5%        |
| Waste                  | 5%          | -           | 11.5%       |
| Land Use & Ecology     | 9.5%        | 12.5%       | 5%          |
| Pollution              | 14%         | 13%         | 10.5%       |
| Total                  | 100%        | 100%        | 100%        |

<!-- image -->

<!-- image -->

## BREEAM In-Use rating benchmarks

The BREEAM rating benchmarks for projects assessed using BREEAM In-Use are outlined in Table 5.

Table 5: BREEAM In-Use rating benchmarks

| BREEAM In-Use Rating   | %score     | Star rating   |
|------------------------|------------|---------------|
| Outstanding            | ≥85        |         |
| Excellent              | ≥70 to <85 |          |
| Very Good              | ≥55 to <70 |           |
| Good                   | ≥40 to <55 |            |
| Pass                   | ≥25 to <40 |             |
| Acceptable             | ≥10 to <25 |              |
| Unclassified           | <10        | -             |

The BREEAM In-Use rating benchmarks enable a client and all other stakeholders to compare the performance of the asset with other existing assets, including those within a portfolio.

An unclassified BREEAM In-Use rating represents performance that is non-compliant with BREEAM In-Use, failing to meet either the BREEAM In-Use minimum standards for key environmental issues or the overall threshold score required for formal BREEAM In-Use certification.

## Minimum standards

To maintain a flexible system, BREEAM In-Use adopts a 'balanced scorecard' approach to the assessment and rating of asset performance. This means that, to achieve a particular level of performance the majority of BREEAM In-Use credits can be traded. Non-compliance in one area can be off-set through compliance in another to achieve the target BREEAM In-Use rating.

However, to ensure that performance against fundamental environmental issues is not over-looked in pursuit of a particular rating, BREEAM In-Use for a Part 3 assessment only sets minimum standards of performance in key areas, such as energy, water and waste see Table 6.

It is important to bear in mind that these are minimum acceptable levels of performance and, in that respect they should not necessarily be viewed as levels that are representative of best practice for a BREEAM In-Use rating level.

The minimum standards in Part 3 must be met in order to achieve a given BREEAM In-Use rating. These minimum standards are contained within the answer options for the Part 3 (Occupier Management) assessment option and are outlined in Table 6. Regardless of the number of credits achieved in the Part 3 questionnaire, all minimum standards answer options related to a specific BREEAM In-Use rating must be met in order to achieve that rating. Where the minimum standards have not been met, the rating cannot be achieved even if enough credits have been gained to satisfy that rating band.

<!-- image -->

Version 2.0: 2016, April 2019

## Table 6: BREEAM USA In-Use Part 3 minimum standards

|                                          | Minimum standards by BREEAM In-Use rating                     | Minimum standards by BREEAM In-Use rating                                                                                                                             | Minimum standards by BREEAM In-Use rating                                                                                                                                                         | Minimum standards by BREEAM In-Use rating                                                                                                                                                         | Minimum standards by BREEAM In-Use rating                                                                                                                                                         |
|------------------------------------------|---------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| BREEAM issue                             | Pass                                                          | Good                                                                                                                                                                  | Very Good                                                                                                                                                                                         | Excellent                                                                                                                                                                                         | Outstanding                                                                                                                                                                                       |
| MAN 14 - Environmental management policy | An environmental policy and/or procedure is under development | An environmental policy and/or procedure is under development                                                                                                         | An environmental policy and/or procedure is in place and has been endorsed by the board of directors/senior management                                                                            | An environmental policy and/or procedure is in place and has been endorsed by the board of directors/senior management                                                                            | An environmental policy and/or procedure is in place and has been endorsed by the board of directors/senior management                                                                            |
| MAN 15 Environmental management issues   | None                                                          | Energy consumption, energy efficiency and supply including targets for reduction of energy consumption contained within an energy plan Waste reduction and management | Energy consumption, energy efficiency and supply including targets for reduction of energy consumption contained within an energy plan Waste reduction and management Pollution reduction/control | Energy consumption, energy efficiency and supply including targets for reduction of energy consumption contained within an energy plan Waste reduction and management Pollution reduction/control | Energy consumption, energy efficiency and supply including targets for reduction of energy consumption contained within an energy plan Waste reduction and management Pollution reduction/control |
| MAN 19 - Sustainability report           | None                                                          | Yes. Internal report which is not independently verified                                                                                                              | Yes. Report is independently verified by a third-party assurance/verification body and is accessible to all internal and external stakeholders                                                    | Yes. Report is independently verified by a third-party assurance/verification body and is accessible to all internal and external stakeholders                                                    | Yes. Report is independently verified by a third-party assurance/verification body and is accessible to all internal and external stakeholders                                                    |
| HEA 25 - Occupier satisfaction           | None                                                          | Skills and capabilities of staff                                                                                                                                      | Skills and capabilities of staff Workplace comfort                                                                                                                                                | Skills and capabilities of staff Workplace comfort Continual professional development                                                                                                             | Skills and capabilities of staff Workplace comfort Continual professional development                                                                                                             |
| ENE 68 - Energy management arrangements  | None                                                          | Energy consumption is actively recorded and monitored                                                                                                                 | Energy consumption is actively recorded and monitored                                                                                                                                             | Energy consumption is actively recorded and monitored                                                                                                                                             | Energy consumption is actively recorded and monitored                                                                                                                                             |

<!-- image -->

SD221 USA © BRE Global Ltd 2019

|                                            | Minimum standards by BREEAM In-Use rating   | Minimum standards by BREEAM In-Use rating                    | Minimum standards by BREEAM In-Use rating                                                                                     | Minimum standards by BREEAM In-Use rating                                                                                                                   | Minimum standards by BREEAM In-Use rating                                                                                                                                                                 |
|--------------------------------------------|---------------------------------------------|--------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| BREEAM issue                               | Pass                                        | Good                                                         | Very Good                                                                                                                     | Excellent                                                                                                                                                   | Outstanding                                                                                                                                                                                               |
| TRA 05 Transport requirements              | None                                        | None                                                         | None                                                                                                                          | Staff commuting                                                                                                                                             | Staff commuting                                                                                                                                                                                           |
| WAT 19 - Water management arrangements     | Water consumption is recorded               | Water consumption is recorded Water consumption is monitored | Water consumption is recorded Water consumption is monitored                                                                  | Water consumption is recorded Water consumption is monitored                                                                                                | Water consumption is recorded Water consumption is monitored                                                                                                                                              |
| MAT 15 - Material procurement issues       | None                                        | None                                                         | None                                                                                                                          | None                                                                                                                                                        | Responsible sourcing has been conducted in accordance with a procedure/guideline/standard that has international scope. Further information regarding responsible sourcing can be found on www.breeam.com |
| POL 15 - Pollution management              | None                                        | None                                                         | Use of effective incident response guidance/procedures in accordance to local, national, or international guidance/procedures | Use of effective incident response guidance/procedures in accordance to local, national, or international guidance/procedures                               | Use of effective incident response guidance/procedures in accordance to local, national, or international guidance/procedures                                                                             |
| POL 16 - Pollution prevention arrangements | None                                        | None                                                         | Pollution risks, levels and incidents are recorded                                                                            | Pollution risks, levels and incidents are recorded Regular inspection and maintenance of machinery / equipment operational in the organization's day-to-day | Pollution risks, levels and incidents are recorded Regular inspection and maintenance of machinery / equipment operational in the organization's day-to-day                                               |

<!-- image -->

Version 2.0: 2016, April 2019

## Calculating an asset's BREEAM USA In-Use rating

A BREEAM USA In-Use Assessor must determine the BREEAM USA In-Use rating using the relevant reporting tool/software  and  in  compliance  with  the  requirements  as  set  out  in  this  technical  manual.  The  process  of determining a BREEAM USA In-Use rating for Part 1, Part 2 and Part 3 is outlined below and an example calculation for a Part 2 assessment included in

## Table 7.

- For each of BREEAM In-Use's environmental categories the number of 'credits' awarded is determined by the BREEAM USA In-Use Assessor in accordance with the criteria of each assessment issue (as detailed in the technical sections of this document).
- The percentage of 'credits' achieved is then calculated for each section.
- The percentage of 'credits' achieved in each section is then multiplied by the corresponding section weighting. This gives the overall environmental category score.
- The section scores are then added together to give the overall BREEAM USA In-Use score for the Part against which the asset has been assessed.
- The overall  score  is  then  compared  to  the  BREEAM  In-Use  rating  benchmark  levels  in  order  to  view  the relevant BREEAM rating that has been achieved.
- For  a  Part  3  rating  the  total  credits  for  each  section  included  in  both  Part  2  and  Part  3  assessments  are combined. These scores are then weighted using Part 3 weightings to give a final 3 score. In addition, for a Part 3 rating, all minimum standards applicable to the rating level must have been met before BREEAM USA In-Use rating is achieved.

Table 7: Example BREEAM USA In-Use Part 2 calculation

| BREEAM Section            | Credits Achieved          | Credits Available         | %of Credits Achieved      | Section Weighting         | Section Score             |
|---------------------------|---------------------------|---------------------------|---------------------------|---------------------------|---------------------------|
| Management                | 39                        | 46                        | 85%                       | 0.15                      | 12.75%                    |
| Health and Wellbeing      | 20                        | 37                        | 54%                       | 0.15                      | 8.1%                      |
| Energy                    | 40                        | 60                        | 67%                       | 0.315                     | 21.11%                    |
| Transport                 | -                         | -                         | -                         | -                         | -                         |
| Water                     | 14                        | 26                        | 54%                       | 0.055                     | 2.97%                     |
| Materials                 | 16                        | 20                        | 80%                       | 0.075                     | 6%                        |
| Waste                     | -                         | -                         | -                         | -                         | -                         |
| Land Use and Ecology      | 6                         | 10                        | 60%                       | 0.125                     | 7.5%                      |
| Pollution                 | 14                        | 24                        | 58%                       | 0.13                      | 7.54%                     |
| Final BREEAM score 65.97% | Final BREEAM score 65.97% | Final BREEAM score 65.97% | Final BREEAM score 65.97% | Final BREEAM score 65.97% | Final BREEAM score 65.97% |
| BREEAM Rating             | BREEAM Rating             | BREEAM Rating             | BREEAM Rating             | BREEAM Rating             | VERY GOOD                 |

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Evidence requirements for BREEAM In-Use

This section provides guidance to Assessors and project teams on the types of evidence required to demonstrate compliance with the BREEAM In-Use assessment criteria.

## Why does BREEAM require evidence?

BREEAM  is  an  assessment  and  certification  program  operated  in  accordance  with  international  standards. Operating to international standards ensures that certification programs such as BREEAM are run in a consistent and  reliable  manner.  The  BREEAM  Assessor's  assessment  report  and  the  Quality  Assurance  process  are fundamental to BREEAM, ensuring consistency of, and confidence in, the BREEAM rating awarded by the Assessor.

To maintain this consistency and credibility, all certification decisions are evidence-based, that is these must be based on verified and credible information that is traceable, relevant to and linked to the asset being assessed. This is not only important for ensuring compliance with the international standards to which BREEAM operates, but also in terms of managing risk to clients and BREEAM Assessors in the event that a certification outcome is challenged.

## The BREEAM USA In-Use Assessor role

It is the BREEAM USA In-Use Assessor who determines the BREEAM USA In-Use rating. The assessment report and collated evidence are the formal records of an Assessor's audit against the criteria defined in the Technical Manual for BREEAM USA In-Use. The BREEAM USA In-Use certificate issued by BRE Global Limited provides assurance that the  process  of  producing  the  assessment  report  carried  out  by  the  BREEAM  USA  In-Use  Assessor  has  been conducted in accordance with the requirements of the program. The purpose of the certificate is therefore to give confidence to the client in the Assessor's performance and processes in determining a BREEAM In-Use rating.

It is the role of the BREEAM USA In-Use Assessor to gather project information and use it to assess performance against the BREEAM USA In-Use program in a competent and impartial manner. To award a BREEAM USA In-Use credit,  the  Assessor  must  be  satisfied  beyond  reasonable  doubt  that  the  evidence  gathered  demonstrates unambiguous compliance with all relevant criteria defined in the BREEAM USA In-Use program. All evidence must be appropriately referenced and made available on request from BRE Global Limited for quality assurance checks.

Clear, ordered and well referenced evidence for each BREEAM USA In-Use issue and criterion facilitates efficient quality assurance and certification. The naming of the files that are submitted as evidence should at least include:

-  BREEAM Asset Registration number
-  Credit reference
-  Description of file

## For example:

-  Naming of file: BIUS00002 \_MAN08\_EnvironPolicy(pdf)
-  Copy in digital format: BIUS0003/HEA01/ExteriorPhoto1(jpg)

<!-- image -->

Version 2.0: 2016, April 2019

If large documents are used as evidence, the Assessor should highlight and reference the page or section of the document that demonstrates compliance.

If photos are used as evidence, these must clearly show how compliance with a criterion is sought and, where needed, be annotated and the photos must be date stamped.

Poor referencing of evidence could delay certification.

## Evidence types

Evidence does not necessarily need to be prepared specifically for the purpose of the BREEAM In-Use assessment. In many instances, the BREEAM In-Use Assessor should be able to source readily available and prepared building information for the purpose of demonstrating compliance. For this reason, BREEAM In-Use aims to avoid being overly prescriptive on the type of evidence required, although some issues do require specific documents to be provided.

The BREEAM In-Use Assessor and client will find that many assessment issues require more than one piece or type of information to demonstrate compliance with one criterion, or alternatively, one piece of information may be sufficient to demonstrate compliance with multiple criteria.

To assist clients and the BREEAM In-Use Assessor in their collation of information for each assessment Part, the different types of documentation that can be used as evidence of compliance are listed below.

These evidence types fall broadly into two categories:

- General evidence includes a broad list of defined information commonly produced for an asset. One or a mix of these types of information can be used to demonstrate compliance for one or more of the BREEAM In-Use issues and criteria, as deemed appropriate by the BREEAM In-Use Assessor for the assessment Part.
- General BREEAM In-Use evidence types are listed in Table 8 and are not necessarily specifically listed in the 'Evidence' section found within each BREEAM In-Use issue. Not all general evidence types will be appropriate for all issues and it is the responsibility of the BREEAM In-Use Assessor to ensure that the evidence provided specifically demonstrates compliance and is fully referenced.
- Specific evidence is defined information that must be provided to verify compliance with the relevant criteria for the BREEAM In-Use credit sought. In all cases it will be the only type of evidence that will be accepted by BRE  Global  Limited  for  that  particular  issue/criterion.  Where  specific  evidence  is  not  provided  and appropriately  referenced  in  the  assessment  report,  the  Quality  Assurance  checks  will  identify  a  nonconformances and certification will be delayed.
- When required, specific evidence is defined and listed for each BREEAM In-Use issue in the 'Evidence' section. Although the 'Evidence' section lists the specific evidence required to demonstrate compliance with particular criteria, simply submitting this evidence may not be sufficient to demonstrate full compliance. Additional 'general  evidence  types'  may  also  be  required.  Not  all  BREEAM  In-Use  issues  will  have  specific  evidence requirements.

Other types of evidence can still be used to demonstrate compliance where an information type provided by a client is not listed in Table 9 or the 'Evidence' section for each issue. To avoid non-conformities and delays in

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

certification, undefined alternative types of evidence must demonstrate credible, robust and traceable assurance to the same level as or better than, specified or general evidence types. If in doubt, please contact BRE Global Limited prior to accepting such evidence.

For some assessment issues, the BREEAM In-Use Assessor is likely to require a mixture of general and specific evidence types.

## Evidence principles for BREEAM Assessors and BRE Global Limited Quality Assurance

As described above, where specific evidence is stated in the 'evidence' table within each assessment issue, this must be sourced and verified by the BREEAM In-Use Assessor.

Where no specific evidence has been listed for an issue or specific criterion, this means that there are potentially a number of different types of 'general' project information, as per Table 9 that can be sourced by the BREEAM In-Use Assessor and used to demonstrate compliance. It is the BREEAM In-Use Assessor's responsibility to source and verify the 'general evidence types' for each relevant criterion, where the client is claiming compliance and credits.

In determining the appropriateness of 'general evidence types' for each issue, the principles outlined in Table 8 must be considered by BREEAM Assessors. Where the 'general evidence types' meet the principles outlined in Table 8 and, where appropriate, the guidance provided in the 'robustness of evidence' section, such evidence is admissible for the purpose of the assessment and the BRE Global Ltd Quality Assurance checks.

These  principles  are  not  listed  in  a  hierarchical  order  and  are  all  equally  important  when  considering  which evidence type to submit to demonstrate compliance for each issue/criterion.

<!-- image -->

## Table 8: BREEAM Evidence principles

|    | Summary                                                   | Principle                                                                                                                                                                                                                                                                                                                 | Objective                                                   | A question to ask to check                                                                                                                                                                          |
|----|-----------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|  1 | Evidence provided for all criteria for all credits sought | Evidence must demonstrate that ALL relevant* criteria and sub-criteria for each credit sought are achieved and where relevant, is provided to support compliance notes, definitions etc.                                                                                                                                  | Completeness                                                | Are all criteria and sub-criteria covered? Have all relevant definitions been addressed?                                                                                                            |
|  2 | Unambiguous assessment                                    | The assessment must demonstrate unambiguous compliance and the evidence must support this assessment. Evidence (and supporting notes) must clearly demonstrate to a 3rd party reviewer that the criteria have been met.                                                                                                   | Independent review compatibility.                           | If a 3 rd party (e.g. BRE Global Limited) reviewed my report with the submitted evidence, would they be able to confirm compliance and award the same credits I have?                               |
|  3 | Robust                                                    | a. When selecting the Evidence type, always ensure it is robust and is relevant to the stage of assessment. The selected Evidence contains all the relevant basic information, with the necessary constituent parts to be deemed robust. b. (see Robustness of evidence section for further details on both of the above) | Proof that evidence is robust and from a reliable source    | Is this the most robust form of evidence available to demonstrate compliance with this criterion? Does the evidence contain all the relevant basic information? Is it fully auditable?              |
|  4 | Use existing evidence                                     | Use existing project information to demonstrate compliance. In most cases evidence shouldn't need to be 'created' for BREEAM compliance purposes.                                                                                                                                                                         | Minimizes evidence and reduces time and cost of compliance. | Does robust evidence meeting the above principles already exist that I can use? If I need to ask for more evidence, is the project seeking credits where compliance is not adequately demonstrated? |

- *Where the Assessor deems specific criteria 'not relevant' to the assessment, a full justification should be collated and then submitted as a technical query, for review by BRE Global Limited.

<!-- image -->

SD221 USA © BRE Global Ltd 2019

Version 2.0: 2016, April 2019

## Robustness of Evidence

Robust evidence provides confirmation that the assessment has been carried out correctly and the asset complies with the criteria for the BREEAM In-Use credits sought. The BREEAM In-Use Assessor should consider the following when gathering project information and evaluating whether the evidence provided is as 'robust' as possible:

-  Is there more than one piece of evidence that could be used to demonstrate compliance?
-  Is the chosen evidence the most robust and appropriate piece of evidence to demonstrate that a particular criterion has been achieved?

Any evidence submitted for a BREEAM USA In-Use assessment must be robust in terms of its source and its traceability. Below is a list of the minimum information the Assessor must expect to see, when certain types of evidence are submitted:

-  Communication records : Any communication records used as evidence must provide clear confirmation of the site name, author's identity and role, the date and recipient(s) identity.
-  Formal letters of correspondence : Must be on company/organization headed note-paper with a signature (electronic signatures are acceptable). Ideally letters should be a secured document.
-  Meeting minutes: Must include date, location and attendee information (names, organizations and roles), along with a record of the meeting and agreed actions.
-  Drawings/site plans/maps/installation diagrams : All of these documents must have the asset/site name, title of drawing, date, revision number and a scale.
-  Specification/building manual : A specification/building manual must be clear that it relates to the project under assessment, and it must have a date and revision number. Where sections of a specification are provided, the Assessor should reference the extract and as a minimum submit the front page of the specification detailing the project name, revision number, and date. Specifications must always refer to as built or operational conditions.

In addition to the list of minimum information, BREEAM strongly advises that Assessors have a formal, written site visit report which could act as standalone evidence. The report must contain the registration number,  asset/site  name,  date,  author  and  summary  text  to  detail  what  was  witnessed,  confirming compliance. Assessors are encouraged to gather their own photographic evidence which can be used to support the text in the report, full details of what has been witnessed on site and which credits/criteria the particular comments relate to. Photographic evidence from other parties, e.g. Facilities Managers, are acceptable, but it is still the Assessor's responsibility to verify their accuracy. Photographs would not be required for each individual product, e.g. lamp fitting or faucet, a representative sample is sufficient.

For other types of evidence not listed, the Assessor should use Table 9 as a guide. As a minimum, the evidence used to assess compliance should always contain key information as the registration number, the project name, the author, date, revision numbers etc.

<!-- image -->

<!-- image -->

## Table 9: Evidence types

| Ref   | Document/evidence type                                      | Description/note                                                                                                                                                                                                                                                                                                                                                        |
|-------|-------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| E1    | Billing data                                                | Evidence in the form of billing that supports the requirements that are outlined in the criteria. Billing data must be from the organization providing the billed services to the asset.                                                                                                                                                                                |
| E2    | BRE Global Limited correspondence reference number          | For example, the reference number for a BRE Global Limited response to an Assessors technical query.                                                                                                                                                                                                                                                                    |
| E3    | BREEAM Assessor's site visit report                         | A formal report based on the BREEAM In-Use Assessor's own survey of the asset to confirm compliance with BREEAM In-Use criteria. An Assessor's site visit report will be distinct from their formal BREEAM In-Use assessment, serving as a form of evidence of compliance in its own right, and it may include photographs taken by the Assessor as part of the survey. |
| E4    | Building (Energy) Management Systems (B(E)MS)/Metering data | Evidence on consumption of metered utilities, such as gas, electricity and water. This data can either be from individual sub-meters or collected through B(E)MS that is installed in the asset.                                                                                                                                                                        |
| E5    | Building Information Model (BIM)                            | The BIM (or BIM files) used for the project containing relevant information/evidence of compliance.                                                                                                                                                                                                                                                                     |
| E6    | Calculations                                                | Evidence provided in a calculation format that supports that set targets/thresholds are met within the asset.                                                                                                                                                                                                                                                           |
| E7    | Certificates of compliance (third party)                    | Examples include ISO 14001, FSC (Forest Stewardship Council), EPC (environmental profile certificate), EPD (environmental product declaration) etc.                                                                                                                                                                                                                     |
| E8    | Communication records                                       | Formal communication records between/from relevant stakeholders and/or other third parties confirming an appointment, action or outcome. This maybeinthe form of a letter, meeting minutes, email correspondence, publication or another form of media.                                                                                                                 |
| E9    | Contractual information                                     | Documents/contracts outlining how certain maintenance/monitoring/testing or other service is carried out by a (third) party.                                                                                                                                                                                                                                            |

<!-- image -->

| Ref   | Document/evidence type         | Description/note                                                                                                                                                                                                                                                                                                                                                                                                                                                                |
|-------|--------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| E10   | Other third-party information  | For example, maps, public transport timetables, product data/details, manufacturers' literature, local standards or codes, product labeling.                                                                                                                                                                                                                                                                                                                                    |
| E11   | Photographic evidence          | Evidence provided in photographic/photocopy format (either hardcopy or digitally) that supports that building services/elements or other relevant infrastructure or product is in place/installed at the asset.                                                                                                                                                                                                                                                                 |
| E12   | Professional services contract | An agreement to provide professional or consulting services such as: maintenance, testing, or legal or technical advice.                                                                                                                                                                                                                                                                                                                                                        |
| E13   | Risk assessment                | The risk assessment considers the various operational risks and other risks on a project and how each risk will be managed and the party responsible for managing each risk.                                                                                                                                                                                                                                                                                                    |
| E14   | Specialist reports             | Professional reports resulting from specialist surveys/studies/test results including (but not limited to):  Environmental Management Systems/Plans  flood risk assessment  acoustics  indoor air quality  transportation analysis  commissioning and maintenance reports and strategies  landscape and habitat management plan  Legionella management plan, etc. These surveys/studies/test results are often carried out by suitably qualified persons/organizations. |
| E15   | Staff interviews               | Interviews with staff members that support that specified (management) are being carried out in the asset. Staff interviews are an important part of the verification that formal processes/procedures/documents are made available to staff/building users.                                                                                                                                                                                                                    |

<!-- image -->

## Issue and credit structure

A BREEAM In-Use assessment is conducted by answering asset, operational and/or occupier specific questions within the Part for which the assessment is undertaken. Each Part has been divided into the relevant categories that are applicable to it containing issues that relate to the specific requirements.

Each BREEAM issue is structured as follows:

- Issue information : This is in the title of the issue and contains the assessment issue reference, name, number of credits available and whether the issue forms part of BREEAM In-Use's minimum standards.
- Question : This contains the question(s) that is asked to assess the BREEAM In-Use assessment issue.
- Aim : This outlines the broad objective of the issue and the impact it measures/mitigates.
- Available credits : This outlines the answer options to the question and the credits that are available for each of the answer options.
- Assessment criteria :  This  section  outlines  the  requirements  that  must  be  met  in  order  for  credits  to  be awarded. The information outlined in this section can include tables of benchmarks or asset type specific performance criteria.
- Evidence : This section describes the type(s) of information that must be provided by the client and given to the BREEAM In-Use Assessor to enable verification of the asset's performance against the assessment criteria as required for certification. The evidence justifies the awarding of the relevant number of BREEAM In-Use credits. The BREEAM In-Use evidence requirements section provides further guidance on general evidence requirements but wherever possible, evidence should not be produced specifically for the purposes of the BREEAM assessment.
- Additional  information :  This  section  contains  any  further  information  relevant  to  the  application  of  the assessment criteria, including any definition of terms used in the assessment issue or sources of additional information that may be of use in addressing the issue.

## Using the technical manual to complete an assessment

Assessments are carried out using the BREEAM In-Use online tool that contains all questions relating to the Parts and categories. These questions are the same as those listed in the technical manual under Question (2). This document  is  intended  to  assist  clients  and  Assessors  in  understanding  and  interpreting  the  questions,  their background and how they affect the assessment results.

The client and/or Assessor will answer the questions with the answer option that reflects the current situation within the asset that is being assessed. The answer options and the available credits are listed in the technical manual under Available credits (4). In order to assist the client and Assessor to select the appropriate answer options, the aim of the credit, listed under Aim (3), and the Assessment criteria (5) can be used. These sections list the criteria that must be met in order to award a certain number of available credits.

The Evidence (6) section outlines what types of specific evidence relating to the question could be supplied in addition to the general evidence requirements as outlined under Evidence requirements for BREEAM USA InUse. Any additional information in which relevant definitions or other information is outlined can be found under

Additional information

(7).

<!-- image -->

The layout of the technical manual reflects the way in which information is entered within the BREEAM In-Use online tool. Each Part has its own specific section in which all the relevant information is outlined. In line with the BREEAM  In-Use  online  tool,  the  manual  outlines  what  building/asset  specific  related  information  must  be completed  prior  to  starting  the  BREEAM  In-Use  assessment.  These  can  be  found  under  the Building  Details section.

The following sections of this manual set out the specific questions and requirements as described above and is organized into the three Parts, each containing the issues and questions relating specifically to that Part. This is followed by an Annex setting out details for Part 3 assessments of Office buildings only.

<!-- image -->

<!-- image -->

## Building Details

## Asset

The following details are entered when an asset is created.

Note: Questions marked * are mandatory.

## Basic Asset Details

-  Asset Manager* - Select the Asset Manager. In the BREEAM In-Use online tool, the Asset Manager is a profile option for users who have been authorized by the Portfolio Owner to have read/write access to assigned Performance Measurements.
-  Name of Asset* - Enter the name of the asset.

The name of the asset entered here will appear above the assets address on any certificates produced for this asset. Certificate shows a maximum of 28 characters.

-  Asset Description - Enter a short description of the asset.

Asset Description cannot be more than 500 characters

-  Year Built* - Select the year in which the asset was constructed
-  In which year was the recent major refurbishment - Select the year of the most recent major refurbishment.

## Full Asset Address

-  Address Line1* - First line of address for the asset (if the asset only comprises of part of a building, additional details relating to the entire building should also be entered).
-  Address Line2 - Second line of address for the asset

Address line 1 and Address line 2 will be combined as a single line on the certificate and a maximum of 28 characters will be shown

-  Address Line3 - Third line of address for the asset
-  Address Line4 - Fourth line of address for the asset

Address line 3 and Address line 4 will be combined as a single line on the certificate and a maximum of 28 characters will be shown

-  Town/City* - Address Town or City
-  Country* - Select Country
-  State* - Select State
-  ZIP code* - Five-digit zip code

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Basic Building Details

Basic building details should be completed when an asset is registered to measure its performance. This section is divided into three: Ownership/Occupancy Details, Asset Dimensions, and Asset Type.

Note: Questions marked * are mandatory.

## Ownership/Occupancy Details

## Asset Ownership/Occupier

Asset Ownership/Occupier contains questions about the asset owner and its occupier(s). Filling out this data will assist in determining who carries the responsibility for carrying out or implementing the requirements as outlined in the criteria.

-  Name of the organization or person that owns the asset* - Enter the name of the person or organization that owns the asset.
-  Name of the organization that manages the tenancy of the asset* - Enter the name of the organization that manages the tenancy of the asset.
-  Name of the organization or person that occupies/leases the asset* - Enter the name of the organization or person  that  occupies/leases  the  asset.    If  there  are  multiple  tenants,  you  may  enter  'Multi-tenanted'  or another variant.
-  Name of the organization leading the BREEAM In-Use assessment* -  Enter the name of the organization leading the BREEAM In-Use assessment.

## Occupancy

Occupancy contains questions about the number of Full Time Occupiers and operating hours. Filling out this data will  assist  in  determining  whether  requirements  relating  to  services  or  fixtures  that  have  been  provided  to occupants have been met.

-  Number of occupants - Enter the number of Full Time Occupants.

To calculate the number of full-time occupiers:

Divide  the  total  hours  worked  by  contracted  building  occupants  during  the  reporting  period  by  the  total number of contracted building occupants.

Then divide the answer by the typical number of hours within the period, assuming that a typical working day is 8 hours and the typical number of working days in a full reporting year is 250.

-  Annual operational days - Enter the total number of days per year that the asset is operating.
-  Daily operational hours - Enter the total number of hours per day that the asset is operating.

<!-- image -->

<!-- image -->

## Asset Dimensions

## Asset Dimensions

-  Planning restrictions* - Select any planning restrictions that might be in place.
-  Width (external) (ft) - Enter the building width in ft. This is only the width of external façade.
-  Length (external) (ft) - Enter the building length in ft.  This is only the length of external façade.
-  Height (floor-to-floor height) (ft) - Enter the floor to floor height in ft.
-  Basic asset shape (aerial view of asset) - Select the shape that best represents the plan of your building (if the shape varies please choose the shape that represents the majority of the building).
-  Number of floors above ground - Enter the number of floors above ground in your building.
-  Number of floors below ground - Enter the number of floors below ground in your building.

The following questions relating to the floor area of the asset only refer to the area of the asset that will be assessed . Please refer to Eligibility criteria for further details.

-  Gross Internal Area (ft )* 2 - Enter the Gross Internal Area of the area of the asset to be assessed in ft . 2

The Gross Internal Area is the area of an asset measured to the internal face of the perimeter walls at each floor level.

Gross Leasable Area of an asset is the floor space contained within a tenancy at each floor level measured from the inside of main faces of external walls and, where applicable, the inside faces of internal inter-tenancy, partition and common area walls.

In a single occupier asset, the Gross Internal Area should equal the Gross Leasable Area. In a multi-tenanted asset, the Gross Internal Area is the sum of Gross Leasable Area and Non-Leasable Area.

Furthermore, for the purposes of BREEAM In-Use:

- a) If  an  assessment  is  only  carried  out  for  the  common  areas,  the  Gross  Internal  Area  equals  NonLeasable Area.
- b) If an assessment is carried out for a multi-tenanted asset's common areas AND tenanted areas that are managed by the asset's facility/building manager, the Gross Internal Area should equal the sum of Non-Leasable Area and Gross Leasable Area of the tenanted areas.

The Assessor must ensure that all consumption data that is filled out in the BREEAM In-Use online tool relates to the area filled in.

If the asset comprises multiple types, the Gross Internal Area must be equal to the sum of the floor area of all asset types.

-  Non-Leasable Area (ft ) 2 - Enter the building's Non-Leasable Are in ft . 2

<!-- image -->

<!-- image -->

Non-Leasable Areas or common areas are understood to be floor space area within a building from which no income can be derived. Examples include common use areas, elevator lobbies, stairwells, plant and technical rooms, management offices or rooms, non-exclusive public spaces and thoroughfares.

Within  BREEAM  In-Use,  it  has  been  agreed  that  parking  areas,  whether  enclosed,  multi-story  or  surface facilities, will be excluded from Non-Leasable Areas.

-  Gross Leasable Area (ft ) 2 - Enter the building's Gross Leasable Area in ft . 2

Within  BREEAM  In-Use,  it  has  been  agreed  that  parking  areas,  whether  enclosed,  multi-story  or  surface facilities, will be excluded from Gross Leasable Areas.

-  Area covered by hard landscaping (ft ) 2 - Enter the area covered by hard landscaping in ft . 2
-  Area covered by soft landscaping (ft ) 2 - Enter the area covered by soft landscaping in ft . 2

## Additional information

These fields can be used to enter any additional information related to the asset dimensions that could assist the client and/or Assessor in completing the assessment.

<!-- image -->

<!-- image -->

## Asset Type

Asset Type contains questions relating to the space type(s) within the asset.

Note: Questions marked * are mandatory, as the inputs are used to generate the energy scores. If the asset comprises multiple types, the Gross Internal Floor Area filled in under Asset Dimensions must be equal to the sum of all asset types.  The full list of Asset Types and Subtypes are available to the Assessors through the BREEAM Knowledge Base.

-  Asset Type 1* - Select the main asset type.
-  Asset Subtype 1* - Select the main asset subtype.
-  Gross Internal Area (ft )* 2 - Enter the main asset type Gross Internal Area.
-  Asset Type 2 - Select the second asset type.
-  Asset Subtype 2 - Select the second asset subtype.
-  Gross Internal Area (ft ) 2 - Enter the second asset type Gross Internal Area.
-  Asset Type 3 - Select the third asset type.
-  Asset Subtype 3 - Select the third asset subtype.
-  Gross Internal Area (ft ) 2 - Enter the third asset type Gross Internal Area.
-  Asset Type 4 - Select the fourth asset type.
-  Asset Subtype 4 - Select the fourth asset subtype.
-  Gross Internal Area (ft ) 2 - Enter the fourth asset type Gross Internal Area.
-  Asset Type 5 - Select the fifth asset type.
-  Asset Subtype 5 - Select the fifth asset subtype.
-  Gross Internal Area (ft ) 2 - Enter the fifth asset type Gross Internal Area.

<!-- image -->

<!-- image -->

## Part 1: Asset Performance

The performance of the asset's built form, construction, fixtures, fittings and installed services

| Issue reference         | Categories              | Credits available   |
|-------------------------|-------------------------|---------------------|
| MAN                     | Management              | -                   |
| HEA                     | Health &Wellbeing       | 33                  |
| ENE                     | Energy                  | 108                 |
| TRA                     | Transport               | 18                  |
| WAT                     | Water                   | 40                  |
| MAT                     | Materials               | 26                  |
| WST                     | Waste                   | 4                   |
| LE                      | Land Use & Ecology      | 6                   |
| POL                     | Pollution               | 22                  |
| Total credits available | Total credits available | 257                 |

<!-- image -->

<!-- image -->

## Management

The Management category is not assessed within Part 1 of the BREEAM USA In-Use assessment.

## Health and Wellbeing

## Category summary table

| Issue Reference         | Title                       |   Credits available |
|-------------------------|-----------------------------|---------------------|
| HEA 01                  | Glazing                     |                   2 |
| HEA 02                  | Glare control               |                   4 |
| HEA 03                  | Thermal control             |                   4 |
| HEA 04                  | Ventilation controls        |                   2 |
| HEA 05                  | Microbial contamination     |                   2 |
| HEA 06                  | Drinking water provisions   |                   2 |
| HEA 07                  | Indoor and/or outdoor space |                   4 |
| HEA 08                  | Illuminance levels (Lux)    |                   4 |
| HEA 09                  | Lighting control            |                   4 |
| HEA 10                  | Inclusive design            |                   3 |
| HEA 11                  | Ventilation requirements    |                   2 |
| Total credits available | Total credits available     |                  33 |

<!-- image -->

<!-- image -->

## Asset Performance HEA 01 - Glazing

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What percentage of the building envelope is glazed?

## Aim

To ensure building users have access to sufficient daylight, via windows and skylights.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | <1%                   |
|         1 | >1 to ≤10%            |
|         2 | >10%                  |

## Assessment criteria

- 1. Glazed areas include skylights that let daylight pass directly into the building.

## Evidence

- 1. Photographic evidence of all sides of building envelope.
- 2. Building elevations specifying height and width of building and all windows and skylights.
- 3. Calculation specifying the total glazed area as a percentage of the building envelope.

## Additional information

## Relevant definitions

Building  envelope :  the  physical  separator  between  the  interior  (often  conditioned)  of  the  building  and  the outdoor environment. It includes the walls, roof and foundation. For the purposes of this BREEAM USA In-Use issue, only the walls and roof portions of the building envelope need to be taken into account.

<!-- image -->

<!-- image -->

## Asset Performance HEA 02 - Glare control

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What glare control features have been fitted or installed in the building?

## Aim

To reduce problems associated with glare in internal occupied areas.

## Available Credits

|   Credits | Answer option                                                                                  |
|-----------|------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                          |
|         0 | Don't know                                                                                     |
|         1 | Glare control feature on all south facing windows, with control by the occupant                |
|         2 | Glare control feature on all south facing windows, with automatic control                      |
|         2 | Glare control feature on all: south, east and west facing windows with control by the occupant |
|         3 | Glare control feature on all: south, east and west facing windows with automatic control       |
|         3 | All windows have manually controlled solar shading                                             |
|         4 | All windows have automatically controlled solar shading                                        |
|         0 | Other                                                                                          |

## Assessment criteria

- 1. Glare control should be provided for relevant building areas where lighting and glare could be problematic for building users, e.g. workstations, projector screens and sports halls.
- 2. Curtains do not meet the criteria for the glare control requirement, as the control/design needs to allow a degree of flexibility to still allow sunlight in. The use of curtains to control glare would cause occupants to rely on artificial lighting to a greater extent.

## Evidence

- 1. Photographic evidence of glare control features.

## Additional information

## Relevant definitions

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Glare control features may include (but are not limited to):

- a. External sun control and shading device(s): sun-shading system for building solar control and protection from excessive solar light and heat.
- b. Low eaves.
- c. Bioclimatic design to provide shading from high-level summer and low-level winter sun.  Bioclimatic design refers to the design of buildings and spaces (interior, exterior, outdoor) based on local climate, aimed at providing thermal and visual comfort, making use of solar energy and other environmental sources.
- d. Internal blinds.
- e. Tinted/opaque windows.

<!-- image -->

<!-- image -->

## Asset Performance HEA 03 - Thermal control

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Do occupants of the asset have personal control over the temperature in their work area?

## Aim

To recognize the provision of asset temperature  controls that allow for independent  adjustment  of heating/cooling systems.

## Available Credits

|   Credits | Answer option                                                                 |
|-----------|-------------------------------------------------------------------------------|
|         0 | Question not answered                                                         |
|         0 | Don't know                                                                    |
|         0 | No                                                                            |
|         1 | Yes, can open windows                                                         |
|         2 | Yes, can adjust temperature (using thermostat or thermostatic radiator valve) |
|         2 | Yes, can adjust airspeed                                                      |
|         4 | Yes, can adjust more than one of the above                                    |
|         0 | Other                                                                         |

## Assessment criteria

- 1. Local occupant control is available for temperature adjustment in separate zones.
- 2. Zoning refers to adequate sections of the building. For example, zoning should consider the different requirements for the central core of a building compared with the external perimeter adjacent to the windows.

## Building specific Assessment Criteria

## Retail

- 1. Temperature  control  within  retail  centers  is  required  at  shop  unit  level.  Temperature  control  within common areas must still be adjustable at the building management level.

## Evidence

- 1. Photographic evidence of controls.
- 2. Building plans illustrating zoned areas.

<!-- image -->

<!-- image -->

- 3. Short description of the zoning strategy that has been provided by the facilities management or building management team.
- 4. Temperature control plans.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance HEA 04 - Ventilation controls

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is there provision for personal control of ventilation for building occupants by enabling them to open windows or modify rates of air supply?

## Aim

To recognize the provision of controls allowing ventilation comfort level optimization by building occupants.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Ideally  sufficient  provision  requires  ventilation  rates  (via  windows  or  mechanical  ventilation)  to  be adjustable within defined zones.
- 2. Zones should adequately reflect the sections of the building. For example, zoning should consider the different requirements for the central core of a building compared with the external perimeter adjacent to the windows.

## Evidence

- 1. For naturally ventilated areas:
- a. Photographic evidence of window location and opening mechanisms.
- 2. For mechanically ventilated areas:
- a. Formal organizational documentation, such as operation and maintenance manual confirming the scope of thermal zoning and the method of control.

## Additional information

Provision of electric desktop fans does not count as a means of ventilation.

<!-- image -->

<!-- image -->

## Asset Performance HEA 05 - Minimizing Legionella contamination risk

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Has a risk assessment been carried out to identify the most effective system to minimize the risk of Legionella contamination?

## Aim

To ensure the most effective and properly designed control systems are installed and to avoid risk of Legionellosis.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. The risk assessment that will determine the most effective system to minimize the risk of Legionellosis must be carried out by a suitable, qualified professional. The study would also indicate where Legionella control systems are not deemed necessary.
- 2. Any  water  system  that  is  at  risk  of  Legionella  contamination  should  have  the  appropriate  Legionella control systems installed. Water systems that are at risk of such contamination include (but are not limited to):
- a. Cooling towers
- b. Evaporative condenser
- c. Domestic hot and cold water systems
- d. Other plant and systems containing water which is likely to exceed 60°F (20°C) and which may release a spray or aerosol during operation or when being maintained. Examples include, but are not limited to:
- i. Humidifiers and air washers
- ii. Spa baths and pools
- iii. Car/bus washing points
- iv. Wet scrubbers
- v. Indoor fountains and water features

<!-- image -->

<!-- image -->

## Evidence

- 1. Copy  of  the  study  that  identifies  the  most  effective  method  to  avoid  the  risk  of  Legionellosis.  The conclusion of this risk assessment must outline what system should be installed. Where no such systems are deemed necessary, this must be outlined in the study.
- 2. Where Legionella control systems have been installed, a copy of the operational manual/manufacturer specification indicating the type of Legionella control should be provided.

## Additional information

## Relevant definitions

Legionellosis (Legionnaires' disease): A type of pneumonia caused by the bacterium Legionella pneumophilia. People catch Legionnaires' disease by inhaling small droplets of water suspended in the air, which contain the bacteria.

Suitably qualified professional: a person with sufficient knowledge, training and experience of the building water system design and water management as it relates to legionellosis to be able to describe the water systems, evaluate where hazardous conditions may occur, determine where control measures can and must be applied and maintained  to  stay  within  established  control  limits  and  establish  procedures  to  monitor  whether  control measures are operating within established limits and if not, take corrective action.

## Other information

Several methods to minimize the risk of Legionellosis currently exist. These include, but are not limited to:

- a) Risk management through a thermal process (temperature control)
- b) Risk management through a chemical process (e.g. chlorination, ozone, copper and silver ionization)
- c) Risk management through a non-chemical process (e.g. U.V. irradiation, ultrasound)

<!-- image -->

<!-- image -->

## Asset Performance HEA 06 - Drinking water provisions

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is drinking water provided for occupants?

## Aim

To ensure the provision of fresh drinking water for building occupants.

## Available Credits

|   Credits | Answer option                                     |
|-----------|---------------------------------------------------|
|         0 | Question not answered                             |
|         0 | Don't know                                        |
|         0 | No                                                |
|         1 | Yes, point of use not connected to utility supply |
|         2 | Yes, point of use connected to utility supply     |

## Assessment criteria

- 1. Drinking water access points need to be:
- a. Appropriate in number and placement to serve all building users; as determined by the Assessor's best judgment.
- b. In a hygienic location and condition.
- c. Freely available and accessible.

Note : faucets in kitchen areas are compliant.

- 2. The following types of water dispensers do not comply with the criteria of this issue:
- a. Faucets in restroom areas.
- 3. The provision of drinking water applies to building occupants that are members of staff. This means that visitors to the asset are not included.

## Building specific Assessment Criteria

## Retail

- 1. For a retail center, adequate provision of drinking water should be provided for (but not limited to):
- a. all tenants and their members of staff
- b. building management personnel

<!-- image -->

<!-- image -->

- c. security staff
- d. cleaners
- e. (where applicable) all office workers (or other members of staff related to the space use) in the building

## Evidence

- 1. Photograph of water access points.
- 2. Building plans with access points identified.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance HEA 07 - Indoor and/or outdoor space

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are indoor rest and/or outdoor spaces provided for building occupants?

## Aim

To recognize the provision of space that is to be used for breaks from the working environment.

## Available Credits

|   Credits | Answer option                                                                                                                                               |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                       |
|         0 | Don't know                                                                                                                                                  |
|         0 | No                                                                                                                                                          |
|         2 | Lounge/Dining areas                                                                                                                                         |
|         2 | Dedicated outdoor space with seating sheltered from wind and/or rain (located at least 33 feet away from roads, parking lots or other sources of pollution) |
|         2 | Break rooms/areas with seating                                                                                                                              |
|         2 | Cafeteria facilities                                                                                                                                        |
|         4 | Combination of 2 or more of the above                                                                                                                       |
|         0 | Other                                                                                                                                                       |

## Assessment criteria

- 1. Resting space should:
- a. Be of an adequate size. Adequate size is based on providing seating space for over 10% of building occupiers.
- b. Be accessible via safe pedestrian routes.
- c. Provide building users with an area that is private and not susceptible to disturbance from sources of noise such as building services, parking lots, delivery areas etc.
- 2. Resting space does not necessarily have to be provided within the asset, however: building users must have free and unrestricted access during working hours.

<!-- image -->

<!-- image -->

## Building specific Assessment Criteria

## Retail

- 1. Shopping centers should base their occupancy figures on average customer foot traffic.
- 2. Common rest areas may include (but are not limited to):
- a. Benches placed within the asset
- b. Food outlets with seating provision within the asset
- 3. Indoor and/or outdoor spaces refer to common areas shared with customers/visitors)
- 4. Food courts and restaurants count towards seating space provision.

## Evidence

- 1. Photographic evidence, demonstrating provisions available to building users.
- 2. Building plans illustrating seating areas within asset.

## Additional information

## Relevant definitions

Lounge/dining areas : areas that are accessible to all building users, where they can have a break from the working environment. These areas contain comfortable seating and tables and are designed for longer breaks. Hot food and drinks could be provided for users.

Break rooms/areas : areas that are accessible to all staff. These areas are designed for short breaks. Hot drinks, such as tea and coffee, are available. Provisions to prepare food could be provided for users.

Cafeteria facilities: areas that are accessible to all staff. These areas are designed for longer breaks and contain comfortable seating and table. Hot food and drinks or provisions to prepare these are provided for staff. Other building users, such as visitors to the asset, could have access to these areas.

<!-- image -->

<!-- image -->

## Asset Performance HEA 08 - Illuminance levels (Lux)

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Do internal and external lighting levels meet national guidance best practice levels?

## Aim

To ensure optimum visual comfort for building occupants.

## Available Credits

|   Credits | Answer option                                                       |
|-----------|---------------------------------------------------------------------|
|         0 | Question not answered                                               |
|         0 | Don't know                                                          |
|         0 | No                                                                  |
|         4 | Yes, illuminance levels meet national guidance best practice levels |

## Assessment criteria

- 1. Lighting  levels  should  be  measured  in  relevant  building  areas  by  a  suitably  qualified  person  or organization.
- 2. A suitably qualified person or organization is a person/organization that has experience in undertaking lighting measurements. They must use the appropriately tested and calibrated equipment (lux meter) to undertake the lighting assessment.
- 3. Credits may not be awarded if light fittings need to be removed or lights covered.
- 4. National  best  practice  lighting  guides:  The  Lighting  Handbook,  10 th edition.    Illuminating  Engineering Society of North America (2011).

## Evidence

- 2. Third  party  documentation or organizational documentation confirming the lighting levels in relevant building areas.

## Additional information

## Relevant definitions

Relevant building area : occupied space is a room or space within the assessed building that is likely to be occupied for 30 minutes or more by a building user. The following internal areas are excluded from the requirements:

- 1. Media and arts production spaces.
- 2. Sports facilities (exercise spaces only, including hydrotherapy and physical therapy areas).

<!-- image -->

<!-- image -->

## Asset Performance HEA 09 - Lighting control

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

To what extent do occupants have control over the lighting in their work area?

## Aim

To optimize the level of occupant control over lighting in relevant building areas.

## Available Credits

|   Credits | Answer option                                                                                             |
|-----------|-----------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                     |
|         0 | Don't know                                                                                                |
|         0 | None                                                                                                      |
|         2 | Automatic lighting controls per zone with manual override                                                 |
|         4 | Automatic lighting controls per zone with manual override with provision of task lighting where requested |
|         0 | Other                                                                                                     |

## Assessment criteria

- 1. Common control systems that would satisfy this credit include:
- a. Daylight sensors that switch lights off when daylight levels are high with manual over-ride facilities for building occupants
- b. Infra-red  or  movement  detectors  that  switch  lighting  on/off  in  zones  with  manual  over-ride facilities for building occupants
- 2. Zoning refers to adequate sections of the building. For example, zoning should consider the different requirements for the central core of a building compared with the external perimeter adjacent to the windows. Zoning of lighting controls is to be as follows:
- a. In office areas, zones of no more than four workplaces
- b. Workstations adjacent to windows/atria and other building areas separately zoned and controlled
- c. Seminar and lecture rooms: zoned for presentation and audience areas
- d. Library spaces: separate zoning of stacks, reading and counter areas
- e. Teaching space/demonstration area
- f. Whiteboard/display screen

<!-- image -->

<!-- image -->

- g. Auditoria: zoning of seating areas, circulation space and lectern area
- h. Dining, restaurant, café areas: separate zoning of serving areas and seating/dining areas
- i. Retail: separate zoning of display and counter areas
- j. Bar areas: separate zoning of bar and seating areas
- 3. The following internal areas are excluded from the lighting zone requirements:
- a. Media and arts production spaces.
- b. Sports facilities (exercise spaces only, including hydrotherapy and physical therapy areas).

## Evidence

- 1. Where automatic/management systems have been installed, this should include how building occupants can over-ride it. This could include (but is not limited to):
- a. installation diagrams
- b. copy of building user guide outlining lighting controls
- c. Photographic evidence of lighting controls
- 2. Manufacturer information.

## Additional information

## Relevant definitions

Relevant building area: occupied space which is a room or space within the assessed building that is likely to be occupied for 30 minutes or more by a building user.

## Other information

There are many types of lighting control systems, but the main focus of this credit is the level of control that occupants have over the lighting of the space or room. As this credit is aimed at health and well-being and not energy consumption, it is important that the occupant has the ability to manually override the lighting controls per zone to suit his/her needs.

<!-- image -->

<!-- image -->

## Asset Performance HEA 10 - Inclusive design

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             3 | No                  |

## Question

Does the asset contain features, beyond those specified by applicable regulations and codes, which enable full use by individuals with disabilities?

## Aim

To recognize and encourage assets that are functional and inclusive for all its users.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         3 | Yes                   |
|         0 | Other                 |

## Assessment criteria

- 1. Features contained in the asset that enable full use by people with temporary or permanent disabilities must be in addition to local codes or requirements for accessibility. Features that have been provided for should include (but are not limited to) the following as guidance:
- a. The approach to all entrances should be level or gently sloping, with access for wheelchair users
- b. Entrances should be illuminated
- c. There should be space for turning a wheelchair in hallways and work areas, and adequate circulation space for wheelchairs elsewhere
- d. Designated restrooms should be easily accessible, correctly signposted and provision based on the number of and location of users
- e. Hand rails should be provided for ease of maneuverability
- f. Where applicable, elevators should be provided to allow individuals with disabilities access to all levels
- g. Evacuation  procedures  should  take  into  account  needs  of  people  with  disabilities.  For  example: providing  evacuation  chairs,  specific  features  for  individuals  who  are  blind/have  low  vision  and individuals who are deaf or hard of hearing.

## Evidence

<!-- image -->

<!-- image -->

- 1. Photographic evidence of listed features
- 2. Building plans outlining installed features
- 3. Specifications of installed features

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance HEA 11 - Ventilation requirements

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Does the asset meet the requirements for either natural ventilation or mechanical ventilation as outlined in the Assessment criteria?

## Aim

To ensure that ventilation systems within the asset do not circulate air that has the potential to be contaminated with exterior sources of pollution AND that re-circulation within the asset is minimized.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

## For natural ventilation

Operable windows/ventilators within the building are located at least 33 feet from roads, parking lots and other potential sources of pollution, and all exhausts are at least 33 feet from any opening to minimize re-circulation within the building.

## For mechanical and mixed-mode ventilation

Air intakes and exhausts are over 33 feet apart to minimize recirculation and intakes are over 66 feet from sources of external pollution. These include, but are not limited to:

- 1. Highways and the main access roads.
- 2. Parking lots and delivery/vehicle waiting bays.
- 3. Other  building  exhausts,  including  from  building  services  plant,  industrial/agricultural  processes  and smoking rooms/areas.

## Evidence

- 1. In the case of natural ventilation:
- a. Photographic evidence or a copy of site plan which clearly indicates that the building location complies with the conditions specified, such as scaled drawings or on-site measurements.

<!-- image -->

<!-- image -->

- 2. In the case of mechanical ventilation:
- a. Photographic evidence or a copy of site plan which identifies the location of intake points and clearly indicates that they comply with the conditions specified, such as scaled drawings or onsite measurements.

## Additional information

## Other information

The distance requirement for air intakes and exhausts does not necessarily mean the plan distance, but the threedimensional distance around and over objects; e.g. on plan the air intakes may be less than 66 feet from a source of external pollution, but the intake may be on the roof of a 10-story building and therefore over 66 feet from the source of pollution.

<!-- image -->

<!-- image -->

## Energy

## Category summary table

| Issue Reference   | Title                                                       | Credits available                                                  |
|-------------------|-------------------------------------------------------------|--------------------------------------------------------------------|
| ENE 01            | Heating, ventilation and air conditioning (HVAC)            | Up to 100 credits are available. Credits are calculated within the |
| ENE 02            | Ventilation strategy                                        |                                                                    |
| ENE 03            | Heat loss                                                   |                                                                    |
| ENE 04            | Building pressure/air leakage test                          |                                                                    |
| ENE 05            | Heating                                                     |                                                                    |
| ENE 06            | Boiler efficiency                                           |                                                                    |
| ENE 07            | Heat pump efficiency                                        |                                                                    |
| ENE 08            | Fuel usage for heat generation                              |                                                                    |
| ENE 09            | Heat distribution                                           |                                                                    |
| ENE 10            | Heat emitter type                                           |                                                                    |
| ENE 11            | Mechanical and electrical heating equipment                 |                                                                    |
| ENE 12            | Cooling system                                              |                                                                    |
| ENE 13            | Efficiency of cooling system                                |                                                                    |
| ENE 14            | Cooling distribution                                        |                                                                    |
| ENE 15            | Heating, ventilation and air conditioning (HVAC) efficiency | Energy                                                             |
| ENE 16            | Refrigerant cooling system                                  |                                                                    |
| ENE 17            | Cooling emitter type                                        |                                                                    |
| ENE 18            | Glazing                                                     |                                                                    |
| ENE 19            | Mechanical and electrical cooling equipment                 |                                                                    |
| ENE 20            | Specific fan power                                          |                                                                    |
| ENE 21            | Duct and air leakage tests                                  |                                                                    |
| ENE 22            | Mechanical and electrical ventilation equipment             |                                                                    |
| ENE 23            | Water heating                                               |                                                                    |
| ENE 24            | Water heating energy sources                                |                                                                    |
| ENE 25            | High frequency ballast                                      |                                                                    |
| ENE 26            | Internal lighting types                                     |                                                                    |

<!-- image -->

<!-- image -->

| Issue Reference         | Title                       | Credits available   |
|-------------------------|-----------------------------|---------------------|
| ENE 27                  | Automatic lighting controls |                     |
| ENE 28                  | Occupancy sensors           |                     |
| ENE 29                  | Benchmarking                | 3                   |
| ENE 30                  | On-site renewables          | 5                   |
| Total credits available | Total credits available     | 108                 |

<!-- image -->

<!-- image -->

## Asset Energy Calculator Guidance

## Introduction

This section has been produced to give BREEAM USA In-Use Assessors further guidance on the workings of the asset energy calculator so it is clear how any improvements to the asset performance can be reflected in the calculation of the asset energy rating.

## Overview

The first step to generating the BREEAM USA In-Use asset energy score is to assess the performance of specific energy end use components, listed in Table 10.

In order to assess the performance of the end use component, specific parameters (subcomponents) that have the greatest impact on the end use component score have been identified. The subcomponents contributing to the end use component score are listed in Table 10.

Table 10: Energy end use components and subcomponents

| End use component    | Subcomponent                                                                                                                         |
|----------------------|--------------------------------------------------------------------------------------------------------------------------------------|
| Heating              | Building Envelope - Thermal Conductance Building Envelope - Air Leakage Rate Ventilation Heat Recovery Efficiency of Heat Generation |
| Cooling              | Solar Gains Building Envelope - Air Leakage Rate Efficiency of Cooling Generation                                                    |
| Heating Distribution | Efficiency of Heating Distribution                                                                                                   |
| Cooling Distribution | Efficiency of Cooling Distribution                                                                                                   |
| Lighting             | Efficiency of Lighting Installation                                                                                                  |
| Ventilation          | Fan Efficiency Duct Leakage Air Handling Unit Leakage                                                                                |
| Hot Water            | Efficiency of Heat Generation                                                                                                        |

<!-- image -->

<!-- image -->

## End Use components

The  individual  subcomponent  scores  are  calculated  by  comparing  actual  performance  to  a  benchmark  best practice value. The actual performance is determined by answering the relevant questions in the energy category in Part 1.

The paragraphs below give a further explanation about the calculation of the subcomponent scores.

## Heating

Four  subcomponents  contribute  to  the  heating  end  use  component  score:  envelope  performance,  building infiltration rate, efficiency of heat generation and ventilation heat recovery efficiency.

It  is  possible  to  make  improvements  to  the  heating  end  use  component  score  by  addressing  each  of  these subcomponents and making improvements to:

- 1. The envelope performance: maximum score awarded for an external wall u-value of less than 0.030 Btu/hr ft  °F. 2
- 2. The building infiltration rate: maximum score awarded for infiltration of less than 2.5m /m  at 50Pa 3 2
- 3. The heat generator efficiency: maximum score awarded for efficiency equivalent to an electric heat pump with a EER of 23.88.
- 4. The ventilation heat recovery: maximum score awarded for ventilation heat recovery efficiency of 95%.

It should be noted that it is not possible to enter a value for ventilation heat recovery directly into the tool. Instead, the tool uses a default value based on the age of the heating system (where applicable).

## Cooling

There are three subcomponents that contribute to the cooling end use component score: solar gain, building infiltration rate and efficiency of cooling generation.

It  is  possible  to  make  improvements  to  the  cooling  end  use  component  score  by  addressing  each  of  these subcomponents and making improvements to:

- 1. Glazing area (as a proxy for solar gains): maximum score awarded for glazing area less than 25% of total façade area
- 2. The building infiltration rate: maximum score awarded for infiltration of less than 2.5m /m  at 50Pa 3 2
- 3. The cooling generator efficiency: maximum score awarded for efficiency equivalent to electric chiller with a EER of 23.88.

## Heating distribution

The heating distribution end use component score is a function of the efficiency of the distribution system and the efficiency of the heat emitter.

Fixed efficiencies are assigned for the building in question in response to the user response to questions that ask for these system details.

The maximum score is achieved where there is no heat distribution i.e. 'local heating'.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Cooling distribution

The cooling distribution end use component score is a function of the efficiency of the distribution system and the efficiency of the cooling emitter.

Fixed efficiencies are assigned for the building in question in response to the user response to questions that ask for these system details.

The maximum score is achieved where there is no cooling distribution i.e. 'local cooling'.

## Lighting

The lighting end use component score is a function of both the type of light fittings installed, and the lighting controls.

The lighting score can be improved by upgrading light fittings, or introducing automatic lighting controls where not already installed.

The most efficient lamp types are LED lighting (with special design lighting control system) and T5 fluorescents. The least efficient lamp types are tungsten halogen and incandescent lamps.

Where fluorescent lamps are installed, the score is improved when they are fitted with high frequency ballasts.

The maximum score is achieved where either LED lighting (with special control) or T5 lamps (with high frequency ballasts) are used with automatic controls covering 75% or more of the floor area not accessible to clients or customers.

Where more than one lamp type is installed, the score is calculated on an area weighted basis.

## Ventilation

The ventilation end use component score is a function of three subcomponents: fan efficiency, duct leakage and air handling unit leakage.

The ventilation end use component score can be improved by:

- 1. Improving fan efficiency: maximum score awarded for a fan efficiency of 0.63 hp/kcfm or less.
- 2. Improving air leakage rates (and undertaking necessary testing to demonstrate compliance): maximum score awarded for Class A test results.

## Hot water

The hot water end use component score is a function of the type of system and the fuel type used for water generation.

The maximum score is achieved for point of use generation using any fuel type other than electric.

## Subcomponent and End use component scores

Once the individual subcomponent scores have been generated, they are multiplied by a weighting factor, which reflects  the  influence  that  the  subcomponent  has  on  the  overall  performance  of  the  respective  end  use component. All weighted subcomponent scores are then summed to generate the main end use component score.

<!-- image -->

<!-- image -->

In order to generate the overall asset energy rating, it is necessary to take account of the influence that each energy end use component has on the total building energy consumption. Therefore, the end use components are weighted, reflecting the importance of the individual end use component in terms of its contribution to the overall energy consumption. The end use component weighting factors vary according to:

- a) Building type, to reflect different energy end use patterns
- b) Asset location, to reflect differences in climate and associated heating or cooling demand

The weighting factors would for example reflect the fact that a large proportion of the energy consumption in a retail building would typically be associated with lighting, or that an office in a hot climate would expect to use more energy for cooling than the same office in a colder climate.

The performance of each end use component is only assessed where that end use is present in the building that is being assessed. If a particular project does not have one or more of the end use components, the available asset energy score is distributed across the other end use components that are present. Table 11 illustrates how the end use component weighting factors for heating, lighting and hot water increase for a naturally ventilated office without cooling, compared to an air-conditioned office with mechanical ventilation.

Table 11: End use component weighting factors

| Open Plan Office                 | End Use Component Weighting   | End Use Component Weighting   | End Use Component Weighting   | End Use Component Weighting   | End Use Component Weighting   | End Use Component Weighting   | End Use Component Weighting   |
|----------------------------------|-------------------------------|-------------------------------|-------------------------------|-------------------------------|-------------------------------|-------------------------------|-------------------------------|
| Servicing strategy               | Heating                       | Heating Distribution          | Cooling                       | Cooling Distribution          | Lighting                      | Mechanical Ventilation        | Hot Water                     |
| Cooling & Mechanical Ventilation | 39.9                          | 7.34                          | 17.71                         | 7.34                          | 9.94                          | 14.47                         | 4.32                          |
| Naturally Ventilated             | 64.41                         | 12.09                         | 0                             | 0                             | 16.38                         | 0                             | 7.12                          |

A  further  adjustment  is  then  applied  to  the  heating,  heating  distribution,  cooling,  and  cooling  distribution benchmarks to account for local climatic conditions.

## Final score

The final score is calculated by adding together the weighted end use component scores.

## Primary energy metric

It should be noted that the metric used to assess asset energy performance is primary energy, where 'primary energy' means energy from renewable and non-renewable sources which has not undergone any conversion or transformation process.

<!-- image -->

<!-- image -->

## Asset energy calculator inputs

There are 2 levels of user input information that inform the calculation of the asset energy score.

Level 1: The user is required to enter information on the building type, age of the building, location (full address including ZIP code) and the maintenance strategy to generate a score. This information establishes the end use component weightings and the climate adjustment made to the end use weightings.

Level 2: The user can enter further information to describe the performance of various systems; user response to these questions is optional.

If the user is unable to answer any questions describing building performance, the tool will use default lookup values for the calculation. These values are based on either:

-  The last time the relevant system was replaced, if known, or
-  The age of the building

Figure 4 illustrates the above logic and calculation of the asset energy calculation score.

<!-- image -->

Figure 4: Asset energy calculation flowchart

<!-- image -->

## Asset  Performance  ENE  01  -  Heating,  Ventilation  and  Air  Conditioning (HVAC)

| Number of credits available                    | Minimum standards   | Mandatory question   |
|------------------------------------------------|---------------------|----------------------|
| Credits are calculated within the Energy Model | No                  | Yes                  |

## Question

What building services are present in the asset?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Answer option                     |
|-----------|-----------------------------------|
| -         | Question not answered             |
| -         | Heating only                      |
| -         | Heating and cooling               |
| -         | Cooling only                      |
| -         | None                              |
| -         | Domestic hot water only           |
| -         | Heating and hot water             |
| -         | Heating and cooling and hot water |
| -         | Cooling and hot water             |

## Assessment criteria

- 1. Building services include any fixed cooling, hot water or heating systems that are installed within the asset. These systems can either service the whole asset or part thereof. Building services include (but are not limited to):
- a. Domestic hot water
- b. Point of use hot water systems
- c. Boilers
- d. Heat pumps
- e. Chillers
- f. Local heaters
- g. Local split air conditioning systems

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- h. Fully centralized air conditioning systems
- 2. Heating/cooling systems can be excluded from the calculation where the heated or cooled area equates to less than 10% of overall floor area.

## Evidence

One of the following is acceptable:

- 1. Visual inspection and verification through photographic evidence of listed system(s).
- 2. Extract of Operational &amp; Maintenance (O&amp;M) manuals listing all building services that are present in the building.
- 3. Installation diagrams.

## Additional information

## Other information

This question must be answered in order to generate the asset energy rating (along with: building type, building age, building location, and building ventilation strategy).

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Asset Performance ENE 02 - Ventilation strategy

| Number of credits available                    | Minimum standards   | Mandatory question   |
|------------------------------------------------|---------------------|----------------------|
| Credits are calculated within the Energy Model | No                  | Yes                  |

## Question

What is the ventilation strategy for the building (Natural or Mechanical)?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Answer option          |
|-----------|------------------------|
| -         | Question not answered  |
| -         | Don't know             |
| -         | Natural ventilation    |
| -         | Mechanical ventilation |
| -         | Other                  |

## Assessment criteria

- 1. Assessors need to confirm that the specified ventilation systems are in use.
- 2. For the purposes of this BREEAM USA In-Use issue:
- a. A mechanically ventilated building is a building with a centralized mechanical ventilation system, or mixed mode building. Typically, a mechanically ventilated building will provide both supply and exhaust.
- b. A naturally ventilated building is a building that is designed to be capable of providing fresh air entirely by natural ventilation strategy (with the exception of local mechanical exhaust systems).
- 3. If both ventilation systems are in use in the building, the selection must be mechanical unless this usage is negligible.

## Evidence

- 1. Visual inspection and verification through photographic evidence of ventilation system.
- 2. Extract of O&amp;M manual listing ventilation systems that are present in the building Installation diagrams.

## Additional information

## Other information

This question must be answered in order to generate the asset energy rating (along with: building type, building age, building location, and building services).

<!-- image -->

SD221 USA © BRE Global Ltd 2019

<!-- image -->

## Asset Performance ENE 03 - Heat loss

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

Please provide the design U-Values of the external walls (Btu/hr ft  °F). 2

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated In Asset Energy Model           |
|-----------|--------------------------------------------------|
| -         | The design U-value of the walls (Btu/hr ft 2 °F) |

## Assessment criteria

- 1. U-Values of the building external walls can be determined through:
- a. A copy of design specifications indicating the design U-value of the assets walls
- b. Relevant building code or regulation providing an indication of U-value figure, at the time that the building was built
- c. Site investigation e.g. building surveyor with appropriate knowledge of prevalent construction methods; this could be the Assessor

Note: If the U-values differ between the external walls please enter the average U-value.

Note: U-values entered must be between 0.030 and 0.352 Btu/hr ft  °F. If the U-value is outside of the permitted 2 values, please enter the upper or lower limit as appropriate.

## Evidence

- 1. Photographic evidence of building wall construction (if possible).
- 2. Building design plans.
- 3. Written details of the relevant building regulations stating the minimum U-value at the time the asset was constructed.
- 4. Expert report by an architect, commissioning agent or equivalent estimating the U-value

## Additional information

## Relevant definitions

U-value: is a measure of heat loss in a building element such as a wall, floor or roof that measures the effectiveness of  a  material  as  an  insulator.  The  U-value  figure  of  the  external  walls  is  used  to  assess  the  overall  envelope performance of the asset. A lower U-value indicates a higher level of thermal efficiency.

<!-- image -->

SD221 USA © BRE Global Ltd 2019

<!-- image -->

## Asset Performance ENE 04 - Building pressure/air leakage test

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the result of the building pressure/air leakage test?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | ≤2.5m 3 /h/m 2 @50Pa                     |
| -         | >2.5 to ≤5m 3 /h/m 2 @50Pa               |
| -         | >5 to ≤10m 3 /h/m 2 @50Pa                |
| -         | >10 to ≤15m 3 /h/m 2 @50Pa               |
| -         | >15m 3 /h/m 2 @50Pa                      |
| -         | Untested                                 |

## Assessment criteria

- 1. Assessors should verify:
- a. The results of building pressure/air leakage tests
- b. That testing was conducted by relevant competent persons
- 2. The appropriate standard for air leakage testing is: ISO 9972:2006/EN 13829:2000 Thermal performance of buildings - Determination of air permeability of buildings - Fan pressurization method or ASTM E77910 Standard Test Method for Determining Air Leakage Rate by Fan Pressurization.
- 3. Air leakage testing results must be from testing that has, at least, been carried out after construction of the building or when structural changes have been made to the building.  The testing must have been carried out by a competent person whose expertise should be broad enough to cover all required technical aspects guaranteeing that the data collected during the test is appropriate and that the results reflect the actual  airtightness  performance  of  the  building.  It  can  be  someone  operating  as  sole  proprietor  or employed by public or private enterprises or agencies.

## Evidence

<!-- image -->

<!-- image -->

- 1. Copy of results from building pressure and/or air leakage test.
- 2. Confirmation of competence levels for persons performing testing.

## Additional information

## Relevant definitions

Air leakage test: a test that quantifies the air permeability rate of the building envelope. The more airtight the building envelope is the lower the air permeability result will be. To maximize energy efficiency, it is advised that the air permeability result is as low as reasonably practicable.

Relevant  competent  person: An  individual  achieving  all  of  the  following  can  be  considered  to  be  a  relevant competent person:

- a) Holds a recognized qualification in airtightness testing and measurement.
- b) Has relevant experience in air pressure testing at least ten large non-residential buildings within the last five years.

<!-- image -->

<!-- image -->

## Asset Performance ENE 05 - Heating

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the main generation type for space heating?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model               |
|-----------|------------------------------------------------------|
| -         | Question not answered                                |
| -         | Don't know                                           |
| -         | Boiler                                               |
| -         | Heat pump/reversible chiller                         |
| -         | Direct electricity consumption                       |
| -         | Other onsite heat generation, e.g. CHP/Solar thermal |
| -         | Heat generated offsite e.g., district heating        |
| -         | Other                                                |

## Assessment criteria

- 1. Where there is more than one heat source in the asset, the Assessor must clarify and verify that the selected generation type is the main heat source for the asset.
- 2. If there is more than one boiler the Assessor should base the efficiency figure on the average efficiency of the systems. This can be weighted based upon respective system capacities.
- 3. If there is more than one heat pump the Assessor should base the COP figure on the average COP of the systems. This can be weighted based upon respective system capacities.

## Evidence

- 1. Photographic evidence of listed space heating system.
- 2. Extract of O&amp;M manuals or copy of manufacturer information of heating systems that are present in the asset.
- 3. Where there is more than one heat source installed, photographic evidence that the selected generation type is the main heat source.

<!-- image -->

<!-- image -->

## Additional information

-

<!-- image -->

Version 2.0: 2016, April 2019

<!-- image -->

Version 2.0: 2016, April 2019

## Asset Performance ENE 06 - Boiler efficiency

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

For boilers, other on-site, offsite, and other generation type heat sources please enter efficiency, if known.

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Boiler efficiency (%)                    |

## Assessment criteria

- 1. If there is more than one boiler the Assessor should base the efficiency figure on the average efficiency of the two systems. This can be weighted based upon respective system capacities.
- 2. The question need not be answered where any other heat generation type as listed in the question is in use in the asset.

## Evidence

- 1. Extract of manufacturer literature stating the boiler efficiency
- 2. Photographic evidence of installed boiler.

## Additional information

## Other information

To assess a CHP unit using BREEAM USA In-Use, select the 'main generation type for space heating' as 'other on site e.g. CHP/solar thermal'. In order to account for the fact that the overall efficiency of the CHP system would not be recognized by entering the actual CHP thermal efficiency, the efficiency value to be entered should be calculated as follows:

𝑂𝑣𝑒𝑟𝑎𝑙𝑙 𝑒𝑓𝑓𝑖𝑐𝑖𝑒𝑛𝑐𝑦 = 𝑡ℎ𝑒𝑟𝑚𝑎𝑙 𝑒𝑓𝑓𝑖𝑐𝑖𝑒𝑛𝑐𝑦 + (2 × 𝑒𝑙𝑒𝑐𝑡𝑟𝑖𝑐𝑎𝑙 𝑒𝑓𝑓𝑖𝑐𝑖𝑒𝑛𝑐𝑦)

As an example, if the thermal efficiency was 50%, and the electrical efficiency 35%, then the calculated efficiency would be:

<!-- formula-not-decoded -->

<!-- image -->

<!-- image -->

## Asset Performance ENE 07 - Heat pump efficiency

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

For heat pump generation type, please enter Energy Efficiency Ratio (EER), if known.

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Heat pump Energy Efficiency Ratio (EER)  |

## Assessment criteria

- 1. If there is more than one heat pump the Assessor should base the EER figure on the average EER of the two systems. This can be weighted based upon respective system capacities.
- 2. The Energy Efficiency Ratio (EER) of a heat pump is calculated as the ratio of heating or cooling provided to electrical energy consumed. EER entered must not be higher than 23.88.

## Evidence

- 1. Extract of O&amp;M or copy of manufacturer information or other efficiency data from another valid source.
- 2. Visual inspection of installed heat pump(s) backed up by photographic evidence.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance ENE 08 - Fuel usage for heat generation

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the main fuel used for heat generation?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Electric                                 |
| -         | Solid fossil fuel                        |
| -         | Oil                                      |
| -         | Gas                                      |
| -         | Other                                    |

## Assessment criteria

- 1. The main fuel used for heat generation is the fuel type for the main source of heat generation, regardless of whether the source of heat generation is on site or off site.
- 2. If a building is connected to a district heating system, then it is the main fuel type for the district heating system that should be entered.
- 3. If the main fuel used for heat generation is biomass/biofuel, select 'Other'.

## Evidence

- 1. Photographic evidence of the listed heat generating equipment.
- 2. Extract of O&amp;M manual or copy of manufacturer information for relevant equipment.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance ENE 09 - Heat distribution

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the predominant medium by which heat is distributed around the asset?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model      |
|-----------|---------------------------------------------|
| -         | Question not answered                       |
| -         | Don't know                                  |
| -         | By air                                      |
| -         | By water                                    |
| -         | By refrigerant                              |
| -         | Other                                       |
| -         | Local heating - no heat distribution system |

## Assessment criteria

-

## Evidence

- 1. Photographic evidence of listed system, indicating distribution method.
- 2. Extract of O&amp;M manual or copy of manufacturer information indicating medium for heat distribution.
- 3. Installation diagrams.

## Additional information

## Relevant definitions

Distribution medium: For the purposes of this BREEAM USA In-Use issue, the distribution medium refers to the medium that is used to distribute the heat from the point at which it is generated, to the point at which it is required. Listed below are examples of typical media by which heat is distributed for specific heat distribution type:

- a. For a conventional gas boiler/radiator/conventional HVAC system, the medium will be water.
- b. For an air-conditioned building, the medium may be air if hot/cold air ducted throughout building, or it may be refrigerant if external condensers are connected to indoor units.
- c. For heat pumps, the medium may be a refrigerant.

<!-- image -->

<!-- image -->

## Asset Performance ENE 10 - Heat emitter type

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the main heat emitter type?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Asset is not heated                      |
| -         | Radiators                                |
| -         | Fan coil units                           |
| -         | Ducted warm air                          |
| -         | Direct radiant heating                   |
| -         | Under floor heating                      |
| -         | Other                                    |

## Assessment criteria

-

## Evidence

- 1. Photographic evidence of the listed equipment.
- 2. Extract of O&amp;M manual
- 3. Building schematics

## Additional information

## Relevant definitions

Main heat emitter type: For the purposes of this BREEAM USA In-Use issue, the main heat emitter type is the main type through which heat is emitted in to the space/area for which heating is required.

Description of listed heat emitter types:

<!-- image -->

<!-- image -->

- a) Radiator  is  a  device  that  warms  a  space  by  radiating  heat  by  running  a  hot  liquid  through  exposed elements (fins or pipes)
- b) Fan coil unit is a device consisting of a heating coil and fan used to warm a space
- c) Ducted warm air heating a space by providing hot air to it through ductwork
- d) Direct radiant heating warms a space by emitting heat from a warm element, such as a floor, wall or overhead panel, warming people and other objects in the space rather than heating the air.
- e) Under floor heating is a form of central heating in which spaces are heated through the floor (either by directly warming people and objects or by heating the air in the space)

<!-- image -->

<!-- image -->

## Asset Performance ENE 11 - Mechanical and electrical heating equipment

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

In what year was the main heat generator/heating system installed/replaced (if known)?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | 2006 +                                   |
| -         | 2002 - 2005                              |
| -         | 1995 - 2001                              |
| -         | 1990 - 1994                              |
| -         | 1985 - 1989                              |
| -         | 1965 - 1984                              |
| -         | 1945 - 1964                              |
| -         | 1920 - 1945                              |
| -         | Pre 1920                                 |

## Assessment criteria

-

## Evidence

- 1. Copy of documentation outlining when heat generator or heating system was installed or replaced, such as,
- a. Extract of O&amp;M manuals or copy of manufacturer information for heat generator/heating system
- b. Service and/or maintenance records
- c. Installation records
- d. Maintenance records
- 2. Photographic evidence of heating system(s) if possible).

<!-- image -->

<!-- image -->

## Additional information

-

<!-- image -->

Version 2.0: 2016, April 2019

<!-- image -->

## Asset Performance ENE 12 - Cooling system

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the main system type for cooling?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Asset is not cooled                      |
| -         | Localized (room) air conditioning unit   |
| -         | Chiller                                  |
| -         | Desiccant cooling system                 |
| -         | Evaporative cooling                      |
| -         | Ground cooling (air)                     |
| -         | Ground cooling (water)                   |
| -         | Sea/river/lake water cooling             |
| -         | Other                                    |

## Assessment criteria

-

## Evidence

- 1. Photographic evidence of relevant systems.
- 2. Extract of relevant O&amp;M manuals or copy of manufacturer information.

## Additional information

## Relevant definitions

Descriptions of typical cooling systems are as follows:

<!-- image -->

<!-- image -->

- a) Localized  (room)  air  conditioning  unit:  cooling  is  typically  supplied  stand-alone,  all  in  one,  (most commonly) wall-mounted unit. This does not include temporary/mobile units or small split systems (where the system type selected should be chiller).
- b) Chiller: cooling is supplied via a system that uses a machine (chiller) that removes heat from a liquid via a vapor-compression or absorption refrigeration cycle. This liquid can then be circulated through a heat exchanger to cool air or equipment as required. These systems are typically (but not limited to):
- i. an outdoor unit serving a split system
- ii. a centralized chiller, typically roof mounted, or housed externally
- c) Desiccant  cooling  system:  desiccant  cooling  relies  on  the  moisture  absorption  properties  of hygroscopic materials.
- d) Evaporative cooling: the evaporation of water is used to decrease the dry bulb temperature of air, Evaporative  cooling  can  be  direct  (water  evaporated  directly  into  supply  air  stream),  or  indirect (secondary air stream is cooled directly and then exhausted).
- e) Ground cooling (air): cooling is provided by drawing outdoor air into the building via an underground duct system where the air exchanges heat with the ground.
- f) Ground cooling (water): cooling is provided by extracting ground water and passing through a heat exchanger before returning to the ground. Can be open loop or closed loop.
- g) Sea/river/lake water cooling: cooling is provided by pumping water from an open body of water by an open loop system with cooling extracted via a heat exchanger.

<!-- image -->

<!-- image -->

## Asset Performance ENE 13 - Efficiency of cooling generator

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

Please enter the Energy Efficiency Ratio (EER) of the cooling generator, if known.

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model     |
|-----------|--------------------------------------------|
| -         | Energy efficiency ratio (EER) of generator |

## Assessment criteria

- 1. The EER of the cooling generator should not be larger than 23.88.

## Evidence

- 1. Extract  of  relevant  O&amp;M  manuals or copy of manufacturer information or other efficiency data from another valid source.
- 2. If there is more than one cooling generator the Assessor should base the EER figure on the average EER of the two systems. This must be weighted based upon the capacity of the systems.

## Additional information

## Other information

To assess CCHP/absorption chillers using BREEAM USA In-Use, select the 'main system type for cooling' as 'Chiller'. The energy efficiency ratio (EER) for cooling generator should then be calculated as follows:

𝐸𝐸𝑅 = 𝑟𝑎𝑡𝑒𝑑 𝑎𝑏𝑠𝑜𝑟𝑝𝑡𝑖𝑜𝑛 𝑐ℎ𝑖𝑙𝑙𝑒𝑟 𝐶𝑂𝑃 × 2

As an example, if the absorption chiller COP was 0.7, then the calculated energy efficiency ratio to be entered into the tool would be:

<!-- formula-not-decoded -->

Where  the  calculated  EER  is  below  the  minimum  value  that  can  be  entered  into  the  tool,  please  enter  the minimum value. This correction is made to cancel out the primary energy factor normally applied for electrical chillers that would not be applicable in this instance.

Please note: absorption chillers are unlikely to score highly under the current methodology due in part to the use of the primary energy metric. The score will however be balanced to some degree by an improved score against the heating end use component where CCHP is used.

<!-- image -->

<!-- image -->

## Asset Performance ENE 14 - Cooling distribution

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the predominant medium by which cooling is distributed around the asset?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Local (room) cooling                     |
| -         | By air                                   |
| -         | By water                                 |
| -         | By refrigerant                           |
| -         | Other                                    |

## Assessment criteria

-

## Evidence

- 1. Extract of relevant O&amp;M manuals or copy of manufacturer information.
- 2. Photographic evidence of relevant systems.

## Additional information

## Relevant definitions

Cooling distribution medium: For the purposes of this BREEAM USA In-Use issue, the distribution medium refers to the medium that is used to distribute the cooling capacity from the point at which it is generated, to the point at which it is required.

Descriptions of typical cooling systems and the cooling medium are as follows:

- a. Chiller: by refrigerant
- b. Desiccant cooling system: typically by air
- c. Evaporative cooling: by air

<!-- image -->

<!-- image -->

- d. Ground cooling: either by air or water
- e. Sea/river/lake water cooling: typically by water

<!-- image -->

<!-- image -->

## Asset Performance ENE 15 - Air distributed cooling system

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the system subtype for air distributed cooling systems?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Single duct constant volume              |
| -         | Single duct variable volume              |
| -         | Dual duct                                |
| -         | Other                                    |

## Assessment criteria

- 1. This question only refers to assets that have air distributed cooling systems installed.

## Evidence

- 1. Extract of relevant O&amp;M manuals or copy of manufacturer information.
- 2. Photographic evidence of relevant systems.

## Additional information

Descriptions of typical air distributed cooling systems are as follows:

- a. Single duct constant volume systems maintain a constant air volume and vary the supply air temperature in response to space conditions.
- b. Single duct variable volume systems control the temperature in a space by varying the quantity of air supplied, rather than the supply air temperature.
- c. Dual duct systems use two separate ducts to circulate both cooled and heated air.

<!-- image -->

<!-- image -->

## Asset Performance ENE 16 - Refrigerant cooling system

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the system subtype for refrigerant cooling systems?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Split system                             |
| -         | Variable refrigerant flow (VRF) system   |
| -         | Other                                    |

## Assessment criteria

-

## Evidence

- 1. Extract of relevant O&amp;M manuals or copy of manufacturer information.
- 2. Photographic evidence of relevant systems.

## Additional information

## Relevant definitions

Descriptions of refrigerant cooling subtypes are as follows:

- a. Split  system  -  This  subtype  utilizes  one  external  condensing  unit/heat  pump,  which  connects,  via refrigerant  pipework,  to the  indoor  unit.  These  systems  can  serve  multiple  rooms  which  have  similar heating/cooling loads. In these systems only one indoor unit is utilized as a master temperature control sensor. Split systems work with a limited number of indoor units.
- b. Variable refrigerant flow (VRF) system - This subtype again utilizes one external condensing unit/heat pump, which is connected to several indoor units.  However, these  systems  allow  versatility  between heating /cooling loads and work independently of each other. VRF systems can work with many more units than split systems (e.g. up to 16 is fairly typical) and can provide simultaneous heating and cooling, and heat recovery.

<!-- image -->

<!-- image -->

## Asset Performance ENE 17 - Cooling emitter type

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the main cooling emitter type?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model             |
|-----------|----------------------------------------------------|
| -         | Question not answered                              |
| -         | Don't know                                         |
| -         | Air ducts                                          |
| -         | Radiators                                          |
| -         | Fan coil units                                     |
| -         | Direct radiant cooling, e.g. passive chilled beams |
| -         | Fan assisted cooling, e.g. active chilled beams    |
| -         | Induction units                                    |
| -         | Other                                              |

## Assessment criteria

- 1. If  more than one cooling emitter type is in use the selection must be that which distributes the most common cooling load within the building.

## Evidence

- 1. Photographic evidence of installed cooling systems.
- 2. Extract of relevant O&amp;M manuals or copy of manufacturer information.
- 3. Installation diagrams.

## Additional information

## Relevant definitions

Main emitter type: For the purposes of this BREEAM USA In-Use issue, the main emitter type is the main type through which cooling capacity is supplied in to the space/area for which cooling is required.

Descriptions of emitter types are listed below:

<!-- image -->

<!-- image -->

- a. Air duct: a tube, canal, pipe, or similar through which coolant is delivered to a room.
- b. Radiator: a temperature-controlled surface that cools indoor temperatures by removing heat.
- c. Fan coil unit is a device consisting of a cooling coil and fan used to cool a space.
- d. Direct radiant cooling (e.g. passive chilled beam): a space is cooled through a temperature-controlled surface that cools indoor temperatures by removing sensible heat. There is no mechanical component to force the air through the system.
- e. Fan assisted cooling (e.g. active chilled beam): a space is cooled through the recirculation of cool air by a fan. This fan could be installed in combination with direct radiant cooling to increase its cooling capacity.
- f. Induction units: a space is cooled by a process in which induced room air is cooled by a water coil to the extent needed to control the room temperature.

<!-- image -->

<!-- image -->

## Asset Performance ENE 18 - Glazing

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What percentage of the external elevation is glazed?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model              |
|-----------|-----------------------------------------------------|
| -         | Percentage of external elevation that is glazed (%) |

## Assessment criteria

-

## Evidence

- 1. Photographic evidence of building from all sides.
- 2. Building elevations

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance ENE 19 - Mechanical and electrical cooling equipment

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

In what year was the main chiller/cooling system installed/replaced (if known)?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | 2006 +                                   |
| -         | 2002 - 2005                              |
| -         | 1995 - 2001                              |
| -         | 1990 - 1994                              |
| -         | 1985 - 1989                              |
| -         | 1965 - 1984                              |
| -         | 1945 - 1964                              |
| -         | 1920 - 1945                              |
| -         | Pre 1920                                 |

## Assessment criteria

-

## Evidence

- 1. Extract of relevant O&amp;M manuals or copy of manufacturer information for chiller/cooling system.
- 2. Service/maintenance records for the chiller/cooling system.
- 3. Visual inspection of equipment date (photographic evidence if possible).

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance ENE 20 - Specific fan power

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the specific fan power for air handling systems?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | 3.16 hp/kcfm                             |
| -         | 1.90 hp/kcfm                             |
| -         | 0.63 hp/kcfm                             |
| -         | Other                                    |

## Assessment criteria

- 1. In this instance, air handling systems are systems (usually centralized) which distribute air (usually for cooling) around the building.

## Evidence

- 1. Extract of relevant O&amp;M manuals or copy of manufacturer information.

## Additional information

Specific Fan Power is a measure of the efficiency of a fan. It is calculated by dividing the electrical power consumed by  a  fan  (hp)  by  the  airflow  through  that  fan  (ft /min).  If  multiple  systems  have  been  installed,  it  would  be 3 calculated by dividing the sum of the electrical power consumed by all fans by the airflow through these fans. -

<!-- image -->

<!-- image -->

## Asset Performance ENE 21 - Duct and air handling leakage tests

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What are the results of duct and air handling leakage tests?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Not applicable                           |
| -         | No test                                  |
| -         | Class A result                           |
| -         | Class B result                           |
| -         | Other                                    |

## Assessment criteria

- 1. Class A and Class B results for duct and air handling leakage tests are:

<!-- formula-not-decoded -->

Where:

f = air leakage in cfm/100 ft 2

p = static pressure in wg (inch water gauge)

As referenced in:

Sheet  Metal  &amp;  Air  Conditioning  Contractors'  National  Association  (SMACNA) HVAC  Air  Duct  Leakage Manual , 2nd edition (2012).

## Evidence

- 1. Copy of duct and air handling leakage test results.

<!-- image -->

<!-- image -->

## Additional information

## Other information

The maximum score is awarded for Class A systems i.e. those with the lowest air leakage rates.

<!-- image -->

Version 2.0: 2016, April 2019

<!-- image -->

## Asset Performance ENE 22 - Mechanical and electrical ventilation equipment

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

In what year was the main ventilation system installed/replaced (if known)?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | 2006 +                                   |
| -         | 2002 - 2005                              |
| -         | 1995 - 2001                              |
| -         | 1990 - 1994                              |
| -         | 1985 - 1989                              |
| -         | 1965 - 1984                              |
| -         | 1945 - 1964                              |
| -         | 1920 - 1945                              |
| -         | Pre 1920                                 |

## Assessment criteria

-

## Evidence

- 1. Extract of relevant O&amp;M manuals or copy of manufacturer information for ventilation system.
- 2. Service/maintenance records for the ventilation system.
- 3. Visual inspection of equipment date (photographic evidence if possible).

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance ENE 23 - Domestic water heating

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What type of domestic hot water heating is provided?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Point of use                             |
| -         | Centralized                              |
| -         | Other                                    |

## Assessment criteria

- 1. This question pertains to the predominant system that is used for domestic hot water generation within the asset and does not include systems that are used to heat spaces.

## Evidence

- 1. Photographic evidence of water heating systems.
- 2. Extract of relevant O&amp;M manuals or copy of manufacturer information.
- 3. Installation diagrams.

## Additional information

## Relevant definitions

Commonly used water heating types:

- a. Point of use: hot water is directly provided from a faucet for drinking and cooking, i.e. via an instant hot water device.
- b. Centralized: hot water for drinking and cooking is provided centrally, i.e. through a storage tank water heater or boiler.

<!-- image -->

<!-- image -->

## Asset Performance ENE 24 - Domestic water heating energy sources

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What energy source is used to heat domestic water? If there is a mixture of centralized and point of use systems please select the energy source type of the centralized system.

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | Electric                                 |
| -         | Solid fossil fuel                        |
| -         | Oil                                      |
| -         | Gas                                      |
| -         | Other                                    |

## Assessment criteria

- 1. If there is a mixture of centralized and point of use systems, the energy source type of the centralized system should be selected.

## Evidence

- 1. Photographic evidence of relevant system.
- 2. Extract of relevant O&amp;M manuals or copy of manufacturer information.
- 3. Installation maps.

## Additional information

## Relevant definitions

Some examples of water heating include (but are not limited to):

- a. Point of use, likely to be electric
- b. Boiler or water heater, likely to be gas or oil

<!-- image -->

<!-- image -->

## Asset Performance ENE 25 - High frequency ballast

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What percentage of fluorescent lamps has high frequency ballasts?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | There are no fluorescent lamps           |
| -         | 0 to <50%                                |
| -         | ≥50% to <75%                             |
| -         | ≥75% to <100%                            |
| -         | 100%                                     |
| -         | Other                                    |

## Assessment criteria

-

## Evidence

- 1. Photographic evidence of ballasts used for fluorescent lamps.
- 2. Copy of relevant manufacturer literature (if necessary).
- 3. Copy of building plans highlighting areas which use fluorescent lamps with high frequency ballasts.

## Additional information

## Relevant definitions

High frequency ballast is a device that is designed to limit the current through the tube of a fluorescent lamp and to optimally operate a fluorescent lamp.

<!-- image -->

<!-- image -->

## Asset Performance ENE 26 - Internal lighting types

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

Of all internal lamps, what percentage is of the type as listed below?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model                                       |
|-----------|------------------------------------------------------------------------------|
| -         | Percentage of Compact Fluorescent lighting (%)                               |
| -         | Percentage of Tungsten Halogen lighting (%)                                  |
| -         | Percentage of Incandescent lamps lighting (%)                                |
| -         | Percentage of T12 type lighting (%)                                          |
| -         | Percentage of T8 type lighting (%)                                           |
| -         | Percentage of T5 type lighting (%)                                           |
| -         | Percentage of LED type lighting (%) (with a special lighting control system) |
| -         | Percentage of LED type lighting (%) (with a typical lighting control system) |
| -         | Percentage of metal halide type lighting (%)                                 |

## Assessment criteria

- 1. For LED type lighting with a special lighting control system:
- Special design lighting control systems allow the user to control all lighting within the asset from a central location. Other features include pre-set scene lighting levels for varying spaces, for example dimming levels etc. Special lighting systems include a variety of different control panels such as: integration to automated control systems and video controls. These lighting systems allow multiple zones to be created to allow for an improvement in energy efficiency.
- 2. For LED type lighting with a typical lighting control system:
- Typical lighting control systems utilize stand-alone control within the space, whereby adjustment occurs only at the lighting location. Examples could include occupancy sensors and daylight sensors etc. Typical lighting systems include an on/off switch and can include dimming settings.
- 3. Valid responses for each lamp type questions are in percentage (%) values and must equal 100%.

## Evidence

<!-- image -->

<!-- image -->

- 1. Photographic evidence of lighting types used.
- 2. Copy of building plans highlighting areas which use the mentioned lighting types.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance ENE 27 - Automatic lighting controls

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What percentage of the building floor area (not accessible to clients/customers) with access to daylight has fully functioning automatic controls with daylight sensors for lighting?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | 0%                                       |
| -         | >0% to ≤25%                              |
| -         | >25% to ≤50%                             |
| -         | >50% to ≤75%                             |
| -         | >75%                                     |

## Assessment criteria

-

## Evidence

- 1. Photographic evidence of installed daylight sensors.
- 2. Copy of building plans highlighting areas that use daylight sensors for lighting.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance ENE 28 - Occupancy sensors

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What percentage of the building floor area (not accessible to client/customers) has fully functioning occupancy sensors for lighting?

## Aim

This data is required to generate the asset energy rating.

## Available Credits

| Credits   | Input calculated in Asset Energy Model   |
|-----------|------------------------------------------|
| -         | Question not answered                    |
| -         | Don't know                               |
| -         | 0%                                       |
| -         | >0% to ≤25%                              |
| -         | >25% to ≤50%                             |
| -         | >50% to ≤75%                             |
| -         | >75%                                     |

## Assessment criteria

-

## Evidence

- 1. Photographic evidence of installed lighting sensors.
- 2. Copy of building plans highlighting areas which use occupancy sensors for lighting

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance ENE 29 - Benchmarking

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             3 | No                  |

## Question

Has the asset been assessed against a local or national energy performance standard?

## Aim

To  ascertain  whether  the  organization  has  benchmarked  their  asset  performance  against  a  national  energy performance standard.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         3 | Yes                   |

## Assessment criteria

- 1. Energy performance standards must be derived from relevant national policy framework.  An example would  be  the  U.S.  Department  of  Energy's  Building  Energy  Asset  Score  (Asset  Score)  is  a  national standardized tool for assessing the physical and structural energy efficiency of commercial and multifamily residential buildings.

## Evidence

- 1. Copy of a certificate which illustrates that the asset has been certified against the relevant local/national energy performance standards.

## Additional information

## About the Building Energy Asset Score

The Building Energy Asset Score is a national standardized tool for assessing the physical and structural energy efficiency of commercial and multifamily residential buildings. The Asset Score generates an Asset Score Report that enables users to compare the physical energy efficiency of buildings, communicate building efficiency to the marketplace, and identify opportunities to invest in energy efficiency upgrades. More information and access to the online tool can be found at http://energy.gov/eere/buildings/building-energy-asset-score.

## Other information

This question does not feed in to the energy model.

<!-- image -->

<!-- image -->

## Asset Performance ENE 30 - On-site renewables

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             5 | No                  |

## Question

What percentage of the total energy consumption is offset by on-site renewables and renewable micro grids?

## Aim

To  understand  if  renewable  energy  technologies  are  being  used  on  site  and  how  much  these  offset  energy requirements for the site.

## Available Credits

|   Credits | Answer option                                                 |
|-----------|---------------------------------------------------------------|
|         0 | Question not answered                                         |
|         0 | Don't know                                                    |
|         0 | There is no on-site or renewable micro grid energy generation |
|         1 | ≥0<5%                                                         |
|         2 | ≥5% to <10%                                                   |
|         3 | ≥10% to <15%                                                  |
|         4 | ≥15% to <20%                                                  |
|         5 | ≥20%                                                          |

## Assessment criteria

- 1. Calculating  energy  offset  should  be  done  by  the  following  formula  (all  figures  for  energy  should  be converted to kWh prior to calculation):

<!-- formula-not-decoded -->

per onsite used energy Total E 

annum annum per site on ies techno renewable from produced Energy Er  log

energy Offset Eo 

- 2. All  renewable  energy  generation  should  be  sub-metered.  This  metered  data  would  then  be  used  to calculate the proportion of renewable energy generated (in kWh).
- 3. Renewable energy produced on site needs to be used directly, fed into the grid and/or stored for later use.

<!-- image -->

<!-- image -->

- 4. For the purposes of BREEAM USA In-Use, energy from renewable sources means energy from renewable non-fossil fuel sources, namely wind, solar, heat pumps (aerothermal, geothermal, hydrothermal) and ocean  energy,  hydropower,  biomass,  landfill  gas,  sewage  treatment  plant  gas  and  bio  gases.    Full definitions of these are found under the Additional Information section.

The following requirements must also be met:

- a. There must be a Private wire arrangement directly supplying energy produced to the building under assessment.
- b. Where  the  state  in  which  the  asset  being  assessed  is  located  has  an  independent  state certification program for installers of small scale renewable energy or Combined Heat and Power systems, these technologies must be certified in accordance with the state scheme.
- c. The accreditation program must align with the relevant state directives or standards.
- d. Air source heat pumps can only be considered as a renewable technology when used in heating mode. Please contact BRE Global Limited for more information on accounting for energy from heat pumps.
- Where independent accreditation programs do not exist in the state, the Client must demonstrate they have investigated the competence of the installer selected to install the LZC technology. The Client must also demonstrate that they are confident the installers have the skill and competence to install the technology appropriately.

Other systems may be acceptable as part of a LZC strategy under this issue but are not inherently considered  as  LZC  technologies.  Acceptability  will  be  dependent  on  the  nature  of  the  system proposed and the carbon benefits achieved. The BREEAM Assessor must confirm acceptability with BRE Global Limited if in doubt.

- 5. Simply signing up to a renewable energy purchasing program is NOT considered  to  be  an  acceptable means of demonstrating compliance with the criteria.

## Evidence

- 1. Photographic evidence of on-site renewable energy sources or community renewable energy programs
- 2. Yearly energy bills
- 3. Yearly metering data
- 4. Data sources created through amalgamation of energy bills or metering data (Excel Spread sheets for example)

## Additional information

## Relevant definitions

Aerothermal energy means energy stored in the form of heat in the ambient air;

Geothermal energy means energy stored in the form of heat beneath the surface of solid earth;

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

Hydrothermal energy means energy stored in the form of heat in surface water;

Biomass means the biodegradable fraction of products, waste and residues from biological origin from agriculture (including vegetal and animal substances), forestry and related industries including fisheries and aquaculture, as well as the biodegradable fraction of industrial and municipal waste;

Bioliquids means liquid fuel for energy purposes other than for transport, including electricity and heating and cooling, produced from biomass;

Biofuels means liquid or gaseous fuel for transport produced from biomass.

## Other information

This question does not feed into the energy model.

Community energy projects have an emphasis on local engagement, local leadership and control and the local community benefiting collectively from the outcomes. Community-led action can often tackle challenging issues around energy, with community groups well placed to understand their local areas and to bring people together with common purpose.

Examples include (but are not limited to):

-  Community-owned  renewable  electricity  installations  such  as  solar  photovoltaic  (PV)  panels,  wind turbines or hydroelectric generation.
-  Members of the community jointly switching to a renewable heat source such as a heat pump or biomass boiler.

<!-- image -->

<!-- image -->

## Transport

## Category summary table

| Issue Reference         | Title                         |   Credits available |
|-------------------------|-------------------------------|---------------------|
| TRA 01                  | Cyclist facilities            |                   4 |
| TRA 02                  | Proximity to public transport |                   8 |
| TRA 03                  | Proximity to amenities        |                   4 |
| TRA 04                  | Pedestrian and cyclist safety |                   2 |
| Total credits available | Total credits available       |                  18 |

<!-- image -->

<!-- image -->

## Asset Performance TRA 01 - Cyclist facilities

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What provisions are available to cyclists?

## Aim

To encourage building users to cycle by ensuring adequate provision of cyclist facilities.

## Available Credits

|   Credits | Answer option                                                                                                                                                                                             |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                                                                     |
|         0 | Don't know                                                                                                                                                                                                |
|         0 | No                                                                                                                                                                                                        |
|         1 | Well-lit secure cycle racks are in place                                                                                                                                                                  |
|         2 | Well-lit secure cycle racks and gender-specific changing facilities or individual cubicles (including lockers) in place                                                                                   |
|         3 | Well-lit secure cycle racks, gender-specific changing facilities or individual cubicles, and shower facilities (including lockers) in place                                                               |
|         4 | Well-lit secure cycle racks, gender-specific changing facilities or individual cubicles, and shower facilities (including lockers), and a ventilated drying area to hang wet clothes in a sheltered space |
|         0 | Other                                                                                                                                                                                                     |

## Assessment criteria

- 1. Compliant cycle storage facilities (see definition under Additional Information section) must be provided for a percentage of staff in accordance with the following figures:
- a. 10% of staff numbers for organizations for the first 500 staff PLUS
- b. 7% of staff numbers for organizations for the next 501 - 1000 staff PLUS
- c. 5% of staff numbers for organizations for the next 1000+ staff

For assets where the majority of building users are not staff, e.g. retail centers, the above requirements apply to staff only. In addition, the following must be provided for visitors:

- d. 5% of the total number of customer parking lot spaces (excluding disabled spaces and parent-andchild spaces where provided). This is subject to providing a minimum of 10 cycle racks. Any asset that provides at least 50 customer cycle storage spaces will comply regardless of the number of

<!-- image -->

<!-- image -->

parking spaces. The staff spaces must be provided in addition to customer spaces and while they do not need to be separate from customer spaces, this is encouraged.

## 2. Cycle rack requirements:

- a. Fixtures to lock bicycles are not required for locked sheds.
- b. The majority of racks are within 329 feet of the building entrance.

## 3. Lockers:

The number of lockers is at least equal to the number of cycle spaces provided, and these should be accessible by both male and female users. For assets where the majority of building users are not staff, e.g. retail centers, this requirement applies to staff only.

## 4. Shower requirements:

- a. One shower is provided for every 10 cycle storage racks and both male and female users  are accommodated.
- b. These are available for others to use in addition to cyclists.

For assets where the majority of building users are not staff, e.g. retails centers, this requirement applies to staff only.

## 5. Drying space:

Should be a specially designed and designated space (a plant room  does not comply) and heating/ventilation should be adequate. For assets where the majority of building users are not staff, e.g. retails centers, this requirement applies to staff only.

## 6. Proximity to public transport:

For sites where at least 50% of the available credits for BREEAM USA In-Use issue TRA 02 Proximity to public transport have been awarded (rounded to the nearest whole credit), the number of compliant cycle spaces  can  be  reduced  by  50%.  This  reduction  will  also  reduce  the  requirement  for  compliant shower/lockers by the same margin.

## 7. Public bicycle sharing systems:

Bicycle sharing systems are increasingly popular and diverse systems have appeared over the past few years in major cities and towns whereby a number of bicycles are made available for shared use amongst people who do not own a bicycle. The central concept of many of the systems is free or affordable access to  bicycles  for  city  transport  in  order  to  reduce  the  use  of  automobiles  for  short  trips  inside  the  city thereby diminishing traffic congestion, noise and air-pollution.

Up to 50% of the BREEAM cycle racks requirement may be provided by a public bicycle sharing system where it complies with the following:

- a. The program is implemented by the municipality or through a public-private partnership.
- b. The system must be open to casual users who wish to use them for one-way rides to work, education or shopping centers.

<!-- image -->

<!-- image -->

- c. Bicycles are available at unattended urban locations; and they operate in a manner that could be seen as 'bicycle transit'.
- d. Service terminals must be available throughout the city.
- e. The average distance between service terminals is 1,641 feet maximum in inner city areas.
- f. A service terminal is available within 1,641 feet of the main building entrance.
- g. The station terminals do not need to comply with the cycle rack requirements listed above.

The number of compliant facilities is calculated based on the total number of cycle racks required. For retail projects, public bicycle racks can also count towards the number of customer cycle racks required (i.e. whereas the total number of cycle racks may be reduced by 50%, the number of compliant facilities may not be reduced).

## Evidence

- 1. Photographic evidence of (where applicable):
- a. cycle racks
- b. showers
- c. lockers
- d. changing facilities
- e. drying space

## Additional information

## Other information

If the number of cycling facilities that should be supplied is not a whole number, it must be rounded up to the nearest whole number. For example, where the number of cycling facilities that should be provided is calculated to be 10.2, the actual number of facilities that must be provided is 11.

<!-- image -->

<!-- image -->

## Asset Performance TRA 02 - Proximity to public transport

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             8 | No                  |

## Question

Is the asset within walking distance of public transport networks that operate a frequent service?

## Aim

To ensure appropriate public transport provision is available to building occupants.

## Available Credits

|   Credits | Answer option                                                                                                                                 |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                         |
|         0 | Don't know                                                                                                                                    |
|         1 | Public transport network over 0.75 miles away from the building via a safe pedestrian route, with a 30 minute service frequency at peak times |
|         2 | Public transport network over 0.75 miles away from the building via a safe pedestrian route, with a 15 minute service frequency at peak times |
|         3 | Public transport network within 0.75 miles of the building via a safe pedestrian route, with a 30 minute service frequency at peak times      |
|         4 | A chartered bus service is provided at the beginning and end of the working day                                                               |
|         4 | Public transport network within 1,641 feet of the building via a safe pedestrian route, with a 30 minute service frequency at peak times      |
|         6 | Public transport network within 0.75 miles of the building via a safe pedestrian route, with a 15 minute service frequency at peak times      |
|         8 | Public transport network within 1,641 feet of the building via a safe pedestrian route, with a 15 minute service frequency at peak times      |
|         0 | No public transport network in place that meets the above criteria                                                                            |
|         0 | Other                                                                                                                                         |

## Assessment criteria

- 1. The distance must be measured via safe pedestrian routes; such as sidewalks and safe crossing points, or, where provided, dedicated pedestrian crossing points. The distance should NOT be measured in a straight line.

## Evidence

<!-- image -->

<!-- image -->

- 1. Annotated map demonstrating the route and distance to public transport nodes.
- 2. Photographic evidence public transport networks and safe pedestrian route(s).
- 3. Copies of public transport network timetables.

## Additional information

## Relevant definitions

Safe pedestrian routes include, but are not limited to: sidewalks and safe crossing points or, where provided, dedicated pedestrian crossing points.

<!-- image -->

<!-- image -->

## Asset Performance TRA 03 - Proximity to amenities

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is the asset within walking distance of amenities?

## Aim

To ensure appropriate amenities are available to building occupants.

## Available Credits

|   Credits | Answer option                                                                                                                                             |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                     |
|         0 | Don't know                                                                                                                                                |
|         1 | A café or similar type of food service within 0.75 miles of the building via a safe pedestrian route                                                      |
|         2 | A café or similar type of food service within 1,641 feet of the building via a safe pedestrian route                                                      |
|         2 | A café or similar type of food service and bank/cash machine or mail facilities or post box within 0.75 miles of the building via a safe pedestrian route |
|         4 | A café or similar type of food service and bank/cash machine or mail facilities or post box within 1,641 feet of the building via a safe pedestrian route |
|         0 | None of the above                                                                                                                                         |
|         0 | Other                                                                                                                                                     |

## Assessment criteria

- 1. All amenities listed must be open during employee working hours.

## Evidence

- 1. Where amenities listed are external to the asset:
- a. Annotated map demonstrating the route and distance to amenities listed by the client.
- b. Photographic evidence of listed amenities and safe pedestrian route(s).
- 2. Where amenities listed are contained within the asset:
- a. Asset floor plans with location of amenities indicated.
- b. Photographic evidence of listed amenities and safe pedestrian route(s).

<!-- image -->

<!-- image -->

## Additional information

## Relevant definitions

Safe pedestrian routes include, but are not limited to: sidewalks and safe crossing points or, where provided, dedicated pedestrian crossing points.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Asset Performance TRA 04 - Pedestrian and cyclist safety

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are  service  delivery  access  points,  routes,  and  maneuvering  areas  on-site  independent  from  parking  areas, pedestrian, and cyclist access points and routes?

## Aim

To recognize and encourage the provision of safe and secure pedestrian and cycle access routes.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. If the building does not have any external areas and internal access is directly from the safe pedestrian routes, then the building assessed is compliant.

## Evidence

- 1. Copy of site map indicating location of service delivery areas in relation to other areas to indicate that these are separate.
- 2. Photographic evidence of the service delivery areas and safe pedestrian route(s)

## Additional information

## Other information

Safe pedestrian routes include, but are not limited to: sidewalks and safe crossing points or, where provided, dedicated pedestrian crossing points.

<!-- image -->

<!-- image -->

## Water

## Category summary table

| Issue Reference         | Title                                         |   Credits available |
|-------------------------|-----------------------------------------------|---------------------|
| WAT 01                  | Water metering                                |                   6 |
| WAT 02                  | Water efficient equipment: Toilets            |                   4 |
| WAT 03                  | Water efficient equipment: Urinals            |                   4 |
| WAT 04                  | Water efficient equipment: Hand washing sinks |                   4 |
| WAT 05                  | Water efficient equipment: Showers            |                   4 |
| WAT 06                  | Water efficient equipment: Appliances         |                   4 |
| WAT 07                  | Leak prevention                               |                   4 |
| WAT 08                  | Leak detection system                         |                   4 |
| WAT 09                  | Isolation valves                              |                   4 |
| WAT 10                  | Reducing utility-supplied water consumption   |                   2 |
| Total credits available | Total credits available                       |                  40 |

<!-- image -->

<!-- image -->

## Asset Performance WAT 01 - Water metering

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             6 | No                  |

## Question

To what level is water consumption metered?

## Aim

To ensure water consumption can be monitored and therefore enable building users to target reductions in water consumption.

## Available Credits

|   Credits | Answer option                                                                                                                                                                                                                                                                                         |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                                                                                                                                                                 |
|         0 | Don't know                                                                                                                                                                                                                                                                                            |
|         0 | Not metered                                                                                                                                                                                                                                                                                           |
|         2 | Site - Where water consumption is metered for the whole site                                                                                                                                                                                                                                          |
|         4 | Building - Where water consumption is metered at the whole building level                                                                                                                                                                                                                             |
|         6 | All water-consuming plant or building areas that consume 10% or more of the building's total water demand are either fitted with sub meters or have water monitoring equipment integral to the plant or area AND Where the building is multi-tenanted: water consumption is metered per tenanted area |
|         6 | No water supply to the building                                                                                                                                                                                                                                                                       |
|         0 | Other                                                                                                                                                                                                                                                                                                 |

## Assessment criteria

- 1. A water meter on the utility supply to the site or building (whichever is applicable) including where water is supplied via a well or other private source.
- 2. Evidence provided demonstrates that a water meter is installed on relevant water supplies to the specific response given in the credit criteria.
- 3. Each water meter has the ability to have instantaneous reading (e.g. has a pulsed output) and enables connection to a Building Management System (BMS) or similar for the monitoring of water consumption.
- 4. Where water is metered and monitored at site level, the water meters must measure all water that is utilized on site, including, but not limited to:

<!-- image -->

<!-- image -->

- a. Utility supply
- b. Well supply
- c. Rainwater harvesting
- d. Grey water harvesting
- 5. If there is no water supply to the building, the Assessor must validate this.

## Evidence

- 1. Copies of site/building/asset plans, indicating where water meters are located.
- 2. Photographic evidence of installed water meters.
- 3. Copy of most current water meter readings to confirm that all meters are working.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance WAT 02 - Water efficient equipment: Toilets

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of toilets have been fitted with low flush technologies?

## Aim

To reduce water consumption by encouraging the specification of water efficient toilets.

## Available Credits

|   Credits | Answer option                                                                        |
|-----------|--------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                |
|         0 | Don't know                                                                           |
|         0 | 0%                                                                                   |
|         1 | All toilets ≤1.6 gallons per flush                                                   |
|         2 | ≥75% of toilets ≤1.2 gallon per flush (all remaining toilets ≤1.6 gallons per flush) |
|         3 | All toilets ≤1.2 gallon per flush                                                    |
|         4 | ≥50% of toilets ≤0.8 gallon per flush (all remaining toilets ≤1.2 gallon per flush)  |

## Assessment criteria

- 1. An adequate proportion of toilets within the asset need to be checked by the Assessor. It is not necessary to check all toilets. At least 10% of toilets within the building should be observed.
- 2. For dual flush toilets the effective flush volume will need to be calculated, an explanation and worked example is available in the additional information section.

## Evidence

- 1. Manufacturer/supplier literature of installed toilets (if available).
- 2. Photographic evidence of low-flush toilets.
- 3. Copies of asset floor plans indicating the location and quantity of toilets.
- 4. If manufacturer information is unavailable:
- a. Photographic evidence of information on cistern to identify flow rate.
- b. Copy of liaisons with manufacturer confirming toilet is low flush.
- c. Assessor comment to justify the reason why the toilet is deemed to be low flush.

## Additional information

<!-- image -->

<!-- image -->

## Relevant definitions

Effective flush volume (EFV) is the volume of water needed to clear the toilet and transport any contents far enough to avoid blocking the drain. The effective flush volume of a single flush toilet is the volume of water used for one flush.

The effective flush volume of a dual flush toilet is the ratio of full flush to reduced flush. This is taken to be one full flush for every three reduced flushes for non-residential buildings.

The effective flush volume would therefore be calculated as follows, using a 1.6/1.28 gallon dual flush volume toilet as an example:

<!-- formula-not-decoded -->

<!-- image -->

<!-- image -->

## Asset Performance WAT 03 - Water efficient equipment: Urinals

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Does the asset contain low water use or waterless urinals?

## Aim

To reduce water consumption.

## Available Credits

|   Credits | Answer option                                                                |
|-----------|------------------------------------------------------------------------------|
|         0 | Question not answered                                                        |
|         0 | Don't know                                                                   |
|         0 | No                                                                           |
|         1 | Timed flush urinals with ≤0.8 gallons per flush                              |
|         2 | Timed flush urinals with ≤0.3 gallons per flush                              |
|         2 | Passive Infra Red (PIR) controlled flush urinals with ≤0.8 gallons per flush |
|         3 | Passive Infra Red (PIR) controlled flush urinals with ≤0.3 gallons per flush |
|         4 | Waterless urinals                                                            |
|         4 | There are no urinals present in the asset                                    |

## Assessment criteria

- 1. Where multiple fittings are specified with various flow rates, the flow rates for each type of fitting will need to be calculated and the average flow rate determined by the Assessor.
- 2. Water  consumption  figures  will  need  to  be  derived  from  the  manufacturer's  product  information  to determine the consumption of the urinals as follows:
- a. Urinals: Flush volume in gallons/use for single use flush urinals.
- b. Cistern fed systems: The flushing frequency/hour and cistern capacity in gallons.
- 3. If  manufacturer information is unavailable it should be possible to tell whether urinals are waterless, however Assessor should provide the manufacturer and model number with photographic evidence if this is the case within the Assessor comments section of the assessment.
- 4. If there are no urinals within the asset, the Assessor must verify that this is due to one of the following reasons:
- a. The asset is female access only (for example, a women's dormitory)

<!-- image -->

<!-- image -->

- b. The asset contains unisex toilets only

## Evidence

- 1. An adequate proportion of urinals within the asset need to be checked by the Assessor to determine whether they are low flush / waterless, although it is not necessary to check them all. At least 10% of urinals within the building should be observed.
- 2. Photographic evidence of installed urinals.
- 3. Manufacturer/supplier literature of installed urinals (if available).
- 4. Copies of asset floor plans indicating the location and quantity of urinals highlighting which urinals are waterless.

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Asset Performance WAT 04 - Water efficient equipment: Hand washing sinks

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of the hand washing sink faucets are designed for low water use?

## Aim

To reduce water consumption by encouraging specification of water efficient equipment.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | 0%                    |
|         1 | ≥1 to <25%            |
|         2 | ≥25 to <50%           |
|         3 | ≥50 to <75%           |
|         4 | ≥75%                  |

## Assessment criteria

- 1. Hand washing sink faucets must have a maximum flow rate that is less than 1.6 gallons per minute.
- 2. Hand washing sink must have automatic control (e.g. push button with an auto shutoff or Active Infra-Red Faucets).

## Evidence

- 1. Photographic evidence of installed hand washing sinks.
- 2. Manufacturer/supplier literature of water efficient specifications.
- 3. Copies asset floor plans identifying the location and quantity of hand wash sinks.
- 4. An adequate proportion of hand washing sinks within the asset must be checked by the Assessor. It is not necessary to check all faucets. At least the following percentage of hand washing sinks within the asset must be observed and confirmed to meet the credit criteria:
- a. ≥1 to &lt;25 - 5%
- b. ≥25 to &lt;50 - 10%
- c. ≥50 to &lt;75 - 15%

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- d. &gt;75 - 20%
- 5. Manufacturer  documentation  should  be  provided  for  the  hand  washing  sink  faucets  that  have  been installed and observed within the building in order to confirm that they are low water use.
- 6. Where manufacturer information  is  not  available,  evidence  must  be  provided  that  confirms  that  the faucets  meet  the  stated  criteria.  This  could  include  measured  flow  rates  or  confirmation  from  the manufacturer that the installed faucets meet the criteria.

## Additional information

## Other information

Only faucets that are specifically used in hand washing sinks are applicable. This requirement does not apply to:

- a. 'Scrub' facilities in clinical areas of healthcare buildings
- b. Faucets provided to janitors and other cleaning staff
- c. Kitchen and external faucets
- d. Other  instances  where  such  fittings  would  be  inappropriate  for  medical/health-related  reasons  (such instances must be justified by the design the building management)

Types of low water use hand washing sink faucets include, but are not limited to:

- a. Spray faucets
- b. Aerated faucets
- c. Press or push button faucets with an auto-shutoff
- d. Faucets with user sensors such as Active Infra-Red faucets

<!-- image -->

<!-- image -->

## Asset Performance WAT 05 - Water efficient equipment: Showers

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of the showers is low water use?

## Aim

To reduce water consumption associated with the use of showers.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | 0                     |
|         1 | ≥1 to <25%            |
|         2 | ≥25 to <50%           |
|         3 | ≥50 to <75%           |
|         4 | ≥75%                  |
|         4 | No showers in place   |

## Assessment criteria

- 1. In order to be awarded the relevant credits showers must have a maximum flow rate less than 1.6 gallons per minute.

## Evidence

- 1. Photographic evidence of installed showers.
- 2. Manufacturer/supplier literature of water efficient specifications.
- 3. Copies of asset floor plans demonstrating location of changing facilities.
- 4. Manufacturer documentation should be provided for the showers that have been installed and observed within the building in order to confirm that they are low water use.
- 5. Where manufacturer information  is  not  available,  evidence  must  be  provided  that  confirms  that  the showers  meet  the  stated  criteria.  This  could  include  measured  flow  rates  or  confirmation  from  the manufacturer that the installed faucets meet the criteria.

## Additional information

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Other information

An adequate proportion of showers within the asset  need to  be  checked  by  the  Assessor,  although  it  is  not necessary to check them all. At least the following percentage of showers within the asset should be observed regarding credit criteria:

- a. ≥1 to &lt;25 - 5%
- b. ≥25 to &lt;50 - 10%
- c. ≥50 to &lt;75 - 15%
- d. &gt;75 - 20%

<!-- image -->

<!-- image -->

## Asset Performance WAT 06 - Water efficient equipment: Appliances

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of the water consuming appliances are low water use (dishwashers, washing machines)?

## Aim

To reduce water consumption associated with the use of appliances.

## Available Credits

|   Credits | Answer option                          |
|-----------|----------------------------------------|
|         0 | Question not answered                  |
|         0 | Don't know                             |
|         0 | 0%                                     |
|         1 | ≥1% to <25%                            |
|         2 | ≥25% to <50%                           |
|         3 | ≥50% to <75%                           |
|         4 | ≥75%                                   |
|         4 | No water consuming appliances in place |

## Assessment criteria

- 1. In order to be awarded the relevant credits, baseline water usage of installed equipment must be equal to or below the figures as outlined in Table 12.

Table 12:Water consumption baseline levels of appliances.

| Component                                      | Baseline              |
|------------------------------------------------|-----------------------|
| Commercial sized dishwasher                    | 1.8 gallons per rack  |
| Domestic sized dishwasher (if applicable)      | 3.4 gallons per cycle |
| Commercial/industrial sized washing machine    | 1.3 gallons per lb    |
| Domestic sized washing machine (if applicable) | 15.8 gallons per load |

- 2. Only water consuming appliances that are under the operational control of the building owner and/or are fitted by the building owner must be assessed.

<!-- image -->

<!-- image -->

## Evidence

- 1. Photographic evidence of listed appliances.
- 2. Manufacturer specifications of appliances installed in the asset.
- 3. Copies of asset floor plans with marked location of appliances installed.

## Additional information

## Relevant definitions

Appliances : products with a useful life of approximately two or more years and that are replaced infrequently.

<!-- image -->

<!-- image -->

## Asset Performance WAT 07 - Leak detection system

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Does the asset have an automated leak detection system?

## Aim

To reduce the impact of water leaks that may otherwise go undetected.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. A leak detection system detects higher than normal flow rates at meters and/or sub-meters. It does not necessarily require a system that directly detects water leakage along part or the whole length of the water supply system. The system can be flow based or sensor based.
- 2. The leak detection system should be:
- a. Able to easily identify any detected leaks
- b. Activated when a continuous flow of water passes through the water meter at a flow rate above a pre-set minimum for a pre-set period of time
- 3. The system does not need to cut off the water supply when the alarm is triggered.
- 4. Where there is a water supply company meter at the site/building boundary, it may be necessary to install a separate flow meter (or alternative measurement system) just after the water supply company meter to  detect  leaks.  However,  if  the  water  supply  company  agrees  to  some  form  of  leak  detection  being installed on their meter, this would also be acceptable.

## Evidence

- 1. Photographic evidence of leak detection system.
- 2. Manufacturer specifications of system.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance WAT 08 - Leak prevention

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are toilet areas fitted with controls that isolate water supply when they are unoccupied?

## Aim

To reduce the impact of water leaks in areas that are not occupied that may otherwise go undetected.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. Shut off systems may control combined restrooms (for example the male and female restrooms within a core) provided that the source of the leak within that area can be isolated once the building is occupied (i.e. the facilities management team are able to pin point the position of the leak whether it is in the male or female restrooms).
- 2. Proximity detection shut off is not required for each individual toilet, but the requirement is for the cold water supply to be isolated for each restroom block on a floor.
- 3. The requirements of this credit apply to facilities with a single restroom (potentially within smaller or low occupancy  buildings).  In  these  instances,  shut-off  can  be  provided  via  the  same  switch  that  controls lighting (whether proximity detection or a manual switch). Programmable timed controllers linked to the shut-off device are an acceptable means of compliance for facilities in this type of space, where constant use is to be expected during operating hours.

## Evidence

- 1. Photographic evidence of water shut off controls.
- 2. Manufacturer specifications of shut off controls (if available).
- 3. Systematic diagram showing the areas of isolation.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance WAT 09 - Isolation valves

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of water using appliances have isolation valves fitted?

## Aim

To minimize unnecessary water consumption due to defects and to minimize disruption during maintenance.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | 0%                    |
|         1 | ≥1% to <25%           |
|         2 | ≥25% to <50%          |
|         3 | ≥50% to <75%          |
|         4 | ≥75%                  |

## Assessment criteria

- 1. Evidence illustrates that isolation valves are installed for relevant equipment within the asset. Relevant equipment includes (but is not limited to):
- a. Hand washing sink
- b. Shower
- c. Toilet
- d. Urinal
- e. Washing machine
- f. Dishwasher
- g. Refrigerator/ice machine
- 2. If isolation valves are fitted to areas in which water using appliances are installed, such as shower blocks and restroom areas, the  aim of  the  credit  would  be  met.  These  areas  can  be  included  in  the  overall percentage.
- 3. Isolation valves are classified as any valve in the pipe that prevents the flow of water to specific equipment (for example, toilets).

<!-- image -->

<!-- image -->

- 4. Isolation valves must be easily accessible.

## Evidence

- 1. Photographic evidence of water isolation controls.
- 2. Manufacturer specifications of isolation controls (if available).

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Asset Performance WAT 10 - Reducing utility-supplied water consumption

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Does the asset use site-derived alternative water supply for any use?

## Aim

To reduce the demand for utility-supplied water within the asset.

## Available Credits

|   Credits | Answer option                                                                                  |
|-----------|------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                          |
|         0 | Don't know                                                                                     |
|         0 | No                                                                                             |
|         2 | Legislative requirements prevent use of site-derived alternative water supply within the asset |
|         2 | Yes                                                                                            |

## Assessment criteria

- 1. Both potable and non-potable water obtained from non-utility sources count towards the credit criteria. Sources might include (but are not limited to):
- a. Grey  water  such  as  reclaimed  wastewater,  refrigeration  system  condensate,  ice  machine condensate, steam system condensate
- b. Rain water
- c. Well water

## Evidence

- 1. Photographic evidence of site-derived alternative water source.
- 2. Manufacturer information.
- 3. Where legislative requirements prevent the use of site-derived alternative water supply, copy of relevant legislation.

## Additional information

-

<!-- image -->

<!-- image -->

## Materials

## Category summary table

| Issue Reference         | Title                    |   Credits available |
|-------------------------|--------------------------|---------------------|
| MAT 01                  | Condition survey         |                   4 |
| MAT 02                  | Security advice          |                   4 |
| MAT 03                  | Intruder alarm system    |                   4 |
| MAT 04                  | Alarm system monitoring  |                   4 |
| MAT 05                  | Natural hazards          |                   4 |
| MAT 06                  | Future adaptation        |                   4 |
| MAT 07                  | Designing for robustness |                   2 |
| Total credits available | Total credits available  |                  26 |

<!-- image -->

<!-- image -->

## Asset Performance MAT 01 - Condition survey

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

If  a  condition  survey  has  been  completed  within  the  last  5  years,  has  work  been  conducted  to  rectify  any issues/defects identified?

## Aim

To encourage asset/property owners to understand the physical condition of their property, and manage any deficiencies  to  structural,  mechanical,  electrical,  plumbing,  fire  protection,  communications  and  life  safety systems.

## Available Credits

|   Credits | Answer option                                                                                                                                                    |
|-----------|------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                            |
|         0 | Don't know                                                                                                                                                       |
|         0 | Asset is over 5 years old and a condition survey has not been carried out within the last 5 years                                                                |
|         0 | A condition survey has been carried out, however no work has been carried out to rectify issues/defects identified                                               |
|         1 | A condition survey has been carried out and an action plan is in place which establishes when issues will be rectified                                           |
|         2 | A condition survey has been carried out and all major issues/defects have been rectified                                                                         |
|         3 | A condition survey has been carried out and all major issues/defects have been rectified and an action plan confirms when the remaining issues will be rectified |
|         4 | A condition survey has been carried out and all identified issues/defects have been rectified                                                                    |
|         4 | The asset is less than 5 years old and no condition survey has been undertaken                                                                                   |
|         0 | Other                                                                                                                                                            |

## Assessment criteria

- 1. A condition survey should be conducted by a competent person and assess the condition of the asset, in terms of the main building elements; both external/internal envelope and equipment.
- 2. A condition survey typically includes (but is not limited to):
- a. Structural condition
- b. Condition of mechanical components

<!-- image -->

<!-- image -->

- c. Condition of electrical components
- d. Condition of plumbing
- e. Fire protection
- f. Communications and life safety systems
- g. Health and Safety conditions and environmental conditions; including, but not limited to:
- i. Damp
- ii. Cold
- iii. Drafts
- iv. Acoustic and noise penetration
- v. Ventilation
- vi. Daylight
- 3. Criteria for repairing or renewing defective elements should be established to ensure work prioritization.

## Evidence

- 1. Records of previous condition surveys.
- 2. Copy of action plan.
- 3. Photographic and/or documentation to demonstrate the address of defects.
- 4. Assets that are less than 5 years old will require appropriate public records of property registration to demonstrate the building's age.

## Additional information

## Relevant definitions

Competent  person: a  person  that  is  trained  and  qualified  to  conduct  condition  surveys  in  accordance  with legislative requirements.

Major issues are issues that need to be addressed in order for the building to operate and function correctly and do not directly adversely affect the health of the occupants.

Minor issues are issues that can be addressed at a later stage as these do not directly adversely affect the health of the occupants or the operation of the building.

<!-- image -->

<!-- image -->

## Asset Performance MAT 02 - Security advice

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

How were security measures for the building and its content decided upon?

## Aim

To ensure all property related security issues are identified by a competent third-party organization and addressed in order to reduce risks from crime.

## Available Credits

|   Credits | Answer option                                                                                                                                               |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                       |
|         0 | Don't know                                                                                                                                                  |
|         0 | No security measures in place (other than locks for doors)                                                                                                  |
|         1 | A competent third-party organization was consulted to identify security issues and minor issues have been addressed in accordance to the suggested actions  |
|         2 | Acompetent third-party organization wasconsulted to identify security issues andall major issues have been addressed in accordance to the suggested actions |
|         4 | A competent third-party organization was consulted to identify security issues and all identified issues/defects have been rectified                        |
|         0 | Other                                                                                                                                                       |

## Assessment criteria

- 1. A consultation involving a competent third-party organization has been carried out to identify potential weaknesses of property perimeters and building interiors.
- 2. Issues raised by consultation are addressed in accordance with report recommendations.

## Evidence

- 1. Copy of the report and actions raised from the survey by a suitably competent and qualified third-party organization.
- 2. Photographic evidence and/or documentation to demonstrate the rectification of issues/defects.

## Additional information

## Relevant definitions

<!-- image -->

<!-- image -->

Competent third-party: an organization that has detailed knowledge of the security industry of the country in which the asset is located, with regards to apparatus and strategies that an organization might use to enhance the security of their asset. This includes knowing what is appropriate and why it is technically beneficial.

<!-- image -->

<!-- image -->

## Asset Performance MAT 03 - Intruder alarm system

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Has the asset been fitted with an intruder alarm system that is certified to National or International standard or is the asset manned by a security guard 24 hours a day?

## Aim

To ensure the asset is equipped with appropriate security systems to prevent any damage to the asset.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. If devices are installed a security grading should have been conducted to determine design requirements.
- 2. 24-hour guard security should be undertaken by trained staff either employed by the organization or contracted to look after the site.

## Evidence

- 1. Assets that have intruder alarms will require:
- a. Documentation demonstrating intruder alarm system is approved to an appropriate National or International standard.
- b. Photographic evidence of the intruder alarm system.
- 2. Assets that have 24-hour guard security will require:
- a. Company details and contract agreement of the organization providing security.

## Additional information

## Other information

A security grading is given to an alarm system by a certification body, e.g UL or LPCB. This might be useful as a particular alarm grading might be needed in order to qualify for insurance coverage on a business premises. This will be dependent on the nature of the risk that is being protected regarding the asset.

<!-- image -->

<!-- image -->

## Asset Performance MAT 04 - Alarm system monitoring

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are the alarm systems (fire, intruder) connected to a monitored facility that is operational 24 hours a day?

## Aim

To ensure an asset has appropriate response to a fire and break-in when the building is unoccupied.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. Alarm receiving centers (ARC) should be staffed at all times.
- 2. Emergency response procedures should be in place with contractors and emergency services to enable the ARC monitoring function to be maintained while the emergency incident is investigated.

## Evidence

- 1. Documentation confirming the asset alarm systems are connected to a monitored facility.
- 2. Relevant contractual documents with the monitoring facility.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance MAT 05 - Natural hazards

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Have emergency plans been developed to deal with threats from all relevant natural hazards?

## Aim

To ensure the asset is protected against the potential impacts of natural hazards.

## Available Credits

|   Credits | Answer option                                |
|-----------|----------------------------------------------|
|         0 | Question not answered                        |
|         0 | Don't know                                   |
|         0 | No                                           |
|         2 | Yes                                          |
|         4 | No, asset is in an area where no risks exist |

## Assessment criteria

- 1. The emergency plan includes a coherent emergency strategy for all relevant natural hazards for the time period specified.
- 2. Relevant  natural  hazard  risks/plans  should  have  been  identified  by  competent  individuals/relevant organizations.
- 3. Natural  hazards  are  natural  processes  or  phenomena  occurring  in  the  biosphere  or  crust  that  may constitute a damaging event. The list below is not intended to be exhaustive, but provides an indication of the type of hazards that should be considered to meet the definition. Other natural hazards may be relevant under this issue. Relevance will be dependent on local geography, geology, hydrology and climate factors  and  the  Assessor  should  be  satisfied  that  appropriate  local  expertise  has  been  sought  by  the client/design team to identify these fully:
- a. Floods (addressed in Asset Performance POL 02 - Flood risk assessment)
- b. Natural disasters of geological origin such as volcanic eruptions, earthquakes and landslides
- c. Natural disasters of climatic or meteorological origin such as droughts, avalanches, wave surges including tsunamis and tidal waves, and wind storms including cyclones, hurricanes, tornadoes, tropical storms, and typhoons
- d. Wildfires
- 4. Emergency plans have been delegated to relevant individuals within the organization.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- 5. If there is no perceived threat from natural hazards this should be outlined in appropriate documentation from a relevant authority or expert.

## Evidence

- 1. Copy of relevant natural hazard emergency plans.
- 2. For assets that list no natural hazard risk exists:
- a. Documented confirmation from relevant agency/experts that the asset is located in an area of no risk.

## Additional information

## Other information

The metric used to describe risk from a natural hazard is the return period or recurrence interval, a ratio that describes the time elapsed between incidences of the natural hazard in question. This metric is used as a rough estimate and will not predict the actual time period between natural hazards and is calculated using historical data.

<!-- image -->

<!-- image -->

## Asset Performance MAT 06 - Future adaptation

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Does the design of the asset allow future adaptation to meet changing demands such as variations in use and functionality?

## Aim

To recognize and encourage buildings which have been built to allow a degree of flexibility for future usage.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. The building should have been designed with a degree of flexibility to ensure that future changes in use are possible. This flexibility could consist of (but is not limited to):
- a. Partition walls that can be easily re-positioned.
- b. Circuitry/plumbing  that  can  be  easily  removed/adapted  when  areas  are  unoccupied  or  when there is increased usage required; for example lighting removal or addition etc.
- c. Other design features deemed suitable by the Assessor.

## Evidence

- 1. Photographic evidence of (internal) design features that allow for flexibility as stated or deemed relevant by the Assessor.
- 2. Plans, studies, reports or other documentation that reflect that functional adaptability was taken into consideration during the design process.

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Asset Performance MAT 07 - Designing for robustness

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Does the asset contain features that protect exposed elements of the building and landscaping from damage from pedestrian traffic, internal vehicular/cart movement, and external vehicular collision?

## Aim

To minimize the frequency of building part replacement, maximizing materials optimization.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Examples of features that protect exposed elements of the building include, but are not limited to:
- a. Asset walls separated from vehicular traffic by a path or barrier
- b. Wall/corner guards
- c. Traffic posts
- 2. Examples of features that protect exposed elements of landscaping include, but are not limited to:
- a. Pathways which are easily accessible and dissuade building users to walk across landscaped areas
- b. Landscaped areas are fenced off

## Evidence

- 1. Photographic evidence of asset protection infrastructure listed by the client.
- 2. Plans, studies, reports or other documentation that reflect that robustness was taken into consideration during the design process.

## Additional information

-

<!-- image -->

<!-- image -->

## Waste

## Category summary table

| Issue Reference         | Title                        |   Credits available |
|-------------------------|------------------------------|---------------------|
| WST 01                  | Storage of operational waste |                   4 |
| Total credits available | Total credits available      |                   4 |

<!-- image -->

<!-- image -->

## Asset Performance WST 01 - Storage of operational waste

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is waste collected and separated at a central location?

## Aim

To ensure assets have adequate space for waste stream separation on site, allowing for recycling to take place and thus reduce waste being sent to landfill or for incineration.

## Available Credits

|   Credits | Answer option                                                                                                                       |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                               |
|         0 | Don't know                                                                                                                          |
|         0 | No                                                                                                                                  |
|         1 | Sufficient space to separate 1 waste stream                                                                                         |
|         2 | Sufficient space to separate 2 waste stream or, where waste is collected commingled, separated in 2 waste streams off-site          |
|         3 | Sufficient space to separate 3 waste stream or, where waste is collected commingled, separated in 3 waste streams off-site          |
|         4 | Sufficient space to separate 4 or more waste streams or, where waste is collected commingled, separated in 4 waste streams off-site |
|         0 | Other                                                                                                                               |

## Assessment criteria

- 1. Separate containers should be provided for different waste streams (if this is necessary), examples of these include (but are not limited to):
- a. Glass
- b. Paper
- c. Aluminum cans
- d. Plastic
- e. Other
- 2. Different colored glass separation is classed as one waste stream.

<!-- image -->

<!-- image -->

- 3. If recyclables are stored or collected in the same container (commingled), the Assessor must verify that the waste collector separates the commingled waste in the identified waste streams.
- 4. Containers located in this central area should:
- a. Be grouped together
- b. Be easily identifiable in terms of the waste streams they hold
- 5. Containers should be in an appropriate location, easily accessible to those responsible for disposing of waste.

## Evidence

- 1. Photographic evidence of the central storage space.
- 2. If waste is commingled, records from waste collector that commingled waste is separated in the waste streams as identified.

## Additional information

## Other information

Commingled recycling allows for mixed recyclables to be collected in one container. Recyclable materials including glass,  plastics,  cardboard,  paper,  metals  and  aluminum  cans  and  containers  make  up  commingled  recycling. Compostable materials should be collected separately from recyclables.

<!-- image -->

<!-- image -->

## Land Use and Ecology

## Category summary table

| Issue Reference         | Title                               |   Credits available |
|-------------------------|-------------------------------------|---------------------|
| LE 01                   | Planted area                        |                   4 |
| LE 02                   | Ecological features of planted area |                   2 |
| Total credits available | Total credits available             |                   6 |

<!-- image -->

<!-- image -->

## Asset Performance LE 01 - Planted area

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of the asset's footprint has been planted?

## Aim

To measure and encourage planted areas within the asset's footprint that enhance the asset's site ecology.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | 0%                    |
|         1 | ≤10%                  |
|         2 | >10% to ≤40%          |
|         3 | >40% to ≤70%          |
|         4 | >70% to 100%          |

## Assessment criteria

- 1. Planted area can contain or be a mix of horizontal and vertical planting.
- 2. Vertical habitats or green walls can be:
- a. Free standing or part of the building, as long as these are located within the asset's footprint.
- b. Partially or completely covered with vegetation and, in some cases, soil or an inorganic growing medium.

## Evidence

- 1. Visual inspection of planted areas and ecological structures.
- 2. Photographic evidence of planted areas and/or installed ecological structures.

## Additional information

## Relevant definitions

Green roof: A  green roof is a roof that is partially or completely covered with vegetation and soil or another growing medium, situated on top of a waterproof membrane. These systems can be either intensive or extensive.

<!-- image -->

<!-- image -->

- a. Intensive Green roof systems have a deep growing medium, which allow the establishment of trees and shrubs.  The  depth  of  the  growing  medium  requires  extra  loading  requirements  within  the  holding structure and requires a complex irrigation system for maintenance.
- b. Extensive green roof systems have a  thin growing medium and require minimal maintenance, and in general do not require irrigation.

Brown roof: A  brown roof allows local plant species to populate the roof over time. Brown roofs are crafted primarily to replicate local brownfield conditions through the use of by-products of developments: Brick rubble, crushed  concrete,  and  subsoils.  Such  designs  are  naturally  colonized  by  vegetation,  non-vegetated  loose substrates also provide habitat for a range of invertebrates and birds.

Planted Area: Horizontal planted areas can be partially or completely covered in vegetation but cannot be bare soil.

<!-- image -->

<!-- image -->

## Asset Performance LE 02 - Ecological features of planted area

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What ecological features have been planted/installed in the planted area(s) of the asset's footprint?

## Aim

To measure and recognize ecological features that have been installed in the planted areas of the asset's footprint in order to improve the ecological value of the site.

## Available Credits

|   Credits | Answer option                                                                             |
|-----------|-------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                     |
|         0 | Don't know                                                                                |
|         0 | No                                                                                        |
|         2 | Planters (containing living plants) outside                                               |
|         2 | Traditional planted areas, such as planting in parking lots and planting around the asset |
|         2 | Other planted areas, such as green roofs and green walls                                  |
|         2 | Features to assist local fauna                                                            |
|         0 | Other                                                                                     |

## Assessment criteria

- 1. Native floral species or those with a known attraction or benefit to local wildlife can be considered to enhance the ecological value.
- 2. Features to assist local fauna include (but are not limited to):
- a. Bird boxes
- b. Bat boxes
- c. Insect boxes

Note: Assessors must verify that these features are installed and maintained correctly.

- 3. Planted areas must be of a viable size to support the flora and fauna within them.

## Evidence

- 1. Visual inspection of ecological structures.
- 2. Photographic evidence of installed ecological structures.

<!-- image -->

<!-- image -->

## Pollution

## Category summary table

| Issue Reference         | Title                                  |   Credits available |
|-------------------------|----------------------------------------|---------------------|
| POL 01                  | Pollution prevention                   |                   4 |
| POL 02                  | Flood risk assessment                  |                   4 |
| POL 03                  | Surface water runoff impact mitigation |                   2 |
| POL 04                  | Impacts of refrigerants                |                   4 |
| POL 05                  | Refrigerant leak detection system      |                   4 |
| POL 06                  | NO x emissions                         |                   4 |
| Total credits available | Total credits available                |                  22 |

<!-- image -->

<!-- image -->

## Asset Performance POL 01 - Pollution prevention

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are there light liquid separators fitted within the drainage  system  to  vehicular areas and/or  grease separators/filters for kitchen facilities, where required?

## Aim

To  reduce  the  risk  of  polluting  natural  waterways  through  contaminated  surface  run-off  and/or  grease  from kitchen facilities entering drainage systems.

## Available Credits

|   Credits | Answer option                                                                                                                                                                       |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                                               |
|         0 | Don't know                                                                                                                                                                          |
|         0 | No                                                                                                                                                                                  |
|         4 | Yes, light liquid interceptors are installed within the drainage system to vehicular areas AND/OR grease separators/filters are installed within kitchen facilities, where required |
|         4 | Asset does not require light liquid separators or grease separators                                                                                                                 |

## Assessment criteria

- 1. Light liquid separators must be installed for all vehicular areas, and/or grease separators/filters must be installed within kitchen facilities, unless it can be demonstrated that they are not required. Where either of these areas is not present, the criterion only applies to the vehicular areas.  For example, if there are vehicular areas but no kitchen facilities, the criterion only applies to the vehicular areas.
- 2. Where it can be demonstrated that drainage or wash down facilities do not lead water from inside an underground or covered area to natural waterways, such areas comply with the requirements by default.
- 3. An asset will not require light liquid separators or grease separators/filters if there are no parking and/or kitchen facilities on site.
- 4. The following site areas (where present) require oil separators in surface water drainage systems:
- a. Parking lots larger than 8,611 ft  or with 50 or more parking spaces 2
- b. Smaller parking lots discharging to a sensitive environment
- c. Areas where delivery vehicles are parked or maneuvered

<!-- image -->

<!-- image -->

- d. Vehicle maintenance areas
- e. Roads
- f. Industrial sites where oil is stored or used

## Evidence

- 1. Photographic evidence of interceptor equipment on site.
- 2. Manufacturer details.
- 3. Site plans detailing location of interceptors.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance POL 02 - Flood risk assessment

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is the building located in a low or zero flood risk area?

## Aim

To encourage the identification of flood risk and implement mitigation measures, where required.

## Available Credits

|   Credits | Answer option                                              |
|-----------|------------------------------------------------------------|
|         0 | Question not answered                                      |
|         0 | Don't know                                                 |
|         1 | No, flood mitigation measures required but not implemented |
|         2 | No, flood mitigation measures required and implemented     |
|         4 | Yes                                                        |

## Assessment criteria

- 1. The level of flood risk is based on the level of risk for the zone in which the asset is located. These are:
- a. Asset is located in a high flood risk zone
- b. Asset is located in a medium flood risk zone
- c. Asset is located in a low flood risk zone
- d. Asset is located in a zero flood risk zone
- 2. Flooding from the following sources must be taken into account:
- a. Fluvial (rivers)
- b. Tidal (sea)
- c. Surface water: sheet run-off from adjacent land (urban or rural)
- d. Groundwater: most common in low-lying areas underlain by permeable rock (aquifers)
- e. Sewers: combined, foul or surface water sewers
- f. Reservoirs, canals and other artificial sources
- g. A nearby functional flood plain (a zone that comprises land where water has to flow or be stored in times of flood)

<!-- image -->

<!-- image -->

- 3. A Flood Risk Assessments (FRAs) should be carried out to identify the flood risk of the area in which the building is located.
- 4. FRAs are usually carried out during pre-construction as part of planning documentation; however postconstruction assessments also meet credit criteria.
- 5. FRAs need to be undertaken by the relevant organization/authority or a competent individual.
- 6. Where the asset is determined to be located in a low or zero flood risk area, no additional steps have to be taken to reduce and manage the impact of pollution associated with flooding.
- 7. It must be demonstrated that recommendations have been implemented.

## Evidence

- 1. FRA documentation from relevant body or competent individual.
- 2. Information regarding relevant qualifications and experience of the person/organization that has carried out the FRA.
- 3. Photographic evidence of FRA recommendation implementation.

## Additional information

## Relevant definitions

A competent individual will have qualifications and experience relevant to designing flood prevention measures and calculations. Where complex flooding calculations and prevention measures are required, this must be a specialist hydrological engineer.

<!-- image -->

<!-- image -->

## Asset Performance POL 03 - Surface water runoff impact mitigation

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are there measures in place to minimize the rate of surface water runoff from the site?

## Aim

To reduce the risk of waterway pollution and other environmental damage from storm water.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Appropriate measures to minimize surface water runoff include (but are not limited to):
- a. Low-impact Development (LID)
- b. Permeable surfaces
- c. Infiltration trenches
- d. (Roof) planting
- e. Rainwater tanks
- 2. Where applicable, measures should take account of the need to restrict discharge from chemical cleaning, which could include (but is not limited to):
- a. Secondary containment around drainage systems
- b. Double skinned containers
- c. Light liquid/oil separators
- d. Shut-off valves fitted to the site drainage system to prevent the escape of chemicals to natural watercourses (in the event of a spillage or secondary containment failure).

## Evidence

- 1. Annotated photographic evidence of on-site measures.

## Additional information

<!-- image -->

<!-- image -->

BREEAM USA In-Use Technical Manual (PD130)

Version 2.0: 2016, April 2019

## Relevant definitions

Secondary containment: a structure made of an impermeable material that forms a barrier to retain liquids.

<!-- image -->

<!-- image -->

## Asset Performance POL 04 - Impact of refrigerants

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What refrigerants are used in the asset refrigeration equipment?

## Aim

To encourage the use of refrigerants with a low global warming potential (GWP) in refrigerant equipment.

## Available Credits

|   Credits | Answer option                                                                                |
|-----------|----------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                        |
|         0 | Don't know                                                                                   |
|         0 | All refrigerants have a global warming potential of >10 (e.g. majority HFCs, HCFC, CFCs)     |
|         2 | All refrigerants have a global warming potential of ≤10 (e.g. Propane, Butane)               |
|         4 | All refrigerants have a global warming potential of ≤1 (e.g. Ammonia, Water, Carbon dioxide) |
|         4 | No refrigerants used                                                                         |
|         0 | Other                                                                                        |

## Assessment criteria

- 1. The scope of this question will exclude domestic-scale refrigeration equipment and small plug-in chillers with integral refrigeration plant. Such systems on average have a charge 11 pounds or less, therefore in most circumstances individually installed or small multiple installations will not fall within scope of this credit. However, the Assessor should ask the client organization to confirm that the total charge is ≤11lbs.
- 2. The issue applies to all equipment and areas using refrigerants including, but not limited to:
- a. Walk-in cold storage enclosures
- b. Cold store services including, but not limited to; chilled water pipe work, refrigerant pipe work and ductwork
- c. Comfort cooling
- 3. A list of typical refrigerants with a low GWP can be found in Table 13 in the additional information section of this issue.
- 4. This issue applies to refrigerants used in equipment that is installed on-site only.

## Evidence

- 1. Copy of manufacturer's information confirming the global warming potential of refrigerants used on site.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- 2. Photographic evidence of refrigerant packaging/systems (if necessary).
- 3. Statement from building manager indicating that the asset does not contain any systems that contain refrigerants.

## Additional information

## Relevant definitions

GWP : GWP is defined as the potential for global warming that a chemical has relative to 1 unit of carbon dioxide, the primary greenhouse gas. In determining the GWP of the refrigerant, the Intergovernmental Panel on Climate Change (IPCC) methodology using a 100-year Integrated Time Horizon (or ITH) should be applied.

Refrigerant: There are three main make-ups of refrigerants:

- Hydrogenated Fluorocarbon Refrigerants (HFCs) are made up of hydrogen, fluorine, and carbon. Because they do not use a chlorine atom (which is used in most refrigerants) they are known to be one of the least damaging to our ozone.
- Hydrogenated Chlorofluorocarbon Refrigerants (HCFCs) are made up of hydrogen, chlorine, fluorine, and carbon.  These  refrigerants  contain  minimal  amounts  of  chlorine;  they  are  not  as  detrimental  to  the environment as some other refrigerants.
- Chlorofluorocarbon Refrigerants (CFCs) contain chlorine, fluorine and carbon. These refrigerants carry high amounts of chlorine so they are known for being the most hazardous to the ozone layer.

The use of CFCs and HCFCs as refrigerants has been addressed under the Montreal Protocol. Phase out programs have been agreed resulting in these substances no longer being used as refrigerants in all new build and most existing  situations.  The  industry's  favored  replacements  are  currently  HFCs,  which  are  often  potent  global warming contributors. Hydrocarbons and ammonia-based refrigerants have low or zero GWP. These are now widely available and are valid alternatives to HFCs in all buildings, provided health and safety issues are fully addressed. United Nations Environment Programme (UNEP) hosts a HCFC Help Centre, which contains information about the management, phase out of and alternatives to HCFCs. TABLE 13 contains a list of common refrigerant types with a low GWP.

<!-- image -->

<!-- image -->

Table 13: Common refrigerant types with a low GWP

| R-Number   | Chemical name                 | GWP100-yr   |
|------------|-------------------------------|-------------|
| R-30       | Dichloromethane               | 9           |
| R-170      | Ethane                        | 3           |
| R-290      | Propane                       | 3           |
| R-600      | Butane                        | 3           |
| R-600a     | Isobutane                     | 3           |
| R-702      | Hydrogen                      | 5.8         |
| R-717      | Ammonia                       | 0           |
| R-718      | Water                         | <1          |
| R-729      | Air (nitrogen, oxygen, argon) | 0           |
| R-744      | Carbon dioxide                | 1           |
| R-1150     | Ethylene                      | 3           |
| R-1234yf   | 2,3,3,3-Tetrafluoropropene    | <1          |
| R-1270     | Propylene                     | 3           |

Sources: The United Nations Environment Programme (UNEP) '2010 Report of the Refrigeration, Air-conditioning and Heat Pumps Technical Options Committee'

EN 378-1:2008+A2:2012: Refrigerating systems and heat pumps - Safety and environmental requirements. Part 1: Basic requirements, definitions, classification and selection criteria - Annex E.

The Intergovernmental Panel on Climate Change 5th Assessment Report, Chapter 8, 'Anthropogenic and Natural Radiative Forcing', 2013

'Global  environmental  impacts  of  the  hydrogen  economy',  Derwent et  al , Int.  J.  Nuclear  Hydrogen  Production  and Application, Vol. 1, No. 1, 2006

<!-- image -->

<!-- image -->

## Asset Performance POL 05 - Refrigerant leak detection systems

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is there an automated refrigerant leak detection system in place for all equipment that use refrigerants?

## Aim

To reduce the level of greenhouse gas emissions related to the leakage of refrigerants.

## Available Credits

|   Credits | Answer option                                                                    |
|-----------|----------------------------------------------------------------------------------|
|         0 | Question not answered                                                            |
|         0 | Don't know                                                                       |
|         0 | No leak detection system in place                                                |
|         3 | Yes, warning alarm/lighting only                                                 |
|         4 | No refrigerants used                                                             |
|         4 | Yes, automatic shutdown and pump down of refrigerants and warning alarm/lighting |
|         0 | Other                                                                            |

## Assessment criteria

- 1. A leak detection system should be in place for systems that are installed in the building for the following uses, including, but not limited to:
- a. Comfort cooling
- b. Cold storage, including commercial food/drink display cabinets but excluding domestic appliances e.g. refrigerators and freezers
- c. Process based cooling loads e.g. servers/IT equipment
- 2. Refrigerant leak detection systems are not required and thus credits can be awarded if:
- a. Only small multiple hermetic systems are installed where the refrigerant charge in each unit is 11lbs or less.
- b. Environmentally benign refrigerants such as air and water, are used.
- c. Systems use solid refrigerants, where very little refrigerant will escape to the atmosphere in the event  of  system  failure  and  leakage.  This  must  be  confirmed  by  the  refrigeration  system manufacturer.

## Evidence

<!-- image -->

<!-- image -->

- 1. Operation and maintenance manuals detailing installation of leak detection system or site inspection.
- 2. In the case of solid refrigerants, manufacturer confirmation of minimal leak risk.

## Additional information

-

<!-- image -->

<!-- image -->

## Asset Performance POL 06 - NOx emissions

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Does the building generate nitrogen oxide (NOx) emissions as a result of any on-site combustion of fuel to meet space heating or hot water demand?

## Aim

To encourage and recognize the use of heating that minimizes NOx emissions.

## Available Credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | Yes                   |
|         4 | No                    |

## Assessment criteria

- 1. For  this  question  NOx  is  mainly  emitted  from  high  temperature combustion where  trace elements of nitrogen exist in the fuel, such as: coal, oil and gas etc. However high-temperature oxidation of molecular nitrogen in the air used for combustion also releases NOx, although temperatures need to be around 2,732°F (1,500°C) before this occurs.
- 2. If a 'No' answer is selected, Assessors must confirm that relevant equipment on site or within the asset does not utilize the fuel types that have been specified.

## Evidence

- 1. Copy of manufacturer's details for equipment installed and their dry NOX emissions rate in lb/Btu.
- 2. Photographic evidence of heating system(s).

## Additional information

## Relevant definitions

NOx emissions: NOx emissions are pollutant gases produced by the combustion of fuels. NOx reacts with heat and sunlight to produce ozone that can cause serious respiratory problems. It also reacts with water to produce acid rain, which has a detrimental effect on ecosystems.

<!-- image -->

<!-- image -->

## Part 2: Building Management

## Assessment of how the asset is managed and its operational performance

| Issue reference         | Categories              | Credits available   |
|-------------------------|-------------------------|---------------------|
| MAN                     | Management              | 46                  |
| HEA                     | Health &Wellbeing       | 37                  |
| ENE                     | Energy                  | 60                  |
| TRA                     | Transport               | -                   |
| WAT                     | Water                   | 26                  |
| MAT                     | Materials               | 20                  |
| WST                     | Waste                   | -                   |
| LE                      | Land Use & Ecology      | 10                  |
| POL                     | Pollution               | 24                  |
| Total credits available | Total credits available | 223                 |

<!-- image -->

<!-- image -->

## Management

## Category summary table

| Issue reference         | Title                                       |   Credits available |
|-------------------------|---------------------------------------------|---------------------|
| MAN01                   | Building user guide                         |                   2 |
| MAN02                   | Building user education                     |                   2 |
| MAN03                   | Building user information                   |                   2 |
| MAN04                   | Operation and maintenance manuals           |                   2 |
| MAN05                   | Maintenance procedures                      |                   6 |
| MAN06                   | Maintenance policy                          |                   4 |
| MAN07                   | Environmental policies and responsibilities |                   4 |
| MAN08                   | Environmental policies                      |                   4 |
| MAN09                   | Operating procedures: Energy reduction      |                   4 |
| MAN10                   | Ventilation system leak testing             |                   4 |
| MAN11                   | Green lease                                 |                   4 |
| MAN12                   | Building management system review           |                   4 |
| MAN13                   | Building adaptation                         |                   4 |
| Total credits available | Total credits available                     |                  46 |

<!-- image -->

<!-- image -->

## Building Management MAN 01 - Building user guide

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Has relevant information from the building user guide been made accessible to all building users?

## Aim

To  recognize  and  encourage  the  provision  of  appropriate  guidance  for  building  users  which  enables  them  to understand and use the building.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Dedicated building/site specific guidance for the non-technical building user. The purpose of the guide is to help building users access, understand and operate the building efficiently and in a manner in keeping with the original design intent.
- 2. A  Building  User  Guide  will  provide  easily  accessible  and  understandable  information  relevant  to  the following stakeholders:
- a. The building's staff (or where relevant residents)
- b. The non-technical facilities management team/building manager
- c. Other building users, e.g. visitors/community users
- 3. The content of the guide will be specific to the building type and end users, but broadly should include information on the following:
- a. Overview  of  the  building  and  its  environmental  strategy,  e.g.  energy/water/waste  efficiency policy/strategy and how users should engage with/deliver the policy/strategy
- b. Building services overview and access to controls, e.g. where to find them, what they control, how to operate effectively and efficiently etc.
- c. Pre-arrival information for visitors, e.g. access and security procedures/provisions
- d. Provision of, and access to, shared facilities
- e. Safety and emergency information/instructions

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- f. Building related operational procedures specific to building type/operation, e.g. laboratories
- g. Building related incident reporting/feedback arrangements
- h. Building related training information/links
- i. Provision of, and access to, transport facilities, e.g. public transport, cyclist facilities, pedestrian routes etc.
- j. Location of, and access to, local amenities
- k. Renovation, refurbishment and maintenance arrangements/considerations
- l. Links, references and relevant contact details
- 4. There is no requirement on the format the Building User Guide should take.

## Evidence

- 1. Copies of relevant sections of the Building User Guide.
- 2. Details how relevant information has been made accessible to building users, examples include (but are not limited to):
- a) training schedules
- b) copy of emails to (new) building users
- c) copy of information pack handed to new building users

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAN 02 - Building user education

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are  regular  meetings  or  formal  communications  scheduled  with  occupants  to  discuss  asset  related  issues (including environmental matters), and are such issues reported to the management?

## Aim

To  facilitate  structured  feedback  and  awareness  to  enable  management  staff  and  building  occupants  to understand how to better operate the building.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Meetings should be scheduled at appropriate intervals and  locations,  and  when  new  procedures  are adopted or systems/controls installed.
- 2. Formal communications should be scheduled at appropriate intervals, and when new procedures are adopted or systems/controls installed.
- 3. Formal communications include (but are not limited to):
- a. Standard feedback forms
- b. Dedicated email address
- c. Intranet feedback forms
- d. Standard forms in areas accessible by all staff

## Evidence

- 1. Formal organizational documentation, such as meeting minutes.
- 2. Confirm with meeting attendees (identified via documented minutes for example) that meetings take place at reasonable intervals.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAN 03 - Building user information

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is a notice board or display area present within the asset to provide staff and visitors with information relating to the environmental policies and/or performance of the asset?

## Aim

To recognize and encourage building management that informs staff and visitors about asset performance.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Evidence is provided to demonstrate that environmental matters related to the building/organization are communicated through the use of notice board(s) or building specific display areas.
- 2. Notice boards can report on information relating to:
- a. Health, Safety and Environmental policies
- b. Building/Organizational Operating Procedures
- c. Asset/organizational environmental performance
- d. Public transport
- e. Environmental best practice topics

## Evidence

- 1. Photographic evidence of notice board/display area.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAN 04 - Operation and maintenance manuals

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is a full set of operation and maintenance (O&amp;M) manuals available and accessible by building management/facilities management staff?

## Aim

To  ensure  adequate  technical  information  is  available  to  managers  and  contractors  carrying  out  necessary management, maintenance and refurbishment duties.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Building  O&amp;M manuals should cover all  current  and  relevant  building  services  and  building  elements which may include (but are not limited to):
- a. Heating and cooling systems
- b. Water distribution systems
- c. Ventilation systems
- d. Lighting systems
- e. External shading systems
- f. Construction/specification details for building envelope
- g. Renewable and low carbon technologies (where present)

## Evidence

- 1. List of all current and relevant building services and elements included in the O&amp;M manuals.
- 2. Photocopy/photographic evidence of the front cover and table of contents of the O&amp;M manuals.

## Additional information

## Other information

<!-- image -->

<!-- image -->

The  Assessor  is NOT required  to  assess  the  content  of  the  O&amp;M  manuals,  but  must  ensure  that  all  relevant documents are available and accessible.

Where a building is managed by a building management contractor the manuals may be kept off site, but it is important that the information is in a form that makes it easy for contractors to obtain copies and make use of them on site.

<!-- image -->

<!-- image -->

## Building Management MAN 05 - Maintenance procedures

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             6 | No                  |

## Question

Please indicate where there is a maintenance policy/procedure in place for the following building elements/services.

## Aim

To recognize and encourage:

-  best practice maintenance of building elements/services
-  the setting of periodic schedules to manage the efficiency of the assets infrastructure
-  procedures that ensure building equipment is working efficiently
-  that proactive and appropriate inspections are in place

## Available credits

|   Credits | Answer option                                                                 |
|-----------|-------------------------------------------------------------------------------|
|         0 | Question not answered                                                         |
|         0 | Don't know                                                                    |
|         2 | Building envelope                                                             |
|         2 | Heating, Ventilation and Cooling (HVAC) systems, as applicable, and hot water |
|         2 | Lighting                                                                      |

## Assessment criteria

- 1. In order to award the credits for HVAC systems, procedures should be in place to cover all HVAC systems, as applicable.
- 2. It  can  be  demonstrated  how  the  policy  is  implemented  at  the  local  level,  either  through  general organizational operation, or project related initiatives and management strategies.
- 3. The  maintenance  policy/procedure  should  include  an  established  periodic  scheduled  maintenance procedure allowing the building and its services to be maintained in good condition.
- 4. Maintenance reports should state as a minimum:
- a. Person or organization carrying out the maintenance
- b. Date the maintenance has been carried out
- c. Description of building service/element that has been maintained
- d. Outcomes of maintenance procedure

<!-- image -->

<!-- image -->

- e. Actions following the maintenance procedure
- f. Date indicating next maintenance interval

## Evidence

- 1. Formal organizational documentation illustrating maintenance schedules.
- 2. Photocopy of reports of last maintenance procedure for the systems specified. This could be a cover page and table of contents and must clearly state:
- a. Person or organization carrying out the maintenance
- b. Date the maintenance has been carried out
- c. Description of building service/element that has been maintained.

## Additional information

## Other information

- If a  building  is  mechanically  ventilated,  typically  all  aspects  would  be  in  place;  therefore,  maintenance policies/procedures should be in place to cover these.
- If  a  building  is  naturally  ventilated,  typically  no  aspects,  or  only  ventilation,  would  be  in  place;  therefore,  a maintenance policy/procedure for these aspects does not have to be in place.

<!-- image -->

<!-- image -->

## Building Management MAN 06 - Maintenance policy

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is/are the maintenance policy(ies) proactive or reactive?

## Aim

To recognize and encourage proactive maintenance policies which enable the efficient operation of the building.

## Available credits

|   Credits | Answer option                                                      |
|-----------|--------------------------------------------------------------------|
|         0 | Question not answered                                              |
|         0 | Don't know                                                         |
|         1 | Reactive policy only. Policy reviewed more than 1 year ago         |
|         2 | Reactive policy only. Policy reviewed within the last year         |
|         3 | Proactive maintenance policy. Policy reviewed more than 1 year ago |
|         4 | Proactive maintenance policy. Policy reviewed within the last year |
|         0 | Other                                                              |

## Assessment criteria

- 1. A reactive maintenance policy is a policy where maintenance is carried out when problems are reported.
- 2. A proactive maintenance policy is a policy where maintenance is planned with regular intervals with the aim to prevent faults or breakdowns from occurring.
- 3. Information within the policy outlines:
- a. The scope and aims of the policy
- b. Who has endorsed and has responsibility for that policy
- c. How it will be implemented and policy objectives achieved
- d. Schedule specifying what maintenance has been and will be undertaken at set intervals
- 4. The  maintenance  policy/procedure  should  include  an  established  periodic  scheduled  maintenance procedure allowing the building and plant to be maintained in good condition.
- 5. Maintenance policies should be regularly reviewed, at least when there are significant changes made to the building or equipment is replaced.

<!-- image -->

<!-- image -->

- 6. The  facilities  manager/building  manager  demonstrates  (i.e.  through  examples)  how  the  policy  is implemented and affected at the local level, either through general organizational operation, or project related initiatives and management strategies.

## Evidence

- 1. A copy of the maintenance policy.
- 2. A review schedule of the maintenance policy.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAN 07 - Environmental policies and responsibilities

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Has an environmental management policy or plan been developed by the building management organization?

## Aim

To recognize and encourage that environmental management provisions are in place.

## Available credits

|   Credits | Answer option                                                                                                                                          |
|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                  |
|         0 | Don't know                                                                                                                                             |
|         0 | No                                                                                                                                                     |
|         1 | The building management organization has developed and implemented an environmental policy or plan approved by the board of directors/senior managers  |
|         2 | The environmental policy or plan has been distributed throughout the building management organization and responsibilities have been set               |
|         3 | The building management organization has developed and implemented an environmental management policy or plan, including scope, objectives and targets |
|         4 | The environmental management policy or plan has been certified to ISO 14001 or equivalent standards                                                    |
|         0 | Other                                                                                                                                                  |

## Assessment criteria

- 1. Where the environmental management policy or plan has been ISO 14001 certified, the Assessor does not need to check its content or structure.
- 2. The environmental management policy or plan must be in use and the review process must ensure that targets are set and actions plans are completed.
- 3. The environmental management plan or policy must be available and accessible by all building users.

## Evidence

- 1. Signed copy of environmental policy document.
- 2. Evidence of communication of plan to staff.
- 3. List of responsibilities and persons identified as champions to help implement these responsibilities.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- 4. Where the Environmental Management System is third party certified: a copy of a valid Environmental Management System certificate must be provided.

## Additional information

## About ISO 14001

The  International  Organization  for  Standardization  (ISO)  14000  series  sets  the  criteria  for  companies  and organizations of all types to identify and appropriately manage their environmental impacts and responsibilities. The  ISO  14001  standard  maps  out  a  framework  that  an  organization  can  follow  to  set  up  an  effective environmental management system.  Third party certification provides assurance to all stakeholders that the environmental management system is meets the international standard and is effectively implemented in the organization.

All ISO standards are reviewed every five years to establish if a revision is required to keep it current and relevant for the marketplace.  Organizations currently certified to ISO 14001:2004 have three years to transition to the current standard, ISO 14001:2015.

## Other information

Tailored Environmental Management Systems that are verified by a competent independent third party Assessor could meet the requirements to achieve 4 credits provided that the certifying body is internationally recognized.

<!-- image -->

<!-- image -->

## Building Management MAN 08 - Environmental policies

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Does  the  building  management  team  have  an  environmental  management  policy  in  place  that  requires improvement targets to be met?

## Aim

To  recognize  and  encourage  policies  that  aim  to  reduce  the  assets  environmental  impacts  through  defined improvement targets.

## Available credits

|   Credits | Answer option                                                                                                                  |
|-----------|--------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                          |
|         0 | Don't know                                                                                                                     |
|         0 | No                                                                                                                             |
|         1 | Yes, improvement targets have been set for energy consumption                                                                  |
|         2 | Yes, improvement targets have been set for energy and water consumption                                                        |
|         2 | Yes, improvement targets have been set for energy and waste/recycling                                                          |
|         3 | Yes, improvement targets have been set for energy, water and waste/recycling                                                   |
|         4 | Yes, improvement targets have been set for all of the above, and additional resource performance and sustainability indicators |
|         0 | Other                                                                                                                          |

## Assessment criteria

- 1. Additional resource performance criteria could include biodiversity, pollution, procurement improvement etc.
- 2. The policy should have senior management approval.
- 3. The asset owner demonstrates (i.e. through examples) how the policy is implemented and affected at the  local  level,  either  through  general  organizational  operation,  or  project  related  initiatives  and management strategies.

## Evidence

- 1. A copy of the environmental policy document highlighting areas in which improvement targets have been set.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- 2. Specific examples that demonstrate environmental impacts are being measured and put into a format that is easy to interpret, such as past annual figures being used as benchmarks within a spreadsheet etc.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAN 09 - Operating procedures: Energy reduction

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are operating procedures in place to help reduce energy consumption?

## Aim

To recognize and encourage procedures that ensure energy consumption within the building is controlled and reduced where practicable.

## Available credits

|   Credits | Answer option                                                                                                                 |
|-----------|-------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                         |
|         0 | Don't know                                                                                                                    |
|         0 | No plans/procedures for minimizing energy consumption are in place                                                            |
|         2 | Yes - Energy reduction plans/procedures are in place                                                                          |
|         4 | Yes - Energy reduction plans/procedures that include annual budgets for energy efficiency and reduction measures are in place |
|         0 | Other                                                                                                                         |

## Assessment criteria

- 1. The operating procedures should be formally documented and available to all relevant building users.
- 2. The operating  procedures  should  be  updated  regularly  to  help  ensure  alignment  with  overall  energy management plans (or other related documents). These updates should at least occur when:
- a. New energy consuming technologies/products or serviced are introduced in the asset.
- b. The energy management plan (or other related document) is reviewed.
- 3. Operating procedures to help reduce energy consumption should include (but are not limited to) the following:
- a. Allocation of adequate resources (financial and human) to energy management.
- b. There is a reliable and effective system for monitoring and reporting energy performance.
- c. Targeting  all  relevant  areas  and  building  users,  active  engagement  of  the  workforce  around energy issues.

## Evidence

- 1. Copies  of  relevant  documentation  outlining  the  procedures  that  are  in  place  to  reduce  energy consumption.

<!-- image -->

<!-- image -->

- 2. Update schedule
- 3. Description of how procedures are communicated with relevant building users.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAN 10 - Ventilation system leak testing

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are duct and air handling unit leakage tests undertaken regularly, and are leaks rectified if identified?

## Aim

To ensure ventilation systems operate at optimum efficiency.

## Available credits

|   Credits | Answer option                                           |
|-----------|---------------------------------------------------------|
|         0 | Question not answered                                   |
|         0 | Don't know                                              |
|         0 | Not tested                                              |
|         4 | Yes, tested regularly and leaks have been rectified     |
|         4 | Not applicable: there are no duct or air handling units |

## Assessment criteria

- 1. Testing should be undertaken on a yearly basis, either by competent members of the facilities team or third party professionals.
- 2. Air  duct  and  handling  systems  should  be  tested  in  accordance  with  local  standards  or  best  practice guidance (such as the Sheet Metal and Air Conditioning Contractors' National Association (SMACNA) HVAC Air Duct Leakage Manual, 2 nd edition).

## Evidence

- 1. Evidence of relevant building monitoring/testing procedures, this could be within relevant sections taken from Building Management MAN 04 - Operation and maintenance manuals
- 2. Copy of inspection logs.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAN 11 - Green lease

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are green lease agreements/contracts with tenants in place?

## Aim

To encourage the implementation of lease agreements which contain incentives to actively engage tenants to consider energy, water, and waste efficient practices.

## Available credits

|   Credits | Answer option                                                                  |
|-----------|--------------------------------------------------------------------------------|
|         0 | Question not answered                                                          |
|         0 | Don't know                                                                     |
|         0 | No                                                                             |
|         2 | Yes, with qualitative targets                                                  |
|         4 | Yes, with qualitative and quantitative targets on at least lighting and energy |

## Assessment criteria

- 1. Green leases can include (but are not limited to):
- a. Energy efficiency targets
- b. Alteration
- c. Tenant handbook/Environmental policy/Energy management plan data
- d. Reporting
- e. Improvements/schedule of dilapidations
- f. Financial incentives
- g. Preferred maintenance contractors
- h. Separate energy, water, and/or gas metering
- i. Dispute resolution procedures
- 2. Where the asset is multi-tenanted, a green lease agreement/contract must be in place for at least 75% of the tenants.

## Evidence

- 1. A copy of the tenant contract with the green lease section and scope highlighted or identified.

<!-- image -->

<!-- image -->

## Additional information

-

<!-- image -->

Version 2.0: 2016, April 2019

<!-- image -->

## Building Management MAN 12 - Building management system review

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are  building  management  systems  regularly  reviewed  to  ensure  they  are  fully  functional  and  operating  as intended?

## Aim

To ensure building management systems are running efficiently and effectively.

## Available credits

|   Credits | Answer option                                                      |
|-----------|--------------------------------------------------------------------|
|         0 | Question not answered                                              |
|         0 | Don't know                                                         |
|         0 | No                                                                 |
|         2 | Yes - monitored by in-house FM team                                |
|         4 | Yes - monitored and/or certified by accredited third party auditor |
|         4 | Not applicable - no building management system within asset        |

## Assessment criteria

- 1. This issue is addressing full building management systems. Individual automated controls, such as PIRs controlling lighting, are NOT considered to be a building management system.
- 2. In-house FM team members must be trained to be able to operate the building management system to high efficiency standards.
- 3. Building management systems must be reviewed at least every 6 months.
- 4. Accredited third party professionals should be experts in how to operate the specific system that is being assessed.

## Evidence

- 1. Copy of inspection log.
- 2. Written confirmation from qualified person (such as a member of the FM team or third party auditor) to the Assessor that there is no building management system in the building.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAN 13 - Functional adaptability

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is  an  asset  strategy in place that outlines possible adaptation strategies/procedures to meet future demands, including those relating to climate change and changes in functionality?

## Aim

To  encourage  the  asset  management  team  to  have  appropriate  strategies/procedures  in  place  that  outline possible adaptation to the asset to meet to future demands.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. The scope of the strategy should cover (but is not limited to):
- a. The potential for major refurbishment, including replacing the façade.
- b. Design  aspects  that  facilitate  the  replacement  of  all  major  equipment  within  the  life  of  the building e.g. panels in floors/walls that can be removed without affecting the structure, providing lifting beams and hoists.
- c. The  degree  of  adaptability  of  the  internal  environment  to  accommodate  changes  in  working practices.
- d. The  degree  of  adaptability  of  the  internal  physical  space  and  external  shell  to  accommodate change in-use or resilience to natural hazards.
- e. The extent of accessibility to local services, such as local power, data infrastructure etc.

## Evidence

- 1. Copy of strategies/procedures for adaptation of the asset to meet changing future demands.

## Additional information

-

<!-- image -->

<!-- image -->

## Health and Wellbeing

## Category summary table

| Issue reference         | Title                                                       |   Credits available |
|-------------------------|-------------------------------------------------------------|---------------------|
| HEA 12                  | Fresh air rates                                             |                   4 |
| HEA 13                  | Operating temperature                                       |                   2 |
| HEA 14                  | Internal environment: CO 2 monitoring                       |                   2 |
| HEA 15                  | Internal environment: CO monitoring                         |                   2 |
| HEA 16                  | Internal environment: NO x monitoring                       |                   2 |
| HEA 17                  | Internal environment: Refurbishment/renovation/redecoration |                   2 |
| HEA 18                  | Volatile organic compounds                                  |                   2 |
| HEA 19                  | Control of chemicals                                        |                   4 |
| HEA 20                  | Acoustic conditions                                         |                   4 |
| HEA 21                  | Deep cleaning                                               |                   4 |
| HEA 22                  | Legionella management                                       |                   2 |
| HEA 23                  | Occupant satisfaction: Surveying                            |                   3 |
| HEA 24                  | Occupant satisfaction: Feedback                             |                   4 |
| Total credits available | Total credits available                                     |                  37 |

<!-- image -->

<!-- image -->

## Building Management HEA 12 - Fresh air rates

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

If the asset uses mechanical ventilation, have fresh air rates been measured?

## Aim

To recognize and encourage a healthy internal environment through the supply of sufficient fresh air.

## Available credits

|   Credits | Answer option                                                                              |
|-----------|--------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                      |
|         0 | Don't know                                                                                 |
|         0 | No                                                                                         |
|         2 | Yes                                                                                        |
|         3 | Measured fresh air rates are in line with the current local and state building regulations |
|         4 | Measured fresh air rates are in line with published national best practice                 |
|         4 | Not applicable, the asset is not mechanically ventilated                                   |

## Assessment criteria

- 1. Measurements are to be undertaken by competent persons.
- 2. Fresh air measurements must have been taken within 12 months of the assessment date and when major changes to the building or its occupancy have been made.
- 3. Where measurements have been taken in line with national best practice or building regulations, the proper procedures must have been followed. This must be demonstrated as part of the evidence. National best practice is defined by ASHRAE 62.1-2010.
- 4. Fresh air rates need to be measured in all relevant areas of the building in order to comply.

## Evidence

- 1. Copy of report confirming:
- a. Measured fresh air rates
- b. That fresh air measurement has taken place in line with relevant guidance (if applicable)
- c. That fresh air supply meets or exceeds standards against which it was assessed (if applicable)

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- 2. Confirmation of competency of person/organization undertaking air quality testing. This could be a copy of the measured results or schedule of work that includes the name(s) and qualifications of the qualified person(s).

## Additional information

## Relevant definitions

Relevant building area : occupied space which is a room or space within the assessed building that is likely to be occupied for 30 minutes or more by a building user. This includes public areas, such as dayrooms, exercise areas and communal areas, in shopping centers.

<!-- image -->

<!-- image -->

## Building Management HEA 13 - Operating temperature

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are temperatures managed in accordance with the design specifications of the asset?

## Aim

To ensure that the temperature within the asset meets the design specifications.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. For mechanically ventilated spaces, the temperatures within the building as specified in the design for winter and summer should be managed.
- 2. For naturally ventilated spaces, the temperature within the building as specified in the design for winter temperatures  should  be  managed.  The  temperature  set  for  thermostats  can  be  used  to  meet  the requirements.

## Evidence

- 1. Building  management  system  readings  or  manual  recordings  of  summer  and  winter  temperature  (as applicable).
- 2. Copy of design specification outlining summer and winter temperature (as applicable) of the asset.  This information might also be found in the building operations and maintenance manual.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management HEA 14 - Internal environment: CO2 monitoring

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are internal levels of Carbon Dioxide (CO2) monitored and controlled?

## Aim

To encourage the monitoring of internal conditions to ensure a healthy indoor environment is provided.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. CO2 levels should be measured in all relevant areas within the asset as follows:
- a. Areas of the building subject to large and unpredictable or variable occupancy patterns have CO2 sensors specified, AND:

In  mechanically  ventilated  spaces: The sensor(s) are linked to the mechanical ventilation system and provide demand-controlled ventilation to the space.

In  naturally  ventilated  spaces: The  sensors  either  have  the  ability  to  alert  the  building owner/manager when levels exceed the recommended set point, or are linked to controls with the ability to adjust the quantity of fresh air, i.e. automatic opening windows/roof vents.

- b. For all other building areas regular and planned measurements of CO2 should be logged for a period of one week's typical occupancy for the building, in all occupied spaces, under normal operating conditions, at least 4 times a year.

## Evidence

- 1. Photographic evidence of measuring equipment.
- 2. Specifications of the measuring equipment installed and in-use, including a brief outline of the scope of operation.
- 3. Copy of procedures and/or monitoring log.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management HEA 15 - Internal environment: CO monitoring

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are internal levels of Carbon Monoxide (CO) monitored and controlled where sources of CO have been identified inside the asset and in proximity to external air intakes?

## Aim

To encourage the monitoring of internal conditions to ensure a healthy indoor environment is provided.

## Available credits

|   Credits | Answer option                                                                                                                       |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                               |
|         0 | Don't know                                                                                                                          |
|         0 | No                                                                                                                                  |
|         2 | Yes                                                                                                                                 |
|         2 | There are no internal sources of CO and no external air intakes present/external air intakes are not in proximity to sources of CO. |

## Assessment criteria

- 1. CO levels should be continuously monitored and controlled in the following areas:
- a. Where sources of CO are installed internally.
- b. In external air intakes that are within 65 feet of possible sources of CO.
- 2. An alarm should be activated when CO levels rise above a pre-set maximum for a pre-set period of time.

## Evidence

- 1. Photographic evidence of measuring equipment.
- 2. Specifications of the measuring equipment installed and in-use, including a brief outline of the scope of operation.
- 3. Copy of procedures and/or monitoring log.
- 4. List of sources of CO that are installed in the building and/or near external air intakes.
- 5. Diagrams, photos or plans indicating internal sources of CO and/or sources of CO in proximity to external air intakes.
- 6. Where no sources of CO are installed in the building or where there are no sources of CO near external air intake:

<!-- image -->

<!-- image -->

## a. Confirmation of building management team that no sources of CO have been installed

## Additional information

## Other information

Sources of CO emissions include all fuel burning devices, including (but not limited to):

-  Traffic from nearby roads
-  Traffic at loading docks
-  Back-up generators
-  CO emissions related to cooling, heating or providing electricity to the asset

<!-- image -->

<!-- image -->

## Building Management HEA 16 - Internal environment: NOx monitoring

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are internal levels of Nitrogen Oxides (NOx) monitored and controlled where sources of NOx have been identified inside the asset and in proximity to external air intakes?

## Aim

To encourage the monitoring of internal conditions to ensure a healthy indoor environment is provided.

## Available credits

|   Credits | Answer option                       |
|-----------|-------------------------------------|
|         0 | Question not answered               |
|         0 | Don't know                          |
|         0 | No                                  |
|         2 | Yes                                 |
|         2 | This is not necessary for the asset |

## Assessment criteria

- 1. NOx levels should be continuously monitored and controlled in the following areas:
- a. Where sources of NOx are installed internally
- b. In external air intakes that are within 65 feet of possible sources of NOx
- 2. An alarm should be activated when NOx levels rise above a pre-set maximum for a pre-set period of time.

## Evidence

- 1. Photographic evidence of measuring equipment.
- 2. Specifications of the measuring equipment installed and in-use, including a brief outline of the scope of operation.
- 3. Copy of procedures and/or monitoring log.
- 4. List of sources of NOx that are installed in the building and/or near external air intakes.
- 5. Diagrams, photos or plans indicating internal sources of NOx and/or sources of NOx in proximity to external air intakes.
- 6. Where no sources of NOx are installed in the building or where there are no sources of NOx near external air intake:
- a. Confirmation of building management team that no sources of NOx have been installed.

<!-- image -->

SD221 USA © BRE Global Ltd 2019

<!-- image -->

## Additional information

## Relevant definitions

NOx emissions: NOx emissions are pollutant gases produced by the combustion of fossil fuels. NOx reacts with heat and sunlight to produce ozone that can cause serious respiratory problems. It also reacts with water to produce acid rain, which has a detrimental effect on ecosystems.

Sources of NOx emissions include all fuel burning devices, including (but not limited to):

- a. Traffic from nearby roads
- b. Traffic at loading docks
- c. Back-up generators
- d. NOx emissions related to cooling, heating or providing electricity to the asset

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

<!-- image -->

## Building Management HEA 17 -Internal environment: Refurbishment/renovation/redecoration

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are policies/procedures in place to minimize the exposure of building occupants to chemicals and dusts released by refurbishment/renovation/redecoration works?

## Aim

To reduce the risk to health associated with chemical and/or dust exposure.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Policies/formal procedures to minimize risk to building occupants from building refurbishment/renovation/redecoration must be in place. These can be:
- a. Included within risk assessments that are conducted/undertaken prior to any work taking place.
- b. Included  in  an  internal  organizational  policy,  where  these  policies/procedures  can  be  easily identified.

## Evidence

- 1. Copy of official documents that highlight the methods and relevant clauses that set conditions to minimize exposure to chemicals and dust during refurbishment/renovation/redecoration works.
- 2. Evidence  of  precautions  taken  for  previous  works,  including  relevant  risk  assessments  assessing  the conditions and risks identified (if relevant).

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management HEA 18 - Volatile organic compounds

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is there a strategy/policy in place for minimizing the use of harmful volatile organic compound (VOC) emitting materials/substances?

## Aim

To recognize and encourage a healthy internal environment  through the use of internal finishes, fittings and cleaning products with reduced/no emissions of VOCs.

## Available credits

|   Credits | Answer option                     |
|-----------|-----------------------------------|
|         0 | Question not answered             |
|         0 | Don't know                        |
|         0 | No                                |
|         2 | Yes                               |
|         2 | Yes, part of a maintenance policy |

## Assessment criteria

- 1. Strategies/policies to reduce the use of harmful VOC emitting materials/substances can either be standalone documents or part of a wider environmental policy/strategy.
- 2. Strategies can be based on (a combination of):
- a. Procurement
- b. Process
- c. Risk aversion
- d. Maintenance
- 3. Typical materials/substances that should be covered by the policy/procedure:
- a. Paints, adhesives, and cleaning materials
- b. Electrical appliances such as printers
- c. Carpet and other flooring materials
- d. Office furniture

## Evidence

- 1. Copy of relevant policy/procedure.

<!-- image -->

<!-- image -->

## Additional information

## Relevant definitions

Volatile  organic  compounds (VOCs)  are  emitted  by  a  wide  array  of  products  numbering  in  the  thousands. Examples  include:  paints  and  lacquers,  paint  strippers,  cleaning  supplies,  pesticides,  building  materials  and furnishings, glues and adhesives, Urea-formaldehyde foam insulation (UFFI), pressed wood products (hardwood plywood wall paneling, particleboard, fiberboard) and furniture made with these pressed wood products.

<!-- image -->

<!-- image -->

## Building Management HEA 19 - Control of chemicals

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is adequate extraction provided to relevant building areas to keep the concentration of pollutants from printers and specialist equipment at acceptable levels?

## Aim

To maintain acceptable levels of internal air quality.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. Adequate extraction (natural or mechanical)
- 2. to comply with this requirement is required where windows cannot be opened in the immediate vicinity, or ventilation within the building is poor.
- 3. Relevant  building  areas  are  areas  within  the  building  where  any  of  the  equipment  mentioned  in  the question are installed/placed.
- 4. Adequate  extraction  for  specialist  equipment  must  be  provided  where  this  is  stated  within  the manufacturer guidance.

## Evidence

- 1. Photographic evidence of extraction fans and/or ventilation systems.
- 2. Floor plan indicating where equipment is placed and where extraction is in place.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management HEA 20 - Acoustic conditions

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Have internal acoustic conditions been monitored by a suitably qualified third party acoustician?

## Aim

To ensure the acoustic performance of the building meets the appropriate best practice standards.

## Available credits

|   Credits | Answer option                                      |
|-----------|----------------------------------------------------|
|         0 | Question not answered                              |
|         0 | Don't know                                         |
|         0 | No                                                 |
|         2 | Yes                                                |
|         4 | Yes, and all recommendations have been implemented |

## Assessment criteria

- 1. A named third party acoustician is responsible for optimizing acoustic comfort and ensuring compliance with the appropriate best practice standards.
- 2. As a minimum, monitoring of acoustic comfort should be carried out when changes are made to the building envelope or building services that would influence acoustic conditions in the relevant spaces within the building.
- 3. Acoustic conditions need to be measured in all relevant spaces in the building to comply with the issue.
- 4. Acoustic conditions should be in line with national standards or best practice guidelines.

## Evidence

- 1. Details of the individual responsible for the acoustic maintenance and monitoring; including qualification.
- 2. Records of monitoring demonstrating compliance with appropriate best practice standards.

## Additional information

## Relevant definitions

Relevant building area : occupied space which is a room or space within the assessed building that is likely to be occupied for 30 minutes or more by a building user. This includes public areas, such as dayrooms, exercise areas and communal areas, in shopping centers.

<!-- image -->

<!-- image -->

Third party acoustician : An individual achieving the following items can be considered 'suitably qualified' for the purposes of this issue:

- 1. Holds a university/higher education qualification or equivalent qualification in acoustics.
- 2. Has a minimum of three years relevant experience (within the last five years). Such experience must clearly demonstrate a practical understanding of factors affecting acoustics in relation to construction and the built environment, including, acting in an advisory capacity to provide recommendations for suitable acoustic performance levels and mitigation measures.

<!-- image -->

<!-- image -->

## Building Management HEA 21 - Deep cleaning

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is  there  a  strategy  in  place  to  carry  out  deep  cleaning  of  soft  furnishing  and/or  carpets,  at  an  appropriate frequency?

## Aim

To recognize and encourage a policy of regular cleaning of soft furnishing and/or carpets to reduce the risk to health associated with poor building cleanliness.

## Available credits

|   Credits | Answer option                                                                                      |
|-----------|----------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                              |
|         0 | Don't know                                                                                         |
|         0 | No                                                                                                 |
|         1 | Yes, deep cleaning of soft furnishings and/or carpets carried out once every three years           |
|         2 | Yes, deep cleaning of soft furnishings and/or carpets carried out more than once every three years |
|         4 | Yes, deep cleaning of soft furnishings and/or carpets carried out at least annually                |
|         4 | There are no soft furnishings and/or carpets within the asset                                      |

## Assessment criteria

- 1. Deep cleaning would typically require the use of specialist/steam cleaning apparatus.
- 2. Regular daily cleaning of soft furnishings and/or carpets is not considered 'deep cleaning'.
- 3. The use of harmful chemicals should be minimized to reduce the effects of deep cleaning on the indoor environment.

## Evidence

- 1. A copy of the maintenance/cleaning policy highlighting the relevant cleaning clauses.
- 2. Records of deep cleaning carried out that confirm the policy has been followed.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management HEA 22 - Legionella management

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are all systems that are installed to reduce the risk of Legionella contamination adequately maintained?

## Aim

To ensure Legionella contamination systems are maintained to avoid the risk of Legionella contamination.

## Available credits

|   Credits | Answer option                                                                                                                  |
|-----------|--------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                          |
|         0 | Don't know                                                                                                                     |
|         0 | No                                                                                                                             |
|         2 | Regular inspection and maintenance of all systems, by a competent third party contractor, in accordance with national standard |
|         2 | No systems have been installed for the control of Legionella                                                                   |
|         0 | Other                                                                                                                          |

## Assessment criteria

- 1. The national standard is ASHRAE 188-2015.  Regular inspections and maintenance of the systems are required to be done in line with this standard.
- 2. There need to be fully documented operation and inspection maintenance manuals for each system. These manuals include (but are not limited to):
- a. Listing of all equipment that is installed
- b. Maintenance schedules for the installed equipment stating (at a minimum) the time intervals for:
- i. Inspection (no more than 1 year)
- ii. Overhaul
- iii. Cleaning

## Evidence

- 1. Copy of list of systems that are installed to reduce the risk of Legionella contamination.
- 2. Copy of legionella inspection log and results.
- 3. If 'No systems have been installed for the control of legionella' is selected the Assessor must ensure that a copy of the report that outlines that no Legionella control systems are deemed necessary should be

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

provided. The report as specified in Asset Performance HEA 05 - Minimizing Legionella contamination will suffice.

## Additional information

## Relevant definitions

Competent person :  a  person with sufficient knowledge, training and experience of the building water system design and water management as it relates to legionellosis to be able to describe the water systems, evaluate where  hazardous  conditions  may  occur,  determine  where  control  measures  can  and  must  be  applied  and maintained  to  stay  within  established  control  limits  and  establish  procedures  to  monitor  whether  control measures are operating within established limits and if not, take corrective action.-

<!-- image -->

<!-- image -->

## Building Management HEA 23 - Occupant satisfaction: Surveying

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             3 | No                  |

## Question

Are procedures in place for the collection and recording of occupant satisfaction in regards to the asset's internal environment?

## Aim

To  ensure  that  building  occupant  satisfaction  with  the  building  is  regularly  monitored  and  reviewed  so improvements can be made.

## Available credits

|   Credits | Answer option                                          |
|-----------|--------------------------------------------------------|
|         0 | Question not answered                                  |
|         0 | Don't know                                             |
|         0 | No                                                     |
|         2 | Yes                                                    |
|         3 | Yes, third party system used as a basis for the survey |

## Assessment criteria

- 1. Regular collection and recording of building occupant satisfaction (using an established procedure) should be undertaken at least once every three years and additionally when major changes in facility planning, building services etc. have been undertaken.
- 2. The survey process should be designed to cover, as a minimum:
- a. Internal environmental conditions
- b. Internal environmental controls
- c. Internal fit-out and contents
- d. Common areas and facilities in the building
- 3. The  occupant  satisfaction  feedback  process  can  be  carried  by  an  in-house  team  provided  they  can demonstrate that they have the necessary research skills and expertise in social research. An independent consultant may be more acceptable to the respondents in terms of maintaining the confidentiality of their responses.
- 4. Qualitative  methods,  such  as  the  use  of  structured  interviews  and/or  focus  groups  may  also  comply, provided they involve a cross section of building occupants and cover the range of issues set out above.
- 5. To avoid de-motivation of respondents it is important in that the results and subsequent actions are communicated  to  the  participants  either  in  a  report  or  a  presentation.  Where  occupant  satisfaction

<!-- image -->

<!-- image -->

surveys have taken place, the Assessor should check that contents of the survey and the results have been communicated to all occupants.

## Evidence

- 1. A copy of the building occupant's satisfaction feedback forms.
- 2. Copy of procedure and survey process.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management HEA 24 - Occupant satisfaction: Feedback

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are procedures in place to address feedback and issues as highlighted in the occupant satisfaction survey process?

## Aim

To recognize and encourage procedures to act on information gathered through occupant satisfaction surveys so that the building performance can be optimized.

## Available credits

|   Credits | Answer option                                                           |
|-----------|-------------------------------------------------------------------------|
|         0 | Question not answered                                                   |
|         0 | Don't know                                                              |
|         0 | No                                                                      |
|         2 | Yes                                                                     |
|         4 | Yes, targets are set and signed off at senior manager or director level |

## Assessment criteria

- 1. Procedures to act on feedback from occupant satisfaction surveys should be undertaken at least once every three years and when major changes in facility planning, building services etc. have been made.
- 2. Targets should be set for all topics for which building occupants have highlighted issues.
- 3. All  targets  and  procedures that are in place as a result of the occupant satisfaction survey should be accessible to all building occupants.
- 4. Process on targets and procedures should be reviewed annually.

## Evidence

- 1. Copy of reviews/targets that have been set based on occupant survey outcomes.
- 2. Records of how information on target setting and procedure development has been communicated with building occupants. This could either be through hard copy or soft copy.

## Additional information

-

<!-- image -->

<!-- image -->

## Energy

## Category summary table

| Issue reference         | Title                                      | Credits available                                                              |
|-------------------------|--------------------------------------------|--------------------------------------------------------------------------------|
| ENE 31                  | Energy consumption start date              | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 32                  | Energy consumption end date                | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 33                  | Electricity consumption                    | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 34                  | Natural gas consumption                    | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 35                  | LPG consumption                            | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 36                  | Gas oil consumption                        | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 37                  | Solid fossil fuel consumption              | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 38                  | Biodiesel consumption                      | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 39                  | Biogas consumption                         | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 40                  | Wood/Waste wood consumption                | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 41                  | District heating consumption               | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 42                  | Carbon intensity district heating          | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 43                  | District cooling consumption               | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 44                  | Carbon intensity district cooling          | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 45                  | Electricity exported                       | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 46                  | Non-standard energy uses                   | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 47, 50, 53, 56 &59  | Non-standard energy use                    | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 48, 51, 54, 57 &60  | Non-standard energy consumption            | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 49, 52, 55, 58 &61  | Non-standard energy consumption floor area | Up to 40 credits are available. Credits are calculated within the Energy Model |
| ENE 62                  | Energy consumption monitoring              | 4                                                                              |
| ENE 63                  | Energy consumption data use                | 4                                                                              |
| ENE 64                  | Sub-metering: Main energy sources          | 4                                                                              |
| ENE 65                  | Sub-metering: Other energy sources         | 4                                                                              |
| ENE 66                  | Sub-metering: Tenanted areas               | 4                                                                              |
| Total credits available | Total credits available                    | 60                                                                             |

<!-- image -->

<!-- image -->

## Operational Energy Calculator Guidance

## Introduction

This section has been produced to give BREEAM USA In-Use Assessors further guidance on the workings of the operational energy calculator so it is clear how any reductions in operational energy consumption will be reflected in the calculation of the operational energy rating.

## Overview

In  order  to  calculate  the  operational  energy  rating,  the  carbon  dioxide  (CO2)  emissions  resulting  from  actual building energy consumption are compared to the equivalent CO2 emissions for a reference building. There are three main parts to the methodology: establishing the reference benchmark, establishing the actual building CO2 emissions, and comparing the reference benchmark with the actual CO2 emissions to generate a rating.

## Establishing reference benchmark

The reference benchmark is set according to the main activity type in the building being assessed.  To reflect that there may be more than one activity carried out in any given building e.g. an office block with a restaurant area, it is possible to select up to five different asset types for a single assessment. Where more than one asset type is selected, the reference benchmark is calculated on an area-weighted basis. This reference benchmark is adjusted to take account of local climate using the same degree-day calculation methodology used for the asset model. In order to recognize the lower energy consumption of naturally ventilated properties, the reference benchmarks are based on a mix of both air-conditioned and naturally ventilated premises.

The reference building energy consumption is converted to CO2 by multiplying the electrical and non-electrical energy benchmarks  by  appropriate carbon  emission  factors.  The  carbon emissions  factor  for  all  non-electrical energy  consumption  is  based  on  a natural gas / fuel oil mix and is fixed. The Emissions &amp; Generation Resource Integrated Database (eGRID) 1 provides all the carbon emissions factors for electrical energy consumption for US assets. The asset is  mapped  to  the  relevant  electricity sub region using the ZIP code provided when the asset was registered. These

<!-- image -->

<!-- image -->

factors  will  only  change  when  the  BREEAM  USA  In-Use  program  is  updated  to  provide  a  consistent  basis  for comparison.

More information can be found on their website:  https://www.epa.gov/energy/egrid

## Establishing actual energy consumption

The utility-supplied metered energy consumption is used as the starting point for establishing the applicable energy  consumption  for  the  actual  building.  It  is  possible  to  make  two  'corrections'  to  the  metered  energy consumption data:

-  Energy consumption associated with non-standard energy uses that would not be considered typical for the type of building being assessed can be subtracted where separately metered.
-  Any electricity exported from the site can be subtracted where there is a separate export meter.

A final correction is then made to account for consumption data based on any reporting period that is not 365 days. Users are able to manually enter metered energy consumption for a number of different fuel types including: grid supplied electricity, natural gas, propane, gas oil, solid fossil fuels, biodiesel, biogas, wood, district heating and district cooling. Energy generated from on-site renewables and consumed by the asset is not included in the calculation.

Assets using ENERGY STAR Portfolio Manager  to record and monitor their energy consumption can run reports ® from the tool to obtain the data needed to answer the energy consumption questions where the tool is being used to track that energy usage.  ENERGY STAR Portfolio Manager  allows the energy consumption for all fuel ® types to be entered in a multitude of measurement units (depending on the fuel) and then translates this to standard units.  Automated data exchange with ENERGY STAR Portfolio Manager  is not currently supported. ®

Once  the  energy  consumption  for  each  fuel  type  has  been  entered,  the  tool  calculates  the  associated  CO2 emissions for the actual building by multiplying the consumption data by the relevant carbon emission factors for each fuel type. As for the reference baseline, the carbon emission factor for electricity varies according to the location of the assessment, but the emission factors for non-electrical consumption are fixed. The only exception to this is for district heating and cooling systems where it is possible to enter the actual emissions factor for the system where known.

## Establishing final score

The operational energy rating is then calculated by comparing the actual CO2 emissions to the reference CO2 emissions using a sliding scale with maximum credits being awarded for a zero carbon building, and zero credits awarded where the actual emissions are more than twice the reference emissions.

<!-- image -->

<!-- image -->

## Building Management ENE 31 - Energy consumption start date

| Number of credits available                    | Minimum standards   | Mandatory question   |
|------------------------------------------------|---------------------|----------------------|
| Credits are calculated within the Energy Model | No                  | Yes                  |

## Question

Please enter the start date of the annual reporting period for consumption data applicable to questions Building Management ENE 33 - Electricity consumption to Building Management ENE 45 - Electricity exported.

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide date as: MM/DD/YYYY   |
|-----------|-------------------------------|
| N/A       |                               |

## Assessment criteria

- 1. Assessors must ensure that the reporting period is between 11 - 13 months.

## Evidence

- 1. Copies of energy bills or verified meter readings for the beginning and end of the reporting period.

## Additional information

## Other information

The intention is that the user enters energy consumption data based on a 365-day period; however, it is possible to enter data for any reporting period between 11 and 13 months.  Any reporting period outside of the 11- to 13month range would be invalid and result in zero credits being scored.

<!-- image -->

<!-- image -->

## Building Management ENE 32 - Energy consumption end date

| Number of credits available                    | Minimum standards   | Mandatory question   |
|------------------------------------------------|---------------------|----------------------|
| Credits are calculated within the Energy Model | No                  | Yes                  |

## Question

Please enter the end date of the annual reporting period for consumption data applicable to questions Building Management ENE 33 - Electricity consumption to Building Management ENE 45 - Electricity exported.

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide date as: MM/DD/YYYY   |
|-----------|-------------------------------|
| N/A       |                               |

## Assessment criteria

- 1. Assessors must ensure that the reporting period is between 11 - 13 months.

## Evidence

- 1. Copies of energy bills or verified meter readings for the beginning and end of the reporting period.

## Additional information

## Other information

The intention is that the user enters energy consumption data based on a 365-day period; however, it is possible to enter data for any reporting period between 11 and 13 months. Any reporting period outside of the 11- to 13month range would be invalid and result in zero credits being scored.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 33 - Electricity consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much utility  supplied  electricity  was  consumed  by  the  asset  on  annual  basis  (kWh),  as  metered  in  the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kWh/year   |
|-----------|------------------------|
| N/A       |                        |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area Asset Dimensions.
- 2. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.

## Evidence

- 1. Copies of energy bills or verified meter readings for the beginning and end of the reporting period.  This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 34 - Natural gas consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much natural gas is consumed by the asset on an annual basis (therms), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: therms/year   |
|-----------|---------------------------|
| N/A       |                           |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under: Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area. Asset Dimensions
- 2. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.

## Additional information

## Other information

Please note: all fuel consumption must be entered for Building Management ENE 34 - Natural gas consumption through to Building Management ENE 43 - District cooling consumption.  If the asset uses a fuel type that is not listed, please contact BRE Global Limited for guidance on how to account for this.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 35 - Propane consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much propane is consumed by the asset on an annual basis (kBtu), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kBtu/year   |
|-----------|-------------------------|
| N/A       |                         |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area.
- 2. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.
- 3. Calculating propane usage can be achieved via:
- a. Metering
- b. Calculations based on inventory data (the number of canisters used on site) during the reporting period (where their specifications are known)

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.
- 2. Calculations based on inventory data.

## Additional information

## Other information

Please note: all fuel consumption must be entered for Building Management ENE 34 - Natural gas consumption through to Building Management ENE 43 - District cooling consumption. If the asset uses a fuel type that is not listed, please contact BRE Global Limited for guidance on how to account for this.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 36 - Gas oil consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much gas oil (light fuel oil/diesel) is consumed by the asset on an annual basis (kBtu), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kBtu/year   |
|-----------|-------------------------|
| N/A       |                         |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area.
- 2. This figure regards fuel that has been used directly within the asset NOT for vehicles or other appliances operating on site, unless this is specified within the scope.
- 3. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.
- 4. Recording fuel usage can be achieved through:
- a. Metering of equipment
- b. Estimates of system efficiency and running times
- c. Calculations based on inventory data

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.
- 2. Calculations based on inventory data.
- 3. Photographic evidence of sub meters (if relevant).

## Additional information

## Other information

Please note: all fuel consumption must be entered for Building Management ENE 34 - Natural gas consumption through to Building Management ENE 43 - District cooling consumption.  If the asset uses a fuel type that is not listed, please contact BRE Global Limited for guidance on how to account for this.

<!-- image -->

SD221 USA © BRE Global Ltd 2019

<!-- image -->

## Building Management ENE 37 - Solid fossil fuel consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much solid fossil fuel is consumed by the asset supplied on an annual basis (kBtu), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kBtu/year   |
|-----------|-------------------------|
| N/A       |                         |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area.
- 2. Solid fossil fuel refers to the burning of solid material for the purposes of creating heat, such as coal.
- 3. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.
- 4. Calculating the amount of solid fuel usage can be achieved through:
- a. Sub-metering of equipment which uses solid fuel
- b. Invoices for materials purchased during the reporting period and calculations based on the calorific content of the material.

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.
- 2. Calculations based on inventory data.
- 3. Photographic evidence of sub-meters (if relevant)

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 38 - Biodiesel consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much biodiesel is consumed by the asset on an annual basis (kBtu), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kBtu/year   |
|-----------|-------------------------|
| N/A       |                         |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area.
- 2. Cooking oil can only be used when it has been appropriately refined to a standard that is suitable for fuel usage.
- 3. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.
- 4. Calculating biodiesel usage can be achieved through:
- a. Sub-metering of equipment which uses this fuel
- b. Invoices for biodiesel materials purchased during the reporting period and calculations based on the calorific content of the material.

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.
- 2. Calculations based on inventory data.
- 3. Photographic evidence of sub-meters (if relevant)

## Additional information

## Other information

Please note: all fuel consumption must be entered for Building Management ENE 34 - Natural gas consumption through to Building Management ENE 43 - District cooling consumption.  If the asset uses a fuel type that is not listed, please contact BRE Global Limited for guidance on how to account for this.

<!-- image -->

SD221 USA © BRE Global Ltd 2019

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 39 - Biogas consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much biogas is consumed by the asset on an annual basis (kWh), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kWh/year   |
|-----------|------------------------|
| N/A       |                        |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area.
- 2. Biogas can be used from offsite suppliers or as a result of on-site generation, following a process such as anaerobic digestion etc.
- 3. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.
- 4. Calculating biogas usage can be achieved through:
- a. Sub-metering of equipment which uses this fuel
- b. Invoices for gas imported during the reporting period

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.
- 2. Calculations based on inventory data.
- 3. Photographic evidence of sub-meters (if relevant).

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 40 - Wood/Waste wood consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much wood/waste wood is consumed by the asset on an annual basis (kBtu), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kBtu/year   |
|-----------|-------------------------|
| N/A       |                         |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area.
- 2. Calculating  the  amount  of  wood/wood  waste  usage  can  be  achieved  through  invoices  for  materials purchased during the reporting period and calculations based on the calorific content of the material.
- 3. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.
- 2. Calculations based on inventory data.

## Additional information

## Other information

Please note: all fuel consumption must be entered for Building Management ENE 34 - Natural gas consumption through to Building Management ENE 43 - District cooling consumption.  If the asset uses a fuel type that is not listed, please contact BRE Global Limited for guidance on how to account for this.

<!-- image -->

<!-- image -->

## Building Management ENE 41 - District heating consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much district heating energy is consumed by the asset on an annual basis (kBtu), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kBtu/year   |
|-----------|-------------------------|
| N/A       |                         |

## Assessment criteria

- 1. Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area.
- 2. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.
- 3. Evidence provided will illustrate that an accurate calculation of district heating energy usage has been provided. This could include, but is not limited to:
- a. Relevant metering of equipment
- b. Building energy management systems
- c. Calculation via energy bills for fuel types if these fuel types are only used for district heating etc.

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.
- 2. Calculations based on inventory data.
- 3. Photographic evidence of sub-meters (if relevant).

## Additional information

## Relevant definitions

District heating refers  to heating which is delivered via a central source to different parts of the building, for example, a system that runs from central boilers.

<!-- image -->

SD221 USA © BRE Global Ltd 2019

<!-- image -->

Version 2.0: 2016, April 2019

## Other information

Please note: all fuel consumption must be entered for Building Management ENE 34 - Natural gas consumption through to Building Management ENE 43 - District cooling consumption.  If the asset uses a fuel type that is not listed, please contact BRE Global Limited for guidance on how to account for this.

<!-- image -->

<!-- image -->

## Building Management ENE 42 - Carbon intensity district heating

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

If known, what is the carbon intensity of the district heating system in kgCO2/MBtu?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kgCO 2 /MBtu   |
|-----------|----------------------------|
| N/A       |                            |

## Assessment criteria

- 1. The carbon intensity of the district heating system would be sourced from the supplier of this system.

## Evidence

- 1. Relevant literature/records/data or other information from the district heating supplier stating the carbon intensity of the system.

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 43 - District cooling consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

How much district cooling energy consumption is consumed by the asset on an annual basis (kBtu), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kBtu/year   |
|-----------|-------------------------|
| N/A       |                         |

## Assessment criteria

- Please ensure that all consumption data relates specifically to the area of the asset that is being assessed. This is the area that has been filled in as Gross Internal Area under Asset Dimensions. This also includes further guidance on the definition of Gross Internal Area.
- Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.
- Accurate calculation of district cooling energy usage could come from:
- a. Relevant metering of equipment
- b. Building energy management systems

## Evidence

- 1. Copies of utility bills or verified meter readings for the beginning and end of the reporting period. This evidence is required for all sources for this energy type that contribute to the total consumption. Monthly usage breakdowns are not required.
- 2. Calculations based on inventory data.
- 3. Photographic evidence of sub-meters (if relevant).

## Additional information

## Other information

Please note: all fuel consumption must be entered for Building Management ENE 34 - Natural gas consumption through to Building Management ENE 43 - District cooling consumption.  If the asset uses a fuel type that is not listed, please contact BRE Global Limited for guidance on how to account for this.

<!-- image -->

<!-- image -->

## Building Management ENE 44 - Carbon intensity district cooling

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

If known, what is the carbon intensity of the district cooling system in kgCO2/MBtu?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kgCO 2 /MBtu   |
|-----------|----------------------------|
| N/A       |                            |

## Assessment criteria

- 1. The carbon intensity of the district cooling system would be sourced from the supplier of this system.

## Evidence

- 1. Relevant literature/records/data or other information from the district cooling supplier stating the carbon intensity of the system.

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 45 - Electricity exported

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the quantity of electricity exported off site on an annual basis (kWh), as metered in the reporting period?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kWh/year   |
|-----------|------------------------|
| N/A       |                        |

## Assessment criteria

- 1. The quantity of electricity exported off site would only need to be considered where there are separate meters for the import and export of electricity.
- a. Where these meters are combined, the contribution of electricity generated on site and exported off site will already be factored in to the main electricity consumption figure.
- 2. Where a separate meter for import and export of electricity are installed on-site:
- a. Only the electricity that is exported via the export meter should be taken in to account
- 3. Assessors must confirm that the reporting period is aligned with the start and end date of the utility bills.

## Evidence

- 1. Photographic evidence of relevant export meter
- 2. Line diagram outlining the connection of the on-site electricity generators to the export meters.
- 3. Building Energy Management System (BEMS) data.
- 4. Copies of verified data for the period specified in Building Management ENE 31 - Energy consumption start date and Building Management ENE 32 - Energy consumption end date.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management ENE 46 - Non-standard energy uses

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

Select the number of non-standard energy uses that are sub-metered within the asset (0-5 types).

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Answer option         |
|-----------|-----------------------|
| -         | Question not answered |
| -         | 0                     |
| -         | 1                     |
| -         | 2                     |
| -         | 3                     |
| -         | 4                     |
| -         | 5                     |

## Assessment criteria

- 1. For the purposes of a BREEAM USA In-Use assessment, non-standard energy uses are defined as:
- a. Regional server room: Energy used in a server room that services multiple satellite offices/servers.
- b. Trading floor: Energy used in a room where traders are gathered to operate on financial markets
- c. Bakery oven: Energy used in a commercial sized oven used to bake foods.
- d. Sports flood lighting: Energy used by broad-beamed, high intensity artificial lights (often used outside)
- e. Furnace or forming process
- i. Energy used in a furnace: an industrial devise used for many things, such as extracting metals or as heat source in chemical plants.
- ii. Energy used in forming process: a manufacturing process that makes uses of suitable stresses to cause deformation of materials to produce required shapes.
- f. Blast  chilling  or  freezing:  Energy  used  for  cooling  materials  (often  food)  quickly  to  low temperatures.

<!-- image -->

<!-- image -->

## Evidence

- 1. Photographic evidence of sub-meters.
- 2. Building plans illustrating the location of sub-meters.

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management ENE 47, 50, 53, 56 &amp; 59 - Non-standard energy use

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

Select the non-standard sub-metered energy use.

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Answer option              |
|-----------|----------------------------|
| -         | Question not answered      |
| -         | Regional server room       |
| -         | Trading floor              |
| -         | Bakery oven                |
| -         | Sports floodlighting       |
| -         | Furnace or forming process |
| -         | Blast chilling or freezing |

## Assessment criteria

- 1. Non-standard energy uses are defined as:
- a. Regional server room: Energy used in a server room that services multiple satellite offices/servers
- b. Trading floor: Energy used in a room where traders are gathered to operate on financial markets
- c. Bakery oven: Energy used in a commercial sized oven used to bake foods.
- d. Sports  floodlighting:  Energy  used  by  broad-beamed,  high  intensity  artificial  lights  (often  used outside)
- e. Furnace or forming process:
- i. Energy used in a furnace: an industrial devise used for many things, such as extracting metals or as heat source in chemical plants.
- ii. Energy used in forming process: a manufacturing process that makes uses of suitable stresses to cause deformation of materials to produce required shapes.
- f. Blast  chilling  or  freezing:  Energy  used  for  cooling  materials  (often  food)  quickly  to  low temperatures.

## Evidence

<!-- image -->

<!-- image -->

- 1. Photographic evidence of non-standard energy use.
- 2. Written explanation what non-standard energy use is used.

## Additional information

-

<!-- image -->

Version 2.0: 2016, April 2019

<!-- image -->

## Building  Management  ENE  48,  51,  54,  57  &amp;  60  -  Non-standard  energy consumption

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the energy usage of the non-standard sub-metered energy use?

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: kWh/year   |
|-----------|------------------------|
| N/A       |                        |

## Assessment criteria

- 1. Non-standard energy uses should be sub-metered to confirm the energy use associated with the nonstandard energy use and area.
- 2. Non-standard energy uses are defined as:
- a. Regional server room: Energy used in a server room that services multiple satellite offices/servers
- b. Trading floor: Energy used in a room where traders are gathered to operate on financial markets
- c. Bakery oven: Energy used in a commercial sized oven used to bake foods.
- d. Sports  floodlighting:  Energy  used  by  broad-beamed,  high  intensity  artificial  lights  (often  used outside)
- e. Furnace or forming process:
- i. Energy used in a furnace: an industrial devise used for many things, such as extracting metals or as heat source in chemical plants.
- ii. Energy used in forming process: a manufacturing process that makes uses of suitable stresses to cause deformation of materials to produce required shapes.
- f. Blast  chilling  or  freezing:  Energy  used  for  cooling  materials  (often  food)  quickly  to  low temperatures.

## Evidence

- 1. Copies of verified meter data for the 12-month period specified.
- 2. Photographic evidence of the installation of sub-meters for the non-standard energy use.

## Additional information

-

<!-- image -->

<!-- image -->

## Building  Management  ENE  49,  52,  55,  58  &amp;  61  -  Non-standard  energy consumption floor area

| Number of credits available                    | Minimum standards   |
|------------------------------------------------|---------------------|
| Credits are calculated within the Energy Model | No                  |

## Question

What is the floor area associated with the non-standard energy use (ft )? 2

## Aim

This data is required to generate the operational energy rating.

## Available credits

| Credits   | Provide as: ft 2   |
|-----------|--------------------|
| N/A       |                    |

## Assessment criteria

- 1. The floor area that is associated with the non-standard energy use should be measured. The floor area is calculated as follows for the non-standard energy uses:
- a. Regional server room: The area/room that houses the regional server equipment.
- b. Trading floor: The area/floor that comprises the trading.
- c. Bakery oven: The area comprising the bakery oven and the associated process.
- d. Sports floodlighting: The area/grounds that are lit by the floodlights.
- e. Furnace or forming process:
- i. The area comprising the furnace and the associated process.
- ii. The area comprising the forming process.
- f. Blast chilling or freezing: The area comprising the blast chiller/freezer and associated process.

## Evidence

- 1. Building plans illustrating floor area related to the non-standard energy use.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management ENE 62 - Energy consumption monitoring

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is energy consumption monitored and is this data accessible?

## Aim

To encourage the monitoring of energy consumption that in turn will allow building managers to set improvement targets.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. Consumption data can be acquired from:
- a. Meters (manually or automatically read)
- b. Delivery and stock-level figures
- 2. In order to illustrate that this data is accessible, the building management team (or whoever is responsible for  energy  measurement) must  present  data  held  in  a  single  location,  such  as  a  spreadsheet,  clearly arranged folders, building energy management systems or other relevant storage systems.  An example would be ENERGY STAR Portfolio Manager®, an online tool developed and managed by the US EPA, used to measure and track energy and water consumption, as well as greenhouse gas emissions.

## Evidence

- 1. Records of energy consumption data as part of a spread sheet; calculated from metering data or energy bills.

## Additional information

Assets using ENERGY STAR Portfolio Manager® to record and monitor their energy consumption can provide a spreadsheet download of the meter entries within ENERGY STAR as evidence once the Assessor has verified the data is held in the asset's building profile. -

<!-- image -->

<!-- image -->

## Building Management ENE 63 - Energy consumption data use

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

How is collected energy consumption data used?

## Aim

To facilitate the structured and systematic provision of reporting on energy consumption to encourage building users to understand and set efficiency improvement targets.

## Available credits

|   Credits | Answer option                                             |
|-----------|-----------------------------------------------------------|
|         0 | Question not answered                                     |
|         0 | Don't know                                                |
|         1 | Filed away                                                |
|         2 | Compared against asset targets                            |
|         3 | Compared against asset targets and reported on internally |
|         4 | All of the above and in addition reported to management   |
|         0 | Other                                                     |

## Assessment criteria

- 1. Building energy consumption should be monitored, targeted and reported to the appropriate level within the building occupant's organizational structure.
- 2. There are dedicated energy management/reduction targets endorsed at senior level. The targets must address/declare that:
- a. The organization is dedicated to reducing energy consumed as a result of its operation/s.
- b. The organization will work with occupiers/suppliers to address impacts of consumed energy and strategies to reduce consumption (if relevant).

## Evidence

- 1. Evidence of company utilizing data in ways identified, such as:
- a. Corporate Social Responsibility reports detailing how data is targeted and improved.
- b. Evidence of improvement target setting and ways these are implemented.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management ENE 64 - Sub-metering: Main energy sources

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

How many of the following main energy uses are covered by separate sub-meters:

-  Heating
-  Cooling
-  Interior Lighting
-  Ventilation

## Aim

To facilitate the structured and systematic provision of reporting on energy consumption to ensure building users understand and set targets to operate the building more efficiently.

## Available credits

|   Credits | Answer option             |
|-----------|---------------------------|
|         0 | Question not answered     |
|         0 | Don't know                |
|         0 | No sub-meters provided    |
|         1 | 1 of the main energy uses |
|         2 | 2 of the main energy uses |
|         3 | 3 of the main energy uses |
|         4 | 4 of the main energy uses |

## Assessment criteria

- 1. Only main energy uses are covered in this issue. Other energy uses are covered in Building Management ENE 65 - Sub-metering: Other energy sources.
- 2. Assessors should verify that the sub-meters were operational during the reporting period.

## Evidence

- 1. Copies of verified meter data for the first and last date of the 12-month reporting period.
- 2. Line diagram indicating sub-meters and the related energy uses.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management ENE 65 - Sub-metering: Other energy sources

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Which of the following energy uses are covered by separate sub-meters:

-  Exterior lighting
-  All means of vertical transportation (e.g. elevators and escalators)
-  Display and aesthetical effects lighting
-  Ventilation, heating and cooling in transitional spaces (e.g. air curtains and revolving doors)
-  Small power/plug load.

## Aim

To encourage separate metering of appliances within the asset in order to attain a better granularity of data which can be used to target improvements.

## Available credits

|   Credits | Answer option                       |
|-----------|-------------------------------------|
|         0 | Question not answered               |
|         0 | Don't know                          |
|         0 | None of the listed energy uses      |
|         1 | 1 of the listed energy uses         |
|         2 | 2 of the listed energy uses         |
|         3 | 3 of the listed energy uses         |
|         4 | 4 or more of the listed energy uses |

## Assessment criteria

- 1. Only energy uses that are sub-metered should be selected.
- 2. Sub-metering for main energy uses is covered by Building Management ENE 64 - Sub-metering: Main energy sources.

## Evidence

- 1. Copies or verified meter data for the first and last date of the 12-month period specified.
- 2. Line diagram indicating sub-meters and the related energy uses.

<!-- image -->

<!-- image -->

## Additional information

## Relevant definitions

Small power: plug-in equipment/appliances connected through power points.

<!-- image -->

Version 2.0: 2016, April 2019

<!-- image -->

## Building Management ENE 66 - Sub-metering: Tenanted areas

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are heating and cooling sub-meters provided for tenanted areas?

## Aim

To facilitate the structured and systematic provision of reporting on energy consumption to ensure building users understand and set targets to operate the asset more efficiently.

## Available credits

|   Credits | Answer option                                                     |
|-----------|-------------------------------------------------------------------|
|         0 | Question not answered                                             |
|         0 | Don't know                                                        |
|         0 | No                                                                |
|         2 | Yes the asset is partially sub-metered for tenanted areas         |
|         4 | Yes the asset is fully sub-metered or occupied by a single tenant |

## Assessment criteria

- 1. It is noted that lighting and small power can be difficult to separate cost effectively for metering purposes. Therefore, it is acceptable for lighting and small power to be combined per floor level.
- 2. For naturally ventilated assets: only heating sub-meters must be provided.

## Evidence

- 1. Copies of bills or verified data for the 12-month period specified.

## Additional information

## Relevant definitions

Small power: plug-in equipment/appliances connected through power points.

<!-- image -->

<!-- image -->

## Transport

The Transport category is not assessed within Part 2 of the BREEAM USA In-Use assessment.

## Water

## Category summary table

| Issue reference         | Title                                       |   Credits available |
|-------------------------|---------------------------------------------|---------------------|
| WAT 11                  | Annual consumption                          |                   4 |
| WAT 12                  | Water consumption: Monitoring and reporting |                   8 |
| WAT 13                  | Drinking water provision                    |                   2 |
| WAT 14                  | Refurbishment policy: Water efficiency      |                   2 |
| WAT 15                  | Water system maintenance strategy           |                   4 |
| WAT 16                  | Water recycling                             |                   4 |
| WAT 17                  | Water extraction                            |                   2 |
| Total credits available | Total credits available                     |                  26 |

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management WAT 11 - Annual consumption

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What is the annual water consumption? Enter volume in thousand gallons (kgal).

## Aim

To ensure management are aware of annual consumption from potable and non-potable water sources.

## Available credits

|   Credits | Enter volume in kgal   |
|-----------|------------------------|
|         4 |                        |

## Assessment criteria

- 1. Annual water consumption should include the sum of all water drawn into the boundaries of the reporting organization for this asset. This includes water consumption from potable and non-potable water sources (including groundwater, rainwater and utility water supply), for any use over the course of the reporting period.

## Evidence

- 1. Meter readings.
- 2. Utility bills.
- 3. Spreadsheet data derived from bills or meter readings.

## Additional information

-

<!-- image -->

<!-- image -->

## Building  Management  WAT  12  -  Water  consumption:  Monitoring  and reporting

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             8 | No                  |

## Question

Is  there a strategy in place to use water monitoring data to minimize water consumption that includes target setting and reporting mechanisms?

## Aim

To use information gained from monitoring to help inform the water strategy and reduce overall consumption.

## Available credits

|   Credits | Answer option                                                                                                               |
|-----------|-----------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                       |
|         0 | Don't know                                                                                                                  |
|         0 | No                                                                                                                          |
|         1 | Strategy is in place, no other actions are taken                                                                            |
|         2 | Strategy is in place and water targets are filed away                                                                       |
|         4 | Strategy is in place that compares water consumption against asset targets                                                  |
|         6 | Strategy is in place that compares water consumption against asset targets and report on these internally                   |
|         8 | Strategy is in place that compares water consumption against asset targets and report on these internally and to management |

## Assessment criteria

- 1. The strategy should outline how monitoring data will be used to help minimize water consumption. This could for example be through:
- a. Identifying areas of unexpectedly high water consumption that could indicate system leaks.
- b. Identifying the areas with high water consumption that should be targeted for installing water efficiency measures.
- c. Making monitoring data available to asset users with a view to modifying user behavior.

## Evidence

- 1. A copy of the strategy/policy.
- 2. Records of water consumption analysis; Spreadsheet, summary report etc.

<!-- image -->

<!-- image -->

- 3. Copies of how water consumption and analysis have been reported internally such as:
- a. Internal memos
- b. Newsletters or tenant/staff presentations
- c. Posters
- d. Emails
- 4. Copies if how water consumption and analysis have been reported to management such as:
- a. Summary
- b. Executive report
- c. Emails

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management WAT 13 - Drinking water provision

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is the provision of drinking water regularly reviewed to ensure that it meets users' needs?

## Aim

To recognize and encourage the provision of sufficient water access points.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Drinking water access points need to be:
- a. Easily accessible to all users; at least one access point per floor level, in a hygienic location and condition
- c. Appropriate in number and placement to serve all building users; as determined by the Assessor's best judgment
- 2. Assessors should ensure that the number of occupants is regularly reviewed and that access to drinking points is reflective of any changes in occupants.
- 3. Drinking water access points should at least be reviewed after:
- a. Refurbishments or alterations have been made to the building
- b. Significant changes in the number of occupants are recorded

## Evidence

- 1. Documentation specifying number of occupants in the building and per floor and the number of access points to drinking water, i.e. building plans specifying access points and number of occupants.
- 2. Documentation outlining  review  schedules,  major  changes  to  the  building  or  changes  in  numbers  of occupants.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management WAT 14 - Refurbishment policy: Water efficiency

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is  there  a  policy  in  place  to  replace  water  appliances  and  fittings  with  low  water  use  equivalents  during refurbishments?

## Aim

Promoting the reduction of water consumption through installation of water-efficient fixtures and fittings.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. As a minimum, the policy should include:
- a. A replacement program.
- b. A schedule of approved replacement appliances. The appliances listed in this schedule should be easy to identify to be of low water use by relevant labeling, such as the U.S. EPA's WaterSense . ®
- 2. If all water appliances and fittings have already been replaced with low water use equivalents, a policy should still be in place to ensure a continuation of good practice.

## Evidence

- 1. Copy of the policy document.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management WAT 15 - Water system maintenance strategy

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Does the organization have a strategy for maintaining water systems?

## Aim

To ensure that reliable water supplies are maintained and any wastage through leaks is minimized.

## Available credits

|   Credits | Answer option                             |
|-----------|-------------------------------------------|
|         0 | Question not answered                     |
|         0 | Don't know                                |
|         0 | No                                        |
|         2 | Yes                                       |
|         4 | Yes, it is a proactive maintenance policy |

## Assessment criteria

- 1. A proactive maintenance policy is a defined maintenance strategy to ensure that the reliability of the installed fittings and water systems is increased. These maintenance policies typically consist of two parts:
- a. Preventive maintenance: maintenance, measurements, tests, parts replacement, etc. to prevent faults from occurring.
- b. Predictive  maintenance:  maintenance  techniques  that  are  designed  to  help  determine  the condition of installed equipment in order to predict when maintenance should occur.

## Evidence

- 1. Copy of relevant section of maintenance strategy.
- 2. Copy of maintenance logs.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management WAT 16 - Water recycling

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of total water consumption is from alternative supplies?

## Aim

To encourage the use of alternative water supplies to reduce the demand for utility supplied fresh water.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | 0%                    |
|         1 | ≥1 to <25%            |
|         2 | ≥25 to <50%           |
|         3 | ≥50 to <75%           |
|         4 | ≥75%                  |

## Assessment criteria

- 1. Alternative water supplies include water that is treated prior to reuse and water that is not treated prior to reuse.
- 2. Both rainwater and greywater can be considered as alternative water supplies.
- 3. Other water sources can be used to meet the aim of the credit as long as the alternative water supply is used to reduce demand of utility-supplied fresh water for unregulated water uses.

## Evidence

## Either:

- 1. Calculations  (based  on  metered  data  for  both  utility  an  alternative  supplies)  to  demonstrate  the percentage of water consumption obtained from alternative supplies, OR
- 2. Meter readings for both utility and alternative supplies to allow the Assessor to calculate percentage of water from alternative supplies.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management WAT 17 - Water extraction

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is non-utility water extraction metered and monitored to avoid over-extraction?

## Aim

To avoid over-extraction of the water table.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | No water is extracted |
|         2 | Yes                   |

## Assessment criteria

- 1. It is essential that reliable metering provides a record of how much water is taken, metering will allow, and will thus illustrate:
- a. Catchments are accurately balanced against overall requirements, to maintain a healthy water environment
- b. Spare resources are allocated to new/future abstractions
- c. Equitable payments can be set
- d. Assurance that water permit conditions are being adhered to

## Evidence

- 1. Evidence of monitoring data
- 2. If possible, copy of policy which stipulates monitoring is to take place

## Additional information

-

<!-- image -->

<!-- image -->

## Materials

## Category summary table

| Issue reference         | Title                               |   Credits available |
|-------------------------|-------------------------------------|---------------------|
| MAT 08                  | Condition survey                    |                   4 |
| MAT 09                  | Sustainable procurement policy      |                   2 |
| MAT 10                  | Sustainable procurement initiatives |                   4 |
| MAT 11                  | Fire risk assessment                |                   2 |
| MAT 12                  | Fire risk management                |                   2 |
| MAT 13                  | Emergency plan                      |                   4 |
| MAT 14                  | Natural hazard management           |                   2 |
| Total credits available | Total credits available             |                  20 |

<!-- image -->

<!-- image -->

## Building Management MAT 08 - Condition survey

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Where a condition survey has been carried out, who was the responsible party for completing it?

## Aim

To ensure that a competent party carries out a condition survey.

## Available credits

|   Credits | Answer option                                                                   |
|-----------|---------------------------------------------------------------------------------|
|         0 | Question not answered                                                           |
|         0 | Don't know                                                                      |
|         0 | No condition survey has been carried out                                        |
|         1 | Carried out by the building management personnel                                |
|         2 | Carried out by building management following third party approved procedures    |
|         3 | Carried out by an independent third party                                       |
|         4 | Carried out by an independent chartered building surveyor                       |
|         4 | The asset is less than 5 years old and no condition survey has been carried out |
|         0 | Other                                                                           |

## Assessment criteria

- 1. The  responsible  party/person  that  carries  out  the  condition  surveys  must  be  suitably  trained  and experienced. Competent persons include:
- a. Facilities management/building management staff
- b. Civil engineers or other relevant engineering disciplines
- c. Architects
- d. Chartered surveyors
- a. Members of institutions whom have undergone appropriate due diligence or training to conduct condition surveys

## Evidence

- 1. Copy of the section/page of the condition survey stating the name and organization (including third party certification where available) of the party that carried out the condition survey.

<!-- image -->

<!-- image -->

- 2. Information  regarding  relevant  qualifications  and  experience  of  the  person  who  has  undertaken  the condition survey.
- 3. Assets that are less than 5 years old will require appropriate public records of property registration to demonstrate the building's age.

## Additional information

Chartered surveyor (CS) is  the term for a Professional Member or Fellow of the Royal Institution of Chartered Surveyors (RICS).  Though it started in the United Kingdom, the RICS is an international professional body that accredits professionals within the land, property and construction sectors across the world. In order to become a Chartered  Surveyor,  trainees  must  undertake  a  degree  accredited  by  the  RICS  and  pass  the  Assessment  of Professional  Competence.    Members  of  all  status  can  be  found  through  a  search  of  the  RICS  website: http://www.rics.org/us/find-a-member/

For  more  information  please  go  to  the  RICS  Americas  website:  http://www.rics.org/us/about-rics/where-weare/americas/about-rics-americas/  -

<!-- image -->

<!-- image -->

## Building Management MAT 09 - Sustainable procurement policy

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is an environmental/sustainable procurement policy in place with regards to the maintenance, refurbishment and operation of the building that covers materials, products, and services?

## Aim

To recognize and encourage the implementation of formal environmental policies that address, and aim to reduce organizational purchases of materials, products and services with a high environmental impact.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. An environmental purchasing policy should cover consumables and replacement equipment. The policy should have also been endorsed at senior management level.
- 2. The asset owner demonstrates (i.e. through examples) how the policy is implemented, either through general organizational operation, or project related initiatives and management strategies.
- 3. All  timber or timber-based products (such as paper and paper products) that are procured should be 'Legally harvested and Legally traded timber' as outlined in the additional information section.

## Evidence

- 1. A copy of the environmental/sustainable purchasing policy.

## Additional information

## Relevant definitions

Legally harvested timber :  timber that has been harvested in accordance with the applicable legislation in the country of harvest.

Legally traded timber : timber that is legally traded means timber or products derived from timber were:

- 1. Exported in compliance with exporting country laws governing the export of timber and timber products, including payment of any export taxes, duties, or levies.

<!-- image -->

<!-- image -->

- 2. Imported in compliance with importing country laws governing the import of timber and timber products, including payment of any import taxes, duties, or levies or not in contravention of exporting country laws governing the export of timber and timber products, including payment of any export taxes, duties, or levies.
- 3. Traded in compliance with legislation related to the Convention on International Trade In Endangered Species (CITES) where applicable.

<!-- image -->

<!-- image -->

## Building Management MAT 10 - Sustainable procurement initiatives

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What initiatives are included in the scope of the environmental/sustainable procurement policy?

## Aim

To recognize and encourage measures which ensure that environmental impacts associated with the management of the building are minimized by setting environmental standards for procurement of goods and services.

## Available credits

|   Credits | Answer option                                                                                                      |
|-----------|--------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                              |
|         0 | Don't know                                                                                                         |
|         0 | No policy in place                                                                                                 |
|         1 | The asset owner works with the supply chain to help reduce environmental impact of procurements                    |
|         1 | Environmental impacts of materials are taken into account with targets to reduce negative impacts                  |
|         1 | CO 2 emissions arising from transport of materials are taken into account and targets set to reduce CO 2 emissions |
|         1 | The asset owner has targets to reduce the consumption of hazardous materials                                       |
|         0 | Other                                                                                                              |

## Assessment criteria

- 1. The policy should be endorsed at senior management level.

## Evidence

- 1. A copy of the policy highlighting the relevant clauses.
- 2. Confirmation  of  the  name/position  of  the  top-level  manager  with  ownership  and  responsibility  for implementation.
- 3. Specific examples that demonstrate compliance with the policy objectives.

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Building Management MAT 11 - Fire risk assessment

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Has a fire risk assessment been carried out?

## Aim

To recognize and encourage the execution of a fire risk assessment that goes beyond statutory requirements and identifies fire risks to property and the environment and sets out procedures to keep these impacts to a minimum as far as practicable.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. For the purposes of this issue, the fire risk assessment should address property and the environment.
- 2. A fire risk assessment must be carried out by a competent person. For more complex assessments, the necessary competency may not reside with a single individual, but will instead be provided by a team, including those with relevant local knowledge.
- 3. A fire risk assessment should be carried out in accordance with a recognized methodology, e.g. NFPA 551 Guide for the Evaluation of Fire Risk Assessment.

## Evidence

- 1. Copy of most recent fire risk assessments carried out.
- 2. Documentation  (such  as  a  certificate)  to  prove  competence  of  the  person  undertaking  the  fire  risk assessment.
- 3. Information regarding relevant qualifications and experience of the person who has undertaken the fire risk assessment.

## Additional information

## Relevant definitions

Competent person: A competent person is 'a person with enough training and experience or knowledge and other qualities to enable them properly to assist in undertaking the preventative and protective measures'.

<!-- image -->

SD221 USA © BRE Global Ltd 2019

## Building Management MAT 12 - Fire risk management

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is  there a fire manager or other member of staff in place who manages, monitors and initiate reviews of the relevant procedures as identified in the fire risk assessment?

## Aim

To recognize and encourage proactive fire risk assessment practices which help ensure the risk of fire within the asset is kept to a minimum as far as practicable.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Fire risks identified through an appropriate fire risk assessment(s) should be continuously monitored to make sure that the risks of fire are kept to minimum, as far as is practicable. Competent persons should be involved in setting out and undertaking routine fire safety checks throughout the site.
- 2. Procedures  as  identified  in  the  fire  risk  assessment  should  at  least  be  reviewed  annually  AND  when changes are made to the building.
- 3. If  necessary,  evidence  provided  demonstrates  involvement of the fire service and/or accredited third party whom is competent.

## Evidence

- 1. Evidence provided for Building Management MAT 11 - Fire risk assessment.
- 2. Evidence of fire safety checking through documentation and recent examples.
- 3. If necessary, evidence of third party approval or fire service involvement.

## Additional information

## Relevant definitions

Competent person: A competent person is 'a person with enough training and experience or knowledge and other qualities to enable them properly to assist in undertaking the preventative and protective measures'. -

<!-- image -->

<!-- image -->

## Building Management MAT 13 - Emergency plan

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is there  an  emergency  plan  in  place  that  includes  strategies  for  the  protection  of  property  and/or  the environment?

## Aim

To encourage fire risk/emergency plans that go beyond statutory requirements and aim to protect property and the environment in addition to people.

## Available credits

|   Credits | Answer option                                         |
|-----------|-------------------------------------------------------|
|         0 | Question not answered                                 |
|         0 | Don't know                                            |
|         0 | No                                                    |
|         2 | Yes, protection of property                           |
|         4 | Yes, protection of property and environmental impacts |

## Assessment criteria

- 1. For the purposes of this issue, the emergency plan should address property and/or the environment.
- 2. In simple premises, the emergency plan may be no more than a fire action notice.
- 3. In multi-occupied and more complex premises, the emergency plan will need to be more detailed and compiled only after consultation with other responsible people, e.g. owners or other employees, who have control (or some control) over the building.
- 4. A complex building will usually require trained staff to assist other occupants who are not necessarily familiar with the building or its safety systems.
- 5. The following should at least be included or taken into consideration when developing an emergency plan:
- a. Providing an accessible means of escape solution should be an integral part of the fire safety management process.
- b. Fire safety management should take into account the full range of people who might use the premises, paying particular attention to the needs of people with physical or mental impairments.
- c. When providing means of escape for a building, intervention and assistance by the fire and rescue services should not be assumed or relied upon.
- d. In addition to life safety considerations, the fire safety plan may also include:

<!-- image -->

<!-- image -->

- i. Mitigation of potential environmental impacts of fire (e.g. water run-off)
- ii. Risk management, business continuity, contingency planning, restart planning
- iii. Contingency plans for salvage and damage control

## Evidence

- 1. A copy of the fire risk/emergency plan with sections that relate to the protection of building and contents identified.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management MAT 14 - Natural hazard management

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is a policy to enhance the protection of the asset from risks arising from natural hazards in place?

## Aim

To recognize and encourage policies that are in place to reduce risk of damage from natural hazards.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. A policy to enhance the protection of the asset from risks arising from relevant natural hazards should be in place.
- 2. Relevant  natural  hazard  risks  should  have  been  identified  and  a  policy  written  by  competent individuals/relevant organizations.
- 3. If there is no perceived threat from natural hazards this must be outlined in the natural risk policy.
- 4. Natural  hazards  are  natural  processes  or  phenomena  occurring  in  the  biosphere  or  crust  that  may constitute a damaging event. The list below is not intended to be exhaustive, but provides an indication of the type of hazards that should be considered to meet the definition. Other natural hazards may be relevant under this issue. Relevance will be dependent on local geography, geology, hydrology and climate factors  and  the  Assessor  should  be  satisfied  that  appropriate  local  expertise  has  been  sought  by  the client/design team to identify these fully:
- a. Floods (addressed in Asset Performance POL 02 - Flood risk assessment)
- b. Natural disasters of geological origin such as volcanic eruptions, earthquakes and landslides
- c. Natural disasters of climatic or meteorological origin such as droughts, avalanches, wave surges including tsunamis and tidal waves, and wind storms including cyclones, hurricanes, tornadoes, tropical storms, and typhoons
- d. Wildfires

## Evidence

- 1. A copy of the natural hazard risk policy/strategy.

<!-- image -->

<!-- image -->

- 2. Copy of qualification of person that has written the natural hazard risk policy.

## Additional information

## Relevant definitions

Competent individual: an individual (or individuals) with relevant technical and professional experience suitable to:

- a. Determine the potential for natural hazards in the region of the development
- b. Determine the likely impacts on the site, building and locality
- c. Subsequently identify appropriate mitigation measures

This (or these) individual(s) should practice to and abide by a professional code of conduct or similar.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Waste

The Waste category is not assessed within Part 2 of the BREEAM USA In-Use assessment.

## Land Use and Ecology

## Category summary table

| Issue reference         | Title                            |   Credits available |
|-------------------------|----------------------------------|---------------------|
| LE 03                   | Ecology report                   |                   4 |
| LE 04                   | Biodiversity action plan         |                   4 |
| LE 05                   | External landscaping/maintenance |                   2 |
| Total credits available | Total credits available          |                  10 |

<!-- image -->

<!-- image -->

## Building Management LE 03 - Ecology report

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Has an ecology report been developed?

## Aim

Encouraging organizations to establish the ecological value of their asset/site and improve the ecological value based on recommendations that have been made by a suitably qualified ecologist.

## Available credits

|   Credits | Answer option                                                 |
|-----------|---------------------------------------------------------------|
|         0 | Question not answered                                         |
|         0 | Don't know                                                    |
|         0 | No                                                            |
|         1 | Yes, none of the suggested improvements have been implemented |
|         2 | Yes, no ecology has been identified on site                   |
|         2 | Yes, and major improvements have been implemented             |
|         4 | Yes, and all improvements have been implemented               |
|         0 | Other                                                         |

## Assessment criteria

- 1. The ecology report detailing the outcomes of the ecology survey must either be written by an individual that meets the Suitable Qualified Ecologist (SQE) criteria or, where it is written by an ecologist who does not meet the SQE criteria, it has been reviewed and signed off by an SQE who must have found it to be:
- a. Representing sound industry practice
- b. Written objectively (avoiding invalid biased and exaggerated statements)
- c. Appropriate given the local site conditions and scope of works proposed
- 2. The ecologist must base their findings on data collected from a site visit conducted at appropriate time(s) of the year, when different plant and animal species are evident.
- 3. An SQE must be independent of the organization.

## Evidence

- 1. Copy of ecology survey, including report.

<!-- image -->

<!-- image -->

- 2. Evidence that the ecology survey was carried out by a competent individual such as: copies of relevant documents, qualifications, resume or industry membership.
- 3. Evidence that the recommendations were implemented.

## Additional information

## Relevant definitions

Suitably Qualified Ecologist: An individual achieving all the following items can be considered to be 'suitably qualified' for the purposes of a BREEAM USA In-Use assessment:

- a. Holds  a  degree  or  equivalent  qualification  in  ecology  or  in  a  related  subject  comprising  a significant ecology component.
- b. Is a practicing ecologist, with a minimum of three years relevant experience (within the last five years). Such experience must clearly demonstrate a practical understanding of factors affecting ecology in relation to construction and the built environment; including, acting in an advisory capacity  to  provide  recommendations  for  ecological  protection,  enhancement  and  mitigation measures. The relevant experience must relate to the region that the assessment is being carried out in.

<!-- image -->

<!-- image -->

## Building Management LE 04 - Biodiversity action plan

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is a biodiversity action plan in place that sets specific targets to enhance the ecological value of the site?

## Aim

To encourage organizations to develop a biodiversity action plan based on the outcomes of the ecology survey that set targets and is reviewed on a regular basis to enable assets to maintain and enhance the ecological value of the site.

## Available credits

|   Credits | Answer option                                                                        |
|-----------|--------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                |
|         0 | Don't know                                                                           |
|         0 | No                                                                                   |
|         4 | Yes                                                                                  |
|         4 | Not applicable, the ecology survey determined that there was no biodiversity on site |

## Assessment criteria

- 1. A Biodiversity Action Plan (BAP) should set targets that are:
- a.Specific to the asset/site
- b.Measurable and achievable
- c. Realistic and time bound
- 2. The BAP should be underpinned by the findings of the site ecology survey, which has been undertaken by a competent person. A competent person in this instance is a suitably qualified ecologist (SQE).
- 3. The BAP should be reviewed at least when large changes to the asset/site are made.
- 4. The BAP should link to local and regional biodiversity requirements in accordance with the Convention on Biological Diversity where applicable.

## Evidence

- 1. Copy of biodiversity plan/strategy.
- 2. Evidence  that  the  plan/strategy  was  developed  by  a  competent  individual  such  as  copies  of  relevant documents, qualifications, resume or industry membership.

<!-- image -->

<!-- image -->

## Additional information

## Relevant definitions

Suitably Qualified Ecologist: An individual achieving all the following items can be considered to be 'suitably qualified' for the purposes of a BREEAM USA In-Use International assessment:

- a. Holds  a  degree  or  equivalent  qualification  in  ecology  or  in  a  related  subject  comprising  a significant ecology component.
- b. Is a practicing ecologist, with a minimum of three years relevant experience (within the last five years). Such experience must clearly demonstrate a practical understanding of factors affecting ecology in relation to construction and the built environment; including, acting in an advisory capacity  to  provide  recommendations  for  ecological  protection,  enhancement  and  mitigation measures. The relevant experience must relate to the region that the assessment is being carried out in.

## Other information

Convention  on  Biological  Diversity  -  For  more  information  regarding  this  please  visit  the  official  website: http://www.cbd.int/convention/

<!-- image -->

<!-- image -->

## Building Management LE 05 - External landscaping/maintenance

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is there a policy/plan in place to maintain and improve the ecological value of the asset and its immediate site?

## Aim

To encourage organizations to develop a policy/plan that maintains and improves the ecological value of the asset and its immediate site.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. Organizations responsible for site landscaping should either,
- a. Have their own policies that stipulate that the work they undertake will maintain or enhance the ecological value on site.

OR

- b. Have contractual agreements with building management/building owner that stipulate that the work they undertake will maintain or enhance the ecological value on site.
- 2. The policy/plan should consist of (but is not limited to):
- a. Landscaping
- b. Integrated pest management
- c. Cleaning of façade, landscaping, and hardscape
- d. Planting/installation of features to enhance flora and fauna on site

## Evidence

- 1. Copy of relevant policy or contractual agreement.

## Additional information

## Relevant definitions

<!-- image -->

<!-- image -->

Integrated Pest Management (IPM) is a method of controlling pests by prevention, monitoring, and control. This method of pest control offers the opportunity to eliminate or drastically reduce the use of pesticides, and to minimize the toxicity of and exposure to any products that are used.

## Other information

External landscaping and maintenance plans would be informed by the outcomes of the ecological survey and biodiversity action plan. This will ensure that the ecological value of the site has been established and that the correct measures and plans are in place to ensure that the ecological value will be maintained.

<!-- image -->

<!-- image -->

## Pollution

## Category summary table

| Issue reference         | Title                               |   Credits available |
|-------------------------|-------------------------------------|---------------------|
| POL 07                  | Night time light pollution          |                   4 |
| POL 08                  | Chemical storage                    |                   4 |
| POL 09                  | Secondary containment               |                   2 |
| POL 10                  | Light-liquid separators             |                   2 |
| POL 11                  | Refrigerants                        |                   2 |
| POL 12                  | Land contamination mitigation       |                   4 |
| POL 13                  | Emergency preparedness and response |                   2 |
| POL 14                  | Complaints procedure                |                   4 |
| Total credits available | Total credits available             |                  24 |

<!-- image -->

<!-- image -->

## Building Management POL 07 - Night time light pollution

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are steps taken to minimize night time light pollution arising from internal and external lighting?

## Aim

To ensure that internal and external lighting is concentrated in the appropriate areas and that upward lighting is minimized, reducing unnecessary light pollution, and nuisance to neighboring properties.

## Available credits

|   Credits | Answer option                                                                                                         |
|-----------|-----------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                 |
|         0 | Don't know                                                                                                            |
|         0 | No                                                                                                                    |
|         2 | Yes, routine checks and monitoring is performed by building/facility management                                       |
|         4 | Yes, a light pollution survey has been conducted by a third party and all recommendations have been fully implemented |

## Assessment criteria

- 1. A light pollution survey should (at least) be undertaken:
- a. When significant changes are made to the building and/or the site
- b. Once every 4 years
- 2. Internal and external lighting should be designed to reduce light pollution. Design measures could include for example:
- a.    Selecting fittings that focus light onto desired areas only
- b. Using light sources with the minimum intensity required to achieve desired luminosity levels
- c. Internal  and  external  lighting  can  be  automatically  switched  off  between  11pm  and  6am. Options to achieve this are, but are not limited to:
- i. Providing a timer for all internal and external lighting set to the appropriate hours
- ii. By formal requirements in contracts for staff that is last to leave occupied spaces within the asset
- 3. If there is no external lighting on or around the assessed development, the requirements only apply to internal lighting.

<!-- image -->

<!-- image -->

- 4. Where light fittings are specified to comply with specific security standards and these conflict with these BREEAM  USA  In-Use  criteria  they  can  be  excluded  from  the  assessment  of  this  issue.  In  these circumstances, the Assessor must obtain evidence confirming that the specific security standards are applicable to the assessed development.
- 5. Where a different curfew time applies for other reasons (e.g. noise control), consideration should be given to the co-ordination of the curfews, e.g. allowing sufficient time of operation for the lighting after the conclusion of the activity to facilitate crowd dispersal, particularly where large numbers of spectators are involved.
- 6. Where non-security lighting is considered to be essential between 11pm and 6am, i.e. for buildings which open/operate between these times, the lighting system is able to automatically switch to lower levels of lighting recommended for lighting during these hours (or provide these lower levels at all times).
- 7. Flush  stud  lights  used  for  safety  purposes  in  vehicle  maneuvering  areas  may  be  excluded  from  the assessment.

## Evidence

- 1. Photographic evidence confirming that external luminaires are designed to restrict upward light and light spill
- 2. Confirmation that lighting is switched off after a set time.
- 3. Copies of sections of light pollution survey specifying results and recommendations.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management POL 08 - Chemical storage

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are all  hazardous chemicals stored in areas with adequate containment to deal  with ≥110% of the chemicals stored?

## Aim

To reduce the impact of a chemical leak/spill by ensuring that these areas remain effective in the event of a leak/spill

## Available credits

|   Credits | Answer option                                                       |
|-----------|---------------------------------------------------------------------|
|         0 | Question not answered                                               |
|         0 | Don't know                                                          |
|         0 | No                                                                  |
|         4 | Not applicable, there are no hazardous chemical stored in the asset |
|         4 | Yes                                                                 |

## Assessment criteria

- 1. Containment for spillage can come in the form of one mitigation measure or the combination of several. Mitigation measures can include, (but are not limited to):
- a. Double skinned tanks
- b. Drip trays
- c. Non-permeable membranes in the room where tanks are located
- d. Secondary containment

## Evidence

- 1. Photographic evidence of chemical storage.
- 2. Confirmation that facilities are appropriate to the area they serve.

## Additional information

## Relevant definitions

Secondary containment: a structure made of an impermeable material that forms a barrier to retain liquids.

<!-- image -->

<!-- image -->

## Building Management POL 09 - Secondary containment

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are secondary containment areas checked regularly to ensure that they remain effective?

## Aim

To maintain the effectiveness of any secondary containment areas.

## Available credits

|   Credits | Answer option                                                                                                    |
|-----------|------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                            |
|         0 | Don't know                                                                                                       |
|         0 | No                                                                                                               |
|         2 | No secondary containment areas required as no liquids requiring secondary containment storage are stored on-site |
|         2 | Yes                                                                                                              |

## Assessment criteria

- 1. Where secondary containment areas are present internal checks are conducted at planned intervals to determine  whether  the  secondary  containment  areas  are  being  maintained  to  operate  at  optimum efficiency.

## Evidence

- 1. Copy of logbook or inspection schedule.

## Additional information

## Relevant definitions

Secondary containment : a structure made of an impermeable material that forms a barrier to retain liquids.

<!-- image -->

<!-- image -->

## Building Management POL 10 - Light-liquid separators

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Does the scope of the maintenance policy cover light-liquid separators?

## Aim

To ensure light-liquid separators are maintained to operate as intended.

## Available credits

|   Credits | Answer option                      |
|-----------|------------------------------------|
|         0 | Question not answered              |
|         0 | Don't know                         |
|         0 | No                                 |
|         2 | No light-liquid separators on site |
|         2 | Yes                                |

## Assessment criteria

- 1. Detailed inspection and maintenance requirements should be documented in the maintenance policy.

## Evidence

- 1. Copy of maintenance policy highlighting the light-liquid separator maintenance schedule.

## Additional information

## Relevant definitions

Light-liquid  separators are  a  vessel,  as  part  of  a  surface  water  drainage  system,  into  which  potentially contaminated wastewater will flow and where light liquids are separated from the wastewater by means of gravity and/or coalescence, and retained.

<!-- image -->

<!-- image -->

## Building Management POL 11 - Refrigerants

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is a strategy and timetable to replace refrigerants with low environmental impact alternatives in place?

## Aim

To reduce the impact of refrigerants on the environment.

## Available credits

|   Credits | Answer option                                                                                    |
|-----------|--------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                            |
|         0 | Don't know                                                                                       |
|         0 | No                                                                                               |
|         2 | No as refrigerants have been replaced with low environmental impact alternatives/were never used |
|         2 | Yes                                                                                              |

## Assessment criteria

- 1. The strategy needs to cover:
- a. Equipment containing refrigerants which is to be replaced
- b. What low environmental impact refrigerant the existing refrigerant is to be replaced with
- c. The timescale over which this is to be delivered
- 2. The strategy should cover air conditioning and refrigeration systems equipment within the building for the following uses, including:
- a. Comfort cooling
- b. Cold storage, including commercial food/drink display cabinets but excluding domestic appliances e.g. refrigerators and freezers
- c. Process based cooling loads e.g. servers/IT equipment
- 3. Small multiple hermetic systems are exempt where the refrigerant charge in each unit is 11lbs or less.
- 4. If replacement has already taken place then full credits can be awarded.

## Evidence

- 1. Copy of the strategy/objectives relating to replacing refrigerants.

<!-- image -->

<!-- image -->

## Additional information

## Other information

Table 14: Examples of refrigerants with a low Global Warming Potential (GWP)

| R-Number   | Chemical name                 | GWP(100-yr)   |
|------------|-------------------------------|---------------|
| R-30       | Dichloromethane               | 9             |
| R-170      | Ethane                        | 3             |
| R-290      | Propane                       | 3             |
| R-600      | Butane                        | 3             |
| R-600a     | Isobutane                     | 3             |
| R-702      | Hydrogen                      | 5.8           |
| R-717      | Ammonia                       | 0             |
| R-718      | Water                         | <1            |
| R-729      | Air (Nitrogen, oxygen, argon) | 0             |
| R-744      | Carbon dioxide                | 1             |
| R1216      | Ethylene                      | 3             |
| R-1234yf   | 2,3,3,3-Tetrafluoropropene    | <1            |
| R-1270     | Propylene                     | 3             |

Sources: The United Nations Environment Programme (UNEP) '2010 Report of the Refrigeration, Air-conditioning and Heat Pumps Technical Options Committee'

EN 378-1:2008+A2:2012: Refrigerating systems and heat pumps - Safety and environmental requirements. Part 1: Basic requirements, definitions, classification and selection criteria - Annex E.

The Intergovernmental Panel on Climate Change 5th Assessment Report, Chapter 8, 'Anthropogenic and Natural Radiative Forcing', 2013

'Global environmental impacts of the hydrogen economy', Derwent et al , Int. J. Nuclear Hydrogen Production and Application, Vol. 1, No. 1, 2006

<!-- image -->

<!-- image -->

## Building Management POL 12 - Land contamination mitigation

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Has  an  assessment  of  the  site  been  performed  to  check  for  potential  land  contamination  issues  (e.g. environmental due diligence, desk study, intrusive investigation, etc.)?

## Aim

To recognize and encourage actions taken which prevent/reduce risk of the site having a negative impact on the surrounding environment.

## Available credits

|   Credits | Answer option                                         |
|-----------|-------------------------------------------------------|
|         0 | Question not answered                                 |
|         0 | Don't know                                            |
|         0 | No                                                    |
|         2 | Yes                                                   |
|         4 | Yes, and all contamination issues have been addressed |
|         4 | Yes, no contamination issues have been found          |

## Assessment criteria

- 1. For 2 credits: A contaminated land specialist's site investigation should identify:
- a. Any areas of contamination and the degree of contamination
- b. The contaminant sources/types
- c. The options for remediating sources of pollution which present unacceptable risk to the site and surrounding environment
- 2. For 4 credits, in addition to the above, the following must apply: Any areas of contamination identified in the  contaminated  land  site  investigation  have  been  remediated  in  accordance  with  the  remediation strategy and its implementation plan.

## Evidence

- 1. Copy of the land specialist's contamination report.
- 2. A copy of the professional report (or relevant sections of the report) confirming:
- a. Description of the remedial works undertaken
- b. Description  of  the  pollution  linkages  addressed  (this  may  not  be  applicable  where  the contaminant is a non-native invasive plant species)

<!-- image -->

<!-- image -->

## Additional information

## Relevant definitions

Contaminant is defined as any solid, liquid or gaseous material in, or on the ground to be covered by the building, which is classed as a hazard and therefore presents an unacceptable risk to human health and the environment. The definition also includes land significantly infested by non-native invasive plant species.

Non-native  invasive  plant species  are  non-indigenous  species  that  adversely  affect  the  habitats  they  invade economically,  environmentally  or  ecologically.  Further  information  on  control  and  disposal  together  with legislative requirements relating to such species should be obtained from the relevant environmental body.

A relevant pollutant linkage is  one that has been identified during the risk assessment stage as representing inacceptable risks to human health or the environment.

<!-- image -->

<!-- image -->

## Building Management POL 13 - Emergency preparedness and response

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is  a  response  plan  in  place  to  deal  with  pollution  incidents  in  line  with  national  standards  or  best  practice guidelines?

## Aim

To reduce the impact of any pollution incidents on the surrounding environment.

## Available credits

|   Credits | Answer option                                                     |
|-----------|-------------------------------------------------------------------|
|         0 | Question not answered                                             |
|         0 | Don't know                                                        |
|         0 | No                                                                |
|         2 | No pollution risks identified for asset                           |
|         2 | Yes                                                               |
|         2 | Not applicable as no sources of pollution are located on the site |

## Assessment criteria

- 1. A response plan outlining emergency response procedures for dealing with potential pollution incidents should be in place. Sources of potential pollution include (but are not limited to):
- a. Fuel storage (e.g. diesel for emergency back-up generators)
- b. Refrigerants that are stored on site
- 2. The response plan should be periodically reviewed, especially after the occurrence of any accidents or emergency situations.
- 3. Where practical, the response procedures should be tested periodically.

## Evidence

- 1. Copy of the response plan outlining the incident response procedures.
- 2. Records of any testing of emergency response procedures.

## Additional information

-

<!-- image -->

<!-- image -->

## Building Management POL 14 - Complaints procedure

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is there a complaints procedure in place that deals with any issues relating to the asset and associated operations (e.g. noise, odor, and light)?

## Aim

To ensure any issues affecting building users or occupiers in the surrounding areas can be raised through a formal route and dealt with effectively.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. The complaints procedure should detail how to deal with any complaints quickly and impartially.

## Evidence

- 1. Copy of relevant complaints procedure

## Additional information

-

<!-- image -->

<!-- image -->

## Part 3: Occupier Management

## Assessment of the occupier's policies and activities that are conducted within the building

| Issue reference         | Categories              |   Credits available |
|-------------------------|-------------------------|---------------------|
| MAN                     | Management              |                  92 |
| HEA                     | Health &Wellbeing       |                 112 |
| ENE                     | Energy                  |                 124 |
| TRA                     | Transport               |                  89 |
| WAT                     | Water                   |                  83 |
| MAT                     | Materials               |                 106 |
| WST                     | Waste                   |                  79 |
| LE                      | Land Use & Ecology      |                  13 |
| POL                     | Pollution               |                  91 |
| Total credits available | Total credits available |                 789 |

<!-- image -->

<!-- image -->

## Management

## Category summary table

| Issue reference         | Title                                   |   Credits available |
|-------------------------|-----------------------------------------|---------------------|
| MAN14                   | Environmental management policy         |                   4 |
| MAN15                   | Environmental management issues         |                  16 |
| MAN16                   | Environmental management implementation |                  13 |
| MAN17                   | Environmental objectives                |                   4 |
| MAN18                   | Organizational performance review       |                   2 |
| MAN19                   | Sustainability report                   |                   3 |
| MAN20                   | Green lease                             |                   4 |
| Total credits available | Total credits available                 |                  46 |

<!-- image -->

<!-- image -->

## Occupier Management MAN 14 - Environmental management policy

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | Yes                 |

## Question

Is there an environmental management policy and/or procedure in place?

## Aim

To recognize and encourage the implementation of a formal environmental management policy in which the intent and objectives to manage environmental activities are outlined and responsibilities allocated.

## Minimum standards

- 1. To gain a 'Pass' rating there must be evidence that an environmental policy and/or procedure is/are under development.
- 2. To gain a 'Very Good' rating there must be evidence that an environmental policy and/or procedure is in place and has been endorsed by the board of directors/senior management.

## Available credits

|   Credits | Answer option                                                                                                                                                                                                 |
|-----------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                                                                         |
|         0 | There is no environmental policy and/or procedure                                                                                                                                                             |
|         1 | An environmental policy and/or procedure is under development                                                                                                                                                 |
|         2 | An environmental policy and/or procedure is under development with a ≤ 2 year endorsement plan                                                                                                                |
|         3 | An environmental policy and/or procedure is in place and has been endorsed by the board of directors/senior management                                                                                        |
|         4 | An environmental policy and/or procedure has been developed with stakeholders' consultation in compliance with the guidance given in ISO 14001, or equivalent and stakeholders' comments have been integrated |
|         0 | Other                                                                                                                                                                                                         |

## Assessment criteria

- 1. The environmental management policy should:
- a. Be appropriate to the nature, scale and environmental impacts of an organization's activities, products and services
- b. Include a commitment to continual improvement and prevention of pollution

<!-- image -->

<!-- image -->

- c. Include a commitment to comply with applicable legal requirements and with other requirements which relate to an organizations specific environmental aspects
- d. Install a framework for setting and reviewing environmental objectives and targets
- e. Be documented, implemented and maintained
- f. Is communicated to all persons working for or on behalf of the organization

## Evidence

- 1. For 1 credit: Copy of the confirmation that the environmental management policy and/or procedure is being developed with the proposed timing and amount currently completed.
- 2. For  2  credits:  Confirmation  that  the  environmental  management  policy  and/or  procedure  is  being developed with a proposed time line showing that it will be implemented within 2 years.
- 3. For 3 credits: A copy of the environmental management policy and / or relevant procedures signed by top management.
- 4. For 4 credits: Copy of current ISO 14001 certificate, or equivalent third party certification document.

## Additional information

## Other information

See: ISO 14001 ' Environmental Management Systems - Requirements with guidance for use ' (ISO 14001:2004 A.2 Environmental Policy, ISO 14001:2015 5.2 Environmental Policy)

The  environmental  policy  is  the  driver  for  implementing  and  improving  an  organization's  environmental management so that it can maintain and/or improve its environmental performance. A policy should therefore reflect commitment of top management to comply with applicable legal requirements, to prevent pollution and to continually improve.

## About ISO 14001

The  International  Organization  for  Standardization  (ISO)  14000  series  sets  the  criteria  for  companies  and organizations of all types to identify and appropriately manage their environmental impacts and responsibilities. The  ISO  14001  standard  maps  out  a  framework  that  an  organization  can  follow  to  set  up  an  effective environmental management system.  Third party certification provides assurance to all stakeholders that the environmental management system is meets the international standard and is effectively implemented in the organization.

All ISO standards are reviewed every five years to establish if a revision is required to keep it current and relevant for the marketplace.  Organizations currently certified to ISO 14001:2004 have three years to transition to the current standard, ISO 14001:2015.

<!-- image -->

<!-- image -->

## Occupier Management MAN 15 - Environmental management issues

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            16 | Yes                 |

## Question

Which of the following issues do the environmental management arrangements specifically measure/manage?

## Aim

To encourage the management of a broad range of environmental issues.

## Minimum standards

- 1. To gain a 'Good' rating, environmental management arrangements that measure and monitor energy consumption,  energy  efficiency  and  supply  including  targets  for  reduction  of  energy  consumption contained within an energy plan, AND waste reduction and management must be in place within the occupying organization.
- 2. In addition to point 1, to gain a 'Very Good' rating, environmental management arrangements are in place to measure and monitor Pollution reductions.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Issue                                                                                                                                              |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------|
|         1 | Energy consumption, energy efficiency and supply including targets for reduction of energy consumption contained within an energy plan             |
|         1 | Water consumption, efficiency and wastage                                                                                                          |
|         1 | Waste reduction and management                                                                                                                     |
|         1 | Pollution reduction/control                                                                                                                        |
|         1 | Reductions in the carbon footprint of business travel                                                                                              |
|         1 | Responsible purchasing of products and services                                                                                                    |
|         1 | Reductions in the carbon footprint of staff commuting                                                                                              |
|         1 | Decision processes which actively promote more sustainable purchasing practices including consideration of cost, time and quality                  |
|         1 | Decision processes which address environmental and sustainability issues alongside cost, time and quality when planning capital expenditure        |
|         1 | Decision processes which address environmental and sustainability issues alongside cost, time and quality when planning accommodation requirements |
|         1 | Measurements of company carbon footprint against a verifiable system in kgCO 2 /ft 2                                                               |

<!-- image -->

| Credits   | Issue                                                                     |
|-----------|---------------------------------------------------------------------------|
| 1         | Land use, ecology and biodiversity                                        |
| 1         | Environmental policy in use as a minimum standard for all sub-contractors |
| 1         | Policy to offset carbon emission                                          |
| 1         | Promotion of flexible working arrangements to reduce unnecessary travel   |
| 1         | Promotion of home working arrangements to reduce unnecessary travel       |
| -         | Other                                                                     |

## Assessment criteria

- 1. An organization should identify the environmental aspects within the scope of its business operations, taking into account the inputs and outputs associated (intended and unintended) with its activities. This includes products and services, planned or new developments, or new or modified activities for example.
- 2. An organization should establish, implement and maintain procedures(s) that are documented and kept up  to  date,  ensuring  that  significant  environmental  aspects  are  taken  into  account  in  establishing, implementing and maintaining appropriate environmental management.
- 3. An organization should consider aspects that it can influence, such as those related to goods and services used by the organization and those related to products and services that it provides.

## Evidence

- 1. Copy of the Environmental Management processes and procedures with relevant sections highlighted.

## Additional information

## Other information

See: ISO 14001 ' Environmental Management Systems - Requirements with guidance for use ' (ISO 14001:2004 A.3.1 Environmental aspects, ISO 14001:2015 6.1 Planning: Actions to address risks and opportunities)

## About ISO 14001

The  International  Organization  for  Standardization  (ISO)  14000  series  sets  the  criteria  for  companies  and organizations of all types to identify and appropriately manage their environmental impacts and responsibilities. The  ISO  14001  standard  maps  out  a  framework  that  an  organization  can  follow  to  set  up  an  effective environmental management system.  Third party certification provides assurance to all stakeholders that the environmental management system is meets the international standard and is effectively implemented in the organization.

All ISO standards are reviewed every five years to establish if a revision is required to keep it current and relevant for the marketplace.  Organizations currently certified to ISO 14001:2004 have three years to transition to the current standard, ISO 14001:2015.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Occupier Management MAN 16 -Environmental management

## implementation

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            13 | No                  |

## Question

To what degree have the environmental management arrangements been implemented and improvements been managed?

## Aim

To encourage the implementation of environmental management arrangements throughout the organization.

## Available credits

|   Credits | Answer options                                                                                                                                                                                                                                                    |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         1 | All environmental aspects and all prevention policies have been identified and defined                                                                                                                                                                            |
|         1 | All environmental issues that may arise from within the asset have been regularly reviewed.                                                                                                                                                                       |
|         1 | Targets are set and monitored to ensure that actions are completed                                                                                                                                                                                                |
|         1 | Management arrangements include procedures to incorporate feedback from staff, clients and other stakeholders                                                                                                                                                     |
|         1 | Individual staff are identified who are accountable for implementation of the environmental policies, objectives and targets                                                                                                                                      |
|         1 | Formal, regular training is provided for key environmental management staff                                                                                                                                                                                       |
|         1 | Where no Environmental Management System (EMS) is in place, an EMS is under development                                                                                                                                                                           |
|         2 | EMSis in place that includes procedures to review position against anappropriate peer group through published guidance, benchmarking etc.                                                                                                                         |
|         4 | An Environmental management system (EMS) has been in place for at least 3 years covering activities which are related to the building/site under assessment in accordance with the principles of ISO 14001 and has an independent third party audit/certification |
|         0 | Other                                                                                                                                                                                                                                                             |

## Assessment criteria

- 1. Management should ensure the availability or resources essential to establish, implement, maintain and improve the environmental management policy.
- 2. Appropriate roles, responsibilities and authorities should be defined, documented and communicated in order to facilitate effective environmental management. As part of this commitment, top management

<!-- image -->

<!-- image -->

should designate a specific management representative(s) with defined responsibility and authority for implementing the environmental management system.

- 3. There  should  be  regular  reporting  to  top  management  on  the  performance  of  the  environmental management system for review, including recommendations for improvement.
- 4. The  organization  should  identify  the  awareness,  knowledge,  understanding  and  skills  needed  by  any person with responsibility and authority to perform tasks relating to environmental management on its behalf if necessary. Competence should be measured on the basis of appropriate education, training and experience, and associated records shall be retained.
- 5. The organization should ensure that employees are aware of the organization's environmental policy and environmental management system as well as the environmental aspects of the organization's activities, products and services that could be affected by their work.
- 6. Organizations  should  have  implemented  procedures  for  receiving,  documenting  and  responding  to relevant communications from interested parties.
- 7. When considering external communication about environmental aspects, organizations should take into consideration the views and information needs of all interested parties. Where organizations elect to communicate externally, the organization should establish a procedure to do so. Methods of external communication can include annual reports, newsletters, websites and community meetings.

## Evidence

- 1. Staff interviews.
- 2. Copy of the environmental management agreement.
- 3. Copy of EMS surveillance audit report(s) conduct by appropriate third party organization (if applicable).
- 4. Copy of certificate reference number (if applicable).
- 5. Records and certificates of employee(s) qualifications and/or relevant training (if applicable).
- 6. Copy of benchmark data used (if applicable).
- 7. Evidence of Management review(s); minutes, action plans (if applicable).

## Additional information

## Other information

See: ISO 14001 ' Environmental Management Systems - Requirements with guidance for use ' (ISO 14001:2004 A.4 Implementation and operation, ISO 14001:2015 7 Support)

## About ISO 14001

The  International  Organization  for  Standardization  (ISO)  14000  series  sets  the  criteria  for  companies  and organizations of all types to identify and appropriately manage their environmental impacts and responsibilities. The  ISO  14001  standard  maps  out  a  framework  that  an  organization  can  follow  to  set  up  an  effective environmental management system.  Third party certification provides assurance to all stakeholders that the environmental management system is meets the international standard and is effectively implemented in the organization.

<!-- image -->

<!-- image -->

All ISO standards are reviewed every five years to establish if a revision is required to keep it current and relevant for the marketplace.  Organizations currently certified to ISO 14001:2004 have three years to transition to the current standard, ISO 14001:2015.

<!-- image -->

<!-- image -->

## Occupier Management MAN 17 - Environmental objectives

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | Yes                 |

## Question

In the last reporting year for the organization, what percentage of organizational environmental objectives were achieved?

## Aim

To encourage and recognize the continual improvement of environmental performance.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | <25%                  |
|         1 | ≥25% to <50%          |
|         2 | ≥ 50% to <75%         |
|         3 | ≥75% to <100%         |
|         4 | 100%                  |

## Assessment criteria

- 1. The organization must have a minimum of 6 set targets within the Environmental Management Policy in order to achieve any credits.
- 2. Environmental objectives are to be established and maintained at relevant functions and levels within the organization. These should be specific and measurable wherever practicable, and consistent with the environmental policy, including the commitments to prevention of pollution, compliance with applicable legal requirements, and continual improvement.
- 3. Organizations should be able to demonstrate that the credit criteria has been met by providing up to date records of environmental impacts on site which have been targeted and met.
- 4. Targets should address major relevant environmental impacts for which the organization is responsible, such as those identified in Environmental Management Policy.
- 5. Organizations should be able to demonstrate how they have achieved reductions.

## Evidence

- 1. Copy of documented environmental objectives.
- 2. Internal audit reports measuring environmental performance.
- 3. Management Review Minutes.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

- 4. Organizational Corporate Sustainability Report, documenting performance against objectives.

## Additional information

## Other information

See: ISO 14001 ' Environmental Management Systems - Requirements with guidance for use ' (ISO 14001:2004 4.3.3 Objectives, targets and programme(s); ISO 14001:2015 6.2 Environmental objectives and planning to achieve them)

The  program  for  establishing  objectives  should  include,  where  appropriate  and  practical,  consideration  of planning, design, production, marketing, and disposal stages. This can be undertaken for both current and new activities, products or services. For products, this can address design, materials, production processes, use and ultimate disposal. For installations or significant modifications of processes, this can address planning, design, construction, commissioning,  operation  and,  at  the appropriate  time  determined  by  the  organization, decommissioning.

<!-- image -->

<!-- image -->

## Occupier Management MAN 18 - Organizational performance review

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

How often is a review of the organizational performance against the environmental objectives carried out by the board of directors/senior management?

## Aim

To encourage the development and review of environmental objectives to continually improve organizational performance.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | Never                 |
|         0 | Infrequently          |
|         1 | At least annually     |
|         2 | At least twice a year |

## Assessment criteria

- 1. Reviews should include, but are not limited to:
- a. Results of evaluations of compliance with legal requirements.
- b. Communication(s) from external interested parties, including complaints.
- c. The environmental performance of the organization.
- d. Performance against objectives and targets.
- e. Follow-up actions from previous reviews.
- f. Changing circumstances, including developments in legal and other requirements related to the organizations environmental impacts.
- g. Recommendations for improvement.
- 2. A management review should cover the scope of the environmental management system, although not all elements of the environmental system need to be reviewed at once and the review process may take place over a period of time.

## Evidence

<!-- image -->

<!-- image -->

- 1. Review minutes, indicating agreed recommendations for improvement.
- 2. Results of review and changes made.

## Additional information

See: ISO 14001 ' Environmental Management Systems - Requirements with guidance for use ' (ISO 14001:2004 4.6 Management Review; ISO 14001:2015 9.3 Management review).

<!-- image -->

<!-- image -->

## Occupier Management MAN 19 - Sustainability report

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             3 | Yes                 |

## Question

Does the organization produce a sustainability/Corporate Social Responsibility (CSR) report?

## Aim

To ensure transparent communication of social, economic and environmental performance.

## Minimum standards

- 1. To gain a 'Good' rating the occupying organization must provide appropriate evidence that a CSR report exists but hasn't been independently verified.
- 2. To  gain  a  'Very  Good'  rating  the  occupying  organization  must  ensure  that  the  CSR  report  has  been independently verified by a third-party assurance/verification body and is accessible to all internal and external stakeholders.

## Available credits

|   Credits | Answer option                                                                                                                                                                                                      |
|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                                                                                              |
|         0 | No                                                                                                                                                                                                                 |
|         1 | Yes. Internal report which is not independently verified                                                                                                                                                           |
|         2 | Yes. Report is independently verified by a third-party assurance/verification body and is accessible to all internal and external stakeholders                                                                     |
|         3 | Yes. Report conforms to the Global Reporting Initiative (GRI) guidelines and it is independently verified by a third-party assurance/verification body and is accessible to all internal and external stakeholders |
|         0 | Other                                                                                                                                                                                                              |

## Assessment criteria

- 1. The  sustainability/CSR report should  provide  a  balanced  and  reasonable  representation  of  the sustainability performance of the reporting organization - covering both positive and negative issues.
- 2. The report should have been written based on accurate, verifiable data, collected by the organization over the period of one year. A report which covers a period of more than 1 year is compliant when it includes data for each yearly interval.

## Evidence

- 1. Copy  of  sustainability report  with  sections  about  the  performance  of  the  organization  against sustainability objectives and targets.

<!-- image -->

<!-- image -->

- 2. Name of third-party organization whom independently verified report (if applicable)
- 3. Review organization website for electronic copy of publication.

## Additional information

## Other information

The standardized content for International Sustainability/Corporate Social Responsibility Reports is documented by the Global Reporting Initiative (GRI). The GRI express that organizations aiming to report on sustainability performance must report on their Social, Economic and Environmental performance indicators.

<!-- image -->

<!-- image -->

## Occupier Management MAN 20 - Green lease

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Are tenants engaged and actively involved in a green lease with their landlord?

## Aim

To  ensure  the  collaboration  between  building  owners  and  occupiers,  in  order  to  improve  the  environmental performance of the building.

## Available credits

|   Credits | Answer option                                                                   |
|-----------|---------------------------------------------------------------------------------|
|         0 | Question not answered                                                           |
|         0 | Don't know                                                                      |
|         0 | No                                                                              |
|         2 | Yes (with qualitative targets)                                                  |
|         4 | Yes (with qualitative and quantitative targets on at least lighting and energy) |
|         4 | Not applicable, the building is owner-occupied                                  |

## Assessment criteria

- 1. See compliance requirement from Building Management MAN 11 - Green lease.

## Evidence

- 1. Copy of green lease agreement.

## Additional information

-

<!-- image -->

<!-- image -->

## Health and Wellbeing

## Category summary table

| Issue reference         | Title                                      |   Credits available |
|-------------------------|--------------------------------------------|---------------------|
| HEA 25                  | Occupier satisfaction                      |                  10 |
| HEA 26                  | Health and wellbeing management targets    |                  57 |
| HEA 27                  | Health and wellbeing management objectives |                   4 |
| HEA 28                  | View out                                   |                   2 |
| HEA 29                  | Communal rest areas                        |                   2 |
| Total credits available | Total credits available                    |                  75 |

<!-- image -->

<!-- image -->

## Occupier Management HEA 25 - Occupier satisfaction

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            10 | Yes                 |

## Question

Are the following key issues measured, monitored, and managed?

## Aim

To ensure that staff capabilities, prospects and wellbeing are enhanced by the organization.

## Minimum standards

- 1. To gain a 'Good' rating the occupying organization is required to measure, monitor and manage the skills and capabilities of employees.
- 2. In addition to point 1, to gain a 'Very Good' rating the occupying organization is required to measure, monitor and manage workplace comfort.
- 3. In addition to point 1 and point 2, to gain an 'Excellent' rating the occupying organization is required to measure, monitor and manage the continual professional development of their employees.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer options                     |
|-----------|------------------------------------|
|         1 | Skills and capabilities of staff   |
|         1 | Social interaction/team building   |
|         1 | Workplace comfort                  |
|         1 | Productivity                       |
|         2 | Staff satisfaction                 |
|         2 | Continual professional development |
|         2 | Management effectiveness           |
|         0 | Other                              |

## Assessment criteria

- 1. Measuring and monitoring of these aspects should be done using a formal process; this could include, but is not limited to:
- a. Regular meetings/reviews
- b. Questionnaires

<!-- image -->

<!-- image -->

- c. Auditing
- d. Staff event days

## Evidence

- 1. Description  of  how  employees'  records  are  held  locally.  Assessors  must  verify  that  these  records  are updated when new employees are hired or when employees leave.
- 2. Copy of the building occupants satisfaction feedback forms, procedure and/or survey.
- 3. Minutes from employee meetings.
- 4. Description of annual performance review. This should include the date the review is undertaken, a copy of the performance review structure and how performance reviews are communicated to staff.
- 5. Notes from staff interviews conducted.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management HEA 26 - Health and well-being management targets

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            57 | No                  |

## Question

Are management arrangements that set health and well-being targets and monitor implementation?

## Aim

To recognize and encourage management arrangements that monitor and set relevant health and well-being targets aimed at improving health and well-being for all staff.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer option                                                                                                                                |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------|
|         1 | Scope and objectives are defined                                                                                                             |
|         1 | Health and well-being issues/concerns of staff are evaluated and recorded                                                                    |
|         1 | Changes in health and well-being issues/concerns of staff are monitored and reported                                                         |
|         1 | Targets are set and monitored to ensure that actions are completed                                                                           |
|         1 | Occupant satisfaction surveys are carried out at least annually                                                                              |
|         1 | Customers/visitor feedback mechanisms are in place                                                                                           |
|         1 | Mechanisms are included to incorporate feedback into procedures or strategy                                                                  |
|         1 | Individual staff are identified who are accountable for implementation of the health, well-being and safety policies, objectives and targets |
|         1 | Signs, notices and posters are displayed in appropriate locations to highlight areas of risk to health and safety                            |
|         1 | Awareness seminars / training sessions are carried out for all staff regarding health and well-being and safety                              |
|         1 | Formal, regular training is provided for staff responsible for health, safety and well-being management                                      |
|         1 | Improvement targets are set in line with best practice guidance available (including workplace comfort and human resource management)        |
|         1 | Certification achieved against a people management standard tailored to help achieve business objectives                                     |

<!-- image -->

<!-- image -->

| Credits   | Answer option                                                                                                                                                                           |
|-----------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1         | An environmental management system (EMS) is in place that includes procedures to review position against appropriate peer group through verified published reporting, benchmarking etc. |
| 1         | Regular communication is carried out with staff covering health, safety and well-being issues (i.e. through newssheets, meetings, posters, published statistics etc.)                   |
| 1         | A staff mentoring/support system is in place which is independent of staff performance                                                                                                  |
| 41*       | Initiatives to minimize health risks and promote occupant well-being on site/building/area assessed are undertaken (in line with the appropriate Appendix)*                             |
| 0         | Other                                                                                                                                                                                   |

- *Appendix section on page 379.

## Appendix

The HEA 26A - Health and Wellbeing Appendix lists several in house initiatives that might be utilized by the organization in order to meet the aims of this section.

## Assessment criteria

- 1. Management arrangements should be documented and available to view where applicable.
- 2. Management arrangements can be combined in a separate document or part of a wider management policy.

## Evidence

- 1. Copy of:
- a. Health/user comfort agreements
- b. Corporate rules
- c. Means of recording work-related injuries or illnesses
- d. Tenant surveys, complaints, etc.
- e. Appropriate certification to a people management standard
- 2. Copy of records regarding:
- a. First aid/medical use
- b. Health and safety on site
- c. Health policy/user comfort
- d. Employees who have completed relevant training
- 3. Assessor information for visual inspection of the internal organizational structure of the systems.
- 4. Date of last feedback.
- 5. Interviews with employees.

<!-- image -->

<!-- image -->

- 6. Agenda notes and schedules of forward-looking awareness/training sessions.
- 7. Credentials of the peer group.
- 8. Information  on  benchmarks  used  and  date  of  benchmarks  compared  to  the  measured,  which  were published.
- 9. Relevant articles written in company newsletter(s).

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier  Management  HEA  27  -  Health  and  well-being  management objectives

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

In  the  last  reporting  year  for  the  organization,  what  percentage  of  the  health  and  well-being  management objectives for the organization was achieved?

## Aim

To ensure health and wellbeing objectives are being met.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | <25%                  |
|         1 | ≥25% to <50%          |
|         2 | ≥50% to <75%          |
|         3 | ≥75% to <100%         |
|         4 | 100%                  |

## Assessment criteria

- 1. The organization must have a minimum of 6 targets from Occupier Management HEA 26 - Health and well-being management targets in order to achieve any credits.

## Evidence

- 1. Copy of Health and Wellbeing objectives set for the calendar year
- 2. Review of company website, intranet, and newsletter(s) for publication of results
- 3. List of objectives indicating which ones have been achieved
- 4. Interviews with employees

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management HEA 28 - View out

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Is there a policy or practice in place to ensure that all workstations or desks for building users in the organization have an adequate external view out of a window?

## Aim

To enhance wellbeing within the workspace by allowing building occupants to refocus their eyes from close work activities to reduce the risk of eyestrain or dry eyes.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. The view out should be through an external window providing a view of a landscape or buildings (rather than just sky) at seated eye level (4.0 to 4.5 feet) in the relevant building areas.
- 2. A view in to an internal courtyard or atrium will comply provided the distance from the opening to the back wall of the courtyard/atrium is at least 35 feet (allowing enough distance for the eyes to refocus).
- 3. The view cannot be an internal view across the room, as this is likely to become obstructed by partitions, filing cabinets etc.
- 4. Roof  lights  and  high  level  windows  that  do  not  provide  an  adequate  view  out  do  not  meet  the requirements.
- 5. Relevant building areas should be within 25 feet distance of a window or permanent opening providing a view .
- 6. The distance between the wall with the window/opening and nearest external solid object (i.e. buildings, screens walls/fences) should be ≥35 feet.

## Evidence

- 1. Photographic evidence.
- 2. A copy of building floor plans illustrating the maximum distance to a view out of a window from the furthest workstations.

<!-- image -->

<!-- image -->

BREEAM USA In-Use Technical Manual (PD130)

Version 2.0: 2016, April 2019

## Additional information

## Relevant definitions

Relevant building areas are areas within the asset where there are, or will be, workstations or desks for building users.

<!-- image -->

<!-- image -->

## Occupier Management HEA 29 - Communal rest areas

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

Are  courses  of  action  undertaken  to  ensure  that  indoor  and  outdoor  rest  spaces  are  not  used  for  any  other purpose, such as meetings?

## Aim

To recognize and encourage the provision of rest areas for building users, which are not subsequently utilized for meetings at times of high demand.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         2 | Yes                   |

## Assessment criteria

- 1. If an internal space is used as a communal rest area, the space is prohibited to be used as a meeting room.
- 2. Rest areas comply with Asset Performance HEA 07- Indoor and/or outdoor space.

## Evidence

- 1. Photographic  evidence  of  each  of  the  communal  rest  area(s)  in  the  assessed  area,  indicating signs/guidelines for area usage
- 2. Copies of policies that are available to staff on how communal rest areas are used.

## Additional information

-

<!-- image -->

<!-- image -->

## Energy

## Category summary table

| Issue reference         | Title                             |   Credits available |
|-------------------------|-----------------------------------|---------------------|
| ENE 67                  | Energy policy                     |                   3 |
| ENE 68                  | Energy management arrangements    |                  51 |
| ENE 69                  | Trends in energy performance data |                   2 |
| ENE 70                  | Energy objectives                 |                   4 |
| ENE 71                  | Energy savings                    |                   4 |
| Total credits available | Total credits available           |                  64 |

<!-- image -->

<!-- image -->

## Occupier Management ENE 67 - Energy policy

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             3 | No                  |

## Question

Which of the following issues are considered within the organization's energy policy?

## Aim

To ensure that there is a range of different energy management procedures/policies included in the energy policy.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer options                                                                              |
|-----------|---------------------------------------------------------------------------------------------|
|         1 | Reduction in energy demand                                                                  |
|         1 | Reduction in energy consumption                                                             |
|         1 | Making further CO 2 reductions through the installation of Low and Zero Carbon technologies |

## Assessment criteria

- 1. Reduction  in  energy  demand  can  be  achieved  by  reducing  heating,  cooling  and  small  power  energy demands. This can be done by, for example:
- a. improving the building envelope
- b. specifying low energy use light fittings
- c. making amendments to cooling and heating temperatures
- 2. Reduction in energy consumption can be achieved by meeting demand efficiently. This can be done by, for example, the installation of high efficiency boilers, fans and other building services equipment.
- 3. Low and Zero Carbon (LZC) technologies are installations that are installed on-site, near-site or off-site that employ low or zero carbon sources to generate energy.
- 4. The energy policy should be signed off at senior level and be actively implemented by dedicated staff members within the organization.
- 5. An energy policy can be a separate document or part of a wider energy management policy.

## Evidence

- 1. Copy of relevant energy policy/strategy.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management ENE 68 - Energy management arrangements

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            51 | Yes                 |

## Question

To what extent do management arrangements set energy targets, and monitor implementation for this asset?

## Aim

To  recognize  and  encourage  management  arrangements  aimed  at  improving  energy  performance  and  usage awareness.

## Minimum standards

To gain 'Good' rating, energy consumption must be actively recorded and monitored.

## Available credits

Credits awarded for each of the following criteria met:

| Credit(s) Awarded   | Answer option                                                                                                                           |
|---------------------|-----------------------------------------------------------------------------------------------------------------------------------------|
| 1                   | Scope and objectives are defined                                                                                                        |
| 1                   | Energy consumption is actively recorded and monitored                                                                                   |
| 1                   | A locally or nationally recognized rating system is used to demonstrate operation consumption                                           |
| 1                   | Targets are set and monitored to ensure that actions are completed                                                                      |
| 1                   | Management arrangements include procedures to monitor energy consumption                                                                |
| 1                   | Awareness seminars/training sessions are carried out for all staff regarding energy management                                          |
| 1                   | Individual staff are identified who are accountable for implementation of the environmental policies, objectives and targets            |
| 1                   | Includes mechanisms to incorporate feedback into procedures or strategy                                                                 |
| 1                   | Formal, regular training is provided for staff responsible for energy management                                                        |
| 1                   | Improvement targets are set in an improvement strategy in line with the maintenance procedures                                          |
| 1                   | Third party certification under an energy management standard such as ISO 50001:2011 which is either independently audited or certified |
| 40*                 | Energy saving initiatives are undertaken (in line with the appropriate Appendix)*                                                       |
| 0                   | Other                                                                                                                                   |

*Appendix section on page 380

<!-- image -->

<!-- image -->

## Appendix

The ENE 68A - Energy Appendix lists in-house initiatives that might be utilized by the organization to meet the aims of this section.

## Assessment criteria

- 1. Management arrangements should be documented and available to view where applicable.

## Evidence

- 1. Copy of the Energy Management Strategy.
- 2. Copy of annual utility bill for all energy uses.
- 3. Description of energy monitoring process.
- 4. Training/seminar materials from staff awareness events.
- 5. List of staff champions and interviews with a small sample of these people.
- 6. Description/copy of framework by which feedback is provided.
- 7. Training materials for staff responsible for energy management.
- 8. Evidence of improvement targets, evidence from Occupier Management ENE 70 - Energy objectives.
- 9. Third party documentation regarding energy management certification.
- 10. Where the building has been occupied for more than 3 years: copy of last two years of energy use records.
- 11. Where the building has been occupied for less than 3 years: copy of last 12 months of energy use records plus policies and procedures for on-going monitoring.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management ENE 69 - Trends in energy performance data

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

How often are the organization's energy performance data trends at this asset reviewed and compared with historical data and performance targets?

## Aim

Identifying short and long-term energy performance trends; highlighting opportunities for energy savings and any identifying changes in trends due to the implementation of energy management procedures.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Never                 |
|         0 | Infrequently          |
|         1 | At least annually     |
|         2 | At least twice a year |

## Assessment criteria

- 1. All  energy  consumption  for  the  organization  at  this  asset  should  be  measured  and  compared  with historical data and performance targets.

## Evidence

- 1. Relevant spread sheets or energy benchmarking data identifying energy performance trends
- 2. Relevant documentation indicating what energy management procedures have been implemented and what effect these had on the energy performance trends.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management ENE 70 - Energy objectives

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

In the last reporting year for the organization, what percentage of the organization's energy objectives/targets was achieved?

## Aim

To  ensure  that  energy  objectives  and  targets  are  met;  thereby  encouraging  and  recognizing  the  continual improvement of energy performance.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | <25%                  |
|         1 | ≥25% to <50%          |
|         2 | ≥50% to <75%          |
|         3 | ≥75% to <100%         |
|         4 | 100%                  |

## Assessment criteria

- 1. Targets must have been set for the previous year.

## Evidence

- 1. Company reports, declarations, such as the energy management strategy outlining energy targets.
- 2. Previous target setting documentation.
- 3. Copy of Energy Management Strategy (relating to set objectives/targets).

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management ENE 71 - Energy savings

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What were the organization's energy savings at this asset for the previous reporting year, based on a benchmark of energy used 3 reporting years ago?

## Aim

To encourage and recognize energy savings of the asset for various energy sources and systems; thereby reducing energy consumption of the asset.

## Available credits

A maximum of 4 credits are  awarded for providing the savings data for one or more of the following energy sources and systems:

| Credits awarded   | Answer option                                                             |
|-------------------|---------------------------------------------------------------------------|
| 4 Credits         | Electricity savings of the asset from the utility supply in kWh/year/ft 2 |
| 4 Credits         | Natural gas savings by the asset in therms/year/ft 2                      |
| 4 Credits         | Liquid Petroleum Gas (LPG) savings by the asset in kBtu/year/ft 2         |
| 4 Credits         | Oil savings by the asset in kBtu/year/ft 2                                |
| 4 Credits         | Solid fuel savings by the asset in kBtu/year/ft 2                         |
| 4 Credits         | District heating energy savings by the asset supplied in kBtu/year/ft 2   |
| 4 Credits         | District cooling energy savings by the asset supplied in kBtu/year/ft 2   |
| 4 Credits         | Increase of renewable energy generated on-site in kWh/year/ft 2           |

## Assessment criteria

- 1. The energy data that is provided must demonstrate year on year savings.

## Evidence

- 1. Evidence provided for previous questions concerning energy measurement is sufficient.

## Additional information

ENERGY STAR Portfolio Manager ® allows the energy consumption for all fuel types to be entered in a multitude of measurement units (depending on the fuel) and then translates this to the standard unit of measurement specified in this question.  Assets using ENERGY STAR Portfolio Manager  can run a report on Energy Use per Fuel Source to ® provide data to determine the answer to this question for the reporting period.

<!-- image -->

<!-- image -->

## Transport

## Category summary table

| Issue reference         | Title                               |   Credits available |
|-------------------------|-------------------------------------|---------------------|
| TRA 05                  | Transport requirements              |                  12 |
| TRA 06                  | Transport management arrangements   |                  59 |
| TRA 07                  | Local public transport              |                   4 |
| TRA 08                  | Local amenities                     |                   4 |
| TRA 09                  | Transport objectives                |                   4 |
| TRA 10                  | Transport impact of commuting       |                   2 |
| TRA 11                  | Transport impact of business travel |                   2 |
| TRA 12                  | Transport impact of goods delivery  |                   2 |
| Total credits available | Total credits available             |                  89 |

<!-- image -->

<!-- image -->

## Occupier Management TRA 05 - Transport requirements

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            12 | Yes                 |

## Question

Are the environmental impacts associated with the following transport requirements reduced/managed by the organization at this asset?

## Aim

To ensure that the environmental impacts of all travel to and from the asset are reduced/managed.

## Minimum standards

To gain an 'Excellent' rating the occupying organization is required to reduce and manage the impact of staff commuting.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer options          |
|-----------|-------------------------|
|         2 | Visitor/customer travel |
|         2 | Deliveries              |
|         4 | Staff commuting         |
|         4 | Business travel         |
|         0 | Other                   |

## Assessment criteria

- 1. Environmental impacts associated with the mentioned transport requirements should be established and reduced/managed. Environmental impacts can include, but are not limited to:
- a. Fossil fuel use
- b. Emissions related to transport
- c. Pollution related to transport
- d. Noise
- 2. The management of the environmental impacts associated with the travel requirements can be combined in a separate document (travel plan) or part of a wider management policy.

## Evidence

- 1. Copy of the organization specific management arrangements related to the environmental impacts of the travel requirements.

<!-- image -->

<!-- image -->

- 2. Copy of the site-specific transport survey/assessment,
- 3. Copy of travel policies/procedures.
- 4. Photographic evidence confirming installation of measures that support the management arrangements.

## Additional information

## Relevant definitions

A travel plan is  a  strategy for managing all travel and transport within an organization, principally to increase choice and reduce reliance on the car by seeking to improve access to site or development by sustainable modes of transport. A travel plan contains both physical and behavioral measures to increase travel choices and reduce reliance  on  single  occupancy  car  travel.  A  travel  plan  can  be  as  simple  or  complex  as  the  building  and  its operation/use requires.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Occupier Management TRA 06 - Transport management arrangements

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            59 | No                  |

## Question

To what extent are transport management arrangements in place to allow monitoring against set targets for the organization at this asset?

## Aim

To recognize and encourage management aimed at reducing the effects of transport to the environment and increasing awareness of travel impacts.

## Available credits

Credits awarded for each of the following criteria met:

|   Credit(s) Awarded | Answer option                                                                                                                   |
|---------------------|---------------------------------------------------------------------------------------------------------------------------------|
|                   1 | Scope and objectives are defined                                                                                                |
|                   1 | Business travel impacts are measured and recorded                                                                               |
|                   1 | Staff commuting impacts are measured and recorded                                                                               |
|                   1 | Visitor / client travel impacts are measured and recorded                                                                       |
|                   1 | Targets are set and monitored to ensure that actions are completed                                                              |
|                   1 | Business travel impacts are monitored                                                                                           |
|                   1 | Staff commuting impacts are monitored                                                                                           |
|                   1 | Visitor / client travel impacts are monitored                                                                                   |
|                   1 | Staff are encouraged to follow the transport hierarchy to minimize carbon impacts of transport when selecting mode of travel    |
|                   1 | Initiatives are undertaken to minimize air-based business travel patterns                                                       |
|                   1 | Financial incentives are provided to promote carbon efficient means of transport for staff                                      |
|                   1 | Carbon efficient means of transport are provided for staff and visitors                                                         |
|                   1 | Awareness seminars / training sessions are carried out for all staff regarding minimization and management of transport impacts |
|                   1 | Individual staff are identified who are accountable for implementation of the transport policies, objectives and targets        |
|                   1 | Formal, regular training is provided for staff responsible for transport management                                             |

<!-- image -->

| 1   | Includes mechanisms to incorporate feedback into procedures or strategy                                                                                                                                    |
|-----|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1   | Improvement targets are set in line with best practice guidance available                                                                                                                                  |
| 1   | An environmental management system (EMS) is in place that includes procedures to review position against an appropriate peer group through published guidance, benchmarking etc. with regards to transport |
| 1   | Deliveries are scheduled to minimize impacts on staff and surrounding environment                                                                                                                          |
| 40* | Initiatives are undertaken to minimize car-based travel patterns (in line with the appropriate Appendix)*                                                                                                  |
| 0   | Other                                                                                                                                                                                                      |

- *Appendix section on page 382

## Appendix

The TRA 06A - Transport Appendix lists several in house initiatives that might be utilized by the organization to meet the aims of this section.

## Assessment criteria

- 1. Management arrangements should be documented and available to view where applicable.
- 2. The transport management arrangements can be combined in a separate document or part of a wider management policy.

## Evidence

- 1. A copy of the organization specific management arrangements/Travel Plan, highlighting relevant clauses:
- a. A copy of the site-specific transport survey/assessment
- b. A copy of travel policies/procedures
- c. Records demonstrating regular reviews of transport policy
- d. Records demonstrating monitoring of relevant travel
- e. Means of motivating staff, including evidence of incentives
- f. Training material/dates and certificates for training completion
- g. Interviews with staff
- h. Information on deliveries to site
- i. Photographic evidence
- j. Visual inspection notes

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management TRA 07 - Local public transport

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is there an agreement in place to liaise with local public transport operators to improve services to the asset and ensure that information is readily available for building users?

## Aim

To ensure the availability of public transport links for people travelling to and from the asset; thereby encouraging and facilitating public transport usage.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. An  agreement  should  be  made  with  local  transport  operators  and  be  tailored  to  the  organization's requirements.
- 2. Information  should  be  freely  available  to  all  building  users.  This  can  be  done  through  hardcopies  or softcopies (i.e. through intranet, notice boards, leaflets or email) or a combination of the two.
- 3. For organizations with a fixed shift pattern i.e. where building users will predominantly arrive/depart at set  times,  the  credits can  be  allocated  when a dedicated bus service to and from the building at the beginning  and  end  of  each  shift/day  has  been  provided.  The  bus  must  provide  transfer  to  the  local population center, public transport interchange or be a door-to-door service.

## Evidence

- 1. A copy of the arrangement(s) with local public transport provider(s).
- 2. A copy of public transport operator timetables.
- 3. A copy of the public transport route map highlighting the location of the asset.
- 4. Evidence  confirming  installation  of  measures  that  are  in  place  to  make  the  information  available  to building users. This could include, but is not limited to, photographic evidence of notice boards or copies of leaflets.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management TRA 08 - Local amenities

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

Is information made available to asset users on the location of local amenities near the asset?

## Aim

To ensure that asset users do not travel excessively to reach amenities; thereby reducing the environmental impact of prolonged travel.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Don't know            |
|         0 | No                    |
|         4 | Yes                   |

## Assessment criteria

- 1. Local amenities include, but are not limited to:
- a. Local convenience store
- b. ATM/cash machine
- c. Post office
- 2. Site and local amenities information needs to be made readily available to all building users. This can be done via hardcopies or softcopies (i.e. leaflets, maps or information board).
- 3. The distance/time  required  to  get  to  the  local  amenities  should  be  clearly  communicated  within  the information provision.

## Evidence

- 1. Evidence of information provision to all building users such as photographic evidence of an information board or local information leaflets.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management TRA 09 - Transport objectives

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

In the last reporting year for the organization, what percentage of the organization's transport objectives and targets were achieved?

## Aim

To ensure that targets related to transport are met within an appropriate timeframe, enabling the introduction of new targets; thus ensuring the continual improvement of transport.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | <25%                  |
|         1 | ≥25% to <50%          |
|         2 | ≥50% to <75%          |
|         3 | ≥75% to <100%         |
|         4 | 100%                  |

## Assessment criteria

- 1. Targets must be for the latest available year.

## Evidence

- 1. Copy of documented targets and when these were achieved.
- 2. Documentation  and  photographic  evidence  confirming  installation  of  measures  that  support  the Assessment criteria.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management TRA 10 - Transport impact of commuting

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What is the total work commute in miles per year for staff in the asset?

## Aim

To  recognize  and  encourage  the  measurement  of  annual  distance  travelled  for  staff  commutes;  improving knowledge of management, and enabling quantitative targets to be implemented.

## Available credits

| Mode of transport                      | Figures to be entered in relevant fields (2 credits can be awarded if known for 1 or more categories).   |
|----------------------------------------|----------------------------------------------------------------------------------------------------------|
| Car (vehicle miles/year)               |                                                                                                          |
| Train (passenger miles/year)           |                                                                                                          |
| Light rail/tram (passenger miles/year) |                                                                                                          |
| Bus (passenger miles/year)             |                                                                                                          |
| Motorcycle (vehicle miles/year)        |                                                                                                          |
| Bicycle/walk (miles/year)              |                                                                                                          |

## Assessment criteria

- 1. Staff commute relates to the total distance that people that work in the asset travel to and from work. This does not include additional business related trips, such as external meetings.
- 2. Travel data should be collected through travel surveys or other reliable form of data collection.

## Evidence

- 1. A copy of a document demonstrating results of staff commuting survey, illustrating a relevant transport data
- 2. Documentation illustrating how such data was acquired.

## Additional information

## Relevant definitions

Car : any personal vehicle used for commuting purposes.

Train: includes rail service between a central city and adjacent suburbs (also called commuter rail, regional rail or suburban rail) and long-distance rail between major cities.

<!-- image -->

SD221 USA © BRE Global Ltd 2019

<!-- image -->

Light  rail/tram :  this  category  includes  rail  travel  within  an  urban  center  (such  as  subways,  elevated  railways, metropolitan railways (metro), streetcars, trolley cars, and tramways). -

<!-- image -->

<!-- image -->

## Occupier Management TRA 11 - Transport impact of business travel

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What are the transport impacts of business travel relating to this asset in miles per year?

## Aim

To  recognize  and  encourage  the  measurement  of  annual  distance  travelled  for  business;  thereby  improving knowledge of management, and enabling quantitative targets to be implemented.

## Available credits

| Mode of transport                                                                    | Figures to be entered in relevant fields (maximum of 2 credits available)   |
|--------------------------------------------------------------------------------------|-----------------------------------------------------------------------------|
| Long haul flights - over 7 hours in length (passenger miles/year)                    |                                                                             |
| Medium haul flights - between 1.5 hours and 7 hours in length (passenger miles/year) |                                                                             |
| Short haul flights - up to 1.5 hours in length (passenger miles/year)                |                                                                             |
| Car (vehicle miles/year)                                                             |                                                                             |
| Train (passenger miles/year)                                                         |                                                                             |
| Light rail/tram (vehicle miles/year)                                                 |                                                                             |
| Bus (vehicle miles/year)                                                             |                                                                             |
| Motorcycle (vehicle miles/year)                                                      |                                                                             |
| Bicycle/walk (miles/year)                                                            |                                                                             |

## Assessment criteria

- 1. Business travel relates to the total distance that people that work in the asset travel for business. (This includes business related trips, such as external meetings, overseas conferences, etc.)

## Evidence

- 1. Transport data, including documentation illustrating how such data was acquired.

## Additional information

## Relevant definitions

Car : any personal vehicle used for business travel purposes.

<!-- image -->

<!-- image -->

Train : includes travel on commuter rail (between a central city and adjacent suburbs) and intercity rail (between major cities).

Light rail/tram : rail typically within an urban center, such as subways, elevated railways, metropolitan railways (metro), streetcars, trolley cars, and tramways. -

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Occupier Management TRA 12 - Transport impact of goods delivery

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What is the total business related transport impact of goods delivery from operations in this asset?

## Aim

To  recognize  and  encourage  the  measurement  of  the  annual  distance  travelled  for  goods  delivery;  thereby improving knowledge of management, and enabling quantitative targets to be implemented.

## Available credits

| Mode of transport                                | Figures to be entered in relevant fields (2 credits available)   |
|--------------------------------------------------|------------------------------------------------------------------|
| Medium- to Heavy-Duty Truck (vehicle miles/year) |                                                                  |
| Van or Light-Duty Truck (vehicle miles/year)     |                                                                  |
| Standard-sized vehicle (vehicle miles/year)      |                                                                  |
| Rail freight (ton-miles/year)                    |                                                                  |
| Marine freight (ton-miles/year)                  |                                                                  |

## Assessment criteria

- 1. Goods delivery from operations includes goods delivered to AND from the asset.
- 2. Where there are no business related impacts of goods delivery please fill in '0' in the relevant fields. Credits will then be awarded accordingly.

## Evidence

- 1. Goods delivery figures, including documentation illustrating how such data was acquired.

## Additional information

## Relevant definitions

Medium- to Heavy-Duty Truck : a large, heavy motor vehicle over 14,000 lbs used to transport and deliver goods.

Van or Light-Duty Truck : vehicles with a wheelbase greater than 121 inches, weighing no more than 14,000lbs. Includes full-size pickup trucks, full-size vans and extended-length SUVs.

Standard-sized vehicle: vehicles with a wheelbase less than 121 inches.  Includes passenger cars, minivans, SUVs and small pickup trucks. -

<!-- image -->

<!-- image -->

## Water

## Category summary table

| Issue reference         | Title                              |   Credits available |
|-------------------------|------------------------------------|---------------------|
| WAT 18                  | Water management: Staff engagement |                   3 |
| WAT 19                  | Water monitoring & management      |                  48 |
| WAT 20                  | Water management targets           |                   4 |
| WAT 21                  | Water consumption                  |                   2 |
| Total credits available | Total credits available            |                  57 |

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Occupier Management WAT 18 - Water management: Staff engagement

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             3 | No                  |

## Question

How are activities managed to avoid unnecessary water consumption?

## Aim

To ensure the reduction of water consumption and the demands placed on water supplies.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer options                                                           |
|-----------|--------------------------------------------------------------------------|
|         0 | Question not answered                                                    |
|         0 | Activities are not managed                                               |
|         1 | Green/staff champions identified to encourage reduction of water wastage |
|         1 | Awareness training for staff                                             |
|         1 | Staff feedback mechanisms in place to raise issues, such as leakages     |
|         0 | Other                                                                    |

## Assessment criteria

- 1. Staff champions should promote reductions in water consumption through frequent engagement with staff.
- 2. Awareness raising should be through seminars, team meetings or general updates.
- 3. Feedback mechanisms should be simple to access.

## Evidence

- 1. Interviews with relevant staff.
- 2. Copy of awareness raising material.
- 3. Copy of relevant feedback procedures.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management WAT 19 - Water monitoring &amp; management

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            48 | Yes                 |

## Question

To what extent are water management arrangements in place that allow monitoring against set targets for the organization at this asset?

## Aim

To  recognize  and  encourage  management  arrangements  aimed  at  reducing  the  consumption  of  water  and increasing awareness of water consumption.

## Minimum standards

- 1. To gain a 'Pass' rating the occupying organizations must ensure that water consumption is recorded.
- 2. In  addition  to  point  1,  to  gain  a  'Good'  rating  the  occupying  organization  must  ensure  that  water consumption is monitored.

## Available credits

Credits awarded for each of the following criteria met:

| Credit(s) Awarded   | Answer option                                                                                                                                                                                       |
|---------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1                   | Scope and objectives defined                                                                                                                                                                        |
| 1                   | Water consumption is recorded                                                                                                                                                                       |
| 1                   | Targets are set and monitored to ensure that actions are completed                                                                                                                                  |
| 1                   | A water management system is in place                                                                                                                                                               |
| 1                   | Water consumption is monitored                                                                                                                                                                      |
| 1                   | Includes mechanisms to incorporate feedback into procedures or strategy                                                                                                                             |
| 1                   | Improvement targets are set in line with best practice guidance available                                                                                                                           |
| 1                   | Environmental management system (EMS) is in place that includes procedures to review position against an appropriate peer group through published guidance, benchmarking etc. with regards to water |
| 40*                 | Water saving initiatives are undertaken (in line with the appropriate Appendix)*                                                                                                                    |
| 0                   | Other                                                                                                                                                                                               |

*Appendix section on page 383

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

The WAT 19A - Water Appendix lists several in house initiatives that might be utilized by the organization to meet the aims of this section.

## Assessment criteria

- 1. A water management policy should address/declare that:
- a. The organization will comply with environmental legislation relating to water management.
- b. The organization is dedicated to reducing consumption of water as a result of its operation and related activities.
- c. As part of the strategy there must be:
- i. A water consumption minimization champion, who  has the support of senior management, with responsibility for the necessary communications, resources, action program and training to make the strategy work
- ii. Some  form  of  training  of  employees  in  their  role(s)  and  responsibilities  for  water consumption minimization

## Evidence

- 1. Copy of the water management arrangements
- 2. Copies of records for monitoring the consumption phases / sectors / areas / processes
- 3. Agenda of the training records, employee attendance records
- 4. Management review records where relevant to water management
- 5. Interviews with staff champions

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management WAT 20 - Water management targets

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

In the last reporting year for the organization, what percentage of the organization's annual water management objectives/targets at this asset was achieved?

## Aim

To ensure that water management objectives are met within an appropriate timeframe, enabling the introduction of new targets; thus ensuring the continual improvement of water performance.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | <25%                  |
|         1 | ≥25% to <50%          |
|         2 | ≥50% to <75%          |
|         3 | ≥75% to <100%         |
|         4 | 100%                  |

## Assessment criteria

- 1. Figures must be those relating to the latest annual targets that have been set.

## Evidence

- 1. Meter readings from previous year.
- 2. Current meter readings.
- 3. Copy of water management policy highlighting water targets.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management WAT 21 - Water consumption

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What was the total quantity of water consumed in thousand gallons (kgal) at this asset during the reporting period?

## Aim

To ensure that management and occupants of the asset are aware of the consumption of water for the last year.

## Available credits

|   Credits | Enter total quantity of water consumed in kgal during the reporting period   |
|-----------|------------------------------------------------------------------------------|
|         2 |                                                                              |

## Assessment criteria

- 1. The occupying organization must make clear how this information was collected.

## Evidence

- 1. Meter readings from previous year
- 2. Utility bills

## Additional information

-

<!-- image -->

<!-- image -->

## Materials

## Category summary table

| Issue reference         | Title                                                          |   Credits available |
|-------------------------|----------------------------------------------------------------|---------------------|
| MAT 15                  | Material procurement: Selection                                |                   7 |
| MAT 16                  | Material procurement: Management arrangements                  |                  52 |
| MAT 17                  | Supplier approval                                              |                   3 |
| MAT 18                  | Supplier quality policy                                        |                   4 |
| MAT 19                  | Supplier environmental management                              |                   4 |
| MAT 20                  | Supplier quality management (third party certified)            |                   4 |
| MAT 21                  | Supplier environmental management (third party certified)      |                   4 |
| MAT 22                  | Supplier responsible sourcing standard (third party certified) |                   4 |
| MAT 23                  | Material procurement targets                                   |                   4 |
| Total credits available | Total credits available                                        |                  86 |

<!-- image -->

<!-- image -->

## Occupier Management MAT 15 - Material procurement: Selection

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             7 | Yes                 |

## Question

To what extent are sustainability and environmental issues considered when procuring materials for this asset?

## Aim

To limit the environmental impact of materials procured for occupant activities.

## Minimum standards

To gain an 'Outstanding' rating, the occupier of the asset must ensure that responsible procurement has been conducted in accordance with a procedure/guideline/standard that has international scope.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer options                                                                                                                            |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Not applicable                                                                                                                            |
|         1 | Minimizing the emission from deliveries                                                                                                   |
|         2 | Procedures are in place to reduce procurement of consumables where practicable                                                            |
|         2 | Procedures are in place to take account of embodied emission impacts such as recyclability, low energy, reusable, sustainable, life cycle |
|         2 | Responsible sourcing has been conducted in accordance with a procedure/guideline/standard that has international scope.                   |
|         0 | Other                                                                                                                                     |

## Assessment criteria

- 1. Materials that are covered in the procurement policy relate to materials that are needed to perform the tasks that are relevant to the type of asset. These materials can include not just office operations but all business activities, and include but are not limited to:
- a. Office paper
- b. Cleaning products
- c. Ink cartridges
- d. Electrical equipment
- 2. Criteria such as working conditions, environmental practices, safety standards, and human rights policies should be factored into the selection process.

<!-- image -->

<!-- image -->

- 3. Where contracting with a supplier, companies should make it known that they expect business partners to comply with all national laws and regulations, including labor and environmental laws.
- 4. All timber or timber-based products that is procured is 'Legally harvested and Legally traded timber' as outlined in the additional information section.

## Evidence

- 1. Copy of Sustainable procurement policy,
- 2. Evidence of actions taken to monitor embodied impacts of purchased materials,
- 3. Documented confirmation from suppliers,
- 4. Certification reference number against appropriate responsible sourcing standard.

## Additional information

## Relevant definitions

Responsible  sourcing: The  management  and  implementation  of  sustainable  development  principles  in  the provision,  procurement  and  traceability  of  construction  materials  and  components.  In  BREEAM,  this  is demonstrated through auditable third-party certification programs. More information will be available in the Resources  section  on  www.breeam.com.  Including  an  up  to  date  table  of  responsible  sourcing  certification programs recognized by BRE Global Ltd. for the purposes of a BREEAM assessment.

BRE Global framework standard (BES 6001) for responsibly sourcing of construction products:

- 1. Organizational management
- 2. Supply chain management
- 3. Environmental and social care

For a copy of the standard, application forms, fee sheets, program document and certified listings related to Responsible Sourcing of Construction Products please visit the Green Book Live Website; http://www.greenbooklive.com

To ease compliance burden on suppliers, which tend to small and medium-sized enterprises, organizations should consider  partnering  with  sectorial  associations  that  have  developed  industry-wide  supplier  codes  of  conduct. Examples of such initiatives include the International Council of Toy Industries CARE Foundation.

Legally harvested timber: timber that has been harvested in accordance with the applicable legislation in the country of harvest.

Legally traded timber: timber that is legally traded means timber or products derived from timber were:

- 1. Exported in compliance with exporting country laws governing the export of timber and timber products, including payment of any export taxes, duties, or levies.
- 2. Imported in compliance with importing country laws governing the import of timber and timber products, including payment of any import taxes, duties, or levies or not in contravention of exporting country laws governing the export of timber and timber products, including payment of any export taxes, duties, or levies.
- 3. Traded in compliance with legislation related to the Convention on International Trade in Endangered Species (CITES) where applicable.

<!-- image -->

## Occupier  Management  MAT  16  -  Material  procurement:  Management arrangements

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            52 | No                  |

## Question

Are management arrangements for the procurement of materials that allow monitoring against set targets for this asset in place?

## Aim

To  increase  awareness  and  continuously  limit  the  environmental  impact  of  materials  procured  for  occupant activities.

## Available credits

Credits awarded for each of the following criteria met:

|   Credit(s) Awarded | Answer option                                                                                                                                                                                                          |
|---------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                   1 | Scope and objectives are defined and appropriate requirements specified                                                                                                                                                |
|                   1 | Targets are set and monitored to ensure that actions are completed                                                                                                                                                     |
|                   1 | A management system is in place to promote the efficient use of materials                                                                                                                                              |
|                   1 | Management arrangements include procedures to incorporate feedback from staff, clients and other stakeholders                                                                                                          |
|                   1 | Materials purchasing is monitored to include need, quantities, and sustainability issues                                                                                                                               |
|                   1 | Awareness seminars/training sessions are carried out for all staff regarding materials procurement                                                                                                                     |
|                   1 | Individual staff are identified who are accountable for implementation of the materials policy, objectives and targets                                                                                                 |
|                   1 | Formal, regular training is provided for staff responsible for materials procurement                                                                                                                                   |
|                   1 | Mechanisms are in place to incorporate feedback into procurement procedures or strategy                                                                                                                                |
|                   1 | Improvement targets are set in line with best practice guidance available                                                                                                                                              |
|                   1 | A list of acceptable suppliers is maintained for all materials.                                                                                                                                                        |
|                   1 | An environmental management system (EMS) is in place that includes procedures to review position against an appropriate peer group through published guidance, benchmarking etc. with regards to materials procurement |

<!-- image -->

| Credit(s) Awarded   | Answer option                                                                                               |
|---------------------|-------------------------------------------------------------------------------------------------------------|
| 40*                 | Initiatives to reduce materials procurement impacts are undertaken (in line with the appropriate Appendix)* |
| 0                   | Other                                                                                                       |

- *Appendix section on page 384

## Appendix

The MAT 16A - Materials Appendix lists several in house initiatives that might be utilized by the organization to meet the aims of this section.

## Assessment criteria

- 1. Organizations  must  ensure  that  top  management  quality  objectives  that  meet  the  requirements  of business products are established at relevant functions and levels within the organization. It is important that quality objectives are deemed measurable and consistent with the quality policy. In planning product realization, organizations shall determine the following, as appropriate:
- a. Quality objectives and requirements for the product
- b. The need to establish processes and documents and to provide resources specific to products
- c. Required verification, validation, monitoring, measurement, inspection and test activities specific to the product and the criteria for product acceptance;
- d. Records needed to provide evidence that the realization processes and resulting product meet requirements.

## Evidence

- 1. Copy of the procurement arrangements/procurement policy highlighting the relevant clauses.
- 2. Material-Management-System/Register.
- 3. Visual inspection of the internal organizational structure of the systems.
- 4. Interviews with employees.
- 5. Copy of the records to verify the Procurement Policy.
- 6. Agenda of the training records, training materials etc.
- 7. Copy of the procurement arrangements, including names of key personnel, objectives and guidelines used.
- 8. Complete records and certificates of employees.

## Additional information

## Other information

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

See: ISO 9001 'Quality Management Systems - Requirements' (ISO 9001:2008 5.3 Quality Policy; ISO 9001:2015 5.2 Policy)

## About ISO 9001

ISO 9001 is an international quality management standard that presents guidelines intended to increase business efficiency and customer satisfaction. The goal of ISO 9001 is to embed a quality management system within an organization, increasing productivity, reducing unnecessary costs, and ensuring quality of processes and products.

<!-- image -->

<!-- image -->

## Occupier Management MAT 17 - Supplier approval

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             3 | No                  |

## Question

Which of the following initiatives are used at the organizational level to determine the acceptability of suppliers?

## Aim

To ensure that materials are ethically and sustainably sourced by suppliers.

## Available credits

|   Credits | Answer option                                                 |
|-----------|---------------------------------------------------------------|
|         0 | Question not answered                                         |
|         0 | The acceptability of suppliers is not determined              |
|         2 | A Supplier Questionnaire/Survey is in use                     |
|         3 | Membership of an industry/supply chain initiative is required |
|         0 | Other                                                         |

## Assessment criteria

- 1. The  acceptability  of  suppliers  should  be  reviewed  annually  or  when  suppliers  change  to  ensure  the applicability of the requirements.

## Evidence

- 1. Copy of supplier questionnaire/survey
- 2. Copy of letter(s) sent to suppliers
- 3. Copy of membership certificate.

## Additional information

## Other information

Organizations can ask their suppliers to provide comprehensive information about their social and environmental practices. On-site visits can be organized to monitor suppliers' progress, or lack of progress, in meeting social and environmental  performance  objectives.  Evaluating  this  information  can  become  part  of  a  company's  regular assessments of business requirements. Businesses can involve their suppliers' factory management and workers in monitoring, and provide training and tools to develop their own compliance system and identify problems.

<!-- image -->

<!-- image -->

## Occupier Management MAT 18 - Supplier quality policy

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of the organization's suppliers is required to have a quality policy?

## Aim

To ensure that suppliers document objectives for quality and the commitment of to ensure quality.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | None                  |
|         0 | <25% of suppliers     |
|         1 | ≥25% of suppliers     |
|         2 | ≥50% of suppliers     |
|         3 | ≥75% of suppliers     |
|         4 | 100% of suppliers     |

## Assessment criteria

- 1. A supplier/contractors quality policy should be:
- a. Appropriate to the purposes of the organization in question
- b. Include commitment to comply with requirements and continually improve the effectiveness of their quality management
- c. Provide a framework for establishing and reviewing quality objectives
- d. Reviewed at appropriate intervals for continuing suitability
- 2. The quality policy of the supplier does not necessarily have to be third party certified in order to comply with the credit requirements.
- 3. The  asset  owner  should  review  that  the  environmental  management  system  of  suppliers  is  in  place annually or when suppliers change to ensure the applicability of the requirements.

## Evidence

- 1. Copy of the letters distributed to suppliers/contractors asking for the quality policy.
- 2. Copy of the suppliers polices.
- 3. List outlining all suppliers and those who have a quality policy in place.

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Additional information

The percentage calculation for the suppliers is by number of suppliers rather than based on procurement spend.

See: ISO 9001 'Quality Management Systems - Requirements' (ISO 9001:2008 5.3 Quality Policy; ISO 9001:2015 5.2 Quality Policy)

## About ISO 9001

ISO 9001 is an international quality management standard that presents guidelines intended to increase business efficiency and customer satisfaction. The goal of ISO 9001 is to embed a quality management system within an organization, increasing productivity, reducing unnecessary costs, and ensuring quality of processes and products.

-

<!-- image -->

<!-- image -->

## Occupier Management MAT 19 - Supplier environmental management

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of the organization's suppliers are required to have an environmental management system?

## Aim

To ensure that suppliers manage their activities and processes to prevent or  mitigate harmful environmental impacts.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | None                  |
|         0 | <25% of suppliers     |
|         1 | ≥25% of suppliers     |
|         2 | ≥50% of suppliers     |
|         3 | ≥75% of suppliers     |
|         4 | 100% of suppliers     |

## Assessment criteria

- 1. It is important that a supplier's management system has identified the significant environmental aspects that are applicable to their organization and that they can control directly and indirectly.
- 2. A supplier/contractors environmental policy should be:
- a. Appropriate to the purposes of the organization in question
- b. Include commitment to comply with requirements and continually improve the effectiveness of their environmental management
- c. Provide a framework for establishing and reviewing environmental objectives
- d. Reviewed at appropriate intervals for continuing suitability
- 3. The  asset  owner  should  review  that  the  environmental  management  system  of  suppliers  is  in  place annually or when suppliers change to ensure the applicability of the requirements.
- 4. The  environmental  management  system  of  the  supplier  does  not  necessarily  have  to  be  third  party certified in order to comply with the credit requirements.

## Evidence

<!-- image -->

<!-- image -->

- 1. Copy of the letters distributed to suppliers/contractors asking for the environmental policy.
- 2. Copy of the suppliers' policies.
- 3. List outlining all suppliers and those who have an environmental management system in place.

## Additional information

The percentage calculation for the suppliers is by number of suppliers rather than based on procurement spend.

## Other information

See: ISO 14001 ' Environmental Management Systems - Requirements with guidance for use ') (ISO 14001:2004 A.2 Environmental Policy, ISO 14001:2015 5.2 Environmental Policy).

<!-- image -->

<!-- image -->

## Occupier Management MAT 20 - Supplier quality management (third party certified)

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of the organization's suppliers must have third party certification under a quality management standard such as ISO 9001 or equivalent?

## Aim

To ensure that suppliers document objectives for quality and the commitment of the supplier to ensure quality.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | None                  |
|         0 | <25% of suppliers     |
|         1 | ≥25% of suppliers     |
|         2 | ≥50% of suppliers     |
|         3 | ≥75% of suppliers     |
|         4 | 100% of suppliers     |

## Assessment criteria

- 1. The organizations in question shall have an implemented and maintained quality management system that is structured accordingly to continually improve its effectiveness in accordance with the requirements of International Standards.
- 2. Organizations that have a certified Quality Management System should:
- a. Determine  the  processes  needed  for  the  quality  management  system  and  their  application throughout the organization,
- b. Determine the sequence and interaction of these processes,
- c. Determine the criteria and methods needed to ensure that the operation and monitoring of the above processes,
- d. Ensure  the  availability  of  resources  and  information  necessary  to  support  the  operation  and monitoring of these processes, and
- e. Monitor, measure where applicable, and analyze these processes, and

<!-- image -->

<!-- image -->

- f. Implement actions necessary to achieve planned results and continual improvement of the above processes.

## Evidence

- 1. Copy of the letters distributed to suppliers/contractors asking for the quality policy.
- 2. Copy of the suppliers' policies.

## Additional information

The percentage calculation for the suppliers is by number of suppliers rather than based on procurement spend.

## Other information

See: ISO 9001:2008 'Quality Management Systems - Requirements' (ISO 9001:2008 4.1 General requirements, ISO 9001:2015 4 Context of the organization).

## About ISO 9001

ISO 9001 is an international quality management standard that presents guidelines intended to increase business efficiency and customer satisfaction. The goal of ISO 9001 is to embed a quality management system within an organization, increasing productivity, reducing unnecessary costs, and ensuring quality of processes and products.

<!-- image -->

<!-- image -->

## Occupier  Management  MAT  21  -  Supplier  environmental  management (third party certified)

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What  percentage  of  the  organization's  suppliers  must  have  third  party  certification  under  an  environmental management standard such as ISO 14001 or equivalent?

## Aim

To ensure that suppliers manage their activities and processes to prevent or mitigate harmful environmental impacts.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | None                  |
|         0 | <25% of suppliers     |
|         1 | ≥25% of suppliers     |
|         2 | ≥50% of suppliers     |
|         3 | ≥75% of suppliers     |
|         4 | 100% of suppliers     |

## Assessment criteria

- 1. This international standard is applicable to any organization that wishes to:
- a. Maintain and improve an environmental management systems
- b. Assure itself of conformity with its stated environmental policy

## Evidence

- 1. Copy of supplier certification under relevant standard.

## Additional information

The percentage calculation for the suppliers is by number of suppliers rather than based on procurement spend.

See: ISO 14001 ' Environmental Management Systems - Requirements with guidance for use ' (ISO 14001:2004 4 Environmental  management  system  requirements;  ISO  14001:2015  4  Environmental  management  system requirements).

<!-- image -->

<!-- image -->

## Occupier  Management  MAT  22  -  Supplier  responsible  sourcing  standard (third party certified)

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

What percentage of the organization's suppliers are required to have a third party certification under a recognized responsible sourcing standard?

## Aim

To ensure that supplier's products have been manufactured with materials that have been responsibly sourced.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | None                  |
|         0 | <25% of suppliers     |
|         1 | ≥25% of suppliers     |
|         2 | ≥50% of suppliers     |
|         3 | ≥75% of suppliers     |
|         4 | 100% of suppliers     |

## Assessment criteria

- 1. Responsible sourcing has been conducted in accordance with a procedure/guideline/standard that has international scope.
- 2. All timber or timber-based products must be 'Legally harvested and Legally traded timber' as outlined in the additional information section.

## Evidence

- 1. Copy of supplier certification under relevant standard.

## Additional information

The percentage calculation for the suppliers is by number of suppliers rather than based on procurement spend.

## Relevant definitions

Responsible  sourcing: The  management  and  implementation  of  sustainable  development  principles  in  the provision,  procurement  and  traceability  of  construction  materials  and  components.  In  BREEAM,  this  is demonstrated through auditable third-party certification programs. More information will be available in the

<!-- image -->

SD221 USA © BRE Global Ltd 2019

<!-- image -->

Resources  section  on  www.breeam.com.  Including  an  up  to  date  table  of  responsible  sourcing  certification programs recognized by BRE Global Ltd. for the purposes of a BREEAM assessment.

BRE Global framework standard (BES 6001) for responsibly sourcing of construction products:

- 1. Organizational management
- 2. Supply chain management
- 3. Environmental and social care

For a copy of the standard, application forms, fee sheets,  program document and certified listings related to Responsible Sourcing of Construction Products please visit the Green Book Live Website; http://www.greenbooklive.com

To ease compliance burden on suppliers, which tend to small and medium-sized enterprises, organizations should consider  partnering  with  sectorial  associations  that  have  developed  industry-wide  supplier  codes  of  conduct. Examples of such initiatives include the International Council of Toy Industries CARE Foundation.

Legally harvested timber :  timber that has been harvested in accordance with the applicable legislation in the country of harvest.

Legally traded timber: timber that is legally traded means timber or products derived from timber were:

- 1. Exported in compliance with exporting country laws governing the export of timber and timber products, including payment of any export taxes, duties, or levies.
- 2. Imported in compliance with importing country laws governing the import of timber and timber products, including payment of any import taxes, duties, or levies or not in contravention of exporting country laws governing the export of timber and timber products, including payment of any export taxes, duties, or levies.
- 3. Traded in compliance with legislation related to the Convention on International Trade in Endangered Species (CITES) where applicable.

<!-- image -->

<!-- image -->

## Occupier Management MAT 23 - Material procurement targets

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

In  the  last  reporting  year  for  the  organization,  what  percentage  of  the  organization's  materials  procurement objectives and targets were achieved?

## Aim

To ensure that material procurement targets are met within an appropriate timeframe, enabling the introduction of new targets; thus ensuring the continual improvement of material procurement.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | <25%                  |
|         1 | ≥25% to <50%          |
|         2 | ≥50% to <75%          |
|         3 | ≥75% to <100%         |
|         4 | 100%                  |

## Assessment criteria

- 1. Figures must be those relating to the latest annual targets that have been set.

## Evidence

- 1. Copy of documented material procurement objectives and targets,
- 2. Management Review minutes,
- 3. Review company website, intranet for publication of information.

## Additional information

-

<!-- image -->

<!-- image -->

## Waste

## Category summary table

| Issue reference         | Title                                       |   Credits available |
|-------------------------|---------------------------------------------|---------------------|
| WST 02                  | Waste management: The waste hierarchy       |                   8 |
| WST 03                  | Waste management: Recycling and reclamation |                   4 |
| WST 04                  | Waste management arrangements               |                  51 |
| WST 05                  | Waste monitoring                            |                   4 |
| WST 06                  | Waste performance                           |                   2 |
| WST 07                  | Waste management objectives                 |                   4 |
| WST 08                  | Waste sent to landfill                      |                   2 |
| WST 09                  | Waste diverted from landfill                |                   2 |
| WST 10                  | Waste sent for incineration                 |                   2 |
| Total credits available | Total credits available                     |                  79 |

<!-- image -->

<!-- image -->

## Occupier Management WST 02 - Waste management: The waste hierarchy

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             8 | No                  |

## Question

How is waste managed in line with the waste hierarchy?

## Aim

To encourage alignment of waste management policies with the waste hierarchy.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer options                                                       |
|-----------|----------------------------------------------------------------------|
|         0 | Question not answered                                                |
|         0 | All waste is put into a container                                    |
|         2 | Waste management policy incorporates the reduction of waste produced |
|         2 | Waste management policy incorporates the reuse of waste materials    |
|         2 | Waste management policy incorporates recycling of waste              |
|         2 | Waste management policy incorporates recovery of energy from waste   |
|         0 | Other                                                                |

## Assessment criteria

- 1. The organization's waste management policy should state how the alignment with the waste hierarchy criteria specified is achieved.
- 2. The  waste  management  policy  can  refer  to  waste  from  products  consumed  and/or  produced  by  the organization.

## Evidence

- 1. Copy of the waste management policy

## Additional information

## Other information

The waste hierarchy encourages effective management of waste through:

- a. Prevention;
- b. Re-use;
- c. Recycling;

<!-- image -->

<!-- image -->

- d. Other recovery, e.g. energy recovery; and
- e. Disposal.

When  applying  the  waste  hierarchy,  all  measures  to  encourage  the  options  that  deliver  the  best  overall environmental outcome should be taken. This may require specific waste streams departing from the hierarchy where this is justified by life cycle thinking on the overall impacts of the generation and management of such waste.

<!-- image -->

<!-- image -->

## Occupier  Management  WST  03  -  Waste  management:  Recycling  and reclamation

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

How are waste streams managed to minimize environmental impact?

## Aim

To encourage ease of recycling and reclamation when waste creation is unavoidable.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer options                                                                                                         |
|-----------|------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                  |
|         0 | All waste is put into a container                                                                                      |
|         1 | Waste is crushed for ease of storage on site before removal for recycling                                              |
|         1 | 4 or more waste streams are segregated before removal or commingled recycling containers are used throughout the asset |
|         1 | Waste is discarded in separate containers by staff within the asset                                                    |
|         1 | Containers are adequately labeled to allow ease of use for staff                                                       |
|         0 | Other                                                                                                                  |

## Assessment criteria

- 1. Waste streams refer to different types of waste generated within the building, such as:
- a. Paper
- b. Cardboard
- c. Packaging
- d. Plastics; including packing film
- e. Glass
- f. Batteries
- g. Timber
- h. Fluorescent lamps
- i. Vegetable oils
- j. Mineral oils

<!-- image -->

<!-- image -->

- 2. Different colored glass separation is classed as one waste stream.

## Evidence

- 1. Photographs of how waste is managed such as:
- a. Waste crushing apparatus
- b. Waste segregation
- c. Internal waste segregation
- d. Labeling of containers

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management WST 04 - Waste management arrangements

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            51 | No                  |

## Question

To what extent are waste management arrangements/strategies that set targets and monitors implementation in place for this asset?

## Aim

To  recognize  and  encourage  management  arrangements  aimed  at  improving waste  production  performance, segregation and awareness.

## Available credits

Credits awarded for each of the following criteria met:

| Credit(s) Awarded   | Answer option                                                                                                                                                                                       |
|---------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1                   | Scope and objectives defined                                                                                                                                                                        |
| 1                   | Total waste volume/mass is recorded.                                                                                                                                                                |
| 1                   | Targets are set to promote better waste management and monitored.                                                                                                                                   |
| 1                   | Waste management system is in place and operational.                                                                                                                                                |
| 1                   | Waste generation is monitored.                                                                                                                                                                      |
| 1                   | Awareness seminars/training sessions are carried out for all staff regarding waste minimization and management.                                                                                     |
| 1                   | Formal, regular training including legislation and compliance awareness, is provided for staff responsible for waste management.                                                                    |
| 1                   | Individual staff are identified who are accountable for implementation of the waste management policies, objectives and targets.                                                                    |
| 1                   | Includes mechanisms to incorporate feedback into procedures or strategy.                                                                                                                            |
| 1                   | Staff responsible for waste management work closely with an authorized waste management firm to ensure waste practices are managed efficiently.                                                     |
| 1                   | Environmental management system (EMS) is in place that includes procedures to review position against an appropriate peer group through published guidance, benchmarking etc. with regards to waste |
| 40*                 | Initiatives are taken to minimize waste (in line with the appropriate Appendix)*                                                                                                                    |

<!-- image -->

<!-- image -->

|   Credit(s) Awarded | Answer option   |
|---------------------|-----------------|
|                   0 | Other           |

- *Appendix section on page 385

## Appendix

The WST 04A - Waste Appendix lists several in house initiatives that might be utilized by the organization in order to meet the aims of this section.

## Assessment criteria

- 1. Organizations must ensure that top management quality objectives that meet the requirements of the business, are established at relevant functions and levels within the organization. It is important that objectives  are  deemed  measurable  and  consistent  with  the  policy.  In  planning  product  realization, organizations shall determine the following, as appropriate:
- a. Quality objectives and requirements for waste management
- b. The  need  to  establish  processes  and  documents  and  to  provide  resources  specific  to  waste management
- c. Required verification, validation, monitoring, measurement, inspection and test activities specific to waste management and the criteria for waste management acceptance;
- d. Records  needed  to  provide  evidence  that  the  realization  processes  and  resulting  waste management meet requirements

## Evidence

- 1. Evidence provided for the relevant criteria can include:
- a. Audits
- b. Procedures
- c. Strategies
- d. Interviews
- e. Any other deemed suitable by the Assessor's sound judgment

## Additional information

See: ISO 9001 'Quality management systems - Requirements' (ISO 9001:2008 5.4 Planning, ISO 9001:2015 6 Planning).

<!-- image -->

<!-- image -->

## Occupier Management WST 05 - Waste monitoring

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

How many waste types are recorded and monitored?

## Aim

To promote the practice of monitoring waste generated within the asset so the organization can understand what it produces and thus target improvements with well-designed policy.

## Available credits

|   Credits | Answer option                                |
|-----------|----------------------------------------------|
|         0 | Question not answered                        |
|         0 | No recording or monitoring of waste types    |
|         1 | 2 waste types recorded and monitored         |
|         2 | 3 waste types recorded and monitored         |
|         4 | 4 or more waste types recorded and monitored |
|         0 | Other                                        |

## Assessment criteria

- 1. The organization should be able to demonstrate that it is recording/monitoring waste generated within the asset by providing up to date figures for waste types produced within the asset on (at least) a monthly basis.
- 2. Recording/monitoring of waste generated should be performed in a way that allows easy interpretation of  data  and  be  more  detailed  than  annual  figures  received  from  waste  carriers.  Providing  complex information, using bills from waste carriers for example, does not count as active monitoring/recording.

## Evidence

- 1. Copy of recording/monitoring; this can be information contained within spreadsheets, etc.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management WST 06 - Waste performance

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

How often is the organization's waste performance at this asset reviewed?

## Aim

To encourage the continual improvement of waste performance.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | Never                 |
|         0 | Infrequently          |
|         1 | At least annually     |
|         2 | At least twice a year |

## Assessment criteria

- 1. Where waste audits are regularly carried out, the following should be considered:
- a. The quantities of waste of each type generated;
- b. The way in which wastes are being handled and stored;
- c. The costs of disposal for different types of waste;
- d. Cost savings as a result of waste minimization strategies (where historical data for comparison is available);
- e. An audit has been carried out prior to the assessment and within the past twelve months and the audit has been used to inform and update the waste strategy.

## Evidence

- 1. Copy of waste audit process and relevant paper trail.
- 2. Dates of previous two audits.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management WST 07 - Waste management objectives

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

In the last reporting year for the organization, what percentage of the organization's annual waste management objectives was achieved?

## Aim

To encourage  and  recognize  the  meeting  of  waste  management  objectives,  thereby  improving  waste performance.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | <25%                  |
|         1 | ≥25% to <50%          |
|         2 | ≥50% to <75%          |
|         3 | ≥75% to <100%         |
|         4 | 100%                  |

## Assessment criteria

- 1. Targets must have been met for the latest annual review period.

## Evidence

- 1. Agreed and documented informal incremental objectives/targets.
- 2. Presentation of achieved objectives, combined with relevant first hand evidence such as weigh bills.

## Additional information

-

<!-- image -->

<!-- image -->

Version 2.0: 2016, April 2019

## Occupier Management WST 08 - Waste sent to landfill

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What is the total quantity of waste sent to landfill on an annual basis (tons) as measured in the reporting period?

## Aim

To identify the impact of waste that is sent to landfill.

## Available credits

|   Credits | Enter quantity of waste sent to landfill in tons during the reporting period   |
|-----------|--------------------------------------------------------------------------------|
|         2 |                                                                                |

## Assessment criteria

- 1. The occupant of the asset must make clear how this information was collected.
- 2. Data provided must be for the same time period as the data provided in Occupier Management WST 09 Waste diverted from landfill and Occupier Management WST 10 - Waste sent for incineration.

## Evidence

- 1. Copies of weigh bills for the relevant time period.
- 2. Copies of relevant invoices and receipts.
- 3. Visual inspection and/or hard copy of waste calculation sheet.
- 4. Internal and  External  audit reports relevant  to waste  management  practices  (if  environmental management system has been implemented by participating organization).
- 5. Relevant section of Corporate Social Responsibility (CSR) report (if written by participating organization).

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management WST 09 - Waste diverted from landfill

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What is the total quantity of waste diverted from landfill on an annual basis (tons) as measured in the reporting period?

## Aim

To encourage and promote the recycling of resources, avoiding the associated impacts of sending waste to landfill.

## Available credits

|   Credits | Enter quantity of waste diverted from landfill in tons during the reporting period   |
|-----------|--------------------------------------------------------------------------------------|
|         2 |                                                                                      |

## Assessment criteria

- 1. The occupant of the asset must make clear how this information was collected.
- 2. Data provided must be for the same time period as the data provided in Occupier Management WST 08 Waste sent to landfill and Occupier Management WST 10 - Waste sent for incineration.

## Evidence

- 1. Copies of weigh bills for the relevant time period,
- 2. Review of organizational waste data calculations, Internal and External audit reports relevant to waste management practices (if environmental management system has been implemented by participating organization),
- 3. Relevant section of Corporate Social Responsibility (CSR) report (if written by participating organization).

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management WST 10 - Waste sent for incineration

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             2 | No                  |

## Question

What is the total quantity of waste sent for incineration on an annual basis (tons) as measured in the reporting period?

## Aim

To encourage and promote the recycling of resources, avoiding the associated impacts of sending waste to landfill.

## Available credits

|   Credits | Enter quantity of waste sent for incineration in tons during the reporting period   |
|-----------|-------------------------------------------------------------------------------------|
|         2 |                                                                                     |

## Assessment criteria

- 1. The occupant of the asset must make clear how this information was collected.
- 2. Data provided must be for the same time period as the data provided in Occupier Management WST 08 Waste sent to landfill and Occupier Management WST 09 - Waste diverted from landfill.

## Evidence

- 1. Copies of weigh bills or other documentation demonstrating the amount for the relevant time period.
- 2. Internal and  External  audit reports relevant  to waste  management  practices  (if  environmental management system has been implemented by participating organization).
- 3. Relevant section of Corporate Social Responsibility (CSR) report (if written by participating organization).

## Additional information

-

<!-- image -->

<!-- image -->

## Land Use and Ecology

## Category summary table

| Issue reference         | Title                            |   Credits available |
|-------------------------|----------------------------------|---------------------|
| LE 06                   | Ecology/biodiversity enhancement |                   3 |
| Total credits available | Total credits available          |                   3 |

<!-- image -->

<!-- image -->

## Occupier Management LE 06 - Ecology/biodiversity enhancement

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             3 | No                  |

## Question

Does the organization contribute to ecology/biodiversity enhancement through sponsorship or active support?

## Aim

To encourage organizations to support local ecology and biodiversity.

## Available credits

|   Credits | Answer option                                                                                                                             |
|-----------|-------------------------------------------------------------------------------------------------------------------------------------------|
|         0 | Question not answered                                                                                                                     |
|         0 | No                                                                                                                                        |
|         1 | Partnerships/sponsorship or active support arrangements are in place with international wildlife protection/enhancement organizations     |
|         2 | Partnerships/sponsorship or active support arrangements are in place with state or national wildlife protection/enhancement organizations |
|         3 | Partnerships/sponsorship or active support arrangements are in place with local wildlife protection/enhancement organizations             |
|         0 | Other                                                                                                                                     |

## Assessment criteria

- 1. Partnerships/sponsorship and active support can come through direct donations of capital and/or staff time.
- 2. Partnerships/sponsorship and active support are most valuable when applied at a local level. Therefore, international partnerships are recognized but not awarded the maximum number of credits.
- 3. Partnerships/sponsorship and active support can be given to a range of groups. As a guide, these groups could:
- a. Provide advice on protecting the habitat for species of local importance to/on the site.
- b. Draw on their local knowledge of any features or species of ecological interest on or near the site.
- c. Provide on-going support and advice to the educational establishment to help manage, maintain and develop the outdoor space in the longer term.

## Evidence

- 1. Copy of relevant partnership/sponsorship documents.

## Additional information

<!-- image -->

<!-- image -->

## Pollution

## Category summary table

| Issue reference         | Title                             |   Credits available |
|-------------------------|-----------------------------------|---------------------|
| POL 15                  | Pollution management              |                  11 |
| POL 16                  | Pollution prevention arrangements |                  52 |
| POL 17                  | Pollution prevention targets      |                   4 |
| Total credits available | Total credits available           |                  67 |

<!-- image -->

<!-- image -->

## Occupier Management POL 15 - Pollution management

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            11 | Yes                 |

## Question

Is pollution managed through avoidance and management of risks?

## Aim

To ensure the avoidance, or minimal production or use of polluting/hazardous materials.

## Minimum standards

To gain a 'Very Good' rating the occupying organization must manage pollution control in line with effective incident response guidance/procedures in accordance to local, national, or international guidance/procedures.

## Available credits

Credits awarded for each of the following criteria met:

|   Credits | Answer options                                                                                                                                                                                                                             |
|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|         2 | Use of effective incident response guidance/procedures in accordance to local, national, or international guidance/procedures                                                                                                              |
|         2 | Reduce and effectively control environmental pollution impacts (these should include the following, as a minimum, where relevant: lighting, noise generating plant/equipment, traffic nuisance)                                            |
|         3 | Use of CO 2 , CO and Nitrous Oxides (NO x ) and other emission controls                                                                                                                                                                    |
|         4 | Use of non-polluting/non-hazardous alternatives wherever possible (these should include the following, as a minimum and where relevant: cleaning products, refrigerants, lubricants, oils, hydraulic fluids, paints, adhesives, batteries) |
|         0 | Other                                                                                                                                                                                                                                      |

## Assessment criteria

- 1. Analysis of risks from dangerous substances, prevention and management can be demonstrated by, but not limited to:
- a. Risk assessment
- b. Procurement strategies
- c. Emergency procedures
- 2. Management practices should be reviewed annually or when changes to any system/building element are made.

## Evidence

<!-- image -->

<!-- image -->

- 1. Relevant documentation outlining pollution management through avoidance and management of risks such as copies of:
- a. Risk assessments
- b. Procurement strategies
- c. Emergency procedures

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management POL 16 - Pollution prevention arrangements

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                            52 | No                  |

## Question

To what extent are pollution prevention objectives/management arrangements in place that allow monitoring against set targets?

## Aim

To recognize and encourage management arrangements aimed at reducing pollution and increasing awareness of pollutants.

## Minimum standards

- 1. To gain a 'Very Good' rating the occupying organization's pollution prevention management must ensure all pollution risks, levels and incidents are recorded.
- 2. In  addition  to  point  1,  to  gain  an  'Excellent'  rating,  the  occupying  organization's  pollution  prevention management must  ensure  that  regular  inspection  and  maintenance  of  machinery/equipment  that  is operational in the organization's day-to-day activities is conducted.

## Available credits

Credits awarded for each of the following criteria met:

|   Credit(s) Awarded | Answer option                                                                                                                                                 |
|---------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                   1 | Scope and objectives defined                                                                                                                                  |
|                   1 | Pollution risks, levels and incidents are recorded                                                                                                            |
|                   1 | Targets are set and monitored to ensure that actions are completed                                                                                            |
|                   1 | Regular inspection and maintenance of machinery/equipment operational in the organization's day-to-day activities to minimize the risk of pollution occurring |
|                   1 | Routine inspection and maintenance of machinery/equipment occasionally operated in the organizations activities to minimize the risk of pollution occurring   |
|                   1 | Pollution risks, levels and incidents are monitored                                                                                                           |
|                   1 | Awareness seminars/training sessions are carried out for all staff regarding pollution avoidance and control                                                  |
|                   1 | Individual staff are identified who are accountable for implementation of the pollution management policies, objectives and targets                           |

<!-- image -->

<!-- image -->

| Credit(s) Awarded   | Answer option                                                                                                                                                                                           |
|---------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1                   | Formal, regular training is provided for staff responsible for pollution prevention and management                                                                                                      |
| 1                   | Mechanisms are in place to incorporate feedback into procedures or strategy                                                                                                                             |
| 1                   | Improvement targets are set in line with best practice guidance available                                                                                                                               |
| 1                   | Environmental management system (EMS) is in place that includes procedures to review position against an appropriate peer group through published guidance, benchmarking etc. with regards to pollution |
| 40*                 | Initiatives are undertaken to prevent pollution (in line with the appropriate Appendix)*                                                                                                                |
| 0                   | Other                                                                                                                                                                                                   |

- *Appendix section on page 387

## Appendix

The POL 16A - Pollution Appendix lists several in house initiatives that might be utilized by the organization in order to meet the aims of this section.

## Assessment criteria

- 1. Organizations must ensure that top management quality objectives that meet the requirements of the business  are  established  at  relevant  functions  and  levels  within  the  organization.  It  is  important  that objectives  are  deemed  measurable  and  consistent  with  the  policy.  In  planning  product  realization, organizations shall determine the following, as appropriate:
- a. Quality objectives and requirements for pollution management
- b. The need to establish processes and documents and to provide resources specific to pollution management
- c. Required verification, validation, monitoring, measurement, inspection and test activities specific to pollution management and the criteria for pollution management acceptance;
- d. Records  needed  to  provide  evidence  that  the  realization  processes  and  resulting  pollution management meet requirements

## Evidence

- 1. Copy of the pollutant avoidance agreements business rules.
- 2. Copy of records of pollutants and all compensation measures undertaken including a copy of the register of pollution accidents.
- 3. Copy of the records of maintenance and repair copy of the maintenance register photos.
- 4. Copy of the records of maintenance and repair copy of the maintenance register.
- 5. Copy of the records for inspection during operation.

<!-- image -->

<!-- image -->

- 6. Copy of the pollutant avoidance agreements agenda of the training records, interviews with staff.
- 7. Copy of the pollutant avoidance agreement names of the employees, interviews with employees.
- 8. Records and certificates of the employees who have completed the training interviews with employees.
- 9. Assessor information for visual inspection of the internal organization structure of systems date of the last feedback.
- 10. Copy of the pollutant avoidance agreement benchmarks used.
- 11. Credentials of the peer group date of benchmarks compared to the measured, which were published.

## Additional information

-

<!-- image -->

<!-- image -->

## Occupier Management POL 17 - Pollution prevention targets

|   Number of credits available | Minimum standards   |
|-------------------------------|---------------------|
|                             4 | No                  |

## Question

In  the  last  reporting  year  for  the  organization,  what  percentage  of  the  organization's  pollution  prevention objectives and targets were achieved?

## Aim

To ensure that targets set ensuring continual action to prevent pollution.

## Available credits

|   Credits | Answer option         |
|-----------|-----------------------|
|         0 | Question not answered |
|         0 | <25%                  |
|         1 | ≥25% to <50%          |
|         2 | ≥50% to <75%          |
|         3 | ≥75% to <100%         |
|         4 | 100%                  |

## Assessment criteria

Not applicable.

## Evidence

- 1. Agreed and documented informal incremental objectives/targets, allowing improvements to be assessed against.
- 2. Presentation of achieved objectives.
- 3. Copy of Pollution Management Strategy (relating to set objectives/targets).

## Additional information

-

<!-- image -->

<!-- image -->

## Appendix A: Offices

<!-- image -->

Version 2.0: 2016, April 2019

<!-- image -->

## Introduction

The Appendix questions for offices cover a range of initiatives that might be undertaken by the organization in order to improve its performance. The categories with appendix question sets are:

-  Health and Wellbeing
-  Energy
-  Transport
-  Water
-  Materials
-  Waste
-  Pollution

## Available credits

Each section within the Appendix has the potential to earn credits, which are then added to the final score in Part 3: Occupier Management.

## Assessment criteria

In order to demonstrate compliance, as with all other questions, the organization will need to demonstrate that it is actively practicing the relevant initiatives.

<!-- image -->

<!-- image -->

## HEA 26A - Health and Wellbeing

| Health and Wellbeing Initiatives                                                                                                               |   Credit(s) Available |
|------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------|
| Provision of planters in occupied areas                                                                                                        |                     1 |
| Clear labeling of hazardous areas, e.g. electricity machinery rooms                                                                            |                     2 |
| Provision of comfortable and individual controllable lighting at workstations                                                                  |                     2 |
| Provision of refreshment facilities, e.g. cafeteria/restaurant, hot and cold drink provision, vending machines                                 |                     2 |
| Provision of external rest areas                                                                                                               |                     2 |
| Monitoring and if necessary reducing office noise levels to acceptable levels.                                                                 |                     4 |
| Monitoring of internal air quality and making changes to address issues raised                                                                 |                     4 |
| Avoiding the use of equipment, such as printers and photocopiers, within main office areas without adequate local ventilation                  |                     4 |
| Implementation of a system for staff to give feedback on comfort of an asset                                                                   |                     4 |
| Provision or subsidization of the use of sports facilities                                                                                     |                     4 |
| Encouraging social activities, e.g. team building activities, organization of social events etc.                                               |                     4 |
| Provision of indoor rest areas and/or staff lounges                                                                                            |                     4 |
| Provision of a health plan for staff, e.g. employee discount with private health care organizations, corporate discount with fitness club etc. |                     4 |
| Total credits available                                                                                                                        |                    41 |

## Assessment criteria

- 1. The organization must adhere to each requirement in all instances within the asset unless there is a valid reason that this is not the case.
- 2. Valid reasons will need to be assessed by the Assessor on a case-by-case basis.

## Evidence

- 1. This can include, but is not limited to:
- a. Photographic evidence.
- b. Technical/manufacturer information.
- c. Staff interviews.
- d. Any other method deemed suitable by the Assessor.

<!-- image -->

<!-- image -->

## ENE 68A - Energy

| Energy Initiatives                                                                                                                           |   Credit(s) Awarded |
|----------------------------------------------------------------------------------------------------------------------------------------------|---------------------|
| Energy saving tips and signage on Information Technology (IT) equipment                                                                      |                   1 |
| No supplementary heating/cooling/ventilation                                                                                                 |                   2 |
| Use of energy efficient printers and photocopiers, such as those that are ENERGY STAR ® certified                                            |                   2 |
| Making guidance on use of blinds on windows to maximize daylight available                                                                   |                   2 |
| Policy to minimize printing                                                                                                                  |                   2 |
| Use of proximity/time switches to equipment                                                                                                  |                   2 |
| Reduction in electrical information technology equipment, such as printers, through group use                                                |                   2 |
| Switching off lights and equipment doing out-of-work hours                                                                                   |                   2 |
| Making guidance on manual control of heating and cooling available                                                                           |                   2 |
| Switching off equipment rather than leaving on standby                                                                                       |                   2 |
| Use of water boilers in place of kettles                                                                                                     |                   3 |
| Use of energy efficient servers, such as those that are ENERGY STAR ® certified                                                              |                   3 |
| The virtualization of servers                                                                                                                |                   3 |
| Use of Light Emitting Diode (LED) screens                                                                                                    |                   4 |
| Use of low power work stations and/or laptops, and a remote server which hosts all information Technology (IT) applications and data storage |                   4 |
| Voltage optimization of utility electricity                                                                                                  |                   4 |
| Total credits available                                                                                                                      |                  40 |

## Assessment criteria

- 1. The organization must adhere to each requirement in all instances within the asset unless there is a valid reason that this is not the case.
- 2. Valid reasons will need to be assessed by the Assessor on a case-by-case basis.

## Evidence

- 1. This can include, but is not limited to:
- a. Photographic evidence.
- b. Technical/manufacturer information.

<!-- image -->

<!-- image -->

- c. Staff interviews.
- d. Any other method deemed suitable by the Assessor.

<!-- image -->

<!-- image -->

## TRA 06A - Transport

| Transport Saving Initiatives                                                                                                                  |   Credit(s) Available |
|-----------------------------------------------------------------------------------------------------------------------------------------------|-----------------------|
| Policy for a staff car share program                                                                                                          |                     2 |
| Well-lit foot and cycle paths on and around the site to optimize safety and encourage use                                                     |                     2 |
| Home working policy                                                                                                                           |                     2 |
| Restricted parking based on a needs-based permit system that gives priority to drivers that meet certain criteria                             |                     2 |
| Charging for car parking                                                                                                                      |                     2 |
| Staff car pool (more than 1 person going to customer for meeting)                                                                             |                     2 |
| Policy for staff use public transport network if travelling on business within the local area                                                 |                     2 |
| All car pool cars to have CO 2 emissions of 177 CO ₂ g/mile or less                                                                           |                     2 |
| All rental cars to be have CO 2 emissions of 193 CO ₂ g/mile or less                                                                          |                     2 |
| Carbon offsetting of staff travel                                                                                                             |                     2 |
| Staff/visitor shuttle bus for travel to and from key transport links                                                                          |                     4 |
| Policy to calculate and monitor CO 2 or equivalent transport emissions from staff travel/commute                                              |                     4 |
| Incentives in place for travelling to work on foot, by bike, car sharing or by public transport (for example, a monthly free breakfast/lunch) |                     4 |
| Video-conferencing facilities                                                                                                                 |                     4 |
| Phone or internet conferencing facilities                                                                                                     |                     4 |
| Total credits available                                                                                                                       |                    40 |

## Assessment criteria

- 1. The organization must adhere to each requirement in all instances within the asset unless there is a valid reason that this is not the case.
- 2. Valid reasons will need to be assessed by the Assessor on a case-by-case basis.

## Evidence

- 1. This can include, but is not limited to:
- a. Photographic evidence.
- b. Technical/manufacturer information.
- c. Staff interviews.
- d. Any other method deemed suitable by the Assessor.

<!-- image -->

<!-- image -->

## WAT 19A - Water

| Water Saving Initiatives                                                                                                           |   Credit(s) Awarded |
|------------------------------------------------------------------------------------------------------------------------------------|---------------------|
| Separate water meter on hot water cold feed to provide indication of hot water consumption                                         |                   1 |
| Water softeners are demand initiated (i.e. based on water consumption rather than a pre- programed timer)                          |                   2 |
| Insulating pipework                                                                                                                |                   2 |
| Water saving tips/signage                                                                                                          |                   2 |
| Only appliances requiring soft water are connected to water softeners                                                              |                   3 |
| Policy to reuse water for landscaping                                                                                              |                   3 |
| Reduce water consumption for landscape by use of mulch to retain moisture in the garden.                                           |                   3 |
| Install rain barrels to help collection of rain water for landscape use                                                            |                   3 |
| Adopt water efficient landscaping practices - i.e. use plants that require less water                                              |                   3 |
| Reducing water pipe length                                                                                                         |                   3 |
| Ensure that water using appliances are operated with full loads                                                                    |                   3 |
| Fit water saving devices in cistern for flushing or fit low water consumption appliances such as those with the WaterSense ® label |                   5 |
| Water pressure reduction for general appliances                                                                                    |                   7 |
| Total credits available                                                                                                            |                  40 |

## Assessment criteria

- 1. The organization must adhere to each requirement in all instances within the asset unless there is a valid reason that this is not the case.
- 2. Valid reasons will need to be assessed by the Assessor on a case-by-case basis.

## Evidence

- 1. This can include, but is not limited to:
- a. Photographic evidence.
- b. Technical/manufacturer information.
- c. Staff interviews.
- d. Any other method deemed suitable by the Assessor.

<!-- image -->

<!-- image -->

## MAT 16A - Materials

| Materials Procurement initiatives                                                                                                        | Credit(s) Awarded   |
|------------------------------------------------------------------------------------------------------------------------------------------|---------------------|
| Monitor and double check meeting arrangements to reduce over ordering refreshments, room size, facilities                                | 2                   |
| Use of detergents which are fully degradable                                                                                             | 2                   |
| Recyclability/Reusability - for example print cartridges                                                                                 | 2                   |
| Base decision process on whole life cost of equipment and consumables, considering the following:                                        |                     |
| Durability - extended life of products                                                                                                   | 2                   |
| Maintainability - ease of cleaning, self-cleaning                                                                                        | 2                   |
| Upgradeability - computer equipment that can be upgraded, modular equipment                                                              | 2                   |
| Work with suppliers to minimize packaging                                                                                                | 4                   |
| Policy and procurement to ensure that printers with low impact such as ammonia free, non- carcinogenic toners                            | 6                   |
| Policy to review all consumed products at least once every two years to identify alternatives which have less of an environmental impact | 8                   |
| Working with suppliers to reduce impact of supply chain                                                                                  | 10                  |
| Total credits available                                                                                                                  | 40                  |

## Assessment criteria

- 1. The organization must adhere to each requirement in all instances within the asset unless there is a valid reason that this is not the case.
- 2. Valid reasons will need to be assessed by the Assessor on a case-by-case basis.

## Evidence

- 1. This can include, but is not limited to:
- a. Photographic evidence.
- b. Technical/manufacturer information.
- c. Staff interviews.
- d. Any other method deemed suitable by the Assessor.

<!-- image -->

<!-- image -->

## WST 04A - Waste

| Waste Initiative                                                                                                               |   Credit(s) Awarded |
|--------------------------------------------------------------------------------------------------------------------------------|---------------------|
| Office recycling programs covering key office waste streams for example paper, magazines, printer/toner cartridges             |                   1 |
| Use clearly differentiated recycling containers (such as labeled and color coordinated) to promote sorting at source           |                   1 |
| Double sided printing                                                                                                          |                   1 |
| Avoidance of printing emails and other non-essential documentation                                                             |                   1 |
| Staff awareness and communication program                                                                                      |                   1 |
| Incentives for staff to reduce waste                                                                                           |                   1 |
| Use of recycled paper                                                                                                          |                   1 |
| Re-use of paper                                                                                                                |                   1 |
| Recycling programs covering other office-related waste streams: cans and bottles, plastics, food waste                         |                   2 |
| Electronic archiving                                                                                                           |                   2 |
| Policy and procedure to reuse of single sided printing as office notepads, draft printing etc.                                 |                   2 |
| Use of 20lb bond paper or lower for general use                                                                                |                   2 |
| Office food waste streams sent for recovery by composting or bio-gas                                                           |                   2 |
| Policy and procedure to reuse office supplies such as binders, file folders, paper clips etc.                                  |                   2 |
| Policy and contract to reuse unwanted IT equipment through local schools, charities, and community organizations               |                   2 |
| Policy and contract to reuse furniture within the organization or through local schools, charities and community organizations |                   2 |
| Policy and contract to work with suppliers to minimize and/or reuse packaging / take back surplus products                     |                   2 |
| Encourage the use of reusable catering containers such as plates, cups etc.                                                    |                   2 |
| Policy and procedure in place to recycle disposable batteries                                                                  |                   2 |
| Conduct office surveys and occupant surveys to identify ways of minimizing, recycling and managing waste                       |                   2 |

<!-- image -->

<!-- image -->

| Waste Initiative                                                                                                                                                                       |   Credit(s) Awarded |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------|
| Use a certified/registered waste carrier to collect materials, such as waste contractors, scrap metal merchants, recycling businesses, local authorities, and dumpster hire businesses |                   4 |
| Work with a waste contractor to maximize reuse, recycling and minimize landfill                                                                                                        |                   4 |
| Total credits available                                                                                                                                                                |                  40 |

## Assessment criteria

- 1. The organization must adhere to each requirement in all instances within the asset unless there is a valid reason that this is not the case.
- 2. Valid reasons will need to be assessed by the Assessor on a case-by-case basis.

## Evidence

- 1. This can include, but is not limited to:
- a. Photographic evidence.
- b. Technical/manufacturer information.
- c. Staff interviews.
- d. Any other method deemed suitable by the Assessor.

<!-- image -->

<!-- image -->

## POL 16A - Pollution

| Pollution prevention and control initiatives to air, land and water                                                                     |   Credit(s) Awarded |
|-----------------------------------------------------------------------------------------------------------------------------------------|---------------------|
| Procedures and training for safe delivery and handling of hazardous materials                                                           |                   4 |
| Check chemical, oil and waste storage containers are fit for purpose, regularly inspected and maintained                                |                   6 |
| Ensure wash waters from cleaning activities with detergents should be drained to sanitary sewer                                         |                   6 |
| Ensure oil interceptors are located and maintained in areas such as parking lots, garages, forecourts, kitchens and fuel delivery areas |                   6 |
| Check surface water treatments address contamination by silt, chemicals, oils etc.                                                      |                   6 |
| Check drainage plans are easily accessible to occupier                                                                                  |                   6 |
| Appropriate contingency plans - spill kits or absorbent material for spillages or run off water from fire fighting                      |                   6 |
| Total credits available                                                                                                                 |                  40 |

## Assessment criteria

- 1. The organization must adhere to each requirement in all instances within the asset unless there is a valid reason that this is not the case.
- 2. Valid reasons will need to be assessed by the Assessor on a case-by-case basis.

## Evidence

- 1. This can include, but is not limited to:
- a. Photographic evidence.
- b. Technical/manufacturer information.
- c. Staff interviews.
- d. Any other method deemed suitable by the Assessor.

<!-- image -->

<!-- image -->

## Schedule of changes to this BREEAM Program Document

This Schedule provides details of relevant additions or changes made to the BREEAM USA In-Use 2016 program that have resulted in a reissue of the Technical Manual.  It is important to note that in general a reissue does not result  in  changes,  deletions  or  additions  to  the  main  assessment  criteria  or  assessment  issues.  Fundamental changes to assessment criteria are typically made as part of a formal program update, resulting in a new BREEAM program version.

| Key   | Type of Change                                                                                                                                                                                                        |
|-------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| A     | An addition, insertion, alteration or deletion to the program document which does not directly affect the assessment criteria, calculation procedures or schedule of evidence (and therefore assessment of an asset). |
| C     | An addition, insertion, alteration or deletion to the scope, assessment criteria, evidence required or relevant definitions.                                                                                          |

Issue 1.1

| Issue or section                        | Identifier             | Type   | Specifics of change                                                                                                                             |
|-----------------------------------------|------------------------|--------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| Throughout the Manual                   | --                     | A      | Correction of typographical errors and clarifications of terminology                                                                            |
| Evidence requirements for BREEAM in-Use | Robustness of evidence | A      | "Photographic evidence can be used…" to "Assessors are encouraged to gather their own photographic evidence which can be used…"                 |
| All Parts                               |                        | A      | Inserted table to show the total number of credits available for each Category addressed in the Part.                                           |
| HEA 03                                  | Evidence 4             | C      | Changed 'Heating' to 'Temperature'                                                                                                              |
| HEA 05                                  | Title                  | A      | Changed title from 'Microbial contamination' to Minimizing Legionella contamination risk' to more accurately describe what the issue addresses. |
| HEA 06                                  | Title                  | A      | Changed title from 'Water provisions' to 'Drinking water provisions' to more accurately describe what the issue addresses.                      |
| ENE 04                                  | Title                  | A      | Changed wording in title from 'Pressure/air' to 'Building pressure/air' to more accurately describe what the issue addresses.                   |
| ENE 21                                  | Title                  | A      | Changed title from 'Leakage tests' to 'Duct and air handling leakage tests' to more accurately describe what the issue addresses.               |

<!-- image -->

SD221 USA © BRE Global Ltd 2019

| Issue or section   | Identifier             | Type   | Specifics of change                                                                                                                                |
|--------------------|------------------------|--------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| ENE 23             | Title                  | A      | Changed title from 'Water heating' to 'Domestic water heating' to more accurately describe what the issue addresses.                               |
| ENE 24             | Title                  | A      | Changed title from 'Water heating energy sources' to 'Domestic water heating energy sources' to more accurately describe what the issue addresses. |
| ENE 30             | Evidence 1             | A      | Changed 'community' to 'micro grid' and 'schemes' to 'programs' to reflect US terminology.                                                         |
| TRA 01             | Assessment Criteria 1c | A      | Changed 'with over' to 'for the next' and added '+' in front of '1000' to clarify the calculation method.                                          |
| WAT 01             | Title                  | A      | Changed words in title from 'meter' to 'metering' to more accurately describe what the issue addresses.                                            |
| POL 03             | Title                  | A      | Changed title from 'Impact mitigation' to 'Surface water runoff impact mitigation' to more accurately describe what the issue addresses.           |
| POL 05             | Title                  | A      | Changed title from 'Leak detection systems' to 'Refrigerant leak detection systems' to more accurately describe what the issue addresses.          |
| MAN09              | Title                  | A      | Changed title from 'Operating procedures' to 'Operating procedures: energy reduction' to more accurately describe what the issue addresses.        |
| MAN10              | Title                  | A      | Changed title from 'Leak testing' to 'Ventilation system leak testing' to more accurately describe what the issue addresses.                       |
| MAN12              | Title                  | A      | Changed title from 'Building controls review' to 'Building management system review' to more accurately describe what the issue addresses.         |
| MAN13              | Title                  | A      | Changed title from 'Building adaptation' to 'Functional adaptability' to more accurately describe what the issue addresses.                        |
| ENE 45             | Evidence 4             | C      | Changed '12-month period specified' to 'in ENE 31 and ENE 32', reflecting the requirement for consistent reporting period for all fuel types.      |
| WAT 12             | Evidence 3b            | C      | Added 'or tenant/staff presentations' after newsletters.                                                                                           |
| WAT 13             | Title                  | A      | Changed title from 'Drinking water' to 'Drinking water provision' to more accurately describe what the issue addresses.                            |

<!-- image -->

<!-- image -->

| Issue or section   | Identifier             | Type   | Specifics of change                                                                                                                                       |
|--------------------|------------------------|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------------|
| WAT 14             | Title                  | A      | Changed title from 'Refurbishment' to 'Refurbishment policy: water efficient fixtures and fittings' to more accurately describe what the issue addresses. |
| WAT 15             | Title                  | A      | Changed title from 'Water strategy' to 'Water system maintenance strategy' to more accurately describe what the issue addresses.                          |
| WAT 17             | Title                  | A      | Changed title from 'Aspects and impacts' to 'Water extraction' to more accurately describe what the issue addresses.                                      |
| MAT 11             | Title                  | A      | Changed title from 'Risk assessment' to 'Fire risk assessment' to more accurately describe what the issue addresses.                                      |
| MAT 12             | Title                  | A      | Changed title from 'Risk management' to 'Fire risk management' to more accurately describe what the issue addresses.                                      |
| MAT 14             | Title                  | A      | Changed title from 'Hazard management' to 'Natural hazard management' to more accurately describe what the issue addresses.                               |
| WAT 18             | Title                  | A      | Changed title from 'Water management' to 'Water management: staff engagement' to more accurately describe what the issue addresses.                       |
| WAT 19             | Title                  | A      | Changed title from 'Water management' to 'Water monitoring & management' to more accurately describe what the issue addresses.                            |
| MAT 18             | Additional information | C      | Clarification that the percentage calculation for the suppliers is by the number of suppliers rather than procurement spend.                              |

## Issue 2.0

| Issue or section                        | Identifier   | Type   | Specifics of change                                                                                                                |
|-----------------------------------------|--------------|--------|------------------------------------------------------------------------------------------------------------------------------------|
| Terms and conditions                    | Disclaimer   | A      | Replaced BRE America, LLC with BRE Global Limited                                                                                  |
| About the BRE Group                     |              | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                         |
| About this Program Document             |              | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                         |
| Changes to this BREEAM program document |              | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited Added row to include this issue as the Current version. |

<!-- image -->

| Issue or section                         | Identifier                                  | Type   | Specifics of change                                                                                                                         |
|------------------------------------------|---------------------------------------------|--------|---------------------------------------------------------------------------------------------------------------------------------------------|
| Introduction to BREEAM                   |                                             | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                                  |
| Introduction to BREEAM                   | BREEAM USA programs                         | A      | Slight rewording to remove reference to BRE America, LLC and replaced with BRE Global Limited                                               |
| Introduction to BREEAM                   | Ensuring quality and consistency            | A      | Replaced section to reference BRE Global Limited specific activities                                                                        |
| BREEAM USA In- Use                       | BREEAM USA In- Use                          | A      | Spelling correction                                                                                                                         |
| BREEAM USA In- Use                       | Relationship to other BREEAM programs       | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                                  |
| BREEAM USA In- Use                       | How to apply the BREEAM USA In- Use program | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                                  |
| Scoring and Rating of BREEAM USA In- Use | Introduction paragraph                      | A      | Removal of extra wording.                                                                                                                   |
| Scoring and Rating of BREEAM USA In- Use | Minimum standards                           | A      | Spelling correction                                                                                                                         |
| Evidence requirements                    |                                             | A      | Removed references to BRE America, LLC and replaced with BRE Global Limited                                                                 |
| Building Details                         | Asset Address                               | A      | Reordered State, ZIP Code and Country to reflect the order in the online tool.                                                              |
| Building Details                         | Asset Ownership/ Occupier Details           | C      | Clarified that where there are multiple organizations or persons occupying/leasing the asset, 'multi-tenanted' or a variant can be entered. |
| Basic Building Details                   | Ownership / Occupancy Details               | A      | Spelling correction                                                                                                                         |
| Basic Building Details                   | Asset Dimensions                            | A      | Spelling correction                                                                                                                         |

<!-- image -->

| Issue or section    | Identifier                     | Type   | Specifics of change                                                                                                        |
|---------------------|--------------------------------|--------|----------------------------------------------------------------------------------------------------------------------------|
| Asset Type          |                                | C      | Clarified that the full list of Asset Types and Subtypes are available to the Assessors through the BREEAM Knowledge Base. |
| ENE 30              | On-site renewables             | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| ENE 34              | Natural gas consumption        | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| ENE 35              | Propane consumption            | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| ENE 36              | Gas oil consumption            | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| ENE 38              | Biodiesel consumption          | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| ENE 40              | Wood/Waste wood consumption    | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| ENE 41              | District heating consumption   | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| ENE 43              | District cooling consumption   | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| ENE 66              | Sub-metering: Tenanted areas   | A      | Removed reference to BRE America, LLC and replaced with BRE Global Limited                                                 |
| MAT 09              | Sustainable procurement policy | A      | Spelling correction                                                                                                        |
| Schedule of Changes |                                | A      | Insertion of this table.                                                                                                   |

<!-- image -->

<!-- image -->