---
document_id: seai_energy_audit_handbook
title: "SEAI Energy Audit Handbook: Comprehensive Methodology for Non-Domestic Audits"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2021
original_file: "seai_energy_audit_handbook_methodology.pdf"
tables_detected: 86
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Energy Audit Handbook

<!-- image -->

1

BOOKMARK

## Contents

| Introduction                   | Introduction                                                     | 4   |
|--------------------------------|------------------------------------------------------------------|-----|
| 1. Undertaking an energy audit | 1. Undertaking an energy audit                                   | 5   |
| 1.1                            | What is an energy audit?                                         | 6   |
| 1.2                            | Why carry out an energy audit?                                   | 6   |
| 1.3                            | How does an energy audit work?                                   | 6   |
| 2. Initial preparation         | 2. Initial preparation                                           | 9   |
| 2.1                            | Arrange the introductory meeting                                 | 10  |
| 2.2                            | Agree the approach                                               | 10  |
| 2.3                            | Request specific information and data                            | 10  |
| 2.4                            | Identify key personnel                                           | 11  |
| 3. Pre-analysis and planning   | 3. Pre-analysis and planning                                     |     |
| 3.1                            | Undertake preliminary analysis                                   | 13  |
| 3.2                            | Review best available technologies/practices                     | 13  |
| 3.3                            | Consider measurement planning and portable measuring instruments | 13  |
| 3.4                            | Analyse current and past performance                             | 15  |
| 3.4.1                          | Energy billing data analysis                                     | 15  |
| 3.4.2                          | Use of regression analysis                                       | 18  |
| 3.4.3                          | Use benchmarking                                                 | 20  |

| 4   | 3.5                          | Develop an audit checklist                       | 21   |
|-----|------------------------------|--------------------------------------------------|------|
|     | 3.5.1                        | Energy Venn diagram sample application           | 22   |
| 5   | 3.5.2                        | Sample audit checklist for compressed air system | 23   |
| 6   | 4. Conducting the site visit | 4. Conducting the site visit                     |      |
| 6 6 | 4.1                          | Devise site visit agenda                         | 26   |
| 9   | 4.2 4.3                      | Consider health and safety                       | 26   |
|     |                              | Carry out site visit                             | 26   |
|     | 4.3.1                        | Assess energy management                         | 27   |
| 10  | 5. Technical assessment      | 5. Technical assessment                          |      |
| 11  | 5.1                          | Buildings                                        | 31   |
| 12  | 5.1.1                        | What to check                                    | 31   |
|     | 5.1.2                        | Typical opportunities                            | 31   |
| 13  | 5.1.4                        | Other resources                                  | 31   |
| 13  | 5.2                          | Lighting                                         | 32   |
| 13  | 5.2.1                        | What to check                                    | 32   |
|     | 5.2.2                        | Typical opportunities                            | 32   |
| 15  | 5.2.3                        | Potential pitfalls                               | 33   |
| 15  | 5.2.4                        | Other resources                                  | 33   |
| 18  | 5.3                          | Heating and boilers                              | 34   |
| 20  | 5.3.1                        | What to check                                    | 34   |
|     | 5.3.2                        | Typical opportunities                            | 34   |

25

29

| 5.3.3   | Potential pitfalls                               |   35 |
|---------|--------------------------------------------------|------|
| 5.3.4   | Other resources                                  |   35 |
| 5.4     | Heating, ventilation and air conditioning (HVAC) |   36 |
| 5.4.1   | What to check                                    |   36 |
| 5.4.2   | Typical opportunities                            |   36 |
| 5.4.3   | Potential pitfalls                               |   36 |
| 5.4.4   | Other resources                                  |   36 |
| 5.5     | Pumps                                            |   37 |
| 5.5.1   | What to check                                    |   37 |
| 5.5.2   | Typical opportunities                            |   37 |
| 5.5.3   | Potential pitfalls                               |   37 |
| 5.5.4   | Other resources                                  |   37 |
| 5.6     | Transport                                        |   38 |
| 5.6.1   | What to check                                    |   38 |
| 5.6.2   | Typical opportunities                            |   38 |
| 5.6.3   | Potential pitfalls                               |   38 |
| 5.6.4   | Other resources                                  |   38 |
| 5.7     | Refrigeration and cooling                        |   39 |
| 5.7.1   | What to check                                    |   39 |
| 5.7.2   | Typical opportunities                            |   39 |
| 5.7.3   | Potential pitfalls                               |   40 |
| 5.7.4   | Other resources                                  |   40 |
| 5.8     | Industrial processes                             |   41 |
| 5.8.1   | What to check                                    |   41 |
| 5.8.2   | Typical opportunities                            |   41 |
| 5.8.3   | Potential pitfalls                               |   41 |

50

| 5.8.4                               | Other resources                     | 41   | 7. Identifying and prioritising                    | 7. Identifying and prioritising                    | 50   |
|-------------------------------------|-------------------------------------|------|----------------------------------------------------|----------------------------------------------------|------|
| 5.9                                 | Wastewater treatment plants         | 42   | opportunities                                      | opportunities                                      |      |
| 5.9.1                               | What to check                       | 42   |                                                    |                                                    |      |
| 5.9.2                               | Typical opportunities               | 42   | 7.1                                                | Identify opportunities for improvement             | 51   |
| 5.9.3                               | Potential pitfalls                  | 42   | 7.2                                                | Generate register of opportunities                 | 51   |
| 5.9.4                               | Other resources                     | 42   | 7.2.1                                              | Recommended information                            | 51   |
| 5.10                                | Compressed air                      | 43   | 7.3                                                | Methods to identify opportunities                  | 53   |
| 5.10.1                              | What to check                       | 43   | 7.4                                                | Prioritise opportunities                           | 53   |
| 5.10.2                              | Typical opportunities               | 43   | 7.5                                                | Data retention                                     | 53   |
| 5.10.3                              | Potential pitfalls                  | 43   |                                                    |                                                    |      |
| 5.10.4                              | Other resources                     | 43   | 8. Reporting the results                           | 8. Reporting the results                           | 54   |
| 5.11                                | Renewable energy                    | 44   |                                                    |                                                    |      |
|                                     |                                     |      | 8.1                                                | Audit Report                                       | 55   |
| Financial analysis of opportunities | Financial analysis of opportunities | 45   | 8.2                                                | Management presentation/closing meeting            | 56   |
| 6.1                                 | Choice of financial analysis tool   | 46   | Appendices                                         | Appendices                                         | 57   |
| 6.1.1                               | Small investments                   | 46   |                                                    |                                                    |      |
| 6.1.2                               | Larger investments                  | 46   | Appendix 1: Sample data request                    | Appendix 1: Sample data request                    | 58   |
| 6.1.3                               | Additional considerations           | 46   | Appendix 2: Best practice and technology resources | Appendix 2: Best practice and technology resources | 59   |
| 6.2                                 | Validated calculations              | 46   | Appendix 3: Sample bills analysis tool             | Appendix 3: Sample bills analysis tool             | 60   |
| 6.2.1                               | General approach                    | 46   | Appendix 4: Sample site visit agenda               | Appendix 4: Sample site visit agenda               | 61   |
| 6.2.2                               | Accuracy considerations             | 46   | Appendix 5: Sample financial analysis tool         | Appendix 5: Sample financial analysis tool         | 62   |
| 6.3                                 | Financial analysis methods          | 47   | Appendix 6: Sample register of opportunities       | Appendix 6: Sample register of opportunities       | 63   |
| 6.3.1                               | Simple payback                      | 47   | Terms and definitions                              | Terms and definitions                              | 64   |
| 6.3.2                               | Net present value                   | 47   |                                                    |                                                    |      |
| 6.3.3                               | Internal rate of return             | 48   |                                                    |                                                    |      |
| 6.3.4                               | Life cycle costing                  | 49   |                                                    |                                                    |      |

## Introduction

An ongoing process of energy management can help keep organisations at the leading edge in their industries, providing sustained competitive advantage. Given the rate of change in energy technology and markets, and the impact that it can have on performance, businesses with a strong track record in the area recognise the value of maintaining a strategic focus on energy.

A more sustainable approach to energy through energy efficiency and the use of renewables often represents the lowest risk and most cost-effective investment for companies looking to improve their environmental performance.

It will also serve as a useful reference guide for those undertaking the energy audit, be they internal or external auditors.

meaningful decision-making on energy improvement opportunities identified.

One of the first steps for an organisation in adopting a more sustainable approach to energy is carrying out an energy audit. Completing an energy audit gives a company a better picture of its energy consumption and identifies opportunities for improvement often delivering immediate cost savings. It can also demonstrate compliance with legal obligations which require certain organisations to undertake energy audits.

The Sustainable Energy Authority of Ireland (SEAI) has developed this comprehensive Energy Audit Handbook as a step-by-step guide to energy auditing. We believe it will benefit all organisations considering or carrying out an energy audit; regardless of sector, size or experience.

The handbook sets out the complete energy audit process guiding users each step of the way - from audit preparation and pre-analysis through to conducting the site visit and reporting findings. It gives the user a better understanding of what to expect from an energy auditor which can be particularly useful for companies preparing for their first audit. The handbook includes some key resources and a range of references offering a best practice framework for both high level and technically detailed use.

The advice in this handbook is intended to be proportionate, so that the level of detail used by the auditor for any measurement, estimate or analysis provides a sufficiently accurate picture of energy performance. This will facilitate relevant and

<!-- image -->

Important Note: The Energy Audit Handbook does not aim to be a definitive energy audit guide, and compliance with this handbook does not confirm compliance with the legal auditing obligations set out in the Energy Efficiency Directive 2012, transposed into Irish law as SI 426 (2014). For more information on these legal obligations see the SEAI website: Energy Auditing Scheme.

<!-- image -->

1. Undertaking an Energy Audit

## 1.1 What is an energy audit?

An energy audit is an inspection, survey and analysis of energy flows for identification of energy savings opportunities in a building, process or system to reduce the amount of energy input into the system, without negatively affecting the output(s).

The scope and the level of detail used in an energy audit should be proportionate and will depend on the impact of the energy uses and the purpose for which the output information will be used. Opportunities identified in an energy audit can vary; they may be of a technical nature, or they may also relate to how energy is managed by the organisation and/or how people's behaviour can influence energy use. All of these types of opportunities should be considered for inclusion in an energy audit report.

## 1.2 Why carry out an energy audit?

## There are many reasons for undertaking an energy audit including:

- · To improve energy performance and minimise the environmental impacts of the organisation's operations.
- · To identify behavioural change opportunities by evaluating current operations and maintenance practices.
- · To identify technical opportunities by evaluating significant process energy-using components or utilities including boilers, refrigeration plant, ventilation systems, building performance and fleet efficiency.
- · To provide clear financial information regarding energy savings opportunities in order to prioritise these items for the organisation's decision-making process.
- · To gain a greater understanding of a part or all of the organisation's energy usage patterns.
- · To identify potential for using renewable energy supply technologies.
- · To achieve compliance with legal requirements such as the Energy Efficiency Directive, Industrial Emissions Directive or the Environmental Protection Agency's waste license requirements.To comply with corporate social responsibility goals.
- · To meet customer and shareholder expectations.
- · To inform a strategic plan aimed at minimising the organisation's carbon footprint.
- · To contribute to the process for certification to a formal energy management system, as set out in ISO 50001.

<!-- image -->

## 1.3 How does an energy audit work?

ISO50002 (2015) provides clarity on structures for efficient energy audits and is the acknowledged baseline for information on energy audits. However, the information in this handbook aims to provide additional direction, guidance and assistance on the process of delivering an energy audit.

## The energy audit process has two distinct phases:

Phase 1:

Preparation &amp; Pre-analysis, and

Phase 2:

Site Visit &amp; Reporting.

<!-- image -->

<!-- image -->

<!-- image -->

2. Initial Preparation

## 2.1 Arrange the introductory meeting

The purpose of the introductory meeting is to set the context for the energy audit; confirm its scope; engage all relevant organisation personnel in the audit process and request specific energy information from the organisation. This information should enable appraisal of the client organisation's current energy use and energy management system.

## 2.2 Agree the approach

Preparation and planning are key to ensuring that an effective and proportionate audit is conducted. Once the rationale for carrying out an energy audit has been established with the client organisation; the scope, level of analysis and the boundaries of the audit should be agreed.

For instance, the scope may be organisation-wide (including multi-site locations); it may form part of a larger legal compliance assessment; or it may be specific to a significant energy-using piece of equipment, department, process, transport fleet or building. This may result in the auditor taking a different approach on different sites or different operating areas. The client organisation may wish the auditor to focus on a specific area or process, e.g. refrigeration energy use. Where there is a legal requirement to audit energy  use, the scoping exercise may include establishing the percentage of the organisation's energy use to be covered by the audit.

When planning the audit agenda, it is important to note the operational patterns of the area to be audited. The best time to audit a significant energy-using piece of equipment is during both operational periods and nonoperational periods, so that the audit team can identify baseload reduction opportunities.

## 2.3 Request specific information and data

## The data requested may include any or all of the following:

- · Electricity bills, other fuel bills, meter registration system operator (MRSO) data, gas point registration number (GPRN) data, or access to online billing data. The energy billing information should span a minimum of one year but ideally should include the previous three years.
- · Energy monitoring software and data sets, as well as copies of building layout drawings, piping and

<!-- image -->

instrumentation diagram/drawings (P&amp;IDs), site plans, asset or equipment lists, process diagrams, and activity metrics data such as production output or occupancy weather data may also be requested.

- · Historic energy performance information from mandatory public sector monitoring and reporting data (M&amp;R), other performance information collected such as LIEN, CSO data or previous energy audits. Known opportunities for energy efficiency improvements may also be beneficial at this stage. However, the information request needs to be cognisant of the industry or organisation being audited; for example, information routinely available in a highly-regulated industry may not be available in another industry.

<!-- image -->

## 2.4 Identify key personnel

The success of the audit clearly depends on the availability of key documents, the subsequent review of these documents and the data gathered. However, the availability of knowledgeable and experienced members of the client organisation, who may provide significant detail about operational routines, recent and planned changes, technical improvements, or specific areas of concern is also critical.

The auditor should identify all key personnel, gain an understanding of their roles and responsibilities, and establish their availability to cooperate with the audit process. A senior director should also be identified at this point, to sign off on the audit as part of a management review.

'Buy in' will be required from various departments to ensure that sufficient time and resources are made available to enable the auditor to analyse the main areas of energy consumption, and to determine departments' operational practices and behaviours.  Organisational commitment should extend wider than just utilities personnel and should include members of the operations, maintenance teams and any sub-contractors working on site. Typically, production personnel play a key role in determining how much energy is used and they should be included in any discussions.

<!-- image -->

<!-- image -->

3. Pre-analysis &amp; Planning

## 3.1 Undertake preliminary analysis

Preliminary analysis of relevant data provided by the client organisation can help the auditor to carry out more effective site work, as it can highlight potential areas for further investigation. Such areas might include periods with spikes in energy use or any particularly regulatory considerations. These will help identify the measurements that need to be taken.

When the required data has been received from the organisation, a certain level of analysis should be carried out to inform the decision-making process for the rest of the audit. Analysis of the data should give a better understanding of the operational regime; the nature and quantity of energy consumption; the major energy consuming equipment that will need to be closely examined during the site visit and the requirements for any temporary metering or spot metering. In addition, analysis of the supplied data should assist the process of defining the audit checklist and the site visit agenda.

if auditing a milk processing plant, it is important to know about current energy management best practice in the dairy industry and in refrigeration. There are numerous handbooks, standards and best available technology (BAT) documents available for each sector, and these should be referenced via the relevant BREF standard. Other materials include SEAI special working group reports and various reference documents under the IPPC Directive and the Industrial Emissions Directive (IED), the Carbon Trust, the Chartered Institute of Building Services Engineers (CIBSE), and the US Government.

data collected for a number of days and can then be uploaded either directly or remotely for analyses off site. Other systems can be installed wirelessly or wireless broadband technology utilised; where real time data can be collected from a web platform thus avoiding the necessity to be on site.

## 3.2 Review best available technologies/practices

A key element of energy audit preparation is to research current energy management best practice for the client's sector or business activity. For example, if auditing a local authority, it is imperative to be aware of the latest technologies in public lighting. Similarly,

## 3.3 Consider measurement planning and portable measuring instruments

Portable measuring instruments may be needed to substantiate the accuracy of existing permanent instruments where there is a question in relation to their accuracy. Modern portable metering can store

<!-- image -->

<!-- image -->

Table 1 shows the appropriate portable measuring equipment for various systems that could be tested during an energy audit.

<!-- image -->

<!-- image -->

## Table 1 - Instrument Types

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Electrical Systems                               | Temperature Measurement                                                                                               | Combustion Systems    | Steam Systems                                    | HVAC Systems                             | Buildings                                             | Compressed Air                | Data Loggers                                                                      | LPHW and CHW            |
|--------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|-----------------------|--------------------------------------------------|------------------------------------------|-------------------------------------------------------|-------------------------------|-----------------------------------------------------------------------------------|-------------------------|
| • Multimeter • Voltmeter • Ammeter • Power Meter | • Surface Pyrometer • Portable Electronic • Thermometer • Thermocouple Probe • Infrared Thermometer • Infrared Camera | • Combustion Analyser | • Ultrasonic Leak • Detectors • SteamTrap Tester | • Manometer • Psychrometric • Anemometer | • Light Meter • Measuring Tape • Thermal Image Camera | • Ultrasonic Leak • Detectors | • 4-20Ma Logger • 0-10V Logger • Digital Logger • Vibration Logger • Light Sensor | • Ultrasonic Flowmeters |

## 3.4 Analyse current and past performance

Analysis of information supplied by the client organisation, site visit observations and metering results will help the audit team gain a thorough understanding of energy usage profiles across the site.  It will also help them develop a better understanding of the processes carried out and the types of technologies used. In addition, it will help determine specific areas on which the audit should concentrate.

## 3.4.1 Energy billing data analysis

The auditor's initial review of energy bills should determine if any unnecessary charges have been incurred.

## For example:

- · Charges associated with excessive or insufficient maximum import capacity (MIC) for electricity.

<!-- image -->

## Analysis of bills, MRSO data or energy monitoring system may include the following:

- Figure 1 - Sample Energy Analysis

Monthly electricity load profile over a period of two years indicating significant peak in electrical consumption in February 2016. The energy audit should establish what caused this increase.  This could possibly be a metering error or an accidental change to a process parameter.

<!-- image -->

Monthly profile indicating seasonal driver for gas consumption. This driver should be further analysed to determine if the driver is weather related or activity related and determine if the relationship is statistically significant.

<!-- image -->

<!-- image -->

## Figure 1 (contd)  - Sample Energy Analysis

Quarter-hour profile indicating electrical load profile over a seven-day period, including weekend profile. This should be analysed to determine baseloads, out-ofhour consumption and any anomalies in the data that may lead to identification of energy savings opportunities.

<!-- image -->

<!-- image -->

## 3.4.2 Use of regression analysis

The energy consumption profiles identified from the bills or the energy monitoring systems can be further analysed using statistical analysis techniques such as regression analysis (Figure 2). This is a powerful analytical tool and may be used to gain greater insight into what is driving changes in the facility's energy consumption.

For instance, the auditor can use data from a building and illustrate the energy consumption versus the weather; discuss poor, average and strong correlation (R ) values, or consider 2 baseload and operational control issues which may be affecting these values. Heating degree day analysis provides a methodology for analysing space heating energy loads against variance in outside temperatures. Therefore, any other water heating or cooking gas loads, where applicable, should be subtracted from the total consumption to determine the space heating energy use.

The energy audit report should interpret graphs in order to gain an understanding of issues such as baseloads, changes in performance over time, poor R  values, and higher energy 2 consumption during certain weekends. The audit report may also issue recommendations on how to use this information for ongoing energy management after the audit has been completed.

This information can subsequently be used to determine future energy consumption as part of an energy performance indicator (EnPI) for ongoing monitoring and management of performance.  Degree day data for space heating analysis is available from the Met office. Typically, base load data of 15.5°C is used for office and 18°C is used for buildings with high heat demand - such as hospitals and nursing homes.

<!-- image -->

- Figure 2 - Regression Analysis

Regression analysis involves the comparison of energy consumption on the Y axis versus the potential energy driver on the X axis.

The regression analysis needs to be analysed to determine the R 2 value or the coefficient of determination. The higher the R  value the greater 2 the influence the energy driver has on the energy consumption.

Energy Consumption v Weather

<!-- image -->

In the first example on the left, where the R  value 2 is 0.936, this indicates that 93.6% of the variability in energy consumption is accounted for by variability in the weather. Whereas, in the third example, only 12.64% of the energy consumption variability is related to the variability of the weather.

This analysis will yield the formula Y = MX * C where: Y is the predicted energy consumption, M is the slope of the line (energy consumed per unit of output) and C is a constant (possibly baseload of the facility).

Energy Consumption v Weather

<!-- image -->

HDD

<!-- image -->

Energy Consumption v Weather

<!-- image -->

HDD

## 3.4.3 Use benchmarking

Benchmarking aims to compare the organisation's energy performance against similar external operations - possibly sister sites, or similar industry sectors. Benchmarking activity can also be carried out at significant energy user (SEU) level. Internal benchmarking is a useful exercise for sector-specific activities where there are no external benchmarking data available and a company can develop its own benchmarks from historical energy use data or production data. This should be undertaken when equipment is new and will assist in determining loss in performance over time. When using benchmarking information, it is important to understand the benchmarking methodology used and the assumptions made during the benchmarking exercise.

Information on how to compare operations is available from multiple sources including the Chartered Institution of Building Services Engineers (CIBSE) , The American Society of Heating, Refrigerating and AirConditioning Engineers (ASHRAE), The Carbon Trust, and EU Best Practice Guides. The CIBSE TM46:2008 is a useful benchmarking guide for buildings and it encompasses 29 benchmarking categories. A sample of building benchmarking data from this handbook is provided in Table 2. Considerations around significant energy user benchmark indices are outlined in Table 3.

<!-- image -->

## Table 2 Sample of building benchmarking data

| Building Type                       |   Electricity Typical Benchmark (kWh/m 2 ) |   Fossil-thermal Typical Benchmark (kWh/m 2 ) | Source                                  |
|-------------------------------------|--------------------------------------------|-----------------------------------------------|-----------------------------------------|
| General Office                      |                                         95 |                                           120 | CIBSE TM46/ Energy Consumption Guide 19 |
| Supermarket/ Other Large Food Store |                                        400 |                                           105 | CIBSE TM46                              |
| Hotel                               |                                        105 |                                           330 | CIBSE TM46                              |
| 25m Swimming Pool                   |                                        237 |                                          1336 | Energy Consumption Guide 78             |
| University Campus                   |                                         80 |                                           240 | CIBSE TM46                              |

## Table 3: Significant energy user benchmark indices

| Significant Energy User   | Typical Performance Benchmark   | Items to Consider Prior to Benchmarking   |
|---------------------------|---------------------------------|-------------------------------------------|
| Boilers                   | Boiler Efficiency               | Boiler Type, Fuel Source                  |
| Compressors               | Specific Energy Consumption     | Drier Technology, Size of Plant           |
| Chillers                  | Coefficient of Performance      | Refrigeration Temperature, Refrigerant    |
| Lighting                  | Lux Levels, Kwh/m 2             | Energy Service, Lighting Technology       |
| Transport                 | Litres/100km, Mpg               | Vehicle Type, Journey such as Intercity   |

## 3.5 Develop an audit checklist

It may be helpful to develop an energy audit checklist to assist in identifying the significant energy users on the site and their respective operating parameters.

For example, when auditing a steam boiler, it may be useful to develop a checklist which would prompt the auditor to record specific information, as shown in Figure 3.

Figure 3

<!-- image -->

## 3.5.1 Energy Venn diagram sample application

The Energy Venn diagram (Figure 4) is an effective way of visualising the factors contributing to energy use, and may be useful when drawing up a checklist.

At the core is the energy service or utility. Usually, this is an SEU and therefore has the greatest impact on energy usage intensity. The challenge for identifying energy efficiency opportunities should begin here and work out through the layers. The layers outside the core generally have a diminishing impact on energy intensity.

## Figure 4 - Energy Venn diagram illustrating energy consumption 'layers'

<!-- image -->

## The following table shows how the Energy Venn diagram layers relate to a lighting system.

- Table 3: Significant energy user benchmark indices

| Layer                     | Definition                                                     | Lighting Example                                                                               |
|---------------------------|----------------------------------------------------------------|------------------------------------------------------------------------------------------------|
| Energy Service            | The desired outcome that necessitates the use of energy        | Luminance level for office tasks                                                               |
| Process                   | The means by which the energy service is achieved              | Natural/artificial lighting                                                                    |
| Equipment                 | The constituent parts of the process                           | Fixtures, shading devices, reflectors                                                          |
| Control                   | The control applied on the above equipment                     | Automation systems including daylight sensors, occupancy sensors, dimming capability, switches |
| Operation and Maintenance | The ongoing operation and maintenance applied to the equipment | Optimal change-out of light tubes, alignment to evolving occupancy patterns                    |
| Management                | The ongoing management of the equipment                        | Awareness campaigns, EPIs (Energy Performance Indicators)                                      |

<!-- image -->

## 3.5.2 Sample audit checklist for compressed  air system

The approach used to devise a checklist for a compressed air system using the Energy Venn diagram is illustrated in Figure 5.

- · What do I want to do with the compressed air?
- · What requires the compressed air?
- · What is the fundamental piece of work that I want compressed air to do?
- · Is there another way of delivering the output that requires using less or no energy?
- · Can I use a less energy intensive alternative?
- · What is the minimum specification required?
- Figure 5 - Developing a checklist for compressed air system

<!-- image -->

<!-- image -->

As shown above, if using the Energy Venn diagram certain questions are developed in relation to each layer. These are listed below:

## Energy service, how the energy is being used:

## Plant design:

- · Is the compressed air at only 7-10% efficiency necessary for the specific job or could the function be fulfilled by another more efficient method, for example, an electric actuator?
- · If it is not feasible to use a more efficient method, is it possible to reduce pressure, which would decrease energy use and losses from leakage and so on? This could, for instance, include the inappropriate use of air - for cooling (when a fan would be more suitable), or for cleaning (when other methods could be used).

## Process technology:

- · Is the correct type of compressor employed for the pressure and volume needed?
- · Does the installed set of compressors adequately meet the load?
- · Is the pressure drop in the piping excessive? If that is the case, it may indicate that the demand has expanded beyond what the network was originally designed to handle.
- · Is there an opportunity for heat recovery?

## Control systems:

- · Are the installed controls adequate?
- · Have the controls and energy performance for operation in unloaded mode been evaluated against a variable-speed drive (VSD) solution?
- · Would a variable inlet volume compressor meet the load more efficiently?

<!-- image -->

## Operation and maintenance:

- · Are leaks repaired in a timely way?

## Housekeeping:

- · Are lines and equipment switched off when they should be, e.g. at night or during breaks?
- · Are redundant pipe runs isolated?

A number of other checklist questions for common technologies are set out in Section 5 of this handbook.

The checklist should be formatted as a series of questions or points, and should include space for inserting data gathered and additional information such as machine details, hours of operation etc.

<!-- image -->

4. Conducting the Site Visit

## 4.1 Devise site visit agenda

## Prior to conducting the site visit, the auditor should devise a site visit agenda to ensure that a focused audit is carried out.

This should include the site visit opening meeting, a list of areas/ utilities to be visited, meetings with operations and maintenance teams and production personnel, and a closing meeting with all teams .

Depending on the scale of the audit, the agenda may span several days. Other aspects that may be considered include whether it is necessary to see the plant in operation and/or during downtime or at nighttime; any possible monitoring or measurement that may be needed; availability of people with operational knowledge and any other site activities.

<!-- image -->

## A sample site visit agenda can

be found in Appendix 4

## 4.2 Consider health and safety

It is essential to observe all site safety rules and permitto-work requirements while conducting on-site audit activities. A risk assessment or method statement will be required for certain installations prior to carrying out the energy audit. The audit team should be aware of any risks associated with the site activities and actively mitigate them; for example, personal protective equipment must be worn or permission to enter the site may be refused.

## 4.3 Carry out site visit

The site visit comprises a detailed walk-around of the area(s) to be audited, with a significant emphasis on the largest energy-consuming assets or SEUs. Typically, this involves reviewing energy and utility systems with the respective area supervisors and discussing the current operations, maintenance and control regimes of each energy-using piece of equipment. The discussions should cover various improvement categories, as shown in Table 5. Use a camera to record, for example, settings or condition of insulation, if allowed.

The audit checklist, developed as part of the planning stage, will be useful at this point. Note taking and record-keeping during the site survey are also crucial. This includes indicating personnel spoken to, the

<!-- image -->

systems that have been examined, the parameters observed, and assessing operational performance using metered data. Establishing positive relationships with key client personnel is important to enable the auditor to elicit useful information and possibly identify opportunities for energy efficiency improvements.

## Table 5: Sample improvement categories to be covered by the audit.

| Category                  | Examples                                                                                                                                                                                                                                                                            |
|---------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Behavioural: Housekeeping | Turning off equipment when not required, operating equipment for the minimum desired time for the minimum required set-points.                                                                                                                                                      |
| Technical: Maintenance    | Replacing filters as part of preventative maintenance programmes, re-instating insulation, leak remediation programmes.                                                                                                                                                             |
| Technical: Controls       | Reviewing control systems and optimising the control strategies for optimal energy performance. For example, on a dryer system, control on extract humidity rather than supply temperature; on ventilation systems, control on extract CO 2 levels rather than supply temperatures. |
| Capital                   | Infrastructural or equipment changes requiring capital investment. Typically, audits focus more on capital investments/improvements rather than no-cost or low-cost improvements (covered in the above three categories).                                                           |

## 4.3.1 Assess energy management

The assessment of the client organisation's overall approach to energy management should be carried out with senior management in order to determine what they could do to embed energy management principles further within the organisation structure. Specifically, the assessment should be used to determine current practice, and the progress and achievements made to date.

Table 6 provides a matrix to help an organisation assess its current status. It contains six columns, representing key aspects of energy management.  It contains five rows relevant to each level of maturity, from row 0 indicating that little or nothing is in progress up to row 4 showing advanced level of development. Organisations can be asked to consider each column in turn and tick the box that most represents their current situation. The client organisation may wish to adapt the wording within the boxes to reflect its own context more closely.

<!-- image -->

## Table 6: Energy management assessment matrix

<!-- image -->

|   Level | Energy Policy                                                                    | Organising                                                                                                               | Motivation                                                                                                          | Information Systems                                                                                                          | Marketing                                                                                                                      | Investment                                                                                                                               |
|---------|----------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|
|       4 | Energy policy, action plan and regular review have commitment of top management. | Energy management fully integrated into management structure. Clear delegation of responsibility for energy consumption. | Formal and informal channels of communication regularly exploited by energy manager and energy staff at all levels. | Comprehensive system sets targets, monitors consumption, identifies faults, quantifies savings and provides budget tracking. | Marketing the value of energy efficiency and the performance of energy management both within the organisation and outside it. | Positive discrimination in favour of'green'schemes, with detailed investment appraisal of all new-build and refurbishment opportunities. |
|       3 | Formal energy policy, but no active commitment from top management.              | Energy manager accountable to energy committee representing all users, chaired by a member of the managing board.        | Energy committee used as main channel together with direct contact with major users.                                | M&T reports for individual premises based on sub- metering, but savings not reported effectively to users.                   | Programme of staff awareness and regular publicity campaigns.                                                                  | Same payback criteria employed as for all other investment.                                                                              |
|       2 | Unadopted energy policy set by energy manager or senior departmental manager.    | Energy manager in post, reporting to ad hoc committee, but line management and authority are unclear.                    | Contact with major users through ad hoc committee chaired by senior departmental manager.                           | Monitoring and targeting reports based on supply meter data. Energy unit has ad hoc involvement in budget setting            | Some ad hoc staff awareness training.                                                                                          | Investment using short-term payback criteria onl y.                                                                                      |
|       1 | An unwritten set of guidelines                                                   | Energy management is the part-time responsibility of someone with limited authority or influence.                        | Informal contacts between engineer and a few users.                                                                 | Cost reporting based on invoice data. Engineer compiles reports for internal use within technical department.                | Informal contacts used to promote energy efficiency.                                                                           | Only low-cost measures taken.                                                                                                            |
|       0 | No explicit policy                                                               | No energy management or any formal delegation of responsibility for energy consumption                                   | No contact with users.                                                                                              | No information system. No accounting for energy consumption.                                                                 | No promotion of energy efficiency.                                                                                             | No investment in increasing energy efficiency in premises.                                                                               |

<!-- image -->

## 5. Technical Assessment

A number of technical areas must be considered when carrying out an energy audit. Depending on the organisation being audited, certain areas will require a technical assessment in order to identify opportunities for energy efficiency improvements

Areas that may require examination include, but are not limited to, the following:

- Buildings and building fabric such as glazing and insulation
- · · Lighting
- · Heating, controls and boilers
- · Heating ventilation and air conditioning (HVAC)
- · Pumps
- · Transport fleet, telematics
- · Refrigeration
- · Industrial processes
- · Wastewater treatment plants
- · Compressed air
- · Renewable energy.

Further information and guidance on auditing each of these areas are detailed overleaf.

<!-- image -->

## 5.1 Buildings

Buildings account for a significant amount of energy consumption. They offer a large opportunity for improved energy performance depending on their age, condition and design intent.

## 5.1.1 What to check

## 5.1.2 Typical opportunities

- · Broken or poorly maintained windows and doors
- · Poorly utilised space
- · Poor roof lights
- · Holes, leaks, draughts or dampness in the building fabric
- · Windows open during cold weather
- · Inadequate insulation
- · The complaints log for the building
- · Thermal bridging or hot spots (use a thermal imaging camera during a cold night)
- · Building equipment such as heating system, ventilation system, lighting system and IT systems for additional opportunities for energy efficiency improvements
- · The building performance against benchmarks, and understand why the building performance is different to the benchmark
- · Use of auxiliary electric heater
- · Staff comfort
- · Improving building air tightness to reduce heating requirement
- · Identifying over heating/cooling of areas
- · Reducing building activity when unoccupied for long periods
- · Reducing early building activation in the morning prior to occupancy
- · Reducing heating system activity during unoccupied periods
- · Improving temperature set-point protocols
- · Assessing the occupancy patterns of the building
- · Increasing the utilisation of the building (increasing density)
- · Adapting ventilation rates and adopting technologies used for ventilation
- · Better utilisation of the building management system.

<!-- image -->

## 5.1.3 Potential pitfalls

- · Loss of production due to the disruptive nature of some deep retrofits
- · Failure to provide maintenance and operations personnel with adequate training for deploying a sophisticated building management system.

## 5.1.4 Other resources

- · CIBSE - Guide F Energy efficiency in buildings

## 5.2 Lighting

Lighting is one of the most visible energy consumers in any building or facility, and developments in technology and effective controls may offer significant opportunities for energy efficiency improvements.

With regard to the control of lighting, the most important area to address is behaviour change, as no level of automation can outstrip the efficiency that can be achieved by manual switching when applied correctly.

## 5.2.1 What to check

- · Lighting on in unoccupied spaces
- · Excessive light levels for the tasks required in the space
- · Inaccessible light switches
- · Lighting types that do not facilitate switching off in infrequently used spaces (lighting with a long strike time)
- · Large areas controlled by one switch, or lighting wired directly to a meter control box (MCB) without a switch
- · Motion sensors with no manual override switch
- · Daylight linked controls and auto dimming
- · Occupancy sensors
- · Lighting fixtures located in suboptimal locations

(over enclosed machines or over a cabinet where only the top of the machine is illuminated)

- · External lighting on fixed time switch, manual control or photocell located in a shaded area
- · Unsuitable, dirty or discoloured diffusers and shades Obscured or dirty roof lights (daylight harvesting)
- · Reluctance of the occupants or management to turn off unnecessary lighting
- · Artificial lighting in areas with sufficient daylight (or blinds closed during the day)
- · Night-time lighting levels and switch off procedures
- · Lux levels appropriate for the activity in an area as outlined below

## 5.2.2 Typical opportunities

- · Checking lighting levels as stairwells, corridors and circulation areas are often over lit; there may be an opportunity to disconnect some fittings
- · Replacing high-intensity lighting with more energyefficient alternatives, e.g. replacing T8 with T5 or light-emitting diode (LED)

<!-- image -->

## · Table 7: Appropriate Lux levels

| Area                                  |   Recommended Illuminance (lux) |
|---------------------------------------|---------------------------------|
| Open plan office, mainly screen based |                             300 |
| Open plan office, mainly paper based  |                             500 |
| Meeting rooms and conference rooms    |                             300 |
| Break rooms and canteens              |                             200 |
| Plant rooms                           |                             200 |
| Corridors                             |                             100 |
| Workshops                             |                             300 |

## 5.2.2 Typical opportunities (contd.)

- · Relocating photocell to area of direct light
- · Installing additional switching so as to facilitate turning off some lights when not required
- · Running an awareness campaign to inform all employees of the importance of turning off lighting when the area is unoccupied
- · Installing lighting maps for switching banks
- · Installing automatic controls (timers, personal infrared sensors (PIRs), occupancy sensors and photocells), especially in infrequently used spaces
- · Cleaning skylights and windows
- · Introducing a practice of opening blinds to maximise the use of daylight
- · Cleaning reflectors and diffusers to maximise the efficiency of light fittings
- · Removing any unnecessary lighting and relocating fittings in poor locations (over cabinets or redundant machines or too close to walls).

## 5.2.3 Potential pitfalls

- · Installing PIRs with short duration, creating annoyance and hence resistance from occupants
- · Overly complex switching circuits
- · Over-reliance on automated lighting controls.

## 5.2.4 Other resources

- · The Society of Light and Lighting (SLL) - Lighting Handbook
- · CIBSE - Guide F Energy efficiency in buildings SEAI Lighting guides

<!-- image -->

## 5.3 Heating and boilers

Steam thermal oil and hot water boilers are energy conversion devices that convert the energy in fuels into a usable means of space and process heating for buildings and various processes.

It is essential to obtain a clear understanding of the energy service requirement in terms of both the temperature requirements of the thermal oil or hot water systems and the pressure requirements of steam systems.

## 5.3.1 What to check

- · Insulation conditions of the boiler, distribution systems' pipes, valves, flanges and fittings
- · Condition of any control dampers, three port valves
- · Boiler loads, to determine if there are multiple boilers operating on low loads resulting in dry cycling
- · Hot water flowing through standby boilers
- · Level of controls including, zoning, optimum stop start, weather compensation
- · Boilers operating out of hours
- · The 'as found' and 'as left' combustion efficiency of the boiler following the most recent maintenance report
- · The combustion efficiency of multiple units

(compare units and determine the cause of different efficiencies)

- · The system's thermal efficiency (calculate)
- · Electric heating in offices, e.g. portable heaters
- · On steam boilers, feed water volume, the boiler total dissolved solids (TDS) levels, condensate return rates, condensate return temperatures, and steam plumes from condensate receivers.

## 5.3.2 Typical opportunities

- · Insulating high temperature pipes, valves and flanges and minimising the temperature setting on the hot water boiler
- · Installing weather-compensating temperature controls
- · Installing flue gas isolation damper on standby boiler
- · Reviewing the sequence control of the boilers and associated waste heat recovery devices on the thermal system, e.g. heat recovery from process,

<!-- image -->

combined heat and power (CHP), solar collector, etc.

- · Installing two-way valves on the hot water distribution system and controlling the distribution pump using a variable-speed drive (VSD)
- · Isolating circulating pumps when not required
- · Ensuring that the condensing boiler operates on condensing mode
- · Checking the correct minimum blowdown rate and ensuring that the TDS levels are maintained in accordance with the boiler manufacturer's guidance
- · Considering installing de-stratification fans in spaces with high ceilings, thus reducing the space temperature
- · Addressing failed steam traps
- · Insulating uninsulated feed water tank
- · Replacing steam with high temperature hot water.

## 5.3.3 Potential pitfalls

- · Installed condensing boilers not operating in condensing modes
- · Turning off hot water systems for a period, which may result in corrosion and subsequent leakage in the distribution system
- · Long heat-up time for spaces when heating systems are operated intermittently.

## 5.3.4 Other resources

- · SEAI - Technical Guide: Boiler Controls
- · Carbon Trust - GPG 30 - Energy efficient operation of industrial boilers
- · CIBSE - Guide F Energy efficiency in buildings

<!-- image -->

## 5.4 Heating, ventilation and air conditioning (HVAC)

## HVAC accounts for significant energy consumption of both electricity and thermal fuel in a wide variety of buildings and also in industry.

Systems encompass heat generators such as boilers, chillers and distribution systems, including piped and ducted.

- · Passing valves

<!-- image -->

## 5.4.1 What to check

- · The temperature in the conditioned space (is it excessively high or low?)
- · Heating or cooling operating outside of required periods
- · Presence of draughts
- · Heating and cooling running simultaneously in areas, potentially serviced by different systems
- · Overly tight control of temperature or relative humidity
- · Use of supplementary heating, e.g. portable heaters
- · Damaged or blocked filters or fouled coils
- · Restricted airflows, e.g. at grilles
- · Use of fresh air or recirculation in accordance with intent of controls (this will depend on internal and external conditions and whether humidity is controlled)
- · Fans and dampers working correctly
- · Water supply and return temperatures for heating and cooling applications.

## 5.4.2 Typical opportunities

- · Matching variable speed control on fans, refrigerant compressors and circulation pumps to demand
- · Using 'free-cooling' during low ambient conditions
- · Reviewing HVAC operational controls
- · Adapting ventilation rate to occupancy through CO 2 controls
- · Heat recovery using run-around coils or air-to-air heat exchanger
- · Improving temperature and time controls
- · Enthalpy control
- · Rebalancing or recommissioning
- · Lowering air changes
- · Replacing steam heating with low pressure hot water system (LPHW).

<!-- image -->

## 5.4.3 Potential pitfalls

- · HVAC systems typically have to satisfy needs for a large number of occupants and these needs may vary significantly
- · Difficulty of making changes where conditions are regulated.

## 5.4.4 Other resources

- · SEAI - HVAC special working group reports and guides
- · SEAI - HVAC operational control checklist
- · SEAI - AHU operational control - spreadsheet training

## 5.5 Pumps

Pumps are one of the largest consumers of electricity and have widespread application in buildings, industrial processes and water and wastewater treatment.

## 5.5.1 What to check

## 5.5.2 Typical opportunities

- · The peak flow and head requirement and duration
- · The most common flow and head requirement and the duration it occurs
- · Design specification, commissioning sheets and maintenance records. There is often a mismatch in these, thus leading to opportunities for improvement.
- · Current requirements compared with what the pump was originally designed to handle
- · Feasibility of using an alternative pump
- · If a VSD is fitted, whether a speed adjustment could deliver better kWh per m3
- · Are any valves throttled?
- · Is the liquid velocity within the typical range?
- · Any parallel pumps with different commissioned values and/or running performance
- · Standby pump running as assist pump
- · Evidence of operational problems - cavitation, noise, overheating of fluid, leaking check valves, liquid hammer, suboptimal (e.g. emergency storm) pump running due to lack of repair to normal pump
- · Are any motors overheating, and/or unclean?
- · In many cases, installing a new pump would be justifiable - to reflect the actual operating conditions as opposed to the original design conditions
- · Matching of pump operation point for maximum efficiency to most common load
- · If the system has a VSD, determining the optimum speed
- · If the system has no VSD, considering installing a VSD
- · If there are duty/standby installations, considering upgrade of one pump only and running this one for most of the time, with the older pump as standby to improve the feasibility of the project.
- · Using two-port control and variable-speed pumps in place of three-port control
- · Changing piping to reduce velocities and pressure drops due to sharp bends, etc.
- · Isolating redundant pipe runs
- · Reducing overall flow and pressure in a system and using a small booster pump to supply loads with high pressure drop and small flow.

<!-- image -->

## 5.5.3 Potential pitfalls

- · Throttled valves do not always point to the need for speed control, particularly if there is a high static head. Therefore, the system should be considered as a whole before making any recommendations on this
- · Any capacity tests should be carefully coordinated with operating personnel, so as to avoid servicerelated issues
- · Complicated networks may require a full hydraulic model in order to determine optimal operating conditions.

## 5.5.4 Other resources

- · SEAI - Pump efficiency calculation tool
- · US DoE - Pumping system assessment tool

## 5.6 Transport

Transport energy saving opportunities typically break down into vehicle-related (i.e. purchase of more efficient vehicles or maintenance of current vehicles), driver behaviour and organisation planning and management.

## 5.6.1 What to check

- · Age and suitability of vehicles for tasks
- · Using correct tyre pressures - if pressure is 25% too low, rolling resistance increases by 10% and fuel consumption by 2%
- · Level of data available on fuel use, if available, carry out comparison of litres/ 100km based on class of vehicle
- · Route planning, is there potential to improve or to drive at night when road congestion is lower?
- · Maintenance regimes, tyre pressure and type of tyres
- · Aerodynamics, is there potential for improved aerodynamics for longer-trip vehicles?
- · Driver practices, is there potential for reduced idling time and driver practices?
- · Maintenance, state of insulation, seals and age of refrigerated units
- · Fuel leakage.

## 5.6.2 Typical opportunities

- · Using reduced rolling resistance tyres can lower fuel consumption by 3%
- · Driver training, potentially in tandem with monitoring of fuel usage - gives reduced idling time with savings of 5-10%
- · Reducing drag with measures such as covering open loads - using aerodynamic aids on larger vehicles can save 3-15%
- · Choosing correct vehicle for task, taking into account load, traffic, environment and route
- · Regularly removing unnecessary loads
- · Using GPS, telematics and fleet management systems
- · Matching truck size to load delivery requirements
- · Considering life cycle energy use cost as part of new vehicle purchase decision
- · Carrying out maintenance/upgrading of refrigerated units
- · Considering electric cars for the organisation's fleet.

<!-- image -->

## 5.6.3 Potential pitfalls

- · Potential improvements that are related to driver practices may need to be handled carefully during the energy audit
- · Good data for evaluation may be difficult to obtain unless fleet management and/or reliable odometer and fuel figures are available.

## 5.6.4 Other resources

- · SEAI - Transport energy efficiency guides
- · SEAI - Electric Vehicle Information

## 5.7 Refrigeration and cooling

The amount of energy used in a refrigeration system is largely determined by the overall temperature difference that must be overcome, i.e. the difference between condensing and evaporating temperature, and the size of the load that must be cooled.

## 5.6.1 What to check

- · Potential to use 'free cooling' for some or all of the time - perhaps with ambient temperatures
- · Is the capacity of the plant appropriate for the current load?
- · Does the plant operate at part load for a large portion of the time?

if the temperature difference is appropriate for the plant. Check the design conditions temperature difference. Typically, this is about 6-12°C for air coolers and 3-8°C for liquid coolers, but it is also quite application specific. A 1°C decrease in evaporating temperature typically increases running costs by between 2% and 4%

- · Potential to use an alternative mix of plant at part load - for example, fixed-speed screw for baseload and piston compressor for load trimming
- · Plant condensing temperature and cooling medium temperature (typically water or outdoor air). Check if the temperature difference is appropriate for the plant. Check the design conditions temperature difference - typically about 10°C for an evaporative condenser and 15°C for an air-cooled condenser. A 1°C increase in condensing temperature typically increases running costs by between 2% and 4%
- · Plant evaporating temperature and cooled medium temperature (often water-glycol or indoor air). Check
- · Temperature set-points. Are the set-points ideal for the intended application under all conditions?
- · Evidence of maintenance issues with the plant and/ or difficulties in achieving temperatures
- · Use of plant that will need to be replaced or become difficult to maintain, depending on refrigerant phase-out regulations
- · Insulation levels and condition including moisture ingress
- · Short-cycling of plant
- · High pressure drops in liquid circuits. Can indicate high flows and pump load which ultimately increases cooling load
- · Air leakage into cold spaces due to poor

<!-- image -->

housekeeping or maintenance

- · Fouling (or icing where relevant) of evaporators, condensers or heat exchangers.

## 5.7.2 Typical opportunities

- · Using free cooling where the process temperature required is higher than the ambient temperature
- · Reducing condensing temperature when ambient conditions are lower, e.g. at night or during the winter
- · Minimising auxiliary loads such as circulation pumps, depending on load requirements
- · Running more condenser fans to reduce condensing temperature even under warm conditions when the load is lower
- · Better load matching of available plant
- · Maximising cooled space or medium temperatures and evaporating temperatures
- · Reducing air leakage through use of a fast-acting door, air curtains, strip curtains, dedicated personnel doors

## 5.7.2 Typical opportunities (contd.)

- · Optimising defrost cycles
- · Optimising time controls for plant operation
- · Installing VSDs
- · Splitting plant to serve loads at different temperatures
- · Replacing equipment with more efficient plant - this leads to an opportunity for energy efficient design
- · Using a heat pump to provide cooling and then heating process water simultaneously.

## 5.7.3 Potential pitfalls

- · Minimum condenser temperature may be limited by needs for defrosting or oil cooling
- · Auxiliary loads such as pumps and fans may need to keep running to allow detection of load change by temperature sensors
- · Diverse loads and temperature requirements on a central system may mean that energy efficiency is compromised, as the lowest required temperature must be attained. This may be an opportunity for a dedicated smaller system to handle smaller loads at lower temperatures
- · Minimum condenser temperature may be limited by requirements for defrosting or oil cooling.

## 5.7.4 Other resources

- · SEAI - Refrigeration special working group reports and guides
- · Carbon Trust -  Refrigeration guides

<!-- image -->

## 5.8 Industrial processes

This section describes a common approach that can be applied to various industrial processes. Before starting work on an industrial process, the auditor should develop a flow diagram of the process. Once this has been completed, and assuming that the auditor has a sufficient understanding of the process, it should be possible to establish the steps in the process that are the main users of various types of energy.

## 5.8.1 What to check

- to the influence of their actions on energy use
- · Consistency in the product mix, recipe control etc.
- · Maintenance issues or challenges in achieving required quality that may result in higher energy demand
- · Parasitic loads, e.g. air leakage in ovens, furnaces or extract systems, excessive moisture in raw materials, inappropriate use of auxiliary services.

## 5.8.2 Typical opportunities

- · Improving quality control and overall equipment effectiveness (OEE) leading to improved energy efficiency
- · Improving operational control through better understanding of parameters critical for energy use in the process
- · Addressing bottlenecks in the process helping the rest of the process to improve efficiency
- · Changing process to remove energy-using steps,
- · Options to reduce the energy service need (load)
- · Opportunities to use a more efficient form of energy generation, e.g. gas burner in place of oil burners
- · Heat pump to recover energy from cooling loads
- · Options to reduce the level of energy use, e.g. lower process temperature in steel plant, lower pressure steam in dryer plant etc.
- · Potential for alternative, more efficient technologies
- · Options to improve the understanding of the consumption drivers or energy-relevant variables
- · Whether plant capacity is properly aligned or sized to throughput
- · Potential to make gains with improved production planning, e.g. run at full capacity and then stop for a period rather than running continuously at part load
- · High rework or reject rates indicating a requirement for control improvements
- · Level of operator knowledge of systems with regard
- e.g. using low temperature cure adhesive thus removing the need to use a curing oven
- · Improving insulation for heating and cooling processes
- · Optimising production runs or batch sizes for energy use.

<!-- image -->

## 5.8.3 Potential pitfalls

- · Complex processes require specialist understanding
- · Proprietary technologies may mean that early engagement with vendors is needed in order to deliver savings.

## 5.8.4 Other resources

- · BREF documents - Reference documents under the IPPC Directive and the IED
- · Carbon Trust - Sector specific publications

## 5.9 Wastewater treatment plants

Many large sites have wastewater treatment plants (WWTPs). Designs of these plants vary due to the range of effluent types and local effluent outflow requirements. Measures tend to focus on aeration, which typically accounts for between 40% and 50% of the WWTP energy use.

## 5.9.1 What to check

- · Maintenance regime and state of repair of plant and fittings, including sludge removal etc.
- · Design plant load and current plant load patterns
- · Proper control of dissolved oxygen (DO) level
- · Ingress of excessive hydraulic load, e.g. storm drain water
- · Load optimisation, e.g. use of less cleaning water or separation of unwanted waste streams where appropriate
- · Level of technology efficiency, e.g. fine bubble diffusers (blowers) in place of surface aeration
- · Appropriateness of plant size
- · Desired level of plant turn-down ratio for various typical load levels
- · Correct division of flow in the air distribution system
- · Difficulties in achieving plant outflow requirements
- · Significant variability in plant flow and load. Are DO sensors and other controls properly maintained and
- cleaned regularly so that they can be read correctly?
- · Opportunities for biogas generation and use.

## 5.9.2 Typical opportunities

- · Installing fine bubble diffusion technology
- · Effectively distributing air to meet load, e.g. concentrating at start of process where there is a higher demand
- · Improving process control including DO control
- · Controlling variable-speed blowers and aerators by DO
- · Using buffer storage tanks to smooth uneven flow from process
- · Using high-efficiency motors, blowers and pumps
- · Sizing pumps to achieve efficiency at typical common flow rates, as opposed to design maximum
- · When using centrifugal systems, allowing sludge to thicken in order to reduce dewatering costs
- · Generation of biogas to displace oil or natural gas in the fuel supply mix.

<!-- image -->

## 5.9.3 Potential pitfalls

- · Composition of inflow effluent may vary greatly, making optimisation difficult
- · Lack of standby plant may make modification difficult
- · Ineffective process control to achieve required emissions (potentially due to gaps in operator knowledge) may need to be addressed in order to affect energy savings.

## 5.9.4 Other resources

- · Efficiency Vermont - Reduce energy use at water and wastewater facilities.
- · Efficiency Vermont - Wastewater treatment facility energy checklist

## 5.10 Compressed air

Compressed air is one of the largest energy users in industry. Due to its ease of use, it is often used inappropriately.

## 5.10.1 What to check

## 5.10.2 Typical opportunities

- · Age of compressors and number of stages in each
- · Audible air leakage during site survey
- · Leak tags on the system for prolonged periods of time
- · System optimisation: Is it operating at the minimum acceptable pressure?
- · Pressure drops: does pressure drop across the air treatment plant?
- · Compressor air inlet temperature and is it installed in hot boiler room or plant room?
- · Means of work and alternatives (liquid agitation using air, compressed air for product transport etc.)
- · Compressor sequence control
- · Status of part-load operations for multiple compressor sites
- · Proper air isolation on equipment lines when not in use.
- · Repairing compressed air leaks
- · If excessive compressed air pressure required for one critical application, using a volumetric expander ('donkey') compressor
- · Ducting fresh air to the compressor air inlet from outside, ambient air temperature is typically between 5°C and 10°C colder than compressor room air
- · Recovering the waste heat from the air compressor to use for space heating or potentially pre-heating combustion air for a boiler
- · Installing a variable-speed air compressor instead of a fixed-speed air compressor for partial load operations
- · For new applications, installing waste heat recovery from the oil cooling system in an LPHW system
- · Isolating compressed air distribution systems during out of production hours (zone control solenoid valves)
- · Isolating dead legs
- · Doing a pump-up test at night time or when air using equipment is not in use
- · Replacing users that require high-volume, lowpressure air with air blowers.
- · Installing moisture-sensing drain traps instead of manual air receiver blowdown valves.

<!-- image -->

## 5.10.3 Potential pitfalls

- · Completing compressed air leak detection programmes but not fixing the leaks
- · Reducing the compressed air pressure without completing a whole system evaluation
- · Accepting that leaks are part of all compressed air systems and that air leaks are acceptable.

## 5.10.4 Other resources

- · SEAI - Compressed air technical guide.
- · SEAI - Compressed air savings calculator

## 5.11 Renewable energy

Renewable energy may be included in the scope of the energy audit. If included, it may assume more or less importance depending on the focus of the audit and the objectives of the client organisation management team.

For example, if the organisation's goal is carbon reduction, then renewable energy technologies will form a central element of the assessment of opportunities. However, if the organisation's goal is energy reduction, then low-cost or no-cost opportunities could be more important for the audit focus.

The energy efficiency first principle should always be applied to ensure that the energy requirement is minimised, before considering new sources of energy. Applying this principle will likely reduce the size of the renewable system required and, in turn, should probably reduce the investment cost.

Once an organisation decides that they wish to pursue a renewable energy option for heating or electricity supply, the challenge is to determine the appropriate renewable measure(s) for their business. In determining this, the auditor should be able to help the organisation:

- · Identify what is financially viable and what is most appropriate for the business
- · Decide on the financing mechanism, whether to develop their own project or use an ESCO model to fund the upgrade, and
- · Agree where to implement the renewable energy measure.

While one renewable measure may work well for one business, there is no guarantee that it will work well for another; careful evaluation and consideration are required before choosing any option. Any evaluation should also consider the measure that fits best with the organisation's brand, image and environmental or corporate social responsibility objectives.

<!-- image -->

For further information on renewable energy technologies, see SEAI Renewables.

<!-- image -->

<!-- image -->

## 6. Financial Analysis of Opportunities

Financial analysis of opportunities for energy efficiency improvements is a key step in the audit process. The level of financial analysis depends on the type of opportunity, the size of the investment and the level of risk associated with the various opportunities

## 6.1 Choice of financial analysis tool

## 6.1.3 Additional considerations

## 6.1.1 Small investments

In cases where savings are relatively small and the implementation cost is low, a detailed life cycle cost analysis is not warranted. A simple evaluation based on simple payback methodology may be adequate for decision-making purposes.

## 6.1.2 Larger investments

For larger investments, if only one solution is being put forward for evaluation and the payback is very short, there may be little added benefit in conducting a life cycle costing exercise. However, when operating costs are substantial, life cycle costing techniques can be useful in getting a more balanced view of the overall cost over the lifetime of the asset.  This might convince decision makers of longer term benefits and assist in securing financial appraisal.

Residual values can also be considered in the assessment. Care should be taken to complete a sensitivity analysis as small changes in the factors chosen (such as discount factor, operations and maintenance costs, or inflation for fuel or services) can radically change the outcomes, particularly over long analysis time periods.

## 6.2 Validated calculations

## 6.2.1 General approach

It should be possible for another party to check that the energy savings calculations are reasonable. This requires sufficient information on assumptions and methods used to be recorded. If, for example, design software is used, information on the inputs should be recorded. The basis for the savings estimated should be real and transparent.

<!-- image -->

## 6.2.2 Accuracy considerations

The calculations should be sufficiently robust to enable decision-making at a level appropriate to the scope of the audit. For example, an investment-grade audit, which focusses heavily on the return on investment and financial concerns involved with the potential energy efficiency improvements, requires more rigorous input data and calculations than a brief scoping audit that is intended to identify opportunities for further investigation. In other cases, if a clear magnitude of savings can be established with a 'rule of thumb' calculation, this could be used if a detailed calculation would not appreciably change the answer to a degree where a different outcome is likely. For example, changing the payback for a project from 3 years to 3.18 years by using a more detailed analysis would probably not warrant the extra effort. It is not generally expected that the output of an energy audit will be the basis for a design (unless that is specifically agreed in the scope). Rather, the audit results, on their own, may be sufficient

to enable decision-making for measures to be ranked for consideration and to be implemented. The level of calculations to be carried out and the robustness of approach to be adopted should be chosen with this in mind, and agreed at the time of commencement of the audit.

## 6.3 Financial analysis methods

A range of financial analysis tools can be employed at this stage, such as simple payback, net present value, internal rate of return and life cycle cost analysis.

For many of these tools, software applications are available online, which can save time when generating projections for the planned upgrade.

Simple payback is by far the most common financial analysis tool used in the energy-auditing arena, but this may not always be the most appropriate tool. For large projects a sensitivity analysis should be carried out to determine how the financial viability of a project would be affected by changes to assumptions made, such as operating hours, forecast activity levels, energy inflation. Interdependencies and dependant projects should also be discussed.

<!-- image -->

## A sample financial analysis tool can be found in Appendix 5

## 6.3.1 Simple payback

The simple payback period is the length of time required to recover the cost of an investment. The payback period is an important determinant of whether to undertake the project; typically, longer payback periods are not desirable. The payback period ignores the time value of money, unlike other methods of capital budgeting, such as net present value, internal rate of return, or discounted cash flow.

## Simple payback provides a good initial assessment of the viability of a project and is widely understood. For example:

Project investment cost:

€100,000

Projected savings per year:

€40,000

## Simple Payback:

| Investment   | €100,000   | 2.5 years   |
|--------------|------------|-------------|
| Savings      | €40,000    |             |

<!-- image -->

6. Financial Analysis of Opportunities

## 6.3.2 Net present value

Net present value (NPV) takes into account the time value of money. This refers to the view that money is worth more now than in the future, due to factors such as the cost of capital, uncertainty, etc. The analysis converts future cash flow values to current values which facilitates like-for-like comparison of projects.

## The following is a brief summary of present value calculations:

The value used to convert future value to present value is the discount rate r. If r = 0.10 or 10%, then we accept that the difference in value over a year is 10%. So...

<!-- formula-not-decoded -->

For example, if the projected savings are €40,000 per year, and that saving is realised at the end of the first year, then the current value, using a discount rate of 15%, is:

<!-- image -->

<!-- formula-not-decoded -->

Over the period of n years:

<!-- formula-not-decoded -->

(1+r) n

Therefore, if we have a saving of €40,000 in five years time, then the present value is:

<!-- formula-not-decoded -->

If we have a stream of savings or costs over a certain time period, then the NPV can be used to combine the present values of these figures. For example, if we make an investment of €100,000 and then have projected savings of €40,000 per year for five years, and if we use a discount rate of 15%, the figures would be as follows

## Calculation 1

|   Year | Cash Flow (€)   | Present Value (€)   | Net Present Value (€)   |
|--------|-----------------|---------------------|-------------------------|
|      0 | -100,000        | -100,000            | -100,000                |
|      1 | 40,000          | 34,783              | -65,217                 |
|      2 | 40,000          | 30,246              | -34,972                 |
|      3 | 40,000          | 26,301              | -8,671                  |
|      4 | 40,000          | 22,870              | 14,199                  |
|      5 | 40,000          | 19,887              | 34,086                  |

The investment is shown as a negative figure and the savings as a positive figure. Note that the NPV only becomes positive after more than three years. A negative NPV project should not be undertaken (from a financial viability viewpoint).

Discount rates vary depending on the organisation and on the types of projects undertaken by an organisation. Typically, the rates are set by the finance department and take into account the type of capital available, the cost of this capital, and the risk associated with a particular project. Therefore, they would normally be higher than the cost of borrowing. Rates may vary from 4-8% for infrastructure-type projects in the public sector up to 15-30% or higher for private sector projects. It can also be seen as the minimum rate of return that an organisation wishes to receive on an investment.

Net present value is an example of a discounted cash flow (DCF) method.

## 6.3.3 Internal rate of return

Internal rate of return (IRR) is a measure of the profitability of a project. It can be considered as

<!-- image -->

6. Financial Analysis of Opportunities the return that the investment would need to deliver if it were invested elsewhere. The IRR is the rate of return on a project that makes the NPV equal to zero. Therefore, for a project to be viable, the IRR must always be greater than the discount rate. It can be calculated by trial and error (or by using a spreadsheet function). In the above example, the IRR can be calculated at 28.6% so that the cash flow table becomes:

## Calculation 2

|   Year | Cash Flow (€)   | Present Value (€)   | Net Present Value (€)   |
|--------|-----------------|---------------------|-------------------------|
|      0 | -100,000        | -100,000            | -100,000                |
|      1 | 40,000          | 31,104              | -68,896                 |
|      2 | 40,000          | 24,187              | -44,709                 |
|      3 | 40,000          | 18,808              | -25,901                 |
|      4 | 40,000          | 14,625              | 11,276                  |
|      5 | 40,000          | 11,372              | 96                      |

In this case, the NPV is approximately zero (€96), based on the five-year lifetime of the project.

Internal rate of return is also an example of a discounted cash flow (DCF) method.

## 6.3.4 Life cycle costing

There are various approaches to life cycle costing (LCC) but, essentially, they combine investment and operating costs in order to get an indication of overall costs. The NPV approach can be used to compare future and current costs. The following example compares two projects. The first involves an investment of €100,000 and running costs of €65,000. The second involves costs of €125,000 and €55,000, respectively, both with a discount rate of 15%.

<!-- image -->

## Further guidance can also be found in the following publications:

- · SEAI - Investing in Energy: A Practical Guide to Preparing and Presenting Energy Investment Proposals
- · Carbon Trust - Making the business case for a carbon reduction project

## Calculation 3

|                     | Year   | Project 1     | Project 1         | Project 2     | Project 2         |
|---------------------|--------|---------------|-------------------|---------------|-------------------|
|                     |        | Cash Flow (€) | Present Value (€) | Cash Flow (€) | Present Value (€) |
| Investment (€)      | 0      | 100,000       | 100,000           | 125,000       | 125,000           |
| Running Cost (€)    | 1      | 65,000        | 56,522            | 55,000        | 47,826            |
| '                   | 2      | 65,000        | 49,149            | 55,000        | 41,588            |
| '                   | 3      | 65,000        | 42,739            | 55,000        | 36,163            |
| '                   | 4      | 65,000        | 37,164            | 55,000        | 31,446            |
| '                   | 5      | 65,000        | 32,316            | 55,000        | 27,345            |
| Life Cycle Cost (€) |        |               | 317,890           |               | 309,368           |

The NPV and IRR functions are included in spreadsheet software, which can help simplify their application. The effects of inflation can also be included in the calculations. Projects with different lifetimes and irregular costs, such as periodic reconditioning costs, can be assessed in the financial analysis.

<!-- image -->

## 7. Identifying &amp; Prioritising Opportunities

## 7.1 Identify opportunities for improvement

The purpose of carrying out an energy audit is to systematically identify opportunities for energy efficiency improvements. Opportunities may be identified at any stage during the planning and completion of the audit report, however, it is useful to record what the client organisation's significant energy users are as early in the process as possible. This helps to ensure that the opportunities identified are focused on those areas that will have the most substantial impact on energy use, carbon emissions, and cost. When the significant energy users have been identified, the drivers (or relevant variables) for energy use can also be identified.

## 7.2 Generate register of opportunities

When generating a register of opportunities, it is useful

- to look at various types of opportunities. These could be classified as behavioural, organisational and technical.
- Opportunities may be identified through analysis of the
- client organisation's energy bills and through regression analysis. For example, a building's heating may be

expected to be aligned with heating degree day (HDD) data. If it transpires that this is not the case, then there may be an opportunity for controls improvement.

Operations personnel, who are familiar with the operation of the relevant energy users on a day-to-day basis may be interviewed as part of the audit, with a view to establishing whether there are energy savings opportunities in relation to maintenance issues or problems with operating equipment.

## 7.2.1 Recommended information

## Recommended information to include in the register of opportunities is:

- · Reference number
- · Description of measure
- · Date noted
- · Calculated saving
- · Estimate of cost
- · Simple payback
- · Assumptions made
- · Fuel

<!-- image -->

## Additional information that could be included:

- · Area affected
- · Ease of implementation
- · Nature of change
- · Technical
- · Organisational
- · People/behaviour
- · CO 2 savings
- · SEU affected

## Figure 6: Register of opportunities sample

<!-- image -->

<!-- image -->

<!-- image -->

A sample of a register of opportunities can be found in Appendix 6

## 7.3 Methods to identify opportunities

Methods used in the audit to identify energy savings opportunities may include some, or all of the following:

- · Checking energy performance
- - against manufacturers performance specification handbook
- - against best practice data
- - against theoretical minimum energy needed
- - for periods of poor performance against periods of good performance
- - at part load
- - your own established at initial commissioning stage
- · Checking energy use during quiet periods, e.g. when the building is closed, at night-time and weekends, or low production times
- · Applying the Energy Venn diagram techniques described in Section 3.5
- · Reviewing methods to reduce loads
- · Reviewing maintenance issues
- · Reviewing controls behaviour
- · Reviewing feedback/input from maintenance and operations personnel
- · Reviewing energy savings opportunities identified by analysis of bills.

All identified opportunities should be included in the register, along with any sources and assumptions for calculations of savings and costs of implementation.

## 7.4 Prioritise opportunities

While decisions on implementation are the prerogative of the client, the auditor should provide some recommendations on implementation priorities. The energy savings opportunities should be divided into two prioritised categories: technically feasible recommendations and financially feasible recommendations. Such prioritisation can be based on the main reasons for carrying out the audit - for example, generating the largest possible CO  savings, 2 largest kWh of primary energy savings, shortest payback period, highest NPV, or highest IRR.

<!-- image -->

## Typically, the main considerations are the:

- · Scale of the savings
- · Cost of the measure
- · Ease of implementation
- · Interdependent nature of opportunities and their impact on savings.

<!-- image -->

## An indicative overview is provided in Appendix 5 and Appendix 6

## 7.5 Data retention

Data generated during the audit should be retained. Such data may be in either electronic or hard copy format, and it should be possible to retrieve the data subsequently in order to comply with any legislation, verify audit conclusions, facilitate further analysis, or track performance. A suitable retention period should be determined), at the audit planning stage, taking into account existing organisation data retention policies and procedures, legal obligations, etc.

<!-- image -->

## 8.1 Audit report

A key element of the energy audit is the compilation of a clear and concise report. It needs to convey the depth and breadth of the appraisal carried out, and it should clearly outline the opportunities for improvement.

It will be used by the organisation for a number of years as a reference for improvements that could be made. As a result, it should contain sufficient information on the background to the existing equipment and practices as well as clear descriptions of the opportunities for improvement, with associated energy saving calculations.

## As the main output from the audit, the audit report must be comprehensive and should include the following content:

## Executive summary

The executive summary should be a succinct summary of the energy audit and it should summarise the most important information resulting from the audit including:

- 1. Energy consumption and costs
- 2. Comparison of performance against known benchmarks/EnPIs
- 3. Most significant opportunities for improvement
- 4. Assessment of current energy management practices
- 5. Recommended next steps.
- 6. It should also convey the key messages and recommendations from the auditor in order to enable senior management to implement the report recommendations and improve the organisation's energy performance.

## Introduction

The introduction should give a brief outline of the scope of the audit, the activities covered by the energy audit, an overview of the client organisation and its day-today operations. It should also provide background information on the site to provide context for the report should it be reviewed by external audiences.

## Energy usage

This section should outline the energy consumption of the various sources, including macro consumption data. This should include monthly consumption and

8. Reporting the Results

<!-- image -->

load profiles of the energy sources, energy drivers for the energy sources and benchmarking of organisational performance or energy performance indicators.

In addition, all significant energy-using equipment should be identified in this section.

## Significant energy users (SEUs)

For each significant energy user, the following information should be provided:

- 1. Process descriptions
- 2. Description of current state and opportunities for improvement
- 3. Engineering calculations and financial calculations as appropriate.

## Recommendations

Based on information provided in the significant energy users section of the report, the opportunities for improvement should be assessed and prioritised in order to determine the most appropriate opportunities for improvement. This section of the report will recommend the most beneficial actions with financial assessments that the organisation could take.

## Metering requirements

Measurement and monitoring of energy users is a key output of the energy audit. This section of the report should document the current measurement systems in place and the recommended metering required in order to accurately measure the energy performance of the organisation through active energy management.

## Renewable energy technologies

Depending on the scope of the audit, renewable energy technologies may be included in the energy audit. If included, this section of the energy audit report should discuss the various renewable energy technologies assessed as part of the audit.

## Energy usage

This section should outline the energy consumption

## 8.2 Management presentation/ closing meeting

Senior management often find it difficult to allocate the time to engage with internal energy personnel on opportunities for improved energy performance. For this reason, the auditor should prepare a short presentation for the closing meeting on the key observations recorded during the course of the energy audit.

Areas to be covered in this presentation could include the following:

- · Energy consumption and costs
- · Benchmarking externally and internally
- · Opportunities for improvement identified including cost savings and simple paybacks
- · Recommended next steps.

This meeting provides a unique opportunity for an external expert to present to senior management and advise them on the implementation of the report recommendations. As such, it is important that the audit team ensures that all relevant senior management, the finance team and energy/ environment team personnel are in attendance.

<!-- image -->

## Appendices

## Appendix 1: Sample data request

The following is a sample data request and can be adapted based on the type of client organisation, the likelihood of obtaining the information and other practical considerations.

## Sample data request

In order to facilitate preliminary analysis and completion of your energy audit, please provide the following information:

- · Electricity bills for the past three calendar years include energy and cost information
- · Other fuel bills for the past three calendar years include energy and cost information
- · MRSO data for the past 12 months
- · GPRN data for the past 12 months
- · Access to online billing data
- · Access to in house energy monitoring data
- · Mandatory monitoring and reporting (M&amp;R) data
- · Large Industry Energy Network (LIEN) performance information, where this is relevant.
- · Process flow diagrams
- · Building layout drawings
- · Process and instrumentation drawings (P&amp;IDs) for large energy users
- · Site plans
- · Asset or equipment lists for main energy-using equipment
- · Activity metrics data (such as production output, occupancy, weather data) - data for variables that may drive energy use
- · Historical energy performance information
- · Copies of any previous energy audits
- · Details of known opportunities for energy efficiency improvements or existing register of opportunities
- · Historical energy management programmes or initiatives
- · Details of personnel who have energy-related roles or responsibilities
- · Details of upcoming organisational changes or expansion plans that are expected to affect energy use
- · Previous energy audits.

## Appendix 2: Best practice and technology resources

## A key element of energy audit preparation is to research current energy management best practice in the sector in which the organisation operates.

For example, if auditing a local authority, it is imperative to be aware of the latest technologies in buildings, water pumping, wastewater treatment and public lighting. Similarly, if auditing a milk processing plant, it is important to be knowledgeable about current energy management best practice in the dairy industry. There are numerous guides, standards and best available technology (BAT) and BREF documents available for each sector, and these should be consulted in advance of the audit.

The following is a list of useful references, including but not limited to:

## 1. SEAI - Special working group outputs, BAT documents

These cover best practice in HVAC, compressed air, refrigeration, food and dairy sector, data centre sector and large commercial buildings.

## 2. SEAI - Technology assessment tools

These tools have been developed to help achieve best in class efficiency in various technologies.

## 3. SEAI - Public Sector Programme best practice guidance documents

These guides cover a range of energy uses common in the public sector including water services, ICT and public lighting.

## 4. BREF Documents

Reference documents under the IPPC Directive and the IED

## 5. US Energy Star Programme tools and resources

This link provides reference information on a wide range of industries and products.

## 6. CIBSE - Guide F: Energy Efficiency in Buildings

Guidance on energy efficiency in design and operation of building services including a chapter on energy audits and surveys.

## 7. SEAI - Building Energy Manager's Resource Guide

Comprehensive guide to energy use in buildings (currently under review).

## 8. Carbon Trust - Sector specific guides

A wide range of guides on specific sectors and technologies.

## 9. Reduced energy consumption in plastics engineering (RECIPE)

European best practice guide for the plastics processing industry.

## 10. US Office of Energy Efficiency and Renewable Energy

A range of projects, analyses, protocols, and strategies to reduce industrial energy intensity and carbon emissions in specific industries and technology areas.

## 11. Energy Star

An international standard for energy efficient consumer products originating in the United States.

## Appendix 3: Sample bills analysis tool

## Energy Bill Tracker Tool

Download: http://www.seai.ie/EnergyMap/Resources\_tools/Template\_Energy\_Use\_Cost\_Savings\_/Energy\_Bill\_Tracker\_Tool/Energy\_Bill\_tracker\_Tool.html

## ESB Tariff Analysis Tool

Download: http://www.seai.ie/EnergyMap/Resources\_tools/Template\_Energy\_Use\_Cost\_Savings\_/ESB\_Tariff\_Analysis/ESB\_Tariff\_Analysis.html

<!-- image -->

## Appendix 4: Sample site visit agenda

An agenda is a useful way to help the client organisation with planning around the audit process. It also helps to ensure delivery of an organised and focused audit. The example below shows the level of detail that should be provided to ensure that the client has a clear understanding of what the audit team's visit will entail.

## Sample energy audit site visit timetable:

| Time   | Activity                                                                                                                                                                              |                                                                                                                                                                                                 |
|--------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 8:30   | Auditor arrives and is introduced to relevant client organisation representatives.                                                                                                    | • Observe main activities on the site focusing on energy use and including processes and utilities. • Discuss energy use with personnel who are responsible for process operations on the site. |
| 9:00   | Site visit opening meeting: The main site contact person, as well as other relevant personnel who will have some involvement in the audit, should attend part or all of this meeting. | Audit team examines on-site energy monitoring system. Closing meeting: The main site contact person and relevant personnel should attend.                                                       |
| 11:00  | Tour site and inspect main process: All relevant personnel who will have some involvement in the audit should take part in this site tour.                                            | • Plan schedule for subsequent days or non-operational periods (e.g. night-time or weekends).                                                                                                   |

## Appendix 5: Sample financial analysis tool

<!-- image -->

## Financial Analysis Tool

## Energy Management System Tools

Instructions: Only complete the Green Cells as other cells have formula built into them Add or delete years depending on the project analysis then modify blue output cells

This financial analysis tool is a simple tool developed to complete financial analysis calculations for the purpose of informed decision making in the area of energy management systems and project selection. The examples below are for the comparison of two alternative pieces of equipment with different capital costs, different operating costs and different energy saving potentials. The analysis is completed over a 10 year period for the purposes of NPV and LCC calculations. This tool can be further developed to incorporate maintenance into the NPV and LCC cashflows and for large complex projects sensitivity analysis should be completed

|                     | Project Option 1   | Project Option 2   | Notes                                                                            |
|---------------------|--------------------|--------------------|----------------------------------------------------------------------------------|
| Project Investment  | €55,000            | €69,000            | Insert the two alternative i nvestment costs here                                |
| Operating Cost      | €91,055            | €67,226            |                                                                                  |
| Annual Savings      | €15,000            | €19,282            | Calculate the energy savings of the two projects here against                    |
| Annual Energy Costs | €16,362            | €12,080            | the base case Calculate operating cost of the two alternative projects here      |
| Discount Rate       | 15%                | 15%                | Contact your finance department to obtain organisations                          |
| Energy Inflation    | 3%                 | 3%                 | In SPB analysis the l owest number here i s the correct project discount rate    |
| Simple Payback      | 3.67               | 3.58               | In SPB analysis the l owest number here i s the correct project to select        |
| NPV                 | €28,476            | €38,305            | to select For NPV the highest NPV value i s the correct project to select        |
| IRR                 | 26.9%              | 27.7%              | For IRR the highest IRR i s the correct project to select (must be               |
| LCC                 | -€146,055          | -€136,226          | < discount rate) For LCC the l owest LCC value i s the correct project to select |

LCC ANALYSIS OF PROJECT ALTERNATIVES

€160,000

€140,000

€120,000

€40,000

Annual Savings

Annual Energy Costs

Discount Rate

Energy Inflation

Simple Payback

NPV

IRR

LCC

€15,000

€16,362

15%

3%

3.67

€28,476

26.9%

€19,282

Calculate the energy savings of the two  projects here against

€12,080

the base case

Calculate operating cost of the two alternative projects here

15% Contact your finance department to obtain organisations discount rate

3% In SPB analysis the lowest number here is the correct project

3.58

In SPB analysis the lowest number here is the correct project to select

€38,305

to select

For NPV the highest NPV value is the correct project to select

27.7% For IRR the highest IRR is the correct project to select (must be

-€146,055

-€136,226

&lt; discount rate)

For LCC the lowest LCC value is the correct project to select

## LCC ANALYSIS OF PROJECT ALTERNATIVES

<!-- image -->

AXIS TITLE

| Table 1 NPV Cashflow Calculator   | Table 1 NPV Cashflow Calculator   | Table 1 NPV Cashflow Calculator   | Table 2 LCC Cashflow Calculator   | Table 2 LCC Cashflow Calculator   | Table 2 LCC Cashflow Calculator   |
|-----------------------------------|-----------------------------------|-----------------------------------|-----------------------------------|-----------------------------------|-----------------------------------|
|                                   | Project Option 1                  | Project Option 2                  |                                   | Project Option 1                  | Project Option 2                  |
| Year 0                            | -€55,000                          | -€69,000                          | Cost                              | -€55,000                          | -€69,000                          |
| Year 1                            | €15,000                           | €19,282                           | Year 1                            | -€16,362                          | -€12,080                          |
| Year 2                            | €15,450                           | €19,860                           | Year 2                            | -€16,853                          | -€12,442                          |
| Year 3                            | €15,914                           | €20,456                           | Year 3                            | -€17,358                          | -€12,816                          |
| Year 4                            | €16,391                           | €21,070                           | Year 4                            | -€17,879                          | -€13,200                          |
| Year 5                            | €16,883                           | €21,702                           | Year 5                            | -€18,416                          | -€13,596                          |
| Year 6                            | €17,389                           | €22,353                           | Year 6                            | -€18,968                          | -€14,004                          |
| Year 7                            | €17,911                           | €23,024                           | Year 7                            | -€19,537                          | -€14,424                          |
| Year 8                            | €18,448                           | €23,714                           | Year 8                            | -€20,123                          | -€14,857                          |
| Year 9                            | €19,002                           | €24,426                           | Year 9                            | -€20,727                          | -€15,303                          |
| Year 10                           | €19,572                           | €25,159                           | Year 10                           | -€21,349                          | -€15,762                          |

## Appendix 6: Sample register of opportunities

## Register of Opportunities Tool

Download: http://www.seai.ie/Your\_Business/Resources/Technology\_Assessment\_Tools/

## Register	of	Opportunities

## EXAMPLE

<!-- image -->

|                                                                                                                                                                              |                     | Estimated Annual Savings   | Estimated Annual Savings   | Estimated Annual Savings   | Estimated Annual Savings   |                   |                                           |                                                                                                           |              |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------|----------------------------|----------------------------|----------------------------|----------------------------|-------------------|-------------------------------------------|-----------------------------------------------------------------------------------------------------------|--------------|
| Ref                                                                                                                                                                          | Opportunity         | Fuel Type                  | [kWh]                      | [€]                        | [kgCO2]                    | Category          | Electrical / Thermal / Fleet] Responsible | Additional Information / Comments                                                                         | Date Entered |
| 001 Replace dichrolic spots with 4 watt LED spot lamps in Rooms XYZ                                                                                                          | Electricity         | 9,042                      | €1,356                     | 4,692.8                    | Technical                  | Electrical        | Jim B                                     |                                                                                                           | 24-Oct-11    |
| 002 Insulate all hot water pipe work, valves and flanges in boiler room and laundry area                                                                                     | Natural Gas         | 7,905                      | €474                       | 1,936.7                    |                            | Technical Thermal | Jim B                                     |                                                                                                           | 24-Oct-11    |
| 003 Building ABC: Change T8 fluorescent light fittings to T5s, install presence detectors in enclosed spaces and include daylight detectors where natural light is available | Electricity         | 6,605                      | €991                       | 3,428.0                    | Technical                  | Electrical        | Jim B                                     |                                                                                                           | 24-Oct-11    |
| 004 Set extraction fan in kitchen to minimum                                                                                                                                 | setting Electricity | 2,097                      | €315                       | 1,088.3                    | People                     | Electrical        | Liam S                                    | Lowest is adequate for normal cooking activity - include as part of awareness campaign                    | 24-Oct-11    |
| 005 Install timer on hot water boiler                                                                                                                                        | Electricity         | 1,048                      | €157                       | 543.9                      | Technical                  | Electrical        | Dermot R                                  | 24-Oct-11                                                                                                 |              |
| 006 Maintain correct tyre pressures (weekly check)                                                                                                                           | Transport Fuels     |                            |                            |                            | People                     | Fleet             | Sean W                                    | Probably 3% savings across all vehicles                                                                   | 24-Oct-11    |
| 007 Adjust aerodynamic aids to reduce parasitic drag                                                                                                                         | Transport Fuels     |                            |                            |                            | Technical                  | Fleet             | Dermot R                                  | At 100 km/h, air resistance accounts for 60-70% of fuel usage. >= 10% savings for HGVs at cruising speeds | 24-Oct-11    |
| 008 Slow down (adhere to speed limits) and use cruise control where appropriate                                                                                              | Transport Fuels     | 183,000                    | €23,790                    | 48,312.0                   | People                     | Fleet             | Dermot R                                  |                                                                                                           | 24-Oct-11    |
| 009 Switch off fan in Clean Room 1 when Room not in use                                                                                                                      | Electricity         | 46,242                     | €6,187                     | 23,999.6                   | People                     | Electrical        | Liam T / Pat D                            | 1-Nov-11                                                                                                  |              |
| 010 Turn off AHU 1 at weekends (6pm Fri - 6am Mon)                                                                                                                           | Electricity         | 126,720                    | €16,955                    | 65,767.7                   | People                     | Electrical        | Liam T                                    |                                                                                                           | 1-Nov-11     |
| 011 Tender electricity supply                                                                                                                                                | Electricity         |                            | €40,000                    |                            | Organisational             | Electrical        | Pat D                                     |                                                                                                           | 1-Nov-11     |
| 012 Install Power Factor correction unit                                                                                                                                     | Electricity         |                            | €23,000                    |                            | Technical                  | Electrical        | Jim B                                     | 1-Nov-11                                                                                                  |              |
| 013 Replace VSD on Condensor Tower No.1 Motor                                                                                                                                | Electricity         | 33,600                     | €4,496                     | 17,438.4                   | Technical                  | Electrical        | Jim B                                     | 1-Nov-11                                                                                                  |              |

014

Procure	&amp;	install	replacement	York	Chiller

Electricity

137,466

€18,393

71,344.9

Technical

Electrical

Tony	C

1-Nov-11

015

Investigate	options	to	replace	Mould	Machine	No.	2	with	electric machine

Oil

€25,000

Technical

Combination

Tony	C

1-Nov-11

## Terms and definitions

## Energy audit

' A systematic procedure with the purpose of obtaining adequate knowledge of the existing energy consumption profile of a building or group of buildings, an industrial or commercial operation or installation or a private or public service, identifying and quantifying costeffective energy savings opportunities, and reporting the findings' . Source: Energy Efficiency Directive 2012/27/EU Article 1 (25).

## Energy consumption

Quantity of energy applied. Source: IS ISO 50001:2011, (3.7).

## Energy performance

Measurable results related to energy efficiency, energy use and energy consumption (3.6).

Note 1 to entry: In the context of energy management systems, results can be measured against the organisation's energy policy, objectives, targets and other energy performance requirements.

Note 2 to entry: Energy performance is one component of the performance of the energy management system.

Source:

EN ISO 50001:2011, Section 3.12.

## Energy performance indicator

Quantitative value or measure of energy performance, as defined by the organisation.

Note 1 to entry: Could be expressed as a simple metric, ratio or a more complex model.

Source:

EN ISO 50001:2011, Section 3.13.

## Energy audit scope

Extent of energy uses and related activities to be included in the energy audit as defined by the organisation in consultation with the energy auditor, which can include several boundaries.

Example: Organisation, facility/facilities, equipment, system(s) and process (es). The energy audit scope can include energy related to transport.

Source: ISO 50002: 2014 Energy audits - requirements with guidance for use, section 3.4.

## Significant energy use

Energy use accounting for substantial energy consumption and/or offering considerable potential for energy performance improvement.

Source:

EN ISO 50001:2011, Section 3.27.

<!-- image -->

e

w www.seai.ie

<!-- image -->