---
document_id: seai_energy_management_smes
title: "Energy Management Guide for Small and Medium Enterprises (SMEs)"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2020
original_file: "seai_energy_management_guide_for_smes.pdf"
tables_detected: 14
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Management

A Guide for Small Business

II

Over the coming years, Ireland must use less energy, move to clean energy, and innovate to create new solutions to meet our energy needs. There is significant potential for businesses to influence and participate in Ireland's sustainable energy future. Energy efficiency can help you save money and make you more resilient to rising energy costs.

Businesses could save 10% off their energy bills through implementing relatively low or no-cost energy efficiency measures. You will also reduce your carbon footprint. Customers are embracing green business, and it is increasingly important to show that you are taking genuine steps to improve the sustainability of your business.

## How to use this energy management pack

This guide is designed to help you, as an owner or manager of a small business, to improve your energy management practices. It takes you through each of the steps to save energy.

Any business, large or small, can improve its energy performance by following a few simple techniques and steps. The effort required will vary from company to company, as will the degree of success. A company that is starting an energy management programme can make significant achievements by good housekeeping measures alone. By putting a programme in place, like the one outlined in this guide, you will reduce costs and improve profits.

The accompanying workbook provides space for you to fill in details specific to your organisation and allows you to keep track of your progress. The guide and workbook are also supplemented by a completed sample workbook, which will serve as a reference as you make your way through the process. Together the guide, workbook and completed sample workbook can be used as your energy management file.

<!-- image -->

| Steps          |                                                                |           |
|----------------|----------------------------------------------------------------|-----------|
| 1. PREPARATION | • Assess the current energy management situation               | ACTION 1  |
|                | • Assess the business case for energy management               | ACTION 2  |
|                | • Identify the issues driving your energy management programme | ACTION 3  |
| 2. COMMIT      | • Assign an energy coordinator                                 | ACTION 4  |
|                | • Write an energy statement                                    | ACTION 5  |
| 3.             |                                                                |           |
| IDENTIFY       | • Document your energy bills                                   | ACTION 6  |
|                | • Take meter readings                                          | ACTION 7  |
|                | • Identify energy users and influencers                        | ACTION 8  |
|                | • Compile a register of opportunities                          | ACTION 9  |
| 4. PLAN        | • Complete an energy action plan                               | ACTION 10 |
| 5. ACT         | • Establish an operations and maintenance checklist            | ACTION 11 |
|                | • Get your staff involved                                      | ACTION 12 |
|                | • Facilitate training                                          | ACTION 13 |
| 6. REVIEW      | • Compare your performance                                     | ACTION 14 |
|                | • Complete a review checklist                                  | ACTION 15 |
|                | • Make recommendations for future programmes                   | ACTION 16 |

1

## Step 1 - Preparation

## Understanding energy management

The phrase 'you can't manage what you can't measure'  is particularly appropriate for managing your energy. Good energy management starts with understanding where you use energy and how much you use. By understanding this you can significantly reduce how much you use and very importantly reduce your energy bills.

<!-- image -->

## What is your current energy management situation?

Your first step is to assess your current energy management situation.

Fill out the energy management diagnostic questionnaire in the workbook to help you assess this. Use the example in the completed sample workbook to help you.

<!-- image -->

## The business case for energy management

Did you know that by decreasing energy use by 10% you can have a significant impact on your profit? Table 1, below, shows how much a business can pay for energy and how a decrease of just 10% in energy usage can have a significant impact on profits. Looking at energy from a financial point of view will also help you to determine what resources can be allocated to this programme.

## Table 1 - The business case for energy management

## FINANCIAL INDICATORS

| Company operating costs (€/yr)                                            | €315,000   |
|---------------------------------------------------------------------------|------------|
| Company energy costs (€/yr)                                               | €10,579    |
| Energy costs as %of total costs                                           | 3.36%      |
| Annual profits (€)                                                        | €28,900    |
| Energy as a %of profits                                                   | 37%        |
| Increase in profits to be realised by decreasing energy costs by just 10% | 4%         |

Another way to look at this is that for every €1 saved on energy costs, most businesses would have to make €10 worth of sales to make the same €1 of profit. So, for example, wasting €1,000 a year on energy due to poor energy management would require €10,000 worth of sales to make the equivalent €1,000 of profit.

Think of the other drivers you may have for implementing an energy management programme. Examples include:

- · Pressure from suppliers;
- · Environmental concerns;
- · Audits from corporate clients;
- · Questions from staff and clients.

## ACTION 2

## What is your business case for energy management?

Fill out your own business case table in the workbook and estimate what resources and effort you can afford to spend tackling your energy management.

## ACTION 3

In the workbook, list the issues that are driving your energy management programme.

<!-- image -->

<!-- image -->

## Step 2 - Commit

## Key goals:

- · As a manager make your own commitment to the energy management programme;
- · Elect a member of staff as energy coordinator;
- · Create an effective, manageable energy statement.

Full commitment to energy management is vital for success. This may mean making a commitment to energy management in terms of both time and money.

## Energy coordinator

Depending on the size of your business, you may decide to appoint a staff member as an energy coordinator.

Your energy coordinator will manage energy in your business and should be able to make key decisions. These responsibilities and tasks should be added to their job description.

The energy coordinator should be enthusiastic, able to communicate well with co-workers and be available to dedicate the time to establish an effective programme.

This energy coordinator should have an interest in energy management and some knowledge of it.

Examples of staff members who could take on the role of energy coordinator are facilities managers, store managers, office managers, etc. You will need to look carefully within your own business to assess who is the most suitable candidate.

## Role of the energy coordinator

- · Assess current energy use in the company;
- · Identify areas where savings can be made;
- · Draw up plan of action for energy savings;
- · Coordinate the implementation of the energy plan;
- · Communicate plan with other staff members;
- · Monitor energy usage on an ongoing basis;
- · Monitor and evaluate staff behaviour with respect to energy usage;
- · Report on the energy management programme;
- · Coordinate awareness-raising activities for staff.

It is essential that the energy coordinator receives some help with these tasks, so ensure that others are also involved and that tasks are not left to one person.

<!-- image -->

## ACTION 4

Assign an energy coordinator for your business. Document this in the workbook.

6

## Energy statement

The next step is to draft a formal energy statement to make your commitment clear to staff at all levels and to explain to them how they will be involved.

An energy statement details your commitment to dealing with energy issues, efficiency and the need to increase awareness amongst staff of the benefits of being energy efficient.

## It should briefly outline:

- · Your overall objectives with respect to energy management;
- · Your targets and expectations;
- · How you hope to achieve them.

An energy statement should be very simple and should compliment with your existing company policies.

## Energy Statement

X Ltd. is dedicated to implementing energy efficient practices, recognising that this is essential to our continued business success.

We are committed to the following:

- · Continual improvement in reducing our energy usage;
- · Compliance with all environmental and other appropriate legislation;
- · Minimising the impact that our energy use has on the environment;
- · Communication of our energy statement and energy programme to all staff;
- · Ensuring suppliers and contractors are aware of our energy programme.

Michelle King

Manager

## The energy statement is complied with in practice by:

- · Setting objectives and targets and reviewing these annually;
- · Addressing signicant energy usage areas;
- · Making sure that energy consumption is visible to all employees and demonstrating how they can influence energy consumption, without any reduction in performance or working conditions;
- · Motivating and encouraging employees to make suggestions that may contribute to reducing energy consumption.

By implementing the following steps of this programme, you will be putting the commitments in your energy statement into practice.

At this stage if you are not taking on the role of energy coordinator, you should hand over this process to the person you are appointing as energy coordinator.

<!-- image -->

## ACTION 5

In the workbook, write an energy statement for your business.

## Step 3 - Identify

## Key goals:

- · Study your energy bill and understand your tariffs and costs;
- · Learn where and when you use the most energy and identify the main energy users;
- · Identify possible energy and cost savings.

Your energy bills, including electricity, natural gas, Liquid Petroleum Gas (LPG), heating oil, wood, etc., are the quickest and easiest way of determining your energy use. In order to better understand your energy consumption and annual usage trends, it is a good idea to keep track of your bills and collect as much information as possible from them. Many energy suppliers will do this for you and also provide information on your energy usage and demand consumption patterns. Most of this information is available through your online account, so make sure you are set up. They will tell you your average energy spend per year, trends in usage (including peaks and lows) and will highlight seasonal variations in energy use.

## Things to look out for when you get your bill

- · How many night units are you using?
- · Are there any unusual trends in your energy usage? (You will be able to identify this through Action 6, below.)
- · Is there something unusual about a bill that cannot be explained, e.g. high gas use during summertime?
- · Do you have penalties or charges on your bill?
- · Can you reduce the amount of excess wattless units for which you are being charged? Talk to your supplier about your options.

Appendix 1 (page 19) lists explanations of key terms that may appear on your bill.

## ACTION 6

Gather your previous year's energy bills and fill these into your workbook.

As you implement your energy management programme, from now on fill in your bills as you receive them. File these bills or copies in your energy management folder.

7

## Suppliers and tariffs

Significant savings can be made by ensuring you are on the right tariff.

First thing you need to do is check that the Maximum Import Capacity (MIC) on your bill is accurate. You should be on a general purpose tariff if your MIC is 50kVA or less. However, if you use 10% or more of your electricity at night, you should avail of the general purpose night saver tariff. If your MIC is greater than 50kVA, you should contact your supplier to discuss your options.

Check your tariff regularly to ensure you are on the right one - your energy demands may change over time. In addition,  tariffs are continually being revised and changed by the energy suppliers.

Talk to your supplier(s) about your tariff or check their website for up-to-date information.

Check the Commission for Regulation of Utilities (CRU) website (www.cru.ie) for more details on energy suppliers.

## Recording your own energy consumption

Many energy bills are estimates rather than readings. You should take your own readings from your meter. If you have one of the older meters, this is the only accurate method of recording your energy consumption. You should also submit these readings to your energy supplier so that you are charged accurately. The first thing to do is to locate your meter. You may need to contact your building maintenance company if you are renting.

<!-- image -->

<!-- image -->

Take meter readings for electricity and gas at regular intervals, e.g. once a month, and record them in the workbook.

## Identifying energy users and opportunities

By looking at your energy usage and costs you will be able to identify the areas where you can make savings, while also establishing a baseline against which to measure your future energy demands.

Try to identify:

- · Your main energy-using equipment;
- · What factors influence energy use e.g. production, weather, shutdown periods, health and safety, etc.;
- · The key people who influence energy use and how you will involve them in reducing use;
- · If you are using excessive energy at night, over the weekend or on public holidays;
- · If your summer energy use is in line with expectations;
- · In cases where production volumes or other activity indicators apply, the relationship between these indicators and energy.

<!-- image -->

## ACTION 8

Fill out the energy users and influences table in the workbook identifying energy-using equipment, influential factors and people and if there is a potential energy saving to be made. Use the example in the completed sample workbook to help you.

## Table 2 - Typical energy usage areas

| SECTOR                  | ENERGY USAGE AREAS                                                                                                                                                             |                                                                                                                                                    |
|-------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| Retail                  | • Space heating • Water heating • Air-conditioning system • Air curtains • Mechanical ventilation • Background lighting                                                        | • Display lighting • Signage • Cold storage or cold rooms • Refrigeration systems • Display refrigeration units • Waste compactors                 |
| Hotels                  | • Leisure centres or swimming pool • Space heating • Water heating • Air-conditioning system • Mechanical ventilation • Kitchen or catering or canteen                         | • Cold stores and cold rooms • Laundry services • Lifts • Background lighting • Display lighting • Waste compactor                                 |
| Manufacturing           | • Compressed air units • Electric motors, drives, tools • Cooling systems • Heat recovery units • Fans • Boilers or burners • Air-conditioning system • Mechanical ventilation | • Space heating • Water heating • Production machinery • Pumping systems • Control systems • Background lighting • Task lighting • Waste compactor |
| Office                  | • Space heating • Water Heating • Air-conditioning • Mechanical • Background                                                                                                   | • IT servers • IT equipment • Lifts                                                                                                                |
| Sports and              | • Task lighting • Swimming pools • Facilities e.g. sauna or steam rooms • Pumps                                                                                                | • Kitchen or catering or canteen • Vending machines                                                                                                |
| recreational facilities | • Space heating • Water heating                                                                                                                                                | • Mechanical ventilation • Background lighting • Display lighting • High bay lighting • Vending machines                                           |

Identifying energy users and opportunities is important and can sometimes be a little complicated. Do not be afraid to look for some technical assistance to complete this step, if necessary.

## ACTION 9

## Register of opportunities

The energy users and influences table will give you lots of energy-saving ideas. You should record all these as a register of opportunities. You may not end up carrying out all these actions. The next step will help you prioritise and plan what actions you do take.

Start to fill out your register of opportunities in the workbook.

Some common opportunities are outlined overleaf in Table 3 and in the completed sample workbook.

## Table 3 - Areas where potential energy-saving opportunities can be achieved

| AREA             | POTENTIAL ENERGY-SAVING OPPORTUNITIES   | POTENTIAL ENERGY-SAVING OPPORTUNITIES                                                                                                 | COST                   |
|------------------|-----------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|------------------------|
| Lighting         | •                                       | Balance artificial with natural lighting levels                                                                                       | No cost                |
|                  | •                                       | Ensure people know where lighting controls are located                                                                                | No cost                |
|                  | •                                       | Ensure that unoccupied areas are not lit unnecessarily                                                                                | No cost                |
|                  | •                                       | Place labels on light switches and controls                                                                                           | No cost                |
|                  | •                                       | Put time controls on display lighting                                                                                                 | Low cost               |
|                  | •                                       | Consider whether a whole area should be lit, or if task lighting will suffice                                                         | Low cost               |
|                  | •                                       | Clean dirty light diffusers and shades                                                                                                | Low cost               |
|                  | •                                       | Consider upgrading lighting to modern, energy efficient LED technology                                                                | Investment opportunity |
|                  | •                                       | Consider the installation of motion sensors for lighting                                                                              | Investment opportunity |
| Insulation and   | •                                       | Ensure doors and windows are not left open                                                                                            | No cost                |
| draughts         | •                                       | Identify the source of draughts and resolve any identified issues - particularly around windows and doors                             | Low cost               |
|                  | •                                       | Repair broken windows or roof lights                                                                                                  | Investment opportunity |
|                  | •                                       | Replace single-glazing with double or triple-glazing                                                                                  | Investment opportunity |
|                  | •                                       | Review and improve the building insulation, where necessary - consider both internal and external insulation                          | Investment opportunity |
| Office equipment | •                                       | Ensure IT equipment is not left on standby for long periods of time or overnight                                                      | No cost                |
|                  | •                                       | Ensure PC monitors are not left on overnight                                                                                          | No cost                |
|                  | •                                       | Ensure PC monitors are switched to power saving mode                                                                                  | No cost                |
|                  | •                                       | Ensure photocopiers, printers and plotters are not left on overnight                                                                  | No cost                |
| Ventilation      | •                                       | Use natural ventilation, where available, over mechanical ventilation                                                                 | No cost                |
|                  | •                                       | Avoid leaving windows open if air-conditioned                                                                                         | No cost                |
|                  | •                                       | Clean clogged or blocked filters                                                                                                      | Low cost               |
|                  | •                                       | Ensure proper timing of on or off switches, i.e. do not leave ventilation on in an unoccupied building                                | Low cost               |
| Space heating    | •                                       | Avoid unnecessary heating outside of working hours                                                                                    | No cost                |
| and boiler       | •                                       | Avoid excessive temperatures                                                                                                          | No cost                |
|                  | •                                       | Ensure temperature sensors and thermostats are located in the appropriate locations                                                   | No cost                |
|                  | •                                       | Switch radiators off when not needed                                                                                                  | No cost                |
|                  | •                                       | Avoid leaving windows and doors open when heating is on                                                                               | No cost                |
|                  | •                                       | Avoid sources of waste heat, e.g. heating unoccupied rooms, heating and air-conditioning competing with each other, etc.              | No cost                |
|                  | •                                       | Install weather compensation sensor to control space heating relative to weather conditions                                           | Investment opportunity |
|                  | •                                       | Replace or install insulation on boilers and pipework                                                                                 | Investment opportunity |
| Hot water demand | •                                       | Avoid unnecessary use of hot water. Remember, there can be a triple cost here: buy the water, heat the water and treat the wastewater | No cost                |
|                  | •                                       | Avoid excessive temperatures at hot water taps                                                                                        | No cost                |
|                  | •                                       | Replace or install insulation on hot water storage vessels                                                                            | Investment opportunity |
|                  | •                                       | Ensure hot water pipework is insulated                                                                                                | Investment opportunity |
| Kitchen or       | •                                       | Avoid running dishwashers on part-load                                                                                                | No cost                |
| canteen areas    | •                                       | Avoid locating fridges and freezers next to heat sources                                                                              | No cost                |
|                  | •                                       | Avoid overheating ovens                                                                                                               | No cost                |

## Step 4 - Plan

## Key goals:

- · Develop your energy action plan;
- · Set targets that your staff understand and can aspire to achieve;
- · Assign responsibility.

## What is an energy action plan and why make one?

An energy action plan sets out targets to be achieved, which can ultimately be used as benchmarks of success.

A plan secures budget and resources to ensure your energy statement and objectives are achieved. When completing yearly planning and budgeting, incorporate your energy action plan to ensure that energy management is high on the agenda and approached in an organised manner.

65-70% of barriers to implementing energy management in business are organisational barriers, e.g. time, resources, access to capital.

It is worthwhile having a copy of your energy action plan on display so that staff can read it. This will keep everyone aware of the progress that is being made in energy management.

## What to put in your energy action plan

Ideally you should have the following elements included in your Energy Action Plan:

- · Objectives or targets;
- · Cost or budget;
- · Person responsible for each objective;
- · Target date for completion of each objective;
- · Actual date of completion.

Having all of these elements included will give clear direction as to what is to be done, by whom and when. Without this, there may be confusion.

## Prioritising projects

You have already identified many opportunities that you may want to explore. However, it will not be feasible to put all of these in place in the first year of your programme. You need to decide what is realistic in one year and what projects are priorities. When completing your plan, carry out your priority items first and allocate appropriate resources. Priority can be based on some of the following factors:

- · Resources available;
- · Areas currently wasting significant amounts of energy;
- · The potential energy and cost saving;
- · Projects where you can get quick wins;
- · Highly visible projects, which will encourage greater awareness of energy;
- · Management among staff;
- · Changes that your employees will quickly understand.

<!-- image -->

## ACTION 10

Complete your energy action plan in the workbook. Ask your manager to sign this to show commitment.

A sample energy action plan is available in the completed sample workbook. This may give you some ideas for your own plan.

## Step 5- Act

## Key goals:

- · Implement your energy action plan;
- · Raise energy awareness among all staff members;
- · Motivate and encourage staff to participate enthusiastically;

This is where you, under the leadership of the energy coordinator, take action.

## Take action on your opportunities

The following are ways to take action on the opportunities you have identified to date.

- · Energy action plan

Start implementing the opportunities according to the timeline in your energy action plan.

- · Operation and maintenance

Establish a maintenance programme for your premises to ensure that equipment and processes already on-site are in good working order and operating at optimum energy efficiency. Link this to activities in your energy action plan.

## · Procurement

When buying new equipment, consider energy consumption. Prior to purchasing big items, it might be necessary to calculate their energy use over a number of years. Procurement can also involve the possibility of changing fuel suppliers, i.e. tendering out for an electricity supplier or exploring other options for procurement. This won't cut down your energy consumption, but it could potentially save you money on your fuel bills. You may also wish to change to a supplier of green electricity.

- · Design

This might only apply to those who are considering refurbishment, new build or extensions. This step would involve ensuring that energy efficient measures are included at preliminary planning and design or redesign stage.

As part of your  'Act' step, try to link to existing procedures and systems. For example, in the food or catering industry it may be appropriate to link HACCP , while in an office situation it may be beneficial to tie into the environmental standard ISO 14001.

## ACTION 11

Complete your energy action plan in the workbook. Ask your manager to sign this to show commitment.

A sample energy action plan is available in the completed sample workbook. This may give you some ideas for your own plan.

## Awareness action:

It is also time to start thinking about methods of communicating with staff to motivate, inform and enable them to implement the new programme fully. Raising awareness of your new energy management procedures is essential to the success of the plan.

The most important objective is to make any new system easy to understand. Awareness-raising activities need not be expensive or time consuming. Be clever and use as many existing communication tools as you can.

Bear in mind the following points when putting together an awareness campaign:

- · Explain to staff why they need to change;
- · Tell and show staff how to change;
- · Encourage staff to change.

There are a number of different tools that can be used to raise awareness. It is advisable to use a combination of these tools to get maximum effect. Examples of such tools are posters, leaflets, memos, green noticeboard, web notices, newsletter articles, etc.

Depending on the size of your company, you can kick off your action plan with an energy awareness day. In doing so you will attract the attention of a large number of  staff and perhaps members of the public, if this is appropriate. An awareness event will pave the way for other awareness-raising measures in the future.

## Training

Certain people within your organisation may also benefit from energy efficiency training, especially those who have a significant impact on energy use (e.g. the operations personnel should be trained sufficiently to operate all relevant equipment with energy saving in mind). When you filled out the 'operations and maintenance checklist' in the workbook (action 11), you indicated where you felt the responsible person needed training.

<!-- image -->

## ACTION 12

Tell your staff about your plans and get them involved using a variety of energy awareness resources.

## ACTION 13

Identify who on your staff needs training and carry out or facilitate training.

## Step 6 - Review

## Key goals:

- · Continuously monitor and compare your performance;
- · Complete a full review of targets and the progress towards achieving them.

Carrying out a review of your energy management programme is an integral step in ensuring continuous improvement. If you have made significant savings by implementing simple measures, it will boost morale. A review will help you to discover which resources have been most successful at making your business more energy efficient. Future actions required will also be easier to determine. There are two elements to this review step.

- 1.  Continuous or ongoing checks to compare your performance.
- 2.    Full yearly review of your progress towards achieving targets set out in your action plan.

Ongoing checks consist of monitoring your bills and comparing your performance, as outlined below.

## Monitoring bills

You have already started to record your energy bills. Go back and compare your energy costs from before you started your energy management programme to those since you started the programme. It is worthwhile doing this every two months.

## Compare your performance

Have a standard or point of reference for making comparisons on energy consumption, to assess how well you are progressing against other internal or external reference standards. In general, these may be based on consumption, cost or environmental indicators and together with benchmarking can help to identify the scope for improvement in energy efficiency.

Perhaps the most relevant approach within a small business is to look at past performance and compare against your current trends. Another option is to compare against established best practice in your sector. Some common comparisons are listed below.

## Common comparisons

- · Energy use per person - kWh/employee.
- · Energy to revenue - kWh/revenue.
- · Energy use per unit area - kWh/m 2 .
- · Energy use per unit of production - kWh/output, i.e. kWh/kg or €/kg (common in manufacturing).
- · Energy use over time - kWh/period (day/week/month).

Once you decide what would be most relevant to your situation, you can start to keep a record to track your progress over the year and to benchmark against previous years. Use more than one comparison to fully inform your review.

<!-- image -->

## Example: company with 20 employees and an electricity spend of &lt;€30K per year

Based on understanding their bill and meter, they take a weekly reading and calculate standard references in €/kg and kWh/kg. This is then added to the existing production overview system. This takes less than 10 minutes per week but has the advantage of highlighting electricity use beside other costs on an ongoing basis, which will be the driver of their programme.

## Review progress

You should do an annual review and  reflect on your progress towards your targets and the objectives. Some questions to ask yourself include:

- · Have targets been met and if not, why not;
- · Whether responsibilities have been taken on board and;
- · How successful initiatives and projects have been.

Complete this review on a quarterly basis initially and then annually once it is well established.

## Future recommendations

Once you have reviewed the success of your programme and compared your performance, you need to make some recommendations for future programmes. Look back at your review checklist and use this to inform next year's programme.

## Conclusions

Well done. You are well on your way to getting to grips with energy management in your business. This should become your annual approach to energy management. It must be a cyclical process to ensure that you are continually improving the way in which you manage your energy and energy costs. Contact SEAI if you are having difficulties with any aspect of your energy management. There are also a number of independent consultants who can be employed to assist with energy management in your business.

## ACTION 14

Fill in performance comparison progress table in the workbook.

<!-- image -->

<!-- image -->

Fill out future recommendations section in workbook.

## Appendix I

## Understanding your energy bills

In addition to your billing and supply addresses and customer account number, your bill contains the following information:

| Online registration number                          | If you currently use the online tool.                                                                                                                                                                                                                                                                                 |
|-----------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| MIC -MaximumImport Capacity (Electricity only)      | The level of electrical capacity, which represents the maximum load you are contracted to import from the electricity network for use in your premises.                                                                                                                                                               |
| MPRN-MeterPoint Reference Number (Electricity only) | This identifies and is unique to your meter connection point.                                                                                                                                                                                                                                                         |
| GPRN -GasPoint Registration Number (Gas only)       | This is a seven-digit reference number to identify your gas meter connection.                                                                                                                                                                                                                                         |
| DGcode (Electricity only)                           | An industry code representing your distribution use of system group.                                                                                                                                                                                                                                                  |
| MCcode (Electricity only)                           | An industry code representing your meter configuration code.                                                                                                                                                                                                                                                          |
| Profile code (Electricity only)                     | An industry code representing your load profile classification.                                                                                                                                                                                                                                                       |
| Tariff                                              | The specific tariff your company is on and associated rates.                                                                                                                                                                                                                                                          |
| Units                                               | The number of units you have consumed in the billing period.                                                                                                                                                                                                                                                          |
| Standing charge                                     | All electricity customers must pay this levy, which goes towards maintaining the country's electricity infrastructure.                                                                                                                                                                                                |
| Multiplier (Electricity only)                       | For customers who use a large amount of electricity and require large supply cables. A predetermined percentage of usage is passed through the meter and the remainder of the usage is calculated from that.                                                                                                          |
| Wattless units (Electricity only)                   | Some items occasionally require an amount of wattless energy for their operation, which is measured seperately and can give rise to a serarate charge. When the amount of wattless units used exceeds an amount higher than one-third of the total general units, a charge is incurred for the excess units consumed. |
| AC band - Annual Consumption band (Gas only)        | Your estimated annual usage of natural gas fits within the band range notified. There are five bands: A, B, C, Y, Z.                                                                                                                                                                                                  |

<!-- image -->

18

SEAI Energy Management

<!-- image -->

<!-- image -->

Sustainable Energy Authority of Ireland Hatch Street Upper

3 Park Place Dublin 2, Ireland

@seai\_ie

<!-- image -->