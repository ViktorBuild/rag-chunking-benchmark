---
document_id: seai_programme_impact_2025
title: "SEAI Programme Impact Report: Energy Efficiency Grants & Reductions"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2025
original_file: "seai_programme_impact_report_2025.pdf"
tables_detected: 78
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## SEAI Programme Impact Report 2025

Measuring our contribution to the Irish energy transition

<!-- image -->

## SEAI Programme Impact Report 2025

Measuring our contribution to the Irish energy transition

October 2026

## Report prepared for SEAI by:

Energy Policy &amp; Programme Evaluation Unit

## Disclaimer

While every effort has been made to ensure the accuracy of the contents of this report, SEAI accepts no liability whatsoever to any third party for any loss or damage arising from any interpretation or use of the information contained in this report, or reliance on any views expressed therein. Public disclosure authorised. This guide may be reproduced in full or, if content is extracted, then it should be fully credited to SEAI.

## Sustainable Energy Authority of Ireland

SEAI is Ireland's national energy authority investing in, and delivering, appropriate, effective and sustainable solutions to help Ireland's transition to a clean energy future. We work with the public, businesses, communities and the Government to achieve this, through expertise, funding, educational programmes, policy advice, research and the development of new technologies.

SEAI is funded by the Government of Ireland through the Department of Climate, Energy and the Environment.

© Sustainable Energy Authority of Ireland

Reproduction of the contents is permissible provided the source is acknowledged.

## Contents

| Executive summary ...............................................................................................................                                | Executive summary ...............................................................................................................                                |   4 |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| 1.                                                                                                                                                               | Introduction.................................................................................................................                                    |   7 |
| 2.                                                                                                                                                               | SEAI 2025 outturn by sector ....................................................................................                                                 |  11 |
| Residential sector programmes..........................................................................................................................          | Residential sector programmes..........................................................................................................................          |  11 |
| Business sector programmes..............................................................................................................................         | Business sector programmes..............................................................................................................................         |  14 |
| Public sector programmes...................................................................................................................................      | Public sector programmes...................................................................................................................................      |  18 |
| Electric vehicle programmes ...............................................................................................................................      | Electric vehicle programmes ...............................................................................................................................      |  19 |
| 3.                                                                                                                                                               | Long-term carbon abatement potential of low-carbon technology....................                                                                                |  22 |
| 4.                                                                                                                                                               | Programmatic and methodological updates.........................................................                                                                 |  25 |
| 5.                                                                                                                                                               | Conclusions ...............................................................................................................                                      |  27 |
| Glossary ................................................................................................................................                        | Glossary ................................................................................................................................                        |  28 |
| Appendix 1: Estimating programme impacts ...................................................................                                                     | Appendix 1: Estimating programme impacts ...................................................................                                                     |  30 |
| Overview of indicators.......................................................................................................................................... | Overview of indicators.......................................................................................................................................... |  30 |
| Tables of conversions and assumptions............................................................................................................                | Tables of conversions and assumptions............................................................................................................                |  35 |
| Appendix 2: Programme details.........................................................................................                                           | Appendix 2: Programme details.........................................................................................                                           |  39 |
| Appendix 3: Version control ...............................................................................................                                      | Appendix 3: Version control ...............................................................................................                                      |  40 |

## Executive summary

Each year, SEAI reports its annual output and impacts in an outturn table, provided to the Department of Climate, Energy and the Environment. The outturn table indicates the exchequer spend and private spend supporting energy efficiency and decarbonisation measures taken during the year, along with estimated new annual energy savings, grid electricity savings displaced, carbon dioxide equivalent savings and other impact metrics. This SEAI Programme Impact Report summarises the 2025 outturn table and provides context, commentary, and conclusions to guide future work in support of Ireland's energy transition.

<!-- image -->

Among key findings from the 2025 Programme Impact Report are the following:

## Overall findings

- · Programmes delivered by SEAI on behalf of government achieved significant impact in 2025, where using a budget of approximately €610 million, energy efficiency and decarbonisation activities were financed with nearly €600 million in supports, leveraging private spending of approximately €675 million. This is an increase from the €544 million in total exchequer funding in 2024.
- · The combined effect of supported activities led to estimated new annual final energy savings of approximately 400 GWh/year, roughly equivalent to the total annual energy consumption of close to 22,700 homes. This is down somewhat from approximately 430 GWh/year in 2024, due to a surge in completed multi-year projects in that year. Activities in 2025 also led to new annual grid electricity displaced of over 210 GWh/year, up from approximately 150 GWh/year in 2024. Combined, these will reduce carbon emissions by almost 150 ktCO2/year, slightly less than 158 ktCO2/year in new annual savings from 2024.
- · At average 2025 prices, these savings will reduce the energy bills of householders and businesses collectively by approximately €114 million/year, slightly more than the €106M in new annual energy cost savings in 2024.
- · We estimate that SEAI programmes supported approximately 13,200 jobs in the sustainable energy and related sectors during 2025, supporting the wider economy and leading to greater tax receipts. Due to an increase in the assumed wage rate in 2025, this is down from 14,490 jobs supported in 2024.

## Residential sector

- · SEAI supported 58,607 home energy upgrades in 2025, resulting in an estimated final energy saving of 189 GWh and an emissions saving of 81 ktCO2/year.
- · 8,835 low-income homes were upgraded by SEAI programmes in 2025.
- · Household energy bills were reduced by approximately €69 million/year by actions in 2025, on top of additional comfort and health benefits, as the indoor environment of homes is improved.
- · The Microgeneration Support Scheme delivered 35 ktCO2/year of savings by displacing an estimated 157 GWh/year of grid electricity through the placement of rooftop solar PV on homes in 2025.
- · The rate of uptake of heat pumps in 2025 increased 18% year-on-year. The 4,370 installed heat pumps saved an estimated 9.4 ktCO2 in 2025, and will save close to 300 ktCO2 over a 20-year technology lifespan.

## Business sector

- · SEAI supported 1,279 energy efficiency and renewable projects for businesses in 2025, reducing their final energy demand by 112 GWh/year, displacing 54 GWh/year of grid electricity, and reducing CO2 emissions by 40 ktCO2/year.
- · For the estimated business investment spend of approximately €74 million, combined with government spend of €22.1 million, we estimate that the energy savings achieved by 2025 programme activity will save Irish businesses close to €30 million/year in annual energy costs.

## Public sector

- · Working in tandem, the public sector energy efficiency programme and the Pathfinders projects are estimated to have achieved up to 50 GWh/year in new annual final energy savings, leading to approximately 11 ktCO2/year in new annual carbon abatement.
- · This reduced the public sector energy bill by up to €7 million/year.

- · We estimate that Pathfinder projects supported over 900 jobs during 2025.

## Electric vehicles

- · Electric vehicle grants increased to 18,651 in 2025, representing a significant rebound after the approximately 12,300 grants in 2024 when the maximum grant level was reduced from €5,000 to €3,500.
- · Home electric vehicle charger grants were nearly as high, with 17,750 grants awarded, indicating a significant expansion of home charging capability.
- · The delivery of electric vehicle chargers in apartment buildings has increased, with 31 projects funded in 2025.
- · Altogether, the grant-aided electric vehicles and charges are estimated to lead to new annual final energy savings of 52 GWh/year, owing to the increased fundamental efficiency of electric vehicles over fossil fuel-powered vehicles, or €9 million/year in energy savings for consumers.
- · Combining that energy efficiency with lower carbon emissions from electricity, this leads to new annual carbon abatement of 14 ktCO2/year.

This report provides further detailed metrics for SEAI programmes. Aside from these annual metrics, SEAI's Energy Policy and Programme Evaluation team also works to refine the impact estimates for each programme through in-depth programme evaluations. The impact estimates produced both annually and through deeper evaluations inform SEAI's annual National Energy Projections, which in turn feed the EPA National Emissions Projections reports.  Further detail on the achievement towards sustainable energy targets is provided separately by SEAI in several related releases over the course of the year.

## 1. Introduction

SEAI is the expert authority on energy usage in Ireland, using robust, objective data and an evidencebased approach to help inform policy development and behaviours. To support this, SEAI generates comprehensive data on the impacts of programmes that we deliver on behalf of Government, as part of our mission to shift Ireland away from fossil fuels.

As reflected in SEAI's Statement of Strategy 2026 - 2030 1 , we seek not only to bring about reductions in energy consumption and energy-related carbon emissions; our aim is also to support improvements in health and wellbeing, in more affordable energy costs and improved business competitiveness, and a more independent and secure Irish energy system. We also strive to ensure that the benefits and opportunities brought about by this shift are distributed fairly.

To help assess our progress toward those aims, each year, SEAI provides the Department of Climate, Energy and the Environment, with data for SEAI programme spend and estimates of the impact of that spend. These impacts are used by the Department to report to central Government via the Revised Estimates Volume (REV) process and are published through various SEAI channels. An initial estimate of impact is made at the time of budget setting (budgeted outturn estimates), and subsequently on actual annual expenditure (outturn impacts). They are also used to track progress against various Government climate and energy obligations, as variously defined in the Climate Actions and Low Carbon Development Act, the Government's Climate Action Plans, and EU directives and regulations. The outputs further serve as inputs to SEAI's National Energy Modelling Framework and National Energy Projections outputs.

This publication, now the second in the annual series, presents the SEAI outturn tables for 2025 along with the background, context, and interpretation of the table's contents, to support a broader understanding of the impacts and progress SEAI is making in contributing to transforming Ireland's energy systems. Note that in this report we omit a number of programmes from the reporting scope where the impacts are either long-term or indirect or where insufficient data is currently available. The impacts for the Research, Development, and Demonstration activities supported by SEAI, the Energy Efficiency Obligation Scheme, and the Business Energy Efficiency scheme are separately assessed and reported on via different channels.

## Estimating programme outcomes

The impacts of a programme, whether it provides grant support for energy efficiency measures, mobilises communities to take part in the energy transition, or provides information on renewable energy generation, can be illustrated within a programme logic model 2 . Put simply, the programme logic model illustrates how the inputs provided to a programme functionally lead to fulfilling the programme's objectives, including the intervening steps of activities, outputs, outcomes, and impacts. The outturn from SEAI programmes comprises metrics across a variety of the programme logic elements. Figure 1 illustrates the components of the programme logic model, along with examples of programme metrics associated with each component, drawn from SEAI programmes.

1 SEAI (2026). Statement of strategy 2026 - 2030 . Available at https://www.seai.ie/news-andevents/news/seai-publishes-statement-strategy-2026-2030

2 See W.K. Kellogg Foundation (2004). W.K. Kellogg Foundation Logic Model Development Guide for comprehensive guidance on the use of programme logic models. Available at https://wkkf.issuelab.org/resource/logic-model-development-guide.html.

Figure 1: An illustrative programme logic model for SEAI programmes with data examples

<!-- image -->

## Scope of outcomes considered

Because energy and emissions savings are a common objective across SEAI programmes, they and associated metrics are the main focus of impacts reported on in the annual impact report. Associated metrics include the value of energy savings and jobs supported by energy efficiency and decarbonisation projects. Emissions savings can also be associated with reduced fines or compliance costs for each additional quantity of energy or emissions saved. However, these are not quantified here 3 .

In addition to the above, a wide range of other impacts of energy efficiency and decarbonisation measures have been documented by the International Energy Agency 4 . Certain of these are discussed in qualitative terms in the sections that follow, for each sector in turn. Further, each programme will undergo a periodic impact evaluation that addresses the full range of intended, and indeed unintended, impacts of its interventions.

The energy and carbon savings quantified here also have important knock-on effects that are not quantified here. Aside from the real climate mitigation benefits from carbon savings contributions, energy savings help to reduce compliance costs and fines from exceeding mandatory targets.

3 See Department of Environment, Climate, and Communications and Department for Public Expenditure and Reform (2023). Spending Review 2023: Estimating the Potential Cost of Compliance with 2030 Climate &amp; Energy Targets and Irish Fiscal Advisory Council (2026). A colossal missed opportunity: Ireland's climate action and the potential costs of missing targets .

4 See IEA (2025), Multiple Benefits of Energy Efficiency, IEA, Paris https://www.iea.org/reports/multiplebenefits-of-energy-efficiency, Licence: CC BY 4.0.

Table 1: Overview of SEAI programme outturn for 2025, compared to outturn for 2024 (bracketed)

| Sectoral outturn 2025 (2024)   | SEAI capital spend, €M   |   of which grants awarded, €M | Est. private spend, €M   | Total Spend, €M   | Est. new annual final energy savings, GWh/year   | Est. new annual grid electricity displaced, GWh/year   | Est. newannual carbon savings, ktCO 2 /year   | Value of energy saved or generated, €M/year   | Jobs supported (gross estimate)   |
|--------------------------------|--------------------------|-------------------------------|--------------------------|-------------------|--------------------------------------------------|--------------------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------|
| Residential                    | 446.8 (415.7)            |                         428   | 408 (415)                | 855 (831)         | 189 (215)                                        | 157 (123)                                              | 81 (88)                                       | 69 (72)                                       | 11,200 (12,700)                   |
| Business                       | 22.1 (14.6)              |                          21.6 | 74 (70)                  | 96 (84)           | 112 (93)                                         | 54 (30)                                                | 40 (32)                                       | 29 (17)                                       | 1,100 (1,100)                     |
| Public Sector                  | 71.3 (61.7)              |                          70   | --                       | 71 (62)           | 50 (93)                                          | --                                                     | 11 (23)                                       | 7 (12)                                        | 900 (900)                         |
| Electric Vehicles              | 73.4 (51.9)              |                          73.2 | 192 (172)                | 266 (224)         | 52 (30)                                          | --                                                     | 14 (15)                                       | 9 (5)                                         | --                                |
| Total 5                        | 613.6 (543.9)            |                         592.8 | 675 (657)                | 1,289 (1,201)     | 402 (431)                                        | 211 (153)                                              | 147 (158)                                     | 114 (106)                                     | 13,200 (14,700)                   |

5 To eliminate the risk of double-counting, total business sector energy savings, value of energy savings, and carbon savings for LIEN, EXEED, and SSRH are calculated using the maximum values of either LIEN figures or the sum of EXEED and SSRH figures.

## Interpreting year-to-year and programme-to-programme variations

The outturn tables reported here include comparisons to 2024 outturn results. However, results for successive years must be interpreted with caution, especially when comparing sectoral or overall totals. As detailed in Chapter 4, some programmes have implemented rule or grant-level changes between 2024 and 2025. In other cases, we have updated our methodologies for calculating impacts to reflect new evidence.

Total figures may also vary in unexpected ways from year to the next. For example, while SEAI capital spend increased in 2025 over 2024, estimated energy savings decreased from 2024 to 2025. This is for several reasons:

- · Some programmes, such as Community Energy Grants for non-domestic upgrades, and for EXEED, provide multi-annual funding for energy savings that are only realised at the completion of a project. Therefore, grant spend and energy savings will not vary in harmony.
- · The Large Industry Energy Network consumes zero capital spend, but it does leverage significant energy savings through its activities. Therefore, its energy savings will vary from year to year, while its capital spend will not.
- · Some important conversion factors vary from year to year, altering programme effectiveness. For example, the composite emissions factor for some residential programmes diminished by 6% in 2025, which led to a reduction in carbon savings for the same amount of energy savings.

Finally, the programme portfolio is intentionally composed of schemes with different cost structures and objectives, reflecting the need to balance emissions reduction, market development and social equity, rather than optimising solely for lowest cost per unit of energy or carbon saved. Therefore, when comparing costs versus energy and carbon savings between schemes, the differences do not necessarily imply that equivalent savings could be achieved by reallocating funding between programmes, as each scheme targets distinct cohorts and faces different delivery, eligibility and capacity constraints.

## 2. SEAI 2025 outturn by sector

## Residential sector programmes

## Inputs

The outturn for residential sector programmes is summarised in Table 2. In 2025, a total of €447 million of SEAI capital spend provided the grant funding required to upgrade 58,607 homes across all residential schemes, as well as other buildings as part of the Community Energy Grants scheme. The Micro-generation Support Scheme, which supports rooftop solar photovoltaics, leveraged €237 million in private spending due to sustained high demand. The National Home Energy Upgrade Scheme, which leverages 'One-Stop Shops' to carry out comprehensive retrofit projects, saw the highest private spend per home, covering approximately 60% of the retrofit costs. This scheme typically requires significant efficiency improvements and the installation of renewable heating systems to qualify for funding.

As a 100% grant-funded programme, the Warmer Homes Scheme represented both the largest overall cost and the highest cost per home upgraded. However, the programme specifically targets homes categorised as most vulnerable in their ability to make the energy transition. As part of a just transition, facilitating upgrades in this category is essential to ensure that they are not left behind. And as discussed in the Wider Impacts section below, this category derives substantial benefits from home energy upgrades beyond simply energy savings.

## Energy and emissions impacts

SEAI's residential programmes delivered an estimated 189 GWh/year of final energy savings in 2025, representing a 12% decrease compared with 216 GWh/year of new annual savings in 2024. The reduction primarily reflects a decline in reported savings from non-domestic Community Energy Grant projects. As these projects generally have multi-year delivery timelines, reported savings can vary between years, with lower figures occurring when projects are under development rather than reaching completion. There was also a slight decline in total estimated savings for the Better Energy Homes programme, directly linked to a reduction in the number of applications completed compared to the previous year.

Better Energy Homes contributed the largest share (40%) of the total residential sector savings. Domestic Community Energy Grants made the most significant advancement in terms of homes completed, with a 44% increase on 2024 activity levels. The National Home Energy Upgrade Scheme (One Stop Shop) also recorded a significant increase in completion rates, rising by 31% compared with 2024.

The Microgeneration Support Scheme delivered an estimated 35 ktCO2/year of savings in 2025 by displacing approximately 155 GWh/year of grid electricity through rooftop solar PV installations on homes, which equates to the total annual energy consumption of approximately 10,400 homes. Calculated carbon savings increased by 12% year on year, reflecting both continued growth in the number of households installing solar PV and a trend towards larger system sizes. This represents a strong programme performance. However, the contribution of residential solar PV should be understood in the context of the wider residential decarbonisation challenge. Solar PV primarily reduces demand for grid electricity used for appliances, lighting and other electrical loads. It does not generally make a meaningful contribution to the decarbonisation of residential space and water heating, which remains the most pressing emissions challenge in the sector.

In this context, the contrast between SEAI-supported solar PV and heat pump installations is notable. In 2025, SEAI supported 33,048 residential solar PV installations compared with 4,370 heat pump installations. While heat pump uptake increased year on year, deployment remains well below the scale required to meet national residential heating targets. This points to a persistent imbalance in the residential transition, with supported activity expanding more rapidly in electricity generation than in the decarbonisation of heat, through heat pump deployment (i.e. electrification).

The long-term emissions outlook (as discussed in Chapter 3) further strengthens the case for increased focus on heat pumps. As the electricity grid decarbonises, the emissions abatement delivered by additional solar PV generation will gradually decline. In contrast, the abatement potential of heat pumps will increase as lower-carbon electricity replaces fossil fuel heating. This underscores the need for sustained policy support, supply-chain development, consumer-focused delivery models and additional innovative measures to accelerate heat pump upgrades at scale.

## Wider impacts

Of the total number of homes retrofitted in 2025 (58,607), SEAI's residential programmes supported upgrades in 8,834 low income homes, representing just over 15% of all residential upgrades delivered -during the year. The majority of these upgrades were delivered under the Warmer Homes Scheme, for which all participating households are classified as low income and qualify through receipt of social -welfare payments. In addition, all Approved Housing Body (AHB) homes supported through the One Stop Shop and Community Energy Grant programmes are treated as low income for reporting -purposes. Homes supported under the Solar PV for Medically Vulnerable scheme are not necessarily fuel poor, but represent a distinct vulnerable cohort, reflecting eligibility criteria linked to reliance on electrically powered medical or life support equipment; 473 homes received support under this -programme in 2025.

Looking across recent years, the number of fuel poor homes supported by SEAI programmes has -increased substantially, rising from 1,977 homes in 2020 to 8,834 homes in 2025, an average increase of approximately 35% per year over the period.  This growth has been driven primarily by the increasing number of retrofits delivered through the Warmer Homes Scheme. However, the year on --year rate of increase slowed markedly in 2025, to under 6%, compared with much higher growth rates in earlier years. Over the same period, the depth of upgrades delivered to low income households has -increased, with an estimated 74% of these homes receiving deep retrofits in 2025, reflecting a shift toward more comprehensive energy efficiency measures and greater long term benefits for comfort, -health, and energy affordability.

Grant-funded retrofit programmes support employment by sustaining long-term jobs, supporting small businesses, developing supply chains, and contributing to local economic activity. It is estimated that SEAI's residential programmes supported approximately 11,200 direct jobs in 2025. In some cases, these high-level estimates show a decline relative to 2024; however, they are sensitive to underlying assumptions, including wage rates, which increased in 2025. As a result, the estimated figures may understate actual employment supported, which may have increased despite the apparent decline in estimated job numbers.

Table 2: SEAI programme outturn for 2025 compared to 2024 (bracketed): Residential Sector Programmes

| Programme outturn 2025 (2024)                        | Total number of homes upgraded   | SEAI capital spend, €M   |   Of which grants awarded, €M | Est. private spend leveraged, €M   | Leverage factor (private € spend leveraged per € SEAI spend)   | Total spend, €M   | Est. new annual final energy savings, GWh/year   | Est. new annual grid electricity displaced, GWh/year   | Est. new annual carbon savings, ktCO 2 / year   | Value of energy savings or generation, €M/year   | Heat pumps installed   | Number homes upgraded to B2   | Energy poor homes supported   |
|------------------------------------------------------|----------------------------------|--------------------------|-------------------------------|------------------------------------|----------------------------------------------------------------|-------------------|--------------------------------------------------|--------------------------------------------------------|-------------------------------------------------|--------------------------------------------------|------------------------|-------------------------------|-------------------------------|
| Better Energy Warmer Homes                           | 8,134 (7,743)                    | 246.1 (229.7)            |                         233.7 | --                                 | --                                                             | 246 (230)         | 38 (36)                                          | --                                                     | 9.5 (9.5)                                       | 6.6 (4.8)                                        | 212 (49)               | 540 (332)                     | 8,134 (7,743)                 |
| Community Energy Grant (Domestic)                    | 998 (683)                        | 16.9 (14.7)              |                          16.9 | 21 (21)                            | 1.2 (1.5)                                                      | 37 (36)           | 12 (8)                                           | --                                                     | 3.0 (2.2)                                       | 1.2 (1.1)                                        | 948 (683)              | 932 (683)                     | 169 (63)                      |
| Community Energy Grant (Non- Domestic)*              | --                               | 27.2 (26.5)              |                          27.1 | 33 (39)                            | 1.2 (1.5)                                                      | 60 (65)           | 40 (69)                                          | --                                                     | 8.9 (18.1)                                      | 7.4 (9.2)                                        | --                     | --                            | --                            |
| National Home Energy Upgrade Scheme (One- Stop Shop) | 1,938 (1,474)                    | 43.0 (32.1)              |                          42.2 | 66 (39)                            | 1.6 (1.2)                                                      | 109 (71)          | 23 (18)                                          | --                                                     | 5.8 (4.7)                                       | 2.3 (2.4)                                        | 1,727 (1,359)          | 1,832 (1,437)                 | 532 (545)                     |
| Better Energy Homes                                  | 14,016 (15,660)                  | 45.6 (48.5)              |                          42.2 | 52 (59)                            | 1.2 (1.2)                                                      | 97 (108)          | 76 (85)                                          | --                                                     | 18.7 (22.3)                                     | 12.9 (11.4)                                      | 1,483 (1,542)          | 3,067 (3,237)                 | --                            |
| Micro- generation Support Scheme                     | 33,048 (28,424)                  | 65.3 (64.2)              |                          63.1 | 237 (257)                          | 3.8 (4.0)                                                      | 303 (321)         | --                                               | 155 (123)                                              | 35.0 (31.3)                                     | 38.0 (43.5)                                      | --                     | 19,873 (16,148)               | --                            |
| Solar PV for medically vulnerable                    | 473                              | 2.8                      |                           2.8 | --                                 | --                                                             | 2.8               | --                                               | 2.2                                                    | 0.5                                             | 0.5                                              | --                     | 74                            | --                            |
| Total for residential programmes                     | 58,607 (53,984)                  | 446.8 (415.7)            |                         428   | 408 (415)                          | --                                                             | 855 (831)         | 189 (215)                                        | 157 (123)                                              | 81 (88)                                         | 69 (72)                                          | 4,370 (3,633)          | 26,244 (21,837)               | 8,835 (8,351)                 |

SEAI's programmes deliver a wide range of benefits that are not included in this report or in the impacts table. Residential energy efficiency and renewable energy programmes offer a range of nonenergy benefits that significantly enhance the quality of life for homeowners 6 . These programmes often lead to improved indoor air quality by reducing pollutants and allergens, which can result in better health outcomes and fewer respiratory issues 7 .

Additionally, energy-efficient homes tend to have better insulation and temperature regulation, providing a more comfortable living environment year-round. These improvements can also increase the overall value of the property, making it more attractive to potential buyers. Technology prices can be driven downwards through increased volume sales, making energy-efficient technologies more accessible to a broader audience. They also contribute to capacity and skills building, as homeowners and professionals alike gain valuable knowledge and expertise in implementing and maintaining energy-efficient solutions. Furthermore, upgrades can foster a sense of community and environmental responsibility, as residents become more aware of their energy consumption and its impact.

These considerations are important when interpreting programme impacts with regards to the cost of energy savings and emissions abatement. For example, fully-funded retrofits (such as those under the Warmer Homes Scheme) result in a relatively high cost per unit of energy saved compared to other programmes. However, it should be noted such programmes also encompass objectives beyond energy and carbon metrics. These impacts, while not analysed here, are crucial and intended.

## Business sector programmes

The outturn for business sector programmes is summarised in Table 3.

## Inputs

A total of €22.1 million of SEAI capital spend was used by business programmes in 2025. As a peer-topeer networking programme, Large Industry Energy Network is not associated with direct capital expenditure costs by SEAI, rather it seeks to highlight opportunities that can then be taken up by industry as part of operational business improvements.

The Non-Domestic Microgeneration scheme represented the largest capital spend at €13.9 million, delivering 63.3 MWp of solar PV peak capacity through 1,195 businesses.

6 International Energy Agency (2019). Multiple Benefits of Energy Efficiency 2019 . Published March 2019. Available at: Multiple Benefits of Energy Efficiency 2019 - Analysis - IEA (Accessed: 26 March 2025). 7 See for example Milner, J., Hutchinson, E., Hamilton, I., Armstrong, B., and Wilkinson, P. (2025). Evaluation of the 'Warmth &amp; Wellbeing' Scheme on Health and Wellbeing: Final Report to the Department of the Environment, Climate and Communications, Government of Ireland . Available at: gov.ie - Warmth and Wellbeing Scheme (Accessed: 26 March 2025) and Kimberly Lazo Green, Michelle M C Tan, Eugenie Evelynne Johnson, Nisar Ahmed, Claire Eastaugh, Fiona Beyer, Dawn Craig, Gemma F Spiers, Barbara Hanratty, Interventions for cold homes: a rapid review of the health impacts, European Journal of Public Health , Volume 34, Issue 4, August 2024, Pages 682-695, https://doi.org/10.1093/eurpub/ckae058.

Table 3: SEAI programme outturn for 2025 compared to 2024 (bracketed): business sector programmes

| Programme outturn 2025 (2024)                                                 | Total number of grants supported   | SEAI capital spend, €M   | Of which grants awarded, €M   | Est. private spend leveraged, €M   | Leverage factor (private € spend leveraged per € SEAI spend)   | Total spend, €M   | Est. new annual final energy savings, GWh/year   | Est. new annual grid electricity displaced, GWh/year   | Est. new annual carbon savings, ktCO 2 /year   | Value of energy savings or generation, €M/year   | Jobs supported   |
|-------------------------------------------------------------------------------|------------------------------------|--------------------------|-------------------------------|------------------------------------|----------------------------------------------------------------|-------------------|--------------------------------------------------|--------------------------------------------------------|------------------------------------------------|--------------------------------------------------|------------------|
| Large Industry Energy Network (LIEN)                                          | --                                 | --                       | --                            | --                                 | --                                                             | --                | 112 (93)                                         | --                                                     | 27.7 (19.4)                                    | 15.8 (11.2)                                      | --               |
| Non-Domestic Microgeneration Scheme                                           | 1195 (927)                         | 13.9 (9.2)               | 13.5                          | 54 (45)                            | 4.0 (4.9)                                                      | 68 (54)           | --                                               | 54 (30)                                                | 12.2 (7.5)                                     | 13.1 (5.7)                                       | 800 (700)        |
| Excellence in Energy Efficient Design (EXEED)                                 | 12 (14)                            | 4.5 (1.8)                | 4.4                           | 15 (21)                            | 3.5 (11.5)                                                     | 20 (23)           | 20 (42)                                          | --                                                     | 4.3 (9.5)                                      | 3.4 (8.0)                                        | 200 (300)        |
| Support Scheme for Renewable Heat (SSRH) - Operational aid for biomass/biogas | 65 (57)                            | 1.7 (1.4)                | 1.6                           | --                                 | --                                                             | 1.7 (1.4)         | --                                               | --                                                     | 14.9 (11.1)                                    | --                                               | --               |
| Support Scheme for Renewable Heat (SSRH) - Investment grant for heat pumps    | 7 (4)                              | 2.0 (2.1)                | 2.0                           | 5.2 (4.0)                          | 2.6 (1.9)                                                      | 7.3 (6.1)         | 3 (18)                                           | --                                                     | 0.9 (3.9)                                      | --                                               | 100 (100)        |
| Total for business programmes 8                                               | 1,279 (1,002)                      | 22.1 (14.6)              | 21.6                          | 74 (70)                            | --                                                             | 96 (84)           | 112 (93)                                         | 54 (30)                                                | 40 (32)                                        | 29 (17)                                          | 1,100 (1,100)    |

8 To eliminate the risk of double-counting, total business sector energy savings, value of energy savings, and carbon savings for LIEN, EXEED, and SSRH are calculated using the maximum values of either LIEN figures or the sum of EXEED and SSRH figures.

The Support Scheme for Renewable Heat's operational aid for biomass and biogas is based on usable heat output in biomass and biogas heating systems, supporting its operation for up to 15 years. Therefore, the capital expenditure of €1.7 million associated with this programme does not relate to upfront infrastructure costs, but to the cost of tariff subsidies in 2025. In addition to grant spend, a further €74 million in private funding was leveraged across business programmes. The majority of private spend leveraged was through the Non-Domestic Micro-Generation scheme with €54 million and the Excellence in Energy Efficient Design (EXEED) scheme with €15 million invested by Irish businesses.

Capital expenditure of €4.2 million was recorded for the Business Energy Efficiency scheme in 2025, up from €3.3 million in 2024. This spend is linked to energy audits provided to small and medium enterprises (SMEs). In 2025, 2,002 audits were grant funded under this scheme. These audits assess the energy performance of SMEs and indicate a set of actions that can be taken to improve energy efficiency. Energy audit support is an important enabling tool for business and facilitates no-cost measures and energy investments. However, to avoid double-counting, no savings are directly attributed to the energy audit support, as the recommended investments may be supported by:

- · SEAI capital grants (i.e., the savings are captured within these grants),
- · Energy efficiency obligation schemes (i.e., the savings are captured in EEOS), or
- · May be made without state support.

For this reason, direct impacts for Business Energy Efficiency are not estimated separately for this report. The Business Energy Efficiency scheme also includes delivery of the SEAI Energy Academy and Energy Management training.

The Business Energy Upgrade Scheme (BEUS) launched in November 2024. Throughout 2025, the scheme received applications for 274 measures amounting to €3.51 million. The most popular measures include heat pumps, BMS controls and fabric upgrades.

## Energy and emissions impacts

SEAI's business support programmes saved an estimated 112 GWh/year in final energy in 2025, up from 93 GWh/year in 2024. This estimate comes directly from the 112 GWh/year of energy savings leveraged by the Large Industry Energy Network programme. To avoid double-counting energy savings between the Large Industry Energy Network, on the one hand, and EXEED and SSRH on the other, we do not add together these programmes; instead, we include only the larger of the two, which is the energy savings estimate for the Large Industry Energy Network.

Using a similar approach to avoiding double-counting for emissions, we estimate that SEAI's business support programmes saved an estimated 40 ktCO2/year in 2025, compared to 32 ktCO2/year in 2024. Now we add the 27.7 ktCO2/year of savings leveraged by the Large Industry Energy Network programme to the 12.2 ktCO2/year of savings associated with the Non-Domestic Micro-Generation scheme. Again we exclude EXEED and SSRH since the sum of their estimated carbon savings is less than the estimate for the Large Industry Energy Network. Selecting the larger value takes account of estimated savings in the LIEN that have occurred outside of EXEED and SSRH.

The Non-Domestic Micro-Generation scheme delivered those 12.2 ktCO2/year of savings by displacing an estimated 53.8 GWh/year of grid electricity via solar PV installed by businesses in 2025. A 63% yearon-year growth in carbon savings can be explained by continued increase in installations (+28%), and larger system sizes. The number of systems 10-1000 kWp increased by 34% in 2025. Furthermore, a small number of units (4) totalling 7.8 GW peak were installed in 2025 under the scheme.

Support Scheme for Renewable Heat operational aid for biomass and biogas saved an estimated 14.9 ktCO2 in 2025, up from 2024 savings of 11.1 ktCO2. In 2025, 8 new businesses joined the existing 57 on the tariff scheme. It does not, however, lead to significant energy savings. Rather, this support replaces fossil fuel-based heating with renewables, which does not always result in an energy efficiency gain, though it does provide carbon savings. The programme does contribute to Ireland's RES-H targets. In 2025, this amounted to 44.41 GWh/year. Support Scheme for Renewable Heat investment aid for heat pumps, which supports installation of commercial heat pumps, produced final energy savings of 3 GWh/year and carbon savings of 0.9 ktCO2/year. In 2025, the programme delivered nearly twice the number of mid-to-large range heat pump projects. However, the total savings decreased year on year due to the two large scale industrial process heating projects delivered in 2024.

The Large Industry Energy Network is a peer-to-peer network managed and supported by SEAI for companies with an annual energy spend of €1M or more. Due to the scale of measurement and verification required, savings associated with the Large Industry Energy Network are reported one year in arrears. As shown in Table 3, 112 GWh/year of final energy savings are attributed to the Large Industry Energy Network programme for 2024. This is increased from 93.4/year GWh in 2023. Savings for the Large Industry Energy Network are an assumed contribution of the programme towards overall energy savings achieved by industry entities involved in the network.

## Wider impacts

SEAI's business programmes supported an estimated 1,100 jobs in 2025. This is an underestimate as it does not include jobs created through increased ambition to deliver energy savings enabled by the Large Industry Energy Network programme. Beyond energy savings and job creation, SEAI's business programmes deliver a broad range of benefits not quantified in this report.

Investment in energy efficiency and renewables can strengthen a business's resilience to external factors such as energy or material prices. The adoption of renewable electricity generation, or renewable heat technology, such as heat pumps or biomass, can reduce a business's reliance on imported fossil fuels that are susceptible to price shocks. Energy efficiency measures can also reduce a business's energy demand and thus lowering energy costs. Additionally, energy efficiency measures and renewable energy technology often leads to lower energy and production costs for SMEs and large industry. As a result, this can increase profit margins, production capacity, and create the potential for new revenue streams.

Energy efficiency measures may also lower operational costs for businesses that use machinery. Process optimisation often extends equipment lifetime; deferring capital investments, reducing maintenance costs, and decreasing machinery downtime.

Further benefits include, but are not limited to:

- · Increased asset value of buildings,
- · Enhanced employee productivity because of improved physical work environment 9 , and
- · Increased supply chain capacity.

It can also stimulate the technology market and impact the technology prices through driving volume sale.

9 IEA 2019, Multiple Benefits of Energy Efficiency 2019, IEA, Paris https://www.iea.org/reports/multiplebenefits-of-energy-efficiency-2019, Licence: CC BY 4.07

Business energy efficiency and renewable energy programmes deliver benefits to the wider society such as improved air quality from reduced greenhouse gas emissions (GHG).

## Public sector programmes

Outturn for the public sector has in recent years been calculated for two programmes: Public Sector Partnerships, and Public Sector Pathfinders. The first is a support programme aimed at enhancing public sector bodies' own capabilities to monitor and improve their energy efficiency, particularly in compliance with articles of the EU's Energy Efficiency Directive and Energy Performance of Buildings Directive specific to the public sector. The second programme, Pathfinders, provides co-funding for major projects.

In 2025, the portfolio of programmes in SEAI focusing on the public sector has been reorganised and expanded to include two additional programmes, focusing on retro-commissioning and on public bodies with significant property portfolios. While these programmes are in their initial phases, SEAI is in the process of revising the calculation methodologies in advance of reporting for 2026 outturn.

During the intervening year, we report 2025 outturn for the public sector as a whole, using data energy efficiency project data extracted from the Public Sector Monitoring and Reporting system. The outturn for Public Sector programmes is shown in the first two columns of Table 4.

Table 4: SEAI programme outturn for 2025 compared to 2024 (bracketed): public sector programmes

| Programme outturn 2025 (2024)      | SEAI capital spend, €M   |   Of which grants awarded, €M | Est. new annual final energy savings, GWh/year   | Est. new annual carbon savings, ktCO 2 /year   | Value of energy savings or generation, €M/year   | Jobs supported   |
|------------------------------------|--------------------------|-------------------------------|--------------------------------------------------|------------------------------------------------|--------------------------------------------------|------------------|
| Total for public sector programmes | 71.3 (61.7)              |                            70 | 50 (93)                                          | 11 (23)                                        | 7 (12)                                           | 900 (900)        |

## Inputs

For 2025, due to extensive overlap between programmes' effects, public sector programmes are reported together. This includes the SEAI's Pathfinder programme and Public Sector Partnership programme. For 2025, this uses an interim methodology accumulating estimated energy savings from individual projects reported as completed in the Public Sector M&amp;R system. The Public Sector M&amp;R system tracks the progress of 350 public bodies and approximately 3,000 schools.

SEAI's Pathfinder programme supports public bodies to deliver sustainable solutions including deep retrofits and renewable heat. In 2025, the programme amounted to €21.1 million in SEAI capital. Public sector partners provide the remaining 50% of project costs through exchequer funding.

The Public Sector Energy Efficiency programme supports public bodies to achieve public sector energy targets outlined in the Climate Action Plan and the Public Sector Energy Efficiency Strategy (2017). The programme provides bespoke energy management advisory, training and networking supports, built on a partnership with public bodies. This represents zero effective capital cost for SEAI. The costs of implementing measures and initiatives as a result of the programme are borne by other public sector bodies and Government Departments as part of fulfilling their obligations.

## Energy and emissions impacts

We estimate that SEAI's public sector programmes saved an estimated 50 GWh in 2025, bringing about an annual emissions abatement of 11.2 ktCO2.

## Wider impacts

The International Energy Agency report on Multiple Benefits of Energy Efficiency 10  found that energy efficiency and renewable energy programmes invest in long term energy savings, resulting in a decrease in public expenditure, providing a public benefit. A holistic consideration to building and energy use, space optimisation and long-term infrastructure aim to deliver better public services using less energy and carbon. Furthermore, improvements to public buildings through the programmes can also support accrual of value in capital stock.

The same International Energy Agency report also found that energy efficiency measures contribute to better building quality, leading to improved temperature regulation, air quality and lighting. These improvements directly benefit public sector employees, with a better physical work environment linked with increased employee productivity. Additionally, the general public benefits from increased comfort and broader health benefits when accessing public services in buildings such as hospitals, schools and libraries. Energy efficient lighting upgrades implemented in public spaces through the programmes can also improve public safety.

Supports delivered through the public sector programmes are likely to have a broader benefit on households and businesses. This can occur through a spillover effect on employees, where workplace promotion of sustainable solutions is adopted at home. Additionally, a number of awareness campaigns were funded through the public sector programmes promoting behaviour change in the wider community.

## Electric vehicle programmes

The outturn for electric vehicle programmes is shown in the last row of Table 5.

10 IEA (2025), Multiple Benefits of Energy Efficiency, IEA, Paris https://www.iea.org/reports/multiplebenefits-of-energy-efficiency, Licence: CC BY 4.0

Table 5: SEAI programme outturn for 2025 compared to 2024 (bracketed): electric vehicle programmes

| Programme outturn 2025 (2024)    | Number of vehicle/ charger instal- lations   | SEAI capital spend, €M   |   Of which grants awarded, €M | Est. private spend leveraged, €M   | Leverage factor (private € spend leveraged per € SEAI spend)   | Total spend, €M   | Est. new annual final energy savings, GWh/ year   | Est. new annual carbon savings, ktCO 2 / year   | Value of energy savings or generation, €M/year   |
|----------------------------------|----------------------------------------------|--------------------------|-------------------------------|------------------------------------|----------------------------------------------------------------|-------------------|---------------------------------------------------|-------------------------------------------------|--------------------------------------------------|
| Electric vehicles purchase grant | 18,651 (12,300)                              | 66.7 (44.2)              |                          66.5 | 173 (145)                          | 2.6 (3.3)                                                      | 240 (189)         | 52 (30)                                           | 14 (15)                                         | 9.2 (5.3)                                        |
| Home charger grant               | 17,750                                       | 5.6 (6.8)                |                           5.5 | 18 (27)                            | 3.3 (4.0)                                                      | 24 (34)           | --                                                | --                                              | --                                               |
| Apartment charger grant          | 31                                           | 1.2 (1.0)                |                           1.2 | 0.6 (0.2)                          | 0.5 (0.2)                                                      | 1.7 (1.2)         | --                                                | --                                              | --                                               |
| Total                            | 36,432                                       | 73.4 (51.9)              |                          73.2 | 192 (172)                          | 2.6 (3.3)                                                      | 266 (224)         | 52 (30)                                           | 14 (15)                                         | 9.2 (5.3)                                        |

SEAI offers grant supports for new battery electric vehicle purchases, including passenger cars, light commercial vehicles, and large panel vans. While e-moped and electric motorcycle grants are now included, these were not yet available in 2025. Grants are also available for home chargers, as well as to support multi-unit dwellings to install charging infrastructure.

## Inputs

Electric vehicle grants awarded in 2025 totalled €66.7 million (including both private and commercial applicants), while €5.6 million was awarded for home chargers and €1.2 million for apartment charging infrastructure projects. We estimate that the private spend leveraged by these grant awards were €173 million for electric vehicles, €18 million for home chargers, and €0.6 million for apartment chargers. While electric vehicle grants awarded increased by more than 50% from 2024 to 2025, private spend increased by only 20%, likely for two reasons: first, due to a slight reduction in the 'electric vehicle price premium', and second, due to the growth in availability of more affordable electric vehicle models, where purchasers are paying a lower price by receive the same grant aid per vehicle.

To elaborate on the electric vehicle price premium, when estimating private spend leveraged, rather than counting the full cost of the vehicle as leveraged, we consider only the additional cost of an electric vehicle relative to a comparable internal combustion engine vehicle. We regard the remaining cost of the electric vehicle as being likely to have been spent regardless. For 2025, the level of this estimated premium was set at 30% based on findings from the International Energy Agency 11 , which is a slight reduction from the 2024 estimates that assumed an electric vehicle premium of 38%. If in the future electric vehicle and internal combustion vehicle prices come into alignment, then none of the purchase price could be considered leveraged.

## Energy and emissions impacts

For energy savings, we only provide an estimate for electric vehicle grants, where we assume that those savings are in fact produced through the combination of supports for both vehicles and chargers. We estimate the annual final energy saved from electric vehicles supported in 2025 to be 52 GWh/year. Applying a carbon factor based on the expected fuel mix of an internal combustion engine vehicle

11 IEA (2025), Global EV Outlook 2025, IEA, Paris, https://www.iea.org/reports/global-ev-outlook2025/trends-in-electric-car-affordability, Licence: CC BY 4.0

alternative, this equates to an annual abatement of 14 ktCO2/year. The annual carbon emission abatement achieved by new electric vehicles sold in 2025 is expected to increase in future years as grid electricity generation increases its use of renewable sources. The value of new annual energy savings from electric vehicles is estimated to be €9.2 million/year.

## Wider impacts

Electric vehicles bring a number of established benefits to their users; for example, the convenience of home charging, the reduction in operating costs, and increased reliability due to simpler mechanical technology compared to internal combustion engine vehicles. Depending on typical usage patterns, some electric vehicles may lead to inconveniences due to range limitations and scarcity of public charging points.

Aside from reduced greenhouse gas emissions associated with electric vehicles, they bring a number of social benefits in terms of improved air quality due to reduced emissions of nitrous oxides, carbon monoxide, and sulphur oxides. Particulates should also decrease, although it should be noted that tyre and brake wear contribute considerably to particulate emissions, and these cannot be expected to decrease when switching to electric vehicles. Noise disturbance at low speeds is considerably lower both for electric vehicle occupants and external road users in the vicinity, although at high speeds tyre noise tends to dominate, and these would not be diminished.

As with any other private vehicle, electric vehicle usage contributes to transport system congestion, which in turn can lead to greater emissions from internal combustion engine vehicles sharing the road with electric vehicles. As such, the benefits of increased adoption of electric vehicles can only be maximised if overall automobile usage levels can be managed appropriately.

Rapid adoption of electric vehicles depends on the development of sufficient capacity to distribute electrical demand across the national grid at times of peak demand. However, wider adoption of electric vehicles may also have the potential to enhance the flexible usage and resilience of the electricity grid, for example through the use of bidirectional charging, the use of electric vehicles for battery storage, and peak shifting while connected for long periods. Depending on how effectively this potential can be realised, this flexibility could lead to a reduced need for fossil fuel electricity generation during peak demand periods.

## 3. Long-term carbon abatement potential of lowcarbon technology

The outturn figures reported in the preceding chapter estimate the new annual carbon abatement as achieved in 2025, for actions carried out in 2025. While we express these on a per-year basis, in fact these should not be interpreted as projections of their annual carbon abatement over the lifetimes of the measures carried out, since the carbon intensity of different energy sources is expected to change in the coming years. This is most pronounced for electricity, where a growing supply of wind, solar, and biomass energy sources is expected to gradually reduce the carbon intensity of electricity drawn from the grid.

This has implications for the long-term carbon abatement potential of certain kinds of measures carried out in a single year, especially low-carbon technology that produces or consumes electricity. Taking an example, the 33,048 residential solar photovoltaic systems installed in 2025 represent a significant contribution to national annual carbon abatement. Each individual system, generating an estimated 4,678 kWh on average in its first year of operation, avoided just over one tonne of CO  in ₂ 2025.

The long-term carbon abatement of these installations can be assessed using projected emissions factors indicated by the With Existing Measures scenario of the National Energy Projections. Over their assumed 25-year operational lifetime (2025 to 2049), these installations are estimated to collectively avoid a cumulative 297,200 tonnes of CO . At the individual level, each installation is projected to avoid ₂ approximately nine tonnes of CO  over its lifetime, reflecting both the sustained generation of ₂ renewable electricity at the household and building level, and the progressive decarbonisation of the grid.

However, the annual carbon emissions abatement of these installations will decline significantly over time. The With Existing Measures scenario estimates that the emissions factor of the electricity grid is projected to improve from 0.226 kg CO /kWh in 2025 to 0.034 kg CO /kWh by 2049, a reduction of 85%. ₂ ₂ This means that by the final years of the panels' lives, each unit of solar generation will displace considerably less carbon than it does today by avoiding grid generated electricity as the grid will already be substantially less reliant on fossil fuels. As a result, annual fleet-level abatement is projected to fall from 35.0 kt CO  in 2025 to just 4.7 kt CO  in 2049, a decline of approximately 87%. A smaller ₂ ₂ secondary factor is natural panel degradation, which reduces output by approximately 0.5% per year, resulting in an approximately 12% reduction in generation over the 25-year lifetime.

This front-loaded abatement profile has implications for how the long-term value of solar photovoltaics. The emissions abatement potential is highest at the point of installation and declines thereafter, reinforcing the case for accelerating deployment now rather than deferring it. This of course does not take away from the householder or business benefits of reduced energy costs, and the cumulative emissions reduction still contributes to reducing the rate of global warming dud to GHG emissions.

In contrast to solar PV, the projected lifetime carbon abatement profile for heat pumps installed in 2025 is expected to increase over time under the same electricity decarbonisation pathway. A total of 4,370 heat pump systems were installed by SEAI residential retrofit programmes in 2025. Assuming a 20-year lifespan, the average annual emissions abatement for the 2025 heat pump fleet is projected to

rise from 2.2 tCO2 in 2025 to 2.9 tCO2 in 2044 12 , an increase of 34%. This upward trend reflects the declining carbon intensity of grid electricity over time, which reduces the post-retrofit emissions associated with electric heating while the avoided emissions from displaced fossil fuel heating remain substantial. For context, the corresponding per-installation figures for the 2025 solar PV cohort are lower and declining over time: approximately 1.06 tCO2 per installation in 2025, falling to about 0.14 tCO2 by 2049. This provides the basis for Figure 2 which compares per-installation SPV and heat pump carbon savings.

As with all long-run projections, these estimates are sensitive to assumptions on realised heat pump performance, dwelling heat demand, system retention over time, and the future emissions intensity of displaced fuels and electricity. The projections should therefore be interpreted as scenario-based estimates used to illustrate the point, rather than forecasts of observed outturn.

Figure 2: Projected annual emissions abated per average heat pump and SPV installation in 2025.

<!-- image -->

This distinction has important implications for policy design and programme prioritisation. Measures with front-loaded abatement, such as solar PV, deliver most of their carbon benefit immediately after installation, which makes them particularly valuable where the policy objective is to reduce emissions quickly and support near-term annual targets. Measures such as heat pumps, and EVs by contrast, become progressively more valuable over time as the electricity grid decarbonises, because their avoided emissions are then measured against a lower-carbon electricity system.

12 See Carbon emissions abatement in Appendix 1 for an outline of the heat pump savings calculation methodology.

For policymakers, this means that annual delivery metrics alone may not capture the full strategic value of different measures. Decisions on funding allocation, measure mix, and long-term carbon planning should consider both the timing of savings and the expected evolution of emissions over the lifetime of the measure.

## 4. Programmatic and methodological updates

## Programmatic developments

In administering programmes on behalf of government, SEAI strives to learn from evidence and adapt programme design and implementation, as well as to report to government on insights for policy. In 2025, changes were relatively minor. The Microgeneration Support Scheme reduced the grant amount for rooftop solar PV from to a maximum of €1,800 and the battery storage add-on grant was discontinued. The Home Energy Upgrade Loan Scheme was rolled out, which complements grant schemes to support home energy upgrades, but since it is administered by the Strategic Banking Corporation of Ireland, we do not include it in the outturn figures here.

More significant changes have been implemented already in 2026, such as a number of adjustments to home energy grant levels and eligibility rules, and the rollout of a pilot scrappage scheme for purchasers of electric vehicles. EXEED and SSRH have made programme enhancements during 2026, where changes include expanded grant support, both in the amount awarded and the projects eligible, a simplified Energy Service Company (ESCO) model, and the lead in time for approval. Since the focus in this report is on 2025 outturn, none of these adjustments factor into any of the figures reported here.

While the changes above are likely to accelerate the rates of residential and business upgrades and of electric vehicle uptake somewhat, the SEAI National Energy Projections 2025 report suggests that additional measures as described in its 'With additional measures' (WAM) scenario would help to reduce overshoot with regard to mandatory targets set out in the Renewable Energy Directive and the Energy Efficiency Directive. However, to reduce these overshoots more substantially requires a more transformative approach to infrastructure delivery that would accelerate the deployment of critical components of a sustainable energy system, as well as delivering net energy demand reductions over time, rather than increases. managing and tackling increasing energy demand.

## Updates to impact estimation methods

Realised energy savings and, consequently, carbon emissions, are dependent on a number of factors outside the specific characteristics of the measures implemented, all of which create challenges for estimates. We continuously seek new evidence and methodologies that can improve our estimates, providing more informed guidance on how our programmes can most effectively achieve their objectives.

In the 2025 impact estimates reported above, the following changes apply:

- · Residential Solar PV: the estimate of the value of energy savings is now calculated using an assumed 50%/50% split between self-consumption (35.4 c/kWh for avoided electricity purchased) and exported electricity (17.5 c/kWh).
- · Electric vehicles: the energy savings calculation has been updated to align with the StreamSave 13 methodology, which is also used for reporting against the EU Energy Efficiency Directive's energy efficiency obligation targets. Here, we continue to apply a 0.74 behavioural factor as done in previous years, pending the analysis of new data on electric vehicle driving distances.
- · Support Scheme for Renewable Heat, heat pump investment support: energy savings are now calculated using the total of completed projects' estimated contributions to the EU Renewable Energy Directive's renewable heat obligation.

13 StreamSave Project (2022). Deliverable D2.2 - Standardized saving methodologies: Energy, CO2 savings and costs.

- · Business sector programmes: starting in 2025, and for revised 2024 impact estimates (see section below), to avoid double-counting energy-saving projects in large industry, the business sector totals are now calculated using the maximum of two quantities:
- o the estimated energy savings for the Large Industry Energy Network, and
- o the sum of estimated energy savings for the EXEED programme and the Support Scheme for Renewable Heat.
- · Public sector programmes: we report energy savings for all programmes as a combined estimate for the sector, using an interim calculation that sums the energy savings of projects that public sector bodies have reported into the Public Sector Monitoring and Reporting (M &amp; R) system as completed. Because the project-level energy savings reported in the M &amp; R system are not verified, SEAI is currently developing a new methodology that we expect to use for 2026 impact reporting.

## 5. Conclusions

Programmes delivered by SEAI on behalf of Government have demonstrated the capacity to bring about substantial progress in improving energy efficiency and decarbonising energy systems through financial support and capacity building. Through approximately €610 million in exchequer funding leading to nearly €600 million in supports, combined with over €675 million in private spend leveraged through SEAI programmes, energy efficiency and decarbonisation projects have led to new final energy savings of approximately 400 GWh/year and new grid electricity displaced of over 210 GWh/year. These represent energy cost reductions of over €110 million/year, as well as an annual reduction in carbon emissions of nearly 150 ktCO2. These investments have also supported nearly 13,200 jobs in the sustainable energy sector.

In compliance with the Climate Action Plan and Ireland's international obligations, these programmes contribute to Ireland's climate change efforts in two key ways: first, by the direct emissions abatements resulting from actions taken through participation in these programmes, and second, through the market development in terms of supply-side capacity and customer awareness and demand, which can, and ideally will, lead to actions even beyond those directly supported by SEAI programmes. As these markets develop, and typically with incentives to address market failures, the support delivered through SEAI will play a diminishing role in achieving Ireland's targets.

As the electricity system is progressively decarbonised through an increasing share of renewable sources, the annual carbon abatement of the measures implemented in 2025 will gradually change as well, with heat pumps expected to have an increasing impact on emissions reductions as the electricity they rely on is increasingly renewable. At the same time, rooftop solar PV is expected to have a diminishing impact as the carbon savings of replacing grid electricity with fully renewable solar will gradually shrink.

Further analysis that incorporates the estimates presented in this report, is included in Ireland's National Energy Projections annual publication 14 . It is evident from the data in this report and the National Energy Projections that a multi-faceted policy approach is required to drive the required rates of technology deployment, supported by the International Energy Agency's work, which has indicated in its Energy Efficiency Policy Toolkit 15  that a mutually reinforcing policy package encompassing information, incentives and regulation is required to speed up the pace of change. Per SEAI's National Energy Projections reports, technology change alone will no longer be sufficient for us to live in accordance with our climate obligations. Systemic changes to economy, society and lifestyles must be facilitated such that we deliver for a society to thrive within Ireland's fair share of planetary boundaries. The evidence presented here supports that further definition and delivery of such actions is required.

14 SEAI 2025. National Energy Projections: 2025 Report , for comprehensive projections of Ireland's future energy savings and energy system characteristics. Available at: National Energy Projections | Key Publications | SEAI

15 IEA 2025, Energy Efficiency Policy Toolkit 2025, IEA, Paris https://www.iea.org/reports/energyefficiency-policy-toolkit-2025, Licence: CC BY 4.0

## Glossary

Table 6 provides a glossary of abbreviations used in this report.

## Table 6: Table of abbreviations

| Abbreviation   | Explanation                                                                                                             |
|----------------|-------------------------------------------------------------------------------------------------------------------------|
| BEH            | Better Energy Homes scheme                                                                                              |
| BER            | Building Energy Rating system, Ireland's Energy Performance Certificates scheme                                         |
| BEUS           | Business Energy Upgrade Scheme                                                                                          |
| BEV            | Battery Electric Vehicle                                                                                                |
| CAP            | Climate Action Plan                                                                                                     |
| CEG            | Community Energy Grants scheme                                                                                          |
| CO 2           | Carbon dioxide                                                                                                          |
| CSO            | Central Statistics Office                                                                                               |
| EED            | Energy Efficiency Directive                                                                                             |
| EEOS           | Energy Efficiency Obligation Scheme                                                                                     |
| €M             | Million Euro                                                                                                            |
| EV             | Electric Vehicle                                                                                                        |
| EXEED          | Energy Efficient Design scheme                                                                                          |
| GHG            | Greenhouse gas                                                                                                          |
| GW             | Gigawatts, a measure of power                                                                                           |
| GWh            | Gigawatt-hours, a measure of energy                                                                                     |
| HEV            | Hybrid Electric Vehicle, including Plug-In Hybrid Electric Vehicles                                                     |
| kt             | Kilotonnes, a measure of mass                                                                                           |
| ktoe           | Kilotonnes of oil equivalent, a measure of energy based on the energy content of crude oil                              |
| kWh            | Kilowatt-hours, a measure of energy                                                                                     |
| kWp            | Kilowatt-peak, a measure of the maximum electrical power output of solar photovoltaics under controlled test conditions |
| LIEN           | Large Industry Energy Network                                                                                           |
| IEA            | International Energy Agency                                                                                             |
| MSS            | Microgeneration Support Scheme                                                                                          |
| NDMG           | Non-Domestic Microgeneration scheme                                                                                     |
| OSS            | National Home Energy Upgrade Scheme (One-Stop Shop)                                                                     |

| Abbreviation   | Explanation                                                                                                                          |
|----------------|--------------------------------------------------------------------------------------------------------------------------------------|
| PHEV           | Plug-In Hybrid Electric Vehicle                                                                                                      |
| RES-E          | Renewable Energy Share target for Electricity                                                                                        |
| RES-H          | Renewable Energy Share target for Heat                                                                                               |
| REV            | Revised Estimates Volume process                                                                                                     |
| SEAI           | Sustainable Energy Authority of Ireland                                                                                              |
| SME            | Small or Medium Enterprise                                                                                                           |
| Solar PV       | Solar Photovoltaic System                                                                                                            |
| SSRH           | Support Scheme for Renewable Heat                                                                                                    |
| WAM            | With Additional Measures, a policy scenario under the National System for Policies and Measures used for national energy projections |
| WEM            | With Existing Measures, a policy scenario under the National System for Policies and Measures used for national energy projections   |
| WHS            | Better Energy Warmer Homes scheme                                                                                                    |

## Appendix 1: Estimating programme impacts

To estimate the impacts provided in this report, SEAI applies a variety of methods depending on the type of programme, the nature of the impact estimated, and the data available to us. The primary source is our own programme administrative data, for example data on the grant amounts awarded and the specific measures supported by those grant awards. In all cases, we make use of the best data and methodologies available to us, while at the same time ensuring we meet our obligations to protect personal data.

## Overview of indicators

The SEAI outturn tables provide high-level statistics that are broadly common across SEAI programmes. The focus is on outcomes that are essential to SEAI's organisational mission, where energy savings and energy-related carbon abatement are front and centre.

The outturn tables also provide selected associated metrics that are common across several programmes and fulfil on a range of Government targets and broader ambitions-for example, number of low-income homes upgraded, and number of (gross) jobs supported. The tables include the spend associated with programme outturn, including both the spend from the exchequer via SEAI's capital budget, and private investment that is leveraged when householders and businesses engage in SEAI programmes.

Finally, for certain programmes we list additional outcomes that are among those programmes' key objectives, but for which we are not presently able to provide quantitative estimates due to data availability or methodological issues.

## Inputs

For programmes to function, several key inputs are required, including capital budget and staff resourcing by Government. Here we report on programme capital expenditure from the exchequer, as well as private investment made on the part of applicants to SEAI programmes. Assumptions for applicant investment vary by programme, with some estimates based on actual costs incurred by applicants (after grants), while for other programmes we assume a fixed ratio between grant level and total cost, based on historical cost data. The estimates of private spend also include any supports received from obligated parties within Ireland's Energy Efficiency Obligation Scheme, which SEAI also administers on behalf of Government.

## Energy and emissions impacts

Estimates of new annual energy savings , grid electricity displaced , and carbon emissions abated are provided for all programmes where such outcomes are evident. These shed light on the progress made in the last year to reduce Ireland's dependence on fossil fuels through energy efficiency measures, and renewable energy generation deployed via the programmes listed. It should be noted that the estimates cover SEAI delivered programmes, and not the full suite of actions being delivered across Government in the name of climate action. A broader suite of impacts is accounted for in SEAI's National Energy Projections 16 , and includes the anticipated future impact of, for example, building

regulations, EU transport regulations, and others, as detailed in that report, in addition to those presented in the tables that follow.

## Energy savings

Energy savings are expressed as new annual delivered energy savings, defined as the reduction in energy consumed at the point of use in the year in which measures are installed. The focus on 'new' savings means that savings achieved in previous years are excluded, and the focus on 'annual' savings means that future year savings from the same measures are not counted in the year of installation. As -a result, the annual savings reported for each year can be summed across years to estimate the ongoing annual energy savings attributable to measures installed over that period, for the lifetime of those measures. Any estimate of lifetime savings would, however, need to take account of wider system developments, such as changes in the emissions intensity of grid electricity.

## Residential sector

Savings estimates are produced using programme-specific methodologies that reflect differences in target groups, installed measures, and observed or modelled performance. In doing so, SEAI does not rely directly on BER-modelled energy savings as a measure of energy consumption impacts. The BER system is designed as a standardised comparative assessment tool and, by design, applies fixed assumptions relating to occupancy patterns, internal temperatures, and household behaviour. As a consequence, systematic differences between BER-modelled energy demand and actual, metered energy consumption are expected and routinely observed. While BER data is used extensively to characterise dwelling efficiency and to inform modelling of retrofit impacts, programme-level energy savings estimates are calibrated or adjusted to better reflect observed energy use rather than relying on BER outputs alone.

For the Warmer Homes Scheme, annual energy savings are estimated using separate per home savings -assumptions for shallow and deep retrofits. The mix of shallow and deep retrofits is drawn from scheme delivery data for each year, recognising that the depth of retrofit has increased over time. Theoretical energy savings are adjusted by applying a 50 percent comfort taking factor to reflect the -higher likelihood that previously underheated homes increase indoor temperatures or heating duration following retrofit. This approach is consistent with evidence showing that, for energy poor -households, a significant share of benefits from energy efficiency improvements is realised as improved comfort and health rather than reduced energy consumption. The resultant per-home saving estimated for 2025 activity is 4,421 kWh.

For Better Energy Homes, savings estimates are informed by an ex post billing analysis conducted in -2013, which compared changes in energy use for retrofit recipient homes with a matched control group. That analysis found average savings of approximately 3,664 kWh per home. The assumed per home savings have since been increased to 5,400 kWh to reflect the growing prevalence of deeper -retrofit measures, such as external wall insulation and heat pump installations. A rebound effect of 36 percent is embedded within this estimate, based on observed before and after energy use patterns --from the original analysis.

For the One Stop Shop programme, average annual energy savings are estimated at 12,000 kWh per retrofit. This figure is derived from separate calculations for building fabric improvements and heat pump installations. Fabric retrofit savings are estimated using a bottom up housing stock model in -which dwellings move from lower to higher BER bands as a result of retrofit. Modelled energy demand for all dwellings, excluding appliances, is calibrated to the national energy balance by applying BER specific adjustment factors to dwelling energy intensity. Poorer BER bands are adjusted -

downwards and better BER bands upwards, implicitly allowing for comfort take back effects. Savings -from fabric retrofits are then calculated based on the change in modelled energy demand associated with BER band improvements.

Heat pump savings for One Stop Shop are estimated separately, using an average heat demand of 11,900 kWh per dwelling and an assumed average coefficient of performance, resulting in an estimated fuel saving of approximately 7,500 kWh per annum for dwellings switching to a heat pump. Based on application data an assumed share of homes installing heating pumps is derived, with the remaining homes involving fabric upgrades only. Applying these weights results in an average saving of around 12,000 kWh per One Stop Shop project.

Given the similarity in retrofit scope, the Community Energy Grants residential scheme is assumed to achieve the same average per home energy savings as One Stop Shop, using the same modelling and calibration approach. For non-domestic Community Energy Grant projects, annual energy savings are derived from the Energy Credit Management System (ECMS), which is used to record modelled savings achieved under Ireland's Energy Efficiency Obligation Scheme (EEOS). Reported savings for eligible nondomestic CEG projects are based on the values recorded in ECMS by obligated parties and represent the estimated energy savings attributed to these interventions.

Across programmes, SEAI accounts for direct rebound effects only, that is, behavioural or operational responses that lead to higher energy use following efficiency improvements, such as heating homes to higher temperatures or for longer periods. These effects are incorporated through explicit comfort taking factors or implicitly through model calibration to observed energy consumption. -Indirect, economy wide, and supply side rebound effects are not included in scheme level savings ---estimates due to the absence of robust evidence that can be consistently applied at programme level.

No rebound or comfort taking adjustment is applied to Solar PV estimates, as reported impacts relate -to electricity generated rather than reductions in delivered energy demand.

## Business and public sectors

Large Industry Energy Network saving estimates are derived from the programme's annual review delivered one year in arrears. The annual review collects energy saving data from LIEN members with an approximate 90% response rate. An attribution factor of 29% is applied annual savings based on a study by Cahill &amp; O'Gallachoir (2011). This identifies the attribution of LIEN to members achieving energy savings above that of non-LIEN companies. Emission savings for CO2 includes Scope 1 and 2.

For Non-Domestic Microgeneration this report presents the annual electricity grid displacement. It reports the impacts related to renewable electricity generation rather than reductions in delivered energy demand. This is calculated using a specific yield factor of 850 from the European Commission, Joint Research Centre. PVGIS - Photovoltaic Geographical Information System.

Savings for the Excellence in Energy Efficient Design (EXEED) programme are estimated based on the completely measures delivered within the 2025 calendar year. Given the wide variety of projects supported through EXEED savings are calculated on a per projects bases. The reported savings includes only stage 2 capital investment works. Savings have not been quantified foe Stage 1 audits or EXEED certification. It should also be noted that given the scale of projects funded through EXEED many projects can run multi-year, with many milestones. Therefore, the potential savings from the capital investment in 2025 will not be limited to the metrics presented in this report.

For the Support Scheme for Renewable Heat (SSRH)savings are calculated separately for Operational Aid (biomass) and for Investment Aid (heat pumps). This report does not present energy savings for SSRH - Operational Aid as there are little to no efficiency gains when switching from a fossil fuel boiler to a biomass boiler. Emission savings are calculated based on the biomass boilers produced heat. Not included in this estimate are the potential indirect emissions produced from transport of biomass material. Heat pump energy savings are calculated using the RES-H methodology using the estimated delivered heat demand and the appliances seasonal coefficient of performance (SCOP).

For 2025, an interim methodology is used to estimate the energy savings of the SEAI's Pathfinder programme and Public Sector Partnership programme. Estimated energy savings are calculated from individual projects reported through the Public Sector M&amp;R system.

## Electric vehicles and chargers

Energy savings from electric vehicles are computed using the StreamSave+ energy savings methodology 17 , as implement in Ireland's Energy Efficiency Obligation Scheme (EEOS). However, while the EEOS scheme has recently adjusted the behavioural parameter from 0.74 to 1.0, to reflect an absence of evidence of rebound in kilometres travelled when switching from an internal combustion engine vehicle to an electric vehicle, here we maintain a the behavioural factor of 0.74 pending an internal review of the results of a survey on electric vehicle grant recipients on their usage patterns.

## Grid electricity displaced

Alongside energy savings, we report the contribution from renewable generation programmes in terms of 'grid electricity displaced', with the final energy savings from these programmes reported as zero. This is because the electricity produced by these systems constitutes an extra generation capacity, rather than an actual reduction in energy consumption. As such, these initiatives do not yield any reduction in final energy consumed. While they may produce energy savings through avoided electricity transmission losses, we do not currently have an established approach to estimating this.

Programmes affected include the residential Microgeneration Support Scheme, and the Non-Domestic Microgeneration scheme, both of which primarily support solar photovoltaic systems (Solar PV). The reported carbon savings of 35 ktCO2 are associated with the electricity sector and represent a contribution to Ireland's renewable energy share for that sector (RES-E). They do not facilitate emissions reductions in the residential and business sector.

## Carbon emissions abatement

We also calculate new annual emissions abatement from the same new annual energy savings for most programmes. For these, we apply emissions factors for each energy source as estimated in the Energy in Ireland report 18 . Note, however, that while programme outputs reference 2025 data, the Energy in Ireland 2025 report uses 2024 energy consumption data.

For heat pumps, carbon savings are estimated separately from the delivered-energy (kWh) methodology above and are reported as annual emissions abatement in the year of installation, with projected cohort impacts shown over time. At dwelling level, annual pre- and post-retrofit delivered heat is defined as the sum of space-heating and water-heating delivered energy from BER records.

17 StreamSave Project (2022). Deliverable D2.2 - Standardized saving methodologies: Energy, CO2 savings and costs.

18 SEAI 2025. Energy in Ireland: 2025 Report . Available at: Energy In Ireland | Key Publications | SEAI

These are combined with fuel-specific emissions factors to estimate annual pre- and post-retrofit emissions, and annual carbon savings are calculated as the difference between the two.

To improve realism relative to standard BER assumptions, BER-derived delivered heat is calibrated using BER-band adjustment factors derived from observed consumption evidence. Separate calibration factors are applied to pre- and post-retrofit BER ratings, so that:

- · pre-retrofit delivered heat is scaled by a pre-rating factor, and
- · post-retrofit delivered heat is scaled by a post-rating factor.

Calibrated annual emissions are then recomputed using the same fuel/emissions-factor framework, and calibrated annual savings are used for reporting. On this basis, the 2025 heat pump cohort (5,844 installations across OSS, BEH, WHS and CEG) is estimated to deliver:

- · a total annual calibrated emissions saving of 9.43 ktCO2 in 2025,
- · an average annual calibrated emissions saving of 2.16 tCO2 per installation in 2025, and
- · a cumulative calibrated emissions saving over the 20-year lifespan (2025-2044)

As with all projection-based estimates, these results are scenario-dependent and sensitive to assumptions on realised system performance, heat demand, calibration-factor validity, and future grid decarbonisation.

All savings assumptions and rebound factors are kept under review and are updated as improved data and evidence become available.

## Sectoral totals and shared impacts

In the residential and business sector outturn tables, we provide some statistics for total outturn across programmes. Note however that the totals for business sector programmes do not sum together the Large Industry Energy Network with the totals for certain other business sector programmes. Similarly, we do not include totals for the Public Sector or Electric Vehicle programmes.

The reason for this is that in these cases, multiple programmes work in tandem to produce the energy savings estimated. Consequently, the energy savings reported for certain programmes may overlap with part of the energy savings reported for another programme, so that a sum of these would not be an accurate measure of the combined impact. Examples of programmes working in tandem include: EXEED and Large Industry Energy Network; Public Sector Energy Efficiency and Public Sector Pathfinders; and Electric Vehicle Purchase Grants and Electric Vehicle Home Charger Grants.

Note also that we do not report here the contributions of the Energy Efficiency Obligation Scheme (EEOS), where obligated energy suppliers support the deployment of a variety of energy efficiency measures. As part of Ireland's reporting for the Energy Efficiency Directive, work is ongoing to systematically account for the overlaps between the EEOS and other programmes, but it is likely that a substantial share of the energy savings in the EEOS are already accounted for in SEAI grant-funding programmes, such as Better Energy Homes and the National Home Energy Upgrade Scheme.

## Wider impacts

## Value of energy savings

To help interpret the benefits of energy savings and renewable generation, we estimate the value to consumers (both residential and business) of energy savings and grid electricity displaced based on energy prices as of the end of 2025.

## Low income homes upgraded

For certain residential programmes, we provide estimates of low-income homes upgraded. This is only an estimate - for personal data protection reasons, we do not normally use data on household-specific income to determine whether the upgrade was for a low-income home. Rather, we use programme characteristics to make general assumptions about the target group.

## Jobs supported

For programmes that directly support energy upgrade projects, we also provide estimates of gross jobs supported, based on an assumed share of costs attributed to labour, an average wage rate, and an assumed multiplier effect based on the literature.

## Multiple benefits

Besides targeting low-income homes and supporting jobs, SEAI programmes are recognised as providing a wide range of benefits; however, these benefits vary significantly across programmes. For this reason, and because these benefits are difficult to quantify with confidence, we do not include quantitative estimates in this report. However, we do list the most essential other benefits in the Wider Impacts section of each sector. Many programmes have additional benefits, beyond total energy or emissions savings, as central objectives to their design and delivery. Those benefits will be reviewed using periodic evaluations of programme-specific impacts.

## Costs and cost savings of energy savings and carbon abatement

Using indicators for new annual energy savings and carbon abatement as well as annual programme capital expenditures from the exchequer as well as private investment, we provide estimates of cost per kWh of new annual energy saved and per tonne of new carbon abatement. However, these estimates must be read with caution, for several reasons:

- · Average energy savings and carbon abatement costs are not necessarily indicative of marginal costs of varying the level of investment in a programme.
- · Different programmes target markets and technologies with different levels of maturity, hence different levels of grant support may be warranted to encourage the necessary market development, capacity and skills building to cause a full transition away from fossil fuels.
- · For several programmes investing in decarbonisation, such as heat pumps and electric vehicles, carbon abatement effects will increase as grid electricity is increasingly produced by renewable sources.
- · For other programmes, such as microgeneration, the marginal carbon abatement effects from avoided grid electricity consumption will diminish somewhat as grid renewables increase.
- · The original aim of the various programmes must be considered when contextualising their impacts. It is often more costly per tonne for programmes designed to kick start nascent markets, or those supporting those most in need.

## Tables of conversions and assumptions

The following tables provide additional details on the assumptions and sources of those assumptions as part of impact estimates, by sector: Table 7 for residentials sector programmes, Table 8 for business and public sector programmes, and Table 9 for electric vehicle programmes.

## Table 7: Residential sector impact calculation assumptions

| Assumption                                                                                                       | Value                                                | Unit     | Source                                                                                                                                                                                                                              |
|------------------------------------------------------------------------------------------------------------------|------------------------------------------------------|----------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Better Energy Homes delivered energy savings per home                                                            | 5,400                                                | kWh/year | Adapted from: Scheer, J., Clancy, M. & Ní Hógáin, S., 2013. Quantification of energy savings from Ireland's Home Energy Saving scheme: an ex post billing analysis. Energy Efficiency, 6, pp.35-48. doi:10.1007/s12053- 012-9164-8. |
| Warmer Homes Scheme delivered energy savings per home                                                            | 3,867 for shallow measures, 11,400 for deep measures | kWh/year | XD Sustainable Energy Consulting Ltd, 2019. Better Energy Warmer Homes and Warmth & Wellbeing Schemes: Study of the Schemes' Impacts in 2019. Sustainable Energy Authority of Ireland                                               |
| National Home Energy Upgrade Scheme (One Stop Shop) and Community Energy Grant delivered energy savings per home | 12,000                                               | kWh/year | Estimated by SEAI's Energy Modelling Unit. Assumes that 88% of homes install a heat pump and all homes reach B2 BER                                                                                                                 |
| Micro-generation Support Scheme delivered electricity generated per solar PV installation per annum              | 4,326                                                | kWh/year | Median delivered energy generation for participating Microgeneration Support Scheme homes in 2025. Data obtained from Building Energy Rating and Microgeneration Support Scheme programme databases                                 |
| Warmer Homes Scheme homes with shallow and deep measures                                                         | 28% shallow measure 72% deep measures                | %        | Warmer Homes Scheme data                                                                                                                                                                                                            |
| CO 2 emissions factor for the residential sector                                                                 | 0.263                                                | kt/GWh   | Weighted average calculated using the National Energy Balance and emissions factors from SEAI: Conversion Factors | SEAI Statistics | SEAI                                                                                          |
| Average annual wage of retrofit sector                                                                           | 57,600                                               | €        | CSO Earnings and Labour Costs Table 6c Average hourly total labour costs by economic sector and other characteristics and quarter                                                                                                   |
| Share of retrofit costs covered by grant in Better Energy Homes and One Stop Shop                                | 45                                                   | %        | Historical SEAI programme cost data                                                                                                                                                                                                 |
| Share of retrofit costs covered by grant in Community Energy Grants                                              | 41                                                   | %        | Historical SEAI programme cost data                                                                                                                                                                                                 |
| Share of retrofit costs covered by grant in Warmer Homes Scheme                                                  | 100                                                  | %        | Programme design                                                                                                                                                                                                                    |
| Energy cost (weighted average)                                                                                   | 13.44                                                | ¢/kWh    | Estimated from SEAI energy price statistics: https://www.seai.ie/data-and-insights/seai- statistics/prices                                                                                                                          |

Table 8: Business and public sector impact calculation assumptions

| Assumption                                                                           | Value   | Unit        | Source                                                                                                                                              |
|--------------------------------------------------------------------------------------|---------|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| Large Industry Energy Network and Public sector energy efficiency Attribution factor | 29%     | %           | SEAI reporting                                                                                                                                      |
| Value of energy savings per GWh                                                      | 50,000  | €           | SEAI programme data                                                                                                                                 |
| CO 2 emissions factor for the public and business sector                             | 0.250   | kt/GWh      | Weighted industry average calculated using the National Energy Balance and emissions factors from SEAI: Conversion Factors | SEAI Statistics | SEAI |
| Support Scheme for Renewable Heat payment years                                      | 15      | years       | SEAI programme data                                                                                                                                 |
| Average annual wage of retrofit sector                                               | 57,600  | €           | CSO Earnings and Labour Costs Table 6c Average hourly total labour costs by economic sector and other characteristics and quarter                   |
| EXEED (grants & certification)                                                       | 2       | kt CO 2 /€m | SEAI programme data                                                                                                                                 |
| Energy cost (weighted average) Large Industry Energy Network                         | 11.97   | cent/kWh    | Estimated from SEAI energy price statistics:                                                                                                        |
| Energy cost (weighted average) EXEED                                                 | 18.45   | cent/kWh    | https://www.seai.ie/data- and-insights/seai- statistics/prices                                                                                      |
| Energy cost (weighted average) Public Sector Programme                               | 12.53   | cent/kWh    | https://www.seai.ie/data- and-insights/seai- statistics/prices                                                                                      |
| Energy cost (weighted average) Heat pump non-domestic                                | 6.98    | cent/kWh    | https://www.seai.ie/data- and-insights/seai- statistics/prices                                                                                      |
| Energy cost (weighted average) Solar PV non-domestic                                 | 19.25   | cent/kWh    | https://www.seai.ie/data- and-insights/seai- statistics/prices                                                                                      |

## Table 9: Electric vehicle impact calculation assumptions

| Assumption                                             | Value     | Unit      | Source                                                                                                                                                       |
|--------------------------------------------------------|-----------|-----------|--------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Electric vehicle price premium for 2024                | 30%       | %         | IEA (2025), Global EV Outlook 2025, IEA, Paris, https://www.iea.org/reports/global-ev-outlook- 2025/trends-in-electric-car-affordability, Licence: CC BY 4.0 |
| Average grant spend per passenger vehicle              | 3561      | €/vehicle | SEAI grant data                                                                                                                                              |
| Average grant spend per small to medium commercial van | 3767      | €/vehicle | SEAI grant data                                                                                                                                              |
| Average grant spend per large panel commercial van     | 7478      | €/vehicle | SEAI grant data                                                                                                                                              |
| Energy savings per vehicle                             | 2,400     | kWh/year  | Internal SEAI Electric vehicle unit calculations                                                                                                             |
| Share of diesel / petrol in ICEV fleet                 | 55% / 45% | %         | Central Statistics Office                                                                                                                                    |
| Average diesel cost                                    | 170.8     | c/litre   | AA Ireland                                                                                                                                                   |
| Average petrol cost                                    | 174.4     | c/litre   | AA Ireland                                                                                                                                                   |

## Appendix 2: Programme details

Programme-specific details can be found at the SEAI web site using the links in Table 10.

## Table 10: Links to programme details

| Sector            | Programme                                           | Link                              |
|-------------------|-----------------------------------------------------|-----------------------------------|
| Residential       | Better Energy Warmer Homes Scheme                   | Fully Funded Energy Upgrades      |
| Residential       | Community Energy Grant - Domestic                   | Community grants and funding      |
| Residential       | National Home Energy Upgrade Scheme (One-Stop Shop) | One Stop Shop services for homes  |
| Residential       | Better Energy Homes                                 | Individual Energy Upgrade Grants  |
| Residential       | Micro-generation Support Scheme                     | Solar Electricity PV Grants       |
| Business          | Large Industry Energy Network                       | Large Industry Energy Network     |
| Business          | Non-domestic micro-generation scheme                | Non-Domestic Microgen Scheme      |
| Business          | Excellence in Energy Efficient Design (EXEED)       | EXEED Grant Scheme                |
| Business          | Support Scheme for Renewable Heat                   | Support Scheme for Renewable Heat |
| Public sector     | Public sector energy efficiency                     | Public Sector Energy Programme    |
| Public sector     | Public sector pathfinders                           | Pathfinder Programme              |
| Electric vehicles | Electric vehicles purchase grants                   | Electric Vehicle Grants           |
| Electric vehicles | Electric vehicles home and apartment charger grants | Electric Vehicle Charging Grants  |

## Appendix 3: Version control

|   Version | Date       | Notes              |
|-----------|------------|--------------------|
|         1 | 19/10/2026 | Published publicly |