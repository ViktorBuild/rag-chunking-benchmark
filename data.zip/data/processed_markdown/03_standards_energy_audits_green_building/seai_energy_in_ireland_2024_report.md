---
document_id: seai_energy_in_ireland_2024
title: "Energy in Ireland 2024 Report: National Energy Balances and Metrics"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2024
original_file: "seai_energy_in_ireland_2024_report.pdf"
tables_detected: 722
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## ENERGY IN IRELAND

20 24 Report

<!-- image -->

## Energy in Ireland

2024 Report

December 2024

ID: EII-2024-1.0

## Sustainable Energy Authority of Ireland

SEAI is Ireland's national energy authority investing in, and delivering, appropriate, effective and sustainable solutions to help Ireland's transition to a clean energy future. We work with the public, businesses, communities and the Government to achieve this, through expertise, funding, educational programmes, policy advice, research and the development of new technologies.

SEAI is funded by the Government of Ireland through the Department of Communications, Climate Action and Environment.

© Sustainable Energy Authority of Ireland

Reproduction of the contents is permissible provided the source is acknowledged.

## Acknowledgements

SEAI gratefully acknowledges the co-operation of all the organisations, agencies, energy suppliers and distributors that provide data and respond to its questionnaires throughout the year. This co-operation is especially appreciated in 2024, when many data providers have been asked to submit more data within shorter deadlines, as SEAI worked to collect energy details to inform Government policy and satisfy new emergency reporting brought about by the current energy crisis.

## Foreword

When it comes to Ireland contributing to reducing emissions that tackle the climate crisis, progress already made is essential and must be recognised, but it also cannot be mistaken as full success. A tipping point is often described as the point at which a series of small changes becomes significant enough to cause larger, more important changes. The progress we see in this report is a collective movement in the right direction. To realise full success on the back of that progress, Ireland now needs to march on and scale up our actions in our energy transition for the benefit of our people, our economy and ultimately to ensure an inhabitable planet.

<!-- image -->

The data in this report illustrates many welcome achievements for 2023. For example, we reached our lowest energy related emissions in over 30 years, with a pattern emerging where Ireland ' s energy related emissions have fallen for seven of the last ten years. Our electricity emissions continue to decrease significantly, and our highly fossil-fuel-reliant heat sector has seen its emissions reduce for the third year in a row. The data also shows achievement of our highest proportion of renewables in our energy mix since records began, with a record year for energy from wind generation and large-scale solar farms. These are all great signals, but not yet at the pace needed to achieve our committed targets. The question is can we capitalise on all this momentum, so it really is the start of the tipping point for Ireland.

We are at a critical period in our journey to a sustainable energy future. While we have succeeded in reducing emissions, our energy demand has continued to grow for a variety of reasons. Given the cumulative nature of emissions in the atmosphere, we are to be reminded that it ' s not just the end goal of emission reductions by 2030 or 2050 that matter, but our emission results each-and-every year against science-based carbon budgets and sectoral ceilings. These are our non-negotiables.

The latest definitive national data and analysis presented in this report, and in SEAI ' s latest energy projections released earlier this year, point to the need to both speed up; on deploying more renewable energy and energy efficiency technologies and practices, and to strategically slow down, on carbon intense activities across all sectors, thereby reducing our demand.

For speeding up, we must compress the timelines for massive deployment of renewables on our electricity grid, the development of district heating networks in our cities and towns, elimination of oil and gas fired boilers, massive roll out of electric vehicles and immediate demand reduction. The rates of change required are unprecedented and require a massive redoubling of effort and support. A ' do everything possible ' attitude is required of all sectors and actors, and we must continue to work together in communities.

For strategic slowing down, Ireland must make wise decisions on growth, limiting it where needed, to ensure choices that fit within the ecological boundaries set by science. Anything else would be irresponsible. It is incumbent on this generation of decision makers to find ways for society to prosper within planetary limits. This can feel like a daunting task. But as I have written many times over the last number of years, we have the technical solutions, now it ' s about winning hearts and minds, incentivising action and making tough choices on regulation and growth.

The data in this year ' s report further emphasises that in tandem with going full speed to replace fossil fuels in our economy and society, timing growth is essential. We need to balance necessary growth by using energy more efficiently and we need to be strategic in economic growth decisions that help Ireland in its energy transition and avoid further burdening its ability to meet our climate obligations.

As we move into 2025, the world is going through a lot of changes, not just in relation to our environment and climate. In Ireland we will enter the last year of the current carbon budget, under new national leadership. The data in this report shows us that we have the green shoots of progress appearing, but staying at the current pace of change will likely lead to increasing demand outpacing our sustainable energy transition. We must build on the current momentum, those signals of success, so that we look back in 2030 and see 2025 as the true tipping point for critical mass action and delivery in the energy transition. It needs bold, courageous leadership from across Government, business, and citizens, but it can be done.

At SEAI we currently support Ireland ' s public sector, thousands of businesses, tens of thousands of households and over 900 sustainable energy communities to get off fossil fuels every year. No matter where you are on the journey to your sustainable energy future, at SEAI we exist to support you to play your part. Whilst the hill we must climb is steep, if we all put our energy behind the changes needed, we will get there together. Please join us and be a part of the movement, let ' s tip the balance together.

## William Walsh, CEO

## Contents

| Acknowledgements...................................................................................................................................................................................2              | Acknowledgements...................................................................................................................................................................................2              | Acknowledgements...................................................................................................................................................................................2              |    |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----|
| Foreword........................................................................................................................................................................................................  | Foreword........................................................................................................................................................................................................  | Foreword........................................................................................................................................................................................................  |  3 |
| Contents......................................................................................................................................................................................................... | Contents......................................................................................................................................................................................................... | Contents......................................................................................................................................................................................................... |  5 |
| Technical Highlights..................................................................................................................................................................................            | Technical Highlights..................................................................................................................................................................................            | Technical Highlights..................................................................................................................................................................................            |  9 |
| 1                                                                                                                                                                                                                 | Key Trends in Ireland's Energy in 2023 and 2024..........................................................................................................                                                         | Key Trends in Ireland's Energy in 2023 and 2024..........................................................................................................                                                         | 10 |
| 1.1                                                                                                                                                                                                               | Energy-Related Emissions in 2023 and 2024.....................................................................................................                                                                    | Energy-Related Emissions in 2023 and 2024.....................................................................................................                                                                    | 11 |
| 1.1.1                                                                                                                                                                                                             | 1.1.1                                                                                                                                                                                                             | Electricity Emissions in 2023 and 2024.......................................................................................................                                                                     | 13 |
| 1.1.2                                                                                                                                                                                                             | 1.1.2                                                                                                                                                                                                             | Transport Emissions in 2023 and 2024.......................................................................................................                                                                       | 14 |
| 1.2 Ireland's European Energy Targets to 2030........................................................................................................                                                             | 1.2 Ireland's European Energy Targets to 2030........................................................................................................                                                             | 1.2 Ireland's European Energy Targets to 2030........................................................................................................                                                             | 16 |
| 1.2.1                                                                                                                                                                                                             | 1.2.1                                                                                                                                                                                                             | Ireland's Renewable Energy and EU Targets ............................................................................................                                                                            | 16 |
| 1.2.2                                                                                                                                                                                                             | 1.2.2                                                                                                                                                                                                             | Ireland's Energy Demand and EU Targets.................................................................................................                                                                           | 19 |
| 1.3 Transport in 2023 and 2024......................................................................................................................................                                              | 1.3 Transport in 2023 and 2024......................................................................................................................................                                              | 1.3 Transport in 2023 and 2024......................................................................................................................................                                              | 22 |
| 1.3.1                                                                                                                                                                                                             | 1.3.1                                                                                                                                                                                                             | Transport Energy Demand...............................................................................................................................                                                            | 22 |
| 1.3.2                                                                                                                                                                                                             | 1.3.2                                                                                                                                                                                                             | Renewable Energy in Transport.....................................................................................................................                                                                | 23 |
| 1.4 Electricity in 2023 and 2024......................................................................................................................................                                            | 1.4 Electricity in 2023 and 2024......................................................................................................................................                                            | 1.4 Electricity in 2023 and 2024......................................................................................................................................                                            | 25 |
| 1.4.1                                                                                                                                                                                                             | 1.4.1                                                                                                                                                                                                             | Electricity Demand..............................................................................................................................................                                                  | 25 |
| 1.4.2                                                                                                                                                                                                             | 1.4.2                                                                                                                                                                                                             | Electricity Supply..................................................................................................................................................                                              | 26 |
| 1.4.3                                                                                                                                                                                                             | 1.4.3                                                                                                                                                                                                             | Renewable Energy in Electricity.....................................................................................................................                                                              | 29 |
| 1.5 Heat and Residential Demand in 2023 and 2024.............................................................................................                                                                     | 1.5 Heat and Residential Demand in 2023 and 2024.............................................................................................                                                                     | 1.5 Heat and Residential Demand in 2023 and 2024.............................................................................................                                                                     | 31 |
| 1.5.1                                                                                                                                                                                                             | 1.5.1                                                                                                                                                                                                             | Heat Demand........................................................................................................................................................                                               | 31 |
| 1.5.2                                                                                                                                                                                                             | 1.5.2                                                                                                                                                                                                             | Renewables in Heat............................................................................................................................................                                                    | 32 |
| 1.5.3                                                                                                                                                                                                             | 1.5.3                                                                                                                                                                                                             | Residential Energy Demand............................................................................................................................                                                             | 33 |
| 2 Overview of energy data.........................................................................................................................................................                                | 2 Overview of energy data.........................................................................................................................................................                                | 2 Overview of energy data.........................................................................................................................................................                                | 37 |
| 2.1                                                                                                                                                                                                               | The National Energy Balance....................................................................................................................................                                                   | The National Energy Balance....................................................................................................................................                                                   | 37 |
| 2.2                                                                                                                                                                                                               | Additional data...............................................................................................................................................................                                    | Additional data...............................................................................................................................................................                                    | 39 |
| 2.3                                                                                                                                                                                                               | Data on energy-related emissions .........................................................................................................................                                                        | Data on energy-related emissions .........................................................................................................................                                                        | 39 |
| 3                                                                                                                                                                                                                 | Primary energy ............................................................................................................................................................................                       | Primary energy ............................................................................................................................................................................                       | 40 |
| 3.1                                                                                                                                                                                                               | Primary energy production .......................................................................................................................................                                                 | Primary energy production .......................................................................................................................................                                                 | 40 |
| 3.2                                                                                                                                                                                                               | Primary energy imports and exports.....................................................................................................................                                                           | Primary energy imports and exports.....................................................................................................................                                                           | 43 |
| 3.3                                                                                                                                                                                                               | Primary energy supply and requirement.............................................................................................................                                                                | Primary energy supply and requirement.............................................................................................................                                                                | 44 |
| 3.4                                                                                                                                                                                                               | Security of supply and import dependency .......................................................................................................                                                                  | Security of supply and import dependency .......................................................................................................                                                                  | 47 |

| 4   | Energy transformation.............................................................................................................................................................. 49          | Energy transformation.............................................................................................................................................................. 49                                                                                                                                                      | Energy transformation.............................................................................................................................................................. 49                                                                                                                                                      |
|-----|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|     | 4.1                                                                                                                                                                                             | Overview of transformation...................................................................................................................................... 49                                                                                                                                                                         | Overview of transformation...................................................................................................................................... 49                                                                                                                                                                         |
|     | 4.2                                                                                                                                                                                             | Electricity generation................................................................................................................................................... 49                                                                                                                                                                | Electricity generation................................................................................................................................................... 49                                                                                                                                                                |
|     | 4.2.1                                                                                                                                                                                           | 4.2.1                                                                                                                                                                                                                                                                                                                                       | Energy input to electricity generation......................................................................................................... 50                                                                                                                                                                                          |
|     | 4.2.2 Electricity generated                                                                                                                                                                     | 4.2.2 Electricity generated                                                                                                                                                                                                                                                                                                                 | and net imports......................................................................................................... 53                                                                                                                                                                                                                 |
|     | 4.2.3 Efficiency of electricity                                                                                                                                                                 | 4.2.3 Efficiency of electricity                                                                                                                                                                                                                                                                                                             | supply ........................................................................................................................ 58                                                                                                                                                                                                          |
|     | 4.2.4 Combined                                                                                                                                                                                  | 4.2.4 Combined                                                                                                                                                                                                                                                                                                                              | heat and power generation...................................................................................................... 58                                                                                                                                                                                                          |
|     | 4.2.5 Solar, wind and hydro                                                                                                                                                                     | 4.2.5 Solar, wind and hydro                                                                                                                                                                                                                                                                                                                 | capacity...................................................................................................................... 61                                                                                                                                                                                                           |
|     | 4.3                                                                                                                                                                                             | Oil refining ....................................................................................................................................................................... 66                                                                                                                                                     | Oil refining ....................................................................................................................................................................... 66                                                                                                                                                     |
|     | 4.4                                                                                                                                                                                             | Other transformation processes.............................................................................................................................. 67                                                                                                                                                                             | Other transformation processes.............................................................................................................................. 67                                                                                                                                                                             |
|     | 4.4.1 Pumped hydroelectric storage.......................................................................................................................                                       | 4.4.1 Pumped hydroelectric storage.......................................................................................................................                                                                                                                                                                                   | 68                                                                                                                                                                                                                                                                                                                                          |
|     | 4.4.2 Battery storage.....................................................................................................................................................                      | 4.4.2 Battery storage.....................................................................................................................................................                                                                                                                                                                  | 69                                                                                                                                                                                                                                                                                                                                          |
|     | 4.4.3 Peat                                                                                                                                                                                      | 4.4.3 Peat                                                                                                                                                                                                                                                                                                                                  | briquetting................................................................................................................................................... 70                                                                                                                                                                           |
| 5   | Final energy .................................................................................................................................................................................. | Final energy ..................................................................................................................................................................................                                                                                                                                             | 72                                                                                                                                                                                                                                                                                                                                          |
|     | 5.1                                                                                                                                                                                             | Final energy consumption by energy type ......................................................................................................... 72                                                                                                                                                                                        | Final energy consumption by energy type ......................................................................................................... 72                                                                                                                                                                                        |
|     | 5.2                                                                                                                                                                                             | Final energy consumption by sector ..................................................................................................................... 75                                                                                                                                                                                 | Final energy consumption by sector ..................................................................................................................... 75                                                                                                                                                                                 |
|     | 5.2.1 Final energy consumption                                                                                                                                                                  | 5.2.1 Final energy consumption                                                                                                                                                                                                                                                                                                              | in industry......................................................................................................... 77                                                                                                                                                                                                                     |
|     | 5.2.2 Final energy consumption                                                                                                                                                                  | 5.2.2 Final energy consumption                                                                                                                                                                                                                                                                                                              | in transport ...................................................................................................... 79                                                                                                                                                                                                                      |
|     | 5.2.3 Final                                                                                                                                                                                     | 5.2.3 Final                                                                                                                                                                                                                                                                                                                                 | energy consumption in residential.................................................................................................... 84                                                                                                                                                                                                    |
|     | 5.2.4                                                                                                                                                                                           |                                                                                                                                                                                                                                                                                                                                             | energy consumption in services......................................................................................................... 86                                                                                                                                                                                                  |
|     |                                                                                                                                                                                                 |                                                                                                                                                                                                                                                                                                                                             | 90                                                                                                                                                                                                                                                                                                                                          |
| 6   | Energy modes..............................................................................................................................................................................      | Energy modes..............................................................................................................................................................................                                                                                                                                                  |                                                                                                                                                                                                                                                                                                                                             |
|     |                                                                                                                                                                                                 | Final energy consumption by mode...................................................................................................................... 90                                                                                                                                                                                   | Final energy consumption by mode...................................................................................................................... 90                                                                                                                                                                                   |
|     | 6.2                                                                                                                                                                                             | Heat mode....................................................................................................................................................................... 91 6.2.1 Final energy in heat mode by sector........................................................................................................... 92 | Heat mode....................................................................................................................................................................... 91 6.2.1 Final energy in heat mode by sector........................................................................................................... 92 |
|     | 6.2.2                                                                                                                                                                                           | Final energy in heat mode by fuel................................................................................................................ 93                                                                                                                                                                                        | Final energy in heat mode by fuel................................................................................................................ 93                                                                                                                                                                                        |
|     | 6.3 Transport                                                                                                                                                                                   |                                                                                                                                                                                                                                                                                                                                             | mode............................................................................................................................................................. 95                                                                                                                                                                        |
|     | 6.3.1                                                                                                                                                                                           | Final energy in transport mode by subsector.......................................................................................... 95                                                                                                                                                                                                    | Final energy in transport mode by subsector.......................................................................................... 95                                                                                                                                                                                                    |
|     | 6.3.2                                                                                                                                                                                           |                                                                                                                                                                                                                                                                                                                                             |                                                                                                                                                                                                                                                                                                                                             |
|     |                                                                                                                                                                                                 | Final energy use in transport mode by energy type............................................................................. 96                                                                                                                                                                                                           | Final energy use in transport mode by energy type............................................................................. 96                                                                                                                                                                                                           |
|     | 6.4.1 Final energy use in electricity mode by sector ........................................................................................                                                   | 6.4.1 Final energy use in electricity mode by sector ........................................................................................                                                                                                                                                                                               | 98                                                                                                                                                                                                                                                                                                                                          |
| 7   | 6.5 Primary energy requirement by mode.................................................................................................................                                         | 6.5 Primary energy requirement by mode.................................................................................................................                                                                                                                                                                                     |                                                                                                                                                                                                                                                                                                                                             |
|     | Energy-related greenhouse gas (GHG) emissions.......................................................................................................                                            | Energy-related greenhouse gas (GHG) emissions.......................................................................................................                                                                                                                                                                                        | 99                                                                                                                                                                                                                                                                                                                                          |
|     |                                                                                                                                                                                                 |                                                                                                                                                                                                                                                                                                                                             | 101                                                                                                                                                                                                                                                                                                                                         |
|     | 7.1 GHG intensity of electricity consumption..........................................................................................................101                                       | 7.1 GHG intensity of electricity consumption..........................................................................................................101                                                                                                                                                                                   |                                                                                                                                                                                                                                                                                                                                             |
|     | 7.2 Energy-related GHG emissions by sector..........................................................................................................                                            | 7.2 Energy-related GHG emissions by sector..........................................................................................................                                                                                                                                                                                        | 102                                                                                                                                                                                                                                                                                                                                         |

8

9

| 7.2.1                               | Industry emissions                                                                                                                                                                    | ............................................................................................................................................105   |
|-------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------|
| 7.2.2                               | Transport emissions .........................................................................................................................................106                      |                                                                                                                                                   |
| 7.2.3                               | Residential emissions.......................................................................................................................................108                       |                                                                                                                                                   |
| 7.2.4                               | Commercial and public services emissions.............................................................................................109                                              |                                                                                                                                                   |
| 7.3 Energy-related GHG emissions by | mode...........................................................................................................                                                                       | 110                                                                                                                                               |
| 7.4                                 | Avoided emissions from renewable energy .....................................................................................................110                                      |                                                                                                                                                   |
| Energy targets and                  | policy .....................................................................................................................................................113                       |                                                                                                                                                   |
| 8.1                                 | Greenhouse gas emissions......................................................................................................................................113                     |                                                                                                                                                   |
| 8.1.1                               | Greenhouse gas emissions reductions targets......................................................................................115                                                  |                                                                                                                                                   |
| 8.1.2                               | Carbon budgets and sectoral emission ceilings ...................................................................................                                                     | 119                                                                                                                                               |
| 8.2                                 | Renewable energy targets.......................................................................................................................................123                    |                                                                                                                                                   |
| 8.2.1                               | Renewable Energy Directive and targets.................................................................................................123                                            |                                                                                                                                                   |
| 8.2.2                               | Biomass sustainability......................................................................................................................................124                       |                                                                                                                                                   |
| 8.2.3                               | RES Results...........................................................................................................................................................125             |                                                                                                                                                   |
| 8.2.4                               | Electricity from renewable energy sources                                                                                                                                             | (RES-E)..............................................................................130                                                          |
| 8.2.5                               | Heat from renewable energy sources (RES-H)                                                                                                                                            | ...................................................................................... 132                                                        |
| 8.2.6                               | Transport energy from renewable sources (RES-T)                                                                                                                                       | ............................................................................. 134                                                                 |
| 8.3                                 | Energy prices to industry..........................................................................................................................................138                |                                                                                                                                                   |
| Drivers of energy                   | demand....................................................................................................................................................143                         |                                                                                                                                                   |
| 9.1                                 | Energy, economy and emissions...........................................................................................................................143                           |                                                                                                                                                   |
| 9.2                                 | Energy and the weather............................................................................................................................................                    | 145                                                                                                                                               |
| 9.3                                 | Economic energy intensities ...................................................................................................................................                       | 146                                                                                                                                               |
| Further sectoral                    | Primary energy requirement by sector...............................................................................................................148                                |                                                                                                                                                   |
|                                     | energy intensity..........................................................................................................................................149                         |                                                                                                                                                   |
| 10.2                                | Industry                                                                                                                                                                              |                                                                                                                                                   |
| 10.3                                | Transport ........................................................................................................................................................................150 |                                                                                                                                                   |
| 10.3.1                              | Private car activity .............................................................................................................................................150                 |                                                                                                                                                   |
| 10.3.2                              | CO 2 intensity of new private cars................................................................................................................150                                 |                                                                                                                                                   |
| 10.3.3                              | Penetration of zero emissions vehicles.....................................................................................................151                                        |                                                                                                                                                   |
| 10.3.4                              | Heavy goods vehicle activity.........................................................................................................................153                              |                                                                                                                                                   |
| 10.4                                | Residential......................................................................................................................................................................     | 156                                                                                                                                               |
| 10.4.1                              | Weather correction...........................................................................................................................................                         | 156                                                                                                                                               |
| 10.4.2                              | Energy consumption per dwelling..............................................................................................................157                                      |                                                                                                                                                   |
| 10.5                                | Commercial and public services............................................................................................................................159                         |                                                                                                                                                   |

| 10.5.1                                                                                                                                                                                              | Energy intensity of the commercial and public services sector...................................................... 159                                                                             |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 10.5.2 Public sector 11                                                                                                                                                                             | developments..........................................................................................................................160                                                           |
| Provisional energy data from monthly surveys............................................................................................................162                                         | Provisional energy data from monthly surveys............................................................................................................162                                         |
| 11.1 Monthly utility scale electricity data to 2024................................................................................................... 162                                          | 11.1 Monthly utility scale electricity data to 2024................................................................................................... 162                                          |
| 11.1.1                                                                                                                                                                                              | Seasonality in utility scale monthly electricity supply......................................................................... 163                                                                |
| 11.1.2                                                                                                                                                                                              | Monthly utility scale electricity generated ..............................................................................................168                                                       |
| 11.1.3                                                                                                                                                                                              | Monthly electricity imported and exported in 2024 ........................................................................... 171                                                                   |
| 11.2 Gas..................................................................................................................................................................................... 172   | 11.2 Gas..................................................................................................................................................................................... 172   |
| 11.2.1                                                                                                                                                                                              | Seasonality in monthly gas supply.............................................................................................................172                                                   |
| 11.2.2                                                                                                                                                                                              | Monthly gas supply in 2024..........................................................................................................................174                                             |
| 11.3 Oil ...................................................................................................................................................................................... 176 | 11.3 Oil ...................................................................................................................................................................................... 176 |
| 11.3.1                                                                                                                                                                                              | Seasonality and COVID impacts in monthly oil deliveries ................................................................ 177                                                                        |
| 11.3.2                                                                                                                                                                                              | Monthly oil supplies in 2024.........................................................................................................................182                                            |
| Appendix 1: List of figures ................................................................................................................................................................. 184   | Appendix 1: List of figures ................................................................................................................................................................. 184   |
| Appendix 2: List of tables................................................................................................................................................................... 188   | Appendix 2: List of tables................................................................................................................................................................... 188   |
| Appendix 3: Glossary of abbreviations ......................................................................................................................................... 190                 | Appendix 3: Glossary of abbreviations ......................................................................................................................................... 190                 |
| Appendix 4: Glossary of terms .........................................................................................................................................................192          | Appendix 4: Glossary of terms .........................................................................................................................................................192          |
| Appendix 5: Energy units and conversion factors ....................................................................................................................194                             | Appendix 5: Energy units and conversion factors ....................................................................................................................194                             |
| Appendix 6: Data sources................................................................................................................................................................... 196     | Appendix 6: Data sources................................................................................................................................................................... 196     |
| Appendix 7: Bibliography................................................................................................................................................................... 197     | Appendix 7: Bibliography................................................................................................................................................................... 197     |
| Appendix 8: Energy statistics revisions ......................................................................................................................................... 200               | Appendix 8: Energy statistics revisions ......................................................................................................................................... 200               |
| Appendix 9: Electricity and gas price tables ...............................................................................................................................201                     | Appendix 9: Electricity and gas price tables ...............................................................................................................................201                     |
| Appendix 10: Energy in Ireland data and charts.......................................................................................................................204                            | Appendix 10: Energy in Ireland data and charts.......................................................................................................................204                            |

## Technical Highlights

## Energy-related Emissions

- · Ireland's national energy-related emissions in 2023 were at their lowest level in over 30 years.
- · Energy-related emissions in 2023 were 31.4 MtCO2eq, down 8.3% on 2022-levels.
- · Electricity accounted for a 24.1% of energy emissions, transport for 37.6% and heat for 38.3%.
- · 2023 heat emissions were 12.0 MtCO2eq, the lowest on record, having fallen 3-years in a row.
- · 2023 transport emissions were 11.8 MtCO2eq, 0.3% higher than in 2022.
- · 2023 electricity emissions were 7.6 MtCO2eq, the lowest on record, down 22.0% on 2022 levels.

## Renewable Energy

- · 14.1% of Ireland's primary energy was renewable in 2023 - the highest value to date.
- · Ireland used 1.61 TWh more renewable energy in 2023 than in 2022.
- · Over three-quarters of renewable energy used in 2023 came from wind, biodiesel, and biomass.
- · In 2023, Ireland's RES-Overall result was 15.3%, up from 13.1% in 2022.
- · Ireland's RES-Overall result is amongst the lowest in Europe, and below our 2020 16% baseline target.

## Overall Energy Demand

- · End-user energy demand in Ireland increased by 1.11 TWh in 2023, up 0.8% on 2022 levels.
- · 140.8 TWh of energy was directly consumed by Irish end-users in 2023.
- · 55.6% of all energy consumed in Ireland was oil products, mainly diesel, petrol, and heating oils.
- · Electricity accounted for 22.4% of energy consumption in 2023.
- · The transport sector is the largest consumer of energy, accounting for 43.4% of energy demand in 2023.

## Transport Demand

- · Demand for transport energy increased by 2.61 TWh in 2023, up 4.5% on 2022 levels.
- · Energy demand for international aviation increased by 12.9% in 2023.
- · Energy demand from private car use increased by 5.0% in 2023.
- · Overall, 94.0% of Ireland's transport energy came from fossil fuels in 2023.
- · In 2023 biofuels accounted for 8.5% of energy in road diesel, and 4.2% of energy in road petrol.

## Electricity Demand

- · Electricity demand in Ireland rose by 1.24 TWh in 2023.
- · Commercial services, which include data centres, accounted for 41.2% of electricity demand.
- · The residential sector accounted for 25.6% of electricity demand in 2023.
- · Data centres accounted for 20.1% of all electricity demand in 2023.

## Electricity Supply

- · 44.3% of Ireland's gross electricity supply came from natural gas in 2023.
- · Wind generation provided 33.7% of electricity supply in 2023.
- · Ireland generated 11.7 TWh of renewable energy from wind generation - a new record.
- · Net-imported electricity accounted for 9.5% of electricity supply in 2023.

## Heat Demand

- · Heat demand fell by 2.64 TWh in 2023, with reductions across all economic sectors.
- · 90.2% of Ireland's heat demand was satisfied using fossil fuels in 2023.
- · Ireland's use of renewable energy in heat demand has increased from 5.2% in 2013 to 8.0% in 2023.
- · Ambient heat captured by heat-pumps accounted for 28.9% of all renewable heat.

## 1 Key Trends in Ireland's Energy in 2023 and 2024

SEAI's Energy in Ireland 2024 report provides a definitive record on the supply, transformation, and end-user demand of energy in Ireland. Section 1 of the report identifies key trends in Ireland's energy and relatedemissions to 2023, as well as provisional data from the first 9-months of 2024, to provide insights on:

- · Energy-related emissions.
- · Ireland's EU energy targets.
- · Transport demand and biofuel use.
- · Electricity demand and supply.
- · Heat demand and residential energy demand.

Sections 2 to 11 of the report provide more detailed quantitative descriptions of Ireland's primary energy, energy transformations, final energy demand, energy-related emissions, as well as technical details on active energy targets and policy.

Quantifying and understanding Ireland's energy ecosystem and its related emissions has never been more important. New data and new targets set in 2024 bring strong clarity on the increased level of ambition needed to support Ireland's journey towards a sustainable energy future:

- 1. In February 2024, the Government approved Ireland's Article 4 target under the EU's Energy Efficiency Directive (EED), which requires Ireland to make sincere cooperative efforts to limit 2030's total final energy consumption to 121.55 TWh (10.451 Mtoe) - a reduction of 13% on current levels.
- 2. In July 2024, Ireland published it's updated National Energy and Climate Plan (NECP), increasing Ireland's overall renewable energy share in 2030 from 34.1% to 43.0%, as per the requirements of the third iteration of the Renewable Energy Directive (RED-III).
- 3. At the conclusion of 2024, Ireland will be 80% through the 5-year period of its first National Carbon Budget (2021-2025) with its progress against sectoral emissions ceilings (SECs) becoming clearer.

In this year's Energy in Ireland report, SEAI has moved its energy-related emission reporting from mega tonnes of carbon dioxide (MtCO2) to mega tonnes of carbon dioxide equivalent (MtCO2eq). This methodology update better aligns SEAI's reporting of energy-related emissions to those in the national carbon budgets, and to the EPA's Greenhouse Gas (GHG) Emissions Inventory, compiled in accordance with IPCC guidelines. Emissions quantified in units of MtCO2eq provide a fuller assessment of global warming potential, because they capture the impact of methane and nitrous oxide, as well as those from carbon dioxide.

## 1.1 Energy-Related Emissions in 2023 and 2024

Ireland's national energy-related emissions in 2023 were at their lowest level in over 30 years. Energy-related emissions in 2023 were 31.4 MtCO2eq, down 8.3% on 2022 levels, and lower even than those observed during the height of COVID impacts in 2020. Energy-related emissions fell by over 2.8 MtCO2eq in 2023 - the largest annual reduction observed in 12 years. Ireland's national energy-related emissions have fallen for seven of the last ten years.

Figure 1.1: Time series of Ireland's energy related emissions

<!-- image -->

While energy-related emissions have fallen in recent years, SEAI's National Energy Projections report 2024 shows that the pace of these reductions is not sufficient to deliver on Ireland's legally binding carbon budgets, even under the most optimistic scenarios considered under SEAI's modelling. Ireland's national energy-related emissions, as reported in the EPA's Greenhouse Gas (GHG) Inventory, do not include emissions associated with international aviation or international maritime transport 1 . However, for context, SEAI estimates that Ireland's emissions from international aviation amounted to 3.4 MtCO2eq, equivalent to approximately 11% of national energy-related emissions.

Ireland must rapidly transform its economy and society to one based on sustainable energy technologies, like wind and solar farms, bioenergy, district heating schemes, electric vehicles, and heat-pumps. We must also reduce energy demand by making our technologies and practices more energy efficient, and by making behavioural changes that reduce our day-to-day energy demand across heat, electricity, and transport.

To gain more insight on where emissions reductions have been made, it is useful to breakdown the total national energy-related emissions into transport emissions and electricity emissions, as they are defined in the national carbon budgets, and all other remaining 'heat' emissions 2 . Transport and electricity have well

1 These international emissions are calculated and reported separately in accordance with guidance from United Nations Framework Convention on Climate Change (UNFCCC) and the Intergovernmental Panel on Climate Change (IPCC).

2 All other remaining 'heat' emissions are defined as total energy-related emissions, less electricity emissions, less transport emissions.

defined sectoral emission ceilings (SECs) within the carbon budgets, but there is no explicit target for energyrelated emissions or the heat emissions 3 .

Figure 1.2: Ireland's energy related emissions split into transport emissions and electricity emissions (as they are defined in the national carbon budgets) and all other remaining 'heat' emissions

<!-- image -->

In transport emissions, the impact of COVID-related travel restrictions and work- and school-from-home mandates is evident in the 2020 and 2021 data. Transport emissions in 2023 (11.8 MtCO2eq) were 0.3% higher than those in 2022. They are 4.3% below those observed immediately before COVID but remain higher than those from 2011-2014. Data from the CSO shows that transport activity in Ireland has risen in this 10-year period. The number of kilometres travelled by private cars in 2023 is up by 13% since 2013, and the number of tonne-kilometres by road freight is up by 38%.

Electricity emissions in 2023 were the lowest on record at 7.6 MtCO2eq, down 22.0% on 2022 levels. As discussed further below, this reduction in electricity emissions was due to an increased use of net-imported electricity across international interconnectors with Northern Ireland and Great Britain, and more renewable generation in Ireland.

Ireland's remaining heat emissions in 2023 also reached their lowest level on record at 12.0 MtCO2eq. Heat emissions have fallen for three years in a row and are now 15.8% lower than those in 2020. It is important to recognise that the heating seasons in 2022 and 2023 were relatively warm, and energy prices were relatively high, factors which are likely to have driven down demand for heating fuels, and thus heat emissions. Other factors, like increased rates of home energy upgrades are also likely to have helped reduce emissions.

In 2023, electricity accounted for almost a quarter (24.1%) of energy-related emissions, with transport accounting for a further 37.6%. Heat emissions accounted for the remaining 38.3%. Overall, energy-related emissions in 2023 were down by 2.8 MtCO2eq on the previous year. This net reduction came from a 2.1 MtCO2eq drop in electricity emissions, a 0.7 MtCO2eq drop in heat emissions, and a 0.03 MtCO2eq increase in transport emissions.

3 As per the EPA's GHG inventory, electricity sector emissions under the carbon budgets are given by the sum of emissions from (1) public electricity and heat production (IPCC code 1.A.1.a), (2) solid fuel and other energy industries (IPCC code 1.A.1.c), and (3) fugitive emissions (IPCC code 1.B.1 &amp; 1.B.2). As a result, the electricity emission in the carbon budgets include no emissions from auto-producers (including CHP plants), but do include the emissions associated with peat-briquetting, and fugitive emissions, such as the emissions associated with the production, processing, transmission, and storage of natural gas, etc.

Figure 1.3: Ireland's energy-related emissions in 2023 and compared to 2022, split into transport emissions and electricity emissions (as they are defined in the national carbon budgets) and all other remaining 'heat' emissions

<!-- image -->

## 1.1.1 Electricity Emissions in 2023 and 2024

Approximately three-quarters of the reduced electricity emissions observed in 2023 can be attributed to the increased use of net-imported electricity. Ireland's gross electricity supply in 2023 included 3.0 TWh more net-imported electricity, and 1.0 TWh more electricity from renewables, compared to 2022. Electricity generation from natural gas, coal, oil, and peat in Ireland's power plants all reduced in 2023, and this reduced use of fossil generation led to the 2.1 MtCO2eq reduction in electricity emissions in 2023. Further details on net-imported electricity are given in Section 1.4.2 and Section 4.4.2.

Figure 1.4: 2022 to 2023 changes in Ireland's gross supply of electricity and its impact on electricity generation emissions (NRW: Non-renewable wastes)

<!-- image -->

<!-- image -->

Ireland's electricity emissions under the national carbon budgets are officially determined by the Environment Protection Agency (EPA) through the Greenhouse Gas (GHG) Inventory. The EPA have reported electricity GHG emissions of 9.9 MtCO2eq, 9.7 MtCO2eq, and 7.6 MtCO2eq for the first 3-years of the first carbon budget (2021-2025), respectively. Based on its monthly surveys of energy suppliers, SEAI can make a provisional extrapolation of Ireland's electricity emissions to the end of 2024. This best estimate indicates 6.9 MtCO2eq of electricity emissions could occur in 2024, which would be down 8.2% on 2023 levels.

If SEAI's estimate for 2024 proves accurate, then only 5.9 MtCO2eq of emissions would remain available for electricity in 2025. Emissions above this level will result in electricity exceeding its sectoral emission ceiling (SEC) of 40 MtCO2eq in the first carbon budget. For reference, the electricity sector's SEC in the second carbon budget (2026-2030) is 20 MtCO2eq - precisely half of that in the first budget - and equivalent to a nominal annual emission of just 4.0 MtCO2eq.

Figure 1.5: Reported and estimated electricity emissions in the first carbon budget

<!-- image -->

## 1.1.2 Transport Emissions in 2023 and 2024

The EPA have reported transport GHG emissions of 11.1 MtCO2eq, 11.8 MtCO2eq, and 11.8 MtCO2eq for the first 3-years of the first carbon budget (2021-2025), respectively. Based on its monthly surveys of energy suppliers, SEAI can make a provisional extrapolation of Ireland's transport emissions to the end of 2024. This best estimate indicates 11.7 MtCO2eq of transport emissions in 2024, down by 0.6%, but almost unchanged from the annual emissions observed in both 2022 and 2023.

If SEAI's estimate for 2024 proves accurate, then only 7.6 MtCO2eq of emissions would remain available for transport in 2025. Emissions above this level will result in transport exceeding its SEC of 54 MtCO2eq. Achieving transport emissions of 7.6 MtCO2eq in 2025 would require an unprecedented annual reduction of 35%. For reference, transport emissions fell by just under 16% in 2020 due to COVID-related travel restrictions and work-from-home mandates. The transport sector's SEC in the second carbon budget (20262030) is 37 MtCO2eq, which is equivalent to nominal annual emissions of just 7.4 MtCO2eq.

## Figure 1.6: Reported and estimated transport emissions in the first carbon budget

<!-- image -->

Barring an unprecedented externality, Ireland's transport emissions will exceed their sectoral emission ceiling in the first carbon budget. Emissions that exceed the first carbon budget are carried-over into the second carbon budget, where they will need to be addressed by even more intensive policies and measures. Acting immediately to reduce transport emissions - and all other emissions - is essential to getting back on target trajectory.

While SEAI can make extrapolations of electricity and transport emissions to the end of 2024, it cannot confidently generate an estimate for heat emissions in 2024. This uncertainty comes from the unknown impact of the Q4-2024 heating season on demand, and relatively poor responses to SEAI's monthly surveys from solid fuel suppliers. In 2024, additional functions were conferred on SEAI through three new statutory instruments, giving it a new formal legal basis to direct relevant suppliers and undertakings to provide energy data to SEAI, which will strengthen Ireland's energy reporting going forward. SEAI will determine 2024 heat emissions and total energy-related emissions once data from its annual surveys are returned, and once public administrative data from the EPA, the Central Statistics Office (CSO), and Revenue Commissioners, becomes available.

## 1.2 Ireland's European Energy Targets to 2030

Ireland has 2030 EU energy targets on both the share of renewable energy in its energy portfolio, and the total energy demand of that portfolio. These dual targets act together to improve the quality of energy in Ireland, by increasing the share of renewable energy being used, and to reduce the quantity of energy needed in Ireland, by increasing efficient use of energy through better technology and behaviours.

## 1.2.1 Ireland's Renewable Energy and EU Targets

Ireland's total primary energy consumption in 2023 was 163.8 TWh, down 1.8% on the previous year. Total primary energy is the amount of 'raw' energy that Ireland needs to satisfy end-user demand across the economy. Primary energy includes all the energy that goes directly to end-users, as well as crude oil that is first processed in Ireland into oil-products, like diesel and petrol used on our roads, and the gas and coal fed into power plants to generate electricity.

While Ireland's primary energy demand in 2023 was the most renewable it has ever been, with 23.0 TWh of renewables in our primary energy mix, 82.7% of Ireland's energy came from fossil fuels. 14.1% of Ireland's primary energy was renewable in 2023, with fossil fuel remaining the dominant source of Ireland's energy. However, the relative contribution of fossil fuel is falling, down from 91.4% in 2013, and 97.7% in 2003.

Figure 1.7: Time series percentage breakdown of Ireland's primary energy consumption by fossil fuel, renewable energy, and other sources (i.e. net-imported electricity and non-renewable wastes)

<!-- image -->

Ireland used 1.61 TWh more renewable energy in 2023. This net increase came from broad increases in the use of biodiesel, solar PV, wind generation, hydro-electric generation, ambient heat capture from heatpumps, bioethanol, and renewable wastes. The largest individual increase in renewable energy use came from higher use of biodiesel, driven by increased biofuel blending into road diesel (moving from 6.5% in 2022 to 8.5% in 2023). The second largest individual increase came from solar PV, driven by the connection of new utility-scale solar-farms to the national grid in late-2022 and early-2023, as mentioned above. Not all sources of renewable energy saw increased use in 2023. Ireland used 0.55 TWh less biomass than in 2022. This reduction was mainly due to reduced use of biomass in public thermal power plants, coupled with reduced direct end-user consumption of biomass in both the industry and residential sectors.

Figure 1.8: 2022 to 2023 changes in Ireland's use of renewable energy

<!-- image -->

Ireland's 23.0 TWh of renewable energy used in 2023 came from a broad portfolio of technologies and sustainable energy products. The three largest sources of renewable energy in Ireland are wind generation of electricity, the biodiesel blended into the 'road diesel' sold in garage forecourts, and biomass. While some of this biomass goes to electricity generation in public thermal power plants and combined heat and power (CHP) plants, more than half is consumed directly by consumers. Together, these three sources account for just over three-quarters of all renewable energy used in Ireland in 2023.

Figure 1.9: Breakdown of the 23.0 TWh of renewable energy used in Ireland in 2023

<!-- image -->

Heat pumps, capturing renewable ambient heat, accounted for 4.8% of renewable energy in 2023, more than came from hydro-electric generation, and are one of the fastest growing sources of renewables in Ireland. At the end of 2023, there were approximately 112,000 dwellings with heat pumps, up from 80,000 at the end of 2022.

Solar photovoltaic (PV) generation in Ireland also experienced a marked increase. Solar PV delivered 0.65 TWh of renewable electricity in 2023, up 335% on the previous year. This rapid increase came from the connection of several utility-scale solar-farms to the national grid in late-2022 and early-2023. Solar PV generation from these utility-scale solar-farms has already exceeded that of all rooftop solar PV generation. In 2023, just under two-thirds of Ireland's solar PV generation came from utility-scale solar-farms. Based on its monthly surveys of energy suppliers, SEAI provisionally estimates that utility-scale solar-farms will account for approximately three-quarters of all solar PV generation in 2024.

Ireland's renewable energy share, and that of all EU member states, is calculated and monitored by the European Commission under different iterations of the Renewable Energy Directive (RED). The renewable energy share of EU member states is monitored through four key metrics:

• RES-Overall

Overall renewable energy share.

• RES-E

Renewable energy share in electricity.

• RES-T

Renewable energy share in transport.

• RES-H Renewable energy share in heating (and cooling).

The methodology for calculating the four RES results and setting their targets, which can include applying multipliers, limits, normalisations, and sustainability-checks on specific energy sub-products, is specified through the relevant iteration of the Directive for a given year. Ireland's RES-overall targets out to 2030 are specified in the National Energy Climate Plan (NECP), prepared under the EU Regulation on the Governance of the Energy Union, RED-II and RED-III. In addition to a 'baseline' RES-Overall target of 16% in all years to 2030, Ireland has a series of reference points for specific milestone years:

• 2022

19.3% (RED-II).

• 2025 27.6% (RED-III).

• 2027

33.6% (RED-III).

• 2030

43.0% (RED-III).

In 2023, Ireland's RES-Overall result was 15.3%, up from 13.1% in 2022. According to data published on the Eurostat database, Ireland's RES-Overall result in 2023 is amongst the lowest in Europe. As per data available on the 5 th of December 2024, Ireland has the fourth lowest result in Europe, after Malta, Belgium, and Luxembourg. However, some of these countries may yet opt to use statistical transfers to increase their 2023 RES-Overall result.

Ireland's RES-overall result in 2023 was the highest achieved to date without the use of statistical transfers. However, the overall result in 2023 remains below Ireland's baseline target of 16%, and below the indicative trajectory set by the milestone years reference points. Ireland purchased 3.5 TWh of renewable energy statistical transfers from Denmark and Estonia for €50 million to comply with its 2020 RES-Overall target. The future cost of statistical transfers needed to comply with Ireland's 2030 target, and milestone targets out to 2030 remains unclear, but is likely to be substantially higher than those incurred in 2020.

Figure 1.10: Ireland's overall renewable energy share results and targets under RED-II and RED-III

<!-- image -->

Further details on Ireland's RES-Overall result, and its renewable energy share results in electricity, transport, and heat can be found in Section 8.2.

## 1.2.2 Ireland's Energy Demand and EU Targets

End-user energy demand in Ireland increased by 1.11 TWh in 2023, up 0.8% on 2022 levels. This net-increase in energy demand came from increased demand for oil, electricity, renewables, and non-renewable waste (NRW), coupled with decreased demand for natural gas, coal, and peat.

Figure 1.11: 2022 to 2023 changes in Ireland's energy consumption by energy product

<!-- image -->

In 2023, 140.8 TWh of energy was directly consumed by end-users in the Irish economy. Over half (55.6%) of all energy consumed was oil products, mainly petrol, diesel, and heating oils. Electricity accounted for just under a quarter (22.4%) of energy consumption in 2023. Coal and peat each accounted for 1.2% of Ireland's energy consumption in 2023.

Figure 1.12: Breakdown of Ireland's 2023 energy consumption by energy product

<!-- image -->

Ireland experienced increased energy demand from the transport and commercial service sectors in 2023. Coupled with decreased energy demand from the residential, industry, agriculture-and-fisheries, and public service sectors. Energy demand for transport increased by 2.61 TWh or 4.5% in 2023, while energy demand from the commercial service sector increased by 1.07 TWh or 6.9%.

## Figure 1.13: 2022 to 2023 changes in Ireland's energy consumption by sector

<!-- image -->

The transport sector remains the largest consumer of energy and accounted for 43.4% of all end-user energy demand in 2023. Energy consumption in the residential sector accounted for a further 21.1% of demand, followed by the industry sector with 17.1%. Combined, the transport and residential sectors account for almost two-thirds of all end-user energy demand.

Figure 1.14: Breakdown of Ireland's 2023 energy consumption by sector

<!-- image -->

Under Article 4 of the Energy Efficiency Directive (EED), the EU has set itself a binding target of reducing total final energy consumption by 763 Mtoe by 2030. In February 2024, the Irish government approved Ireland's Article 4 target under the EED and submitted this as part of Ireland's National Energy and Climate Plan (NECP). Under this target and Article 4 of the EED, Ireland is required to make sincere cooperative efforts to limit its total final energy consumption  to 121.55 TWh (10.451 Mtoe) by 2030. This target represents a 13% 4 reduction on current energy consumption levels and will require reducing Ireland's energy demand to its lowest level in 25 years. Ireland's progress against its EED target is subject to monitoring by the European Commission through Ireland's NECP.

4 The definition of the total final energy consumption used for Article 4 of the EED excludes the use of ambient heat captured by heatpumps, and so differs slightly from the total final energy consumption cited in other statistics.

## Figure 1.15: Ireland's total final energy consumption under the EED and its Article 4 target for 2030

<!-- image -->

Aligning national policies and measures to the 2030 EED target will support sustainable technologies and behaviours that reduce energy demand. Our need to reduce energy demand further motivates the adoption of electric-vehicles (EVs), which are more efficient than internal combustion engine (ICE)-vehicles, and heatpumps, which are more efficient than gas- and oil-boilers. The EED target supports the need for more active travel and use of public transport, as well as the roll-out of further home energy upgrades.

## 1.3 Transport in 2023 and 2024

The transport sector is the single largest source of energy demand in the Irish economy, and one of the largest sources of GHG emissions in Ireland. In 2023, transport accounted for just over 43% of Ireland's energy demand, and over 21% of Ireland's total GHG emissions.

## 1.3.1 Transport Energy Demand

Demand for transport energy increased by 2.61 TWh in 2023, up 4.5% on 2022 levels. The net-increase in transport energy demand was mainly led by increases in fuel use for international aviation and private car use. Fuel demand for international aviation increased by 1.52 TWh or 12.9% in 2023, while energy demand from private car use increased by 1.16 TWh or 5.0%.

Figure 1.16: 2022 to 2023 changes in Ireland's transport energy demand by sub-sector

<!-- image -->

Private cars remain the largest consumer of transport energy and accounted for 39.9% of all transport energy demand in 2023. The second largest transport sub-sector is aviation, which accounted for 21.9% of transport energy demand. In total, road transport accounted for just over three-quarters of all transport demand. Sea and rail accounted for 1.8% and 0.8% of transport energy demand in 2023, respectively.

Figure 1.17: Breakdown of Ireland's 2023 transport energy demand by sub-sector

<!-- image -->

Reducing the number of private car journeys, especially short driver-only journeys, will have a significant impact on transport energy demand and transport emissions. This reduction can be achieved by supporting opportunities to substitute private car use with public transport or active travel options. Our purchasing habits also impact the volume of freight moving on our roads and needs to be considered.

## 1.3.2 Renewable Energy in Transport

Over half (57.4%) of transport energy demand in 2023 came from fossil-based diesel. The second largest source of transport demand came from jet kerosene, which accounted for over one-fifth (21.8%) of transport energy demand. Ireland consumes over 50% more jet kerosene than it does petrol, which accounted for 14.1% of transport demand in 2023. Electricity accounted for 0.5% of Ireland's transport energy demand in 2023. Overall, 94.0% of Ireland's transport energy came from fossil fuels in 2023.

Figure 1.18: Breakdown of Ireland's 2023 transport energy demand by energy sub-product

<!-- image -->

Diesel is the primary energy product powering Ireland's private cars, road freight vehicles (heavy goods vehicles and light goods vehicles) and well as public passenger vehicles. The term 'road diesel' describes the diesel fuel mix available for purchase at garage forecourts across the country. Road diesel is a blend of fossilbased diesel and sustainable biofuel components, including fatty acid methyl esters (FAME), hydro-treated vegetable oil (HVO), and co-processed HVO. The biofuel blending of these sustainable compounds into road diesel helps reduces transport emissions by substituting-out some fraction of the fossil-based diesel.

In 2023, 8.5% of road diesel's energy content came from biofuels, up from 6.5% in 2022. Based on monthly surveys returns up to September 2024, SEAI can make a provisional extrapolation of biofuel blending in road diesel to the end of 2024. SEAI's best estimate is that 9.3% of road diesel's energy content will come from biofuel in 2024, setting a further record high.

Ireland's road petrol also consists of a blend of fossil-based petrol and sustainable biofuel, mainly bioethanol. After remaining relatively constant around 3.2% from 2016 to 2022, the renewable energy content in road petrol increased to 4.2% in 2023. SEAI's best estimate is that 5.8% of road petrol's energy content will come from biofuel in 2024, setting a new high.

## Figure 1.19: Energy content of biofuel blending into road diesel shown on a scale of 0-100% and a scale of 90-100% for improved data visualisation

<!-- image -->

In 2023, Ireland used 36.7 TWh of road diesel, up 1.1% on the 36.3 TWh of road diesel used in 2022. However, because of the higher biofuel blend-rate used in 2023 compared to 2022, Ireland used less fossilbased diesel in 2023. Ireland used 33.6 TWh of fossil-based diesel in 2023, down 1.0% on 2022 levels. So, while demand for road diesel was up in 2023, emissions from road diesel were down. 2023 is the first year in which this 'inversion' effect has been observed. The effect arises due to the coincidence of (1) a large increase in biofuel blend-rate, and (2) a modest increase in demand for road diesel, both falling in the same calendar year.

While reductions in transport emissions from biofuel blending are welcome, it is important to acknowledge that over 90% of Ireland's road diesel, and 94% of road petrol, still comes from fossil-fuels, and both act as considerable sources of Ireland's emissions. Biofuel blending can help reduce transport emissions, but it is only a partial solution. Internationally, there is limited availability of sustainable biofuel feedstock, and unchecked demand for biofuel production crops can act to displace crops needed for food production. Additionally, there are technical limits on the blend-rate of certain biofuels in standard road vehicles. For example, bioethanol is limited to 10% by volume in EN 228 gasoline, and conventional FAME-based biodiesel is limited to 7% by volume in EN 590 diesel.

## Figure 1.20: Recent demand for road diesel broken down by fossil and biofuel components

<!-- image -->

94% of transport energy came from fossil-fuels in 2023. We must urgently (1) avoid unnecessary trips, especially short driver-only trips in private cars, (2) shift fossil-based travel to transport and modes of active travel, such as cycling and walking, and (3) improve the national vehicle fleet by switching fossil-based ICEvehicles to EVs.

## 1.4 Electricity in 2023 and 2024

Electricity accounted for just over 22% of Ireland's energy demand in 2023, with just over 40% of that electricity coming from renewable sources. Renewable electricity is by far the largest vector of renewable energy into Ireland's homes, offices, and businesses.

## 1.4.1 Electricity Demand

Electricity demand in Ireland rose by 1.24 TWh in 2023. This net-increase was strongly led by a 1.15 TWh increase in demand from the commercial services sector, which includes data centres. While total electricity demand increased by 4.1% in 2023, electricity demand from the commercial services sector increased by 9.7%. Smaller increases in demand were also observed in the transport, industry, and public service sectors, coupled with decreases in the residential and agriculture-and-fisheries sectors.

Figure 1.21: 2022 to 2023 changes in Ireland's electricity demand by sector

<!-- image -->

End-user electricity demand in 2023 was 31.6 TWh. The commercial services sector continues to lead the economy's demand for electricity, accounting for 41.2% in 2023. The residential sector accounted for just over one-quarter (25.6%) of electricity demand, followed by the industry sector with 21.2%. In 2023, 1.2% of Ireland's electricity demand came from the transport sector, from electric vehicles, and Dublin's LUAS and DART commuter services.

Figure 1.22: Breakdown of Ireland's electricity demand by sector

<!-- image -->

Ireland's demand for electricity has grown every year for the last 10 years. The dominant driver of this longterm increased demand has been the commercial services sector. Since 2013, electricity demand from the commercial services sector has increased by 79.1%. By way of comparison, across the same 10-year period, residential demand for electricity has increased by just 1.7%, and industry demand has increased by 6.7%.

The key driver of increased electricity demand in the commercial services sector has been Ireland's data centres. Data published by the CSO shows that electricity demand from data centres has increased by 412% since 2015, which is the first year for which the CSO has published data-centre specific demand. In 2023, data centres accounted for just over one-fifth (20.1%) of all electricity demand in Ireland. For reference, when it announced a new scheme for rating the sustainability of data centres in 2024, the European Commission noted that data centres accounted for approximately 3% of the EU's electricity demand.

Figure 1.23: Electricity demand by from data centres compared to electricity demand from all other sectors of the Irish economy

<!-- image -->

Outside of data centres, the combined net-demand for electricity from all other sectors of the Irish economy has been relatively constant. Outside of data centres, Ireland's demand for electricity has only grown by 2.8% since 2015. Data centres are responsible for 88.2% of the increased electricity demand observed in the Irish economy since 2015.

Additional electricity demand must be outpaced by increased installed capacity for renewable generation, if we are to decarbonise Ireland's electricity system further, all else being equal. Electricity demand must be managed to ensure that Ireland stays within the confines of our carbon budgets, sectoral emission ceilings, and energy demand reduction targets.

## 1.4.2 Electricity Supply

Ireland's gross electricity in 2023 was 34.6 TWh. Gross electricity supply includes all electricity generation by utility-scale power plants (public thermal and CHP) as well as all micro-to-small scale electricity generation, including rooftop solar PV. Gross supply includes the-net import of electricity across international interconnectors but excludes the transmission and distribution losses associated with moving electricity across the national grid, and the cycle-losses incurred from energy storage, i.e. pumped or battery-storage.

In 2023, 44.3% of Ireland's gross electricity supply came from natural gas, followed by 33.7% from wind generation, and 9.5% from the net-import of electricity from Northern Ireland and Great Britain. Combined these three sources accounted for 87.5% of Ireland's electricity supply. In total, fossil fuel generation accounted for 48.9% of the electricity supply, with renewable generation accounting for 40.7% of electricity

supply. Other sources, consisting of net-imports and generation from non-renewable wastes, accounted for the remaining 10.4% of supply in 2023.

Figure 1.24: Percentage breakdown of Ireland's gross electricity supply

<!-- image -->

<!-- image -->

On a percentage basis, Ireland's electricity supply has never had less fossil fuel generation or used more netimported electricity. 2023 was the first year in which fossil fuel generation accounted for less than half of Ireland's gross electricity supply.

Based on monthly survey returns to the end of September 2024, the breakdown of electricity supply in 2024 appears to broadly mirror that of 2023, with increased use of net-imported electricity and renewable generation acting to reduce fossil generation in Ireland. However, until data is available from the 'high wind' months in Q4-2024, it is not possible to confidently generate a 2024 breakdown.

Despite electricity demand increasing steadily for the last 10-years, electricity generation in Ireland has fallen for the last two years. Electricity generation in Ireland has fallen since Q1-2023 due to an increased use of net-imported electricity flowing through international interconnectors to Northern Ireland and Great Britain. As noted above, 9.5% of Ireland's gross electricity supply came from net-imported electricity in 2023. Based on monthly surveys returns to the end of September 2024, it is evident that Ireland will use even more netimported electricity in 2024. SEAI provisionally estimates that net-imported electricity will account for approximately 14% of Ireland's electricity supply in 2024.

Figure 1.25: Monthly net-imports of electricity into Ireland with a 12-month moving average

<!-- image -->

The relative contribution of net-imported electricity to Ireland's electricity supply can best be illustrated by monthly data on utility-scale supply. This data shows that indigenous electricity generation in Ireland has been the principal source of electricity supply for every month on record. The data also shows some extended periods, e.g . May 2013 to June 2015, when net-imports consistently made contributions to Ireland's electricity supply. Where the data shows values greater than 100%, Ireland was a net-exported of electricity to Northern Ireland in that month.

Recently, since January 2023, net-imports have accounted for an average of 12.4% of utility-scale supply. For 15 of the 21 calendar months between January 2023 and September 2024, net-imports accounted for more than 10% of utility-scale electricity supply. The largest contribution from net-imports to date occurred in June 2024, when net-imports accounted for 20.8% of Ireland's utility-scale electricity supply.

Figure 1.26: Relative contributions net-imported electricity and indigenous generation to Ireland's utility-scale supply of electricity

<!-- image -->

Strong interconnection of national grids can help decarbonise electricity by providing access to low carbon imported electricity when renewable generation from wind and solar in Ireland is low. Similarly, when wind and solar generation in Ireland is high, and might be subject to curtailment, renewable electricity can be exported. We must ensure that the electricity market incentivises the generation and interconnector flow of renewable electricity.

## 1.4.3 Renewable Energy in Electricity

In 2023, Ireland generated 11.7 TWh of renewable energy from wind generation, exceeding the previous record of 11.6 TWh set in 2020 by 0.1 TWh. Ireland's wind generation comes from the thousands of wind turbines installed around the country. In 2023, Ireland had 4.74 GW of installed wind capacity, up 4.5% on the previous year.

SEAI's provisional estimate for installed wind capacity in 2024 is 4.85 GW, based on Eirgrid data to the end of August, and ESB-Networks data to the end of September. When Eirgrid and ESB-Networks release full data for the calendar year, the installed capacity for 2024 is likely to be higher than this provisional estimate. A relatively large fraction of a new capacity can be added in the fourth-quarter of the year, after construction during the summer, and commissioning during the autumn months.

Figure 1.27: Ireland's installed wind capacity with 2024 estimates, projections to 2030, CAP targets

<!-- image -->

Ireland has a 2025 CAP target of 6 GW for installed wind capacity, and 2030 CAP targets of 9 GW and 5 GW for onshore and offshore capacity, respectively. SEAI's projections under the 'with additional measures' (WAM) scenario indicate a total installed capacity of 11.2 GW by the end of 2030. This WAM scenario is defined to include the levels of variable renewable capacity required to achieve Ireland's renewable energy share of electricity (RES-E) target of 80% for 2030, while accounting for future growth in electricity demand, and other variables affecting the RES-E results.

Over the last 10-years, Ireland has added wind capacity at an average rate of 0.26 GW per annum, although this has dropped to a rate of 0.14 GW over the last 5-years. To align to the pace of the WAM projections needed to deliver on the 80% RES-E target, the roll-out of onshore wind capacity needs to return to the rate

previously achieved between 2016 and 2019. And offshore wind projects, delivering annual increases in installed capacity of between 0.8 GW and 1.4 GW, need to be in place before the end of 2030.

Increasing wind generation through added wind infrastructure is key to decarbonising Ireland's electricity supply. The decarbonisation of electricity maximised the positive impact of sustainability technologies like heat pumps and electric vehicles. The recent slow-down in added wind capacity is impacting Ireland's transition to a sustainable energy future. Renewable capacity must be added faster than electricity demand increases. We must do everything we can to support the roll-out of both onshore and offshore wind and grid-connected solar PV capacity.

The amount of renewable energy from solar photovoltaic (PV) electricity generation in Ireland increased significantly in 2023. Ireland generated 0.65 TWh of solar PV, up 335% on 2022 levels. The rapid increase in solar PV was due to the connection of several utility-scale solar farms to the grid in later 2022 and early 2023. In just one year, electricity generation from these large-scale solar farms exceeded that from all rooftop solar generation. In 2023, just under two-thirds of all solar PV generation in Ireland came from solar farms.

Figure 1.28: Summary of Ireland's solar PV generation, showing contributions from utility-scale solar farms and rooftop solar panels

<!-- image -->

Solar PV exhibits a strong seasonal variation, peaking in June or July. The seasonal profile of solar PV is complementary to that of wind, with solar PV highest during the summer months, when wind is at its lowest, and vice versa. A balanced blend of solar PV and wind capacity therefore smooths the seasonal variation associated with renewable generation, reducing the need for fossil generation.

SEAI's best estimate for solar PV generation from solar farms in 2024 is 0.73 TWh, up 78% on 2023 levels. This means that total solar generation in 2024 may reach 1 TWh, with approximately three-quarters of that coming from utility-scale solar farms. Although not yet certain, it is likely that Ireland will generate more electricity from solar PV than from coal in 2024 for the first time.

## 1.5 Heat and Residential Demand in 2023 and 2024

For the purposes of national energy statistics, and to align with European energy reporting, heat demand is defined as total energy demand, less electricity demand, less transport demand. Heat accounted for over 34% of Ireland's energy demand in 2023.

## 1.5.1 Heat Demand

Heat demand in Ireland fell by 2.64 TWh in 2023. Heat demand reduced across all economic sectors residential, industry, agriculture-and-fisheries, public services, and commercial services. Just under half of the overall heat demand reduction came from the residential sector.

## Figure 1.29: 2022 to 2023 changes in heat demand by sector

<!-- image -->

Heat demand in 2023 was 48.4 TWh. The residential sector accounted for 44.6% of heat demand, followed by the industry sector, which accounted for 35.8%. Almost one-quarter of industrial heat goes to the production of food and beverages. Combined, the residential and industry sectors accounted for just over 80% of Ireland's heat demand.

Figure 1.30: Breakdown of Ireland's 2023 heat demand by sector

<!-- image -->

The 2.64 TWh reduction in Ireland's heat demand was led by a 1.68 TWh reduction in demand for natural gas, with smaller reductions in coal, oil, and peat. Ireland used 0.19 TWh more non-renewable wastes (NRWs) and 0.003 TWh more renewable energy for heating in 2023.

## Figure 1.31: 2022 to 2023 changes in heat demand by energy product

<!-- image -->

Combined, oil (43.7%) and natural gas (39.5%) accounted for over 83% of Ireland's heat demand. 2023 is the first year in which renewable energy has provided more heat than coal and peat combined.

## Figure 1.32: Breakdown of Ireland's 2023 heat demand by sector

<!-- image -->

## 1.5.2 Renewables in Heat

Ireland's heat demand remains dominated by fossil fuels. In 2023, 90.2% of heat demand was satisfied using fossil fuels. This is down just 3.8 percentage points in the last 10-years, from 94.0% in 2013. In the same period, Ireland's use of renewable energy for heat has increased from 5.2% in 2013 to 8.0% in 2023. The use of other heat sources, such as non-renewable wastes has increased from 0.9% in 2013 to 1.8% in 2023.

<!-- image -->

Figure 1.33: Time series breakdown of heat demand by fossil fuels, renewable energy, and other sources (i.e. non-renewable waste)

<!-- image -->

Historically, most of Ireland's renewable heat has come from biomass. In 2003, biomass accounted for 93.5% of all renewable heat in Ireland, but this has dropped to 45.6% in 2023, as ambient heat from heat-pumps and the use of renewable wastes has increased. In 2023, ambient heat from heat-pumps accounted for 28.9% of all renewable heat, up from 24.3% in 2022.

Figure 1.34: Time series breakdown of renewable heat demand by sub-product

<!-- image -->

## 1.5.3 Residential Energy Demand

Ireland's residential energy demand decreased by 1.44 TWh in 2023, down 4.6% on 2022 levels. This netdecrease in residential demand came about from demand reductions in natural gas, coal, peat, electricity, and oil. The only increase in residential energy demand in 2023 came from renewables, mainly driven by the increased use of heat-pumps in new builds and upgraded homes.

## Figure 1.35: 2022 to 2023 changes in Ireland's residential energy demand

<!-- image -->

In 2023, Ireland's residential sector consumed 29.6 TWh of energy. Heating oil, particularly kerosene, remains the most significant energy product used in Irish homes and accounted for 40.9% of all residential demand. Electricity accounted for over one-quarter (27.3%) of residential demand, followed by 18.2% from natural gas. The renewable ambient heat captured by heat-pumps accounted for 2.8% of residential energy demand in 2023. At the end of 2023, there were approximately 112,000 dwellings with heat pumps, up from 80,000 at the end of 2022. A further 22,000 heat pumps were added in the first nine months of 2024, this a combination of new dwellings and retrofits 5 .

Ireland's residential heat demand remains particularly carbon intense. Switching homes in towns and cities to district heating, and adding renewably powered heat pumps to other homes, will be key solutions to decarbonising the residential sector. Reducing residential heat demand in existing homes through home energy upgrades will also be critical.

## Figure 1.36: Breakdown of Ireland's 2023 residential energy demand by energy product

<!-- image -->

2023 was the third year in a row in which residential energy demand has fallen, reducing to levels last observed in 1998. Residential demand for the three key energy products of oil, electricity, and natural gas were all down in 2023, compared to 2020 levels. Oil demand was down 25.1%, electricity demand was down

5 Figures taken from SEAI's BER database.

7.0%, and gas demand was down 21.2%. Note that residential energy demand in 2020 was particularly high due to COVID-related work- and school-from-home mandates.

## Figure 1.37: Time series of residential energy demand by energy product

<!-- image -->

The observed reduction in residential energy demand in the last few years has likely been driven by multiple competing factors - high energy prices, weather effects, behavioural effects such as the post-COVID shift of return-to-office after an extended period of work-from-home, the impact of new builds and home energy upgrades on heating efficiency and increases in Ireland's population.

Decoupling the weighted-effect of these different drivers on residential heat demand is extremely challenging. However, in terms of a high-level qualitative explanation, two factors are likely to have played a key role in the observed reduction in residential energy demand:

- · The reduced need for home heating, due to higher average external ambient temperatures.
- · The affordability of home heating, due to periods of relatively higher energy prices

Met Éireann publishes daily weather and temperature data for multiple weather stations around Ireland. This data includes the number of heating-degree-days (HDDs) per month. The number of HDDs that fall in a calendar year provides a simple high-level metric for quantifying how often and how intensely homes around Ireland need to be heated that year.

While 2019, 2020 and 2021 all had close to the long-term average number of HDDs for Ireland, 2022 had 6.9% less HDDs than average, and 2023 had 12.6% less than average. This means that 2023 and 2022 were both warmer than average, so homes required less heating in those years, compared to 2020. As a result, it is expected that residential energy demand in 2023 and 2022 would be lower than in 2020.

Figure 1.38: Percentage Difference in annual Heating Degree Days (HDDs) from long term average

<!-- image -->

The unit prices of all the three major energy products used in the residential sector - oil, electricity, and natural gas - were higher in 2022 and 2023 compared to their 2020 levels. The unit price of kerosene in 2023 was 82.9% higher than in 2020, while the effective unit price of household electricity was up by 35.1%, and the effective unit price of household gas was up by 125.9% 6 . Through price elasticity effects, these substantial increases in residential energy prices are likely to have acted to reduce residential energy demand in 2023 and 2022 compared to 2020.

Figure 1.39: Annual average residential energy prices in Ireland for kerosene, electricity, and natural gas

<!-- image -->

SEAI's provisional monthly data from energy suppliers indicates that residential energy demand in 2024 may be increasing on 2023-levels. Residential gas demand was 5.4% higher in the first 9-months of 2024 compared to the same period in 2023, and monthly kerosene deliveries (95% or which goes to the residential market) were 3.6% higher in the first 9-months of 2024 compared to the same period in 2023. While these are positive leading indicators of increased residential energy demand in 2024, until data is available from the Q4-2024 heating season, it is not possible to confidently generate an extrapolation for 2024.

6 In line with Eurostat guidelines, SEAI uses effective unit price (EUP) for the international reporting of energy prices. EUP sums-up not only the unit cost of energy, but also any standing charges, taxes, and levies that are applied. As a result, EUP is typically higher than the 'unit price' cited by electricity and gas suppliers but is a truer holistic measure of how much consumers are being charged per unit of energy consumed. The EUP of electricity includes the price reducing effects of the series of €200 and €150 account credits applied to residential electricity bills from 2022 to 2024. For further details, see - https://www.seai.ie/data-and-insights/seai-statistics/prices

## 2 Overview of energy data

## 2.1 The National Energy Balance

Following the formal establishment of the Energy Policy Statistical Support Unit (now called Energy Statistics Team, SEAI) in 2002, the Department of Communications, Marine and Natural Resources transferred the responsibility for the collection of data, to meet Ireland's reporting obligations in relation to energy statistics, to the new unit.

The information in this report is largely based on Ireland's 2023 National Energy Balance [1] and the preceding annual energy balances back to 1990. These energy balances quantify the flow and transformation of energy sources from primary supply to final consumption, and profile that consumption across different sectors of the economy.

A simplified schematic for the energy balance flow is illustrated in Figure 2.1. National energy balances are the definitive sources for constructing other normalised national energy indicators, such as energy intensity, energy efficiency, and energy-related greenhouse gas emissions. A Sankey diagram showing the flow of energy in Ireland 2023 is provided in Figure 2.2.

Figure 2.1: Main energy flows in Ireland

<!-- image -->

## Figure 2.2: Energy Flow in Ireland in 2023 (TWh)

<!-- image -->

The energy balance is organised into three main parts, which are discussed in the following subsections:

- · Primary energy  - section 3 provides data on the production ( i.e. extraction of energy from natural sources), imports, export and stock changes of energy in Ireland.
- · Energy transformation - section 4 provides data on the transformation of energy from one to another ( e.g. electrical power generation, oil refining)
- · Final energy consumption - section 5 provides data on the type and quantities of energy consumed in each sector of the economy.

SEAI constructs the expanded energy balance for each fuel or energy product, such as gasoline, lignite, biomass and electricity. There are currently 34 fuels listed in the expanded balance. The number of fuels and energy products included in the balance has increased over the years as Ireland's energy mix has diversified. For analysis and presentation purposes, fuels can be combined into seven aggregated fuel or energy types:

- · Coal
- · Peat
- · Oil
- · Natural gas
- · Renewables
- · Non-renewable waste
- · Electricity

In general, the data in this report is presented for aggregated energy types. Short versions of the energy balance in units of terawatt-hours (TWh) and kilotonnes of oil equivalent ( ktoe) are presented in Appendix 10. A more detailed, expanded balance showing data on each sub-energy type is available on the SEAI website at https://www.seai.ie/data-and-insights/seai-statistics/key-publications/national-energy-balance/.

The data in the national energy balances are informed by survey responses received from approximately 300 organisations, including energy producers, import/export companies and energy supply companies. Besides populating the energy balance, SEAI uses these surveys to fulfil Ireland's energy statistics reporting obligations to Eurostat (EU Energy Statistics Regulation (EC 1099/2008)) [2] and the International Energy Agency (IEA).

To ensure that the best possible information is always available to Government and other users, SEAI employs a policy of continuous improvement regarding historic energy balances, updating these with data revisions and new methodologies as they become available. An overview of the revisions and amendments to energy statistics made during 2024 is provided in Appendix 8.

## 2.2 Additional data

To help policymakers, analysts, researchers, and the public better understand Ireland's energy data, SEAI is expanding its use of data visualisations and interactive dashboards. In 2023 SEAI launched new interactive graphics and dashboards that allow users to explore monthly updates on energy delivery; quarterly updates on energy and fuel costs; and geographical analysis, comparing Ireland to other EU countries, and zooming down to the local authority level within Ireland. Please visit SEAI's website at https://www.seai.ie/data-andinsights/seai-statistics/monthly-energy-data/electricity-monthly/ to access the data.

SEAI currently publishes the energy balance for each year from 1990 to 2023. However, for the purposes of lending clarity to the data of most interest, the charts in this report generally only show data from 2003 onwards, while the tables show comparisons back to 2013. A spreadsheet containing complete timeseries from 1990 to 2023 for almost all graphs and charts in this report will be made available for download via the link in Appendix 10 shortly after launch.

Feedback and comments on this report are welcome. Contact details are available on the back cover of this report.

## 2.3 Data on energy-related emissions

For Energy in Ireland 2024, SEAI has moved its energy-related emission reporting from mega tonnes of carbon dioxide (MtCO2) to mega tonnes of carbon dioxide equivalent (MtCO2eq). The greenhouse gases (GHGs) covered within these CO2eq estimates include carbon dioxide (CO2), methane (CH4) and nitrous oxide (N2O), gases which are known to contribute to the warming of the earth's atmosphere to varying extents over a given timeframe. GHG quantities from fuel combustion have been calculated using sector and fuel specific data from the EPA's National Inventory Submissions [3]. To calculate a total CO2eq value, the emission metric used to quantify the differences in cumulative warming effects attributed to each of these gases is the 100year global warming potential (GWP100) and has been adapted from the IPCC Fifth Assessment Report. [4]

This change in methodology better aligns SEAI's reporting of energy-related emissions to those in national carbon budgets, and the EPA's GHG National Inventory Submissions, compiled in accordance with IPCC guidelines.

## 3 Primary energy

Primary energy is the total amount of energy that is required to satisfy the down-stream final energy use of end-users. It describes the initial energy sources that are transformed, transmitted, and distributed, before that energy is made available to end-users for final consumption. Primary energy therefore describes the energy inputs of processes like electricity generation and crude oil refining, rather than the consumption of that electricity or refined oil products.

The primary energy supply depends on the final energy use, as well as the efficiencies of the various transformation processes needed to ensure that end-users receive final energy in the form that is needed. Just like final energy use, primary energy supply can be usefully analysed by fuel, sector and mode.

## 3.1 Primary energy production

Primary energy production refers to the production of energy products from natural sources within Ireland's national boundaries. Examples of production include extraction of peat, crude oil or natural gas from natural deposits; recovery of waste for energy purposes; electricity generation by wind, solar or hydro; thermal energy collection by solar thermal systems; and production of biomass or biogas.

Figure 3.1 shows the latest breakdown of Ireland's annual primary energy production by energy type. Figure 3.2 shows Ireland's annual primary energy production by energy type and the ratio of primary energy production to supply.

Figure 3.1: Share of 2023 primary energy production by energy type

<!-- image -->

Figure 3.2: Indigenous primary energy production by energy type with production / supply ratio

<!-- image -->

Table 3.1: Primary energy production by energy type (share)

| Energy [TWh]   | 2013                | 2014                 | 2015                | 2016                  | 2017                  | 2018                  | 2019                  | 2020                  | 2021                  | 2022                  | 2023                  |
|----------------|---------------------|----------------------|---------------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|
| Wind           | 4.54                | 5.14                 | 6.57                | 6.15                  | 7.45                  | 8.64                  | 10.02                 | 11.55                 | 9.78                  | 11.21                 | 11.67                 |
| Natural gas    | (16.8%) 1.90 (7.0%) | (21.5%) 1.53 (6.4%)  | (28.8%) 1.31 (5.7%) | (12.5%) 28.99 (58.7%) | (13.1%) 33.19 (58.4%) | (14.7%) 32.00 (54.6%) | (20.7%) 24.97 (51.7%) | (27.9%) 19.38 (46.7%) | (27.8%) 14.63 (41.5%) | (30.9%) 13.55 (37.3%) | (33.8%) 10.87 (31.4%) |
| Biomass        | 2.13 (7.9%)         | 2.45                 | 2.36 (10.3%)        | 2.66                  | 2.88 (5.1%)           | 2.89 (4.9%)           | 2.76 (5.7%)           | 2.61                  | 2.70 (7.7%)           | 2.81                  | 2.18                  |
| Non-ren. waste | 0.71 (2.6%)         | (10.3%) 0.77 (3.2%)  | 0.80 (3.5%)         | (5.4%) 0.78 (1.6%)    | 1.32 (2.3%)           | 1.69 (2.9%)           | 1.69 (3.5%)           | (6.3%) 1.71 (4.1%)    | 1.66 (4.7%)           | (7.7%) 1.73 (4.8%)    | (6.3%) 1.96 (5.7%)    |
| Ren. Waste     | 0.57 (2.1%)         | 0.60                 | 0.66 (2.9%)         | 0.74                  | 1.09                  | 1.63                  | 1.59                  | 1.69                  | 1.67                  | 1.76                  | 1.79                  |
| Peat           | 15.43 (57.0%)       | (2.5%) 11.42 (47.8%) | 8.95 (39.2%)        | (1.5%) 7.90 (16.0%)   | (1.9%) 8.65 (15.2%)   | (2.8%) 9.49 (16.2%)   | (3.3%) 4.54 (9.4%)    | (4.1%) 1.49 (3.6%)    | (4.7%) 1.49 (4.2%)    | (4.9%) 1.49 (4.1%)    | (5.2%) 1.49 (4.3%)    |
| Ambient        | 0.24                | 0.27                 | 0.31                | 0.38                  | 0.44                  | 0.47                  | 0.55                  | 0.65                  | 0.75                  | 0.94                  | 1.12 (3.2%)           |
| Biodiesel      | (0.9%) 0.25 (0.9%)  | (1.1%) 0.26 (1.1%)   | (1.4%) 0.28 (1.2%)  | (0.8%) 0.28 (0.6%)    | (0.8%) 0.33 (0.6%)    | (0.8%) 0.36 (0.6%)    | (1.1%) 0.48 (1.0%)    | (1.6%) 0.63 (1.5%)    | (2.1%) 0.90 (2.6%)    | (2.6%) 1.16 (3.2%)    | 1.06 (3.1%)           |
| Hydro          | 0.60                | 0.71                 | 0.81                | 0.68                  | 0.69                  | 0.69                  | 0.89                  | 0.93                  | 0.75                  | 0.70                  | 0.94                  |
| Solar PV       | (2.2%) 0.00 (0.0%)  | (3.0%) 0.00 (0.0%)   | (3.5%) 0.00 (0.0%)  | (1.4%) 0.01 (0.0%)    | (1.2%) 0.01 (0.0%)    | (1.2%) 0.02 (0.0%)    | (1.8%) 0.03 (0.1%)    | (2.2%) 0.06 (0.1%)    | (2.1%) 0.09 (0.2%)    | (1.9%) 0.15 (0.4%)    | (2.7%) 0.65 (1.9%)    |
| Biogas         | 0.13 (0.5%)         | 0.15                 | 0.16                | 0.19                  | 0.19 (0.3%)           | 0.20 (0.3%)           | 0.22 (0.5%)           | 0.24 (0.6%)           | 0.26 (0.7%)           | 0.32 (0.9%)           | 0.32 (0.9%)           |
| Landfill gas   | 0.44 (1.6%)         | (0.6%) 0.45 (1.9%)   | (0.7%) 0.49 (2.1%)  | (0.4%) 0.46 (0.9%)    | 0.45 (0.8%)           | 0.39 (0.7%)           | 0.37 (0.8%)           | 0.34 (0.8%)           | 0.34 (1.0%)           | 0.30 (0.8%)           | 0.28 (0.8%)           |
| Solar thermal  | 0.12 (0.4%)         | 0.12 (0.5%)          | 0.13 (0.6%)         | 0.14                  | 0.15                  | 0.16                  | 0.16                  | 0.16                  | 0.16                  | 0.16                  | 0.16                  |
| Bioethanol     | 0 (0%)              | 0 (0%)               | 0 (0%)              | (0.3%) 0 (0%)         | (0.3%) 0.00 (0.0%)    | (0.3%) 0.03 (0.1%)    | (0.3%) 0.05 (0.1%)    | (0.4%) 0.04 (0.1%)    | (0.5%) 0.04 (0.1%)    | (0.4%) 0.06 (0.2%)    | (0.5%) 0.08 (0.2%)    |
| Total          | 27.06 (100%)        | 23.89 (100%)         | 22.83 (100%)        | 49.35 (100%)          | 56.84 (100%)          | 58.67 (100%)          | 48.32 (100%)          | 41.47 (100%)          | 35.23 (100%)          | 36.33 (100%)          | 34.57 (100%)          |

## 3.2 Primary energy imports and exports

Figure 3.3 shows Ireland's net energy imports by fuel type, along with the ratio of net imports to primary energy supply. Import dependency and energy security is discussed further in section 3.4.

Figure 3.3: Imports (positive) and exports (negative) by energy type (with total net imports)

<!-- image -->

Table 3.2: Imports by energy type (share)

| Energy [TWh]   | 2013          | 2014          | 2015           | 2016           | 2017           | 2018           | 2019           | 2020          | 2021          | 2022           | 2023          |
|----------------|---------------|---------------|----------------|----------------|----------------|----------------|----------------|---------------|---------------|----------------|---------------|
| Oil            | 95.44 (59.7%) | 91.99 (60.3%) | 105.94 (62.7%) | 104.76 (74.1%) | 108.37 (76.1%) | 106.26 (75.8%) | 105.23 (74.7%) | 96.94 (70.3%) | 98.71 (65.4%) | 103.28 (65.9%) | 99.63 (67.1%) |
| Natural gas    | 43.23 (27.0%) | 41.75 (27.4%) | 42.20 (25.0%)  | 19.82 (14.0%)  | 16.38 (11.5%)  | 20.10 (14.3%)  | 28.20 (20.0%)  | 33.84 (24.6%) | 36.35 (24.1%) | 38.45 (24.5%)  | 37.39 (25.2%) |
| Renewables     | 1.33 (0.8%)   | 1.54 (1.0%)   | 1.45 (0.9%)    | 1.62 (1.1%)    | 1.85 (1.3%)    | 1.78 (1.3%)    | 2.15 (1.5%)    | 2.27 (1.6%)   | 1.81 (1.2%)   | 2.18 (1.4%)    | 3.04 (2.0%)   |
| Coal           | 17.20 (10.8%) | 14.32 (9.4%)  | 17.69 (10.5%)  | 14.32 (10.1%)  | 14.75 (10.4%)  | 10.51 (7.5%)   | 3.15 (2.2%)    | 2.99 (2.2%)   | 11.68 (7.7%)  | 11.15 (7.1%)   | 4.77 (3.2%)   |
| Peat           | 0 (0%)        | 0 (0%)        | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)        | 0 (0%)        | 0 (0%)         | 0 (0%)        |
| Non-ren. waste | 0 (0%)        | 0 (0%)        | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)        | 0 (0%)        | 0 (0%)         | 0             |
| Electricity    | 2.63 (1.6%)   | 2.85 (1.9%)   | 1.75 (1.0%)    | 0.87 (0.6%)    | 1.12 (0.8%)    | 1.62 (1.2%)    | 2.18 (1.5%)    | 1.76 (1.3%)   | 2.45 (1.6%)   | 1.58 (1.0%)    | 3.72 (2.5%)   |
| Total imports  | 159.83 (100%) | 152.46 (100%) | 169.02 (100%)  | 141.39 (100%)  | 142.47 (100%)  | 140.28 (100%)  | 140.91 (100%)  | 137.80 (100%) | 151.00 (100%) | 156.65 (100%)  | 148.55 (100%) |

Table 3.3: Exports by energy type (share)

| Energy [TWh]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Oil            | 16.26 (96.4%) | 16.47 (95.1%) | 20.67 (94.1%) | 19.10 (91.6%) | 25.45 (92.8%) | 19.97 (90.8%) | 18.23 (91.1%) | 20.31 (90.0%) | 19.90 (93.0%) | 18.25 (90.3%) | 15.85 (93.9%) |
| Natural gas    | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        |
| Renewables     | 0.00 (0.0%)   | 0.00 (0.0%)   | 0.00 (0.0%)   | 0.00 (0.0%)   | 0.00 (0.0%)   | 0.11 (0.5%)   | 0.08 (0.4%)   | 0.19 (0.9%)   | 0.20 (1.0%)   | 0.17 (0.8%)   | 0.19 (1.1%)   |
| Coal           | 0.12 (0.7%)   | 0.12 (0.7%)   | 0.13 (0.6%)   | 0.11 (0.5%)   | 0.11 (0.4%)   | 0.18 (0.8%)   | 0.10 (0.5%)   | 0.09 (0.4%)   | 0.41 (1.9%)   | 0.44 (2.2%)   | 0.39 (2.3%)   |
| Peat           | 0.10 (0.6%)   | 0.02 (0.1%)   | 0.08 (0.4%)   | 0.05 (0.3%)   | 0.06 (0.2%)   | 0.08 (0.4%)   | 0.07 (0.3%)   | 0.07 (0.3%)   | 0.03 (0.1%)   | 0.01 (0.1%)   | 0.00 (0.0%)   |
| Non-ren. waste | 0             | 0             | 0             | 0             | 0             | 0             | 0             | 0             | 0             | 0             | 0             |
|                | 0.38          | 0.70          | 1.08          | 1.58 (7.6%)   | (6.5%)        | 1.65          | 1.54          | 1.91          | 0.86 (4.0%)   | 1.33          | 0.45 (2.6%)   |
| Electricity    | (2.3%)        | (4.1%)        | (4.9%)        |               | 1.80          | (7.5%)        | (7.7%)        | (8.5%)        |               | (6.6%)        |               |
| Total exports  | 16.86 (100%)  | 17.31 (100%)  | 21.97 (100%)  | 20.85 (100%)  | 27.42 (100%)  | 21.99 (100%)  | 20.01 (100%)  | 22.57 (100%)  | 21.40 (100%)  | 20.21 (100%)  | 16.89 (100%)  |

Table 3.4: Net imports by energy type (share)

| Energy [TWh]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Oil            | 79.18 (55.4%) | 75.52 (55.9%) | 85.26 (58.0%) | 85.65 (71.1%) | 82.92 (72.1%) | 86.29 (73.0%) | 87.00 (72.0%) | 76.63 (66.5%) | 78.82 (60.8%) | 85.03 (62.3%) | 83.78 (63.6%) |
| Natural gas    | 43.23 (30.2%) | 41.75 (30.9%) | 42.20 (28.7%) | 19.82 (16.4%) | 16.38 (14.2%) | 20.10 (17.0%) | 28.20 (23.3%) | 33.84 (29.4%) | 36.35 (28.0%) | 38.45 (28.2%) | 37.39 (28.4%) |
| Renewables     | 1.33 (0.9%)   | 1.54 (1.1%)   | 1.44 (1.0%)   | 1.62 (1.3%)   | 1.85 (1.6%)   | 1.67 (1.4%)   | 2.07 (1.7%)   | 2.08 (1.8%)   | 1.60 (1.2%)   | 2.01 (1.5%)   | 2.85 (2.2%)   |
| Coal           | 17.08 (11.9%) | 14.20 (10.5%) | 17.55 (11.9%) | 14.21 (11.8%) | 14.64 (12.7%) | 10.33 (8.7%)  | 3.06 (2.5%)   | 2.91 (2.5%)   | 11.27 (8.7%)  | 10.71 (7.9%)  | 4.38 (3.3%)   |
| Peat           | -0.10 (-0.1%) | -0.02 (-0.0%) | -0.08 (-0.1%) | -0.05 (-0.0%) | -0.06 (-0.1%) | -0.08 (-0.1%) | -0.07 (-0.1%) | -0.07 (-0.1%) | -0.03 (-0.0%) | -0.01 (-0.0%) | -0.00 (-0.0%) |
| Non-ren. waste | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        |
| Electricity    | 2.24 (1.6%)   | 2.15 (1.6%)   | 0.67 (0.5%)   | -0.71 (-0.6%) | -0.68 (-0.6%) | -0.03 (-0.0%) | 0.64 (0.5%)   | -0.15 (-0.1%) | 1.59 (1.2%)   | 0.25 (0.2%)   | 3.28 (2.5%)   |
| Total net      | 142.96        | 135.15        | 147.06        | 120.54        | 115.05        | 118.29        | 120.90        | 115.24        | 129.60        | 136.44 (100%) | 131.67        |

## 3.3 Primary energy supply and requirement

SEAI uses the following standard definition of primary energy supply for each fuel and energy type in the energy balance:

Primary energy supply = primary energy production + imports - exports - int. marine bunkers + stock change

Primary energy production is discussed in section 3.1, while imports and exports are discussed in section 3.2. International marine bunkers refer to the fuel delivered at Ireland's ports to vessels that are engaged in international navigation; currently only fuel oil and gas oil are used for this purpose. Stock change is the change between opening and closing stock levels for a fuel held in Ireland during the year. A positive stock

change indicates the net effect of the stock of a product being drawn down to enter the primary energy supply. A negative value indicates that the stock of the product has increased during the year. Stocks do not include reserves of fuels or products that are not yet extracted from natural deposits.

Another key measure of primary energy is primary energy requirement, defined as primary energy supply less non-energy use of the fuel or energy type:

Primary energy requirement = primary energy supply - non-energy use

For most fuel types included in the energy balance, there are no significant non-energy uses, and their primary energy supply and requirement are equal. In Ireland, the exceptions to this are bitumen, lubricating oil and white spirits, all oil products not used for energy purposes. Some natural gas was used for nonenergy purposes up until 2002. Renewables used for materials, such as wood for construction or peat for gardening are not tracked in the energy balance as they are not used for energy purposes.

Figure 3.4 displays the breakdown of energy types in Ireland's primary energy requirement for 2023.

Figure 3.4: Share of primary energy requirement by energy type

<!-- image -->

Figure 3.5 shows the trend in annual total primary energy requirement by energy type. Table 3.5 provides a detailed summary of the quantities and share of each energy type in Ireland's total primary energy requirement in comparison to previous years.

Total primary energy requirement peaked in 2008 before the economic downturn and reached a low in 2014 before growing to a relatively stable level from 2016 to 2019. A significant contraction to total primary energy requirement occurred in 2020 due to the impacts of the COVID-19 pandemic; this contraction was mostly confined to oil products, caused by a downturn in transport demand.

In absolute terms, Ireland's 2023 total primary energy requirement (163.79 TWh) was below that from 20 years ago (170.41 TWh) and above that from 10 years ago (155.06 TWh), with intervening periods of growth and decline. Nevertheless, the mix of fuels and energy types in primary energy has evolved significantly

during this time. The broad trend has been the growth of renewables and natural gas displacing oil, coal and peat. Despite the meaningful development of renewables, fossil fuels still dominate Ireland's primary energy supply.

Figure 3.5: Primary energy requirement by energy type in TWh

<!-- image -->

Table 3.5: Primary energy requirement by energy type (share)

| Energy [TWh]              | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|---------------------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Oil                       | 73.04 (47.1%) | 72.56 (47.1%) | 77.38 (47.8%) | 80.78 (47.8%) | 79.79 (47.6%) | 83.19 (48.6%) | 83.48 (49.1%) | 69.77 (44.9%) | 73.71 (45.9%) | 80.36 (48.2%) | 80.07 (48.9%) |
| Natural gas               | 44.92 (29.0%) | 43.40 (28.2%) | 43.83 (27.1%) | 49.44 (29.3%) | 50.19 (29.9%) | 52.11 (30.4%) | 53.16 (31.3%) | 53.22 (34.3%) | 50.98 (31.7%) | 52.00 (31.2%) | 48.26 (29.5%) |
| Renewables                | 10.33 (6.7%)  | 11.68 (7.6%)  | 13.23 (8.2%)  | 13.21 (7.8%)  | 15.57 (9.3%)  | 17.21 (10.0%) | 19.14 (11.3%) | 20.95 (13.5%) | 19.07 (11.9%) | 21.44 (12.9%) | 23.04 (14.1%) |
| Coal                      | 15.19 (9.8%)  | 14.52 (9.4%)  | 17.05 (10.5%) | 16.86 (10.0%) | 13.33 (8.0%)  | 9.16 (5.3%)   | 4.50 (2.6%)   | 5.02 (3.2%)   | 10.59 (6.6%)  | 8.45 (5.1%)   | 5.08 (3.1%)   |
| Peat                      | 8.63 (5.6%)   | 9.03 (5.9%)   | 8.92 (5.5%)   | 8.54 (5.1%)   | 8.08 (4.8%)   | 7.98 (4.7%)   | 7.32 (4.3%)   | 4.86 (3.1%)   | 3.08 (1.9%)   | 2.59 (1.6%)   | 2.10 (1.3%)   |
| Non-ren. waste            | 0.71 (0.5%)   | 0.77 (0.5%)   | 0.80 (0.5%)   | 0.78 (0.5%)   | 1.32 (0.8%)   | 1.69 (1.0%)   | 1.69 (1.0%)   | 1.71 (1.1%)   | 1.66 (1.0%)   | 1.73 (1.0%)   | 1.96 (1.2%)   |
| Electricity (net imports) | 2.24 (1.4%)   | 2.15 (1.4%)   | 0.67 (0.4%)   | -0.71 (-0.4%) | -0.68 (-0.4%) | -0.03 (-0.0%) | 0.64 (0.4%)   | -0.15 (-0.1%) | 1.59 (1.0%)   | 0.25 (0.2%)   | 3.28 (2.0%)   |
| Total                     | 155.06 (100%) | 154.10 (100%) | 161.88 (100%) | 168.89 (100%) | 167.60 (100%) | 171.30 (100%) | 169.94 (100%) | 155.37 (100%) | 160.69 (100%) | 166.82 (100%) | 163.79 (100%) |

## 3.4 Security of supply and import dependency

Energy security, in its simplest terms, means having uninterrupted access to reliable, affordable supplies of energy. Secure supplies of energy are essential for our economy and for maintaining safe and comfortable living conditions.

Energy imports dependency is one of the simplest and most widely used indicators of a country's energy security, with indigenous energy sources generally considered to be more secure than imported energy. While the overall energy imports dependency figure provides a useful context, a deeper understanding of energy security requires more detailed information on individual energy sources. This includes the countries from where each fuel is sourced, global market conditions, transportation and other infrastructure requirements. It also requires analysis of the current trends in energy use, and of the significant changes that will occur in energy use - both nationally and globally over the coming years. Energy security is considered in more detail in a separate SEAI publications [5], [6].

Energy imports dependency is defined as the ratio of net energy imports to gross available energy [7]: Energy import dependency  = Imports -Exports Gross available energy Or: Energy import dependency  = Imports -Exports

Primary energy requirement + Non energy use + Int. marine bunkers

Figure 3.6 illustrates the trend in import dependency since 1990, comparing it with that for the EU 27, and shows the dramatic change in Ireland's import dependency in 2016 resulting from the start of natural gas production from the Corrib gas field. Indigenous production accounted for 32% of Ireland's energy requirements in 1990. From the mid-1990s, import dependency grew significantly due to the increase in energy use, together with the decline in indigenous natural gas production at Kinsale since 1995, and decreasing peat production. Ireland's overall import dependency reached 91% in 2006. In 2016, import dependency fell sharply following the opening of the Corrib gas field but subsequently increased again, as annual production from the field decreased. Import dependency decreased slightly from 80% in 2022 to 78% in 2023 due to reduced net imports, which were only partially offset by the reduction in primary energy requirement.

This trend reflects the fact that Ireland is not endowed with significant indigenous fossil fuel resources and has only in recent years begun to harness significant quantities of renewable resources.

Figure 3.6: Import dependency of Ireland and the EU-27

<!-- image -->

Source: SEAI and Eurostat

## 4 Energy transformation

Energy transformation involves converting one fuel type or energy source into another, such as transforming crude oil into petrol and diesel in an oil refinery, or converting coal and gas into electricity in a thermal generation plant. Approximately half of all primary energy undergoes a transformation, of one kind or another, before it reaches an end user for final consumption.

Primary energy supply includes all inputs and losses in energy transformation processes, while final energy use only includes the outputs from those transformation processes. Transformation outputs are less than the primary supply inputs due to the energy required to make the transformations, and losses from those processes.

## 4.1 Overview of transformation

As shown in Figure 4.1, the two most significant energy transformation processes in Ireland are thermal electricity generation and oil refining. Oil refining has had a relatively constant, long-term average input of approximately 37 TWh per annum, while the transformation input of public thermal power plants for electricity generation has been trending downward over the long term as coal, oil and peat fired power are replaced by gas and renewables.

Figure 4.1: Energy inputs to transformation processes

<!-- image -->

## 4.2 Electricity generation

Total energy inputs to electricity generation account for approximately one-third of Ireland's total primary energy supply. The Sankey diagram in Figure 4.2 shows the flow of energy from the inputs to electricity generation through to the final electricity used by the different sectors. As the diagram shows, a significant portion of the energy used to generate electricity is lost before the electricity reaches the end user, through a

combination of transformation losses, own use of electricity by power plants, pumped hydro storage losses, and transmission and distribution losses.

Figure 4.2: Flow of energy in electricity generation and consumption (TWh) 7

<!-- image -->

## 4.2.1 Energy input to electricity generation

Figure 4.3 shows the trends in primary energy supply to electricity generation broken out by energy type.

Note that non-combustible renewable sources accounted for a higher share of generated electricity than of energy input to electricity generation. This is because the thermal generation of electricity from natural gas and coal has significant energy losses (see Figure 4.2), while electricity generation from non-combustible renewable sources (wind, hydro and solar) is considered to be 100% efficient as this is the point at which the measurable energy enters the system.

Table 4.1 shows the energy input to electricity generation by energy type with comparison to previous years.

7 GEP refers to gross electricity production .

## Figure 4.3: Energy input to electricity generation by energy type

<!-- image -->

Table 4.1 provides the quantities and shares of energy types that go into electricity generation in Ireland, while Table 4.2 provides a breakdown of the energy input to electricity generation by source (renewable, non-renewable or electricity net imports). Figure 4.4 shows the changes in energy input to electricity generation in the last year, by fuel type and energy source.

Table 4.1: Energy input to electricity generation by energy type (share)

| Energy [TWh]              | 2013               | 2014                 | 2015                 | 2016                  | 2017                 | 2018                  | 2019                  | 2020                  | 2021               | 2022                | 2023               |
|---------------------------|--------------------|----------------------|----------------------|-----------------------|----------------------|-----------------------|-----------------------|-----------------------|--------------------|---------------------|--------------------|
| Natural gas               | 24.44 (47.8%)      | 22.98                | 22.12                | 27.29                 | 28.24                | 28.67 (53.9%)         | 29.38                 | 29.91                 | 27.28 (48.6%)      | 30.21 (53.4%)       | 28.16 (53.2%)      |
| Wind                      | 4.54 (8.9%)        | (45.3%) 5.14 (10.1%) | (42.3%) 6.57 (12.6%) | (49.4%) 6.15          | (51.7%) 7.45 (13.6%) | 8.64 (16.3%)          | (56.3%) 10.02 (19.2%) | (57.4%) 11.55 (22.2%) | 9.78 (17.4%)       | 11.21 (19.8%)       | 11.67 (22.0%)      |
| Coal                      | 11.29 (22.1%)      | 10.94 (21.5%)        | 13.09 (25.0%)        | (11.1%) 12.82 (23.2%) | 10.09 (18.5%)        | 5.69                  | 1.72                  | 2.26 (4.3%)           | 7.82 (13.9%)       | 6.56                | 3.66               |
| Electricity (net imports) | 2.24 (4.4%)        | 2.15 (4.2%)          | 0.67 (1.3%)          | -0.71 (-1.3%)         | -0.68 (-1.2%)        | (10.7%) -0.03 (-0.1%) | (3.3%) 0.64 (1.2%)    | -0.15 (-0.3%)         | 1.59 (2.8%)        | (11.6%) 0.25 (0.4%) | (6.9%) 3.28 (6.2%) |
| Ren. waste                | 0.30 (0.6%)        | 0.30                 | 0.30 (0.6%)          | 0.30                  | 0.62 (1.1%)          | 1.15 (2.2%)           | 1.12                  | 1.18 (2.3%)           | 1.13 (2.0%)        | 1.14 (2.0%)         | 1.11 (2.1%)        |
| Non-ren. waste            | 0.27 (0.5%)        | (0.6%) 0.29 (0.6%)   | 0.29 (0.6%)          | (0.5%) 0.29 (0.5%)    | 0.66 (1.2%)          | 1.06 (2.0%)           | (2.1%) 1.03 (2.0%)    | 1.08 (2.1%)           | 1.04 (1.8%)        | 1.05 (1.9%)         | 1.09 (2.1%)        |
| Hydro                     | 0.60 (1.2%)        | 0.71 (1.4%)          | 0.81 (1.5%)          | 0.68 (1.2%)           | 0.69 (1.3%)          | 0.69 (1.3%)           | 0.89 (1.7%)           | 0.93 (1.8%)           | 0.75 (1.3%)        | 0.70 (1.2%)         | 0.94 (1.8%)        |
| Biomass                   | 0.59 (1.2%)        | 0.68 (1.3%)          | 0.50 (1.0%)          | 1.02 (1.8%)           | 0.99 (1.8%)          | 0.88 (1.7%)           | 0.90 (1.7%)           | 1.14 (2.2%)           | 1.18 (2.1%)        | 1.26 (2.2%)         | 0.93 (1.8%)        |
| Oil                       | 0.51               | 0.70                 | 1.00                 | 0.80                  | 0.39                 | 0.40                  | 0.91                  | 1.25                  | 4.19               | 2.97 (5.3%)         | 0.65 (1.2%)        |
| Solar PV                  | (1.0%) 0.00 (0.0%) | (1.4%) 0.00 (0.0%)   | (1.9%) 0.00 (0.0%)   | (1.4%) 0.01 (0.0%)    | (0.7%) 0.01 (0.0%)   | (0.8%) 0.02 (0.0%)    | (1.7%) 0.03 (0.1%)    | (2.4%) 0.06 (0.1%)    | (7.5%) 0.09 (0.2%) | 0.15 (0.3%)         | 0.65 (1.2%)        |
| Peat                      | 5.90 (11.5%)       | 6.39                 | 6.44 (12.3%)         | 6.07 (11.0%)          | 5.68 (10.4%)         | 5.50 (10.3%)          | 5.05 (9.7%)           | 2.49 (4.8%)           | 0.83 (1.5%)        | 0.64 (1.1%)         | 0.42               |
| Landfill gas              | 0.44 (0.9%)        | (12.6%) 0.45 (0.9%)  | 0.49 (0.9%)          | 0.46 (0.8%)           | 0.45 (0.8%)          | 0.39 (0.7%)           | 0.37 (0.7%)           | 0.34 (0.7%)           | 0.34 (0.6%)        | 0.30 (0.5%)         | (0.8%) 0.28 (0.5%) |
| Biogas                    | 0.05 (0.1%)        | 0.06 (0.1%)          | 0.06 (0.1%)          | 0.08 (0.1%)           | 0.08 (0.1%)          | 0.08 (0.2%)           | 0.10 (0.2%)           | 0.10 (0.2%)           | 0.11 (0.2%)        | 0.12 (0.2%)         | 0.12 (0.2%)        |
| Total                     | 51.16 (100%)       | 50.79 (100%)         | 52.34 (100%)         | 55.25 (100%)          | 54.67 (100%)         | 53.16 (100%)          | 52.17 (100%)          | 52.14 (100%)          | 56.13 (100%)       | 56.56 (100%)        | 52.96 (100%)       |

Table 4.2: Energy input to electricity generation from renewables, non-renewables and electricity net imports (share)

| Energy [TWh]                | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|-----------------------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Renewables                  | 6.53 (12.2%)  | 7.34 (13.9%)  | 8.72 (16.5%)  | 8.70 (15.9%)  | 10.29 (19.1%) | 11.87 (22.3%) | 13.43 (25.4%) | 15.30 (29.4%) | 13.38 (23.2%) | 14.88 (26.2%) | 15.71 (27.9%) |
| Non-                        | 44.63 (83.6%) | 43.45 (82.1%) | 43.61 (82.3%) | 46.56 (85.4%) | 44.38 (82.2%) | 41.29 (77.7%) | 38.74 (73.4%) | 36.84 (70.9%) | 42.75 (74.1%) | 41.67 (73.4%) | 37.25 (66.2%) |
| renewables Electricity (net | 2.24 (4.2%)   | 2.15 (4.1%)   | 0.67 (1.3%)   | -0.71 (-1.3%) | -0.68 (-1.3%) | -0.03 (-0.1%) | 0.64 (1.2%)   | -0.15 (-0.3%) | 1.59 (2.8%)   | 0.25 (0.4%)   | 3.28 (5.8%)   |
| Total                       | 53.40 (100%)  | 52.94 (100%)  | 53.01 (100%)  | 54.54 (100%)  | 53.99 (100%)  | 53.13 (100%)  | 52.81 (100%)  | 51.99 (100%)  | 57.72 (100%)  | 56.81 (100%)  | 56.23 (100%)  |

Figure 4.4: Change in input energy type to electricity generation in 2023 compared with 2022

<!-- image -->

## 4.2.2 Electricity generated and net imports

This subsection presents the gross quantity of electricity supplied annually by source, prior to losses, own use or energy storage. Figure 4.5 and Table 4.3 detail the gross electricity supply from each energy type.

The follow definition of gross electricity supply is followed:

𝐺𝐺𝐺𝐺𝐺𝐺𝐺𝐺𝐺𝐺 𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝐺𝐺𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒 𝐺𝐺𝑠𝑠𝑠𝑠𝑠𝑠𝑒𝑒𝑒𝑒

= 𝑔𝑔𝐺𝐺𝐺𝐺𝐺𝐺𝐺𝐺 𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝐺𝐺𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒 𝑠𝑠𝐺𝐺𝐺𝐺𝑝𝑝𝑠𝑠𝑒𝑒𝑒𝑒𝑒𝑒𝐺𝐺𝑝𝑝 - 𝑔𝑔𝐺𝐺𝐺𝐺𝐺𝐺𝐺𝐺 𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝐺𝐺𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒 𝑓𝑓𝐺𝐺𝐺𝐺𝑓𝑓 ℎ𝑒𝑒𝑝𝑝𝐺𝐺𝐺𝐺 𝑠𝑠𝑠𝑠𝑓𝑓𝑠𝑠 𝐺𝐺𝑒𝑒𝐺𝐺𝐺𝐺𝑠𝑠𝑔𝑔𝑒𝑒 -𝑔𝑔𝐺𝐺𝐺𝐺𝐺𝐺𝐺𝐺 𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝐺𝐺𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒 𝑓𝑓𝐺𝐺𝐺𝐺𝑓𝑓 𝑏𝑏𝑠𝑠𝑒𝑒𝑒𝑒𝑒𝑒𝐺𝐺𝑒𝑒 𝐺𝐺𝑒𝑒𝐺𝐺𝐺𝐺𝑠𝑠𝑔𝑔𝑒𝑒 + 𝑝𝑝𝑒𝑒𝑒𝑒 𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝐺𝐺𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒𝑒 𝑒𝑒𝑓𝑓𝑠𝑠𝐺𝐺𝐺𝐺𝑒𝑒𝐺𝐺

Gross electricity production is the key quantity used in national energy statistics reported under Eurostat and IEA guidelines. It refers to the sum of the electrical energy production by all the generating units measured at the output terminals of the main generator or inverter [8]. Gross electricity production includes the output from hydro pump storage and battery storage, but does not include electricity from imports.

To provide a more useful presentation of all sources of electricity, prior to consumption/generation in energy storage systems, the data presented in this section is presented as gross electricity supply, following the definition above. The data in Figure 4.5 and Table 4.3 includes all electricity producers, from residential rooftop solar PV to utility scale thermal power plants and wind farms. It includes all electricity that enters the national grid, as well as electricity that is generated and consumed on the same site without entering the grid (referred to as auto-production or auto-consumption).

## Figure 4.5: Gross electricity supply by energy type

<!-- image -->

Table 4.3: Gross electricity production by energy type (share), with net imports

| Energy [TWh]              | 2013          | 2014                 | 2015                 | 2016                 | 2017               | 2018                 | 2019                  | 2020                  | 2021               | 2022                  | 2023               |
|---------------------------|---------------|----------------------|----------------------|----------------------|--------------------|----------------------|-----------------------|-----------------------|--------------------|-----------------------|--------------------|
| Natural gas               | 13.13 (47.2%) | 12.64                | 12.37                | 15.33                | 15.68 (52.3%)      | 16.02                | 15.91                 | 16.24                 | 15.16 (45.7%)      | 16.53                 | 15.35 (44.3%)      |
| Wind                      | 4.54 (16.3%)  | (45.2%) 5.14 (18.4%) | (43.0%) 6.57 (22.8%) | (51.9%) 6.15 (20.8%) | 7.45 (24.8%)       | (51.9%) 8.64 (28.0%) | (50.7%) 10.02 (32.0%) | (51.0%) 11.55 (36.3%) | 9.78 (29.5%)       | (48.8%) 11.21 (33.1%) | 11.67 (33.7%)      |
| Electricity (net imports) | 2.24 (8.1%)   | 2.15 (7.7%)          | 0.67 (2.3%)          | -0.71 (-2.4%)        | -0.68 (-2.3%)      | -0.03 (-0.1%)        | 0.64 (2.1%)           | -0.15 (-0.5%)         | 1.59 (4.8%)        | 0.25 (0.7%)           | 3.28               |
| Coal                      | 4.28 (15.4%)  | 3.96 (14.2%)         | 4.88 (16.9%)         | 4.70 (15.9%)         | 3.65 (12.2%)       | 2.15 (7.0%)          | 0.51 (1.6%)           | 0.67 (2.1%)           | 2.72 (8.2%)        | 2.37 (7.0%)           | (9.5%) 1.21 (3.5%) |
| Hydro                     | 0.60 (2.2%)   | 0.71 (2.5%)          | 0.81                 | 0.68                 | 0.69 (2.3%)        | 0.69 (2.2%)          | 0.89 (2.8%)           | 0.93 (2.9%)           | 0.75 (2.3%)        | 0.70 (2.1%)           | 0.94 (2.7%)        |
| Solar PV                  | 0.00 (0.0%)   | 0.00 (0.0%)          | (2.8%) 0.00 (0.0%)   | (2.3%) 0.01          | 0.01 (0.0%)        | 0.02 (0.1%)          | 0.03 (0.1%)           | 0.06 (0.2%)           | 0.09 (0.3%)        | 0.15 (0.4%)           | 0.65 (1.9%)        |
| Biomass                   | 0.23 (0.8%)   | 0.26 (0.9%)          | 0.20 (0.7%)          | (0.0%) 0.40 (1.3%)   | 0.38 (1.3%)        | 0.33 (1.1%)          | 0.35 (1.1%)           | 0.43 (1.4%)           | 0.47 (1.4%)        | 0.51 (1.5%)           | 0.35 (1.0%)        |
| Ren. waste                | 0.07 (0.3%)   | 0.07 (0.3%)          | 0.08 (0.3%)          | 0.08 (0.3%)          | 0.15 (0.5%)        | 0.33 (1.1%)          | 0.32 (1.0%)           | 0.33 (1.0%)           | 0.35 (1.1%)        | 0.35 (1.0%)           | 0.33 (1.0%)        |
| Non-ren. waste            | 0.07 (0.2%)   | 0.07 (0.2%)          | 0.07 (0.3%)          | 0.07 (0.2%)          | 0.16 (0.5%)        | 0.30 (1.0%)          | 0.29 (0.9%)           | 0.30 (0.9%)           | 0.32 (1.0%)        | 0.32 (0.9%)           | 0.33 (0.9%)        |
| Oil                       | 0.19 (0.7%)   | 0.26                 | 0.41 (1.4%)          | 0.29 (1.0%)          | 0.14               | 0.14                 | 0.28 (0.9%)           | 0.39                  | 1.45 (4.4%)        | 1.08 (3.2%)           | 0.23 (0.7%)        |
| Peat                      | 2.28 (8.2%)   | (0.9%) 2.50 (8.9%)   | 2.52 (8.8%)          | 2.32                 | (0.5%) 2.16 (7.2%) | (0.5%) 2.09 (6.8%)   | 1.93 (6.1%)           | (1.2%) 0.92 (2.9%)    | 0.32               | 0.25                  | 0.15               |
| Landfill gas              | 0.16 (0.6%)   | 0.17 (0.6%)          | 0.18 (0.6%)          | (7.9%) 0.16 (0.6%)   | 0.16 (0.5%)        | 0.14 (0.5%)          | 0.13 (0.4%)           | 0.12 (0.4%)           | (1.0%) 0.12 (0.4%) | (0.7%) 0.10 (0.3%)    | (0.4%) 0.10 (0.3%) |
| Biogas                    | 0.03 (0.1%)   | 0.04 (0.1%)          | 0.03 (0.1%)          | 0.04 (0.1%)          | 0.04 (0.1%)        | 0.04 (0.1%)          | 0.06 (0.2%)           | 0.05 (0.2%)           | 0.05 (0.2%)        | 0.06 (0.2%)           | 0.05 (0.2%)        |
| Total                     | 27.82 (100%)  | 27.96 (100%)         | 28.78 (100%)         | 29.51 (100%)         | 30.00 (100%)       | 30.88 (100%)         | 31.36 (100%)          | 31.83 (100%)          | 33.17 (100%)       | 33.87 (100%)          | 34.64 (100%)       |

A comparison of Figure 4.3 and Figure 4.5 is equivalent to a comparison of the energy supplied to electricity generation and gross output of electricity from generation. The difference in scale between the two figures (40 TWh vs . 70 TWh) reflects the generation losses. The relative increase in share from renewable sources in Figure 4.5 ( vs . Figure 4.3) is due to wind, hydro and solar generation being taken as 100% efficient.

Table 4.4 shows gross electricity production (including net imports) from renewables, non-renewables and net imports. Figure 4.6 shows the changes in gross electricity generation by source in 2023 compared to 2022. Figure 4.7 shows the annual imports, exports and net exports of electricity over the last 21 years.

Table 4.4: Gross electricity supply from renewables, non-renewables and net imports (share)

| Energy [TWh]                | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|-----------------------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Renewables                  | 5.63 (22.0%)  | 6.39 (24.8%)  | 7.86 (28.0%)  | 7.51 (24.9%)  | 8.88 (29.0%)  | 10.20 (33.0%) | 11.80 (38.4%) | 13.46 (42.1%) | 11.61 (36.8%) | 13.07 (38.9%) | 14.09 (44.9%) |
| Non-                        | 19.95 (78.0%) | 19.42 (75.2%) | 20.24 (72.0%) | 22.71 (75.1%) | 21.79 (71.0%) | 20.70 (67.0%) | 18.92 (61.6%) | 18.52 (57.9%) | 19.98 (63.2%) | 20.54 (61.1%) | 17.27 (55.1%) |
| renewables Electricity (net | 2.24 (8.8%)   | 2.15 (8.3%)   | 0.67 (2.4%)   | -0.71 (-2.4%) | -0.68 (-2.2%) | -0.03 (-0.1%) | 0.64 (2.1%)   | -0.15 (-0.5%) | 1.59 (5.0%)   | 0.25 (0.7%)   | 3.28 (10.4%)  |
| Total                       | 25.58 (100%)  | 25.81 (100%)  | 28.11 (100%)  | 30.23 (100%)  | 30.68 (100%)  | 30.90 (100%)  | 30.72 (100%)  | 31.98 (100%)  | 31.59 (100%)  | 33.62 (100%)  | 31.36 (100%)  |

Figure 4.6: Change in gross electricity supply by energy type in 2023 compared with 2022

<!-- image -->

## Figure 4.7: Electricity imports, exports and net imports

<!-- image -->

## 4.2.3 Efficiency of electricity supply

Figure 4.8 shows trends in the efficiency of Ireland's electricity supply. The efficiency of electricity supply is the ratio of the electricity available for consumption (including by other energy sector users such as refining) to the energy input to generation and net electricity imports:

<!-- formula-not-decoded -->

The overall efficiency is determined by the weighted average of electricity generation from non-combustible renewable sources, such as wind, hydro and solar (taken to be 100% efficient), and electricity from combustible sources, such as gas, coal and biomass (which have transformation losses). The efficiency of electricity supply increases as the share of non-combustible renewable sources, and as more efficient fuels and technologies are employed in thermal generation plants.

The efficiency of Ireland's electricity supply has generally improved over the last two decades, due to introducing higher efficiency natural gas plants, the closure of or reduction in utilisation of older oil-, coal-, and peat-fired stations, as well as increased direct generation from renewable sources (wind, solar PV and hydro) and net imports.

Figure 4.8: Efficiency of electricity supply

<!-- image -->

## 4.2.4 Combined heat and power generation

Combined heat and power (CHP) is the simultaneous generation of usable heat and electricity in a single process. In conventional electricity generation, much of the input energy is lost as waste heat. The efficiency of a CHP plant can be 20-25% higher than the combined efficiency of heat-only boilers and conventional power stations. Also, if embedded in the network close to the point of electrical consumption, CHP can avoid some of the transmission losses incurred by centralised generation. In the right circumstances, despite higher capital outlay, CHP can be an economical means of improving the efficiency of energy use and reducing emissions. Table 4.5 shows the operational electrical capacity (MWe) over the last ten years, broken down by fuel.

Table 4.5: Operational CHP capacity by fuel (share)

| Capacity [MWe]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|------------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Natural Gas      | 282.4 (91.6%) | 285.4 (91.8%) | 287.7 (92.1%) | 285.5 (91.5%) | 292.1 (91.7%) | 298.3 (93.5%) | 300.3 (93.2%) | 301.2 (93.1%) | 303.7 (93.2%) | 305.5 (93.2%) | 301.8 (93.2%) |
| Solid Fuels      | 5.2 (1.7%)    | 5.2 (1.7%)    | 5.2 (1.7%)    | 5.2 (1.7%)    | 5.2 (1.6%)    | 5.2 (1.6%)    | 2.6 (0.8%)    | 2.6 (0.8%)    | 2.6 (0.8%)    | 2.6 (0.8%)    | 2.6 (0.8%)    |
| Biomass          | 5.4 (1.7%)    | 5.4 (1.7%)    | 5.4 (1.7%)    | 5.4 (1.7%)    | 5.4 (1.7%)    | 5.4 (1.7%)    | 6.6 (2.0%)    | 6.6 (2.0%)    | 6.6 (2.0%)    | 6.6 (2.0%)    | 6.6 (2.0%)    |
| Oil Fuels        | 8.9 (2.9%)    | 8.8 (2.8%)    | 7.9 (2.5%)    | 7.5 (2.4%)    | 7.6 (2.4%)    | 1.0 (0.3%)    | 1.0 (0.3%)    | 1.1 (0.3%)    | 1.1 (0.3%)    | 1.1 (0.3%)    | 0.9 (0.3%)    |
| Biogas           | 6.3 (2.0%)    | 6.3 (2.0%)    | 6.3 (2.0%)    | 8.4 (2.7%)    | 8.4 (2.6%)    | 9.3 (2.9%)    | 11.9 (3.7%)   | 11.9 (3.7%)   | 11.9 (3.6%)   | 11.9 (3.6%)   | 11.9 (3.7%)   |
| Total            | 308.1 (100%)  | 311.0 (100%)  | 312.5 (100%)  | 312.1 (100%)  | 318.7 (100%)  | 319.2 (100%)  | 322.3 (100%)  | 323.4 (100%)  | 325.8 (100%)  | 327.7 (100%)  | 323.9 (100%)  |

Figure 4.9 illustrates the fuel consumption, along with electricity and heat outputs, from CHP in Ireland over the last 21 years. The step-change increase observed in 2006 is due to the Aughinish Alumina CHP plant coming online.

## Figure 4.9: CHP fuel input and thermal/electricity output

<!-- image -->

Figure 4.10 focuses on CHP generated electricity in Ireland as a proportion of gross electricity consumption (that is electricity generation plus net imports). Table 4.6 provides data on the number of CHP units that exported electricity to the grid in the last two years and the total quantity of electricity exported.

Figure 4.10: CHP electricity as percentage of total electricity generation

<!-- image -->

Table 4.6: Electricity exported to the grid from CHP

|                                    | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   | 2023   |
|------------------------------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| No. of CHP units exporting to grid | 18     | 18     | 20     | 16     | 17     | 17     | 17     | 16     | 16     | 18     | 18     |
| Electricity exported to grid [GWh] | 1,377  | 1,372  | 1,417  | 1,375  | 1,384  | 1,395  | 1,337  | 1,378  | 1,317  | 1,309  | 1,194  |

## 4.2.5 Solar, wind and hydro capacity

Figure 4.11 and Table 4.7 show the installed capacity of rooftop and grid-scale solar PV in Ireland at the end of each year. Rooftop refers to all solar PV installations with a maximum export capacity (MEC) 0.2 MW, as well as some generators above this threshold that do not export power to the grid (parallel generators). All solar PV generators that are above 0.2 MW and export power to the grid are included in grid-scale capacity.

Figure 4.12 shows the location of grid-scale solar PV generators ( i.e. solar farms) connected in Ireland.

Figure 4.11: Installed solar PV capacity (AC) at year end

<!-- image -->

Table 4.7: Installed solar PV capacity (AC) at year end

| Capacity [MW]   |   2013 |   2014 |   2015 |   2016 |   2017 |   2018 |   2019 |   2020 |   2021 |   2022 |   2023 |
|-----------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Rooftop         |   1.09 |   1.49 |   2.71 |   6.26 |  13.16 |  24.01 |  44.72 |  72.89 | 111.95 | 175.12 | 307.79 |
| Grid-scale      |   0    |   0    |   0    |   0    |   0    |   0    |   0    |   0    |   0    |  34.19 | 445.12 |
| Total           |   1.09 |   1.49 |   2.71 |   6.26 |  13.16 |  24.01 |  44.72 |  72.89 | 111.95 | 209.31 | 752.9  |

## Figure 4.12: Map of grid-scale solar PV (solar farms) connected in Ireland

Figure 4.13 shows the annual growth in installed wind generation capacity and overall cumulative capacity since 2000 [9]. 203 MW of wind capacity was added during 2023 and the total installed capacity at the end of

<!-- image -->

the year was 4,739 MW. Note that these capacity figures include both transmission-connected and distribution-connected windfarms, along with a small number of autoproducers (sites that generate electricity for their own consumption). The location of grid-connected wind farms in Ireland can be seen in Figure 4.14.

Figure 4.13: Installed wind generation capacity

Source: EirGrid and ESB Networks

<!-- image -->

Table 4.8: Wind capacity

| Capacity [MW]                 | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   | 2023   |
|-------------------------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Added wind capacity           | 219    | 360    | 168    | 351    | 518    | 355    | 453    | 180    | 32     | 197    | 203    |
| Total installed wind capacity | 1,923  | 2,283  | 2,451  | 2,802  | 3,319  | 3,674  | 4,126  | 4,307  | 4,339  | 4,536  | 4,739  |

## Figure 4.14: Map of grid-connected wind farms in Ireland

<!-- image -->

Unlike solar and wind generation, the installed capacity of hydroelectric generation has been consistent for over 10 years at approximately 237 MW (excluding pumped storage). The location of hydro generators can be seen in Figure 4.15.

Figure 4.15: Map of grid-connected hydroelectric generators in Ireland (pumped hydro not shown)

<!-- image -->

The output from wind and hydro generation is affected by the amount of the resource (wind and rainfall) in a particular year. It is also affected by the extent of outages of the plant for reasons such as faults, maintenance and curtailment. An indication of how these factors affect the output of wind and hydro can be obtained by examining the capacity factors for these generation types. The capacity factor is the ratio of average electricity produced to the theoretical maximum possible if the installed capacity was generating at a maximum for a full year. Capacity factors for wind and hydro for the last 11 years are presented in Table 4.9

The rates of capacity increase each year can have a significant impact on the capacity factor in periods of large annual capacity increases. If significant capacity is added late in the year, this artificially reduces the capacity factor for the year. To mitigate this, the wind capacity factor is calculated using the average of the installed capacity at the beginning and end of the year.

Table 4.9: Annual capacity factor for wind and hydro

| Capacity factor [%]          | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   | 2023   |
|------------------------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Wind                         |        |        |        |        |        |        |        |        |        |        |        |
| (based on average in-year    | 29.1%  | 28.4%  | 32.2%  | 27.2%  | 28.2%  | 28.7%  | 29.8%  | 31.8%  | 26.2%  | 29.3%  | 29.2%  |
| Hydro                        |        |        |        |        |        |        |        |        |        |        |        |
| (based on year-end capacity) | 28.9%  | 34.1%  | 38.8%  | 32.8%  | 33.3%  | 33.4%  | 42.7%  | 44.9%  | 36.1%  | 33.8%  | 45.4%  |

## 4.3 Oil refining

Ireland has one oil refinery at Whitegate in Cork, that is currently operated by Irving Oil. Whereas electricity generation has a variety of fuel inputs and just one output (electricity), oil refining has one major fuel input (crude oil), but multiple fuel outputs (petrol, diesel and kerosene, etc .). Figure 4.11 and Table 4.7 show the outputs from oil refining, primarily being fuel oil, diesel (gas oil) and petrol (gasoline).

Due to the highly international nature of the oil market, refinery outputs are not heavily influenced by local demand in the Irish market, but on the configuration and capabilities of the refinery. A significant portion of the refinery's output is exported directly, while the majority of oil products used for final energy in Ireland are imported as finished products. Nonetheless, the refinery is an important piece of infrastructure regarding energy security.

## Figure 4.16: Outputs from oil refining

<!-- image -->

Table 4.10: Outputs from oil refining (share)

| Energy [TWh]    | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023               |
|-----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|--------------------|
| Fuel oil        | 10.66 (31.2%) | 10.68 (32.0%) | 13.28 (32.8%) | 12.17 (31.5%) | 11.93 (31.3%) | 11.18 (30.3%) | 8.30 (25.0%)  | 9.44 (27.1%)  | 11.12 (30.0%) | 9.85 (26.9%)  | 9.00 (26.0%)       |
| Gasoil / diesel | 13.71 (40.1%) | 13.06 (39.1%) | 15.76 (38.9%) | 14.86 (38.5%) | 14.62 (38.3%) | 13.34 (36.2%) | 12.77 (38.4%) | 12.54 (36.0%) | 13.20 (35.7%) | 13.44 (36.6%) | 13.03 (37.6%)      |
| Gasoline        | 6.55 (19.1%)  | 6.09 (18.2%)  | 7.49 (18.5%)  | 6.86 (17.8%)  | 6.83 (17.9%)  | 7.45 (20.2%)  | 6.42 (19.3%)  | 6.65 (19.1%)  | 6.80 (18.4%)  | 6.62 (18.1%)  | 7.38 (21.3%)       |
| Kerosene        | 1.29 (3.8%)   | 1.68 (5.0%)   | 1.75 (4.3%)   | 2.15 (5.6%)   | 1.94 (5.1%)   | 2.64 (7.2%)   | 3.76 (11.3%)  | 3.41 (9.8%)   | 3.13 (8.4%)   | 3.43 (9.4%)   | 3.17 (9.1%)        |
| Jet kerosene    | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)             |
| Refinery gas    | 0.80 (2.3%)   | 0.86 (2.6%)   | 1.24 (3.1%)   | 1.07 (2.8%)   | 1.05 (2.7%)   | 1.05 (2.8%)   | 0.88 (2.6%)   | 0.99 (2.8%)   | 1.13 (3.1%)   | 1.37 (3.7%)   | 1.24 (3.6%)        |
| LPG             | 0.83 (2.4%)   | 0.78 (2.3%)   | 0.61 (1.5%)   | 0.56 (1.4%)   | 0.64 (1.7%)   | 0.75 (2.0%)   | 0.59 (1.8%)   | 0.68 (2.0%)   | 0.55 (1.5%)   | 0.49 (1.3%)   | 0.48               |
| Naphtha         | 0.35 (1.0%)   | 0.24 (0.7%)   | 0.35 (0.9%)   | 0.93 (2.4%)   | 1.15 (3.0%)   | 0.43 (1.2%)   | 0.51 (1.5%)   | 1.09 (3.1%)   | 1.09 (2.9%)   | 1.47 (4.0%)   | (1.4%) 0.37 (1.1%) |
| Total           | 34.20 (100%)  | 33.39 (100%)  | 40.49 (100%)  | 38.59 (100%)  | 38.16 (100%)  | 36.83 (100%)  | 33.23 (100%)  | 34.80 (100%)  | 37.03 (100%)  | 36.67 (100%)  | 34.66 (100%)       |

## 4.4 Other transformation processes

Several other energy transformation processes operate in the Irish energy sector, though all are relatively small compared to electricity generation, CHP and oil refining.

## 4.4.1 Pumped hydroelectric storage

Pumped hydroelectricity storage is the process of using electricity to pump water to an uphill reservoir, and later releasing the water from the reservoir through a turbine to generate electricity. A pumped storage facility acts like a battery to store relatively large amounts of electricity. There is one pumped hydroelectric station in Ireland at Turlough Hill in Wicklow, with a total capacity of 292 MW. It can operate for roughly 6 hours at maximum generating capacity.

The electricity generated from pumped hydro storage is not considered hydroelectricity for statistical purposes and is not counted as renewable energy. Pumped storage facilities act to store electricity previously generated by other sources. Although it is not a renewable source, pumped hydro storage is useful for integrating and smoothing variable non-synchronous renewable electricity sources, such as wind, onto the electricity system.

Figure 4.12 shows the annual consumption and generation of electricity, along with associated overall efficiency, at Turlough Hill. The facility underwent significant overhaul work from 2010 to 2012, producing no electricity in 2011.

Figure 4.17: Pumped hydroelectric storage (Turlough Hill)

<!-- image -->

## 4.4.2 Battery storage

Figure 4.18 and Table 4.11 show the generation capacity of grid-connected battery storage at the end of each year, while Figure 4.19 and Table 4.12 show the storage capacity. Generation capacity is the maximum electrical power that the unit(s) can delivery, defined as maximum export capacity (MEC) to the grid. Storage capacity is the maximum energy the unit(s) can store when fully charged.

The data presented here only includes battery storage capable of exporting power to the grid with an MEC of at least 0.2 MW. Consequently, batteries installed in homes or businesses for the purposes of storing energy for own use are not included in this dataset.

Approximately 17 battery storage units had been connected to Ireland's transmission and distribution networks by the end of 2023. Table 4.13 shows the annual electrical energy consumed and generated by these units; 2022 is the first year for which data is available.

Figure 4.18: Battery generation capacity [MW] at year end

<!-- image -->

Table 4.11: Battery generation capacity at year end

| Generation capacity [MW]   |   2020 |   2021 |   2022 |   2023 |
|----------------------------|--------|--------|--------|--------|
| 1 - 10 MWh                 |   19.5 |   28.5 |   47.5 |   47.5 |
| 10 - 100 MWh               |    0   |  237.4 |  366.4 |  426.4 |
| > 100 MWh                  |    0   |    0   |    0   |   75   |
| Total                      |   19.5 |  265.9 |  413.9 |  548.9 |

Figure 4.19: Battery storage - energy storage capacity (MWh) at year end

<!-- image -->

Table 4.12: Battery storage capacity at year end

| Storage capacity [MWh]   |   2020 |   2021 |   2022 |   2023 |
|--------------------------|--------|--------|--------|--------|
| 1 - 10 MWh               |  15.24 |  19.74 |  30.46 |  30.46 |
| 10 - 100 MWh             |   0    | 144.2  | 297.45 | 327.45 |
| > 100 MWh                |   0    |   0    |   0    | 150    |
| Total                    |  15.24 | 163.94 | 327.91 | 507.91 |

Table 4.13: Battery storage consumption and generation

| Energy [GWh]   |   2022 |   2023 |
|----------------|--------|--------|
| Consumption    |  24.24 |  35.14 |
| Generation     |   3.69 |   7.17 |

## 4.4.3 Peat briquetting

Peat briquetting converts milled peat into briquettes for residential use. Peat briquette production has been reducing since the early 1990s, as shown in Figure 4.13. Production of peat briquettes in Ireland ended in 2023 with the closure of Bord na Móna's Derrinlough facility in Co Offaly.

## Figure 4.20: Annual production of peat briquettes

<!-- image -->

## 5 Final energy

The term final energy describes the energy that is directly consumed by an end-user. It covers energy delivered for manufacturing, transport of goods and people, and the day-to-day energy requirements of living, such as heating and cooking. SEAI analyses final energy consumption by fuel and by sector.

Final energy use excludes energy lost in the transformation or transmission of primary energy supply, because this energy is not available to the end user. Multiple primary energy sources may be aggregated and transformed into a single final energy type for an end user. For example, when an end user consumes electricity (as final energy), that electricity originated from a blend of wind, natural gas, etc ., (that is, primary energy sources). Similarly, final energy use covers the energy in petrol and diesel consumed by end users, but not the energy that was needed to convert crude oil into that petrol and diesel in a refinery.

Final energy use is important, because individuals and businesses have direct control over how they decide to consume it - petrol vs . diesel vs. electric vehicles for surface transport, gas vs . oil vs. heatpumps for heating, etc.

## 5.1 Final energy consumption by energy type

In evaluating final energy use or consumption in Ireland, SEAI collects data on each fuel, or energy type, from various sources:

- · Aggregated electricity consumption data collected by the meter registration system operator (MRSO, a function within ESB Networks).
- · Aggregated gas consumption data collected by Gas Networks Ireland (GNI).
- · Oil supply data reported to the DECC for the payment of the National Oil Reserves Agency (NORA) levy.
- · Biofuel data collected by NORA for the Renewable Transport Fuel Obligation (RTFO).
- · Fuel consumption data reported by permit holders to the EPA under EU Emissions Trading System (ETS).
- · Aggregated carbon tax receipts published by the Central Statistics Office (CSO).
- · SEAI surveys of solid fuel suppliers.
- · SEAI surveys of biomass/wood suppliers.
- · Other data requests made by SEAI.
- · SEAI data on the number and size of heat pumps and solar thermal collectors in domestic and nondomestic buildings.
- · Aggregated data from SEAI's domestic and non-domestic Building Energy Rating (BER) database on the number and size of heat pumps and solar thermal collectors

Figure 5.1 shows the current percentage breakdown of Ireland's final energy use by energy type. Oil products account for more than half of Ireland's final energy use, followed by electricity, gas, renewables, coal and peat, in that order.

Oil makes up a significant share of final energy in each sector. Ireland is almost completely dependent on oil for the servicing of its transport sector, and that sector is Ireland's largest end use of energy.

Electricity from renewable sources ( e.g. wind, solar PV, renewable waste) is included in the 'electricity' energy type for final energy use, not 'renewables'. Final consumption of electricity includes grid-supplied electricity

as well as electricity that is generated and consumed on the same site without entering the grid (referred to as auto-production or auto-consumption).

The 'renewables' energy type in final energy comprises the combustion of biomass and biogas for heat, the combustion of biofuels in transport, solar thermal and ambient heat ( via heat pumps). Similarly, consumption of oil, gas, coal and peat reported here is the direct consumption of these fuels and excludes fuels consumed for generation of electricity, non-energy use, and those converted into other fuels as discussed in section 4.

Figure 5.1: Share of 2023 final energy consumption by energy type

<!-- image -->

Figure 5.2 shows the annual trends in final energy use by energy type for the most recent 21-year period. Table 5.1 provides numerical details on the absolute values, relative shares, and percentage changes in the final energy use by energy type shown in Figure 5.2. Although Ireland remains heavily reliant on oil, its consumption has decreased, in absolute and percentage terms, over the period presented. Decreases were precipitated by two events: the economic downturn from 2008 to 2012 and the COVID-19 impact in 2020 and 2021. Outside of these events, oil consumption has increased each year. Other general trends over the period shown have been decreases in the consumption of coal and peat, and increases in the consumption of gas, electricity and renewables.

Figure 5.2: Total final consumption by energy type

<!-- image -->

Table 5.1: Final energy consumption by energy type (share)

| Energy [TWh]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Oil            | 72.13 (56.9%) | 71.63 (56.6%) | 75.40 (56.8%) | 78.34 (57.1%) | 78.82 (57.0%) | 81.93 (56.6%) | 81.67 (56.5%) | 67.75 (51.8%) | 69.50 (52.0%) | 77.02 (55.2%) | 78.29 (55.6%) |
| Electricity    | 24.87 (19.6%) | 24.82 (19.6%) | 25.79 (19.4%) | 26.38 (19.2%) | 26.63 (19.3%) | 27.87 (19.3%) | 28.41 (19.7%) | 28.63 (21.9%) | 29.92 (22.4%) | 30.33 (21.7%) | 31.57 (22.4%) |
| Natural gas    | 18.94 (14.9%) | 18.79 (14.9%) | 19.92 (15.0%) | 20.80 (15.2%) | 21.12 (15.3%) | 22.76 (15.7%) | 22.89 (15.8%) | 22.75 (17.4%) | 22.65 (16.9%) | 20.99 (15.0%) | 19.30 (13.7%) |
| Renewables     | 3.85 (3.0%)   | 4.42 (3.5%)   | 4.66 (3.5%)   | 4.69 (3.4%)   | 5.35 (3.9%)   | 5.38 (3.7%)   | 5.70 (3.9%)   | 5.64 (4.3%)   | 5.74 (4.3%)   | 6.50 (4.7%)   | 7.37 (5.2%)   |
| Coal           | 4.08 (3.2%)   | 4.00 (3.2%)   | 4.11 (3.1%)   | 4.24 (3.1%)   | 3.47 (2.5%)   | 3.75 (2.6%)   | 3.09 (2.1%)   | 3.16 (2.4%)   | 3.20 (2.4%)   | 2.27 (1.6%)   | 1.74 (1.2%)   |
| Peat           | 2.54 (2.0%)   | 2.33 (1.8%)   | 2.34 (1.8%)   | 2.30 (1.7%)   | 2.20 (1.6%)   | 2.30 (1.6%)   | 2.13 (1.5%)   | 2.20 (1.7%)   | 2.10 (1.6%)   | 1.87 (1.3%)   | 1.63 (1.2%)   |
| Non-ren. waste | 0.45 (0.4%)   | 0.48 (0.4%)   | 0.51 (0.4%)   | 0.48 (0.4%)   | 0.66 (0.5%)   | 0.64 (0.4%)   | 0.66 (0.5%)   | 0.62 (0.5%)   | 0.63 (0.5%)   | 0.68 (0.5%)   | 0.87 (0.6%)   |
| Total          | 126.86 (100%) | 126.47 (100%) | 132.74 (100%) | 137.23 (100%) | 138.27 (100%) | 144.62 (100%) | 144.55 (100%) | 130.75 (100%) | 133.73 (100%) | 139.65 (100%) | 140.77 (100%) |

## 5.2 Final energy consumption by sector

In calculating the final energy use by sector, SEAI uses the data on final energy use of each fuel type as described in section 5.1 and apportions it to each sector using data from, among other things:

- · CSO's most recent annual Business Energy Use Survey.
- · SEAI solid fuel and biomass/wood supplier surveys indicating sales to industry, commercial and residential sectors.
- · Aggregated metered electricity consumption in each sector.
- · Aggregated metered gas consumption in each sector.
- · SEAI's Public Sector Monitoring and Reporting Programme.

Figure 5.3 shows the share of each sector in final energy consumption. The transport sector consumes more than 40% of total final energy, more than the next two sectors (residential and industry) combined. The services sector contains both commercial and public services, a further breakdown is given in section 5.2.4.

Figure 5.3: Share of 2023 final energy consumption by sector

<!-- image -->

Figure 5.4 shows the annual final energy demand broken out by sector. The broad reduction in final energy use across all sectors from 2008 to 2012 is attributed to the international economic downturn, with the industry, transport and services sectors returning to growth after 2012, and growth in the residential sector delayed until 2014.

The reduction in 2020 final energy use was mostly due to the COVID-19 restrictions and was almost entirely limited to the transport sector. Prior to 2020, final energy demand for transport had risen every year since 2012 as activity growth outstripped efficiency improvements. Transport remains the sector with greatest final energy use, followed in order by the residential sector, industry and services.

## Figure 5.4: Final energy consumption by sector

Table 5.2 provides absolute values and relative shares in the final energy consumption by sector.

<!-- image -->

Table 5.2: Final energy consumption by sector (share)

| Energy [TWh]    | 2013             | 2014                    | 2015             | 2016               | 2017               | 2018                 | 2019                    | 2020                    | 2021                    | 2022                    | 2023                 |
|-----------------|------------------|-------------------------|------------------|--------------------|--------------------|----------------------|-------------------------|-------------------------|-------------------------|-------------------------|----------------------|
| Transport       | 50.57 (39.9%)    | 52.58 (41.6%)           | 55.67 (41.9%)    | 57.79 (42.1%)      | 59.38 (42.9%)      | 60.87 (42.1%)        | 61.36 (42.5%)           | 45.53 (34.8%)           | 48.74 (36.4%)           | 58.53 (41.9%)           | 61.14 (43.4%)        |
| Residential     | 34.46 (27.2%)    | 31.20 (24.7%)           | 33.17            | 34.40              | 32.94              | 35.07                | 34.17                   | 37.10                   | 35.50                   | 31.08                   | 29.64                |
|                 | 21.80            | 23.51 (18.6%)           | (25.0%)          | (25.1%)            | (23.8%)            | (24.3%)              | (23.6%)                 | (28.4%)                 | (26.5%)                 | (22.3%)                 | (21.1%) 24.01        |
| Industry        | (17.2%)          |                         | 23.35 (17.6%)    | 24.28 (17.7%)      | 25.15 (18.2%)      | 25.87 (17.9%)        | 25.55 (17.7%)           | 26.27 (20.1%)           | 25.99 (19.4%)           | 24.79 (17.8%)           | (17.1%) 22.58        |
| Services        | 17.14 (13.5%)    | 16.52 (13.1%)           | 17.98 (13.5%)    | 18.13 (13.2%)      | 18.05 (13.1%)      | 19.90 (13.8%)        | 20.54 (14.2%)           | 18.91 (14.5%)           | 20.59 (15.4%)           | 21.57 (15.4%)           | (16.0%) 3.16 (2.2%)  |
| Agriculture     | 2.60 (2.1%) 0.29 | 2.39 (1.9%) 0.28 (0.2%) | 2.32 (1.7%) 0.24 | 2.41 (1.8%)        | 2.48 (1.8%)        | 2.60 (1.8%) 0.32     | 2.66 (1.8%) 0.27 (0.2%) | 2.72 (2.1%) 0.22 (0.2%) | 2.70 (2.0%) 0.22 (0.2%) | 3.49 (2.5%) 0.20 (0.1%) | 0.23                 |
| Fisheries Total | (0.2%) 126.86    | 126.47                  | (0.2%) 132.74    | 0.22 (0.2%) 137.23 | 0.27 (0.2%) 138.27 | (0.2%) 144.62 (100%) | 144.55 (100%)           | 130.75                  | 133.73                  | 139.65                  | (0.2%) 140.77 (100%) |

## 5.2.1 Final energy consumption in industry

In determining the sectoral breakdown of energy consumption, SEAI uses a blend of data sources, including the BEUS from the CSO. In June 2024, the CSO published the latest version of the BEUS, which is based on energy use in 2022 [10]. SEAI uses this most recent BEUS release in estimating the breakdown of 2023 energy consumption across the industry sector.

Figure 5.5 shows the current share of each energy type in the final energy consumed in industry. Natural gas forms the largest share, at more than 40%, followed by electricity and oil. Renewables accounts for around 9%.

Figure 5.5: Shares of energy types in industry final energy

<!-- image -->

Figure 5.6 shows that natural gas, wastes and renewables have all increased their shares of industrial energy use over the period, while the shares of oil and coal have decreased. The share of electricity has declined slightly faster than overall energy consumption within the industry sector. The increase evident in renewables, is mainly due to the use of biomass in the wood-processing industry, and the use of the renewable portion of wastes in cement manufacturing.

There was also significant fuel switching from coal and oil to natural gas during this period. Because gas is less carbon intensive than oil or coal, this fuel switching, along with increased use of renewable energy, has resulted in lower average emissions per unit of energy used in industry during this period. Peat has not been used in the sector since 2018. Natural gas consumption in 2023 was around 17% below its peak in 2020.

Figure 5.6: Final energy in industry by energy type

Table 5.3 shows the quantities and relative shares of energy consumption in industry by energy type.

<!-- image -->

Table 5.3: Final energy in industry by energy type (share)

| Energy [TWh]   | 2013         | 2014         | 2015         | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023         |
|----------------|--------------|--------------|--------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|--------------|
| Natural gas    | 7.98 (36.6%) | 8.88 (37.8%) | 9.31 (39.9%) | 10.08 (41.5%) | 10.63 (42.3%) | 11.33 (43.8%) | 11.50 (45.0%) | 11.96 (45.5%) | 11.47 (44.1%) | 10.50 (42.4%) | 9.92 (41.3%) |
| Electricity    | 6.29 (28.8%) | 6.69 (28.4%) | 6.52 (27.9%) | 6.73 (27.7%)  | 6.72 (26.7%)  | 6.44 (24.9%)  | 6.37 (24.9%)  | 6.77 (25.8%)  | 6.79 (26.1%)  | 6.61 (26.7%)  | 6.71 (27.9%) |
| Oil            | 4.48 (20.6%) | 4.20 (17.9%) | 3.68 (15.8%) | 3.69 (15.2%)  | 3.69 (14.7%)  | 3.91 (15.1%)  | 3.88 (15.2%)  | 3.84 (14.6%)  | 3.97 (15.3%)  | 4.03 (16.3%)  | 3.91 (16.3%) |
| Renewables     | 1.64 (7.5%)  | 2.00 (8.5%)  | 2.08 (8.9%)  | 2.05 (8.4%)   | 2.25 (8.9%)   | 2.32 (9.0%)   | 2.22 (8.7%)   | 2.19 (8.3%)   | 2.09 (8.0%)   | 2.14 (8.6%)   | 1.99 (8.3%)  |
| Non-ren. waste | 0.45 (2.1%)  | 0.48 (2.1%)  | 0.51 (2.2%)  | 0.48 (2.0%)   | 0.66 (2.6%)   | 0.64 (2.5%)   | 0.66 (2.6%)   | 0.62 (2.4%)   | 0.63 (2.4%)   | 0.68 (2.7%)   | 0.87         |
| Coal           | 0.96 (4.4%)  | 1.24 (5.3%)  | 1.23 (5.3%)  | 1.24 (5.1%)   | 1.19 (4.7%)   | 1.23 (4.7%)   | 0.92 (3.6%)   | 0.88 (3.4%)   | 1.04 (4.0%)   | 0.82 (3.3%)   | 0.61 (2.5%)  |
| Peat           | 0.01 (0.0%)  | 0.01 (0.0%)  | 0.01 (0.0%)  | 0.01 (0.0%)   | 0.01 (0.0%)   | 0.01 (0.0%)   | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)       |
| Total          | 21.80 (100%) | 23.51 (100%) | 23.35 (100%) | 24.28 (100%)  | 25.15 (100%)  | 25.87 (100%)  | 25.55 (100%)  | 26.27 (100%)  | 25.99 (100%)  | 24.79 (100%)  | 24.01 (100%) |

## 5.2.2 Final energy consumption in transport

Fuel consumption in transport is often closely aligned to the mode of transport used: jet kerosene is used for air transport; fuel oil for shipping; petrol and liquefied petroleum gas (LPG) are almost exclusively used for road transport; and diesel is used for road transport, domestic navigation 8 , and rail.

Figure 5.7 shows the share of each energy type in transport energy consumption. Figure 5.7 shows the share of energy types in transport in 2023. Figure 5.8 and Table 5.4 show the trends in transport's final energy use, split by energy type over the last 21 years. Blended fuels (fossil fuels and biofuels) are reported separately as their renewable and non-renewable constituent components, despite being consumed as blended products.

The most important point to note is that transport remains almost completely dependent on fossil fuels, particularly oil products. This lack of fuel diversity is unique amongst the sectors of final energy consumption. Renewables made up a relatively small share of transport energy use in 2023. Electricity also remains a small share of transport energy use, which is split between electric rail (Dublin Area Rapid Transit (DART) and Luas) and electric vehicles (mostly private cars). This has meant that there has been very little decarbonisation of the transport fuel mix to date, with transport greenhouse gas emissions remaining tightly coupled to energy use.

There was a clear shift from petrol to diesel over the time period, due to the switch to diesel private cars accelerated by the changes to the private car tax system from 2008 onwards.

Biopropane (also referred to as bioLPG) is a biofuel ( i.e. renewable liquid transport fuel) that is used in place of LPG. To avoid the disclosure of commercially sensitive data, SEAI includes biopropane in the biodiesel figures in the transport sector in the national energy statistics.

Figure 5.7: Shares of energy types in transport final energy

<!-- image -->

Figure 5.8: Final energy in transport sector by energy type

<!-- image -->

Table 5.4: Final energy in transport sector by energy types (share)

| Energy [TWh]    | 2013          | 2014                              | 2015                                  | 2016                           | 2017                    | 2018               | 2019          | 2020             | 2021             | 2022          | 2023          |
|-----------------|---------------|-----------------------------------|---------------------------------------|--------------------------------|-------------------------|--------------------|---------------|------------------|------------------|---------------|---------------|
| Diesel / gasoil | 27.50 (54.4%) | 29.25 (55.6%)                     | 31.72 (57.0%)                         | 34.32 (59.4%)                  | 34.80 (58.6%)           | 36.31 (59.6%)      | 36.80 (60.0%) | 31.83 (69.9%)    | 33.98 (69.7%)    | 35.50 (60.7%) | 35.10 (57.4%) |
| Jet kerosene    | 7.85 (15.5%)  | 8.70 (16.5%)                      | 9.84                                  | 10.10                          | 11.88                   | 12.83 (21.1%)      | 12.98 (21.1%) | 4.63 (10.2%)     | 5.18             | 11.84         | 13.36         |
|                 | 13.93 (27.5%) | 13.18 (25.1%)                     | (17.7%)                               | (17.5%)                        | (20.0%)                 |                    |               |                  | (10.6%)          | (20.2%)       | (21.8%)       |
| Gasoline        |               |                                   | 12.50 (22.4%)                         | 11.66 (20.2%)                  | 10.52                   | 9.59 (15.7%)       | 9.08 (14.8%)  | 6.73 (14.8%)     | 7.13 (14.6%)     | 8.12 (13.9%)  | 8.65 (14.1%)  |
| Biodiesel       | 0.86 (1.7%)   | 1.04                              | 1.14                                  | 1.00                           | (17.7%) 1.52 (2.6%)     | 1.48 (2.4%)        | 1.90          | 1.82 (4.0%)      | 1.87 (3.8%)      | 2.37 (4.1%)   | 3.13          |
| Bioethanol      | 0.33          | (2.0%) 0.31                       | 0.35                                  | 0.38                           | 0.34                    | 0.32               | (3.1%) 0.30   | 0.23             | 0.24             | 0.27          | (5.1%) 0.38   |
| Electricity     | (0.7%) 0.04   | (0.6%) 0.04                       | (0.6%)                                | (0.7%)                         | (0.6%)                  | (0.5%) 0.07        | (0.5%) 0.09   | (0.5%) 0.10      | (0.5%) 0.15      | (0.5%) 0.22   | (0.6%) 0.33   |
| Natural gas     | 0.04 (0.1%)   | (0.1%)                            | (0.1%)                                | (0.4%)                         | (0.4%) 0.03             | (0.4%) 0.02        | (0.3%) 0.02   | (0.4%)           | (0.4%)           | 0.19 (0.3%)   | 0.18 (0.3%)   |
| LPG             | 0.02 (0.0%)   | 0.03 0.02                         | 0.03                                  | 0.25 (0.1%)                    | 0.05 (0.1%) 0.24 (0.0%) | (0.1%) 0.26 (0.0%) | 0.20 (0.0%)   | 0.18 0.01 (0.0%) | 0.19 0.01 (0.0%) | 0.02 (0.0%)   | 0.02 (0.0%)   |
| Fuel oil        | (0.1%) 0 (0%) | (0.1%) (0.0%) 0 (0%) 52.58 (100%) | (2.1%) 0.04 (0.1%) 0.05 (0.1%) 0 (0%) | (1.7%) 0.05 (0.1%) 0.03 0 (0%) | 0 (0%)                  | 0 (0%)             | (0.1%) 0 (0%) | (0.2%) 0 (0%)    | (0.3%) 0 (0%)    | (0.4%) 0 (0%) | (0.5%) 0 (0%) |

Figure 5.9 shows the current share of each subsector in transport by final energy. Road transport accounts for just over 75% of energy consumption in the transport sector, followed by international aviation at around 22%. Navigation (domestic), rail, pipeline and domestic aviation account for the remaining 3%.

SEAI collects data on the quantity of each fuel sold for consumption in road transport from the national oil levy administration (OLA) operated by the Department of Environment, Climate and Communications. SEAI uses various methods to further disaggregate road transport energy consumption into:

- · Private car - vehicles in the private taxation class
- · Freight - vehicles in the goods taxation class with an unladen weight equal to or greater than 2,033 kg.
- · Light goods vehicle - vehicles in the goods taxation class with an unladen weight less than 2,033 kg.
- taxation classes. This includes public and
- · Public passenger - vehicles in the large PSV and small PSV private buses, coaches, taxis and hackneys.
- · Fuel tourism - defined as fuel that is bought within the state by motorists and hauliers but consumed outside the State.
- · Road unspecified - the balance of recorded road transport fuel consumption that is not attributable to the items above. This includes fuel consumed by vehicles for which insufficient data is available. This includes vehicles taxed as motorcycles , vintage/veteran , hearses , motor caravan youth , community bus or school bus . It also includes state-owned vehicles, diplomatic vehicles, emergency vehicles, and vehicles exempt under the Disabled Drivers and Disabled Passengers (Tax Concessions) Regulations. Fuel consumption by vehicles not under taxation ( e.g. foreign registered vehicles) and not reflected in the fuel tourism end use would also be captured here. The unspecified figure also, by default, accounts for any discrepancy between the estimated and the real world energy demand of the individual road transport modes above.

Figure 5.9: Shares of subsectors in transport final energy

<!-- image -->

Figure 5.10 shows the trend for energy use of transport by subsector over the period. Transport has been the sector most responsive to changes in economic growth. Transport energy use and CO2 emissions peaked in 2007, before falling sharply during the recession. It returned to growth in 2013, but by 2021, total transport energy use was still below the 2007 peak. The energy use of light goods vehicles (LGV) is estimated from 2008 onwards. Prior to 2008, the energy use of this subsector was included in the 'unspecified' category.

Private car energy use dominates and accounted for nearly 40% of transport energy use. Private car energy use declined briefly during the recession in 2009 and 2010 but returned to growth in 2011. It peaked in 2015 and remained relatively flat until 2019, before the sharp drop in 2020. In 2023 consumption by private cars has returned to 99% of pre-pandemic levels (2019).

Aviation energy use is notable in that it usually makes up a large share of transport energy use in Ireland, particularly since 2000, but can be severely affected by external factors, such as recessions or the COVID-19 pandemic. International aviation energy consumption fell by 44% between 2007 and 2012 during the recession. It returned to strong growth after 2012, reaching an all-time-high in 2019, 6.8% above the previous 2007 peak, before the dramatic fall in 2020. In 2022, consumption in international aviation had returned to around the same level as 2017, followed by a further increase to a new record high in 2023.

Road freight energy use also saw a large reduction during the recession, falling by 49% between 2007 and 2013. It has increased since, but remains below the 2007 peak. These changes are due to changes in the amount of goods transported, as discussed further in section 10.3.4.

Figure 5.10: Final energy in transport by subsector

<!-- image -->

Table 5.5: Transport final energy by subsector (share)

| Energy [TWh]             | 2013          | 2014               | 2015               | 2016               | 2017          | 2018               | 2019          | 2020          | 2021          | 2022          | 2023                |
|--------------------------|---------------|--------------------|--------------------|--------------------|---------------|--------------------|---------------|---------------|---------------|---------------|---------------------|
| Road private car         | 24.45 (48.4%) | 25.08 (47.7%)      | 25.19 (45.3%)      | 24.81 (42.9%)      | 24.36 (41.0%) | 24.36 (40.0%)      | 24.63 (40.1%) | 20.16 (44.3%) | 21.42 (43.9%) | 23.24 (39.7%) | 24.40 (39.9%)       |
| Road freight             | 6.76 (13.4%)  | 7.23 (13.7%)       | 7.28 (13.1%)       | 8.55 (14.8%)       | 8.70 (14.6%)  | 8.53 (14.0%)       | 9.18 (15.0%)  | 8.43 (18.5%)  | 9.25 (19.0%)  | 9.17 (15.7%)  | 9.32                |
| Road unspecified         | 2.07 (4.1%)   | 1.52 (2.9%)        | 1.55 (2.8%)        | 2.41 (4.2%)        | 5.31 (8.9%)   | 5.68 (9.3%)        | 4.52 (7.4%)   | 4.68 (10.3%)  | 3.88 (8.0%)   | 5.19 (8.9%)   | (15.2%) 5.23 (8.6%) |
| Road light goods vehicle | 4.13 (8.2%)   | 4.33 (8.2%)        | 4.39 (7.9%)        | 4.18 (7.2%)        | 4.10 (6.9%)   | 3.97 (6.5%)        | 3.82 (6.2%)   | 3.45 (7.6%)   | 3.20 (6.6%)   | 3.52 (6.0%)   | 3.49 (5.7%)         |
| Road fuel tourism        | 2.44 (4.8%)   | 2.81 (5.4%)        | 4.51 (8.1%)        | 4.47 (7.7%)        | 1.92 (3.2%)   | 2.17 (3.6%)        | 2.89 (4.7%)   | 0.94 (2.1%)   | 2.41 (4.9%)   | 2.29 (3.9%)   | 2.05 (3.3%)         |
| Road public passenger    | 1.65 (3.3%)   | 1.58 (3.0%)        | 1.55 (2.8%)        | 1.54 (2.7%)        | 1.51 (2.5%)   | 1.59 (2.6%)        | 1.59 (2.6%)   | 1.38 (3.0%)   | 1.40 (2.9%)   | 1.46 (2.5%)   | 1.52 (2.5%)         |
| International aviation   | 7.80 (15.4%)  | 8.65 (16.5%)       | 9.79 (17.6%)       | 10.04 (17.4%)      | 11.82 (19.9%) | 12.77 (21.0%)      | 12.91 (21.0%) | 4.58 (10.1%)  | 5.12 (10.5%)  | 11.76 (20.1%) | 13.28 (21.7%)       |
| Navigation               | 0.67 (1.3%)   | 0.84 (1.6%)        | 0.83 (1.5%)        | 1.00 (1.7%)        | 0.88 (1.5%)   | 0.98 (1.6%)        | 1.04 (1.7%)   | 1.27 (2.8%)   | 1.36 (2.8%)   | 1.15 (2.0%)   | 1.08 (1.8%)         |
| Rail                     | 0.49 (1.0%)   | 0.45               | 0.46               | 0.47               | 0.48 (0.8%)   | 0.49               | 0.51 (0.8%)   | 0.42 (0.9%)   | 0.45 (0.9%)   | 0.49 (0.8%)   | 0.52 (0.8%)         |
| Pipeline                 | 0.04 (0.1%)   | (0.9%) 0.03 (0.1%) | (0.8%) 0.05 (0.1%) | (0.8%) 0.25 (0.4%) | 0.24 (0.4%)   | (0.8%) 0.26 (0.4%) | 0.20 (0.3%)   | 0.18 (0.4%)   | 0.18 (0.4%)   | 0.19 (0.3%)   | 0.17                |
| Domestic aviation        | 0.06 (0.1%)   | 0.06 (0.1%)        | 0.06 (0.1%)        | 0.07 (0.1%)        | 0.07 (0.1%)   | 0.07 (0.1%)        | 0.07 (0.1%)   | 0.05 (0.1%)   | 0.08 (0.2%)   | 0.08 (0.1%)   | (0.3%) 0.09 (0.1%)  |
| Total                    | 50.57 (100%)  | 52.58 (100%)       | 55.67 (100%)       | 57.79 (100%)       | 59.38 (100%)  | 60.87 (100%)       | 61.36 (100%)  | 45.53 (100%)  | 48.74 (100%)  | 58.53 (100%)  | 61.14 (100%)        |

## 5.2.3 Final energy consumption in residential

Figure 5.11 shows the most recent breakdown of energy consumption in the residential sector by energy type, while Figure 5.12 shows the annual quantities of each energy type consumed over the last 21 years. The shares of each have been relatively stable, with a gradual increase in the share of electricity, gas, and renewables, and a continuing, though gradual, decline in coal, peat and oil use.

Oil remains the dominant fuel in the residential sector at just over 40%. Electricity is the second largest source, with natural gas having the third largest share. Use of renewables directly in households has grown each year since 2017.

Table 5.6 provides the quantities and shares of each energy type in the residential sector over the last 11 years. It is notable that electricity consumption over the period was at its highest in 2021.

Figure 5.11: Shares of energy types in residential final energy

<!-- image -->

Figure 5.12: Final energy in residential by energy type

<!-- image -->

Table 5.6: Final energy in residential sector by energy type (share)

| Energy [TWh]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023                 |
|----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|----------------------|
| Oil            | 13.21 (38.3%) | 11.60 (37.2%) | 12.90 (38.9%) | 13.93 (40.5%) | 13.32 (40.4%) | 14.28 (40.7%) | 14.08 (41.2%) | 16.19 (43.6%) | 14.58 (41.1%) | 12.16 (39.1%) | 12.12                |
| Electricity    | 7.95 (23.1%)  | 7.71 (24.7%)  | 7.88 (23.8%)  | 7.87 (22.9%)  | 7.95 (24.1%)  | 8.17 (23.3%)  | 8.11 (23.7%)  | 8.69 (23.4%)  | 8.75 (24.6%)  | 8.22 (26.4%)  | (40.9%) 8.08 (27.3%) |
| Natural gas    | 7.05 (20.5%)  | 6.23 (20.0%)  | 6.46 (19.5%)  | 6.55 (19.0%)  | 6.46 (19.6%)  | 7.03 (20.0%)  | 6.88 (20.1%)  | 6.86 (18.5%)  | 6.92 (19.5%)  | 6.28 (20.2%)  | 5.41 (18.2%)         |
| Peat           | 2.53 (7.4%)   | 2.33 (7.5%)   | 2.33 (7.0%)   | 2.29 (6.7%)   | 2.19 (6.6%)   | 2.29 (6.5%)   | 2.13 (6.2%)   | 2.20 (5.9%)   | 2.10 (5.9%)   | 1.87 (6.0%)   | 1.63 (5.5%)          |
| Renewables     | 0.59 (1.7%)   | 0.59 (1.9%)   | 0.72 (2.2%)   | 0.77 (2.2%)   | 0.74 (2.3%)   | 0.80 (2.3%)   | 0.81 (2.4%)   | 0.89 (2.4%)   | 0.99 (2.8%)   | 1.12 (3.6%)   | 1.29 (4.3%)          |
| Coal           | 3.12 (9.0%)   | 2.75 (8.8%)   | 2.87 (8.7%)   | 2.99 (8.7%)   | 2.28 (6.9%)   | 2.52 (7.2%)   | 2.16 (6.3%)   | 2.27 (6.1%)   | 2.16 (6.1%)   | 1.44 (4.6%)   | 1.12 (3.8%)          |
| Non-ren. Waste | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)               |
| Total          | 34.46 (100%)  | 31.20 (100%)  | 33.17 (100%)  | 34.40 (100%)  | 32.94 (100%)  | 35.07 (100%)  | 34.17 (100%)  | 37.10 (100%)  | 35.50 (100%)  | 31.08 (100%)  | 29.64 (100%)         |

## 5.2.4 Final energy consumption in services

In determining the sectoral breakdown of commercial and public service energy use, SEAI uses a blend of data sources, including the Business Energy Use Survey (BEUS) from the CSO [10]. In June 2024, the CSO published the latest version of the BEUS, which is based on energy use in 2022. SEAI uses this most recent BEUS release in apportioning 2023 energy consumption across the commercial and public service sectors.

Figure 5.13: Shares of energy types in commercial and public services final energy

<!-- image -->

Figure 5.14: Final energy in commercial and public services by energy type

Figure 5.14 shows the changes in the fuel mix in the services sector over the period. The range of fuels used in this sector is small - essentially oil, gas and electricity. Oil and gas are used predominantly for space heating, but also for water heating, cooking and, in some subsectors, laundry. Electricity is used in buildings

<!-- image -->

for heating, air conditioning, water heating, lighting, lifts and escalators, automatic doors, and ICT. Electricity in services is also used for public lighting, off-road electric vehicles, and water and sanitation services.

Electricity use in services is driven by the changing structure of this sector and the general increase in use of ICT, electric heating and air conditioning. Data centres are also included under commercial services.

Small quantities were consumed in services until 2006; however, consumption of peat is no longer recorded as statistically significant. Similarly, the consumption of coal in the sector is now very low, at approximately 2 GWh per annum.

The quantities and shares of energy types consumed in commercial and public services are shown in Table 5.7.

Table 5.7: Final energy in commercial and public services (share)

| Energy [TWh]   | 2013          | 2014         | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|----------------|---------------|--------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Electricity    | 10.03 (58.5%) | 9.83 (59.5%) | 10.79 (60.0%) | 11.17 (61.6%) | 11.35 (62.9%) | 12.65 (63.5%) | 13.30 (64.7%) | 12.50 (66.1%) | 13.68 (66.4%) | 14.74 (68.3%) | 15.94 (70.6%) |
| Natural gas    | 3.86 (22.5%)  | 3.65 (22.1%) | 4.10 (22.8%)  | 3.93 (21.7%)  | 3.79 (21.0%)  | 4.14 (20.8%)  | 4.31 (21.0%)  | 3.75 (19.8%)  | 4.07 (19.8%)  | 4.02 (18.6%)  | 3.80 (16.8%)  |
| Oil            | 2.81 (16.4%)  | 2.56 (15.5%) | 2.72 (15.1%)  | 2.53 (14.0%)  | 2.41 (13.4%)  | 2.64 (13.3%)  | 2.46 (12.0%)  | 2.14 (11.3%)  | 2.28 (11.1%)  | 2.21 (10.2%)  | 2.26 (10.0%)  |
| Renewables     | 0.43 (2.5%)   | 0.48 (2.9%)  | 0.37 (2.1%)   | 0.49 (2.7%)   | 0.49 (2.7%)   | 0.47 (2.3%)   | 0.47 (2.3%)   | 0.51 (2.7%)   | 0.56 (2.7%)   | 0.60 (2.8%)   | 0.58 (2.6%)   |
| Coal           | 0.01 (0.0%)   | 0.00 (0.0%)  | 0.00 (0.0%)   | 0.01 (0.0%)   | 0.01 (0.0%)   | 0.01 (0.0%)   | 0.01 (0.0%)   | 0.00 (0.0%)   | 0.00 (0.0%)   | 0.00 (0.0%)   | 0.00 (0.0%)   |
| Peat           | 0 (0%)        | 0 (0%)       | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        |
| Non-ren. waste | 0 (0%)        | 0 (0%)       | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        |
| Total          | 17.14 (100%)  | 16.52 (100%) | 17.98 (100%)  | 18.13 (100%)  | 18.05 (100%)  | 19.90 (100%)  | 20.54 (100%)  | 18.91 (100%)  | 20.59 (100%)  | 21.57 (100%)  | 22.58 (100%)  |

Figure 5.15 shows the current breakdown of final energy consumption by subsector in commercial services alone, while Figure 5.16 shows the timeseries of the annual final energy consumption in commercial services. Figure 5.17 shows the current share of energy types in public services alone and Figure 5.18 shows the corresponding timeseries of annual final energy consumption in public services.

Figure 5.15: Shares of final energy in commercial services by subsector

<!-- image -->

Figure 5.16: Final energy in commercial services by subsector (breakdown not available prior to 2009)

<!-- image -->

Figure 5.17: Shares of final energy in public services by subsector

<!-- image -->

Figure 5.18: Final energy in public services by subsector (breakdown not available prior to 2009)

<!-- image -->

## 6 Energy modes

It is useful to split energy supply or use into the three modes of electricity, transport and heat. These represent distinct energy services and markets, and also map onto national and European renewable energy targets. To avoid double counting across modes, any heat and transport energy provided by electricity (for example electric heaters and electric vehicles (EVs)) is counted in the electricity mode only, not the heat or transport modes. This ensures that summing across the three modes gives a consistent total energy use.

## 6.1 Final energy consumption by mode

Figure 6.1 shows the current split in final energy use between electricity, transport and heat. Figure 6.2 shows the historical trend of the three modes in terms of final energy use. Table 6.1 shows the quantities and shares of final energy use in each mode and changes relative to previous years.

The transport and heat modes historically account for approximately 40% of final energy use each, with the electricity mode accounting for the remaining 20%. However, electricity consumption has increased steadily over this period at a faster rate than total energy consumption. The heat mode tends to show the greatest year-to-year fluctuations, due to its sensitivity to weather effects. Section 9.2 provides more detail on weather effects on heating energy. Final energy use in transport decreased during the 2008-2012 recession, and again during the COVID-19 restrictions in 2020 and early 2021. Outside of these events, final energy use in the transport mode has increased each year.

Figure 6.1: Current split of final energy by mode of application

<!-- image -->

Figure 6.2: Final energy in electricity, transport and heat modes

<!-- image -->

Table 6.1: Final energy in electricity, transport and heat compared (share)

| Energy [TWh]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Electricity    | 24.87 (19.6%) | 24.82 (19.6%) | 25.79 (19.4%) | 26.38 (19.2%) | 26.63 (19.3%) | 27.87 (19.3%) | 28.41 (19.7%) | 28.63 (21.9%) | 29.92 (22.4%) | 30.33 (21.7%) | 31.57 (22.4%) |
| Transport      | 50.52         | 52.54         | 55.62         | 57.74         | 59.33         | 60.80         | 61.28         | 45.43         | 48.60         | 58.31         | 60.81         |
| Heat           | (39.8%)       | (41.5%)       | (41.9%)       | (42.1%)       | (42.9%)       | (42.0%)       | (42.4%)       | (34.7%)       | (36.3%)       | (41.8%)       | (43.2%)       |
|                | 51.47         | 49.11         | 51.32         | 53.11         | 52.30         | 55.95         | 54.86         | 56.69         | 55.21         | 51.02         | 48.38         |
|                | (40.6%)       |               | (38.7%)       | (38.7%)       | (37.8%)       | (38.7%)       | (38.0%)       | (43.4%)       | (41.3%)       | (36.5%)       |               |
|                |               | (38.8%)       |               |               |               |               |               |               |               |               | (34.4%)       |
|                | 126.86        | 126.47        | 132.74        | 137.23        | 138.27        | 144.62        | 144.55        | 130.75        | 133.73        | 139.65        | 140.77        |
| Total          |               | (100%)        | (100%)        |               |               |               |               |               |               |               | (100%)        |
|                | (100%)        |               |               | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        |               |

## 6.2 Heat mode

The heat mode captures all final energy consumption outside of transport and not in the form of electricity. It captures space, water and process heating not provided by electricity. It also includes fuel use in machinery outside of the transport sector: construction, mining, agriculture, forestry, fishing etc. The heat mode does not include fuel use outside of final energy consumption: fuel input to energy transformation or own use by energy sector (electricity generation, oil refining, gas refining etc. ).

Figure 6.3 shows the historical final energy use in the heat mode with and without a weather correction. SEAI uses the concept of degree days for weather normalisation across warmer and colder years, which is the established standard recommended by Eurostat [11]. Further details are provided in section 9.2.

Weather-corrected heat demand reached a broad minimum in the period of 2012 to 2015 (averaging 49.5 TWh), likely due to a combination of impacts from the economic recession, a period of (then) record high oil prices, and efficiency improvements in the heating and insulation of buildings. After 2015, reduced international oil prices coupled with the recovery of the Irish economy acted to increase heat demand. Heat demand has decreased again since 2020, coinciding with the end of COVID restrictions in 2021 followed by high energy prices and milder weather in 2022 and 2023.

Figure 6.3: Final energy use for heat, actual and weather corrected

<!-- image -->

## 6.2.1 Final energy in heat mode by sector

As shown in Figure 6.4 and detailed in Table 6.2, the residential sector is the largest end user of final energy in the heat mode, followed by industry, services, and agricultural and fisheries sectors.

Household demand for heat is strongly affected by weather, as evidenced by the historic peak in 2008, a year that had periods of extremely cold weather.

Figure 6.4: Final energy in heat mode by sector

<!-- image -->

Table 6.2: Final energy in heat mode by sector (share)

| Energy [TWh]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Residential    | 26.51 (51.5%) | 23.50 (47.8%) | 25.29         | 26.52         | 24.99 (47.8%) | 26.91 (48.1%) | 26.06 (47.5%) | 28.41 (50.1%) | 26.75 (48.4%) | 22.87 (44.8%) | 21.56 (44.6%) |
|                | 15.52         | 16.82         | (49.3%)       | (49.9%)       | 18.43 (35.2%) | 19.43 (34.7%) | 19.18 (35.0%) | 19.50         | 19.19         | 18.18         | 17.31         |
| Industry       | (30.1%)       | (34.2%)       | 16.83 (32.8%) | 17.54 (33.0%) |               |               |               | (34.4%)       | (34.8%)       | (35.6%)       | (35.8%)       |
| Services       | 7.11 (13.8%)  | 6.69 (13.6%)  | 7.19 (14.0%)  | 6.96 (13.1%)  | 6.70 (12.8%)  | 7.25 (13.0%)  | 7.24 (13.2%)  | 6.41 (11.3%)  | 6.91 (12.5%)  | 6.83 (13.4%)  | 6.64 (13.7%)  |
|                | 2.04          | 1.83          | 1.76          | 1.85          | 1.92          | 2.04          | 2.11          | 2.15          | 2.14          | 2.95          | 2.64          |
| Agriculture    | (4.0%)        | (3.7%)        | (3.4%)        | (3.5%)        | (3.7%)        | (3.6%)        | (3.8%)        | (3.8%)        | (3.9%)        | (5.8%)        | (5.5%)        |
| Fisheries      | 0.29          | 0.28          | 0.24          | 0.22          | 0.27          | 0.32          | 0.27          | 0.22          | 0.22          | 0.20          | 0.23          |
|                | (0.6%)        | (0.6%)        | (0.5%)        | (0.4%)        | (0.5%)        | (0.6%)        | (0.5%)        | (0.4%)        | (0.4%)        | (0.4%)        | (0.5%)        |
| Total          | 51.47         | 49.11         | 51.32         |               | 52.30         | 55.95         | 54.86         | 56.69         | 55.21         | 51.02         |               |
|                |               |               |               | 53.11         |               |               |               |               |               |               | 48.38         |
|                | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        |

## 6.2.2 Final energy in heat mode by fuel

Figure 6.5 and Table 6.3 detail the fuels and energy sources in the final energy heat mode. Oil remains the largest fuel type for the delivery of heat, followed closely by natural gas. The last two decades have seen Ireland shift from an oil dominance in the heat mode to near parity between oil and gas for heat supply. This was driven by Ireland's expanding gas network and an industrial transition from oil to gas. Since 2015, both oil and natural gas have been approximately equal sources of final energy for the heat mode, with oil always slightly leading.

Coal and peat combined make up just less than 10% of Ireland's final energy demand in the heat mode. These are followed by renewables and non-renewable waste.

Figure 6.5: Final energy in heat mode by fuel

<!-- image -->

Table 6.3: Final energy in heat mode by energy type (share)

| Energy [TWh]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Oil            | 22.84 (44.4%) | 20.47 (41.7%) | 21.31 (41.5%) | 22.22 (41.8%) | 21.60 (41.3%) | 23.19 (41.4%) | 22.80 (41.6%) | 24.55 (43.3%) | 23.20 (42.0%) | 21.55 (42.2%) | 21.17 (43.7%) |
| Natural gas    | 18.90 (36.7%) | 18.76 (38.2%) | 19.87 (38.7%) | 20.56 (38.7%) | 20.89 (39.9%) | 22.50 (40.2%) | 22.69 (41.4%) | 22.56 (39.8%) | 22.45 (40.7%) | 20.80 (40.8%) | 19.12 (39.5%) |
| Renewables     | 2.66 (5.2%)   | 3.07 (6.3%)   | 3.17 (6.2%)   | 3.31 (6.2%)   | 3.48 (6.7%)   | 3.58 (6.4%)   | 3.50 (6.4%)   | 3.60 (6.3%)   | 3.64 (6.6%)   | 3.86 (7.6%)   | 3.86 (8.0%)   |
| Coal           | 4.08 (7.9%)   | 4.00 (8.1%)   | 4.11 (8.0%)   | 4.24 (8.0%)   | 3.47 (6.6%)   | 3.75 (6.7%)   | 3.09 (5.6%)   | 3.16 (5.6%)   | 3.20 (5.8%)   | 2.27 (4.4%)   | 1.74 (3.6%)   |
| Peat           | 2.54 (4.9%)   | 2.33 (4.8%)   | 2.34 (4.6%)   | 2.30 (4.3%)   | 2.20 (4.2%)   | 2.30 (4.1%)   | 2.13 (3.9%)   | 2.20 (3.9%)   | 2.10 (3.8%)   | 1.87 (3.7%)   | 1.63 (3.4%)   |
| Non-ren. waste | 0.45 (0.9%)   | 0.48 (1.0%)   | 0.51 (1.0%)   | 0.48 (0.9%)   | 0.66 (1.3%)   | 0.64 (1.1%)   | 0.66 (1.2%)   | 0.62 (1.1%)   | 0.63 (1.1%)   | 0.68 (1.3%)   | 0.87 (1.8%)   |
| Total          | 51.47 (100%)  | 49.11 (100%)  | 51.32 (100%)  | 53.11 (100%)  | 52.30 (100%)  | 55.95 (100%)  | 54.86 (100%)  | 56.69 (100%)  | 55.21 (100%)  | 51.02 (100%)  | 48.38 (100%)  |

Figure 6.6 profiles oil use for final energy in the heat mode broken down by sector. The largest and most consistent reduction in oil use for heat has come from the industry sector, with the service sector also seeing smaller reductions.

Oil consumption for heat in the residential sector fell by 40% from 2010 to 2014, during a period of (then) record high oil prices, before trending upwards in the second half of the decade. It fell in 2021 and again in 2022, coinciding with the end of COVID restrictions, milder weather and a return of higher prices. Oil consumption in households remained at the similar level in 2023, another year with mild weather and high prices.

Figure 6.6: Final consumption of oil for heat by sector

<!-- image -->

## 6.3 Transport mode

The transport mode captures all energy consumption in transport, excluding electricity. The transport mode is equivalent to the transport sector (see section 5.2.2) minus electricity consumption in that sector.

## 6.3.1 Final energy in transport mode by subsector

Figure 6.7 and Table 6.4 show the trends and details of final energy use in the transport mode by subsector.

The road unspecified quantity in Figure 6.7 and Table 6.4 relates to measured consumption of transport fuels that cannot be definitively attributed to one of the road transport subsectors, and is composed entirely of petrol, road diesel and respective blended biofuels. See section 5.2.2 for more details.

Figure 6.7: Final energy in transport mode by subsector

<!-- image -->

Table 6.4: Final energy in transport mode by subsector (share)

| Energy [TWh]             | 2013          | 2014               | 2015               | 2016               | 2017          | 2018               | 2019          | 2020          | 2021          | 2022          | 2023                |
|--------------------------|---------------|--------------------|--------------------|--------------------|---------------|--------------------|---------------|---------------|---------------|---------------|---------------------|
| Road private car         | 24.45 (48.4%) | 25.08 (47.7%)      | 25.19 (45.3%)      | 24.81 (43.0%)      | 24.35 (41.0%) | 24.34 (40.0%)      | 24.60 (40.1%) | 20.11 (44.3%) | 21.33 (43.9%) | 23.08 (39.6%) | 24.14 (39.7%)       |
| Road freight             | 6.76 (13.4%)  | 7.23 (13.8%)       | 7.28 (13.1%)       | 8.55 (14.8%)       | 8.70 (14.7%)  | 8.53 (14.0%)       | 9.18 (15.0%)  | 8.43 (18.5%)  | 9.25 (19.0%)  | 9.17 (15.7%)  | 9.32                |
| Road unspecified         | 2.07 (4.1%)   | 1.52 (2.9%)        | 1.55 (2.8%)        | 2.41 (4.2%)        | 5.31 (9.0%)   | 5.68 (9.3%)        | 4.52 (7.4%)   | 4.68 (10.3%)  | 3.88 (8.0%)   | 5.19 (8.9%)   | (15.3%) 5.23 (8.6%) |
| Road light goods vehicle | 4.13 (8.2%)   | 4.33 (8.2%)        | 4.39 (7.9%)        | 4.18 (7.2%)        | 4.10 (6.9%)   | 3.97 (6.5%)        | 3.82 (6.2%)   | 3.45 (7.6%)   | 3.20 (6.6%)   | 3.51 (6.0%)   | 3.48 (5.7%)         |
| Road fuel tourism        | 2.44 (4.8%)   | 2.81 (5.4%)        | 4.51 (8.1%)        | 4.47 (7.7%)        | 1.92 (3.2%)   | 2.17 (3.6%)        | 2.89 (4.7%)   | 0.94 (2.1%)   | 2.41 (5.0%)   | 2.29 (3.9%)   | 2.05 (3.4%)         |
| Road public passenger    | 1.65 (3.3%)   | 1.58 (3.0%)        | 1.55 (2.8%)        | 1.54 (2.7%)        | 1.51 (2.5%)   | 1.59 (2.6%)        | 1.59 (2.6%)   | 1.38 (3.0%)   | 1.40 (2.9%)   | 1.45 (2.5%)   | 1.51 (2.5%)         |
| International aviation   | 7.80 (15.4%)  | 8.65 (16.5%)       | 9.79 (17.6%)       | 10.04 (17.4%)      | 11.82 (19.9%) | 12.77 (21.0%)      | 12.91 (21.1%) | 4.58 (10.1%)  | 5.12 (10.5%)  | 11.76 (20.2%) | 13.28 (21.8%)       |
| Navigation               | 0.67 (1.3%)   | 0.84 (1.6%)        | 0.83 (1.5%)        | 1.00 (1.7%)        | 0.88 (1.5%)   | 0.98 (1.6%)        | 1.04 (1.7%)   | 1.27 (2.8%)   | 1.36 (2.8%)   | 1.15 (2.0%)   | 1.08 (1.8%)         |
| Rail                     | 0.45 (0.9%)   | 0.41               | 0.42               | 0.42               | 0.44 (0.7%)   | 0.44               | 0.46 (0.8%)   | 0.37 (0.8%)   | 0.40 (0.8%)   | 0.45 (0.8%)   | 0.47                |
| Pipeline                 | 0.04 (0.1%)   | (0.8%) 0.03 (0.1%) | (0.7%) 0.05 (0.1%) | (0.7%) 0.25 (0.4%) | 0.24 (0.4%)   | (0.7%) 0.26 (0.4%) | 0.20 (0.3%)   | 0.18 (0.4%)   | 0.18 (0.4%)   | 0.19 (0.3%)   | (0.8%) 0.17 (0.3%)  |
| Domestic aviation        | 0.06 (0.1%)   | 0.06 (0.1%)        | 0.06 (0.1%)        | 0.07 (0.1%)        | 0.07 (0.1%)   | 0.07 (0.1%)        | 0.07 (0.1%)   | 0.05 (0.1%)   | 0.08 (0.2%)   | 0.08 (0.1%)   | 0.09 (0.1%)         |
| Total                    | 50.52 (100%)  | 52.54 (100%)       | 55.62 (100%)       | 57.74 (100%)       | 59.33 (100%)  | 60.80 (100%)       | 61.28 (100%)  | 45.43 (100%)  | 48.60 (100%)  | 58.31 (100%)  | 60.81 (100%)        |

## 6.3.2 Final energy use in transport mode by energy type

Figure 6.8 and Table 6.5 show the final energy use in the transport mode by fuel type. To avoid double counting across the transport and electricity modes, energy provided by electricity ( e.g. EVs) are counted in the electricity mode only, and so are excluded from this data.

In 2020, every single fuel type in the transport mode saw a reduction against its 2019 values, with an overall reduction in final energy use of 26% in transport. All fuels remained below pre-pandemic levels in 2021 and 2022 (with the exception of biodiesel). In 2023, biodiesel, bioethanol and jet kerosene surpassed prepandemic levels. Jet kerosene consumption reflects the growth in international aviation, while the increase in biodiesel and bioethanol reflect increased biofuel blending as well as the return of road transport energy consumption to near pre pandemic levels.

One significant long-term trend is the year-on-year reduction in petrol use since 2007, which continued into the COVID-impacted years (2020 and 2021). This was mostly driven by a sustained switch from petrol to diesel vehicles.

Liquid biofuels accounted for 5.7% of final energy in the transport mode in 2023.

Figure 6.8: Final energy in transport mode by fuel

<!-- image -->

Table 6.5: Final energy in transport mode by fuel (share)

| Energy [TWh]    | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023               |
|-----------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|--------------------|
| Diesel / gasoil | 27.50 (54.4%) | 29.25 (55.7%) | 31.72 (57.0%) | 34.32 (59.4%) | 34.80 (58.7%) | 36.31 (59.7%) | 36.80 (60.1%) | 31.83 (70.1%) | 33.98 (69.9%) | 35.50 (60.9%) | 35.10 (57.7%)      |
| Jet kerosene    | 7.85 (15.5%)  | 8.70 (16.6%)  | 9.84 (17.7%)  | 10.10 (17.5%) | 11.88 (20.0%) | 12.83 (21.1%) | 12.98 (21.2%) | 4.63 (10.2%)  | 5.18 (10.7%)  | 11.84 (20.3%) | 13.36 (22.0%)      |
| Gasoline        | 13.93 (27.6%) | 13.18 (25.1%) | 12.50 (22.5%) | 11.66 (20.2%) | 10.52 (17.7%) | 9.59 (15.8%)  | 9.08 (14.8%)  | 6.73 (14.8%)  | 7.13 (14.7%)  | 8.12 (13.9%)  | 8.65 (14.2%)       |
| Biodiesel       | 0.86 (1.7%)   | 1.04 (2.0%)   | 1.14 (2.1%)   | 1.00 (1.7%)   | 1.52 (2.6%)   | 1.48 (2.4%)   | 1.90 (3.1%)   | 1.82 (4.0%)   | 1.87 (3.8%)   | 2.37 (4.1%)   | 3.13 (5.1%)        |
| Bioethanol      | 0.33 (0.7%)   | 0.31 (0.6%)   | 0.35 (0.6%)   | 0.38 (0.7%)   | 0.34 (0.6%)   | 0.32 (0.5%)   | 0.30 (0.5%)   | 0.23 (0.5%)   | 0.24 (0.5%)   | 0.27 (0.5%)   | 0.38 (0.6%)        |
| Natural gas     | 0.04 (0.1%)   | 0.03 (0.1%)   | 0.05 (0.1%)   | 0.25 (0.4%)   | 0.24 (0.4%)   | 0.26 (0.4%)   | 0.20 (0.3%)   | 0.18 (0.4%)   | 0.19 (0.4%)   | 0.19 (0.3%)   | 0.18               |
| LPG             | 0.02 (0.0%)   | 0.02 (0.0%)   | 0.03 (0.1%)   | 0.03 (0.1%)   | 0.03 (0.0%)   | 0.02 (0.0%)   | 0.02 (0.0%)   | 0.01 (0.0%)   | 0.01 (0.0%)   | 0.02 (0.0%)   | (0.3%) 0.02 (0.0%) |
| Fuel oil        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)             |
| Total           | 50.52 (100%)  | 52.54 (100%)  | 55.62 (100%)  | 57.74 (100%)  | 59.33 (100%)  | 60.80 (100%)  | 61.28 (100%)  | 45.43 (100%)  | 48.60 (100%)  | 58.31 (100%)  | 60.81 (100%)       |

## 6.4 Electricity mode

The electricity mode captures all final energy consumption of electricity, regardless of sector. The electricity mode does not include electricity consumed outside of final energy consumption: energy transformation processes (refining, pumped storage), own use in power stations or transmission/distribution losses.

## 6.4.1 Final energy use in electricity mode by sector

Figure 6.9 shows the trends and breakdown of final energy consumption in the electricity mode across the main sectors. 2023 was a record high for final energy demand for electricity. In order of largest to smallest, the sectoral consumers are services, residential, industry, agriculture and fisheries, and transport (barely visible in Figure 6.9).

## Figure 6.9: Final consumption in electricity mode by sector

<!-- image -->

Table 6.6 provides the quantities and shares of final energy use of the electricity mode by sector over the last 11 years. Overall, the last 10 years have seen a significant increase in electricity consumption in services (+59%) and modest increases in residential (+2%) and industry (+7%). Consumption in agriculture remains low at 1.6% of the total. The percentage growth in using electricity in transport over the last 10- and 20-year period is significant, but the absolute quantity of electricity used in transport remains small. Electricity use in transport includes the DART rail system, the Luas light rail system and EVs on the road. Transport accounts for around 1% of consumption in the electricity mode.

Table 6.6: Final consumption in electricity mode by sector (share)

| Energy [TWh]        | 2013              | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023               |
|---------------------|-------------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|--------------------|
| Services            | 10.03 (40.3%)     | 9.83 (39.6%)  | 10.79 (41.8%) | 11.17 (42.3%) | 11.35 (42.6%) | 12.65 (45.4%) | 13.30 (46.8%) | 12.50 (43.7%) | 13.68 (45.7%) | 14.74 (48.6%) | 15.94 (50.5%)      |
| Residential         | 7.95 (32.0%)      | 7.71 (31.0%)  | 7.88          | 7.87          | 7.95 (29.9%)  | 8.17 (29.3%)  | 8.11          | 8.69          | 8.75          | 8.22          | 8.08               |
|                     | 6.29              | 6.69          | (30.6%)       | (29.8%)       | 6.72          | 6.44          | (28.5%)       | (30.4%)       | (29.2%) 6.79  | (27.1%)       | (25.6%) 6.71       |
| Industry            | (25.3%)           | (26.9%)       | 6.52 (25.3%)  | 6.73 (25.5%)  | (25.2%)       | (23.1%)       | 6.37 (22.4%)  | 6.77 (23.6%)  | (22.7%)       | 6.61 (21.8%)  | (21.2%) 0.52       |
| Agriculture         | 0.56 (2.2%)       | 0.56 (2.2%)   | 0.56 (2.2%)   | 0.56 (2.1%)   | 0.56 (2.1%)   | 0.56 (2.0%)   | 0.55 (1.9%)   | 0.57 (2.0%)   | 0.55 (1.9%)   | 0.53 (1.8%)   | (1.6%) 0.33 (1.0%) |
| Transport Fisheries | (0.2%) 0          | (0.2%) 0 (0%) | (0.2%) 0 (0%) | (0.2%) 0      | (0.2%) 0      | (0.2%) 0 (0%) | (0.3%) 0 (0%) | (0.3%) 0 (0%) | (0.5%) 0 (0%) | (0.7%) 0 (0%) | 0 (0%)             |
| Total               | (0%) 24.87 (100%) | 24.82         | 25.79 (100%)  | (0%) 26.38    | (0%) 26.63    | 27.87 (100%)  | 28.41         | 28.63         | 29.92         | 30.33         | 31.57 (100%)       |

## 6.5 Primary energy requirement by mode

Figure 6.10 shows the primary energy supply through the lens of the electricity, transport and heat modes. To avoid double counting, heat and transport energy provided by electricity is counted in the electricity mode only.

Figure 6.11 shows the historical trend in primary energy by mode. All three modes have a broadly similar share in primary energy. This differs from the mode split of final energy use (see section 6.1) where the electricity mode is approximately half that of heat and transport. This is because a significant amount of energy is lost in the thermal generation of electricity, and never reaches end users for final consumption. Therefore, the primary supply electricity mode is always substantially higher than the final use electricity mode. For more information on electricity generation inputs, outputs and efficiency, see section 4.2.

All three of the modes decreased during the economic downturn from 2008 to 2012. Transport grew to become the largest of the three modes from 2014 to 2019, before shrinking to become the smallest in 2020 due to the impact of the COVD-19 travel restrictions. Primary energy in transport overtook heat and electricity again 2022, continuing to grow in 2023 while the other two modes decreased.

In the context of the electricity mode, primary energy decreased in 2023 while final energy increased (see section 6.1). Increased demand for electricity was offset by increased electricity imports, continued growth in non-combustible renewables (solar PV and wind) and reduction in thermal generation, reducing the overall primary energy input to the electricity mode. Further details on electricity generation are provided in section 4.2.

Figure 6.10: Shares of primary energy by mode

<!-- image -->

Figure 6.11: Primary energy by mode

<!-- image -->

## 7 Energy-related greenhouse gas (GHG) emissions

In this section, GHG quantities from fuel combustion have been calculated using sector and fuel specific data from the EPA's National Inventory Submissions [3] (see section 2.3 for more details). GHG emissions associated with fugitive emissions ( e.g. from natural gas production and distribution, oil refining and storage, disused coal mines (1990-present) and also from coal mining (1990-1995)) are provided separately by the EPA in Ireland's National Inventory Submissions (1990-2022) [3] and in Ireland's Provisional Greenhouse Gas Emissions (1990-2023). [16]

## 7.1 GHG intensity of electricity consumption

Figure 7.1 shows the CO2eq emission intensity of Ireland's electricity consumed, which is measured in gCO2eq/kWh. The stacked bars show the share of GHG emissions by fuel for each kWh of electricity consumption in Ireland. It is important to note that the stacked bars in the graph represent the contributions of different fuels to the overall emission intensity of Ireland's electricity consumption, not the emission intensity of the individual fuels themselves.

Figure 7.1: GHG emissions per kWh of electricity consumption, with contribution by energy type

<!-- image -->

The CO2eq intensity of electricity consumption fell to a historic low in 2020, before increasing slightly in 2021 due to an increase in emissions from coal and, to a lesser extent, oil. The CO2eq intensity fell again in 2022 and 2023 due to a decrease the share of oil and coal in the generation mix. The dramatic overall improvements in annual CO2eq emission intensity, as seen in Figure 7.1, are due to reductions in using coal for electricity generation, increased generation from renewable sources and, in 2023, increased net imports.

Over the longer term, there has been a shift away from coal and oil, two of the fuels with the highest CO2eq intensity. These fuels have been replaced by a combination of high efficiency gas combined cycle gas turbine (CCGT) generation and renewables. Imported electricity is also considered as zero carbon in the context of national emissions, as emissions are counted in the jurisdiction in which they are emitted.

## 7.2 Energy-related GHG emissions by sector

This subsection provides a breakdown of energy-related GHG emissions by sector of final energy consumption in the National Energy Balance. In addition to presenting the direct GHG emissions from combustion in each sector, GHG emissions associated with electricity consumption in that sector are presented. Consequently, the resulting sectoral GHG emission totals provide an indication of the total energy related emissions that can be attributed to activity in each energy-use sector.

The approach used in this subsection differs to that used in the National GHG Inventory (along with the carbon budgets and sectoral emissions ceilings), where sectoral totals are based on emissions directly arising in each sector. Under the sectoral emissions ceiling, emissions arising from combustion of fuel in public electricity production are counted in under in the electricity sector regardless of where the electricity itself is consumed.

Figure 7.2, Figure 7.3 and Table 7.1 show the most recent and historical energy-related CO2eq emissions split by sector. In this case, the emissions from electricity generation are shown separately from the emissions from direct fossil fuel use in the end-use sectors.

International aviation is also shown separately. It is included in the National Energy Balance (in line with international practice) and so is included in the figures for transport energy use in this report. However, it is not included in the National Greenhouse Gas Inventory (in line with international practice) and is also not included in Ireland's national greenhouse gas emissions reduction targets for 2030 and 2050.

Excluding international aviation, energy-related CO2eq emissions reached a recent low point in 2020 before increasing slightly in 2021 and decreasing again in 2022 and 2023. Transport (excluding international aviation) provides the largest share of energy-related CO2eq emissions, followed by electricity generation, the residential sector, industry, international aviation, services, agriculture, other and fisheries, in that order. The 'other' category includes emissions from oil refineries, natural gas refining and peat briquetting.

Figure 7.2: Current sectoral shares of energy-related CO2eq

<!-- image -->

## Figure 7.3: Energy-related annual CO2eq emissions by sector 9

<!-- image -->

Table 7.1: Energy-related CO2eq by sector (share)

| GHG [MtCO 2 eq]                 | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023                 |
|---------------------------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|----------------------|
| Electricity generation          | 11.70 (31.0%) | 11.53 (30.9%) | 12.13 (30.9%) | 12.86 (31.5%) | 12.05 (30.1%) | 10.70 (26.8%) | 9.45 (24.6%)  | 8.86 (25.9%)  | 10.36 (28.7%) | 10.14 (27.3%) | 8.03                 |
| Transport (excl. int. aviation) | 10.92 (28.9%) | 11.20 (30.0%) | 11.69 (29.7%) | 12.21 (29.9%) | 12.05 (30.1%) | 12.22 (30.6%) | 12.22 (31.9%) | 10.29 (30.1%) | 10.97 (30.4%) | 11.64 (31.3%) | 11.68 (33.7%)        |
| Industry                        | 3.39 (9.0%)   | 3.61 (9.7%)   | 3.59 (9.1%)   | 3.71 (9.1%)   | 3.83 (9.6%)   | 4.05 (10.1%)  | 3.97 (10.3%)  | 4.02 (11.8%)  | 4.04 (11.2%)  | 3.81 (10.2%)  | 3.62                 |
| Residential                     | 7.07 (18.7%)  | 6.27 (16.8%)  | 6.71 (17.1%)  | 7.00 (17.1%)  | 6.51 (16.3%)  | 7.00 (17.5%)  | 6.73 (17.5%)  | 7.34 (21.5%)  | 6.87 (19.0%)  | 5.75 (15.5%)  | (10.4%) 5.35 (15.4%) |
| Services                        | 1.50 (4.0%)   | 1.41 (3.8%)   | 1.54 (3.9%)   | 1.45 (3.5%)   | 1.39 (3.5%)   | 1.51 (3.8%)   | 1.50 (3.9%)   | 1.31 (3.8%)   | 1.41 (3.9%)   | 1.39 (3.7%)   | 1.35 (3.9%)          |
| Agriculture                     | 0.59 (1.6%)   | 0.53 (1.4%)   | 0.51 (1.3%)   | 0.54 (1.3%)   | 0.55 (1.4%)   | 0.59 (1.5%)   | 0.61 (1.6%)   | 0.62 (1.8%)   | 0.62 (1.7%)   | 0.85 (2.3%)   | 0.76 (2.2%)          |
| Fisheries                       | 0.08 (0.2%)   | 0.07 (0.2%)   | 0.07 (0.2%)   | 0.06 (0.1%)   | 0.07 (0.2%)   | 0.08 (0.2%)   | 0.07 (0.2%)   | 0.06 (0.2%)   | 0.06 (0.2%)   | 0.05 (0.1%)   | 0.06 (0.2%)          |
| Other                           | 0.48 (1.3%)   | 0.44 (1.2%)   | 0.53 (1.3%)   | 0.42 (1.0%)   | 0.47 (1.2%)   | 0.52 (1.3%)   | 0.46 (1.2%)   | 0.48 (1.4%)   | 0.47 (1.3%)   | 0.47 (1.3%)   | 0.42 (1.2%)          |
| Total (excl. int. aviation)     | 35.72 (94.6%) | 35.06 (94.0%) | 36.77 (93.5%) | 38.24 (93.6%) | 36.92 (92.3%) | 36.67 (91.7%) | 35.02 (91.3%) | 32.99 (96.5%) | 34.79 (96.3%) | 34.11 (91.8%) | 31.27 (90.1%)        |
| International aviation          | 2.02 (5.4%)   | 2.24 (6.0%)   | 2.54 (6.5%)   | 2.60 (6.4%)   | 3.06 (7.7%)   | 3.31 (8.3%)   | 3.34 (8.7%)   | 1.19 (3.5%)   | 1.32 (3.7%)   | 3.04 (8.2%)   | 3.44 (9.9%)          |
| Total (incl. int. aviation)     | 37.74 (100%)  | 37.30 (100%)  | 39.30 (100%)  | 40.84 (100%)  | 39.98 (100%)  | 39.98 (100%)  | 38.36 (100%)  | 34.17 (100%)  | 36.12 (100%)  | 37.15 (100%)  | 34.71                |

## 7.2.1 Industry emissions

Approximately 60% of greenhouse gas emissions from industry are energy related. The total sectoral energyrelated CO2eq emissions as shown here include estimations of upstream emissions for the electricity consumed by industry. Figure 7.4 shows the energy-related CO2eq emissions from industry, detailing the onsite CO2eq emissions associated with direct fuel combustion and the upstream emissions associated with electricity consumption. Table 7.2 shows the quantities and relative shares of energy-related CO2eq emissions in industry by energy product.

Figure 7.4: Industry energy-related CO2eq emissions by energy type

<!-- image -->

Table 7.2: Quantities and shares of energy-related CO2eq emissions in industry (share)

| GHG [MtCO 2 eq]   | 2013         | 2014         | 2015         | 2016         | 2017         | 2018         | 2019         | 2020         | 2021         | 2022         | 2023         |
|-------------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|
| Natural gas       | 1.61 (25.4%) | 1.81 (27.0%) | 1.91 (28.7%) | 2.03 (29.0%) | 2.14 (31.1%) | 2.28 (35.0%) | 2.32 (38.1%) | 2.42 (39.6%) | 2.33 (36.4%) | 2.14 (35.6%) | 2.02 (38.0%) |
| Electricity       | 2.96 (46.6%) | 3.11 (46.3%) | 3.07 (46.0%) | 3.28 (47.0%) | 3.04 (44.2%) | 2.47 (37.9%) | 2.12 (34.8%) | 2.10 (34.3%) | 2.35 (36.8%) | 2.21 (36.8%) | 1.71 (32.0%) |
| Oil               | 1.26 (19.8%) | 1.19 (17.8%) | 1.07 (16.1%) | 1.08 (15.4%) | 1.07 (15.6%) | 1.14 (17.4%) | 1.12 (18.4%) | 1.10 (18.0%) | 1.15 (18.0%) | 1.15 (19.2%) | 1.10 (20.7%) |
| Non-ren. waste    | 0.18 (2.9%)  | 0.16 (2.4%)  | 0.18 (2.6%)  | 0.16 (2.3%)  | 0.20 (2.9%)  | 0.19 (3.0%)  | 0.20 (3.3%)  | 0.18 (3.0%)  | 0.20 (3.1%)  | 0.22 (3.6%)  | 0.28 (5.2%)  |
| Coal              | 0.33 (5.2%)  | 0.43 (6.4%)  | 0.42 (6.3%)  | 0.42 (6.1%)  | 0.41 (5.9%)  | 0.42 (6.5%)  | 0.32 (5.2%)  | 0.30 (5.0%)  | 0.36 (5.6%)  | 0.28 (4.7%)  | 0.21 (3.9%)  |
| Renewables        | 0.01 (0.1%)  | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.2%)  |
| Peat              | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.1%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.1%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  |
| Total             | 6.35 (100%)  | 6.71 (100%)  | 6.66 (100%)  | 6.99 (100%)  | 6.87 (100%)  | 6.52 (100%)  | 6.09 (100%)  | 6.12 (100%)  | 6.39 (100%)  | 6.02 (100%)  | 5.32 (100%)  |

## 7.2.2 Transport emissions

Figure 7.5 and Table 7.3 show the energy-related CO2eq emissions from transport, detailing emissions associated with direct fuel combustion and the upstream emissions associated with electricity consumption. Table 7.4 provides an emissions breakdown by subsector (includes direct and indirect emissions).

Figure 7.5: Transport energy-related emissions by energy type (including international aviation)

<!-- image -->

Table 7.3: Quantities and shares of energy-related CO2eq emissions in transport (share)

| GHG [MtCO 2 eq]   | 2013         | 2014         | 2015         | 2016         | 2017         | 2018         | 2019         | 2020         | 2021         | 2022         | 2023                 |
|-------------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|----------------------|
| Diesel / gasoil   | 7.34 (56.6%) | 7.80 (58.0%) | 8.46 (59.4%) | 9.16 (61.7%) | 9.29 (61.4%) | 9.69 (62.3%) | 9.82 (63.0%) | 8.50 (73.9%) | 9.07 (73.5%) | 9.48 (64.2%) | 9.38                 |
| Jet kerosene      | 2.03 (15.7%) | 2.25 (16.7%) | 2.55 (17.9%) | 2.61 (17.6%) | 3.07 (20.3%) | 3.32 (21.4%) | 3.36 (21.5%) | 1.20 (10.4%) | 1.34 (10.9%) | 3.06 (20.8%) | (61.7%) 3.46 (22.8%) |
| Gasoline          | 3.54 (27.3%) | 3.35 (24.9%) | 3.17 (22.3%) | 2.96 (20.0%) | 2.67 (17.6%) | 2.43 (15.6%) | 2.30 (14.8%) | 1.70 (14.8%) | 1.81 (14.6%) | 2.06 (13.9%) | 2.19 (14.4%)         |
| Electricity       | 0.02 (0.2%)  | 0.02 (0.1%)  | 0.02 (0.1%)  | 0.02 (0.2%)  | 0.02 (0.2%)  | 0.03 (0.2%)  | 0.03 (0.2%)  | 0.03 (0.3%)  | 0.05 (0.4%)  | 0.07 (0.5%)  | 0.08 (0.5%)          |
| Biodiesel         | 0.01 (0.1%)  | 0.02 (0.1%)  | 0.02 (0.1%)  | 0.02 (0.1%)  | 0.03 (0.2%)  | 0.03 (0.2%)  | 0.03 (0.2%)  | 0.03 (0.3%)  | 0.03 (0.3%)  | 0.04 (0.3%)  | 0.05 (0.3%)          |
| Natural gas       | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.05 (0.3%)  | 0.05 (0.3%)  | 0.05 (0.3%)  | 0.04 (0.3%)  | 0.04 (0.3%)  | 0.04 (0.3%)  | 0.04 (0.3%)  | 0.04 (0.2%)          |
| LPG               | 0.00 (0.0%)  | 0.01 (0.0%)  | 0.01 (0.0%)  | 0.01 (0.0%)  | 0.01 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00                 |
| Bioethanol        | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | (0.0%) 0.00 (0.0%)   |
| Fuel oil          | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)          |
| Total             | 12.96 (100%) | 13.46 (100%) | 14.24 (100%) | 14.83 (100%) | 15.14 (100%) | 15.55 (100%) | 15.59 (100%) | 11.51 (100%) | 12.35 (100%) | 14.76 (100%) | 15.20 (100%)         |

Table 7.4: Quantities and shares of transport CO2eq emissions by subsector, including GHG emissions from direct combustion and indirect GHG emissions from electricity use (share)

| GHG [MtCO 2 eq]                | 2013                 | 2014                 | 2015                 | 2016                | 2017                 | 2018                 | 2019                 | 2020                 | 2021                 | 2022                 | 2023                 |
|--------------------------------|----------------------|----------------------|----------------------|---------------------|----------------------|----------------------|----------------------|----------------------|----------------------|----------------------|----------------------|
| Road private car               | 6.19                 | 6.35                 | 6.37                 | 6.30 (42.4%)        | 6.14                 | 6.16                 | 6.19                 | 5.05                 | 5.38                 | 5.79                 | 5.97                 |
| Road freight                   | (47.8%) 1.75 (13.5%) | (47.2%) 1.86 (13.8%) | (44.7%) 1.87 (13.2%) | 2.22                | (40.6%) 2.22 (14.7%) | (39.6%) 2.19 (14.1%) | (39.7%) 2.33 (15.0%) | (43.9%) 2.13 (18.5%) | (43.6%) 2.34 (19.0%) | (39.2%) 2.30 (15.6%) | (39.3%) 2.29 (15.1%) |
| Road unspecified               | 0.52 (4.0%)          | 0.38 (2.8%)          | 0.39 (2.7%)          | (14.9%) 0.60 (4.1%) | 1.34 (8.9%)          | 1.44 (9.3%)          | 1.14 (7.3%)          | 1.17 (10.2%)         | 0.97 (7.9%)          | 1.30 (8.8%)          | 1.28 (8.4%)          |
| Road light goods vehicle       | 1.07 (8.2%)          | 1.12 (8.3%)          | 1.13 (7.9%)          | 1.08 (7.3%)         | 1.05 (6.9%)          | 1.02 (6.5%)          | 0.97 (6.2%)          | 0.87 (7.6%)          | 0.81 (6.6%)          | 0.88 (6.0%)          | 0.86 (5.6%)          |
| Road fuel tourism              | 0.63 (4.9%)          | 0.72 (5.4%)          | 1.16 (8.1%)          | 1.16 (7.8%)         | 0.49 (3.2%)          | 0.56 (3.6%)          | 0.73 (4.7%)          | 0.24 (2.1%)          | 0.61 (4.9%)          | 0.57 (3.9%)          | 0.50 (3.3%)          |
| Road public passenger services | 0.43 (3.3%)          | 0.40 (3.0%)          | 0.40 (2.8%)          | 0.40 (2.7%)         | 0.38 (2.5%)          | 0.41 (2.6%)          | 0.40 (2.6%)          | 0.35 (3.0%)          | 0.36 (2.9%)          | 0.37 (2.5%)          | 0.37 (2.4%)          |
| Navigation                     | 0.18 (1.4%)          | 0.22 (1.7%)          | 0.22 (1.6%)          | 0.27 (1.8%)         | 0.24 (1.6%)          | 0.26 (1.7%)          | 0.28 (1.8%)          | 0.34 (2.9%)          | 0.36 (2.9%)          | 0.31 (2.1%)          | 0.29 (1.9%)          |
| Rail                           | 0.15 (1.2%)          | 0.14 (1.0%)          | 0.14 (1.0%)          | 0.15 (1.0%)         | 0.15 (1.0%)          | 0.15 (1.0%)          | 0.15 (1.0%)          | 0.12 (1.1%)          | 0.13 (1.1%)          | 0.15 (1.0%)          | 0.15 (1.0%)          |
| Pipeline                       | 0.01 (0.1%)          | 0.01 (0.0%)          | 0.01 (0.1%)          | 0.05                | 0.05 (0.3%)          | 0.05 (0.3%)          | 0.04 (0.3%)          | 0.04 (0.3%)          | 0.04 (0.3%)          | 0.04 (0.3%)          | 0.04 (0.2%)          |
| Domestic aviation              | 0.02 (0.1%)          | 0.01 (0.1%)          | 0.02 (0.1%)          | (0.3%) 0.02 (0.1%)  | 0.02 (0.1%)          | 0.02 (0.1%)          | 0.02 (0.1%)          | 0.01 (0.1%)          | 0.02 (0.2%)          | 0.02 (0.1%)          | 0.02 (0.2%)          |
| Total (excl. int. aviation)    | 10.94 (84.4%)        | 11.22 (83.4%)        | 11.71 (82.2%)        | 12.23 (82.5%)       | 12.08 (79.8%)        | 12.25 (78.7%)        | 12.25 (78.6%)        | 10.32 (89.7%)        | 11.02 (89.3%)        | 11.72 (79.4%)        | 11.76 (77.4%)        |
| International aviation         | 2.02 (15.6%)         | 2.24 (16.6%)         | 2.54 (17.8%)         | 2.60 (17.5%)        | 3.06 (20.2%)         | 3.31 (21.3%)         | 3.34 (21.4%)         | 1.19 (10.3%)         | 1.32 (10.7%)         | 3.04 (20.6%)         | 3.44 (22.6%)         |
| Total (incl. int. aviation)    | 12.96 (100%)         | 13.46 (100%)         | 14.24 (100%)         | 14.83 (100%)        | 15.14 (100%)         | 15.55 (100%)         | 15.59 (100%)         | 11.51 (100%)         | 12.35 (100%)         | 14.76 (100%)         | 15.20 (100%)         |

## 7.2.3 Residential emissions

Figure 7.6 show the energy-related CO2eq emissions from residential, detailing emissions associated with direct fuel combustion and the upstream emissions associated with electricity consumption. There was a reduction in energy-related CO2eq emissions between 2010 and 2014, but a return to growth in 2015, 2016, 2018 and again in 2020. Emissions reduced again in 2021, 2022 and 2023, reflecting the decrease in consumption in the sector due to milder weather and high energy prices.

Figure 7.6: Residential energy-related CO2eq by fuel

<!-- image -->

Table 7.5: Quantities and shares of energy-related CO2eq emissions in the residential sector (share)

| GHG [MtCO 2 eq]   | 2013         | 2014         | 2015         | 2016         | 2017         | 2018         | 2019         | 2020         | 2021         | 2022         | 2023         |
|-------------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|
| Oil               | 3.44 (31.8%) | 3.02 (30.6%) | 3.35 (32.2%) | 3.62 (33.4%) | 3.46 (34.2%) | 3.70 (36.5%) | 3.65 (38.7%) | 4.20 (41.8%) | 3.79 (38.3%) | 3.16 (37.1%) | 3.14 (42.4%) |
| Electricity       | 3.74 (34.6%) | 3.58 (36.3%) | 3.71 (35.6%) | 3.84 (35.4%) | 3.60 (35.6%) | 3.13 (30.9%) | 2.70 (28.6%) | 2.69 (26.8%) | 3.03 (30.6%) | 2.75 (32.3%) | 2.06 (27.8%) |
| Natural gas       | 1.43 (13.2%) | 1.28 (13.0%) | 1.33 (12.7%) | 1.32 (12.2%) | 1.30 (12.9%) | 1.42 (14.0%) | 1.39 (14.8%) | 1.39 (13.9%) | 1.41 (14.2%) | 1.28 (15.1%) | 1.11 (14.9%) |
| Peat              | 1.01 (9.3%)  | 0.93 (9.4%)  | 0.93 (8.9%)  | 0.91 (8.4%)  | 0.88 (8.7%)  | 0.91 (9.0%)  | 0.85 (9.1%)  | 0.88 (8.8%)  | 0.84 (8.5%)  | 0.75 (8.8%)  | 0.66 (8.9%)  |
| Coal              | 1.18 (10.9%) | 1.04 (10.6%) | 1.09 (10.4%) | 1.13 (10.4%) | 0.86 (8.6%)  | 0.96 (9.4%)  | 0.82 (8.7%)  | 0.86 (8.6%)  | 0.82 (8.3%)  | 0.55 (6.5%)  | 0.43 (5.9%)  |
| Renewables        | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  |
| Non-ren. waste    | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  |
| Total             | 10.81 (100%) | 9.85 (100%)  | 10.42 (100%) | 10.84 (100%) | 10.11 (100%) | 10.13 (100%) | 9.43 (100%)  | 10.03 (100%) | 9.90 (100%)  | 8.50 (100%)  | 7.40 (100%)  |

## 7.2.4 Commercial and public services emissions

Figure 7.7 shows the primary energy-related CO2eq emissions of the services sector, distinguishing between the on-site CO2eq emissions associated with direct fuel combustion and the upstream emissions associated with electricity consumption.

Figure 7.7: Commercial and public services sector CO2eq emissions by energy type

<!-- image -->

Table 7.6: Quantities and shares of CO2eq emissions in commercial and public services (share)

| GHG [MtCO 2 eq]   | 2013         | 2014         | 2015         | 2016         | 2017         | 2018         | 2019         | 2020         | 2021         | 2022         | 2023         |
|-------------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|
| Electricity       | 4.72 (75.9%) | 4.56 (76.4%) | 5.07 (76.7%) | 5.44 (79.0%) | 5.13 (78.7%) | 4.85 (76.2%) | 4.43 (74.7%) | 3.87 (74.7%) | 4.73 (77.0%) | 4.93 (78.0%) | 4.05 (75.0%) |
| Natural gas       | 0.78 (12.6%) | 0.75 (12.5%) | 0.84 (12.8%) | 0.79 (11.5%) | 0.76 (11.7%) | 0.83 (13.1%) | 0.87 (14.7%) | 0.76 (14.7%) | 0.83 (13.5%) | 0.82 (13.0%) | 0.78 (14.4%) |
| Oil               | 0.71 (11.4%) | 0.65 (10.9%) | 0.69 (10.4%) | 0.64 (9.4%)  | 0.61 (9.4%)  | 0.67 (10.5%) | 0.62 (10.5%) | 0.54 (10.5%) | 0.58 (9.4%)  | 0.56 (8.8%)  | 0.57 (10.5%) |
| Renewables        | 0.01 (0.2%)  | 0.01 (0.2%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  | 0.01 (0.1%)  |
| Coal              | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  |
| Peat              | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  |
| Non-ren. waste    | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  |
| Total             | 6.22 (100%)  | 5.97 (100%)  | 6.61 (100%)  | 6.89 (100%)  | 6.52 (100%)  | 6.37 (100%)  | 5.93 (100%)  | 5.18 (100%)  | 6.15 (100%)  | 6.32 (100%)  | 5.41 (100%)  |

## 7.3 Energy-related GHG emissions by mode

Figure 7.8 shows energy-related CO2eq emissions, divided into the three modes of electricity, transport and heat. This aggregates the direct energy-related emissions from industry, residential, commercial services, public services, agriculture and fisheries, along with emissions from oil refining, peat briquetting and natural gas production as shown in Figure 7.2, Figure 7.3 and Table 7.1, together as heat. The emissions for transport including international aviation, are shown for reference.

Figure 7.8: Energy-related CO2eq emissions by electricity, transport and heat

<!-- image -->

Energy-related CO2eq emissions in all three modes declined after 2007 during the recession, but transport returned to growth after 2012 with heat and electricity returning to growth after 2014.

From 2016, there was a dramatic reduction in CO2eq emissions from electricity generation, due to the reduction in coal and peat (the most carbon-intensive fossil fuels) and an increase in electricity from renewable and zero-carbon sources.

CO2eq emissions from electricity generation reached a minimum in 2020, before increasing again in 2021. In 2022 and 2023, CO2eq emissions from electricity generation decreased again, reaching another minimum in 2023.

In 2020, there was a dramatic reduction in CO2eq emissions from transport due to travel restrictions imposed during the COVID-19 pandemic, with emissions from international aviation alone dropping 64%. Emissions from transport subsequently increased in 2021, almost returning to pre-pandemic levels in 2022. In contrast, CO2eq emissions from heat increased slightly during 2020, due in part to more time spent at home during COVID-19 restrictions, before decreasing again in 2021, 2022 and 2023, due the end of restrictions, milder weather and high fuel prices.

## 7.4 Avoided emissions from renewable energy

Using renewable energy displaces the use of fossil fuels, thereby avoiding greenhouse gas (GHG) emissions. This subsection presents an estimate of the GHG emissions avoided by use of renewable energy in Ireland.

The net emission of CO2 from the combustion of biogenic carbon in sustainable biomass fuels (including solid biomass, biofuel, bioliquids and biogas) is counted as zero (in line with international practice), as it is assumed that the biomass itself absorbs an equal amount of CO2 during growth from the fast domain carbon cycle as is emitted during combustion [12]. In contrast, fossil fuel extraction and combustion results in the transfer of carbon from the slow domain carbon cycle to the fast domain carbon cycle, resulting in greater quantities of carbon in our current atmosphere. While biomass fuels produce some GHGs during combustion, their net contribution to the overall quantity of GHGs in the current atmosphere is much less than that from the combustion of fossil fuels on a per unit energy basis when considering CO2, CH4 and N2O together.

SEAI estimate the annual amount of GHG avoided by each renewable energy type based on the fossil fuels that are displaced. This analysis requires an estimate of the types of fossil fuels displaced, as well as the quantities, by each renewable energy type for each year from 1990 to 2023. This analysis is conducted for each of the modes (electricity, heat and transport) and the results are presented on this basis. Avoided emissions associated with electricity generated from renewables are included within the electricity mode.

The following simplifying assumptions are used in calculating the avoided emissions in the electricity mode :

- · Renewables displace marginal fossil fuel generators that would otherwise have been required to produce the electricity - specifically natural gas, gas oil (distillate) and fuel oil.
- · The efficiency and carbon intensity of the displaced marginal generation is equal to that of the public thermal power plants using gas oil, fuel oil or natural gas in the specific year. Consequently, the efficiency and carbon intensity of the displaced generation varies each year in line with the historical trend seen in public power generation from 1990 to present.
- · Renewables do not displace electricity imports.
- · Wind generation increases emissions from fossil fuel generation due to the effects of increased ramping and cycling. This is estimated using a factor, based on previous detailed electricity dispatch modelling [13, 14, 15].
- · Renewables do not displace coal or peat generation. Historical, this was effectively the case as coal and peat plants operated as base load. However, in recent years peat generation has been phased out (ceasing entirely at the start of 2024) and coal generation has decreased significantly in the last ten years. The assumption that renewables do not displace any peat or coal generation means that the estimated avoided emissions are conservatively low in recent years.

In the heat mode , avoided emissions are calculated for each renewable energy type in each sector, using the following assumptions:

- · Renewables replace fossil fuel consumption based on the fossil fuel mix in that sector and year, except for the items listed below.
- · Biomass in the wood and wood products subsector does not displace fossil fuel alternative(s) - this industry has traditionally used process waste and residue as a fuel.
- · Renewable waste in the other non-metallic mineral products subsector displaces the fossil fuel mix of that subsector, which contains a higher proportion of solid fossil fuels (coal and petroleum coke) than the industry sector as a whole.
- · Avoided emissions associated with ambient heat use in heat pumps must take account of the total heat delivered by heat pumps, along with the carbon intensity of the associated electricity consumption.

In the transport mode , it is assumed that biofuel and biogas displace their fossil fuel equivalents. In this analysis, the renewable portion of electricity consumed in EVs or rail is not considered as avoided emissions in the transport mode - emissions avoided due to renewable generation are included in the electricity mode.

Figure 7.9 shows the trend in annual avoided GHG emissions from renewable energy in electricity, heat and transport from 2003 to present. The estimated emissions avoided through the use of renewable energy was 7.15 MtCO2eq in 2023, more than any previous year, with:

- · 5.57 MtCO2eq avoided by use of renewables in electricity;
- · 0.88 MtCO2eq avoided by use of renewables in transport; and
- · 0.70 MtCO2eq avoided by use of renewables in heat.

Decarbonising the electricity system, combined with increased electrification of heat and transport through the use of electric vehicles (EVs) and heat pumps is an important part of the strategy for decarbonising the energy system as a whole. The use of renewable electricity ensures that switching to EVs and heat pumps results in less GHG emissions than the fossil fuel alternative. Electrification of heat and transport reduces direct fossil fuel use in the non-ETS sector, thereby contributing to meeting the non-ETS greenhouse gas emissions reduction target 10 , see section 8.1.

## Figure 7.9: Avoided emissions from renewable energy in electricity, heat and transport modes

<!-- image -->

Figure 7.10 shows the breakdown in annual avoided GHG emissions by each renewable energy type and mode of application. Wind accounted for 4.55 MtCO2eq or 63.6% of the total avoided emissions in 2023. This was followed by biodiesel in transport (10.9%), hydro in electricity (5.4%) and ambient heat delivered by heat pumps (3.9%).

10 Electricity generation is covered by the EU emissions trading system (ETS), therefore emissions savings achieved in electricity generation do not count directly towards Ireland's EU targets to reduce greenhouse gas emissions outside of the ETS (non-ETS)

## Figure 7.10: Avoid emissions by renewable energy type 11

<!-- image -->

## 8 Energy targets and policy

This section examines areas that are a focus of national and international energy policy, including Ireland's progress towards its EU targets for renewable energy and greenhouse gas emissions, and also the issues of energy security and cost competitiveness.

## 8.1 Greenhouse gas emissions

Figure 8.1 shows greenhouse gas emissions by source for 2005 and provisional figures for 2023 (excluding land use and land use change), as reported by the EPA [16].  The share of greenhouse gas emissions from energy use has fallen in both percentage and absolute quantity since 2005. Ireland has a comparably large share of greenhouse gas emissions from agriculture when compared to the EU average. For the EU as a whole in 2022, 12% of greenhouse gas emissions were from agriculture, compared to 35% in Ireland [17]. Almost all (98%) of the energy-related greenhouse gas emissions are from CO2, with the rest from methane (CH4) and nitrous oxide (N2O) by-products of combustion such as nitrous oxide (N2O) emissions.

11 Mode denoted in brackets: (E) for electricity, (T) for transport and (H) for heat

Figure 8.1: National total greenhouse gas emissions by source (excludes international aviation)

<!-- image -->

Source: data from EPA

## 8.1.1 Greenhouse gas emissions reductions targets

The EU 2030 climate and energy framework sets a target for the EU as a whole to achieve a 55% greenhouse gas emissions reduction by 2030 compared to 1990. The greenhouse gas emissions reductions targets are split across two categories. The first category covers large-scale carbon emitters, typically large industrial sites or electricity generation stations, but also including some bodies in the services sector and international aviation. These bodies are dealt with at EU level under the EU ETS. The second category covers all greenhouse gas emissions not covered by the ETS, known as the non-ETS sector. Achieving greenhouse gas emissions reductions in the non-ETS sector is the responsibility of national governments. The EU Effort Sharing Regulation (ESR) [18] and implementing decision [19] requires Ireland to reduce its non-ETS emissions by at least 42% by 2030, compared to a 2005 baseline. The ESR also limits the non-ETS emissions in the intervening years 2021-2029, further details are available in the EPA's Provisional Greenhouse Gas Emissions 1990-2023 report [16].

Figure 8.2 compares Ireland's total and energy emissions, split between ETS and non-ETS sectors, for the baseline year (2005) and 2023.

Figure 8.2: Energy-related and total GHG emissions in the ETS and non-ETS sectors for 2005 baseline and 2023

<!-- image -->

Source: data from EPA

The non-ETS sector includes most greenhouse gas emissions in the residential, transport and services sectors. It also includes most non-energy-related emissions, notably from agriculture.

Figure 8.3 shows the trend in non-ETS emissions relative to 2005 for all non-ETS emissions, and also separately for energy related non-ETS emissions and agriculture non-ETS emissions. The data are from the EPA and are provisional for 2023.

Figure 8.3: Index of non-ETS greenhouse gas emissions relative to 2005

<!-- image -->

Source: data from EPA

Figure 8.4 shows the trend in non-ETS energy-related greenhouse gas emissions split by sector. 12  Transport and households typically account for over 80% of energy-related non-ETS emissions.

## Figure 8.4: Energy-related non-ETS greenhouse gas emissions

<!-- image -->

Source: data from EPA

Figure 8.5 shows the trend in emissions from fossil fuel combustion from those installations included in the EU ETS in Ireland after 2005. Most of the ETS emissions in Ireland are from electricity generation, and this is also where most of the reduction in greenhouse gas emissions has occurred.

12 This excludes emissions associated with electricity use by these sectors - emissions from electricity generation are included in the EU ETS. It also excludes international aviation and the activity of organisation in the industry and services sectors that are within the ETS.

Figure 8.5: EU ETS greenhouse gas emissions in Ireland (excluding international aviation)

Source: data from EPA

<!-- image -->

Table 8.1: Energy-related GHG emissions, ETS and non-ETS (share)

| GHG [MtCO 2 eq]            | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|----------------------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Energy-related ETS         | 14.38 (24.8%) | 14.30 (24.6%) | 14.98 (24.8%) | 15.76 (25.1%) | 14.84 (24.0%) | 13.39 (21.7%) | 12.07 (20.2%) | 11.35 (19.7%) | 13.03 (21.6%) | 12.59 (21.3%) | 10.26 (18.7%) |
| Non-energy related ETS     | 1.30 (2.2%)   | 1.65 (2.8%)   | 1.83 (3.0%)   | 1.97 (3.1%)   | 2.04 (3.3%)   | 2.09 (3.4%)   | 2.06 (3.4%)   | 1.91 (3.3%)   | 2.26 (3.7%)   | 2.07 (3.5%)   | 1.93 (3.5%)   |
| Total ETS                  | 15.68 (27.0%) | 15.95 (27.5%) | 16.81 (27.8%) | 17.72 (28.3%) | 16.88 (27.3%) | 15.49 (25.1%) | 14.13 (23.7%) | 13.26 (23.0%) | 15.28 (25.4%) | 14.66 (24.8%) | 12.20 (22.2%) |
| Energy-related non-ETS     | 21.48 (37.0%) | 20.89 (36.0%) | 21.88 (36.2%) | 22.61 (36.1%) | 22.19 (35.8%) | 23.36 (37.9%) | 23.06 (38.6%) | 21.70 (37.7%) | 21.86 (36.3%) | 21.64 (36.7%) | 21.12 (38.4%) |
| Non-energy related non-ETS | 20.84 (35.9%) | 21.23 (36.6%) | 21.72 (36.0%) | 22.37 (35.7%) | 22.85 (36.9%) | 22.74 (36.9%) | 22.55 (37.8%) | 22.65 (39.3%) | 23.05 (38.3%) | 22.71 (38.5%) | 21.69 (39.4%) |
| Total non-ETS              | 42.32 (73.0%) | 42.12 (72.5%) | 43.60 (72.2%) | 44.98 (71.7%) | 45.04 (72.7%) | 46.10 (74.9%) | 45.61 (76.3%) | 44.35 (77.0%) | 44.91 (74.6%) | 44.35 (75.2%) | 42.81 (77.8%) |
| National total             | 57.99 (100%)  | 58.07 (100%)  | 60.41 (100%)  | 62.70 (100%)  | 61.92 (100%)  | 61.58 (100%)  | 59.75 (100%)  | 57.61 (100%)  | 60.19 (100%)  | 59.00 (100%)  | 55.01 (100%)  |

ETS is a 'cap and trade' system where an EU-wide limit or cap is set for participating installations. The cap is reduced over time so that total emissions fall. Within that limit, 'allowances' for emissions are auctioned or allocated for free (outside the power generation sector and depending on the nature of the installation). Individual operators must report the greenhouse gas emissions from their installations each year and surrender sufficient allowances to cover their emissions. If an operator exceeds its available allowances, it must purchase more. If an operator has reduced its emissions, it can sell its leftover allowances. The system is designed to bring about reductions in emissions at the lowest possible overall cost. The EPA is responsible for implementing the EU ETS in Ireland and administering the accounts on Ireland's domain in the Union Registry.

## 8.1.2 Carbon budgets and sectoral emission ceilings

The carbon budget represents the total greenhouse gas emissions, measured in tonnes of CO2 equivalent (CO2eq), that Ireland may emit in different periods. The Climate Action and Low Carbon Development Act [20] commits Ireland to a legally binding target of a 51% reduction in emissions by 2030, compared to 2018 levels. The carbon budget programme comprises three successive five-year carbon budgets [21], also legally binding:

- · 295 MtCO2eq between 2021-2025
- · 200 MtCO2eq between 2026-2030
- · 151 MtCO2eq between 2031-2035

In total, these budgets commit Ireland to an average overall reduction in emissions of -4.8% per annum from 2021 to 2025, and -8.3% per annum from 2026 to 2030. Sectoral ceilings [22] published in July 2022 set out the maximum amount of greenhouse gas emissions that are permitted in different sectors of the economy during a carbon budget period. Combined, the carbon budgets and sectoral ceilings tell us when and where we need to make the emission reductions to remain on track for our 2030 target.

In 2023, Ireland's national energy-related emissions were 31.4 ktCO2eq, which accounted for 57% of Ireland's total greenhouse gas (GHG) emissions 55.0 MtCO2eq 13 . This means SEAI's National Energy Balance is a key input into the Environmental Protection Agency's (EPA) GHG inventory calculation for the formal calculation of emission results. Practically 100% of emissions from the electricity, transport, residential (buildings) and commercial (buildings) sectors are energy related; however, 66% of emissions from the industry sector and only about 4% of emissions from the agriculture sector are energy related. Most agriculture emissions are methane from livestock, and nitrous oxide from fertiliser and manure management.

Figure 8.6 summarises the sectoral ceilings within the first two carbon budgets, spanning 2021-2025 and 2026-2030. The five-year total CO2eq emissions permitted by the different sectors in each budget period (squares). The 'indicative emission' value for a sector is a guide to the maximum annual emissions expected from that sector at the end of the budget period, but it is not a binding target. For example, the transport sector is permitted to emit a total of 54 MtCO2eq in the five-year period between 2021 to 2025, with an indicative annual emission of 10 MtCO2eq in the 2025 calendar year.

13 As per the EPA's Provisional Greenhouse Gas Emissions 1990-2023 , the national total was 55,006 ktCO2eq in 2023, while the national total with LULUCF (land-use, land-use change and forestry) was 60,620 ktCO2eq.

Figure 8.6: Sectoral ceilings first two carbon budgets, spanning 2021-2025 and 2026-2030 g g

<!-- image -->

Figure 8.7 shows the emissions to the end of 2023 under the electricity sectoral emission ceiling, along with remaining budget for the 2021-2025 and 2026-2030 periods. The remaining budget amounts are represented as annual averages. The solid blue bars for 2021, 2022 and 2023 relate to GHG emissions emitted from the electricity sector. It is worth noting that the remaining budget values (grey bars) are not targets. They convey only the average annual emissions compatible with satisfying the sectoral emission ceiling. The policies and strategies for reducing emissions in different sectors may be back-loaded to the end of the carbon budgets.

The 2021-2025 ceiling for emissions from the electricity sector is 40 MtCO2eq in total, or 8 MtCO2eq as an annual average (denoted by the dotted bars). Over the first three years of the budget period, the total sectoral emissions were 27.15 MtCO2eq, meaning that remaining budget is 12.85 MtCO2eq for 2024-2025, or 6.43 MtCO2eq as an annual average (denoted by the dark grey bars).

Figure 8.7: Sectoral emissions ceiling for electricity

Source: emission data from EPA's GHG Provisional Emissions 1990-2023

<!-- image -->

Figure 8.8 shows the emissions to the end of 2023 under the transport sectoral emission ceiling, along with remaining budget for the 2021-2025 and 2026-2030 periods. The remaining budget amounts are represented as annual averages. The solid green bars for 2021-2023 relate to GHG emissions emitted from the transport sector. It is worth noting that the remaining budget values (grey bars) are not targets. They convey only the average annual emissions compatible with satisfying the sectoral emission ceiling. The policies and strategies for reducing emissions in different sectors may be back-loaded to the end of the carbon budgets.

The 2021-2025 ceiling for emissions from the transport sector is 54 MtCO2eq in total, or 10.8 MtCO2eq as an annual average (denoted by the dotted bars). Over the first three years of the budget period, the total sectoral emissions were 34.64 MtCO2eq, meaning that remaining budget is 19.36 MtCO2eq for 2023-2025, or 9.68 MtCO2eq as an annual average (denoted by the dark grey bars).

Figure 8.8: Sectoral emissions ceiling for transport

<!-- image -->

Source: emission data from EPA's GHG Provisional Emissions 1990-2023

## 8.2 Renewable energy targets

## 8.2.1 Renewable Energy Directive and targets

The first Renewable Energy Directive (RED) [23] was the most important legislation influencing the growth of renewable energy in the EU and Ireland for the decade ending in 2020. From 2021, RED was replaced by the second (or recast) Renewable Energy Directive (RED II) [24], which continues to promote the growth of renewable energy out to 2030. RED set out two mandatory targets for renewable energy in Ireland to be met by 2020, while REDII sets new targets and criteria to be met by Ireland in 2030 and the interim.

Under the European Green Deal and REPowerEU plan, a significant revision [25] to RED II was finalised during 2023 and entered into force on 20 November 2023 (referred to as RED III). RED III sets more ambitious targets for 2030 and requires Member States to take additional measures to promote the use of renewable energy. RED III also redefines how progress towards the renewable energy targets is calculated, with significant changes made in how the renewable energy share in transport (RES-T) is determined.

The main target set out in the directives relates to overall renewable energy share (RES) and is commonly referred to as the overall RES target. The overall RES is the annual percentage of the gross final consumption (GFC) 14 of energy from renewable sources in the state and is calculated as the sum of:

- a. Gross final consumption of electricity from renewable sources - referred to as RES-E
- b. Gross final consumption of energy from renewable sources in heating and cooling - referred to as RES-H
- c. Final consumption of energy from renewable sources in the transport sector - referred to as RES-T

## Overall RES

Under RED I, Ireland's target for the overall RES was 16% of gross final energy consumption in 2020. Ireland's overall RES in 2020 was 13.5%, meaning that Ireland was obligated to acquire statistical transfers of 3.3 TWh of renewable energy from other Member States to compensate for this shortfall.

RED II introduced a binding EU-wide target for overall RES of 32% in 2030 and required Member States to set their national contributions to the EU-wide target. As per the National Energy and Climate Plant (NECP) 2021-2030 [26], submitted in 2019, Ireland's overall RES target was set at 34.1% in 2030.

RED III increased the binding EU-wide target for overall RES to at least 42.5%. In July 2024, Ireland set its national contributions to this target in its updated NECP. Ireland's overall RES target is now 43.0% in 2030 [27].

## RES-E

There is no RES-E target specified in the EU legislation. Ireland's national RES-E target was for 40% of gross electricity consumption to come from renewable sources in 2020 The actual RES-E achieved in 2020 was 39.1%, falling just short of the national target. Nevertheless, the development of renewable electricity was a major success in Ireland since 2005. Ireland's updated NECP 2021-2030 and Climate Action Plan 2024 (CAP 24) includes a target to increase the share of electricity generated from renewable sources to 80% in 2030 [27, 28].

## RES-H

While the RES-H was calculated annually and formed a component of the overall RES, RED I &amp; II did not specify binding targets for RES-H. RED II required Ireland to 'endeavour to increase' the RES-H by an indicative 1.1 percentage points (pp) as an annual average calculated for the periods 2021-2025 and 2026-

14 Gross final consumption of energy is an alternative to total final consumption and is the denominator used by the EU to track progress towards the targets in the RED. It is defined as ' the energy commodities delivered for energy purposes to industry, transport, households, services including public services, agriculture, forestry and fisheries, the consumption of electricity and heat by the energy branch for electricity and heat production, and losses of electricity and heat in distribution and transmission. '

2030. However, RED III introduced a requirement for states to increase RES-H by at least 0.8 pp and 1.1 pp as annual averages calculated for 2021-2025 and 2026-2030, respectively.

## RES-T

The second mandatory target set by the directive relates to the renewable energy share in the transport sector. 15 This is commonly referred to as the RES-T target. The 2020 RES-T target was for at least 10% of energy consumed in road and rail transport to come from renewable sources. The actual RES-T achieved in 2020 was 10.2%, meaning that Ireland did meet this target. RED II set a new RES-T target of 14% by 2030; however, RED III has increased the 2030 RES-T target to 29%, on an energy basis. Alternatively, a Member State may choose to follow a target to reduce the greenhouse gas intensity of energy in transport by 14.5%. RED III also slightly changed the scope of the RES-T to include additional forms of transport.

## 8.2.2 Biomass sustainability

Besides specifying new EU and national renewable energy targets, RED II also introduced new sustainability and verification criteria for biomass fuels (solid and gaseous) to be implemented from the transposition date (30 June 2021). Introducing these criteria led to circumstances where a portion of the biomass fuel consumed in Ireland in 2021 and 2022 could not be counted in the national renewable shares, specifically towards the overall RES, RES-E and RES-H.

From the beginning of July 2021, biomass fuel consumed in installations, above certain sizes, must fulfil various sustainability 16 and greenhouse gas saving criteria to be counted towards national renewable energy targets, or be eligible for financial supports. In addition, the biomass fuel must be subject to a verification procedure requiring economic operators to demonstrate that the sustainability and greenhouse gas saving criteria, as laid out in the directive, have been fulfilled. Verification must require economic operators to, among other things, maintain sustainability records of all consignments of biomass, applying a mass balance, and arrange for independent auditing of all information submitted to the competent authority.

National legislation [29] was introduced in July 2022 to transpose the biomass sustainability and verification requirements of RED II into Irish law. While a system of verification commenced in 2023 for operators of biomass installations under support schemes, no verification system was in place during 2021 or 2022. Consequently, any biomass consumed during the 2021 (from July onwards) or 2022 that was required to meet the sustainability criteria and undergo verification could not be included in the overall RES, RES-E and RES-H.

Only biomass fuel consumed in an installation with a rated thermal output above one of the following thresholds is required to meet the sustainability criteria:

- · Equal to or exceeding 20 MW for solid biomass fuels (decreasing to 7.5 MW in 2025 under RED III); or
- · Equal to or exceeding 2 MW for gaseous biomass fuels.

In 2021, approximately 780 GWh of renewable final energy could not be counted towards the RES overall (equivalent to 0.6 pp). This increased to 1,514 GWh or 1.1 pp in 2022.

Most of this biomass fuel that could not contribute to the RES targets in 2021 or 2022 was consumed in EU ETS installations. For 2023, verification of the sustainability of biomass fuels was completed under the EU ETS system. Consequently, only a relatively small quantity of biomass fuel (and bioliquid) that was consumed in 2023 could not contribute towards the RES targets.

15 In the context of RED and RED II, consumption in the transport sector relates only to energy in road and rail; however, renewable energy consumed in aviation and marine can contribute towards the RES-T.

16 'Sustainability', in the context of biomass under REDII, relates to: soil monitoring and management; protection of land with high biodiversity; protection of land with high carbon stock; protection of peatland; sustainable forest production; and land-use, land-use change and forestry (LULUCF).

Biomass fuels consumed in smaller installations are not required to meet the sustainability and verification criteria to be counted towards the renewable energy targets. Biomass, such as wood, consumed in the residential sector and in many smaller commercial/industrial boilers can be included the RES.

Where biomass fuel could not contribute to the RES results, due to the absence of verification, it still contributed to decarbonisation by displacing fossil fuel and reducing greenhouse gas emissions under EU ETS and Ireland's national emissions allocations.

## 8.2.3 RES Results

Table 8.2 shows Ireland's the overall RES figures, along with the RES-E/-H/-T, for 2020 to 2023. The values in the table are calculated under the EU legislation and Commission guidance that was active at the time: 2020 values were calculated under RED I, while 2021-2023 were calculated under RED II.

Table 8.2: Ireland's progress towards overall renewable energy share (RES) targets

| Target [%]   | 2020                              | 2021   | 2022   | 2023   | 2030 Target                |
|--------------|-----------------------------------|--------|--------|--------|----------------------------|
| RES-E        | 39.1%                             | 37.7%  | 37.4%  | 40.4%  | 80% 17                     |
| RES-T        | 10.2%                             | 4.6%   | 5.8%   | 7.6%   | 14% (RED II) 29% (RED III) |
| RES-H        | 6.3%                              | 5.6%   | 5.5%   | 7.9%   | 15.8% (RED III) 18         |
| Overall RES  | 13.5% (16.2% with stat transfers) | 12.5%  | 13.1%  | 15.3%  | 43.0%                      |

17 As stated in the Climate Action Plans 2023 and 2024

18 This is based on the 0.8 pp and 1.1 pp average annual increases for 2021-2025 and 2026-2030, as set out in RED III

Figure 8.9 shows the current split of renewable energy between the three modes. Figure 8.10 shows the contribution of renewable electricity, heat and transport to the overall RES target. Renewable electricity makes the largest contribution to the overall RES and has been responsible for most of the overall growth in renewable energy since 2005. Figure 8.10 also shows the share of heat and electricity generated by biomass fuels that was excluded from the overall RES (see section 8.2.2 for further details).

Figure 8.9: 2023 share of renewable energy by mode

<!-- image -->

Figure 8.10: Renewable energy share (overall RES) with contribution by mode

<!-- image -->

Figure 8.11 shows the overall RES from 2010 to 2022 along with Ireland's current 2030 target of 43.0%. and the minimum trajectory set out in Ireland's updated NECP, as per EU legislation [30].

Figure 8.11: Renewable energy share (overall RES) and trajectories to 2030 target

<!-- image -->

Figure 8.12 illustrates the 2023 gross final consumption (GFC) of energy in each of transport, heat and electricity according to the RED II calculation, and the portion of each mode that comes from renewable sources. This gives important context to the separate heat, transport and electricity targets. Although electricity has the highest share of renewable energy, it is the smallest of the modes in terms of GFC. The transport mode makes up the largest share of GFC, follow by heat, which has the smallest renewable share.

Figure 8.12: Renewable and fossil gross final energy consumption by mode

<!-- image -->

Figure 8.13 and Table 8.3 show the share and quantity of renewable energy used each year, split by source. Most of the growth in renewable energy has come from wind. Wind provides more than half of all renewable energy. Solid biomass and bioliquids were the next largest sources of growth. Bioenergy, including solid biomass, renewable wastes, landfill gas, biogas and bioliquids, collectively accounted for approximately onethird of Ireland's renewable energy.

Figure 8.13 and Table 8.3 also show the quantities and shares of final energy from biomass and biogas that were excluded from the 2021-2023 RES figures as verification of sustainability was outstanding, see section 8.2.2 for further details.

Figure 8.13: Renewable energy share of gross final consumption by source

<!-- image -->

Table 8.3: Overall RES - Renewable energy in gross final consumption by energy type (share)

| Energy [TWh]                           | 2013          | 2014          | 2015          | 2016          | 2017           | 2018           | 2019           | 2020           | 2021           | 2022           | 2023           |
|----------------------------------------|---------------|---------------|---------------|---------------|----------------|----------------|----------------|----------------|----------------|----------------|----------------|
| Hydro (normalised)                     | 0.74 (0.6%)   | 0.73 (0.6%)   | 0.72 (0.5%)   | 0.73 (0.5%)   | 0.72 (0.5%)    | 0.72 (0.5%)    | 0.74 (0.5%)    | 0.76 (0.6%)    | 0.76 (0.6%)    | 0.76 (0.5%)    | 0.76 (0.5%)    |
| Wind (normalised)                      | 4.61 (3.6%)   | 5.25 (4.1%)   | 6.20 (4.7%)   | 6.57 (4.8%)   | 7.63 (5.6%)    | 8.69 (6.1%)    | 9.80 (6.9%)    | 10.68 (8.0%)   | 10.97 (8.0%)   | 11.34 (8.1%)   | 11.88 (8.6%)   |
| Biomass & ren. waste                   | 2.53 (2.0%)   | 2.93 (2.3%)   | 2.90 (2.2%)   | 3.16 (2.3%)   | 3.31 (2.4%)    | 3.48 (2.4%)    | 3.29 (2.3%)    | 3.35 (2.5%)    | 2.65 (1.9%)    | 2.05 (1.5%)    | 3.13 (2.2%)    |
| Biofuels & biogas in transport         | 1.02 (0.8%)   | 1.25 (1.0%)   | 1.43 (1.1%)   | 1.33 (1.0%)   | 1.87 (1.4%)    | 1.80 (1.3%)    | 2.21 (1.5%)    | 2.06 (1.5%)    | 2.12 (1.6%)    | 2.68 (1.9%)    | 3.30 (2.4%)    |
| Biogas & landfill gas                  | 0.27 (0.2%)   | 0.30 (0.2%)   | 0.31 (0.2%)   | 0.32 (0.2%)   | 0.32 (0.2%)    | 0.30 (0.2%)    | 0.30 (0.2%)    | 0.33 (0.2%)    | 0.23 (0.2%)    | 0.14 (0.1%)    | 0.20 (0.1%)    |
| Ambient                                | 0.24 (0.2%)   | 0.27 (0.2%)   | 0.31 (0.2%)   | 0.38 (0.3%)   | 0.45 (0.3%)    | 0.51 (0.4%)    | 0.61 (0.4%)    | 0.66 (0.5%)    | 0.75 (0.6%)    | 0.94 (0.7%)    | 1.12 (0.8%)    |
| Solar thermal                          | 0.12 (0.1%)   | 0.12 (0.1%)   | 0.13 (0.1%)   | 0.14 (0.1%)   | 0.15 (0.1%)    | 0.16 (0.1%)    | 0.16 (0.1%)    | 0.16 (0.1%)    | 0.16 (0.1%)    | 0.16 (0.1%)    | 0.16 (0.1%)    |
| Solar PV                               | 0.00 (0.0%)   | 0.00 (0.0%)   | 0.00 (0.0%)   | 0.01 (0.0%)   | 0.01 (0.0%)    | 0.02 (0.0%)    | 0.04 (0.0%)    | 0.06 (0.0%)    | 0.08 (0.1%)    | 0.15 (0.1%)    | 0.65 (0.5%)    |
| Numerator Overall RES (Overall RES)    | 9.52 (7.4%)   | 10.84 (8.4%)  | 12.01 (9.0%)  | 12.63 (9.2%)  | 14.46 (10.5% ) | 15.69 (10.9% ) | 17.15 (12.0% ) | 18.07 (13.6% ) | 17.73 (13.0% ) | 18.22 (13.1% ) | 21.20 (15.3% ) |
| Biomass & ren. waste not verified      | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0.69 (0.5%)    | 1.33 (1.0%)    | 0.23 (0.2%)    |
| Biogas & landfill gas not verified     | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0.09 (0.1%)    | 0.18 (0.1%)    | 0.11 (0.1%)    |
| Ren. energy excluded from numerator    | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0 (0%)         | 0.78 (0.6%)    | 1.51 (1.1%)    | 0.35 (0.2%)    |
| Denominator Overall RES (GFC adjusted) | 128.78 (100%) | 128.52 (100%) | 132.73 (100%) | 137.95 (100%) | 137.40 (100%)  | 143.28 (100%)  | 143.00 (100%)  | 133.30 (100%)  | 136.44 (100%)  | 139.43 (100%)  | 138.97 (100%)  |

## 8.2.4 Electricity from renewable energy sources (RES-E)

Ireland has no binding national target for RES-E for 2030, nor was there one for 2020, but RES-E forms the backbone of Ireland's strategy to achieve the overall renewable energy target for 2030. Ireland's Climate Action Plan 2024 (CAP 24) [28] includes a target to increase the share of electricity generated from renewable sources up to 80% by 2030.

The Government set an ambitious national target for RES-E of 40% for 2020. Ireland fell just short of this target, achieving 39.1% RES-E in 2020. However, electricity generation has been the most successful of the three modes for the development of energy from renewable sources. The share of electricity from renewable energy increased fivefold between 2005 and 2020 and there was a sevenfold increase in the annual quantity of renewable electricity generated.

Figure 8.14 and Table 8.4 show the renewable energy share in electricity (RES-E) by source. RES-E decreased from 39.1% in 2020 to 37.7% in 2021. This drop was primarily due to an increase in electricity consumption, while renewable generation remained stagnant, with around 0.8 pp of electricity generated from biomass or biogas that was ineligible to be counted towards the RES-E. In 2022, the RES-E dropped to 37.4% with around 1.6 pp of electricity from biomass and biogas that was ineligible to contribute. In 2023 the RES-E increased to 40.4%, the highest yet.

Figure 8.14: RES-E - gross final consumption of electricity from renewable sources

<!-- image -->

Table 8.4: RES-E - gross final consumption of electricity from renewable sources (share)

| Energy [TWh]                        | 2013         | 2014         | 2015         | 2016         | 2017         | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|-------------------------------------|--------------|--------------|--------------|--------------|--------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Hydro (normalised)                  | 0.74 (2.7%)  | 0.73 (2.6%)  | 0.72 (2.5%)  | 0.73 (2.5%)  | 0.72 (2.4%)  | 0.72 (2.3%)   | 0.74 (2.4%)   | 0.76 (2.4%)   | 0.76 (2.3%)   | 0.76 (2.2%)   | 0.76 (2.2%)   |
| Wind (normalised)                   | 4.61 (16.6%) | 5.25 (18.8%) | 6.20 (21.5%) | 6.57 (22.3%) | 7.63 (25.4%) | 8.69 (28.2%)  | 9.80 (31.3%)  | 10.68 (33.5%) | 10.97 (32.9%) | 11.34 (33.3%) | 11.88 (34.1%) |
| Solar PV                            | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.00 (0.0%)  | 0.01 (0.0%)  | 0.01 (0.0%)  | 0.02 (0.1%)   | 0.04 (0.1%)   | 0.06 (0.2%)   | 0.08 (0.3%)   | 0.15 (0.4%)   | 0.65 (1.9%)   |
| Renewable waste                     | 0.07 (0.3%)  | 0.07 (0.3%)  | 0.08 (0.3%)  | 0.08 (0.3%)  | 0.15 (0.5%)  | 0.33 (1.1%)   | 0.32 (1.0%)   | 0.33 (1.0%)   | 0.35 (1.1%)   | 0.35 (1.0%)   | 0.33 (1.0%)   |
| Biomass                             | 0.23 (0.8%)  | 0.26 (0.9%)  | 0.20 (0.7%)  | 0.40 (1.3%)  | 0.38 (1.3%)  | 0.33 (1.1%)   | 0.35 (1.1%)   | 0.43 (1.4%)   | 0.23 (0.7%)   | 0.03 (0.1%)   | 0.34 (1.0%)   |
| Landfill gas                        | 0.16 (0.6%)  | 0.17 (0.6%)  | 0.18 (0.6%)  | 0.16 (0.6%)  | 0.16 (0.5%)  | 0.14 (0.5%)   | 0.13 (0.4%)   | 0.12 (0.4%)   | 0.12 (0.4%)   | 0.10 (0.3%)   | 0.10 (0.3%)   |
| Biogas                              | 0.03 (0.1%)  | 0.04 (0.1%)  | 0.03 (0.1%)  | 0.04 (0.1%)  | 0.04 (0.1%)  | 0.04 (0.1%)   | 0.05 (0.2%)   | 0.06 (0.2%)   | 0.03 (0.1%)   | 0.01 (0.0%)   | 0.02 (0.1%)   |
| RES-E numerator (RES-E)             | 5.83 (21.0%) | 6.52 (23.3%) | 7.40 (25.7%) | 7.99 (27.1%) | 9.09 (30.3%) | 10.29 (33.3%) | 11.43 (36.5%) | 12.44 (39.1%) | 12.55 (37.7%) | 12.73 (37.4%) | 14.08 (40.4%) |
| Biomass excluded                    | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0.24 (0.7%)   | 0.48 (1.4%)   | 0.00 (0.0%)   |
| Landfill gas excluded               | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0 (0%)        |
| Biogas excluded                     | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0.02 (0.1%)   | 0.05 (0.1%)   | 0.04 (0.1%)   |
| Ren. energy excluded from numerator | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)        | 0 (0%)        | 0 (0%)        | 0.26 (0.8%)   | 0.53 (1.6%)   | 0.05 (0.1%)   |
| RES-E denominator (GFC of elec.)    | 27.82 (100%) | 27.96 (100%) | 28.78 (100%) | 29.51 (100%) | 29.99 (100%) | 30.87 (100%)  | 31.36 (100%)  | 31.85 (100%)  | 33.33 (100%)  | 34.05 (100%)  | 34.83 (100%)  |

## 8.2.5 Heat from renewable energy sources (RES-H)

Under RED III, which entered into force in November 2023 (transposition deadline in 2025), Ireland must increase the share of renewable energy in heating and cooling by at least 0.8 pp and 1.1 pp as annual averages for the periods 2021-2025 and 2026-2030, respectively. Based on Ireland's 2020 RES-H figure of 6.3%, Ireland's RES-H would need to reach 10.3% in 2025 to achieve the target for 2021-2025.

Figure 8.15 and Table 8.5 show the share of heating provided by renewable energy as a share of overall heat (gross final consumption of heat). RES-H fell from 6.3% in 2020 to 5.6% in 2021 and then 5.5% in 2022; this decrease can be attributed to the transition from RED I to RED II and the introduction of new sustainability and verification criteria for biomass fuels, see section 8.2.2. In 2023 the RES-H increased 7.9%, a new high. This increase was due to the sustainability data relating to biomass and biogas becoming available in 2023 ( i.e. less renewable energy excluded from the RES-H), an increase in the quantity of renewable energy and an overall decrease in consumption of energy in heat.

Figure 8.15: RES-H - gross final consumption of heat from renewable sources 19

<!-- image -->

Renewable heat energy is dominated by the use of solid biomass and renewable wastes in industry. Utilisation of ambient energy ( via heat pumps) has grown five-fold between 2013 and 2023 and is now a significant source of renewable heat energy, accounting for approximately 27% of renewable heat energy in 2023. Table 8.5 shows the breakdown of renewable energy types used for heat.

Recent growth in renewable energy use for heat has been due to increased use of renewable wastes in industry and increased use of heat pumps delivering ambient energy in the residential and services sectors. The latter is mostly due to revisions to building regulations for new dwellings and the support of grant schemes.

19 Bioliquid (notably HVO and bioLPG) is included within the biomass figures to avoid statistical disclosure.

Table 8.5: RES-H - gross final consumption of heat from renewable sources 20  (share)

| Energy [TWh]                        | 2013         | 2014         | 2015         | 2016         | 2017         | 2018         | 2019         | 2020         | 2021         | 2022         | 2023         |
|-------------------------------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|
| Biomass                             | 1.97 (3.8%)  | 2.29 (4.7%)  | 2.26 (4.4%)  | 2.24 (4.2%)  | 2.31 (4.4%)  | 2.35 (4.2%)  | 2.16 (3.9%)  | 2.09 (3.7%)  | 1.52 (2.8%)  | 1.05 (2.1%)  | 1.77 (3.6%)  |
| Renewable waste                     | 0.26 (0.5%)  | 0.30 (0.6%)  | 0.36 (0.7%)  | 0.44 (0.8%)  | 0.47 (0.9%)  | 0.47 (0.8%)  | 0.47 (0.8%)  | 0.50 (0.9%)  | 0.54 (1.0%)  | 0.63 (1.2%)  | 0.68 (1.4%)  |
| Biogas                              | 0.08 (0.2%)  | 0.09 (0.2%)  | 0.10 (0.2%)  | 0.11 (0.2%)  | 0.11 (0.2%)  | 0.11 (0.2%)  | 0.12 (0.2%)  | 0.15 (0.3%)  | 0.08 (0.1%)  | 0.03 (0.1%)  | 0.09 (0.2%)  |
| Solar Thermal                       | 0.12 (0.2%)  | 0.12 (0.3%)  | 0.13 (0.3%)  | 0.14 (0.3%)  | 0.15 (0.3%)  | 0.16 (0.3%)  | 0.16 (0.3%)  | 0.16 (0.3%)  | 0.16 (0.3%)  | 0.16 (0.3%)  | 0.16 (0.3%)  |
| Ambient heat                        | 0.24 (0.5%)  | 0.27 (0.5%)  | 0.31 (0.6%)  | 0.38 (0.7%)  | 0.45 (0.9%)  | 0.51 (0.9%)  | 0.61 (1.1%)  | 0.66 (1.2%)  | 0.75 (1.4%)  | 0.94 (1.8%)  | 1.12 (2.3%)  |
| RES-H numerator                     | 2.67 (5.2%)  | 3.07 (6.3%)  | 3.17 (6.2%)  | 3.31 (6.2%)  | 3.49 (6.6%)  | 3.60 (6.4%)  | 3.51 (6.3%)  | 3.57 (6.3%)  | 3.06 (5.6%)  | 2.81 (5.5%)  | 3.81 (7.9%)  |
| Biomass (excluded)                  | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0.45 (0.8%)  | 0.85 (1.7%)  | 0.23 (0.5%)  |
| Biogas (excluded)                   | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0.07 (0.1%)  | 0.13 (0.3%)  | 0.07 (0.1%)  |
| Ren. energy excluded from numerator | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0.51 (0.9%)  | 0.98 (1.9%)  | 0.30 (0.6%)  |
| RES-H denominator (GFC heat)        | 51.47 (100%) | 49.10 (100%) | 51.32 (100%) | 53.02 (100%) | 52.73 (100%) | 56.37 (100%) | 55.31 (100%) | 57.06 (100%) | 54.97 (100%) | 50.86 (100%) | 48.50 (100%) |

20 Bioliquid (notably HVO and bioLPG) is included within the biomass figures to avoid statistical disclosure.

## 8.2.6 Transport energy from renewable sources (RES-T)

RED I established a mandatory minimum target for the share of renewable energy sources in transport (RES-T) by 2020: 10% of all petrol, diesel, biofuels and electricity consumed in road and rail transport. Ireland's RES-T reached 10.2% in 2020.

RED II requires Ireland, along with all Member States, to set an obligation on fuel suppliers to ensure that the share of renewable energy within the final consumption of energy in transport is at least 14% by 2030. This target has increased to 29% by 2030 under RED III.

It should be noted that renewable energy consumed in any mode of transport contributes towards the RES-T, but that only certain energy types consumed in road &amp; rail are counted in the denominator:

RES-T (RED II)=

Final consumption of renewable energy in all transport

Final consumption of energy in road &amp; rail

The only fossil fuels counted in the denominator are petrol, diesel and natural gas; the relatively small quantity of fossil LPG consumed in road transport is not included in RES-T denominator, but is included in the overall RES.

In accordance with Eurostat guidance and reporting requirements for RES data, the above RED II definition will be used for calculating RES-T up to and including 2024. For 2025 onwards the scope of the RES-T calculation will change to that defined by RED III, which will include all transport modes including marine transport:

RES

-

T (RED III) =

Final consumption of renewable energy in all transport

Final consumption in all transport

To maintain consistency with Ireland's official 2023 RES data reported to the European Commission (Eurostat) in November 2024, the 2021-2023 RES-T presented in this subsection are calculated under the RED II definitions and methodology.

RED II, as with RED I before it, specifies several weightings or multipliers that are applied to certain fuels or energy for the calculation of RES-T. These weightings help to incentivise the use of advanced biofuels and biofuels from wastes over crop-based fuels, generally promoting those with lower life-cycle greenhouse gas intensities. Table 8.6 sets out the current multipliers under RED II and how they have changed from those used for RED I. More than 90% of the biofuel and biogas used in transport is produced from feedstocks listed in Annex IX of RED II, including used cooking oil (UCO) and tallow (category 1 &amp; 2), and consequently count twice towards the RES-T target.

These multipliers do not apply to the overall RES. Prior to the transition to RED II, there was a significant difference between the RES-T value and the share of renewable energy in transport, as a component of the overall RES.

Table 8.6: Multipliers used in the calculation of RES-T

|                                                                | RED I                           | RED II                          |
|----------------------------------------------------------------|---------------------------------|---------------------------------|
| Biofuels & biogas from Annex IX feedstocks                     | 2× (numerator only)             | 2× (numerator & denominator)    |
| Renewable electricity in road                                  | 5× (numerator only)             | 4 × (numerator & denominator)   |
| Renewable electricity in rail                                  | 2.5 × (numerator & denominator) | 1.5 × (numerator & denominator) |
| Aviation & maritime fuels (excl. fuels from food & feed crops) | -                               | 1.2 × (numerator)               |

In addition to the change in multipliers used in the RES-T calculation, RED II also includes three limits on biomass fuels produced from certain feedstocks, see Table 8.6. These limits are defined as percentages of energy consumed in transport. Although two of these limits can technically apply to bioliquids or biomass fuels consumed outside of the transport sector, they are currently only relevant to fuels used in the transport sector.

The first limit relates to the share of used cooking oil (UCO) and animal fat (tallow) category 1 &amp; 2 and is the most consequential change to the calculation of Ireland's RES-T arising from the transition to RED II.  UCO and tallow (category 1 &amp; 2) accounted for 4.8% of final energy consumption in transport in 2023; under RED II, this biofuel is limited to 1.7% of transport energy for the purposes of RES-T. In 2023, approximately 45% of the biofuel and biogas in transport consumed in Ireland (before application of multipliers) could not be counted towards RES-T due to this limit.

The second limit relates to fuels produced from food and feed crops ( e.g. bioethanol from maize, biodiesel from sunflower). Biofuels from food and feed crops only constituted 0.5% of final consumption of energy in transport in 2023, well below the limit of 2%.

The third limit applies to biofuels (as well as to bioliquids and biomass fuels) produced from crops with a 'high indirect land-use change risk' (high ILUC risk), specifically fuels produced from palm oil. The limit is based on the share of biofuels or biogas from high ILUC risk feedstocks in Ireland in 2019, i.e . 0.028%. No biofuels or biogas produced from such feedstocks were consumed in 2023.

Table 8.7: Limits on biofuels from certain feedstocks

| Feedstocks                                                | Fuel type                                            | Scope               | Limit                      | 2023 share   |
|-----------------------------------------------------------|------------------------------------------------------|---------------------|----------------------------|--------------|
| Used cooking oil (UCO) and animal fat (tallow cat. 1 & 2) | • Biofuels • Biogas                                  | RES-T only          | 1.7% of transport energy   | 4.8%         |
| Food and feed crops                                       | • Biofuels • Bioliquids • Biomass fuels in transport | Overall RES & RES-T | 2% of transport energy     | 0.005%       |
| High ILUC-risk food & feed crops                          | • Biofuels • Bioliquids • Biomass fuels              | Overall RES & RES-T | 0.028% of transport energy | 0%           |

Figure 8.14 shows the annual RES-T from 2005 to present and the share of renewable energy in transport, as it contributes to the overall RES. The RES-T increased from 5.8% in 2022 to 7.6% in 2023. The decrease in RES-T from 10.2% in 2020 to 4.6% in 2021 was due to the change in calculation methodology between RED I and RED II.

The share of renewable energy in transport, without multipliers or limits, increased from 4.8% in 2022 to 5.7% in 2023.

Figure 8.16: RES-T - final consumption in transport from renewable sources

<!-- image -->

The Renewable Transport Fuel Obligation (RTFO), formerly the Biofuel Obligation Scheme (BOS), requires fuel suppliers to include 21% (by energy) renewable transport fuel in their annual sales of transport fuels [31].

The RTFO is a certificate-based mandate that grants one certificate for each MJ of renewable transport fuel placed on the market in Ireland; two certificates are granted to fuels produced from feedstocks listed in Annex IX of RED II.

Oil companies are required to apply to NORA for certificates and to demonstrate that the quantities of renewable transport fuel for which they are claiming certificates are accurate. Since the Sustainability Regulations (SI 33 of 2012) [32] were introduced, companies are also required to demonstrate that the renewable transport fuel being placed on the market is sustainable, fulfilling the requirements of RED II.

Since the obligation was established in 2010, it has increase as follows:

- · 4% by volume in 2010
- · 6% by volume in 2013;
- · 8% by volume in 2017;
- · 10% by volume in 2019;
- · 11% by volume in 2020;
- · 13% by volume in 2022
- · 16.985% by energy in 2023; and
- · 21% by energy in 2024.

Further details on the RTFO are available in NORA's RFTO Annual Reports [33].

Figure 8.17 and Table 8.8 show the final energy from renewable sources used in transport in absolute terms, without multipliers or limits applied. Biofuels provide almost all of the renewable energy in transport, 96.0% in 2023, with renewable electricity providing 3.4% and biomethane (also referred to as bio compressed natural gas) contributing 0.6%.

Figure 8.17: Renewable energy in transport by energy type (without multipliers)

<!-- image -->

Table 8.8: Renewable energy for transport by source - without multipliers (share)

| Energy [TWh]   | 2013         | 2014         | 2015         | 2016         | 2017         | 2018         | 2019         | 2020         | 2021         | 2022        | 2023    | 2023    | 2023    | 2023    |
|----------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|-------------|---------|---------|---------|---------|
| Biodiesel      | 0.86 (71.6%) | 1.04 (76.6%) | 1.14 (76.2%) | 1.00         | 1.52 (81.0%) | 1.48 (81.5%) | 1.90 (85.1%) | 1.82 (87.6%) | 1.87         | 2.37        | 3.13    | 3.13    | 3.13    | 3.13    |
|                | 0.33 (27.7%) | 0.31         |              | (71.7%)      |              |              | 0.30         | 0.23         | (86.3%)      | (86.2%)     | (85.5%) | (85.5%) | (85.5%) | (85.5%) |
| Biogasoline    |              | (22.8%)      | 0.35 (23.2%) | 0.38 (27.4%) | 0.34 (18.3%) | 0.32 (17.5%) | (13.7%)      | (10.9%)      | 0.24 (10.9%) | 0.27 (9.8%) | 0.38    | 0.38    | 0.38    | 0.38    |
| Renewable      | 0.01         | 0.01         | 0.01         | 0.01         | 0.01         | 0.02         | 0.03         | 0.03         | 0.05         | 0.09        | 0.12    | 0.12    | 0.12    | 0.12    |
| electricity    | (0.7%)       | (0.6%)       | (0.6%)       | (0.8%)       | (0.7%) 0     | (1.0%) 0     | (1.2%) 0     | (1.5%)       | (2.5%)       | (3.2%) 0.01 | 0       | 0       | 0       | 0       |
| Biojet         | 0 (0%)       | 0 (0%)       | 0 (0%)       | 0 (0%)       | (0%)         | (0%) 0       | (0%)         | 0 (0%)       | 0 (0%)       | (0.3%)      | (0%)    | (0%)    | (0%)    | (0%)    |
| Biomethane     | 0            | 0            | 0            | 0            | 0            |              | 0            | 0            | 0.00         | 0.01        | 0.02    | 0.02    | 0.02    | 0.02    |
|                | (0%)         | (0%)         | (0%)         | (0%)         | (0%)         | (0%)         | (0%)         | (0%)         | (0.2%)       | (0.4%)      | (0.6%)  | (0.6%)  | (0.6%)  | (0.6%)  |
|                | 1.20         | 1.36         | 1.50         | 1.39         | 1.88         | 1.82         | 2.23         | 2.08         | 2.16         | 2.75        | 3.66    | 3.66    | 3.66    | 3.66    |
| Total          |              |              |              |              |              |              |              |              |              |             |         |         |         |         |
|                |              | (100%)       |              |              |              |              |              |              |              |             |         |         |         |         |
|                | (100%)       |              |              |              |              |              |              |              |              |             |         |         |         |         |
|                |              |              |              |              |              |              |              |              |              |             | (100%)  | (100%)  | (100%)  | (100%)  |
|                |              |              | (100%)       |              |              |              |              |              |              |             |         |         |         |         |
|                |              |              |              |              |              |              |              |              |              |             |         | (100%)  |         |         |
|                |              |              |              |              |              |              |              |              |              |             |         |         | (100%)  |         |
|                |              |              |              |              |              |              |              |              |              |             | (100%)  |         |         |         |
|                |              |              |              |              |              |              |              | (100%)       |              |             |         |         | (100%)  |         |
|                |              |              |              |              |              |              |              |              | (100%)       |             |         |         |         |         |
|                |              |              |              | (100%)       |              |              |              |              |              |             |         |         |         |         |

## 8.3 Energy prices to industry

Energy use is an important part of economic activity and therefore the price paid for energy is a determining factor in the economy's competitiveness. Ireland has a high import dependence on oil and gas and is essentially a price-taker on these commodities. The EU has introduced competition into the electricity and gas markets through the liberalisation process to reduce energy costs to final consumers.

SEAI publishes annual reports titled Electricity and Gas Prices in Ireland [34] based on data collected under EU legislation [35] on the transparency of gas and electricity prices. These reports focus specifically on gas and electricity prices using data published by Eurostat and are a useful reference on cost competitiveness and cover both business and households.

This section focuses on business energy prices. It presents comparisons of the cost of energy in various forms in Ireland and compares prices in OECD Europe and the US. The source of the data presented here is the International Energy Agency's (IEA) Energy Prices and Taxes [36]. This data source was chosen because it is produced quarterly and contains data to the end of 2023. Prices shown are in US dollars and are in current (nominal) money. Relative price increases since 2015, however, are tabulated for EU countries and the US in index format in both nominal and real terms.

Nominal value refers to the current value expressed in money terms in a given year, whereas real value adjusts nominal value to remove the effects of price changes and inflation, to give the constant value over time indexed to a reference year.

Figure 8.18 and Table 8.9 show that electricity prices to Irish industry have been increasing in recent years, with a steep increase from Q1 2021 and continuing into 2022 and 2023. The fuel mix for electricity generation is one factor that has a key bearing on the variation in the price of electricity. Compared to the EU, Ireland has a high overall dependency for electricity generation on fossil fuels including gas generation.

Figure 8.18: Electricity prices to industry

<!-- image -->

Source: Energy Prices and Taxes ©OECD/IEA

Table 8.9: Electricity price to industry change since 2015

<!-- image -->

| Index 2015 = 100           |   OECD Europe |   Austria |   Belgium |   Denmark |   Finland |   France |   Germany |   Greece | Ireland Italy   |   Luxembourg |   Netherlands |   Portugal |   Spain |   Sweden |   United Kingdom |   United States |
|----------------------------|---------------|-----------|-----------|-----------|-----------|----------|-----------|----------|-----------------|--------------|---------------|------------|---------|----------|------------------|-----------------|
| 4th quarter 2023 (nominal) |           319 |       222 |       187 |       180 |       112 |      190 |       155 |      178 | 215 139         |          301 |           305 |        101 |     131 |      182 |              272 |             113 |
| 4th quarter 2023 (real)    |           138 |       188 |       119 |       122 |        83 |      137 |       114 |      130 | 238 100         |          206 |           229 |         79 |      92 |      124 |              193 |              88 |

Source: Energy Prices and Taxes ©OECD/IEA

Table 8.10 shows that oil prices to industry in Ireland were 61% higher in real terms in Q4 2023 than in 2015. The average oil price in Europe and the US also increased. Crude oil prices averaged around $82/barrel in 2023, compared with $101/barrel on average in 2022.

Figure 8.19: Oil prices to industry

<!-- image -->

Source: Energy Prices and Taxes ©OECD/IEA

Table 8.10: Oil prices to industry change since 2015

<!-- image -->

| Index 2015 = 100           |   OECD Europe |   Austria |   Belgium |   Denmark |   Finland |   France |   Germany |   Greece |   Ireland |   Italy |   Luxembourg |   Netherlands |   Portugal | Spain Sweden   |   United Kingdom |   United States |
|----------------------------|---------------|-----------|-----------|-----------|-----------|----------|-----------|----------|-----------|---------|--------------|---------------|------------|----------------|------------------|-----------------|
| 4th quarter 2023 (nominal) |           225 |       145 |       149 |       141 |       159 |      159 |       152 |      150 |       145 |     129 |          155 |           147 |        140 | 144 177        |              140 |             159 |
| 4th quarter 2023 (real)    |           106 |       122 |        94 |        96 |       118 |      115 |       112 |      109 |       161 |      93 |          106 |           110 |        110 | 101 120        |               99 |             123 |

Source: Energy Prices and Taxes ©OECD/IEA

Figure 8.20 and Table 8.11 show that natural gas prices to Irish industry increased dramatically from the end of 2021, continuing growth well into 2022. In the fourth quarter of 2023, the price of gas to industry in Ireland was 164% above 2015 levels in real terms. The figure also shows the gap between gas prices in Europe and the USA.

Figure 8.20: Natural gas prices to industry

<!-- image -->

Source: Energy Prices and Taxes ©OECD/IEA

Table 8.11: Natural gas prices to industry change since 2015

<!-- image -->

| Index 2015 = 100           |   OECD Europe |   Austria |   Belgium |   Denmark |   Finland | France Germany   |   Greece |   Ireland |   Italy |   Luxembourg |   Netherlands |   Portugal |   Spain |   Sweden |   United Kingdom |   United States |
|----------------------------|---------------|-----------|-----------|-----------|-----------|------------------|----------|-----------|---------|--------------|---------------|------------|---------|----------|------------------|-----------------|
| 4th quarter 2023 (nominal) |           326 |       164 |       172 |       198 |       146 | 193 238          |      152 |       238 |     166 |          171 |           213 |        151 |     175 |        0 |              275 |             112 |
| 4th quarter 2023 (real)    |           151 |       139 |       109 |       134 |       108 | 140 175          |      111 |       264 |     120 |          117 |           159 |        118 |     123 |        0 |              196 |              87 |

Source: Energy Prices and Taxes ©OECD/IEA

Figure 8.21 summarises the data presented in Table 8.9, Table 8.10 and Table 8.11. The IEA publishes an overall energy price index (real) for industry, which shows that the overall energy price to Irish industry between 2015 and the fourth quarter of 2023 increased for all fuels.

Figure 8.21: Real energy price changes to industry since 2015 (index)

<!-- image -->

Source: Energy Prices and Taxes ©OECD/IEA

## 9 Drivers of energy demand

This section takes a high-level view of the trends in the economy, weather, energy use and energyrelated greenhouse gas emissions since 2001.

## 9.1 Energy, economy and emissions

Energy supply responds to the level of demand for energy services (heating, transportation and electricity) and how end users want that energy demand satisfied. Energy service demand is driven primarily by economic activity and by the energy end-use technologies employed in undertaking such activity.

The relationship between economic activity and energy demand is less straightforward in Ireland than it is for most other countries. Gross Domestic Product (GDP) is the most widely accepted measure of economic activity internationally, but Ireland's GDP is strongly influenced by the revenue and profits reported by multinational companies. Some economic activity of these companies results in large amounts of value added (see Appendix 4), but with little energy consumption. This was illustrated clearly in 2015, when Irish GDP increased suddenly by +25% from 2014, due to the transfer of intellectual property from multinational companies. Care must be taken when comparing macro-economic indicators, such as energy per unit GDP, across countries.

The CSO has developed alternative indicators to GDP that more accurately reflect the level of economic activity in the domestic economy, and to remove the distorting effects of globalisation. Modified domestic demand 21  (MDD) was first published in the Quarterly National Accounts [37] results for Q1-2017 and excluded trade by aircraft leasing companies, exports and imports of R&amp;D services, and exports and imports of R&amp;D-related IP products. For comparison, Ireland's MDD grew by +5.3% from 2014 to 2015, vs. +25% for GDP.

Figure 9.1 shows the historical trends for MDD, energy prices and final energy, each expressed as an index relative to 2005. This figure illustrates changes in economic growth and shows the effect of the economic downturn between 2008 and 2012 (and the subsequent return to growth after 2013) and the dip in 2020 due to the impact of COVID-19 on economic activity.

Table 9.1 gives the GDP and MDD values for the economy, primary energy, final energy and energy-related CO2eq emissions for the period.

21 Previous editions of this report presented another economic indicator, modified gross national income (GNI*), as an alternative to GDP. For more information on the differences between GDP, GNI* and modified domestic demand refer to the CSO.

Figure 9.1: Index of modified domestic demand, final energy demand and energy price

<!-- image -->

Source: SEAI and CSO

Table 9.1: GDP, MDD, final energy, primary energy and energy-related CO2eq

| Energy type          | 2013        | 2014        | 2015        | 2016        | 2017        | 2018        | 2019        | 2020        | 2021        | 2022        | 2023        |
|----------------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|
| GDP [Billion €2022]  | 224.54      | 245.50      | 305.93      | 309.67      | 340.80      | 366.51      | 384.98      | 412.54      | 479.60      | 520.94      | 492.13      |
| MDD [Billion €2022]  | 164.62      | 175.28      | 185.74      | 193.63      | 202.11      | 208.32      | 214.07      | 205.28      | 221.93      | 245.20      | 258.08      |
| Final energy [TWh]   | 126.86      | 126.47      | 132.74      | 137.23      | 138.27      | 144.62      | 144.55      | 130.75      | 133.73      | 139.65      | 140.77      |
| Primary energy [TWh] | 155.06      | 154.10      | 161.88      | 168.89      | 167.60      | 171.30      | 169.94      | 155.37      | 160.69      | 166.82      | 163.79      |
| Energy related GHG   | 35,854      | 35,194      | 36,860      | 38,371      | 37,026      | 36,750      | 35,134      | 33,055      | 34,887      | 34,227      | 31,385      |
| [ktCO 2 eq]          | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] | [ktCO 2 eq] |

Source: CSO, EPA and SEAI

In 2020, final energy use, energy-related CO2eq emissions and MDD fell, due largely to the impact of COVID19 on economic activity (while GDP increased by +5.9%). All indicators returned to growth in 2021 and continued into 2022 and 2023 except for GDP which fell by 5.5% in 2023, driven by a contraction in multinational-dominated sectors.

Figure 9.2 shows the relationship between final energy demand, primary energy use and energy-related CO2eq emissions, expressed as an index relative to 2005. The difference between the trends in final energy use and primary energy supply arises from improvements in the efficiency of energy transformations, particularly electricity generation.

The overall efficiency of electricity generation has increased over the period. These improvements are driven by introducing higher efficiency CCGT gas generators, reductions in inefficient coal generation, and the increased supply of wind-generated electricity (considered 100% efficient).

Figure 9.2: Index of final energy, primary energy and energy-related CO2eq

<!-- image -->

Source: EPA and SEAI

## 9.2 Energy and the weather

Weather variations from year to year can have a significant effect on the energy demand of a country, particularly on the portion of the energy demand associated with space heating. A method to measure the weather, or climatic variation, is the use of 'degree days'.

Degree days are the measure or index used to consider the severity of the weather when looking at energy use in terms of heating (or cooling) load on a building. A degree day is a measure of how cold (or warm) it is outside, relative to a day on which little or no heating (or cooling) would be required. Thus, it is a measure of the cumulative temperature deficit (or surplus) of the outdoor temperature, relative to a neutral target temperature (base temperature) at which no heating or cooling would be required. The larger the number of heating degree days, the colder the weather. For example, if the outdoor temperature for a particular day is 10 degrees lower, on average, than the base temperature (15.5 degrees), this would contribute 10 degree days to the annual or monthly total. The typical heating season in Ireland is October to May.

Met Éireann calculates degree day data for each of its synoptic weather stations. SEAI calculates a population weighted average of these data to arrive at a meaningful degree day average for Ireland that is related to the heating energy demand of the country.

Figure 9.3 shows the percentage deviation in the number of heating degree days from the long-term average between 2005 and 2023. Over that period, 2010 was the coldest year recorded and 2007 was the warmest. The portion of each fuel assumed to be used for heating is adjusted by multiplying it by the ratio of the longterm average number of degree days to the number of degree days in the given year. This adjustment yields a lower normalised energy consumption in cold years, and a higher normalised consumption in mild years. Typically, the weather adjustment is within ±6% of the actual energy consumption. The largest correction over the period was for 2010, an exceptionally cold year, where the weather-corrected energy consumption was over 10% less than the actual energy consumption.

Figure 9.3: Deviation from average heating degree days (2005 to 2023) and resulting weather adjustment

<!-- image -->

Source: Met Éireann and SEAI

## 9.3 Economic energy intensities

Energy intensity is defined as the amount of energy required to produce a functional output. For the economy, the measure of output is generally taken to be the GDP. As mentioned in section 9.1, MDD is a more meaningful indicator of economic activity in Ireland, but GDP is still the standard international metric; therefore, here we present energy intensity in terms of GDP. We use GDP measured in constant prices to remove the influence of inflation.

Figure 9.4 shows the trend in primary energy intensity (primary energy divided by GDP) and final energy intensity (final energy consumption divided by GDP) (at constant 2022 prices). The difference between these two trends reflects the amount of energy lost in the transformation of primary energy into final energy, mostly for electricity generation. The primary and final energy intensity of the economy has generally fallen since 2002, except in 2008 and 2016, which can be attributed to a combination of increased energy efficiency and increases in GDP.  The graph also shows electricity intensity (final electricity consumption divided by GDP). In 2023 GDP fell by 5.5%, driven by a contraction in multinational-dominated sectors.

The sharp fall in the energy intensity of the economy in 2015 of 16% must be understood in the context of the 25% increase in GDP, which resulted from transferring assets into Ireland and had little or no effect on energy consumption. This change should be viewed as an adjustment rather than a reduction in intensity. This is a good example of why energy intensity is not a good measure of energy efficiency progress, especially in Ireland.

Figure 9.4: Primary, final and electricity intensities

<!-- image -->

Source: SEAI

There are many factors that contribute to how trends in energy intensity of the economy evolve. These factors include technological efficiency and the fuel mix, particularly in relation to electricity generation; economies of scale in manufacturing; and, not least, the structure of the economy. The structure of the economy in Ireland has changed considerably over the past 20 to 30 years. It has shifted toward the high value-added sectors, such as pharmaceuticals, electronics and services. Relative to traditional 'heavier' industries, such as car manufacturing and steel production, these growing sectors are not highly energy intensive. Examples of changes to the structure of the industry sector include the cessation of steel production in 2001, of fertiliser production in late 2002, and of sugar production in 2007.

The energy intensity of the economy will continue to decrease if, as expected, the economy becomes increasingly dominated by high value added, low energy-consuming sectors. This results in a more productive economy from an energy perspective, but does not necessarily mean that the actual processes used are more energy efficient, or that less energy is being used overall in the economy.

## 10 Further sectoral analysis

This section explores in more detail the changes in energy use in each of the main sectors: industry, transport, residential and services.

## 10.1 Primary energy requirement by sector

Figure 10.1 shows how Ireland's primary energy supply ultimately services the energy needs of different sectors of the economy. Where primary energy is used directly by end users in a particular sector, then allocation is straightforward. An example is the use of natural gas in the residential sector. Where fuels undergo a transformation process before final use by an end-user, then the full primary energy required to satisfy that final use is allocated to the sector. For example, for the electricity used in the residential sector, the fuels used to generate that electricity (gas, wind, coal, peat and oil, etc. ) are allocated to the residential sector.

## Figure 10.1: Total primary energy requirement by sector

<!-- image -->

Table 10.1 details the quantities, shares and trends of primary energy supply across economic sectors. The total primary supply is split across the transport, residential, services, industry, and agriculture and fisheries sectors. Sectoral energy-related CO2eq emissions are presented in section 7.2.

Table 10.1: Primary energy by sector compared with previous years (share)

| Energy [TWh]   | 2013          | 2014          | 2015    | 2016    | 2017    | 2018    | 2019    | 2020    | 2021    | 2022    | 2023    |
|----------------|---------------|---------------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
|                | 51.16         | 53.15         | 56.55   | 58.52   | 60.23   | 61.75   | 62.12   | 46.31   | 49.65   | 59.72   | 62.28   |
| Transport      | (33.0%) 43.34 | (34.5%)       | (35.1%) | (34.9%) | (35.9%) | (36.0%) | (36.6%) | (29.7%) | (30.7%) | (35.6%) | (38.1%) |
| Residential    |               | 39.67         | 41.75   | 43.37   | 41.67   | 42.88   | 41.33   | 44.69   | 43.57   | 38.55   | 35.32   |
|                | (28.0%)       | (25.8%)       | (25.9%) | (25.9%) | (24.8%) | (25.0%) | (24.3%) | (28.7%) | (27.0%) | (23.0%) | (21.6%) |
| Services       | 27.93         | 26.97         | 29.27   | 30.45   | 30.09   | 31.48   | 31.76   | 29.26   | 32.63   | 34.34   | 33.14   |
|                | (18.0%)       | (17.5%) 30.95 | (18.2%) | (18.2%) | (17.9%) | (18.3%) | (18.7%) | (18.8%) | (20.2%) | (20.5%) | (20.3%) |
|                | 28.87         |               | 30.51   | 31.97   | 32.55   | 32.08   | 31.29   | 32.25   | 32.30   | 30.86   | 28.80   |
| Industry       | (18.6%)       | (20.1%)       | (18.9%) | (19.1%) | (19.4%) | (18.7%) | (18.4%) | (20.7%) | (20.0%) | (18.4%) | (17.6%) |
| Agriculture &  | 3.51          | 3.27          | 3.17    | 3.27    | 3.36    | 3.45    | 3.42    | 3.44    | 3.44    | 4.20    | 3.77    |
| Fisheries      | (2.3%)        | (2.1%)        | (2.0%)  | (1.9%)  | (2.0%)  | (2.0%)  | (2.0%)  | (2.2%)  | (2.1%)  | (2.5%)  | (2.3%)  |
|                | 154.81        | 154.01        | 161.26  | 167.57  | 167.90  | 171.64  | 169.92  | 155.96  | 161.60  | 167.67  | 163.31  |
| Total          | (100%)        | (100%)        | (100%)  | (100%)  | (100%)  | (100%)  | (100%)  | (100%)  | (100%)  | (100%)  | (100%)  |

## 10.2 Industry energy intensity

Industrial energy intensity is the amount of energy required to produce a unit of value added, measured in constant money values. Figure 10.2 shows the industrial energy intensity over the period expressed in kilograms of oil equivalent per euro of industrial value added at 2022 money value (kWh/€2022). Over the period, industrial energy consumption fell, while value added increased, resulting in a reduction in intensity.

Figure 10.2: Industry energy intensity

<!-- image -->

Value-added output from industry was 74% higher in 2015 compared with 2014. The large increase in gross value added in 2015 is explained by several one-off factors, such as transferring assets into Ireland, and what are known as reverse takeovers. This increase in gross value added incurred no additional energy consumption.

The step-change in industry energy intensity in 2015 illustrates the fact that energy intensity is not a good indicator of energy efficiency, as variations may result from many factors, such as structural changes, or changes to the fuel mix or activity.

## 10.3 Transport

## 10.3.1 Private car activity

Figure 10.3 shows the total kilometres driven by private cars in Ireland each year. This is based on an analysis of NCT data for all years, except 2020 and 2021. The NCT methodology assumes that the kilometres driven between the last two dates in a car which has had an NCT are split evenly across that time periods, which can be 4, 2 or 1 years. In normal times, this is a reasonable assumption, but if there is a sudden change the activity pattern and the functioning of the NCT is disrupted, both of which occurred during COVID-19, then this method no longer gives good results. Therefore, we developed an alternative approach for 2020 and 2021. We estimated the reduction in activity of the average petrol car in these years from the observed drop in petrol use (most of which occurs in private cars). We then assumed that the average diesel car's activities were reduced by the same proportion as the average petrol car. From 2022, we returned to the NCT methodology for estimating vehicle kilometres.

The total number of vehicle-kilometres travelled declined following the economic crash (during 2009 and 2010) but returned to growth soon after in 2011. Total vehicle-kilometres continued to grow until the dramatic fall in 2020 due to travel restrictions during COVID-19.

There was a clear shift from petrol to diesel cars in this period. This was already underway prior to the changes in motor taxation in 2008, but accelerated sharply after that.

Annual vehicle-kilometres for electric vehicles (EVs) have been estimated since 2009 and have grown every year since. Hybrid electric vehicles (HEV) and Plug-in hybrid electric vehicles (PHEV) have been estimated since 2015.

## Figure 10.3: Private car total annual vehicle-kilometres

Source: Based on NCT Data

<!-- image -->

## 10.3.2 CO2 intensity of new private cars

Figure 10.4 shows the change in the weighted average specific CO2 emissions of new cars licensed for the first time (excluding battery EVs) over the period, according to standardised testing procedures. This does not include imported, second-hand cars.

Since 2008, the combined effect of the EU legislation obligating manufacturers to reduce average fleet emissions and the changes to the Irish taxation system for private cars has been to shift new car purchases from higher to lower CO2 emissions bands, and to reduce the average specific CO2 emissions of new cars.

The standardised testing procedures are known to underestimate the fuel use and CO2 emissions of cars, compared to typical real-world driving conditions. The difference between the test emissions and the emissions produced in real-world driving conditions is referred to as the on-road factor, or the performance gap. Several reports by the International Council on Clean Transportation highlighted that the performance gap between test results and real-world driving increased dramatically after 2008, and that the real-world fuel consumption and carbon emissions of new vehicles are increasingly higher than the reported values under standardised testing procedures.

The data up to 2020 is based on the results of a standardised laboratory test procedure called the New European Driving Cycle (NEDC). From January 2021, a new test methodology called the Worldwide Harmonised Light Vehicle Test Procedure (WLTP) came into force for all new cars to better reflect real-world driving profiles.

Figure 10.4: Specific CO2 emissions of new cars, excluding battery electric vehicles

<!-- image -->

Source: Dept. Transport, Vehicle Registration Unit data.

## 10.3.3 Penetration of zero emissions vehicles

There are two sources of cars for the Irish market: brand new imports and pre-owned imports, shown in Figure 10.5. The importance of the pre-owned imports market varies over time, but in the lead up to the UK leaving the EU, its share had increased until 2019, and has fallen since then. This is important as the profile of pre-owned imports tends to differ to that of new car imports.

Figure 10.5: Share of private cars licensed for the first time that are new or pre-owned imports

Source: CSO and Dept. Transport, Vehicle Registration Unit

<!-- image -->

Figure 10.6 and Table 10.2 show the share of private cars added to the Irish car stock each year that are EVs, split into new imports and pre-owned imports.

This is showing strong growth, but still from a low base. As 81% of all vehicles licensed for the first time in 2023 have an internal combustion engine, and given that the typical lifespan of a car is around 15 years, it will be well into the next decade before there is a significant phasing out of cars with internal combustion engines.

Figure 10.6: Private cars licensed for the first time that are battery electric vehicles

Source: CSO and Dept. Transport, Vehicle Registration Unit.

<!-- image -->

Table 10.2: Electric private cars licensed for the first time (share)

<!-- image -->

| Private Cars                               | 2013       | 2014        | 2015        | 2016        | 2017        | 2018          | 2019          | 2020          | 2021          | 2022           | 2023           |
|--------------------------------------------|------------|-------------|-------------|-------------|-------------|---------------|---------------|---------------|---------------|----------------|----------------|
| New imports                                | 51 (76.1%) | 222 (81.3%) | 476 (83.4%) | 392 (64.5%) | 623 (57.1%) | 1,222 (63.6%) | 3,443 (84.9%) | 3,940 (90.2%) | 8,554 (94.9%) | 15,462 (97.3%) | 22,493 (92.3%) |
| Pre-owned imports                          | 16 (23.9%) | 51 (18.7%)  | 95 (16.6%)  | 216 (35.5%) | 469 (42.9%) | 700 (36.4%)   | 611 (15.1%)   | 428 (9.8%)    | 455 (5.1%)    | 435 (2.7%)     | 1,865 (7.7%)   |
| Total electric cars licensed for the first | 67         | 273         | 571         | 608         |             | 1,922         | 4,054         | 4,368         | 9,009         |                |                |
| time                                       |            | (100%)      |             |             | 1,092       |               |               |               |               | 15,897         | 24,358         |
|                                            | (100%)     |             | (100%)      | (100%)      | (100%)      | (100%)        | (100%)        | (100%)        | (100%)        | (100%)         | (100%)         |

## 10.3.4 Heavy goods vehicle activity

The main metric used to measure activity in the road freight sector is tonne-kilometres. This is the total weight of material transported, multiplied by the distance over which it is transported. Figure 10.7 and Table 10.3 present data on road freight tonne-kilometres, along with data on economic growth, as measured by MDD. In Figure 10.7, the data are presented as an index with respect to 2000. The data are taken from the CSO's Road Freight Transport Survey, [38] which considers, for example, vehicles taxed as goods vehicles, those weighing over two tonnes unladen and those which are actually used as goods vehicles, rather than for service-type work. We estimate the energy use of HGVs based on the activity, as measured by tonnekilometres, and the energy consumption per tonne-kilometre, based on the EU average.

Although HGV activity was less affected by COVID-19 travel restrictions than private cars or aviation, the number of tonne-kilometres still fell in 2020. This was nearly twice the reduction seen in total economic activity, as measured by MDD. HGV activity returned to growth in 2021.

## Figure 10.7: Road freight activity

Source: CSO

<!-- image -->

Table 10.3: Road freight activity

|                       | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   | 2023   |
|-----------------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Mega tonne-kilometres | 9,138  | 9,772  | 9,844  | 11,564 | 11,759 | 11,537 | 12,403 | 11,383 | 12,485 | 12,384 | 12,596 |
| MDD                   |        |        |        |        |        |        |        |        |        |        |        |
| [billion € 2022]      | 164.6  | 175.3  | 185.7  | 193.6  | 202.1  | 208.3  | 214.1  | 205.3  | 221.9  | 245.2  | 258.1  |

The CSO also provides data on HGV activity, classed by main type of work done. Figure 10.8 shows the trends for tonne-kilometres in each category between 2000 and 2023.

Figure 10.8: Road freight activity by main type of work done

<!-- image -->

## Source: CSO

Between 2007 and 2013, the category 'Delivery of construction materials' experienced both the largest absolute decrease and the largest percentage decrease (77%). It was responsible for the largest share of the total reduction in activity from 2007 to 2013, accounting for 34%. This corresponded to the collapse of activity in the construction sector during this period.

Despite the recovery of the economy between 2012 and 2019, the HGV activity in most categories did not recover to 2007 levels. HGV activity fell by 8.2% in 2020 due to the COVID-19 pandemic, returning to 2019 levels in 2021.  In 2023, HGV activity increased by 1.7%.

## 10.4 Residential

## 10.4.1 Weather correction

Figure 10.9 shows the trend for the residential sector's final energy consumption between 2002 and 2023, with and without weather correction. Weather correction yields a lower normalised energy consumption in cold years ( e.g. 2010), and a higher normalised consumption in mild years ( e.g. 2023).

Annual variations in weather affect the space heating requirements of occupied buildings. Weather correction involves adjusting the energy used for space heating by benchmarking the weather in a particular year with that of a long-term average, measured in terms of numbers of degree days.

## Figure 10.9: Residential final energy

<!-- image -->

Source: Based on SEAI and Met Éireann data

## 10.4.2 Energy consumption per dwelling

Figure 10.10 shows the trend in final energy consumption per dwelling with and without weather correction.

## Figure 10.10: Energy per dwelling (permanently occupied)

<!-- image -->

Source: Based on SEAI, CSO and Met Éireann data

Table 10.4: Quantities of energy consumption and CO2eq emissions per dwelling (share)

<!-- image -->

| Energy [kWh/dw]                   | 2013           | 2014           | 2015                  | 2016                  | 2017                  | 2018                  | 2019                  | 2020                  | 2021                  | 2022                  | 2023                  |
|-----------------------------------|----------------|----------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|-----------------------|
| Non-electric                      | 15,885 (76.9%) | 14,000 (75.3%) | 14,980                | 15,624                | 14,521                | 15,429                | 14,746                | 15,867                | 14,749                | 12,449                | 11,592                |
| Electricity                       | 4,764 (23.1%)  | 4,591 (24.7%)  | (76.2%) 4,669 (23.8%) | (77.1%) 4,638 (22.9%) | (75.9%) 4,622 (24.1%) | (76.7%) 4,682 (23.3%) | (76.3%) 4,588 (23.7%) | (76.6%) 4,855 (23.4%) | (75.4%) 4,825 (24.6%) | (73.6%) 4,473 (26.4%) | (72.7%) 4,346 (27.3%) |
| Total energy                      | 20,649 (100%)  | 18,591 (100%)  | 19,649 (100%)         | 20,263 (100%)         | 19,143 (100%)         | 20,111 (100%)         | 19,334 (100%)         | 20,721 (100%)         | 19,574 (100%)         | 16,922 (100%)         | 15,939 (100%)         |
| Non-electric (weather corrected)  | 15,191 (76.3%) | 14,295 (75.6%) | 14,540 (75.8%)        | 15,382 (76.9%)        | 14,844 (76.2%)        | 15,095 (76.4%)        | 14,672 (76.2%)        | 15,744 (76.5%)        | 14,696 (75.3%)        | 12,980 (74.2%)        | 12,572 (74.1%)        |
| Electricity (weather corrected)   | 4,730 (23.7%)  | 4,605 (24.4%)  | 4,648 (24.2%)         | 4,627 (23.1%)         | 4,638 (23.8%)         | 4,666 (23.6%)         | 4,584 (23.8%)         | 4,849 (23.5%)         | 4,822 (24.7%)         | 4,501 (25.8%)         | 4,399 (25.9%)         |
| Total energy (weather corrected)  | 19,921 (100%)  | 18,900 (100%)  | 19,188 (100%)         | 20,009 (100%)         | 19,482 (100%)         | 19,760 (100%)         | 19,257 (100%)         | 20,593 (100%)         | 19,518 (100%)         | 17,481 (100%)         | 16,971 (100%)         |
| GHG [tCO 2 eq/dw]                 | 2013           | 2014           | 2015                  | 2016                  | 2017                  | 2018                  | 2019                  | 2020                  | 2021                  | 2022                  | 2023                  |
| Non-electrical energy-related GHG | 4.2 (65.1%)    | 3.7 (63.6%)    | 4.0 (64.2%)           | 4.1 (64.4%)           | 3.8 (64.5%)           | 4.0 (68.7%)           | 3.8 (71.1%)           | 4.1 (73.0%)           | 3.8 (69.1%)           | 3.1 (67.7%)           | 2.9 (72.0%)           |
| Electricity energy-related GHG    | 2.3 (34.9%)    | 2.1 (36.4%)    | 2.2 (35.8%)           | 2.3 (35.6%)           | 2.1 (35.5%)           | 1.8 (31.3%)           | 1.5 (28.9%)           | 1.5 (27.0%)           | 1.7 (30.9%)           | 1.5 (32.3%)           | 1.1 (28.0%)           |
| Total energy- related GHG         | 6.5 (100%)     | 5.9 (100%)     | 6.2 (100%)            | 6.4 (100%)            | 5.9 (100%)            | 5.8 (100%)            | 5.4 (100%)            | 5.6 (100%)            | 5.5 (100%)            | 4.6 (100%)            | 4.0 (100%)            |

Source: Based on SEAI, CSO and Met Éireann data

Figure 10.11: Unit energy-related greenhouse gas emissions per dwelling

<!-- image -->

## 10.5 Commercial and public services

## 10.5.1 Energy intensity of the commercial and public services sector

The energy intensity of the services sector is generally measured in relation to the value added generated by services activities. As shown in Figure 10.12, this intensity is flatter than that of industry.

Figure 10.12: Energy intensity of the commercial and public services sector

<!-- image -->

Two other indicators in this sector are energy use per unit of floor area and per employee. The consumption of oil and gas is mainly for space heating purposes and is likely to be more related to the floor area heated, rather than to the number of people occupying a building at a given time. Due to an absence of data on floor area in the services sector, it is not currently possible to calculate the consumption per unit of floor area.

Figure 10.13: Energy per employee in the commercial and public services sector

<!-- image -->

Electricity use per employee is used as an indicator of energy use in the services sector because, usually, there is a correlation between electricity use and the number of employees. Figure 10.13 shows electricity per employee has been increasing since 2020.

Table 10.5: Quantities of energy per employee in commercial and public services (share)

| Energy [kWh/employee]   | 2013          | 2014          | 2015          | 2016          | 2017          | 2018          | 2019          | 2020          | 2021          | 2022          | 2023          |
|-------------------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|---------------|
| Electricity             | 6,738 (58.5%) | 6,418 (59.5%) | 6,884 (60.0%) | 6,904 (61.6%) | 6,807 (62.9%) | 7,330 (63.5%) | 7,434 (64.7%) | 7,195 (66.1%) | 7,362 (66.4%) | 7,418 (68.3%) | 7,668 (70.6%) |
| Non-electricity         | 4,777         | 4,367         | 4,591         | 4,305         | 4,021         | 4,205         | 4,047         | 3,687         | 3,720         | 3,436         | 3,197         |
| energy                  | (41.5%)       | (40.5%)       | (40.0%)       | (38.4%)       | (37.1%)       | (36.5%)       | (35.3%)       | (33.9%)       | (33.6%)       | (31.7%)       | (29.4%)       |
| Total energy            | 11,515        | 10,785        | 11,475        | 11,209        | 10,828        | 11,534        | 11,481        | 10,882        | 11,081        | 10,854        | 10,865        |
| Total energy            | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        | (100%)        |

## 10.5.2 Public sector developments

The public sector comprises approximately 4,000 separate public bodies, about 3,650 of which are individual schools. The other 350 comprise, among other things, Government departments, non-commercial State bodies, State-owned companies and local authorities. Each 'public body' is a stand-alone organisation and can range in size from very small (for example, a small rural school or a five-person agency) to very large (for example, the Health Service Executive or An Garda Síochána). The vast majority of energy is consumed by the 100 largest organisations.

Public services energy consumption comprises two main classes of energy consumer:

- · Public sector buildings (offices, hospitals, clinics, nursing homes, schools, prisons, barracks, Garda stations, etc. ), which primarily consume electricity, natural gas and oil-based fuels in addition to smaller amounts of renewable and solid fuels.
- · Public sector utilities , which primarily consume electricity, such as wastewater treatment plants, water treatment facilities, pumping stations and street lighting (~400,000 units).

In addition, the energy consumed by public bodies also includes some consumption counted in the transport sector in the National Energy Balance. For example, this includes public transport fleets (rail, bus, etc. ), as well as other transport fleets operated by public bodies such as ambulances, local authority vehicles, Garda fleet, Defence Forces' vehicles, etc.

Under the Climate Action Plan, every public sector organisation must reduce energy-related emissions by 51% by 2030 and achieve a 50% improvement in energy efficiency in the public sector by 2030.

Since 1 January 2011, public sector bodies have been required to report to the Government annually on their energy use and the actions they have taken to reduce consumption. The reporting system includes a national public sector energy database, which includes all public sector electricity and natural gas meter numbers. Over time, the monitoring and reporting system will build a comprehensive bottom-up picture of energy consumption in the sector through the population of the national public sector energy database.

SEAI have published the Annual Report 2023 on Public Sector Energy Efficiency Performance [39]. It noted that 345 public sector bodies and 3,015 schools completed reports on energy and these represented 99% of total public sector energy consumption. The total energy consumption in 2022 of these bodies was 9,888 GWh (primary energy), which comprised 4,470 GWh of electricity, 3,333 GWh of thermal energy and 2,085 GWh of transport energy. This cost the State €1,097 million in 2022. The report also noted that the improvement in energy efficiency amounts to 32.5% on business as usual, equivalent to 4,627 GWh of avoided primary energy consumption, or €327 million in cost savings for the sector. Non-electricity CO2 emissions had decreased by 3.9% in 2022 since the baseline, while total CO2 emissions had decreased by 17.3%.

## 11 Provisional energy data from monthly surveys

The trends observed in provisional monthly data are not as definitive or as inclusive as those based on the annual energy data in SEAI's National Energy Balance, or the annual emissions data in EPA's National Greenhouse Gas Emissions Inventory. But the trends in the monthly data can often be identified just a few weeks after the fact, providing much timelier insights. The different scopes of monthly and annual energy statistics is summarised below:

<!-- image -->

Insights from provisional monthly data are best regarded as useful early indications of shifts and trends in energy that will later be more fully quantified and verified by definitive annual data. The complementary use of both fast-provisional monthly data, and slower-definitive annual data, helps balance the competing needs of timeliness and authority in Ireland's energy data.

## 11.1 Monthly utility scale electricity data to 2024

The monthly data currently available to SEAI on electricity supply covers only the utility scale supply of electricity, i.e. the electricity supplied by large-scale grid-connected sites, and through international interconnectors. As a result, the monthly data does not capture instances of mini- or micro-generation of electricity, for example the electricity generated in rooftop solar panels. The monthly data also does not capture the small number of auto-producers active in Ireland that generate electricity for their own consumption.

<!-- image -->

Nonetheless, the fast-provisional total utility scale supply of electricity calculated from monthly data serves as an excellent proxy for identifying developing trends in Ireland's total electricity supply, and the total electricity demand driving that supply. The utility scale supply of electricity in recent years has accounted for over 95% of overall electricity supply. Small-scale electricity generation, as well as transmission, distribution, and storage losses, are fully accounted for in SEAI's National Energy Balance, which benefits from more definitive annual surveys and cross-agency reconciliations of data. The monthly data is provided by EirGrid in megawatt hours (MWh) in terms of a net electricity production basis and converted to terawatt hours (TWh) by SEAI.

## 11.1.1 Seasonality in utility scale monthly electricity supply

The bar chart in Figure 11.1 shows the utility scale electricity supply per month from January 2015 to September 2024. For clarity and ease of comparison, 2024 is coloured dark blue, whereas, previous years are coloured in a lighter shade of blue. The red line shows a 12-month moving average of those monthly values and helps to identify underlying long-term trends. While the seasonality of electricity supply is somewhat apparent in this 'raw' monthly data, it can be made much clearer through cross-year averaging and normalisation for number of days in a given month, as shown in subsequent figures.

Figure 11.1: Monthly utility scale electricity supply - January 2015 to September 2024

<!-- image -->

Source: data from EirGrid

Figure 11.2 shows the average monthly utility scale electricity supply by month, where each month's value is the average of that month's electricity supply (total, renewable or non-renewable), normalised for number of days in a month, over the previous 5 years. For example, the January value is the average of January in 2020, 2021, 2022, 2023 and 2024 and the October value is the average of October in 2019, 2020, 2021, 2022 and 2023. The figure below shows average total supply (top), average renewable supply (middle) and average non-renewable supply (bottom). It shows the seasonality of our electricity supply whereby the electricity supply is higher in the winter months and lower in the summer months. The renewable supply shows a pronounced seasonal variation, oscillating around an average value of approximately 1.1 TWh. It has a maximum of approximately 1.4 TWh from December to February, and a minimum of approximately 0.8 TWh from June to August. The seasonal variation of renewable electricity generation is therefore approximately ±31% the annual average. This variation is largely driven by the strong seasonality of wind generation, which makes up a considerable fraction of our renewable electricity generation (see below for more details). Fortunately, the seasonality of our renewable electricity generation matches the seasonality of our demand the wind generally blows hardest in the winter months, and this is when energy demand for light and heat is highest. The non-renewable supply is relatively flat at approximately 1.6 TWh per month, but shows higher non-renewable electricity supply in the summer months, and lower non-renewable electricity supply in the winter months. Non-renewable electricity supply is anti-correlated to renewable supply - when renewable supply is high, non-renewable electricity is low, and vice versa. This is most clearly illustrated by comparing the average values of February and July, where the particularly high and low renewable supply values match particularly low and high renewable supply values.

Figure 11.2: Average monthly utility scale electricity supply over last 5 years (normalised for number of days per month)

<!-- image -->

Source: data from EirGrid

Figure 11.3 shows utility scale monthly electricity supply ( i.e. total generation plus net imports) from January to September in 2024, split by electricity supply from renewable generation and non-renewable sources. Although this value can be regarded as a leading indicator of Ireland's renewable share of energy in electricity (RES-E), it is not directly equivalent to the RES-E value because the methodology for the RES-E calculation additionally includes (1) mini- and micro- generation of renewable electricity, (2) the electricity generated by auto-producers (including CHP plants), (3) multi-year normalisation of wind and hydro generations, and (4) a formal accounting for the sustainability status of various biomass fuels.

Figure 11.3: Share of renewable/non-renewable utility scale electricity supply - January to September 2024

<!-- image -->

Source: data from EirGrid

The bar chart in Figure 11.4 shows the share of utility scale monthly electricity supply, split by electricity supply from indigenous generation (green) and net imports (blue) between January 2015 to September 2024. For clarity and ease of comparison, 2024 is coloured in darker shades, whereas previous years are coloured in lighter shades. In months with percentage shares above 100%, this represents periods when there was a net export of electricity outside of Ireland's national boundaries, across international interconnectors. The lines show two 12-month moving averages of the monthly data and help to identify underlying long-term trends in monthly indigenous electricity production (green) and electricity net imports (blue) data.

Figure 11.4: Share of utility scale electricity supply split by indigenous generation and net imports

<!-- image -->

Source: data from EirGrid

## 11.1.2 Monthly utility scale electricity generated

The bar chart in Figure 11.5 shows utility scale electricity generated and exported to the grid per month from January 2015 to September 2024. For clarity and ease of comparison, 2024 is coloured dark blue, whereas previous years are coloured in a lighter shade of blue. The red line shows a 12-month moving average of monthly values and helps to identify underlying long-term trends.

Figure 11.5: Monthly utility scale electricity generation - January 2015 to September 2024

<!-- image -->

Source: data from EirGrid

Figure 11.6 shows the monthly electricity generation to the grid to date in 2024, broken down by input fuel or energy type. Note that this figure shows the electricity generated due to each fuel/energy input, rather than the quantity of fuel/energy needed to generate that electricity. The seasonal variations in electricity generated from wind and gas are visible, with wind accounting for 50% of grid exported electricity in March 2024.

Figure 11.6: Monthly electricity generation by source in 2024

<!-- image -->

Source: data from EirGrid

Figure 11.7 shows the breakdown of the generated electricity by input fuel or energy type, averaged over the last 12 calendar months, e.g. from September 2023 to September 2024. This 12-month approach is more appropriate than simply averaging over the year-to-date, because electricity generation from October to December has higher seasonal renewable contributions.

Figure 11.7: Sources of electricity generation - 12-month rolling average to September 2024

<!-- image -->

Source: data from EirGrid

## 11.1.3 Monthly electricity imported and exported in 2024

The bar chart in Figure 11.8 shows the import and export of electricity to-and-from Ireland through international interconnections each month. The resulting 'net import 'of electricity through the interconnections is shown by the black data points joined with a line to guide the eye. For clarity and ease of comparison, 2024 is coloured blue, whereas previous years are coloured orange. A positive net import value for a given month means that Ireland imported more electricity than it exported that month, while a negative net import value for a given month means that Ireland exported more electricity than it imported that month.

Figure 11.8: Monthly imported and exported electricity (with net imports) - January 2015 to September 2024

<!-- image -->

Source: data from EirGrid

## 11.2 Gas

Ireland's national gas supply comes from the sum indigenous production at the Corrib Gas Field and international imports from the UK through a pair of international interconnectors to Moffat in Scotland.

SEAI uses public data from the Gas Network Ireland dashboard, and monthly survey returns from the Corrib Gas Field, to determine Ireland's national gas supply, and its split across indigenous production and imports flows.

The gas monthly data is expressed in terms of gross calorific value (GCV), while SEAI's national Energy Balance expresses all energy in terms of net calorific value (NCV). The net calorific value can be calculated from the gross calorific value by multiplying by a factor of 0.902.

## 11.2.1 Seasonality in monthly gas supply

Figure 11.9 shows the monthly supply of grid gas over the last few years, split into imported gas (blue), indigenous gas (green) and stock draw (red). For clarity and ease of comparison, 2024 is coloured in darker shades, whereas previous years are coloured in lighter shades.  The large step-change increase in indigenous production in January 2016 is due to the connection of the Corrib gas field to the national gas grid. Indigenous production peaked in 2017 and has slowly been decreasing since then, which is commensurate with the natural life cycle of a gas field. The sharp drops in indigenous production in September 2017, July 2021 and July-August 2023 correspond to periods of maintenance at the Corrib gas field or its connection to the grid. In these periods of low indigenous production, the gas interconnectors between Ireland and Scotland stepped-up delivery of imports to satisfy demand. The monthly supply of gas to the grid can be 'spikey' because a substantial fraction of total gas supply is used for electricity generation which backs intermittent wind generation. In periods of low wind, gas supply to gas-fired electricity plants needs to increase, and vice versa.

Figure 11.9: Monthly gas supply trends - January 2015 to September 2024

Source: data from GNI &amp; SEAI

<!-- image -->

Figure 11.10 shows the total gas supply to the grid by month, where each month's value is the average value of that month's gas supply, normalised for number of days in a month, over the previous 5 years. For example, the January value is the average of January in 2020, 2021, 2022, 2023 and 2024 and the October value is the average of October in 2019, 2020, 2021, 2022 and 2023. While certain sectors have pronounced seasonal variations, particularly the residential sector's gas demand for space heating, the overall seasonal variation in total gas supply is relatively small. Market-shifts act to flatten the profile of monthly gas supply across the year. In winter months, gas supply to the residential sector is higher for heating, but gas supply to electricity generation is lower (because wind generation has a seasonal peak). Conversely, in summer months, gas supply to the residential sector is lower, but gas supply to electricity generation is higher (because wind generation has a seasonal low).

Figure 11.10: Average monthly gas supply over last 5 years (normalised for number of days per month)

<!-- image -->

Source: data from GNI &amp; SEAI

## 11.2.2 Monthly gas supply in 2024

As currently collected, the monthly gas supply data shown in Figure 11.11 is broken down into indigenous gas and imported gas. In general, indigenous supply is relatively constant on a month-to-month basis (outside of periodic maintenance in June 2024) and imported gas is adjusted to match demand patterns, especially those arising from gas-fired electricity generation plants stepping-up and -down to back renewable generation of electricity.

## Figure 11.11: 2024 monthly gas supply

<!-- image -->

Source: data from GNI &amp; SEAI

Figure 11.12 shows the breakdown of monthly gas supply data in 2024 by indigenous gas and imported gas, averaged over the last 12 calendar months, i.e. from September 2023 to September 2024. This approach is more appropriate than simply averaging over the year-to-date to September 2024, because electricity generation from October to December has higher seasonal renewable contributions. In the last 12-months, the proportion of electricity generation to the grid was:

•

Imported gas 22%

•

Indigenous gas 78%

## Figure 11.12: Source of gas supply - 12-month rolling average to September 2024

<!-- image -->

Source: data from GNI &amp; SEAI

## 11.3 Oil

Monthly data on the delivery of both oil products and biofuel products to the Irish market is made available to SEAI through its access to the national oil levy administration (OLA) database, which is maintained and operated by the Department of the Environment, Climate and Communications (DECC). SEAI uses data from DECC's OLA database to satisfy several of Ireland's energy reporting obligations to the European Commission under the Energy Statistics Regulation 1099/2008 [2], and to populate the national Energy Balance for Ireland.

Relevant obligated parties, for example large oil suppliers operating in the Irish market, are required to make monthly submission to the OLA database. Despite occasional corrections and revisions by these suppliers, the running total of monthly gross inland deliveries provides an excellent fast-provisional proxy for identifying trends in Ireland's demand for oil products and biofuel blending.

Monthly oil supply is captured in terms of gross inland deliveries (GIDs), or 'The observed delivery of finished petroleum products from primary sources ( e.g. refineries, blending plants etc. ) to the inland market' and published in terms of net calorific value (NCV). GID is the quantity of oil-products flowing through the market from production to delivery, now ready sale or consumption:

Gross Inland Delivery = Primary product receipts + Refinery gross output + Recycled products Refinery fuel + Imports - Exports - International marine bunkers + Inter-product transfers - Products transferred - Stocks changes

## 11.3.1 Seasonality and COVID impacts in monthly oil deliveries

Figure 11.13 shows the sum of monthly oil deliveries from road diesel (blue), motor petrol (orange), heating kerosene (red), jet kerosene (grey), and gas oil (green) from January 2016 to September 2024. For clarity and ease of comparison, 2024 is coloured in darker shades, whereas previous years are coloured in lighter shades.

Figure 11.13: Oil supply trends - January 2016 to September 2024

Source: data from Dept. of Environment, Climate and Communications and SEAI

<!-- image -->

Figure 11.14 to Figure 11.17 breakout the monthly delivery of different oil products to better show their seasonal variation, and any impacts from COVID. For clarity and ease of comparison, 2024 is coloured in darker shades, whereas previous years are coloured in lighter shades.

Figure 11.14 shows the monthly deliveries of heating kerosene. It has a strong seasonal pattern with demand peaking in the height of winter and falling to about 20% of peak values in the summer months.

Figure 11.14: Trend in heating kerosene - January 2016 to September 2024

<!-- image -->

Source: data from Dept. of Environment, Climate and Communications and SEAI

Figure 11.15 shows the monthly deliveries of jet kerosene. Deliveries of jet kerosene show peaks in summer months and in the Christmas / New Years period, due to the high volume of flights to and from Ireland for holidays and tourism. In April 2020, delivery of jet kerosene fell to just 10% of its peak value in 2019, as COVID travel restrictions were rolled out.

Figure 11.15: Trend in jet kerosene - January 2016 to September 2024

<!-- image -->

Source: data from Dept. of Environment, Climate and Communications and SEAI

Figure 11.16 shows the monthly deliveries of motor petrol. It show a gradual, but noticeable decline from January 2016 to January 2020, before being disrupted by COVID impacts. This led to significant dips in April 2020 and January 2021 following the announcement of national lockdown restrictions on 27 March and 31 December 2020, respectively. A smaller dip around and after Christmas 2021 was likely due to travel hesitancy after the COVID-Omicron surge.

Figure 11.16: Trend in motor petrol - January 2016 to September 2024

<!-- image -->

Source: data from Dept. of Environment, Climate and Communications and SEAI

Figure 11.17 shows the monthly deliveries of road diesel. Road diesel deliveries show the same sharp COVID features as motor petrol. However, in contrast to motor petrol, road diesel shows a gradual but noticeable increase from January 2016 to January 2020.

## Figure 11.17: Trend in road diesel - January 2016 to September 2024

<!-- image -->

Source: data from Dept. of Environment, Climate and Communications and SEAI

## 11.3.2 Monthly oil supplies in 2024

Figure 11.18 shows the breakdown of monthly oil deliveries by type in 2024 to date. The seasonal variations in heating kerosene and jet kerosene are visible and tend to compensate for each other in the total oil deliveries, i.e. deliveries of jet kerosene are highest in summer, when deliveries of heating kerosene are lowest.

Figure 11.18: Monthly oil product supply - 2024 to date

<!-- image -->

Source: data from Dept. of Environment, Climate and Communications and SEAI

Figure 11.19 shows the percentage breakdown of average monthly oil deliveries by type to date in 2024:

•

Road Diesel 46%

• Jet Kerosene 17%

•

Gas oil 14%

• Motor Petrol 12%

- · Heating Kerosene 11%

Figure 11.19: Breakdown of oil product supply - 2024 to date

<!-- image -->

Source: data from Dept. of Environment, Climate and Communications and SEAI

## Appendix 1: List of figures

| Figure 1.1: Time series of Ireland's energy related emissions ...............................................................................................                                                                                                                                                                                                                                                                            | 11                                                                                                                                                              |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Figure 1.2: Ireland's energy related emissions split into transport emissions and electricity emissions (as are defined in the national carbon budgets) and all other remaining 'heat' emissions .............................................                                                                                                                                                                                           | they 12                                                                                                                                                         |
| Figure 1.3: Ireland's energy-related emissions in 2023 and compared to 2022, split into transport emissions and electricity emissions (as they are defined in the national carbon budgets) and all other remaining 'heat' emissions .................................................................................................................................................................................................... | 13                                                                                                                                                              |
| Figure 1.4: 2022 to 2023 changes in Ireland's gross supply of electricity and its impact on electricity generation emissions (NRW: Non-renewable wastes) .............................................................................................................                                                                                                                                                                   | 13                                                                                                                                                              |
| Figure 1.5: Reported and estimated electricity emissions in the first carbon budget .................................................                                                                                                                                                                                                                                                                                                    | 14                                                                                                                                                              |
| Figure 1.6: Reported and estimated transport emissions in the first carbon budget..................................................                                                                                                                                                                                                                                                                                                      | 15                                                                                                                                                              |
| Figure 1.7: Time series percentage breakdown of Ireland's primary energy consumption by fossil fuel, renewable energy, and other sources (i.e. net-imported electricity and non-renewable wastes)..........................                                                                                                                                                                                                              | 16                                                                                                                                                              |
| Figure 1.8: 2022 to 2023 changes in Ireland's use of renewable energy ..........................................................................                                                                                                                                                                                                                                                                                         | 17                                                                                                                                                              |
| Figure 1.9: Breakdown of the 23.0 TWh of renewable energy used in Ireland in 2023...............................................                                                                                                                                                                                                                                                                                                         | 17                                                                                                                                                              |
| Figure 1.10: Ireland's overall renewable energy share results and targets under RED-II and RED-III ...................                                                                                                                                                                                                                                                                                                                   | 18                                                                                                                                                              |
| Figure 1.11: 2022 to 2023 changes in Ireland's energy consumption by energy product.........................................                                                                                                                                                                                                                                                                                                             | 19                                                                                                                                                              |
| Figure 1.12: Breakdown of Ireland's 2023 energy consumption by energy product ...................................................                                                                                                                                                                                                                                                                                                        | 19                                                                                                                                                              |
| Figure 1.13: 2022 to 2023 changes in Ireland's energy consumption by sector............................................................                                                                                                                                                                                                                                                                                                  | 20                                                                                                                                                              |
| Figure 1.14: Breakdown of Ireland's 2023 energy consumption by sector                                                                                                                                                                                                                                                                                                                                                                    | ...................................................................... 20                                                                                       |
| Figure 1.15: Ireland's total final energy consumption under the EED and its Article 4 target for 2030                                                                                                                                                                                                                                                                                                                                    | ............... 21                                                                                                                                              |
| Figure 1.16: 2022 to 2023 changes in Ireland's transport energy demand by sub-sector.........................................                                                                                                                                                                                                                                                                                                            | 22                                                                                                                                                              |
| Figure 1.17: Breakdown of Ireland's 2023 transport energy demand by sub-sector...................................................                                                                                                                                                                                                                                                                                                        | 22                                                                                                                                                              |
| Figure 1.18: Breakdown of Ireland's 2023 transport energy demand by energy sub-product................................                                                                                                                                                                                                                                                                                                                   | 23                                                                                                                                                              |
| Figure 1.19: Energy content of biofuel blending into road diesel shown on a scale of 0-100% and a scale                                                                                                                                                                                                                                                                                                                                  | of 24                                                                                                                                                           |
| 90-100% for improved data visualisation...................................................................................................................................... Figure 1.20: Recent demand for road diesel broken down by fossil and biofuel components ...............................                                                                                                                                    | 24 25                                                                                                                                                           |
| Figure 1.21: 2022 to 2023 changes in Ireland's electricity demand by sector ................................................................                                                                                                                                                                                                                                                                                             |                                                                                                                                                                 |
| Figure 1.22: Breakdown of Ireland's electricity demand by sector......................................................................................                                                                                                                                                                                                                                                                                   | 25                                                                                                                                                              |
| Figure 1.23: Electricity demand by from data centres compared to electricity demand from all other sectors                                                                                                                                                                                                                                                                                                                               | of                                                                                                                                                              |
| the Irish economy....................................................................................................................................................................................                                                                                                                                                                                                                                    | 26                                                                                                                                                              |
| Figure 1.24: Percentage breakdown of Ireland's gross electricity supply.........................................................................                                                                                                                                                                                                                                                                                         | 27                                                                                                                                                              |
| Figure 1.25: Monthly net-imports of electricity into Ireland with a 12-month moving average.............................                                                                                                                                                                                                                                                                                                                 | 28                                                                                                                                                              |
| scale supply of electricity ..................................................................................................................................................................... Figure 1.27: Ireland's installed wind capacity with 2024 estimates, projections to 2030, CAP targets .................                                                                                                                 | 28                                                                                                                                                              |
|                                                                                                                                                                                                                                                                                                                                                                                                                                          | 29                                                                                                                                                              |
| Figure 1.28: Summary of Ireland's solar PV generation, showing contributions from utility-scale solar farms and rooftop solar panels ...................................................................................................................................................................... .............................................................................................                                | 30 31                                                                                                                                                           |
| Figure 1.29: 2022 to 2023 changes in heat demand by sector Figure 1.30: Breakdown of Ireland's 2023 heat demand by sector                                                                                                                                                                                                                                                                                                                | ..................................................................................... 31                                                                        |
| Figure 1.31: 2022 to 2023 changes in heat demand by energy product ..........................................................................                                                                                                                                                                                                                                                                                            | 32                                                                                                                                                              |
| Figure 1.32: Breakdown of Ireland's 2023 heat demand by sector .....................................................................................                                                                                                                                                                                                                                                                                     | 32                                                                                                                                                              |
| Figure 1.33: Time series breakdown of heat demand by fossil fuels, renewable energy, and other sources                                                                                                                                                                                                                                                                                                                                   | (i.e.                                                                                                                                                           |
| non-renewable waste)...........................................................................................................................................................................                                                                                                                                                                                                                                          | 33                                                                                                                                                              |
| Figure 1.34: Time series breakdown of renewable heat demand by sub-product........................................................                                                                                                                                                                                                                                                                                                       | 33                                                                                                                                                              |
| Figure 1.35: 2022 to 2023 changes in Ireland's residential energy demand...................................................................                                                                                                                                                                                                                                                                                              | 34 34                                                                                                                                                           |
| Figure 1.36: Breakdown of Ireland's 2023 residential energy demand by energy product....................................... Figure 1.37: Time series of residential energy demand by energy product.....................................................................                                                                                                                                                                 | 35                                                                                                                                                              |
|                                                                                                                                                                                                                                                                                                                                                                                                                                          | 36                                                                                                                                                              |
| Figure 1.39: Annual average residential energy prices in Ireland for kerosene, electricity, and natural                                                                                                                                                                                                                                                                                                                                  |                                                                                                                                                                 |
| Figure 1.38: Percentage Difference in annual Heating Degree Days (HDDs) from long term average ................                                                                                                                                                                                                                                                                                                                          | gas...... 36 Ireland........................................................................................................................................ 37 |
| Figure 2.1: Main energy flows in Figure 2.2: Energy Flow in Ireland in 2023 (TWh).......................................................................................................................                                                                                                                                                                                                                                 | 38                                                                                                                                                              |
| Figure 3.1: Share of 2023 primary energy production by energy type..............................................................................                                                                                                                                                                                                                                                                                         | 41                                                                                                                                                              |

| Figure 3.2: Indigenous primary energy production by energy type with production / supply ratio .....................                                                                                                                                                             | 41                                                                                                                   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|
| Figure 3.3: Imports (positive) and exports (negative) by energy type (with total net imports) ...............................                                                                                                                                                    | 43                                                                                                                   |
| Figure 3.4: Share of primary energy requirement by energy type.......................................................................................                                                                                                                            | 45                                                                                                                   |
| Figure 3.5: Primary energy requirement by energy type in TWh.........................................................................................                                                                                                                            | 46                                                                                                                   |
| Figure 3.6: Import dependency of Ireland and the EU-27.......................................................................................................                                                                                                                    | 48                                                                                                                   |
| Figure 4.1: Energy inputs to transformation processes............................................................................................................                                                                                                                | 49                                                                                                                   |
| Figure 4.2: Flow of energy in electricity generation and consumption (TWh)................................................................                                                                                                                                       | 50                                                                                                                   |
| Figure 4.3: Energy input to electricity generation by energy type.......................................................................................                                                                                                                         | 51                                                                                                                   |
| Figure 4.4: Change in input energy type to electricity generation in 2023 compared with 2022...........................                                                                                                                                                          | 53                                                                                                                   |
| Figure 4.5: Gross electricity supply by energy type ...................................................................................................................                                                                                                          | 54                                                                                                                   |
| Figure 4.6: Change in gross electricity supply by energy type in 2023 compared with 2022...................................                                                                                                                                                      | 56                                                                                                                   |
| Figure 4.7: Electricity imports, exports and net imports                                                                                                                                                                                                                         | .......................................................................................................... 57        |
| Figure 4.8: Efficiency of electricity generation and supply......................................................................................................                                                                                                                | 58                                                                                                                   |
| Figure 4.9: CHP fuel input and thermal/electricity output......................................................................................................                                                                                                                  | 59                                                                                                                   |
| Figure 4.10: CHP electricity as percentage of total electricity generation........................................................................                                                                                                                               | 60                                                                                                                   |
| Figure 4.11: Installed solar PV capacity (AC) at year end.........................................................................................................                                                                                                               | 61                                                                                                                   |
| Figure 4.12: Map of grid-scale solar PV (solar farms) connected in Ireland ....................................................................                                                                                                                                  | 62                                                                                                                   |
| Figure 4.13: Installed wind generation capacity..........................................................................................................................                                                                                                        | 63                                                                                                                   |
| Figure 4.14: Map of grid-connected wind farms in Ireland....................................................................................................                                                                                                                     | 64                                                                                                                   |
| Figure 4.15: Map of grid-connected hydroelectric generators in Ireland (pumped hydro not shown)................                                                                                                                                                                  | 65                                                                                                                   |
| Figure 4.16: Outputs from oil refining.............................................................................................................................................                                                                                              | 67                                                                                                                   |
| Figure 4.17: Pumped hydroelectric storage (Turlough Hill)....................................................................................................                                                                                                                    | 68                                                                                                                   |
| Figure 4.18: Battery generation capacity [MW] at year end...................................................................................................                                                                                                                     | 69                                                                                                                   |
| Figure 4.19: Battery storage - energy storage capacity (MWh) at year end....................................................................                                                                                                                                     | 70                                                                                                                   |
| Figure 4.20: Annual production of peat briquettes....................................................................................................................                                                                                                            | 71                                                                                                                   |
| Figure 5.1: Share of 2023 final energy consumption by energy type.................................................................................                                                                                                                               | 73                                                                                                                   |
| Figure 5.2: Total final consumption by energy type..................................................................................................................                                                                                                             | 74                                                                                                                   |
| Figure 5.3: Share of 2023 final energy consumption by sector.............................................................................................                                                                                                                        | 75                                                                                                                   |
| Figure 5.4: Final energy consumption by sector.........................................................................................................................                                                                                                          | 76                                                                                                                   |
| Figure 5.5: Shares of energy types in industry final energy....................................................................................................                                                                                                                  | 77                                                                                                                   |
| Figure 5.6: Final energy in industry by energy type...................................................................................................................                                                                                                           | 78                                                                                                                   |
| Figure 5.7: Shares of energy types in transport final energy Figure 5.8: Final energy in transport sector by energy type...................................................................................................                                                      | ................................................................................................. 79 80              |
| Figure 5.9: Shares of subsectors in transport final energy......................................................................................................                                                                                                                 | 81                                                                                                                   |
| Figure 5.10: Final energy in transport by subsector ..................................................................................................................                                                                                                           | 82                                                                                                                   |
| Figure 5.11: Shares of energy types in residential final energy.............................................................................................                                                                                                                     | 84                                                                                                                   |
| Figure 5.12: Final energy in residential by energy type............................................................................................................                                                                                                              | 85                                                                                                                   |
| Figure 5.13: Shares of energy types in commercial and public services final energy..................................................                                                                                                                                             | 86                                                                                                                   |
| Figure 5.14: Final energy in commercial and public services by energy type.................................................................                                                                                                                                      | 86                                                                                                                   |
| Figure 5.15: Shares of final energy in commercial services by subsector.........................................................................                                                                                                                                 | 88                                                                                                                   |
| Figure 5.16: Final energy in commercial services by subsector (breakdown not available prior to 2009)...........                                                                                                                                                                 | 88                                                                                                                   |
| Figure 5.17: Shares of final energy in public services by subsector .................................................................................... Figure 5.18: Final energy in public services by subsector (breakdown not available prior to 2009)...................... | 89 89                                                                                                                |
| Figure 6.1: Current split of final energy by mode of application..........................................................................................                                                                                                                       | 90                                                                                                                   |
| modes........................................................................................                                                                                                                                                                                    |                                                                                                                      |
| Figure 6.2: Final energy in electricity, transport and heat                                                                                                                                                                                                                      | 91                                                                                                                   |
| Figure 6.3: Final energy use for heat, actual and weather                                                                                                                                                                                                                        | corrected.................................................................................. 92                       |
| Figure 6.4: Final energy in heat mode by sector.........................................................................................................................                                                                                                         | 92                                                                                                                   |
| Figure 6.5: Final energy in heat mode by fuel..............................................................................................................................                                                                                                      | 93 94                                                                                                                |
| Figure 6.6: Final consumption of oil for heat by sector............................................................................................................                                                                                                              | subsector........................................................................................................ 95 |
| Figure 6.7: Final energy in transport mode by Figure 6.8: Final energy in transport mode by fuel.................................................................................................................... Figure 6.9: Final consumption in electricity mode by        | 97 sector.................................................................................................. 98       |
| Figure 6.10: Shares of primary energy by mode.......................................................................................................................100                                                                                                          |                                                                                                                      |

| Figure 6.11: Primary energy by mode...........................................................................................................................................100                                                                                                                                        |                                                                                                                |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------|
| Figure 7.1: GHG emissions per kWh of electricity consumption, with contribution by energy type                                                                                                                                                                                                                           | ................... 101                                                                                        |
| Figure 7.2: Current sectoral shares of energy-related CO 2                                                                                                                                                                                                                                                               | eq..............................................................................................102            |
| Figure 7.3: Energy-related annual CO 2 eq emissions by sector                                                                                                                                                                                                                                                            | ......................................................................................... 103                  |
| Figure 7.4: Industry energy-related CO 2 eq emissions by energy type.............................................................................                                                                                                                                                                        | 105                                                                                                            |
| Figure 7.5: Transport energy-related emissions by energy type (including international aviation).....................                                                                                                                                                                                                    | 106                                                                                                            |
| Figure 7.6: Residential energy-related CO 2 eq by fuel.............................................................................................................                                                                                                                                                      | 108                                                                                                            |
| Figure 7.7: Commercial and public services sector CO 2 eq emissions by energy type...............................................                                                                                                                                                                                        | 109                                                                                                            |
| Figure 7.8: Energy-related CO 2 eq emissions by electricity, transport and heat...........................................................                                                                                                                                                                               | 110                                                                                                            |
| Figure 7.9: Avoided emissions from renewable energy in electricity, heat and transport modes........................112                                                                                                                                                                                                  |                                                                                                                |
| Figure 7.10: Avoid emissions by renewable energy                                                                                                                                                                                                                                                                         | type.......................................................................................................113 |
| Figure 8.1: National total greenhouse gas emissions by source (excludes international aviation) ......................                                                                                                                                                                                                   | 114                                                                                                            |
| Figure 8.2: Energy-related and total GHG emissions in the ETS and non-ETS sectors for 2005 baseline and 2023............................................................................................................................................................................................................ | 115                                                                                                            |
| Figure 8.3: Index of non-ETS greenhouse gas emissions relative to 2005 .....................................................................                                                                                                                                                                             | 116                                                                                                            |
| Figure 8.4: Energy-related non-ETS greenhouse gas emissions.........................................................................................117                                                                                                                                                                  |                                                                                                                |
| Figure 8.5: EU ETS greenhouse gas emissions in Ireland (excluding international aviation)...................................                                                                                                                                                                                             | 118                                                                                                            |
| Figure 8.6: Sectoral ceilings first two carbon budgets, spanning 2021-2025 and                                                                                                                                                                                                                                           | 2026-2030...............................120                                                                    |
| Figure 8.7: Sectoral emissions ceiling for electricity ................................................................................................................121                                                                                                                                               |                                                                                                                |
| Figure 8.8: Sectoral emissions ceiling for transport.................................................................................................................122                                                                                                                                                 |                                                                                                                |
| Figure 8.9: 2023 share of renewable energy by mode...........................................................................................................126                                                                                                                                                         |                                                                                                                |
| Figure 8.10: Renewable energy share (overall RES) with contribution by mode..........................................................                                                                                                                                                                                    | 126                                                                                                            |
| Figure 8.11: Renewable energy share (overall RES) and trajectories to 2030 target..................................................                                                                                                                                                                                      | 127                                                                                                            |
| Figure 8.12: Renewable and fossil gross final energy consumption by mode..............................................................                                                                                                                                                                                   | 127                                                                                                            |
| Figure 8.13: Renewable energy share of gross final consumption by source...............................................................                                                                                                                                                                                  | 128                                                                                                            |
| Figure 8.14: RES-E - gross final consumption of electricity from renewable sources................................................                                                                                                                                                                                       | 130                                                                                                            |
| Figure 8.15: RES-H - gross final consumption of heat from renewable sources .........................................................                                                                                                                                                                                    | 132                                                                                                            |
| Figure 8.16: RES-T - final consumption in transport from renewable sources.............................................................                                                                                                                                                                                  | 136                                                                                                            |
| Figure 8.17: Renewable energy in transport by energy type (without multipliers).....................................................                                                                                                                                                                                     | 137                                                                                                            |
| Figure 8.18: Electricity prices to industry......................................................................................................................................139                                                                                                                                     |                                                                                                                |
| Figure 8.20: Natural gas prices to industry..................................................................................................................................141                                                                                                                                         |                                                                                                                |
| Figure 8.21: Real energy price changes to industry since 2015 (index)...........................................................................142                                                                                                                                                                      |                                                                                                                |
| Figure 9.1: Index of modified domestic demand, final energy demand and energy price......................................                                                                                                                                                                                                | 144                                                                                                            |
| Figure 9.2: Index of final energy, primary energy and energy-related CO                                                                                                                                                                                                                                                  | 145                                                                                                            |
| 2 eq.............................................................. Figure 9.3: Deviation from average heating degree days (2005 to 2023) and resulting weather                                                                                                                                                           | adjustment.146                                                                                                 |
| Figure 9.4: Primary, final and electricity intensities..................................................................................................................147                                                                                                                                              |                                                                                                                |
| Figure 10.1: Total primary energy requirement by sector.....................................................................................................148                                                                                                                                                          |                                                                                                                |
| Figure 10.2: Industry energy intensity...........................................................................................................................................149                                                                                                                                     |                                                                                                                |
| Figure 10.3: Private car total annual vehicle-kilometres                                                                                                                                                                                                                                                                 | ........................................................................................................150    |
| Figure 10.4: Specific CO 2 emissions of new cars, excluding battery electric vehicles ................................................                                                                                                                                                                                   | 151                                                                                                            |
| Figure 10.5: Share of private cars licensed for the first time that are new or pre-owned imports.......................                                                                                                                                                                                                  | 152                                                                                                            |
| Figure 10.6: Private cars licensed for the first time that are battery electric vehicles ................................................                                                                                                                                                                                | 153                                                                                                            |
| Figure 10.7: Road freight activity.....................................................................................................................................................154                                                                                                                               |                                                                                                                |
| Figure 10.8: Road freight activity by main type of work                                                                                                                                                                                                                                                                  | done............................................................................................155            |
| Figure 10.9: Residential final energy..............................................................................................................................................156                                                                                                                                   |                                                                                                                |
| Figure 10.10: Energy per dwelling (permanently occupied).................................................................................................                                                                                                                                                                | 157                                                                                                            |
| Figure 10.11: Unit energy-related greenhouse gas emissions per dwelling..................................................................158                                                                                                                                                                             |                                                                                                                |
| Figure 10.12: Energy intensity of the commercial and public services sector...............................................................                                                                                                                                                                               | 159                                                                                                            |
| Figure 10.13: Energy per employee in the commercial and public services sector ....................................................                                                                                                                                                                                      | 160                                                                                                            |
| Figure 11.1: Monthly utility scale electricity supply - January 2015 to September 2024.........................................                                                                                                                                                                                          | 164                                                                                                            |
| Figure 11.2: Average monthly utility scale electricity supply over last 5 years (normalised for number of                                                                                                                                                                                                                | days                                                                                                           |

| Figure 11.3: Share of renewable/non-renewable utility scale electricity supply - January to September 2024                                                                                                             | ...................................................................................................................................................................................................................... 166   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Figure 11.4: Share of utility scale electricity supply split by indigenous generation and net imports................167                                                                                               |                                                                                                                                                                                                                              |
| Figure 11.5: Monthly utility scale electricity generation - January 2015 to September 2024 ................................                                                                                            | 168                                                                                                                                                                                                                          |
| Figure 11.6: Monthly electricity generation by source in 2024...........................................................................................169                                                            |                                                                                                                                                                                                                              |
| Figure 11.7: Sources of electricity generation - 12-month rolling average to September 2024...........................                                                                                                 | 170                                                                                                                                                                                                                          |
| Figure 11.8: Monthly imported and exported electricity (with net imports) - January 2015 to September                                                                                                                  | 2024                                                                                                                                                                                                                         |
| ...................................................................................................................................................................................................................... | 171                                                                                                                                                                                                                          |
| Figure 11.9: Monthly gas supply trends - January 2015 to September 2024 ...............................................................                                                                                | 172                                                                                                                                                                                                                          |
| Figure 11.10: Average monthly gas supply over last 5 years (normalised for number of days per month).....173                                                                                                           |                                                                                                                                                                                                                              |
| Figure 11.11: 2024 monthly gas supply........................................................................................................................................174                                       |                                                                                                                                                                                                                              |
| Figure 11.12: Source of gas supply - 12-month rolling average to September 2024 ...............................................                                                                                        | 175                                                                                                                                                                                                                          |
| Figure 11.13: Oil supply trends - January 2016 to September 2024 ................................................................................                                                                      | 177                                                                                                                                                                                                                          |
| Figure 11.14: Trend in heating kerosene - January 2016 to September 2024..............................................................                                                                                 | 178                                                                                                                                                                                                                          |
| Figure 11.15: Trend in jet kerosene - January 2016 to September 2024........................................................................                                                                           | 179                                                                                                                                                                                                                          |
| Figure 11.16: Trend in motor petrol - January 2016 to September 2024.......................................................................                                                                            | 180                                                                                                                                                                                                                          |
| Figure 11.17: Trend in road diesel - January 2016 to September 2024...........................................................................                                                                         | 181                                                                                                                                                                                                                          |
| Figure 11.18: Monthly oil product supply - 2024 to date.....................................................................................................182                                                        |                                                                                                                                                                                                                              |
| Figure 11.19: Breakdown of oil product supply - 2024 to date..........................................................................................183                                                              |                                                                                                                                                                                                                              |
| Figure 11.20: Residential Electricity Prices - January to June 2024 (includes 2 x €150 account credits)............                                                                                                    | 201                                                                                                                                                                                                                          |
| Figure 11.21: Household Electricity Prices - EU Ranking - January to June 2024.......................................................                                                                                  | 201                                                                                                                                                                                                                          |
| Figure 11.22: Residential Gas Prices - January to June 2024...............................................................................................202                                                          |                                                                                                                                                                                                                              |
| Figure 11.23: Household Gas Prices - EU Ranking - January to June 2024...................................................................                                                                              | 202                                                                                                                                                                                                                          |
| Figure 11.24: Business Electricity Prices - January to June 2024........................................................................................                                                               | 202                                                                                                                                                                                                                          |
| Figure 11.25: Business Gas Prices - January to June 2024....................................................................................................203                                                        |                                                                                                                                                                                                                              |

## Appendix 2: List of tables

| Table 3.1: Primary energy production by energy type (share) ..............................................................................................                                                                                                                                       | 42                                                                                                       |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------|
| Table 3.2: Imports by energy type (share).....................................................................................................................................                                                                                                                   | 43                                                                                                       |
| Table 3.3: Exports by energy type (share)......................................................................................................................................                                                                                                                  | 44                                                                                                       |
| Table 3.4: Net imports by energy type (share).............................................................................................................................                                                                                                                       | 44                                                                                                       |
| Table 3.5: Primary energy requirement by energy type (share)............................................................................................                                                                                                                                         | 46                                                                                                       |
| Table 4.1: Energy input to electricity generation by energy type (share)                                                                                                                                                                                                                         | ......................................................................... 52                             |
| Table 4.2: Energy input to electricity generation from renewables, non-renewables and electricity net                                                                                                                                                                                            | imports                                                                                                  |
| (share) ..........................................................................................................................................................................................................                                                                               | 52                                                                                                       |
| Table 4.3: Gross electricity production by energy type (share), with net imports.........................................................                                                                                                                                                        | 55                                                                                                       |
| Table 4.4: Gross electricity supply from renewables, non-renewables and net imports (share)..............................                                                                                                                                                                        | 56                                                                                                       |
| Table 4.5: Operational CHP capacity by fuel (share)..................................................................................................................                                                                                                                            | 59                                                                                                       |
| Table 4.6: Electricity exported to the grid from CHP.................................................................................................................                                                                                                                            | 60                                                                                                       |
| Table 4.7: Installed solar PV capacity (AC) at year end.............................................................................................................                                                                                                                             | 61                                                                                                       |
| Table 4.8: Wind capacity.......................................................................................................................................................................                                                                                                  | 63                                                                                                       |
| Table 4.9: Annual capacity factor for wind and hydro..............................................................................................................                                                                                                                               | 66                                                                                                       |
| Table 4.10: Outputs from oil refining (share) ...............................................................................................................................                                                                                                                    | 67                                                                                                       |
| Table 4.11: Battery generation capacity at year end.................................................................................................................                                                                                                                             | 69                                                                                                       |
| Table 4.12: Battery storage capacity at year end........................................................................................................................                                                                                                                         | 70                                                                                                       |
| Table 4.13: Battery storage consumption and generation......................................................................................................                                                                                                                                     | 70                                                                                                       |
| Table 5.1: Final energy consumption by energy type (share)................................................................................................                                                                                                                                       | 74                                                                                                       |
| Table 5.2: Final energy consumption by sector (share)............................................................................................................                                                                                                                                | 76                                                                                                       |
| Table 5.3: Final energy in industry by energy type (share)                                                                                                                                                                                                                                       | ..................................................................................................... 78 |
| Table 5.4: Final energy in transport sector by energy types (share)                                                                                                                                                                                                                              | ................................................................................... 80                   |
| Table 5.5: Transport final energy by subsector (share).............................................................................................................                                                                                                                              | 83 85                                                                                                    |
| Table 5.6: Final energy in residential sector by energy type (share)................................................................................... Table 5.7: Final energy in commercial and public services (share)                                                                        | ...................................................................................... 87                |
| Table 6.1: Final energy in electricity, transport and heat compared (share)....................................................................                                                                                                                                                  | 91                                                                                                       |
| Table 6.2: Final energy in heat mode by sector (share)............................................................................................................                                                                                                                               | 93                                                                                                       |
| Table 6.3: Final energy in heat mode by energy type (share)................................................................................................                                                                                                                                      | 94                                                                                                       |
| Table 6.4: Final energy in transport mode by subsector (share)...........................................................................................                                                                                                                                        | 96 97                                                                                                    |
| Table 6.5: Final energy in transport mode by fuel (share)....................................................................................................... Table 6.6: Final consumption in electricity mode by sector (share)                                                              | .................................................................................... 99                  |
| Table 7.1: Energy-related CO 2 eq by sector (share) ..................................................................................................................                                                                                                                           | 104                                                                                                      |
| Table 7.2: Quantities and shares of energy-related CO eq emissions in industry                                                                                                                                                                                                                   | (share)........................................ 105                                                      |
| Table 7.3: Quantities and shares of energy-related CO 2 eq emissions in transport (share) .....................................                                                                                                                                                                  |                                                                                                          |
| Table 7.4: Quantities and shares of transport CO 2 eq emissions by subsector, including GHG emissions                                                                                                                                                                                            | 106 from                                                                                                 |
| Table 7.6: Quantities and shares of CO 2 eq emissions in commercial and public services (share)........................                                                                                                                                                                          | 118                                                                                                      |
| Table 8.1: Energy-related GHG emissions, ETS and non-ETS (share)................................................................................                                                                                                                                                 | 109                                                                                                      |
| (share)...........................                                                                                                                                                                                                                                                               |                                                                                                          |
| Table 8.2: Ireland's progress towards overall renewable energy share (RES) targets ................................................                                                                                                                                                              | 125                                                                                                      |
| Table 8.3: Overall RES - Renewable energy in gross final consumption by energy type                                                                                                                                                                                                              | 129                                                                                                      |
| Table 8.4: RES-E - gross final consumption of electricity from renewable sources (share)..................................... Table 8.5: RES-H - gross final consumption of heat from renewable sources (share) ..............................................                                   | 131 133                                                                                                  |
| RES-T...........................................................................................................135                                                                                                                                                                              |                                                                                                          |
| Table 8.6: Multipliers used in the calculation of                                                                                                                                                                                                                                                |                                                                                                          |
| Table 8.7: Limits on biofuels from certain feedstocks.............................................................................................................135                                                                                                                            |                                                                                                          |
| Table 8.8: Renewable energy for transport by source - without multipliers                                                                                                                                                                                                                        | (share)................................................... 138                                           |
| Table 8.9: Electricity price to industry change since 2015.....................................................................................................139                                                                                                                               |                                                                                                          |
| Table 8.10: Oil prices to industry change since 2015..............................................................................................................140                                                                                                                            |                                                                                                          |
| Table 8.11: Natural gas prices to industry change since 2015............................................................................................141 Table 9.1: GDP, MDD, final energy, primary energy and energy-related CO eq.......................................................... | 144                                                                                                      |
| 2 Table 10.1: Primary energy by sector compared with previous years (share)...............................................................                                                                                                                                                       | 149                                                                                                      |

| Table 10.2: Electric private cars licensed for the first time (share).....................................................................................153                               |     |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Table 10.3: Road freight activity ......................................................................................................................................................154 |     |
| Table 10.4: Quantities of energy consumption and CO 2 eq emissions per dwelling (share)....................................                                                                 | 158 |
| Table 10.5: Quantities of energy per employee in commercial and public services (share)....................................                                                                 | 160 |
| Table A10.211.1: Short energy balance 2023 (ktoe)................................................................................................................206                        |     |

## Appendix 3: Glossary of abbreviations

| Abbreviation   | Explanation                                               |
|----------------|-----------------------------------------------------------|
| BEUS           | Business Energy Use Survey                                |
| CAP            | Climate action plan                                       |
| CCGT           | Combined cycle gas turbine                                |
| CHP            | Combined heat and power                                   |
| CO 2           | Carbon dioxide                                            |
| CO 2 eq        | Carbon dioxide equivalent                                 |
| CSO            | Central Statistics Office                                 |
| DART           | Dublin Area Rapid Transit                                 |
| DECC           | Department of the Environment, Climate and Communications |
| EPA            | Environmental Protection Agency                           |
| ETS            | EU Emission Trading Scheme                                |
| EV             | Electric vehicle                                          |
| GCV            | Gross calorific value                                     |
| GDP            | Gross domestic product                                    |
| GFC            | Gross final consumption (of energy)                       |
| GHG            | Greenhouse gas                                            |
| GNI*           | Modified gross national income                            |
| GNP            | Gross national product                                    |
| goe            | Gramme of oil equivalent                                  |
| GWh            | Gigawatt hour                                             |
| HGV            | Heavy goods vehicle                                       |
| ICT            | Information and communications technology                 |
| IEA            | International Energy Agency                               |
| IP             | Intellectual property                                     |
| IPCC           | Intergovernmental Panel on Climate Change                 |
| ktoe           | Kilotonne of oil equivalent                               |
| LNG            | Liquefied natural gas                                     |
| MDD            | Modified domestic demand                                  |
| NCT            | National Car Testing service                              |
| NCV            | Net calorific value                                       |
| NECP           | National Energy and Climate Plan                          |

| Abbreviation   | Explanation                                            |
|----------------|--------------------------------------------------------|
| NEDC           | New European Driving Cycle                             |
| NEEAP          | National energy efficiency action plan                 |
| NORA           | National Oil Reserves Agency                           |
| NREAP          | National renewable energy action plan                  |
| OECD           | Organization for Economic Co-operation and Development |
| PV             | Photovoltaic                                           |
| R&D            | Research and development                               |
| RED            | Renewable Energy Directive                             |
| REDI           | First Renewable Energy Directive                       |
| REDII          | Recast Renewable Energy Directive                      |
| RES            | Renewable energy share                                 |
| RES-E          | Renewable energy share in electricity                  |
| RES-H          | Renewable energy share in heat                         |
| RES-T          | Renewable energy share in transport                    |
| SEAI           | Sustainable Energy Authority of Ireland                |
| TFC            | Total final energy consumption                         |
| TJ             | Terajoule                                              |
| TPER           | Total primary energy requirement                       |
| TWh            | Terawatt hour                                          |
| UCO            | Used cooking oil                                       |
| UNFCCC         | United Nations Framework Convention on Climate Change  |
| VOC            | Volatile organic compounds                             |
| WLTP           | Worldwide Harmonised Light Vehicle Test                |

## Appendix 4: Glossary of terms

Biomass: Directive (EU) 2018/2001 defines biomass as the biodegradable fraction of products, waste and residues from biological origin from agriculture, including vegetal and animal substances, from forestry and related industries, including fisheries and aquaculture, as well as the biodegradable fraction of waste, including industrial and municipal waste of biological origin.

Carbon dioxide (CO2): A compound of carbon and oxygen formed when carbon is burned. Carbon dioxide is one of the main greenhouse gases. Units used in this report are t CO2 - tonnes of CO2, kt CO2 - kilotonnes of CO2 (10 3 tonnes) and MtCO2 - megatonnes of CO2 (10 6  tonnes).

Carbon dioxide equivalent (CO2eq): Used as a measure of the global warming impact of greenhouse gases on the basis of their global warming potential. Quantities of gases other than CO2 are converted into equivalent quantities of CO2 based on their global warming potential.

Carbon intensity (gCO2/kWh) : This is the amount of CO2 that will be released per kWh of energy of a given fuel. For most fossil fuels the value of this is almost constant, but in the case of electricity it will depend on the fuel mix used to generate the electricity and also on the efficiency of the technology employed.

Combined heat and power (CHP) plants : CHP refers to plants which are designed to produce both heat and electricity, for own use only or third-party owned and selling electricity and heat on site as well as exporting electricity to the grid.

Energy intensity : The amount of energy used per unit of activity. Examples of activity used in this report are gross domestic product (GDP), value added, number of households, employees, etc. Where possible, the monetary values used are in constant prices.

Gross and net calorific value (GCV and NCV) : The GCV gives the maximum theoretical heat release during combustion, including the latent heat of condensation of the water vapour produced during combustion. This water is produced by the combustion of the hydrogen in the fuel, or in some cases from the evaporation of water already present in the fuel. The NCV excludes this heat of condensation because it cannot be recovered in conventional boilers. For natural gas, the difference between GCV and NCV is about 10%, for oil it is approximately 5%.

Gross domestic product (GDP) : The GDP represents the total output of the economy over a period.

Gross electricity production: Gross electricity production is measured at the output terminals of the main generator or inverter; it therefore includes the energy taken by station auxiliaries and losses in transformers that are considered integral parts of the station. The difference between gross and net production is the amount of own use of electricity in the generation plants.

Gross final consumption (GFC) : Directive (EU) 2018/2001 defines gross final consumption of energy as ' the energy commodities delivered for energy purposes to industry, transport, households, services including public services, agriculture, forestry and fisheries, the consumption of electricity and heat by the energy branch for electricity and heat production, and losses of electricity and heat in distribution and transmission.'

Gross inland energy consumption : Sometimes abbreviated as gross inland consumption, is the total energy demand of a country or region. It represents the quantity of energy necessary to satisfy inland consumption of the geographical entity under consideration.

Heating degree days : 'Degree days' is the measure or index used to take account of the severity of the weather when looking at energy use in terms of heating (or cooling) 'load' on a building. A degree day is an expression of how cold (or warm) it is outside, relative to a day on which little or no heating (or cooling) would be required. It is thus a measure of the cumulative temperature deficit (or surplus) of the outdoor temperature relative to a neutral target temperature (base temperature) at which no heating or cooling would be required.

Modified gross national income (GNI*) : Modified gross national income (or GNI*) was introduced by the CSO in 2017 to assess the level of activity in the Irish economy excluding the effects of globalisation that disproportionately affect the Irish economic results. GNI* is defined as GNI less the effects of the profits of re-domiciled companies and the depreciation of intellectual property products and aircraft leasing companies.

Nominal and real values : Nominal value refers to the current value expressed in money terms in a given year, whereas real value adjusts nominal value to remove effects of price changes and inflation to give the constant value over time indexed to a reference year.

Total final consumption (TFC) : This is the energy used by the final consuming sectors of industry, transport, residential, services, agriculture and fisheries. It excludes the energy sector: electricity generation, oil refining, etc. Sometime referred to as total final energy consumption.

Total primary energy requirement (TPER) : This is the total requirement for all uses of energy, including energy used to transform one energy form to another (such as burning fossil fuel to generate electricity) and energy used by the final consumer.

Value added : Value added is an economic measure of output. The value added of industry, for instance, is the additional value created by the production process through the application of labour and capital. It is defined as the value of industry's output of goods and services less the value of the intermediate consumptions of goods (raw materials, fuel, etc. ) and services.

Wastes (non-renewable) : The non-renewable portion of wastes used as an energy source.

Weather correction : Annual variations in weather affect the space heating requirements of occupied buildings. Weather correction involves adjusting the energy used for space heating by benchmarking the climate in a particular year with that of a long-term average measured in terms of number of degree days.

## Appendix 5: Energy units and conversion factors

## Energy conversion factors

|       | To: toe     | MWh    | GJ      |
|-------|-------------|--------|---------|
| From: | Multiply by |        |         |
| toe   | ×1          | ×11.63 | ×41.868 |
| MWh   | ÷11.63      | ×1     | ×3.6    |
| GJ    | ÷41.868     | ÷3.6   | ×1      |

## Energy units

Joule (J): Joule is the international (SI) unit of energy.

Kilowatt hour (kWh): The conventional unit of energy that electricity is measured by and charged for commercially.

Tonne of oil equivalent (toe): This is a conventional standardised unit of energy. One tonne of oil equivalent is defined as having a net calorific value (NCV) of 41.868 GJ.  A related unit is the kilogram of oil equivalent (kgoe), where 1 kgoe = 10 -3  toe.

## Decimal prefixes

| deca (da)   | 10 1   | deci (d)   | 10 -1   |
|-------------|--------|------------|---------|
| hecto (h)   | 10 2   | centi (c)  | 10 -2   |
| kilo (k)    | 10 3   | milli (m)  | 10 -3   |
| mega (M)    | 10 6   | micro (m)  | 10 -6   |
| giga (G)    | 10 9   | nano (n)   | 10 -9   |
| tera (T)    | 10 12  | pico (p)   | 10 -12  |
| peta (P)    | 10 15  | femto (f)  | 10 -15  |
| exa (E)     | 10 18  | atto (a)   | 10 -18  |

## Calorific values

| Fuel                               | NCV toe/t   | NCV MJ/m 3   | NCV MJ/kg   |
|------------------------------------|-------------|--------------|-------------|
| Crude oil                          | 1.023       | -            | 42.81       |
| Gasoline / petrol (100% petroleum) | 1.065       | -            | 44.59       |
| Kerosene                           | 1.056       | -            | 44.20       |
| Jet kerosene                       | 1.053       | -            | 44.10       |
| Gas oil / diesel (100% petroleum)  | 1.034       | -            | 43.31       |
| Residual fuel oil (heavy oil)      | 0.985       | -            | 41.24       |
| Milled peat (2023)                 | 0.130       | -            | 5.43        |
| Sod peat                           | 0.313       | -            | 13.10       |
| Peat briquettes                    | 0.443       | -            | 18.55       |
| Coal                               | 0.665       | -            | 27.84       |
| LPG                                | 1.126       | -            | 47.16       |
| Petroleum coke (2023)              | 0.766       | -            | 32.09       |
| Natural gas (2023)                 | -           | 35.67        | -           |

## Emission factors

CO2 emission factors from fuel combustion are listed below. These emission factors include direct CO2 emissions from fuel combustion and do not include indirect or upstream emissions, such as those from extraction, cultivation, transportation or processing of fuels. To calculate GHG quantities from fuel combustion, SEAI use sector and fuel specific data from the EPA's National Inventory Submissions [3] (see section 2.3 for more details).

| Liquid Fuels                | t CO 2 /TJ (NCV)   | g CO 2 /kWh (NCV)   |
|-----------------------------|--------------------|---------------------|
| Motor Spirit (Gasoline)     | 70.0               | 251.9               |
| Jet Kerosene                | 71.4               | 257.0               |
| Other Kerosene              | 71.4               | 257.0               |
| Gas/Diesel Oil              | 73.3               | 263.9               |
| Residual Oil                | 76.0               | 273.6               |
| LPG                         | 63.7               | 229.3               |
| Solid Fuels and Derivatives |                    |                     |
| Petroleum Coke (2023)       | 94.1               | 338.6               |
| Coal                        | 94.6               | 340. 6              |
| Milled Peat (2023)          | 136.58             | 491.7               |
| Sod Peat                    | 104.0              | 374.4               |
| Peat Briquettes             | 98.9               | 355.9               |
| Gas                         |                    |                     |
| Natural Gas (2023)          | 56.6               | 203.8               |
| Electricity                 |                    |                     |
| Electricity (2023)          | 70.5               | 253.7               |

## Appendix 6: Data sources

SEAI gratefully acknowledges the co-operation of all the organisations, agencies, energy suppliers and distributors that provide data and respond to its questionnaires throughout the year:

- · Applus+ (National Car Test)
- · Central Statistics Office
- · Department of the Environment, Climate and Communications
- · Department of Housing, Local Government, and Heritage
- · Department of Transport
- · EirGrid
- · Environmental Protection Agency
- · ESB Networks
- · European Commission DG TREN
- · EU-funded ODYSSEE Project
- · Eurostat
- · Gas Networks Ireland
- · International Energy Agency
- · Met Éireann
- · National Grid UK
- · Revenue Commissioners
- · Road Safety Authority (Vehicle Registration Unit)
- · US Energy Information Administration
- · Vehicle Certification Agency UK.

## Appendix 7: Bibliography

- [1]   Sustainable Energy Authority of Ireland (SEAI), 'National Energy Balance,' [Online]. Available: https://www.seai.ie/data-and-insights/seai-statistics/key-publications/national-energy-balance.
- [2] European Union, 'Regulation (EC) No 1099/2008 of the European Parliament and of the Council on energy statistics,' 2008, as amended. [Online]. Available: https://eur-lex.europa.eu/legalcontent/EN/TXT/?uri=CELEX%3A32008R1099.
- [3] Environmental Protection Agency (EPA), 'Ireland's National Inventory Submissions 2024,' 2024. [Online]. Available: https://www.epa.ie/publications/monitoring--assessment/climate-change/airemissions/irelands-national-inventory-submissions-2024.php.
- [4] G. Myhre, D. Shindell, F.-M. Bréon, W. Collins, J. Fuglestvedt, J. Huang, D. Koch, J.-F. Lamarque, D. Lee, B. Mondoza, T. Nakajima, A. Robock, G. Stephens, T. Takemura and H. Zhang, 'Anthropogenic and Natural Radiative Forcing,' in Climaate Change 2013: The Physical Science Basis. Contribution of Working Group I to the Fifth Assessment Report of the Intergovernmental Panel on Climate Change , Cambridge, United Kingdom and New York, NY, USA, Cambridge University Press, 2013, pp. 659-740.
- [5] Sustainable Energy Authority of Ireland (SEAI), 'Ireland's Energy Supply and Security of Supply,' 2024. [Online]. Available: https://www.seai.ie/data-and-insights/seai-statistics/key-publications/energysupply-security.
- [6] Sustainable Energy Authority of Ireland (SEAI), 'Energy Security in Ireland,' 2020. [Online]. Available: https://www.seai.ie/sites/default/files/publications/Energy-Security-in-Ireland-2020-.pdf.
- [7] Eurostat, 'Energy Imports Dependency (nrg\_ind\_id),' [Online]. Available: https://ec.europa.eu/eurostat/cache/metadata/en/nrg\_ind\_id\_esmsip2.htm.
- [8] Eurostat, 'Electricity and Heat Annual Questionnaire: Reporting Instructions,' [Online]. Available: https://ec.europa.eu/eurostat/documents/38154/16135593/Electricity\_Heat-Questionnaire\_Instructions.pdf.
- [9] EirGrid, 'System and Renewable Data Reports,' [Online]. Available: https://www.eirgrid.ie/grid/systemand-renewable-data-reports.
- [10]   Central Statistics Office (CSO), 'Business Energy Use 2022,' 2024.
- [11]   Eurostat, 'Energy Statistics - Cooling and Heating Degree Days (nrg\_chdd),' [Online]. Available: https://ec.europa.eu/eurostat/cache/metadata/fr/nrg\_chdd\_esms.htm.
- [12]   P. Ciais, C. Sabine, G. Bala, L. Bopp, V. Brovkin, J. Canadell, A. Chhabra, R. DeFries, J. Galloway, M. Heimann, C. Jones, C. Le Quéré, R. Myneni, S. Piao and P. Thornton, 'Carbon and Other Biogeochemical Cycles,' in Climate Change 2013: The Physical Science Basis. Contribution of Working Group I to the Fifth Assessment Report of the Intergovernmental Panel on Climate Change , Cambridge, United Kingdom and New York, NY, USA, Cambridge University Press, 2013, p. 470.
- [13]   Sustainable Energy Authority of Ireland (SEAI), 'Renewable Energy in Ireland 2012,' 2014. [Online]. Available: https://www.seai.ie/sites/default/files/publications/Renewable-Energy-in-Ireland-2012.pdf.
- [14]   H. Holttinen, C. Cantor, J. McCann and J. Kiviluoma, 'Holttinen, Hannele &amp; Kiviluoma, Juha &amp; Cantor, Carla &amp; Mccann, John &amp; Clancy, Matthew &amp; Milligan, Michael. (2014). Estimating the Reduction of Generating System CO2 Emissions Resulting from Significant Wind Energy Penetration,' Berlin, 2014.
- [15]   Sustainable Energy Authority of Ireland (SEAI), 'Quantifying Ireland's Fuel and CO2 Emissions Savings from Renewable Electricity in 2012,' 2014. [Online]. Available: https://www.seai.ie/sites/default/files/publications/Quantifying-Irelands-Fuel-and-CO2-EmissionsSavings-from-Renewable-Electricity-in-2012.pdf.
- [16]   Environmental Protection Agency (EPA), 'Ireland's Provisional Greenhouse Gas Emissions 1990-2023,' [Online]. Available: https://www.epa.ie/publications/monitoring--assessment/climate-change/airemissions/irelands-provisional-greenhouse-gas-emissions-1990-2023.php.
- [31]   National Oil Reserves Agency (NORA), 'The Renewable Trasnport Fuel Obligation,' [Online]. Available: https://www.nora.ie/rtfo.
- [32]   Government of Ireland, 'S.I. No. 33/2012 - European Union (Biofuel Sustainability Criteria) Regulations 2012,' 2012. [Online]. Available: https://www.irishstatutebook.ie/eli/2012/si/33/made/en/print.

| [17]   | Eurostat, 'Greenhouse gas emissions by source sector,' 18 April 2024. [Online]. Available: https://ec.europa.eu/eurostat/databrowser/view/env_air_gge$dv_447/default/table?lang=en&category =agr.aei.aei_sec. [Accessed 09 December 2024].                                                                                                                                                                                                                                                                                                                                                              |
|--------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| [18]   | European Union, 'Regulation (EU) 2018/842 of the European Parliament and of the Council on binding annual greenhouse gas emission reductions by Member States from 2021 to 2030 contributing to climate action to meet commitments under the Paris Agreement,' and amending Regulation (EU) No 525/2013. 2018, as amended. [Online]. Available: https://eur-lex.europa.eu/legal- content/EN/TXT/?uri=CELEX%3A32018R0842&qid=1733227419478.                                                                                                                                                              |
| [19]   | European Union, 'Commission Implementing Decision (EU) 2020/2126 on setting out the annual emission allocations of the Member States for the period from 2021 to 2030 pursuant to Regulation (EU) 2018/842 of the European Parliament and of the Council,' 2020, as amended. [Online]. Available: https://eur-lex.europa.eu/eli/dec_impl/2020/2126/oj.                                                                                                                                                                                                                                                  |
| [20]   | Government of Ireland, 'Climate Action and Low Carbon Development (Amendment) Act 2021,' 2021. [Online]. Available: https://www.irishstatutebook.ie/eli/2021/act/32/section/15/enacted/en/html.                                                                                                                                                                                                                                                                                                                                                                                                         |
| [21]   | Government of Ireland, 'Carbon Budgets,' 2022. [Online]. Available: https://www.gov.ie/en/publication/9af1b-carbon-budgets/.                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
| [22]   | Government of Ireland, 'Government announces sectoral emissions ceilings, setting Ireland on a pathway to turn the tide on climate change,' 2022. [Online]. Available: https://www.gov.ie/en/publication/76864-sectoral-emissions-ceilings/.                                                                                                                                                                                                                                                                                                                                                            |
| [23]   | European Union, 'Directive 2009/28/EC of the European Parliament and of the Council on the promotion of the use of energy from renewable sources and amending and subsequently repealing Directives 2001/77/EC and 2003/30/EC,' 2009, as amended. (Repealed by Directive (EU) 2018/2001). [Online]. Available: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32009L0028.                                                                                                                                                                                                                  |
| [24]   | European Union, 'Directive 2018/2001 of the European Parliament and of the Council on the promotion of the use of energy from renewable sources (recast).,' 2018, as amended. [Online]. Available: https://eur-lex.europa.eu/legal-content/en/TXT/?uri=CELEX%3A32018L2001.                                                                                                                                                                                                                                                                                                                              |
| [25]   | European Union, 'Directive (EU) 2023/2413 of the European Parliament and of the Council amending Directive (EU) 2018/2001, Regulation (EU) 2018/1999 and Directive 98/70/EC as regards the promotion of energy from renewable sources,' and repealing Council Directive (EU) 2015/652. 2023. [Online]. Available: https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX:32023L2413.                                                                                                                                                                                                                 |
| [26]   | Government of Ireland, 'Ireland's National Energy and Climate Plan 2021-2030,' 2019. [Online]. Available: https://www.gov.ie/en/publication/0015c-irelands-national-energy-climate-plan-2021-2030/.                                                                                                                                                                                                                                                                                                                                                                                                     |
| [27]   | Government of Ireland, 'Ireland's National Energy and Climate Plan 2021-2030,' July 2024. [Online]. Available: https://www.gov.ie/en/publication/a856a-national-energy-and-climate-plan-necp-2021- 2030/.                                                                                                                                                                                                                                                                                                                                                                                               |
| [28]   | Government of Ireland, 'Climate Action Plan 2024,' 2023. [Online]. Available: https://www.gov.ie/en/publication/79659-climate-action-plan-2024/.                                                                                                                                                                                                                                                                                                                                                                                                                                                        |
| [29]   | Government of Ireland, 'S.I. No. 350/2022 - European Union (Renewable Energy) Regulations (2) 2022,' 2022. [Online]. Available: https://www.irishstatutebook.ie/eli/2022/si/350/.                                                                                                                                                                                                                                                                                                                                                                                                                       |
| [30]   | European Union, 'Regulation (EU) 2018/1999 of the European Parliament and of the Council on the Governance of the Energy Union and Climate Action,' amending Regulations (EC) No 663/2009 and (EC) No 715/2009 of the European Parliament and of the Council, Directives 94/22/EC, 98/70/EC, 2010/31/EU and 2013/30/EU of the European Parliament and of the Council, Council Directives 2009/119/EC and (EU) 2015/652 and repealing Regulation (EU) No 525/2013 of the European Parliament and of the Council. 2018, as amended. [Online]. Available: https://eur- lex.europa.eu/eli/reg/2018/1999/oj. |

| [33]   | National Oil Reserves Agency (NORA), 'RTFO Annual Reports,' [Online]. Available: https://www.nora.ie/annual-reports.                                                                                                                                                                                                                                      |
|--------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| [34]   | Sustainable Energy Authority of Ireland (SEAI), 'Electricity & Gas Prices,' [Online]. Available: https://www.seai.ie/data-and-insights/seai-statistics/key-publications.                                                                                                                                                                                  |
| [35]   | European Union, 'Regulation (EU) 2016/1952 of the European Parliament and of the Council on European statistics on natural gas and electricity prices and repealing Directive 2008/92/EC,' 2016. [Online]. Available: https://eur-lex.europa.eu/eli/reg/2016/1952/oj.                                                                                     |
| [36]   | International Energy Agency (IEA), 'Energy Prices,' [Online]. Available: https://www.iea.org/data-and- statistics/data-product/energy-prices.                                                                                                                                                                                                             |
| [37]   | Central Statistics Office (CSO), 'Quarterly National Accounts,' [Online]. Available: https://www.cso.ie/en/statistics/nationalaccounts/quarterlynationalaccounts/.                                                                                                                                                                                        |
| [38]   | Central Statistics Office (CSO), 'Road Freight Transport Survey,' [Online]. Available: https://www.cso.ie/en/statistics/transport/roadfreighttransportsurvey/.                                                                                                                                                                                            |
| [39]   | Sustainable Energy Authority of Ireland (SEAI), 'Public Sector Energy Efficiency Performance Report,' 2023. [Online]. Available: https://www.seai.ie/plan-your-energy-journey/public-sector/monitoring-and- reporting/public-sector-results.                                                                                                              |
| [40]   | European Union, 'Directive 2003/87/EC of the European Parliament and of the Council establishing a scheme for greenhouse gas emission allowance trading within the Community and amending Council Directive 96/61/EC.,' 2003, as amended. [Online]. Available: https://eur-lex.europa.eu/legal- content/EN/TXT/?uri=CELEX%3A32003L0087&qid=1733224636202. |
| [41]   | European Union, 'Directive (EU) 2023/1791 of the European Parliament and of the Council on energy efficiency and amending Regulation (EU) 2023/955 (recast),' 2023, as amended. [Online]. Available: https://eur-lex.europa.eu/legal- content/EN/TXT/?uri=OJ%3AJOL_2023_231_R_0001&qid=1695186598766#.                                                    |

## Appendix 8: Energy statistics revisions

Some changes, revisions and corrections to the historic energy balance data were implemented during 2023. The most significant of these are listed below.

## Total Final Energy Consumption

- · Sectoral split revised to align with the latest data from the 2022 CSO Business Energy Use Survey (BEUS), including historic revisions. Please see full methodological changes from the CSO at https://www.cso.ie/en/methods/surveybackgroundnotes/businessenergyuse/

## Ambient Heat

- · The ambient heat calculation have been updated to reflect the latest heat pump performance data available from the BER database.

## Transport

- · The bottom-up modelling of public passenger services and light goods vehicles was updated to include battery electricity vehicles and plug-in hybrids for 2015 to present. This changed the apportionment of petrol and diesel between these sub sectors and the other road sub sector. The addition of these vehicles also increased the consumption of electricity in the transport sector.

## Gasoil consumption in agriculture and residential

All quantities of gasoil made available for final consumption in Ireland are reported by oil suppliers via the Oil Levy Assessment (OLA) database administered by the Department of Environment, Climate and Communications. SEAI collect total annual gasoil consumption data from this database. This total consumption is then apportioned between the sectors of the economy based on, amongst other data, the CSO s Business Energy Use Survey, tax rebate data, EU-ETS data, and a historic assessment of the level of ' consumption in the agriculture sector.

It has become apparent to SEAI that this legacy method of apportioning was producing timeseries of annual gasoil consumption in the residential and agriculture sectors that are not consistent with other known factors:

- 1. The actual usage of gasoil in the residential sector has decreased significantly as almost all modern domestic oil boilers use kerosene instead of gasoil.
- 2. SEAI ' s assessments of energy consumption in agriculture, using a bottom-up assessment and analysis of available statistics on farming output, indicate a level of consumption higher than the agriculture gasoil timeseries.

During 2023, SEAI sought and received information on the usage of gasoil in agriculture and residential sectors from industry groups. SEAI amended the methodology for the apportionment of gasoil between residential and agriculture for 2022 and 2023 based on the best available data and the known trend in the consumption of other fuels in the residential sector.

This has been done as an interim measure while SEAI undertakes a programme to improve its assessment of energy demand in agriculture and strengthen bottom-up statistics on agriculture energy usage. In parallel, a similar programme will be undertaken for residential energy, specifically gasoil and certain solid fuels.

Upon the completion of these programmes, it is likely that SEAI will revise the timeseries of gasoil consumption for the agriculture and residential sectors.

## Appendix 9: Electricity and gas price tables

SEAI collects and analyses electricity and gas prices every 6-months, in line with EU Regulation 2016/1952. SEAI calculates the effective unit price of energy (the revenue collected for energy delivered, divided by the total quantity of energy delivered) across different consumption bands , and then calculate the weighted average price, based on the market-share of each consumption band. Using data available from Eurostat, SEAI ranks the effective unit price paid by Irish consumers, compared to their European counterparts.

The tables below update the effective electricity and gas energy prices paid by residential and business consumers in Ireland for January - June 2024. The tables breakdown the effective unit price of energy in each band, the changes in that price over the last 12- and 24-months, Ireland's EU ranking of the price in that band, with a ranking of 1 meaning highest price, and the market share of each band.

Note: Due to the recent increases in energy prices, Ireland introduced measures to alleviate the burden on final consumers.  Domestic electricity customers, including pay as you go customers, have so far received credits worth €1,250 on their bills, as:

- · four credits of €200 in April 2022, November 2022, January 2023 and March 2023.
- · three credits of €150 in December 2023, January 2024 and March 2024.

In Budget 2025 two further credits of €125 were announced, to be paid in November 2024 and January 2025.  These rebates are administered by electricity suppliers and are accounted for in the residential electricity prices for the relevant semester.

## Household Prices - Electricity

Figure 11.20: Residential Electricity Prices - January to June 2024 (includes 2 x €150 account credits)

| Household electricity prices (all taxes included) weighted average across all suppliers   |   c/kWh S1 2024 | Change in 12 months   | Change in 24 months   | Band Share of Market   |
|-------------------------------------------------------------------------------------------|-----------------|-----------------------|-----------------------|------------------------|
| Band DA Consumption < 1,000 kWh                                                           |            29.8 | +124%                 | +33%                  | 6.5%                   |
| Band DB 1,000 kWh < Consumption < 2,500 kWh                                               |            43.8 | +128%                 | +97%                  | 10.9%                  |
| Band DC 2,500 kWh < Consumption < 5,000 kWh                                               |            37.4 | +37%                  | +61%                  | 34.4%                  |
| Band DD 5,000 kWh < Consumption < 15,000 kWh                                              |            33.2 | +11%                  | +45%                  | 40.9%                  |
| Band DE Consumption > 15,000 kWh                                                          |            30.5 | +3%                   | +40%                  | 7.2%                   |
| Weighted Average                                                                          |            35.4 | +29%                  | +55%                  |                        |

Figure 11.21: Household Electricity Prices - EU Ranking - January to June 2024

| Household electricity prices (all taxes included) weighted average across all suppliers   |   c/kWh S1 2024 | Ranking EU (EUR)   |   PPS/kWh S1 2024 | Ranking EU (PPS)   |
|-------------------------------------------------------------------------------------------|-----------------|--------------------|-------------------|--------------------|
| Band DA Consumption < 1,000 kWh                                                           |            29.8 | 19                 |              24.8 | 24                 |
| Band DB 1,000 kWh < Consumption < 2,500 kWh                                               |            43.8 | 2                  |              36.5 | 5                  |
| Band DC 2,500 kWh < Consumption < 5,000 kWh                                               |            37.4 | 2                  |              31.1 | 7                  |
| Band DD 5,000 kWh < Consumption < 15,000 kWh                                              |            33.2 | 2                  |              27.6 | 9                  |
| Band DE Consumption > 15,000 kWh                                                          |            30.5 | 4                  |              25.4 | 13                 |
| Weighted Average                                                                          |            35.4 |                    |              29.5 |                    |

## Household Prices - Gas

Figure 11.22: Residential Gas Prices - January to June 2024

| Household gas prices (all taxes included) weighted average across all suppliers   |   c/kWh S1 2024 | Change in 12 months   | Change in 24 months   | Band Share of Market   |
|-----------------------------------------------------------------------------------|-----------------|-----------------------|-----------------------|------------------------|
| Band D1 Consumption < 20 GJ                                                       |            14.3 | -10.2%                | +50%                  | 9.5%                   |
| Band D2 20 GJ < Consumption < 200 GJ                                              |            12.7 | -13.2%                | +50%                  | 88.9%                  |
| Band D3 Consumption > 200 GJ                                                      |             9.7 | -15.6%                | +23%                  | 1.6%                   |
| Weighted Average                                                                  |            12.8 | -12.8%                | +51%                  |                        |

Figure 11.23: Household Gas Prices - EU Ranking - January to June 2024

| Household gas prices (all taxes included) weighted average across all suppliers   |   c/kWh S1 2024 | Ranking EU (EUR)   |   PPS/kWh S1 2024 | Ranking EU (PPS)   |
|-----------------------------------------------------------------------------------|-----------------|--------------------|-------------------|--------------------|
| Band D1 Consumption < 20 GJ                                                       |            14.3 | 11                 |              11.9 | 12                 |
| Band D2 20 GJ < Consumption < 200 GJ                                              |            12.7 | 4                  |              10.6 | 11                 |
| Band D3 Consumption > 200 GJ                                                      |             9.7 | 8                  |               8.1 | 15                 |
| Weighted Average                                                                  |            12.8 |                    |              11.9 |                    |

For residential electricity and gas prices, SEAI provide Ireland's prices and EU ranking in terms of both Euro (EUR) and purchasing power standard (PPS) units.

PPS is a 'virtual' unit of currency, calculated by Eurostat, in which national 'account aggregates' are normalised to recognise price-level differences between different countries. Notionally, one unit of PPS currency allows someone to purchase the same amount of goods and services in any country (which is not true for one unit of EUR, because of the varying costs of living in Eurozone countries).

When comparing the cost of energy to households, PPS-ranking can offer more nuanced insights than a EUR-ranking, because PPS considers the relative cost of living and the inflation rates of countries. While the normalisation applied in calculating the PPS prices includes consideration of the gross domestic product (GDP) of a country, it is not limited to a GDP correction - the PPS calculation involves product level, product group level, and aggregation level normalisations, to help ensure its robustness.

## Business Prices - Electricity

Figure 11.24: Business Electricity Prices - January to June 2024

| Business electricity prices (ex VAT) weighted average across all suppliers   |   c/kWh S1 2024 | Change in 12 months   | Change in 24 months   | Ranking (EU)   | Band Share of Market   |
|------------------------------------------------------------------------------|-----------------|-----------------------|-----------------------|----------------|------------------------|
| Band IA Consumption < 20 MWh                                                 |            32.4 | -13%                  | +7%                   | 4              | 7.4%                   |
| Band IB 20 MWh < Consumption < 500 MWh                                       |            30.3 | -15%                  | +29%                  | 1              | 20.1%                  |
| Band IC 500 MWh < Consumption < 2,000 MWh                                    |            25.6 | -10%                  | +18%                  | 1              | 9.6%                   |
| Band ID 2,000 MWh < Consumption < 20,000 MWh                                 |            21.8 | -9%                   | +12%                  | 2              | 20.6%                  |
| Band IE 20,000 MWh < Consumption < 70,000 MWh                                |            20.7 | -10%                  | +10%                  | 2              | 7.3%                   |
| Band IF 70,000 MWh < Consumption < 150,000 MWh                               |            19.7 | -18%                  | -2%                   | 3              | 4.3%                   |
| Band IG > 150,000 MWh                                                        |            16.3 | -23%                  | -29%                  | 1              | 30.6%                  |
| Weighted Average                                                             |            22.8 | -16%                  | +3%                   |                |                        |

## Business Prices - Gas

## Figure 11.25: Business Gas Prices - January to June 2024

| Business gas prices (ex VAT) weighted average across all suppliers   |   c/kWh S1 2024 | Change in 12 months   | Change in 24 months   | Ranking (EU)   | Band Share of Market   |
|----------------------------------------------------------------------|-----------------|-----------------------|-----------------------|----------------|------------------------|
| Band I1 Consumption < 1,000 GJ                                       |            11   | -15%                  | +44%                  | 3              | 12.3%                  |
| Band I2 1,000 GJ < Consumption < 10,000 GJ                           |             7.9 | -19%                  | +7%                   | 9              | 20.3%                  |
| Band I3 10,000 GJ < Consumption < 100,000 GJ                         |             6.5 | -16%                  | -4%                   | 9              | 23.5%                  |
| Band I4 100,000 GJ < Consumption < 1,000,000 GJ                      |             5.1 | -20%                  | -6%                   | 10             | 40.6%                  |
| Band I5 1,000,000 GJ < Consumption < 4,000,000 GJ                    |             2.9 | -47%                  | -60%                  | 17             | 3.4%                   |
| Weighted Average                                                     |             6.6 | -18%                  | +1%                   |                |                        |

## Appendix 10: Energy in Ireland data and charts

The data and charts used in the preparation of this report, including timeseries data back to 1990, are available in spreadsheet format on the SEAI website: https://www.seai.ie/data-and-insights/seai-statistics/key-publications/energy-in-ireland

Complete versions of the National Energy Balance for 1990 to 2023 are published on the SEAI website: https://www.seai.ie/data-and-insights/seai-statistics/key-publications/national-energy-balance

Condensed versions of the 2023 National Energy Balance are provided in Table A10.1, in TWh, and Table A10.2, in ktoe.

## Table A10.1: Short energy balance 2023 (TWh)

| Energy [TWh]                                                   | Coal   | Peat   | Oil        | Natural Gas   | Renewables   | Non-Renew. Waste   | Electricity   | Total      |
|----------------------------------------------------------------|--------|--------|------------|---------------|--------------|--------------------|---------------|------------|
| Indigenous Production                                          | -      | 1.49   | -          | 10.87         | 20.26        | 1.96               | -             | 34.57      |
| Imports                                                        | 4.77   | -      | 99.63      | 37.39         | 3.04         | -                  | 3.72          | 148.55     |
| Exports                                                        | 0.39   | 0.00   | 15.85      | -             | 0.19         | -                  | 0.45          | 16.89      |
| Mar. Bunkers                                                   | -      | -      | 1.55       | -             | -            | -                  | -             | 1.55       |
| Stock Change                                                   | 0.70   | 0.61   | 0.42       | -             | -0.06        | -                  | -             | 1.67       |
| Primary Energy Supply (incl. non-energy)                       | 5.08   | 2.10   | 82.65      | 48.26         | 23.04        | 1.96               | 3.28          | 166.36     |
| Primary Energy Requirement (excl. non-energy)                  | 5.08   | 2.10   | 80.07      | 48.26         | 23.04        | 1.96               | 3.28          | 163.79     |
| Transformation Input                                           | 3.66   | 0.56   | 34.35      | 28.41         | 2.45         | 1.09               | 0.55          | 71.07      |
| Public Thermal Power Plants                                    | 3.66   | 0.39   | 0.65       | 25.38         | 2.27         | 1.09               | -             | 33.43      |
| Combined Heat and Power Plants                                 | -      | 0.03   | 0.01       | 2.78          | 0.18         | -                  | -             | 2.99       |
| Pumped Storage Consumption                                     | -      | -      | -          | -             | -            | -                  | 0.47          | 0.47       |
| Briquetting Plants                                             | -      | 0.14   | -          | -             | -            | -                  | -             | 0.14       |
| Oil Refineries & other energy sector                           | -      | -      | 33.70      | 0.26          | -            | -                  | 0.08          | 34.03      |
| Transformation Output                                          | -      | 0.14   | 34.66      | -             | -            | -                  | 18.40         | 53.20      |
| Public Thermal Power Plants                                    | -      | -      | -          | -             | -            | -                  | 16.19         | 16.19      |
| Combined Heat and Power Plants                                 | -      | -      | -          | -             | -            | -                  | 1.91          | 1.91       |
| Pumped Storage Generation                                      | -      | -      | -          | -             | -            | -                  | 0.30          | 0.30       |
| Briquetting Plants                                             | -      | 0.14   | -          | -             | -            | -                  | -             | 0.14       |
| Oil Refineries                                                 | -      | -      | 34.66      | -             | -            | -                  | -             | 34.66      |
| Exchanges and transfers                                        | 0.22   | -      | -0.76      | 0.06          | -13.32       | -                  | 13.26         | -0.54      |
| Electricity                                                    | -      | -      | -          | -             | -13.26       | -                  | 13.26         | -          |
| Heat                                                           | - 0.22 | -      | -          | -             | -            | -                  | -             | - -0.54    |
| Other Own Use and Distribution Losses                          | -      | - 0.04 | -0.76 1.25 | 0.06 0.62     | -0.06 -      | - -                | - 3.16        | 5.08       |
| Available Final Energy Consumption                             | 1.64   | 1.63   | 80.94      | 19.29         | 7.28         | 0.87               | 31.23         | 142.88     |
| Non-Energy Consumption                                         | -      | -      | 2.57       | -             | -            | -                  | -             | 2.57       |
| Final Non-Energy Consumption                                   | -      | -      | 2.57       | -             | -            | -                  | -             | 2.57       |
| Total Final Energy Consumption                                 | 1.74   | 1.63   | 78.29      | 19.30         | 7.37         | 0.87               | 31.57         | 140.77     |
| Industry                                                       | 0.61   | -      | 3.91       | 9.92          | 1.99         | 0.87               | 6.71          | 24.01      |
| Non-Energy Mining                                              | -      | -      | 0.08       | -             | -            | -                  | 0.28          | 0.37       |
| Food, Beverages and Tobacco                                    | -      | -      | 0.95       | 3.24          | 0.13         | -                  | 1.11          | 5.42       |
| Textiles and Textile Products                                  | -      | -      | 0.07       | 0.12          | -            | -                  | 0.04          | 0.24       |
| Wood and Wood Products                                         | -      | -      | 0.03       | 0.06          | 1.18         | -                  | 0.28          | 1.55       |
| Pulp, Paper, Publishing and Printing                           | -      | -      | 0.01       | 0.06          | -            | -                  | 0.08          | 0.16       |
| Chemicals and Man-Made Fibres                                  | -      | -      | 0.11       | 1.26          | 0.00         | -                  | 0.96          | 2.33       |
| Rubber and Plastic Products                                    | -      | -      | 0.04       | 0.06          | -            | - 0.87             | 0.23          | 0.33       |
| Other Non-Metallic Mineral Products                            | 0.61   | -      | 1.74       | 0.24          | 0.69 -       | -                  | 0.76 0.70     | 4.91       |
| Basic Metals and Fabricated Metal Products                     | -      | -      | 0.05 0.04  | 4.11 0.07     | -            | -                  | 0.15          | 4.87 0.27  |
| Machinery and Equipment n.e.c Electrical and Optical Equipment | -      | -      |            |               | -            | -                  | 1.34          | 1.62       |
|                                                                | -      | -      | 0.04       | 0.25          |              |                    | 0.03          | 0.05       |
| Transport Equipment Manufacture                                | -      | -      | 0.02       | 0.01          | - -          | - -                | 0.60          | 1.15       |
| Other Manufacturing                                            | -      | -      | 0.15       | 0.40          |              |                    |               |            |
| Construction                                                   | -      | -      | 0.58       | 0.04          | -            | -                  | 0.13          | 0.76       |
| Transport                                                      | -      | -      | 57.12      | 0.18          | 3.51         | -                  | 0.33          | 61.14      |
| Road Freight                                                   | -      | -      | 8.52       | 0.01          | 0.79         | -                  | -             | 9.32       |
| Light Goods Vehicle                                            | - -    | -      | 3.18       | -             | 0.30         | -                  | 0.01          | 3.49       |
| Road Private Car                                               |        | -      | 22.42      | -             | 1.71         | -                  | 0.26          | 24.40      |
| Public Passenger Services Rail                                 | -      | - -    | 1.39 0.47  | - -           | 0.12 -       | - -                | 0.01          | 1.52       |
|                                                                | -      |        |            |               |              |                    | 0.05          | 0.52       |
| Domestic Aviation                                              | -      | -      | 0.09       | -             | -            | -                  | -             | 0.09       |
| International Aviation                                         | - -    | -      | 13.28      | -             | -            | -                  | -             | 13.28      |
| Fuel Tourism                                                   |        | -      | 1.87       | -             | 0.17         | -                  | -             | 2.05       |
| Navigation                                                     | - -    | -      | 1.08       | -             | -            | -                  | -             | 1.08 5.41  |
| Unspecified                                                    |        | -      | 4.82       | 0.17          | 0.41         | -                  | -             |            |
| Residential                                                    | 1.12   | 1.63   | 12.12      | 5.41          | 1.29         | -                  | 8.08          | 29.64      |
| Commercial/Public Services                                     | 0.00   | -      | 2.26       | 3.80          | 0.58         | -                  | 15.94         | 22.58      |
| Commercial Services                                            | 0.00   | -      | 1.06       | 2.02          | 0.41         | -                  | 13.02         | 16.51 6.07 |
| Public Services                                                | -      | -      | 1.20       | 1.78          | 0.17 -       | - -                | 2.92          | 3.16       |
| Agricultural                                                   | -      | -      | 2.64       | -             |              |                    | 0.52          | 0.23       |
| Fisheries                                                      | -      | -      | 0.23       | -             | -            | -                  | -             |            |
| Statistical Difference                                         | -0.10  | 0.00   | 0.08       | -0.01         | -0.10        | -                  | -0.34         | -0.46      |

## Table A10.211.1: Short energy balance 2023 (ktoe)

| Energy [ktoe]                                                                  | Coal   | Peat   | Oil   | Natural Gas   | Renewables   | Non-Renew. Waste   | Electricity   | Total   |
|--------------------------------------------------------------------------------|--------|--------|-------|---------------|--------------|--------------------|---------------|---------|
| Indigenous Production                                                          | -      | 128    | -     | 935           | 1742         | 168                | -             | 2973    |
| Imports                                                                        | 410    | -      | 8566  | 3215          | 261          | -                  | 320           | 12773   |
| Exports                                                                        | 34     | 0      | 1363  | -             | 16           | -                  | 38            | 1452    |
| Mar. Bunkers                                                                   | -      | -      | 133   | -             | -            | -                  | -             | 133     |
| Stock Change                                                                   | 60     | 53     | 36    | -             | -5           | -                  | -             | 144     |
| Primary Energy Supply (incl. non-energy)                                       | 437    | 180    | 7106  | 4150          | 1981         | 168                | 282           | 14304   |
| Primary Energy Requirement (excl. non-energy)                                  | 437    | 180    | 6885  | 4150          | 1981         | 168                | 282           | 14083   |
| Transformation Input                                                           | 315    | 48     | 2953  | 2443          | 210          | 94                 | 47            | 6111    |
| Public Thermal Power Plants                                                    | 315    | 34     | 55    | 2182          | 195          | 94                 | -             | 2875    |
| Combined Heat and Power Plants                                                 | -      | 2      | 1     | 239           | 15           | -                  | -             | 257     |
| Pumped Storage Consumption                                                     | -      | -      | -     | -             | -            | -                  | 41            | 41      |
| Briquetting Plants                                                             | -      | 12     | -     | -             | -            | -                  | -             | 12      |
| Oil Refineries & other energy sector                                           | -      | -      | 2897  | 22            | -            | -                  | 7             | 2926    |
| Transformation Output                                                          | -      | 12     | 2980  | -             | -            | -                  | 1582          | 4575    |
| Public Thermal Power Plants                                                    | -      | -      | -     | -             | -            | -                  | 1392          | 1392    |
| Combined Heat and Power Plants                                                 | -      | -      | -     | -             | -            | -                  | 164           | 164     |
| Pumped Storage Generation                                                      | -      | -      | -     | -             | -            | -                  | 26            | 26      |
| Briquetting Plants                                                             | -      | 12     | -     | -             | -            | -                  | -             | 12      |
| Oil Refineries                                                                 | -      | -      | 2980  | -             | -            | -                  | -             | 2980    |
| Exchanges and transfers                                                        | 19     | -      | -66   | 5             | -1145        | -                  | 1140          | -47     |
| Electricity                                                                    | -      | -      | -     | -             | -1140        | -                  | 1140          | -       |
| Heat Other                                                                     | - 19   | - -    | - -66 | - 5           | - -5         | - -                | - -           | - -47   |
| Own Use and Distribution Losses                                                | -      | 4      | 108   | 53            | -            | -                  | 272           | 436     |
| Available Final Energy Consumption                                             | 141    | 140    | 6960  | 1659          | 626          | 75                 | 2685          | 12285   |
| Non-Energy Consumption                                                         | -      | -      | 221   | -             | -            | -                  | -             | 221     |
| Final Non-Energy Consumption                                                   | -      | -      | 221   | -             | -            | -                  | -             | 221     |
| Total Final Energy Consumption                                                 | 149    | 140    | 6732  | 1660          | 634          | 75                 | 2715          | 12104   |
| Industry                                                                       | 52     | -      | 337   | 853           | 171          | 75                 | 577           | 2065    |
| Non-Energy Mining                                                              | -      | -      | 7     | -             | -            | -                  | 24            | 32      |
| Food, Beverages and Tobacco                                                    | -      | -      | 82    | 278           | 11           | -                  | 95            | 466     |
| Textiles and Textile Products                                                  | -      | -      | 6     | 11            | -            | -                  | 4             | 20      |
| Wood and Wood Products                                                         | -      | -      | 2     | 5             | 102          | -                  | 24            | 134     |
| Pulp, Paper, Publishing and Printing                                           | -      | -      | 1     | 5             | -            | -                  | 7             | 14      |
| Chemicals and Man-Made Fibres                                                  | -      | -      | 10    | 108           | 0            | -                  | 83            | 201     |
| Rubber and Plastic Products                                                    | -      | -      | 3     | 5             | -            | -                  | 20            | 28      |
| Other Non-Metallic Mineral Products Basic Metals and Fabricated Metal Products | 52 -   | - -    | 149 5 | 21 354        | 59 -         | 75 -               | 65 60         | 422 419 |
| Machinery and Equipment n.e.c                                                  | -      | -      | 4     | 6             | -            | -                  | 13            | 23      |
| Electrical and Optical Equipment                                               | -      | -      | 3     | 21            | -            | -                  | 115           | 139     |
| Transport Equipment Manufacture                                                | -      | -      | 1     | 1             | -            | -                  | 2             | 4       |
| Other Manufacturing                                                            | -      | -      | 13    | 34            | -            | -                  | 52            | 99      |
|                                                                                |        | -      |       |               | -            |                    | 11            | 65      |
| Construction Transport                                                         | - -    | -      | 50    | 4             | 302          | - -                | 28            |         |
|                                                                                |        |        | 4912  | 15            |              |                    |               | 5257    |
| Road Freight                                                                   | -      | -      | 733   | 0             | 68           | -                  | -             | 802     |
| Light Goods Vehicle Road Private Car                                           | - -    | -      | 274   | -             | 25           | -                  | 1             | 300     |
|                                                                                | -      | -      | 1928  | -             | 147          | -                  | 23            | 2098    |
| Public Passenger Services                                                      | -      | -      | 119   | -             | 11 -         | - -                | 1             | 130     |
| Rail                                                                           |        | -      | 40    | -             |              |                    | 4             | 45      |
| Domestic Aviation                                                              | -      | -      | 8     | -             | -            | -                  | -             | 8       |
| International Aviation                                                         | - -    | -      | 1142  | -             | -            | -                  | -             | 1142    |
| Fuel Tourism                                                                   |        | -      | 161   | -             | 15           | -                  | -             | 176     |
| Navigation                                                                     | - -    | -      | 92    | -             | -            | -                  | -             | 92      |
| Unspecified                                                                    |        | -      | 415   | 15            | 35           | -                  | -             | 465     |
|                                                                                | 97     | 140    | 1042  | 465           | 111          | -                  |               | 2549    |
| Residential Commercial/Public Services                                         | 0      | -      | 194   | 326           | 50           | -                  | 695 1370      | 1941    |
| Commercial Services                                                            | 0      | -      | 91    | 174           | 35           | -                  | 1119          | 1420    |
| Public Services                                                                | -      | -      | 103   | 153           | 15           | -                  | 251           | 522 272 |
| Agricultural                                                                   | -      | -      | 227   | -             | -            | -                  | 44            |         |
| Fisheries                                                                      | -      | -      | 20    | -             | -            | -                  | -             | 20      |
| Statistical Difference                                                         | -8     | 0      | 7     | -1            | -8           | -                  | -29           | -40     |

## Appendix 11: Version control

|   Version | Date       | Notes                               |
|-----------|------------|-------------------------------------|
|      0.9  | 10/12/2024 | Pre-release embargoed version       |
|      0.99 | 10/12/2024 | Pre-release with formatting changes |
|      1    | 11/12/2024 | Publication                         |

<!-- image -->

## Sustainable Energy Authority of Ireland

Three Park Place Hatch Street Upper Dublin 2 Ireland D02 FX65

e

info@seai.ie

w  www.seai.ie

t

+353 1 808 2100

<!-- image -->

<!-- image -->