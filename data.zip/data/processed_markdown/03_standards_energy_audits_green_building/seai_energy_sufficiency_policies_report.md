---
document_id: seai_sufficiency_policies_2024
title: "Public Support for Energy Sufficiency Policies"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2024
original_file: "seai_energy_sufficiency_policies_report.pdf"
tables_detected: 95
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Public support for energy sufficiency policies in Ireland

<!-- image -->

## Public support for energy sufficiency policies in Ireland

Results from a nationally representative survey experiment

September 2026

## Report prepared by:

Ciarán Lavin, Senior Behavioural Scientist -

Hannah Julienne, Programme Manager   Behavioural Economics

## Sustainable Energy Authority of Ireland

SEAI is Ireland's national energy authority investing in, and delivering, appropriate, effective and sustainable solutions to help Ireland's transition to a clean energy future. We work with the public, businesses, communities and the Government to achieve this, through expertise, funding, educational programmes, policy advice, research and the development of new technologies.

SEAI is funded by the Government of Ireland through the Department of Climate, Energy and the Environment.

© Sustainable Energy Authority of Ireland

Reproduction of the contents is permissible provided the source is acknowledged.

## Contents

| Executive summary ............................................................................................................... 2                                          | Executive summary ............................................................................................................... 2                                          |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Introduction ............................................................................................................................................................. 2 | Introduction ............................................................................................................................................................. 2 |
| Main findings ........................................................................................................................................................... 3  | Main findings ........................................................................................................................................................... 3  |
| Conclusion................................................................................................................................................................ 4 | Conclusion................................................................................................................................................................ 4 |
| 1. Introduction........................................................................................................................ 6                                    | 1. Introduction........................................................................................................................ 6                                    |
| 1.1.                                                                                                                                                                         | Background ................................................................................................................................................ 6                |
| 1.2.                                                                                                                                                                         | Energy policy in Ireland - where sufficiency fits in ............................................................................... 7                                       |
| 1.3.                                                                                                                                                                         | Existing research on policy support...................................................................................................... 10                                 |
| 1.4.                                                                                                                                                                         | Study aims and research questions...................................................................................................... 12                                   |
| 2.                                                                                                                                                                           | Methods..................................................................................................................... 14                                              |
| 2.1.                                                                                                                                                                         | Sampling and data collection................................................................................................................. 14                             |
| 2.2.                                                                                                                                                                         | Study design............................................................................................................................................. 14                 |
| 2.3.                                                                                                                                                                         | Analysis ..................................................................................................................................................... 16            |
| 3.                                                                                                                                                                           | Results........................................................................................................................ 17                                           |
| 3.1.                                                                                                                                                                         | Participant characteristics ...................................................................................................................... 17                        |
| 3.2.                                                                                                                                                                         | Overall results.......................................................................................................................................... 18                 |
| 3.3.                                                                                                                                                                         | Results by individual policy .................................................................................................................... 22                         |
| 4.                                                                                                                                                                           | Discussion.................................................................................................................. 40                                              |
| 4.1.                                                                                                                                                                         | Strong and broad support for sufficiency policies.............................................................................. 40                                           |
| 4.2.                                                                                                                                                                         | Perceived policy fairness is most important but not always predictable ........................................ 41                                                           |
| 4.3.                                                                                                                                                                         | Support is sometimes boosted by highlighting policy co-benefits...................................................41                                                         |
| 4.4.                                                                                                                                                                         | Alignment of current policy with public opinion is mixed ................................................................. 41                                                |
| 4.5.                                                                                                                                                                         | People consistently underestimate support for policies ................................................................... 42                                                |
| 4.6.                                                                                                                                                                         | Conclusion................................................................................................................................................ 43                |
| Appendix............................................................................................................................... 44                                   | Appendix............................................................................................................................... 44                                   |
| Appendix 1: Sample characteristics.................................................................................................................... 44                    | Appendix 1: Sample characteristics.................................................................................................................... 44                    |
| Appendix 2: Fairness and effectiveness ratings of policies............................................................................. 46                                   | Appendix 2: Fairness and effectiveness ratings of policies............................................................................. 46                                   |
| Appendix 3: Regression modelling results ........................................................................................................ 48                         | Appendix 3: Regression modelling results ........................................................................................................ 48                         |

## Executive summary

## Introduction

In addition to setting its own carbon budgets, Ireland is obligated to contribute to EU targets to reduce greenhouse gas emissions and energy consumption, and to increase the share of renewable energy. However, even with full implementation of the Climate Action Plan (CAP) by 2030, Ireland is projected to fall significantly short on these obligations. To achieve what's required means adding policies that bring the ambition beyond both efficiency and an expansion of renewable energy supply, to focus on reducing energy consumption in the first place. Energy sufficiency provides a framework for achieving this by meeting personal and societal energy needs while significantly reducing material and energy consumption. However, we know little about how people in Ireland view energy sufficiency-type policies and what factors might be important to public support.

This report describes the results of an online survey experiment run in October 2025 that measured support and opinions about 16 energy sufficiency policies among a large and representative sample (N=2,400) of people in Ireland. Policies were chosen to cover a range of energy sectors (transport, built environment, and electricity), and to vary in their restrictiveness. 1  Each participant responded to six policies, resulting in approximately 900 responses for each policy and was randomly assigned to one of three groups. Each group was shown a different rationale for the policies: one group were told about energy demand reduction outcomes, another about co-benefits for quality-of-life (e.g. health, housing, cost-of-living), and a third about both. For half of the policies each participant saw, we also included an example of where a similar policy had been implemented elsewhere, to see if this made a difference to support.

## What is energy sufficiency?

Energy sufficiency is an approach to energy policy that aims to reduce overall energy demand by shaping consumption patterns and lifestyles to remain within environmental limits while ensuring a good quality of life for all. It is often contrasted with the more familiar concept of energy efficiency. While an efficiency approach aims to achieve the same outcome using less energy (e.g. enabling people to switch from a petrol or diesel car to an EV), a sufficiency approach seeks to reduce the need for energy use in the first place (e.g. facilitating active travel or ensuring services are close to people so they have less need to travel). The overarching idea is to use just enough energy and materials to meet individual and societal needs.

1 The set of policies was selected to achieve a balance of policy type, sector, restrictiveness and likely popularity, in order to build a comprehensive picture of the types of measures that the public support or oppose. The inclusion of a given policy in this study should not necessarily be taken as an endorsement by SEAI.

## Main findings

## Strong and broad support for sufficiency policies

All but two of the 16 energy sufficiency policies presented were majority supported (see Figure 1). Sociodemographic differences in responses were sparse, other than the oldest age group (aged 65+) showing higher support for policies on average. Where sociodemographic differences were found, it was usually for policies with direct relevance to the subgroup in question. Importantly, while respondents in the centre and on the right (politically) were less supportive overall than those on the left, there was strong support for most policies across the political spectrum, and supporters of current government parties were no less supportive than everyone else, suggesting that fears of voter punishment for implementing these types of policies would not be supported by evidence.

Figure 1. Summary of support ratings for each of the 16 policies presented to participants in the study. The figure is ordered by the proportion of ratings of 7 given to each. Labels for proportions of 3% and below have been omitted for clarity.

Would you oppose or support having this policy in Ireland?

1 Fully Oppose

2

3

4

5

6

7 Fully Support

100%

<!-- image -->

## People consistently underestimate support for policies

The average difference between the proportion of people who supported a policy and the proportion who believed that most people would support it was 25 percentage points. Actual support exceeded perceived majority-support for every policy examined, and by a substantial margin in most cases. In other words, despite widespread support for energy sufficiency policies, many people underestimate their popularity   This finding is consistent with previous studies showing that support for climate . action is underestimated, including by academics and politicians. As a result, policy action may not currently be considered or implemented due to a misperception of the public's willingness to accept energy sufficiency policies. These findings suggest there is greater scope for more political ambition in this area than is commonly assumed.

## Perceived policy fairness is the most important predictor of support

Sufficiency policies are designed to tackle higher consumption and consider issues of equity and fairness, which research to date has shown is the most important factor in predicting public support for climate policies. We repeat this finding in the present study: how fair someone thought a policy to be was the factor that best predicted their level of support for that policy, even more so than how effective they thought it would be. Further research is required to determine what types of fairness (e.g. distributional, procedural) are most important to support.

## Support is sometimes boosted by highlighting co-benefits

Participants who did not think climate change should be a high or very high priority for government (41% of those surveyed) supported energy sufficiency policies less on average than the remaining 59% who did. For this low-medium climate priority group, support tended to be somewhat higher when the rationale they were given for a policy was focused on its quality-of-life co-benefits rather than on energy demand reduction. Interestingly, however, no increase in support was seen when the rationale mentioned both energy demand reduction and co-benefits. This suggests it is the lack of energy or climate language that boosted support for this particular group. Providing examples of where policies had been implemented elsewhere was associated with a small increase in support on average but made no meaningful difference in most cases.

## Conclusion

If Ireland is to meet its emissions and energy demand reduction obligations, SEAI National Energy Projections show that sufficiency-oriented policies that reduce or avoid the need for energy use are a wholly necessary part of the policy package. This research demonstrates that the Irish public supports the introduction of many such policies. More generally, this study adds to the growing literature showing strong public support for climate policies, that is nevertheless systematically underestimated by the public and politicians alike. This underestimation of support likely limits the perceived scope for climate action amongst decision makers and there is a risk that we are curtailing required climate action partly due to a false belief that demand reduction policies would be met with public resistance. While some types of policies are naturally less popular than others, overall support levels in this study were high and remarkably consistent across individuals with varying backgrounds, characteristics, and political affiliations. A clear message that emerges is that consideration of equity and fairness in policy design is crucial to maximise public support. Careful targeting of supports and policies is part of this.

## Policy recommendations

- 1. There is room for more political ambition in the energy sufficiency policy space. This study uncovered broad support for a large range of energy sufficiency policies and measures. Importantly, support for these policies is strong across the political spectrum.
- 2. Avoid making assumptions about public support for climate policy. Without robust empirical evidence, public support risks being underestimated, potentially limiting political ambition and preventing the implementation of impactful policies. This study contributes to this evidence gap, but further research should be conducted on potentially impactful policies.
- 3. Keep fairness considerations at the heart of policy development. Perceptions of fairness are by far the most important factor in public support for energy sufficiency (and other) policies. Fair, equitable policies are generally the most effective and accepted by society where they directly tackle excessive rates of consumption.
- 4. Consider focusing communications on co-benefits of sufficiency policies rather than on energy demand reduction. living) can sometimes boost support, particularly among those for whom climate is not a high
- Policy rationales focused on quality-of-life co-benefits (e.g. for health, housing, and cost-ofpriority. However, where possible, communications should be pre-tested as it is not always predictable what will boost support for a given policy.
- 5. Highlight the broad public support for climate policy and facilitate national debate. Despite widespread support for energy demand reduction policies, most people do not think they would be popular. People appear to have a poor grasp of the opinion of others and may benefit from more fora through which to share their views.

## 1. Introduction

## 1.1. Background

In addition to setting its own carbon budgets, Ireland is obligated to contribute to EU targets to reduce greenhouse gases, energy consumption, and increase the share of renewable energy. Even in the unlikely event of full implementation of the Climate Action Plan (CAP) by 2030, Ireland is projected to fall significantly short on these obligations. 2,3  As things are, we are unlikely to meet the 2030 final energy consumption obligation even by 2040, a point at which steeper reductions will be required.

This has large economic consequences 4  in addition to the more existential climate ones. Global heating is happening much faster than expected, and the required rate of progress towards targets will only grow. To bridge the gap to 2030 targets with established efficiency measures and renewables- or technology-focused policy would require unprecedented acceleration that, according to the SEAI National Energy Projections, is no longer feasible in such a short timeframe. The need for additional ambitious policies that reduce demand for energy is clear from Ireland's current trajectory . A pertinent question therefore is what types of energy demand reduction policies the public are more likely to support. The CAP emphasises the importance of both political and public acceptance of required policies, 'which in some ca ses require a fundamental level of individual and societal behaviour change.' 5

Energy sufficiency is an approach to energy policy that aims to reduce overall energy demand by shaping consumption patterns and lifestyles to remain within environmental limits while ensuring a good quality of life for all. Sufficiency is sometimes categorised into four types of action or change: 1) absolute consumption reduction; 2) modal shift; 3) product longevity; and 4) sharing practices. 6 Typically, these actions reduce energy used, as well as the need for material resources. For example, in the transport sector, energy sufficiency policy would include infrastructure investment that supports shifts from private car use to public or active travel, or urban planning that ensures services are close to people, reducing the distances they need to travel in the first place. In contrast, increasing EV uptake, while necessary, is not considered an energy sufficiency policy from this perspective, but rather an efficiency one. Discussions of sufficiency are rooted in equity, fairness, restraint, and ecological responsibility, and try to target excessive levels of consumption first.

While we have some sufficiency-oriented policies in Ireland (primarily in the transport sector), there is scope for much broader implementation of sufficiency principles to reduce energy demand and related emissions. However, we know little about how people in Ireland view this type of policy. While sufficiency policies often have equity baked in by design, and perceived fairness is the strongest predictor of support of policies more generally, they are often about doing or having less of something

2 SEAI (2025). National Energy Projections. https://www.seai.ie/data-and-insights/seai-statistics/key-publications/national-energyprojections

3 Environmental Protection Agency (EPA) (2026). Ireland's Greenhouse Gas Emissions Projections 2025-2030. https://www.epa.ie/publications/monitoring--assessment/climate-change/air-emissions/irelands-greenhouse-gas-emissionsprojections-2025-2030.php

4 IFAC and CCAC (2025) , 'A colossal missed opportunity: Ireland's climate action and the potential costs of missing targets'. https://www.fiscalcouncil.ie/wpcontent/uploads/2025/03/Irelands-climate-action-and-the-potential-costs-of-missing-targets.pdf

5 Department of Climate, Energy and the Environment (2024). Climate Action Plan 2024. http://www.gov.ie/en/department-ofclimate-energy-and-the-environment/publications/climate-action-plan-2024/

6 Sandberg, M. (2021). Sufficiency transitions: A review of consumption changes for environmental sustainability. Journal of Cleaner Production , 293 , 126097. 10.1016/j.jclepro.2021.126097

(at least amongst wealthier groups), which may be off-putting to some. Previous research (outlined below) suggests that actual support may outstrip perceived support, i.e. people (and policymakers) underestimate public support for general climate action. But perceptions of energy sufficiency policies specifically are not well studied. And while existing research points to reliable intrinsic aspects of climate policies that affect support (e.g. fairness and effectiveness), it has less to say about extrinsic factors (e.g. the rationale provided to people for implementing a policy).

To address these gaps, we ran a study with a large representative sample of people in Ireland to measure support for energy sufficiency policies given different policy rationales, as well as what people perceived this level of support to be.

## 1.2. Energy policy in Ireland -where sufficiency fits in

In this study, we asked participants about a range of different hypothetical (but plausible) energy sufficiency policies covering various sectors and including variety in terms of policy restrictiveness and severity. To produce a list of such policies, we surveyed the existing policy landscape from a sufficiency perspective. 7  We organise this section by sector -transport, built environment and electricity -but sufficiency policies are often difficult to categorise neatly. They are sometimes implemented in one sector but have a main impact in another (e.g. a common goal of spatial planning of the built environment is to minimise transport needs).

## 1.2.1. Transport

The primary targets (unchanged in the Climate Action Plan (CAP) from 2024 to 2025) for transport policy in Ireland are a 20% reduction in vehicle kilometre (km) travelled and a 50% reduction in fuel used, alongside electrification and modal shift. These targets, as well as the avoid-shift-improve hierarchical principle used to organise the transport sections in CAP, are sufficiency-oriented, and CAP 2024 lists 13 recommendations from the Climate Change Advisory Council (CCAC), many of which align with sufficiency principles. 8

Major public transport projects are ongoing in all five cities, and the CAP describes a multi-pronged active travel infrastructure plan, entailing cycling networks in each county, and expanding the range of electric bikes available, aiming to provide viable alternatives to private car use. The CAP includes ambitious commitments including ' for 70% of people in rural Ireland to have access to public transport services that provide at least three return trips to the closest large town , but current levels of urban ' sprawl and rural housing make it difficult to meet transport needs through active and public transport provisions. One of CCAC's recommendations is that housing and land use policy properly consider proximity between people and the places they go.

Another of CCAC's recommendations calls for 'proven approaches to drive behavioural change' such as congestion charges and car parking restrictions. They also recommend recalibrating motor tax to reflect resource and energy efficiency. Further sufficiency policies for the transport sector can be found in the Odyssee-Mure policy database, 9  including subsidies for electric bikes, building codes that provide for bike charging and storage, information interventions such as vehicle labelling, and the promotion of

7 We have not evaluated current policies in any formal or holistic sense, and the hypothetical policy ideas presented in the study should not be taken as fully formed policies, or necessarily as endorsements. The point is to test the type of policies and policy features that people are more supportive of, by including a variety.

8 Department of Climate, Energy and the Environment (2025). Climate Action Plan 2025. http://www.gov.ie/en/department-of-

climate-energy-and-the-environment/publications/climate-action-plan-2025/

9 https://www.indicators.odyssee-mure.eu/energy-efficiency-database.html

remote working. Related to the last of these is reduced working hours, e.g. a four-day working week, which was trialled in Ireland in 2022, reducing travel requirements. 10

## Aviation

International aviation is not addressed in CAP because its governance is generally taken to come under more global agreements. However, the Irish Government does have control over impactful policies in this area. For instance, the Government has recently removed a passenger cap at Dublin Airport. Without alternative measures to curb demand, this change could increase emissions by up to 22% by 2031 according to Dublin Airport Authority's planning documents . 11,12

Climate groups including Opportunity Green have proposed implementing air tax such as the UK's Air Passenger Duty or the French Solidarity Tax. 13  But carbon taxes are regressive -burdens are relatively higher for lower income groups -and unpopular. Distributional impacts are important for acceptability and successfully communicating ringfencing of funds to reduce regressivity is difficult. 14  An alternative sufficiency-oriented approach is to directly target excessive consumption. 15  One way to do so is via a frequent flyer tax, wherein, for example, an additional charge is levied for a person's third return flight within a year, and any flights beyond the third. Globally, and in Ireland, a small proportion of (wealthier) people do most of the flying. 16

Another way to reduce aviation is to incentivise alternatives. 17  The UK is the most popular destination from Irish airports. The Sail and Rail scheme offers a combined ticket that links train and ferry travel into a single journey between Ireland and the UK (or France and Spain).

## 1.2.2. Built environment &amp; planning

In CAP, the built environment refers to buildings (residential, public, and commercial), and their associated heat demand. All new buildings from 2025 must meet Nearly Zero Energy Building (NZEB) standards and, from 2030, Zero Energy Building standards. These policies are geared towards building efficiency and renewable technologies. The Building Energy Rating (BER) used to compare the energy performance of buildings is not sensitive to the absolute floor area of a dwelling. A larger home will necessarily use more energy than an equally efficient smaller home, but both will have the same BER, which reflects a lack of sufficiency-oriented thinking.

10 Kelly, O., Schor, J., Fan, W., Bezdenezhnykh, T., Gu, G., &amp; Bridson Hubbard, N. (2022). The Four Day Week: Assessing global trials of reduced work time with no reduction in pay: Evidence from Ireland. University College Dublin.

https://researchrepository.ucd.ie/server/api/core/bitstreams/6caa43f3-5bfc-4789-9c84-842a11ca0dbc/content

11 https://www.businesspost.ie/news/dublin-airport-emissions-will-rise-by-22-if-passenger-cap-is-lifted-daa-said-in-planningsubmissio/

12

EPA (2026).

Ireland's Provisional Greenhouse Gas Emissions 1990

-2025. https://www.epa.ie/publications/monitoring--

assessment/climate-change/air-emissions/EPA-Provisional-GHG-Emissions-1990-2025-web.pdf. If it were counted in national statistics, aviation would currently make up about 6% of Ireland's total GHG emissions. And while international aviation is excluded from carbon budgets and emissions targets, it is included in the final energy consumption target under the Energy Efficiency Directive (EED).

13 These are taxes charged on all flights leaving UK or France airports respectively. They vary according to flight distance and the class of travel. The UK version has separate, higher rates for private jets.

14 Carattini, S., Kallbekken, S., &amp; Orlov, A. (2019). How to win public support for a global carbon tax. Nature 565 , (7739), 289-291. https://www.nature.com/articles/d41586-019-00124-x

15 Fouquet, R., &amp; O'Garra, T. (2022). In pursuit of progressive and effective climate policies: Comparing an air travel carbon tax and a frequent flyer levy. Energy Policy , 171 , 113278. https://doi.org/10.1016/j.enpol.2022.113278

16 Gössling, S., &amp; Humpe, A. (2020). The global scale, distribution and growth of aviation: Implications for climate change. Global Environmental Change , 65 , 102194. https://doi.org/10.1016/j.gloenvcha.2020.102194

17 Opportunity Green. https://opportunitygreen.org/shipping/insights/five-ways-to-improve-rail-and-sail-london-to-dublin/

There are several potential sufficiency-oriented policies that could be considered in this sector: setting standards for living area, 18  regulation to incentivise the prioritisation of high-density buildings, or incentives to downsize home when surplus space is present could all reduce floor space per capita, 19 which in turns reduces heating and materials resource requirement. Floor area per capita in Ireland is amongst the highest in EU countries. 20

Importantly, some policies that are implemented in built environment and spatial planning are amongst the most effective in reducing transport emissions. Reducing the average distance that people need to travel to the places they go is the surest way to reduce transport emissions. It makes private car trips both shorter and less likely to occur. Combatting urban sprawl is noted in CAP as highly important in this regard. Relatedly, the high prevalence of one-off rural housing in Ireland also stands out as a barrier to reducing energy demand for transport. Existing restrictions on these buildings were recently eased, however.

## 1.2.3. Electricity

Sufficiency policy is perhaps least represented in the electricity sector. While there is reference to 'managing demand growth' for electricity in CAP, there is no mention of reducing absolute consumption levels (excessive or otherwise). Demand reduction is not a feature of the National Energy Demand Strategy (NEDS) either, which instead focuses on flexibility. The most prominent aim in the CAP for the sector is to raise the share of demand met by renewable supply from about 40% to 80% by 2030. Given that demand growth has outpaced renewable supply growth every year since 2020, achieving these goals will be difficult without also reducing demand. Looking at where most new demand comes from, an obvious place to start is with limits on new data centres (though at the end of 2025, an effective moratorium on data centre development in the Dublin region since 2021 was lifted, with limited conditions 21 ). CAP doesn't directly address data centre loads, other than to mention exploration of enhanced emissions reporting and strategies to incentivise demand flexibility among large energy users (LEUs), and that SEAI will support LEUs  with developing exemplar energy efficiency ' approaches to new and existing assets .'

The NEDS sets out aims for demand flexibility in the residential sector through increasing the uptake of dynamic and time-of-use electricity tariffs. The European Commission has suggested consumers should have access to another alternative structure, which has yet to be introduced here but is common across the globe: the rising block structure. 22   23  Rising block tariffs offer a certain amount of electricity, approximately enough to meet basic needs of a household at a low price. As consumption increases beyond this, the cost per unit increases. As such, this structure directly targets excessive consumption

18 Bertoldi, P. (2022). Policies for energy conservation and sufficiency: Review of existing policies and recommendations for new and effective policies in OECD countries. Energy and Buildings , 264 , 112075. https://doi.org/10.1016/j.enbuild.2022.112075 19

https://energysufficiency.de/en/additional-information/

20 SEAI (2018). Energy in the Residential Sector. https://www.seai.ie/sites/default/files/publications/Energy-in-the-ResidentialSector-2018-Final.pdf

21 CRU (2025). Large Energy Users Connection Policy. https://www.cru.ie/about-us/news/the-cru-publishes-its-decision-on-newelectricity-connection-policy-for-data-centres/

22 European Commission (2023). Proposal for a REGULATION of the EUROPEAN PARLIAMENT and of the COUNCIL Amending Regulations (EU) 2019; EC (2023). Commission Staff Working Document -Reform of Electricity Market Design.

23 Pollitt, M. G., von der Fehr, N. H. M., Willems, B., Banet, C., Le Coq, C., &amp; Chyong, C. K. (2024). Recommendations for a futureproof electricity market design in Europe in light of the 2021-23 energy crisis. Energy policy, 188, 114051. https://doi.org/10.1016/j.enpol.2024.114051

while increasing affordability, in line with sufficiency principles. 24  This structure can also be made timevariant to encourage demand flexibility.

Softer sufficiency-oriented policy to reduce electricity consumption in homes and businesses through information and awareness campaigns have been implemented. 25  But consideration of the public built environment is perhaps missing. Unnecessary public lighting, including lit advertisement billboards (which also serves to promote purchase of high-consumption products via commercial messaging), alongside decorative building lighting, empty-office lighting, and excessive illumination in public spaces is one potential avenue in this regard. 26

## 1.3. Existing research on policy support

In this section we briefly describe relevant social and psychological research on policy support and highlight where there are important evidence gaps. After describing research on overall levels of climate action or policy support, we discuss relevant findings about factors that influence support. We then outline evidence on perception gaps (differences between actual and perceived support) and end the section by outlining the research questions we address in the remainder of the report.

## 1.3.1. Climate policy support

Worldwide, there is generally high public support for climate action. For example, in a survey spanning 125 countries, 69% of participants reported willingness to give 1% of their income to fight climate change. In Ireland, more than 85% of people think both government and citizens should be doing more to address the issue. 27  Scepticism about the reality of climate change is rare and usually overestimated by the public and researchers, though scepticism about some specific measures to tackle climate change can be more common . 28  There are, however, fewer studies than one might expect that investigate which specific policies the public support. 29  Some reliable findings are that people prefer enabling or 'pull' policies (e.g. additional infrastructure) 30  over restrictive or 'push' policies (e.g. carbon taxes). 31 Research in other European countries has shown majority acceptance of limits on land use, car-free days, reduced working hours, and progressive energy tariffs, but less for restrictions on cars 32 or certain types of home (detached single family homes), and annual fees for dwellings with excessive living space. 33

24 UK Energy Research Centre (2026). Rising Block Tariffs: A Progressive Social Tariff or Damaging to Vulnerable Consumers? https://ukerc.ac.uk/publications/rising-block-tariffs-a-progressive-social-tariff-or-heavily-damaging-to-vulnerable-consumers/

25 https://www.gov.ie/en/department-of-climate-energy-and-the-environment/campaigns/reduce-your-use/

26 In 2007, the city of São Paulo, Brazil removed over 15,000 billboards in a bid to reduce 'visual pollution'. Grenoble, France banned commercial street advertising in 2014, replacing billboards with trees; and some US states do not allow highway billboards.

27 O'Mahony, D., Quinlan, C., Cotter, D., Rochford, M. F., Leiserowitz, A. Regan, A. Carman, J., and Rosenthal, S. (2024). Clima te Change in the Irish Mind: Wave 2, Report 1. https://www.epa.ie/publications/monitoring--assessment/climate-change/climatechange-in-the-irish-mind-wave-2-report-1.php

28 Fairbrother, M. (2022). Public opinion about climate policies: A review and call for more studies of what people want. PLOS Climate , 1(5), e0000030. https://doi.org/10.1371/journal.pclm.0000030

29 Poortinga, W. (2025). The role of policy appraisals and second-order beliefs in public support for climate policies in the UK. Climate Policy , 1 -15. https://doi.org/10.1080/14693062.2025.2539977

30 Drews, S., &amp; Van Den Bergh, J. C. J. M. (2016). What explains public support for climate policies? A review of empirical and experimental studies. Climate Policy , 16 (7), 855 -876. https://doi.org/10.1080/14693062.2015.1058240

31 Umit, R., &amp; Schaffer, L. M. (2020). Attitudes towards carbon taxes across Europe: The role of perceived uncertainty and selfinterest. Energy Policy , 140 , 111385. https://doi.org/10.1016/j.enpol.2020.111385

32 Jenny, A., Müller, U., Skelton, R., &amp; Mastai, N. (2024). Policies for sufficiency: Factors influencing acceptance in the Swiss population. Sustainability: Science, Practice and Policy , 20 (1), 2420415. https://doi.org/10.1080/15487733.2024.2420415

Alexander-Haw, A., Dütschke, E., Janßen, H., Schleich, J., Tröger, J., &amp; Tschaut, M. (2024). Report on long term effects of

33 sufficiency lifestyles and governance approaches for diffusion. FULFILL Deliverable D , 3 .

## 1.3.2. Factors influencing support for climate policy

Perceptions of fairness are reliably the strongest predictor of support for climate policies. 34 Unsurprisingly, perceived effectiveness is also important. These intrinsic features of policies are relatively well studied compared to more extrinsic aspects such as how policies are presented and communicated, including the rationale presented for a given policy.  35

Other studies have shown that language used to describe policy matters. Reactions to sufficiencyrelated concepts can be negative when the term ' degrowth ' is used , 36 and degrowth-type framing doesn't increase support for specific climate policies. 37 But, while co-benefits of energy sufficiency policies (e.g. for equity, health) are often notable and sometimes more obvious than the climate outcomes, the extent to which emphasising these co-benefits affects support for policies has not been examined. Co-benefits are overlooked in policymaking in general. 38

One type of framing that has received more attention is whether policies are presented as changes or as already-existing measures. 'Status quo bias' 39 -the tendency to favour the way things are over a change   has been observed in several contexts. -In one experiment, participants' willingness to pay for their state to be part of a regional carbon mitigation policy was 2.5 times higher if they were told their state was already part of the scheme compared to if they were told they would be joining. 40  In another experiment, Irish participants rated a town layout more favourably when told it was already in place compared to when it was planned. 41  It is not clear whether the effect is entirely place dependent; for example, whether knowing that a proposed change in Area A is already the status quo in Area B reduces the bias against that change in Area A.

As well as policy attributes and presentation, characteristics of people and their environments are sometimes important too. For example, opposition to climate policies is more likely to come from people on the political right than the left, 42,43  though this effect is disproportionately studied in the US where it appears to be most pronounced. 44  Similarly, compared to egalitarians, those with hierarchical

34 Bergquist, M., Nilsson, A., Harring, N., &amp; Jagers, S. C. (2022). Meta-analyses of fifteen determinants of public opinion about climate change taxes and laws. Nature Climate Change , 12 (3), 235-240. https://doi.org/10.1038/s41558-022-01297-6

35 Heyen, D. A., &amp; Wicki, M. (2024). Increasing public support for climate policy proposals: a research agenda on governable acceptability factors. Climate Policy, 24(6), 785-794. https://doi.org/10.1080/14693062.2024.2330390

36 Drews, S., &amp; Antal, M. (2016). Degrowth: A 'missile word' that backfires? Ecological Economics , 126 , 182-187. http://doi.org/10.1016/j.ecolecon.2016.04.001

37 O'Dell, D., Contu, D., &amp; Shreedhar, G. (2025). Public support for degrowth policies and sufficiency behaviours in the United States: A discrete choice experiment. Ecological Economics , 228 , 108446. https://doi.org/10.1016/j.ecolecon.2024.108446 38 Karlsson, M., Alfredsson, E., &amp; Westling, N. (2020). Climate policy co-benefits: a review. Climate Policy , 20 (3), 292-316. https://doi.org/10.1080/14693062.2020.1724070

39 Samuelson, W., &amp; Zeckhauser, R. (1988). Status quo bias in decision making. Journal of risk and uncertainty , 1 (1), 7-59. https://doi.org/10.1007/BF00055564

40 Lang, C., Weir, M., &amp; Pearson-Merkowitz, S. (2021). Status quo bias and public policy: Evidence in the context of carbon mitigation. Environmental Research Letters , 16 (5), 054076. https://doi.org/10.1088/1748-9326/abeeb0

41 Andersson Y., McGowan, F., Timmons, S., and Lunn, P.  (2023). Status quo bias impedes active travel policy by changing the process of opinion formation. ESRI Working Paper 755. https://www.esri.ie/publications/status-quo-bias-impedes-active-travelpolicy-by-changing-the-process-of-opinion

42 McCright, A. M., Dunlap, R. E., &amp; Marquart-Pyatt, S. T. (2016). Political ideology and views about climate change in the European Union. Environmental Politics , 25 (2), 338 -358. https://doi.org/10.1080/09644016.2015.1090371

43 Hornsey MJ, Harris EA, Bain PG, Fielding KS. Meta-analyses of the determinants and outcomes of belief in climate change. Nature Climate Change . 2016 Jun; 6(6):622 -6. https://doi.org/10.1038/nclimate2943

44 Hornsey MJ, Harris EA, Fielding KS. Relationships among conspiratorial beliefs, conservatism and climate scepticism across nations. Nature Climate Change . 2018 Jul; 8(7):614 -20. https://doi.org/10.1038/s41558-018-0157-2

and individualist worldviews are more likely to be sceptical about climate science. 45  Several studies find that older groups are more supportive of climate policies. 46,47  Less consistently, women are more supportive of some policies than men. 48,49  Knowledge, risk perception, social trust and norms are also important. But these and aforementioned sociodemographic factors are less influential compared to perceived fairness, effectiveness, and worry about climate change.

## 1.3.3. Perception gaps and pluralistic ignorance

While actual support for climate action in general and for several specific measures is high, perceived support tends to be much lower. That is, people underestimate the extent to which other people support climate action. For example, while 69% of people would contribute 1% of their income to tackle climate change, only 43% think most others would do the same. 50  This phenomenon in which a majority want stronger action but believe they are a minority has been called  pluralistic ignorance . ' '

Importantly, pluralistic ignorance is not limited to the general public. Academics also substantially underestimate public support, as do politicians -this has now been documented in multiple studies and regions including a recent study with MPs in the UK. 51,52,53,54  This point is central to the purpose of this study: if it is the case that most people (including policymakers) are underestimating support for stronger energy sufficiency policies, then we are likely in a situation where we are curtailing required action partly due to a false belief that demand reduction policies would not be stomached by the public.

## 1.4. Study aims and research questions

Ultimately, we need more research to better understand public support for sufficiency policies to design policies that stand the best chance of working, and to be aware of misperceptions about what people think should happen. In this study, we asked a representative sample of people in Ireland for their opinion on a large set of energy sufficiency policies across sectors, using an experiment designed to address various gaps in the literature and answer a set of research questions.

45 Jylhä, K. M., Cantal, C., Akrami, N., &amp; Milfont, T. L. (2016). Denial of anthropogenic climate change: Social dominance orientation helps explain the conservative male effect in Brazil and Sweden. Personality and Individual differences , 98 , 184-187. https://doi.org/10.1016/j.paid.2016.04.020

46 Martin et al. (2025). Perceptions of climate change and policy among farmers and the public in Ireland. ESRI Research Series No. 207. https://www.esri.ie/publications/perceptions-of-climate-change-and-policy-among-farmers-and-the-public-in-ireland 47 Dietz, T., Dan, A., &amp; Shwom, R. (2007). Support for climate change policy: Social psychological and social structural

influences. Rural sociology , 72 (2), 185-214. https://doi.org/10.1526/003601107781170026

48 Lehrer, L., Hellmann, L., &amp; Betsch, C. (2025). Understanding sociodemographic differences in climate behavior, climate policy acceptance, and political participation. The Journal of Climate Change and Health , 21 , 100353.

https://doi.org/10.1016/j.joclim.2024.100353

49 Silva, T., Hamdon, C., &amp; Huddart, E. (2025). Masculinity, femininity, and support for climate policy. Environmental Sociology , 1-19. https://doi.org/10.1080/23251042.2025.2517426

50 Andre, P., Boneva, T., Chopra, F., &amp; Falk, A. (2024). Globally representative evidence on the actual and perceived support for climate action. Nature Climate Change , 14 (3), 253 -259. https://doi.org/10.1038/s41558-024-01925-3

51 Sevincer, A.T., Hostlowsky, L., Styhler, F. (2026). Public support for climate action is underestimated in the German political domain. Commun Earth Environ 7, 543. https://doi.org/10.1038/s43247-026-03721-7

52 Carrington, D. (2026, January 5). 'A silent majority': MPs underestimate support for green policies, study reveals. The Guardian . https://www.theguardian.com/environment/2026/jan/05/mps-underestimate-support-green-policies-study

53 Walgrave, M., &amp; Soontjens, K. (2025). Responsive nor responsible? Politicians' climate change policy preferences and public opinion perceptions. Environmental Politics , 1 -25. https://doi.org/10.1080/09644016.2025.2492439

54 Tanase, LM., Reisch, L.A., Dewies, M., &amp; de-Wit, L. (2026)  Perception gaps in the British Parliament reveal a possible pathway to . stronger climate policy action. Commun. Sustain. 1, 127. https://doi.org/10.1038/s44458-026-00097-9

Our overarching research question arose from consideration of two facts taken together. First, that evidence from modelling shows sufficiency policies are needed to meet our obligations, and second, there is lack of evidence about whether people in Ireland would support energy sufficiency policies, which types would be more supported than others, whether some groups of people would be more supportive than others.

Research question 1: What level of support is there amongst people in Ireland for a range of sufficiency policies, and which groups of people and characteristics, as well as policy attributes, are associated with greater levels of policy support?

The research gap regarding the effect of highlighting co-benefits on policy support, and the potential for alternative narratives to resonate with those for whom climate is less of a priority, motivated our second research question.

Research question 2: Does the rationale given for sufficiency policies affect policy support, and does this depend on an individual's attitude towards climate action?

Following from findings regarding status quo bias, we reasoned that giving examples of where sufficiency policies have already been implemented elsewhere might increase support for these.

Research question 3: Does providing an implementation example of a policy from elsewhere increase support for its implementation?

We also sought to replicate previous differences in actual and perceived support (perception gaps) for climate policy with a large set of energy sufficiency policies.

Research question 4: Are there differences between perceived and actual support for energy sufficiency policies?

Finally, assuming perception gaps were found, we sought to investigate whether willingness to share views on energy sufficiency policies was greater when policies were strongly opposed compared to when they were strongly supported or in between, which might explain such gaps.

Research question 5: are people more likely to share strong views on a policy compared to when they are less sure?

## 2. Methods

## 2.1. Sampling and data collection

We collected data from a nationally representative 55  sample of 2,400 participants in October 2025. The study was sent electronically to the panel of a leading Irish market research company, 56  and completed on a computer, tablet or smartphone. Participants were paid €4 for their time.

## 2.2. Study design

On the study landing page, participants were told that a government agency was running the study to better understand public support for different types of policies in Ireland. SEAI was not mentioned and nor was climate or energy at this stage. Participants were further told that their responses could help to inform future decisions about policy in Ireland. Before responding to policies, participants were provided with more specificity regarding what the policies aimed to do, i.e. policy rationale (described below).

Each participant responded to six policies that were randomly drawn from the pool of 16 in a random order. This resulted in an approximately 900 responses per policy (min= 862, max= 948).

## 2.2.1. Experimental manipulations

The study included two experimental manipulations, to address research questions RQ2 and RQ3. See Figure 2 for a visual representation of the experiment design.

## Stated rationale -between-subjects

Participants were randomly assigned to one of three groups. For one of the groups, the policies were framed as energy demand reduction measures (the Energy condition); for a second group, the measures were framed in terms of their co-benefits for quality of life (the Quality-of-Life (QoL) condition); and for the third group, both energy demand and quality-of-life benefits were combined (the Combination condition).

## Policy example -within-subject

For all participants, the last three policies they saw included a statement about where the policy (or similar) is already implemented. Given that the order in which they saw the policies was randomised, this meant that each policy was presented with alongside an example approximately half of the time.

## Figure 2. Simple schematic representation of the study experiment design.

<!-- image -->

## 2.2.2. Policy stimuli

Table 1 summarises the study policies in shortform and includes labels: a) policy type (whether the policy is a restrictive or enabling policy; and b) the co-benefit type that was described (in the Quality-ofLife and Combination conditions). The full wording for each policy can be found alongside the results for each.

The set of policies was selected to achieve a balance of policy type, sector, restrictiveness and likely popularity, in order to build a comprehensive picture of the types of measures that the public support or oppose. The inclusion of a given policy in this study should not necessarily be taken as an endorsement by SEAI.

Table 1. Summary of policy measures used in the study.

|   1 | Sail & Rail travel subsidy                      | Enabling    | Cost-of-living                 |
|-----|-------------------------------------------------|-------------|--------------------------------|
|   2 | Frequent flyer tax                              | Restrictive | Air quality; Health/Wellbeing  |
|   3 | Four-day week                                   | Enabling    | Health/Wellbeing               |
|   4 | Car restrictions in urban areas                 | Restrictive | Air quality; Safety            |
|   5 | E-cargo bike grants                             | Enabling    | Health/Wellbeing               |
|   6 | Vehicle mass tax                                | Restrictive | Air quality; Safety            |
|   7 | Stronger public transport investment            | Enabling    | Health/Wellbeing               |
|   8 | Congestion charges                              | Restrictive | Air quality; Health/Wellbeing  |
|   9 | High-density housing                            | Enabling    | Housing; Proximity to services |
|  10 | Limits on one-off rural housing                 | Restrictive | Proximity to services          |
|  11 | Downsizing tax relief                           | Enabling    | Housing                        |
|  12 | Maximum office temperature settings             | Restrictive | Public services                |
|  13 | Rising block electricity tariffs                | Enabling    | Cost-of-living                 |
|  14 | Data centre ban extension                       | Restrictive | Public services                |
|  15 | Air drying space in new housing                 | Enabling    | Health/Wellbeing               |
|  16 | Remove lit advertising & reduce public lighting | Restrictive | Health/Wellbeing               |

## 2.2.3. Outcome measures

For each of the six policies in turn, participants:

- 1) rated their support for the policy on a 7-point scale (from 1 Fully Oppose to 7 Fully Support),
- 2) estimated national support (whether more people would oppose the policy than support it, more would support than oppose, or most would be unsure or not care),
- 3) indicated whether they would express their opinion to others (with no one, with those who likely shared their views, or with anyone),

- 4) rated the fairness of the policy (7-point scale), and
- 5) rated its effectiveness (7-point scale).

Each participant produced 6 cases of each outcome variable, resulting in 14,400 responses for each of the outcome variables.

After participants rated each policy, we presented them with one policy again, randomly selected, and asked them ' What, if anything, would make this policy better or increase public support for it? .' They provided responses in an open text box.

## 2.2.4. Other measures

Participants rated the importance to them of climate change, health, housing, and cost of living policy issues on 7-point scales; and the level of priority they thought climate policy should be for government (1) Low; 2) Medium; 3) High; 4) Very High). 57  Participants completed two tasks, adapted from existing measures, 58  to measure knowledge about climate issues (one on sectoral emissions and one on effectiveness of different actions). We also asked participants to rate their own understanding of how to save energy and whether they thought Ireland's national GHG emissions were going up, down, or staying the same. Finally, participants completed personal and socio-demographic information.

## 2.3. Analysis

Many of our main results are simple descriptives of support and perceived support for policies. But further, we statistically model support in two ways to assess the influence of participant characteristics, climate literacy and priority, policy attributes, and experimental manipulations (above) on support for policies.

The first is at an aggregate level, analysing responses to all 16 policies together. We model our 7-point measure of support using an ordinal logistic regression, using a multi-level structure and clustered standard errors to account for repeated measures from the same participants. We also model reported willingness to share policy views using the same type of analysis.

The second way we model support is at an individual policy level, i.e. we model support for each of the 16 policies in separate ordinal logistic regressions. For these models we used a recategorised 5-level version of the 7-point variable used for the overall models above to ensure the assumption of proportional odds was satisfied.

57 This question was adopted from the EPA Climate Change in the Irish Mind study: O'Mahony, D., Quinlan, C., Cotter, D., Rochford, M. F., Leiserowitz, A. Regan, A. Carman, J., and Rosenthal, S. (2024). Climate Change in the Irish Mind: Wave 2, Report 1. Johnstown estate, Wexford: Environmental Protection Agency

58 Martin et al. (2025). Perceptions of climate change and policy among farmers and the public in Ireland. ESRI Research Series No. 207.

## 3. Results

This section is split into three subsections. In the first, we briefly describe important characteristics and general climate attitudes of the sample. In the second, we describe overall support for energy sufficiency policies, (i.e. pooling responses for all policies together), and outline factors that affect support. We also describe perception gaps, i.e. differences between actual and perceived support for policies. Finally, in the third subsection, we consider each policy individually, describing support levels and the factors associated with variation in support levels for each.

## 3.1. Participant characteristics

Sample characteristics are summarised in Appendix 1. Here we describe some of those most relevant to this study and to the policies presented.

## 3.1.1. Sociodemographic variables

The sample was representative of the Irish population on gender, age, region, and social grade. A majority (58%) had third level education. Most (62%) lived in a larger urban area (large town, satellite/commuter town, suburb, or city centre), 17% lived in a small town or village, and 22% lived in a rural area. 38% of participants lived in a household with at least one child of school age or younger, and 65% of participants owned their home.

## 3.1.2. Mobility habits

In terms of mobility, most participants (85%) used a car at least once a week; 59% reported doing so daily. About a quarter of respondents reported using a bike to get around, but just 13% used one on a weekly basis. Just over a fifth (22%) of participants reported taking three or more personal flights (return) per year. Nearly 27% took three or more flights of any kind (work or personal combined) per year.

## 3.1.3. Climate/energy literacy

To measure knowledge about which sectors consume most energy we asked participants to rank six sectors in order of their energy consumption, giving a point for every sector ranked within one place of its correct rank. The mean score was 2.4 (SD=1.2).

Participants were somewhat better at identifying effective actions for reducing energy consumption (choosing from pairs of actions). The mean score was 2.6 out of 5 (SD=1.1). We also asked participants to self-rate how well they understood how to save energy at home on a 7-point scale. The mean response was 5.6 (SD= 1.2).

Just 27% of participants responded correctly to a question about Ireland's greenhouse gas emissions trajectory over recent years ( going down a little ). 2% instead thought emissions were going down a ' ' lot, but almost half (45%) thought emissions have been going up (31% 'a little' and 14% ' a lot ). Just ' over a quarter (26%) of respondents thought emissions have been staying about the same.

## 3.1.4. Political views

Politically, the sample was balanced. Almost half of participants (47%) placed themselves in the centre (a 4 on the 7-point scale), 29% were left of centre (2% extreme left) with 24% to the right (3% extreme right).

## Climate priority

We asked participants how highly they felt the government should prioritise climate change (Figure 3). Most (about three in five) participants said that climate should be a  high ' ' or 'very high' priority (33% and 26% respectively). Another 29% said it should be a medium priority, while just 12% said low.

Figure 3. Participants  ratings of the level of priority they think climate change should be given ' by government.

Do you think climate change should be a very high, high, medium, or low priority for the Government of Ireland?

<!-- image -->

Middle-aged people (aged 35-54) were less likely to rate climate change as a high or very high priority (53%), compared to both younger (62%) and older (65%) cohorts. Those from lower (C2DEF) social grades were less likely to rate climate as a high/very high priority (54%) compared with those from higher (ABC1) grades (65%). Men were very slightly less likely to rate it as a high/very high priority (57%) compared with women (61%), but there were no differences by geographical region. People with high household income (€12 0,000 or more) were more likely to rate climate as a high/very high priority (69%) compared to those with incomes in the lowest bracket (€4 0,000 or less; 58%). 59

## 3.2. Overall results

This section describes responses to all policies taken together, i.e. aggregated responses across policies, the factors associated with support, and gaps between actual and perceived support. The output table for the statistical models used to produce the estimates of associations between various factors and support are shown in Appendix 3A.

## 3.2.1. Factors affecting policy support

Support for energy sufficiency policies was broadly very high. The median response was 5 on the 7point scale, with 7 (fully support) being the most common response, accounting for a third of all responses (Figure 4A). In contrast, just 10% of responses were 1 (fully oppose). These responses at the extremes were distributed across participants. In other words, it was not the case that the same group of participants were responsible for all or most of the policy opposition (Figure 4B). Just three participants rated their support for all the policies they saw as 1, and 20 more gave either a 1 or 2 in response to all of them (less than 1% of the sample). Instead, opposition was more highly concentrated on certain policies. We detail support for each individual policy in a later section.

59 It is important to note that we asked participants this question after they were asked to rate the importance of other policy issues, which were cost of living, housing, and health policy.

## Figure 4. Distribution of all support ratings (6 per participant; left (A)) and distribution of participant mean support ratings (right (B)).

<!-- image -->

## Participant characteristics, knowledge and attitudes

There was a surprising lack of sociodemographic differences in overall policy support. The only difference found was between certain age groups, whereby the oldest group (65+) were modestly more likely to support policies compared to the reference group aged 45-54 (see Appendix 1, Model 1: OR=1.43, p&lt;.001) 60 . This difference disappeared when perceived fairness was added to the model (Model 5), suggesting that greater perceived fairness of policies among the older group drove their stronger support. Gender, region, social grade, and household composition had no overall influence on policy support. We delve more into sociodemographic differences in a later section in which individual policies are modelled.

Climate and energy literacy was important to support. Both knowledge of relative sectoral emissions (a variable that ranged from 0-6; Model 3: OR=1.05, p=0.03) and of which climate actions or behaviours are more effective than others (range 0-5; Model 3: OR=1.06, p=0.01) had positive associations with policy support. Self-reported understanding of energy saving was also positively related to support (OR=1.2, p&lt;0.001). Compared to people who thought emissions levels were not changing, both people who thought they were increasing (OR=1.2, p=0.004) and people who thought they were decreasing (OR=1.18, p=0.017) were more likely to give higher support ratings.

Unsurprisingly, those who rated climate change as a low or medium priority were less supportive than people who rated it high or very high (Model 3: OR=0.48, p&lt;0.001). Politically, those in the centre (Model 2: OR=0.63, p&lt;0.001), on the centre right (OR=0.58, p&lt;0.001) or further right (OR=0.52, p&lt;0.001) were less likely to support policies than those on the left. But despite these differences, support was very high across the political spectrum. People on the left gave an overall mean response of 5.2 (SD=1.1); people in the centre 4.9 (SD=1.1); and people on the right 4.8 (SD=1.3) -well above the midpoint of the scale. Moreover, supporters of parties currently in government were no less likely than other participants to support potential energy sufficiency policies (OR=1.01, p=0.83).

60 OR stands for odds ratio. An odds ratio is a measure of the strength of the association between predictor variable (e.g. age) and the outcome variable (support). An OR greater than 1 indicates a positive association (e.g. being older increases the odds of giving a policy a higher support rating); an OR equal to 1 indicates no association (i.e. no change in odds of support due to age); and an OR less than 1 indicates a negative association. The p value indicates the likelihood that the association observed is due to chance. A lower p value indicates that the association is less likely due to chance (i.e. it is more likely to be a real association).

## Policy attributes

Attributes related to the individual policies themselves were the most important factors in support. Perceived fairness and effectiveness were the two most important predictors of support (see Appendix 2 for fairness and effectiveness ratings of each policy), with perceived fairness being particularly predictive of policy support (Model 5: OR=4.29, p&lt;0.001). When fairness and effectiveness are accounted for, policy restrictiveness ( i.e. whether the policy was categorised as restrictive ('push' ) or enabling ('pull') ) had a smaller influence on support (OR=0.78, p&lt;0.001). Its effect was markedly larger when perceived fairness and effectiveness were excluded suggesting most of its impact is mediated by these perceptions.

## Experimental manipulations: stated rationale and providing examples

The stated rationale manipulation had no overall effect on support. However, it did have an interaction effect with the level of priority a participant thought the government should give to climate change (Figure 5). Among respondents for whom climate was a low or medium priority, those in the Quality-oflife (QoL) condition displayed higher support than their counterparts in the Energy condition (OR=1.44, p=0.005). Interestingly, there was no such interaction with the combination condition, suggesting that to some people with lower climate priority, the mention of climate or energy was off-putting. It may be that the absence of climate or energy language was as important to them as the presence of the cobenefits.

Figure 5. Mean policy support ratings by stated rationale manipulation and climate policy priority illustrating the modest interaction effect. Error bars are standard errors.

Policy support by stated rationale and climate priority

<!-- image -->

While the effect of the policy example manipulation was statistically significant (OR=1.12, p&lt;0.001), the effect is very small overall and therefore not particularly meaningful. The direction of the effect also reverses when policy attributes are added to the model (Model 5), suggesting that giving examples increase the perceived effectiveness and fairness of policies.

In a later section, we model each of the policies individually and find heterogenous effects of both experimental manipulations.

## 3.2.2. Perception gaps

To assess perception gaps we compared the proportion of participants who supported each policy (rated it 5 or more on the 7-point scale) to the proportion who said they thought that more people would support the policy than oppose it. In other words, we compared the proportion of people who supported each policy to the proportion who perceived majority support for each policy.

Figure 6 illustrates this comparison, ordered by level of actual policy support. For every policy, the proportion of people who perceived majority-support was lower than the proportion of people who supported the policy, and for all but one (the four-day working week), substantially so. On average there was a 25-percentage-point (ppt) difference in the proportion of people who supported a policy compared to the proportion that expected most others to support a policy. Most participants perceived majority support for only four of the 14 policies for which there was more than 50% support.

Figure 6. Perception gaps (of support and opposition) for each policy, ordered by magnitude of support for the policy.

<!-- image -->

Opposition to policies (ratings of 3 or less) was overestimated, but to a lesser degree than support was underestimated. There was 8 ppt on average between the share of people who opposed a policy and the share of people who thought most others would oppose it. The difference was largest for the vehicle mass tax (23 ppt), congestion charges (22 ppt) and urban car restrictions (21 ppt) policies. These three policies were opposed by between 31% and 36% of participants, but majority opposition was perceived for each. There were no differences between shares of actual opposition and perceived majority-opposition for the four-day week policy, grants for e-cargos, or a ban on new data centres. In general, most of the gap between support and perceived support was accounted for by perceived uncertainty or indifference of others towards the policies, except among the five least popular policies, where the majority perception was majority opposition.

## Willingness to share views with others

For each policy they were presented with, we asked participants whether they would feel comfortable sharing their opinion on the policy with other people (Figure 7). Level of support for the policy had a strong association with willingness to share views. People were more willing to share the stronger their view on the policy in either direction (see Appendix 3B for model results), although willingness to share views was high across the board (in 72% of all responses, participants said they would share their opinion with anyone). Thinking your view was in the majority was associated with greater willingness to share (OR=2.27, p&lt;0.001), but not to an extent that would explain the large perception gaps observed. Participants still reported being willing to share their opinion with anyone in almost two thirds of cases in which they thought theirs was a minority opinion.

Figure 7. Reported willingness to share policy support view with other people according to level of policy support for the policy in question.

Willingness to share by level of support

<!-- image -->

Men were more likely to say they would share their opinion (OR=1.43, p&lt;0.001). Younger groups were significantly less likely, and older groups significantly more likely to be willing to share views compared to middle aged group. There was also a positive association of willingness to share with income level. People from higher (ABC1) social grades were also more willing to share their view. Less obviously, participants from households with children were less willing to share views compared to people living alone (OR=0.48, p&lt;0.001). Finally, people living in Connacht were less likely to share their views compared to people living in Dublin (OR=0.55, p&lt;0.001).

## 3.3. Results by individual policy

In this section we describe support levels for each of the 16 policies in turn, as well as modelling results for the factors associated with support. Full model results are in Appendix 3C.  61  The exact wording presented to participants in the study is shown in the boxes, including text shown for the stated example and different rationales. For conciseness, we do not include the wording from the Combination condition, which was simply an amalgamation of the other two conditions. Table 2 provides a summary of results presented in this section.

61 Modelling results are based on ordinal logistic regressions of 5-level variables of the support variable for each policy. Ratings of 2 &amp; 3 and 5 &amp; 6 were combined. This recategorisation ensured that models satisfied the assumption of proportional odds (a requirement for valid ordinal regression results).

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 2. Summary of support for individual policies and factors associated with each (green text indicates positive relationship with level of policy support and red indicates a negative one).

| Four-day week                        |   6.05 |   1.48 | - Males, aged 55+, Combination rationale                                                                                 |
|--------------------------------------|--------|--------|--------------------------------------------------------------------------------------------------------------------------|
| Air drying space in new housing      |   5.8  |   1.59 | - Males, large house + 65+, climate priority                                                                             |
| Public transport investment          |   5.88 |   1.45 | - Motorists + 65+, climate priority                                                                                      |
| Sail & rail travel subsidy           |   5.67 |   1.57 | - Males, €80 - €120k income + Climate priority                                                                           |
| Downsizing tax relief                |   5.57 |   1.69 | - Aged 18-24 + 55+, climate priority, knowledge, QoL rationale                                                           |
| Remove lit adverts & reduce lighting |   5.33 |   1.8  | + Climate priority                                                                                                       |
| Max office temperatures              |   5.28 |   1.8  | + 65+, €120k+, climate priority                                                                                          |
| Data centre ban extension            |   4.99 |   1.87 | - €40 - €80k + 35-44, existing policy                                                                                    |
| E-cargo bikes grants                 |   4.93 |   1.92 | - Motorists, QoL rationale + Young children, cyclists, climate priority                                                  |
| Rising block electricity tariffs     |   4.76 |   1.96 | - €120k+ , Connacht + Males, climate priority, QoL rationale*                                                            |
| High-density housing                 |   4.75 |   1.85 | + Male, 65+, city dweller, climate priority, Combination, QoL rationale*                                                 |
| Vehicle mass tax                     |   4.42 |   2.11 | - Motorists, social grade C2DEF + Large town/city dweller, cyclist, 65+, climate priority                                |
| Car restrictions in urban areas      |   4.44 |   2.07 | - Motorists, social grade C2DEF + Large town/city, cyclist, 65+, climate priority                                        |
| Congestion charges                   |   4.19 |   2.18 | - Motorists, suburban dwellers + Cyclists, €40k+ , 65+, climate priority, existing policy, QoL* & Combination rationale* |
| Frequent flyer tax                   |   4.05 |   2.2  | - Number of flights + 18-24, climate priority, QoL rationale*                                                            |
| Limits on one-off rural housing      |   3.6  |   2.12 | - Living rurally, middle-aged , €40k+ + Apartment dweller, climate priority, QoL rationale                               |

- * Indicates an interaction effect with climate priority (e.g. that the rationale type was more effective among people for whom climate was a low or medium priority).

## Policy 1: Sail &amp; Rail travel subsidy

## Policy: A government subsidy for Sail &amp; Rail* tickets to Great Britain.

*Sail &amp; Rail is a joint scheme where you get a single ticket that covers both the ferry and train.

[Example stated] Germany and Spain have had subsidised train travel since 2022.

[Energy rationale] Over a third of overseas trips from Ireland go to Great Britain. Taking the ferry and train produces up to 90% fewer carbon emissions than flying.

[Quality-of-life rationale] Over a third of overseas trips from Ireland go to Great Britain. A subsidy for Sail &amp; Rail would make these trips cheaper and easier for lots of people.

The mean support rating for a Sail &amp; Rail travel subsidy was 5.7 (SD=1.6). 78% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 8% opposed the policy (gave it a 3 or less); and 14% neither supported nor opposed it (rated it 4 on the scale). The most common response was 7 Fully Support (45%) (Figure 8).

Figure 8. Distribution of support ratings for the Sail &amp; Rail travel subsidy policy.

<!-- image -->

## Factors affecting support

Men were slightly less supportive of the policy (OR=0.76, p=0.03). However, their mean rating was 5.5 (SD=1.7) -so support, although lower, was still substantial. People on low incomes (under € 40,000) were slightly more supportive than higher middle-income people (with an annual household income between €80,000 and €120,000) (OR=0.64, p=0.04). Interestingly, proximity to a ferry port (i.e. living in a county with a ferry port or a county that bordered one) did not impact support (OR=1.14, p=0.32), and neither did the number of flights a person took.

There was no effect of either experimental manipulation (stated rationale or policy example).

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common response included reference to ensuring Sail &amp; Rail is affordable, that the subsidy is large enough and makes the option cheaper than flying. Several people also remarked on the importance of providing ample information (e.g. about the benefits to the environment) and ensuring this reaches the public through publicity campaigns. Another response was that transport links on both sides (in Ireland and the UK) need to be adequate and line up with ferry times.

## Policy 2: Frequent flyer tax

Policy: A 'frequent flyer tax' where people pay more for their third return flight* in a year and any further flights, with some exceptions (e.g. for medical or bereavement reasons). *80% of Irish people fly fewer than 3 times a year and would not be affected by this tax.

[Example stated] Several organisations, including Safe Landing , a global campaign group made up of aviation workers, advocate for this idea.

[Energy rationale] This could greatly reduce emissions by encouraging those who fly the most to reduce the number of flights they take, without affecting people who fly less. [Quality-of-life] This could improve air and noise pollution near airports by encouraging those who fly the most to reduce the number of flights they take, without affecting people who fly less.

The mean support rating for a frequent flyer tax was 4.1 (SD=2.2). 45% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 39% opposed the policy (gave it a 3 or less); and 15% neither supported nor opposed it (rated it 4 on the scale). While almost 2 in 5 people were opposed to a frequent flyer tax, and 30% strongly so (Figure 9), more people supported the policy than opposed it.

Figure 9. Distribution of support ratings for the frequent flyer tax policy.

<!-- image -->

## Factors affecting support

A u-shaped relationship with age is apparent, such that older and younger groups are more supportive than middle-aged. The youngest group (18-24) were most likely to support the measure (OR=1.57, p&lt;0.05; compared with those aged 45-54). Support decreased the more flights a person took. Interestingly, people who took two annual flights were less likely to support the policy than people who took none even though the tax would not affect them (OR= 0.48, p&lt;0.001). The mean support rating among people who flew less than once a year was 4.9 (SD=2.1); among those who took one return flight it was 4.6 (SD=2.09); among those who flew twice it was 4.1 (SD=2.1); three times 3.0 (SD=1.9); and four times 2.4 (SD=1.86).

Importantly, while the stated rationale manipulation had no influence overall, the Quality-of-life condition did interact with climate priority (OR=1.9, p=0.04). That means among those who give low or medium priority to climate change, the Energy rationale was less effective than the Quality-of-life rationale. There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses were to ensure that the policy does not unduly affect people with no alternative, that the equity aspects of the policy are soundly communicated, and that flying alternatives are available and incentivised.

## Policy 3: Four-day week

## Policy: Change the length of the standard working week from five to four days, without changing pay.

[Stated example] Four-day work weeks have been successfully trialled in several countries including Ireland in a 2022 pilot with 17 companies.

[Energy rationale] A four-day work week increases productivity, while reducing carbon emissions (e.g. from commuting).

[Quality-of-life] A four-day work week increases productivity, while improving work-life balance and health.

The mean support rating for a four-day week was 6 (SD=1.5). 84% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 6% opposed the policy (gave it a 3 or less); and 10% neither supported nor opposed it (rated it 4 on the scale; Figure 10). Perhaps unsurprisingly, a four-day working week was the most popular policy presented to participants.

## Figure 10. Distribution of support ratings for the four-day week policy.

<!-- image -->

## Factors affecting support

The oldest group (65+) was the least supportive (OR=0.51, p=0.01). Men were also somewhat less likely to support the policy (OR=0.74, p=0.03) but there was no association between support and having children in the household, working patterns, driving frequency or any other participant characteristics.

Those who saw a Combination of both rationales were slightly less likely to support the policy compared to those in the Energy rationale group (OR=0.70, p=0.03), but given the few opposers to this policy, this result should be interpreted with caution. There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common response was to ensure it is fairly and universally applied (e.g. that it would include nurses and teachers), that it is flexible in that people can choose which four days they work, and to ensure that work-life balance and other benefits are communicated.

## Policy 4: Car restrictions in urban areas

Policy: Restrict private car use in the centre of cities and large towns, by pedestrianising more streets and reducing parking spaces.

[Stated example] Lots of cities around the world already restrict cars on city streets, including in Ireland (e.g. Grafton Street in Dublin).

[Quality-of-life] Car-

[Energy rationale] Car-free areas make it quicker, easier and safer for people to use more sustainable modes of transport (e.g. bus, cycling or walking). free areas are much safer, more pleasant and better for people's health (better air quality and less noise pollution).

The mean support rating for car restrictions in urban areas was 4.4 (SD=2.1). 53% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 32% opposed the policy (gave it a 3 or less); and 15% neither supported nor opposed it (rated it 4 on the scale). This was the fourth least popular (as defined by the proportion of 7 ratings it received) policy of the sixteen that participants rated. However, it still received majority support with 53% of people who rated it giving it a 5 or higher (Figure 11).

## Figure 11. Distribution of support ratings for the car restrictions in urban areas policy.

<!-- image -->

## Factors affecting support

People aged 65+ were more supportive of this policy compared to people aged 45-54 (OR=1.61, p=0.02), while those in the C2DEF social grade were less supportive than those in the ABC1 group (OR=0.63, p&lt;0.001). People who use a car at least weekly were much less likely to support the policy than those who use one less often or not at all (OR=0.34, p&lt;0.001), while regular cyclists (using a bike at least weekly) were much more likely to support it compared to non-cyclists (OR=1.89, p=0.001). There was no significant effect of having a disability in the household on support.

Neither experimental manipulation made a difference overall. As with the frequent flyer tax however, when looking at the interaction between stated rationale and climate priority, we did see a significant effect, such that the Energy rationale was less effective among lower prioritisers and more effective among higher prioritisers compared to the Quality-of-Life co-benefits rationale (OR=2.59, p=0.002). There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses were ensuring that access to affected areas is straightforward and cheap using public transport, that the needs of disabled and older groups catered to, and that park-and-ride facilities are made available.

## Policy 5: E-cargo bikes grants

## Policy: Introduce grants for e-cargo bikes.*

*An electric bike with a large storage space (e.g. for transporting goods or children).

[Stated example] Germany, France, and many other European countries offer such grants.

[Energy rationale] E-cargo bikes are a convenient substitute for cars for some trips, greatly reducing fuel use and carbon emissions.

[Quality-of-life] E-cargo bikes are a convenient way to get around and can save time on some trips while providing exercise and reducing stress.

The mean support rating for e-cargo bike grants was 4.9 (SD=1.9). 62% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 22% opposed the policy (gave it a 3 or less); and 17% neither supported nor opposed it (rated it 4 on the scale; Figure 12).

## Figure 12. Distribution of support ratings for the e-cargo bikes grants policy.

<!-- image -->

## Factors affecting support

There were few differences in support according to participant characteristics. While regular drivers were less supportive of the policy (OR=0.62, p=0.006), the mean rating among that group was still positive (M=4.9, SD=1.9). Unsurprisingly regular cyclists were more supportive of the policy compared to non-cyclists, though not to a large extent (OR=1.69, p=0.01). People with pre-school children -likely the group who would benefit most from implementation -were slightly more likely to support it (OR=1.49, p=0.049).

Being in the Quality-of-Life rationale condition had a small negative effect compared to the energy rationale condition overall (OR=0.68, p=0.04). There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses were about upgrading infrastructure (e.g. more and better bike lanes) to improve the safety of the e-cargo bikes, both for owners and other road users. Respondents also highlighted that publicity campaigns to communicate the grants and the benefits of e-cargo bikes would be beneficial.

## Policy 6: Vehicle mass tax

## Policy: A tax on private vehicles based on weight/size and emissions they produce, such that petrol and diesel SUVs pay more.*

*This would not apply to commercial vehicles.

[Stated example] France has introduced a tax on cars according to weight, due to increase in 2026.

[Energy rationale] Compared to regular cars, SUVs produce a lot more emissions (if they were a country, SUVs alone would be the world's fifth -largest emitter).

[Quality-of-life] Compared to regular cars, SUVs cause a lot more air pollution, are much deadlier to pedestrians and also more likely to roll over and harm their passengers.

The mean support rating for a vehicle mass tax was 4.4 (SD=2.1). 55% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 31% opposed the policy (gave it a 3 or less); and 14% neither supported nor opposed it (rated it 4 on the scale). Responses to the policy idea were somewhat polarised in that 22% of respondents fully supported it and 17% fully opposed it. But overall, it was majority supported (Figure 13).

## Figure 13. Distribution of support ratings for the vehicle mass tax policy.

<!-- image -->

## Factors affecting support

People aged 65+ were more likely to support the policy compared to middle-aged (OR=1.69, p=0.01) and people in C2DEF less likely than people in ABC1 grades (OR=0.76, p=0.04). People living in large urban areas were somewhat more likely to support the policy (OR=1.58, p=0.01). Regular drivers were less likely to support it (OR=0.53, p=0.001), and regular cyclists more likely to (OR= 1.77, p=0.005). Neither those in households with young children (OR=0.75, p=0.06) or a disability (OR=1.19, p=0.17) were statistically less likely to support the policy compared to those in households without young children or a disability, respectively.

There were no effects of either experimental manipulation on support.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses were about ensuring exemptions are in place (e.g. for work vehicles) and communicating the benefits of the policy and the environmental damage caused by large vehicles. Several respondents were under the impression that these types of cars are necessary for large families. Another suggestion was to instead reduce tax for small cars and increase incentives for EVs.

## Policy 7: Stronger public transport investment

Policy: Reallocate funds to invest heavily in public transport across the country to increase the number of routes and frequency of services.

[Stated example] Italy and other European countries already have extensive rail networks, and London has very frequent services.

[Energy rationale] 70% of journeys in Ireland are made by car, which are responsible for a large share of our emissions. Better public transport would help people make fewer journeys by car. [Quality-of-life] 70% of journeys in Ireland are made by car, often because public transport is lacking or inconvenient. Better public transport would improve quality of life for many people.

The mean support rating for stronger public transport investment was 5.9 (SD=1.5). 83% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 7% opposed the policy (gave it a 3 or less); and 10% neither supported nor opposed it (rated it 4 on the scale; (Figure 14). This was the joint-second most popular policy.

## Figure 14. Distribution of support ratings for the stronger public transport investment policy.

<!-- image -->

## Factors affecting support

There was a u-shaped relationship between support and age. The youngest and oldest groups were more likely to support it compared to middle aged people. 65+ aged people were most supportive relative to middle-aged (OR= 1.58, p= 0.04). Regular drivers gave lower support scores on average compared to people who rarely or never used a car (OR= 0.50, p&lt;0.001), but the mean amongst motorists was still 5.8 (SD=1.5), i.e. support was overwhelmingly strong.

There were no effects of either experimental manipulation on support.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses included that investment be focused in particular ways, e.g. on certain modes. Other suggestions included integrating contactless payment options and making public transport cheaper and easier than using a car. Fairness was also important to people e.g. including rural investment and ensuring accessibility.

## Policy 8: Congestion charges

Policy: Congestion charges for drivers entering city centre areas during peak traffic hours.

[Stated example] London, Stockholm and many other cities have successful congestion charges.

[Energy rationale] Congestion charges reduce traffic and encourage the use of more sustainable transport.

[Quality-of-life] Congestion charges reduce traffic, improve air quality and make cities more liveable.

The mean support rating for congestion charges was 4.2 (SD=2.2). Almost exactly half (50.1%) of respondents supported the policy (gave it a 5 or more on the 7-point scale); 36% opposed the policy (gave it a 3 or less); and 14% neither supported nor opposed it (rated it 4 on the scale). Compared to other policies, support for congestion charges was mixed and polarised (Figure 15).

Figure 15. Distribution of support ratings for the congestion charges policy.

<!-- image -->

## Factors affecting support

Compared to people living in the city centre, those living in suburbs were less likely to give a supportive rating (OR=0.59, p=0.026). Regular cyclists supported it more than non-cyclists (OR=1.93, p&lt;0.001), and regular drivers less (OR=0.51, p&lt;0.001). People on middlehigher incomes (€ 80,000€120,000) were more likely to support congestion charges than those on low incomes ( under €40,000) (OR=1.61, p=0.021), though there was not statistically significant difference in the highest bracket (€120,000 or more).

This was one of the few policies for which the policy example manipulation had a statistically significant impact - respondents who saw the example were slightly more supportive on average than those who were not shown the example (OR=1.28, p=0.048). The mean rating for those in the stated example group was 4.4 (SD=2.1), whereas for the others it was 4 (SD=2.2).

The stated rationale manipulation did not have an overall effect but it did interact with both the Qualityof-life condition (OR=2.60, p=0.002) and Combination condition (OR=2.22, p=0.009). These rationales were relatively more effective among people with lower climate priority. The mean rating amongst lower-prioritisers in the Energy condition was 3.1 (SD=2.2), while in the Quality-of-life and Combination conditions it was 3.7 (SD=2.2 and SD=2.1, respectively).

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common response was improving public transport to affected areas. People also mentioned that affordable parking facilities outside the city centres would help.

## Policy 9: High-density housing

Policy: Change planning rules to prioritise buildings with a high density of housing units that maximises the number of people that can live in a given space.

[Stated example] High-density residential buildings are the norm in most European countries.

[Energy rationale] High-density housing uses less energy for heating. It also means services are closer to more people, reducing transport emissions.

[Quality-of-life] High-density housing means new homes can be provided for many more people, and it's easier to ensure services are close by.

The mean support rating for high-density housing was 4.8 (SD=1.9). 58% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 24% opposed the policy (gave it a 3 or less); and 18% neither supported nor opposed it (rated it 4 on the scale; Figure 16).

## Figure 16. Distribution of support ratings for the high-density housing policy.

<!-- image -->

## Factors affecting support

The oldest group (65+) was more likely to support this policy compared to middle aged people (OR= 1.59, p= 0.031). Men were slightly more supportive of this policy (OR=1.38, p=0.009), as were those living in large towns or cities compared with those in rural areas (OR=1.52, p=0.011). There were no effects of household or dwelling size on policy support.

Being in the Combination condition had a positive effect on support relative to the Energy condition (OR=1.51, p=0.004). There was also an interaction effect between the Quality-of-Life condition and climate priority (OR=1.87, p=0.034), with the interaction with the Combination condition falling short of statistical significance at the 5% level (OR=1.69, p=0.07). The mean rating amongst lower prioritisers in the Energy condition was 3.9 (SD=1.8), while in the Quality-of-Life condition it was 4.6 (SD=2.0), and in the Combination condition it was 4.7 (SD=1.9). There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses were about ensuring that the surrounding area could meet the needs of people living in the high-density housing buildings. For example, many people mentioned having enough space for children to play and that shops were nearby. People also mentioned affordability of the housing and that communicating the other benefits of high-density housing would be helpful.

## Policy 10: Limits on one-off rural housing

Policy: Limit the construction of one-off rural housing outside of established towns and villages, with some exceptions (e.g. people involved in agriculture).

[Stated example] The UK has planning restrictions on one-off rural housing.

[Energy rationale] One-off rural housing increases reliance on cars rather than sustainable alternatives. Detached homes also use much more energy for heating than other types of home. [Quality-of-life] Building houses in towns or villages rather than one-off rural housing means people have more services near them and don't need to travel long distances.

The mean support rating for limits on one-off rural housing was 3.6 (SD=2.1). 36% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 48% opposed the policy (gave it a 3 or less); and 15% neither supported nor opposed it (rated it 4 on the scale; Figure 17). This was the least popular policy presented to participants.

## Figure 17. Distribution of support ratings for the policy of limits on one-off rural housing.

<!-- image -->

## Factors affecting support

A feint u-shaped relationship between age and support was apparent. But the oldest group (65+) was most likely to support this policy compared to middle-aged people (OR= 1.9, p=0.004). Perhaps unsurprisingly, people who currently live in small towns or villages (OR=2.07, p&lt;0.001), or larger towns or cities (OR=3.42, p&lt;0.001) were much more likely to support the policy compared to people living in rural areas. People in detached (OR=0.58, p=0.04) and semi-detached (OR=0.54, p=0.008) homes were less likely to support it compared to apartment dwellers. Income was negatively associated with support. Participants with annual household income of € 40,000-€ 80,000 (OR=0.63, p=0.005), € 80,000-€ 120,000 (OR=0.61, p=0.02) and € 120,000+ (OR=0.37, p=0.001) were all likely to give a lower support rating than those with household income less than € 40,000 annually.

The Quality-of-Life condition had a modest overall positive impact compared to the Energy condition (OR=1.42, p=0.02). Interestingly, the Combination condition was not statistically different to the Energy condition, suggesting that for this policy, energy demand reduction framing may put some people off the policy rather than (or in addition to) the co-benefits of the Quality-of-Life rationale having a positive influence. There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common response was to broaden exemptions (e.g. to allow people with a longstanding connection to the area or whose parents have a house on the land to build a house). Others mentioned the need to make living in small villages more attractive.

## Policy 11: Downsizing tax relief

## Policy: Waive stamp duty (tax) for people downsizing to a smaller home when a larger space is no longer needed.

[Stated example] In social housing in Frankfurt (Germany) people get a moving bonus if they move from a flat that is larger than they need to a smaller one.

[Energy rationale] A smaller home uses a lot less energy per person for heating, which is the biggest use of energy in Irish homes.

[Quality-of-life] Moving to a smaller place frees up more homes for the families who need them.

The mean support rating for downsizing tax relief was 5.6 (SD=1.7). 76% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 12% opposed the policy (gave it a 3 or less); and 13% neither supported nor opposed it (rated it 4 on the scale; Figure 18).

## Figure 18. Distribution of support ratings for downsizing tax relief.

<!-- image -->

## Factors affecting support

The only participant characteristic associated with variation in support level was age. While those aged 18-24 were somewhat less supportive relative to those aged 45-54 (OR=0.57, p=0.025), people aged 5564 (OR=1.68, p=0.03) and over 65 (OR=1.96, p=0.005) were more supportive. House size, dwelling area type, and tenure had no influence on support.

Being the Quality-of-Life condition had a positive effect on support, albeit a small one (OR=1.43, p=0.026); people in the Quality-of-Life condition had a mean support rating of 5.8 (SD=1.6) compared to 5.5 (SD=1.7) in the Energy condition. There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common response was to ensure the incentive to downsize was large, with many reporting they would also support waiving stamp duty.

## Policy 12: Maximum office temperature settings

## Policy: Limit maximum heating temperatures in public sector office buildings.

[Stated example] Other European countries such as Germany and Spain already limit heating temperatures in public buildings.

[Energy rationale] Heating is one of the biggest uses of energy. Using less in public buildings would save a lot of energy.

[Quality-of-life] Heating is one of the biggest expenses for public buildings. Using less would save a lot of money that could be used for other things such as improving services.

The mean support rating for maximum office temperature settings was 5.3 (SD=1.8). 69% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 16% opposed the policy (gave it a 3 or less); and 15% neither supported nor opposed it (rated it 4 on the scale; Figure 19).

Figure 19. Distribution of support ratings for maximum office temperature settings.

<!-- image -->

## Factors affecting support

Being aged 65+ (and thus in most cases no longer working) was associated with greater support (OR=2.04, p&lt;0.001; compared with 45-54 age group), as was having an annual household income of at least € 120,000 (OR=2.1, p=0.017 ; compared with those with incomes under €40,000 ). Working arrangements made no difference.

The Quality-of-Life rationale interacted with climate priority (OR=1.86, p=0.04), such that amongst those who gave a lower priority to climate, those in the Quality-of-Life condition gave modestly higher ratings (M=4.9, SD=1.9) than those in the Energy condition (M=4.7, SD=1.9). There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses were tracking the energy savings, communicating them, and using any money saved for the public good. People also noted the importance of communicating the reasoning behind the policy and involving people in setting temperatures that ensured broad comfort.

## Policy 13: Rising block electricity tariffs

Policy: Mandate electricity suppliers to provide 'rising block tariffs' that start with a discounted price for the first 'block' of electricity (enough to meet essential household needs) but get more expensive the more you use.

[Stated example] More than half of the world's population uses this pricing system, including in Italy and California.

[Energy rationale] This pricing model encourages people who use a lot of electricity to reduce how much they use to stay within the cheapest block.

[Quality-of-life] This pricing model helps to tackle fuel poverty by providing cheaper electricity to cover the essentials and only charging more for excessive consumption.

The mean support rating for rising block electricity tariffs was 4.8 (SD=2). 62% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 23% opposed the policy (gave it a 3 or less); and 14% neither supported nor opposed it (rated it 4 on the scale; Figure 20).

## Figure 20. Distribution of support ratings for rising block electricity tariffs.

<!-- image -->

## Factors affecting support

Male gender was associated with giving a higher rating for this policy (OR=1.34, p=0.017). High household income (€ 120,000 or more) was associated with weaker support (OR=0.46, p=0.009; compared to the lowest income bracket (under €40,000) ). People in Connacht and Ulster were also less likely to be supportive than people in Dublin (OR=0.69, p=0.04). The number of people in the household had no association with support.

Climate priority again interacted with the Quality-of-life rationale. Among people for whom climate was lower priority, the mean rating in the Energy condition was 4.0 (SD=2.0), while in the Quality-of-life condition it was 4.8 (SD=2.0). There was no effect of the policy example manipulation.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses were ensuring fairness in terms of how much energy was covered in each block, avoiding larger bills for large lower income families, and ensuring exemptions are available for those that need them. The importance of clear communication of both tariffs and electricity consumption was emphasised too.

## Policy 14: Data centre ban extension

## Policy: A nationwide ban on new data centres until at least 2030.

[Stated example] Currently, no new data centres are allowed in the Dublin region until 2028.

[Energy rationale] Data centres already use 22% of all electricity used in Ireland. [Quality-of-life] Data centres take up large amounts of land that could be used to grow food or left wild, without creating many jobs. The strain they put on the grid increases risk of blackouts.

The mean support rating for extending the ban on new data centres was 5 (SD=1.9). 61% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 20% opposed the policy (gave it a 3 or less); and 19% neither supported nor opposed it (rated it 4 on the scale; Figure 21).

Figure 21. Distribution of support ratings for a data centre ban extension.

<!-- image -->

## Factors affecting support

Being aged 35-44 was associated with slightly higher support compared to being aged 45-54 (OR=1.6, p=0.01), while annual household income of € 40,000 -€ 80,000 was associated with reduced support compared to those on the lowest incomes (OR=0.69, p=0.02).

Interestingly, climate priority did not have an association with support for this policy (OR=0.98, p=0.91). This was one of only two policies for which this was true. The stated rationale manipulation had no influence either. However, the policy example manipulation did impact support to a small extent. Participants informed of the existing (at the time of the study) effective moratorium gave a mean rating of 5.2 (SD=1.86), while others gave a mean rating of 4.8 (SD=1.88), a difference that was statistically significant (OR=1.43, p=0.004).

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common response was to inform people about the high share of electricity used by data centres in Ireland.

## Policy 15: Air drying space in new housing

<!-- image -->

The mean support rating for regulating new builds to have space suitable for air-drying clothes was 5.8 (SD=1.6). 80% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 8% opposed the policy (gave it a 3 or less); and 12% neither supported nor opposed it (rated it 4 on the scale; Figure 22).

## Figure 22. Distribution of support ratings air drying space in new housing.

<!-- image -->

## Factors affecting support

People in very large homes (250m 2  or more) gave lower support ratings than those in small homes (OR=0.64, p=0.042), with men also giving lower ratings (OR=0.66, p=0.002), perhaps reflecting a lack of awareness of the importance of space and less responsibility for laundry. People aged 65+ were more supportive (OR=1.63, p=0.027; compared with the 45-54 age group).

There were no effects of either experimental manipulation on support.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common response was informing people about the energy-intensity of tumble dryers and of the benefits of having space to dry clothes naturally.

## Policy 16: Remove lit advertising &amp; reduce public lighting

<!-- image -->

The mean support rating for removing lit advertising and reducing public lighting was 5.3 (SD=1.8). 71% of respondents supported the policy (gave it a 5 or more on the 7-point scale); 15% opposed the policy (gave it a 3 or less); and 13% neither supported nor opposed it (rated it 4 on the scale; Figure 23).

Figure 23. Distribution of support ratings for the policy to remove lit advertising and reduce public lighting.

<!-- image -->

## Factors affecting support

There were no associations between support for this policy and age, gender, region, social grade, income, or type of area.

There were no effects of either experimental manipulation on support.

## Suggestions to increase support

When participants were asked what would increase support for this policy, the most common responses were about the public lighting aspect of the policy: participants emphasised proper consideration of what constituted necessary lighting.

## 4. Discussion

This study measured public support for energy sufficiency-oriented policies in a large and representative sample of people living in Ireland, as well as a wide range of potential influences on support. The discussion focuses on what types of factors (sociodemographic and participant characteristics, climate attitudes, policy attributes, extrinsic aspects of policy presentation) affected support for what types of policies, and what the significance of these results are. It also discusses the significance of a public widely underestimating support for policies that they themselves endorse.

## 4.1. Strong and broad support for sufficiency policies

All but two of the 16 policies presented (the frequent flyer tax and limits to new rural one-off housing) were majority supported. Sociodemographic differences in support were sparse. When modelling all policy responses together, the only difference was between age groups. People aged 65 and above were the most supportive on average, particularly compared with those aged 45-55. This difference persisted even when accounting for political views but disappeared when perceived fairness was added to the model, suggesting that a greater perceived fairness of policies drove the modestly greater support of those aged 65+. Small gender differences were also observed for several policies, but in different directions. Men were slightly less supportive of three of the most popular policies (the fourday week, regulating for adequate space to dry clothes, a sail &amp; rail subsidy), but more supportive of rising block energy tariffs and high-density housing.

Where individual characteristic associations were found, it was usually for policies with direct relevance to the subgroup in question. For example, people with pre-school children were slightly more supportive of the introduction of an e-cargo bike grant and those with higher incomes (who tend to consume more energy) were less likely to support rising block tariffs. These differences were almost always small, with some exceptions: people who flew more were considerably less supportive of a frequent flyer tax, and cyclists, relative to non-cyclists, were much more supportive of any policy directed towards motor vehicles, while people who drove at least weekly were more likely to oppose them.

The only participant characteristic with a consistent and meaningful impact on support was the level of priority participants thought should be given to climate change by the Government. We adapted a measure from the EPA Climate Change in the Irish Mind (CCIM) study. Interestingly, responses differed considerably between our sample and the CCIM sample, such that respondents to our study were less likely to give high priority to climate (59% compared to 78%). This is likely partly due to the fact we asked participants to rate the importance of other policy issues before answering this question. Still, three in five in our sample thought climate should be a 'high' or 'very high' priority , and this group were more supportive of all but two policies: the extension of a ban on new data centres and a fourday week.

Importantly, while people in the centre and on the right of the political spectrum were less supportive than those on the left, supporters of current government parties were no less supportive than everyone else, suggesting that fears of voter punishment for implementing these types of policies would not be supported by evidence.

In sum, support for the presented policies was high among all groups. And notably, this was true regardless of how policies were framed, as evidenced by the little overall effect of our experimental manipulations, indicating a high degree of stability in these opinions. It is reasonable to conclude then that energy sufficiency policies are, in general, popular policies in Ireland. Indeed, the lack of

sociodemographic differences in support was striking, and would likely be a helpful aspect to include when communicating a given policy measure to the public.

## 4.2. Perceived policy fairness is most important but not always predictable

As noted in the introduction, sufficiency policies are designed to tackle higher consumption and consider issues of equity and fairness, which research to date has shown is the most important factor in predicting public support. We replicate this finding here: the association between perceived fairness of a policy and support for that policy dwarfed the next biggest predictor, which was perceived effectiveness of the policy. In other words, whether a person thinks a policy will work is less important to them than whether they think it is fair, even if climate is a high priority for them.

We measured general perceptions of fairness only. But different types of fairness exist, e.g. distributional fairness and procedural fairness. In other words, there are different ways in which people can think about the fairness of a given policy, and research evidence is not yet clear on which ones are most important in the context of support. The (lack of) support for a frequent flyer tax is perhaps a good case through which to consider these points. Ostensibly, it was one of the fairest policies we presented to participants from a distributional perspective. It is in effect a progressive form of carbon tax. It would have affected less than a quarter of people -the group who fly at least three times a year and are therefore likely wealthier and responsible for a disproportionate share of emissions. But it was perceived as the third least fair policy and was the second least supported. There are several possible explanations for this. International travel is an aspiration for many people, and people may have been responding from the point of view of their future self. Others may simply not think it is fair that people flying more should have to pay extra. But further research into predictors of perceptions of fairness of both frequent flyer taxes and other polices is needed, and particularly important given the centrality of fairness to policy support.

## 4.3. Support is sometimes boosted by highlighting policy co-benefits

As mentioned above, participants who did not think climate change should be a high priority for the government tended to support policies less than those who did. For this low-priority group, support was higher when given the Quality-of-Life policy rationale relative to the Energy rationale, on average. In particular, the Quality-of-Life rationale boosted their support for some built environment policies (highdensity housing, maximum office temperature settings, and, to a less certain extent, limits on rural one-off housing), for multiple transport policies (the frequent flyer tax, congestion charges, and car restrictions in urban areas), and for rising block electricity tariffs. Notably, many of these policies are restrictive in nature and lower in overall popularity. It is interesting that where the Quality-of-life rationale had an effect, the Combination rationale usually did not. This suggests that rather than the presence of co-benefits, it is the lack of energy or climate language that boosted support, at least for a subset of people.

Providing existing examples of policies made no meaningful difference to support in most cases, other than a modest boost to support for a data centre ban extension and for congestion charges. This and the heterogeneity of effects of providing a rationale based on co-benefits point to a need for case-bycase assessment of policy communication rather than a one-size-fits-all approach.

## 4.4. Alignment of current policy with public opinion is mixed

Our results show that some recent policy developments are more in line with public opinion than others. Some policies that were supported align with recent developments, and less-supported policies

are similar to ones being rolled back. On the other hand, the public did support several policies that are counter to recent developments.

One real-world policy development that our sample supported is the increased car restrictions (via pedestrianisation and reduction of parking space) that is taking place in certain areas. While relatively less popular amongst our set of policies, it was still majority supported (55% vs 32% opposed) and thus would appear to be welcomed by most people in Ireland. A measure increasingly seen in policy discussion, and called for by the Just Transition Commission, 62  is a vehicle mass tax. Again, this was relatively less popular than other policies we asked people about, but majority-supported all the same (55% vs 31% opposed). Congestion charges recently cited in media reports as being under consideration in Dublin to ease worsening traffic issues also had more support than opposition (50% vs 36% opposed). Incidentally, congestion charges tend to enjoy greater real-world approval postimplementation. 63  Combatting urban sprawl is a CAP priority to reduce kilometres travelled, especially by car. High-density building is an effective way to do both and was supported by most people. Limiting rural housing though is considered by most experts as crucial to reduce private car mileage and was not supported by our sample. This is a point of convergence with policy development however, as restrictions were recently amended.

On the other hand, the public mostly diverge from recent data centre policy development, with most (61%) supporting a hypothetical nationwide ban until at least 2030. Also, while the frequent flyer tax was not majority-supported (i.e. fewer than half of responses scored it a 5 or more on the 7-point scale), it too had more support (45%) than opposition (39%). However, government recently moved to remove the passenger cap at Dublin Airport. Support for a Sail &amp; Rail travel subsidy was strongly supported (78%) and if uptake was high, this could significantly reduce emissions from aviation given the frequency of trips from Dublin to the UK. There are important barriers besides cost to consider however, and this is not a measure currently under consideration.

## 4.5. People consistently underestimate support for policies

The number of people who supported polices was substantially greater than the number of people who perceived majority support for 15 of 16 polices. In other words, while most people supported most of the policies, relatively few believed that this would true. The average difference across those 16 policies between the share of people who supported a policy, and the number of people who thought most others would support it, was 25 percentage points. While this has not been demonstrated before in a set of policies this large and diverse, or in policies that are sufficiency-oriented, it is consistent with a number of previous studies on climate policy. 64,65,66  Interestingly however, we note an important nuance. While opposition to policies was overestimated, much of the difference between actual and perceived support was composed of perceived uncertainty on the part of others. People were more likely to be unsure about the opinion of others (or think they were indifferent) than think they opposed them outright.

62 Just Transition Commission (2026). Towards a Just Transition in Transport. https://justtransitioncommission.ie/wpcontent/uploads/2026/05/JTC\_Transport\_Report\_2026-05-28-.pdf

63 Börjesson, M., Eliasson, J., &amp; Hamilton, C. (2016). Why experience changes attitudes to congestion pricing: The case of Gothenburg. Transportation Research Part A: Policy and Practice , 85 , 1-16. https://doi.org/10.1016/j.tra.2015.12.002 Poortinga, W. (2025). The role of policy appraisals and second-order beliefs in public support for climate policies in the UK.

64 Climate Policy, 1 -15. https://doi.org/10.1080/14693062.2025.2539977

65 Andre, P., Boneva, T., Chopra, F., &amp; Falk, A. (2024). Globally representative evidence on the actual and perceived support for climate action. Nature Climate Change, 14(3), 253 -259. https://doi.org/10.1038/s41558-024-01925-3

66 Sparkman, G., Geiger, N., &amp; Weber, E. U. (2022). Americans experience a false social reality by underestimating popular climate policy support by nearly half. Nature communications , 13 (1), 4779. https://doi.org/10.1038/s41467-022-32412-y

A 'spiral of silence' has been theorise d in relation to climate support. Media and public discourse tend to be negative, which makes people less likely to voice positive views, which in turn biases public discourse towards negativity. Our participants were not reticent to share opinions, even when they thought their opinion was a minority one. We had reasoned that a lower willingness to share opinions perceived as unpopular would explain (at least in part) differences between actual and perceived support. But while perception gaps were large, the difference in willingness to share perceived majority views compared to perceived minority views was less so. A potential alternative explanation is that while happy to share any views on climate and energy, most people simply do not have the opportunity to do so, and that most of the policies we presented to people are things that most of the public rarely think about.

## 4.6. Conclusion

This study has added to the growing literature showing strong public support for climate policies, which is systematically underestimated. Our results demonstrate that this support extends to a large set of sufficiency-oriented measures that reduce or avoid the need for energy use in the first place. While some types of policies were naturally less popular than others, overall levels of support were generally high and consistent across people with varying backgrounds, characteristics, and political orientation. Our results should not in all cases, however, be taken as support for exact policies -a study like this cannot present enough detail about a given policy to make claims about a real-world implementation with all the nuances that would entail -but rather as support for these types of policies and their aims. A clear message that emerges is that consideration of equity and fairness in policy design is crucial to maximise public support. Careful targeting of supports and policies is part of this.

If Ireland is to meet its emissions targets, sufficiency policies are a wholly necessary part of the policy package. This research has demonstrated that the public supports the introduction of many of these types of policies and measures. With the consequences of climate change increasingly visible and felt on our shores, it is a matter of urgency that polices to reduce the demand for energy are enacted rapidly.

## Appendix

## Appendix 1: Sample characteristics

Table A1. Sociodemographic and household characteristics of the sample.

| Variable                        | Category                            | %    |
|---------------------------------|-------------------------------------|------|
| Gender                          | Female                              | 54%  |
| Gender                          | Male                                | 45%  |
| Gender                          | Other                               | 0.6% |
| Gender                          | Prefer not to say                   | 0.2% |
| Age                             | 45 - 54                             | 21%  |
| Age                             | 18 - 24                             | 10%  |
| Age                             | 25 - 34                             | 17%  |
| Age                             | 35 - 44                             | 20%  |
| Age                             | 55 - 64                             | 16%  |
| Age                             | 65+                                 | 17%  |
| Social grade                    | ABC1                                | 49%  |
| Social grade                    | C2DEF                               | 51%  |
| Education                       | Degree                              | 27%  |
| Education                       | Diploma                             | 16%  |
| Education                       | Leaving Certificate (or equivalent) | 23%  |
| Education                       | Less than Leaving Certificate       | 6%   |
| Education                       | Postgraduate degree                 | 14%  |
| Education                       | Technical/Vocational Certificate    | 14%  |
| Employment                      | Employed full time                  | 48%  |
| Employment                      | Employed part time                  | 15%  |
| Employment                      | Homemaker/carer                     | 8%   |
| Employment                      | Retired                             | 15%  |
| Employment                      | Self-employed                       | 3%   |
| Employment                      | Student                             | 4%   |
| Employment                      | Unable to work                      | 4%   |
| Employment                      | Unemployed                          | 3%   |
| Income (household annual gross) | Under €40,000                       | 31%  |
| Income (household annual gross) | €40,000 -80,000                     | 35%  |
| Income (household annual gross) | €80,000 - €120,000                  | 17%  |
| Income (household annual gross) | €120,000 or more                    | 6%   |
| Income (household annual gross) | Don't know                          | 4%   |
| Income (household annual gross) | Prefer not to say                   | 7%   |

| Variable                       | Category                       | %    |
|--------------------------------|--------------------------------|------|
| Household size                 | 1                              | 14%  |
| Household size                 | 2                              | 27%  |
| Household size                 | 3                              | 21%  |
| Household size                 | 4                              | 23%  |
| Household size                 | 5+                             | 15%  |
| Region                         | Dublin                         | 30%  |
| Region                         | Leinster (excluding Dublin)    | 28%  |
| Region                         | Munster                        | 26%  |
| Region                         | Connacht                       | 12%  |
| Region                         | Ulster                         | 5%   |
| Area                           | City centre                    | 10%  |
| Area                           | City suburb                    | 29%  |
| Area                           | Satellite/Commuter town        | 8%   |
| Area                           | Other large town               | 15%  |
| Area                           | Small town or village          | 17%  |
| Area                           | Rural area                     | 22%  |
| Tenure                         | Own home                       | 65%  |
| Tenure                         | Renting                        | 27%  |
| Tenure                         | Other                          | 8%   |
| House type                     | Apartment/flat/bedsit          | 11%  |
| House type                     | Detached house                 | 39%  |
| House type                     | Semi-detached/end of terrace   | 35%  |
| House type                     | Terraced house                 | 14%  |
| House type                     | Mobile home/temporary building | 0.3% |
| House size                     | Under 100 m 2                  | 16%  |
| House size                     | 100 m 2 -150 m 2               | 18%  |
| House size                     | 150 m 2 -250 m 2               | 21%  |
| House size                     | 250 m 2 or more                | 21%  |
| House size                     | Don't know                     | 24%  |
| Children under 18 in household | Children under 18 in household | 37%  |
| Disability in household        | Disability in household        | 38%  |

## Table A2. Mobility variables.

| Variable                          | Category             | %    |
|-----------------------------------|----------------------|------|
| Car use                           | Daily                | 59%  |
|                                   | At least once a week | 26%  |
|                                   | Less often           | 7%   |
|                                   | Never                | 8%   |
| Bike use                          | Daily                | 4%   |
|                                   | At least once a week | 9%   |
|                                   | Less often           | 13%  |
|                                   | Never                | 74%  |
| Personal flights (annual, return) | 0                    | 22%  |
|                                   | 1                    | 30%  |
|                                   | 2                    | 26%  |
|                                   | 3                    | 10%  |
|                                   | 4                    | 6%   |
|                                   | 5+                   | 5%   |
| Work flights (annual, return)     | 0                    | 88%  |
|                                   | 1                    | 6%   |
|                                   | 2                    | 3%   |
|                                   | 3                    | 1.4% |
|                                   | 4                    | 0.8% |
|                                   | 5+                   | 1.3% |

## Appendix 2: Fairness and effectiveness ratings of policies

## Perceived fairness of each policy

<!-- image -->

## Perceived effectiveness of each policy

<!-- image -->

## Appendix 3: Regression modelling results

This appendix has three parts. The first (3A) displays modelling results of pooled support responses. We report five separate ordinal logistic regressions of overall policy support referred to in the main text. These models account for multiple responses from each participant using clustered standard errors and random intercepts by participant. The second part (3B) displays the results of modelling for willingness to share policy opinions. The model is the same type as used for support. The third part (3C) displays models of support for each of the 16 policies. In tables showing models of support, we have excluded the 'Don't know' and 'Prefer not to say' categor ies of income response given the difficulty in interpreting these, but these responders are included in the models themselves.

To describe estimates and certainty of model results, we report odds ratios (ORs), p values, and confidence intervals. An odds ratio indicates the strength of the relationship between a predictor variable (e.g. age or stated rationale) and outcome variable (support). Specifically, it is an estimate of the change in odds of a change in the outcome (support) that occurs from being in one group compared to another group. An OR of 1 indicates no change in odds, i.e. the predictor variable has no association with the outcome. An OR greater than 1 indicates a positive relationship, i.e. a change in the predictor increases the odds of an outcome (support) being higher. And an OR less than 1 reduces the odds of the outcome (support) being higher.

A confidence interval provides a measure of certainty about the precision of the odds ratio estimate. The confidence interval is a range of values within which the true odds ratio is likely to sit. A wide range of values indicates a lower certainty that the estimate is particularly close to the true value. We use a 95% confidence interval, which is standard in this kind of research, which means that if the study were run 100 times, we would expect the range to capture the true value in 95 of the ranges produced.

A p-value is a number that indicates how likely the result is to happen by random chance. Smaller values (a threshold of .05 is widely used) means the result is likely to be genuine as opposed to occurring by chance.

## 3A: Overall support ratings, pooled

Table A3. Model outputs of the five ordinal logistic regressions of overall policy support referred to in the main text. Model 1 includes sociodemographic and experimental manipulation variables. Model 2 adds political support variables. Model 3 includes sociodemographic, climate knowledge and priority, and experimental manipulations variables. Model 4 adds an interaction term for stated rationale and climate priority. Model 5 adds policy attributes.

|                                         |                          | Model 1             | Model 2             |
|-----------------------------------------|--------------------------|---------------------|---------------------|
|                                         |                          | OR [95% CI]         | OR [95% CI]         |
| Gender (ref. Female/Other)              | Male                     | 1.03 [0.92,1.14]    | 1.05 [0.94,1.17]    |
| Age (ref. 45-54)                        | 18 - 24                  | 1.15 [0.94,1.4]     | 1.07 [0.88,1.32]    |
| Age (ref. 45-54)                        | 25 - 34                  | 1.09 [0.91,1.31]    | 1.04 [0.87,1.25]    |
| Age (ref. 45-54)                        | 35 - 44                  | 1.03 [0.87,1.22]    | 1.01 [0.86,1.2]     |
| Age (ref. 45-54)                        | 55 - 64                  | 1.14 [0.94,1.38]    | 1.15 [0.95,1.39]    |
| Age (ref. 45-54)                        | 65+                      | 1.43*** [1.19,1.73] | 1.44*** [1.2,1.74]  |
| Region (ref. Dublin)                    | Rest of Leinster         | 0.97 [0.84,1.11]    | 0.96 [0.84,1.11]    |
| Region (ref. Dublin)                    | Munster                  | 1 [0.86,1.16]       | 1 [0.86,1.16]       |
| Region (ref. Dublin)                    | Connacht/Ulster          | 0.86. [0.73,1.01]   | 0.85* [0.72,1]      |
| Social grade (ref. ABC1)                | C2DEF                    | 1.08 [0.96,1.21]    | 1.02 [0.91,1.14]    |
| Household income (ref. < € 40,000)      | €40,000 - €80,000        | 0.88. [0.77,1.01]   | 0.88. [0.77,1.01]   |
| Household income (ref. < € 40,000)      | €80,000 - €120,000       | 0.95 [0.8,1.13]     | 0.94 [0.79,1.11]    |
| Household income (ref. < € 40,000)      | €120,000 or more         | 0.92 [0.7,1.22]     | 0.92 [0.7,1.21]     |
| Household composition (ref. Live alone) | Two adults               | 1.02 [0.85,1.22]    | 1 [0.84,1.2]        |
| Household composition (ref. Live alone) | Household with children  | 1.08 [0.91,1.28]    | 1.11 [0.94,1.31]    |
| Household composition (ref. Live alone) | Three+ adults (no child) | 1.14 [0.92,1.4]     | 1.13 [0.92,1.39]    |
| Support government party (ref. No)      | Yes                      |                     | 1.01 [0.9,1.14]     |
| Political orientation (ref. 1-2 (Left)) | 3 (Left of centre)       |                     | 0.86 [0.7,1.05]     |
| Political orientation (ref. 1-2 (Left)) | 4 (Centre)               |                     | 0.63*** [0.53,0.76] |
| Political orientation (ref. 1-2 (Left)) | 5 (Right of centre)      |                     | 0.58*** [0.47,0.71] |
| Political orientation (ref. 1-2 (Left)) | 6-7 (Right)              |                     | 0.52*** [0.39,0.69] |
| Stated Rationale (ref. Energy)          | Quality-of-life (QoL)    | 1.02 [0.9,1.16]     | 1.03 [0.91,1.17]    |
| Stated Rationale (ref. Energy)          | Combination              | 1.02 [0.89,1.16]    | 1.02 [0.89,1.16]    |
| Policy example (ref. Not stated)        | Example stated           | 1.14*** [1.07,1.21] | 1.14*** [1.07,1.21] |
| Observations                            |                          | 14,400              | 14,400              |

S ignificance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

|                                                                 |                                              | Model 3             | Model 4             | Model 5             |
|-----------------------------------------------------------------|----------------------------------------------|---------------------|---------------------|---------------------|
|                                                                 |                                              | OR [95% CI]         | OR [95% CI]         | OR [95% CI]         |
| Gender                                                          | Male                                         | 1.03 [0.93,1.14]    | 1.03 [0.93,1.14]    | 0.98 [0.89,1.08]    |
| Age (ref. 45-54)                                                | 18 - 24                                      | 1.09 [0.9,1.33]     | 1.08 [0.89,1.31]    | 0.86. [0.71,1.03]   |
| Age (ref. 45-54)                                                | 25 - 34                                      | 1.09 [0.92,1.29]    | 1.08 [0.91,1.28]    | 0.78** [0.66,0.92]  |
| Age (ref. 45-54)                                                | 35 - 44                                      | 1.06 [0.91,1.24]    | 1.05 [0.9,1.23]     | 0.95 [0.83,1.1]     |
| Age (ref. 45-54)                                                | 55 - 64                                      | 1.02 [0.86,1.22]    | 1.03 [0.86,1.23]    | 1.05 [0.9,1.23]     |
| Age (ref. 45-54)                                                | 65+                                          | 1.2* [1,1.42]       | 1.19* [1,1.42]      | 0.92 [0.79,1.08]    |
| Region (ref. Dublin)                                            | Rest of Leinster                             | 0.98 [0.85,1.12]    | 0.97 [0.85,1.11]    | 1.08 [0.96,1.22]    |
| Region (ref. Dublin)                                            | Munster                                      | 1.01 [0.88,1.15]    | 1 [0.87,1.15]       | 1.02 [0.9,1.15]     |
| Region (ref. Dublin)                                            | Connacht/Ulster                              | 0.88 [0.76,1.03]    | 0.88. [0.75,1.02]   | 1.01 [0.88,1.16]    |
| Social grade (ref. ABC1)                                        | C2DEF                                        | 0.99 [0.88,1.1]     | 0.98 [0.88,1.1]     | 1.1. [1,1.22]       |
| Household income (ref. < €40,000 )                              | €40,000 - €80,000                            | 0.86* [0.76,0.98]   | 0.87* [0.76,0.98]   | 0.94 [0.84,1.06]    |
| Household income (ref. < €40,000 )                              | €80,000 - €120,000                           | 0.85. [0.73,1]      | 0.85. [0.73,1]      | 1.02 [0.87,1.19]    |
| Household income (ref. < €40,000 )                              | €120,000 or more                             | 0.77* [0.59,1]      | 0.78. [0.6,1.01]    | 1.08 [0.86,1.37]    |
| Household composition (ref. Live alone)                         | Two adults                                   | 1.05 [0.89,1.25]    | 1.05 [0.89,1.24]    | 0.92 [0.79,1.07]    |
| Household composition (ref. Live alone)                         | Household with children                      | 1.15. [0.98,1.35]   | 1.15. [0.98,1.34]   | 0.92 [0.79,1.08]    |
| Household composition (ref. Live alone)                         | Three+ adults (no child)                     | 1.16 [0.95,1.41]    | 1.16 [0.95,1.41]    | 0.88 [0.73,1.07]    |
| Climate priority (ref. High/Very High)                          | Low/Medium                                   | 0.48*** [0.43,0.53] | 0.42*** [0.35,0.5]  | 0.82* [0.69,0.97]   |
| Self-rated energy saving understanding (1-7)                    | Self-rated energy saving understanding (1-7) | 1.2*** [1.14,1.25]  | 1.2*** [1.14,1.25]  | 1.06** [1.02,1.11]  |
| Perception of emissions (ref. staying the same)                 | Going down                                   | 1.19* [1.03,1.36]   | 1.18* [1.03,1.36]   | 1.12. [0.99,1.26]   |
| Perception of emissions (ref. staying the same)                 | Going up                                     | 1.2** [1.06,1.36]   | 1.2** [1.06,1.36]   | 1.16** [1.04,1.3]   |
| Climate knowledge                                               | Sectoral emissions (0-6)                     | 1.05* [1.01,1.09]   | 1.05* [1.01,1.09]   | 0.99 [0.95,1.03]    |
| Climate knowledge                                               | Effective actions (0-5)                      | 1.06* [1.01,1.1]    | 1.06* [1.01,1.1]    | 1.06** [1.02,1.11]  |
| Policy type (ref. Enabling)                                     | Restrictive                                  |                     |                     | 0.78*** [0.73,0.84] |
| Perceived fairness of policy (1-7)                              | Perceived fairness of policy (1-7)           |                     |                     | 4.29*** [4.02,4.58] |
| Perceived effectiveness of policy (1-7)                         | Perceived effectiveness of policy (1-7)      |                     |                     | 2.26*** [2.13,2.39] |
| Stated rationale (ref. Energy)                                  | Quality-of-life (QoL)                        | 1.03 [0.91,1.16]    | 0.89 [0.77,1.04]    | 0.86* [0.75,0.99]   |
| Stated rationale (ref. Energy)                                  | Combination                                  | 1.04 [0.92,1.17]    | 1.01 [0.87,1.18]    | 0.98 [0.85,1.14]    |
| Stated rationale*Climate priority (ref. Energy, High/Very high) | QoL*Low/Medium                               |                     | 1.43** [1.12,1.83]  | 1.05 [0.84,1.32]    |
| Stated rationale*Climate priority (ref. Energy, High/Very high) | Combination*Low/Medium                       |                     | 1.06 [0.83,1.36]    | 1.07 [0.86,1.35]    |
| Policy example (ref. Not stated)                                | Example stated                               | 1.14*** [1.07,1.21] | 1.14*** [1.07,1.21] | 0.82*** [0.77,0.88] |
| Observations                                                    |                                              | 14,400              | 14,400              | 14,400              |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## 3B: Willingness to share policy opinions

Table A4. Model outputs of the five ordinal logistic regressions of willingness to share opinions with others (3 level outcome variable: Would not share; Would share with like-minded people; Would share with anyone) referred to in the main text.

|                                             |                                    | OR [95% CI]          |
|---------------------------------------------|------------------------------------|----------------------|
| Gender                                      | Male                               | 1.43** [1.12, 1.83]  |
| Age (ref. 45-54)                            | 18 - 24                            | 0.39*** [0.24, 0.64] |
| Age (ref. 45-54)                            | 25 - 34                            | 0.49*** [0.33, 0.73] |
| Age (ref. 45-54)                            | 35 - 44                            | 0.5*** [0.35, 0.72]  |
| Age (ref. 45-54)                            | 55 - 64                            | 1.32 [0.87, 2]       |
| Age (ref. 45-54)                            | 65+                                | 1.72* [1.13, 2.62]   |
| Region (ref. Dublin)                        | Rest of Leinster                   | 1.14 [0.84, 1.56]    |
| Region (ref. Dublin)                        | Munster                            | 0.79 [0.58, 1.09]    |
| Region (ref. Dublin)                        | Connacht/Ulster                    | 0.5*** [0.35, 0.72]  |
| Social grade (ref. C2DEF)                   | ABC1                               | 1.41** [1.09, 1.83]  |
| Household income (ref. € 40,000)            | €40,000 - €80,000                  | 1.81*** [1.32, 2.47] |
| Household income (ref. € 40,000)            | €80,000 - €120,000                 | 2.54*** [1.72, 3.77] |
| Household income (ref. € 40,000)            | €120,000 or more                   | 4.03*** [2.37, 6.86] |
| Household income (ref. € 40,000)            | Don't know                         | 0.66 [0.3, 1.47]     |
| Household income (ref. € 40,000)            | Prefer not to say                  | 0.28*** [0.16, 0.5]  |
| Household composition (ref. Live alone)     | Two adults                         | 0.94 [0.63, 1.42]    |
| Household composition (ref. Live alone)     | Household with children            | 0.48*** [0.32, 0.7]  |
| Household composition (ref. Live alone)     | Three or more adults (no children) | 1.2 [0.72, 1.99]     |
| Policy type (ref. Enabling)                 | Restrictive policy                 | 0.93 [0.84, 1.03]    |
| Perceived own opinion as majority (ref. No) | Yes                                | 2.27*** [1.99, 2.58] |
| Climate literacy                            | Sectoral emissions (0-6)           | 0.89* [0.81, 0.99]   |
| Climate literacy                            | Effective actions (0-5)            | 1.33*** [1.19, 1.48] |
| Support (ref. 1 Fully oppose)               | 2                                  | 0.45*** [0.32, 0.63] |
| Support (ref. 1 Fully oppose)               | 3                                  | 0.32*** [0.24, 0.44] |
| Support (ref. 1 Fully oppose)               | 4                                  | 0.25*** [0.19, 0.34] |
| Support (ref. 1 Fully oppose)               | 5                                  | 0.62** [0.46, 0.83]  |
| Support (ref. 1 Fully oppose)               | 6                                  | 1.01 [0.75, 1.36]    |
| Support (ref. 1 Fully oppose)               | 7 Fully support                    | 2.79*** [2.08, 3.74] |
| Observations                                | 14,400                             | 14,400               |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## 3C: Models of support for each policy

For each policy we modelled support using two ordinal logistic regression models. The outcome variable was a 5-level recategorisation of the 7-point variable used for the overall models above to ensure the assumption of proportional odds was satisfied.

Model 1 includes sociodemographic variables, as well as variables specific to the policy in question (e.g. for the frequent flyer tax policy model, we include the number of return flights the person takes annually), and the experimental manipulations. In Model 2, we add an interaction term for stated rationale and climate priority.

## Policy 1: Sail &amp; Rail travel subsidy

|                                                           |                        | Model 1            | Model 2            |
|-----------------------------------------------------------|------------------------|--------------------|--------------------|
|                                                           |                        | OR [95% CI]        | OR [95% CI]        |
| Gender (ref. Female/Other)                                | Male                   | 0.76* [0.59, 0.98] | 0.8. [0.62, 1.04]  |
| Age (ref. 45-54)                                          | 18 - 24                | 0.91 [0.56, 1.47]  | 0.87 [0.54, 1.41]  |
| Age (ref. 45-54)                                          | 25 - 34                | 0.88 [0.58, 1.34]  | 0.89 [0.59, 1.36]  |
| Age (ref. 45-54)                                          | 35 - 44                | 0.81 [0.54, 1.21]  | 0.8 [0.53, 1.2]    |
| Age (ref. 45-54)                                          | 55 - 64                | 0.84 [0.55, 1.29]  | 0.8 [0.52, 1.22]   |
| Age (ref. 45-54)                                          | 65+                    | 0.87 [0.56, 1.35]  | 0.83 [0.53, 1.29]  |
| Social grade (ref. ABC1)                                  | C2DEF                  | 0.95 [0.72, 1.25]  | 1.01 [0.76, 1.33]  |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000      | 0.82 [0.59, 1.14]  | 0.86 [0.62, 1.2]   |
|                                                           | €80,000 - €120,000     | 0.64* [0.42, 0.98] | 0.62* [0.4, 0.94]  |
|                                                           | €120,000 or more       | 1.11 [0.61, 2.01]  | 1.07 [0.59, 1.96]  |
| Disability in household (ref. No)                         | Yes                    | 1.17 [0.9, 1.52]   | 1.16 [0.89, 1.52]  |
| Annual return flights (ref. 0)                            | 1                      | 1.1 [0.78, 1.57]   | 1.07 [0.75, 1.52]  |
| Annual return flights (ref. 0)                            | 2                      | 1.11 [0.76, 1.63]  | 1.11 [0.76, 1.62]  |
| Annual return flights (ref. 0)                            | 3                      | 1.02 [0.63, 1.65]  | 1.03 [0.63, 1.68]  |
| Annual return flights (ref. 0)                            | 4                      | 1.05 [0.6, 1.84]   | 1.06 [0.61, 1.87]  |
| Annual return flights (ref. 0)                            | 5 or more              | 0.7 [0.42, 1.18]   | 0.73 [0.43, 1.22]  |
| Lives close to ferry port (ref. No)                       | Yes                    | 1.14 [0.88, 1.46]  | 1.12 [0.87, 1.45]  |
| Children in home (ref. No)                                | Yes                    | 1.14 [0.86, 1.52]  | 1.18 [0.89, 1.58]  |
| Stated rationale (ref. Energy)                            | Quality-of-life (QoL)  | 1.06 [0.78, 1.43]  | 0.91 [0.6, 1.37]   |
| Stated rationale (ref. Energy)                            | Combination            | 1.17 [0.87, 1.58]  | 1.3 [0.87, 1.94]   |
| Climate priority (ref. High/Very high)                    | Low/Medium             |                    | 0.58* [0.37, 0.89] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium         |                    | 1.45 [0.79, 2.69]  |
| high)                                                     | Combination*Low/Medium |                    | 0.79 [0.43, 1.44]  |
| Existing policy (ref. Not stated)                         | Example stated         | 1.25. [0.97, 1.59] | 1.24. [0.97, 1.59] |
| Observations                                              |                        | 908                | 908                |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 2: Frequent flyer tax

|                                                           |                        | Model 1              | Model 2              |
|-----------------------------------------------------------|------------------------|----------------------|----------------------|
|                                                           |                        | OR [95% CI]          | OR [95% CI]          |
| Gender (ref. Female/Other)                                | Male                   | 1.03 [0.81, 1.31]    | 1.04 [0.82, 1.33]    |
| Age (ref. 45-54)                                          | 18 - 24                | 1.57* [1.01, 2.43]   | 1.33 [0.85, 2.08]    |
| Age (ref. 45-54)                                          | 25 - 34                | 1.18 [0.8, 1.72]     | 1.1 [0.75, 1.62]     |
| Age (ref. 45-54)                                          | 35 - 44                | 0.73. [0.5, 1.05]    | 0.73. [0.51, 1.06]   |
| Age (ref. 45-54)                                          | 55 - 64                | 1.29 [0.85, 1.95]    | 1.14 [0.75, 1.74]    |
| Age (ref. 45-54)                                          | 65+                    | 1.41. [0.95, 2.08]   | 1.28 [0.87, 1.9]     |
| Region (ref. Dublin)                                      | Rest of Leinster       | 0.86 [0.63, 1.18]    | 0.88 [0.64, 1.21]    |
| Region (ref. Dublin)                                      | Munster                | 0.9 [0.65, 1.23]     | 0.9 [0.66, 1.25]     |
| Region (ref. Dublin)                                      | Connacht/Ulster        | 0.91 [0.63, 1.31]    | 0.89 [0.62, 1.3]     |
| Social grade (ref. ABC1)                                  | C2DEF                  | 0.9 [0.7, 1.17]      | 0.97 [0.75, 1.26]    |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000      | 1.12 [0.83, 1.53]    | 1.1 [0.8, 1.5]       |
| Household income (ref. < €40,000 )                        | €80,000 - €120,000     | 1.18 [0.79, 1.75]    | 1.12 [0.75, 1.67]    |
| Household income (ref. < €40,000 )                        | €120,000 or more       | 1.56 [0.9, 2.72]     | 1.33 [0.75, 2.35]    |
| Annual return flights (ref. 0)                            | 1                      | 0.79 [0.55, 1.12]    | 0.77 [0.54, 1.1]     |
| Annual return flights (ref. 0)                            | 2                      | 0.48*** [0.33, 0.69] | 0.43*** [0.3, 0.63]  |
| Annual return flights (ref. 0)                            | 3                      | 0.19*** [0.12, 0.29] | 0.18*** [0.11, 0.29] |
| Annual return flights (ref. 0)                            | 4                      | 0.1*** [0.05, 0.17]  | 0.1*** [0.06, 0.18]  |
| Annual return flights (ref. 0)                            | 5 or more              | 0.17*** [0.1, 0.28]  | 0.16*** [0.1, 0.27]  |
| Stated rationale (ref. Energy)                            | Quality-of-life (QoL)  | 0.81 [0.61, 1.08]    | 0.63* [0.43, 0.93]   |
| Stated rationale (ref. Energy)                            | Combination            | 0.88 [0.66, 1.18]    | 0.78 [0.53, 1.13]    |
| Climate priority (ref. High/Very high)                    | Low/Medium             |                      | 0.25*** [0.16, 0.38] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium         |                      | 1.9* [1.05, 3.44]    |
| high)                                                     | Combination*Low/Medium |                      | 1.38 [0.76, 2.52]    |
| Existing policy (ref. Not stated)                         | Example stated         | 1.16 [0.92, 1.47]    | 1.18 [0.93, 1.49]    |
| Observations                                              |                        | 924                  | 924                  |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 3: Four-day week

|                                                           |                          | Model 1            | Model 2            |
|-----------------------------------------------------------|--------------------------|--------------------|--------------------|
|                                                           |                          | OR [95% CI]        | OR [95% CI]        |
| Gender (ref. Female/Other)                                | Male                     | 0.74* [0.56, 0.98] | 0.74* [0.56, 0.98] |
| Age (ref. 45-54)                                          | 18 - 24                  | 1.02 [0.58, 1.79]  | 0.98 [0.56, 1.73]  |
| Age (ref. 45-54)                                          | 25 - 34                  | 0.84 [0.54, 1.31]  | 0.83 [0.53, 1.3]   |
| Age (ref. 45-54)                                          | 35 - 44                  | 1.11 [0.71, 1.73]  | 1.12 [0.71, 1.75]  |
| Age (ref. 45-54)                                          | 55 - 64                  | 0.62. [0.38, 1]    | 0.61* [0.38, 0.99] |
| Age (ref. 45-54)                                          | 65+                      | 0.51* [0.3, 0.86]  | 0.5** [0.29, 0.84] |
| Region (ref. Dublin)                                      | Rest of Leinster         | 1.16 [0.81, 1.67]  | 1.16 [0.8, 1.67]   |
| Region (ref. Dublin)                                      | Munster                  | 1.1 [0.76, 1.59]   | 1.09 [0.75, 1.59]  |
| Region (ref. Dublin)                                      | Connacht/Ulster          | 0.93 [0.61, 1.41]  | 0.93 [0.61, 1.42]  |
| Social grade (ref. ABC1)                                  | C2DEF                    | 0.98 [0.72, 1.32]  | 1 [0.74, 1.35]     |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000        | 1.05 [0.74, 1.5]   | 1.04 [0.73, 1.48]  |
| Household income (ref. < €40,000 )                        | €80,000 - €120,000       | 1.2 [0.76, 1.91]   | 1.17 [0.74, 1.87]  |
| Household income (ref. < €40,000 )                        | €120,000 or more         | 1.17 [0.61, 2.31]  | 1.12 [0.59, 2.22]  |
| Driving frequency (ref. Less than weekly)                 | Uses car at least weekly | 0.78 [0.52, 1.17]  | 0.79 [0.52, 1.18]  |
| Working pattern (ref. Not in employment outside the       | Employed & always WFH    | 0.99 [0.57, 1.73]  | 0.97 [0.56, 1.7]   |
| home/student)                                             | Employed & sometimes WFH | 1.32 [0.83, 2.11]  | 1.31 [0.82, 2.11]  |
| home/student)                                             | Employed & never WFH     | 1.15 [0.79, 1.66]  | 1.17 [0.81, 1.69]  |
| Children in home (ref. No)                                | Yes                      | 0.8 [0.58, 1.12]   | 0.82 [0.59, 1.13]  |
| Stated rationale (ref. Energy)                            | Quality-of-life (QoL)    | 0.75 [0.53, 1.06]  | 0.72 [0.46, 1.13]  |
| Stated rationale (ref. Energy)                            | Combination              | 0.7* [0.5, 0.98]   | 0.7 [0.45, 1.08]   |
| Climate priority (ref. High/Very high)                    | Low/Medium               |                    | 0.76 [0.46, 1.27]  |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium           |                    | 1.11 [0.56, 2.22]  |
| high)                                                     | Combination*Low/Medium   |                    | 1.01 [0.52, 1.98]  |
| Existing policy (ref. Not stated)                         | Example stated           | 1.1 [0.84, 1.44]   | 1.1 [0.84, 1.45]   |
| Observations                                              |                          | 869                | 869                |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 4: Car restrictions in urban areas

|                                                           |                           | Model 1              | Model 2              |
|-----------------------------------------------------------|---------------------------|----------------------|----------------------|
|                                                           |                           | OR [95% CI]          | OR [95% CI]          |
| Gender (ref. Female/Other)                                | Male                      | 0.91 [0.71, 1.17]    | 1.01 [0.79, 1.3]     |
| Age (ref. 45-54)                                          | 18 - 24                   | 1.23 [0.77, 1.95]    | 1.15 [0.72, 1.84]    |
| Age (ref. 45-54)                                          | 25 - 34                   | 1.03 [0.69, 1.54]    | 1.02 [0.68, 1.54]    |
| Age (ref. 45-54)                                          | 35 - 44                   | 1.11 [0.76, 1.63]    | 1.18 [0.8, 1.73]     |
| Age (ref. 45-54)                                          | 55 - 64                   | 1.17 [0.79, 1.74]    | 1.28 [0.86, 1.9]     |
| Age (ref. 45-54)                                          | 65+                       | 1.61* [1.07, 2.43]   | 1.44. [0.96, 2.18]   |
| Region (ref. Dublin)                                      | Rest of Leinster          | 0.95 [0.64, 1.4]     | 0.96 [0.65, 1.43]    |
| Region (ref. Dublin)                                      | Munster                   | 1.22 [0.84, 1.77]    | 1.29 [0.88, 1.87]    |
| Region (ref. Dublin)                                      | Connacht/Ulster           | 1.3 [0.84, 2.01]     | 1.28 [0.82, 1.99]    |
| Social grade (ref. ABC1)                                  | C2DEF                     | 0.63*** [0.48, 0.82] | 0.71* [0.54, 0.94]   |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000         | 1.05 [0.76, 1.44]    | 1.1 [0.8, 1.52]      |
|                                                           | €80,000 - €120,000        | 1.19 [0.79, 1.77]    | 1.12 [0.75, 1.68]    |
|                                                           | €120,000 or more          | 1.18 [0.67, 2.08]    | 1.23 [0.7, 2.19]     |
| Dwelling area (ref. City centre)                          | Small town or village     | 0.91 [0.52, 1.59]    | 0.82 [0.47, 1.44]    |
| Dwelling area (ref. City centre)                          | Rural area                | 0.67 [0.39, 1.14]    | 0.66 [0.38, 1.15]    |
| Dwelling area (ref. City centre)                          | Other large town          | 1.07 [0.62, 1.86]    | 1.04 [0.6, 1.81]     |
| Dwelling area (ref. City centre)                          | Satellite/Commuter town   | 0.85 [0.46, 1.57]    | 0.83 [0.45, 1.54]    |
| Dwelling area (ref. City centre)                          | City suburb               | 0.81 [0.51, 1.29]    | 0.81 [0.5, 1.3]      |
| Disability in household (ref. No)                         | Yes                       | 0.82 [0.64, 1.07]    | 0.88 [0.67, 1.14]    |
| Driving frequency (ref. Less than weekly)                 | Uses car at least weekly  | 0.34*** [0.24, 0.49] | 0.33*** [0.23, 0.47] |
| Cycling frequency (ref. Less than weekly)                 | Uses bike at least weekly | 1.89** [1.29, 2.77]  | 1.73** [1.18, 2.55]  |
| Young children in hh (ref. No)                            | Yes                       | 0.98 [0.72, 1.35]    | 1.02 [0.74, 1.4]     |
| Stated rationale (ref. Energy)                            | Quality-of-life (QoL)     | 0.86 [0.64, 1.16]    | 0.58** [0.4, 0.86]   |
| Stated rationale (ref. Energy)                            | Combination               | 0.99 [0.74, 1.32]    | 0.8 [0.55, 1.17]     |
| Climate priority (ref. High/Very high)                    | Low/Medium                |                      | 0.21*** [0.13, 0.32] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium            |                      | 2.59** [1.41, 4.77]  |
| high)                                                     | Combination*Low/Medium    |                      | 1.64 [0.91, 2.98]    |
| Existing policy (ref. Not stated)                         | Example stated            | 1.11 [0.88, 1.41]    | 1.07 [0.84, 1.36]    |
| Observations                                              |                           | 898                  | 898                  |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 5: E-cargo bikes grants

|                                                           |                           | Model 1             | Model 2              |
|-----------------------------------------------------------|---------------------------|---------------------|----------------------|
|                                                           |                           | OR [95% CI]         | OR [95% CI]          |
| Gender (ref. Female/Other)                                | Male                      | 0.88 [0.69, 1.13]   | 0.94 [0.74, 1.21]    |
| Age (ref. 45-54)                                          | 18 - 24                   | 1.2 [0.77, 1.87]    | 1.01 [0.64, 1.59]    |
| Age (ref. 45-54)                                          | 25 - 34                   | 1.09 [0.73, 1.64]   | 1.02 [0.68, 1.54]    |
| Age (ref. 45-54)                                          | 35 - 44                   | 1.06 [0.73, 1.54]   | 1.02 [0.7, 1.48]     |
| Age (ref. 45-54)                                          | 55 - 64                   | 1.04 [0.68, 1.57]   | 0.84 [0.55, 1.29]    |
| Age (ref. 45-54)                                          | 65+                       | 0.96 [0.65, 1.43]   | 0.77 [0.52, 1.15]    |
| Social grade (ref. ABC1)                                  | C2DEF                     | 0.93 [0.72, 1.21]   | 0.99 [0.76, 1.29]    |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000         | 1.22 [0.88, 1.68]   | 1.27 [0.92, 1.75]    |
| Household income (ref. < €40,000 )                        | €80,000 - €120,000        | 1.19 [0.8, 1.77]    | 1.18 [0.79, 1.78]    |
| Household income (ref. < €40,000 )                        | €120,000 or more          | 1.26 [0.7, 2.27]    | 1.15 [0.64, 2.07]    |
| Dwelling area (ref. Rural)                                | Small town or village     | 1.24 [0.84, 1.83]   | 1.25 [0.85, 1.86]    |
| Dwelling area (ref. Rural)                                | Large town/Suburb/City    | 1.22 [0.89, 1.66]   | 1.23 [0.9, 1.68]     |
| Driving frequency (ref. Less than weekly)                 | Uses car at least weekly  | 0.62** [0.44, 0.87] | 0.62** [0.44, 0.88]  |
| Cycling frequency (ref. Less than weekly)                 | Uses bike at least weekly | 1.69* [1.12, 2.56]  | 1.57* [1.04, 2.4]    |
| Pre-school children in household (ref. No)                | Yes                       | 1.49* [1, 2.21]     | 1.61* [1.08, 2.41]   |
| Stated rationale (ref. Energy)                            | Quality-of-life (QoL)     | 0.76. [0.57, 1.02]  | 0.68* [0.46, 0.98]   |
| Stated rationale (ref. Energy)                            | Combination               | 0.91 [0.68, 1.22]   | 0.92 [0.63, 1.33]    |
| Climate priority (ref. High/Very high)                    | Low/Medium                |                     | 0.29*** [0.19, 0.44] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium            |                     | 1.27 [0.7, 2.29]     |
| high)                                                     | Combination*Low/Medium    |                     | 0.98 [0.54, 1.77]    |
| Existing policy (ref. Not stated)                         | Example stated            | 1.11 [0.87, 1.4]    | 1.07 [0.85, 1.36]    |
| Observations                                              |                           | 907                 | 907                  |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 6: Vehicle mass tax

|                                                           |                           | Model 1              | Model 2             |
|-----------------------------------------------------------|---------------------------|----------------------|---------------------|
|                                                           |                           | OR [95% CI]          | OR [95% CI]         |
| Gender (ref. Female/Other)                                | Male                      | 1.12 [0.87, 1.44]    | 1.1 [0.86, 1.42]    |
| Age (ref. 45-54)                                          | 18 - 24                   | 0.95 [0.6, 1.52]     | 0.86 [0.54, 1.37]   |
| Age (ref. 45-54)                                          | 25 - 34                   | 1.14 [0.77, 1.7]     | 1.05 [0.71, 1.57]   |
| Age (ref. 45-54)                                          | 35 - 44                   | 0.94 [0.64, 1.38]    | 0.93 [0.63, 1.38]   |
| Age (ref. 45-54)                                          | 55 - 64                   | 1.27 [0.84, 1.95]    | 1.16 [0.76, 1.78]   |
| Age (ref. 45-54)                                          | 65+                       | 1.69* [1.12, 2.55]   | 1.39 [0.92, 2.11]   |
| Region (ref. Dublin)                                      | Rest of Leinster          | 1.08 [0.76, 1.52]    | 1.15 [0.81, 1.64]   |
| Region (ref. Dublin)                                      | Munster                   | 1.32 [0.94, 1.88]    | 1.44* [1.01, 2.04]  |
| Region (ref. Dublin)                                      | Connacht/Ulster           | 1.28 [0.85, 1.94]    | 1.44. [0.95, 2.18]  |
| Social grade (ref. ABC1)                                  | C2DEF                     | 0.76* [0.59, 0.99]   | 0.82 [0.63, 1.07]   |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000         | 0.86 [0.63, 1.19]    | 0.85 [0.62, 1.18]   |
| Household income (ref. < €40,000 )                        | €80,000 - €120,000        | 1.07 [0.71, 1.6]     | 1.02 [0.68, 1.53]   |
| Household income (ref. < €40,000 )                        | €120,000 or more          | 0.97 [0.54, 1.75]    | 0.82 [0.45, 1.49]   |
| Dwelling area (ref. Rural)                                | Small town or village     | 1.06 [0.72, 1.56]    | 1.08 [0.73, 1.59]   |
| Dwelling area (ref. Rural)                                | Large town/Suburb/City    | 1.58** [1.13, 2.19]  | 1.72** [1.24, 2.41] |
| Disability in household (ref. No)                         | Yes                       | 1.19 [0.92, 1.53]    | 1.2 [0.93, 1.55]    |
| Driving frequency (ref. Less than weekly)                 | Uses car at least weekly  | 0.53*** [0.37, 0.76] | 0.56** [0.38, 0.8]  |
| Cycling frequency (ref. Less than weekly)                 | Uses bike at least weekly | 1.77** [1.2, 2.63]   | 1.75** [1.18, 2.6]  |
| Young children in household (ref. No)                     | Yes                       | 0.75. [0.55, 1.02]   | 0.78 [0.57, 1.07]   |
| Stated rationale (ref. Energy)                            | Quality-of-life (QoL)     | 1.05 [0.78, 1.4]     | 0.87 [0.59, 1.26]   |
| Stated rationale (ref. Energy)                            | Combination               | 0.92 [0.68, 1.23]    | 0.89 [0.61, 1.32]   |
| Climate priority (ref. High/Very high)                    | Low/Medium                |                      | 0.33*** [0.22, 0.5] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium            |                      | 1.6 [0.88, 2.89]    |
| high)                                                     | Combination*Low/Medium    |                      | 1.11 [0.61, 2.02]   |
| Existing policy (ref. Not stated)                         | Example stated            | 0.81. [0.64, 1.03]   | 0.84 [0.66, 1.07]   |
| Observations                                              |                           | 891                  | 891                 |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 7: Stronger public transport investment

|                                                                 |                           | Model 1             | Model 2             |
|-----------------------------------------------------------------|---------------------------|---------------------|---------------------|
|                                                                 |                           | OR [95% CI]         | OR [95% CI]         |
| Gender (ref. Female/Other)                                      | Male                      | 0.79. [0.6, 1.03]   | 0.81 [0.62, 1.06]   |
| Age (ref. 45-54)                                                | 18 - 24                   | 1.58. [0.94, 2.66]  | 1.44 [0.85, 2.44]   |
| Age (ref. 45-54)                                                | 25 - 34                   | 1.01 [0.66, 1.56]   | 1.02 [0.66, 1.57]   |
| Age (ref. 45-54)                                                | 35 - 44                   | 0.95 [0.64, 1.41]   | 1 [0.67, 1.5]       |
| Age (ref. 45-54)                                                | 55 - 64                   | 1.21 [0.79, 1.87]   | 1.14 [0.74, 1.76]   |
| Age (ref. 45-54)                                                | 65+                       | 1.58* [1.03, 2.42]  | 1.42 [0.92, 2.19]   |
| Region (ref. Dublin)                                            | Rest of Leinster          | 0.89 [0.62, 1.29]   | 0.9 [0.62, 1.31]    |
| Region (ref. Dublin)                                            | Munster                   | 0.89 [0.6, 1.31]    | 0.86 [0.58, 1.27]   |
| Region (ref. Dublin)                                            | Connacht/Ulster           | 1.13 [0.73, 1.75]   | 1.1 [0.71, 1.72]    |
| Social grade (ref. ABC1)                                        | C2DEF                     | 0.78. [0.59, 1.04]  | 0.88 [0.66, 1.18]   |
| Household income (ref. < €40,000 )                              | €40,000 - €80,000         | 1.1 [0.77, 1.56]    | 1.13 [0.79, 1.61]   |
| Household income (ref. < €40,000 )                              | €80,000 - €120,000        | 1.03 [0.67, 1.58]   | 0.93 [0.6, 1.43]    |
| Household income (ref. < €40,000 )                              | €120,000 or more          | 0.84 [0.44, 1.61]   | 0.76 [0.4, 1.46]    |
| Dwelling area (ref. Rural)                                      | Small town or village     | 1.09 [0.72, 1.65]   | 1.09 [0.72, 1.66]   |
| Dwelling area (ref. Rural)                                      | Large town/Suburb/City    | 1.14 [0.79, 1.65]   | 1.14 [0.79, 1.65]   |
| Disability in household (ref. No)                               | Yes                       | 1.1 [0.84, 1.45]    | 1.11 [0.84, 1.46]   |
| Driving frequency (ref. Less than weekly)                       | Uses car at least weekly  | 0.5*** [0.34, 0.74] | 0.51** [0.34, 0.76] |
| Cycling frequency (ref. Less than weekly)                       | Uses bike at least weekly | 1.16 [0.76, 1.79]   | 1.12 [0.73, 1.73]   |
| Stated rationale (ref. Energy)                                  | Quality-of-life (QoL)     | 1.2 [0.87, 1.64]    | 1.23 [0.81, 1.85]   |
| Stated rationale (ref. Energy)                                  | Combination               | 1.02 [0.74, 1.4]    | 1.37 [0.9, 2.09]    |
| Climate priority (ref. High/Very high)                          | Low/Medium                |                     | 0.6* [0.38, 0.95]   |
| Stated rationale*Climate priority (ref. Energy, High/Very high) | QoL*Low/Medium            |                     | 0.93 [0.49, 1.78]   |
|                                                                 | Combination*Low/Medium    |                     | 0.53. [0.28, 1]     |
| Existing policy (ref. Not stated)                               | Example stated            | 1.25. [0.97, 1.62]  | 1.2 [0.92, 1.56]    |
| Observations                                                    |                           | 862                 | 862                 |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 8: Congestion charges

|                                                                 |                           | Model 1              | Model 2              |
|-----------------------------------------------------------------|---------------------------|----------------------|----------------------|
|                                                                 |                           | OR [95% CI]          | OR [95% CI]          |
| Gender (ref. Female/Other)                                      | Male                      | 0.98 [0.77, 1.26]    | 1.01 [0.79, 1.29]    |
| Age (ref. 45-54)                                                | 18 - 24                   | 1.09 [0.68, 1.75]    | 0.92 [0.57, 1.48]    |
| Age (ref. 45-54)                                                | 25 - 34                   | 0.95 [0.63, 1.44]    | 0.89 [0.59, 1.35]    |
| Age (ref. 45-54)                                                | 35 - 44                   | 1.11 [0.76, 1.62]    | 1.05 [0.72, 1.53]    |
| Age (ref. 45-54)                                                | 55 - 64                   | 1.15 [0.76, 1.73]    | 0.99 [0.66, 1.5]     |
| Age (ref. 45-54)                                                | 65+                       | 1.53* [1.02, 2.31]   | 1.35 [0.89, 2.03]    |
| Region (ref. Dublin)                                            | Rest of Leinster          | 0.86 [0.59, 1.25]    | 0.84 [0.57, 1.23]    |
| Region (ref. Dublin)                                            | Munster                   | 0.96 [0.67, 1.39]    | 0.9 [0.62, 1.31]     |
| Region (ref. Dublin)                                            | Connacht/Ulster           | 0.97 [0.64, 1.46]    | 1.02 [0.67, 1.54]    |
| Social grade (ref. ABC1)                                        | C2DEF                     | 0.96 [0.73, 1.26]    | 1.09 [0.83, 1.44]    |
| Household income (ref. < €40,000 )                              | €40,000 - €80,000         | 1.35. [0.98, 1.85]   | 1.45* [1.05, 1.99]   |
| Household income (ref. < €40,000 )                              | €80,000 - €120,000        | 1.61* [1.07, 2.41]   | 1.58* [1.05, 2.37]   |
| Household income (ref. < €40,000 )                              | €120,000 or more          | 1.21 [0.69, 2.12]    | 1.11 [0.62, 1.98]    |
| Dwelling area (ref. City centre)                                | Rural area                | 0.66 [0.39, 1.1]     | 0.55* [0.32, 0.93]   |
| Dwelling area (ref. City centre)                                | Small town or village     | 0.62. [0.36, 1.04]   | 0.51* [0.3, 0.88]    |
| Dwelling area (ref. City centre)                                | Other large town          | 0.84 [0.49, 1.44]    | 0.65 [0.38, 1.12]    |
| Dwelling area (ref. City centre)                                | Satellite/Commuter town   | 0.61. [0.34, 1.1]    | 0.49* [0.27, 0.89]   |
| Dwelling area (ref. City centre)                                | City suburb               | 0.59* [0.37, 0.94]   | 0.53** [0.33, 0.84]  |
| Disability in household (ref. No)                               | Yes                       | 0.83 [0.64, 1.07]    | 0.87 [0.67, 1.13]    |
| Driving frequency (ref. Less than weekly)                       | Uses car at least weekly  | 0.51*** [0.36, 0.73] | 0.54*** [0.38, 0.77] |
| Cycling frequency (ref. Less than weekly)                       | Uses bike at least weekly | 1.93*** [1.33, 2.82] | 1.86** [1.27, 2.73]  |
| Stated rationale (ref. Energy)                                  | Quality-of-life (QoL)     | 1.08 [0.81, 1.44]    | 0.74 [0.51, 1.07]    |
| Stated rationale (ref. Energy)                                  | Combination               | 1.06 [0.79, 1.41]    | 0.8 [0.54, 1.17]     |
| Climate priority (ref. High/Very high)                          | Low/Medium                |                      | 0.2*** [0.13, 0.31]  |
| Stated rationale*Climate priority (ref. Energy, High/Very high) | QoL*Low/Medium            |                      | 2.6** [1.42, 4.75]   |
|                                                                 | Combination*Low/Medium    |                      | 2.22** [1.22, 4.03]  |
| Existing policy (ref. Not stated)                               | Example stated            | 1.31* [1.03, 1.66]   | 1.28* [1, 1.62]      |
| Observations                                                    |                           | 891                  | 891                  |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 9: High-density housing

|                                                           |                                   | Model 1             | Model 2             |
|-----------------------------------------------------------|-----------------------------------|---------------------|---------------------|
|                                                           |                                   | OR [95% CI]         | OR [95% CI]         |
| Gender (ref. Female/Other)                                | Male                              | 1.38** [1.08, 1.76] | 1.43** [1.12, 1.83] |
| Age (ref. 45-54)                                          | 18 - 24                           | 1.12 [0.7, 1.81]    | 1.03 [0.64, 1.66]   |
| Age (ref. 45-54)                                          | 25 - 34                           | 1.14 [0.76, 1.72]   | 1.1 [0.73, 1.66]    |
| Age (ref. 45-54)                                          | 35 - 44                           | 1 [0.7, 1.44]       | 1 [0.69, 1.44]      |
| Age (ref. 45-54)                                          | 55 - 64                           | 0.79 [0.53, 1.18]   | 0.76 [0.51, 1.13]   |
| Age (ref. 45-54)                                          | 65+                               | 1.59* [1.05, 2.41]  | 1.42 [0.93, 2.16]   |
| Region (ref. Dublin)                                      | Rest of Leinster                  | 0.82 [0.59, 1.15]   | 0.84 [0.6, 1.18]    |
| Region (ref. Dublin)                                      | Munster                           | 1.1 [0.79, 1.55]    | 1.13 [0.81, 1.58]   |
| Region (ref. Dublin)                                      | Connacht/Ulster                   | 1.21 [0.81, 1.8]    | 1.2 [0.8, 1.79]     |
| Social grade (ref. ABC1)                                  | C2DEF                             | 1.19 [0.92, 1.55]   | 1.26. [0.97, 1.65]  |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000                 | 0.88 [0.63, 1.21]   | 0.88 [0.63, 1.21]   |
| Household income (ref. < €40,000 )                        | €80,000 - €120,000                | 1.36 [0.9, 2.05]    | 1.28 [0.84, 1.93]   |
| House size (ref. Small (less than 100m 2 ))               | €120,000 or more                  | 1.09 [0.62, 1.91]   | 1.03 [0.59, 1.81]   |
|                                                           | Medium (100m 2 - 150m 2 )         | 0.67. [0.45, 1.02]  | 0.69. [0.46, 1.04]  |
|                                                           | Large (150m 2 - 250m 2 )          | 1.03 [0.7, 1.53]    | 1.04 [0.7, 1.53]    |
|                                                           | Very large (250m 2 or more)       | 1.36 [0.92, 2.03]   | 1.33 [0.89, 1.98]   |
| Tenure (ref. own home)                                    | Renting                           | 1.26 [0.93, 1.71]   | 1.26 [0.93, 1.71]   |
|                                                           | Other tenure type                 | 0.98 [0.61, 1.57]   | 0.99 [0.62, 1.58]   |
| Household size (ref. 1 person)                            | 2 people                          | 0.91 [0.61, 1.36]   | 0.93 [0.62, 1.39]   |
| Household size (ref. 1 person)                            | 3 people                          | 0.87 [0.56, 1.36]   | 0.89 [0.57, 1.38]   |
| Household size (ref. 1 person)                            | 4 people                          | 1.2 [0.76, 1.9]     | 1.25 [0.79, 1.98]   |
| Household size (ref. 1 person)                            | 5 or more people                  | 1.03 [0.63, 1.66]   | 1.09 [0.67, 1.77]   |
| Dwelling area (ref. Rural)                                | Small town or village             | 1.16 [0.79, 1.7]    | 1.11 [0.76, 1.63]   |
| Dwelling area (ref. Rural)                                | Large town/Suburb/City            | 1.52* [1.1, 2.11]   | 1.5* [1.08, 2.08]   |
| Stated rationale (ref. Energy)                            | Quality-of-life co-benefits (QoL) | 1.25 [0.94, 1.66]   | 0.99 [0.69, 1.42]   |
| Stated rationale (ref. Energy)                            | Combination of rationale          | 1.51** [1.14, 2.01] | 1.25 [0.87, 1.79]   |
| Climate priority (ref. High/Very high)                    | Low/Medium                        |                     | 0.4*** [0.27, 0.6]  |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium                    |                     | 1.87* [1.05, 3.34]  |
| high)                                                     | Combination*Low/Medium            |                     | 1.69 [0.94, 3.04]   |
| Existing policy (ref. Not stated)                         | Example stated                    | 1.12 [0.89, 1.41]   | 1.11 [0.88, 1.4]    |
| Observations                                              |                                   | 948                 | 948                 |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 10: Limits on rural one-off housing

|                                                                 |                                    | Model 1               | Model 2               |
|-----------------------------------------------------------------|------------------------------------|-----------------------|-----------------------|
|                                                                 |                                    | OR [95% CI]           | OR [95% CI]           |
| Gender (ref. Woman/Other)                                       | Man                                | 1 [0.78, 1.29]        | 1.06 [0.83, 1.37]     |
| Age (ref. 45-54)                                                | 18 - 24                            | 1.6. [0.96, 2.67]     | 1.44 [0.86, 2.41]     |
| Age (ref. 45-54)                                                | 25 - 34                            | 1.43. [0.95, 2.15]    | 1.39 [0.92, 2.09]     |
| Age (ref. 45-54)                                                | 35 - 44                            | 1.32 [0.91, 1.93]     | 1.31 [0.9, 1.91]      |
| Age (ref. 45-54)                                                | 55 - 64                            | 1.15 [0.76, 1.73]     | 1.05 [0.7, 1.59]      |
| Age (ref. 45-54)                                                | 65+                                | 1.95** [1.24, 3.07]   | 1.81* [1.15, 2.86]    |
| Region (ref. Dublin)                                            | Rest of Leinster                   | 0.83 [0.59, 1.19]     | 0.87 [0.61, 1.24]     |
| Region (ref. Dublin)                                            | Munster                            | 0.81 [0.57, 1.14]     | 0.84 [0.59, 1.2]      |
| Region (ref. Dublin)                                            | Connacht/Ulster                    | 0.69. [0.46, 1.04]    | 0.74 [0.48, 1.12]     |
| Social grade (ref. ABC1)                                        | C2DEF                              | 1.26. [0.97, 1.64]    | 1.37* [1.05, 1.79]    |
| Household income (ref. < € 40,000)                              | €40,000 - €80,000                  | 0.63** [0.46, 0.87]   | 0.65** [0.47, 0.89]   |
| Household income (ref. < € 40,000)                              | €80,000 - €120,000                 | 0.6* [0.4, 0.9]       | 0.58* [0.39, 0.88]    |
| Household income (ref. < € 40,000)                              | €120,000 or more                   | 0.36*** [0.2, 0.66]   | 0.33*** [0.18, 0.6]   |
| House type (ref. Apartment)                                     | Detached house                     | 0.59* [0.36, 0.98]    | 0.57* [0.34, 0.96]    |
| House type (ref. Apartment)                                     | Semi-detached/end of terrace house | 0.52** [0.33, 0.83]   | 0.5** [0.31, 0.79]    |
| House type (ref. Apartment)                                     | Terraced house                     | 0.65. [0.4, 1.08]     | 0.65. [0.39, 1.07]    |
| Tenure (ref. own home)                                          | Renting                            | 0.9 [0.66, 1.23]      | 0.91 [0.67, 1.25]     |
|                                                                 | Other tenure type                  | 1.18 [0.73, 1.92]     | 1.23 [0.75, 2]        |
| Household size (ref. 1 person)                                  | 2 people                           | 1.02 [0.69, 1.51]     | 0.97 [0.66, 1.44]     |
| Household size (ref. 1 person)                                  | 3 people                           | 1.32 [0.81, 2.14]     | 1.16 [0.71, 1.89]     |
| Household size (ref. 1 person)                                  | 4 people                           | 1.3 [0.76, 2.2]       | 1.19 [0.7, 2.02]      |
| Household size (ref. 1 person)                                  | 5 or more people                   | 0.93 [0.53, 1.65]     | 0.86 [0.48, 1.53]     |
| Children in household (including over18s) (ref. No)             | Yes                                | 1.01 [0.71, 1.45]     | 1.11 [0.77, 1.6]      |
| Dwelling area (ref. Rural)                                      | Small town or village              | 2.04*** [1.34, 3.11]  | 2.14*** [1.4, 3.27]   |
| Dwelling area (ref. Rural)                                      | Large town/Suburb/City             | 3.46*** [2.32, 5.18]  | 3.67*** [2.44, 5.54]  |
| Stated rationale (ref. Energy)                                  | Quality-of-life (QoL)              | 1.42* [1.05, 1.92]    | 1.16 [0.79, 1.7]      |
| Stated rationale (ref. Energy)                                  | Combination                        | 1.16 [0.86, 1.57]     | 1.27 [0.86, 1.88]     |
| Climate priority (ref. High/Very high)                          | Low/Medium                         |                       | 0.41*** [0.26, 0.65]  |
| Stated rationale*Climate priority (ref. Energy, High/Very high) | QoL*Low/Medium                     |                       | 1.7. [0.92, 3.16]     |
|                                                                 | Combination*Low/Medium             |                       | 0.95 [0.51, 1.74]     |
| Existing policy (ref. Not stated) Observations                  | Example stated                     | 0.88 [0.69, 1.12] 882 | 0.92 [0.72, 1.17] 882 |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 11: Downsizing tax relief

|                                                           |                                   | Model 1             | Model 2            |
|-----------------------------------------------------------|-----------------------------------|---------------------|--------------------|
|                                                           |                                   | OR [95% CI]         | OR [95% CI]        |
| Gender (ref. Female/Other)                                | Male                              | 1.15 [0.89, 1.5]    | 1.16 [0.9, 1.51]   |
| Age (ref. 45-54)                                          | 18 - 24                           | 0.57* [0.35, 0.93]  | 0.53* [0.32, 0.87] |
| Age (ref. 45-54)                                          | 25 - 34                           | 0.76 [0.5, 1.15]    | 0.73 [0.48, 1.1]   |
| Age (ref. 45-54)                                          | 35 - 44                           | 1.01 [0.68, 1.49]   | 1.01 [0.68, 1.5]   |
| Age (ref. 45-54)                                          | 55 - 64                           | 1.68* [1.06, 2.67]  | 1.62* [1.02, 2.59] |
| Age (ref. 45-54)                                          | 65+                               | 1.96** [1.22, 3.13] | 1.93** [1.2, 3.09] |
| Region (ref. Dublin)                                      | Rest of Leinster                  | 1.24 [0.87, 1.77]   | 1.25 [0.87, 1.78]  |
| Region (ref. Dublin)                                      | Munster                           | 1.15 [0.8, 1.64]    | 1.13 [0.79, 1.62]  |
| Region (ref. Dublin)                                      | Connacht/Ulster                   | 0.91 [0.6, 1.38]    | 0.91 [0.6, 1.38]   |
| Social grade (ref. ABC1)                                  | C2DEF                             | 0.81 [0.61, 1.07]   | 0.83 [0.63, 1.1]   |
| Household income (ref. <€40,000)                          | €40,000 - €80,000                 | 1.07 [0.76, 1.5]    | 1.12 [0.8, 1.58]   |
|                                                           | €80,000 - €120,000                | 1.06 [0.69, 1.65]   | 1.08 [0.69, 1.68]  |
|                                                           | €120,000 or more                  | 1.32 [0.71, 2.49]   | 1.31 [0.7, 2.49]   |
| House size (ref. Small (less than 100m 2 ))               | Medium (100m 2 - 150m 2 )         | 0.84 [0.54, 1.31]   | 0.88 [0.57, 1.38]  |
| House size (ref. Small (less than 100m 2 ))               | Large (150m 2 - 250m 2 )          | 0.84 [0.55, 1.29]   | 0.87 [0.56, 1.34]  |
| House size (ref. Small (less than 100m 2 ))               | Very large (250m 2 or more)       | 1.01 [0.66, 1.57]   | 1.03 [0.66, 1.6]   |
| Dwelling area (ref. rural)                                | Small town or village             | 1.05 [0.69, 1.62]   | 1.07 [0.7, 1.65]   |
| Dwelling area (ref. rural)                                | Large town/Suburb/City            | 1.1 [0.76, 1.59]    | 1.1 [0.76, 1.59]   |
| Tenure (ref. own home)                                    | Renting                           | 1.15 [0.83, 1.6]    | 1.17 [0.85, 1.63]  |
| Tenure (ref. own home)                                    | Other tenure type                 | 1.58. [0.94, 2.68]  | 1.6. [0.95, 2.72]  |
| Household size (ref. 1 person)                            | 2 people                          | 0.85 [0.55, 1.29]   | 0.85 [0.56, 1.3]   |
| Household size (ref. 1 person)                            | 3 people                          | 0.91 [0.56, 1.46]   | 0.9 [0.56, 1.46]   |
| Household size (ref. 1 person)                            | 4 people                          | 1.23 [0.74, 2.04]   | 1.24 [0.75, 2.06]  |
| Household size (ref. 1 person)                            | 5 or more people                  | 1.57 [0.9, 2.74]    | 1.65. [0.94, 2.89] |
| Children in home (ref. No)                                | Yes                               | 0.85 [0.6, 1.21]    | 0.86 [0.6, 1.22]   |
| Stated rationale (ref. Energy)                            | Quality-of-life co-benefits (QoL) | 1.43* [1.04, 1.96]  | 1.36 [0.9, 2.05]   |
| Stated rationale (ref. Energy)                            | Combination of rationale          | 0.97 [0.72, 1.3]    | 1.08 [0.73, 1.62]  |
| Climate priority (ref. High/Very high)                    | Low/Medium                        |                     | 0.74 [0.48, 1.14]  |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium                    |                     | 1.11 [0.59, 2.09]  |
| high)                                                     | Combination*Low/Medium            |                     | 0.8 [0.44, 1.47]   |
| Existing policy (ref. Not stated)                         | Example stated                    | 0.92 [0.71, 1.18]   | 0.95 [0.74, 1.23]  |
| Observations                                              |                                   | 879                 | 879                |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 12: Maximum office temperature settings

|                                                           |                          | Model 1             | Model 2              |
|-----------------------------------------------------------|--------------------------|---------------------|----------------------|
|                                                           |                          | OR [95% CI]         | OR [95% CI]          |
| Gender (ref. Female/Other)                                | Male                     | 1.16 [0.91, 1.48]   | 1.18 [0.92, 1.51]    |
| Age (ref. 45-54)                                          | 18 - 24                  | 0.7 [0.45, 1.1]     | 0.58* [0.37, 0.92]   |
| Age (ref. 45-54)                                          | 25 - 34                  | 0.78 [0.53, 1.15]   | 0.69. [0.47, 1.03]   |
| Age (ref. 45-54)                                          | 35 - 44                  | 0.75 [0.51, 1.1]    | 0.74 [0.5, 1.09]     |
| Age (ref. 45-54)                                          | 55 - 64                  | 1.26 [0.82, 1.93]   | 1.18 [0.77, 1.82]    |
| Age (ref. 45-54)                                          | 65+                      | 2.04** [1.31, 3.18] | 1.86** [1.19, 2.91]  |
| Region (ref. Dublin)                                      | Rest of Leinster         | 1.33. [0.96, 1.86]  | 1.33. [0.95, 1.85]   |
| Region (ref. Dublin)                                      | Munster                  | 1.11 [0.8, 1.54]    | 1.12 [0.81, 1.56]    |
| Region (ref. Dublin)                                      | Connacht/Ulster          | 1.11 [0.77, 1.6]    | 1.07 [0.74, 1.54]    |
| Social grade (ref. ABC1)                                  | C2DEF                    | 1.01 [0.77, 1.33]   | 1.1 [0.83, 1.45]     |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000        | 1.25 [0.91, 1.71]   | 1.37. [0.99, 1.88]   |
| Household income (ref. < €40,000 )                        | €80,000 - €120,000       | 1.23 [0.83, 1.82]   | 1.22 [0.82, 1.81]    |
| Household income (ref. < €40,000 )                        | €120,000 or more         | 2.1* [1.15, 3.9]    | 2.18* [1.18, 4.08]   |
| Working pattern (ref. Not in employment outside home)     | Employed & always WFH    | 0.99 [0.61, 1.62]   | 1.02 [0.62, 1.69]    |
| Working pattern (ref. Not in employment outside home)     | Employed & sometimes WFH | 1.18 [0.79, 1.77]   | 1.16 [0.77, 1.74]    |
| Working pattern (ref. Not in employment outside home)     | Employed & never WFH     | 1.12 [0.8, 1.55]    | 1.14 [0.82, 1.59]    |
| Stated rationale (ref. Energy)                            | Quality-of-life (QoL)    | 0.95 [0.71, 1.28]   | 0.74 [0.5, 1.1]      |
| Stated rationale (ref. Energy)                            | Combination              | 1.12 [0.84, 1.51]   | 1.06 [0.72, 1.55]    |
| Climate priority (ref. High/Very high)                    | Low/Medium               |                     | 0.36*** [0.24, 0.55] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium           |                     | 1.86* [1.02, 3.42]   |
| high)                                                     | Combination*Low/Medium   |                     | 1.12 [0.61, 2.06]    |
| Existing policy (ref. Not stated)                         | Example stated           | 0.99 [0.78, 1.27]   | 1.02 [0.8, 1.3]      |
| Observations                                              |                          | 899                 | 899                  |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 13: Rising block electricity tariffs

|                                                           |                                   | Model 1             | Model 2              |
|-----------------------------------------------------------|-----------------------------------|---------------------|----------------------|
|                                                           |                                   | OR [95% CI]         | OR [95% CI]          |
| Gender (ref. Female/Other)                                | Male                              | 1.34* [1.06, 1.71]  | 1.34* [1.05, 1.71]   |
| Age (ref. 45-54)                                          | 18 - 24                           | 1.16 [0.73, 1.84]   | 0.98 [0.61, 1.57]    |
| Age (ref. 45-54)                                          | 25 - 34                           | 1.12 [0.77, 1.65]   | 1.06 [0.72, 1.56]    |
| Age (ref. 45-54)                                          | 35 - 44                           | 0.95 [0.66, 1.37]   | 0.93 [0.64, 1.34]    |
| Age (ref. 45-54)                                          | 55 - 64                           | 1.08 [0.72, 1.63]   | 1.1 [0.73, 1.66]     |
| Age (ref. 45-54)                                          | 65+                               | 1.47. [0.97, 2.21]  | 1.38 [0.91, 2.08]    |
| Region (ref. Dublin)                                      | Rest of Leinster                  | 0.94 [0.68, 1.29]   | 0.93 [0.67, 1.28]    |
| Region (ref. Dublin)                                      | Munster                           | 0.87 [0.62, 1.2]    | 0.88 [0.63, 1.22]    |
| Region (ref. Dublin)                                      | Connacht/Ulster                   | 0.69* [0.48, 0.99]  | 0.68* [0.47, 0.98]   |
| Social grade (ref. ABC1)                                  | C2DEF                             | 0.9 [0.7, 1.17]     | 0.94 [0.73, 1.23]    |
| Household income (ref. <€40,000)                          | €40,000 - €80,000                 | 0.87 [0.64, 1.2]    | 0.86 [0.62, 1.18]    |
| Household income (ref. <€40,000)                          | €80,000 - €120,000                | 0.8 [0.53, 1.21]    | 0.76 [0.5, 1.14]     |
| Household income (ref. <€40,000)                          | €120,000 or more                  | 0.46** [0.26, 0.82] | 0.43** [0.24, 0.77]  |
| House size (ref. Small (less than 100m 2 ))               | Medium (100m 2 - 150m 2 )         | 1.11 [0.73, 1.67]   | 1.11 [0.73, 1.68]    |
| House size (ref. Small (less than 100m 2 ))               | Large (150m 2 - 250m 2 )          | 0.97 [0.64, 1.48]   | 0.95 [0.62, 1.45]    |
| House size (ref. Small (less than 100m 2 ))               | Very large (250m 2 or more)       | 1.21 [0.79, 1.85]   | 1.17 [0.76, 1.79]    |
| Household size (ref. 1 person)                            | 2 people                          | 0.83 [0.56, 1.21]   | 0.84 [0.57, 1.24]    |
| Household size (ref. 1 person)                            | 3 people                          | 0.88 [0.56, 1.33]   | 0.9 [0.58, 1.39]     |
| Household size (ref. 1 person)                            | 4 people                          | 0.95 [0.61, 1.46]   | 1.05 [0.68, 1.62]    |
| Household size (ref. 1 person)                            | 5 or more people                  | 0.99 [0.59, 1.61]   | 1.08 [0.66, 1.79]    |
| Stated rationale (ref. Energy)                            | Quality-of-life co-benefits (QoL) | 1.24 [0.92, 1.66]   | 0.84 [0.57, 1.23]    |
| Stated rationale (ref. Energy)                            | Combination of rationale          | 1 [0.75, 1.34]      | 0.8 [0.55, 1.18]     |
| Climate priority (ref. High/Very high)                    | Low/Medium                        |                     | 0.35*** [0.23, 0.54] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium                    |                     | 2.54** [1.4, 4.63]   |
| high)                                                     | Combination*Low/Medium            |                     | 1.7. [0.95, 3.04]    |
| Existing policy (ref. Not stated)                         | Example stated                    | 1.2 [0.94, 1.52]    | 1.21 [0.95, 1.53]    |
| Observations                                              |                                   | 927                 | 927                  |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 14: Data centres ban extension

|                                                                 |                        | Model 1             | Model 2             |
|-----------------------------------------------------------------|------------------------|---------------------|---------------------|
|                                                                 |                        | OR [95% CI]         | OR [95% CI]         |
| Gender (ref. Female/Other)                                      | Male                   | 0.81. [0.63, 1.03]  | 0.83 [0.65, 1.06]   |
| Age (ref. 45-54)                                                | 18 - 24                | 1.2 [0.77, 1.86]    | 1.17 [0.75, 1.83]   |
| Age (ref. 45-54)                                                | 25 - 34                | 1.36 [0.92, 2.02]   | 1.35 [0.91, 2.01]   |
| Age (ref. 45-54)                                                | 35 - 44                | 1.62* [1.11, 2.36]  | 1.66** [1.14, 2.42] |
| Age (ref. 45-54)                                                | 55 - 64                | 1.29 [0.86, 1.94]   | 1.27 [0.85, 1.91]   |
| Age (ref. 45-54)                                                | 65+                    | 1.08 [0.72, 1.6]    | 1.04 [0.7, 1.56]    |
| Region (ref. Dublin)                                            | Rest of Leinster       | 1.17 [0.85, 1.61]   | 1.15 [0.84, 1.59]   |
| Region (ref. Dublin)                                            | Munster                | 1.25 [0.91, 1.73]   | 1.24 [0.9, 1.71]    |
| Region (ref. Dublin)                                            | Connacht/Ulster        | 0.91 [0.64, 1.32]   | 0.93 [0.64, 1.34]   |
| Social grade (ref. ABC1)                                        | C2DEF                  | 0.99 [0.76, 1.28]   | 1 [0.77, 1.31]      |
| Household income (ref. < €40,000 )                              | €40,000 - €80,000      | 0.69* [0.51, 0.94]  | 0.7* [0.51, 0.95]   |
| Household income (ref. < €40,000 )                              | €80,000 - €120,000     | 0.85 [0.58, 1.24]   | 0.82 [0.56, 1.21]   |
| Household income (ref. < €40,000 )                              | €120,000 or more       | 1.24 [0.68, 2.27]   | 1.16 [0.63, 2.15]   |
| Stated rationale (ref. Energy)                                  | Quality-of-life (QoL)  | 1.11 [0.82, 1.48]   | 1.19 [0.81, 1.73]   |
| Stated rationale (ref. Energy)                                  | Combination            | 1.18 [0.88, 1.57]   | 1.37. [0.94, 2]     |
| Climate priority (ref. High/Very high)                          | Low/Medium             |                     | 0.98 [0.64, 1.48]   |
| Stated rationale*Climate priority (ref. Energy, High/Very high) | QoL*Low/Medium         |                     | 0.83 [0.46, 1.52]   |
|                                                                 | Combination*Low/Medium |                     | 0.69 [0.38, 1.24]   |
| Existing policy (ref. Not stated)                               | Example stated         | 1.43** [1.12, 1.82] | 1.43** [1.12, 1.82] |
| Observations                                                    |                        | 893                 | 893                 |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 15: Air drying space in new housing

|                                                           |                                   | Model 1             | Model 2             |
|-----------------------------------------------------------|-----------------------------------|---------------------|---------------------|
|                                                           |                                   | OR [95% CI]         | OR [95% CI]         |
| Gender (ref. Female/Other)                                | Male                              | 0.66** [0.51, 0.86] | 0.68** [0.52, 0.89] |
| Age (ref. 45-54)                                          | 18 - 24                           | 0.81 [0.5, 1.31]    | 0.76 [0.47, 1.24]   |
| Age (ref. 45-54)                                          | 25 - 34                           | 0.96 [0.63, 1.46]   | 0.91 [0.6, 1.38]    |
| Age (ref. 45-54)                                          | 35 - 44                           | 1 [0.69, 1.47]      | 1.06 [0.72, 1.55]   |
| Age (ref. 45-54)                                          | 55 - 64                           | 1.3 [0.83, 2.02]    | 1.2 [0.77, 1.89]    |
| Age (ref. 45-54)                                          | 65+                               | 1.63* [1.06, 2.51]  | 1.56* [1.01, 2.42]  |
| Region (ref. Dublin)                                      | Rest of Leinster                  | 1.28 [0.91, 1.81]   | 1.28 [0.91, 1.81]   |
| Region (ref. Dublin)                                      | Munster                           | 1.26 [0.89, 1.78]   | 1.3 [0.92, 1.85]    |
| Region (ref. Dublin)                                      | Connacht/Ulster                   | 0.91 [0.61, 1.35]   | 0.95 [0.64, 1.43]   |
| Social grade (ref. ABC1)                                  | C2DEF                             | 1.15 [0.87, 1.52]   | 1.22 [0.92, 1.62]   |
| Household income (ref. <€40,000)                          | €40,000 - €80,000                 | 1.17 [0.84, 1.63]   | 1.18 [0.84, 1.64]   |
| Household income (ref. <€40,000)                          | €80,000 - €120,000                | 1.37 [0.9, 2.1]     | 1.33 [0.87, 2.05]   |
| Household income (ref. <€40,000)                          | €120,000 or more                  | 1.24 [0.69, 2.27]   | 1.11 [0.61, 2.04]   |
| House size (ref. Small (less than 100m 2 ))               | Medium (100m 2 - 150m 2 )         | 0.71 [0.46, 1.1]    | 0.71 [0.45, 1.1]    |
| House size (ref. Small (less than 100m 2 ))               | Large (150m 2 - 250m 2 )          | 0.67. [0.43, 1.05]  | 0.64. [0.4, 1]      |
| House size (ref. Small (less than 100m 2 ))               | Very large (250m 2 or more)       | 0.64* [0.41, 0.98]  | 0.59* [0.38, 0.92]  |
| Stated rationale (ref. Energy)                            | Quality-of-life co-benefits (QoL) | 1.06 [0.78, 1.44]   | 1.08 [0.72, 1.62]   |
| Stated rationale (ref. Energy)                            | Combination of rationale          | 0.88 [0.64, 1.19]   | 0.82 [0.54, 1.24]   |
| Climate priority (ref. High/Very high)                    | Low/Medium                        |                     | 0.4*** [0.25, 0.64] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium                    |                     | 0.89 [0.47, 1.68]   |
| high)                                                     | Combination*Low/Medium            |                     | 1.18 [0.62, 2.24]   |
| Existing policy (ref. Not stated)                         | Example stated                    | 1.03 [0.8, 1.32]    | 1.04 [0.8, 1.34]    |
| Observations                                              |                                   | 900                 | 900                 |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.

## Policy 16: Remove lit advertisements &amp; reduce public lighting

|                                                           |                        | Model 1           | Model 2              |
|-----------------------------------------------------------|------------------------|-------------------|----------------------|
|                                                           |                        | OR [95% CI]       | OR [95% CI]          |
| Gender (ref. Female/Other)                                | Male                   | 1.07 [0.84, 1.38] | 1.07 [0.83, 1.37]    |
| Age (ref. 45-54)                                          | 18 - 24                | 1.09 [0.7, 1.71]  | 1.05 [0.67, 1.66]    |
| Age (ref. 45-54)                                          | 25 - 34                | 0.85 [0.57, 1.26] | 0.85 [0.57, 1.27]    |
| Age (ref. 45-54)                                          | 35 - 44                | 1.07 [0.74, 1.55] | 1.09 [0.75, 1.58]    |
| Age (ref. 45-54)                                          | 55 - 64                | 1.25 [0.84, 1.86] | 1.23 [0.83, 1.82]    |
| Age (ref. 45-54)                                          | 65+                    | 1.49. [1, 2.25]   | 1.42. [0.94, 2.14]   |
| Region (ref. Dublin)                                      | Rest of Leinster       | 1.12 [0.79, 1.57] | 1.14 [0.81, 1.61]    |
| Region (ref. Dublin)                                      | Munster                | 0.9 [0.64, 1.27]  | 0.94 [0.67, 1.34]    |
| Region (ref. Dublin)                                      | Connacht/Ulster        | 0.72 [0.48, 1.08] | 0.74 [0.49, 1.11]    |
| Social grade (ref. ABC1)                                  | C2DEF                  | 0.89 [0.68, 1.16] | 0.94 [0.72, 1.22]    |
| Household income (ref. < €40,000 )                        | €40,000 - €80,000      | 0.84 [0.61, 1.16] | 0.83 [0.6, 1.14]     |
| Household income (ref. < €40,000 )                        | €80,000 - €120,000     | 0.76 [0.51, 1.13] | 0.74 [0.5, 1.09]     |
| Household income (ref. < €40,000 )                        | €120,000 or more       | 0.96 [0.55, 1.66] | 0.87 [0.5, 1.52]     |
| Dwelling area (ref. Rural)                                | Small town or village  | 0.9 [0.61, 1.33]  | 0.91 [0.62, 1.35]    |
| Dwelling area (ref. Rural)                                | Large town/Suburb/City | 0.84 [0.6, 1.19]  | 0.86 [0.61, 1.21]    |
| Stated rationale (ref. Energy)                            | Quality-of-life (QoL)  | 0.95 [0.71, 1.28] | 0.95 [0.65, 1.39]    |
| Stated rationale (ref. Energy)                            | Combination            | 1.14 [0.86, 1.53] | 1.1 [0.75, 1.61]     |
| Climate priority (ref. High/Very high)                    | Low/Medium             |                   | 0.47*** [0.31, 0.72] |
| Stated rationale*Climate priority (ref. Energy, High/Very | QoL*Low/Medium         |                   | 0.97 [0.53, 1.78]    |
| high)                                                     | Combination*Low/Medium |                   | 1.18 [0.65, 2.13]    |
| Existing policy (ref. Not stated)                         | Example stated         | 1.18 [0.93, 1.5]  | 1.19 [0.93, 1.51]    |
| Observations                                              |                        | 922               | 922                  |

Significance codes:  p&lt;0.001 '***'; p&lt;0.01 '**'; p&lt;0.05 '*'; p&lt;0.1 '.'

See 'Analysis' in the Methods section for explanation of odds ratios, p values and confidence intervals.