---
document_id: seai_retrofitting_behaviour_2023
title: "Promoting Retrofitting Among Building Owners: A Behavioural Economics Lens"
category_id: 3
category_name: "Energy Management Standards, Audits & Green Building"
source_organization: "SEAI"
year: 2023
original_file: "seai_retrofitting_behavioural_lens.pdf"
tables_detected: 51
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Promoting retrofitting among homeowners in Ireland through a behavioural lens

Evidence review and policy recommendations

<!-- image -->

SEAI Behavioural Economics Unit Behavioural insights for policy: evidence review

## Promoting retrofitting among homeowners in Ireland through a behavioural lens

Evidence review and policy recommendations

March 2023

## Report prepared for SEAI by:

The Behavioural Insights Team

## Disclaimer

While every effort has been made to ensure the accuracy of the contents of this report, SEAI accepts no liability whatsoever to any third party for any loss or damage arising from any interpretation or use of the information contained in this report, or reliance on any views expressed therein. Public disclosure authorised. This guide may be reproduced in full or, if content is extracted, then it should be fully credited to SEAI.

## Sustainable Energy Authority of Ireland

SEAI is Ireland's national energy aut hority investing in, and delivering, appropriate, effective and sustainable solutions to help Ireland's transition to a clean energy future. We work with the public, businesses, communities and the Government to achieve this, through expertise, funding, educational programmes, policy advice, research and the development of new technologies.

SEAI is funded by the Government of Ireland through the Department of Communications, Climate Action and Environment.

- © Sustainable Energy Authority of Ireland

Reproduction of the contents is permissible provided the source is acknowledged.

## Contents

| Executive summary....................................................................................................................................................................................            |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 1. Introduction ............................................................................................................................................................................................. 5  |
| 1.1 Retrofitting in the context of Net Zero.......................................................................................................................... 5                                          |
| 1.2 Report structure and methodology............................................................................................................................. 10                                             |
| 2. The retrofitting customer journey................................................................................................................................................ 12                          |
| 2.1 Considering ........................................................................................................................................................................... 12                   |
| 2.2 Organising.............................................................................................................................................................................. 14                  |
| 2.3 Installing and operating ................................................................................................................................................... 16                              |
| 3. The barriers to retrofitting .............................................................................................................................................................. 18                |
| 3.1 Capability barriers............................................................................................................................................................... 20                        |
| 3.2 Opportunity barriers .......................................................................................................................................................... 21                           |
| 3.3 Motivation barriers ............................................................................................................................................................. 23                         |
| 4. Solutions................................................................................................................................................................................................. 26 |
| 4.1 Solutions to address financial barriers........................................................................................................................ 29                                           |
| 4.2 Solutions to reduce hassle............................................................................................................................................... 32                                 |
| 4.3 Solutions to raise awareness .......................................................................................................................................... 35                                   |
| 5. Areas for further research................................................................................................................................................................ 41                 |
| Recommendations and conclusion ............................................................................................................................................. 42                                  |
| 6.                                                                                                                                                                                                               |
| 7. Glossary ..................................................................................................................................................................................................   |

## Executive summary

## Overview

11.4% of Ireland's total greenhouse gas emissions derived from the residential sector in 2021. 1 2 Improving a building's energy efficiency by retrofitting is key to reducing these emissions. The Irish government's Climate Action Plan recommends a 40% reduction in emissions from the residential sector, 3  including by achieving a target of implementing 500,000 home energy upgrades (to B2 Building Energy Rating (BER) standard)

by 2030 . 4 The success of Ireland's ambitions in this area ultimately hinges on homeowners shifting their behaviours, adopting new technologies and investing in the energy efficiency of their homes. This is why the Sustainable Energy Authority of Ireland (SEAI) has commissioned the Behavioural Insights Team (UK) to summarise the evidence on what works to encourage uptake of retrofits. This report is part of the behavioural insights for policy series commissioned by SEAI that also includes reports on driving the adoption of electric vehicles and heat pumps in Ireland. 5   6

## The retrofitting customer journey

To better understand retrofitting from the perspective of the Irish homeowner, we initially developed a retrofitting customer journey, outlining the common steps, decision points and frictions that affect homeowners looking to retrofit their homes in Ireland. The customer journey consists of six key stages that are distinguished by the unique behaviours involved. These are illustrated in the graphic below.

## The retrofitting customer journey

<!-- image -->

## The barriers to retrofitting

Throughout the retrofitting journey, customers encounter a multitude of barriers that can be mapped to three categories of factors, as outlined by a prominent theory in the area of behaviour change: the COM-B model. 7 This includes capability barriers which affect the homeowners' psychological and physical ability to retrofit, opportunity barriers which refer to environmental factors that can discourage homeowners from retrofitting, and  motivation  barriers  which  affect  our  mental  processes  and  ultimately  drive  homeowners'  decision  to retrofit. Outlined below are the barriers to retrofitting, across the retrofit customer journey.

|                      |                                                                                                                                                      | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   |
|----------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|
| Barrier category     | Barrier                                                                                                                                              | Trigger                                     | Research                                    | Decide                                      | Set up                                      | Install                                     | Use                                         |
|                      | Lack of awareness of what retrofits are, and their benefits                                                                                          | ✔                                           | ✔                                           | ✔                                           |                                             |                                             |                                             |
| Capability barriers  | The number of options and decisions involved in the retrofitting process                                                                             |                                             |                                             | ✔                                           |                                             |                                             |                                             |
| Capability barriers  | Lack of financial literacy                                                                                                                           |                                             | ✔                                           | ✔                                           |                                             |                                             |                                             |
| Opportunity barriers | *High costs of retrofitting                                                                                                                          | ✔                                           | ✔                                           | ✔                                           |                                             |                                             |                                             |
| Opportunity barriers | Split incentives to retrofit between homeowner landlords and tenants                                                                                 |                                             |                                             | ✔                                           |                                             |                                             |                                             |
| Opportunity barriers | *Lack of skilled installers able to carry out retrofitting works to required standards                                                               |                                             |                                             |                                             | ✔                                           | ✔                                           |                                             |
| Opportunity barriers | Lack of social opportunity due to lack of visibility of retrofits                                                                                    | ✔                                           | ✔                                           |                                             |                                             |                                             |                                             |
| Motivation           | *Friction costs and hassle involved throughout the retrofitting process                                                                              | ✔                                           | ✔                                           | ✔                                           | ✔                                           | ✔                                           | ✔                                           |
| Motivation           | Moderate perceived benefits of retrofitting due to large upfront costs and benefits that arise gradually over extended periods of time               | ✔                                           | ✔                                           | ✔                                           |                                             |                                             |                                             |
| barriers             | Risk aversion due to perceived risks relating to; the finances of funding retrofits, the performance of retrofits, finding competent installers etc. |                                             |                                             | ✔                                           |                                             |                                             |                                             |
| Motivation           | Low consumer trust towards messaging, financing options and installer quality                                                                        | ✔                                           | ✔                                           | ✔                                           | ✔                                           | ✔                                           | ✔                                           |

- * indicates the most significant priority barriers to address.

## Solutions

We developed a list of 22 potential solution ideas on how to encourage retrofitting among Irish homeowners, drawing on: insights from our evidence review; our expertise in behavioural science; and through close collaboration with SEAI. We designed these solutions to address the prioritised barriers identified above, tailoring them to the specific challenges within the Irish context: (i) addressing financial barriers, (ii) reducing hassle, (iii) raising awareness, and (iv) upstream solutions that focus on the functioning of institutions, businesses and markets which in turn influence consumer behaviours. The purpose of these ideas is to show examples of ways to address challenges to retrofitting uptake using behavioural science, on the basis of best practice, and therefore should not be considered to be an exhaustive list.

Among our solution ideas, we recommend that policymakers focus on the solutions to the challenges that reflect the most significant barriers to retrofitting adoption in Ireland. These include financial and hassle barriers, as well as a lack of installers, while also prioritising the specific solution ideas with a combination of high potential impact and high feasibility for implementation, as outlined below.

## Further addressing the financial barriers that prevent homeowners from retrofitting by:

- 1. Conducting a behavioural audit of the existing loans/grants landscape to determine how grants can be simplified and reframed, making them easy and attractive.
- 2. Expanding and expediting a range of green financing solutions (such as green extensions to mortgages and loans) that help homeowners finance retrofits at favourable rates.

## Further addressing the hassle and friction that affect homeowners throughout the retrofitting customer journey by:

- 3. Conducting a behavioural audit on the One Stop Shop scheme to ensure the process is as streamlined as possible and is framed in the most attractive way, as well as taking lessons on what has worked well from One Stop Shop and applying these to other policies.
- 4. Reducing hassle across other points of the customer journey , for example by making it easier for homeowners to access financial solutions, developing new financial solutions, and making it clear how to translate insights from the BER into action.

## Further addressing the challenges around promoting installer training to help counteract the lack of skilled installers that can carry out retrofits by:

- 5. Linking apprenticeship training to the One Stop Shop scheme to ensure guaranteed demand for new workers.
- 6. Mandating (or incentivising) large new-build developers and builders to use a certain proportion of trained retrofitting apprentices / new installers each year , to ensure a higher flow of skills into this industry.
- 7. Mandating retrofit training and energy efficiency to be included by default into the standard curricula of relevant education programmes in the construction sector.

Additionally, policymakers should also consider other solutions with a combination of high impact and feasibility as these may represent the 'lower hanging fruit' in terms of encouraging retrofitting behaviours. These include:

## Increasing awareness and normalising uptake by:

- 8. Making retrofits more visible and normative (including by introducing standardised, recognisable signage to indicate when properties are being retrofitted, displaying salient labels on property listings and hosting open home events) to raise awareness of retrofits and their benefits.

## Harnessing the BER to maximise its potential by:

- 9. Conducting a behavioural audit on the BER to determine how behavioural insights can be applied to the reports to make them more interpretable and easier to act upon.

## Recommendations for further research

Given the surprising number of gaps in the retrofitting-related literature, we also provide suggestions for future research in this area. More specifically, we recommend:

- 1. Evaluating existing and candidate policies: Further research efforts should involve rigorous and regular evaluation of policies to determine efficacy.
- 2. Deep-dive into the key pain points within the customer journey: For example, conducting more research to highlight the main areas of hassle and points of friction for customers across the retrofitting customer journey. This could involve using quantitative data to identify key points within the customer journey with high drop-out rates, and then using qualitative research to explore the reasons behind them. Identifying these points of friction could then allow policymakers to design targeted solutions to boost uptake of retrofits, which would be particularly useful for customers getting retrofits outside of the One Stop Shop service.
- 3. Segmenting and conducting detailed analysis of the Irish population : Segmentation can be valuable in helping policymakers identify the 'low hanging fruit' of customers that are already eng aged and willing to retrofit. It can equally shed light around those customers who will be particularly challenging to target as well as customer segments that have been left behind.
- 4. Conduct further research into the supply-side installer challenges: At present, there is a lack of quantitative research into the barriers to increasing the supply of trained, skilled retrofit installers in Ireland. Future research should be conducted with installers and representatives from industry with the aim of identifying the most significant barriers based on their prevalence.

## 1. Introduction

The present report was commissioned by the Behavioural Economics Unit (BEU) at Sustainable Energy Authority of Ireland (SEAI) to explore retrofitting among residential homeowners within Ireland. This report is part of the behavioural insights for policy series commissioned by SEAI that also includes reports on driving the adoption of electric vehicles and heat pumps in Ireland. 8   9  The aims of this report are twofold. Firstly, we aim to provide a comprehensive evidence synthesis of the known barriers to retrofitting of homes. Secondly, we aim to explore solutions to encourage retrofitting that take into consideration the Irish context. We apply a behavioural science lens to both of these aims throughout.

## 1.1 Retrofitting in the context of Net Zero

Buildings and construction account for an estimated 39% of global carbon emissions: 10  11% from their materials and construction and 28% from the energy used to heat, cool and light buildings. 11  In Ireland, the residential sector alone was responsible for 11.4% of the country's total greenhouse gas emissions in 2021 the fourth highest emitting sector after agriculture (37.5%), transport (17.7%) and energy industries (16.7%). 12 13

There are multiple ways to reduce these emissions, including a shift to cleaner energy sources and smarter consumption within the home (for example appliance use). However, a major part of the solution must be to reduce energy demand by improving the efficiency of the buildings themselves. This not only cuts emissions quickly, but also cuts bills and helps address future infrastructure and demand-management challenges by partially offsetting the otherwise huge increase in demand for renewable electricity as more of our transport and heating systems are electrified. In recognition of this, governments worldwide have emphasised retrofitting -that is, the implementation of modifications to existing buildings with the purpose of improving energy efficiency and / or reducing energy demands - as a key component to their Net Zero strategy and policy.

## The policy challenge

In Ireland, the National Retrofit Plan, published in 2022 as part of the broader Climate Action Plan (2021), outlines the country's retrofitting targets. The plan also sets out how these can be achieved to help meet the country's legally binding commitments to achieve Net Zero emissions by 2050, as well as achieving a 51% reduction in emissions by 2030 (compared to 2021 levels). 14   15

More specifically, the Irish Climate Action Plan highlights the need for Ireland to reduce emissions in the residential sector by 40%: from 7 MtCO2eq in 2018 to 4 MtCO2eq in 2030. 16  This relies, in part, on achieving a target of implementing 500,000 home energy upgrades (to B2 Building Energy Rating (BER) standard) by 2030 . 17 This will likely not only involve improvements to building and fabric efficiency, but improvements in heating systems through the adoption of heat pumps for many homes.

As shown in Figure 1, the number of retrofits in Ireland since 2019 has declined, although it is likely that these numbers have been significantly impacted by the Coronavirus pandemic. Furthermore, BER assessments indicate that 80% of the homes and buildings in Ireland have a BER of C or lower.

With this in mind, it is predicted that in order to reach current 2025 targets, approximately 185,000 homes require retrofits (over 83,000 to a B2 or cost-optimal level). 18  This will be followed by 75,000 B2-equivalent home retrofits per year from 2026 - 2030 (see Figure 2). Additionally, it is expected that by 2025, almost 90% of B2 retrofits will involve installing a heat pump. 19 In summary, there is not a great deal of 'low hanging fruit', and achieving the targets will requi re widespread uptake of deep retrofits, presenting financial and practical challenges.

Figure 1: Number of retrofits in Ireland since 2019 20

<!-- image -->

Note: Figure 1 includes retrofits completed through four main SEAI grant schemes which include individual energy upgrade grants scheme, fully funded energy upgrade scheme, One stop shop scheme and deep retrofit grant scheme.

Figure 2: Projected cumulative number of home upgrades 2019-2025 21

<!-- image -->

## The current retrofit policy landscape in Ireland

To achieve these ambitious targets, the Irish government has implemented a number of policies and initiatives aimed at promoting retrofit uptake. 22  We outline the existing retrofit policy landscape in Ireland in Table 1 below.

Table 1: A sample of the policies, schemes and initiatives that encourage retrofitting in Ireland

| Irish retrofit policy                                               | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
|---------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Increasing awareness                                                | Increasing awareness                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| National awareness campaign                                         | SEAI has implemented a number of campaigns with the ultimate goal of raising national awareness of retrofitting. The most recent retrofit demand generation campaign - aimed at increasing the desirability of retrofits and encouraging people to visit the SEAI website - prompted customers t o 'Discover a new world of comfort' by retrofitting. Previous national awareness campaigns have focussed on educating the public about building energy ratings. The Home Energy Upgrade campaign went live in September 2021. Following the launch, web traffic for the home energy grants page increased by 93% compared to the previous year. In February 2022, the National Retrofit Scheme was announced. This led to a twofold increase in web traffic for the home energy upgrades campaign page. |
| Community-based social marketing scheme                             | SEAI is preparing to launch and evaluate community-based campaigns featuring local events with SEAI support desks, One Stop Shop agents, green finance providers, BER assessors and others to provide retrofit information to local people.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |
| Providing tools and services to boost understanding of retrofitting | Providing tools and services to boost understanding of retrofitting                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Online retrofit tools                                               | The SEAI website includes multiple tools and functions designed to help inform Irish customers. 23 These include energy efficiency calculators to give more tailored advice, 24 clearly presented guidance about grant and funding options, 25 and a tool for tracking existing BER ratings for properties. 26 These functions, amongst others, can help direct and educate customers. The B2 comparison tool went live in March 2022 and has received a total of 8,697 page views (7,567 unique page views) as of August 2022. The page accounts for 0.49% of the total unique views on the SEAI website.                                                                                                                                                                                               |
| Personalised BER roadmaps for homeowners                            | SEAI provides a personalised roadmap for homeowners on how to upgrade their home to a BER B2, including a new BER Advisory report (current EE and future EE potential) and an interactive homeowner BER tool. 27 For a standard non-complex building, the cost of a BER assessment will depend on the type, size and complexity of the dwelling and ranges between € 150.00 and € 300.00. The report is designed to be clear, educational and to incentivise retrofitting. The SEAI's BER roadmap page went live in July 2021. In the period August 2021 to January 2022, the page received 13,356 views. In the subsequent period February 2022 to July 2022, the page received 23,875 views (a 79% increase).                                                                                          |
| Reducing the hassle of retrofitting                                 | Reducing the hassle of retrofitting                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| The One Stop Shop                                                   | SEAI launched a One Stop Shop service in February 2022 that is still growing and developing. 28 A list of One Stop Shop providers can be found on the SEAI website. 29 These provide the full service including: Home energy assessment (a technical surveyor will advise on the best upgrades and provide a technical design); grant                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |

|                                                                                   | application; project management; contractor works; quality assurance; follow up BER; and finance options if upgrading to a B2 BER (some One Stop Shops can offer finance options through their finance partners). As of December 2022, there are 12 One Stop Shop agents registered with SEAI. There are also 10 companies progressing through registrations and most of these will hopefully be registered by early 2023. In 2021, 804 pilot homes were retrofitted (B2 or better) through the One Stop Shop and 293 were retrofitted in 2022. Following the official launch of the scheme in February 2022, 343 homes were retrofitted to a B2 or better as of end of December 2022.   |
|-----------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Providing funding options to finance retrofits                                    | Providing funding options to finance retrofits                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           |
| One Stop Shop                                                                     | As stated above, the One Stop Shop provides wider access to finance for homeowners upgrading their homes to B2 BER.                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      |
| Fully funded energy upgrade (previously known as Warmer Homes Scheme)             | SEAI offers free energy upgrades to homeowners who receive certain welfare payments. 30 An SEAI survey recommends upgrades to homes based on factors such as property age, size, existing heating system and condition. 31 In 2019, 3,426 homes were retrofitted (B2 or better and non B2 homes) through this scheme; 1,473 were retrofitted in 2020; 2,398 were retrofitted in 2021; and 4,438 were retrofitted in 2022.                                                                                                                                                                                                                                                                |
| Individual energy upgrade grants (previously known as Better Energy Homes Scheme) | For customers who would rather handle their own retrofitting, or need to take a step-by-step approach, SEAI provides funding and grant options for specific upgrades. 32 33 These can be for attic insulation, wall insulation, heat pumps, and more. 34 In 2019, 18,711 homes were retrofitted (B2 or better and non B2 homes) through the scheme; 12,307 were retrofitted in 2020; 7,634 were retrofitted in 2021; and 11,806 were retrofitted in 2022.                                                                                                                                                                                                                                |
| Energy efficiency obligation scheme (operating until 2030)                        | This scheme, which is to comply with the EU Energy Efficiency Directive, obliges energy suppliers to support energy efficiency and retrofitting projects in homes and businesses. 35                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     |
| Better Energy Communities                                                         | This scheme supports energy-efficiency community projects through capital funding, partnerships and technical support. Community projects are delivered to homeowners, community groups (e.g., GAA clubs, libraries and sports halls), private sector organisations (e.g., retail stores) and public sector bodies (e.g., public sector schools and facilities) using a cross-sectoral approach, where a partnership between a diverse selection of organisations is essential. In 2022, 295 community energy projects (B2 or better) were delivered successfully.                                                                                                                       |
| Residential retrofit low-cost loans                                               | SEAI is working with the Department of Environment, Climate and Communications and the Strategic Banking Corporation of Ireland to develop low-cost loan schemes that aim to be widely available through high street lenders.                                                                                                                                                                                                                                                                                                                                                                                                                                                            |

| Improving access to skilled installers                                          | Improving access to skilled installers                                                                                                                                                                                                                                                        |
|---------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Upskill and training installers and BER assessors                               | SEAI is developing forecasts for skills and apprenticeships, 36 37 as well as training programs. We are also trying to ensure that the required number of BER assessors are in place, through the development of new quality assurance frameworks that support the scaling-up of activity. 38 |
| Fostering an energy efficient default for Ireland as it transitions to Net Zero | Fostering an energy efficient default for Ireland as it transitions to Net Zero                                                                                                                                                                                                               |
| Multiple upstream regulatory and market initiatives                             | The Department for Environment, Climate and Communications aims to foster a societal backdrop that continues to prioritise energy efficiency. One example is the proposal for a minimum BER rating requirement for private rental properties (from 2025).                                     |

## Retrofitting - a behavioural challenge

Recent estimates predict that around 60% of future emissions reductions will depend on behavioural changes, both through the curtailment of high-carbon activities and the adoption of low-carbon technologies. 39 In the context of retrofitting the home, this means that the success of Ireland's ambitions, as well as the range of policies and initiatives presented above, ultimately hinges on homeowners shifting their behaviours, adopting new technologies and investing in the energy efficiency of their homes.

Many behavioural challenges remain with regard to retrofitting uptake. These include low consumer demand and confidence, low levels of awareness, high amounts of hassle associated with retrofitting, as well as the communication and take up of financial solutions to help fund retrofits. Given these challenges, it is critical for policymakers to consider retrofitting uptake through a behavioural lens. This report aims to facilitate this by presenting a comprehensive synthesis of the barriers to retrofitting (behavioural and otherwise), and by exploring behaviourally-informed solution ideas to promote retrofitting uptake in Ireland.

## Relevant context

It is important to acknowledge that this report was developed in the midst of the cost of living and energy crises . During the period May 2021 to May 2022, Irish consumer prices increased by 7.8% on average, representing the largest annual increase in consumer price index since 1984. 40  In parallel, the energy crisis, partly brought on by the ongoing conflict in Ukraine, has led to a sharp rise in energy costs in Ireland, 41  while also increasing the proportion of Irish households living in energy poverty to 29%, the highest ever recorded rate. 42 With this in mind, it is crucial to consider the financial implications for consumers, given the high costs that are associated with retrofitting homes, while also acknowledging that the need for energy savings has never been greater. These circumstances present an even greater rationale for governments and businesses to promote the retrofitting agenda, giving impetus to bold and ambitious initiatives that seek to incentivise and support consumers.

This report was also written in the context of the Irish housing crisis , which has seen the supply of rental homes lag behind demand, causing significant shortages of available rental housing and steep increases in the cost of renting. This crisis has three major implications that relate to retrofitting: firstly, there is a high demand on the construction sector to build new housing, which is potentially shifting focus from retrofitting existing housing stock. Secondly, the housing crisis may be compounding challenges around skilled labour shortages in Ireland, as it may act as a barrier in attracting skilled labour from overseas (this is discussed in more detail in the Barriers section of the report). Thirdly, the ongoing housing crisis may place constraints on some of the proposed solutions of the report, particularly those which relate to addressing the barrier of split incentives between landlords and tenants within the rental housing market. 43

It is also worth acknowledging the low energy efficiency of Ireland's current housing, which has significant implications for the depth of retrofits required to increase energy efficiency and, in turn, the cost of implementing retrofits. For context, approximately 70% of homes in Ireland were built before 1983.  44 Although recently constructed dwellings in Ireland are far more energy efficient (98% of homes built between 20152020 are grade BER 'A'), 45 it is estimated that 1 million+ homes in Ireland (up to 80% of Irish homes) have a BER rating of C and lower. 46   47 Among these, an estimated 105,000 are rated F while 155,000 are rated G - the two lowest BER ratings. 48  Based on SEAI estimates, retrofitting all G-rated homes in Ireland alone will require an investment of several billion euro which presents a significant financial barrier, particularly to homeowners of lower energy efficient homes.

Certain dwelling types can also pose specific retrofitting challenges. For example, approximately 18% of Irish dwellings fall under the category of 'traditionally built homes', such as Victorian or Georgian houses, which -tend to be less energy-efficient 49  and have protected structure status that requires planning permission prior to retrofitting. 50 51 As a result, owners of traditional-built homes are often apprehensive about installing thermal retrofits due to the risk of removing or damaging heritage features (such as sash windows or brick facades). 52

Similarly, apartment blocks (which account for circa. 8% of Irish dwellings) 53  present unique regulatory and practical barriers to retrofitting which can be prohibitive to occupants. For instance, apartment owners are more likely to be leasehold so require specific approvals to make home improvements. Apartment buildings, meanwhile, may require building-wide retrofitting which presents many practical barriers that limit its feasibility (including securing consent and financial contributions from individual apartment occupiers). 54

## Box 1: The context of oil heated homes in Ireland

The high share of oil-heated homes among Irish housing stock also represents a potential barrier for retrofit adoption. In 2022, oil accounted for an estimated 42% of all energy used in the Irish residential sector. 55 This may demand deeper retrofits involving the replacement of heating systems, for example through the adoption of heat pumps, that span beyond just fabric retrofits in order to reach B2 energy efficiency standards, resulting in potentially larger upfront costs for customers.

## 1.2 Report structure and methodology

## Defining retrofits in the context of this report

This report will explore behaviourally-informed and evidence-based methods to boost uptake of fabric retrofits in residential buildings among Irish homeowners (both owner-occupiers, as well as landlords).

Although retrofitting can encompass a variety of behaviours and modifications to the make-up of a building, broadly speaking there are two categories of retrofit: fabric retrofits, which include material changes that improve the energy efficiency of the home; and changes to energy systems which may involve the installation of solar panelling or heat pumps. Both of these categories of retrofitting present unique challenges and considerations for both policy makers and customers.

This report focuses primarily on fabric retrofits, which includes upgrading or installing insulation (cavity wall, attic, underfloor, etc.), double or triple glazing windows, or improving ventilation and air flow. We have also included the installation of SMART energy technology and efficient appliances, since this has not been addressed in prior SEAI research. Outside of scope are installations of heat pumps (already explored in

another SEAI report) 56 , solar panels and replacements of wood or gas burners and stoves with electric and biomass models.

Throughout the report, we also differentiate retrofits based on their level o f 'deepness', that is to say the intensity of the particular fabric retrofit type or magnitude of works typically required (for example solid wall insulation across the entire home is a deeper retrofit than loft insulation) and the number of retrofits (for instance cavity wall insulation and loft insulation vs loft insulation alone).

## Report structure

This report aims to provide a comprehensive synthesis of barriers and solutions for encouraging the uptake of retrofitting among Irish homeowners. Firstly, we present a retrofitting customer journey that places the multitude of behaviours required of homeowners and landlords into six key stages. Secondly, we outline the barriers to retrofitting based on the COM-B model of behaviour change, 57  while also signposting which barriers relate to specific stages of the customer journey. Finally, we explore solutions to retrofitting by leaning on evidence from the literature, as well as proposing specific solution applications to the unique challenges faced in the Irish context, based on a solution development workshop with SEAI experts.

## Research methodology

Our research involved conducting an in-depth evidence review. We searched for and included evidence which focused on the uptake of retrofitting among homeowners, with a particular focus on evidence exploring retrofitting within Ireland, taking into account the Irish social, infrastructural and political context. This involved reviewing a variety of sources from both the academic literature -such as articles published in peer-reviewed journals -as well as evidence from the grey literature, such as government research reports and government-commissioned surveys. Overall, 112 sources were cited as part of the evidence review, 49 of which were from peer-reviewed journal articles. We outline our search methodology, across the following six steps:

- 1. Identified databases, search terms and criteria: We identified databases to be searched (such as ScienceDirect, Google Scholar), search terms and search strings, and ensured an optimal calibration of search parameters, balancing breadth and depth. Relevant search strings were created, such as 'barriers to retrofitting uptake, interventions to encourage retrofitting'.
- 2. Conducted full search: We conducted the full search of the literature, accessing a range of databases and sources, as identified above.
- 3. Removed duplicates, screened and selected sources for the review: We then removed duplicates that resulted from searches in multiple databases and screened paper abstracts against our selection criteria to confirm whether each source would be selected for full text review.
- 4. Reviewed full texts: We reviewed sources and assessed these against prioritisation criteria, for example prioritising more recent publications, quantitative evaluations and RCTs, or high-quality qualitative evaluations.
- 5. Hand-search: We then manually hand-searched for further sources to supplement the systematic search.
- 6. Assessed the quality of the sources and incorporated the evidence within the report

In addition to our literature search, other steps used to generate insights for the present report included preliminary scoping with SEAI, the provision of data and information held by SEAI on retrofitting within the Irish context, as well as a series of solution workshops between BIT and SEAI designed to develop tailored solutions for the Irish context (see Solution section for more detail).

## 2. The retrofitting customer journey

Irish customers would typically need to go through several steps to successfully install retrofits in their home. Although the route that each person takes to retrofit will vary based on their individual context (for example, depending on whether they live in a heritage building or an apartment, whether they are engaged with the environment and Net Zero, or whether they are eligible for certain SEAI funding options), everyone experiences similar decision points and frictions that influence whether they complete their journey.

In this report, we have defined the Irish retro fit customer journey by six stages: 'Trigger', 'Research', 'Decision to proceed', 'Set up', 'Installation' and 'Usage'. Each of these stages of the customer journey is distinguished by the unique behaviours involved: from initially becoming aware of retrofits, conducting research, deciding on proceeding with a retrofit, setting up installations, through to installation and eventual usage. A summary of the Irish retrofit consumer journey is shown in Fig. 3 below.

## Figure 3: The retrofitting customer journey

<!-- image -->

## 2.1 Considering

At the outset, consumers consider whether or not they want to improve the energy efficiency of their homes. In Ireland, awareness of the need for home energy efficiency is high, 58  but many people only start considering home retrofitting when they are triggered by specific events (such as moving house) then continue to debate retrofitting while they research its cost and feasibility. When considering, customers go through the 'trigger' and the 'research' stage.

## 2.1.1 Stage 1: Trigger

Retrofit customers enter their journey in the trigger stage, when a key event or growing personal motivation prompts them to engage with home energy efficiency and retrofitting. 59   Some of the key potential trigger events are summarised below (table 2), drawing from our own behavioural analysis and analysis from SEAI. 60

## Table 2: Summary of factors that may drive homeowners to consider retrofitting

| Category                | Drivers to consider retrofitting   | Drivers to consider retrofitting                                                                                                            |
|-------------------------|------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|
|                         | •                                  | Receiving a hefty bill from an energy provider prompts people to notice a price increase                                                    |
| Prompt or reminder from | •                                  | Family, peers, and neighbours installing retrofits (SEAI data suggests that this is a contributing trigger for about 5% of Irish customers) |
| changing context        | •                                  | Seeing an advertisement or hearing about SEAI in the media Tenants complaining to landlords about energy bills may drive consideration      |
|                         | •                                  |                                                                                                                                             |
|                         | •                                  | Homeowners reviewing or purchasing a BER advisory report                                                                                    |

- · Moving into or purchasing a new property and viewing the BER

## Key life event

## Government support

## Motivational drivers

- · Renovating a home , which already involves disruption (such as a kitchen upgrade or extension; SEAI data suggests this is a contributing trigger for about 15% of Irish customers). Renovation contractors may also prompt homeowners to consider retrofitting
- · Finalisation of mortgage repayments freeing up funds for retrofits
- · Heating system failure may prompt people to consider home warmth and heat pumps
- · Changing life circumstances such as the addition of a baby to a family, starting a new job, retirement etc.
- · Upstream building regulations that need to be adhered to during renovation
- · Funding options become available or salient
- · Motivation to save money on energy bills (SEAI data suggests this is a contributing trigger for about 65% of Irish homeowners)
- · Motivation to increase the comfort of their home (SEAI data suggests this is a contributing trigger for about 50% of Irish homeowners)
- · Motivation to increase a property's value (SEAI data suggests this is a contributing trigger for about 15% of Irish homeowners)
- · Motivation to protect the environment (SEAI data suggests this is a contributing trigger for about 25% of Irish homeowners)
- · Motivation to install a heat pump : Getting some properties heat pump ready or maximising the effectiveness of a heat pump can require retrofitting

## 2.1.2 Stage 2: Research

Next, customers move into the research stage, when they gather relevant information about retrofitting and familiarise themselves with options and funding. This process can happen through online searches, conversations with neighbours, peers, or professionals as well as by talking to local contractors or engaging with an SEAI Home Energy Assessment and BER Advisory report. Customers continue to consider their options during the research stage, which gives them a better understanding of the advantages, drawbacks, and processes associated with different options. This stage can involve the following activities:

- · Researching a property's existing energy efficiency and BER: Customers can search online for the SEAI National BER Register 61 to view their property's BER certificate, or may have a copy of their BER on file at home. The BER certificate is designed to be clear, educational and to incentivise retrofitting and give customers information about the existing and potential energy performance of their home as well as giving tips (and cost information) about potential solutions. 62  The SEAI website also provides further information that helps customers to understand their BER. 63  Overall, this gives customers information about the energy efficiency of their property. Many properties have BER reports already, (as of December

2022, there are 834,064 records that aren't expired, that is to say no more than 10 years old), however, if a perso n's property does not yet have a BER or it has expired (after 10 years), homeowners need to arrange a BER assessment. This can be done by searching on the SEAI National Register of BER Assessors 64 or telephoning local contractors. This assessment costs between €150 and €300 for a standard non-complex dwelling.

- · Scoping the appropriate type of retrofitting: For instance, trying to understand the required depth of retrofit. In Ireland, the BER certificate is accompanied by an Advisory Report which provides guidance on how to improve a home's BER, with specific guidance on reaching B2 standard. Many people at this stage might speak to a trusted advisor, such as their builder or a knowledgeable acquaintance, and undertake further information searches online.
- · Exploring cost &amp; funding options (such as grant eligibility, loan, savings): This entails searching online to check eligibility for retrofitting grants or funding schemes, for instance on the SEAI website. 65   66 Consumers might also search for low-interest loans for retrofitting. 67   68  Lower income households and those eligible are also able to access grants for fully funded energy upgrades. 69
- · Researching potential installers (such as One Stop Shop): This could entail searching for contractors on the SEAI website (for example in the One Stop Shop 70  or Home Energy Grants 71  directory pages), looking for local installers and contractors, or contacting trusted installers that they have used for previous home renovations. In the case of One Stop Shops, SEAI has set up a new pilot data service 'NAS Trusted Partner Pilot Programme' which enables One Stop Shops and third parties providing services to One Stop Shops to look at different routes to a B2 or better, or the best cost optimal retrofit for a house without having to visit the home. This allows One Stop Shops to carry out rapid prototyping for homeowners to inform and encourage them to make that decision if they want to engage further.

## 2.2 Organising

Next, customers decide whether to go forward with retrofitting, beginning with arranging the set up. This period of the customer journey is burdened with administrative tasks (including arranging the installation at a time that suits both parties, the difficulty of which can be amplified if the contractor has limited availability), as well as difficult decisions requiring real compromises (such as the cost of retrofitting). Overall, this makes people at the 'organisation' stage prone to procrastination and decision paralysis, while arranging for their homes to be retrofitted. When organising, customers go through the 'Decision to proceed' and the 'Set up' stages.

## 2.2.1 Stage 3: Decision to proceed

At this point, people consider what they have learnt about retrofitting: ' Can I afford to retrofit? What kind of retrofit should I go for? What funding options should I use? Will retrofitting be too much hassle? How much might I save in the long run? Can I spare the effort needed to arrange all this? Is it worth it?' . Based on these type of questions, they choose either to proceed or to end their journey. Though this stage is simple in that it is not characterised by multiple additional behaviours , it is critical and behaviourally significant in that there are many cognitive matters to consider when designing effective policy. This is a critical stage for uptake of retrofits that should be targeted with tailored interventions when developing solutions to promote them.

## 2.2.2 Stage 4: Set up

During the administratively intensive 'set up' stage, the consumer arranges everything that needs to align to enable installation of a retrofit, including securing funding, preparing the property or identifying contractors. Some of the key behaviours are:

- · Arranging home energy surveys (if necessary): If they have not already, customers may wish to arrange and undertake a Home Energy Assessment at this stage, in order to fully clarify the types of retrofitting work and depth that they need. It is worth noting that such an audit is incorporated into multiple services that SEAI provide, including the Fully Funded Energy Upgrade and the One Stop Shop Scheme. This entails contacting BER assessors. 72

- · Arranging funding (such as grant, loan, savings): This can involve applying for a variety of funding options, with different eligibility and application processes (as summarised in Table 3 below). Many people drop out at this administratively challenging stage because they do not have the funds to complement the grant (30%), find the process too confusing (10%) or are too busy with other priorities. 73
- · Arranging installation: Irish customers will have differing responsibility for arranging, scheduling, and managing the retrofit installation, depending on the chosen funding option (see Table 3). For example, a One Stop Shop or Fully Funded Energy Upgrade Scheme grantee has minimal involvement in the project administration and associated hassle as many of the administrative elements of project management are handled by SEAI and the contractor (either an internal or an outsourced contractor). Some individuals may be able to finance the retrofitting projects with existing savings and may opt for arranging their own contractors or undertaking retrofitting work themselves if they are skilled enough. It is important to note, however, that if customers do proceed down this route, they would not be eligible for grants or energy efficiency loans. Further, whilst this approach avoids the need to deal with contractors, it may add further friction to the customer journey.

Table 3: Overview of grant funding schemes

| Funding option                                                                                                                                                         | Eligibility                                                                                             | Funding application process                                                                                                                  | Project management                                                                                | Average cost for homeowner                                                                                   |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------|
| Fully Funded Energy Upgrade Scheme                                                                                                                                     | Homeowners whose property was built before 2006 and who receive certain welfare payments.               | An individual applies for the SEAI scheme directly.                                                                                          | SEAI : allocates a surveyor, contractor and BER assessor.                                         | None                                                                                                         |
| One Stop Shop - full service                                                                                                                                           | Homeowners need to commit to completing a minimum level of energy upgrades and get to B2 energy rating. | Homeowners contact their preferred One Stop Shop agent. Agent surveys property and gives quotes. One Stop Shop agents then apply for grants. | One Stop Shop : arranges contractors to complete retrofit.                                        | The grant fixed amounts which is capped at €38,000 for private homeowners and €44,000 for housing bodies. 74 |
| Individual energy upgrade grants 2011 are eligible for insulation and heating controls homes built 2021 are eligible heat pumps and renewable Homeowner not have to to | and before for systems. does commit a minimum level                                                     | Homeowner (or contractor) applies for grant by post/online                                                                                   | Homeowner : arranges specific retrofitting works that are needed, contractor undertakes retrofit. | The grant fixed amounts for different measures, equivalent to approximately one- third of the cost.          |

Energy Efficiency Obligation Scheme -energy providers

Homeowners must contact their energy supplier or any of the other obligated parties to see if they are willing to provide support, before works begin. Receiving support will depend on the discretion of the obligated party. In addition, obligated parties must show that they were essential to the work on the home or business. This means it would not have been carried out at all, as quickly, or to the same extent, without their involvement.

Homeowners must contact their energy provider.

Homeowner arranges for the retrofits and the obligated party (energy supplier) will provide technical support or financial support or a mixture of both.

Under EEOS, the obligated parties can leverage existing SEAI grants which include the Individual Energy Upgrade Grants, One Stop Shop Scheme and Community Energy Grants Scheme to provide financial support towards retrofits in the residential sector. Based on this, the level of financial contribution by the obligated parties will vary. From 2023, obligated parties must achieve a minimum level of upgrade (100 kWh/M2/yr), a preand post-BER, and bring homes to a BER B2 or onto a B2 pathway.

## 2.3 Installing and operating

Finally, customers prepare their home for the task of retrofitting, undergo installation, and then hopefully reap the benefits of using energy in a retrofitted home. This stage involves the last-minute administration of preparing one's home , accommodating the contractors or doing the work oneself, familiarisation with the new retrofits, as well as a period of reflection about the whole process.

## 2.3.1 Stage 5: Installation

Customers are preparing for retrofitting work to be done in their property and ensuring that their homes and schedules are ready. Homeowners also experience the direct disturbance of retrofitting during this stage (in terms of noise, dust, privacy and space). During this stage, the main behaviours that occur include:

- · Preparing one's home for retrofitting: Rooms and walls often need to be cleared to make space for installers and to protect furniture and ornaments from dust and damage. 75  Therefore, homeowners often need to clear attics, rearrange furniture, find alternative accommodation, and even create time in their work schedule (for example arranging annual leave or working from home) before retrofitting can begin. These tasks may be difficult to accommodate for some people with restrictive work obligations or families, and take up time and cognitive bandwidth.
- · Installation takes place: This process takes up to 12 weeks depending on the property type and retrofit depth. 76 While this is happening, homeowners can experience a multitude of disturbances including loud

noises, dust, drafts and social fatigue, as interaction between installer and homeowner can introduce challenges.

Although the hassle and disruption at this stage of the customer journey is unlikely to act as a barrier to retrofitting for customers who have already reached this stage, it is worth noting that the perception of this hassle and disruption can act as a barrier to retrofitting for customers at earlier stages of the decision-making process. Furthermore, their experiences during this stage may also affect how likely they are to recommend retrofitting to others.

## 2.3.2 Stage 6: Usage

At this stage, a consumer will experience the impact of the retrofits, which may cause them to change their energy-use behaviours, become positive or negative advocates of the retrofits, or consider further works.

- · Changing energy usage: Realising that homes maintain a more consistent temperature and hold heat more after retrofitting, customers may change the way they use their heating systems. Typically, this would mean using less energy, but many customers start 'comfort taking', reapin g some of the benefits in increased comfort rather than solely in reduced energy use. Indeed, a recent large-scale analysis of 55,000 households in the UK found that, while people do tend to reduce gas consumption for a year after installing energy efficiency measures, energy use creeps back up to previous high rates 2-4 years after retrofitting. 77
- · Sharing retrofitting experiences: In an ideal world, the successful 'retrofitter' will become an ambassador for home retrofits and talk to family, friends, colleagues and neighbours about their experience of retrofitting. However, this will depend on how positive their experience was.
- · Individual undertakes BER assessment and their BER rating changes: Some individuals may proceed to undertake a final Home Energy Assessment in order to assess the new BER of their property. This is a mandatory step for all SEAI grant schemes whereby grants are only paid if the new BER certificate is published. 78  Some groups of people may be more likely to independently update their Home Energy Assessment, such as landlords who are updating their property listing or people who are about to sell their homes.
- · Considering further energy retrofits: If an individual has not carried out all retrofit measures on their home, they may consider further retrofits.

## 3. The barriers to retrofitting

As outlined in the customer journey, the stages of implementing a home retrofit include organising, considering, installing, and operating retrofits. When navigating this process, there are many barriers, varying in their nature, that can impact retrofit uptake. We explore them in this section, using the COM-B model of behaviour change to distinguish between three different types of barriers to retrofitting uptake: capability barriers, opportunity barriers and motivation barriers (see Box 1 for more detail on the COM-B model). 79 Within this section, we also provide signposts that differentiate between overarching barriers -applicable across several stages of the customer journey -and stage-specific barriers.

## Box 2. The COM-B model of behaviour change

<!-- image -->

When trying to influence behaviour -such as retrofit uptake -it is important to identify and address any specific barriers preventing behaviour change. One useful model for identifying behavioural barriers is the COM-B model of behaviour change 80 , which states that for a behaviour to be adopted, individuals must have sufficient capability, opportunity and motivation:

- · Capability refers to an individual's psychological and physical capacity to engage in the behaviour in question and can include having the necessary knowledge and skills.
- · Opportunity refers to the contextual factors that lie outside the individual's direct locus of control that make the behaviour possible or prompt it, such as the physical and social environment.
- · Motivation refers to the brain processes that energise and direct behaviour, including our goals and conscious decision-making, but also non-conscious factors such as cognitive biases, emotions and habit.

In Table 4 below, we provide a summary of the barriers to retrofitting, categorised based on the COM-B model, as well as indicating the relevant stage of the customer journey that the barriers relate to. It is important to note that some of these barriers are potentially more stubborn in discouraging homeowners to retrofit than others, and thus may have a disproportionate impact on retrofit uptake if addressed. These priority barriers are identified in the table below, marked with an asterisk.

Table 4: Summary of the barriers that affect retrofitting

|                      | Barrier                                                                                                                                              | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   | Relevant stage(s) of the customer journey   |
|----------------------|------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|
|                      | Barrier                                                                                                                                              | Trigger                                     | Research                                    | Decide                                      | Set up                                      | Install                                     | Use                                         |
|                      | Lack of awareness of what retrofits are, and their benefits                                                                                          | ✔                                           | ✔                                           | ✔                                           |                                             |                                             |                                             |
| Capability barriers  | The number of options and decisions involved in the retrofitting process                                                                             |                                             |                                             | ✔                                           |                                             |                                             |                                             |
| Capability barriers  | Lack of financial literacy                                                                                                                           |                                             | ✔                                           | ✔                                           |                                             |                                             |                                             |
| Opportunity barriers | *High costs of retrofitting                                                                                                                          | ✔                                           | ✔                                           | ✔                                           |                                             |                                             |                                             |
| Opportunity barriers | Split incentives to retrofit between homeowner landlords and tenants                                                                                 |                                             |                                             | ✔                                           |                                             |                                             |                                             |
| Opportunity barriers | *Lack of skilled installers able to carry out retrofitting works to required standards                                                               |                                             |                                             |                                             | ✔                                           | ✔                                           |                                             |
| Opportunity barriers | Lack of social opportunity due to lack of visibility of retrofits                                                                                    | ✔                                           | ✔                                           |                                             |                                             |                                             |                                             |
|                      | *Friction costs and hassle involved throughout the retrofitting process                                                                              | ✔                                           | ✔                                           | ✔                                           | ✔                                           | ✔                                           | ✔                                           |
|                      | Moderate perceived benefits of retrofitting due to large upfront costs and benefits that arise gradually over extended periods of time               | ✔                                           | ✔                                           | ✔                                           |                                             |                                             |                                             |
|                      | Risk aversion due to perceived risks relating to; the finances of funding retrofits, the performance of retrofits, finding competent installers etc. |                                             |                                             | ✔                                           |                                             |                                             |                                             |
|                      | Low consumer trust towards messaging, financing options and installer quality                                                                        | ✔                                           | ✔                                           | ✔                                           | ✔                                           | ✔                                           | ✔                                           |

Note: * indicates the most significant priority barriers to address

We explore each of these barriers further in the following section.

## 3.1 Capability barriers

Capability barriers refer to individuals' ability to perform a certain behaviour. For instance, they may relate to the physical or psychological ability, such as having the necessary levels of awareness, memory, attention span and cognitive skills to carry out a behaviour. In the subsection below, we outline the capability barriers that may affect retrofitting uptake.

## Lack of awareness

As we've seen in the customer journey, a key trigger for individuals considering retrofitting their home is becoming aware of what retrofits are and the benefits they could provide. One of the most commonly cited barriers to the adoption of retrofits is that many homeowners are unaware of the range of retrofitting options and how these can improve the energy efficiency of the home. 81   82

Surveys show that 70% of Irish home owners/occupiers and 60% of tenants think they can reduce energy consumption, and consider options to improve the energy efficiency of their homes. 83  However, 12% of homeowners who had not carried out home energy upgrades cited lack of knowledge as the main barrier to carrying out home energy upgrades, with 10% having never thought about home energy upgrades before. 84 This has improved recently, as the percentages citing not knowing what upgrades their home needed and not having thought about home energy upgrades had declined to 9% and 7% respectively over a one-year period. This change suggests that there is an increasing awareness of retrofitting among Irish homeowners that coincides with the ongoing national awareness-raising campaigns. 85  Although these survey findings do highlight the underlying knowledge of retrofits, it is important to note that the surveys referenced here did not measure knowledge of retrofitting directly. Rather, they specifically asked participants to self-report whether they thought they knew the answers which may adversely affect the validity of the findings.

Aside from knowing what retrofitting is, there is also the question of awareness of the financial and nonfinancial benefits that retrofitting can provide. This is critical as it can directly affect customer motivation to progress from the early trigger and research stages of the customer journey to the actual decision to proceed. Research shows that when homeowners are aware of the environmental, cost saving or other (comfort, health) benefits of retrofitting, they are more likely to invest in energy efficient upgrades. 86,87,88 There is also evidence that believing a retrofit will increase the property value boosts the motivation for instalments. 89  This is supported by SEAI research wherein 25% of homeowners cite the increased property value from retrofitting as one of the top three motivators. 90

## High number of options and decisions

The retrofitting customer journey involves important decisions at every stage, ranging from identifying the most suitable retrofits for a home to finding appropriate installers and navigating the numerous financing options available. The number of decisions may lead to the phenomenon of choice overload -where a large number of options and decision points can overwhelm individuals and lead to decision fatigue -making it harder to make a choice 91  and potentially leading homeowners to drop out of the retrofitting process entirely. 92

For example, Ireland offers a number of financial solutions available to homeowners including: grants such as the Individual Energy Upgrade Grants; low cost loans, such as the Residential Retrofit Loan scheme; and green mortgages. 93  Although the breadth of options ensures there are specific solutions to reflect the varying financial circumstances of Irish homeowners, there is a potential risk that the number of options may confuse and deter homeowners who are considering how they can finance their retrofit.

## Lack of financial literacy

The risk of choice overload is further compounded by low financial literacy (that is, the knowledge and skills relating to financial management and planning required to make well-informed financial decisions 94 ). A

comprehensive survey found that approximately 45% of Irish adults have poor financial literacy, more than in comparable countries (34% in Germany, 33% in the UK and 43% in the USA). 95

## 3.2 Opportunity barriers

The decision to retrofit a home can be also influenced by barriers within our environment, such as the choice sets we can choose from, underlying social and cultural norms, as well as the availability of resources such as money and time. Given the role of the immediate environment, it is this category of barrier that is particularly unique to the Irish context.

## High cost

The significant cost of retrofitting is a universal barrier to people undertaking energy upgrades in their home. 96  This is compounded by the fact that these costs are typically upfront while the benefits are delayed, requiring upfront capital or long payback periods that can be subject to high interest rates. 97  A 2016 survey of Irish consumers, found that over 70% of respondents indicated 'not having sufficient funds' as the primary barrier to improving the energy efficiency of the home. 98  More recently, 40% of Irish homeowners without home energy upgrades cited not having enough money as a barrier to carrying retrofits, while 38% indicated that the primary barrier preventing them from installing retrofits was that they are 'too expensive'. 99

<!-- image -->

## Behavioural insight

Hyperbolic discounting: Immediate costs and benefits loom larger than future ones.  100   101 This may lead homeowners to value their immediate savings over future savings that retrofits may provide.

As noted in our Introduction, a range of grants and subsidies such as the Fully Funded Energy Upgrade Scheme and the Individual Energy Upgrade Grants Scheme have been introduced to alleviate the high upfront cost of retrofits, and ease the financial burden on homeowners. 102  The implementation of the One Stop Shop scheme may also relieve some of this financial burden as it can reduce the hassle of searching for financial schemes while also providing access to a wider range of grants than if homeowners were to manage retrofitting projects themselves. The One Stop Shop may also reduce transaction costs associated with retrofit projects through collective purchasing as projects are pooled across homes. 103

However, despite these measures, the costs for retrofitting remain high and can vary significantly depending on various factors including the age and size of the home, the current BER rating and the specific energy upgrades needed (for example, a home that requires heat pump installation to achieve a B2 BER rating can substantially increase retrofitting costs). An estimate from a one One-Stop-Shop-registered installer suggests that the cost of a full retrofit including heat pump can range from €25,000 for a home built since 2000 to €75,000+ for larger or older homes. 104

These costs are particularly high when compared to national average weekly earnings, which in Ireland are €880.37 a week as of Q1 2022 (before tax), 105  and when considering that owner occupied households in Ireland have a median savings value of €8,700 as of 2020. 106 This challenge may be further compounded by the current social and political climate, with the cost of living crisis leading to an increase of 7.8% in Irish consumer prices between May 2021 and May 2022 -the largest annual increase in consumer price index since 1984. 107 This increased burden on the consumer is significant and should be a key consideration for SEAI, and for policymakers more broadly, as the average consumer is far less likely to have the disposable income to afford or even consider retrofits within the current climate.

The issue of costs predominantly arise at the 'decision to proceed' stage, as households ask 'can I afford it?' and 'is it worth it?' However, other cost barriers present themselves earlier in the journey. For example, the

cost of carrying out a home energy survey may deter those without a BER report, undermining their ability to easily see what retrofits might be good for them (Research stage). A general perception of high costs (and lack of awareness of funding options available) may also discourage customers from looking into retrofits at all (trigger stage). Conversely, high energy costs or a desire to reduce bills or invest in a property can be a positive trigger event.

## Box 3: Energy poverty in Ireland

Installing retrofits is even more important for those who are energy poor, however these customers are unfortunately even less likely to be able to afford them. 90% of Irish low-income households rate the cost of retrofits as the main barrier. In 2022, approximately 1 in 5 people in Ireland were at risk of energy poverty -that is, struggling financially to keep their homes adequately warm or cool 108  - with people who are unemployed, retired and from minority groups at greater risk (as an example, 75% of the Irish Traveller Community are currently living in energy poverty). 109   110   111

This problem has been further compounded by the current energy crisis and the conflict in the Ukraine, contributing to a sharp increase in energy costs. The latest figures suggest that an estimated 29% of households are currently living in energy poverty - the highest ever recorded rate. 112

The Fully Fund ed Energy Upgrade Scheme is SEAI's free energy upgrade programme, addressing energy poverty through improved home energy efficiency measures. The scheme provides upgrades to those most in need. Demand for the programme and the need to close for approximately a year due to COVID 19, has led to a significant waiting list. Additionally, the Government has widened the programme eligibility in February 2022, significantly increasing the application rate.

## Split incentives

Split incentives occur in situations where the benefits of a transaction do not accrue to the actor who pays for the transaction. In the context of retrofitting, split incentives are particularly relevant to rented properties, whereby landlords are expected to finance the costs of retrofits, while tenants reap the benefits in terms of comfort and reduced energy bills. In these instances, split incentives can create a strong motivational barrier for landlords and can prevent them from acting. 113

With approximately 30% of Irish households living in rental accommodation, 114  this split incentive between landlords and tenants is a significant barrier to retrofit uptake in Ireland. 115  The barrier is further amplified by the current housing crisis in Ireland, which has led to a lack of supply of rental accommodation. In theory, a well-functioning rental market would incentivise landlords to retrofit their properties because those properties would then command higher income, however in practice, prospective tenants do not seem to sufficiently prioritise energy efficiency in their property choices for this to 'close' the split incentive. Indeed, when surveyed by SEAI, only 33% of landlords believed retrofits would make the property more attractive to prospective tenants. 116

## Lack of skilled installers

A significant barrier to arranging and installing retrofits is the availability of the necessary skills and labour required to carry out home upgrades. 117  Currently, there is a shortage of skilled workers in the Irish construction sector capable of carrying out retrofits to the required standards. 118   119  SEAI estimates that 17,000 additional workers will be needed to achieve the target of retrofitting 500,000 homes to a B2 BER rating by 2030. 120  Qualitative research has revealed a combination of reasons that have contributed to the low levels of skilled workers, including a low willingness to enter into trades; low desirability of the construction industry due to perceptions of it being outdated; and a lack of representation of women in the

sector. 121 The housing crisis has amplified this issue, leading to competing high demand for construction workers to build new housing as well as making it difficult to attract skilled workers from overseas. 122

As it continues to scale up, the introduction of the One Stop Shop scheme could partly ease issues relating to skills and labour shortages by helping individual homeowners navigate and access the fragmented retrofitting supply chain. 123 However, at present the demand for retrofits continues to exceed the supply of the necessary labour and skills. This is partly evidenced by the waiting time for the One Stop Shop, which is currently 2-3 months due to large demand and a general lack of scheme-certified suppliers. Note also that a lack of qualified installers is likely to exacerbate costs for consumers.

## Lack of social opportunity

As with much of our behaviour, decisions to retrofit or install greener energy systems are influenced by the behaviour of those around us. Research has shown that technologies like solar panels spread by 'contagion', where for example people who live in neighbourhoods where solar panels are a common sight are more likely to install their own. 124 Conversely, if it does not appear that many others in your neighbourhood are installing renewable energy devices or undertaking retrofits, you are less likely to consider doing so yourself. This can be an even bigger barrier to uptake of retrofits as, unlike solar panels, many upgrades are not visible and cannot be recognised from outside the house.

This visibility can be important, as not only does it show that others are undertaking similar works, but homeowners may also wish to be perceived as environmentally friendly by others and so value having their upgrades visible to others. 125 The notion of getting 'social kudos' for a heat pump or cavity wall insulation (or disapproval for their absence) seems odd, precisely because there is no normative value ascribed to them at present. Yet it is not so different to, say, buying an electric versus a diesel car, which carries strong status, identity and normative elements. It is therefore well worth exploring ways to increase the visibility and social normativity of retrofits.

<!-- image -->

## Behavioural insight

Social norms: People are more likely to engage in a behaviour when they believe it is in line with the behaviour of the majority, in other words the social norm. Social norms can have a particularly strong effect in shaping behaviour when they relate to social groups with which the actor in question identifies strongly. They can take the shape of descriptive norms or social 'proofs', that is, perceptions of how people actually behave (such as people seeing their neighbours installing retrofits) or injunctive norms around how people should behave (for instance, people knowing that installing retrofits is desirable ). 126  Social norms have been used to encourage a range of green behaviours including reducing energy consumption. 127

## 3.3 Motivation barriers

Motivation barriers refer to the cognitive processes that drive conscious and non-conscious decision-making, and ultimately behaviour. These barriers include, but are not limited to, emotional states, belief in one's own abilities, as well as one's goals and habits.

## High friction costs and hassle

Undertaking retrofits is an often complex and disruptive process which can be off-putting to homeowners. Typically, they have to find and assess relevant information, source individual retrofit measures delivered by separate contractors, arrange the measures, energy audits and finance (often separately), as part of a complex customer journey with high degree of hassle. 128,129  Additionally, if retrofits are not aligned and occur at different times with different contractors, there is no guarantee of work being effectively integrated.

Retrofits are complex undertakings that can require a degree of project management. For example, homeowners may have to schedule or complete an energy audit alongside installation, with one field experiment finding a dropout rate of 60% between scheduling and completion of an audit. 130  Other associated hassles can include the process of applying for certain loans and grants which can deter prospective applicants. Finally, potential customers are often put off by the disruption to everyday life caused by building works. 131

A significant benefit of the One Stop Shop is a reduction in hassle, stress, and disruption thanks to the introduction of a single point of contact to oversee and manage the retrofitting process. This reduces the burden for homeowners to procure and manage suppliers, while enabling projects to be completed faster. 132 When fully-scaled, the One Stop Shop initiative could address many of the hassle-related barriers. However, it is worth noting that the One Stop Shop remains out of reach for homeowners who cannot afford a full, deep retrofit. Additionally, disruption of day-to-day life caused by retrofitting works as well as the hassle of organising finance (say loans or equity release) will still put many off.

<!-- image -->

## Behavioural insight

Friction costs: Friction costs refer to small, seemingly minor details that make a task more challenging and that have a disproportionately large effect on whether people complete the task in question. 133 A typical retrofitting customer journey is riddled with friction costs, including identifying which retrofits to install, exploring contractor options, getting quotes, applying for finance, as well accommodating works being carried out within the home. 134 Generally speaking, the greater the hassle, the greater the positive motivation required to get through it, yet high costs, limited awareness of benefits, and other barriers described here also undermine motivation level.

It is important to also note that people face friction costs and administrative burdens across many facets of their lives, causing significant amounts of lost time. 135   136  This is an important consideration given that the frictions and administrative tasks that accompany retrofits may further compound this burden.

## Moderate perceived personal benefits to retrofitting

According to SEAI research, the single most motivating factor for homeowners to retrofit is saving money through lower energy bills. 137  This benefit is gradual, however, and takes a substantial amount of time to provide homeowners with a return on their investment. Due to present bias, the lack of an immediate financial reward, paired with the initial financial outlay of funding a retrofit, may lead homeowners to conclude that retrofitting is not an immediate priority. 138  This may be the case despite the presence of retrofitting motivators such as the desire to have a more comfortable home, as well as the availability of grants. 139 As a result, homeowners may become more likely to procrastinate or delay their decision to research or to proceed with retrofit installation even if they are aware of the benefits and have the intention to retrofit.

<!-- image -->

## Behavioural insight

Value / action gap: People's intentions, attitudes and beliefs are often weakly correlated with their actual behaviours. 140  While concern for environmental benefits is often high when surveyed, in practice personal benefits like cost saving and comfort tend to be the dominant drivers of behaviour.

## Risk aversion

From the homeowner's perspective, installing retrofits brings about financial risks as well as risks relating to the quality of the building work. When it comes to financing, customers can choose between paying for the costs upfront or over a period of time; both come with significant financial risk. Financing costs upfront can limit consumers' financial flexibility and savings buffer, leaving them more vulnerable to unexpected costs. Meanwhile, opting to finance over a prolonged period inevitably comes with interest rates. 141  Moreover, the return on investment can also discourage individuals from undertaking retrofits if there is a perceived risk that future cost-savings will not match the initial cost. 142  This is reflected in SEAI research, which found that 45% of surveyed homeowners are not convinced by the benefits of retrofitting versus the cost outlay. 143

The decision to install retrofits may also be affected by ulterior risks relating to the quality and the efficacy of the retrofit. One concern for homeowners involves the performance of retrofit measures, and whether certain alterations may cause undesired effects. For example, there might be a perceived risk that cavity wall or underfloor insulation may cause dampness without adequate ventilation. 144  It is important to emphasise, however, that these perceived risks are not necessarily true in circumstances where competent and qualified contractors undertake the works. Relatedly, further risks for homeowners relate to finding and contracting competent installers, ensuring that these installers charge a fair price, as well as subsequent risks relating to the quality of the install itself. 145

## Low consumer trust

Closely related to risk, consumer trust has been identified as a key barrier that can affect motivation to retrofit the home. 146  Consumer trust comes up at several stages of the customer journey: trusting the provision of information around the need and benefits of retrofits; trusting the grants or subsidies available to finance costs; 147 trusting the necessity and utility of the retrofits provided; trusting the contractors installing the retrofits. 148

The One Stop Shop can partly address consumer trust issues by helping homeowners navigate the complex customer journey and accessing certified contractors. Early qualitative research with numerous stakeholders involved in One Stop Shops suggests that the initiative is perceived as being a positive step in building trust and legitimacy around the retrofitting process. 149  However, the initiative is still relatively new and is not yet widely available to the public. Furthermore, specific challenges relating to trust remain and are unlikely to be targeted by existing initiatives. For example, recent findings show that among rural and older homeowners in particular, there is a strong preference for locally based contractors, whom they trust more to carry out retrofitting work. 150

## 4. Solutions

We have identified a list of 22 solutions via two strands of work. First, we collated evidence of effective interventions during our evidence review, the key findings from which are summarised below. This data is limited, however, as most studies relied on self-reported survey and qualitative data, with only a few robust policy impact evaluations able to determine the causal impact of interventions (for example through randomised-controlled trials).

Second, we have drawn on our own expertise on energy behaviours, analysis of barriers to adoption as outlined above, and established behavioural policy-making tools (such as our own EAST framework). 151  We workshopped this data with SEAI experts, to develop fresh but evidence-based ideas for addressing key behavioural challenges at various steps in the Irish retrofit customer journey. Some of these ideas are for new initiatives, while others relate to specific improvements to existing schemes. These solution ideas can serve as examples of ways to address challenges to retrofitting uptake using behavioural science, and should not be considered an exhaustive list.

We categorise all of these solution ideas into four broad types, in line with the main barriers identified in the previous section. They include solutions to (1) address financial barriers, (2) reduce hassle, (3) raise awareness, and (4) upstream solutions that focus on the functioning of institutions, businesses and markets, which in turn influence consumer behaviours.

In Table 5 below, we categorise the proposed solutions outlined within this section according to the specific challenge that they address. We also rank the ideas based on their impact (the potential effect in addressing the challenge and the potential reach) and their feasibility (the ease of implementing the solutions within SEAI and government jurisdiction).

## Table 5: Summary of recommended solutions

(Priority solution ideas are marked *. These were selected by considering the barriers that they address, as well as their impact and feasibility ratings.)

## Solutions to address financial barriers

| Solution                                                                                                                                                                                                                                                                                                                                                     | Impact                                                                               | Feasibility                                                                          |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------|
| Challenge 1: How can Ireland further address the financial barriers to retrofitting?                                                                                                                                                                                                                                                                         | Challenge 1: How can Ireland further address the financial barriers to retrofitting? | Challenge 1: How can Ireland further address the financial barriers to retrofitting? |
| *Conduct a behavioural audit of the existing loan/grant landscape. Simplify and reframe loans/grants to make them easy and attractive. For example: • Minimise paperwork/bureaucracy required to apply for a loan/grant. • Create a simple decision tree tool to decide what schemes/measures are most appropriate depending on eligibility, aims or budget. | Medium                                                                               | High                                                                                 |
| *Expand and expedite a range of green financing solutions such as green loans and mortgages that offer favourable interest rates to support retrofitting projects.                                                                                                                                                                                           | High                                                                                 | Medium                                                                               |
| Introduce collective purchase discounts . Create a register of interested homes via local authorities to facilitate bulk discount retrofits among residents.                                                                                                                                                                                                 | High                                                                                 | Low                                                                                  |

| Increase stamp duty for properties with low BER ratings , with a six-month grace period so buyers receive a refund if they upgrade the property within that timeframe.                  | Medium                                                                                     | Low                                                                                        |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|
| Support and enable households to save in advance for retrofitting.                                                                                                                      | Low                                                                                        | Medium                                                                                     |
| Challenge 2: How can Ireland realign incentives to retrofit between landlords and tenants?                                                                                              | Challenge 2: How can Ireland realign incentives to retrofit between landlords and tenants? | Challenge 2: How can Ireland realign incentives to retrofit between landlords and tenants? |
| Incentivise landlords by mandating a 'warm rent' pricing system . Property rental costs would have to be advertised as 'warm rent' (inclusive of energy costs, or an estimate thereof). | Medium                                                                                     | Medium                                                                                     |
| Introduce tax concessions on rental income to encourage landlords to undertake retrofits.                                                                                               | Medium                                                                                     | Medium                                                                                     |

## Solutions to reduce hassle

| Solution                                                                                                                                                                                                                                      | Impact   | Feasibility   |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|---------------|
| Challenge 3: How can Ireland further enhance the One Stop Shop?                                                                                                                                                                               |          |               |
| Set up a centralised online competitive bidding system where homeowners could let potential One Stop Shop agents bid and where homeowners could select the most cost effective or appealing agent.                                            | High     | Low           |
| *Conduct a behavioural audit on the One Stop Shop scheme. For example, consider: • Streamlining the process of being a qualified contractor. • Frame One Stop Shops to provide the context for higher prices which discourage some consumers. | Medium   | High          |
| Challenge 4: How can Ireland reduce hassle outside of the One Stop Shop?                                                                                                                                                                      |          |               |

## Reduce hassle across other points of the customer journey , for example by:

- · Minimising paperwork/bureaucracy around loan and grant applications and creating a decision tree tool to help homeowners identify the most relevant scheme based on their circumstances (see Challenge 1 ).
- · Introducing collective purchase discounts and support saving for retrofits by creating default overpayment into a savings money pot (see Challenge 1 ).
- · Displaying salient labels on property listings beyond BER ratings (see Challenge 5 ).
- · Setting up a BER helpdesk to provide advice on next steps and offer virtual BER assessments ( see Challenge 6 ).

Medium

High

## Solutions to raise awareness

| Solution                                                                                                                                                                                                                                                                                                                                                                | Impact                                                                        | Feasibility                                                                   |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------|-------------------------------------------------------------------------------|
| Challenge 5: How can Ireland further increase awareness and normalise uptake?                                                                                                                                                                                                                                                                                           | Challenge 5: How can Ireland further increase awareness and normalise uptake? | Challenge 5: How can Ireland further increase awareness and normalise uptake? |
| *Make retrofits more visible and normative. For example: • Put clear and standardised /recognisable signage outside the home during works organised through One Stop Shop. • Display salient labels on property listings beyond BER ratings which are often overlooked. • Lead by example by insulating public buildings, with clear BER ratings displayed at entrance. | Medium                                                                        | High                                                                          |
| Introduce a refer-a-friend bonus and further subsidise homeowners who successfully encouraged a friend to conduct a retrofit.                                                                                                                                                                                                                                           | Medium                                                                        | Medium                                                                        |
| Target high energy users. Partner with energy suppliers to target homeowners likely to receive a large bill, reminding them of the retrofit options available to them at a timely moment.                                                                                                                                                                               | Low                                                                           | High                                                                          |
| Target those who are eligible for schemes. Where schemes are targeted (such as the Fully Funded Energy Upgrade Scheme for low-income households), reach out directly rather than waiting for homes to proactively opt in.                                                                                                                                               | Low                                                                           | High                                                                          |

## Upstream solutions

| Solution                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                     | Impact   | Feasibility   |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|---------------|
| Challenge 6: How can Ireland harness the BER to its full potential?                                                                                                                                                                                                                                                                                                                                                                                                                                                                          |          |               |
| *Conduct a behavioural audit on the BER. There are a wide range of minor tweaks and nudges that could be included such as: • Include well-evidenced behavioural nudges such as social comparisons on energy use, messages that harness loss aversion when emphasising potential savings, and making future savings more salient. • Set up a helpdesk to give advice on next steps (such as access to funding schemes) based on the current BER. • Offer a virtual BER or data driven assessment that removes the need for an assessor visit. | Medium   | High          |
| Consider removing the cost to have a BER assessment. Removing this cost may encourage households to find out about their current energy efficiency, an early stage in the customer journey.                                                                                                                                                                                                                                                                                                                                                  | High     | Low           |

| Challenge 7: How can Ireland promote installer training?                                                                                                                                                                                                                                                                                                                                                                                                       |           |             |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------|-------------|
| *Link apprenticeship training to the One Stop Shop scheme to ensure guaranteed demand for new workers. *Mandate (or a certain proportion                                                                                                                                                                                                                                                                                                                       | High High | High Medium |
| *Mandate retrofit training and energy efficiency to be included by default into the standard curricula of relevant education programmes in the construction sector.                                                                                                                                                                                                                                                                                            | High      | Medium      |
| Introduce subsidies/grants to help installers pay for training and make up for the opportunity cost of lost work during training.                                                                                                                                                                                                                                                                                                                              | High      | Low         |
| Encourage women to enter the construction industry by, for example: • Running communication campaigns to attract more women into engineering in general and into construction in particular. • Raising the profile of existing female workers in the industry to help encourage others into the profession. • Making the profession more appealing to women through measures such as ensuring flexibility at worksites by providing the option of job-sharing. | Medium    | Medium      |
| Clearly communicate the need for retrofit installers in the future to provide long-term assurances to suppliers who need to invest in their workforce. For example: • Lead by example (see Challenge 5 ). • Emphasise the National Retrofit Plan as a long-term commitment in                                                                                                                                                                                  | Low       | High        |

## 4.1 Solutions to address financial barriers

As discussed in the barriers section, retrofits are costly investments. Costs are typically upfront while the benefits are delayed, requiring upfront capital or long payback periods that can be subject to high interest rates.

## Grants and subsidies

Grants mainly serve as direct investment subsidies that may partially or fully cover renovation costs including acquisition of material/equipment, advice, certification and installation. They can include rebates, subsidies or tax credits in which the financial incentive offered is not expected to be repaid. Grants can stimulate demand by subsidising retrofits for households that could not afford them otherwise, given current high upfront costs.

Unsurprisingly, given the importance of cost barriers, grants can be effective even if there is little robust causal evidence to support their impact. For instance, a Slovenian subsidy program increased uptake of retrofits by between 0.08 percentage points to 1.84 percentage points. 152  The impact of grants clearly depends on their generosity, but also the effectiveness of their implementation, with unnecessary frictions often thwarting otherwise ambitious schemes. For example, the UK's Green Homes Grant received widespread criticism for complexities leading to shortages in registered suppliers. It is details such as this that often benefit most from a behavioural approach. 153

In Ireland, evidence shows that an ex-post cash payment is cited as the preferred form of financial incentive, followed closely by an upfront discount. 154  Reduced property tax was the third most popular choice, followed by tax credits for each year of a loan term, while the ability to make repayments through an employer was the least popular choice. Preference also varies by the applicants' attributes, for example households that have previously benefited from retrofit grants are more likely to prefer ex-post cash payments while older -likely more affluent -customers value subsidy schemes less than younger customers.

## Loans

Low-interest loan programmes, usually designed to provide homeowners with poor access to capital with the possibility to invest in costly retrofit measures, have been adopted in many countries to encourage adoption of energy efficient technologies. Evidence shows that zero interest green loans have a substantial, yet short-lived, impact on home energy retrofits. For instance, a French zero-interest green loan programme significantly increased the rate of retrofitting by 3-4 percentage points in the first two years, but not thereafter. The effect is strongest (7-8 p.p.) for low-income homeowners. Furthermore, their success hinges on achieving high uptake by target households, as well as avoiding debt averse homeowners. Evidence suggests that debt aversion negatively affects the adoption of retrofit measures in Europe, hence low-interest loan programmes should target households that are younger and have relatively lower income levels, and that are less likely to be debt-averse. 155

Lastly, the jury is still out on whether loans or grants are more effective. One study conducted in the U.S. state of Maine found that a $1,500 - $3,000 grant had a higher uptake rate than a 5-15 year loan with an interest rate of 4.99%. The author suggests that this is because grants are more effective at addressing the upfront cost barrier and have a lower perceived complexity. However, it could be the notably different amount of financial support that drives this effect. 156

## Solutions to address financial barriers within the Irish context

SEAI and the Irish Government already offer a series of retrofitting grants and are developing low-cost loan options (see Table 1).

## Challenge 1: How can Ireland further address the financial barriers to retrofitting?

One way to address the financial barriers to retrofitting is by increasing the accessibility of the range of financial solutions that are already available in Ireland. 32,778 grant applications were received in 2019, dropping to 17,009 in 2020 and 12,813 in 2021 during the pandemic. In 2022, 33,069 applications indicate a recovery, although the cost of living and energy crisis will likely impact this trend. 157

Moreover, some data indicates the need to boost uptake in Ireland. For example:

- · Only 9% of those eligible have taken up the support from the Individual Energy Upgrade Grant scheme. 158
- · 10% of the BEH grant applications were abandoned but subsequently re-activated, and 15% were completely abandoned. Furthermore, grants for more complicated retrofits -apartments, older and rural homes   are more likely to be abandoned. There is also a seasonal trend in grant application -abandonment, with higher abandonment during winter. 159
- · 60% of Irish homeowners are not willing to borrow in order to fund an energy efficiency upgrade or retrofit. 160

## Our proposed solution:

- 1. Conduct a behavioural audit of the existing loan/grant landscape with an emphasis on simplification. For example:
- a. Minimise paperwork/bureaucracy required to apply for a grant or loan* . Consider this at

- all levels including for contractors who need to register as suppliers, as well as households applying. This could be achieved by pre-filling / automatic population of information based on existing records.
- b. Create a simple decision tree tool* to decide what schemes/measures are most appropriate depending on eligibility, aims or budget. This would make things easier for homeowners by reducing the number of choices across multiple retrofitting decisions.

Even with existing initiatives such as the Individual Energy Upgrade Grants and One Stop Shops, 70% of homeowners believe retrofits are just too expensive. 161  Moreover, people tend to perceive the upfront cost of retrofitting as too high and the pay-back period as too long, which is a significant barrier to retrofitting.

With this in mind, there are a number of ways that SEAI could consider further reducing financial barriers to retrofitting.

## Our proposed solutions:

- 1. Expand and expedite a range of green financing solutions such as green mortgage extensions and green loans that offer favourable interest rates to support retrofitting projects. Mortgage providers could be mandated to offer a green extension to mortgages, for example allowing customers to borrow an extra €20,000 with the same rate for the purpose of improving the property's BER. This should directly relate to affordability since reduced bills increases the ability to service a larger loan, but this is not universally considered in mortgage applications. Some lenders have started to offer green mortgages, though the market has been slow and seemingly unenthusiastic. Alternatively, specific green loans could be provisioned that offer lower interest rates to make financing retrofitting projects more attractive and financially feasible.
- 2. Introduce collective purchase discounts.* This would involve setting up a register of interested homes for each local authority and working with local authorities to offer group discounts to residents. This can (1) reduce the hassle cost of identifying a contractor, (2) provide consumers with assurances since their local authority chooses a good supplier and would take some responsibility for work quality and (3) reduce the cost of the retrofit due to the economies of scale and opportunity to carry out street-by-street bulk installations (this may be of particular relevance to social housing estates where homes are more uniform). Tendering of suppliers for the work could also be linked to apprenticeship schemes (see Challenge 7), to provide guarantees of work to firms training more apprentices.
- 3. Increase stamp duty for properties with low BER ratings , with a 6-month grace period so the buyers receive a refund if they upgrade the property within this timeframe. This not only provides a strong financial incentive but is also potentially timely since retrofit works are easier when the property is not yet fully 'lived in' and may coincide with other renovation or redecoration works. Here, the link to green mortgages could provide the additional funds needed to carry out the work.
- 4. Support and enable households to save in advance for retrofitting.* Similar payroll savings initiatives by employers and automatic 'round up' savings by banks have been used to e -ncourage rainy day savings. While this would be impossible in the present context of historically high energy bills, if the price of energy drops significantly in the next few years, it would be a perfect moment to 'bank' some of those savings by default or by encouragement (say if bills drop by 40%, encourage consumers to syphon 20% (half the savings) into a retrofit savings pot which will help them guard against high

## prices in the future by reducing their energy demands).

Each of the solutions marked * seeks to reduce hassle and friction.

## Challenge 2: How can Ireland realign incentives to retrofit between landlords and tenants?

With approximately 30% of Irish households living in rented accommodation, 162  the split incentive between landlords and tenants to retrofit is a significant barrier to uptake. 163

This barrier is further amplified by the current housing crisis in Ireland, which has led to a lack of supply of rental accommodation, making it particularly difficult to incentivise landlords to retrofit their properties.

## Our proposed solutions:

- 1. Incentivise landlords by mandating a 'warm rent' pricing system . Property rental costs could be advertised as 'warm rent' (inclusive of energy costs, or an estimate thereof). This pricing system realigns the incentive for landlords to insulate their buildings as they will be rewarded by their retrofits financially, with more efficient properties commanding higher rental values. Note, we do not recommend that landlords actually pay the energy bills, as this introduces a moral hazard:  tenants would face no incentive to be frugal with their energy use. Rather, this is about the framing of rental prices, to influence the decisions that prospective tenants make, and thus incentivise landlords to retrofit their properties to make them more attractive on the market. If warm rent pricing is not immediately feasible, a first step could be to mandate inclusion of energy cost labels in rental property advertisements as has previously been done with property sales  164 .
- 2. Introduce tax concessions on rental income to encourage landlords to undertake retrofits. For example, tax credits could be applied to rental income for houses with higher BER ratings. This could encourage landlords to increase the energy efficiency of their rental properties in order to reduce rental income tax. Another option could be to implement a buy-to-let mortgage interest tax, deductible for 5 years or until 50% of the cost of retrofitting is covered.

## 4.2 Solutions to reduce hassle

Undertaking a retrofit is an often complex and disruptive process. Homeowners face tremendous hassle throughout the customer journey (loan application, scheduling an installation and so on). In this section, we discuss solutions that aim to reduce the level of hassle faced by homeowners.

## One Stop Shop

One Stop Shop models offer full service retrofitting, which consists of several phases: (1) the initial building evaluation and thorough analysis (such as an energy audit), (2) the recommendation of retrofit measures that the household should implement, (3) a fully coordinated and managed retrofit execution that may also include help in organising financing for the retrofit, (4) quality assurance procedures and (5) any follow-up works that may be required. 165

One Stop Shops have gained popularity in recent years as they offer a single entry to customers which can guide them through all aspects of the complex retrofit value chain. They simplify the otherwise complex decision-making process within the conventional retrofit customer journey, where customers often make non-expert decisions without proper information on the optimal retrofit for their home. By bridging the gap

between the fragmented supply chain and homeowners, the One Stop Shop reduces the need for homeowners to manage various building professionals while also managing the entire grant application process. As such, One Stop Shop models are considered beneficial for supporting the retrofit decision process. 166

Despite the lack of robust evidence that the One Stop Shop directly increases the uptake of retrofits, evidence shows that the model is welcomed by many homeowners . For instance, 20-30% of Swedish homeowners expressed their interest in a One Stop Shop. Homeowners with environmental concerns and those who already have a renovation plan in place are more inclined to choose a One Stop Shop service for retrofits. 167 Furthermore, the quality of work, clearly defined costs and energy savings and the suggestion of specific measures to adopt play an important role towards deciding to use the One Stop Shop. However, financial incentives such as loans were considered of lower importance for those interested in the One Stop Shop. 168

## Bundling retrofit measures/services

Short of a full One Stop Shop, another way to help drive a greater degree of home retrofits is to present candidate measures in bundles rather than as separate, discrete pieces of work, with each requiring different decisions. While evidence is limited, any such existing initiatives fell short of encouraging higher uptake of retrofits.

For example, one of the barriers to installing loft insulation is the perceived hassle of clearing out belongings. The Behavioural Insights Team tested whether it is possible to improve uptake by promoting a more expensive loft insulation service if it is bundled with a service to clear the loft as well. 169  The results of this trial were inconclusive given the very small overall uptake of loft clearance (with either the bundled offer or the regular offer) but provide some indication that the addition of a loft clearance service appears to increase the uptake of loft insulation.

Another approach is to bundle energy upgrade options to simplify decision-making. For instance, the Behavioural Insights Team also ran an online experiment with Irish homeowners to test an assessment report that bundled upgrade options together into four different packages, where participants could select options to upgrade their hypothetical home. The assessment report used in the experiment was similar to a typical assessment report generated from a home energy audit. The results of this trial showed that combining home energy efficiency upgrades into packages may not affect whether homeowners choose to invest in home upgrades but could increase the amount they are willing to spend and the number of upgrades chosen when they do invest. This is because bundling measures do little to motivate those who are not interested in retrofitting but do make it easier for those who are motivated to go much further with their retrofits. 170

## Solutions to reduce hassle within the Irish context

As outlined in the Barriers section of the report, hassle represents one of the most significant barriers to retrofitting the home. Below, we outline how these barriers can be further addressed both by enhancing the recently-implemented One Stop Shop, as well as considering other solutions that seek to reduce hassle.

## Challenge 3: How can Ireland further enhance the One Stop Shop?

The 'hassle' barriers have been much reduced for customers opting for the One Stop Shop. This service includes home energy assessment, grant application, project management, contractor works, follow up BER, and finance options (some One Stop Shops can offer finance options through their finance partners). However:

- · There is a long waiting list for the One Stop Shop (currently 2-3 months) as the scheme is still new and being rolled out.
- · There is a lack of trained installers and a need for installers to be upskilled.
- · Installers often are not local, so are favoured less by local people.

## Our proposed solutions:

- 1. Set up a centralised online competitive bidding system for One Stop Shop agents where homeowners can select the most cost effective or appealing contractor. This can make the One Stop Shop programme more efficient by matching the suitable agent with the appropriate skills to the homeowner, thereby reducing the waiting time for the One Stop Shop. It would also create an internal market within the One Stop Shop where suppliers would need to attract work by competing on cost, quality and efficiency (provided those metrics were transparently communicated to consumers, via standardised pricing formats, consumer reviews on quality, and guaranteed lead times).
- 2. Conduct a behavioural audit on the One Stop Shop scheme . For example:
- a. Streamlining the process to become a registered One Stop Shop contractor , for example by reviewing the number of qualifications needed to become a registered contractor and reviewing the thresholds for certain eligibility criteria.
- b. Frame the One Stop Shop so that it provides context for high prices that discourage some consumers -quality work, approved suppliers, guarantees, and problem resolution if needed.

## Challenge 4: How can Ireland reduce hassle outside of the One Stop Shop?

It is important to note that a significant portion of homeowners may seek to retrofit their homes outside the One Stop Shop due to various factors, such as avoiding costs and the desire to seek out their own installers. For these homeowners, it is critical that SEAI apply learnings from the One Stop Shop to other schemes and initiatives with the aim of reducing hassle and friction for all homeowners.

With this in mind, a number of the solution ideas outlined in this section also seek to reduce hassle and friction from the perspective of the homeowner. These ideas are summarised below, where we also reference the specific challenges they address. More details on each of the ideas can be found under the corresponding challenges within this section.

## Our proposed solutions:

- 1. Reduce hassle across other points of the customer journey, for example by:
- a. Minimising paperwork/bureaucracy around loan and grant applications and creating a decision tree tool to help homeowners identify the most relevant scheme based on their circumstances (see Challenge 1 ). These measures could reduce the administrative burden on individual homeowners and the decision tree in particular could help those who are uncertain about financing options or those with lower levels of financial literacy.
- b. Introducing collective purchase discounts and support saving for retrofits by creating default overpayment into a savings money pot (see Challenge 1 ). Collective purchase discounts could be particularly effective in reducing the hassle of organising retrofits for individuals living in apartments or in social housing blocks where it may be difficult to coordinate retrofitting works with other landlords and tenants. Default overpayments, on the other hand, have the potential to reduce hassle by automatically helping individuals to save.
- c. Displaying salient labels on property listings beyond BER ratings, such as 'heat pump ready home' displayed on online and window listings (see Challenge 5 ). This would make it easier for prospective buyers and renters to quickly get the sense of the energy efficiency of a particular property.

- d. Set up a BER helpdesk to provide advice on next steps and offer virtual BER assessments (see Challenge 6) . The BER helpdesk could aid and expedite homeowners' decision to retrofit while virtual BER assessments could remove some of the hassle involved in scheduling an initial assessment of the home.

## 4.3 Solutions to raise awareness

The lack of awareness and difficulty in finding the right information can be a barrier to retrofitting. Hence, finding ways to effectively provide this information to people in engaging ways will be important in encouraging more people to undertake retrofits to their homes. In this section, we discuss solutions that aim to raise awareness.

## Energy audits

An energy audit is an inspection survey and analysis of energy flows of a property. The auditor will give advice and retrofit recommendations based on the analysis that is tailored to a particular household's energy requirements and property's characteristics. The energy audit inte nds to overcome homeowners' information barriers and stimulate investment in retrofit measures as it helps customers to identify opportunities to implement retrofits that they did not know about or increase confidence in which options are right for them.

Evidence from a large-scale RCT in the United States shows that energy audit take-up is positively associated with the age of the home, wealth, and share of vehicles in the census tract that are hybrids. 171  The same experiment has found that behaviourally informed and informational letters that encourage audit take-up have no impact, while small subsidies substantially increase it.

However, conducting energy audits is not a guarantee of take-up of energy efficiency upgrades, as evidence shows their effects are mixed . For instance, audit recommendations can be ignored, as found in a study in the Netherlands. This is because homeowners considered their homes to be adequately energy efficient, resulting in homeowners without an audit installing and investing more in measures than those with an audit. 172 Even when consumers act on them, the effects can vary greatly. For instance, German research shows that energy audits can encourage initially pessimistic homeowners who learned about the net positives of retrofitting, but can also discourage overly optimistic ones when they learn their net benefit is in fact likely to be negative. 173  This highlights the possible trade-off between providing impartial and accurate information (from which some households may conclude that retrofitting is not a good option for them) as opposed to using audits as a tool for motivating greater uptake (in which information may use positive framings and emphasise the benefits of uptake).

Factors such as the cost of retrofit and the quality of auditors also influence the follow up, according to a study with U.S. homeowners. 174  The follow-up rates are higher on the generally less expensive improvements and if the auditor conducts a comprehensive, state-of-the-art home energy audit (such as by analysing the homeowner's past energy bills, conducting a blower door test to find air leaks, or providing infrared imaging to check heat loss).

## Awareness campaigns

An effective communications campaign can help to engage and activate homeowners into considering retrofits. Evidence shows that traditional approaches such as print media and television are effective in generating interest and awareness . However, to convert interest into actual retrofits requires a more personal approach of using local networks and trusted messengers to address barriers at social group level. 175 SEAI aims to partly address this through community-based social marketing campaigns where local events will inform homeowners and promote SEAI home upgrade schemes. With regard to the framing of information, highlighting specific benefits of the retrofit (including bill savings, health and comfort), and reduced framing of the cost (such as reducing the initial cost by the amount homeowners would spend on repairs anyway), has been effective in boosting the willingness to adopt retrofits in a U.S. study. 176

## Demonstration programmes

'Eco open home' events showcasing environmentally sustainable home renovations and retrofits can also increase awareness. Alongside inspection of displayed technology in model homes, experts with information materials are often av ailable to describe the features that lower a building's ecological footprint. Participants are met with a range of approaches and ideas for home renovation relevant to local conditions and diverse stories describing the experiences of the renovators. Some notable examples are the Sustainable House Day in Australia and the Oxfordshire Eco-homes Open Days in the U.K.

Evidence shows that such eco open home events can inspire behaviour and support change. For instance, many of the attendees in Australia and the U.K events self-report subsequent adoption of sustainable products after attending. For example, 21% of attendees reported that they had installed wall insulation less than two years after attending the SuperHomes and Bristol Green doors event. These attendees tend to be individuals who are most likely already considering conducting retrofits. 177  However, this doesn't undermine their impact entirely the events may serve a useful function for these people and help them address barriers further along the adoption journey. Examples include building up more in-depth knowledge of options, gaining more confidence in committing to retrofits, or finding out about specific products or installers. The impact of these events is greater when energy efficiency-related issues are presented as local and directly relevant to the community, as local sources of information are often more trusted and valued, while external information flows, particularly from commercial interests, are often less trusted. 178

## Solutions to raise awareness within the Irish context

SEAI and the Irish Government have already worked to raise awareness in Ireland about retrofitting (see Table 1). However, further progress can be made.

## Challenge 5: How can Ireland further increase awareness and normalise uptake?

The most recent Irish survey (2022) shows very high levels of awareness: just 9% say they don't know what energy upgrades their home needs and 7% had not thought of them. This is likely in part related to the ongoing national awareness-raising campaigns. 179  However, more can always be done to boost awareness and engagement with retrofits, and to normalise their adoption.

## Our proposed solutions:

- 1. Make retrofits more visible and normative, as people are more likely to engage in a behaviour when they believe it is in line with the behaviour of the majority, that is the social norm. For example:
- a. Put clear (standardised and recognisable) signage outside the home during works organised through One Stop Shop ('I'm being insulated by the One Stop Shop' or 'My energy bills are going down. Want to know how?')
- b. Display salient labels on property listings* beyond BER ratings which are often overlooked (for example 'Heat pump ready home' or 'Low energy bills' displayed saliently on online and window listings).
- c. Lead by example by insulating public buildings, with clear BER ratings displayed at entrances . Not only can this increase the visibility of green upgrades, increasing their perception as a local norm, but it sends a signal to residents that the local community values energy efficiency. Local and national governments are widely seen as credible and authoritative messengers, and their own actions and decisions carry a lot of weight in communicating the importance of a given issue. By conducting more retrofits, it can further expand the retrofit market and potentially further reduce the cost by attracting more installers to enter the market. This could apply to libraries, hospitals, doctors' surgeries and the like, and the labelling system could

potentially be expanded to businesses, akin to the food hygiene standards displayed at the entrance to restaurants and cafes.

- d. Use behavioural framings in communication , for example that retrofit upgrades are part of a national infrastructure upgrade (implying inevitability and therefore a default of acceptance), rather than something to proactively opt into (implying a default of inaction).
- e. Host open home events that showcase environmentally sustainable home renovations and retrofits. These events can help raise awareness of retrofitting and offer homeowners the opportunity to gather information around the types and benefits of retrofits that are available.
- 2. Introduce a refer-a-friend bonus and further subsidise homeowners who successfully encouraged a friend to conduct a retrofit. This incentivises consumers to share positive experiences of retrofits and raise the awareness within their networks. A softer approach could be to introduce a refer-a-friend discount on BER audits.
- 3. Target high energy users . This could be achieved by partnering with energy suppliers. Based on customers' property and smart meter data, e stimate who will receive large bills in future and forewarn or remind them to consider retrofitting to avoid the bill shock before the winter comes.
- 4. Target those who are eligible for schemes. Where schemes are targeted (such as the Fully Funded Energy Upgrade Scheme for low-income households) reach out directly to emphasise that customers 'have been identified as eligible' rather than waiting for homes to proactively opt in.

Each of the solutions marked * seeks to reduce hassle and friction.

## 4.4 Upstream solutions

Lastly, we discuss upstream solutions that aim to ensure the fabric and function of institutions and markets are working effectively to push everyone in the right direction by default. Specifically, we consider the role of governmental leadership, broad sector-wide incentives, and behavioural market failures to ensure homeowners are incentivised to conduct retrofits.

## Energy Performance/Building Energy Rating Certificate (EPC/BER)

Energy Performance Certificates (EPCs) (UK) /BERs (Ireland) intend to provide clear accessible information about the energy performance of buildings to owners and tenants. They enable buyers to consider energy efficiency and provide incentives for homeowners to implement retrofits to increase their energy efficiency rating, in the hope of boosting the property value. In Ireland, all new dwellings typically require a BER of A2.

The evidence on the effect of EPC ratings on retrofitting is mixed. One 2012 study that assessed the impact of EPCs in Germany found that buyers of owner-occupied dwellings do not incorporate energy efficiency in their purchasing decisions. 180  In the German context, the effectiveness of EPCs is limited, as (1) the certificates are not deemed helpful for understanding the financial implications of energy efficiency, (2) EPCs are not made available to buyers by default and are only made available if the buyer requests to see it, and (3) energy efficiency is only a minor purchasing criterion for dwelling purchases. It is worth acknowledging that German homes may be more energy efficient compared with Irish homes, which may lead individuals to be less concerned with efficiency ratings overall. With this in mind, the findings from this study may not be relevant to the Irish context. Furthermore, the insights from this study may now be outdated given its age. Despite this, evidence from Denmark corroborates that EPC has a limited influence on homeowners' energy retrofit decisions. Despite most homeowners finding the EPC reliable and easy to understand, relatively few find it useful for thinking about home retrofits. 181

On the other hand, evidence from the UK shows that almost all landlords are aware of the minimum energy efficiency standards, but only 80% fully understand the mandate (that properties cannot be rented unless work is carried out to improve their energy efficiency or if they are exempt) or the implications of continuing to rent properties rated an EPC F or G. The least informed are individual landlords, those who only rent a small number of properties, and those who are not a member of a landlord body or use a letting/managing agent. Lastly, the level of compliance to standards remains undetermined. As of April 2020, there are approximately 129,557 (out of 2.97 million properties in the UK private rental sector) properties whose most recent EPC suggests are not compliant to this standard. 182

In Ireland, there is some evidence to suggest that BERs are valued by consumers. For example, the act of checking a property's BER before purchasing a home has been found to correlate with the price of the home as well as the pace of the sale. 164  Furthermore, when surveyed about the reasons to improve the energy efficiency of a rental property, 16% of landlords indicated that improvements would allow landlords to seek higher rents due to the higher BER rating of the property. 183  Further research would be useful to better understand the Irish population's awareness and understanding of BER ratings.

## Upstream solutions within the Irish context

SEAI's BER represents a key lever that could be used to promote retrofit uptakes in Ireland.

## Challenge 6: How can Ireland harness the BER to its full potential?

There is international evidence that people do not follow retrofitting advice within BERs.

## Our proposed solutions:

- 1. Conduct a behavioural audit on the BER . For example:
- a. Include behavioural nudges on the BER . For example, including social comparisons, messages that harness loss aversion and make future savings more salient. These behavioural nudges have been shown to be effective in encouraging the target behaviour in various domains (such as reducing energy consumption).
- b. Set up a helpdesk* to give advice on next steps (for example, access to funding schemes) based on the current BER. This can reduce the level of attrition in the early stage of the customer journey by providing an easier way for homeowners to follow up with the BER recommendations (such as guiding them to existing subsidy schemes)
- c. Offer a virtual BER/data driven assessment that removes the need for an assessor visit* . This can remove the hassle associated with arranging a suitable time with the auditor and the financial cost of the audit. This could also help free up BER assessors themselves.
- 2. Consider removing the cost to have a BER assessment. This cost may significantly deter households from finding out about their current energy efficiency, an early stage in the customer journey. Though the cost is small compared to the cost of retrofits, it is large for an individual who does not yet know if they want to install any retrofits at all and who is merely exploring the issue. It is worth noting that this may result in subsidising those undertaking a BER assessment for reasons other than retrofitting.

Each of the solutions marked * seeks to reduce hassle and friction.

## Installer training and certification

Accreditation for retrofit materials or professionals installing them is key for potential customers to identify effective technologies and trusted installers. A notable example is the Microgeneration Certification Scheme in the UK, where the governing body certifies installers who demonstrate that they can conduct high-quality and reliable installations of the retrofit.

Evidence shows that homeowners value such installer accreditation. For instance, evidence from the Netherlands shows that customers, when choosing contractors, took into account whether they were certified by a governmental accreditation organisation for the building, insulation or installation industry. They reported believing that governmental accreditation in the form of certificates meant that contractors adhered to performance and procedural standards. This credential offered a warranty that an installed retrofit measure and the accompanying service would meet the formal quality standards. 184

## Upstream solutions within the Irish context (continued)

While strategies to upskill Irish installers for energy efficiency retrofitting have been proposed, more could be done to make it happen on the ground.

## Challenge 7: How can Ireland promote installer training?

In Ireland, a large number of construction professionals are still untrained in highly energy efficient buildings and the rapid expansion of building standards in this area has created a huge skill gap in the construction workforce. 185  However, many installers are reluctant to receive training because of the inconsistent and shortlived nature of retrofit policy. Many believe the time and skill invested in building relationships and developing market capacity is wasted when policy support is suddenly cut short.  186

The issue of limited installer capacity is often raised as a barrier to retrofit uptake. Indeed, anecdotal and survey evidence suggests this, as homeowners who want retrofits report difficulty in finding suppliers or installers. However, in a well-functioning market, supply would tend to follow demand. We believe there are two possibilities:

- 1. Demand is actually lower than often posited due to high costs, low motivation, and the other barriers that we have identified. Successful efforts to increase that demand may therefore, in time, lead to increased installer capacity.
- 2. There is a market failure, and suppliers are failing to provide adequate installer capacity in spite of high demand, which would seemingly provide attractive opportunities for charging high prices. These conditions may be particularly likely considering the context of the current Irish housing crisis.

If (1) is true (or even partially true) there is little merit in developing policy to boost installer capacity if one is not first (or simultaneously) boosting consumer demand to use that capacity (in other words, the following ideas on installer capacity should not be implemented in isolation without also implementing other initiatives to boost demand). Conversely, if (2) is true, there is little to gain by boosting demand if one cannot rely on installer capacity following to meet that demand. In other words, with such interdependence between supply and demand, it is important to ensure complementary policies work together, increasing installer capacity and consumer demand simultaneously and in lockstep. Hence, we believe policy interventions must combine the following critical ingredients:

- 1. Demand side policies already suggested above must be perceived to be effective and long-term , so that installers can have confidence in sustained, increased demand to make it worthwhile to increase their installer capacity. This takes time and investment for companies, but also for individuals opting into training and career options.

- 2. A set of supply side policies that further reduce specific barriers to installer capacity. For example, using creative incentives, mandates, nudges, or removing frictions to increase the number of people entering this trade. These ideas are outlined below.

## Our proposed solutions:

- 1. Link apprenticeship training to the One Stop Shop scheme to ensure guaranteed demand for new workers. Since the One Stop Shop is currently over-subscribed, this can ensure installers have future work and shorten the One Stop Shop wait time.
- 2. Mandate (or incentivise) large new-build developers and builders to use a certain proportion of trained retrofitting apprentices / new installers each year . Note some potential links to other policies, for example a collective purchase agreement run by a local authority (challenge 1) might procure the services from local installers who use a certain proportion of apprentices.
- 3. Mandate retrofit training and energy efficiency to be included by default into the standard curricula of relevant education programmes in the construction sector.
- 4. Introduce subsidies/grants to help installers pay for training and make up for the opportunity cost of lost work during training.
- 5. Encourage women to enter the construction industry , as they make up just 8.49% of those working in construction in Ireland. 187 For example, through:
- a. Communications campaigns aimed at attracting more women into engineering in general and into construction in particular by framing messages around the future homes, the growth of sustainability, community and Net Zero.
- b. Raising the profile of existing female workers in the industry to help encourage others into the profession.
- c. Making it appealing, such as ensuring flexibility at worksites by providing the option of jobsharing. Note there is a large body of literature on behavioural interventions to close gender gaps in labour markets, and the use of non-gendered language in job descriptions and advertising flexibility by default are both important.
- 6. Clearly communicate the need for retrofit installers in the future to provide long-term assurances to suppliers who need to invest in their workforce . For example:
- a. Lead by example (see Challenge 5 )
- b. Emphasise the National Retrofit Plan as a long-term commitment in awareness campaigns
- c. Link retrofit targets to legally binding decarbonisation goals

## 5. Areas for further research

Using an evidence-based approach will be essential to informing Ireland's policy strategy to encourage the retrofitting of 500,000 homes by 2030. 188  Currently, gaps remain across retrofitting research which, if addressed, would provide valuable insights relating to how homeowners engage with retrofits, as well as how they interact with existing policies designed to encourage retrofit uptake. In this section, we highlight four key areas that could benefit from further research in the future.

- 1. Evaluating existing and candidate policies: Further research efforts should involve rigorous and regular evaluation of policies, such as:
- · Collecting data about key policies (including key foundational data about uptake of funds, public perceptions and awareness of One Stop Shop campaigns, knowledge and awareness of BER ratings).
- · Undertaking behavioural audits that assess whether policies and services are adequately addressing the barriers to retrofitting they intend to, and ensuring they are as effective as they can be (for example reviewing processes to ensure they are streamlined by identifying and removing points of unnecessary friction).
- · Run field-trials and randomised-controlled trials (RCTs) to assess whether candidate policies work, by how much they improve retrofit uptake and whether this represents value for money which can inform decisions about further iterations and scaling.
- 2. Deep-dive into the key pain points within the customer journey: There should be a greater research focus and a greater effort in general on the retrofitting challenges that are harder to solve. For example, more research to elucidate the main areas of hassle and points of friction for customers across the retrofitting customer journey. This could involve using quantitative data to identify key points within the customer journey with high dropout rates and then using qualitative research to explore the reasons behind them. Identifying these points of friction could then allow policymakers to design targeted solutions to boost uptake of retrofits, which would be particularly useful for customers getting retrofits outside of the One Stop Shop service.

Other areas that may warrant further research include exploring the factors contributing to the gap in skilled contractors; exploring ways of communicating finance grants and loans to individuals in a way that is both simple to understand and attractive; and exploring the ways of addressing lost revenue for landlords while they undertake retrofitting work.

- 3. Segmenting and conducting detailed analysis of the Irish population : Segmentation can be valuable in helping policymakers identify the low hanging fruit of customers who are already engaged and willing to retrofit. It can equally shed light around the segments of customers that will be particularly challenging to target, as well as segments that might have been left behind by existing schemes and policies. Despite this, there is a lack of insight into segmentation for retrofit customers and it will require further research segment Irish consumers by characteristics and variables that are pragmatic for tailoring policy efforts. Previously, SEAI efforts have involved design thinking to identify segments of consumers known as: Aspirational; Comfort and value seekers; and Cost-Driven. 189  However, further research should aim to collect data that can categorise groups by characteristics that can be practically targeted. For example, a recent study found that the likelihood of someone to install retrofits is shaped by age, education, marital status, household size, income/financial status, years of residence, likeliness to move, housing location and ownership of a property shape. 190 In Ireland, further research could entail understanding the different segment trends based on property type, region of Ireland, or income.
- 4. Conduct further research into the supply-side installer challenges: At present, there is a lack of quantitative research on the barriers to increasing the supply of trained, skilled retrofit installers in Ireland. Future research should be conducted with installers and with representatives from industry, with the aim of identifying the most significant barriers based on their prevalence.

## 6. Recommendations and conclusion

This report outlines the findings from a comprehensive evidence review on barriers to, and solutions for, encouraging retrofits among Irish homeowners. We mapped out the retrofit customer journey and the barriers that people face at every step of the way. We then conducted a deep dive into the literature to discover what works to encourage retrofits and generated a longlist of exemplar solutions. These draw on insights from behavioural science and are tailored to the particular challenges of the current Irish context, building on existing schemes and policies.

We recommend that policymakers focus on solutions to the challenges that reflect the most significant barriers to retrofitting adoption in Ireland, namely financial and hassle barriers, as well as a lack of installers. We also recommend that policymakers prioritise the specific solution ideas with a combination of high potential impact and high feasibility for implementation, as outlined below.

## Further addressing the financial barriers that prevent homeowners from retrofitting by:

- 1. Conducting a behavioural audit of the existing loan/grant landscape to determine how grants can be simplified and reframed, making them easy and attractive.
- 2. Expanding and expediting a range of green financing solutions (such as green extensions to mortgages and loans) that help homeowners finance retrofits at favourable rates.

## Further addressing the hassle and friction that affect homeowners throughout the retrofitting customer journey by:

- 3. Conducting a behavioural audit on the One Stop Shop scheme to ensure the process is as streamlined as possible and is framed in the most attractive way, taking lessons on what has worked well from One Stop Shop and applying these to other policies.
- 4. Reduce hassle across other points of the customer journey , for example by making it easier for homeowners to access financial solutions, through the development of new financial solutions and making it clear how to translate insights from the BER into action.

## Further addressing the challenges around promoting installer training to help counteract the lack of skilled installers that can carry out retrofits by:

- 5. Linking apprenticeship training to the One Stop Shop scheme to ensure guaranteed demand for new workers.
- 6. Mandating (or incentivising) large new-build developers and builders to use a certain proportion of trained retrofitting apprentices / new installers each year , to ensure a higher flow of skills into this industry.
- 7. Mandating retrofit training and energy efficiency to be included by default into the standard curricula of relevant education programmes in the construction sector.

Additionally, policymakers should also consider other solutions with a combination of high impact and feasibility as these may represent the lower hanging fruit in terms of encouraging retrofitting behaviours. These include:

## Increasing awareness and normalising uptake by:

- 8. Making retrofits more visible and normative (for example by introducing standardised, recognisable signage to indicate when properties are being retrofitted, displaying salient labels on property listings and hosting open home events, among others) to raise awareness of retrofits and their benefits.

## Maximising the potential of the BER by:

- 9. Conducting a behavioural audit on the BER to determine how behavioural insights can be applied to the reports to make them more easily interpretable and easier to act upon.

Finally, we outline a number of areas for further research that, if addressed, would provide additional insights that could better inform policy design that seeks to encourage retrofit uptake. These include the need to empirically evaluate existing and candidate policies; further exploring the retrofitting customer journey; diving deeper into customer pain points to better understand barriers to uptake; and conducting more research into customer segmentations.

## 7. Glossary

| Acronym          | Explanation                                         |
|------------------|-----------------------------------------------------|
| BER              | Building Energy Rating                              |
| BEU              | Behavioural Economics Unit (SEAI)                   |
| BIT              | Behavioural Insights Team (UK)                      |
| COM-B Model      | Capability, Opportunity and Motivation Barriers     |
| EE               | Energy Efficiency                                   |
| EEOS             | Energy Efficiency Obligation Scheme                 |
| EPC              | Energy Performance Certificate                      |
| MtCO2eq          | Metric tons of carbon dioxide equivalent            |
| OSS              | One Stop Shop                                       |
| RCT              | Randomised Controlled Trial                         |
| SEAI             | Sustainable Energy Authority of Ireland             |
| SMART Technology | Self-monitoring, Analysis, and Reporting Technology |

## 8. References

- 1 Environmental Protection Agency. (2021). https://www.epa.ie/our-services/monitoring--assessment/climatechange/ghg/
- 2 Residential sector emissions refer to the emissions associated with the powering and heating of homes.
- 3 Gov.ie (2023). Climate Action Plan 2021. https://www.gov.ie/en/publication/7bd8c-climate-action-plan2023/
- 4 Gov.ie (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/ 5 SEAI (2020). Driving Purchases of Electric Vehicles in Ireland Behavioural insights for policy series. https://www.seai.ie/publications/Driving-Purchases-of-Electric-Vehicles-in-Ireland.pdf
- 6 SEAI (2020). Encouraging heat pump installations in Ireland. Strategies to maximise heat pump installation and the savings produced. Behavioural Insights Paper Series. https://www.seai.ie/publications/Heat-PumpAdoption.-Maximising-Savings..pdf
- 7 Michie, S., Van Stralen, M. M., &amp; West, R. (2011). The behaviour change wheel: a new method for characterising and designing behaviour change interventions. Implementation science , 6 (1), 1-12.
- 8 SEAI (2020). Driving Purchases of Electric Vehicles in Ireland. Behavioural insights for policy series. https://www.seai.ie/publications/Driving-Purchases-of-Electric-Vehicles-in-Ireland.pdf
- 9 SEAI (2020). Encouraging heat pump installations in Ireland. Strategies to maximise heat pump installation and the savings produced. Behavioural Insights Paper Series. https://www.seai.ie/publications/Heat-PumpAdoption.-Maximising-Savings..pdf
- 10 World Green Building Council. (2021). New report: the building and construction sector can reach net zero carbon emissions by 2050. https://www.worldgbc.org/news-media/WorldGBC-embodied-carbon-reportpublished
- 11 World Green Building Council. (2021). New report: the building and construction sector can reach net zero carbon emissions by 2050. https://www.worldgbc.org/news-media/WorldGBC-embodied-carbon-reportpublished
- 12 Environmental Protection Agency. (2021). https://www.epa.ie/our-services/monitoring-assessment/climate-change/ghg/
- 13 Residential sector emissions refer to the emissions associated with the powering and heating of homes.
- 14 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/
- 15 Gov.ie. (2021). Climate Action Plan 2021. https://www.gov.ie/en/publication/6223e-climate-action-plan2021/
- 16 Gov.ie. (2021). Climate Action Plan 2021. https://www.gov.ie/en/publication/6223e-climate-action-plan2021/
- 17 National Retrofit Plan. (2022, February 8). Gov.ie. https://www.gov.ie/en/publication/5052a-nationalretrofit-plan/
- 18 The cost-optimal level refers to the energy performance level that leads to the lowest operational cost
- 19 Excluding the Solar PV scheme
- 20 SEAI (2022)
- 21 National Retrofit Plan. (2022, February 8). Gov.ie. https://www.gov.ie/en/publication/5052a-nationalretrofit-plan/
- 22 National Retrofit Plan. (2022, February 8). Gov.ie. https://www.gov.ie/en/publication/5052a-nationalretrofit-plan/
- 23 SEAI. (2020). Tools. https://www.seai.ie/tools/
- 24 SEAI. (2020). B2 Home Energy Rating, BER Comparison. Home Energy Upgrades. https://www.seai.ie/homeenergy/home-upgrades/b2-rated-home/
- 25 SEAI. (2020). Home Energy Upgrades and Grants. https://www.seai.ie/grants/home-energy-grants/
- 26 SEAI. (2021). SEAI National BER Register. https://ndber.seai.ie/pass/ber/search.aspx

- 27 SEAI. (2020). BER Advisory Report. Home Energy. https://www.seai.ie/home-energy/building-energy-ratingber/ber-advisory-report/
- 28 SEAI. (2020). One Stop Shop Service. https://www.seai.ie/grants/home-energy-grants/one-stop-shop/ SEAI. (2020). Registered Providers. One Stop Shops. https://www.seai.ie/grants/home-energy-grants/one-
- 29 stop-shop/registered-providers/
- 30 SEAI. (2020). Free Home Energy Upgrade. https://www.seai.ie/grants/home-energy-grants/free-upgradesfor-eligible-homes/
- 31 SEAI. (2020). Free Home Energy Upgrade. https://www.seai.ie/grants/home-energy-grants/free-upgradesfor-eligible-homes/
- 32 SEAI (n.d.). Better Energy Homes Programme Application Guide. Applying For and Claiming Cash Grants. https://www.seai.ie/publications/Homeowner-Application-Guide.pdf
- 33 SEAI. (2020). Individual Energy Upgrade Grants. https://www.seai.ie/grants/home-energy-grants/individualgrants/
- 34 SEAI. (2020). Individual Energy Upgrade Grants. https://www.seai.ie/grants/home-energy-grants/individualgrants/
- 35 SEAI. (2020. Energy Efficiency Obligation Scheme (EEOS). https://www.seai.ie/business-and-publicsector/business-grants-and-supports/energy-efficiency-obligation-scheme/
- 36 Skillsireland.ie. (2021). Expert Group on Future Skill Group. http://www.skillsireland.ie/
- 37 Gov.ie. (2021). Action Plan for Apprenticeship, 2021 to 2025. https://www.gov.ie/en/publication/0879faction-plan-for-apprenticeship-2021-2025/
- 38 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/

39

Climate Change Committee. (2020). Net Zero -

The UK's contribution to stopping global warming.

- https://www.theccc.org.uk/publication/net-zero-the-uks-contribution-to-stopping-global-warming/ 40 Central Statistics Office. (2022). Consumer Price Index.
- https://www.cso.ie/en/statistics/prices/consumerpriceindex/
- 41 SEAI. (2022). Prices.https://www.seai.ie/data-and-insights/seai-statistics/key-statistics/prices/
- 42 ESRI. (2022). Energy poverty at highest recorded rate. https://www.esri.ie/news/energy-poverty-at-highestrecorded-rate
- 43 IPOA. (2022). Housing Policy Needs to Adjust to Address Market Failures in the Rental Sector.

https://ipoa.ie/housing-policy-needs-to-adjust-to-address-market-failures-in-the-rental-sector/

44

Future of Renewable Energy in Europe (FREE). (n.d.). Ireland Rural Energy Data.

https://www.rural-energy.eu/wp-content/uploads/2020/12/FREE-CountrySheet\_A4-IRELAND\_V04-09112020approved.pdf

- 45 Irish Examiner. (2022). Vast majority of new homes meet highest energy standards. https://www.irishexaminer.com/news/arid-40787133.html
- 46 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.
- https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 47 Central Statistics Office. (2022). Domestic Building Energy Ratings Quarter 1 2022.
- https://www.cso.ie/en/releasesandpublications/er/dber/domesticbuildingenergyratingsquarter12022/ 48 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.

https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf

- 49 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/
- 50 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/
- 51 Friends of the Earth. (2022). Ireland Research Report. An Examination of Blockages to Retrofitting and Heat pump Installation in Ireland. https://www.foe.ie/assets/files/pdf/blockages\_to\_retrofitting\_and\_heat-pump\_installation\_in\_ireland.pdf
- 52 Sunikka-Blank, M., &amp; Galvin, R. (2016). Irrational homeowners? How aesthetics and heritage values influence thermal retrofit decisions in the United Kingdom. Energy Research &amp; Social Science, 11 , 97-108. 53
- Central Statistics Office. (2018). Census 2016 Profile 1 - Housing In Ireland.

https://www.cso.ie/en/statistics/surveys/census2016profile1-housinginireland/

- 54 Supporting the retrofit of London's flats. (2022, January 7). London City Hall; London City Hall. https://www.london.gov.uk/decisions/add2550-supporting-retrofit-londons-flats#
- 55 SEAI. (2020). Residential. https://www.seai.ie/data-and-insights/seai-statistics/key-statistics/residential/ 56 SEAI. (2020). Encouraging heat pump installations in Ireland. Strategies to maximise heat pump installation and the savings produced. Behavioural Insights Paper Series.. https://www.seai.ie/publications/Heat-PumpAdoption.-Maximising-Savings..pdf
- 57 Michie, S., Van Stralen, M. M., &amp; West, R. (2011). The behaviour change wheel: a new method for characterising and designing behaviour change interventions. Implementation science , 6 (1), 1-12. 58 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.
- https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 59 Gov.ie. (2020). Long-Term Renovation Strategy. https://www.gov.ie/en/publication/a4d69-long-termrenovation-strategy/
- 60 Gov.ie. (2020). Long-Term Renovation Strategy. https://www.gov.ie/en/publication/a4d69-long-termrenovation-strategy/
- 61 SEAI. (2021). SEAI National BER Register. https://ndber.seai.ie/pass/ber/search.aspx
- 62 SEAI. (2020). Building Energy Rating BER. (2020). https://www.seai.ie/home-energy/building-energy-ratingber/
- 63 SEAI. (n.d.). Cutting energy costs for small and medium sized businesses. A Guide to Building Energy Ratings for Homeowners. https://www.seai.ie/publications/BER-Homeowner-Leaftlet.pdf
- 64 SEAI. (2012). SEAI Public Assessor Search. https://ndber.seai.ie/PASS/Assessors/Search.aspx
- 65 SEAI. (2020). Home Energy Upgrades and Grants. https://www.seai.ie/grants/home-energy-grants/
- 66 SEAI. (2020). Energy Efficiency Obligation Scheme (EEOS). https://www.seai.ie/business-and-publicsector/business-grants-and-supports/energy-efficiency-obligation-scheme/
- 67 SEAI. (2020). Energy Efficiency Obligation Scheme (EEOS). https://www.seai.ie/business-and-publicsector/business-grants-and-supports/energy-efficiency-obligation-scheme/
- 68 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/ 69 SEAI. (2022). Free Home Energy Upgrade. https://www.seai.ie/grants/home-energy-grants/free-upgradesfor-eligible-homes/
- 70 SEAI. (2020). Registered Providers. One Stop Shops. https://www.seai.ie/grants/home-energy-grants/onestop-shop/registered-providers/
- 71 SEAI. (2022). SEAI BEH - Contractor Search. https://hes.seai.ie/GrantProcess/ContractorSearch.aspx
- 72 SEAI. (2012). SEAI Public Assessor Search. https://ndber.seai.ie/PASS/Assessors/Search.aspx
- 73 SEAI. (2022).
- 74 Capped at a max of €38k for private homeowners and €44k for housing bodies.
- 75 Department for Energy &amp; Climate Change. (2013). Removing the hassle factor associated with loft insulation: Results of a behavioural trial.
- https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment\_data/file/236858/ DECC\_loft\_clearance\_trial\_report\_final.pdf
- 76 The Irish Times. (2022). Home retrofits: A guide to costs, grants, time frames and best ways to approach the project. https://www.irishtimes.com/special-reports/renovate/home-retrofits-a-guide-to-costs-grants-timeframes-and-best-ways-to-approach-the-project-1.4811069
- 77 Penasco, C., &amp; Anadon, L. D. (2022). Assessing the Effectiveness of Energy Efficiency Measures in the Residential Sector. Gas Consumption Through Dynamic Treatment Effects: Evidence from England and Wales. SSRN Electronic Journal. https://doi.org/10.2139/ssrn.4003841
- 78 Homeowners can also avail of a €50 grant on the mandatory BER assessment.
- 79 Michie, S., Van Stralen, M. M., &amp; West, R. (2011). The behaviour change wheel: a new method for characterising and designing behaviour change interventions. Implementation science , 6 (1), 1-12. 80 Michie, S., Van Stralen, M. M., &amp; West, R. (2011). The behaviour change wheel: a new method for characterising and designing behaviour change interventions. Implementation science , 6 (1), 1-12.

- 81 Wilson, C., Crane, L., &amp; Chryssochoidis, G. (2015). Why do homeowners renovate energy efficiently? Contrasting perspectives and implications for policy. Energy Research &amp; Social Science , 7 , 12-22.
- 82 Gov.ie. (2022). National Retrofit Plan.https://www.gov.ie/en/publication/5052a-national-retrofit-plan/#
- 83 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.
- https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 84 SEAI (2022). SEAI Retrofit Campaign Postwave Homeowners Research Report.
- 85 SEAI (2022). SEAI Retrofit Campaign Postwave Homeowners Research Report.
- 86 The Institution of Engineering &amp; Technology and Nottingham Trent University (2020). Scaling up retrofit 2050. https://www.theiet.org/impact-society/factfiles/built-environment-factfiles/retrofit-2050/
- 87 Fawcett, T., &amp; Killip, G. (2014). Anatomy of low carbon retrofits: evidence from owner-occupied Superhomes. Building Research &amp; Information , 42 (4), 434-445.
- 88 Wilson, C., Crane, L., &amp; Chryssochoidis, G. (2015). Why do homeowners renovate energy efficiently? Contrasting perspectives and implications for policy. Energy Research &amp; Social Science, 7 , 12-22.
- 89 Haines, V., &amp; Mitchell, V. (2014). A persona-based approach to domestic energy retrofit. Building Research &amp; Information, 42 (4), 462-476.
- 90 SEAI (2022). SEAI Retrofit Campaign Postwave Homeowners Research Report.
- 91 Iyengar, S. S., &amp; Lepper, M. R. (2000). When choice is demotivating: Can one desire too much of a good thing? Journal of personality and social psychology , 79 (6), 995.
- 92 Gov.ie. (2022). National Retrofit Plan.https://www.gov.ie/en/publication/5052a-national-retrofit-plan/#
- 93 SEAI. (2020). Financing Energy Efficiency in Ireland: A Handbook on the Residential Sector. https://www.seai.ie/documents/research-projects/RDD-000503.pdf
- 94 Kempson, E. &amp; Poppe, C. (2018). Assessing the Levels of Financial Capability and Financial Wellbeing in Ireland. A report to the Competition and Consumer Protection Commission (CCPC), Ireland .
- 95 Klapper, L., Lusardi, A., &amp; Van Oudheusden, P. (2015). Financial literacy around the world. World Bank. Washington DC: World Bank .
- 96 Department for Business, Energy and Industrial Strategy. (2019). Building a market for energy efficiency. Call for Evidence Summary of Responses.

https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment\_data/file/813488/ building-market-for-energy-efficiency-summary-of-responses.pdf

- 97 Galvin, R. (2014). Why German homeowners are reluctant to retrofit. Building Research &amp; Information , 42 (4), 398-408.
- 98 SEAI &amp; Element Energy. (2016). Survey on energy efficiency loans in Ireland.
- 99 SEAI (2022). SEAI Retrofit Campaign Postwave Homeowners Research Report.
- 100 Loewenstein, G. (1996). Out of control: Visceral influences on behavior. Organizational behavior and human decision processes , 65 (3), 272-292.
- 101 O'Donoghue, T. &amp; Rabin, M. (1999). Doing it now or later. American Economic Review , 89 (1), 103-124. 102 It is important to note that in the case of the Better Energy Homes scheme, individuals may still need to pay the full upfront cost, claiming the grant back afterwards (if the grant application is handled by the homeowners themselves). If a grant application is completed through a registered contractor, the homeowner pays the contractor net of grants, and grants are directly claimed by the registered contractor. 103 McGinley, O., Moran, P., &amp; Goggins, J. (2020). Key considerations in the design of a One-Stop-Shop retrofit model.
- 104 Electric Ireland Superhomes. (2022). Costs &amp; Fees. SEAI retrofit grants.

https://electricirelandsuperhomes.ie/costs-fees/

- 105 Central Statistics Office. (2022).  Earnings and Labour Costs.

https://www.cso.ie/en/statistics/earnings/earningsandlabourcosts/

- 106 Central Statistics Office. (2020). Household Financial Consumption Survey 2020.

https://www.cso.ie/en/releasesandpublications/ep/p- hfcs/householdfinanceandconsumptionsurvey2020/assets/

- 107 Central Statistics Office. (2022). Consumer Price Index.

https://www.cso.ie/en/statistics/prices/consumerpriceindex/

- 108 European Commission. (2022). Energy poverty. https://ec.europa.eu/energy/eu-buildings-factsheetstopics-tree/energy-poverty\_en

109 Friends of the Earth. (2022). Ireland Research Report. An Examination of Blockages to Retrofitting and Heat-pump Installation in Ireland. https://www.foe.ie/assets/files/pdf/blockages\_to\_retrofitting\_and\_heat-pump\_installation\_in\_ireland.pdf

110 MABS. (2019). Accommodating Ethnicity. Addressing Energy Poverty Among Travellers Living in Mobile Homes and Trailers: An Exploratory Study. https://www.ntmabs.org/publications/development/2019/ntmabsenergy-poverty-report.pdf

- 111 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.

https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 112 ESRI. (2022). Energy poverty at highest recorded rate. https://www.esri.ie/news/energy-poverty-athighest-recorded-rate

- 113 Financing Energy Efficiency in Ireland A Handbook on the Residential Sector. (2020).

https://www.seai.ie/documents/research-projects/RDD-000503.pdf

- 114 Central Statistics Office. (2022). Tenure &amp; Rent. https://www.cso.ie/en/releasesandpublications/ep/pcp1hii/cp1hii/tr/
- 115 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.
- https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 116 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.
- https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 117 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/ 118 Friends of the Earth. (2022). Ireland Research Report. An Examination of Blockages to Retrofitting and Heat-pump Installation in Ireland. https://www.foe.ie/assets/files/pdf/blockages\_to\_retrofitting\_and\_heat-pump\_installation\_in\_ireland.pdf
- 119 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/ 120 Colman O'Sullivan. (2022). Labour and material shortage may impact retrofit scheme. RTE.ie. https://doi.org/urn:epic:1278264
- 121 Friends of the Earth. (2022). Ireland Research Report. An Examination of Blockages to Retrofitting and Heat-pump Installation in Ireland. https://www.foe.ie/assets/files/pdf/blockages\_to\_retrofitting\_and\_heat-pump\_installation\_in\_ireland.pdf

122 Friends of the Earth. (2022). Ireland Research Report. An Examination of Blockages to Retrofitting and Heat-pump Installation in Ireland. https://www.foe.ie/assets/files/pdf/blockages\_to\_retrofitting\_and\_heat-pump\_installation\_in\_ireland.pdf

- 123 McGinley, O., Moran, P., &amp; Goggins, J. (2020). Key considerations in the design of a One-Stop-Shop retrofit model.
- 124 Graziano, M., &amp; Gillingham, K. (2015). Spatial patterns of solar photovoltaic system adoption: the influence of neighbors and the built environment. Journal of Economic Geography, 15 (4), 815-839.
- 125 Balcombe, P., Rigby, D., &amp; Azapagic, A. (2013). Motivations and barriers associated with adopting microgeneration energy technologies in the UK. Renewable and Sustainable Energy Reviews, 22 , 655-666.
- 126 Cialdini, R. B., &amp; Trost, M. R. (1998). Social influence: Social norms, conformity and compliance.
- (9-10), 1082-1095.
- 127 Allcott, H. (2011). Social norms and energy conservation. Journal of public Economics , 95 128 Brown, D. (2018). Business models for residential retrofit in the UK: a critical assessment of five key archetypes. Energy Efficiency , 11 (6), 1497-1517.
- 129 Wilson, C., Crane, L., &amp; Chryssochoidis, G. (2015). Why do homeowners renovate energy efficiently? Contrasting perspectives and implications for policy. Energy Research &amp; Social Science, 7, 12-22.
- 130 Gillingham, K., &amp; Tsvetanov, T. (2018). Nudging energy efficiency audits: Evidence from a field experiment. Journal of Environmental Economics and Management , 90 , 303-316.

- 131 Wilson, C., Crane, L., &amp; Chryssochoidis, G. (2015). Why do homeowners renovate energy efficiently? Contrasting perspectives and implications for policy. Energy Research &amp; Social Science, 7 , 12-22. 132 Boza-Kiss, B., &amp; Bertoldi, P. (2018). One-stop-shops for energy renovations of buildings. Joint Res. Cent. Eur. Energy Effic. Platf.(E3P) .
- 133 Behavioural Insights Team. (2021). Would you like friction with that? https://www.bi.team/blogs/wouldyou-like-friction-with-that/
- 134 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/# 135 Behavioural Insights Team. (2022). Time Taxes. https://www.bi.team/blogs/time-taxes/
- 136 Martin, L., Delaney, L., &amp; Doyle, O. (2022). Everyday administrative burdens and inequality (No. WP22/05). UCD Centre for Economic Research Working Paper Series.
- 137 SEAI. (2022). SEAI Retrofit Campaign Postwave Homeowners Research Report.
- 138 Amoah, C., &amp; Smith, J. (2022). Barriers to the green retrofitting of existing residential buildings. Journal of Facilities Management , (ahead-of-print).
- 139 SEAI. (2022). SEAI Retrofit Campaign. Postwave Homeowners Research Report.
- 140 Sheeran, P., &amp; Webb, T. L. (2016). The intention -behavior gap. Social and personality psychology compass , 10 (9), 503-518.
- 141 Galvin, R. (2014). Why German homeowners are reluctant to retrofit. Building Research &amp; Information , 42 (4), 398-408.
- 142 United Nations. (2017). Consuming Differently, Consuming Sustainably: Behavioural Insights for Policymaking. https://sustainabledevelopment.un.org/index.php?page=view&amp;type=400&amp;nr=2404
- 143 SEAI. (2022). SEAI Retrofit Campaign Postwave Homeowners Research Report.
- 144 Heritage-Survey.org. (2022). Heritage Survey | Problems caused by Retrofitting. https://www.heritagesurvey.org/problems-caused-by-retrofitting
- 145 Bakaloglou, S., &amp; Belaïd, F. (2022). The Role of Uncertainty in Shaping Individual Preferences for Residential Energy Renovation Decisions. The Energy Journal , 43 (4).
- 146 De Wilde, M. (2019). The sustainable housing question: On the role of interpersonal, impersonal and professional trust in low-carbon retrofit decisions by homeowners. Energy Research &amp; Social Science, 51, 138-147.
- 147 De Wilde, M., &amp; Spaargaren, G. (2019). Designing trust: How strategic intermediaries choreograph homeowners' low -carbon retrofit experience. Building Research &amp; Information , 47 (4), 362-374.
- 148 Wilson, C., Crane, L., &amp; Chryssochoidis, G. (2015). Why do homeowners renovate energy efficiently? Contrasting perspectives and implications for policy. Energy Research &amp; Social Science , 7 , 12-22.

149 Friends of the Earth. (2022). Ireland Research Report. An Examination of Blockages to Retrofitting and Heat pump Installation in Ireland. https://www.foe.ie/assets/files/pdf/blockages\_to\_retrofitting\_and\_heat-pump\_installation\_in\_ireland.pdf

150 Friends of the Earth. (2022). Ireland Research Report. An Examination of Blockages to Retrofitting and Heat pump Installation in Ireland. https://www.foe.ie/assets/files/pdf/blockages\_to\_retrofitting\_and\_heat-pump\_installation\_in\_ireland.pdf

- 151 Behavioural Insights Team. (2014). EAST: Four Simple Ways to Apply Behavioural Insights.

https://www.bi.team/publications/east-four-simple-ways-to-apply-behavioural-insights/

- 152 Dolšak, J., Hrovatin, N., &amp; Zorić, J. (2020). Factors impacting energy -efficient retrofits in the residential sector: The effectiveness of the Slovenian subsidy program. Energy and Buildings, 229, 110501.
- 153 The Guardian. (2021). Audit office blames UK government for botched £1.5bn green homes scheme. The Guardian. https://www.theguardian.com/environment/2021/sep/08/audit-office-blames-uk-government-forbotched-15bn-green-homes-scheme
- 154 Collins, M., Dempsey, S., &amp; Curtis, J. (2018). Householder preferences for the design of an energy efficiency retrofit subsidy in Ireland. The Economic and Social Review , 49 (2, Summer), 145-172.
- 155 Schleich, J., Faure, C., &amp; Meissner, T. (2021). Adoption of retrofit measures among homeowners in EU countries: The effects of access to capital and debt aversion. Energy Policy , 149 , 112025.

156 Gillich, A. (2013). Grants versus financing for domestic retrofits: A case study from efficiency Maine. Sustainability , 5 (6), 2827-2839.

- 157 SEAI. (2022).
- 158 MABS, (2021). ENERGISE: Enhancing the transition to energy citizenship: Connecting households with low disposable incomes. https://www.ucc.ie/en/media/research/iss21/ENERGISEpolicybriefingpdf.pdf
- Collins, M., &amp; Curtis, J. (2017). An examination of the abandonment of applications for energy efficiency
- 159 retrofit grants in Ireland. Energy Policy , 100 , 260-270.
- 160 SEAI. (2022). SEAI Retrofit Campaign Postwave Homeowners Research Report.
- 161 SEAI &amp; Element Energy. (2016). Survey on energy efficiency loans in Ireland.
- 162 Central Statistics Office. (2022). Tenure &amp; Rent.  https://www.cso.ie/en/releasesandpublications/ep/pcp1hii/cp1hii/tr/
- 163 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.
- https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 164 Carroll, J., Denny, E., &amp; Lyons, R. C. (2020). Trinity Economics Papers.
- 165 Mahapatra. K., et al. (2013). "Business models for full service energy renovation of single family houses in Nordic countries," Applied Energy , vol. 112, pp. 1558-1565.
- 166 M. Grøn Bjørneboe, S. Svendsen and A. Heller. (2017). "Using a One-Stop Shop Concept to Guide Decisions When Single-Family Houses are Renovated ', Journal of Architectural Engineering, vol. 23, no. 2. 167 Jawad, M. (2021). Swedish Homeowners' Renovation Plans and Interest in a 'One Stop Shop'. -
- 168 Pardalis, G., Mahapatra, K., Bravo, G., &amp; Mainali, B. (2019). Swedish house owners' intenti ons towards renovations: is there a market for one-stop-shop?. Buildings, 9(7), 164.
- 169 Department for Energy &amp; Climate Change. (2013). Removing the hassle factor associated with loft insulation: Results of a behavioural trial.
- https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment\_data/file/236858/ DECC\_loft\_clearance\_trial\_report\_final.pdf
- 170 SEAI &amp; Behavioural Insights Team. (2019).
- 171 Allcott, H., &amp; Greenstone, M. (2017). Measuring the welfare effects of residential energy efficiency programs (No. w23386). National Bureau of Economic Research.
- 172 Murphy, L. (2014). The influence of energy audits on the energy efficiency investments of private owneroccupied households in the Netherlands. Energy Policy , 65 , 398-407.
- 173 Frondel, M., &amp; Vance, C. (2013). Heterogeneity in the effect of home energy audits: Theory and evidence. Environmental and Resource Economics , 55 (3), 407-418.
- 174 Palmer, K. L., Walls, M., &amp; O'Keeffe, L. (2015). Putting information into action: what explains follow-up on home energy audits? Resources for the Future Discussion Paper , 15-34.
- 175 Gillich, A., Sunikka-Blank, M., &amp; Ford, A. (2018). Designing an 'optimal' domestic retrofit programme. Building Research &amp; Information , 46 (7), 767-778.
- 176 Sussman, R., Chikumbo, M., &amp; Gifford, R. (2018). Message framing for home energy efficiency upgrades. Energy and Buildings , 174 , 428-438.
- 177 Berry, S., Sharp, A., Hamilton, J., &amp; Killip, G. (2014). Inspiring lowenergy retrofits: the influence of 'open home' events. Buildi ng Research &amp; Information, 42(4), 422-433.
- 178 Berry, S., &amp; Sharp, A. (2013). The role of open house events to improve energy efficiency: Reaching the new or preaching to the converted? Paper presented at the ECEEE Summer Study, France.
- 179 SEAI. (2022). SEAI Retrofit Campaign Postwave Homeowners Research Report.
- 180 Amecke, H. (2012). The impact of energy performance certificates: A survey of German home owners. Energy Policy , 46 , 4-14.

181 Christensen, T. H., Gram-Hanssen, K., de Best-Waldhober, M., &amp; Adjei, A. (2014). Energy retrofits of Danish homes: is the Energy Performance Certificate useful? Building Research &amp; Information , 42 (4), 489-500. 182 HM Government. (2021). Domestic private rental sector minimum energy efficiency standards: interim evaluation 2020. https://www.gov.uk/government/publications/domestic-private-rental-sector-minimumenergy-efficiency-standards-interim-evaluation-2020

183 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.

https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 184 De Wilde, M. (2019). The sustainable housing question: On the role of interpersonal, impersonal and professional trust in low-carbon retrofit decisions by homeowners. Energy Research &amp; Social Science , 51 , 138147.

185 Zuhaib, S., Manton, R., Hajdukiewicz, M., Keane, M. M., &amp; Goggins, J. (2017). Attitudes and approaches of Irish retrofit industry professionals towards achieving nearly zero-energy buildings. International Journal of Building Pathology and Adaptation , 35 (1), 16-40.

- 186 Brocklehurst, F., Morgan, E., Greer, K., Wade, J., &amp; Killip, G. (2021). Domestic retrofit supply chain initiatives and business innovations: an international review. Buildings and Cities , 2 (1).
- 187 Construction Industry Federation. (2018). Building Equality - Construction Industry Federation. https://cif.ie/building-equality/
- 188 Gov.ie. (2022). National Retrofit Plan. https://www.gov.ie/en/publication/5052a-national-retrofit-plan/ 189 SEAI. (n.d.). Behavioural insights on energy efficiency in the residential sector.

https://www.seai.ie/publications/Behavioural-insights-on-energy-efficiency-in-the-residential-sector.pdf 190 Du, H., Han, Q., &amp; de Vries, B. (2022). Modelling energy-efficient renovation adoption and diffusion process for households: a review and a way forward. Sustainable Cities and Society, 77, 103560

## Sustainable Energy Authority of Ireland

Three Park Place Hatch Street Upper Dublin 2, Ireland D02 FX65

w: www.seai.ie

e: info@seai.ie

t: 01 8082100

<!-- image -->

<!-- image -->

<!-- image -->