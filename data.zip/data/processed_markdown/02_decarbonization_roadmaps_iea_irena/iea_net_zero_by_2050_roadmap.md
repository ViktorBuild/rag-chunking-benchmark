---
document_id: iea_net_zero_2050
title: "Net Zero by 2050: A Roadmap for the Global Energy Sector"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IEA"
year: 2021
original_file: "iea_net_zero_by_2050_roadmap.pdf"
tables_detected: 188
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Net Zero by 2050

## A Roadmap for the Global Energy Sector

Net Zero by 2050 Interactive iea.li/nzeroadmap

Net Zero by 2050 Data iea.li/nzedata

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 30 member countries, 8 association countries and beyond.

## IEA member countries:

Please note that this publication is subject to specific restrictions that limit its use and distribution. The terms and conditions are available online at www.iea.org/t&amp;c/ This publication and any map included herein are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. All rights reserved. International Energy Agency Website: www.iea.org corrections

Australia

Austria

Belgium

Canada

Czech Republic

Denmark

Estonia

Finland

France

Germany

Greece

Hungary

Ireland

Italy

Japan

Korea

Luxembourg

Mexico

Netherlands

New Zealand

Norway

Poland

Portugal

Slovak Republic

Spain

Sweden

Switzerland

Turkey

United Kingdom

United States

The European Commission also participates in the work of the IEA

IEA association countries:

Brazil China India Indonesia

Morocco

Singapore

South Africa

Thailand

<!-- image -->

We are approaching a decisive moment for international efforts to tackle the climate crisis a great challenge of our times. The number of countries that have pledged to reach net-zero emissions by mid-century or soon after continues to grow, but so do global greenhouse gas emissions. This gap between rhetoric and action needs to close if we are to have a fighting chance of reaching net zero by 2050 and limiting the rise in global temperatures to 1.5 °C.

Doing so requires nothing short of a total transformation of the energy systems that underpin our economies. We are in a critical year at the start of a critical decade for these efforts. The 26th Conference of the Parties (COP26) of the United Nations Framework Convention on Climate Change in November is the focal point for strengthening global ambitions and action on climate by building on the foundations of the 2015 Paris Agreement. The International Energy  Agency  (IEA)  has  been  working  hard  to  support  the  UK  government's  COP26 Presidency to help make it the success the world needs. I was delighted to co-host the IEACOP26 Net Zero Summit with COP26 President Alok Sharma in March, where top energy and climate leaders from more than 40 countries highlighted the global momentum behind clean energy transitions.

The discussions at that event fed into this special report, notably through the Seven Key Principles for Implementing Net Zero that the IEA presented at the Summit, which have been backed by 22 of our member governments to date. This report maps out how the global energy sector can reach net zero by 2050. I believe the report Net Zero by 2050: A roadmap for the global energy system - is one of the most important and challenging undertakings in the IEA's history. The Roadmap is the culmination of the IEA's pioneering work on energy data modelling, combining for the first time the complex models of our two flagship series, the World Energy Outlook and Energy Technology Perspectives . It will guide the IEA's work and will be an integral part of both those series going forward.

Despite the current gap between rhetoric and reality on emissions, our Roadmap shows that there are still pathways to reach net zero by 2050. The one on which we focus is - in our analysis - the most technically feasible, cost-effective and socially acceptable. Even so, that pathway remains narrow and extremely challenging, requiring all stakeholders -governments, businesses, investors and citizens - to take action this year and every year after so that the goal does not slip out of reach.

This  report  sets  out  clear  milestones  -  more  than  400  in  total,  spanning  all  sectors  and technologies - for what needs to happen, and when, to transform the global economy from one dominated by fossil fuels into one powered predominantly by renewable energy like solar and wind. Our pathway requires vast amounts of investment, innovation, skilful policy design and implementation, technology deployment, infrastructure building, international co-operation and efforts across many other areas.

Since the IEA's founding in 1974, one of its core missions has been to promote secure and affordable energy supplies to foster economic growth. This has remained a key concern of our Roadmap, drawing on special analysis carried out with the International Monetary Fund and the International Institute for Applied Systems Analysis. It shows that the enormous

I

E

A

.

challenge of transforming our energy systems is also a huge opportunity for our economies, with the potential to create millions of new jobs and boost economic growth.

Another guiding principle of the Roadmap is that clean energy transitions must be fair and inclusive, leaving nobody behind. We have to ensure that developing economies receive the financing and technological know-how they need to continue building their energy systems to meet the needs of their expanding populations and economies in a sustainable way. It is a moral imperative to bring electricity to the hundreds of millions of people who currently are deprived of access to it, the majority in of them in Africa.

The transition to net zero is for and about people. It is paramount to remain aware that not every worker in the fossil fuel industry can ease into a clean energy job, so governments need to promote training and devote resources to facilitating new opportunities. Citizens must be active participants in the entire process, making them feel part of the transition and not  simply  subject  to  it.  These  themes  are  among  those  being  explored  by  the  Global Commission on People-Centred Clean Energy Transitions, which I convened at the start of 2021  to  examine  how  to  enable  citizens  to  benefit  from  the  opportunities  and  navigate the  disruptions  of  the  shift  to  a  clean  energy  economy.  Headed  by  Prime  Minister Mette Frederiksen  of  Denmark  and  composed  of  government  leaders,  ministers  and prominent thinkers, the Global Commission will make public its key recommendations ahead of COP26 in November.

The pathway laid out in our Roadmap is global in scope, but each country will need to design its own strategy, taking into account its specific circumstances. There is no one-size-fits-all approach  to  clean  energy  transitions.  Plans  need  to  reflect  countries'  differing  stages  of economic  development:  in  our  pathway,  advanced  economies  reach  net  zero  before developing economies do. As the world's leading energy authority, the IEA stands ready to provide  governments  with  support  and  advice  as  they  design  and  implement  their  own roadmaps, and to encourage the international co-operation across sectors that is so essential to reaching net zero by 2050.

This landmark report would not have been possible without the extraordinary dedication of the IEA colleagues who have worked so tirelessly and rigorously on it. I would like to thank the  entire  team  under  the  outstanding  leadership  of  my  colleagues  Laura Cozzi  and Timur Gül.

The  world  has  a  huge  challenge  ahead  of  it  to  move  net  zero  by  2050  from  a  narrow possibility  to  a  practical  reality.  Global  carbon  dioxide  emissions  are  already  rebounding sharply as economies recover from last year's pandemic-induced shock. It is past time for governments to act, and act decisively to accelerate the clean energy transformation.

As this report shows, we at the IEA are fully committed to leading those efforts.

Dr Fatih Birol Executive Director International Energy Agency

This study, a cross-agency effort, was prepared by the World Energy Outlook team and the Energy Technology Perspectives team. The study was designed and directed by Laura Cozzi , Chief  Energy Modeller and Head of Division for Energy Demand Outlook, and Timur Gül , Head of Division for Energy Technology Policy.

The  lead  authors  and  co-ordinators  were: Stéphanie Bouckaert , Araceli Fernandez Pales , Christophe McGlade , Uwe Remme and Brent Wanner . Laszlo Varro , Chief Economist, Davide D'Ambrosio and Thomas Spencer were also part of the core team.

The  other  main  authors  were: Thibaut Abergel (buildings), Yasmine Arsalane (economic outlook, electricity), Praveen Bains (biofuels), Jose Miguel Bermudez Menendez (hydrogen), Elizabeth Connelly (transport), Daniel Crow (behaviour), Amrita Dasgupta (innovation), Chiara Delmastro (buildings), Timothy Goodson (buildings,  bioenergy), Alexandre Gouy (industry), Paul Hugues (industry), Lilly Lee (transport), Peter Levi (industry), Hana Mandova (industry), Ariane Millot (buildings), Paweł Olejarnik (fossil  fuel  supply), Leonardo Paoli (innovation, transport), Faidon Papadimoulis (data management), Sebastian Papapanagiotou (electricity networks), Francesco Pavan (hydrogen), Apostolos Petropoulos (transport), Ryszard Pośpiech (data  management), Leonie Staas (behaviour,  industry), Jacopo Tattini (transport), Jacob Teter (transport), Gianluca Tonolo (energy access), Tiffany Vass (industry) and Daniel Wetzel (jobs).

Other  contributors  were:  Lucila  Arboleya  Sarazola,  Simon  Bennett,  Cyril  Cassisa,  Arthur Contejean,  Musa  Erdogan,  Enrique  Gutierrez  Tavarez,  Taku  Hasegawa,  Shai  Hassid,  Zoe Hungerford,  Tae-Yoon  Kim,  Vanessa  Koh,  Luca  Lo  Re,  Christopher  Lowans,  Raimund Malischek, Mariachiara Polisena and Per Anders Widell.

Caroline Abettan, Teresa Coon, Marina Dos Santos, Marie Fournier-S'niehotta, Reka Koczka and Diana Louis provided essential support.

Edmund Hosker carried editorial responsibility and Debra Justus was the copy-editor.

The  International  Monetary  Fund  (IMF),  in  particular  Benjamin Hunt,  Florence Jaumotte, Jared Thomas Bebee and Susanna Mursula, partnered with the IEA to provide the macroeconomic analysis. The International Institute for Applied Systems Analysis (IIASA), in particular Peter Rafaj, Gregor Kiesewetter, Wolfgang Schöpp, Chris Heyes, Zbigniew Klimont, Pallav Purohit, Laura Warnecke, Binh Nguyen, Nicklas Forsell, Stefan Frank, Petr Havlik and Mykola Gusti,  partnered  with  the  IEA  to  provide  analysis  and  related  indicators  on  air pollution and greenhouse gas emissions from land use.

Valuable  comments  and  feedback  were  provided  by  other  senior  management  and numerous other colleagues within the International Energy Agency. In particular Keisuke Sadamori,  Mechthild Wörsdörfer,  Amos Bromhead,  Dan Dorner,  Nick Johnstone, Pascal Laffont, Toril Bosoni, Peter Fraser, Paolo Frankl, Tim Gould, Tom Howes, Brian Motherway,  Aad  van  Bohemen,  César  Alejandro  Hernández,  Samantha  McCulloch, Sara Moarif, Heymi Bahar, Adam Baylin-Stern, Niels Berghout, Sara Budinis, Jean-Baptiste Dubreuil, Carlos  Fernández Alvarez, Ilkka  Hannula ,  Jeremy Moorhouse and Stefan Lorenczik.

I

E

Valuable input to the analysis was provided by: Trevor Morgan (independent consultant) and David Wilkinson (independent consultant).

Thanks go to the IEA Communications and Digital Office (CDO), particularly to Jad Mouawad, Head of CDO, and to Astrid Dumond, Jon Custer, Tanya Dyhin, Merve Erdil, Grace Gordon, Christopher Gully, Jethro Mullen, Julie Puech, Rob Stone, Gregory Viscusi, Therese Walsh and Wonjik Yang for their help in producing and promoting the report and website materials.

Finally, thanks to Ivo Letra of the IEA Information Systems Unit for his essential support in the production process, and to the IEA's Office of Legal Counsel, Office of Management and Administration, and Energy Data Centre for the assistance each provided throughout the preparation of this report.

## Peer reviewers

Many senior government officials and international experts provided input and reviewed preliminary drafts of the report. Their comments and suggestions were of great value. They include:

Aimee Aguilar Jaber

Organisation for Economic Co-operation and Development (OECD)

Keigo Akimoto

Research Institute of Innovative Technology for the Earth, Japan

Doug Arent

National Renewable Energy Laboratory (NREL), United States

Daniel Balog

Permanent Delegation of Hungary to the OECD Volkswagen

Georg Bäuml

Harmeet Bawa

Hitachi ABB Power Grids

Pete Betts

Grantham Research Institute on Climate Change and the Environment, United Kingdom

Sama Bilbao y Leon

World Nuclear Association

Diane Cameron

Nuclear Energy Agency

Rebecca Collyer

European Climate Foundation

Russell Conklin

US Department of Energy

François Dassa

EDF

Jelte de Jong

Ministry of Economic Affairs and Climate Policy, The Netherlands ArcelorMittal

Carl de Maré

Guillaume De Smedt

Air Liquide

Agustin Delgado

Iberdrola

Johanna Fiksdahl

Permanent Delegation of Norway to the OECD

Alan Finkel

Special Advisor to the Australian Government on Low Emissions Technology

Niklas Forsell

International Institute for Applied Systems Analysis (IIASA)

James Foster

UK Department for Business, Energy and Industrial Strategy Toyota

Hiroyuki Fukui

Rosanna Fusco

Eni

Li Gao

Ministry of Ecology and Environment of the People's Republic of China

François Gautier

Permanent Delegation of France to the OECD

Oliver Geden

German Institute for International and Security Affairs International Renewable Energy Agency (IRENA) Enel

Dolf Gielen

Francesca Gostinelli

Jae H. Jung

Ministry of Foreign Affairs, Republic of Korea

Michael Hackethal

Ministry for Economic Affairs and Industry, Germany

Peter Wood

Shell

Selwin Hart

United Nations

David Hawkings

Natural Resources Defense Council

Jacob Herbers

US Department of Energy

Takashi Hongo

Mitsui &amp; Co. Global Strategic Studies Institute, Japan

Christina Hood

Compass Climate, New Zealand

Michael Kelly

World LPG Association

Sir David King

Cambridge University

Ken Koyama

The Institute of Energy Economics, Japan

Fabien Kreuzer

DG Energy, European Commission

Joyce Lee

Global Wind Energy Council (GWEC)

Chen Linhao

Ministry of Science and Technology of the People's Republic of China

Todd Litman

Victoria Transport Policy Institute, Canada

Claude Lorea

Global Cement and Concrete Association

Ritu Mathur

The Energy and Resources Institute (TERI)

Vincent Minier

Schneider Electric

Steve Nadel

American Council for an Energy-Efficient Economy

Stefan Nowak

Technology Collaboration Programme on Photovoltaic Power Systems (PVPS TCP)

Brian Ó Gallachóir

MaREI, SFI Research Centre for Energy, Climate and Marine, University College Cork

Henri Paillère

International Atomic Energy Agency (IAEA)

Yongduk Pak

Korea Energy Economics Institute (KEEI)

Alessandra Pastorelli

Permanent Delegation of Italy to the OECD

Jonathan Pershing

US State Department

Glen Peters

Centre for International Climate and Environmental Research (CICERO)

Stephanie Pfeifer

Institutional Investors Group on Climate Change (IIGCC)

Cédric Philibert

Independent consultant

Lynn Price

Lawrence Berkeley National Laboratory, United States

Andrew Purvis

World Steel

Julia Reinaud

Breakthrough Energy

Yamina Saheb

OpenEXP

Ignacio Santelices

Sustainable Energy Agency, Chile

Andreas Schäfer

University College London

Vivian Scott

The University of Edinburgh

Acknowledgements

Simon Sharpe

Cabinet Office, United Kingdom

Adnan Shihab Eldin

Formerly Kuwait Foundation for the Advancement of Sciences Ministry of Economy, Trade and Industry, Japan KAPSARC

Toshiyuki Shirai

Adam Sieminski

Stephan Singer

Climate Action Network

Varun Sivaram

US State Department

Jim Skea

Imperial College London

Jeff Stehm

Task Force on Climate-Related Financial Disclosures

Jonathan Stern

Oxford Institute for Energy Studies

Wim Thomas

Independent consultant

David Turk

US Department of Energy

Fritjof Unander

Research Council of Norway

Rob van der Meer

The European Cement Association (CEMBUREAU)

Noé van Hulst

International Partnership for Hydrogen and Fuel Cells in the Economy

Tom van Ierland

DG for Climate Action, European Commission

David Victor

University of California, San Diego

Amanda Wilson

Natural Resources Canada

Harald Winkler

University of Cape Town

Markus Wolf

Electric Power Research Institute (EPRI), United States

Markus Wråke

Swedish Energy Research Centre

William Zimmern

BP

The individuals and organisations that contributed to this study are not responsible for any opinions or judgments it contains. All errors and omissions are solely the responsibility of the IEA.

This  document  and  any  map  included  herein  are  without  prejudice  to  the  status  of  or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

## Comments and questions are welcome and should be addressed to:

Laura Cozzi and Timur Gül

Directorate of Sustainability, Technology and Outlooks

International Energy Agency

9, rue de la Fédération

75739 Paris Cedex 15

France

E-mail:

IEAN ZE2050@iea.org

Web: www.iea.org

29

47

| Foreword...........................................................................................................................3   | Foreword...........................................................................................................................3   | Foreword...........................................................................................................................3   | Foreword...........................................................................................................................3   |
|----------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------|
| Executive summary .........................................................................................................            | Executive summary .........................................................................................................            | Executive summary .........................................................................................................            | 13                                                                                                                                     |
| 1                                                                                                                                      | Announced net zero pledges and the energy sector                                                                                       | Announced net zero pledges and the energy sector                                                                                       | 29                                                                                                                                     |
|                                                                                                                                        | 1.1                                                                                                                                    | Introduction...................................................................................................                        | 30                                                                                                                                     |
|                                                                                                                                        | 1.2                                                                                                                                    | Emissions reduction targets and net zero pledges........................................                                               | 31                                                                                                                                     |
|                                                                                                                                        |                                                                                                                                        | 1.2.1                                                                                                                                  | Nationally Determined Contributions ............................................... 31                                                 |
|                                                                                                                                        |                                                                                                                                        | 1.2.2 Net-zero                                                                                                                         | emissions pledges............................................................... 32                                                    |
|                                                                                                                                        | 1.3                                                                                                                                    | Outlook for emissions and energy in the STEPS............................................                                              | 36                                                                                                                                     |
|                                                                                                                                        |                                                                                                                                        | 1.3.1 CO 2 emissions                                                                                                                   | .................................................................................... 36                                                |
|                                                                                                                                        |                                                                                                                                        | 1.3.2 Total energy supply, total final                                                                                                 | consumption and electricity ......................................................................................... 37               |
|                                                                                                                                        |                                                                                                                                        | 1.3.3                                                                                                                                  | Emissions from existing assets .......................................................... 39                                           |
|                                                                                                                                        | 1.4                                                                                                                                    | Announced Pledges Case...............................................................................                                  | 40                                                                                                                                     |
|                                                                                                                                        |                                                                                                                                        | 1.4.1 CO 2 emissions                                                                                                                   | .................................................................................... 41                                                |
|                                                                                                                                        |                                                                                                                                        | 1.4.2 Total                                                                                                                            | energy supply ........................................................................... 43                                           |
|                                                                                                                                        |                                                                                                                                        | 1.4.3 Total                                                                                                                            | final consumption..................................................................... 44                                              |
|                                                                                                                                        |                                                                                                                                        | 1.4.4 Electricity                                                                                                                      | generation......................................................................... 45                                                 |
| 2                                                                                                                                      | A global pathway to net-zero CO₂ emissions in 2050                                                                                     | A global pathway to net-zero CO₂ emissions in 2050                                                                                     | 47                                                                                                                                     |
|                                                                                                                                        | 2.1                                                                                                                                    | Introduction...................................................................................................                        | 48                                                                                                                                     |
|                                                                                                                                        | 2.2                                                                                                                                    | Scenario design..............................................................................................                          | 48                                                                                                                                     |
|                                                                                                                                        |                                                                                                                                        | 2.2.1                                                                                                                                  | Population and GDP........................................................................... 50                                       |
|                                                                                                                                        |                                                                                                                                        | 2.2.2                                                                                                                                  | Energy and CO 2 prices........................................................................ 51                                      |
|                                                                                                                                        | 2.3                                                                                                                                    | CO 2 emissions................................................................................................                         | 53                                                                                                                                     |
|                                                                                                                                        | 2.4                                                                                                                                    | Total energy supply and total final consumption..........................................                                              | 56                                                                                                                                     |
|                                                                                                                                        |                                                                                                                                        | 2.4.1                                                                                                                                  | Total energy supply ........................................................................... 56                                     |
|                                                                                                                                        |                                                                                                                                        | 2.4.2                                                                                                                                  | Total final consumption..................................................................... 60                                        |
|                                                                                                                                        | 2.5                                                                                                                                    | Key pillars of decarbonisation .......................................................................                                 | 64                                                                                                                                     |
|                                                                                                                                        |                                                                                                                                        | 2.5.1 Energy                                                                                                                           | efficiency................................................................................ 65                                          |
|                                                                                                                                        |                                                                                                                                        | 2.5.2                                                                                                                                  | Behavioural change ........................................................................... 67                                      |
|                                                                                                                                        |                                                                                                                                        | 2.5.3 Electrification.....................................................................................                             | 70                                                                                                                                     |

I

E

A

.

3

|                                                 | 2.5.4                                                                                                            | Renewables .......................................................................................               | 73                                        |
|-------------------------------------------------|------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------|-------------------------------------------|
|                                                 | 2.5.5                                                                                                            | Hydrogen and hydrogen-based fuels.................................................                               | 75                                        |
|                                                 | 2.5.6                                                                                                            | Bioenergy...........................................................................................             | 77                                        |
|                                                 | 2.5.7                                                                                                            | Carbon capture, utilisation and storage ............................................                             | 79                                        |
| 2.6                                             | Investment ....................................................................................................  | Investment ....................................................................................................  | 81                                        |
| 2.7                                             | Key uncertainties...........................................................................................     | Key uncertainties...........................................................................................     | 83                                        |
|                                                 | 2.7.1                                                                                                            | Behavioural change ...........................................................................                   | 84                                        |
|                                                 | 2.7.2                                                                                                            | Bioenergy and land-use change.........................................................                           | 90                                        |
|                                                 | 2.7.3                                                                                                            | CCUS applied to emissions from fossil fuels                                                                      | ...................................... 94 |
| Sectoral pathways to net-zero emissions by 2050 | Sectoral pathways to net-zero emissions by 2050                                                                  | Sectoral pathways to net-zero emissions by 2050                                                                  | 99                                        |
| 3.1                                             | Introduction.................................................................................................    | Introduction.................................................................................................    | 100                                       |
| 3.2                                             | Fossil fuel supply .........................................................................................     | Fossil fuel supply .........................................................................................     | 100                                       |
|                                                 | 3.2.1                                                                                                            | Energy trends in the Net-Zero Emissions Scenario..........................                                       | 100                                       |
|                                                 | 3.2.2                                                                                                            | Investment in oil and gas.................................................................                       | 103                                       |
|                                                 | 3.2.3                                                                                                            | Emissions from fossil fuel production..............................................                              | 104                                       |
| 3.3                                             | Low-emissions fuel supply...........................................................................             | Low-emissions fuel supply...........................................................................             | 105                                       |
|                                                 | 3.3.1                                                                                                            | Energy trends in the Net-Zero Emissions Scenario..........................                                       | 105                                       |
|                                                 | 3.3.2                                                                                                            | Biofuels............................................................................................             | 106                                       |
|                                                 | 3.3.3                                                                                                            | Hydrogen and hydrogen-based fuels...............................................                                 | 108                                       |
|                                                 | 3.3.4                                                                                                            | Key milestones and decision points.................................................                              | 111                                       |
| 3.4                                             | Electricity sector..........................................................................................     | Electricity sector..........................................................................................     | 113                                       |
|                                                 | 3.4.1                                                                                                            | Energy and emissions trends in the Net-Zero Emissions Scenario ..                                                | 113                                       |
|                                                 | 3.4.2                                                                                                            | Key milestones and decision points.................................................                              | 117                                       |
| 3.5                                             | Industry ....................................................................................................... | Industry ....................................................................................................... | 121                                       |
|                                                 | 3.5.1                                                                                                            | Energy and emission trends in the Net-Zero Emissions Scenario....                                                | 121                                       |
|                                                 | 3.5.2                                                                                                            | Key milestones and decision points.................................................                              | 129                                       |
| 3.6                                             | Transport.....................................................................................................   | Transport.....................................................................................................   | 131                                       |
|                                                 | 3.6.1                                                                                                            | Energy and emission trends in the Net-Zero Emissions Scenario....                                                | 131                                       |
|                                                 | 3.6.2                                                                                                            | Key milestones and decision points.................................................                              | 138                                       |
| 3.7                                             | Buildings ...................................................................................................... | Buildings ...................................................................................................... | 141                                       |
|                                                 | 3.7.1                                                                                                            | Energy and emission trends in the Net-Zero Emissions Scenario....                                                | 141                                       |
|                                                 | 3.7.2                                                                                                            | Key milestones and decision points.................................................                              | 147                                       |

| 4                                                                                                                                                                                                                                                    | Wider implications of achieving net-zero emissions                                                                                                                                                                                                   | Wider implications of achieving net-zero emissions                                                                                                                                                                                                   |   151 |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| 4.1                                                                                                                                                                                                                                                  | Introduction.................................................................................................                                                                                                                                        | Introduction.................................................................................................                                                                                                                                        |   152 |
| 4.2                                                                                                                                                                                                                                                  | Economy......................................................................................................                                                                                                                                        | Economy......................................................................................................                                                                                                                                        |   153 |
|                                                                                                                                                                                                                                                      | 4.2.1                                                                                                                                                                                                                                                | Investment and financing ................................................................                                                                                                                                                            |   153 |
|                                                                                                                                                                                                                                                      | 4.2.2                                                                                                                                                                                                                                                | Economic activity.............................................................................                                                                                                                                                       |   155 |
|                                                                                                                                                                                                                                                      | 4.2.3                                                                                                                                                                                                                                                | Employment ....................................................................................                                                                                                                                                      |   157 |
| 4.3                                                                                                                                                                                                                                                  | Energy industry............................................................................................                                                                                                                                          | Energy industry............................................................................................                                                                                                                                          |   160 |
|                                                                                                                                                                                                                                                      | 4.3.1                                                                                                                                                                                                                                                | Oil and gas .......................................................................................                                                                                                                                                  |   160 |
|                                                                                                                                                                                                                                                      | 4.3.2                                                                                                                                                                                                                                                | Coal..................................................................................................                                                                                                                                               |   162 |
|                                                                                                                                                                                                                                                      | 4.3.3                                                                                                                                                                                                                                                | Electricity .........................................................................................                                                                                                                                                |   163 |
|                                                                                                                                                                                                                                                      | 4.3.4                                                                                                                                                                                                                                                | Energy-consuming industries ..........................................................                                                                                                                                                               |   165 |
| 4.4                                                                                                                                                                                                                                                  | Citizens ........................................................................................................                                                                                                                                    | Citizens ........................................................................................................                                                                                                                                    |   167 |
|                                                                                                                                                                                                                                                      | 4.4.1                                                                                                                                                                                                                                                | Energy-related Sustainable Development Goals .............................                                                                                                                                                                           |   167 |
|                                                                                                                                                                                                                                                      | 4.4.2                                                                                                                                                                                                                                                | Affordability.....................................................................................                                                                                                                                                   |   170 |
|                                                                                                                                                                                                                                                      | 4.4.3                                                                                                                                                                                                                                                | Behavioural changes........................................................................                                                                                                                                                          |   173 |
| 4.5                                                                                                                                                                                                                                                  | Governments...............................................................................................                                                                                                                                           | Governments...............................................................................................                                                                                                                                           |   175 |
|                                                                                                                                                                                                                                                      | 4.5.1                                                                                                                                                                                                                                                | Energy security ................................................................................                                                                                                                                                     |   175 |
|                                                                                                                                                                                                                                                      | 4.5.2                                                                                                                                                                                                                                                | Infrastructure...................................................................................                                                                                                                                                    |   180 |
|                                                                                                                                                                                                                                                      | 4.5.3                                                                                                                                                                                                                                                | Tax revenues from retail energy sales.............................................                                                                                                                                                                   |   183 |
|                                                                                                                                                                                                                                                      | 4.5.4                                                                                                                                                                                                                                                | Innovation........................................................................................                                                                                                                                                   |   184 |
|                                                                                                                                                                                                                                                      | 4.5.5                                                                                                                                                                                                                                                | International co-operation ..............................................................                                                                                                                                                            |   187 |
| Annexes                                                                                                                                                                                                                                              | Annexes                                                                                                                                                                                                                                              | Annexes                                                                                                                                                                                                                                              |   191 |
| Annex A. Tables for scenario projections.......................................................................                                                                                                                                      | Annex A. Tables for scenario projections.......................................................................                                                                                                                                      | Annex A. Tables for scenario projections.......................................................................                                                                                                                                      |   193 |
| Annex B. Technology costs ............................................................................................                                                                                                                               | Annex B. Technology costs ............................................................................................                                                                                                                               | Annex B. Technology costs ............................................................................................                                                                                                                               |   201 |
| Annex C. Definitions...................................................................................................... Annex D. References ..................................................................................................... | Annex C. Definitions...................................................................................................... Annex D. References ..................................................................................................... | Annex C. Definitions...................................................................................................... Annex D. References ..................................................................................................... |   203 |

I

E

A

.

## Summary for policy makers

The  energy  sector  is  the  source  of  around  three-quarters  of  greenhouse  gas  emissions today  and  holds  the  key  to  averting  the  worst  effects  of  climate  change,  perhaps  the greatest challenge humankind has faced. Reducing global carbon dioxide (CO2) emissions to net zero by 2050 is consistent with efforts to limit the long-term increase in average global temperatures to 1.5 °C. This calls for nothing less than a complete transformation of how we produce, transport and consume energy. The growing political consensus on reaching net zero is cause for considerable optimism about the progress the world can make, but the changes required to reach net-zero emissions globally by 2050 are poorly understood. A huge amount of work is needed to turn today's impressive ambitions into reality, especially given the range of different situations among countries and their differing capacities to make the necessary changes. This special IEA report sets out a pathway for achieving this goal, resulting in a clean and resilient energy system that would bring major benefits for human prosperity and well-being.

The  global  pathway  to  net-zero  emissions  by  2050  detailed  in  this  report  requires  all governments to significantly strengthen and then successfully implement their energy and climate  policies. Commitments  made  to  date  fall  far  short  of  what  is  required  by  that pathway.  The  number  of  countries  that  have  pledged  to  achieve  net-zero  emissions  has grown rapidly over the last year and now covers around 70% of global emissions of CO2. This is a huge step forward. However, most pledges are not yet underpinned by near-term policies and measures. Moreover, even if successfully fulfilled, the pledges to date would still leave around 22 billion tonnes of CO2 emissions worldwide in 2050. The continuation of that trend would be consistent with a temperature rise in 2100 of around 2.1 °C. Global emissions fell in  2020 because of the Covid-19 crisis but are already rebounding strongly as economies recover. Further delay in acting to reverse that trend will put net zero by 2050 out of reach.

In this Summary for Policy Makers, we outline the essential conditions for the global energy sector to reach net-zero CO2 emissions by 2050. The  pathway described in depth in this report achieves this objective with no offsets from outside the energy sector, and with low reliance on negative emissions technologies. It is designed to maximise technical feasibility, cost-effectiveness  and  social  acceptance  while  ensuring  continued  economic  growth  and secure energy supplies. We highlight the priority actions that are needed today to ensure the opportunity of net zero by 2050 - narrow but still achievable - is not lost. The report provides a  global  view,  but  countries  do  not  start  in  the  same  place  or  finish  at  the  same  time: advanced  economies  have  to  reach  net  zero  before  emerging  markets  and  developing economies, and assist others in getting there. We also recognise that the route mapped out here is a path, not necessarily the path, and so we examine some key uncertainties, notably concerning the roles played by bioenergy, carbon capture and behavioural changes. Getting to net zero will involve countless decisions by people across the world, but our primary aim is to inform the decisions made by policy makers, who have the greatest scope to move the world closer to its climate goals.

## Net zero by 2050 hinges on an unprecedented clean technology push to 2030

The path to net-zero emissions is narrow: staying on it requires immediate and massive deployment  of  all  available  clean  and  efficient  energy  technologies. In  the  net-zero emissions pathway presented in this report, the world economy in 2030 is some 40% larger than today but uses 7% less energy. A major worldwide push to increase energy efficiency is an  essential  part  of  these  efforts,  resulting  in  the  annual  rate  of  energy  intensity improvements averaging 4% to 2030 - about three-times the average rate achieved over the last two decades. Emissions reductions from the energy sector are not limited to CO2: in our pathway, methane emissions from fossil fuel supply fall by 75% over the next ten years as a result  of  a  global,  concerted  effort  to  deploy  all  available  abatement  measures  and technologies.

## Ever-cheaper renewable energy technologies give electricity the edge in the race to zero.

Our pathway calls for scaling up solar and wind rapidly this decade, reaching annual additions of 630 gigawatts (GW) of solar photovoltaics (PV) and 390 GW of wind by 2030, four-times the record levels set in 2020. For solar PV, this is equivalent to installing the world's current largest solar park roughly every day. Hydropower and nuclear, the two largest sources of low-carbon  electricity  today,  provide  an  essential  foundation  for  transitions.  As  the electricity sector becomes cleaner, electrification emerges as a crucial economy-wide tool for reducing emissions. Electric vehicles (EVs) go from around 5% of global car sales to more than 60% by 2030.

## P R I O R I T Y A C T I O N

Make the 2020s the decade of massive clean energy expansion

All the technologies needed to achieve the necessary deep cuts in global emissions by 2030 already exist, and the policies that can drive their deployment are already proven.

As  the  world  continues  to  grapple  with  the  impacts  of  the  Covid-19  pandemic,  it  is essential  that  the  resulting  wave  of  investment  and  spending  to  support  economic recovery is aligned with the net zero pathway. Policies should be strengthened to speed the deployment of clean and efficient energy technologies. Mandates and standards are vital  to  drive  consumer  spending  and  industry  investment  into  the  most  efficient technologies. Targets and competitive auctions can enable wind and solar to accelerate the electricity sector transition. Fossil fuel subsidy phase-outs, carbon pricing and other market reforms can ensure appropriate  price  signals.  Policies  should  limit  or  provide disincentives for the use of certain fuels and technologies, such as unabated coal-fired power  stations,  gas  boilers  and  conventional  internal  combustion  engine  vehicles. Governments  must  lead  the  planning  and  incentivising  of  the  massive  infrastructure investment, including in smart transmission and distribution grids.

<!-- image -->

## Net zero by 2050 requires huge leaps in clean energy innovation

Reaching net zero by 2050 requires further rapid deployment of available technologies as well as widespread use of technologies that are not on the market yet. Major innovation efforts must occur over this decade in order to bring these new technologies to market in time. Most of the global reductions in CO2 emissions through 2030 in our pathway come from technologies  readily  available  today.  But  in  2050,  almost  half  the  reductions  come  from technologies that are currently at the demonstration or prototype phase. In heavy industry and long-distance transport, the share of emissions reductions from technologies that are still under development today is even higher.

The biggest innovation opportunities concern advanced batteries, hydrogen electrolysers, and  direct  air  capture  and  storage. Together,  these  three  technology  areas  make  vital contributions  the  reductions  in  CO2  emissions  between  2030  and  2050  in  our  pathway. Innovation over the next ten years - not only through research and development (R&amp;D) and demonstration but also through deployment - needs to be accompanied by the large-scale construction of the infrastructure the technologies will need. This includes new pipelines to transport captured CO2 emissions and systems to move hydrogen around and between ports and industrial zones.

## P R I O R I T Y A C T I O N

## Prepare for the next phase of the transition by boosting innovation

Clean  energy  innovation  must  accelerate  rapidly,  with  governments  putting  R&amp;D, demonstration and deployment at the core of energy and climate policy.

Government R&amp;D spending needs to be increased and reprioritised. Critical areas such as electrification, hydrogen, bioenergy and carbon capture, utilisation and storage (CCUS) today  receive  only  around  one-third  of  the  level  of  public  R&amp;D  funding  of  the  more established low-carbon  electricity generation  and  energy  efficiency technologies. Support is also needed to accelerate the roll-out of demonstration projects, to leverage private investment in R&amp;D, and to boost overall deployment levels to help reduce costs. Around USD 90 billion of public money needs to be mobilised globally as soon as possible to complete a portfolio of demonstration projects before 2030. Currently, only roughly USD 25 billion is budgeted for that period. Developing and deploying these technologies would create major new industries, as well as commercial and employment opportunities.

Annual CO2 emissions savings in the net zero pathway, relative to 2020

<!-- image -->

## The transition to net zero is for and about people

A transition of the scale and speed described by the net zero pathway cannot be achieved without sustained support and participation from citizens. The changes will affect multiple aspects of people's lives - from transport, heating and cooking to urban planning and jobs. We estimate that around 55% of the cumulative emissions reductions in the pathway are linked  to  consumer  choices  such  as  purchasing  an  EV,  retrofitting  a  house  with  energyefficient  technologies  or  installing  a  heat  pump.  Behavioural  changes,  particularly  in advanced economies - such as replacing car trips with walking, cycling or public transport, or  foregoing  a  long-haul  flight  -  also  provide  around  4%  of  the  cumulative  emissions reductions.

Providing electricity to around 785 million people that have no access and clean cooking solutions to 2.6 billion people that lack those options is an integral part of our pathway. Emissions reductions have to go hand-in-hand with efforts to ensure energy access for all by 2030. This costs around USD 40 billion a year, equal to around 1% of average annual energy sector investment, while also bringing major co-benefits from reduced indoor air pollution.

Some of the changes brought by the clean energy transformation may be challenging to implement, so decisions must be transparent, just and cost-effective. Governments need to ensure that clean energy transitions are people-centred and inclusive. Household energy expenditure as a share of disposable income - including purchases of efficient appliances and fuel bills - rises modestly in emerging market and developing economies in our net zero pathway as more people gain access to energy and demand for modern energy services increases  rapidly.  Ensuring  the  affordability  of  energy  for  households  demands  close attention: policy tools that can direct support to the poorest include tax credits, loans and targeted subsidies.

## P R I O R I T Y A C T I O N

Clean energy jobs will grow strongly but must be spread widely

Energy  transitions  have  to  take  account  of  the  social  and  economic  impacts  on individuals and communities, and treat people as active participants.

The transition to net zero brings substantial new opportunities for employment, with 14 million jobs created by 2030 in our pathway thanks to new activities and investment in clean energy. Spending on more efficient appliances, electric and fuel cell vehicles, and building  retrofits  and  energy-efficient  construction  would require a further 16  million workers. But these opportunities are often in different locations, skill sets and sectors than the jobs that will be lost as fossil fuels decline. In our pathway, around 5 million jobs are lost. Most of those jobs are located close to fossil fuel resources, and many are well paid, meaning structural changes can cause shocks for communities with impacts that persist  over  time.  This  requires  careful  policy  attention  to  address  the  employment

losses. It will be vital to minimise hardships associated with these disruptions, such as by retraining workers, locating new clean energy facilities in heavily affected areas wherever possible, and providing regional aid.

Global employment in energy supply in the net zero pathway, 2019-2030

<!-- image -->

## An energy sector dominated by renewables

In the net zero pathway, global energy demand in 2050 is around 8% smaller than today, but it serves an economy more than twice as big and a population with 2 billion more people. More efficient use of energy, resource efficiency and behavioural changes combine to offset increases in demand for energy services as the world economy grows and access to energy is extended to all.

Instead of fossil fuels, the energy sector is based largely on renewable energy. Two-thirds of total energy supply in 2050 is from wind, solar, bioenergy, geothermal and hydro energy. Solar  becomes  the  largest  source,  accounting  for  one-fifth  of  energy  supplies.  Solar  PV capacity increases 20-fold between now and 2050, and wind power 11-fold.

Net zero means a huge decline in the use of fossil fuels. They fall from almost four-fifths of total energy supply today to slightly over one-fifth by 2050. Fossil fuels that remain in 2050 are used in goods where the carbon is embodied in the product such as plastics, in facilities fitted with CCUS, and in sectors where low-emissions technology options are scarce.

Electricity accounts for almost 50% of total energy consumption in 2050. It plays a key role across all sectors - from transport and buildings to industry - and is essential to produce lowemissions fuels such as hydrogen. To achieve this, total electricity generation increases over

two-and-a-half-times between today and 2050. At the same time, no additional new final investment decisions should be taken for new unabated coal plants, the least efficient coal plants  are  phased  out  by  2030,  and  the  remaining  coal  plants  still  in  use  by  2040  are retrofitted. By 2050, almost 90% of electricity generation comes from renewable sources, with wind and solar PV together accounting for nearly 70%. Most of the remainder comes from nuclear.

Emissions from industry, transport and buildings take longer to reduce. Cutting industry emissions by 95% by 2050 involves major efforts to build new infrastructure. After rapid innovation progress through R&amp;D, demonstration and initial deployment between now and 2030 to bring new clean technologies to market, the world then has to put them into action. Every month from 2030 onwards, ten heavy industrial plants are equipped with CCUS, three new hydrogen-based industrial plants are built, and 2 GW of electrolyser capacity are added at industrial sites. Policies that end sales of new internal combustion engine cars by 2035 and boost electrification underpin the massive reduction in transport emissions. In 2050, cars on the road worldwide run on electricity or fuel cells. Low-emissions fuels are essential where energy needs cannot easily or economically be met by electricity. For example, aviation relies largely on biofuels and synthetic fuels, and ammonia is vital for shipping. In buildings, bans on new fossil fuel boilers need to start being introduced globally in 2025, driving up sales of electric heat pumps. Most old buildings and all new ones comply with zero-carbon-ready building energy codes. 1

## P R I O R I T Y A C T I O N

## Set near-term milestones to get on track for long-term targets

Governments need to provide credible step-by-step plans to reach their net zero goals, building confidence among investors, industry, citizens and other countries.

Governments must put in place long-term policy frameworks to allow all branches of government and stakeholders  to  plan  for  change  and  facilitate  an  orderly  transition. Long-term national low-emissions strategies, called for by the Paris Agreement, can set out a vision for national transitions, as this report has done on a global level. These longterm objectives need to be linked to measurable short-term targets and policies. Our pathway details more than 400 sectoral and technology milestones to guide the global journey to net zero by 2050.

1 A zero-carbon-ready building is highly energy efficient and either uses renewable energy directly or uses an energy supply that will be fully decarbonised by 2050, such as electricity or district heat.

<!-- image -->

## There is no need for investment in new fossil fuel supply in our net zero pathway

Beyond  projects  already  committed  as  of  2021,  there  are  no  new  oil  and  gas  fields approved for development in our pathway, and no new coal mines or mine extensions are required. The unwavering policy focus on climate change in the net zero pathway results in a  sharp  decline  in  fossil  fuel  demand,  meaning  that  the  focus  for  oil  and  gas  producers switches  entirely  to  output  -  and  emissions  reductions  -  from  the  operation  of  existing assets. Unabated coal demand declines by 9 8 % to just less than 1% of total energy use in 2050. Gas demand declines by 55% to 1 750 billion cubic metres and oil declines by 75% to 24 million barrels per day (mb/d), from around 90 mb/d in 2020.

Clean electricity generation, network infrastructure and end-use sectors are key areas for increased investment. Enabling infrastructure and technologies are vital for transforming the energy system. Annual investment in transmission and distribution grids expands from USD 260 billion today to USD 820 billion in 2030. The number of public charging points for EVs rises from around 1 million today to 40 million in 2030, requiring annual investment of almost USD 90 billion in 2030. Annual battery production for EVs leaps from 160 gigawatthours (GWh) today to 6 600 GWh in 2030 - the equivalent of adding almost 20 gigafactories 2 each year for the next ten years. And the required roll-out of hydrogen and CCUS after 2030 means  laying  the  groundwork  now:  annual  investment  in  CO2  pipelines  and  hydrogenenabling infrastructure increases from USD 1 billion today to around USD 40 billion in 2030.

## P R I O R I T Y A C T I O N

## Drive a historic surge in clean energy investment

Policies need to be designed to send market signals that unlock new business models and mobilise private spending, especially in emerging economies.

Accelerated delivery of international public finance will be critical to energy transitions, especially in developing economies, but ultimately the private sector will need to finance most of the extra investment required. Mobilising the capital for large-scale infrastructure  calls for closer co-operation  between  developers,  investors,  public financial institutions and governments. Reducing risks for investors will be essential to ensure successful and affordable clean energy transitions. Many emerging market and developing economies, which rely mainly on public funding for new energy projects and industrial facilities, will need to reform their policy and regulatory frameworks to attract more private finance. International flows of long-term capital to these economies will be needed  to  support  the  development  of  both  existing  and  emerging  clean  energy technologies.

2 Battery gigafactory capacity assumption = 35 gigawatt-hours per year.

<!-- image -->

## An unparalleled clean energy investment boom lifts global economic growth

Total  annual  energy  investment  surges  to  USD  5  trillion  by  2030,  adding  an  extra 0.4 percentage point a year to annual global GDP growth, based on our joint analysis with the  International  Monetary  Fund. This  unparalleled  increase  -  with  investment  in  clean energy  and  energy  infrastructure  more  than  tripling  already  by  2030  -  brings  significant economic benefits as the world emerges from the Covid-19 crisis. The jump in private and government spending creates millions of jobs in clean energy, including energy efficiency, as well as in the engineering, manufacturing and construction industries. All of this puts global GDP 4% higher in 2030 than it would be based on current trends.

Governments have a key role in enabling investment-led growth and ensuring that the benefits are shared by all. There are large differences in macroeconomic impacts between regions.  But  government  investment  and  public  policies  are  essential  to  attract  large amounts of private capital and to help offset the declines in fossil fuel income that many countries will experience. The major innovation efforts needed to bring new clean energy technologies  to  market  could  boost  productivity  and  create  entirely  new  industries, providing opportunities to locate them in areas that see job losses in incumbent industries. Improvements in air quality provide major health benefits, with 2 million fewer premature deaths globally from air pollution in 2030 than today in our net zero pathway. Achieving universal energy access by 2030 would provide a major boost to well-being and productivity in developing economies.

## New energy security concerns emerge, and old ones remain

The contraction of oil and natural gas production will have far-reaching implications for all the countries and companies that produce these fuels. No new oil and natural gas fields are needed in our pathway, and oil and natural gas supplies become increasingly concentrated in a small number of low-cost producers. For oil, the OPEC share of a much-reduced global oil supply increases from around 37% in recent years to 52% in 2050, a level higher than at any point in the history of oil markets. Yet annual per capita income from oil and natural gas in producer economies falls by about 75%, from USD 1 800 in recent years to USD 450 by the 2030s, which could have knock-on societal effects. Structural reforms and new sources of revenue are needed, even though these are unlikely to compensate fully for the drop in oil and gas income. While traditional supply activities decline, the expertise of the oil and natural gas industry fits well with technologies such as hydrogen, CCUS and offshore wind that are needed to tackle emissions in sectors where reductions are likely to be most challenging.

The energy transition requires substantial quantities of critical minerals, and their supply emerges as a significant growth area. The total market size of critical minerals like copper, cobalt, manganese and various rare earth metals grows almost sevenfold between 2020 and 2030 in the net zero pathway. Revenues from those minerals are larger than revenues from coal well before 2030. This creates substantial new opportunities for mining companies. It also creates new energy security concerns, including price volatility and additional costs for transitions, if supply cannot keep up with burgeoning demand.

The  rapid  electrification  of  all  sectors  makes  electricity  even  more  central  to  energy security around the world than it is today. Electricity system flexibility - needed to balance wind and solar with evolving demand patterns - quadruples by 2050 even as retirements of fossil fuel capacity reduce conventional sources of flexibility. The transition calls for major increases in all  sources  of  flexibility:  batteries,  demand  response  and  low-carbon  flexible power plants, supported by smarter and more digital electricity networks. The resilience of electricity systems to cyberattacks and other emerging threats needs to be enhanced.

## P R I O R I T Y A C T I O N

## Address emerging energy security risks now

Ensuring  uninterrupted  and  reliable  supplies  of  energy  and  critical  energy-related commodities at affordable prices will only rise in importance on the way to net zero.

The focus of energy security will evolve as reliance on renewable electricity grows and the  role of oil and  gas  diminishes.  Potential  vulnerabilities  from  the  increasing importance  of  electricity  include  the  variability  of  supply  and  cybersecurity  risks. Governments need to create markets for investment in batteries, digital solutions and electricity  grids  that  reward  flexibility  and  enable  adequate  and  reliable  supplies  of electricity. The growing dependence on critical minerals required for key clean energy technologies  calls for new  international  mechanisms  to  ensure  both  the  timely

availability of supplies and sustainable production. At the same time, traditional energy security concerns will not disappear, as oil production will become more concentrated.

Global energy security indicators in the net zero pathway

<!-- image -->

Note: mb/d = million barrels per day; Mt = million tonnes.

## International co-operation is pivotal for achieving net-zero emissions by 2050

Making  net-zero  emissions  a  reality  hinges  on  a  singular,  unwavering  focus  from  all governments - working together with one another, and with businesses, investors and citizens. All  stakeholders need to play their part. The wide-ranging measures adopted by governments at all levels in the net zero pathway help to frame, influence and incentivise the  purchase  by  consumers  and  investment  by  businesses.  This  includes  how  energy companies invest in new ways of producing and supplying energy services, how businesses invest in equipment, and how consumers cool and heat their homes, power their devices and travel.

Underpinning all these changes are policy decisions made by governments. Devising costeffective national and regional net zero roadmaps demands co-operation among all parts of government that breaks down silos and integrates energy into every country's policy making on finance, labour, taxation, transport and industry. Energy or environment ministries alone cannot carry out the policy actions needed to reach net zero by 2050.

Changes in energy consumption result in a significant decline in fossil fuel tax revenues. In many countries today, taxes on diesel, gasoline and other fossil fuel consumption are an important source of public revenues, providing as much as 10% in some cases. In the net zero pathway, tax revenue from oil and gas retail sales falls by about 40% between 2020 and 2030. Managing this decline will require long-term fiscal planning and budget reforms.

The  net  zero  pathway  relies  on  unprecedented  international  co-operation  among governments, especially on innovation and investment. The IEA stands ready to support governments in preparing national and regional net zero roadmaps, to provide guidance and assistance in implementing them, and to promote international co-operation to accelerate the energy transition worldwide.

## P R I O R I T Y A C T I O N

## Take international co-operation to new heights

This is not simply a matter of all governments seeking to bring their national emissions to net zero - it means tackling global challenges through co-ordinated actions.

Governments  must  work  together  in  an  effective  and  mutually  beneficial  manner  to implement  coherent  measures  that  cross  borders.  This  includes  carefully  managing domestic job creation and local commercial advantages with the collective global need for clean energy technology deployment. Accelerating innovation, developing international  standards  and  co-ordinating  to  scale  up  clean  technologies  needs  to  be done in a way that links national markets. Co-operation must recognise differences in the stages of development of different countries and the varying situations of different parts of society. For many rich countries, achieving net-zero emissions will be more difficult and  costly  without  international  co-operation.  For  many  developing  countries,  the pathway to net zero without international assistance is not clear. Technical and financial support is needed to ensure deployment of key technologies and infrastructure. Without greater international co-operation, global CO2 emissions will not fall to net zero by 2050.

## Global energy-related CO2 emissions in the net zero pathway and Low International Co-operation Case

<!-- image -->

<!-- image -->

<!-- image -->

2030

2035

<!-- image -->

<!-- image -->

2040

2050

2

<!-- image -->

<!-- image -->

## Announced net zero pledges and the energy sector

## S U M M A R Y

-  There has been a rapid increase over the last year in the number of governments pledging to reduce greenhouse gas emissions to net zero. Net zero pledges to date cover around 70% of global GDP and CO2 emissions. However, fewer than a quarter of  announced  net  zero  pledges  are  fixed  in  domestic  legislation  and  few  are  yet underpinned by specific measures or policies to deliver them in full and on time.
-  The Stated Policies Scenario (STEPS) takes account only of specific policies that are in place or have been announced by governments. Annual energy-related and industrial process CO2 emissions rise from 34 Gt in 2020 to 36 Gt in 2030 and remain around this level until 2050. If emissions continue on this trajectory, with similar changes in non-energy-related GHG emissions, this would lead to a temperature rise of around 2.7 °C by 2100 (with a 50% probability). Renewables provide almost 55% of global electricity generation in 2050 (up from 29% in 2020), but clean energy transitions lag in other sectors. Global coal use falls by 15% between 2020 and 2050; oil use in 2050 is 15% higher than in 2020; and natural gas use is almost 50% higher.
-  The Announced Pledges Case (APC) assumes that all announced national net zero pledges  are  achieved  in  full  and  on  time,  whether  or  not  they  are  currently underpinned by specific  policies.  Global  energy-related  and  industrial  process  CO2 emissions  fall  to  30 Gt  in  2030  and  22 Gt  in  2050.  Extending  this  trajectory,  with similar action on non-energy-related GHG emissions, would lead to a temperature rise in 2100 of around 2.1 °C (with a 50% probability). Global electricity generation nearly doubles  to  exceed  50 000 TWh  in  2050.  The  share  of  renewables  in  electricity generation rises to nearly 70% in 2050. Oil demand does not return to its 2019 peak and  falls  about  10%  from  2020  to  80 mb/d  in  2050.  Coal  use  drops  by  50%  to 2 600 Mtce in 2050, while natural gas use expands by 10% to 4 350 bcm in 2025 and remains about that level to 2050.
-  Efficiency,  electrification  and  the  replacement  of  coal  by  low-emissions  sources  in electricity  generation  play  a  central  role  in  achieving  net  zero  goals  in  the  APC, especially over the period to 2030. The relative contributions of nuclear, hydrogen, bioenergy and CCUS vary across countries, depending on their circumstances.
-  The divergence in trends between the APC and the STEPS shows the difference that current net zero pledges could make, while underlining at the same time the need for concrete policies and short-term plans that are consistent with long-term net zero pledges. However, the APC also starkly highlights that existing net zero pledges, even if  delivered  in  full,  fall  well  short  of  what  is  necessary  to  reach  global  net-zero emissions by 2050.

I

## 1.1 Introduction

November 2021 will see the most important UN Framework Convention on Climate Change (UNFCCC) Conference of the Parties (COP 26) since the Paris Agreement was signed in 2015. As COP 26 approaches, an increasing number of countries have announced long-term goals to  achieve  net-zero  greenhouse  gas  (GHG)  emissions  over  the  coming  decades.  On 31 March 2021, the International Energy Agency (IEA) hosted a Net Zero Summit to take stock of the growing list of commitments from countries and companies to reach the goals of the Paris Agreement, and to focus on the actions necessary to start turning those net zero goals into reality.

Achieving those goals will be demanding. The Covid-19 pandemic delivered a major shock to the world economy, resulting in an unprecedented 5.8% decline in CO2 emissions in 2020. However, our monthly data show that global energy-related CO2 emissions started to climb again in December 2020, and we estimate that they will rebound to around 33 gigatonnes of carbon dioxide (Gt CO2) in 2021, only 1.2% below the level in 2019 (IEA, 2021). Sustainable economic recovery packages offered a unique opportunity to make 2019 the definitive peak in global emissions, but the evidence so far points to a rebound in emissions in parallel with renewed economic growth, at least in the near term (IEA, 2020a).

Recent  IEA  analyses  examined  the  technologies  and  policies  needed  for  countries  and regions  to  achieve  net-zero  emissions  energy  systems.  The World  Energy  Outlook  2020 examined what would be needed over the period to 2030 to put the world on a path towards net-zero  emissions  by  2050  in  the  context  of  the  pandemic-related  economic  recovery (IEA, 2020b). The Faster Innovation Case in Energy Technology Perspectives 2020 explored whether net-zero emissions could be achieved globally by 2050 through accelerated energy technology development and deployment alone: it showed that, relative to baseline trends, almost half of  the emissions savings needed in 2050 to reach net-zero emissions rely on technologies that are not yet commercially available (IEA, 2020c).

This special report, prepared at the request of the UK President of the COP 26, incorporates the insights and lessons learned from both reports to create a comprehensive and detailed pathway,  or  roadmap,  to  achieve  net-zero  energy-related  and  industrial  process  CO2 emissions globally by 2050. It assesses the costs of achieving this goal, the likely impacts on employment and the economy, and the wider implications for the world. It also highlights the key milestones for  technologies, infrastructure, investment and policy  that are needed along the road to 2050.

This report is set out in four chapters:

-  Chapter 1 explores  the  outlook  for  global  CO 2 emissions  and  energy  supply  and  use based on existing policies and pledges. It sets out projections of global energy use and emissions based on the Stated Policies Scenario (STEPS) , which includes only the firm policies  that  are  in  place  or  have  been  announced  by  countries,  including  Nationally

Determined  Contributions.  It  also  examines  the Announced  Pledges  Case  (APC) ,  a variant of the STEPS that assumes that all of the net zero targets announced by countries around the world to date are met in full.

-  Chapter 2 presents the Net-Zero Emissions by 2050 Scenario (NZE) ,  which describes how energy demand and the energy mix will need to evolve if the world is to achieve net-zero emissions by 2050. It also assesses the corresponding investment needs and explores key uncertainties surrounding technology and consumer behaviour.
-  Chapter 3 examines the implications of the NZE for various sectors, covering fossil fuel supply,  the  supply  of  low-emissions  fuels  (such  as  hydrogen,  ammonia,  biofuels, synthetic fuels and biomethane) and the electricity, transport, industry and buildings sectors. It highlights the key changes required to achieve net-zero emissions in the NZE and the major milestones that are needed along the way.
-  Chapter 4 explores the implications of the NZE for the economy, the energy industry, citizens and governments.

## 1.2 Emissions reduction targets and net zero pledges

## 1.2.1 Nationally Determined Contributions

Under  the  Paris  Agreement,  Parties 1 are  required  to  submit  Nationally  Determined Contributions (NDCs) to the UNFCCC and to implement policies with the aim of achieving their stated objectives. The process is dynamic; it requires Parties to update their NDCs every five years in a progressive manner to reflect the highest possible ambition. The first round of NDCs,  submitted  by  191 countries,  covers  more  than  90%  of  global  energy-related  and industrial process  CO2 emissions. 2 The  first NDCs  included  some  targets  that  were unconditional  and  others  that  were  conditional  on  international  support  for  finance, technology and other means of implementation.

As  of  23  April  2021,  80 countries  have  submitted  new  or  updated  NDCs  to  the  UNFCCC, covering  just  over  40%  of  global  CO   emissions  (Figure 1.1). 2 3 Many of the updated NDCs include  more  stringent  targets  than  in  the  initial  round  of  NDCs,  or  targets  for  a  larger number of sectors or for a broader coverage of GHGs. In addition,  27 countries  and  the European Union have communicated long-term low GHG emissions development strategies to the UNFCCC, as requested by the Paris Agreement. Some of these strategies incorporate a net zero pledge.

1 Parties refers to the 197 members of the UNFCCC which includes all United Nations member states, United Nations General Assembly Observer State of Palestine, UN non-member states Niue and the Cook Islands and the European Union.

2 Unless  otherwise  stated,  CO2  emissions  in  this  report  refer  to  energy-related  and  industrial  process  CO2 emissions.

3 Several countries have indicated that they intend to submit new or updated NDCs later in 2021 or in 2022.

I

1

Figure 1.1 ⊳ Number of countries with NDCs, long-term strategies and net zero pledges, and their shares of 2020 global CO2 emissions

<!-- image -->

IEA. All rights reserved.

Around 40% of countries that have ratified the Paris Agreement have updated their NDCs, but net zero pledges cover around 70% of global CO2 emissions

## 1.2.2 Net-zero emissions pledges

There has been a rapid increase in the number of governments making pledges to reduce GHG emissions to net zero (Figure 1.2). In the Paris Agreement, countries agreed to 'achieve a balance between anthropogenic emissions by sources and removals by sinks of greenhouse gases in the second-half of the century'. The Intergovernmental Panel on Climate Change (IPCC) Special Report on Global Warming of 1.5 °C highlighted the importance of reaching net-zero  CO2  emissions  globally  by  mid-century  or  sooner  to  avoid  the  worst  impacts  of climate change (IPCC, 2018).

Net-zero  emissions  pledges  have  been  announced  by  national  governments,  subnational jurisdictions,  coalitions 4 and  a  large  number  of  corporate  entities  (see  Spotlight).  As  of 23 April 2021,  44 countries  and  the  European  Union  have  pledged  to  meet  a  net-zero emissions target: in total they account for around 70% of global CO2 emissions and GDP (Figure 1.3).  Of  these,  ten  countries  have  made  meeting  their  net  zero  target  a  legal obligation, eight are proposing to make it a legal obligation, and the remainder have made their pledges in official policy documents.

4 Examples include: the UN-led Climate Ambition Alliance in which signatories signal they are working towards achieving net-zero emissions by 2050; and the Carbon Neutrality Coalition launched at the UN Climate Summit in 2017, in which signatories commit to develop long-term low GHG emissions strategies in line with limiting temperature rises to 1.5 °C.

Figure 1.2 ⊳ Number of national net zero pledges and share of global CO2 emissions covered

<!-- image -->

IEA. All rights reserved.

There has been a significant acceleration in net-zero emissions pledges announced by governments, with an increasing number enshrined in law

Notes: In law = a net zero pledge has been approved by parliament and is legally binding. Proposed = a net zero pledge has been proposed to parliament to be voted into law. In policy document = a net zero pledge has been proposed but does not have legally binding status.

Figure 1.3 ⊳ Coverage of announced national net zero pledges

<!-- image -->

IEA. All rights reserved.

Countries accounting for around 70% of global CO2 emissions and GDP have set net zero pledges in law, or proposed legislation or in an official policy document

Note: GDP = gross domestic product at purchasing power parity.

I

1

In contrast to some of the shorter term commitments contained within NDCs, few net zero pledges  are  supported  by  detailed  policies  and  firm  routes  to  implementation.  Net-zero emissions pledges also vary considerably in their timescale and scope. Some key differences include:

-  GHG coverage. Most pledges cover all GHG emissions, but some include exemptions or different  rules  for  certain  types  of  emissions.  For  example,  New  Zealand's  net  zero pledge covers all GHGs except biogenic methane, which has a separate reduction target.
-  Sectoral boundaries . Some pledges exclude emissions from specific sectors or activities. For  example,  the  Netherlands  aims  to  achieve  net-zero  GHG  emissions  only  in  its electricity sector (as part of an overall aim to reduce total GHG emissions by 95%), and some countries, including France, Portugal and Sweden, exclude international aviation and shipping.
-  Use of carbon dioxide removal (CDR) . Pledges take varying approaches to account for CDR within a country's sovereign territory. CDR options include natural CO2 sinks, such as  forests  and  soils,  as  well  as  technological  solutions,  such  as  direct  air  capture  or bioenergy  with  carbon  capture  and  storage.  For  example,  Uruguay  has  stated  that natural CO2 sinks will be used to help it reach net-zero emissions, while Switzerland plans to use CDR technologies to balance a part of its residual emissions in 2050.
-  Use  of  international  mitigation  transfers .  Some  pledges  allow  GHG  mitigation  that occurs outside a country's borders to be counted towards the net zero target, such as through the transfer of carbon credits, while others do not. For example, Norway allows the potential use of international transfers, while France explicitly rules them out. Some countries, such as Sweden, allow such transfers but specify an upper limit to their use.
-  Timeframe .  The  majority  of  pledges,  covering  35%  of  global  CO   emissions  in  2020, 2 target net-zero emissions by 2050, but Finland aims to reach that goal by 2035, Austria and Iceland by 2040 and Sweden by 2045. Among others, the People's Republic of China (hereafter China) and Ukraine have set a target date after 2050.

## S P O T L I G H T

## How are businesses responding to the need to reach net-zero emissions?

There has been a rapid rise in net-zero emissions announcements from companies in recent years: as of February 2021, around 110 companies that consume large amounts of  energy  directly  or  produce  energy-consuming  goods  have  announced  net-zero emissions goals or targets.

Around 60-70% of global production of heating and cooling equipment, road vehicles, electricity  and  cement  is  from  companies  that  have  announced  net-zero  emissions targets  (Figure 1.4).  Nearly  60%  of  gross  revenue  in  the  technology  sector  is  also generated  by  companies  with  net-zero  emission  targets.  In  other  sectors,  net  zero

pledges cover 30-40% of air and shipping operations, 15% of transport logistics and 10% of  construction. All  these  shares  are  likely  to  keep  growing  as  more  companies  make pledges.

Figure 1.4 ⊳ Sectoral activity of large energy-related companies with announced pledges to reach net-zero emissions by 2050

<!-- image -->

IEA. All rights reserved.

Some sectors are more advanced in terms of the extent of net zero targets by companies active in the sector

Notes: Scope 1 = direct emissions from energy and other sources owned or controlled. Scope 2 = indirect emissions from the production of electricity and heat, and fuels purchased and used. Scope 3 = indirect emissions from sources not owned or directly controlled but related to their activities (such as employee travel,  extraction,  transport  and  production  of  purchased  materials  and  fuels,  and  end-use  of  fuels, products and services). Partial value chain includes Scope 1 and 2 emissions and Scope 3 emissions in specific geographic locations or sections of a company's value chain.

Source: IEA analysis based on company reports from the largest 10-25 companies within each sector.

Company pledges may not be readily comparable. Most companies account for emissions and  set  net  zero  pledges  based  on  the  GHG  Protocol  (WRI,  WBCSD,  2004),  but  the coverage  and  timeframe  of  these  pledges  varies  widely.  Some  cover  only  their  own emissions, for example by shifting to the use of zero-emissions electricity in offices and production  facilities,  and  by  eliminating  the  use  of  oil  in  transport  or  industrial operations, e.g. FedEx, ArcelorMittal and Maersk. Others also cover wider emissions from certain  parts  of  their  values  chains,  e.g.  Renault  in  Europe,  or  all  indirect  emissions related to their activities, e.g. Daikin, Toyota, Shell, Eni and Heidelberg. Around 60% of pledges aim to achieve net-zero emissions by 2050, but several companies have set an earlier deadline of 2030 or 2040.

Around 40% of companies that have announced net zero pledges have yet to set out how they aim to achieve them. For those with detailed plans, the main options include direct emissions reductions, use of CO2 removal technologies, such as afforestation, bioenergy

I

1

with  carbon  capture,  utilisation  and  storage  (CCUS),  or  direct  air  capture  with  CO 2 storage, and purchasing emissions (credits generated through emissions reductions that occur elsewhere). The use of offsets could be a cost-effective mechanism to eliminate emissions from parts of value chains where emissions reductions are most challenging, provided that schemes to generate emissions credits result in permanent, additional and verified emissions reductions. However, there is likely to be a limited supply of emissions credits  consistent  with  net-zero  emissions  globally  and  the  use  of  such  credits  could divert investment from options that enable direct emissions reductions.

## 1.3 Outlook for emissions and energy in the STEPS

The IEA Stated Policies Scenario (STEPS) illustrates the consequences of existing and stated policies for the energy sector. It draws on the latest information regarding national energy and climate plans and the policies that underpin them. It takes account of all policies that are backed by robust implementing legislation or regulatory measures, including the NDCs that countries have put forward under the Paris Agreement up to September 2020 and the energy components of announced economic stimulus and recovery packages. So far, few net-zero emissions pledges have been backed up by detailed policies, implementation plans or interim targets: most net zero pledges therefore are not included in the STEPS.

## 1.3.1 CO2 emissions

Global CO2 emissions in the STEPS bring about only a marginal overall improvement in recent trends. Switching to renewables leads to an early peak in emissions in the electricity sector, but reductions across all sectors fall far short of what is required for net-zero emissions in 2050. Annual CO2 emissions rebound quickly from the dip caused by the Covid-19 pandemic in 2020: they increase from 34 Gt in 2020 to 36 Gt in 2030 and then remain around this level until 2050 (Figure 1.5). If emissions trends were to continue along the same trajectory after 2050,  and  with  commensurate  changes  in  other  sources  of  GHG  emissions,  the  global average surface temperature rise would be around 2.7 °C in 2100 (with a 50% probability).

There is strong divergence between the outlook for emissions in advanced economies on one hand  and  the  emerging  market  and  developing  economies  on  the  other.  In  advanced economies, despite a small rebound in the early 2020s, CO2 emissions decline by about a third between 2020 and 2050, thanks to the impact of policies and technological progress in reducing energy demand and switching to cleaner fuels. In emerging market and developing economies, energy demand continues to grow strongly because of increased population, brisk  economic  growth,  urbanisation  and  the  expansion  of  infrastructure:  these  effects outweigh  improvements  in  energy  efficiency  and  the  deployment  of  clean  technologies, causing CO2 emissions to grow by almost 20% by the mid-2040s, before declining marginally to 2050.

Figure 1.5 ⊳ Energy-related and industrial process CO2 emissions by region and sector in the STEPS

<!-- image -->

Note: Other = agriculture and own use in the energy sector.

## 1.3.2 Total energy supply, total final consumption and electricity generation

The projected trends in CO2 emissions in the STEPS result from changes in the amount of energy used and the mix of fuels and technologies. Total energy supply (TES)  worldwide 5 rises by just over 30% between 2020 and 2050 in the STEPS (Figure 1.6). Without a projected annual average reduction of 2.2% in energy intensity, i.e. energy use per unit of GDP, TES in 2050 would be around 85% higher. In advanced economies, energy use falls by around 5% to 2050, despite a 75% increase in economic activity over the period. In emerging market and developing economies, energy use increases by 50% to 2050, reflecting a tripling of economic output between 2020 and 2050. Despite the increase in GDP and energy use in emerging market and developing economies, 750 million people still have no access to electricity in 2050, more than 95% of them in sub-Saharan Africa, and 1.5 billion people continue to rely on the traditional use of bioenergy for cooking.

The global fuel mix changes significantly between 2020 and 2050. Coal use, which peaked in 2014, falls by around 15%. Having fallen sharply in 2020 due to the pandemic, oil demand rebounds quickly, returning to the 2019 level of 98 million barrels per day (mb/d) by 2023 and reaching a plateau of around 104 mb/d shortly after 2030. Natural gas demand increases from 3 900 billion cubic metres (bcm) in 2020 to 4 600 bcm in 2030 and 5 700 bcm in 2050. Nuclear energy grows by 15% between 2020 and 2030, mainly reflecting expansions in China.

5 Total primary energy supply (or total primary energy demand) has been renamed total energy supply in accordance with the International Recommendations for Energy Statistics (IEA, 2020d).

I

1

Figure 1.6 ⊳ Total energy supply and CO2 emissions intensity in the STEPS

<!-- image -->

Coal use declines, oil plateaus and renewables and natural gas grow substantially to 2050

Note: EJ = exajoule; MJ = megajoule; TES = total energy supply.

Total final consumption increases in all sectors in the STEPS, led by electricity and natural gas (Figure 1.7). All the growth is in emerging market and developing economies. The biggest change  in  energy  use  is  in  the  electricity  sector  (Figure 1.8).  Global  electricity  demand increases by 80% between 2020 and 2050, around double the overall rate of growth in final energy consumption. More than 85% of the growth in global electricity demand comes from emerging market and developing economies. Coal continues to play an important role in electricity generation in those economies to 2050, despite strong growth in renewables: in advanced economies, the use of coal for electricity generation drops sharply.

Figure 1.7 ⊳ Total final consumption by sector and fuel in the STEPS

<!-- image -->

IEA. All rights reserved.

Final energy consumption grows on average by 1% per year between 2020 and 2050, with electricity and natural gas meeting most of the increase

Figure 1.8 ⊳ Electricity generation by fuel and share of coal in the STEPS

<!-- image -->

Emerging market and developing economies drive most of the increase in global electricity demand, met mainly by renewables and gas, though coal remains important

## 1.3.3 Emissions from existing assets

The energy sector contains a large number of long-lived and capital-intensive assets. Urban infrastructure,  pipelines,  refineries,  coal-fired  power  plants,  heavy  industrial  facilities, buildings and large hydro power plants can have technical and economic lifetimes of well over 50 years. If today's energy infrastructure was to be operated until the end of the typical lifetime  in  a  manner  similar  to  the  past,  we  estimate  that  this  would  lead  to  cumulative energy-related and industrial process CO2 emissions between 2020 and 2050 of just under 650 Gt CO2. This is around 30% more than the remaining total CO2 budget consistent with limiting global warming to 1.5 °C with a 50% probability (see Chapter 2).

The electricity sector accounts for more than 50% of the total emissions that would come from existing assets; 40% of total emissions would come from coal-fired power plants alone. Industry  is  the  next  largest  sector,  with  steel,  cement,  chemicals  and  other  industry accounting  for  around  30%  total  emissions  from  existing  assets.  The  long  lifetime  of production facilities in these sub-sectors (typically 30-40 years for a blast furnace or cement kiln) and the relatively young age of the global capital stock explain their large contribution. Transport accounts for just over 10% of emissions from existing assets and the buildings sector accounts for just under 5%. The lifetime of vehicles and equipment in the transport and buildings sectors is generally much shorter than is the case in electricity and industry passenger cars, for example, are generally assumed to have a lifetime of around 17 years but associated infrastructure networks such as roads, electricity networks and gas grids have very long lifetimes.

There  are  some  large  regional  differences  in emissions  levels from  existing assets (Figure 1.9).  Advanced  economies  tend  to  have  much  older  capital  stocks  than  emerging market and developing economies, particularly in the electricity sector, and existing assets will reach the end of their lifetimes earlier. For example, the average age of coal-fired power

I

1

plants in China is 13 years and 16 years in the rest of Asia, compared to around 35 years in Europe and 40 years in the United States (IEA, 2020e).

Figure 1.9 ⊳ Emissions from existing infrastructure by sector and region

<!-- image -->

Emerging market and developing economies account for three-quarters of cumulative emissions from existing infrastructure through to 2050

## 1.4 Announced Pledges Case

The Announced Pledges Case (APC) assumes that all national net-zero emissions pledges are realised in full and on time. It therefore goes beyond the policy commitments incorporated in the STEPS. The aim of the APC is to see how far full implementation of the national netzero emissions pledges would take the world towards reaching net-zero emissions, and to examine the scale of the transformation of the energy sector that such a path would require.

The  way  these  pledges  are  assumed  to  be  implemented  in  the  APC  has  important implications  for  the  energy  system.  A  net  zero  pledge  for  all  GHG  emissions  does  not necessarily mean that CO2 emissions from the energy sector need to reach net zero. For example, a country's net zero plans may envisage some remaining energy-related emissions are offset by the absorption of emissions from forestry or land use, or by negative emissions arising from the use of bioenergy or direct capture of CO2 from the air (DAC) with CCUS.  It 6 is not possible to know exactly how net zero pledges will be implemented, but the design of the APC, particularly with respect to the details of the energy system pathway, has been informed by the pathways that a number of national bodies have developed to support net zero pledges (Box 1.1). Policies in countries that have not yet made a net zero pledge are assumed to be the same as in the STEPS. Non policy assumptions, including population and economic growth, are the same as in the STEPS.

6 For  example,  in  recent  economy-wide  net  zero  mitigation  pathways  for  the  European  Union,  around 140-210 million tonnes CO2 of emissions from the energy sector remain in 2050, which are offset by CDR from managed land-use sinks, and bioenergy and DAC with CCUS (European Commission, 2018).

## Box 1.1 ⊳ Consultations with national bodies on achieving national netzero emissions goals

To help inform its work on net zero pathways, the IEA engaged in extensive consultations with experts in academia and national bodies that have developed pathways to support net zero pledges made by governments. This includes groups that have developed netzero emissions pathways for several countries including China, European Union, Japan, United Kingdom and United States, as well as the IPCC. These pathways were not used directly  as  input  for  the  APC,  but  the  discussions  informed  our  modelling  of  national preferences and constraints within each jurisdiction and to benchmark the overall level of energy-related CO2 emissions reductions that are commensurate with economy-wide net zero goals.

## 1.4.1 CO2 emissions

In the APC, there is a small rebound in emissions to 2023, although this is much smaller than the increase that immediately followed the financial crisis in 2008-09. Emissions never reach the previous peak of 36 Gt CO2. Global CO2 emissions fall around 10% to 30 Gt in 2030 and to 22 Gt in 2050. This is around 35% below the level in 2020 and 14 Gt CO2 lower than in the STEPS (Figure 1.10). If emissions continue this trend after 2050, and with a similar level of changes in non-energy-related GHG emissions, the global average surface temperature rise in 2100 would be around 2.1 °C (with a 50% probability).

Figure 1.10 ⊳ Global energy-related and industrial process CO2 emissions by scenario and reductions by region, 2010-2050

<!-- image -->

Achieving existing net zero pledges would reduce emissions globally to 22 Gt CO2 in 2050, a major reduction compared with current policies but still far from net-zero emissions

I

1

The net zero pledges that have been made to date therefore make a major difference to the current trajectory for CO2 emissions. Equally, however, existing net zero pledges fall well short of what is necessary to reach net-zero emissions globally by 2050. This highlights the importance of concrete policies and plans to deliver in full long-term net zero pledges. It also underlines the value of other countries making (and delivering on) net zero pledges: the more countries that do so, and the more ambitious those pledges are, the more the gap will narrow with what is needed to reach net-zero emissions by 2050.

The largest drop in CO2 emissions is in the APC is in the electricity sector with global emissions falling  by  nearly  60%  between  2020  and  2050.  This  occurs  despite  a  near-doubling  of electricity demand as energy end-uses are increasingly electrified, notably in transport and buildings (Figure 1.11). This compares with a fall in emissions of less than 15% in the STEPS.

Figure 1.11 ⊳ Global CO2 emissions by sector in the STEPS and APC

<!-- image -->

IEA. All rights reserved.

Announced net zero pledges would cut emissions in 2050 by 60% in the electricity sector, 40% in buildings, 25% in industry and just over 10% in transport

The transport and industry sectors see a less marked fall in CO2 emissions to 2050 in the APC, with  increases  in  energy  demand  in  regions  without  net  zero  pledges  partially  offsetting emissions reduction efforts in other regions. Emissions from the buildings sector decline by around 40% between 2020 and 2050, compared with around 5% in the STEPS: fossil fuel use in buildings is mostly to provide heating, and countries that have made pledges account for a relatively high proportion of global heating demand.

Even in regions with net zero pledges, there are some residual emissions in 2050, mainly in industry  and  transport.  This  reflects  the  scarcity  of  commercially  available  options  to eliminate all emissions from heavy-duty trucks, aviation, shipping and heavy industry.

## 1.4.2 Total energy supply

Global total energy supply increases by more than 15% between 2020 and 2050 in the APC, compared with a third in the STEPS (Figure 1.12). Energy intensity falls on average by around 2.6% per year to 2050 compared with 2.2% in the STEPS. There is a substantial increase in energy  demand  in  emerging  market  and  developing  economies,  where  economic  and population growth is fastest and where there are fewer net zero pledges, which outweighs the reductions in energy demand in the countries with net zero pledges.

Figure 1.12 ⊳ Total energy supply by source in STEPS and APC

<!-- image -->

IEA. All rights reserved.

Announced net zero pledges lift renewables in the APC from 12% of total energy supply in 2020 to 35% in 2050, mainly at the expense of coal and oil

The global increase in energy supply in the APC is led by renewables, which increase their share in the energy mix from 12% in 2020 to 35% by 2050 (compared with 25% in 2050 in the STEPS). Solar photovoltaics (PV) and wind in the electricity sector together contribute about  50%  of  the  growth  in  renewables  supply,  and  bioenergy  contributes  around  30%. Bioenergy use doubles in industry, triples in electricity generation and grows by a factor of four  in  transport:  it  plays  an  important  role  in  reducing  emissions  from  heat  supply  and removing CO2 from the atmosphere when it is combined with CCUS. Nuclear maintains its share of the energy mix, its output rising by a quarter to 2030 (compared with a 15% increase in  the  STEPS),  driven  by  lifetime  extensions  at  existing  plants  and  new  reactors  in  some countries.

Global coal use falls significantly more rapidly in the APC than in the STEPS. It drops from 5 250 million tonnes of coal equivalent (Mtce) in 2020 to 4 000 Mtce in 2030 and 2 600 Mtce in  2050 (compared with 4 300 Mtce in the STEPS in 2050). Most of this decline is due to reduced coal-fired electricity  generation  in  countries  with  net  zero  pledges  as  plants  are repurposed, retrofitted or retired. In advanced economies, unabated coal-fired power plants

I

1

are generally phased out over the next 10-15 years. China's coal consumption for electricity declines by 85% between 2020 and 2050 on its path towards carbon neutrality in 2060. These declines more than offset continued growth for coal in countries without net zero pledges. Globally, coal use in industry falls by 25% between 2020 and 2050, compared with a 5% decline in the STEPS.

Oil demand recovers slightly in the early 2020s but never again reaches its historic peak in 2019. It declines to 90 mb/d in the early 2030s and to 80 mb/d in 2050, around 25 mb/d lower than in the STEPS, thanks to a strong push to electrify transport and shifts to biofuels and hydrogen, especially in regions with pledges. Natural gas demand increases from about 3 900 bcm in 2020 to around 4 350 bcm in 2025, but is then broadly flat to 2050 (it continues to grow to around 5 700 bcm in the STEPS).

## 1.4.3 Total final consumption

Global  energy  use  continues  to  grow  in  all  major  end-use  sectors  in  the  APC,  albeit substantially  more  slowly  than  in  the  STEPS  (Figure 1.13).  Total  final  consumption  (TFC) increases by around 20% in 2020-50, compared with a 35% increase globally in the STEPS. Measures to improve energy efficiency play a major role in the APC in reducing demand growth in countries with net zero pledges. Without those efficiency gains, electricity demand growth  would  make  it  much  harder  for  renewables  to  displace  fossil  fuels  in  electricity generation. The biggest reduction in energy demand relative to the STEPS is in transport, thanks to an accelerated shift to electric vehicles (EVs), which are around three-times as energy efficient as conventional internal combustion engine vehicles.

Figure 1.13 ⊳ Total final consumption in the APC

<!-- image -->

IEA. All rights reserved.

Announced net zero pledges lead to a shift away from fossil fuels globally to electricity, renewables and hydrogen. Electricity's share rises from 20% to 30% in 2050

The fuel mix in final energy use shifts substantially in the APC. By 2050, electricity is the largest  single  fuel  used  in  all  sectors  except  transport,  where  oil  remains  dominant.  The persistence of oil in transport stems partly from the extent of its continued use in countries without net zero pledges, and partly from the difficulty of electrifying substantial parts of the transport sector, notably trucking and aviation. Electricity does make inroads into transport, however, and rapid growth in the uptake of EVs puts oil use into decline after 2030, with EVs accounting for around 35% of global passenger car sales by 2030 and nearly 50% in 2050 in the APC (versus around 25% in the STEPS in 2050). Electrification in the buildings sector is also much faster in the APC than in the STEPS.

The direct use of renewables expands in all end-use sectors globally through to 2050. Modern bioenergy  accounts  for  the  bulk  of  this  growth,  predominantly  through  the  blending  of biomethane into natural gas networks and liquid biofuels in transport. This occurs mainly in regions with net zero pledges. Hydrogen and hydrogen-based fuels play a larger role in the APC than in the STEPS, reaching almost 15 exajoules (EJ) in 2050, though they still account for only 3% of total final consumption worldwide in 2050. Transport accounts for more than two-thirds of all hydrogen consumption in 2050. In parallel, on-site hydrogen production in the industry and refining sectors gradually shifts towards low-carbon technologies.

## 1.4.4 Electricity generation

Global electricity generation nearly doubles during the next three decades in the APC, rising from  about  26 800 terawatt-hours  (TWh)  in  2020  to  over  50 000 TWh  in  2050,  some 4 000 TWh higher than in the STEPS. Low-emissions energy sources provide all the increase. The share of renewables in electricity generation rises from 29% in 2020 to nearly 70% in 2050, compared with about 55% in the STEPS, as solar PV and wind race ahead of all other sources of generation (Figure 1.14). By 2050, solar PV and wind together account for almost half of electricity supply. Hydropower also continues to expand, emerging as the third-largest energy  source  in  the  electricity  mix  by  2050.  Nuclear  power  increases  steadily  too, maintaining its global market share of about 10%, led by increases in China. Natural gas use in electricity increases slightly to the mid-2020s before starting to fall back, while coal's share of electricity generation falls from around 35% in 2020 to below 10% in 2050. At that point, 20% of the remaining coal-fired output comes from plants equipped with CCUS.

Hydrogen and ammonia start to emerge as fuel inputs to electricity generation by around 2030, used largely in combination with natural gas in gas turbines and with coal in coal-fired power  plants.  This  extends  the  life  of  existing  assets,  contributes  to  electricity  system adequacy  and  reduces  the  overall  costs  of  transforming  the  electricity  sectors  in  many countries. Total battery capacity also rises substantially, reaching 1 600 gigawatts (GW) in 2050, 70% more than in the STEPS.

I

1

Figure 1.14 ⊳ Global electricity generation by source in the APC

<!-- image -->

IEA. All rights reserved.

Renewables reach new heights in the APC, rising from just under 30% of electricity supply in 2020 to nearly 70% in 2050, while coal-fired generation steadily declines

Note: Other renewables = geothermal, solar thermal and marine.

<!-- image -->

## A global pathway to net-zero CO  emissions in 2050 ₂

## S U M M A R Y

-  The Net-Zero Emissions by 2050 Scenario (NZE) shows what is needed for the global energy sector to achieve net-zero CO2 emissions by 2050. Alongside corresponding reductions in GHG emissions from outside the energy sector, this is consistent with limiting the global temperature rise to 1.5 °C without a temperature overshoot (with a 50%  probability).  Achieving  this  would  require  all  governments  to  increase ambitions from current Nationally Determined Contributions and net zero pledges.
-  In the NZE, global energy-related and industrial process CO2 emissions fall by nearly 40% between 2020 and 2030 and to net zero in 2050. Universal access to sustainable energy is achieved by 2030. There is a 75% reduction in methane emissions from fossil fuel  use  by  2030.  These  changes  take  place  while  the  global  economy  more  than doubles through to 2050 and the global population increases by 2 billion.
-  Total energy supply falls by 7% between 2020 and 2030 in the NZE and remains at around this level to 2050. Solar PV and wind become the leading sources of electricity globally before 2030 and together they provide nearly 70% of global generation in 2050. The traditional use of bioenergy is phased out by 2030.
-  Coal demand declines by 90% to less than 600 Mtce in 2050, oil declines by 75% to 24 mb/d, and natural gas declines by 55% to 1 750 bcm. The fossil fuels that remain in  2050  are  used  in  the  production  of  non-energy  goods  where  the  carbon  is embodied in the product (like plastics), in plants with carbon capture, utilisation and storage (CCUS), and in sectors where low-emissions technology options are scarce.
-  Energy efficiency, wind and solar provide around half of emissions savings to 2030 in the NZE. They continue to deliver emissions reductions beyond 2030, but the period to 2050 sees increasing electrification, hydrogen use and CCUS deployment, for which not all technologies are available on the market today, and these provide more than half  of  emissions  savings  between  2030  and  2050.  In  2050,  there  is  1.9 Gt  of  CO 2 removal  in  the  NZE  and  520 million  tonnes  of  low-carbon  hydrogen  demand. Behavioural changes by citizens and businesses avoid 1.7 Gt CO2 emissions in 2030, curb energy demand growth, and facilitate clean energy transitions.
-  Annual energy sector investment, which averaged USD 2.3 trillion globally in recent years, jumps to USD 5 trillion by 2030 in the NZE. As a share of global GDP, average annual energy investment to 2050 in the NZE is around 1% higher than in recent years.
-  The NZE taps into all opportunities to decarbonise the energy sector, across all fuels and  all  technologies.  But  the  path  to  2050  has  many  uncertainties.  If  behavioural changes were to be more limited than envisaged in the NZE, or sustainable bioenergy less  available,  then  the  energy  transition  would  be  more  expensive.  A  failure  to develop CCUS for fossil fuels could delay or prevent the development of CCUS for process emissions from cement production and carbon removal technologies, making it much harder to achieve net-zero emissions by 2050.

## 2.1 Introduction

Achieving  a  global  energy  transition  that  is  compatible  with  the  world's  climate  goals  is unquestionably  a  formidable  task.  As  highlighted  in  Chapter  1,  current  pledges  by governments to reduce emissions to net zero collectively cover around 70% of today's global economic activity and global CO2 emissions. The Announced Pledges Case shows that, if all those pledges were met in full, it would narrow the gap between where we are heading and where we need to be to achieve net-zero emissions by 2050 worldwide. But it also shows that the gap would remain large. Meeting all existing net zero pledges in full would still leave 22 gigatonnes (Gt) of energy-related and industrial process CO2 emissions globally in 2050, consistent with a temperature rise in 2100 of around 2.1 °C (with a 50% probability).

In  this  chapter,  we  examine  the  energy  sector  transformation  which  is  embodied  in  our Net-Zero Emissions by 2050 Scenario. First, it provides an overview of the key assumptions and  market  dynamics  underlying  the  projections,  including  projected  fossil  fuel  and  CO 2 prices. It discusses trends in global CO2 emissions, energy use and investment, including the key  roles  played  by  efficiency  measures,  behavioural  change,  electrification,  renewables, hydrogen and hydrogen-based fuels, bioenergy, and carbon capture, utilisation and storage (CCUS). Further, it discusses some of the key uncertainties surrounding the global pathway towards net-zero emissions related to  behavioural  change,  the  availability  of  sustainable bioenergy, and the deployment of CCUS for fossil fuels. The transformation of specific energy sectors is assessed and discussed in detail in Chapter 3.

## 2.2 Scenario design

The Net-Zero Emissions by 2050 Scenario (NZE) is designed to show what is needed across the main sectors by various actors, and by when, for the world to achieve net-zero energyrelated  and  industrial  process  CO 2 emissions  by  2050.   It  also  aims  to  minimise  methane 1 emissions from the energy sector. In recent years, the energy sector was responsible for around three-quarters of global greenhouse gas (GHG) emissions. Achieving net-zero energyrelated and industrial process CO2 emissions by 2050 in the NZE does not rely on action in areas other than the energy sector, but limiting climate change does require such action. We therefore additionally examine the reductions in CO2 emissions from land use that would be commensurate  with  the  transformation  of  the  energy  sector  in  the  NZE,  working  in co-operation with the International Institute for Applied Systems Analysis (IIASA). In parallel with action on reducing all other sources of GHG emissions, achieving net-zero CO2 emissions from the energy sector by 2050 is consistent with around a 50% chance of limiting the longterm average global temperature  rise to 1.5 °C without a temperature  overshoot (IPCC, 2018).

1 Unless otherwise stated, carbon dioxide (CO2) emissions in this chapter refer to energy-related and industrial process CO2 emissions. Net-zero CO2 emissions refers to zero CO2 emissions to the atmosphere, or with any residual CO2 emissions offset by CO2 removal from direct air capture or bioenergy with carbon capture and storage.

The NZE aims to ensure that energy-related and industrial process CO2 emissions to 2030 are in line with reductions in 1.5 °C scenarios with no or low or limited temperature overshoot assessed in the IPCC in its Special Report on Global Warming of 1.5 °C.  In addition, the NZE 2 incorporates concrete action on the energy-related United Nations Sustainable Development Goals related to achieving universal energy access by 2030 and delivering a major reduction in air pollution. The projections in the NZE were generated by a hybrid model that combines components  of  the  IEA's  World  Energy  Model  (WEM),  which  is  used  to  produce  the projections in the annual World Energy Outlook, and the Energy Technology Perspectives (ETP) model.

## Box 2.1 ⊳ International Energy Agency modelling approach for the NZE

A new, hybrid modelling approach was adopted to develop the NZE and combines the relative strengths of the WEM and the ETP model. The WEM is a large-scale simulation model designed to replicate how competitive energy markets function and to examine the implications of policies on a detailed sector-by-sector and region-by-region basis. The ETP model  is a large-scale partial-optimisation model  with detailed technology descriptions  of  more  than  800 individual  technologies  across  the  energy  conversion, industry, transport and buildings sectors.

This is the first time this modelling approach has been implemented. The combination of the  two  models  allows  for  a  unique  set  of  insights  on  energy  markets,  investment, technologies, and the level and detail of policies that would be needed to bring about the energy sector transformation in the NZE.

Results from the WEM and ETP model have been coupled with the Greenhouse Gas - Air Pollution Interactions and Synergies (GAINS) model developed by IIASA (Amann et al., 2011). The GAINS model is used to evaluate air pollutant emissions and resultant health impacts linked to air pollution. For the first time, IEA model results have also been coupled with the IIASA's Global Biosphere Management Model (GLOBIOM) to provide data on land use and net emissions impacts of bioenergy demand.

The impacts of changes in investment and spending on global GDP in the NZE have been estimated  by  the  International  Monetary  Fund  (IMF)  using  the  Global  Integrated Monetary and Fiscal (GIMF) model. GIMF is a multi-country dynamic stochastic general equilibrium  model  used  by  the  IMF  for  policy  and  risk  analysis  (Laxton  et  al.,  2010; Anderson et al., 2013). It has been used to produce the IMF's World Economic Outlook scenario analyses since 2008.

There are many possible paths to achieve net-zero CO2 emissions globally by 2050 and many uncertainties that could affect any of them; the NZE is therefore a path, not the path to netzero emissions. Much depends, for example, on the pace of innovation in new and emerging

2 The IPCC classifies scenarios as 'no or limited temperature overshoot', if temperatures exceed 1.5 °C by less than 0.1 °C but return to less than 1.5 °C in 2100, and as 'higher overshoot', if temperatures exceed 1.5 °C by 0.1-0.4 °C but return to less than 1.5 °C in 2100.

2

technologies,  the  extent  to  which  citizens  are  able  or  willing  to  change  behaviour,  the availability  of  sustainable  bioenergy  and  the  extent  and  effectiveness  of  international collaboration. We investigate some of the key alternatives and uncertainties here and in Chapter 3. The Net-Zero Emissions by 2050 Scenario is built on the following principles.

-  The uptake of all the available technologies and emissions reduction options is dictated by costs, technology maturity, policy preferences, and market and country conditions.
-  All countries co-operate towards achieving net-zero emissions worldwide. This involves all countries participating in efforts to meet the net zero goal, working together in an effective and mutually beneficial way, and recognising the different stages of economic development of countries and regions, and the importance of ensuring a just transition.
-  An orderly transition across the energy sector. This includes ensuring the security of fuel and  electricity  supplies  at  all  times,  minimising  stranded  assets  where  possible  and aiming to avoid volatility in energy markets.

## 2.2.1 Population and GDP

The energy sector transformation in the NZE occurs against the backdrop of large increases in the world's population and economy (Figure 2.1). In 2020, there were around 7.8 billion people in the world; this is projected to increase by around 750 million by 2030 and by nearly 2 billion people by 2050 in line with the median variant of the United Nations projections (UNDESA, 2019). Nearly all of the population increase is in emerging market and developing economies: the population of Africa alone increases by more than 1.1 billion between 2020 and 2050.

Figure 2.1 ⊳ World population by region and global GDP in the NZE

<!-- image -->

IEA. All rights reserved.

By 2050, the world's population expands to 9.7 billion people and the global economy is more than twice as large as in 2020

Notes: GDP = gross domestic product in purchasing power parity; C &amp; S America = Central and South America. Sources: IEA analysis based on UNDESA (2019); Oxford Economics (2020); IMF (2020a, 2020b).

The  world's  economy  is  assumed  to  recover  rapidly  from  the  impact  of  the  Covid-19 pandemic. Its size returns to pre-crisis levels in 2021. From 2022, the GDP growth trend is close to the pre-pandemic rate of around 3% per year on average, in line with assessments from the IMF. The response to the pandemic leads to a large increase in government debt, but resumed growth, along with low interest rates in many countries, make this manageable in the long term. By 2030, the world's economy is around 45% larger than in 2020, and by 2050 it is more than twice as large.

## 2.2.2 Energy and CO2 prices

Projections of future energy prices are inevitably subject to a high degree of uncertainty. In IEA scenarios, they are designed to maintain an equilibrium between supply and demand. The rapid drop in oil and natural gas demand in the NZE means that no fossil fuel exploration is required and no new oil and natural gas fields are required beyond those that have already been approved for development. No new coal mines or mine extensions are required either. Prices are increasingly set by the operating costs of the marginal project required to meet demand, and this results in significantly lower fossil fuel prices than in recent years. The oil price  drops  to  around  USD 35/barrel  by  2030  and  then  drifts  down  slowly  towards USD 25/barrel in 2050.

Table 2.1 ⊳ Fossil fuel prices in the NZE

| Real terms (USD 2019)      | 2010   | 2020   | 2030   | 2040   | 2050   |
|----------------------------|--------|--------|--------|--------|--------|
| IEA crude oil (USD/barrel) | 91     | 37     | 35     | 28     | 24     |
| Natural gas (USD/MBtu)     |        |        |        |        |        |
| United States              | 5.1    | 2.1    | 1.9    | 2.0    | 2.0    |
| European Union             | 8.7    | 2.0    | 3.8    | 3.8    | 3.5    |
| China                      | 7.8    | 5.7    | 5.2    | 4.8    | 4.6    |
| Japan                      | 12.9   | 5.7    | 4.4    | 4.2    | 4.1    |
| Steam coal (USD/tonne)     |        |        |        |        |        |
| United States              | 60     | 45     | 24     | 24     | 22     |
| European Union             | 108    | 56     | 51     | 48     | 43     |
| Japan                      | 125    | 75     | 57     | 53     | 49     |
| Coastal China              | 135    | 81     | 60     | 54     | 50     |

Notes: MBtu = million British thermal units. The IEA crude oil prices are a weighted average import price among IEA member countries. Natural gas prices are weighted averages expressed on a gross calorific-value basis. US natural gas prices reflect the wholesale price prevailing on the domestic market. The European Union and China gas prices reflect a balance of pipeline and liquefied natural gas (LNG) imports, while Japan gas prices solely reflect LNG imports. LNG prices used are those at the customs border, prior to regasification. Steam coal prices are weighted averages adjusted to 6 000 kilocalories per kilogramme. US steam coal prices reflect mine-mouth price  plus  transport  and  handling  cost.  Coastal  China  steam  coal  price  reflects  a  balance  of imports and domestic sales, while the European Union and Japanese steam coal prices are solely for imports.

2

In  line  with  the  principle  of  orderly  transitions  governing  the  NZE,  the  trajectory  for  oil markets and prices avoids excessive volatility. What happens depends to a large degree on the strategies adopted by resource-rich governments and their national oil companies. In the NZE it is assumed that, despite having lower cost resources at their disposal, they restrict investment in new fields. This limits the need for the shutting in and closure of higher cost production. The market share of major resource-rich countries nevertheless still rises in the NZE due to the large size and slow decline rates of their existing fields.

Producer economies could pursue alternative approaches. Faced with rapidly falling oil and gas demand, they could, for example, opt to increase production so as to capture an even larger share of the market. In this event, the combination of falling demand and increased availability of low cost oil would undoubtedly lead to even lower - and probably much more volatile - prices. In practice, the options open to particular producer countries would depend on  their  resilience  to  lower  oil  prices  and  on  the  extent  to  which  export  markets  have developed for low-emissions fuels that could be produced from their natural resources.

Anticipating  and  mitigating  feedbacks  from  the  supply  side  is  a  central  element  of  the discussion about orderly energy transitions. A drop in prices usually results in some rebound in  demand,  and  policies  and  regulations  would  be  essential  to  avoid  this  leading  to  any increase  in  the  unabated  use  of  fossil  fuels,  which  would  undermine  wider  emissions reduction efforts.

As the energy sector transforms, more fuels are traded globally, such as hydrogen-based fuels and biofuels. The prices of these commodities are assumed to be set by the marginal cost of domestic production or imports within each region.

A  broad  range  of  energy  policies  and  accompanying  measures  are  introduced  across  all regions to reduce emissions in the NZE. This includes: renewable fuel mandates; efficiency standards; market reforms; research, development and deployment; and the elimination of inefficient  fossil  fuel  subsidies.  Direct  emissions  reduction  regulations  are  also  needed  in some cases. In the transport sector, for example, regulations are implemented to reduce sales  of  internal  combustion  engine  vehicles  and  increase  the  use  of  liquid  biofuels  and synthetic fuels in aviation and shipping, as well as measures to ensure that low oil prices do not lead to an increase in consumption.

CO2 prices are introduced across all regions in the NZE (Table 2.2). They are assumed to be introduced  in  the  immediate  future  across  all  advanced  economies  for  the  electricity generation, industry and energy production sectors, and to rise on average to USD 130 per tonne (tCO2) by 2030 and to USD 250/tCO2 by 2050. In a number of other major economies - including China, Brazil, Russia and South Africa - CO2 prices in these sectors are assumed to  rise  to  around  USD 200/tCO2 in  2050.  CO   prices  are  introduced  in  all  other  emerging 2 market and developing economies,  although  it  is  assumed  that  they  pursue  more  direct policies to adapt and transform their energy systems and so the level of CO2 prices is lower than elsewhere.

Table 2.2 ⊳ CO2 prices for electricity, industry and energy production in the NZE

| USD (2019) per tonne of CO 2                       |   2025 |   2030 |   2040 |   2050 |
|----------------------------------------------------|--------|--------|--------|--------|
| Advanced economies                                 |     75 |    130 |    205 |    250 |
| Selected emerging market and developing economies* |     45 |     90 |    160 |    200 |
| Other emerging market and developing economies     |      3 |     15 |     35 |     55 |

* Includes China, Russia, Brazil and South Africa.

## 2.3 CO2 emissions

Global  energy-related  and  industrial  process  CO2  emissions  in  the  NZE  fall  to  around 21 Gt CO2 in 2030 and to net-zero in 2050 (Figure 2.2).  CO2 emissions in advanced economies 3 as a whole fall to net zero by around 2045 and these countries collectively remove around 0.2 Gt CO2 from the atmosphere in 2050. Emissions in several individual emerging market and developing economies also fall to net zero well before 2050, but in aggregate there are around 0.2 Gt CO2 of remaining emissions in this group of countries in 2050. These are offset by CO2 removal in advanced economies to provide net-zero CO2 emissions at the global level.

Figure 2.2 ⊳ Global net CO2 emissions in the NZE

<!-- image -->

IEA. All rights reserved.

CO2 emissions fall to net zero in advanced economies around 2045 and globally by 2050. Per capita emissions globally are similar by the early-2040s.

Note: Includes CO2 emissions from international aviation and shipping.

3 In the period to 2030, CO2 emissions in the NZE fall at a broadly similar rate to the P2 illustrative pathway in the IPCC SR 1.5 (IPCC, 2018). The P2 scenario is described as 'a scenario with … shifts towards sustainable and healthy  consumption  patterns,  low-carbon  technology  innovation,  and  well-managed  land  systems  with limited societal acceptability for BECCS [bioenergy with carbon capture and storage]'. After 2030, emissions in the NZE fall at a much faster pace than in the P2 scenario, which has 5.6 Gt CO2 of residual energy sector and industrial process CO2 emissions remaining in 2050.

2

Several emerging market and developing economies with a very large potential for producing renewables-based electricity and bioenergy are also a key source of carbon dioxide removal (CDR). This includes making use of renewable electricity sources to produce large quantities of biofuels with CCUS, some of which is exported, and to carry out direct air capture with carbon capture and storage (DACCS).

Per capita CO2 emissions in advanced economies drop from around 8 tCO2 per person in 2020 to around 3.5 tCO2 in 2030, a level close to the average in emerging market and developing economies  in  2020.  Per  capita  emissions  also  fall  in  emerging  market  and  developing economies, but from a much lower starting point. By the early 2040s, per capita emissions in both regions are broadly similar at around 0.5 tCO2 per person.

Cumulative global energy-related and industrial process CO2 emissions between 2020 and 2050  amount  to  just  over  460 Gt  in  the  NZE.  Assuming  parallel  action  to  address  CO2 emissions from agriculture, forestry and other land use (AFOLU) over the period to 2050 would result in around 40 Gt CO2 from AFOLU (see section 2.7.2). This means that total CO2 emissions from all sources - some 500 Gt CO2 - are in line with the CO2 budgets included in the  IPCC  SR1.5,  which  indicated  that  the  total  CO   budget  from  2020  consistent  with 2 providing a 50% chance of limiting warming to 1.5 °C is 500 Gt CO2 (IPCC, 2018).  As well as 4 reducing CO2 emissions to net-zero, the NZE seeks to reduce non-CO2 emissions from the energy sector. Methane emissions from fossil fuel production and use, for example, fall from 115 million tonnes (Mt) methane in 2020 (3.5 Gt CO2-equivalent [CO2-eq])  to 30 Mt in 2030 5 and 10 Mt in 2050.

The fastest and largest reductions in global emissions in the NZE are initially seen in the electricity sector (Figure 2.3). Electricity generation was the largest source of emissions in 2020, but emissions drop by nearly 60% in the period to 2030, mainly due to major reductions from coal-fired power plants, and the electricity sector becomes a small net negative source of emissions around 2040. Emissions from the buildings sector fall by 40% between 2020 and 2030 thanks to a shift away from the use of fossil fuel boilers, and retrofitting the existing building stock to improve its energy performance. Emissions from industry and transport both fall by around 20% over this period, and their pace of emissions reductions accelerates during the 2030s as the roll-out of low-emissions fuels and other emissions reduction options is scaled up. Nonetheless, there are a number of areas in transport and industry in which it is difficult to eliminate emissions entirely - such as aviation and heavy industry - and both sectors have a small level of residual emissions in 2050. These residual emissions are offset with applications of BECCS and DACCS.

4 This budget is based on Table 2.2 of the IPCC SR1.5 (IPCC, 2018). It assumes 0.53 °C additional warming from the 2006-2015 period to give a remaining CO2 budget from 2018 of 580 Gt CO2. There were around 80 Gt CO2 emissions emitted from 2018 to 2020.

5 Non-CO2 gases are converted to CO2-equivalents based on the 100-year global warming potentials reported by the IPCC 5th Assessment Report (IPCC, 2014). One tonne of methane is equivalent to 30 tonnes of CO2 .

Figure 2.3 ⊳ Global net-CO2 emissions by sector, and gross and net CO2 emissions in the NZE

<!-- image -->

IEA. All rights reserved.

Emissions from electricity fall fastest, with declines in industry and transport accelerating in the 2030s. Around 1.9 Gt CO2 are removed in 2050 via BECCS and DACCS.

Notes:  Other = agriculture,  fuel  production,  transformation  and  related  process  emissions,  and  direct  air capture. BECCS = bioenergy with carbon capture and storage; DACCS = direct air capture with carbon capture and storage. BECCS and DACCS includes CO2 emissions captured and permanently stored.

The  NZE  includes  a  systematic  preference  for  all  new  assets  and  infrastructure  to  be  as sustainable and efficient as possible, and this accounts for 50% of total emissions reductions in  2050.  Tackling  emissions  from  existing  infrastructure  accounts  for  another  35%  of reductions  in  2050,  while  behavioural  changes  and  avoided  demand,  including  materials efficiency   gains  and  modal  shifts  in  the  transport  sector,  provide  the  remaining  15%  of 6 emissions reductions (see section 2.5.2). A wide range of technologies and measures are deployed in the NZE to reduce emissions from existing infrastructure such as power plants, industrial facilities, buildings, networks, equipment and appliances. The NZE is designed to minimise  stranded  capital  where  possible,  i.e.  cases  where  the  initial  investment  is  not recouped, but in many cases early retirements or lower utilisation lead to stranded value, i.e. a reduction in revenue.

The rapid deployment of more energy-efficient technologies, electrification of end-uses and swift growth of renewables all play a central part in reducing emissions across all sectors in the NZE (Figure 2.4). By 2050, nearly 90% of all electricity generation is from renewables, as is around 25% of non-electric energy use in industry and buildings. There is also a major role for emerging fuels and technologies, notably hydrogen and hydrogen-based fuels, bioenergy and CCUS, especially in sectors where emissions are often most challenging to reduce.

6 Materials efficiency includes strategies that reduce material demand, or shift to the use of lower emissions materials or lower emissions production routes. Examples include lightweighting and recycling.

2

Figure 2.4 ⊳ Average annual CO2 reductions from 2020 in the NZE

<!-- image -->

IEA. All rights reserved.

Renewables and electrification make the largest contribution to emissions reductions, but a wide range of measures and technologies are needed to achieve net-zero emissions

Notes: Activity = changes in energy service demand from economic and population growth. Behaviour = change  in  energy  service  demand  from  user  decisions,  e.g.  changing  heating  temperatures. Avoided demand = change in energy service demand from technology developments, e.g. digitalisation.

## 2.4 Total energy supply and final energy consumption

## 2.4.1 Total energy supply 7

Total energy supply falls to 550 exajoules (EJ) in 2030, 7% lower than in 2020 (Figure 2.5). This occurs despite significant increases in the global population and economy because of a fall  in  energy  intensity  (the  amount  of  energy  used  to  generate  a  unit  of  GDP).  Energy intensity falls by 4% on average each year between 2020 and 2030. This is achieved through a  combination  of  electrification,  a  push  to  pursue  all  energy  and  materials  efficiency opportunities, behavioural changes that reduce demand for energy services, and a major shift  away  from  the  traditional  use  of  bioenergy.   This  level  of  improvement  in  energy 8 intensity is much greater than has been achieved in recent years: between 2010 and 2020, average annual energy intensity fell by less then 2% each year.

After  2030,  continuing  electrification  of  end-use  sectors  helps  to  reduce  energy  intensity further, but the emphasis on maximising energy efficiency improvements in the years up to

7 The terms total primary energy supply (TPES) or total primary energy demand (TPED) have been renamed as total  energy  supply  (TES)  in  accordance  with  the  International  Recommendations  for  Energy  Statistics (IEA, 2020a).

8 Modern forms of cooking require much less energy than the traditional use of biomass in inefficient stoves. For  example,  cooking  with  a  liquefied  petroleum  gas  stove  uses  around  five-times  less  energy  than  the traditional use of biomass.

2030 limits the available opportunities in later years. At the same time, increasing production of  new fuels,  such  as  advanced  biofuels,  hydrogen  and  synthetic  fuels,  tends  to  push  up energy use. As a result, the rate of decline in energy intensity between 2030 and 2050 slows to 2.7% per year. With continued economic and population growth, this means that total energy supply falls slightly between 2030 and 2040 but then remains broadly flat to 2050. Total energy supply in 2050 in the NZE is close to the level in 2010, despite a global population that is nearly 3 billion people higher and a global economy that is over three-times larger.

Figure 2.5 ⊳ Total energy supply in the NZE

<!-- image -->

Renewables and nuclear power displace most fossil fuel use in the NZE, and the share of fossil fuels falls from 80% in 2020 to just over 20% in 2050

The energy mix in 2050 in the NZE is much more diverse than today. In 2020, oil provided 30% of total energy supply, while coal supplied 26% and natural gas 23%. In 2050, renewables provide two-thirds of energy use, split between bioenergy, wind, solar, hydroelectricity and geothermal (Figure 2.6). There is also a large increase in energy supply from nuclear power, which nearly doubles between 2020 and 2050.

There are large reductions in the use of fossil fuels in the NZE. As a share of total energy supply, they fall from 80% in 2020 to just over 20% in 2050. However, their use does not fall to zero in 2050: significant amounts are still used in producing non-energy goods, in plants with  CCUS,  and  in  sectors  where  emissions  are  especially  hard  to  abate  such  as  heavy industry and long-distance transport. All remaining emissions in 2050 are offset by negative emissions elsewhere (Box 2.2). Coal use falls from 5 250 million tonnes of coal equivalent (Mtce) in 2020 to 2 500 Mtce in 2030 and to less than 600 Mtce in 2050 - an average annual decline of 7% each year from 2020 to 2050. Oil demand dropped below 90 million barrels per day (mb/d) in 2020 and demand does not return to its 2019 peak: it falls to 72 mb/d in 2030 and 24 mb/d in 2050 - an annual average decline of more than 4% from 2020 to 2050. Natural gas use dropped to 3 900 billion cubic metres (bcm) in 2020, but exceeds its previous

2

2019 peak in the mid-2020s before starting to decline as it is phased out in the electricity sector. Natural gas use declines to 3 700 bcm in 2030 and 1 750 bcm in 2050 - an annual average decline of just under 3% from 2020 to 2050.

Figure 2.6 ⊳ Total energy supply of unabated fossil fuels and low-emissions energy sources in the NZE

<!-- image -->

Some fossil fuels are still used in 2050 in the production of non-energy goods, in plants equipped with CCUS, and in sectors where emissions are hard to abate

Note: Low-emissions includes the use of fossil fuels with CCUS and in non-energy uses.

## Box 2.2 ⊳ Why does fossil fuel use not fall to zero in 2050 in the NZE?

In total, around 120 EJ of fossil fuels is consumed in 2050 in the NZE relative to 460 EJ in 2020. Three main reasons underlie why fossil fuel use does not fall to zero in 2050, even though the energy sector emits no CO2 on a net basis:

-  Use for non-energy purposes . More than 30% of total fossil fuel use in 2050 in the NZE - including 70% of oil use - is in applications where the fuels are not combusted and so do not result in any direct CO2 emissions (Figure 2.7). Examples include use as  chemical  feedstocks  and  in  lubricants,  paraffin  waxes  and  asphalt.  There  are major efforts to limit fossil fuel use in these applications in the NZE, for instance global plastic collection rates for recycling rising from 15% in 2020 to 55% in 2050, but fossil fuel use in non-energy applications still rises slightly to 2050.
-  Use with CCUS. Around half of fossil fuel use in 2050 is in plants equipped with CCUS (around  3.5 Gt CO2  emissions  are  captured  from  fossil  fuels  in  2050).  Around 925 bcm of natural gas is converted to hydrogen with CCUS. In addition, around 470 Mtce of coal and 225 bcm of natural gas are used with CCUS in the electricity and industrial sectors, mainly to extend the operations of young facilities and reduce stranded assets.

-  Use in sectors where technology options are scarce. The remaining 20% of fossil fuel use in 2050 in the NZE is in sectors where the complete elimination of emissions is  particularly  challenging.  Mostly  this  is  oil,  as  it  continues  to  fuel  aviation  in particular. A small amount of unabated coal and natural gas are used in industry and in  the  production  of  energy.  The  unabated  use  of  fossil  fuel  results  in  around 1.7 Gt CO2 emissions in 2050, which are fully offset by BECCS and DACCS.

Figure 2.7 ⊳ Fossil fuel use and share by sector in 2050 in the NZE

<!-- image -->

Notes:  Non-combustion  includes  use  for  non-emitting,  non-energy  purposes  such  as  petrochemical feedstocks, lubricants and asphalt. Energy production includes fuel use for direct air capture.

Solid, liquid and gaseous fuels continue to play an important role in the NZE, which sees large increases in bioenergy and hydrogen (Figure 2.8). Around 40% of bioenergy used today is for the traditional use of biomass in cooking: this is rapidly phased out in the NZE. Modern forms of solid biomass, which can be used to reduce emissions in both the electricity and industry sectors, rise from 32 EJ in 2020 to 55 EJ in 2030 and 75 EJ in 2050, offsetting a large portion of a drop in coal demand. The use of low-emissions liquid fuels, such as ammonia, synthetic fuels and liquid biofuels, increases from 3.5 EJ (1.6 million barrels of oil equivalent per day [mboe/d]) in 2020 to just above 25 EJ (12.5 mboe/d) in 2050. The supply of low-emissions gases, such as hydrogen, synthetic methane, biogas and biomethane rises from 2 EJ in 2020 to 17 EJ in 2030 and 50 EJ in 2050. The increase in gaseous hydrogen production between 2020  and  2030  in  the  NZE  is  twice  as  fast  as  the  fastest  ten-year  increase  in  shale  gas production in the United States.

2

Figure 2.8 ⊳ Solid, liquid and gaseous fuels in the NZE

<!-- image -->

Increases in low-emissions solids, liquids and gases from bioenergy, hydrogen and hydrogen-based fuels offset some of the declines in coal, oil and natural gas

Notes:  Hydrogen  conversion  losses  =  consumption  of  natural  gas  when  producing  low-carbon  merchant hydrogen using steam methane reforming. Hydrogen-based includes hydrogen, ammonia and synthetic fuels.

## 2.4.2 Total final consumption

Total final consumption worldwide rebounds marginally following its 5% drop in 2020, but it never returns to 2019 levels in the NZE (435 EJ). It falls by just under 1% each year on average between 2025 and 2050 to 340 EJ. Energy efficiency measures and electrification are the two main contributing factors, with behavioural changes and materials efficiency also playing a role.  Without  these  improvements,  final  energy  consumption  in  2050  would  be  around 640 EJ,  around  90%  higher  than  the  level  in  the  NZE.  Final  consumption  of  electricity increases by 25% from 2020 to 2030, and by 2050 it is more than double the level in 2020. The increase in electricity consumption from end-uses sectors and from hydrogen production means that overall annual electricity demand growth is equivalent to adding an electricity market the size of India every year in the NZE. The share of electricity in global final energy consumption jumps from 20% in 2020 to 26% in 2030 and to around 50% in 2050 (Figure 2.9). The direct use of renewables in buildings and industry together with low-emissions fuels such as bioenergy and hydrogen-based fuels provide a further 28% of final energy consumption in  2050;  fossil  fuels  comprise  the  remainder,  most  of  which  are  used  in  non-emitting processes or in facilities equipped with CCUS.

In industry, most of the global emissions reductions in the NZE during the period to 2030 are delivered through energy and materials efficiency improvements, electrification of heat, and fuel switching to solar thermal, geothermal and bioenergy. Thereafter, CCUS and hydrogen play an increasingly important role in reducing CO2 emissions, especially in heavy industries such as steel, cement and chemicals. Electricity consumption in industry more than doubles between 2020 and 2050, providing 45% of total industrial energy needs in 2050 (Figure 2.10).

The  demand  for  merchant  hydrogen  in  industry  increases  from  less  than  1 Mt  today  to around 40 Mt in 2050. A further 10% of industrial energy demand in 2050 is met by fossil fuels used in plants equipped with CCUS.

Figure 2.9 ⊳ Global total final consumption by fuel in the NZE

<!-- image -->

The share of electricity in final energy use jumps from 20% in 2020 to 50% in 2050

Note: Hydrogen-based includes hydrogen, ammonia and synthetic fuels.

In transport, there is a rapid transition away from oil worldwide, which provided more than 90% of fuel use in 2020. In road transport, electricity comes to dominate the sector, providing more than 60% of energy use in 2050, while hydrogen and hydrogen-based fuels play a smaller role, mainly in fuelling long-haul heavy-duty trucks. In shipping, energy efficiency improvements significantly  reduce  energy  needs  (especially  up  to  2030),  while  advanced biofuels and hydrogen-based fuels, such as ammonia, increasingly displace oil. In aviation, the use of synthetic liquids and advanced biofuels grows rapidly, and their share of total energy  demand  rises  from  almost  zero  today  to  almost  80%  in  2050.  Overall,  electricity becomes  the  dominant  fuel  in  the  transport  sector  globally  by  the  early  2040s,  and  it accounts for around 45% of energy consumption in the sector in 2050 (compared with 1.5% in  2020).  Hydrogen  and  hydrogen-based  fuels  account  for  nearly  30%  of  consumption (almost zero in 2020) and bioenergy for a further 15% (around 4% in 2020).

In buildings, the electrification of end-uses including heating leads to demand for electricity increasing by around 35% between 2020 and 2050: it becomes the dominant fuel, reaching 16 000 terawatt-hours (TWh) in 2050, and accounting for two-thirds of total buildings sector energy consumption. By 2050, two-thirds of residential buildings in advanced economies and around 40% of residential buildings in emerging market and developing economies are fitted with a heat pump. Onsite renewables-based energy systems such as solar water heaters and biomass boilers provide a further quarter of final energy use in the buildings sector in 2050 (up from 6% in 2020). Low-emissions district heating and hydrogen provide only 7% of energy use, but play a significant role in some regions.

2

Figure 2.10 ⊳ Global final energy consumption by sector and fuel in the NZE

<!-- image -->

IEA. All rights reserved.

There is a wholesale shift away from unabated fossil fuel use to electricity, renewables, hydrogen and hydrogen-based fuels, modern bioenergy and CCUS in end-use sectors

Note: Hydrogen-based includes hydrogen, ammonia and synthetic fuels.

Buildings energy consumption falls by 25% between 2020 and 2030, largely as a result of a major push to improve efficiency and to phase out the traditional use of solid biomass for cooking:  it  is  replaced  by  liquefied  petroleum  gas  (LPG),  biogas,  electric  cookers  and improved bioenergy stoves. Universal access to electricity is achieved by 2030, and this adds less than 1% to global electricity demand in 2030. Energy consumption in the buildings sector contracts by around 15% between 2030 and 2050 given continued efficiency improvements and  electrification.  By  2050,  energy  use  in  buildings  is  35%  lower  than  in  2020.  Energy efficiency  measures  -  including  improving  building  envelopes  and  ensuring  that  all  new appliances brought to market are the most efficient models available - play a key role in limiting  the  rise  in  electricity  demand  in  the  NZE.  Without  these  measures,  electricity demand in buildings would be around 10 000 TWh higher in 2050, or around 70% higher than the level in the NZE.

## S P O T L I G H T

## How does the NZE compare with similar 1.5 °C scenarios assessed by the IPCC?

The IPCC SR1.5 includes 90 individual scenarios that have at least a 50% chance of limiting warming in 2100 to 1.5 °C (IPCC, 2018).  Only 18 of these scenarios have net-zero CO2 9 energy sector and industrial process emissions in 2050. In other words, only one-in-five of the 1.5 °C scenarios assessed by the IPCC have the same level of emissions reduction

9 Includes 53 scenarios with no or limited temperature overshoot and 37 scenarios with a higher temperature overshoot.

ambition  for  the  energy  and  industrial  process  sectors  to  2050  as  the  NZE. 10 Some comparisons between these 18 scenarios and the NZE in 2050 (Figure 2.11):

Figure 2.11 ⊳ Comparison of selected indicators of the IPCC scenarios and the NZE in 2050

<!-- image -->

The NZE has the lowest level of energy-related CDR and bioenergy of any scenario that achieves net-zero energy sector and industrial process CO2 emissions in 2050

Notes: CCUS = carbon capture, utilisation and storage; CDR = carbon direct removal; TES = total energy supply; TFC = total final consumption. Energy-related CDR includes CO2 captured through bioenergy with CCUS and direct air capture with CCUS and put into permanent storage. Wind and solar share are given as a percentage of total electricity generation. Only 17 of the 18 scenarios assessed by the IPCC report hydrogen use in TFC.

-  Use of CCUS. The scenarios assessed by the IPCC have a median of around 15 Gt CO2 captured using CCUS in 2050, more than double the level in the NZE.
-  Use of CDR. CO2 emissions captured and stored from BECCS and DACCS in the IPCC scenarios range from 3.5-16 Gt CO2 in 2050, compared with 1.9 Gt CO2 in the NZE.

10 The low-energy demand scenario has around 4.5 Gt CO2 energy sector and industrial process emissions in 2050 and is not included in this comparison.

2

-  Bioenergy. The IPCC scenarios use a median of 200 EJ of primary bioenergy in 2050 (compared with 63 EJ today) and a number use more than 300 EJ. The NZE uses 100 EJ of primary bioenergy in 2050.
-  Energy  efficiency. Total  final  consumption  in  the  IPCC  scenarios  range  from 300-550 EJ in 2050 (compared with around 410 EJ in 2020). The NZE has final energy consumption of 340 EJ in 2050.
-  Hydrogen. The  IPCC  scenarios  have  a  median  of  18 EJ  hydrogen  in  total  final consumption in 2050, compared with 33 EJ in the NZE. 11
-  Electricity generation. The shares of wind and solar in total electricity generation in 2050 in the IPCC scenarios range from around 15-80% with a median value of 50%. In the NZE, wind and solar provide 70% of total generation in 2050.

## 2.5 Key pillars of decarbonisation

Achieving the rapid reduction in CO2 emissions over the next 30 years in the NZE requires a broad  range  of  policy  approaches  and  technologies  (Figure 2.12).  The  key  pillars  of decarbonisation  of  the  global  energy  system  are  energy  efficiency,  behavioural  changes, electrification, renewables, hydrogen and hydrogen-based fuels, bioenergy and CCUS.

Figure 2.12 ⊳ Emissions reductions by mitigation measure in the NZE, 2020-2050

<!-- image -->

IEA. All rights reserved.

Solar, wind and energy efficiency deliver around half of emissions reductions to 2030 in the NZE, while electrification, CCUS and hydrogen ramp up thereafter

Notes: Activity = energy service demand changes from economic and population growth. Behaviour = energy service demand changes from user decisions, e.g. changing heating temperatures. Avoided demand = energy service demand changes from technology developments, e.g. digitalisation. Other fuel shifts = switching from coal and oil to natural gas, nuclear, hydropower, geothermal, concentrating solar power or marine.

11 The  NZE  value  for  hydrogen  includes  the  total  energy  content  of  hydrogen  and  hydrogen-based  fuels consumed in final energy consumption.

## 2.5.1 Energy efficiency

Minimising  energy  demand  growth  through  improvements  in  energy  efficiency  makes  a critical contribution in the NZE. Many efficiency measures in industry, buildings, appliances and transport can be put into effect and scaled up very quickly. As a result, energy efficiency measures are front-loaded in the NZE, and they play their largest role in curbing energy demand and emissions in the period to 2030. Although energy efficiency improves further after 2030, its contribution to overall emissions reductions falls as other mitigation measures play an expanding role. Without the energy efficiency, behavioural changes and electrification measures deployed in the NZE, final energy consumption would be around 300 EJ higher in 2050, almost 90% above the 2050 level in the NZE (Figure 2.13). Efficiency improvements also help reduce the vulnerability of businesses and consumers to potential disruptions to electricity supplies.

Figure 2.13 ⊳ Total final consumption and demand avoided by mitigation measure in the NZE

<!-- image -->

Energy efficiency plays a key role in reducing energy consumption across end-use sectors

Notes: Other fuel switch includes switching to hydrogen-related fuels, bioenergy, solar thermal, geothermal, or district heat.

In the buildings sector, many efficiency measures yield financial savings as well as reducing energy  use  and  emissions.  In  the  NZE,  there  are  immediate  and  rapid  improvements  in energy efficiency in buildings, mainly from large-scale retrofit programmes. Around 2.5% of existing residential buildings in advanced economies are retrofitted each year to 2050 in the NZE to comply with zero-carbon-ready building standards 12 (compared with a current retrofit rate of less than 1%). In emerging market and developing economies, building replacement

12 A zero-carbon-ready building is highly energy efficient and uses either renewable energy directly or from an energy supply that will be fully decarbonised by 2050 in the NZE (such as electricity or district heat). A zerocarbon-ready building will become a zero-carbon building by 2050, without further changes to the building or its equipment (see Chapter 3).

2

rates are higher and the annual rate of retrofits is around 2% through to 2050. By 2050, the vast  majority  of  existing  residential  buildings  are  retrofitted  to  be  zero-carbon  buildings. Energy-related building codes are introduced in all regions by 2030 to ensure that virtually all new  buildings  constructed  are  zero-carbon-ready.  Minimum  energy  performance standards  and  replacement  schemes  for  low-efficiency  appliances  are  introduced  or strengthened in the 2020s in all countries. By the mid-2030s, nearly all household appliances sold worldwide are as efficient as the most efficient models available today.

In    the    transport    sector,    stringent    fuel-economy    standards    and    ensuring    no    new passenger cars running on internal combustion engines (ICEs) are sold globally from 2035 result in a rapid shift in vehicle sales toward much more efficient electric vehicles (EVs). 13 The impact on efficiency is seen in the 2030s, as the composition of the vehicle stock changes: electric cars make up 20% of all cars on the road in 2030 and 60% in 2040 (compared with 1% today). Continuous improvements in the fuel economy of heavy road vehicles take place through to 2050 as they switch to electricity or fuel cells, while efficiency in shipping and aviation improves as more efficient planes and ships replace existing stock.

In the industry sector, most manufacturing stock is already quite efficient, but there are still opportunities for energy efficiency improvements. Energy management systems, best-in-class industrial equipment such as electric motors, variable speed drives, heaters and grinders  are  installed,  and  process  integration  options  such  as  waste  heat  recovery  are exploited to their maximum economic potentials in the period to 2030 in the NZE. After 2030, the  rate  of  efficiency  improvement  slows  because  many  of  the  technologies  needed  to reduce  emissions  in  industry  in  the  NZE  require  more  energy  than  their  equivalent conventional technologies. The use of CCUS, for example, increases energy consumption to operate  the  capture  equipment,  and  producing  electrolytic  hydrogen  on-site  requires additional energy than that needed for the main manufacturing process.

Table 2.3 ⊳ Key global milestones for energy efficiency in the NZE

| Sector                                                                  | 2020    | 2030    | 2050    |
|-------------------------------------------------------------------------|---------|---------|---------|
| Total energy supply                                                     | 2010-20 | 2020-30 | 2030-50 |
| Annual energy intensity improvement (MJ per USD GDP)                    | -1.6%   | -4.2%   | -2.7%   |
| Industry                                                                |         |         |         |
| Energy intensity of direct reduced iron from natural gas (GJ per tonne) | 12      | 11      | 10      |
| Process energy intensity of primary chemicals (GJ per tonne)            | 17      | 16      | 15      |
| Transport                                                               |         |         |         |
| Average fuel consumption of ICE heavy trucks fleet (index 2020=100)     | 100     | 81      | 63      |
| Buildings                                                               |         |         |         |
| Share of zero-carbon-ready buildings in total stock                     | <1%     | 25%     | >85%    |
| New buildings: heating & cooling energy consumption (index 2020=100)    | 100     | 50      | 20      |
| Appliances: unit energy consumption (index 2020=100)                    | 100     | 75      | 60      |

Notes: ICE = internal combustion engine; zero-carbon-ready buildings = see description in section 3.7.

13 In 2020, the average battery electric car required around 30% of the energy of the average ICE car to provide the same level of activity.

## 2.5.2 Behavioural change

The wholescale transformation of the energy sector demonstrated in the NZE cannot be achieved without the active and willing participation of citizens. It is ultimately people who drive  demand  for  energy-related  goods  and  services,  and  societal  norms  and  personal choices will play a pivotal role in steering the energy system onto a sustainable path. Just under  40%  of  emissions  reductions  in  the  NZE  result  from  the  adoption  of  low-carbon technologies that require massive policy support and investment but little direct engagement from citizens or consumers, e.g. technologies in electricity generation or steel production. A further 55% of emissions reductions require a mixture of the deployment of low-carbon  technologies  and  the  active  involvement  or  engagement  of  citizens  and consumers,  e.g.  installing  a  solar  water  heater  or  buying  an  EV.  A  final  8%  of  emissions reductions stem from behavioural changes and materials efficiency gains that reduce energy demand, e.g. flying less for business purposes (Figure 2.14). Consumer attitudes can also impact investment decisions by businesses concerned about public image.

In the NZE, behavioural change refers to changes in ongoing or repeated behaviour on the part of consumers which impact energy service demand or the energy intensity of an energyrelated activity. 14 Reductions in energy service demand in the NZE also come from advances in technology, but these are not counted as behavioural changes. For example, increased digitalisation and a growing market share of smart appliances, such as smart thermostats or space-differentiated thermal controls reduce the necessity for people to play an active role in energy saving in homes over time in the NZE.

There are three main types of behavioural change included in the NZE. A wide range of government interventions could be used to motivate these changes (see section 2.7.1).

-  Reducing  excessive  or  wasteful  energy  use. This  includes  reducing  energy  use  in buildings and on roads, e.g. by reducing indoor temperature settings, adopting energy saving practices in homes and limiting driving speeds on motorways to 100 kilometres per hour.
-  Transport mode switching. This includes a shift to cycling, walking, ridesharing or taking buses  for  trips  in  cities  that  would  otherwise  be  made  by  car,  as  well  as  replacing regional air travel by high-speed rail in regions where this is feasible. Many of these types of behavioural changes would represent a break in familiar or habitual ways of life and as such would require a degree of public acceptance and even enthusiasm. Many would also require new infrastructure, such as cycle lanes and high-speed rail networks, clear policy support and high quality urban planning.
-  Materials efficiency gains. This includes reduced demand for materials, e.g. higher rates of recycling, and improved design and construction of buildings and vehicles. The scope for gains to some extent reflects societal preferences. For instance, in some places there

14 This means, for example, that purchasing an electric heat pump instead of a gas boiler is not considered as a  behavioural  change,  as  it  is  both  an  infrequent  event  and  does  not  necessarily  impact  energy  service demand.

2

has been a shift away from the use of single-use plastics in recent years, a trend that accelerates in the NZE. Gains in materials efficiency depend on a mixture of technical innovation in manufacturing and buildings construction, standards and regulations to support best-practice and ensure universal adoption of these innovations, and increased recycling in society at large.

Figure 2.14 ⊳ Role of technology and behavioural change in emissions reductions in the NZE

<!-- image -->

IEA. All rights reserved.

Around 8% of emissions reductions stem from behavioural changes and materials efficiency

Notes: Low-carbon technologies include low-carbon electricity generation, low-carbon gases in end-uses and biofuels. Low-carbon  technologies with the active involvement of citizens includes fuel switching, electrification  and  efficiency  gains  in  end-uses.  Behavioural  changes  and  materials  efficiency  includes transport mode switching, curbing excessive or wasteful energy use, and materials efficiency measures.

Three-quarters  of  the  emissions  reductions  from  behavioural  changes  in  the  NZE  are achieved through targeted government policies supported by infrastructure development, e.g.  a  shift  to  rail  travel  supported  by  high-speed  railways.  The  remainder  come  from adopting voluntary changes in energy saving habits, mainly in homes. Even in this case, public awareness campaigns can help shape day-to-day choices about how consumers use energy. (Details of what governments can do to help bring about behavioural changes are discussed in Chapter 4).

Behavioural changes reduce energy-related activity by around 10-15% on average over the period to 2050 in the NZE, reducing overall global energy demand by over 37 EJ in 2050 (Figure 2.15). In 2030, around 1.7 Gt CO2 emissions are avoided, 45% of which come from transport,  notably  through  measures  to  phase  out  car  use  in  cities  and  to  improve  fuel economy. For example, reducing speed limits on motorways to 100 km/h reduces emissions from road transport by 3% or 140 Mt CO2 in 2030. A shift away from single occupancy car use towards ridesharing or cycling and walking in large cities saves a further 185 Mt CO2. Around

40% of emissions savings in 2030 occur in industry because of improvements in materials efficiency and increased recycling, with the biggest impacts coming from reducing waste and improving the design and construction of buildings. The remainder of emissions savings in 2030 are from behavioural changes in buildings, for example adjusting space heating and cooling temperatures.

Figure 2.15 ⊳ CO2 emissions and energy demand reductions from behavioural changes and materials efficiency in the NZE

<!-- image -->

IEA. All rights reserved.

By 2030, behaviour changes and materials efficiency gains reduce emissions by 1.7 Gt CO2, and energy demand by 27 EJ; reductions increase further through to 2050

In  2050,  the  growing  importance  of  low-emissions  electricity  and  fuels  in  transport  and buildings means that 90% of emissions reductions are in industry, predominantly in those sectors where it is most challenging to tackle emissions directly. Material efficiency alone reduces demand for cement and steel by 20%, saving around 1 700 Mt CO2. Of the emissions reductions  in  transport  in  2050,  nearly  80%  come  from  measures  to  reduce  passenger aviation demand, with the remainder from road transport.

The scope, scale and speed of adoption of the behavioural changes in the NZE varies widely between regions, depending on several factors including the ability of existing infrastructure to support such changes and differences in geography, climate, urbanisation, social norms and cultural values. For example, regions with high levels of private car use today see a more gradual shift than others towards public transport, shared car use, walking and cycling; air travel is assumed to switch to high-speed rail on existing or potential routes only where trains could  offer  a  similar  journey  time;  and  the  potential  for  moderating  air  conditioning  in buildings and vehicles takes into account seasonal effects and humidity. Wealthier regions generally have higher levels of per capita energy-related activity, and behavioural changes play an especially important role in these regions in reducing excessive or wasteful energy consumption.

2

Most of the behavioural changes in the NZE would have some effect on nearly everyone's daily life, but none represents a radical departure from energy-reducing practices already experienced in many parts of the world today. For example, in Japan an awareness campaign has  successfully  reduced  cooling  demand  in  line  with  the  reductions  assumed  in  many regions in the NZE by 2040; legislation to limit urban car use has been introduced in many large cities; and speed limit reductions to around 100 km/h (the level adopted globally in the NZE by 2030) have been tested in the United Kingdom and Spain to reduce air pollution and improve safety.

Table 2.4 ⊳ Key global milestones for behavioural change in the NZE

| Sector    |   Year | Milestone                                                                                                                                                                |
|-----------|--------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Industry  |   2020 |  Global average plastics collection rate = 17%.                                                                                                                         |
| Industry  |   2030 |  Global average plastics collection rate = 27%.  Lightweighting reduces the weight of an average passenger car by 10%.                                                 |
| Industry  |   2050 |  Global average plastics collection rate = 54%.  Efficiency of fertiliser use improved by 10%.                                                                         |
| Transport |   2030 |  Eco-driving and motorway speed limits of 100 km/h introduced.  Use of ICE cars phased out in large cities.                                                            |
| Transport |   2050 |  Regional flights are shifted to high-speed rail where feasible.  Business and long-haul leisure air travel does not exceed 2019 levels.                               |
| Buildings |   2030 |  Space heating temperatures moderated to 19-20 °C on average.  Space cooling temperatures moderated to 24-25°C on average.  Excessive hot-water temperatures reduced. |
| Buildings |   2050 |  Use of energy-intensive materials per unit of floor area decreases by 30%.  Building lifetime extended by 20% on average.                                             |

Note: Eco-driving involves pre-emptive stopping and starting; ICE = internal combustion engine.

## 2.5.3 Electrification

The direct use of low-emissions electricity in place of fossil fuels is one of the most important drivers of emissions reductions in the NZE, accounting for around 20% of the total reduction achieved by 2050. Global electricity demand more than doubles between 2020 and 2050, with the largest absolute rise in electricity use in end-use sectors taking place in industry, which registers an increase of more than 11 000 TWh between 2020 and 2050. Much of this is  due  to  the  increasing  use  of  electricity  for  low-  and  medium-temperature  heat  and  in secondary scrap-based steel production (Figure 2.16).

In transport, the share of electricity increases from less than 2% in 2020 to around 45% in 2050  in  the  NZE.  More  than  60%  of  total  passenger  car  sales  globally  are  EVs  by  2030 (compared with 5% of sales in 2020), and the car fleet is almost fully electrified worldwide by 2050 (the remainder are hydrogen-powered cars). The increase in electric passenger car sales globally over the next ten years is over twenty-times higher than the increase in ICE car sales over the last decade. Electrification is slower for trucks because it depends on higher

density  batteries  than  those  currently  available  on  the  market,  especially  for  long-haul trucking,  and  on  new  high-power  charging  infrastructure:  electric  trucks  nevertheless account for around 25% of total heavy truck sales globally by 2030 and around two-thirds in 2050. The electrification of shipping and aviation is much more limited and only gets under way after large improvements in battery energy density (see section 3.6) (Figure 2.17). In the NZE, demand for batteries for transport reaches around 14 TWh in 2050, 90-times more than in 2020. Growth in battery demand translates into an increasing demand for critical minerals. For example, demand for lithium for use in batteries grows 30-fold to 2030 and is more than 100-times higher in 2050 than in 2020 (IEA, 2021).

Figure 2.16 ⊳ Global electricity demand and share of electricity in energy consumption in selected applications in the NZE

<!-- image -->

Global electricity demand more than doubles in the period to 2050, with the largest rises to produce hydrogen and in industry

Notes: Merchant hydrogen = hydrogen produced by one company to sell to others. Light-duty vehicles = passenger cars and vans. Heavy trucks = medium-freight trucks and heavy-freight trucks.

In  buildings,  electricity  demand  is  moderated  in  the  NZE  by  a  huge  push  to  improve  the efficiency  of  appliances,  cooling,  lighting  and  building  envelopes.  But  a  large  increase  in activity, along with the widespread electrification of heating through the use of heat pumps, means that electricity demand in buildings still rises steadily over the period reaching 66% of total energy consumption in buildings in 2050.

Alongside the growth in the direct use of electricity in end-use sectors, there is also a huge increase  in  the  use  of  electricity  for  hydrogen  production.  Merchant  hydrogen  produced using  electrolysis  requires  around  12 000 TWh  in  2050  in  the  NZE,  which  is  greater  than current total annual electricity demand of China and the United States combined.

2

Figure 2.17 ⊳ Battery demand growth in transport and battery energy density in the NZE

<!-- image -->

Nearly 20 battery giga-factories open every year to 2030 to satisfy battery demand for electric cars in the NZE; higher density batteries are needed to electrify long-haul trucks

Notes: Li-S = lithium-sulphur battery; Wh per kg = Watt hours per kilogramme.

The acceleration of electricity demand growth from 2% per year over the past decade to 3% per year through to 2050, together with a significantly increased share of variable renewable electricity generation, means that annual electricity sector investment in the NZE is threetimes higher on average than in recent years. The rise in electricity demand also calls for extensive  efforts  to  ensure  the  stability  and  flexibility  of  electricity  supply  through demand-side management, the operation of flexible low-emissions sources of generation including hydropower and bioenergy, and battery storage.

Table 2.5 ⊳ Key global milestones for electrification in the NZE

| Sector                                               | 2020   | 2030   | 2050   |
|------------------------------------------------------|--------|--------|--------|
| Share of electricity in total final consumption      | 20%    | 26%    | 49%    |
| Industry                                             |        |        |        |
| Share of steel production using electric arc furnace | 24%    | 37%    | 53%    |
| Electricity share of light industry                  | 43%    | 53%    | 76%    |
| Transport                                            |        |        |        |
| Share of electric vehicles in stock: cars            | 1%     | 20%    | 86%    |
| two/three-wheelers                                   | 26%    | 54%    | 100%   |
| bus                                                  | 2%     | 23%    | 79%    |
| vans                                                 | 0%     | 22%    | 84%    |
| heavy trucks                                         | 0%     | 8%     | 59%    |
| Annual battery demand for electric vehicles (TWh)    | 0.16   | 6.6    | 14     |
| Buildings                                            |        |        |        |
| Heat pumps installed (millions)                      | 180    | 600    | 1 800  |
| Share of heat pumps in energy demand for heating     | 7%     | 20%    | 55%    |
| Million people without access to electricity         | 786    | 0      | 0      |

## 2.5.4 Renewables

At  a  global  level,  renewable  energy  technologies  are  the  key  to  reducing  emissions  from electricity supply. Hydropower has been a leading low-emission source for many decades, but it is mainly the expansion of wind and solar that triples renewables generation by 2030 and increases it more than eightfold by 2050 in the NZE. The share of renewables in total electricity generation globally increases from 29% in 2020 to over 60% in 2030 and to nearly 90%  in  2050  (Figure 2.18).  To  achieve  this,  annual  capacity  additions  of  wind  and  solar between 2020 and 2050 are five-times higher than the average over the last three years. Dispatchable  renewables  are  critical  to  maintain  electricity  security,  together  with  other low-carbon generation, energy storage and robust electricity networks. In the NZE, the main dispatchable renewables globally in 2050 are hydropower (12% of generation), bioenergy (5%), concentrating solar power (2%) and geothermal (1%).

Figure 2.18 ⊳ Fuel shares in total energy use in selected applications in the NZE

<!-- image -->

Renewables are central to emissions reductions in electricity, and they make major contributions to cut emissions in buildings, industry and transport both directly and indirectly

Notes: Indirect renewables = use of electricity and district heat produced by renewables. Other low-carbon = nuclear power, facilities equipped with CCUS, and low-carbon hydrogen and hydrogen-based fuels.

2

Renewables also  play  an  important  role  in  reducing  emissions  in  buildings,  industry  and transport. Renewables can be used either indirectly, via the consumption of electricity or district heating that was produced by renewables, or directly, mainly to produce heat.

In transport, renewables play an important indirect role in reducing emissions by generating the electricity to power electric vehicles. They also contribute to direct emissions reductions through the use of liquid biofuels and biomethane.

In buildings, renewable energy is mainly used for water and space heating. The direct use of renewable energy rises from about 10% of heating demand globally in 2020 to 40% in 2050, about three-quarters of the increase is in the form of solar thermal and geothermal. Deep retrofits and energy-related building codes are paired with renewables whenever possible: almost all buildings with available roof space and sufficient solar insolation are equipped with solar thermal water heaters by 2050, as they are more productive per square metre than solar PV and as heat storage in water tanks is generally more cost-effective than storage of electricity.  Rooftop  solar  PV,  which  produces  renewable  electricity  onsite,  is  currently installed  on  around  25 million  rooftops  worldwide;  the  number  increases  to  100 million rooftops by 2030 and 240 million by 2050. A further 15% of heating in buildings in 2030 comes indirectly from renewables in the form of electricity, and this rises to almost 40% in 2050.

In industry, bioenergy is the most important direct renewable energy source for low- and medium-temperature needs in the NZE. Solar thermal and geothermal also produce low temperature heat for use in non-energy-intensive industries and ancillary or downstream processes in heavy industries. Bioenergy, solar thermal and geothermal together provide about 15% of industry heat demand in 2030, roughly double their share in 2010, and this increases to 40% in 2050. The indirect use of renewable energy via electricity adds 15% to the contribution that renewables make to total industry energy use in 2050.

Table 2.6 ⊳ Key deployment milestones for renewables

| Sector                                                              | 2020   | 2030   | 2050   |
|---------------------------------------------------------------------|--------|--------|--------|
| Electricity sector                                                  |        |        |        |
| Renewables share in generation                                      | 29%    | 61%    | 88%    |
| Annual capacity additions (GW): Total solar PV                      | 134    | 630    | 630    |
| Total wind                                                          | 114    | 390    | 350    |
| - of which: Offshore wind                                           | 5      | 80     | 70     |
| Dispatchable renewables                                             | 31     | 120    | 90     |
| End-uses sectors                                                    |        |        |        |
| Renewable share in TFC                                              | 5%     | 12%    | 19%    |
| Households with rooftop solar PV (million)                          | 25     | 100    | 240    |
| Share of solar thermal and geothermal in buildings                  | 2%     | 5%     | 12%    |
| Share of solar thermal and geothermal in industry final consumption | 0%     | 1%     | 2%     |

Note: TFC = total final consumption.

## 2.5.5 Hydrogen and hydrogen-based fuels

The initial focus for hydrogen use in the NZE is the conversion of existing uses of fossil energy to  low-carbon  hydrogen  in  ways  that  do  not  immediately  require  new  transmission  and distribution infrastructure. This includes hydrogen use in industry and in refineries and power plants, and the blending of hydrogen into natural gas for distribution to end-users.

Global hydrogen use expands from less than 90 Mt in 2020 to more than 200 Mt in 2030; the proportion of low-carbon hydrogen rises from 10% in 2020 to 70% in 2030 (Figure 2.19). Around half of low-carbon hydrogen produced globally in 2030 comes from electrolysis and the remainder from coal and natural gas with CCUS, although this ratio varies substantially between regions.  Hydrogen  is  also  blended  with  natural  gas  in  gas  networks:  the  global average blend in 2030 includes 15% of hydrogen in volumetric terms, reducing CO2 emissions from gas consumption by around 6%.

Figure 2.19 ⊳ Global hydrogen and hydrogen-based fuel use in the NZE

<!-- image -->

IEA. All rights reserved.

The initial focus for hydrogen is to convert existing uses to low-carbon hydrogen; hydrogen and hydrogen-based fuels then expand across all end-uses

Note: Includes hydrogen and hydrogen contained in ammonia and synthetic fuels.

These developments facilitate a rapid scaling up of electrolyser manufacturing capacity and the parallel development of new hydrogen transport infrastructure. This leads to rapid cost reductions  for  electrolysers  and  for  hydrogen  storage,  notably  in  salt  caverns.  Stored hydrogen  is  used  to  help  balance  both  seasonal  fluctuations  in  electricity  demand  and imbalances  that  may  arise  between  the  demand  for  hydrogen  and  its  supply  by  off-grid renewable systems. During the 2020s, there is also a large increase in the installation of end-use equipment for hydrogen, including more than 15 million hydrogen fuel cell vehicles on the road by 2030.

2

After  2030,  low-carbon  hydrogen  use  expands  rapidly  in  all  sectors  in  the  NZE.  In  the electricity  sector,  hydrogen  and  hydrogen-based  fuels  provide  an  important  low-carbon source of electricity system flexibility, mainly through retrofitting existing gas-fired capacity to co-fire with hydrogen, together with some retrofitting of coal-fired power plants to co-fire with ammonia. Although these fuels provide only around 2% of overall electricity generation in 2050, this translates into very large volumes of hydrogen and makes the electricity sector an important driver of hydrogen demand. In transport, hydrogen provides around one-third of fuel use in trucks in 2050 in the NZE: this is contingent on policy makers taking decisions that enable the development of the necessary infrastructure by 2030. By 2050, hydrogen-based fuels also provide more than 60% of total fuel consumption in shipping.

Of  the  530 Mt  of  hydrogen  produced  in  2050,  around  25%  is  produced  within  industrial facilities (including refineries), and the remainder is merchant hydrogen (hydrogen produced by one company to sell to others). Almost 30% of the low-carbon hydrogen used in 2050 takes the form of hydrogen-based fuels, which include ammonia and synthetic liquids and gases. An increasing share of hydrogen production comes from electrolysers, which account for 60% of total production in 2050. Electrolysers are powered by grid electricity, dedicated renewables in regions with excellent  renewable  resources  and  other  low-carbon  sources such as nuclear power. Rolling out electrolysers at the pace required in the NZE is a key challenge given the lack of manufacturing capacity today, as is ensuring the availability of sufficient electricity generation capacity. Global trade in hydrogen develops over time in the NZE, with large volumes exported from gas and renewables-rich areas in the Middle East, Central and South America and Australia to demand centres in Asia and Europe.

Table 2.7 ⊳ Key deployment milestones for hydrogen and hydrogen-based fuels

| Sector                                      | 2020   | 2030   | 2050   |
|---------------------------------------------|--------|--------|--------|
| Total production hydrogen-based fuels (Mt)  | 87     | 212    | 528    |
| Low-carbon hydrogen production              | 9      | 150    | 520    |
| share of fossil-based with CCUS             | 95%    | 46%    | 38%    |
| share of electrolysis-based                 | 5%     | 54%    | 62%    |
| Merchant production                         | 15     | 127    | 414    |
| Onsite production                           | 73     | 85     | 114    |
| Total consumption hydrogen-based fuels (Mt) | 87     | 212    | 528    |
| Electricity                                 | 0      | 52     | 102    |
| of which hydrogen                           | 0      | 43     | 88     |
| of which ammonia                            | 0      | 8      | 13     |
| Refineries                                  | 36     | 25     | 8      |
| Buildings and agriculture                   | 0      | 17     | 23     |
| Transport                                   | 0      | 25     | 207    |
| of which hydrogen                           | 0      | 11     | 106    |
| of which ammonia                            | 0      | 8      | 44     |
| of which synthetic fuels                    | 0      | 5      | 56     |
| Industry                                    | 51     | 93     | 187    |

Note: Hydrogen-based fuels are reported in million tonnes of hydrogen required to produce them.

## 2.5.6 Bioenergy

Global primary demand for bioenergy was almost 65 EJ in 2020, of which about 90% was solid biomass. Some 40% of the solid biomass was used in traditional cooking methods which is unsustainable, inefficient and polluting, and was linked to 2.5 million premature deaths in 2020. The use of solid biomass in this manner falls to zero by 2030 in the NZE, to achieve the UN Sustainable Development Goal 7. Increases in all forms of modern bioenergy more than offset  this, with  production  rising  from  less  than  40 EJ  in  2020  to  around  100 EJ  in  2050 (Figure 2.20). 15 All bioenergy in 2050 comes from sustainable sources and the figures in the NZE  for  total  bioenergy  use  are  well  below  estimates  of  global  sustainable  bioenergy potential, thus avoiding the risk of negative impacts on biodiversity, fresh water systems, and food prices and availability (see section 2.7.2).

Figure 2.20 ⊳ Total bioenergy supply in the NZE

<!-- image -->

IEA. All rights reserved.

Modern bioenergy use rises to 100 EJ in 2050, meeting almost 20% of total energy needs. Global demand in 2050 is well below the assessed sustainable potential

Notes: TES = Total energy supply. Conversion losses occur during the production of biofuels and biogases.

Modern solid bioenergy use rises by about 3% each year on average to 2050. In the electricity sector, where demand reaches 35 EJ in 2050, solid bioenergy provides flexible low-emissions generation to complement generation from solar PV and wind, and it removes CO2 from the atmosphere when equipped with CCUS. In 2050, electricity generation using bioenergy fuels reaches 3 300 TWh, or 5% of total generation. Bioenergy also provides around 50% of district heat production. In industry, where demand reaches 20 EJ in 2050, solid bioenergy provides high temperature heat and can be co-fired with coal to reduce the emissions intensity of

15 Modern bioenergy includes biogases, liquid biofuels and modern solid biomass harvested from sustainable sources. It excludes the traditional use of biomass.

2

existing generation assets. Demand is highest for paper and cement production: in 2050, bioenergy meets 60% of energy demand in the paper sector and 30% of energy demand for cement production. Modern solid bioenergy demand in buildings increases to nearly 10 EJ in 2030, most of it for use in improved cookstoves as unsustainable traditional uses of biomass disappear.  Bioenergy  is  also  increasingly  used  for  space  and  water  heating  in  advanced economies.

Household and village biogas digesters in rural areas provide a source of renewable energy and clean cooking for nearly 500 million households by 2030 in the NZE and total biogas use rises  to  5.5 EJ  in  2050  (from  under  2 EJ  in  2020). 16 Biomethane demand grows to 8.5 EJ, thanks to blending mandates for gas networks, with average blending rates increasing to above 80% in many regions by 2050. Half of total biomethane use is in the industry sector, where  biomethane  replaces  natural  gas  as  a  source  of  process  heat.  The  buildings  and transport  sectors  each  account  for  around  a  further  20%  of  biomethane  consumption  in 2050.

One of the key advantages of bioenergy is that it can use existing infrastructure. For example, biomethane can  use  existing  natural  gas  pipelines  and  end-user  equipment,  while  many drop-in liquid biofuels can use existing oil distribution networks and be used in vehicles with only  minor  or  limited  alterations.  BioLPG  -  LPG  derived  from  renewable  feedstocks  -  is identical  to  conventional  LPG  and  so  can  be  blended  and  distributed  in  the  same  way. Sustainable bioenergy also provides a valuable source of employment and income for rural communities, reduces undue burdens on women often tasked with fuel collection, brings health  benefits  from  reduced  air  pollution  and  proper  waste  management,  and  reduces methane emissions from inefficient combustion and the decomposition of waste.

Liquid biofuel consumption rises from 1.6 mboe/d in 2020 to 6 mboe/d in 2030 in the NZE, mainly  used  in  road  transport.  After  2030,  liquid  biofuels  grow  more  slowly  to  around 7 mboe/d in 2050 and their use shifts to  shipping  and  aviation  as  electricity  increasingly dominates road transport. Almost half of liquid biofuel use in 2050 is for aviation, where biokerosene accounts for around 45% of total fuel use in aircraft.

Bioenergy  with  carbon  capture  and  storage  (BECCS)  plays  a  critical  role  in  the  NZE  in offsetting emissions from sectors where the full elimination of emissions is very difficult to achieve. In 2050, around 10% of total bioenergy is used in facilities equipped with CCUS and around 1.3 Gt CO2 is captured using BECCS. Around 45% of this CO2 is captured in biofuels production,  40%  in  the  electricity  sector  and  the  rest  in  heavy  industry,  notably  cement production.

16 Biogas is a mixture of methane, CO2 and small quantities of other gases produced by anaerobic digestion of organic matter in an oxygen free environment. Biomethane is a near pure source of methane produced either by removing CO2 and other contaminants from biogas or through the gasification of solid biomass (IEA, 2020b).

Table 2.8 ⊳ Key deployment milestones for bioenergy

|                                                      | 2020   | 2030   | 2050   |
|------------------------------------------------------|--------|--------|--------|
| Total energy supply (EJ)                             | 63     | 72     | 102    |
| Share of advanced biomass feedstock                  | 27%    | 85%    | 97%    |
| Modern gaseous bioenergy (EJ)                        | 2.1    | 5.4    | 13.7   |
| Biomethane                                           | 0.3    | 2.3    | 8.3    |
| Modern liquid bioenergy (mboe/d)                     | 1.6    | 6.0    | 7.0    |
| Advanced biofuels                                    | 0.1    | 2.7    | 6.2    |
| Modern solid bioenergy (EJ)                          | 32     | 54     | 74     |
| Traditional use of solid biomass (EJ)                | 25     | 0      | 0      |
| Million people using traditional biomass for cooking | 2 340  | 0      | 0      |

Notes:  mboe/d  =  million  barrels  of  oil  equivalent  per  day.  Bioenergy  from  forest  plantings  is  considered advanced when forests are sustainably managed (see section 2.7.2).

## 2.5.7 Carbon capture, utilisation and storage

CCUS  can  facilitate  the  transition  to  net-zero  CO   emissions  by:  tackling  emissions  from 2 existing assets; providing a way to address emissions from some of the most challenging sectors;  providing  a  cost-effective  pathway  to  scale  up  low-carbon  hydrogen  production rapidly; and allowing for CO2 removal from the atmosphere through BECCS and DACCS.

In the NZE, policies support a range of measures to establish markets for CCUS investment and to encourage use of shared CO2 transport and storage infrastructure by those involved in the production of hydrogen and biofuels, the operation of industrial hubs, and retrofitting of existing coal-fired power plants. Capture volumes in the NZE increase marginally over the next  five  years  from  the  current  level  of  around  40  Mt  CO   per  year,  reflecting  projects 2 currently under development, but there is a rapid expansion over the following 25 years as policy action bears fruit. By 2030, 1.6 Gt CO2 per year is captured globally, rising to 7.6 Gt CO 2 in  2050  (Figure 2.21).  Around  95%  of  total  CO   captured  in  2050  is  stored  in  permanent 2 geological storage and 5% is used to provide synthetic fuels. Estimates of global geological storage  capacity  are  considerably  above  what  is  necessary  to  store  the  cumulative  CO2 captured and stored in the NZE. A total of 2.4 Gt CO2 is captured in 2050 from the atmosphere through  bioenergy  with  CO2  capture  and  direct  air  capture,  of  which  1.9 Gt CO2 is permanently stored and 0.5 Gt CO2 is used to provide synthetic fuels in particular for aviation.

Energy-related and process CO2 emissions in industry account for almost 40% of the CO2 captured  in  2050  in  the  NZE.  CCUS  is  particularly  important  for  cement  manufacturing. Although efforts are pursued in the NZE to produce cement more efficiently, CCUS remains central to efforts to limit the process emissions that occur during cement manufacturing. The electricity sector accounts for almost 20% of the CO2 captured in 2050 (of which around 45% is  from  coal-fired  plants,  40%  from  bioenergy  plants  and  15%  from  gas-fired  plants). CCUS-equipped power plants contribute just 3% of total electricity generation in 2050 but the volumes of CO2 captured are comparatively large. In emerging market and developing economies, where large numbers of coal power plants have been built relatively recently,

2

retrofits  play  an  important  role  where  there  are  storage  opportunities.  In  advanced economies, gas-fired plants with CCUS play a bigger role, providing dispatchable electricity at relatively low cost in regions with cheap natural gas and existing networks. In 2030, around 50 GW of coal-fired power plants (4% of the total at that time) and 30 GW of natural gas power plants (1% of the total) are equipped with CCUS, and this rises to 220 GW of coal (almost half of the total) and 170 GW of natural gas (7% of the total) capacity in 2050. A further 30% of CO2 captured in 2050 comes from fuel transformation, including hydrogen and biofuels production as well as oil refining. The remaining 10% is from DAC, which is rapidly scaled up from several of pilot projects today to 90 Mt CO2 per year in 2030 and just under 1 Gt CO2 per year by 2050.

Figure 2.21 ⊳ Global CO2 capture by source in the NZE

<!-- image -->

IEA. All rights reserved.

By 2050, 7.6 Gt of CO2 is captured per year from a diverse range of sources. A total of 2.4 Gt CO2 is captured from bioenergy use and DAC, of which 1.9 Gt CO2 is permanently stored.

Table 2.9 ⊳ Key global milestones for CCUS

|                                               |   2020 | 2030   | 2050   |
|-----------------------------------------------|--------|--------|--------|
| Total CO 2 captured (Mt CO 2 )                |     40 | 1 670  | 7 600  |
| CO 2 captured from fossil fuels and processes |     39 | 1 325  | 5 245  |
| Power                                         |      3 | 340    | 860    |
| Industry                                      |      3 | 360    | 2 620  |
| Merchant hydrogen production                  |      3 | 455    | 1 355  |
| Non-biofuels production                       |     30 | 170    | 410    |
| CO 2 captured from bioenergy                  |      1 | 255    | 1 380  |
| Power                                         |      0 | 90     | 570    |
| Industry                                      |      0 | 15     | 180    |
| Biofuels production                           |      1 | 150    | 625    |
| Direct air capture                            |      0 | 90     | 985    |
| Removal                                       |      0 | 70     | 630    |

## 2.6 Investment

The radical transformation of the global energy system required to achieve net-zero CO2 emissions in 2050 hinges on a big expansion in investment and a big shift in what capital is spent on. The NZE expands annual investment in energy from just over USD 2 trillion globally on average over the last five years to almost USD 5 trillion by 2030 and to USD 4.5 trillion by 2050 (Figure 2.22). 17 Total annual capital investment in energy in the NZE rises from around 2.5% of global GDP in recent years to about 4.5% in 2030 before falling back to 2.5% by 2050.

Figure 2.22 ⊳ Annual average capital investment in the NZE

<!-- image -->

Capital investment in energy rises from 2.5% of GDP in recent years to 4.5% by 2030; the majority is spent on electricity generation, networks and electric end-user equipment

Notes: Infrastructure includes electricity networks, public EV charging, CO2 pipelines and storage facilities, direct air  capture  and storage facilities, hydrogen refuelling  stations, and import and  export terminals for hydrogen, fossil  fuels  pipelines  and  terminals.  End-use  efficiency  investments  are  the  incremental  cost  of improving the energy performance of equipment relative to a conventional design. Electricity systems include electricity generation, storage and distribution, and public EV charging. Electrification investments include spending  in  batteries  for  vehicles,  heat  pumps  and  industrial  equipment  for  electricity-based  material production routes.

The shift in what capital is spent on leads to annual investment in electricity generation rising from just over USD 500 billion over the last five years to more than USD 1 600 billion in 2030, before falling back as the cost of renewable energy technologies continues to decline. Annual nuclear investment rises too: it more than doubles by 2050 compared with current levels. Annual investment in fuel supply however drops from about USD 575 billion on average over

17 Investment  levels  presented  in  this  report  include  a  broader  accounting  of  efficiency  improvements  in buildings than reported in the IEA World Energy Investment (IEA, 2020c) and so differ from the numbers presented there.

2

the last half-decade to USD 315 billion in 2030 and USD 110 billion in 2050. The share of fossil fuel supply in total energy sector investment drops from its 25% level in recent years to just 7% by 2050: this is partly offset by the rise in spending on low-emissions fuel supply, such as hydrogen, hydrogen-based fuels and bioenergy. Annual investment in these fuels increases to nearly USD 140 billion in 2050. Investment in transport increases significantly in the NZE from USD 150 per year in recent years to more than USD 1 100 billion in 2050: this stems mainly from the upfront cost of electric cars compared with conventional vehicles despite the decline in the cost of batteries.

By technology area, electrification is the dominant focus in the NZE. In addition to more investment in electricity generation, there is a huge increase in investment in expansion and modernisation  of  electricity  networks.  Annual  investment  rises  from  USD 260 billion  on average in recent years to around USD 800 billion in 2030 and remains about that level to 2050. Such investment is needed to ensure electricity security in the face of rising electricity demand and the proportion of variable generation in the power mix. There is also a large increase in investment in the electrification of end-use sectors, which includes spending on EV  batteries,  heat  pumps  and  electricity-based  industrial  equipment.  In  addition  to investment in electrification, there is a moderate increase in investment in hydrogen to 2030 as production facilities are scaled up, and larger increases after as hydrogen use in transport expands: annual investment in hydrogen, including production facilities, refuelling stations and end-user equipment, reaches USD 165 billion in 2030 and over USD 470 billion in 2050. There  is  also  an  increase  in  global  investment  in  CCUS  (annual  investment  exceeds USD 160 billion by 2050 and in efficiency (around USD 640 billion annual investment by 2050, mostly  for  deep  building  retrofits  and  efficient  appliances  in  the  industry  and  buildings sectors).

Financing the investment needed in the NZE involves redirecting existing capital towards clean  energy  technologies  and  substantially  increasing  the  overall  level  of  investment  in energy. Most of this increase in investment comes from private sources, mobilised by public policies that create incentives, set appropriate regulatory frameworks and reform energy taxes. However, direct government financing is also needed to boost the development of new  infrastructure  projects  and  to  accelerate  innovation  in  technologies  that  are  in  the demonstration or prototype phase today. Projects in many emerging market and developing economies  are  often  relatively  reliant  on  public  financing,  and  policies  that  ensure  a predictable flow of bankable projects have an important role in boosting private investment in these economies, as does the scaling up of concessional debt financing and the use of development finance. There are extensive cross-country co-operation efforts in the NZE to facilitate the international flow of capital.

The  large  increase  in  capital  investment  in  the  NZE  is  partly  compensated  for  by  lower operating expenditure. Operating costs account today for a large share of the total cost of upstream fuel supply projects and fossil fuel generation projects: the clean technologies that play an increasing role in the NZE are characterised by much lower operating costs.

## 2.7 Key uncertainties

The  road  to  net-zero  emissions  is  uncertain  for  many  reasons:  we  cannot  be  sure  how underlying  economic  conditions  will  change,  which  policies  will  be  most  effective,  how people and businesses will respond to market and policy signals, or how technologies and their costs will evolve from within or outside the energy sector. The NZE therefore is just one possible  pathway  to  achieve  net-zero  emissions  by  2050.  Against  this  background,  this section looks at what the implications would be if the assumptions in the NZE turn out to be off the mark with respect to behavioural change, bioenergy and CCUS for fossil fuels. These three areas were selected because the assumptions made about them involve a high degree of uncertainty and because of their critical contributions to achieve net-zero emissions by 2050.

Figure 2.23 ⊳ Additional electricity demand in 2050 and additional investment between 2021-2050 for selected areas of uncertainty

<!-- image -->

IEA. All rights reserved.

The absence of behaviour change, restrictions on bioenergy use and failure to develop fossil fuel CCUS would each raise investment to meet net-zero emissions by USD 4-15 trillion

Notes: No behaviour assumes none of the behavioural changes included in the NZE. Restricted bioenergy assumes no increase in land use for bioenergy production. Low fossil CCUS assumes no increase in fossil fuelbased CCUS apart from projects already approved or under construction.

Our analysis clearly highlights that more pessimistic assumptions would add considerably to both the costs and difficulty of achieving net-zero emissions by 2050 (Figure 2.23).

-  Behavioural changes are important in reducing energy demand in transport, buildings and  industry.  If  the  changes  in  behaviour  assumed  in  the  NZE  were  not  attainable, emissions would be around 2.6 Gt CO2 higher in 2050. Avoiding these emissions through the  use  of  additional  low-carbon  electricity  and  hydrogen  would  cost  an  additional USD 4 trillion.

2

-  Bioenergy use grows by 60% between 2020 and 2050 in the NZE and land use for its propagation increases by around 25%. Bioenergy use in 2050 in the NZE is well below current  best  estimates  of  global  sustainable  bioenergy  potential,  but  there  is  a  high degree of uncertainty concerning this level. If land use for bioenergy remains at today's level,  bioenergy  use  in  2050  would  be  around  10%  lower,  and  achieving  net-zero emissions in 2050 would require USD 4.5 trillion extra investment.
-  A failure to develop CCUS for fossil fuels would substantially increase the risk of stranded assets and would require around USD 15 trillion of additional investment in wind, solar and electrolyser capacity to achieve the same level of emissions reductions. It could also critically delay progress on BECCS and DACCS: if these cannot be deployed at scale, then achieving net-zero emissions by 2050 would be very much harder.

## 2.7.1 Behavioural change

## Impact of behavioural changes in selected sectors in the NZE

Changes  in  the  behaviour  of  energy  consumers  play  an  important  role  in  cutting  CO2 emissions and energy demand growth in the NZE. Behavioural changes reduce global energy demand by 37 EJ in 2050, a 10% reduction in energy demand at that time, and without them cumulative emissions between 2021 and 2050 would be around 10% higher (Figure 2.24). Behavioural change plays a particularly important role in the transport sector.

Figure 2.24 ⊳ Reduction in total final consumption due to behavioural changes by fuel in the NZE

<!-- image -->

The impact of behaviour changes and materials efficiency on final energy consumption increases over time

Note: Other includes coal, hydrogen, geothermal, solar thermal, synthetic oil and synthetic gas.

Passenger aviation. Demand would grow more than threefold globally between 2020 and 2050 in the absence of the assumed changes in behaviour in the NZE. About 60% of this

growth  would  occur  in  emerging  market  and  developing  economies.  In  the  NZE,  three changes lead to a 50%  reduction  in  emissions  from  aviation  in  2050,  while  reducing  the number of flights by only 12% (Figure 2.25).

-  Keeping air travel for business purposes at 2019 levels. Although business trips fell to almost zero in 2020, they accounted for just over one-quarter of air travel before the pandemic. This avoids around 110 Mt CO2 in 2050 in the NZE.
-  Keeping  long-haul  flights  (more  than  six  hours)  for  leisure  purposes  at  2019  levels. Emissions from an average long-haul flight are 35-times greater than from a regional flight (less than one hour). This affects less than 2% of flights but avoids 70 Mt CO2 in 2050.
-  A shift to high-speed rail. The opportunities for shifting regional flights to high-speed rail vary by region. Globally, we estimate that around 15% of regional flights in 2019 could have been shifted given existing rail infrastructure; future high-speed rail lines ensure that by 2050 around 17% could be shifted (IEA, 2019). 18 This would reduce emissions by around 45 Mt CO2 in 2050 (high-speed trains generate no emissions in 2050 in the NZE).

Figure 2.25 ⊳ Global CO2 emissions from aviation and impact of behavioural changes in the NZE

<!-- image -->

IEA. All rights reserved.

Demand for passenger aviation is set to grow significantly by 2050, but behavioural changes reduce emissions by 50% in 2050 despite reducing flights by only 12%

Notes: Long-haul = more than 6 hour flight; medium-haul = 1-6 hour flight; regional = less than 1 hour. Business flights = trips  for  work  purposes;  leisure  flights  =  trips  for  leisure  purposes.  Average  speeds  vary  by  flight distance and range from 680-750 km/h.

18 This assumes that: new rail routes avoid water bodies and tunnelling through elevated terrain; travel times are  similar  to  aviation;  and  centres  of  demand  are  sufficiently  large  to  ensure  that  high-speed  rail  is economically viable.

2

Car use. A variety of new measures that aim to reduce the use of cars in cities and overall car ownership levels are assumed in the NZE. They lead to rapid growth in the rideshare market in urban areas, as well as phasing out polluting cars in large cities and replacing them with cycling, walking and public transport. The timing of these changes in the NZE depends on cities having the necessary infrastructure and public support to ensure a shift away from private car use. Between 20-50% of car trips are shifted to buses, depending on the city in question,  with  the  remainder  replaced  by  cycling,  walking  and  public  transport.  These changes  reduce  emissions  from  cars  in  cities  by  more  than  320 Mt CO2  in  total  in  the mid-2030s (Figure 2.26). Their impact on emissions fades over time as cars are increasingly electrified, but they still have a significant impact on curbing energy use in 2050.

Figure 2.26 ⊳ Global CO2 emissions savings and car ownership per household due to behavioural change in the NZE

<!-- image -->

IEA. All rights reserved.

Policies discouraging car use in cities lead to rapid reductions in CO2 emissions and lower car ownership levels, though the impact diminishes over time as cars are electrified

The gradual move away from cars in cities also has an impact on car ownership levels. Survey data  indicates  that  car-share  schemes  and  the  provision  of  public  transport  reduces  car ownership by up to 35%, with the biggest changes taking place in multiple car households (Jochem et al., 2020; Martin, Shaheen and Lidiker, 2010). Without behavioural changes, 35% of households would have a car in 2050; with behavioural changes this share falls to around 20% in the NZE, and two-car households fall from 13% of the total to less than 5%.

The changing patterns of mobility in cities in NZE have implications for materials demand. Reduced  car  ownership  leads  to  a  small  drop  in  steel  demand  in  2050,  saving  around 40 Mt CO2 in steel production. Increased cycling would need to be supported by building an estimated  80 000 km  of  new  cycle  lanes  globally  over  the  period  to  2050,  generating increased demand for cement and bitumen. This effect is small, however: the extra emissions associated with this would be less than 5% of the emissions avoided by lower car use.

## How to bring about the behavioural changes in NZE

Regulations and mandates could enable roughly 70% of the emissions saved by behavioural changes in the NZE. Examples include:

-  Upper speed limits, which are reduced over time in the NZE from their current levels to 100 km/h, cutting emissions from road vehicles by 3% in 2050.
-  Appliance standards, which maximise energy efficiency in the buildings sector.
-  Regulations covering heating temperatures in offices and default cooling temperatures for air conditioning units, which reduce excessive thermal demand.
-  Changes initially tackled by market-based mechanisms, e.g. swapping regional flights for high-speed rail, 19 which can be addressed by regulation over time to mirror changes in public sentiment and consumer norms.

Market-based instruments use a mix of financial incentives and disincentives to influence decision making. They could enable around two-thirds of the emissions saved by behavioural changes in the NZE. Examples include:

-  Congestion pricing and targeted interventions differentiated by vehicle type, 20 such as charges aimed at the most polluting vehicles, or preferential parking for clean cars.
-  Transport demand measures that reduce travel, such as fuel taxes and distance-based vehicle insurance and registration fees (Byars, Wei and Handy, 2017).
-  Information measures that help consumers to drive change, such as mandatory labelling of embodied or lifecycle emissions in manufacturing and a requirement for companies to disclose their carbon emissions.

Information and awareness measures could enable around 30% of the emissions saved by behavioural changes in the NZE. Examples include:

-  Personalised  and  real-time  travel  planning  information,  which  facilitates  a  switch  to walking, cycling and public transport.
-  Product labelling  and  public  awareness  campaigns  in  combination,  which  help  make recycling widespread and habitual.
-  Comparisons  with  consumption  patterns  of  similar  households,  which  can  reduce wasteful energy use by up to 20% (Aydin, Brounen and Kok, 2018).

Not all the behavioural changes in the NZE would be equally easy to achieve everywhere, and policy interventions would need to draw on insights from behavioural science and take into account existing behavioural norms and cultural preferences. Some behavioural changes may be more socially acceptable than others. Citizen assemblies in the United Kingdom and

19 A  law  banning  domestic  flights  where  a  rail  alternative  of  under  two-and-a-half  hours  exists  has  been proposed in France (Assemblee Nationale, 2021).

20 Congestion charging is currently used in 11 major cities and has been shown to reduce traffic volumes by up to 27%. Low-emissions zones charge vehicles to enter urban zones based vehicle type and currently exist in 15 countries (TFL, 2021; Tools of Change, 2014; European Commission, 2021).

2

France indicate a large level of support for taxes on frequent and long-distance flyers and for banning polluting vehicles from city centres; conversely, measures that limit car ownership or reduce speed limits have gained less acceptance (Convention Citoyenne pour le Climat, 2021; Climate Assembly UK, 2020). Behavioural changes which reduce energy use in homes may be particularly  well  supported:  a  recent  survey  showed  85%  support  for  line-drying clothes and switching off appliances, and only 20% of people felt that reducing temperature settings in homes was undesirable (Newgate Research and Cambridge Zero, 2021).

Table 2.10 ⊳ Key behavioural changes in the NZE

<!-- image -->

|                                                                                                              | Policy options                                                                                                                                                                               | Related policy-goals                                                                                                | Cost- effectiveness   | Timeliness    | Social acceptability   | CO 2 emissions impact   |
|--------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------|-----------------------|---------------|------------------------|-------------------------|
| Low-car cities                                                                                               |                                                                                                                                                                                              |                                                                                                                     |                       |               |                        |                         |
|  Phase out ICE cars from large cities.  Rideshare all urban car trips.                                     |  Low-emissions zones.  Access restrictions.  Parking restrictions.  Registration caps.  Parking pricing.  Congestion charges.  Investment in cycling lanes and public transportation. |  Air pollution mitigation.  Public health.  Reduced congestion.  Urban space.  Beautification and liveability. |                       |               |                        |                         |
| Fuel-efficient driving                                                                                       |                                                                                                                                                                                              |                                                                                                                     |                       |               |                        |                         |
|  Reduce motorway speeds to less than 100 km/h.  Eco-driving.  Raise air conditioning                      |  Speed limits.  Real-time fuel efficiency displays.  Awareness campaigns.                                                                                                                 |  Road safety.  Reduced noise pollution.                                                                           |                       |               |                        |                         |
| Reduce regional flights                                                                                      |                                                                                                                                                                                              |                                                                                                                     |                       |               |                        |                         |
|  Replace all flights <1h where high-speed rail is a feasible alternative.                                   |  High-speed rail investment.  Subsidies for high-speed rail travel.  Price premiums.                                                                                                      |  Lower air pollution.  Lower noise pollution.                                                                     |                       |               |                        |                         |
| Reduce international flights                                                                                 |                                                                                                                                                                                              |                                                                                                                     |                       |               |                        |                         |
|  Keep air travel for business purposes at 2019 levels.  Keep long-haul flights for leisure at 2019 levels. |  Awareness campaigns.  Price premiums.  Corporate targets.  Frequent-flyer levies.                                                                                                       |  Lower air pollution.  Lower noise pollution.                                                                     |                       |               |                        |                         |
| Space heating                                                                                                |                                                                                                                                                                                              |                                                                                                                     |                       |               |                        |                         |
|  Target average set-point temperatures of 19-20 °C.                                                         |  Awareness campaigns.  Consumption feedback.  Corporate targets.                                                                                                                          |  Public health.  Energy affordability.                                                                            |                       |               |                        |                         |
| Space cooling                                                                                                | Space cooling                                                                                                                                                                                | Space cooling                                                                                                       | Space cooling         | Space cooling | Space cooling          | Space cooling           |
|  Target average set-point temperatures of 24-25 °C.                                                         |  Awareness campaigns.  Consumption feedback.  Corporate targets.                                                                                                                          |  Public health.  Energy affordability.                                                                            |                       |               |                        |                         |

Notes: Large cities = cities over 1 million inhabitants. ICE = internal combustion engine. CO2 emissions impact = cumulative reductions 2020-2050. Eco-driving = early upshifting as well as avoiding sudden acceleration, stops or idling.  The  number of jobs  that can be done  at home varies considerably by region, globally, an average of 20% of jobs can be done at home.

The behavioural changes in the NZE would bring wider benefits in terms of air pollution in cities, road safety, noise pollution, congestion and health. Attitudes to policy interventions can change quickly when co-benefits become apparent. For example, support for congestion charging  in  Stockholm  jumped  from  less  than  40%  when  the  scheme  was  introduced  to around 70% three years later; a similar trend was seen in Singapore, London and other cities, all of which experienced declines in air pollution after the introduction of charging (Tools of Change, 2014; DEFRA, 2012).

## Are net-zero emissions by 2050 still possible without behavioural change?

If  the behavioural changes described in the NZE were not to materialise, final energy use would  be  27  EJ  and  emissions  1.7 Gt CO2  higher  in  2030,  and  they  would  be  37 EJ  and 2.6 Gt CO2 higher in 2050. This would further increase the already unprecedented ramp-up needed in low-carbon technologies. The share of EVs in the global car fleet would need to increase from around 20% in 2030 to 45% to ensure the same level of emissions reductions (Figure 2.27).  Achieving the same reduction in emissions in homes would require electric heat  pumps  sales  to  reach  680 million  in  2030  (compared  with  440 million  in  the  NZE). Without  gains  in  materials  efficiency,  the  share  of  low-carbon  primary  steel  production would  need  to  be  more  than  twice  as  high  in  2030  as  in  the  NZE.  In  2050,  the  use  of sustainable aviation fuels would also need to rise to 7 mboe/d (compared with 5 mboe/d in the NZE). Emissions from cement and steel production would be 1.7 Gt CO2 higher in 2050 than in the NZE, and so require increased deployment of CCUS in industry, deployment of electric arc furnaces and more use of low-carbon hydrogen.

Figure 2.27 ⊳ Share of low-carbon technologies and fuels with and without behavioural change in 2030 in the NZE

<!-- image -->

In the absence of behavioural changes, the share of low-emissions technologies in enduses in 2030 would need to be much larger to achieve the same emissions as in the NZE

Notes: Electric cars = share of electric cars on the road globally. Sustainable aviation fuels = biojet kerosene and synthetic jet kerosene. Low-carbon steel refers to primary steel production.

2

## 2.7.2 Bioenergy and land-use change

Modern  forms  of  bioenergy  play  a  key  role  in  achieving  net-zero  emissions  in  the  NZE. Bioenergy is a versatile renewable energy source that can be used in all sectors, and it can often  make  use  of  existing  transmission  and  distribution  infrastructure  and  end-user equipment.  But  there  are  constraints  on  expanding  the  supply  of  bioenergy:  with  finite potential  for  bioenergy  production  from  waste  streams,  there  are  possible  trade-offs between  expanding  bioenergy  production,  achieving  sustainable  development  goals  and avoiding conflicts with other land uses, notably food production.

The level of bioenergy use in the NZE takes account of these constraints: bioenergy demand in  2050  is  around  100 EJ.  The  global  sustainable  bioenergy  potential  in  2050  has  been assessed to be at least 100 EJ (Creutzig, 2015) and recent assessments estimate a potential between  150-170 EJ when  integrating relevant UN  Sustainable Development  Goals (Frank, 2021;  IPCC,  2019;  IPCC,  2014;  Wu,  2019).  However,  there  is  a  high  degree  of uncertainty  over  the  precise  levels  of  this  potential.  Using  modelling  developed  in co-operation  with  IIASA,  here  we  examine  the  implications  for  achieving  net-zero  CO2 emissions by 2050 if the available levels of sustainable bioenergy were to be lower. We also examine  what  would  need  to  be  done  to  achieve  large  reductions  in  emissions  from agriculture, forestry and other land use (AFOLU).

## Ensuring a sustainable supply of bioenergy

Most  liquid  biofuels  produced  today  come  from  dedicated  bioenergy  crops  such  as sugarcane, corn or oil crops, often known as conventional biofuels. The expanded use of feedstocks and arable land to produce these biofuels can conflict with food production. In the NZE, there is a shift towards the use of sustainable, certified agricultural products and wood.  Biofuel  production  processes  in  the  NZE  use  advanced  conversion  technologies coupled with CCUS where possible (see section 3.3.2). The emphasis is also on advanced bioenergy feedstocks, including waste streams from other processes, short-rotation woody crops  and  feedstocks  that  do  not  require  the  use  of  arable  land.  Advanced  bioenergy accounts  for  the  vast  majority  of  bioenergy  supply  in  the  NZE  by  2050.  The  use  of conventional energy crops for biofuel production grows from around 9 EJ in 2020 to around 11 EJ in 2030, but then falls by 70% to 3 EJ in 2050 (including feedstocks consumed in the biofuel production processes).

Advanced bioenergy feedstocks that do not require land include organic waste streams from agriculture and industry, and woody residues from forest harvesting and wood processing. Investment in comprehensive waste collection and sorting in the NZE unlocks around 45 EJ of bioenergy supply from various organic waste streams which is primarily used to produce biogases and advanced biofuels (Figure 2.28). Woody residues from wood processing and forest harvesting provide a further 20 EJ of bioenergy in 2050 in the NZE - less than half of current best estimates of the total sustainable potential. Bioenergy can also be produced

from dedicated short-rotation woody crops (25 EJ of bioenergy supply in 2050). 21 Sustainably managed forestry fuelwood or plantations 22 and tree plantings integrated with agricultural production via agroforestry systems that do not conflict with food production or biodiversity provide just over 10 EJ of bioenergy in 2050.

Figure 2.28 ⊳ Global bioenergy supply by source in the NZE

<!-- image -->

IEA. All rights reserved.

Bioenergy use increases by around 60% between 2020 and 2050, while shifting away from conventional feedstocks and the traditional use of biomass

Note: Organic waste streams include agricultural residues, food processing, industrial and municipal organic waste streams; they do not require land area.

Source: IEA analysis based on IIASA data.

The total land area dedicated to bioenergy production in the NZE increases from 330 million hectares (Mha) in 2020 to 410 Mha in 2050. In 2050, around 270 Mha is forest, representing around one-quarter of the total area of global managed forests, and around 5% of total forest area. There is 130 Mha of land used for short-rotation advanced bioenergy crops in 2050 and 10 Mha for conventional bioenergy crops. There is no overall increase in cropland use for bioenergy production in the NZE from today's level and no bioenergy crops are developed on forested land in the NZE. 23 As well as allowing a much greater level of bioenergy crop production on marginal lands, woody energy crops can produce twice as much bioenergy per hectare as conventional bioenergy crops.

21 Woody short-rotation coppice crops grown on crop land, pasture land or marginal lands not suited to food crops.

22 Sustainable forestry management ensures that the carbon stock and carbon absorption capability of the forest is expanded or remains unchanged.

23 Of the 140 Mha land used for bioenergy crops in 2050, 70 Mha are marginal lands or land currently used for livestock grazing and 70 Mha are cropland. There is a 60 Mha increase in cropland use for woody crops to 2050 in the NZE but this is offset by a reduction in cropland use for producing conventional biofuel feedstocks.

2

Total land use for bioenergy in the NZE is well below estimated ranges of potential land availability that take full account of sustainability constraints, including the need to protect biodiversity hotspots and to meet the UN Sustainable Development Goal 15 on biodiversity and land use. The certification of bioenergy products and strict control of what land can be converted to expand forestry plantations and woody energy crops nevertheless is critical to avoid land-use conflict issues. Certification is also critical to ensure the integrity of CO  offsets 2 (see Chapter 1), the use of which should be carefully managed and restricted to sectors that lack alternative mitigation options. A related land-use issue is how to tackle emissions that arise from outside the energy sector (Box 2.3).

## Box 2.3 ⊳ Balancing emissions from land use, agriculture and forestry

To limit the global temperature rise, all sources of GHG emissions need to decline to close to zero or to be offset with CDR. The energy sector accounted for around three quarters of total GHG emissions in recent years. The largest source of GHG emissions other than the energy sector is agriculture, forestry and other land use (AFOLU), which produced between  10-12 Gt CO2-eq  net  GHG  emissions  in  recent  years. 24 CO2  emissions  from AFOLU were around 5-6 Gt CO2, and nitrous oxide and methane emissions were around 5-6 Gt CO2-eq (IPCC, 2019).

Options  to  reduce  emissions  from  AFOLU  and  enhance  removals  include:  halting deforestation; improving forest management practices; instituting farming practices that increase  soil  carbon  levels;  and  afforestation.  A  number  of  companies  have  recently expressed interest in these sorts of nature-based solutions to offset emissions from their operations (see Chapter 1). For afforestation, converting around 170 Mha (roughly half the size of India) to forests would sequester around 1 Gt CO2 annually by 2050.

Achieving net-zero energy-related and industrial process CO2 emissions by 2050 in the NZE does not rely on any offsets from outside the energy sector. But commensurate action on AFOLU would help limit climate change. The energy-sector transformation in the NZE would reduce CO2 emissions from AFLOU in 2050 by around 150 Mt CO2 given the switch away from conventional crops and the increase in short rotation advancedbioenergy crop production on marginal lands and pasture land. To reduce emissions from AFOLU further would require reducing deforestation by two-thirds by 2050, instituting improved forest management practices and planting around 250 Mha of new forests. The combined impact of these changes would reduce CO2 emissions from AFOLU to zero by 2040  and  absorb  1.3 Gt CO2  annually  by  2050.  In  this  case,  cumulative  AFOLU  CO2 emissions between 2020 and 2050 would be around 40 Gt CO2.

Non-CO2 emissions from livestock, as well as other agricultural emissions, may be more difficult to mitigate given the link between livestock production and nitrous oxide and methane  emissions.  Changes  to  farming  practices  and  technology  improvements,

24 AFOLU emissions are emissions from anthropogenic activities and do not include CO2 emissions removal from the atmosphere by natural land sinks.

including changes to animal feed, could help to reduce these emissions, but it may be necessary to use afforestation to offset these emissions entirely. An alternative could be to reduce these emissions by reducing the demand for livestock products. For example, we estimate that reducing meat consumption in households with the highest levels of per capita consumption today to the global average level would reduce GHG emissions by more than 1 Gt CO2-eq in 2050. Lower demand for livestock products would reduce the pasture needed globally for livestock by close to 200 Mha and the cropland that is used to grow feed for livestock by a further 80 Mha.

## Are net-zero emissions by 2050 possible without expanding land use for bioenergy?

Estimates  of  the  global  sustainable  bioenergy  potential  are  subject  to  a  high  degree  of uncertainty,  in  particular  over  the  extent  to  which  new  land  area  could  sustainably  be converted  to  bioenergy  production.  As  a  result,  the  NZE  takes  a  cautious  approach  to bioenergy  use,  with  consumption  in  2050  (100 EJ)  well  below  the  latest  estimates  that integrate relevant SDGs, which suggest a potential between 150-170 EJ. But it is possible that the land available to provide sustainable bioenergy is even more limited. Here we explore the  implications  for  emissions  of  restricting  land  use  for  dedicated  bioenergy  crops  and forestry plantations to around 330 Mha, which is what is used today.

Figure 2.29 ⊳ Impact on electricity demand and ability to achieve net-zero emissions by 2050 without expanded bioenergy land use

<!-- image -->

IEA. All rights reserved.

Achieving net-zero emissions without expanding bioenergy land use would require a further 3 200 TWh from solar PV and wind, increasing capacity in the NZE by nearly 10%

Limiting land use to 330 Mha would reduce available bioenergy supply in 2050 by more than 10 EJ. This would mostly take the form of a reduction in the availability of short-rotation woody energy crops, which are mainly used in the NZE in place of fossil fuels to provide high temperature heat for industrial processes and for electricity generation. Without bioenergy,

2

it is likely that hydrogen and synthetic methane would be used instead, and their production would require around 70 Mt of hydrogen in 2050 (15% more than in the NZE). If this were to be produced through the use of electrolysis it would require around 750 GW of electrolyser capacity and increase electricity demand in 2050 by around 3 200 TWh (Figure 2.29).

The additional electricity that would be needed could be produced using renewables, which would require an additional 1 700 GW of wind and solar PV capacity and almost 350 GW of additional battery capacity in 2050. Annual capacity additions during the 2030s would need to be 160 GW higher than in the NZE. The additional wind, solar, battery and electrolyser capacity, together with the electricity networks and storage needed to support this higher level of deployment would cost more than USD 5 trillion by 2050. This is USD 4.5 trillion more than would be needed if the use of bioenergy were to be expanded as envisaged in the NZE, and would increase the total investment needed in the NZE by 3%. While it might therefore be  possible  still  to  achieve  net-zero  emissions  in  2050  without  expanding  land  use  for bioenergy, this would make the energy transition significantly more expensive.

## 2.7.3 CCUS applied to emissions from fossil fuels

A total of 7.6 Gt CO2 is captured in 2050 in the NZE, almost 50% of which is from fossil fuel combustion, 20% is from industrial processes, and around 30% is from bioenergy use with CO2 capture and DAC (Figure 2.30). The use of CCUS with fossil fuels provides almost 70% of the total growth in CCUS to 2030 in the NZE. Yet the prospects for the rapid scaling up of CCUS are very uncertain for economic, political and technical reasons. Here we look at the implications  for  reaching  net-zero  emissions  in  2050  if  fossil  fuel  CCUS  does  not  expand beyond existing and planned projects.

Figure 2.30 ⊳ CCUS by sector and emissions source in the NZE

<!-- image -->

Note: DAC = direct air capture.

## Are net-zero emissions by 2050 possible without fossil fuel-based CCUS?

Fossil fuel-based CCUS applications comprise most of the CCUS projects added to 2030 in the NZE. These projects help to reduce risks for other non-fossil fuel CCUS applications that are essential to reach net zero. In view of the challenges that fossil fuel-based CCUS projects face, we have constructed a Low CCUS Case (LCC) in which no new fossil fuel CCUS projects are developed beyond those already under construction or approved for development. In the LCC, CO2 emissions captured from fossil fuels are only around 150 Mt in 2050, compared with 3 600 Mt in 2050 in the NZE.

In industry, the lack of new fossil fuel CCUS projects leads in the LCC to 1.2 Gt of additional CO2 emissions compared with the NZE in 2050. It would be necessary to use alternative technologies to eliminate these emissions in order to achieve net zero by 2050. A number of technologies  that  are  at  the  prototype  stage  of  development  would  be  needed,  such  as electric  cement  kilns  or  electric  steam  crackers  for  high-value  chemicals  production  (see Box 2.4). Assuming that these technologies could be demonstrated and deployed at scale, this  would  increase  electricity  demand  by  around  2 400 TWh  and  hydrogen  demand  in industry  by  around  45 Mt  in  2050.  It  would  also  be  necessary  to  replace  the  145 Mt  of hydrogen that is produced in the NZE from fossil fuels equipped with CCUS. Provision of this 190 Mt of hydrogen through electrolysis would require an additional 2 000 GW capacity of electrolysers in 2050 (almost 60% more than in the NZE) and an additional 9 000 TWh of electricity (Figure 2.31).

Figure 2.31 ⊳ Impacts of achieving net-zero emissions by 2050 without expanded fossil fuel-based CCUS

<!-- image -->

IEA. All rights reserved.

Failure to deploy fossil fuel-based CCUS would significantly increase electricity demand and require much more solar, wind and electrolyser capacity

Note: LCC = Low CCUS Case where CCUS applied to fossil fuels is restricted to projects under construction or approved for development today.

2

## Box 2.4 ⊳ Technology innovation in the NZE

Innovation is key to developing new clean energy technologies and advancing existing ones. The importance of innovation increases as we get closer to 2050 because existing technologies will not be able to get us all the way along the path to net-zero emissions. Almost  50%  of  the  emissions  reductions  needed  in  2050  in  the  NZE  depend  on technologies that are at the prototype or demonstration stage, i.e. are not yet available on the market (see Chapter 4).

After a new idea makes its way from the drawing board to the laboratory and out into the world, there are four key stages in the clean energy innovation pipeline (IEA, 2020d). But the pathway to maturity can be long and success is not guaranteed.

-  Prototype. A concept is developed into a design and then into a prototype for a new device, e.g. a furnace that produces steel with pure hydrogen instead of coal.
-  Demonstration. The first examples of a new technology are introduced at the size of  a  full-scale  commercial  unit,  e.g.  a  system  that  captures  CO   emissions  from 2 cement plants.
-  Market uptake. The technology is being deployed in a number of markets. However, it either  has  a  cost  and  performance  gap  with  established  technologies  (e.g. electrolysers for hydrogen production) or it is competitive but there are still barriers, such as integration with existing infrastructure or consumer preferences, to reaching its full market potential (e.g. heat pumps). Policy attention is needed in both cases to stimulate wider diffusion to reduce costs and to overcome existing barriers, with more of the costs and risks being borne gradually by the private sector.
-  Maturity. The  technology  has  reached  market  stability,  and  new  purchases  or installations  are  constant  or  even  declining  in  some  environments  as  newer technologies start  to  compete  with  the  stock  of  existing  assets,  e.g.  hydropower turbines.

Innovation is critical  in  the  NZE  to  bring  new  technologies  to  market  and  to  improve emerging  technologies,  including  for  electrification,  CCUS,  hydrogen  and  sustainable bioenergy. The degree of reliance on innovation in the NZE varies across sectors and along the various steps of the value chains involved (Figure 2.32).

-  Electrification. Almost 30% of the 170 Gt CO2 cumulative emissions reductions from the use of low-emissions electricity in the NZE comes from technologies that are currently  at  prototype  or  demonstration  stage,  such  as  electricity-based  primary steel production or electric trucks.
-  Hydrogen. Not all steps of the low-carbon hydrogen value chain are available on the market today. The majority of demand technologies, such as hydrogen-based steel production, are only at the demonstration or prototype stage. These deliver more than 75% of the cumulative emissions reductions in the NZE related to hydrogen.

-  CCUS. Around 55% of the cumulative emissions reductions that come from CCUS in the NZE are from technologies that are at the demonstration or prototype stage today. While CO2 capture has been in use for decades in certain industrial and fuel transformation processes, such as ammonia production and natural gas processing, it is still being  demonstrated  at  a  large  scale  in  many  of  the  other  possible applications.
-  Bioenergy. Around 45% of the cumulative emissions reductions in the NZE related to sustainable bioenergy come from technologies that are at the demonstration or prototype stage today, mainly for the production of biofuels.

Figure 2.32 ⊳ Cumulative CO2 emissions reductions for selected technologies by maturity category in the NZE

<!-- image -->

CCUS, hydrogen and bioenergy technologies are less mature than electrification. Most technologies for heavy industry and trucks are at early stages of development.

Notes: Bio-FT = Biomass gasification with Fischer-Tropsch synthesis  Maturity levels are the technology . design at the most advanced stage.

2

In  the  electricity  sector,  it  would  be  necessary  to  produce  an  additional  11 300 TWh  of electricity for industry and fuel transformation and to replace virtually all of the electricity generated from fossil fuel powered plants equipped with CCUS in 2050 in the NZE. Using renewables, this would require an additional 7 000 GW of wind and solar PV capacity in 2050. This is around 30% more than in the NZE, and would mean that annual capacity additions of solar PV and wind during the 2030s would need to reach 1 300 GW (300 GW more than in the NZE). To accommodate this additional level of variable renewables and to provide the flexibility that is available from fossil fuel CCUS equipped plants in the NZE, around 660 GW more battery capacity would be needed in 2050 (20% more than in the NZE in in 2050), together with additional 110 GW of other dispatchable capacity.

Reducing the rate of adding CCUS at existing coal- and gas-fired generation plants in the LCC would also raise the risk of stranded assets. We estimate that up to USD 90 billion of existing coal- and gas-fired capacity could be stranded in 2030 and up to USD 400 billion by 2050. Investment in fossil fuel-based CCUS in the NZE to 2050 is around USD 650 billion, which would be avoided in the LCC. But additional investment is required in the LCC for extra wind, solar  and  electrolyser  capacity,  for  electricity-based  routes  in  heavy  industry,  and  for expanded electricity networks and storage to support this higher level of deployment. As a result, the additional cumulative investment to reach net-zero emissions in 2050 in the LCC is USD 15 trillion higher than in the NZE.

Failure  to  develop  CCUS  for  fossil  fuels  would  also  be  likely  to  delay  or  prevent  the development of other CCUS applications. Without fossil fuel-based CCUS, the number of users  and  the  volumes  of  the  CO   transport  and  storage  infrastructure  deployed  around 2 industrial clusters would be reduced. Fewer actors and more limited pools of capital would be available to incur the high upfront costs of infrastructure, as well as other risks associated with the initial roll-out of CCUS infrastructure clusters. In addition, there would be fewer spill-over  learning  and  cost-reduction  benefits  from  developing  fossil  fuel-based  CCUS, making the successful demonstration and scale up of more nascent CCUS technologies much less likely. A delay in the development of other CCUS technologies would have a major impact on the prospect of getting to  net-zero emissions in 2050. For example, CCUS is the only scalable low-emissions option to remove CO2 from the atmosphere and to almost eliminate emissions from cement production. If progress in these technologies were delayed and could not be deployed at scale, then achieving net-zero emissions by 2050 would be vastly more difficult.

<!-- image -->

## Sectoral pathways to net-zero emissions by 2050

\

## S U M M A R Y

-  Fossil fuel use falls drastically in the Net-Zero Emissions Scenario (NZE) by 2050, and no new oil and natural gas fields are required beyond those that have already been approved for development. No new coal mines or mine extensions are required. Lowemissions fuels - biogases, hydrogen and hydrogen-based fuels - see rapid growth. They account for almost 20% of global final energy in 2050, compared with 1% in 2020. More than 500 Mt of low-carbon hydrogen is produced in 2050, of which about 60%  is  produced  using  electrolysis  that  accounts  for  20%  of  global  electricity generation in 2050. Liquid biofuels provide 45% of global aviation fuel in 2050.
-  Electricity demand grows rapidly in the NZE, rising 40% from today to 2030 and more than two-and-a-half-times to 2050, while emissions from generation fall to net-zero in aggregate in advanced economies by 2035 and globally by 2040. Renewables drive the transformation, up from 29% of generation in 2020 to 60% in 2030 and nearly 90% in 2050. From 2030 to 2050, 600 GW of solar PV and 340 GW of wind are added each year. The least-efficient coal plants are phased out by 2030 and all unabated coal by 2040. Investment in electricity grids triples to 2030 and remains elevated to 2050.
-  In industry  emissions drop by 20% to 2030 and 90% to 2050. Around 60% of heavy , industry emissions reductions in 2050 in the NZE come from technologies that are not ready for market today: many of these use hydrogen or CCUS. From 2030, all new industry capacity additions are near-zero emissions. Each month from 2030, the world equips 10 new and existing heavy industry plants with CCUS, adds 3 new hydrogenbased industrial plants and adds 2 GW of electrolyser capacity at industrial sites.
-  In transport, emissions drop by 20% to 2030 and 90% to 2050. The initial focus is on increasing the operational and technical efficiency of transport systems, modal shifts, and the electrification of road transport. By 2030, electric cars account for over 60% of car sales (4.6% in 2020) and fuel cell or electric vehicles are 30% of heavy truck sales (less than 0.1% in 2020). By 2035, nearly all cars sold globally are electric, and by 2050 nearly  all  heavy  trucks  sold  are  fuel  cell  or  electric.  Low-emissions  fuels  and behavioural changes help to reduce emissions in long-distance transport, but aviation and shipping remain challenging and account for 330 Mt CO2 emissions in 2050.
-  In buildings  emissions drop by 40% to 2030 and more than 95% to 2050. By 2030, , around  20%  of  the  existing  building  stock  worldwide  is  retrofitted  and  all  new buildings  comply  with  zero-carbon-ready  building  standards.  Over  80%  of  the appliances  sold  are  the  most  efficient  models  available  by  2025  in  advanced economies and by the mid-2030s worldwide. There are no new fossil fuel boilers sold from 2025, except where they are compatible with hydrogen, and sales of heat pumps soar.  By  2050,  electricity  provides  66%  of  energy  use  in  buildings  (33%  in  2020). Natural gas use for heating drops by 98% in the period to 2050.

## 3.1 Introduction

The Net-Zero Emissions by 2050 Scenario (NZE) involves a global energy system transformation that is unparalleled in its speed and scope. This chapter looks at how the main  sectors  are  transformed,  as  well  as  the  specific  challenges  and  opportunities  this involves  (Figure 3.1).  It  covers  the  supply  of  fossil  and  low-emissions  fuels,  electricity generation and the three main end-use sectors - industry, transport and buildings. For each sector,  we  set  out  some  key  technology  and  infrastructure  milestones  on  which  the  NZE depends for its successful delivery. Further we discuss what key policy decisions are needed, and by when, to achieve these milestones. Recognising that there is no single pathway to achieve net-zero emissions by 2050 and that there are many uncertainties related to clean energy transitions, in this chapter we also explore the implications of choosing not to rely on certain  fuels,  technologies  or  emissions  reduction  options  across  the  transformation  and end-use sectors.

Figure 3.1 ⊳ CO2 emissions by sector in the NZE

<!-- image -->

Emissions fall fastest in the power sector, with transport, buildings and industry seeing steady declines to 2050. Reductions are aided by the increased availability of low-emissions fuels

Note:  Other  =  agriculture,  fuel  production,  transformation  and  related  process  emissions,  and  direct  air capture.

## 3.2 Fossil fuel supply

## 3.2.1 Energy trends in the Net-Zero Emissions Scenario

Coal use declines from 5 250 million tonnes of coal equivalent (Mtce) in 2020 to 2 500 Mtce in  2030  and  to  less  than  600 Mtce  in  2050.  Even  with  increasing  deployment  of  carbon capture,  utilisation  and  storage  (CCUS),  coal  use  in  2050  is  90%  lower  than  in  2020

(Figure 3.2). Oil demand never returns to its 2019 peak and it declines from 88 million barrels per day (mb/d) in 2020 to 72 mb/d in 2030 and to 24 mb/d in 2050, a fall of almost 75% between 2020 and 2050. Natural gas quickly rebounds from the dip in demand in 2020 and rises through to the mid-2020s, reaching a peak of around 4 300 billion cubic metres (bcm), before dropping to 3 700 bcm in 2030 and to 1 750 bcm in 2050. By 2050, natural gas use is 55% lower than in 2020.

Figure 3.2 ⊳ Coal, oil and natural gas production in the NZE

<!-- image -->

Between 2020 and 2050, demand for coal falls by 90%, oil by 75%, and natural gas by 55%

## Oil

The trajectory of  oil  demand  in  the  NZE  means  that  no  exploration  for  new  resources  is required  and,  other  than  fields  already  approved  for  development,  no  new  oil  fields  are necessary. However, continued investment in existing sources of oil production are needed. On average oil demand in the NZE falls by more than 4% per year between 2020 and 2050. If all capital investment in producing oil fields were to cease immediately, this would lead to a loss of over 8% of supply each year. If investment were to continue in producing fields but no new fields were developed, then the average annual loss of supply would be around 4.5% (Figure 3.3). The difference is made up by fields that are already approved for development.

These dynamics are reflected in the oil price in the NZE, which drops to around USD 35/barrel in  2030  and  USD 25/barrel  in  2050.  This  price  trajectory  is  largely  determined  by  the operating costs for fields currently in operation, and only a very small volume of existing production would need to be shut in. However, income from oil production in all countries is  much lower in the NZE than in recent years,  and the NZE projects significant stranded 1

1 Governments may also reduce or eliminate upstream taxes to ensure that production costs are below the oil price to maintain domestic production.

3

capital and stranded value.  The oil price in the NZE would be sufficient in principle to cover 2 the cost of developing new fields for the lowest cost producers, including those in the Middle East, but it is assumed that major resource holders do not proceed with investment in new fields because doing so would create significant additional downward pressure on prices.

The  refining  sector  also  faces  major  challenges  in  the  NZE.  Refinery  throughput  drops considerably and there are significant changes in product demand. With rapid electrification of the vehicle fleet, there is a major drop in demand for traditional refined products such as gasoline  and  diesel,  while  demand  for  non-combusted  products  such  as  petrochemicals increases. In recent years, around 55% of oil demand was for gasoline and diesel, but this drops to less than 15% in 2050, while the share of ethane, naphtha and liquefied petroleum gas (LPG) rises from 20% in recent years to almost 60% in 2050. This shift accentuates the drop  in  oil  demand  for  refiners,  and  refinery  runs  fall  by  85%  between  2020  and  2050. Refiners are used to coping with changing demand patterns, but the scale of the changes in the  NZE  would  inevitably  lead  to  refinery  closures,  especially  for  refineries  not  able  to concentrate primarily on petrochemical operations or the production of biofuels.

Figure 3.3 ⊳ Oil and natural gas production in the NZE

<!-- image -->

## Natural gas

No new natural gas fields are needed in the NZE beyond those already under development. Also not needed are many of the liquefied natural gas (LNG) liquefaction facilities currently under construction or at the planning stage. Between 2020 and 2050, natural gas traded as

2 Stranded capital is capital investment in fossil fuel infrastructure that is not recovered over the operating lifetime of the asset because of reduced demand or reduced prices resulting from climate policies. Stranded value is a reduction in the future revenue generated by an asset or asset owner assessed at a given point in time because of reduced demand or reduced prices resulting from climate policies (IEA, 2020a).

LNG falls by 60% and trade by pipeline falls by 65%. During the 2030s, global natural gas demand declines by more than 5% per year on average, meaning that some fields may be closed prematurely or shut in temporarily. Declines in natural gas demand slow after 2040, and more than half of natural gas use globally in 2050 is to produce hydrogen in facilities with CCUS. The large level of hydrogen, also produced using electrolysis, and biomethane in the NZE, means that the decline in total gaseous fuels is more muted than the decline in natural gas. This has important implications for the future of the gas industry (see Chapter 4).

## Coal

No new coal mines or extensions of existing ones are needed in the NZE as coal demand declines precipitously. Demand for coking coal falls at a slightly slower rate than for steam coal, but existing sources of production are sufficient to cover demand through to 2050. Such a decline in coal demand would have major consequences for employment in coal mining regions  (see  Chapter 4).  There  is  a  slowdown  in  the  rate  of  decline  in  the  2040s  as  coal production facilities are increasingly equipped with CCUS: in the NZE, around 80% of coal produced in 2050 applies CCUS.

## 3.2.2 Investment in oil and gas

Upstream oil and gas investment averages about USD 350 billion each year from 2021 to 2030 in the NZE (Figure 3.4). This is similar to the level in 2020, but around 30% lower than average  levels  during  the  previous  five  years.  Once  fields  under  development  start production, all of the upstream investment in the NZE is to support operations in existing fields; after 2030, total annual upstream investment is around USD 170 billion each year.

Figure 3.4 ⊳ Investment in oil and natural gas supply in the NZE

<!-- image -->

IEA. All rights reserved.

Once fields under development start production, all upstream oil and gas investment is spent on maintaining production at existing fields

Note: Investment in new fields in the 2021-2030 period is for projects that are already under construction or have been approved.

3

## 3.2.3 Emissions from fossil fuel production

Emissions from the supply chains of coal, oil and natural gas fall dramatically in the NZE. The global average greenhouse gas (GHG) emissions intensity of oil production today is just under 100 kilogrammes of carbon-dioxide equivalent (kg CO2-eq) per barrel. Without changes, a large proportion of global production would become uneconomic, as CO2 prices are applied to  the  full  value  chains  of  fossil  fuels.  For  example,  by  2030  the  CO   price  in  advanced 2 economies in the NZE is USD 100 per tonne of CO2 (tCO2), which would add USD 10 to the cost of producing each barrel at today's average level of emissions intensity.

Methane constitutes about 60% of emissions from the coal and natural gas supply chains and about 35% of emissions from the oil supply chain. In the NZE, total methane emissions from fossil  fuels  fall  by  around  75%  between  2020  and  2030,  equivalent  to  a  2.5 gigatonne  of carbon-dioxide equivalent (Gt CO2-eq) reduction in GHG emissions (Figure 3.5). Around onethird of this decline is a result of an overall reduction in fossil fuel consumption, but the larger share comes from a huge increase in the deployment of emissions reduction measures and technologies, which leads to the elimination of all technically avoidable methane emissions by 2030 (IEA, 2020a).

Figure 3.5 ⊳ Methane emissions from coal, oil and natural gas in the NZE

<!-- image -->

IEA. All rights reserved.

Methane emissions from fossil fuels fall by 75% between 2020 and 2030 as result of a concerted global effort to deploy all available reduction measures and technologies

Note: Mt = million tonnes.

Actions to reduce the emissions intensity of existing oil and gas operations in the NZE leads to: the end of all flaring; the use of CCUS with centralised sources of emissions (including to capture natural sources of CO2 that are often extracted with natural gas); and significant electrification  of  upstream  operations  (often  making  use  of  off-grid  renewable  energy sources).

The NZE inevitably brings significant challenges for fossil fuel industries and those who work in them, but it also brings opportunities. Coal mining declines dramatically in the NZE, but the mining of minerals needed for clean energy transitions increases very rapidly, and mining expertise is likely to be highly valued in this context. The oil and gas industry could play a key role in helping to develop at scale a number of clean energy technologies such as CCUS, lowcarbon hydrogen, biofuels and offshore wind. Scaling up these technologies and bringing down their costs will rely on large-scale engineering and project management capabilities, qualities  that  are  a  good  match  to  those  of  large  oil  and  gas  companies.  These  issues, including the question of how to help those affected by the major changes implied by the NZE, are discussed in more detail in Chapter 4.

## 3.3 Low-emissions fuel supply

## 3.3.1 Energy trends in the Net-Zero Emissions Scenario

Reaching net-zero emissions will require low-emissions fuels  where energy needs cannot 3 easily or economically be met by electricity (Figure 3.6). This is likely to be the case for some modes of long-distance transport (trucks, aviation and shipping) and of heat and feedstock supply  in  heavy  industry.  Some  low-emissions  fuels  are  effectively  drop-in,  i.e.  they  are compatible with the existing fossil fuel distribution infrastructure and end-use technologies, and require few if any modifications to equipment or vehicles.

Low-emissions fuels today account for just 1% of global final energy demand, a share that increases to 20% in 2050 in the NZE. Liquid biofuels meet 14% of global transport energy demand in 2050, up from 4% in 2020; hydrogen-based fuels meet a further 28% of transport energy needs by 2050. Low-carbon gases (biomethane, synthetic methane and hydrogen) meet 35% of global demand for gas supplied through networks in 2050, up from almost zero today. The combined share of low-carbon hydrogen and hydrogen-based fuels in total final energy use worldwide reaches 13% in 2050. Hydrogen and ammonia also provide important low-emissions sources of power system flexibility and contribute 2% of overall electricity generation in 2050, which is enough to make the electricity sector an important driver of hydrogen demand.

3 Low-emissions fuels refer to liquid biofuels, biogas and biomethane, and hydrogen-based fuels (hydrogen, ammonia and synthetic hydrocarbon fuels) that do not emit CO2 from fossil fuels directly when used and also emit very little when being produced. For example, hydrogen produced from natural gas with CCUS and high capture rates (90% or higher) is considered a low-emissions fuel, but not if produced without CCUS.

3

Figure 3.6 ⊳ Global supply of low-emissions fuels by sector in the NZE

<!-- image -->

IEA. All rights reserved.

Low-emissions fuels in the form of liquid biofuels, biomethane, hydrogen-based fuels help to decarbonise sectors where direct electrification is challenging

Notes: TFC = total final consumption. Low-carbon gases in the gas grid refers to the blending of biomethane, hydrogen and synthetic methane with natural gas in a gas network for use in buildings, industry, transport and electricity generation. Synfuels refer to synthetic hydrocarbon fuels produced from hydrogen and CO2. Final energy consumption of hydrogen includes, in addition to the final energy consumption of hydrogen, ammonia and synthetic hydrocarbon fuels, the on-site hydrogen production in the industry sector.

## 3.3.2 Biofuels 4

Around 10% of the global primary supply of modern bioenergy (biomass excluding traditional uses for cooking) was consumed as liquid biofuels for road transport and 6% was consumed as  biogases  (biogas  and  biomethane)  to  provide  power  and  heat  in  2020,  with  the  rest directly  used  for  electricity  generation  and  heating  in  the  residential  sector.  Supply accelerates sharply in the NZE with liquid biofuels expanding by a factor of almost four and biogases increasing by a factor of six by 2050.

All but about 7% of liquid biofuels for transport are currently produced from conventional crops such as sugarcane, corn and soybeans. Such crops directly compete with arable land that can be used for food production, which limits the scope for expanding output. So most of the growth in biofuels in the NZE comes from advanced feedstocks such as wastes and residues and woody energy crops grown on marginal lands and cropland not suitable for food

4 Liquids and gases produced from bioenergy.

production (see section 2.7.2). Advanced liquid biofuel production technology using woody feedstock expands rapidly over the next decade in the NZE, and its contribution to liquid biofuels jumps from less than 1% in 2020 to almost 45% in 2030 and 90% in 2050 (Figure 3.7). By 2030, production reaches 2.7 million barrels of oil equivalent per day (mboe/d) by 2030, underpinned by biomass gasification using the Fischer-Tropsch process (bio-FT) and cellulosic ethanol, mostly to produce drop-in substitutes for diesel and jet kerosene. Advanced liquid biofuel production increases by an additional 130% to more than 6 mboe/d in 2050, the bulk of which is biokerosene.

Figure 3.7 ⊳ Global biofuels production by type and technology in the NZE

<!-- image -->

IEA. All rights reserved.

Liquid biofuel production quadruples while that of biogases expands sixfold between 2020 and 2050, underpinned by the development of sustainable biomass supply chains

Notes:  EJ  =  exajoules;  CCUS = carbon  capture,  utilisation  and  storage.  Conventional  ethanol  refers  to production using food energy crops. Advanced ethanol refers to production using wastes and residues and non-food energy crops grown on marginal and non-arable land. Conventional biodiesel includes fatty acid and methyl esters (FAME) route using food energy crops. Advanced biodiesel includes biomass-based FischerTropsch and HEFA routes using wastes, residues and non-food energy crops grown on marginal and non-arable land. Biomethane includes biogas upgrading and biomass gasification-based routes.

Production  using  these  feedstocks  is  mostly  under  development  today.  Current  output capacity, principally cellulosic ethanol, is about 2.5 thousand barrels of oil equivalent per day (kboe/d).  The  NZE  assumes  that  projects  currently  in  the  pipeline  in  Japan,  the  United Kingdom and the United States will bring these technologies to the market within the next few years. The scale up required for all advanced liquid biofuels (including from waste oils) over the next decade is equivalent to building one 55 kboe/d biorefinery every ten weeks (the world's largest biorefinery has capacity of 28 kboe/d).

The supply of these biofuels after 2030 shifts rapidly in the NZE from passenger vehicles and light trucks, where electrification is increasingly the order of the day, to heavy road freight, shipping  and  aviation.  Ammonia  makes  inroads  into  shipping.  Advanced  liquid  biofuels increase their share of the global aviation fuel market from 15% in 2030 to 45% in 2050.

3

Advanced biofuels such as hydrogenated esters and fatty acids (HEFA) and bio-FT are able to adjust their product slates (up to a point) from renewable diesel to biokerosene, and existing ethanol  plants,  especially  those  that  can  be  retrofitted  with  CCUS  or  integrated  with cellulosic feedstock, also make a contribution.

The supply of biogases increases even more than liquid biofuels. Injection into gas networks expands from under 1% of total gas volume in 2020 to almost 20% in 2050, reducing the emissions intensity of the network-based gas. Biomethane is mostly produced by upgrading biogas produced from anaerobic digestion of feedstocks such as agricultural residues like manure and biogenic municipal solid waste, thereby avoiding methane emissions that would otherwise be released. Due to the dispersed nature of these feedstocks, this assumes the construction  of  thousands  of  injection  sites  and  associated  distribution  lines  every  year. Biogas and biomethane are also used as clean cooking fuels and in electricity generation in the NZE.

The production of biofuels can be combined with CCUS at a relatively low cost in some biofuel production  routes  (ethanol,  bio-FT,  biogas  upgrading)  because  the  processes  involved release very pure streams of CO2. In the NZE, the use of biofuels with CCUS results in annual carbon  dioxide  removal  (CDR)  of  0.6 Gt CO2  in  2050,  which  offset  residual  emissions  in transport and industry.

## 3.3.3 Hydrogen and hydrogen-based fuels

Hydrogen use in the energy sector today is largely confined to oil refining and the production of ammonia and methanol in the chemicals industry. Global hydrogen demand was around 90 million tonnes (Mt) in 2020, mainly produced from fossil fuels (mostly natural gas) and emitting  close  to  900 Mt CO2.  Both  the  amount  needed  and  the  production  route  of hydrogen change radically in the NZE. Demand increases almost sixfold to 530 Mt in 2050, of which  half  is  used  in  heavy  industry  (mainly  steel  and  chemicals  production)  and  in  the transport sector; 30% is converted into other hydrogen-based fuels, mainly ammonia for shipping and electricity generation, synthetic kerosene for aviation and synthetic methane blended into gas networks; and 17% is used in gas-fired power plants to balance increasing electricity  generation  from  solar  PV  and  wind  and  to  provide  seasonal  storage.  Overall, hydrogen-based fuels  account for 13% of global final energy demand in 2050 (Figure 3.8). 5

Ammonia is used today as feedstock in the chemical industry, but in the NZE it is also used as fuel in various energy applications, benefitting from its lower transport cost and higher energy density than hydrogen. Ammonia accounts for around 45% of global energy demand for shipping in 2050 in the NZE. Co-firing with ammonia is also a potential early option to reduce CO2 emissions in existing coal-fired power plants. The toxicity of ammonia means that its handling is likely to be limited to professionally trained operators, which could restrict its potential.

5 Hydrogen-based fuels are defined as hydrogen, ammonia as well as synthetic hydrocarbon fuels produced from hydrogen and CO2.

Figure 3.8 ⊳ Global production of hydrogen by fuel and hydrogen demand by sector in the NZE

<!-- image -->

Hydrogen production jumps sixfold by 2050, driven by water electrolysis and natural gas with CCUS, to meet rising demand in shipping, road transport and heavy industry

Note: Refining CNR = hydrogen by-product from catalytic naphtha reforming at refineries.

Synthetic kerosene meets around one-third of global aviation fuel demand in 2050 in the NZE. Its  manufacture at  bioenergy-fired  power  or  biofuel  production  plants  requires  CO2 captured from the atmosphere. CO2 from these sources can be considered carbon neutral, as it results in no net emissions when the fuel is used. There is scope for the co-production of  advanced  liquid  biofuels  and  synthetic  liquid  fuels  from  hydrogen  and  CO ,  with  the 2 integration of the two processes reducing the overall liquid fuel production costs. Alongside synthetic liquid fuels, enough synthetic methane is produced from hydrogen and CO2 in 2050 to meet 10% of demand for network supplied gas in the buildings, industry and transport sectors.

By  2050,  hydrogen  production  in  the  NZE  is  almost  entirely  based  on  low-carbon technologies:  water  electrolysis  accounts  for  more  than  60%  of  global  production,  and natural gas in combination with CCUS for almost 40%. Global electrolyser capacity reaches 850 gigawatts  (GW)  by  2030  and  3 600 GW  by  2050,  up  from  around  0.3 GW  today. Electrolysis absorbs close to 15 000 terawatt-hours (TWh), or 20% of global electricity supply in 2050, largely from renewable resources (95%), but also from nuclear power (3%) and fossil fuels with CCUS (2%). Natural gas use for hydrogen production with CCUS is 925 bcm in 2050, or around 50% of global natural gas demand, with 1.8 Gt CO2 being captured.

Scaling up deployment of technologies and related manufacturing capacity will be critical to reducing  costs.  Water  electrolysers  are  available  on  the  market  today  and  hydrogen production from natural gas with CCUS has been demonstrated at a commercial scale (there are seven plants in operation around the world). The choice between the two depends on

3

economic factors, mainly the cost of natural gas and electricity, and on whether CO2 storage is available. For natural gas with CCUS, production costs in the NZE are around USD 1-2 per kilogramme (kg) of hydrogen in 2050, with gas costs typically accounting for 15-55% of total production costs. For water electrolysis, learning effects and economies of scale result in CAPEX  cost  reductions  of  60%  in  the  NZE  by  2030  compared  to  2020.  Production  cost reductions hinge on lowering the cost of low-carbon electricity, as electricity accounts for 50-85%  of  total  production  costs,  depending  on  the  electricity  source  and  region.  The average cost of producing hydrogen from renewables drops in the NZE from USD 3.5-7.5/kg today to around USD 1.5-3.5/kg in 2030 and USD 1-2.5/kg in 2050 - essentially about the same as the cost of producing with natural gas with CCUS.

Converting hydrogen into other energy carriers, such as ammonia or synthetic hydrocarbon fuels, involves even higher costs. But it results in fuels that can be more easily transported and  stored,  and  which  are  also  often  compatible  with  existing  infrastructure  or  end-use technologies (as in the case of ammonia for shipping or synthetic kerosene for aviation). For ammonia,  the  additional  synthesis  step  increases  the  production  costs  by  around  15% compared with hydrogen (mainly due to additional conversion losses and equipment costs).

The  relatively  high  cost  of  synthetic  hydrocarbon  fuels  explains  why  their  use  is  largely restricted to aviation in the NZE, where alternative low-carbon options are limited. Synthetic kerosene costs were USD 300-700/barrel in 2020: although these costs fall to USD 130-300/barrel by 2050 in the NZE as the costs of electricity from renewables and CO2 feedstocks decline,  the  cost  of  synthetic  kerosene  remains  far  higher  than  the  projected USD 25/barrel cost of conventional kerosene in 2050 in the NZE. The supply of CO2, captured from bioenergy equipped with CCUS or direct air capture (DAC), needed to make these fuels is a relevant  cost  factor, accounting  for  USD 15-70/barrel  of  the  cost  of  synthetic hydrocarbon fuels in 2050. Closing these cost gaps implies penalties for fossil kerosene or support measures for synthetic kerosene corresponding to a CO2 price of USD 250-400/tonne.

Increasing global demand for low-carbon hydrogen in the NZE provides a means for countries to  export  renewable  electricity  resources  that  could  not  otherwise  be  exploited.  For example,  Chile  and  Australia  announced  ambitions  to  become  major  exporters  in  their national  hydrogen  strategies.  With  declining  demand  for  natural  gas  in  the  NZE,  gasproducing countries could join this market by exporting hydrogen produced from natural gas with CCUS. Long-distance transport of hydrogen, however, is difficult and costly because of its low energy density, and can add around USD 1-3/kg of hydrogen to its price. This means that,  depending  on  each  country's  own  circumstances,  producing  hydrogen  domestically may  be  cheaper  than  importing  it,  even  if  domestic  production  costs  from  low-carbon electricity  or  natural  gas  with  CCUS  are  relatively  high.  International  trade  nevertheless becomes increasingly important in the NZE: around half of global ammonia and a third of synthetic liquid fuels are traded in 2050.

## 3.3.4 Key milestones and decision points

Table 3.1 ⊳ Key milestones in transforming low-emissions fuels

| Sector                                                             | 2020   | 2030   | 2050   |
|--------------------------------------------------------------------|--------|--------|--------|
| Bioenergy                                                          |        |        |        |
| Share of modern biofuels in modern bioenergy                       | 20%    | 45%    | 48%    |
| Advanced liquid biofuels (mboe/d)                                  | 0.1    | 2.7    | 6.2    |
| Share of biomethane in total gas networks                          | <1%    | 2%     | 20%    |
| CO 2 captured and stored from biofuels production (Mt CO 2         | 1      | 150    | 625    |
| Hydrogen                                                           |        |        |        |
| Production (Mt H 2 )                                               | 87     | 212    | 528    |
| of which: low-carbon (Mt H 2 )                                     | 9      | 150    | 520    |
| Electrolyser capacity (GW)                                         | <1     | 850    | 3 585  |
| Electricity demand for hydrogen-related production (TWh)           | 1      | 3 850  | 14 500 |
| CO 2 captured from hydrogen production (Mt CO 2 )                  | 135    | 680    | 1 800  |
| Number of export terminals at ports for hydrogen and ammonia trade | 0      | 60     | 150    |

Note: mboe/d = million barrels of oil equivalent per day; Mt = million tonnes; H2 = hydrogen.

## Biofuels

Several  sustainability  frameworks  considering  net  lifecycle  GHG  emissions  and  other sustainability indicators exist in different regions, e.g. the Renewable Energy Directive II in the  European  Union,  RenovaBio  in  Brazil  and  the  Low-C  Fuel  Standards  in  California. However, the scope,  methodology and sustainability  metrics  of  these  frameworks  differ. Global consensus on a sustainability framework and indicators within the next few years would help stimulate investment; this should be a priority. Such a framework should cover all forms of bioenergy (liquid, gaseous and solid) and other low-emissions fuels, and should strive  for  continuous  environmental  performance  improvement.  Certification  schemes ideally should be developed in parallel.

Another early priority is for governments to assess national sustainable biomass feedstock potential as soon as possible to establish the quantities and types of wastes, residues and marginal lands suitable for energy crops. Assessments should provide the basis for national roadmaps for all liquid and gaseous biofuels, and strategies for low-emissions fuels. Early decisions will be needed in this context about how to support the sustainable collection of wastes  and  residues  from  the  forestry,  agriculture,  animal  and  food  industries  and  from advanced municipal solid waste sorting systems: in the NZE, support measures are in place by 2025. Measures might usefully include low-emissions fuels standards that incentivise the use of biofuels as feedstock. International knowledge-sharing would help with the design of such measures and assist efficient dissemination of best practices from regions with existing collection  systems,  e.g.  for  forestry  residues  in  Nordic  countries  and  used  cooking  oil collection in Europe, China and Southeast Asia countries.

Governments  will  also  need  to  decide  how  best  to  support  biogas  installations  and distribution in order to move away from traditional uses of biomass for cooking and heating by  2030.  Such  practices  remain  widespread  in  some  developing  countries.  They  are  best tackled as part of broader programmes to promote clean cooking alongside improving access to electricity and LPG.

Decisions will be needed by 2025 on how best to create markets for sustainable biofuels and close the cost gap between biofuels and fossil fuels. Measures will need to incentivise the rapid  development  and  deployment  of  advanced  liquid  biofuel  technologies  in  end-use sectors (particularly heavy-duty trucking, shipping and aviation), using mechanisms such as low-carbon fuel standards, biofuel mandates and CO2 removal credits. Measures that could boost  the  scaling  up  of  advanced  biofuels  production  in  the  next  four  years  include: incentives for co-processing bio-oil in existing oil refineries or fully converting oil refineries to  biorefineries;  retrofitting  ethanol  plants  with  CCUS;  and  integrating  cellulosic  ethanol production with existing ethanol plants.

New infrastructure will be needed to provide for the injection of more biomethane into gas networks and to transport and store the CO2 captured from ethanol and bio-FT biofuel plants. Governments  should  prioritise  the  co-development  of  biogas  upgrading  facilities  and biomethane injection sites by 2030, ensuring that particular attention is paid to minimising fugitive  biomethane  emissions  from  the  supply  chain.  Where  biomass  availability  allows, governments may see value in encouraging the deployment of biofuel plants with CCUS near existing industrial hubs where integrated CCUS projects are planned, such as the Humber region in the United Kingdom.

## Hydrogen-based fuels

An immediate priority should be for governments to assess the opportunities and challenges of  developing  a  low-carbon hydrogen industry as part of national hydrogen strategies or roadmaps. Decisions will be needed on whether to produce hydrogen domestically from lowcarbon electricity via water electrolysis or from gas with CCUS or a combination of both, or whether to rely on imported hydrogen-based fuels. Building technology leadership along the hydrogen supply chain could help create jobs and stimulate economic growth.

Decisions will be needed during the next decade on how best to bring down the costs of lowcarbon  hydrogen  production.  Switching  existing  hydrogen  production  in  industry  and  oil refining from unabated fossil fuels to low-carbon hydrogen is one possible way to ramp up low-carbon hydrogen production in applications that have large demand already available. Financial support instruments, such as contracts for differences, could help to reduce the current  cost  gap  of  low-carbon  hydrogen  production  compared  to  existing  unabated production from fossil fuels.

Decisions will also be needed on how best to scale up hydrogen. Industrial ports could be a good starting point, since they may provide access to low-carbon hydrogen supply in the form of offshore wind or CO2 storage. They also offer scope to promote new port-related

uses for hydrogen, e.g. shipping and delivery trucks, and they could become the first nodes of  an  international  hydrogen  trade  network.  The  establishment  of  hydrogen  trade  will require  the  development  of  methodologies  to  determine  the  carbon  footprint  of  the different  hydrogen  production  routes  and  the  adoption  of  guarantees  of  origin  and certification schemes for low-carbon hydrogen (and hydrogen-based fuels).

Blending hydrogen into existing gas networks offers another early avenue to scale up lowcarbon  hydrogen  production  and  trigger  cost  reductions.  International  harmonisation  of safety standards and national regulations on allowed concentrations of hydrogen in gas grids would  help  with  this,  as  would  the  adoption  of  blending  quotas  or  low-emissions  fuel standards.

Repurposing  existing  gas  pipelines,  where  technically  feasible,  with  declining  natural  gas demand and connecting large hydrogen demand hubs to transport hydrogen could result in low  cost  and  low  regret  opportunities  to  kick-start  the  development  of  new  hydrogen infrastructure. Developing the infrastructure for hydrogen at the pace required in the NZE would involve considerable investment risks along the value chain of production, transport and  demand  ranging  from  hydrogen  production  technologies  through  to  low-emissions electricity  generation  and  CO   transport  and  storage.  Governments  and  local  authorities 2 could play an important role by co-ordinating the planning processes among the various stakeholders; direct public investment or public-private partnerships could help to develop necessary  shared  infrastructure  for  hydrogen;  and  international  co-operation  and  crossborder initiatives could help to share investment burdens and risks and so facilitate largescale deployments, as in the EU Important Projects of Common European Interest.

## 3.4 Electricity sector

## 3.4.1 Energy and emissions trends in the Net-Zero Emissions Scenario

The NZE involves both a significant increase in electricity needs - the result of an increase in economic activity, rapid electrification of end-uses and expansion of hydrogen production by electrolysis  -  and  a  radical  transformation  in  the  way  electricity  is  generated.  Global electricity demand was 23 230 TWh in 2020 with an average growth rate of 2.3% per year over the previous decade. It climbs to 60 000 TWh in 2050 in the NZE, an average increase of 3.2% per year.

Emerging  market  and  developing  economies  account  for  75%  of  the  projected  global increase in electricity demand to 2050 (Figure 3.9). Their demand increases by half by 2030 and triples by 2050, driven by expanding population and rising incomes and living standards, as well new sources of demand linked to decarbonisation. In advanced economies, electricity demand returns to growth after a decade-long lull, nearly doubling between 2020 and 2050, driven mostly by end-use electrification and hydrogen production.

Figure 3.9 ⊳ Electricity demand by sector and regional grouping in the NZE

<!-- image -->

Electrification of end-uses and hydrogen production raise electricity demand worldwide, with a further boost to expand services in emerging market and developing economies

The transformation of the electricity sector is central to achieving net-zero emissions in 2050. Electricity  generation  is  the  single  largest  source  of  energy-related  CO   emissions  today, 2 accounting  for  36%  of  total  energy-related  emissions.  CO2  emissions  from  electricity generation  worldwide  totalled  12.3 Gt  in  2020,  of  which  9.1 Gt  was  from  coal-fired generation,  2.7 Gt  from  gas-fired  plants  and  0.6 Gt  from  oil-fired  plants.  In  the  NZE,  CO 2 emissions from electricity generation fall to zero in aggregate in advanced economies in the 2030s. They fall to zero in emerging market and developing economies around 2040.

Renewables contribute most to decarbonising electricity in the NZE: global generation from renewables nearly triples by 2030 and grows eightfold by 2050 (Figure 3.10). This raises the share of renewables in total output from 29% in 2020 to over 60% in 2030 and nearly 90% in 2050. Solar PV and wind race ahead, becoming the leading sources of electricity globally before  2030:  each  generates  over  23 000 TWh  by  2050,  equivalent  to  about  90%  of  all electricity produced in the world in 2020. Pairing battery storage systems with solar PV and wind  to  improve  power  system  flexibility  and  maintain  electricity  security  becomes commonplace in  the  late  2020s,  complemented  by  demand  response  for  short  duration flexibility and  hydropower  or  hydrogen  for  flexibility  across  days  or  even  seasons. Hydropower is the largest low-carbon source of electricity today and steadily grows in the NZE, doubling by 2050. Generation using bioenergy - in dedicated plants and as biomethane delivered through gas networks - doubles to 2030 and increases nearly fivefold by 2050.

Figure 3.10 ⊳ Global electricity generation by source in the NZE

<!-- image -->

IEA. All rights reserved.

Solar and wind power race ahead, raising the share of renewables in total generation from 29% in 2020 to nearly 90% in 2050, complemented by nuclear, hydrogen and CCUS

Nuclear power also makes a significant contribution in the NZE, its output rising steadily by 40% to 2030 and doubling by 2050, though its overall share of generation is below 10% in 2050. At its peak in the early 2030s, global nuclear capacity additions reach 30 GW per year, five-times  the  rate  of  the  past  decade.  In  advanced  economies,  lifetime  extensions  for existing reactors are pursued in many countries as they are one of the most cost-effective sources  of  low-carbon  electricity  (IEA,  2019),  while  new  construction  expands  to  about 4.5 GW  per  year  on  average  from  2021  to  2035,  with  an  increasing  emphasis  on  small modular reactors. Despite these efforts, the nuclear share of total generation in advanced economies falls from 18% in 2020 to 10% in 2050. Two-thirds of new nuclear power capacity in the NZE is built in emerging market and developing economies mainly in the form of largescale  reactors,  where  the  fleet  of  reactors  quadruples  to  2050.  This  raises  the  share  of nuclear in electricity generation in those countries from 5% in 2020 to 7% in 2050 (as well as nuclear meeting 4% of commercial heat demand in 2050).

Nuclear power technologies have advanced in recent years, with several first-of-a-kind largescale reactors completed that include enhanced safety features. While projects have been completed on schedule in  China,  Russia  and  the  United  Arab  Emirates,  there  have  been substantial delays and cost overruns in Europe and the United States. Small modular reactors and  other  advanced  reactor  designs  are  moving  towards  full-scale  demonstration,  with scalable designs, lower upfront costs and the potential to improve the flexibility of nuclear power in terms of both operations and outputs, e.g. electricity, heat or hydrogen.

Retrofitting coal- and gas-fired capacity with CCUS or co-firing with hydrogen-based fuels enables existing assets to contribute to the transition while cutting emissions and supporting electricity  security.  The  best  opportunities  for  CCUS  are  at  large,  young  facilities  with

3

available  space  to  add  capture  equipment  and  in  locations  with  CO2  storage  options  or demand for use. Opportunities are concentrated in China for coal-fired power plants and the United States for gas-fired capacity. While they provide just 2% of total generation from 2030 to 2050 in the NZE, retrofitted plants capture a total of 15 Gt CO2 emissions over the period.

Carbon capture technologies remain at an early stage of commercialisation. Two commercial power plants have been equipped with CCUS over the past five years, and there are currently 18 CCUS power projects in development worldwide. Completing these projects in a timely manner  and  driving  down  costs  through  learning-by-doing  will  be  critical  to  further expansion. An alternative would be to retrofit existing coal- and gas-fired power plants to co-fire  high  shares  of  hydrogen-based  fuels.  In  the  NZE,  hydrogen-based  fuels  generate 900 TWh of electricity  in  2030  and  1 700 TWh  in  2050  in  this  way  (about  2.5%  of  global generation in both years). A large-scale (1 GW) demonstration project to co-fire with 20% ammonia  is  underway  in  2021,  with  aims  to  move  towards  ammonia-only  combustion. Manufacturers have signalled that future gas turbine designs will be capable of co-firing high shares of hydrogen. While the investment needed to co-fire hydrogen-based fuels looks to be modest, relatively high fuel costs point to targeted applications to support power system stability and flexibility rather than bulk power.

The global use of unabated fossil fuels in electricity generation is sharply reduced in the NZE. Unabated coal-fired generation is cut by 70% by 2030, including the phase-out of unabated coal in advanced economies, and phased out in all other regions by 2040. Large-scale oil-fired generation is phased out in the 2030s. Generation using natural gas without carbon capture rises in the near term, replacing coal, but starts falling by 2030 and is 90% lower by 2040 compared with 2020.

The electricity sector is the first to achieve net-zero emissions mainly because of the low costs, widespread policy support and maturity of an array of renewable energy technologies. Solar PV is first among them: it is the cheapest new source of electricity in most markets and has policy support in more than 130 countries. Onshore wind is also a market-ready low cost technology that is widely supported and can be scaled up quickly, rivalling the low costs of solar  PV  where  conditions  are  good,  though  it  faces  public  opposition  and  extensive permitting and licensing processes in several markets. Offshore wind technology has been maturing rapidly in recent years; its deployment is poised to accelerate in the near term. The current focus is on fixed-bottom installations, but floating offshore wind starts to make a major contribution from around 2030 in the NZE, helping to unlock the enormous potential that exists around the world. Hydropower, bioenergy and geothermal technologies are well established,  mature  and  flexible  renewable  energy  sources.  As  dispatchable  generating options, they will be critical to electricity security, complemented by batteries, which have seen sharp cost reductions, have proven their ability to provide high-value grid services and can be built in a matter of months in most locations. Concentrating solar and marine power are less mature technologies, but innovation could see them make important contributions in the long term.

## 3.4.2 Key milestones and decision points

Table 3.2 ⊳ Key milestones in transforming global electricity generation

| Category                              | Category                                                                                                                |
|---------------------------------------|-------------------------------------------------------------------------------------------------------------------------|
| Decarbonisation of electricity sector |  Advanced economies in aggregate: 2035.  Emerging market and developing economies: 2040.                              |
| Hydrogen-based fuels                  |  Start retrofitting coal-fired power plants to co-fire with ammonia and gas turbines to co-fire with hydrogen by 2025. |
| Unabated fossil fuel                  |  Phase out all subcritical coal-fired power plants by 2030 (870 GWexisting plants and 14 GWunder construction).        |

-  Phase out all unabated coal-fired plants by 2040.
-  Phase out large oil-fired power plants in the 2030s.
-  Unabated natural gas-fired generation peaks by 2030 and is 90% lower by 2040.

| Category                                                        | 2020    | 2030    | 2050    |
|-----------------------------------------------------------------|---------|---------|---------|
| Total electricity generation (TWh)                              | 26 800  | 37 300  | 71 200  |
| Renewables                                                      |         |         |         |
| Installed capacity (GW)                                         | 2 990   | 10 300  | 26 600  |
| Share in total generation                                       | 29%     | 61%     | 88%     |
| Share of solar PV and wind in total generation                  | 9%      | 40%     | 68%     |
| Carbon capture, utilisation and storage (CCUS) generation (TWh) |         |         |         |
| Coal and gas plants equipped with CCUS                          | 4       | 460     | 1 330   |
| Bioenergy plants with CCUS                                      | 0       | 130     | 840     |
| Hydrogen and ammonia                                            |         |         |         |
| Average blending in global coal-fired generation (without CCUS) | 0%      | 3%      | 100%    |
| Average blending in global gas-fired generation (without CCUS)  | 0%      | 9%      | 85%     |
| Unabated fossil fuels                                           |         |         |         |
| Share of unabated coal in total electricity generation          | 35%     | 8%      | 0.0%    |
| Share of unabated natural gas in total electricity generation   | 23%     | 17%     | 0.4%    |
| Nuclear power                                                   | 2016-20 | 2021-30 | 2031-50 |
| Average annual capacity additions (GW)                          | 7       | 17      | 24      |
| Infrastructure                                                  |         |         |         |
| Electricity networks investment in USD billion (2019)           | 260     | 820     | 800     |
| Substations capacity (GVA)                                      | 55 900  | 113 000 | 290 400 |
| Battery storage (GW)                                            | 18      | 590     | 3 100   |
| Public EV charging (GW)                                         | 46      | 1 780   | 12 400  |

Note: GW = gigawatts; GVA = gigavolt amperes.

Transforming the electricity sector in the way envisioned in the NZE involves large capacity additions for all low-emissions fuels and technologies. Global renewables capacity more than triples to 2030 and increases ninefold to 2050. From 2030 to 2050, this means adding more than 600 GW of solar PV capacity per year on average and 340 GW of wind capacity per year including replacements (Figure 3.11), while offshore wind becomes increasingly important

over time (over 20% of total wind additions from 2021 to 2050, compared with 7% in 2020). The  annual  deployment  of  battery  capacity  in  the  electricity  sector  needs  to  scale  up  in parallel, from 3 GW in 2019 to 120 GW in 2030 and over 240 GW in 2040. Retrofitting existing coal- and gas-fired power plants also needs to get underway.

Figure 3.11 ⊳ Solar PV and wind installed capacity in the NZE

<!-- image -->

IEA. All rights reserved.

Solar PV and wind need to scale up rapidly to decarbonise electricity, with total solar PV capacity growing 20-fold and wind 11-fold by 2050

Figure 3.12 ⊳ Global investment in electricity networks in the NZE

<!-- image -->

Electricity network investment triples to 2030 and remains elevated to 2050, meeting new demand, replacing ageing infrastructure and integrating more renewables

Investment in electricity networks will be crucial to achieving this transformation. Global electricity  networks  that  took  over  130 years  to  build  need  to  more  than  double  in  total length by 2040 and increase by another 25% by 2050. Total grid investment needs to rise to USD 820 billion by 2030, and USD 1 trillion in 2040, before falling back after electricity is fully decarbonised and the growth of renewables slows to match demand growth (Figure 3.12). Replacing ageing infrastructure is an important part of network investment through to 2050 in the NZE.

Governments face several key decisions in the electricity sector if they are to follow the pathway to net-zero emissions by 2050 envisioned in the NZE particularly about how to best use  existing  power  plants.  For  retrofits  of  coal-  or  gas-fired  capacity,  either  with  carbon capture or co-firing with hydrogen-based fuels (or full conversion), decisions are needed to support  first-of-a-kind  projects  before  2030  before  widespread  retirement  of  unabated plants becomes necessary. For other fossil fuel power stations, decisions about phase outs are  needed.  Coal-fired  power  plants  should  be  phased  out  completely  by  2040  unless retrofitted, starting with the least-efficient designs by 2030 (Figure 3.13). This would require shutting 870 GW of existing subcritical coal capacity globally (11% of all power capacity) and international collaboration to facilitate substitutes. By 2040, all large-scale oil-fired power plants  should  be  phased  out.  Natural  gas-fired  generation  remains  an  important  part  of electricity supply through to 2050, but strong government support will be needed to ensure that CCUS is deployed soon and on a large scale.

Figure 3.13 ⊳ Coal-fired electricity generation by technology in the NZE

<!-- image -->

IEA. All rights reserved.

Coal-fired power accounted for 27% of global energy CO2 emissions in 2020, and in the NZE, all subcritical plants are phased out by 2030 and all plants without CCUS by 2040

Notes: APC = Announced Pledges Case; IGCC = integrated gasification combined-cycle. Ammonia includes co-firing and full conversion of coal plants.

3

The path to net-zero emissions could be facilitated by early government action to help move several technologies that provide power system flexibility through the demonstration phases and bring them to market. Expanding the set of energy storage technologies to complement batteries and addressing emerging needs for longer duration seasonal storage would be of particular value. Technical solutions to support the stability of power grids with high shares of solar and wind would also benefit from research and development (R&amp;D) support.

There are three important sets of decisions to be made concerning nuclear power: lifetime extensions;  pace  of  new  construction;  and  advances  in  nuclear  power  technology.  In advanced  economies,  decisions  need  to  be  made  about  new  construction  and  the  large number of nuclear power plants that may be retired over the next decade absent action to extend  their lifetimes and  make  the  required  investment.  Without  further  lifetime extensions  and  new  projects  beyond  those  already  under  construction,  nuclear  power output  in  advanced  economies  will  decline  by  two-thirds  over  the  next  two  decades (IEA, 2019). In emerging market and developing economies, there are decisions to be made about the pace of new nuclear power construction. From 2011 to 2020, an average of 6 GW of  new  nuclear  capacity  came  online  each  year.  By  2030,  the  rate  of  new  construction increases to 24 GW per year in the NZE. The third set of decisions concerns the extent of government support for advanced nuclear technologies, particularly those related to small modular reactors and high-temperature gas reactors, both of which can expand markets for nuclear power beyond electricity.

Figure 3.14 ⊳ Additional global alternative capacity needed in a Low Nuclear and CCUS Case

<!-- image -->

IEA. All rights reserved.

Sharply reducing the roles of nuclear power and carbon capture would require even faster growth in solar PV and wind, making achieving the net zero goal more costly and less likely

Note: The Low Nuclear and CCUS Case assumes that global nuclear power output is about 60% lower in 2050 than in the NZE due to no additional lifetime extensions or new nuclear projects in advanced economies and no expansion of the current pace of construction in emerging market and developing economies, and that the amount of coal- and gas-fired capacity equipped with CCUS is 99% lower than in the NZE.

Failing to take timely decisions on nuclear power and CCUS would raise the costs of a netzero emissions pathway and add to the risk of not meeting the goal by placing an additional burden on wind and solar to scale up even more quickly than in the NZE (Figure 3.14). In a Low Nuclear and CCUS Case , we assume that global nuclear power output is 60% lower in 2050 than in the NZE as a result of no additional nuclear lifetime extensions or new projects in advanced economies and no expansion of the current pace of construction in emerging market  and  developing  economies,  and  that  only  the  announced  CCUS  projects  are completed (representing 1% of the CCUS capacity added in the NZE).

Our analysis indicates that the burden of replacing those sources of low-carbon generation would fall mainly on solar PV and wind power, calling for 2 400 GW more capacity than in the  NZE  -  an  amount  far  exceeding  their  combined  global  capacity  in  operation  in  2020 (Figure 3.14). There would also be a need for about 480 GW of battery capacity above and beyond the 3 100 GW deployed in the NZE, plus more than 300 GW of other dispatchable capacity to meet demand in all seasons and ensure system adequacy. This would call for an additional USD 2 trillion investment in power plants and related grid assets (net of lower investment in nuclear and CCUS). Taking account of avoided fuel costs, the estimated total additional cost of electricity to consumers between 2021 and 2050 is USD 260 billion.

## 3.5 Industry

## 3.5.1 Energy and emission trends in the Net-Zero Emissions Scenario

As  the  second-largest  global  source  of  energy  sector  CO   emissions,  industry  has  a  vital 2 contribution to make in achieving the net zero goal. Industrial CO2 emissions  (including from 6 energy use and production processes) totalled about 8.4 Gt in 2020. Advanced economies accounted for around 20% and emerging market and developing economies for around 80%, although complex global supply chains for the production of materials and manufacturing mean  that  advanced  economies  generally  consume  far  more  finished  goods  than  they produce.

Three  heavy  industries  -  chemicals,  steel  and  cement  -  account  for  nearly  60%  of  all industrial energy consumption and around 70% of CO2 emissions from the industry sector. Production  is  highly  concentrated  in  emerging  market  and  developing  economies,  which account for 70-90% of the combined output of these commodities (Figure 3.15). China alone was responsible for almost 60% of both steel and cement production in 2020. These bulk materials  are  essential  inputs  to  our  modern  way  of  life,  with  few  cost-competitive substitutes; the challenge is to carry on producing these materials without emitting CO2.

The outlook for global materials demand in the NZE is one of plateaus and small increases. This is in stark contrast with the growth seen during the last two decades when global steel

6 All  CO   emissions in this section refer to direct CO2 emissions from the industry sector unless otherwise 2 specified.

3

demand rose by 2.1-times, cement by 2.4-times and plastics (a key group of material outputs from  the  chemical  sector)  by  1.9-times  in  response  to  global  economic  and  population expansion.  When  economies  are  developing,  per  capita  material  demand  tends  to  rise rapidly to build up stocks of goods and infrastructure. As economies mature, future demand stems primarily from the need to refurbish and replace these stocks, the levels of which tend to saturate. In the NZE, flattening or even declining demand in many countries around the world leads to slower global demand growth. Some countries such as India see higher growth in steel and cement production, while production in China declines considerably following its industrial boom period after the turn of the millennium.

Figure 3.15 ⊳ Global CO2 emissions from industry by sub-sector in the NZE

<!-- image -->

IEA. All rights reserved.

The majority of residual emissions in industry in 2050 come from heavy industries in emerging market and developing economies

Note: Other includes the production of aluminium, paper, other non-metallic minerals and other non-ferrous metals, and a series of light industries.

Certain segments of material demand increase rapidly to support the required expansion of energy-related  infrastructure  in  the  NZE,  notably  renewable  electricity  generation  and transport infrastructure. The additional infrastructure required for these two segments by 2050  relative  to  today  alone  contributes  roughly  10%  of  steel  demand  in  2050.  But  coordinated  cross-sectoral strategies, including modal  shifts in transport and  building renovation,  as  well  as  other  changes  in  design,  manufacturing  methods,  construction practices and consumer behaviour, more than offset this increase. Overall, global demand for  steel  in  2050  is  12%  higher  than  today,  primary  chemicals  is  30%  higher  and  cement demand is broadly flat.

CO2 emissions from heavy industry decline by 20% by 2030 and 93% by 2050 in the NZE. Optimising the operational efficiency of equipment, adopting the best available technologies for new capacity additions and measures to improve material efficiency play an important

part  in  this.  However,  there  are  limits  to  how  much  emissions  can  be  reduced  by  these measures.  Almost  60%  of  emissions  reductions  in  2050  in  the  NZE  are  achieved  using technologies that are under development today (large prototype or demonstration scale) (Figure 3.16).

Figure 3.16 ⊳ Global CO2 emissions in heavy industry and reductions by mitigation measure and technology maturity category in the NZE

<!-- image -->

An array of measures reduces emissions in heavy industry, with innovative technologies like CCUS and hydrogen playing a critical role

Hydrogen  and  CCUS  technologies  together  contribute  around  50%  of  the  emissions reductions in heavy industry in 2050 in the NZE. These technologies enable the provision of large amounts of high-temperature heat, which in many cases cannot be easily provided by electricity with current technologies, and help to reduce process emissions from the chemical reactions inherent in some industrial production. Bioenergy also makes a contribution in a wide array of industrial applications.

Aside from the need for high-temperature heat and process emissions, two factors explain the slower pace of emissions reductions in heavy industries relative to other areas of the energy system. First, the ease with which many industrial materials and products can be traded globally means that markets are competitive and margins are low. This leaves little room to absorb additional costs stemming from the adoption of more expensive production pathways. It will take time to develop robust global co-operation and technology transfer frameworks  or  domestic  solutions  to  enable  a  level  playing  field  for  these  technologies. Second, heavy industries use capital-intensive and long-lived equipment, which slows the deployment of innovative low-emission technologies. Capacity additions in  the  period  to 2030 - before a large-scale roll-out of innovative processes can take place - largely explain the persistence of industrial emissions in 2050, more than 80% of which are in emerging market and developing economies. Strategically timed investment in low-carbon technologies could help minimise early retirements (Box 3.1).

3

## Box 3.1 ⊳ Investment cycles in heavy industry

For heavy industry, the year 2050 is just one investment cycle away. Average lifetimes of emissions-intensive assets such as blast furnaces and cement kilns are around 40 years. After about 25 years of operation, however, plants often undergo a major refurbishment to extend their lifetimes.

The challenge is to ensure that innovative near-zero emissions industrial technologies that are at large prototype and demonstration stage today reach markets within the next decade, when around 30% of existing assets will have reached 25 years of age and thus face an investment decision. If these innovative technologies are not ready, or not used even  if  ready,  this  would  have  a  major  negative  impact  on  the  pace  of  emissions reductions or risk an increase in stranded assets (Figure 3.17). Conversely, if they are ready, and if existing plants are retrofit or replaced with them at the 25-year investment decision point, this could reduce projected cumulative emissions to 2050 from existing heavy industry assets by around 40%. The critical window of opportunity from now to 2030 should not be missed.

Figure 3.17 ⊳ CO2 emissions from existing heavy industrial assets in the NZE

<!-- image -->

Intervening at the end of the next 25-year investment cycle could help unlock 60 Gt CO2, around 40% of projected emissions from existing heavy industry assets

The energy mix in industry changes radically in the NZE. The share of fossil fuels in total energy use declines from around 70% today to 30% in 2050. The vast majority of fossil fuels still being used then are in heavy industries, mainly as chemical feedstock (50%) or in plants equipped  with  CCUS  (around  30%).  Electricity  is  the  dominant  fuel  in  industrial  energy demand growth, with its share of total industrial energy consumption rising from 20% in 2020 to 45% in 2050. Some 15% of this electricity is used to produce hydrogen. Bioenergy plays an important role, contributing 15% of total energy use in 2050, but sustainable supplies are

limited, and it is also in high demand in the power and transport sectors. Renewable solar and geothermal technologies to provide heat make a small but fast growing contribution (Figure 3.18).

Figure 3.18 ⊳ Global final industrial energy demand by fuel in the NZE

<!-- image -->

IEA. All rights reserved.

Fossil fuel use in industry is halved by 2050, replaced primarily by electricity and bioenergy

Notes: Industrial energy consumption includes chemical feedstock and energy consumed in blast furnaces and coke ovens. Hydrogen refers to imported hydrogen and excludes captive hydrogen generation. Electricity for hydrogen refers to electricity used in the production of captive hydrogen via electrolysis.

## Chemicals production

In the NZE, emissions from the chemicals sub-sector fall from 1.3 Gt in 2020 to 1.2 Gt in 2030 and around 65 Mt in 2050. The share of fossil fuels in total energy use falls from 83% in 2020 (mostly oil and natural gas), to 76% in 2030 and 61% in 2050. Oil remains the largest fuel used in primary chemicals production by 2050 in the NZE, along with smaller quantities of gas and coal.

Technologies  that  are  currently  available  on  the  market  account  for  almost  80%  of  the emissions savings achieved globally in the chemical industry by 2030 in the NZE relative to today.  They  include  recycling  and  re-use  of  plastics  and  more  efficient  use  of  nitrogen fertilisers, which reduce the demand for primary chemicals, and measures to increase energy efficiency. Beyond 2030, the bulk of emissions reductions result from the use of technologies whose integration in chemical processes is under development today, including certain CCUS applications and electrolytic hydrogen generated directly from variable renewable electricity (Figure 3.19).  CCUS-equipped  conventional  routes  and  pyrolysis  technologies  are  most competitive in regions with access to low cost natural gas, while electrolysis is the favoured option in regions where the deployment of CCUS is impeded by a lack of infrastructure or public acceptance.

3

Figure 3.19 ⊳ Global industrial production of bulk materials by production route in the NZE

<!-- image -->

IEA. All rights reserved.

Near-zero emissions routes dominate cement, primary steel and chemicals production by 2050, with key roles for CCUS and hydrogen-based technologies

Notes: CCUS = carbon capture, utilisation and storage. Chemicals refers to the production of primary chemicals (ethylene, propylene, benzene, toluene, mixed xylenes, ammonia and methanol). Steel refers to primary steel production.  Other  includes  innovative  processes  that  utilise  bioenergy  and  directly  electrify  production. Hydrogen-based refers to electrolytic hydrogen. Fossil fuel-based hydrogen with CCUS is included in the CCUSequipped category.

## Iron and steel production

In the NZE, global CO2 emissions from the iron and steel sub-sector fall from 2.4 Gt in 2020 to 1.8 Gt in 2030 and 0.2 Gt in 2050, as the unabated use of fossil fuels falls sharply. Their share  of  the  overall  fuel  mix  drops  from  85%  today  to  just  over  30%  in  2050.  The  steel industry remains one of the last sectors using significant amounts of coal in 2050, primarily due to its importance as a chemical reduction agent, albeit mostly in conjunction with CCUS.

The NZE sees a radical technological transformation of the iron and steel sub-sector based largely on a major shift from coal to electricity. By 2050, electricity and other non-fossil fuels account for nearly 70% of final energy demand in the sector, up from just 15% in 2020. This shift  is  driven  by  technologies  such  as  scrap-based  electric  arc  furnaces  (EAF),  hydrogenbased  direct  reduced  iron  (DRI)  facilities,  iron  ore  electrolysis  and  the  electrification  of ancillary equipment. The share of coal in total energy use drops from 75% in 2020 to 22% by 2050 in the NZE, of which 90% is used in conjunction with CCUS.

Technologies that are currently on the market deliver around 85% of emissions savings in steel production to 2030. They include material and energy efficiency measures and a major increase in scrap-based production - which requires only around one-tenth of the energy of primary steel production - driven primarily by increased scrap availability as more products reach their end-of-life. Partial hydrogen injection into commercial blast furnaces and DRI

furnaces gain pace in the mid-2020s, building on pilot projects testing the practice today. After 2030, the bulk of emission reductions come from the use of technologies that are under development, including hydrogen-based DRI and iron ore electrolysis. Several CCUS-equipped process technologies are deployed in parallel, including innovative smelting reduction,  natural  gas-based  DRI  production  (particularly  in  regions  with  low  natural  gas prices) and innovative blast furnace retrofit arrangements in regions with relatively young plants.

## Cement production

Producing a tonne of cement today generates around 0.6 tonnes CO2 on average, two-thirds of which are process emissions generated from carbon released from the raw materials used. Fossil fuels - mostly coal plus some petroleum coke - account for 90% of thermal energy needs.

Increased blending of alternative materials into cement to replace a portion of clinker (the active  and  most  emissions-intensive  ingredient),  lower  demand  for  cement  and  energy efficiency  measures deliver around 40% of the emissions savings in 2030 compared with 2020. Through use of blended cements, the global clinker-to-cement ratio declines from 0.71 in 2020 to 0.65 in 2030. The ratio continues to decline after 2030, but more slowly, reaching 0.57  in  2050  (blended  cements  could  reach  a  clinker-to-cement  ratio  as  low  as  0.5,  but market application potential depends on regional contexts). Limestone and calcined clay are the main alternative materials used in blended cements by 2050. Since 0.5 is the lowest technically achievable clinker-to-cement ratio, other measures are needed to achieve deeper emission reductions.

After 2030 in the NZE, the bulk of emissions reductions come from the use of technologies that  are  under  development  today.  CCUS  is  the  most  important,  accounting  for  55%  of reductions in 2050 relative to today. In many cases, it is more cost-effective in the NZE to apply  CCUS  to  fossil  fuel  combustion  emissions  than  to  switch  to  zero-emissions  energy sources. Coal use is eliminated from cement production by 2050, when natural gas accounts for about 40% of thermal energy (up from 15% today), biomass and renewable waste for a further 35% (up from less than 5% today), hydrogen and direct electrification for just about 15%,  and  oil  products  and  non-renewable  waste  for  the  remainder.  Constraints  on  the availability of sustainable biomass supplies prevent it from claiming a higher share. Direct electrification of cement kilns is at the small prototype stage today, and so only starts to be deployed after 2040 on a small scale. From the 2040s, hydrogen provides around 10% of thermal energy needs in cement kilns, although blending of small amounts begins earlier. Innovative types of cement based on alternative binding materials that limit or avoid the generation of process emissions, and even enable CO2 capture during the curing process, are either still at much earlier stages of development relative to other options like CCUS, or have limited applicability.

3

## Box 3.2 ⊳ What about other industry sub-sectors?

Steel, cement and chemicals are not the only outputs from the industry sector. It also includes  other  energy-intensive  sub-sectors  such  as  aluminium,  paper,  other  nonmetallic  minerals  and  non-ferrous  metals,  as  well  as  light  industries  that  produce vehicles, machinery, food, timber, textiles and other consumer goods, together with the energy consumed in construction and mining operations.

Emissions from the light industries decline by around 30% by 2030 and around 95% by 2050 in the NZE. In contrast to the heavy industries, most of the technologies required for deep emission reductions in these sub-sectors are available on the market and ready to deploy. This is in part because more than 90% of total heat demand is low/mediumtemperature, which can be more readily and efficiently electrified.

Figure 3.20 ⊳ Share of heating technology by temperature level in light industries in the NZE

<!-- image -->

IEA. All rights reserved.

The share of electricty in satisfying heat demand for light industries rises from less than 20% today to around 40% in 2030 and about 65% in 2050

Notes: Light industries excludes non-specified industrial energy consumption. Low/medium-temperature heat corresponds to 0-400 °C and high-temperature heat to &gt;400 °C. Other heat sources includes solar thermal and geothermal heaters, as well as imported heat from the power and fuel transformation sector.

Electricity accounts for around 40% of heat demand by 2030 and about 65% by 2050. For low- (&lt;100 °C) and some medium- (100-400 °C) temperature heat, electrification includes an important role for heat pumps (accounting for about 30% of total heat demand in 2050). In the NZE, around 500 MW of heat pumps need to be installed every month over the next 30 years. Along with electrification, there are smaller roles for hydrogen and bioenergy for high-temperature heat (&gt;400 °C), accounting for around 20% and around 15% respectively of total energy demand in 2050 (Figure 3.20). The rate of electrolyser capacity deployment is much lower than heavy industries, but the unit sizes will also be

much  smaller.  About  5%  of  heat  demand  is  satisfied  by  direct  use  of  renewables, including solar thermal and geothermal heating technologies.

Energy  efficiency  also  plays  a  critical  role  in  these  manufacturing  industries,  notably through  increased  efficiency  in  electric  motors  (conveyers,  pumps  and  other  driven systems). By 2030, 90% of the motor sales in other industries are Class 3 or above.

## 3.5.2 Key milestones and decision points

Table 3.3 ⊳ Key milestones in transforming global heavy industry sub-sectors

Category

Heavy industry

-  2035: virtually, all capacity additions are innovative low-emissions routes.

Industrial motors



2035: all electric motors sales are best in class.

| Category                                                  | 2020   | 2030   | 2050   |
|-----------------------------------------------------------|--------|--------|--------|
| Total industry                                            |        |        |        |
| Share of electricity in total final consumption           | 21%    | 28%    | 46%    |
| Hydrogen demand (Mt H 2 )                                 | 51     | 93     | 187    |
| CO 2 captured (Mt CO 2 )                                  | 3      | 375    | 2 800  |
| Chemicals                                                 |        |        |        |
| Share of recycling: reuse in plastics collection          | 17%    | 27%    | 54%    |
| reuse in secondary production                             | 8%     | 14%    | 35%    |
| Hydrogen demand (Mt H 2 )                                 | 46     | 63     | 83     |
| with on-site electrolyser capacity (GW)                   | 0      | 38     | 210    |
| Share of production via innovative routes                 | 1%     | 13%    | 93%    |
| CO 2 captured (Mt CO 2 )                                  | 2      | 70     | 540    |
| Steel                                                     |        |        |        |
| Recycling, re-use: scrap as share of input                | 32%    | 38%    | 46%    |
| Hydrogen demand (Mt H 2 )                                 | 5      | 19     | 54     |
| with on-site electrolyser capacity (GW)                   | 0      | 36     | 295    |
| Share of primary steel production: hydrogen-based DRI-EAF | 0%     | 2%     | 29%    |
| iron ore electrolysis-EAF                                 | 0%     | 0%     | 13%    |
| CCUS-equipped processes                                   | 0%     | 6%     | 53%    |
| CO 2 captured                                             | 1      | 70     | 670    |
| Cement                                                    |        |        |        |
| Clinker to cement ratio                                   | 0.71   | 0.65   | 0.57   |
| Hydrogen demand (Mt H 2 )                                 | 0      | 2      | 12     |
| Share of production via innovative routes                 | 0%     | 9%     | 93%    |
| CO 2 captured (Mt CO 2 )                                  | 0      | 215    | 1 355  |

Note:  DRI = direct reduced iron; EAF = electric arc furnace.

From 2030 onwards, all  new  capacity  additions  in  industry  in  the  NZE  feature  near-zero emissions technologies. Much of the heavy industry capacity that will be added and replaced

in  the  coming  years  is  in  emerging  market  and  developing  economies;  they  may  expect financial support from advanced economies. Each month from 2030 to 2050, the NZE implies an additional 10 industrial plants equipped with CCUS, three additional fully hydrogen-based industrial plants and 2 GW of extra electrolyser capacity at industrial sites. While challenging, this is achievable. For comparison, about 12 heavy industrial facilities were built from scratch on average per month in China alone from 2000 to 2015. By 2050, nearly all production in heavy industry is with near-zero emissions technologies.

Decisive action from governments is imperative to achieve clean energy transitions in heavy industry at the scale and pace envisioned in the NZE. Within the next two years, governments in advanced economies will need to take decisions about funding for R&amp;D for critical nearzero emissions industrial technologies and for mitigating the investment risks associated with demonstrating  them  at  scale.  This  should  lead  to  at  least  two  or  three  commercial demonstration projects for each technology in different regions, and to market deployment by the mid-2020s. International co-ordination and co-operation would facilitate better use of resources and help prevent gaps in funding.

Governments  also  need  to  take  early  decisions  on  large-scale  deployment  of  near-zero emissions technologies. By 2024 in advanced economies and 2026 in emerging market and developing economies, governments should have in place a strategy for incorporating nearzero emissions technologies into the next series of capacity additions and replacements for steel and chemical plants, which should include decisions about whether to pursue CCUS, hydrogen or a combination of both. If they are to succeed, those strategies need to include concrete plans for developing and financing the necessary infrastructure for CCUS and/or hydrogen, together with clean electricity generation for hydrogen  production. The construction of the required infrastructure should begin as soon as possible given the long lead-times involved.

Within a similar timeframe, governments of countries that produce cement should decide how  to  develop  the  necessary  CCUS  infrastructure  for  that  sub-sector,  including  the necessary legal and regulatory frameworks. Importing countries should make plans to move progressively  to  exclusive  use  of  low-emissions  cement,  which  may  involve  the  need  to support the development of CCUS-equipped facilities elsewhere in order to ensure supplies and to avoid a disproportionate burden being placed on other countries.

Strategies must be underpinned by specific policies. By 2025, all countries should have a longterm CO2 emissions reduction policy framework in place to provide certainty that the next wave  of  investment  in  capacity  additions  will  feature  near-zero  emissions  technologies. Successful  strategies  are  likely  to  require  initial  measures  such  as  carbon  contracts  for difference, public procurement and incentives to encourage private sector procurement. As new technologies are deployed and costs decline, there is likely to be a strong case by about 2030 for replacing these initial measures with others such as CO2 taxes, emissions trading systems and emissions performance standards. Financing support for near-zero emissions capacity additions may also have an important role to play through measures such as low interest and concessional loans and blended finance, as well as through contributions by

advanced  economies  to  funds  that  support  projects  in  emerging  market  and  developing economies. Strategies should also include measures to reduce industrial emissions through material  efficiency,  for  example  by  revising  design  regulations,  adopting  incentives  to promote longer product and building lifetimes, and improving systems for collecting and sorting materials for recycling.

There is a strong case for an international agreement on the transition to near-zero emissions for  globally  traded  products  by  the  mid-2020s  so  as  to  establish  a  level  playing  field. Alternatively,  countries  may  need  to  resort  to  measures  to  shield  domestic  near-zero emissions production from competition from products that create emissions. Any such policy would need to be designed to respect the regulatory frameworks governing international trade, such as those of the World Trade Organization.

Even with accelerated innovation timelines and strong policies in place, some high-emitting capacity  additions  will  be  needed  to  meet  demand  in  the  next  decade  before  near-zero emissions technologies are available. It would make sense for governments to require any new capacity to incorporate retrofit-ready designs so that unabated capacity added in the next  few  years  has  the  technical  capacity  and  space  requirement  to  integrate  near-zero emissions technologies in coming years. Beyond 2030, investment in the NZE is confined to innovative near-zero emissions process routes.

Governments should not overlook the need for measures to spur deployment of already available  near-zero  emissions  technologies  in  light  manufacturing  industries.  Adopting  a carbon price and then sufficiently increasing the price over time - through carbon taxes or emissions trading systems for larger manufacturers - may be the simplest way to achieve that objective. Other regulatory measures such as tradeable low-carbon fuel and emissions standards could yield the same outcome, but may involve greater administrative complexity. Technology mandates are likely to be needed to achieve the energy efficiency savings in the NZE, such as minimum energy performance standards for new motors and boilers. Tailored programmes and incentives for small and medium enterprises could also play a helpful role.

## 3.6 Transport

## 3.6.1 Energy and emission trends in the Net-Zero Emissions Scenario

The global transport sector emitted over 7 Gt CO2 in 2020, and nearly 8.5 Gt in 2019 before the Covid-19 pandemic. 7 In the NZE, transport sector CO2 emissions are slightly over 5.5 Gt in 2030. By 2050 they are around 0.7 Gt - a 90% drop relative to 2020 levels. CO2 emissions decline even with rapidly rising passenger travel, which nearly doubles by 2050, and rising freight activity, which increases by two-and-a-half-times from current levels, and an increase in the global passenger car fleet from 1.2 billion vehicles in 2020 to close to 2 billion in 2050.

7 Unless otherwise noted, CO2 emissions reported here are direct emissions from fossil fuel combusted during the operation of vehicles.

3

The  transport  modes  do  not  decarbonise  at  the  same  rate  because  technology  maturity varies markedly between them (Figure 3.21). CO2 emissions from two/three-wheelers almost cease by 2040, followed by cars, vans and rail in the late 2040s. Emissions from heavy trucks, shipping  and  aviation  fall  by  an  annual  average  of  6%  between  2020  and  2050,  but  still collectively amount to more than 0.5 Gt CO2 in 2050. This reflects projected activity growth and that many of the technologies needed to reduce CO2 emissions in long distance transport are  currently  under  development  and  do  not  start  to  make  substantial  inroads  into  the market in the coming decade.

Figure 3.21 ⊳ Global CO2 transport emissions by mode and share of emissions reductions to 2050 by technology maturity in the NZE

<!-- image -->

Passenger cars can make use of low-emissions technologies on the market, but major advances are needed for heavy trucks, shipping and aviation to reduce their emissions

Notes:  Other  road  =  two/three  wheelers  and  buses.  Shipping  and  aviation  include  both  domestic  and international operations. See Box 2.4 for details on the maturity categories.

Decarbonisation of the transport sector in the NZE relies on policies to promote modal shifts and more efficient operations across passenger transport modes (see sections 2.5.7 and 4.4.3),  as well as improvements in energy efficiency. It also depends on two major 8 technology transitions: shifts towards electric mobility (electric vehicles [EVs] and fuel cell electric vehicles [FCEVs])  and shifts towards higher fuel blending ratios and direct use of 9

8 Examples  of  efficient  operations  include:  seamless  integration  of  various  modes  (inter-modality)  and 'Mobility as a Service' in passenger transport; logistics measures in road freight, e.g. backhauling, night-time deliveries, real-time routing; slow steaming in shipping; and air traffic management, e.g. landing and take-off scheduling in aviation.

9 EVs include battery electric vehicles, plug-in hybrid electric-gasoline vehicles and plug-in hybrid electric-diesel vehicles. FCEVs contain a battery and electric motor and are capable of operating without tailpipe emissions.

low-carbon  fuels  (biofuels  and  hydrogen-based  fuels).  These  shifts  are  likely  to  require interventions to stimulate investment in supply infrastructure and to incentivise consumer uptake.

Transport has traditionally been heavily reliant on oil products, which accounted for more than  90%  of  transport  sector  energy  needs  in  2020  despite  inroads  from  biofuels  and electricity (Figure 3.22). In the NZE, the share of oil drops to less than 75% in 2030 and slightly over 10% by 2050. By the early 2040s, electricity becomes the dominant fuel in the transport sector worldwide in the NZE: it accounts for nearly 45% of total final consumption in 2050, followed by hydrogen-based fuels (28%) and bioenergy (16%). Biofuels almost reach a 15% blending share in oil products by 2030 in road transport, which reduces oil needs by around 4.5 million barrels of oil equivalent per day (mboe/d). Beyond 2030, biofuels are increasingly used for aviation and shipping, where the scope for using electricity and hydrogen is more limited. Hydrogen carriers (such as ammonia) and low-emissions synthetic fuels also supply increasing shares of energy demand in these modes.

Figure 3.22 ⊳ Global transport final consumption by fuel type and mode in the NZE

<!-- image -->

IEA. All rights reserved.

Electricity and hydrogen-based fuels account for more than 70% of transport energy demand by 2050

Note: LDVs = Light-duty vehicles; Other road = two/three wheelers and buses.

## Road vehicles

Electrification  plays  a  central role  in  decarbonising  road  vehicles  in  the  NZE.  Battery  cost declines of almost 90% in a decade have boosted sales of electric passenger cars by 40% on average  over  the  past  five  years.  Battery  technology  is  already  relatively  commercially competitive. FCEVs start to make inroads in the 2020s in the NZE. The electrification of heavy trucks  moves  more  slowly  due  to  the  weight  of  the  batteries,  high  energy  and  power

3

requirements required for charging, and limits on driving ranges. But fuel cell heavy trucks make significant progress, mainly after 2030 (Figure 3.23). The number of battery electric, plug-in hybrid and fuel cell electric light-duty vehicles (cars and vans) on the world's roads reaches 350 million in 2030 and almost 2 billion in 2050, up from 11 million in 2020. The number of electric two/three-wheelers also rises rapidly, from just under 300 million today to 600 million in 2030 and 1.2 billion in 2050. The electric bus fleet expands from 0.5 million in 2020 to 8 million in 2030 and 50 million in 2050.

Figure 3.23 ⊳ Global share of battery electric, plug-in hybrid and fuel cell electric vehicles in total sales by vehicle type in the NZE

<!-- image -->

Sales of battery electric, plug-in hybrid and fuel cell electric vehicles soar globally

Note: Light-duty vehicles = passenger cars and vans; Heavy trucks = medium- and heavy-freight trucks.

Light-duty vehicles are electrified faster in advanced economies over the medium term and account  for  around  75%  of  sales  by  2030.  In  emerging  and  developing  economies,  they account for about 50% of sales. Almost all light-duty vehicle sales in advanced economies are battery electric, plug-in hybrid or fuel cell electric by the early 2030s and in emerging and developing economies by the mid-2030s.

For heavy trucks that operate over long distances, currently biofuels are the main viable commercial alternative to diesel, and they play an important role in lowering emissions from heavy-duty  trucks  over  the  2020s.  Beyond  2030,  the  number  of  electric  and  hydrogenpowered heavy trucks increases in the NZE as supporting infrastructure is built and as costs decline (lower battery costs, energy density improvements and lower costs to produce and deliver  hydrogen)  (IEA,  2020b).  This  coincides  with  a  reduction  in  the  availability  of sustainable bioenergy, as limited supplies increasingly go to hard-to-abate segments such as aviation and shipping, though biofuels still meet about 10% of fuel needs for heavy-duty trucks in 2050 (see Chapter 2). Advanced economies have a higher market share of battery

electric and fuel cell electric heavy-duty trucks sales in 2030, more than twice the level in emerging market and developing economies, although this gap closes towards 2050.

Figure 3.24 ⊳ Heavy trucks distribution by daily driving distance, 2050

<!-- image -->

Driving distance is the key factor affecting powertrain choice for trucks

Realising the objectives of the NZE depends on rapid scaling up of battery manufacturing (current announced production capacity for 2030 would cover only 50% of required demand in  that  year),  and  on  the  rapid  introduction  on  the  market  of  next  generation  battery technology (solid state batteries) between 2025 and 2030. Electrified road systems using conductive or inductive power transfer to provide electricity to trucks offer an alternative for battery electric and fuel cell electric trucks on long-distance operations, but these systems too would need rapid development and deployment.

## Aviation 10

The NZE assumes that air travel, measured in revenue-passenger kilometres, increases by only around 3% per year to 2050 relative to 2020. This compares with about around 6% over the 2010-19 period. The NZE assumes that aviation growth is constrained by comprehensive government policies that promote a shift towards high-speed rail and rein in expansion of long-haul business travel, e.g. through  taxes on  commercial  passenger  flights (see section 2.5.2).

Global CO2 emissions from aviation rise in the NZE from about 640 Mt in 2020 (down from around 1 Gt in 2019) to a peak of 950 Mt by around 2025. Emissions then fall to 210 Mt in 2050 as the use of low-emissions fuels grows. Emissions are hard to abate because aviation

10 Aviation  considered  here  includes  both  domestic  and  international  flights.  While  the  focus  here  is  on commercial  passenger  aviation,  dedicated  freight  and  general  (military  and  private)  aviation,  which collectively account for more than 10% of fuel use and emissions, are also included in the energy and emissions accounting.

3

requires fuel with a high energy density. Emissions in aviation comprise just over 10% of unabated CO2 emissions from fossil fuels and industrial processes in 2050.

In the NZE, the global use of jet kerosene declines to about 3 EJ in 2050 from 9 EJ in 2020 (and around 14.5 EJ in 2019 before the Covid-19 crisis), and its share of total energy use falls from  almost  100%  to  just  over  20%.  The  use  of  sustainable  aviation  fuel  (SAF)  starts  to increase significantly in the late-2020s. In 2030, around 15% of total fuel consumption in aviation is SAF, most of which is biojet kerosene (a type of liquid biofuel). This is estimated to increase the ticket price for a mid-haul flight (1 200 km) by about USD 3 per passenger. By 2050,  biojet  kerosene  meets  45%  of  total  fuel  consumption  in  aviation  and  synthetic hydrogen-based fuels meet about 30%. This is estimated to increase the ticket price for a mid-haul flight in 2050 by about USD 10 per passenger. The NZE also sees the adoption of commercial battery electric and hydrogen aircraft from 2035, but they account for less than 2% of fuel consumption in 2050.

Operational  improvements,  together  with  fuel  efficiency  technologies  for  airframes  and engines, also help to reduce CO2 emissions by curbing the pace of fuel demand growth in the NZE.  These  improvements  are  incremental,  but  revolutionary  technologies  such  as  open rotors, blended wing-body airframes and hybridisation could bring further gains and enable the industry to meet the International CiviI Aviation Organization's (ICAO) ambitious 2050 efficiency targets (IEA, 2020b).

## Maritime shipping 11

Maritime  shipping  was  responsible  for  around  830 Mt  CO2  emissions  worldwide  in  2020 (880 Mt CO2 in 2019), which is around 2.5% of total energy sector emissions. Due to a lack of available  low-carbon  options  on  the  market  and  the  long  lifetime  of  vessels  (typically 25-35 years),  shipping  is  one  of  the  few  transport  modes  that  does  not  achieve  zero emissions by 2050 in the NZE. Nevertheless, emissions from shipping decline by 6% annually to 120 Mt CO2 in 2050.

In the short term, there is considerable potential for curbing fuel consumption in shipping through measures to optimise operational efficiency and improve energy efficiency. Such approaches include slow steaming and the use of wind-assistance technologies (IEA, 2020b). In  the  medium to long term, significant emissions reductions are achieved in the NZE by switching to low-carbon fuels such as biofuels, hydrogen and ammonia. Ammonia looks likely to  be  a  particularly  good  candidate  for  scaling  up,  and  a  critical  fuel  for  long-range transoceanic journeys that need fuel with high energy density.

Ammonia and hydrogen are the main low-carbon fuels for shipping adopted over the next three decades in the NZE, their combined share of total energy consumption in shipping reaching around 60% in 2050. The 20 largest ports in the world account for more than half of global cargo (UNCTAD, 2018); they could become industrial hubs to produce hydrogen and

11 Maritime shipping here includes both domestic and international operations.

ammonia for use in both chemical and refining industries, as well as for refuelling ships. Internal combustion engines for ammonia-fuelled vessels are currently being developed by two of the largest manufacturers of maritime engines and are expected to become available on the market by 2024. Sustainable biofuels provide almost 20% of total shipping energy needs in 2050. Electricity plays a very minor role, as the relatively low energy density of batteries  compared  with  liquid  fuels  makes  it  suitable  only  for  shipping  routes  of  up  to 200 km.  Even  with  an  85%  increase  in  battery  energy  density  in  the  NZE  as  solid  state batteries come to market, only short-distance shipping routes can be electrified.

## Rail

Rail transport is the most energy-efficient and least carbon-intensive way to move people and second only to shipping for carrying goods. Passenger rail almost doubles its share of total transport activity to 20% by 2050 in the NZE, with particularly rapid growth in urban and high-speed rail (HSR), the latter of which contributes to curbing growth in air travel. Global CO2 emissions from the rail sector fall from 95 Mt CO2 in 2020 (100 Mt CO2 in 2019) to almost zero by 2050 in the NZE, driven primarily by rapid electrification.

Figure 3.25 ⊳ Global energy consumption by fuel and CO2 intensity in non-road sectors in the NZE

<!-- image -->

IEA. All rights reserved.

Railways rely heavily on electricity to decarbonise, while shipping and aviation curb emissions mainly by switching to low-emissions fuels

Note: Synthetic fuel = low-emissions synthetic hydrogen-based fuels.

In the NZE, all new tracks on high-throughput corridors are electrified from now on, while hydrogen and battery electric trains, which have recently been demonstrated in Europe, are adopted on rail lines where throughput is too low to make electrification economically viable. Oil use, which accounted for 55% of total energy consumption in the rail sector in 2020, falls to almost zero in 2050: it is replaced by electricity, which provides over 90% of rail energy needs and by hydrogen which provides another 5%.

3

## 3.6.2 Key milestones and decision points

## Table 3.4 ⊳ Key milestones in transforming the global transport sector

| Category              |                                                                                              |
|-----------------------|----------------------------------------------------------------------------------------------|
| Road transport        |  2035: no new passenger internal combustion engine car sales globally                       |
| Aviation and shipping |  Implementation of strict carbon emissions intensity reduction targets as soon as possible. |

| Category                                                                  | 2020   | 2030   | 2050   |
|---------------------------------------------------------------------------|--------|--------|--------|
| Road transport                                                            |        |        |        |
| Share of PHEV, BEV and FCEV in sales: cars                                | 5%     | 64%    | 100%   |
| two/three-wheelers                                                        | 40%    | 85%    | 100%   |
| bus                                                                       | 3%     | 60%    | 100%   |
| vans                                                                      | 0%     | 72%    | 100%   |
| heavy trucks                                                              | 0%     | 30%    | 99%    |
| Biofuel blending in oil products                                          | 5%     | 13%    | 41%    |
| Rail                                                                      |        |        |        |
| Share of electricity and hydrogen in total energy consumption             | 43%    | 65%    | 96%    |
| Activity increase due to modal shift (index 2020=100)                     | 100    | 100    | 130    |
| Aviation                                                                  |        |        |        |
| Synthetic hydrogen-based fuels share in total aviation energy consumption | 0%     | 2%     | 33%    |
| Biofuels share in total aviation energy consumption                       | 0%     | 16%    | 45%    |
| Avoided demand from behaviour measures (index 2020=100)                   | 0      | 20     | 38     |
| Shipping                                                                  |        |        |        |
| Share in total shipping energy consumption: Ammonia                       | 0%     | 8%     | 46%    |
| Hydrogen                                                                  | 0%     | 2%     | 17%    |
| Bioenergy                                                                 | 0%     | 7%     | 21%    |
| Infrastructure                                                            |        |        |        |
| EV public charging (million units)                                        | 1.3    | 40     | 200    |
| Hydrogen refuelling units                                                 | 540    | 18 000 | 90 000 |
| Share of electrified rail lines                                           | 34%    | 47%    | 65%    |

Note: PHEV = plug-in hybrid electric vehicles; BEV = battery electric vehicles; FCEV = fuel cell electric vehicles.

Electrification  is  the  main  option  to  reduce  CO   emissions  from  road  and  rail  modes,  the 2 technologies are already on the market and should be accelerated immediately, together with the roll-out of recharging infrastructure for EVs. Deep emission reductions in the hardto-abate  sectors  (heavy  trucks,  shipping  and  aviation)  require  a  massive  scale  up  of  the required technologies over the next decade, which today are largely at the prototype and demonstration stages, together with plans for the development of associated infrastructure, including hydrogen refuelling stations.

The transformation of transport required to be on track to reduce emissions in line with the NZE calls for a range of government decisions over the next decade. In the next few years, all  governments  need  to  eliminate  fossil  fuel  subsidies  and  encourage  switching  to  lowcarbon technologies and fuels across the entire transport sector. Before 2025, governments need to define clear R&amp;D priorities for all the technologies that can contribute to decarbonise transport in line with their strategic priorities and needs. Ideally this would be informed by international dialogue and collaboration. R&amp;D is critical in particular for battery technology, which should be an immediate priority.

To achieve the emissions reductions required by the NZE, governments also need to move quickly to signal the end of sales of new internal combustion engine cars. Early commitments would help the private sector to make the necessary investment in new powertrains, relative supply chains and refuelling infrastructure (see section 4.3.4). This is particularly important for the supply of battery metals, which require long-term planning (IEA, 2021a).

By  2025,  the  large-scale  deployment  of  EV  public  charging  infrastructure  in  urban  areas needs to be sufficiently advanced to allow households without access to private chargers to opt  for  EVs.  Governments  should  ensure  sustainable  business  models  for  companies installing chargers, remove barriers to planning and construction, and put in place regulatory, fiscal and technological measures to enable and encourage smart charging, and to ensure that EVs support electricity grid stability and stimulate the adoption of variable renewables (IEA, 2021b).

For  heavy  trucks,  battery  electric  trucks  are  just  beginning  to  become  available  on  the market, and fuel cell electric technologies are expected to come to market in the next few years. Working in collaboration with truck manufacturers, governments should take steps in the near term to prioritise the rapid commercial adoption of battery electric and fuel cell electric  trucks.  By  2030,  they  should  take  stock  of  the  competitive  prospects  for  these technologies, so as to focus R&amp;D on the most important challenges and allow adequate time for strategic infrastructure deployment, thus paving the way for large-scale adoption during the 2030s.

Governments need to define their strategies for low-carbon fuels in shipping and aviation by 2025 at the latest, given the slow turnover rate of the fleets, after which they should rapidly implement them. International  co-operation  and  collaboration  will  be  crucial  to  success. Priority action should target the most heavily used ports and airports so as to maximise the impact of initial investment. Harbours near industrial areas are ideally placed to become lowcarbon fuel hubs.

3

## Box 3.3 ⊳ What would be the implications of an all-electric approach to emissions reductions in the road transport sector?

The use of a variety of fuels in road transport is a core component of the NZE. However, governments might want to consider an all-electric route to eliminate CO2 emissions from transport, especially if other technologies such as FCEVs and advanced biofuels fail to develop as projected. We have therefore developed an All-Electric Case which looks at the implications of electrifying all road vehicle modes. In the NZE, decarbonisation of road transport occurs primarily via the adoption of plug-in hybrid electric vehicles (PHEVs), battery electric vehicles (BEVs), fuel cell electric vehicles (FCEVs) and advanced biofuels. The All-Electric Case assumes the same rate of road transport decarbonisation as the NZE, but achieved via battery electric vehicles alone.

The All-Electric Case depends on even further advances in battery technologies than the NZE that lead to energy densities of at least 400 Watt hours per kilogramme (Wh/kg) by the 2030s at costs that would make BEV trucks preferable to FCEV trucks in long-haul operations. This would mean 30% more BEVs (an additional 350 million) on the road in 2030 than in the NZE. Over sixty five million public chargers would be needed to support the vehicles, requiring a cumulative investment of around USD 300 billion, 35% higher than the NZE. This would require faster expansion of battery manufacturing. The annual global  battery  capacity  additions  for  BEVs  in  2030  would  be  almost  9 TWh,  requiring 80 giga-factories (assuming 35 GWh per year output) more than in the NZE, or an average of over two per month from now to 2030.

The increased use of electricity for road transport would also create additional challenges for the electricity sector. The total electricity demand for road transport (11 000 TWh or 15% of total electricity consumption in 2050), would be roughly the same in both cases, when account is taken of demand for electrolytic hydrogen. However, the electrolytic hydrogen  in  the  NZE  can  be  produced  flexibly,  in  regions  and  at  times  with  surplus renewables-based capacity and from dedicated (off-grid) renewable power. Peak power demand in  the  All-Electric  Case,  taking  into  consideration  the  flexibility  that  enables smart charging of cars, is about one-third (2 000 GW) higher than in the NZE, mainly due to the additional evening/overnight charging of buses and trucks. If not coupled with energy storage devices, ultra-fast chargers for heavy-duty vehicles could cause additional spikes in demand, putting even more strain on electricity grids.

While  full  electrification  of  road  transport  is  possible,  it  could  involve  additional challenges  and  undesirable  side  effects.  For  example,  it  could  increase  pressure  on electricity grids, requiring significant additional investment, and increasing the vulnerability  of  the  transport  system  to  power  disruptions.  Fuel  diversification  could bring benefits in terms of resilience and energy security.

Figure 3.26 ⊳ Global electricity demand and battery capacity for road transport in the NZE and the All-Electric Case

<!-- image -->

Note: AEC = All-Electric Case.

## 3.7 Buildings

## 3.7.1 Energy and emission trends in the Net-Zero Emissions Scenario

Floor area in the buildings sector worldwide is expected to increase 75% between 2020 and 2050, of which 80% is in emerging market and developing economies. Globally, floor area equivalent to the surface of the city of Paris is added every week through to 2050. Moreover, buildings in many advanced economies have long lifetimes and around half of the existing buildings stock will still be standing in 2050. Demand for appliances and cooling equipment continues  to  grow,  especially  in  emerging  market  and  developing  economies  where 650 million air conditioners are added by 2030 and another 2 billion by 2050 in the NZE. Despite this demand growth, total CO2 emissions from the buildings sector decline by more than 95% from almost 3 Gt in 2020 to around 120 Mt in 2050 in the NZE. 12

Energy  efficiency  and  electrification  are  the  two  main  drivers  of  decarbonisation  of  the buildings sector in the NZE (Figure 3.27). That transformation relies primarily on technologies

12 All  CO   emissions  in  this  section  refer  to  direct  CO2  emissions  unless  otherwise  specified.  The  NZE  also 2 pursues reductions in emissions linked to construction materials used in buildings. These embodied emissions are cut by 40% per square metre of new floor area by 2030, with material efficiency strategies cutting cement and steel use by 50% by 2050 relative to today through measures at the design, construction, use and end-oflife phases.

already  available  on  the  market,  including  improved  envelopes  for  new  and  existing buildings,  heat  pumps,  energy-efficient  appliances,  and  bioclimatic  and  material-efficient building  design.  Digitalisation  and  smart  controls  enable  efficiency  gains  that  reduce emissions  from  the  buildings  sector  by  350 Mt CO2  by  2050.  Behaviour  changes  are  also important in the NZE, with a reduction of almost 250 Mt CO2 in 2030 reflecting changes in temperature  settings  for  space  heating  or  reducing  excessive  hot  water  temperatures. Additional behaviour changes such as greater use of cold temperature clothes washing and line  drying,  facilitate  the  decarbonisation  of  electricity  supply.  There  is  scope  for  these reductions to be achieved rapidly and at no cost.

Figure 3.27 ⊳ Global direct CO2 emissions reductions by mitigation measure in buildings in the NZE

<!-- image -->

IEA. All rights reserved.

Electrification and energy efficiency account for nearly 70% of buildings-related emissions reductions through to 2050, followed by solar thermal, bioenergy and behaviour

Notes:  Activity  =  change  in  energy  service  demand  related  to  rising  population,  increased  floor  area  and income per capita. Behaviour = change in energy service demand from user decisions, e.g. changing heating temperatures.  Avoided  demand  =  change  in  energy  service  demand  from  technology  developments,  e.g. digitalisation.

Rapid shifts to zero-carbon-ready technologies see the share of fossil fuels in energy demand in the buildings sector drop to 30% by 2030, and to 2% by 2050 in the NZE. The share of electricity in the energy mix reaches almost 50% by 2030 and 66% by 2050, up from 33% in 2020 (Figure 3.28). All end-uses today dominated by fossil fuels are increasingly electrified in the NZE, with the share of electricity in space heating, water heating and cooking increasing from less than 20% today to more than 40% in 2050. District energy networks and low-carbon gases, including hydrogen-based fuels, remain significant in 2050 in regions with high heating needs, dense urban populations and existing gas or district heat networks. Bioenergy meets nearly one-quarter of overall heat demand in the NZE by 2050, over 50% of bioenergy use is for  cooking,  nearly  all  in  emerging  market  and  developing  economies,  where  2.7 billion

people gain access to clean cooking by 2030 in the NZE. Space heating demand drops by twothirds between 2020 and 2050, driven by improvement in energy efficiency and behavioural changes such as the adjustment of temperature set points.

Figure 3.28 ⊳ Global final energy consumption by fuel and end-use application in buildings in the NZE

<!-- image -->

IEA. All rights reserved.

Fossil fuel use in the buildings sector declines by 96% and space heating energy needs by two-thirds to 2050, thanks mainly to energy efficiency gains

Note: Other includes desalination and traditional use of solid biomass which is not allocated to a specific end-use.

## Zero-carbon-ready buildings

The NZE pathway for the buildings sector requires a step change improvement in the energy efficiency and flexibility of the stock and a complete shift away from fossil fuels. To achieve this,  more than 85% of buildings need to comply with zero-carbon-ready building energy codes  by  2050  (Box 3.4).  This  means  that  mandatory  zero-carbon-ready  building  energy codes for all new buildings need to be introduced in all regions by 2030, and that retrofits need to be carried out in most existing buildings by 2050 to enable them to meet zerocarbon-ready building energy codes.

Retrofit rates increase from less than 1% per year today to about 2.5% per year by 2030 in advanced economies: this means that around 10 million dwellings are retrofitted every year. In emerging market and developing economies, building lifetimes are typically lower than in advanced economies, meaning that retrofit rates by 2030 in the NZE are lower, at around 2% per year. This requires the retrofitting of 20 million dwellings per year on average to 2030. To  achieve  savings  at  the  lowest  cost  and  to  minimise  disruption,  retrofits  need  to  be comprehensive and one-off.

3

## Box 3.4 ⊳ Towards zero-carbon-ready buildings

Achieving  decarbonisation  of  energy  use  in  the  sector  requires  almost  all  existing buildings to undergo a single in-depth retrofit by 2050, and new construction to meet stringent efficiency standards. Building energy codes covering new and existing buildings are  the  fundamental  policy  instrument  to  drive  such  changes.  Building  energy  codes currently exist or are under development in only 75 countries, and codes in around 40 of these countries are mandatory for both the residential and services sub-sectors. In the NZE, comprehensive zero-carbon-ready building codes are implemented in all countries by 2030 at the latest.

## What is a zero-carbon-ready building?

A zero-carbon-ready building is highly energy efficient and either uses renewable energy directly,  or  uses  an  energy  supply  that  will  be  fully  decarbonised  by  2050,  such  as electricity or district heat. This means that a zero-carbon-ready building will become a zero-carbon  building  by  2050,  without  any  further  changes  to  the  building  or  its equipment.

Zero-carbon-ready buildings should adjust to user needs and maximise the efficient and smart  use  of  energy,  materials  and  space  to  facilitate  the  decarbonisation  of  other sectors. Key considerations include:

-  Scope. Zero-carbon-ready building energy codes should cover building operations (scope 1 and 2) as well as emissions from the manufacturing of building construction materials and components (scope 3 or embodied carbon emissions).
-  Energy use. Zero-carbon-ready energy codes should recognise the important part that  passive  design  features,  building  envelope  improvements  and  high  energy performance  equipment  play  in  lowering  energy  demand,  reducing  both  the operating cost of buildings and the costs of decarbonising the energy supply.
-  Energy supply. Whenever possible, new and existing zero-carbon-ready buildings should integrate locally available renewable resources, e.g. solar thermal, solar PV, PV  thermal  and  geothermal,  to  reduce  the  need  for  utility-scale  energy  supply. Thermal  or  battery  energy  storage  may  be  needed  to  support  local  energy generation.
-  Integration  with  power  systems. Zero-carbon-ready  building  energy  codes  need buildings to become a flexible resource for the energy system, using connectivity and automation to manage building electricity demand and the operation of energy storage devices, including EVs.
-  Buildings and construction value chain. Zero-carbon-ready building energy codes should  also  target  net-zero  emissions  from  material  use  in  buildings.  Material efficiency strategies can cut cement and steel demand in the buildings sector by more than a third relative to baseline trends, and embodied emissions can be further reduced  by  more  robust  uptake  of  bio-sourced  and  innovative  construction materials.

## Heating and cooling

Building envelope improvements in zero-carbon-ready retrofit and new buildings account for the majority of heating and cooling energy intensity reductions in the NZE, but heating and cooling technology also makes a significant contribution. Space heating is transformed in the NZE, with homes heated by natural gas falling from nearly 30% of the total today to less than 0.5% in 2050, while homes using electricity for heating rise from nearly 20% of the total today to 35% in 2030 and about 55% in 2050 (Figure 3.29). High efficiency electric heat pumps become the primary technology choice for space heating in the NZE, with worldwide heat pump  installations  per  month  rising  from  1.5 million  today  to  around  5 million  by  2030 and 10 million by 2050. Hybrid heat pumps are also used in some of the coldest climates, but meet no more than 5% of heating demand in 2050.

Figure 3.29 ⊳ Global building and heating equipment stock by type and useful space heating and cooling demand intensity changes in the NZE

<!-- image -->

IEA. All rights reserved.

By 2050, over 85% of buildings are zero-carbon-ready, reducing average useful heating intensity by 75%, with heat pumps meeting over half of heating needs

Notes: ZCRB refers to buildings meeting zero-carbon-ready building energy codes. Other for building envelope refers to envelopes that do not meet zero-carbon-ready building energy codes. Other for heating equipment stock includes resistive heaters, and hybrid and gas heat pumps.

Not all buildings are best decarbonised with heat pumps, however, and bioenergy boilers, solar thermal, district heat, low-carbon gases in gas networks and hydrogen fuel cells all play a role in making the global building stock zero-carbon-ready by 2050. Bioenergy meets 10% of space heating needs by 2030 and more than 20% by 2050. Solar thermal is the preferred renewable technology for water heating, especially where heat demand is low; in the NZE it meets  35%  of  demand  by  2050,  up  from  7%  today.  District  heat  networks  remain  an attractive  option  for  many  compact  urban  centres  where  heat  pump  installation  is impractical, in the NZE they provide more than 20% of final energy demand for space heating in 2050, up from a little over 10% today.

There are no new coal and oil boilers sold globally from 2025 in the NZE. Sales of gas boilers fall by more than 40% from current levels by 2030 and by 90% by 2050. By 2025 in the NZE, any gas boilers that are sold are capable of burning 100% hydrogen and therefore are zerocarbon-ready. The share of low-carbon gases (hydrogen, biomethane, synthetic methane) in gas distributed to buildings rises from almost zero to 10% by 2030 to above 75% by 2050.

Buildings that meet the standards of zero-carbon-ready building energy codes drive down the need not only for space heating but also for space cooling - the fastest growing end-use in  buildings  since  2000.  Space  cooling  represented  only  5%  of  total  buildings  energy consumption worldwide in 2020, but demand for cooling is likely to grow strongly in the coming decades with rising incomes and a hotter climate. In the NZE, 60% of households have an air conditioner in 2050, up from 35% in 2020. High-performance building envelopes, including bioclimatic designs and insulation, can reduce the demand for space cooling by 30-50%, while providing greater resilience during extreme heat events. In the NZE, electricity demand  for  space  cooling  grows  annually  by  1%  to  reach  2 500 TWh  in  2050.  Without 2 000 TWh of savings from residential building envelope improvements and higher efficiency equipment, space cooling demand would be almost twice as high.

## Appliances and lighting

Electric appliances and lighting become much more efficient over the next three decades in the NZE thanks to policy measures and technical advances. By 2025 in the NZE, over 80% of all  appliances  and  air  conditioners  sold  in  advanced  economies  are  the  best  available technologies today in these markets, and this share increases to 100% by the mid-2030s. In emerging market and developing economies, which account for over half of appliances and air conditioners by 2050, the NZE assumes a wave of policy action over the next decade which leads  to  80%  of  equipment  sold  in  these  markets  in  2030  being  as  efficient  as  the  best available technologies in advanced economies today, increasing to close to 100% by 2050 (Figure 3.30). The share of light-emitting diode (LED) lamps in total lightbulb sales reaches 100% by 2025 in all regions. Minimum energy performance standards are complemented by requirements  for  smart  control  of  appliances  to  facilitate  demand-side  response  in  all regions.

Energy use in buildings will be increasingly focused on electric, electronic and connected equipment and appliances. The share of electricity in energy consumption in buildings rises from 33% in 2020 to around two-thirds in 2050 in the NZE, with many buildings incorporating decentralised  electricity  generation  using  local  solar  PV  panels,  battery  storage  and  EV chargers. The number of residential buildings with solar PV panels increases from 25 million to 240 million over the same period. In the NZE, smart control systems shift flexible uses of electricity  in  time  to  correspond  with  generation  from  local  renewables,  or  to  provide flexibility services to the power system, while optimised home battery and EV charging allow households to interact with the grid. These developments help improve electricity supply security  and  lower  the  cost  of  the  energy  transition  by  making  it  easier  and  cheaper  to integrate renewables into the system.

Figure 3.30 ⊳ Global change in electricity demand by end-use in the buildings sector

<!-- image -->

Energy efficiency is critical to mitigate electricity demand growth for appliances and air conditioning, with savings more than offsetting the impact of electrifying heat

## 3.7.2 Key milestones and decision points

Table 3.5 ⊳ Key milestones in transforming global buildings sector

| Category                                                               | Category                                                                          | Category                                                                          | Category                                                                          |
|------------------------------------------------------------------------|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|
| New buildings                                                          |  From 2030: all new buildings are zero-carbon-ready.                             |  From 2030: all new buildings are zero-carbon-ready.                             |  From 2030: all new buildings are zero-carbon-ready.                             |
| Existing buildings                                                     |  From 2030: 2.5% of buildings are retrofitted to be zero-carbon-ready each year. |  From 2030: 2.5% of buildings are retrofitted to be zero-carbon-ready each year. |  From 2030: 2.5% of buildings are retrofitted to be zero-carbon-ready each year. |
| Category                                                               | Category                                                                          | 2020                                                                              | 2030 2050                                                                         |
| Buildings                                                              | Buildings                                                                         |                                                                                   |                                                                                   |
| Share of existing buildings retrofitted to the zero-carbon-ready level | Share of existing buildings retrofitted to the zero-carbon-ready level            | <1%                                                                               | 20% >85%                                                                          |
| Share of zero-carbon-ready new buildings construction                  | Share of zero-carbon-ready new buildings construction                             | 5%                                                                                | 100% 100%                                                                         |
| Heating and cooling                                                    | Heating and cooling                                                               |                                                                                   |                                                                                   |
| Stock of heat pumps (million units)                                    | Stock of heat pumps (million units)                                               | 180                                                                               | 600 1 800                                                                         |
| Million dwellings using solar thermal                                  | Million dwellings using solar thermal                                             | 250                                                                               | 400 1 200                                                                         |
| Avoided residential energy demand from behaviour                       | Avoided residential energy demand from behaviour                                  | n.a.                                                                              | 12% 14%                                                                           |
| Appliances and lighting                                                | Appliances and lighting                                                           |                                                                                   |                                                                                   |
| Appliances: unit energy consumption (index 2020=100)                   | Appliances: unit energy consumption (index 2020=100)                              | 100                                                                               | 75 60                                                                             |
| Lighting: share of LED in sales                                        | Lighting: share of LED in sales                                                   | 50%                                                                               | 100% 100%                                                                         |
| Energy access                                                          | Energy access                                                                     |                                                                                   |                                                                                   |
| Population with access to electricity (billion people)                 | Population with access to electricity (billion people)                            | 7.0                                                                               | 8.5 9.7                                                                           |
| Population with access to clean cooking (billion people)               | Population with access to clean cooking (billion people)                          | 5.1                                                                               | 8.5 9.7                                                                           |
| Energy infrastructure in buildings                                     | Energy infrastructure in buildings                                                |                                                                                   |                                                                                   |
| Distributed solar PV generation (TWh)                                  | Distributed solar PV generation (TWh)                                             | 320                                                                               | 200 7 500                                                                         |
| EV private chargers (million units)                                    | EV private chargers (million units)                                               | 270                                                                               | 400 3 500                                                                         |

3

Near-term government decisions are required for energy codes and standards for buildings, fossil  fuel  phase  out,  use  of  low-carbon  gases,  acceleration  of  retrofits  and  financial incentives to encourage investment in building sector energy transitions. Decisions will be most effective if they focus on decarbonising the entire value chain, taking into account not only buildings but also the energy and infrastructure networks that supply them, as well as wider considerations including the role of the construction sector and urban planning. Such decisions are likely to bring wider benefits, notably in reducing fuel poverty.

Near-term government action is needed to ensure that zero-carbon-ready buildings become the new norm across the world before 2030 for both new construction and retrofits. This requires  governments  to  act  before  2025  to  ensure  that  zero-carbon-ready  compliant building energy codes are implemented by 2030 at the latest. While this goal applies to all regions, ways to achieve zero-carbon-ready buildings vary significantly across regions and climate  zones,  and  the  same  is  true  for  heating  and  cooling  technology  strategies. Governments should consider paving the way by making public buildings zero-carbon-ready in the coming decade.

Governments will need to find ways to make new zero-carbon-ready buildings and retrofits affordable  and  attractive  to  owners  and  occupants  by  overcoming  financial  barriers, addressing split incentive barriers and minimising disruption to building use. Building energy performance certificates, green lease agreements, green bond financing and pay-as-you save models could all play a part.

Making zero-carbon-ready building retrofits a central pillar of economic recovery strategies in  the  early  2020s  is  a  no-regrets  action  to  jumpstart  progress  towards  a  zero-emissions building sector. Foregoing the opportunity to make energy use in buildings more efficient would drive up electricity demand linked to electrification of energy use in the buildings sector and make decarbonising the energy system significantly more difficult and more costly (Box 3.5).

## Box 3.5 ⊳ What would be the impact of global retrofit rates not rising to 2.5%?

Decarbonising heating in existing buildings in the NZE rests upon a deep retrofit of the majority of the existing building stock. Having almost all buildings meet zero-carbon-ready building energy codes by 2050 would require retrofit rates of 2.5% each year by 2030, up from less than 1% today. Retrofits can be disruptive for occupants, require high upfront investment and may face permitting difficulties. These issues make achieving  the  required  pace  and  depth  of  retrofits  in  the  coming  years  the  biggest challenge facing the buildings sector.

Any  delay  in  reaching  2.5%  of  annual  retrofits  by  2030  would  require  such  a  steep subsequent  ramp  up  as  to  make  retrofitting  the  vast  majority  of  buildings  by  2050 virtually impossible. Modelling indicates that a delay of ten years in the acceleration of retrofitting, would increase residential space heating energy demand by 25% and space

cooling demand by more than 20%, translating to a 20% increase in electricity demand in 2050 relative to the NZE (Figure 3.31). This would put more strain on the power sector, which  would  need  to  install  more  low-carbon  generation  capacity.  Policies  and  fuel switching would still drive down fossil fuel demand in the Delayed Retrofit Case , but an additional 15 EJ of fossil fuels would be burned by 2050, emitting 1 Gt of CO2.

Figure 3.31 ⊳ Global residential space heating and cooling energy demand in the NZE and Delayed Retrofit Case

<!-- image -->

Delays in the ramp up of retrofit rates and depth would be almost impossible to catch up, placing further strain on the power sector and pushing up fossil fuel demand

Governments need to establish policies for coal and oil boilers and furnaces for space and water heating, which in the NZE are no longer available for sale from 2025. They also need to  take  action  to  ensure  that  new  gas  boilers  are  able  to  operate  with  low-carbon  gases (hydrogen ready) in decarbonised gas networks. This puts a premium on the availability of compelling alternatives to the types of boilers being phased out, including the use of heat pumps, efficient wood stoves (using sustainable supplies of wood), district energy, solar PV, solar  thermal  and  other  renewable  energy  technologies.  Which  alternatives  are  best  will depend  to  some  extent  on  local  conditions,  but  electrification  will  be  the  most  energyefficient  and  cost-effective  low-carbon  option  in  most  cases,  and  decarbonising  and expanding district energy networks is likely to make sense where densities allow. The use of biomethane or hydrogen in existing or upgraded gas networks may be the best option in areas where more efficient alternatives are not possible.

Governments also face decisions on minimum energy performance standards (MEPS). The NZE sees  all  countries  introduce  MEPS  for  all  main  appliance  categories  set  at  the  most stringent levels prevailing in advanced economies by 2025 at the latest. Among others, this would mean ending the sale of incandescent, halogen and compact fluorescent lamps by that

3

time. Setting MEPS at the right level will require careful planning; international collaboration to align standards and objectives could play a helpful role in keeping costs down.

The systemic nature of the NZE means that strategies and policies for buildings will work best if they are aligned with those being adopted for power systems, urban planning and mobility. This would help to ensure the successful scaling up of building-integrated PV technologies, battery storage and smart controls to make buildings active service providers to grids. It would  also  help  to  foster  the  deployment  of  smart  EV  charging  infrastructure.  Policies incentivising dense and mixed-use urban planning coupled with easy access to local services and public transport could reduce reliance on personal vehicles (see Chapter 2). There are also  links  between  buildings  strategies  and  measures  to  reduce  the  embodied  carbon emissions of new construction, which falls by 95% by 2050 in the NZE.

<!-- image -->

## Wider implications of achieving net-zero emissions

## S U M M A R Y

-  Economy: In  our  Net-Zero Emissions by 2050 Scenario (NZE), global CO2 emissions reach net zero by 2050 and investment rises across electricity, low-emissions fuels, infrastructure and end-use sectors. Clean energy employment increases by 14 million to 2030, but employment in oil, gas and coal declines by around 5 million. There are varying results for different regions, with job gains not always occurring in the same place, or matching the same skill set, as job losses. The increase in jobs and investment stimulates economic output, resulting in a net increase in global GDP to 2030. But oil and gas revenues in producer economies are 80% lower in 2050 than in recent years and tax revenues from retail oil and gas sales in importing countries are 90% lower.
-  Energy industry: There is a major contraction in fossil fuel production, but companies that  produce  these  fuels  have  skills  and  resources  that  could  play  a  key  role  in developing new low-emissions fuels and technologies. The electricity industry scales up to meet demand rising over two-and-a-half-fold to 2050 and becomes more capital intensive,  focusing  on  renewables,  sources  of  flexibility  and  grids.  Large  energyconsuming companies, vehicle manufacturers and their suppliers adjust designs and retool factories while improving efficiency and switching to alternative fuel supplies.
-  For citizens who lack access to electricity and clean cooking, the NZE delivers universal access by 2030. This costs around USD 40 billion a year over the next decade and adds less than 0.2% to CO2 emissions. For citizens the world over, the NZE brings profound changes, and their active support is essential if it is to succeed. Around three-quarters of  behavioural  changes  in  the  NZE  can  be  directly  influenced  or  mandated  by government policies. The cost of energy is also an important issue for citizens, and the proportion of disposable household income spent on energy over the period to 2050 remains  stable  in  emerging  market  and  developing  economies,  despite  a  large increase in demand for modern energy services.
-  Government action  is  central  to  achieve  net-zero  emissions  globally  by  2050;  it underpins the decisions made by all other actors. Four particular points are worth stressing. First, the NZE depends on actions that go far beyond the remit of energy ministers, and requires a co-ordinated cross-government approach. Second, the fall in oil and gas demand in the NZE may reduce some traditional energy security risks, but they do not disappear, while potential new vulnerabilities emerge from increasing reliance on electricity systems and critical minerals. Third, accelerated innovation is needed.  The  emissions  cuts  to  2030  in  the  NZE  can  be  mostly  achieved  with technologies on the market today, but almost half of the reductions in 2050 depend on technologies that are currently under development. Fourth, an unprecedented level  of  international  co-operation  is  needed.  This  helps  to  accelerate  innovation, develop  international  standards  and  facilitate  new  infrastructure  to  link  national markets. Without the co-operation assumed in the NZE, the transition to net-zero emissions would be delayed by decades.

## 4.1 Introduction

Achieving net-zero emissions by 2050 is a monumental task, especially against a backdrop of increasing  economic  and  population  growth.  It  calls  for  an  unwavering  focus  from  all governments, working together with industries and citizens, to ensure that the transition to global net-zero emissions proceeds in a co-ordinated way without delay. In this chapter, we look at what the changes that deliver net-zero emissions globally by 2050 in the NZE would mean for the economy, the energy industry, citizens and governments.

Figure 4.1 ⊳ Selected global milestones for policies, infrastructure and technology deployment in the NZE

<!-- image -->

Wide-ranging measures and regulations in the NZE help to influence or change the purchases that individuals make, the way they heat and cool their homes, and their means of transport. Many industries, especially those that are currently involved in the production of energy or are  large-scale  users  of  energy,  also  face  change.  Some  of  the  shifts  for  individuals  and industries may be unpopular, underscoring the fact that it is essential to ensure that the energy transition is transparent, just and cost-effective, and to persuade citizens of the need for reform. These changes deliver significant benefits. There are around 790 million people who do not have access to electricity today and 2.6 billion people who do not have access to clean cooking options. The NZE shows how emissions reductions can go hand-in-hand with efforts to provide universal access to electricity and clean cooking, and to improve air quality. It provides significant opportunities too, with clean energy technologies providing many new business  opportunities  and  jobs,  and  with  innovations  that  stimulate  new  industrial capacities.

Underpinning  all  of  these  changes  are  decisions  taken  by  governments.  This  will  require wholehearted buy-in from all levels of government and from all countries. The magnitude of the changes required to reach global net-zero emissions by 2050 are not within the power of government energy or environment departments alone to deliver, nor within the power of individual  countries.  It  will  involve  an  unprecedented  level  of  global  collaboration,  with recognition  of  and  sensitivity  to  differences  in  the  stages  of  development  of  individual countries,  and  an  appreciation  of  the  difficulties  faced  by  particular  communities  and members of society, especially those who may be negatively affected by the transition to net-zero emissions. In the NZE, governments start by setting unequivocal long-term targets, ensuring that these are fully supported from the outset by explicit, near-term targets and policy measures that clearly set out the pathway, and that recognise each country's unique starting  conditions,  to  support  the  deployment  of  new  infrastructure  and  technologies (Figure 4.1).

## 4.2 Economy

## 4.2.1 Investment and financing

The transition to net-zero emissions by 2050 requires a substantial ramp up in the investment of  electricity,  infrastructure  and  the  end-use  sectors.  The  largest  increase  over  the  next decade is in electricity generation: annual investment increases from about USD 0.5 trillion over the past five years to USD 1.6 trillion in 2030 (Figure 4.2). By 2030, annual investment in  renewables  in  the  electricity  sector  is  around  USD 1.3 trillion,  slightly  more  than  the highest level ever spent on fossil fuel supply (USD 1.2 trillion in 2014). Annual investment in clean energy infrastructure increases from around USD 290 billion over the past five years to about USD 880 billion in 2030. This is for electricity networks, public electric vehicle (EV) charging stations, hydrogen refuelling stations and import and export terminals, direct air capture and  CO2  pipelines and  storage facilities. Annual  investment  in low-carbon technologies in end-use sectors rises from USD 530 billion in recent years to USD 1.7 trillion

4

in 2030.  This includes spending on deep retrofitting of buildings, transformation of industrial 1 processes, and the purchase of new low-emissions vehicles and more efficient appliances.

After  2030,  annual  electricity  generation  investment  falls  by  one-third  to  2050.  A  lot  of infrastructure for a low-emissions electricity sector is established within the first decade of the NZE, and the cost of renewables continues to decline after 2030. In end-use sectors, there are continued increases in investment in EVs, carbon capture, utilisation and storage (CCUS) and hydrogen use in industry and transport, and more efficient buildings and appliances.

Global investment in fossil fuel supply falls steadily from about USD 575 billion on average over  the  past  five  years  to  USD 110 billion  in  2050  in  the  NZE,  with  upstream  fossil  fuel investment restricted to maintaining production at existing oil and natural gas fields. This investment reflects the fact that fossil fuels are still used in 2050 in the NZE in processes where  they  are  paired  with  CCUS,  in  non-emitting  processes  (such  as  petrochemical manufacturing),  and  in  sectors  where  emissions  reductions  are  most  challenging  (with emissions offset by carbon dioxide removal). Investment in low-emissions fuels increases more than thirty-fold between 2020 and 2050, reaching about USD 135 billion in 2050. This is split roughly equally between the production of hydrogen and hydrogen-based fuels, and the production of biofuels.

Over the 2021-50 period in the NZE, annual average total energy sector investment as a share of  gross  domestic  product  (GDP)  is  around  1%  higher  than  over  the  past  five  years.  The private sector is central to finance  higher  investment  needs.  It  requires  enhanced collaboration between developers, investors, public financial institutions and governments. Collaboration will be especially important over the next five to ten years for the development of large infrastructure projects and for technologies in the demonstration or prototype phase today such as some hydrogen and CCUS applications. Companies and investors have declared strong  interest  to  invest  in  clean  energy  technologies,  but  turning  interest  into  actual investment at the levels required in the NZE also depends on public policies.

Some obstacles to investment need to be tackled. Many emerging market and developing economies  are  reliant  on  public  sources  to  finance  energy  projects  and  new  industrial facilities. In some cases, improvements in regulatory and policy frameworks would facilitate the international flow of long-term capital to support the development of both new and existing clean energy technologies. The rapid growth in investment in transport and buildings in the NZE presents a different kind of challenge for policy makers. In many cases, an increase in capital spending for an efficient appliance or low-emissions vehicle would be more than offset  by  lower  expenditure  on  fuels  and  electricity  over  the  product  lifetime,  but  some low-income households and small and medium enterprises may not be able to afford the upfront capital required.

1 Investment  levels  presented  in  this  report  include  a  broader  accounting  of  efficiency  improvements  in buildings  and  differ  from  that  reported  in  the  IEA  World  Energy  Investment  report  (IEA,  2020a).  End-use efficiency investments are the incremental cost of improving the energy performance of equipment relative to a conventional design.

Figure 4.2 ⊳ Global average annual energy investment needs by sector and technology in the NZE

<!-- image -->

IEA. All rights reserved.

Investment increases rapidly in electricity generation, infrastructure and end-use sectors. Fossil fuel investment drops sharply, partly offset by a rise in low-emissions fuels.

Notes: CCUS = carbon capture, utilisation and storage; EV = electric vehicle.  Infrastructure includes electricity networks, public EV charging, CO2 pipelines and storage facilities, direct air capture and storage facilities, hydrogen refuelling stations, and import and export terminals for hydrogen and fossil fuels pipelines and terminals. End-use efficiency investments are the incremental cost of improving the energy performance of equipment relative to a conventional design.

## 4.2.2 Economic activity

The  energy  transition  required  for  net-zero  emissions  by  2050  will  affect  all  economic activities directly or indirectly. In co-ordination with the International Monetary Fund, we have modelled the medium-term global macroeconomic impact of the changes in the energy

4

sector that occur in the NZE. This analysis shows that the surge in private and government spending  on  clean  energy  technologies  in  the  NZE  creates  a  large  number  of  jobs  and stimulates economic output in the engineering, manufacturing and construction industries. This results in annual GDP growth that is nearly 0.5% higher than the levels in the Stated Policies Scenario (STEPS)  during latter half of the 2020s (Figure 4.3). 2 3

Figure 4.3 ⊳ Change in annual growth rate of global GDP in the NZE relative to the STEPS

<!-- image -->

IEA. All rights reserved.

The surge in government and private investment in the NZE has a positive impact on global GDP, but there are large differences between regions

Notes: GDP = gross domestic product. Reduction in rents stem mainly from lower fossil fuel income.

Source: IEA analysis based on IMF.

There are large differences in macroeconomic impacts between regions. The decline in fossil fuel use and prices results in a fall in GDP in the producer economies,  where revenues from 4 oil and gas sales often cover a large share of public spending on education, health care and other public services. The drop in oil and gas demand, and the consequent fall in international prices  for  oil  and  gas,  cause  net  income  in  producer  economies  to  drop  to  historic  lows (Figure 4.4). Some countries with the lowest cost oil resources (including members of the

2 The IEA Stated Policies Scenario is the projection for the global energy system based on the policies and measures  that  governments  around  the  world  have  already  put  in  place  and  on  announced  policies  as expressed in official targets and plans, such as Nationally Determined Contributions put forward under the Paris Agreement (see Chapter 1).

3 The estimated general equilibrium macroeconomic impact of the increase in public and private investment and  the  reduction  in  oil-related  revenue  contained  in  the  NZE  has  been  provided  by  the  International Monetary Fund using its Global Integrated Monetary and Fiscal Model (GIMF).

4 Producer economies are large oil and gas exporters that rely on hydrocarbon revenues to finance a significant proportion of their national budgets, including countries in the Middle East, Russia and the Caspian region.

Organization  of  the  Petroleum  Exporting  Countries  [OPEC])  gain  market  share  in  these circumstances, but even they would see large falls in revenues. Structural reforms would be needed  to  address  the  societal  challenges,  including  those  to  accelerate  the  process  of reforming  inefficient  fossil  fuel  subsidies  and  to  speed  up  moves  to  use  hydrocarbon resources  to  produce  low-emissions  fuels,  e.g.  hydrogen  and  hydrogen-based  fuels  (see section 4.3.1).

Figure 4.4 ⊳ Income from oil and gas sales in producer economies in the NZE

<!-- image -->

IEA. All rights reserved.

Structural reforms and new sources of revenue are needed in producer economies, but these are unlikely to compensate fully for a large drop in oil and gas income

The macroeconomic effects of the NZE are very uncertain. They depend on a host of factors including: how government expenditure is financed; benefits from improvements to health; changes in consumer bills; broad impact of changes in consumer behaviour; and potential for  productivity  spill-overs  from  accelerated energy  innovation.  Nonetheless,  impacts  are likely to be lower than assessments of the cost of climate change damages (OECD, 2015). It is  also  likely  that a co-ordinated, orderly transition can be executed without major global systemic financial impacts, but this will require close attention from governments, financial regulators and the corporate sector.

## 4.2.3 Employment

Employment  in  the  energy  sector  shifts  markedly  in  the  NZE  in  response  to  changes  in investment  and  spending  on  energy.  We  estimate  that  today  roughly  40 million  people around  the  world  work  directly  in  the  oil,  gas,  coal,  renewables,  bioenergy  and  energy network industries (IEA, 2020b). In the NZE, clean energy employment increases by 14 million

4

to 2030, while employment in oil, gas and coal fuel supply and power plants declines by around 5 million, leading to a net increase of nearly 9 million jobs (Figure 4.5).

Figure 4.5 ⊳ Global energy sector employment in the NZE, 2019-2030

<!-- image -->

Overall employment in the energy sector increases by almost 9 million to 2030 as jobs created in clean energy sectors outpace losses in fossil fuels

Jobs created would not necessarily be in the same area where jobs are lost, plus the skill sets required for the clean energy jobs may not be directly transferable. Job losses would be most pronounced  in  communities  that  are  heavily  dependent  on  fossil  energy  production  or transformation activities.  Even  where  the  number  of  direct  energy  jobs  lost  is  small,  the impact on the local economy may be significant. Government support would almost certainly be needed to manage these transitions in a just, people-centred way. In preparation, a better understanding of current energy industry employment is needed. A useful action would be for governments  to  adopt  more  detailed  surveying  approaches  for  energy  industry employment, such as those used in the US Energy &amp; Employment Report (NASEO and Energy Futures Initiative, 2021).

In addition to the 14 million new clean energy jobs created in the NZE, other new jobs are created by changes in spending on more efficient appliances, electric and fuel cell vehicles, and  building  retrofits  and  energy-efficient  construction.  These  changes  would  require  a further 16 million workers, meaning that there would be 30 million more people working in clean energy, efficiency and low-emissions technologies by 2030 in the NZE (Figure 4.6). 5 Investment  in  electricity  generation,  electricity  networks,  EV  manufacturing  and  energy efficiency  are  among  the  areas  that  will  open  up  new  employment  opportunities.  For example, jobs in solar and wind more than quadruple in the NZE over current levels. Nearly two-thirds of workers in these sectors by 2030 in the NZE would be highly skilled and the

5 This includes new jobs and jobs filled by moving current employment from one type of production to another.

majority require substantial training. In addition, with the more than doubling of total energy investment, new employment opportunities will arise in associated areas such as wholesale trading, financial and legal services.

In  many  cases  it  may  be  possible  to  shift  workers  to  new  product  lines  within  the  same company, for example in vehicle manufacturing as production reconfigures to EVs. However, there would be larger risks for specialised supply chain companies that provide products and services, e.g.  internal  combustion engines that are replaced by new components such as batteries.

Figure 4.6 ⊳ New workers in clean energy and related sectors and shares by skill level and occupation in the NZE and the STEPS in 2030

<!-- image -->

IEA. All rights reserved.

About 30 million new workers are needed by 2030 to meet increased demand for clean energy, efficiency, and low-emissions technologies; over half are highly skilled positions

Note: EVs = electric vehicles.

The  new  jobs  created  in  the  NZE  tend  to  have  more  geographic  flexibility  and  a  wider distribution than is the case today. Around 40% are jobs located close to where the work is being  done,  e.g.  building  efficiency  improvements  or  wind  turbine  installation,  and  the remaining  are  jobs  tied  to  manufacturing  sites.  Today  the  manufacturing  capacity  for  a number of clean energy technologies, such as batteries and solar photovoltaic panels,  is concentrated  in  particular  areas,  notably  China.  The  rapid  increase  in  demand  for  clean energy technologies in the NZE requires new production capacity to come online that could be located in any region. Those countries and companies that move first may enjoy strategic advantages in capturing burgeoning demand.

4

## 4.3 Energy industry

## 4.3.1 Oil and gas

The  energy  transition  envisioned  in  the  NZE  involves  a  major  contraction  of  oil  and  gas production with far-reaching implications for all the companies that produce these fuels. Oil demand falls from around 90 million barrels per day (mb/d) in 2020 to 24 mb/d in 2050, while natural gas demand falls from 3 900 billion cubic metres (bcm) to around 1 700 bcm. No fossil fuel  exploration  is  required  in  the  NZE  as  no  new  oil  and  natural  gas  fields  are  required beyond those that have already been approved for development. This represents a clear threat to company earnings, but there are also opportunities. The resources and skills of the oil and gas industry are a good match with some of the new technologies needed to tackle emissions in sectors where reductions are likely to be most challenging, and to produce some of the low-emissions liquids and gases for which there is a rapid increase in demand in the NZE (see Chapter 2). By partnering with governments and other stakeholders, the oil and gas industry could play a leading role in developing these fuels and technologies at scale, and in establishing new business models.

The oil and gas industry is highly diverse, and various companies could pursue very different strategies in the transition to net-zero emissions. Minimising emissions from core oil and gas operations  however  should  be  a  first-order  priority  for  all  oil  and  gas  companies.  This includes tackling methane emissions that occur during operations (they fall by 75% between 2020 and 2030 in the NZE) and eliminating flaring. Companies should also electrify operations using renewable electricity wherever possible, either by purchasing electricity from the grid or  by  integrating  off-grid  renewable  energy  sources  into  upstream  facilities  or  transport infrastructure.  Producers  that  can  demonstrate  strong  and  effective  action  to  reduce emissions can credibly argue that their oil and gas resources should be preferred over higher emissions options.

Some oil and gas companies may choose to become 'energy companies' focused on lowemissions technologies and fuels, including renewable electricity, electricity distribution, EV charging and batteries. Several technologies that are critical to the achievement of net-zero emissions, such as CCUS, hydrogen, bioenergy and offshore wind, look especially well-suited to some of the existing skills, competencies and resources of oil and gas companies.

-  Carbon capture, utilisation and storage . The oil and gas industry is already the global leader in developing and deploying CCUS. Of the 40 million tonnes (Mt) of CO2 captured today  at  large-scale  facilities,  around  three-quarters  is  captured  from  oil  and  gas operations, which often produce concentrated streams of CO2 that are relatively easy and cost effective to capture (IEA, 2020c). The oil and gas industry also has the largescale engineering, pipeline, sub-surface and project management skills and capabilities to handle large volumes of CO2 and to help scale up the deployment of CCUS.

-  Low-emissions  hydrogen  and  hydrogen-based  fuels . Oil  and  gas  companies  could contribute  to  developing  and  deploying  low-emissions  hydrogen  in  several  ways (IEA, 2019a). Nearly 40% of hydrogen production in 2050 in the NZE is from natural gas in facilities equipped with CCUS, providing an important opportunity for companies and countries to utilise their natural gas resources in a way that is consistent with net-zero emissions. Of the total output of 530 Mt of hydrogen in 2050, about 30% is processed into ammonia and synthetic fuels (equivalent to around 7.5 mboe/d). The transformation processes involved have many potential synergies with the skills and equipment used in oil and gas processing and refining. Oil and gas companies also have long experience of transporting liquids and gases by pipeline and ships.
-  Advanced  biofuels  and  biomethane . The  production  of  advanced  biofuels  grows substantially  in the  NZE,  but  this  depends  critically  on  continued  technological innovation. Many oil and gas companies have active R&amp;D programmes in these areas and  could  become  leading  producers.  Biomethane  -  a  low-emissions  alternative  to natural gas - can be produced in large centralised facilities, which could be a good fit with the knowledge and technical expertise of existing gas producers (IEA, 2020d).
-  Offshore wind .  About  40%  of  the  lifetime  costs  of  a  standard  offshore  wind  project involve significant synergies with the offshore oil and gas sector (IEA, 2019b). The oil and gas industry has considerable experience of working in offshore locations, which could be of value in the construction of foundations and subsea structures for offshore wind farms, especially when using vessels during installation and operation. The experience of maintaining safety standards in oil and gas companies could also be helpful during maintenance and inspection of offshore wind farms once they are in operation.

Oil and  gas  companies  are  well-placed  to  accelerate  the  pace  of  development  and deployment of these technologies, and to gain a commercial edge over other companies. In the NZE, investment in low-emissions technologies suited to the skills and expertise of oil and gas companies exceeds that in traditional oil and gas operations by 2030. Total capital spending  on  these  technologies  and  on  traditional  oil  and  gas  operations  averages USD 650 billion per year over 2021-50, just less than annual investment in oil and gas projects between 2016 and 2020 (Figure 4.7).

Not all oil and gas companies will choose to follow a strategy of diversifying into other types of energy. For example, it is far from certain that national oil companies will be charged by their state owners to diversify and develop low-emissions energy sources outside their core area of activity;  other  companies may decide simply to concentrate on supplying oil and natural gas as cleanly and efficiently as possible, and to return income to shareholders. What is clear, however, is that no oil and gas company would be unaffected by the NZE and that all parts of the industry need to decide how to respond (IEA, 2020e).

4

Figure 4.7 ⊳ Annual average investment in oil and gas and low-emissions technologies with synergies for the oil and gas industry in the NZE

<!-- image -->

Investment in low-emissions technologies suited to the skills and expertise of oil and gas companies exceeds investment in traditional operations by 2030

Note: CCUS = carbon capture, utilisation and storage.

## 4.3.2 Coal

The precipitous decline in coal use projected in the NZE would have major implications for the  future  of  mining  companies  and  countries  with  large  existing  production  capacities. Around 470 million tonnes of coal equivalent (Mtce) of coal used in the NZE in 2050 is in facilities equipped with CCUS (80% of global coal demand in 2050), which prevents an even sharper decline in demand. But no new coal mines or mine extensions are needed in the NZE. Retraining and regional revitalisation programmes would be essential to reduce the social impact  of  job  losses  at  the  local  level  and  to  enable  workers  and  communities  to  find alternative  livelihoods.  There  could  also  be  opportunities  to  locate  new  clean  energy facilities, including the new processing facilities that are needed for critical minerals, in the areas most affected by mine closures.

For mining companies, however, the contraction in coal demand in the NZE could be offset by the need to increase mining of other raw minerals, including those vital to many clean energy technologies,  such  as  copper,  lithium  and  nickel  (IEA,  2021a).  Global  demand  for these critical minerals rises rapidly in the NZE (Figure 4.8). For example, demand for lithium for use in batteries expands by a factor of 30 by 2030, while demand for rare earths, primarily used for making EV motors and wind turbines, increases by a factor of ten by 2030. Critical mineral resources are not always located in the same locations or countries as existing coal mines, but the skills and experience of mining companies will be essential to ensure that the supply of these minerals is able to match demand at reasonable prices. By the 2040s, the size of the global market for these minerals approaches that for coal today.

Figure 4.8 ⊳ Global value of coal and selected critical minerals in the NZE

<!-- image -->

The market for critical minerals approaches that of coal today in the 2040s

Notes: Includes total revenue for coal and for selected critical minerals used in clean energy technologies. The prices of critical minerals are based on conservative assumptions about cost increases (around a 10%-20% increase from current levels to 2050).

## 4.3.3 Electricity

Getting to net-zero emissions calls for a massive expansion of the electricity sector to power the needs of a growing global economy, the electrification of end-uses that previously used fossil  fuels,  and  the  production  of  hydrogen  from  electrolysis.  While  electricity  demand increases more than two-and-a-half times, the rapid transformation of the industry means that total electricity supply costs triple from 2020 to 2050 in the NZE, raising average costs per unit of electricity generation modestly (Figure 4.9).

The electricity  supply  industry  also  becomes  much  more  capital  intensive,  accelerating  a recent trend. The share of capital in total costs rises from less than 60% in 2020 (already ten percentage points higher than in 2010) to about 80% in 2050. This is largely due to a massive increase in renewable energy and the corresponding need for more network capacity and sources of flexibility, including battery storage. In the late 2020s and 2030s, the upgrading and  replacement  of  existing  solar  and  wind  capacity  as  they  come  to  the  end  of  their operating lives also boosts capital needs.  New nuclear power capacity additions add further 6 capital spending in the NZE. The rising capital intensity of the electricity industry increases the importance of limiting risk for new investment and ensuring sufficient revenues in all years for grid operators to fund rising investment needs - a point underlined by the financial difficulties experienced by some network companies in 2020 due to depressed electricity demand resulting from the Covid-19 crisis (IEA, 2020f).

6 They  typically  need  replacing  after  25-30  years  of  operation,  whereas  many  conventional  hydropower, nuclear and coal plants operate far longer albeit with periodic additional investment.

4

Figure 4.9 ⊳ Global electricity supply costs by component in the NZE

<!-- image -->

Electricity system costs triple to 2050, raising average supply costs modestly; the massive growth of renewables makes the industry more capital intensive

Notes: Electricity supply costs include all the direct costs to produce and transmit electricity to consumers. Battery storage systems are included in power plant capital recovery.

The rising share of renewables in the electricity generation mix has important implications for  the  design  of  electricity  markets.  When  the  shares  of  solar,  wind,  other  variable renewables and nuclear power reach high levels, available electricity supply at no marginal cost is often above electricity demand, resulting in a wholesale price of electricity that is zero or even negative. By 2050, without changes in electricity market design, about 7% of wind and solar output in the NZE would be above and beyond what can be integrated (and so curtailed), and the share of zero-price hours in the year would increase to around 30% in major markets from close to zero today, despite the active use of demand response. If the share of renewables in the electricity generation mix is to rise as envisioned in the NZE, it would therefore be highly desirable to effect significant changes in the design of electricity markets so as to provide signals for investment, including investment in sources of flexibility such as battery storage and dispatchable power plants.

The increase in electricity use inevitably raises associated costs. Operating and maintaining power plants worldwide costs close to USD 1 trillion in 2050 in the NZE, two-and-a-half times the level in 2020. In 2020, upkeep at fossil fuel power plants accounted for USD 150 billion, and  renewables  required  nearly  as  much,  mostly  for  hydropower.  By  2050,  the  cost  of operating and maintaining renewables reaches USD 780 billion, most it needed for wind and solar photovoltaics (PV) as a result of their massive scaling up: offshore wind alone accounts for USD 90 billion.

The sharp reduction of fossil fuel use in the electricity industry and lower fuel prices mean that costs related to fuel and CO2 prices are significantly reduced. This continues a recent trend driven by near record-low natural gas prices in many markets. Even with rising CO2 prices over time, the rapid decarbonisation of electricity means that fuel and CO2 make up a declining share of total costs, falling from about one-quarter  in 2020 to 5% in 2050. The balance  of  fuel  costs  shifts  towards  low-emissions  sources,  mainly  nuclear  power  and bioenergy (including with CCUS), though some still remains related to natural gas and coal used in power plants equipped with CCUS.

One challenge in this context is what to do about the coal-fired power plants in operation. In 2020, over 2 100 gigawatts (GW) of power plants worldwide used coal to produce electricity and heat, and they emitted nearly 30% of all energy-related CO2 emissions. Options include retrofitting  coal-fired  power  plants  with  CCUS  technologies,  co-firing  with  biomass  or ammonia;  repurposing  coal  plants  to  focus  on  providing  flexibility;  and,  where  feasible, phasing  them  out.  In  the  NZE,  all  unabated  coal-fired  power  plants  are  phased  out  in advanced economies by 2030 and in emerging market and developing economies by 2040. As a result, emissions from coal-fired power plants fall from 9.8 gigatonnes (Gt) in 2020 to 3.0 Gt in 2030 and to just 0.1 Gt by 2040 (residual emissions from coal with CCUS plants). 7

Another challenge is related to the scale of capacity retirements envisaged and associated site rehabilitation, starting with coal. The pace of retirement of coal-fired power plants over 2020-50 is nearly triple that of the past decade. Decommissioning at each site can often last a decade and entail significant cost, and may involve closing a mine as well. In some cases, it may be financially attractive to build a renewable energy project on the same site, taking advantage of the grid connection and limiting the cost of rehabilitation. Thousands of natural gas-fired and oil-fired power plants are also retired by 2050, though these sites are often strategically  located  on  the  grid  and  many  are  likely  to  be  replaced  directly  with  battery storage systems.

The large fleet of ageing nuclear reactors in advanced economies means their decommissioning increases, despite many reactor lifetime extensions. In the NZE, annual average nuclear retirements globally are 60% higher over the next 30 years than in the last decade. Each nuclear decommissioning project can span decades, with costs ranging from several hundred million dollars to well over USD 1 billion for large reactors (NEA, 2016).

## 4.3.4 Energy-consuming industries

The changes in the NZE would have an enormous impact on industries that manufacture vehicles and their material and component suppliers. Around 95% of all the cars and nearly all  of  the  trucks  sold  worldwide  in  2020  were  conventional  vehicles  with  an  internal combustion engine. In the NZE, about 60% of global car sales in 2030 are EVs, and 85% of

7 A CO2 capture rate of 90% is assumed, though higher rates are technically possible with reduced efficiencies and additional costs (IEA, 2020g).

4

heavy-duty trucks sold in 2040 are EVs or fuel cell vehicles. In the NZE, vehicle component suppliers and vehicle manufacturers alike retool factories, change designs to incorporate batteries  and  fuel  cells,  and  adjust  supply  chains  to  minimise  the  lifecycle  emissions intensities of vehicles. This provides opportunities to redesign existing parts and manufacturing processes to improve efficiency and lower costs.

The rapid increase in EV sales in the NZE requires an immediate scale up of new supply chains for batteries as well as recharging and low-emissions refuelling infrastructure. In the NZE, battery  production  capacity  increases  to  more  than  6.5 terawatt-hours  (TWh)  by  2030, compared with less than 0.2 TWh in 2020. Any delay in expanding battery manufacturing capacity would have a detrimental impact on the roll-out of EVs and slow cost reductions for other clean energy technologies that benefit in the NZE from having similar manufacturing processes and know-how (such as fuel cell vehicles and electrolysers).

In aviation and shipping, liquid low-emissions fuels are central to cut emissions. Switching to some of these would have little impact on vessel design: the use of hydrogen-based fuels or biofuels  in  shipping  would  only  require  changes  to  the  motor  and  fuel  system,  and  biokerosene  or  synthetic  kerosene  can  operate  with  existing  aircraft.  New  bunkering  and refuelling infrastructure are needed in the NZE, however, and the use of these low-emissions fuels  also  requires  new  safety  and  standardisation  standards,  protocols  for  permitting, construction  and  design,  as  well  as  international  regulation,  monitoring,  reporting  and verification of their production and use.

In heavy industrial sectors - steel, cement and chemicals - most deep emissions reduction technologies are not available on the market today. In the NZE, material producers soon demonstrate near-zero emission processes, aided by government risk-sharing mechanisms, and start to adapt their existing production assets. For multinational companies, this includes developing technology transfer strategies to roll-out processes across plants. International co-operation would help to ensure a level playing field for all. Within countries, efforts focus on  industrial  hubs  in  order  to  accelerate  emissions  reductions  across  multiple  industrial sectors by promoting economies of scale for new infrastructure (such as CO2 transport and storage) and supplies of low-emissions energy.

Materials  producers  work  with  governments  in  the  NZE  to  create  an  international certification system for near-zero emission materials to differentiate them from conventional ones. This would enable buyers of materials such as vehicle manufacturers and construction  companies  to  enter  into  commercial  agreements  to  purchase  near-zero emissions materials at a price premium. In most cases, the premium would result in only a modest impact on the final price of the product price given that materials generally account for a small portion of manufacturing costs (Material Economics, 2019).

## 4.4 Citizens

## 4.4.1 Energy-related Sustainable Development Goals

An inclusive and people-centred transition is key to the world moving rapidly, collectively and consistently toward net-zero emissions by mid-century. The NZE achieves the United Nations energy-related Sustainable Development Goals (SDGs) of universal access to clean modern energy by 2030 (SDG 7.1) and reducing premature deaths caused by air pollution (SDG 3.9).  The  technologies,  options  and  measures  used  to  achieve  full  access  to  lowemissions electricity  and  clean  cooking  solutions  by  2030  in  the  NZE  also  help  to  reduce greenhouse gas (GHG) emissions from household energy use.

## Energy access

About 790 million people worldwide did not have access to electricity in 2020, most of them living  in  sub-Saharan  Africa  and  developing  Asia.  Around  2.6 billion  people  did  not  have access to clean cooking options: 35% of them were in sub-Saharan Africa, 25% in India and 15% in China. A lack of access to energy not only impedes economic development, but also causes serious harm to health and is a barrier to progress on gender equality and education. 8

Figure 4.10 ⊳ People gaining access to electricity by type of connection in emerging market and developing economies in the NZE

<!-- image -->

IEA. All rights reserved.

More than 80% of people gaining access to electricity by 2030 are supplied renewable power and just over half via off-grid systems

8 Households  relying  on  the  traditional  use  of  biomass  for  cooking  dedicate  around  1.4 hours  each  day collecting firewood and several hours cooking with inefficient stoves, a burden largely borne by women (IEA, 2017).

4

Around 45% of those who lack access to electricity by 2030 gain it via a connection to a main grid,  while  the  rest  are  served  by  mini-grids  (30%)  and  stand-alone  solutions  (25%) (Figure 4.10). Almost all off-grid or mini-grid solutions are 100% renewable. Decentralised systems  that  rely  on  diesel  generators,  which  are  also  deployed  in  some  grid-connected systems  to  compensate  for  low  reliability,  are  phased  out  later  and  replaced  with  solar storage  systems.  Achieving  full  access  does  not  lead  to  a  significant  increase  in  global emissions: in 2030 it adds less than 0.2% to CO2 emissions. Achieving full access to electricity also brings efficiency gains and accelerates the electrification of appliances, which become critical to emissions reductions in buildings after 2030 in emerging market and developing economies.

For clean cooking, 55% of those gaining access by 2030 in the NZE do so through improved biomass cookstoves (ICS) fuelled by modern biomass, biogas or ethanol, 25% through the use of liquefied petroleum gas (LPG) and 20% via electric cooking solutions (Figure 4.11). LPG is the main fuel adopted in urban areas and ICS is the main option in rural areas. The use of LPG results in a slight increase in CO2 emissions in 2030 but a net reduction in overall GHG emissions  due  to  reduced  methane,  nitrous  oxides  and  black  carbon  emissions  from  the traditional use of biomass. In addition, LPG is increasingly decarbonised after 2030 using biosourced  butane  and  propane  (bioLPG)  produced  sustainably  from  municipal  solid  waste (MSW) and other renewable feedstocks. The technical potential of bioLPG production from MSW in 2050 in Africa could be enough to satisfy the cooking needs of more than 750 million people (GLPGP, 2020; Liquid Gas Europe, 2021).

Figure 4.11 ⊳ Primary cooking fuel by share of population in emerging market and developing economies in the NZE

<!-- image -->

IEA. All rights reserved.

Traditional biomass is entirely replaced with modern energy by 2030, mainly in the form of bioenergy and LPG; by 2050, electricity, bioenergy and bioLPG meet most cooking needs

Notes: Modern bioenergy includes improved cook stoves, biogas and ethanol. Liquefied petroleum gas (LPG) includes fossil and renewable fuel.

The achievement of universal access to clean energy by 2030 requires governments and donors to put expanding access at the heart of recovery plans and programmes. There would be  multiple  benefits:  investing  heavily  in  energy  access  would  provide  an  immediate economic boost, create local jobs and bring durable improvements to social well-being by modernising health services and food chains. In the NZE, around USD 35 billion is spent each year  improving  access  to  electricity  and  almost  USD 7 billion  each  year  on  clean  cooking solutions for people in low-income countries from now to 2030.

## Air pollution and health

More than 90% of people around the world are exposed to polluted air today. Such pollution led to around 5.4 million premature deaths in 2020, undermining economic productivity and placing extra stress on healthcare systems. Most of these deaths were in emerging market and developing economies. Just over half were caused by exposure to outdoor air pollution; the remainder resulted from breathing polluted air indoors, caused mainly by the traditional use of biomass for cooking and heating.

Energy-related emissions of the three major air pollutants - sulphur dioxide (SO2), nitrogen oxides (NOX) and fine particulate matter (PM2.5) - fall rapidly in the NZE. SO2 emissions fall by 85% between 2020 and 2050, mainly as a result of the large-scale phase-out of coal-fired power plants and industrial facilities. NOX emissions also drop by around 85% as a result of the  increased  use  of  electricity,  hydrogen  and  ammonia  in  the  transport  sector.  The increased uptake of clean cooking fuels in developing countries, together with air pollution control  measures  in  industry  and  transport,  results  in  a  90%  drop  in  PM2.5 emissions (Figure 4.12). The reduction in air pollution in the NZE leads to roughly a halving in premature deaths in 2050 compared with 2020, saving the lives of about 2 million people per year, around 85% of them in emerging market and developing economies.

Figure 4.12 ⊳ Global premature deaths and air pollutant emissions in the NZE

<!-- image -->

Reductions in major air pollutants mean 2 million fewer premature deaths per year

4

## 4.4.2 Affordability

## Total spending on energy

Energy affordability is a key concern for governments, businesses and households. Global direct  spending  on  energy,  i.e.  the  total  fuel  bills  paid  by  all  end  users,  which  totalled USD 6.3 trillion in 2020, increases by 45% to 2030 and 75% to 2050, in large part reflecting population and GDP growth over this period. As a share of global GDP, the figures look rather different: total direct spending on energy holds steady at around 8% out to 2030 (similar to the average over the last five years), but then declines to 6% in 2050. This decline offsets a significant  share  of  the  higher  cost  of  buying  new,  more  efficient  energy-consuming equipment.

A portion of the increase in energy spending in the NZE is related to rising CO2 prices and the removal  of  consumption  subsidies  for  fossil  fuels  and  electricity.  CO   pricing  (taxes  and 2 trading schemes) paid by end users at its peak generates global revenues in the NZE of close to  USD 700 billion  each  year  between  2030  and  2035,  before  declining  steadily  due  to declining overall emissions: these revenues could be recycled into economies or otherwise used to improve consumer welfare, particularly for low-income households. The NZE also sees  the  progressive  removal  of  consumption  subsidies  for  fossil  fuels,  many  of  which disproportionally  benefit  wealthier  segments  of  the  population  that  use  more  of  the subsidised  fuel.  Phasing  out  the  subsidies  would  provide  more  efficient  price  signals  for consumers, and spur more energy conservation and measures to improve energy efficiency. The impact of phasing out subsidies on lower income households could be offset through direct payment schemes or other means at lower overall costs to the economy.

Figure 4.13 ⊳ Global energy spending by fuel in the NZE

<!-- image -->

Total energy spending increases by 75% to 2050, mainly on electricity

Note: Other = hydrogen-based and synthetic fuels, and district heating.

The  transformation  of  the  global  energy  system  in  the  NZE  drives  a  major  shift  in  the composition of energy spending. Spending on electricity at USD 2.7 trillion in 2020 (45% of total energy spending) exceeded spending on oil products for the first time and it rises to over USD 8.5 trillion in 2050 (80% of total energy spending) (Figure 4.13). Retail electricity prices increase by 50% on average, contributing to the total increase. Spending on oil, which has  dominated  overall  energy  spending  for  decades,  goes  into  long-term  decline  in  the 2020s, its share of spending falling from 40% in 2020 to just 5% in 2050. Spending on natural gas and coal also declines in the long term, offset by higher spending on low-emissions fuels. Spending on bioenergy reaches about USD 900 billion per year by 2040, while other lowemissions fuels, including hydrogen-based products, gain a foothold and establish a market worth of around USD 600 billion per year by 2050.

## Household spending on energy

Direct spending by households on energy, including for heating, cooling, electricity and fuel for passenger cars, falls as a share of disposable income in the NZE, though there are large differences between countries (Figure 4.14).

Figure 4.14 ⊳ Average annual household energy bill in the NZE

<!-- image -->

IEA. All rights reserved.

The proportion of disposable household income spent on energy is stable in emerging market and developing economies, and drops substantially in advanced economies

Note: Hydrogen-based includes hydrogen, ammonia and synthetic fuels.

In advanced economies, the average annual bill declines from about USD 2 800 in 2020 to USD 2 300  in  2030,  thanks  to  a  strong  push  on  energy  efficiency  and  cost-effective electrification. Oil products make up close to half of household energy bills in 2020, but this falls to 30% in 2030 and almost zero in 2050, due to a rapid shift to EVs and to downward pressure on oil prices. Natural gas bills, which make up almost 10% of the total today, also

4

fall to almost zero in 2050 with the electrification of heating and cooking. Electricity rises from about 35% of household fuel bills in 2020 to 90% in 2050, increasing the sensitivity of households to electricity prices and consumption. Increasing incomes mean that household spending on energy as a share of disposable income drops from 4% in 2020 to 2% in 2050.

In  emerging  market  and  developing  economies,  there  is  a  huge  increase  in  demand  for modern energy services linked to expanding populations, economic growth, rising incomes and universal access to electricity and clean cooking options. As in advanced economies, electricity accounts for the vast majority of energy bills in 2050. The use of more efficient appliances and equipment curbs some of the increase in demand, but household bills still increase in the NZE by over 60% to 2030 and more than double by 2050. As a percentage of disposable income, however, bills in emerging market and developing economies remain around 4%, and there are large social and economic benefits from increased energy use.

Figure 4.15 ⊳ Change in household spending on energy plus energy-related investment in the NZE relative to 2020

<!-- image -->

Total household spending on energy increases modestly in emerging market and developing economies, leaving over 90% of additional income available for other uses

Taking  into  account  additional  investment  in  electricity-consuming  equipment  such  as efficient  appliances  and  electric  vehicles,  spending  on  energy  plus  related  investment  is USD 1.30 higher per day per household globally in 2050 than in 2020 in the NZE. This modest increase means that expenditure on energy makes up a smaller share of disposable income in  2050 than it does today, though the impacts vary by country. In advanced economies, additional investment in electrification, energy efficiency and renewable energy costs about USD 750 per household by 2030 and USD 720 in 2050, which is fully offset by reductions in the  level  of  energy  bills  (Figure 4.15).  In  emerging  market  and  developing  economies,  a

growing basket of energy services means increased use of energy, and total energy-related household spending increases. Additional investment moderates the change in energy bills, with  the  result  that  total  energy-related  spending  takes  2  percentage  points  more  of household disposable income in 2030 and 1 percentage point more in 2050 than today.

## 4.4.3 Behavioural changes

Behavioural changes play an important part in reducing energy demand and emissions in the NZE, especially in sectors where technical options for cutting emissions are limited in 2050. While  it  is  citizens  and  companies  that  modify  their  behaviour,  the  changes  are  mostly enabled by the policies and investments made by governments, and in some instances, they are required by laws or regulations. The Covid-19 pandemic has increased general awareness of the potential effectiveness of behavioural changes, such as mask-wearing, and working and schooling at home. The crisis demonstrated that people can make behavioural changes at significant speed and scale if they understand the changes to be justified, and that it is necessary for governments to explain convincingly and to provide clear guidance about what changes are needed and why they are needed.

Figure 4.16 ⊳ Emissions reductions from policy-driven and discretionary behavioural changes by citizens and companies in the NZE

<!-- image -->

IEA. All rights reserved.

Three-quarters of the emissions saved by behavioural changes could be directly influenced or mandated by government policies

Around three-quarters of the emissions saved by behavioural changes between 2020 and 2050  in the NZE  could  be  directly influenced  or mandated  by  government  policy (Figure 4.16). They include mitigation measures such as phasing out polluting cars from large cities  and  reducing  speed  limits  on  motorways.  The  other  one-quarter  involves  more discretionary  behavioural  changes,  such  as  reducing  wasteful  energy  use  in  homes  and

4

offices,  though  even  these  types  of  changes  could  be  promoted  through  awareness campaigns  and  other  means.  Around  10%  of  emissions  savings  directly  influenced  or mandated by government policy would require new  or redirected investment in infrastructure. For example, the shift in the NZE from regional flights to high-speed rail would necessitate building around 170 000 kilometres of new track globally by 2050 (a tripling of 2020 levels).

Behavioural changes made by citizens and companies play a roughly equal role in reducing emissions in the NZE. Most changes in road transport and energy-saving in homes would depend on individuals, whereas the private sector has the primary role in reducing energy demand  in  commercial  buildings  and  pursuing  materials  efficiency  in  manufacturing. Companies can also influence behavioural changes indirectly, for example, by promoting the use of public transport by employees that commute or encouraging working from home. However,  a  simple  distinction  between  the  role  for  individuals  and  companies  masks  a complex underlying dynamic: it is ultimately citizens as consumers of energy-related goods and services who shape corporate strategies, but at the same time companies do much to influence and generate consumer demand through marketing and advertising. In the NZE, consumers and companies move together in adopting behavioural changes, with governments setting the direction of those changes and facilitating them via effective and sustained policy support.

The behavioural changes in the NZE happen to different extents in different regions, and reflect a range of geographical and infrastructure constraints, as well as existing behavioural norms  and  cultural  preferences.  In  countries  with  low  rates  of  car  ownership  or  energy service demand in buildings, many of the behavioural changes in advanced economies in NZE would not be relevant or appropriate. As a result, around half of the emissions savings from behavioural changes are in emerging market and developing economies, despite around 95% of activity growth in buildings and road transport between 2020 and 2050 occurring there. Nevertheless,  there  are  significant  opportunities  in  emerging  market  and  developing economies  for  materials  efficiency  and  urban  design  to  decouple  growth  in  economic prosperity and energy services from increases in emissions. For example, around 85% of CO2 emissions reductions from cement and steel making in 2050 are due to gains in materials efficiency in emerging market and developing economies.

Cities are important to the behavioural changes in the NZE. Urban design can reduce the average  city  dweller's  carbon  footprint  by  up  to  60%  by  shaping  lifestyle  choices  and influencing day-to-day behaviour. For example, compact cities with clustered amenities can shorten average trip lengths; digitalisation can help shared private mobility to become the de facto option to accommodate much of the growth in service demand; and urban green infrastructure can reduce cooling demand (Feyisa, Dons &amp; Meilby, 2014).

## 4.5 Governments

## 4.5.1 Energy security

Energy security is an important consideration for governments and those they serve, and the pathway to net-zero emissions must take account of it. Concerns about energy security have traditionally  been  associated  with  oil  and  natural  gas  supplies.  The  drop  in  oil  and  gas demand and the increased diversity of the energy sources used in the NZE may reduce some risks, but they do not disappear. There are also new potential vulnerabilities associated with the need to maintain reliable, flexible and secure electricity systems, and with the increase in  demand  for  raw  minerals  for  clean  energy  technologies.  Improving  energy  efficiency remains the central measure for increasing energy security - even with rapid growth in lowemissions electricity generation, the safest energy supplies are those that are not needed.

## Oil and gas security

No new oil and natural gas fields are required in the NZE beyond those already approved for development, and supplies become increasingly concentrated in a small number of low-cost producers. For oil, OPEC's share of global oil supply grows from around 37% in recent years to 52% in 2050, a level higher than at any point in the history of oil markets (Figure 4.17). For natural gas, inter-regional liquefied natural gas (LNG) trade increases from 420 bcm in 2020 over the next five years but it then falls to around 160 bcm in 2050. Nearly all exports in 2050 come from the lowest cost and lowest emissions producers. This means that the importance of ensuring adequate supplies of oil and natural gas to the smooth functioning of the global energy system would be quantitatively lower in 2050 than today, but it does not suggest that the risk of a shortfall in supply or sudden price rise is necessarily going to diminish, and a shortfall or sudden price rise would still have large repercussions for a number of sectors.

Figure 4.17 ⊳ Global oil supply and LNG exports by region in the NZE

<!-- image -->

IEA. All rights reserved.

Increased reliance on OPEC and other producer economies suffering from falling oil and gas revenues could pose a risk to supply security in consuming countries

4

Even if the timing and ambition of emission reduction policies are clear, the changes in the NZE clearly have implications for producers and consumers alike. Many producer economies would see oil and gas revenues drop to some of the lowest ever levels (see section 4.2.2). Even  if  these  producers  increase  their  market  share,  and  diversify  their  economies  and sources of tax revenue, they are likely to struggle to finance essential spending at current levels. This could have knock-on effects for social stability, and that in turn could potentially threaten the smooth delivery of oil and gas to consuming countries. Moves on the part of producer economies to gain market share or a failure to maintain upstream operations while managing the extreme strains that would be placed on their fiscal balances could lead to turbulent and volatile markets, greatly complicating the task facing policy makers.

## Electricity security

The rapid electrification of all sectors in the NZE, and the associated increase in electricity's share of total final consumption from 20% in 2020 to nearly 50% in 2050, puts electricity even more at the heart of energy security across the world than it already is (IEA, 2020h). Greater reliance on electricity has both positive and negative implications for overall energy security. One  advantage  for  energy-importing  countries  is  that  they  become  more self-sufficient, since a much higher share of electricity supply is based on domestic sources in the NZE than is the case for other fuels. However the increased importance of electricity means  that  any  electricity  system  disruption  would  have  larger  impacts.  Electricity infrastructure is often more vulnerable to physical shocks such as extreme weather events than  pipelines  and  underground  storage  facilities,  and  climate  change  is  likely  to  put increasing pressure on electricity systems, for example through more frequent droughts that might decrease the availability of water for hydropower and for cooling at thermal power plants. The resilience of electricity systems needs to be enhanced to mitigate these risks and maintain  electricity  security,  including  through  more  robust  contingency  planning,  with solutions based on digital technologies and physical system hardening (IEA, 2021b).

Cybersecurity could pose an even greater risk to electricity security as systems incorporate more digitalised monitoring and controls in a growing number of power plants, electricity network assets and storage facilities. Policy makers have a central part to play in ensuring that the cyber resilience of electricity is enhanced, and there are a number of ways in which they can pursue this (IEA, 2021c).

Maintaining  electricity  security  also  requires  a  range  of  measures  to  ensure  flexibility, adequacy and reliability at all times. Enhanced electricity system flexibility is of particular importance  as  the  share  of  variable  renewables  in  the  generation  mix  rises.  As  a consequence, electricity system flexibility quadruples globally in the NZE in parallel with a more than two-and-a half-fold increase in electricity supply.  A portfolio of flexibility sources 9 -  including  power  plants,  energy  storage  and  demand  response  supported  by  electricity

9 Electricity system flexibility is quantified here based on hour-to-hour ramping needs, which is only one aspect of flexibility that also includes actions on much shorter time scales to maintain frequency and other ancillary services.

networks - is  used  to  match  supply  and  demand  at  all  times  of  the  year,  under  varying weather conditions and levels of demand. There is a significant shift in the NZE from using coal-  and  gas-fired  power  plants  for  the  provision  of  flexibility  to  the  use  of  renewables, hydrogen, battery storage, and demand-side response (Figure 4.18).

Figure 4.18 ⊳ Electricity system flexibility by source in the NZE

<!-- image -->

IEA. All rights reserved.

To meet four-times the amount of hour-to-hour flexibility needs, batteries and demand response step up to become the primary sources of flexibility

Electricity  demand  also  becomes  much  more  flexible  as  a  result  of  the  use  of  demand response measures, e.g. to shift consumption to times when renewable energy is plentiful. Conventional sources of demand response such as moderating industry activities remain important, but new areas of demand response such as smart charging of EVs unlock valuable new  ways  of  supplementing  them. 10 As  the  EV  fleet  expands  in  the  NZE,  EVs  provide  a significant  portion  of  total  electricity  system  flexibility.  Although  the  technology  already exists, the roll-out of smart charging has been slow to date due to institutional and regulatory barriers; these hurdles are overcome in the NZE. Measures are also implemented to ensure that  the  digitalisation  of  charging  and  other  sources  of  flexibility  does  not  compromise cybersecurity, and that potential social acceptance issues are addressed.

Energy storage also plays an important role in the provision of flexibility in the NZE. The deployment of battery storage systems is already starting to accelerate and to contribute to the management of short-duration flexibility needs, but the massive scale up to 3 100 GW of storage  in  2050  (with  four  hour  duration  on  average)  envisaged  in  the  NZE  hinges  on overcoming current regulatory and market design barriers. Pumped hydropower offers an attractive means of providing flexibility over a matter of hours and days, while hydrogen has

10 Smart  chargers  share  real-time  data  with  a  centralised  platform  to  allow  system  operators  to  optimise charging profiles based on how much energy the vehicle needs over a specified span of time, how much is available, the price of wholesale electricity, grid congestion and other parameters.

4

the potential to play an important part in longer term seasonal storage since it can be stored in converted gas storage facilities that have several orders of magnitude more capacity than battery storage projects.

Dispatchable power is essential to the secure transition of electricity systems, and in the NZE this comes increasingly from low-emissions sources. Hydropower provides a significant part of  flexibility  in  many  electricity  systems  today,  and  this  continues  in  the  future,  with particular emphasis on expanding pumped hydro facilities. Nuclear power and geothermal plants, though designed for baseload generation, also provide a degree of flexibility in the NZE, but there are constraints on how much these sources can be expanded. This leaves an important role for thermal power plants that are equipped with carbon capture or use lowemissions fuels. For example, the use of sustainable biomass or low-emissions ammonia in existing  coal  plants  offers  a  way  of  allowing  these  facilities  to  continue  to  contribute  to flexibility and capacity adequacy, while at the same time reducing CO2 emissions. Additional measures will also be necessary to maintain power system stability (Box 4.1).

## Box 4.1 ⊳ Power system stability with high shares of variable renewables

Stability is a key feature of electricity security, allowing systems to remain in balance and withstand disturbances such as sudden  generator or grid outages. Historically, conventional  generators  such  as  nuclear,  hydro  and  fossil  fuels  have  been  central  to electricity  system  stability,  providing  inertia  with  rotating  machines  that  allow  stored kinetic energy to be instantly converted into power in case of a system disturbance, and generating a voltage signal that helps all generators remain synchronous.

In contrast, newer technologies such as solar PV, wind and batteries are connected to the system through converters. They generally do not contribute to system inertia and are configured as 'grid-following' units, synchronising to conventional generators. Maintaining system stability will call for new approaches as the share of converter based resources, and in particular variable renewables, rises much higher in electricity systems.

There is a growing body of knowledge and studies on stability in systems with high shares of  variable  renewables.  For  example,  a  recent  joint  study  by  the  IEA  and  RTE,  the transmission system operator in France, analyses the conditions under which it would be technically feasible to integrate high shares of variable renewables in France (IEA, 2021d). Based on the findings of this study:

-  One option to ensure stability for a net zero power system is to maintain a minimum amount of conventional generation from low-carbon technologies during hours of high shares VRE output. This approach to maintain stability comes at the cost of solar and wind curtailment at high shares.
-  Updated grid codes can be used to call for variable renewables and batteries to provide  fast  frequency  response  services,  which  can  help  reduce  the  amount  of conventional generation needed for stability.

-  Synchronous condensers are able to provide inertia without generating electricity. The  technology  is  already  proven  at  GW-scale  in  Denmark  and  also  in  South Australia, but experience needs to be expanded at larger scale.
-  Grid-forming converters can allow variable renewables and batteries to generate a voltage signal, though experience with this approach needs to move beyond microgrids and small islands to large interconnected systems.

Demonstration projects, stakeholder consultations and international collaboration will be critical to fully understand the merits of each of these four approaches and the scope for a portfolio of options that would most cost-effectively achieve net zero emissions while maintaining electricity security.

Electricity networks support and enable the use of all sources of flexibility, balancing demand and supply over large areas. Timely investment in grids to minimise congestion and expand the size of the areas where supply and demand are balanced will be critical to making the best  use  of  solar  PV  and  wind  projects,  and  ensuring  affordable  and  reliable  supplies  of electricity. Expanding long-distance transmission also makes a key contribution in the NZE, since a lack of available land near demand centres and other factors mean new sources of generation are often located in remote areas. It is important that new transmission systems are  built  with  variable,  bidirectional  operation  in  mind  in  order  to  maximise  the  use  of available flexibility sources, and that regulatory and market arrangements support flexible connections between systems. The key value of interconnections comes from complementary  electricity  demand  and  wind  patterns:  solar PV  output  is  more  highly correlated than wind over large areas.

The NZE sees a major increase in demand for critical minerals such as copper, lithium, nickel, cobalt and rare earth elements that are essential for many clean energy technologies. There are several potential vulnerabilities that could hinder the adequate supply of these minerals and lead to price volatility (IEA, 2021a). Today's production and processing operations for many minerals  are  highly  concentrated  in  a  small  number  of  countries,  making  supplies vulnerable to political instability, geopolitical risks and possible export restrictions. In many cases,  there  are  also  concerns  about  land-use  changes,  competition  for  scarce  water resources, corruption and misuse of government resources, fatalities and injuries to workers, and human rights abuses, including the use of child labour. New critical mineral projects can have long lead times, so the rapid increase in demand in the NZE could lead to a mismatch in timing between supply and demand. The international trade and investment regime is key to maintaining reliable mineral supplies, but policy support and international co-ordination will be needed to ensure the application of rigorous environmental and social regulations.

4

## 4.5.2 Infrastructure

Getting to net-zero emissions will require huge amounts of new infrastructure and lots of modifications  to  existing  assets.  Energy  infrastructure  is  transformed  in  the  NZE  as  all countries  and  regions  move  from  systems  supporting  the  use  of  fossil  fuels  and  the distribution of conventionally generated electricity to systems based largely on renewable electricity and low-emissions fuels. In many emerging market and developing economies, the provision of large amounts of infrastructure would be necessary in the coming decades in any case, creating a window of opportunity to support the transition to a net-zero emissions economy. In all countries, governments will play a central role in planning, financing and regulating the development of infrastructure. Some of the main infrastructure components - electricity networks and EV charging, pipelines systems for low-emissions fuels and CO2, and transport infrastructure - are discussed below.

The rapid increase in electricity demand in the NZE and the transition to renewable energy call  for  an  expansion  and  modernisation  of  electricity  networks  (Figure 4.19).  This  would require a sharp reversal in the recent trend of declining investment: failure to achieve this would almost certainly make the energy transition for net-zero emissions impossible. Tariff design and permitting procedures also need to be revised to reflect fundamental changes in the provision and uses of electricity. Some of the main considerations include:

-  Long-distance transmission . Most of the growth in renewables in the NZE comes from centralised sources. Yet the best solar and wind resources are often in remote regions, requiring new transmission connections. Ultra high-voltage direct current systems are likely to play an important role in supporting transmission over long distances.
-  Local distribution . Energy efficiency gains in households and wider use of rooftop solar PV mean surplus electricity will be available more often, while electric heat pumps and residential  EV  charging  points  will  require  electricity  to  be  more  widely  available. Together these developments point to the need for substantial increases in distribution network capacity.
-  Grid  substations . The  massive  expansion  of  solar  PV  and  wind  requires  new  grid substations:  their  capacity  expands  by  more  than  57 000 GW  in  the  NZE  by  2030, doubling current capacity globally.
-  EV charging . Major new public charging networks are built in the NZE, including in work places, highway service stations and residential complexes, to support EV expansion and long-distance driving on highways.
-  Digitalisation of networks . With a large increase in the use of connected devices, the digitalisation of grid assets supports more flexible grid operations, better management of variable renewables and more efficient demand response.

Figure 4.19 ⊳ Annual average electricity grid expansion, replacement and substation capacity growth in the NZE

<!-- image -->

IEA. All rights reserved.

Grid and substation expansion is driven largely by the massive deployment of renewables and electrification of end-uses, with a rising digital share of infrastructure

Note: Substation capacity here assumes active electricity is equal to apparent electricity.

Pipelines continue to play a key role in the transmission and distribution of energy in the NZE:

-  Given the rapid decline of fossil fuels, significant investment in new oil and gas pipelines are not needed in the NZE. However investment is needed to link the production of lowemissions liquids and gases with consumption centres, and to convert existing pipelines and associated distribution infrastructure for the use of these low-emissions fuels. Some low-emissions fuels, such as biomethane and synthetic hydrogen-based fuels, can make use of existing infrastructure without any modifications, but pure hydrogen requires a retrofit of existing pipelines. New dedicated hydrogen infrastructure is also needed in the  NZE,  for  example  to  move  hydrogen  produced  in  remote  areas  with  excellent renewable resources to demand centres.
-  The expansion of CCUS in the NZE requires investment in CO2 transport and storage capacity.  By  2050,  7.6 Gt  of  CO   is  captured  worldwide,  requiring  a  large  amount  of 2 pipeline  and  shipping  infrastructure  linking  the  facilities  where  CO   is  captured  with 2 storage  sites. Industrial clusters, including  ports,  may  offer  the  best  near-term opportunities  to  build  CO2  pipeline  and  hydrogen  infrastructure,  as  the  various industries  in  those  clusters  using  the  new  infrastructure  would  be  able  to  share  the upfront investment needs (Figure 4.20).

4

## Figure 4.20 ⊳ Illustrative example of a shared CO2 pipeline in an industrial cluster

Deployment of technologies like CCUS and hydrogen and their enabling infrastructure would benefit strongly from a cross-sectoral approach in industrial clusters

<!-- image -->

Transforming transport infrastructure represents both a challenge and an opportunity. The challenge arises from the potential increase in the energy and carbon intensity of economic growth during the infrastructure development phase. 11 Steel and cement are the two main components  of  virtually  all  infrastructure  projects,  but  they  are  also  among  the  most challenging  sectors  to  decarbonise.  The  opportunity  comes  from  the  scope  that  exists  in some countries to develop infrastructure from scratch in a way that is compatible with the net  zero  goal.  Countries  undergoing  rapid  urbanisation  today  can  design  and  steer  new infrastructure development towards higher urban density and high-capacity mass transit in tandem with EV charging and low-emissions fuelling systems.

Rail  has  an  important part to play as transport infrastructure is developed. The NZE sees large-scale investment in all regions in high-speed trains to replace both long-distance car driving  and  short-haul  aviation.  It  also  sees  large-scale  investment  in  all  regions  in  track, control systems, rolling stock modernisation and combined freight facilities to improve speed and flexibility for just-in-time logistical operations and thus support a shift of freight from road to rail, especially for container traffic.

11 The modelling for the NZE incorporates the increase in steel and cement that is required to build additional transport  infrastructure  (roads,  cars  and  trucks)  and  energy  infrastructure,  e.g.  power  plants  and  wind turbines.

## 4.5.3 Tax revenues from retail energy sales

The slump in the consumption of fossil fuels required to get to net-zero emissions would result in the loss of a large amount of tax revenue in many countries, given that fuels such as oil-based transport fuels and natural gas are often subject to high excise or other special taxes. In recent years, energy-related taxes accounted for around 4% of total government tax  revenues  in  advanced  economies  on  average  and  3.5%  in  emerging  market  and developing economies, but they provided as much as 10% in some countries (OECD, 2020).

Figure 4.21 ⊳ Global revenues from taxes on retail sales of oil and gas in the NZE

<!-- image -->

Tax revenue from oil and natural gas retail sales falls by close to 90% between 2020 and 2050 in  the  NZE (Figure 4.21). Governments are likely to need to rely on some combination of other tax revenues and public spending reforms to compensate. Some taxation measures focused on the energy sector could be useful. However, any such taxes would need to be carefully designed  to minimise  their impact  on  low-income  households,  as  poorer households spend a higher percentage of their disposable income on electricity and heating. Options for energy-related taxes include:

-  CO2 prices . These are introduced in all regions in the NZE, albeit at different levels for countries and sectors, which provide additional revenue streams. The reduction in oil and natural gas excise taxes is more than compensated over the next 15 years by higher revenues from CO2 prices related to these fuels paid by end users and other sectors, but these too fall as the global energy system moves towards net-zero emissions.
-  Road fees and congestion charges . These would have the added benefit of discouraging driving and encouraging switching to other less carbon-intensive modes of transport.

4

-  Increasing taxation on electricity . Higher taxes on all electricity sales could generate substantial revenues, especially since large increases in price often have little effect on consumption. This might be counterproductive, however, as it would reduce the costeffectiveness of both EVs and heat pumps, which could slow their adoption, although this risk could be mitigated by the introduction of CO2 prices.

Natural gas is currently less taxed than transport fuels in most countries. Introducing and raising  CO2 prices  for  natural  gas  used  in  buildings,  mostly  for  heating,  would  accelerate energy efficiency improvements and boost government revenues, although care would be needed to avoid disproportionately impacting low-income households. Taxing natural gas used  in  industry  would  improve  the  competitiveness  of  less  carbon-intensive  fuels  and technologies  such  as  hydrogen,  but  would  run  the  risk  of  undermining  the  international competitiveness  of  energy-intensive  sectors and  carbon  leakage  in  the absence  of co-ordinated global action or border carbon-tax adjustments.

## 4.5.4 Innovation

Without a major acceleration in clean energy innovation, reaching net-zero emissions by 2050 will not be achievable. Technologies that are available on the market today provide nearly all of the emissions reductions required to 2030 in the NZE to put the world on track for  net-zero  emissions  by  2050.  However,  reaching  net-zero  emissions  will  require  the widespread use after 2030 of technologies that are still under development today. In 2050, almost 50% of CO2 emissions reductions in the NZE come from technologies currently at demonstration or prototype stage (Figure 4.22). This share is even higher in sectors such as heavy industry and long-distance transport. Major innovation efforts are vital in this decade so that the technologies necessary for net-zero emissions reach markets as soon as possible.

Figure 4.22 ⊳ Global CO2 emissions changes by technology maturity category in the NZE

<!-- image -->

While the emissions reductions in 2030 mostly rely on technologies on the market, those under development today account for almost half of the emissions reductions in 2050

Innovation cycles for early stage clean energy technologies are much more rapid in the NZE than what has typically been achieved historically, and most clean energy technologies that have not been demonstrated at scale today reach markets by 2030 at the latest. This means the time from first prototype to market introduction is on average 20% faster than the fastest energy technology developments in the past, and around 40% faster than was the case for solar  PV  (Figure 4.23).  Technologies at the demonstration stage, such as CCUS in cement production or low-emissions ammonia-fuelled ships, are brought into the market in the next three to four years. Hydrogen-based steel production, direct air capture (DAC) and other technologies at the large prototype stage reach the market in about six years, while most technologies at small prototype stage - such as solid state refrigerant-free cooling or solid state batteries - do so within the coming nine years.

Figure 4.23 ⊳ Time from first prototype to market introduction for selected technologies in the NZE and historical examples

<!-- image -->

IEA. All rights reserved.

Technology development cycles are cut by around 20% from the fastest developments seen in the past

Note: H2  =  hydrogen;  CCUS  =  carbon  capture,  utilisation  and  storage;  LED  =  light-emitting  diode;  Li-ion  = lithium-ion.

Sources: IEA analysis based on Carbon Engineering, 2021; Greco, 2019; Tenova, 2018; Gross, 2018; European Cement Research Academy, 2012; Kamaya, 2011; Zemships, 2008.

An acceleration of this magnitude is clearly ambitious. It requires technologies that are not yet available  on  the  market  to  be  demonstrated  very  quickly  at  scale  in  multiple configurations and in various regional contexts. In most cases, these demonstrations are run in parallel in the  NZE.  This  is  in  stark  contrast  with  typical  practice  in  technology development: learning is usually transferred across consecutive demonstration projects in different contexts to build confidence before widespread deployment commences.

The acceleration that is needed also requires a large increase in investment in demonstration projects. In the NZE, USD 90 billion is mobilised as soon as possible to complete a portfolio

4

of demonstration projects before 2030: this is much more than the roughly USD 25 billion budgeted  by  governments  to  2030.  Most  of  these  projects  are  concerned  with  the electrification  of  end-uses,  CCUS,  hydrogen  and  sustainable  bioenergy,  mainly  for  longdistance transport and heavy industrial applications.

Increased public funding helps to manage the risks of such first-of-a-kind projects and to leverage private investment in research and development (R&amp;D) in the NZE. This represents a  reversal  of  recent  trends:  government  spending  on  energy  R&amp;D  worldwide,  including demonstration projects, has fallen as a share of GDP from a peak of almost 0.1% in 1980 to just 0.03% in 2019. Public funding also becomes better aligned with the innovations needed to  reach  net-zero  emissions.  In  the  NZE,  electrification,  CCUS,  hydrogen  and  sustainable bioenergy account for nearly half of the cumulative emissions reductions to 2050. Just three technologies are critical in enabling around 15% of the cumulative emissions reductions in the  NZE  between  2030  and  2050:  advanced  high-energy  density  batteries,  hydrogen electrolysers and DAC.

## Governments drive innovation in the NZE

Bringing  new  energy  technologies  to  market  can  often  take  several  decades,  but  the imperative of reaching net-zero emissions globally by 2050 means that progress has to be much faster. Experience has shown that the role of government is crucial in shortening the time needed to bring new technology to market and to diffuse it widely (IEA, 2020i). The government role includes educating people, funding R&amp;D, providing networks for knowledge exchange, protecting intellectual property, using public procurement to boost deployment, helping  companies  innovate,  investing  in  enabling  infrastructure  and  setting  regulatory frameworks for markets and finance.

Knowledge transfer from first-mover countries can also help in the acceleration needed, and is particularly important in the early phases of adoption when new technologies are typically not competitive with incumbent technologies. For example, in the case of solar PV, national laboratories played a key role in the early development phase in the United States, projects supported directly by government in Japan created market niches for initial deployment and government  procurement  and  incentive  policies  in  Germany,  Italy,  Spain,  United  States, China,  Australia  and  India  fostered  a  global  market.  Lithium-ion  (Li-ion)  batteries  were initially developed through public and private research that took place mostly in Japan, their first energy-related commercial operation was made possible in the United States, and mass manufacturing today is primarily in China.

Many of the biggest clean energy technology challenges could benefit from a more targeted approach to speed up progress  (Diaz Anadon, 2012; Mazzucato, 2018). In the NZE, concerted government  action  leverages  private  sector  investment  and  leads  to  advances  in  clean energy technologies that are currently at different stages of development.

-  To  2030,  the  focus  of  government  action  is  on  bringing  new  zero-  or  low-emissions technologies to market. For example, in the NZE, steel starts to be produced using lowemissions hydrogen at the scale of a conventional steel plant, large ships start to be

fuelled  by  low-emissions  ammonia and electric trucks begin operating on solid state batteries.  In  parallel,  there  is  rapid  acceleration  in  the  deployment  of  low-emissions technologies that are already available on the market but that have not yet reached mass  market  scale,  bringing  down  the  costs  of  manufacturing,  construction  and operating such technologies due to learning-by-doing and economies of scale.

-  From 2030 to 2040, technology advances are consolidated  to scale up nascent lowemissions technologies and expand clean energy infrastructure. Clean energy technologies  that  are  in  the  laboratory  or  at  small  prototype  stage  today  become commercial. For example, fuels are replaced by electricity in cement kilns and steam crackers for high value chemicals production.
-  From 2040 to 2050, technologies at a very early stage of development today are adopted in promising niche markets. By 2050, clean energy technologies that are at demonstration or large prototype stage today become mainstream for purchases and new  installations,  and  they  compete  with  present  conventional  technologies  in  all regions. For example, ultra high-energy density batteries are used in aircraft for short flights.

## 4.5.5 International co-operation

The  pathway  to  net-zero  emissions  by  2050  will  require  an  unprecedented  level  of international co-operation between governments. This is not only a matter of all countries participating in efforts to meet the net zero goal, but also of all countries working together in  an  effective  and  mutually  beneficial  manner.  Achieving  net-zero  emissions  will  be extremely challenging for all countries, but the challenges are toughest and the solutions least easy to deliver in lower income countries, and technical and financial support will be essential  to  ensure  the  early  stage  deployment  of  key  mitigation  technologies  and infrastructure in many of these countries. Without international co-operation, emissions will not fall to net zero by 2050.

There are four aspects of international co-operation that are particularly important (Victor, Geels and Sharpe, 2019).

-  International demand signals and economies of scale . International co-operation has been critical to the cost reductions seen in the past for many key energy technologies. It can accelerate knowledge transfer and promote economies of scale. It can also help align the creation of new demand for clean energy technologies and fuels in one region with the development of supply in other regions. These benefits need to be weighed against  the  importance  of  creating  domestic  jobs  and  industrial  capacities,  and  of ensuring supply chain resilience.
-  Managing trade and competitiveness . Industries that operate in a number of countries need  standardisation  to  ensure  inter-operability.  Progress  on  innovation  and  clean energy technology deployment in sectors such as heavy industry has been inhibited in the  past  by  uncoordinated  national  policies  and  a  lack  of  internationally  agreed

4

standards.  The  development  of  such  standards  could  accelerate  energy  technology development and deployment.

-  Innovation, demonstration and diffusion . Clean energy R&amp;D and patenting is currently concentrated  in  a  handful  of  places:  United  States,  Europe,  Japan,  Korea  and  China accounted for more than 90% of clean energy patents in 2014-18. Progress towards net-zero  emissions  would  be  increased  by  moving  swiftly  to  extend  experience  and knowledge of clean energy technologies in countries that are not involved in their initial development, and by funding first-of-a-kind demonstration projects in emerging market and developing economies. International programmes to fund demonstration projects, especially in sectors where technologies are large and complex, would accelerate the innovation process (IEA, 2020i).
-  Carbon dioxide removal (CDR) programmes . CDR technologies such as bioenergy and DAC equipped with CCUS are essential to provide emissions reductions at a global level. International co-operation is needed to fund and certify these programmes, so as to make the most of  suitable  land,  renewable  energy  potential  and  storage  resources, wherever they may be. International emissions trading mechanisms could play a role in offsetting emissions in some sectors or areas with negative emissions, though any such mechanisms would require a high degree of co-ordination to ensure market functioning and integrity.

The  NZE  assumes  that  international  co-operation  policies,  measures  and  efforts  are introduced to overcome these hurdles. To explore the potential implications of a failure to do so, we have devised a Low International Co-operation Case (Box 4.2). This examines what would happen if national efforts to mitigate climate change ramp up in line with the level of effort in the NZE but co-operation frameworks are not developed at the same speed. It shows that the lack of international co-operation has a major impact on innovation, technology demonstration, market co-ordination and ultimately on the emissions pathway.

## Box 4.2 ⊳ Framing the Low International Co-operation Case

To develop the Low International Co-operation Case , technologies and mitigation options were  assessed  and  grouped  based  on  their  current  degree  of  maturity  and  the importance of international co-operation to their deployment. Mature technologies in markets that are firmly established and that have a low exposure to international cooperation  are  assumed  to  have  the  same  deployment  pathways  as  in  the  NZE. Technologies and mitigation options where co-operation is needed to achieve scale and avoid duplication, that have a large exposure to international trade and competitiveness, that  depend  on  large  and  very  capital-intensive  demonstration  programmes,  or  that require support to create market pull and standardisation to ensure inter-operability, are assumed to be deployed more slowly (Malhotra and Schmidt, 2020). Compared with the NZE, these technologies are delayed by 5-10 years in their initial deployment in advanced economies and by 10-15 years in emerging market and developing economies.

Figure 4.24 ⊳ CO2 emissions in the Low International Co-operation Case and the NZE

<!-- image -->

Without international co-operation, the transition to net zero would be delayed by decades

Weak  international  co-operation  slows  the  deployment  of  mitigation  options  that  are currently  in  the  demonstration  phase  (Figure 4.24).  This  includes  emissions  reductions  in heavy industry, trucks, aviation, shipping and CDR. The energy transition proceeds unevenly as a result. Over the next 20 years in the Low International Co-operation Case, emissions decline at a rapid but still slower pace than in the NZE in electricity generation, cars, light industry and buildings. However, emissions reductions are much slower in other areas. After the mid-2030s, the pace of emissions reductions worldwide slows markedly relative to the NZE, and the transition to net zero is delayed by decades. Just over 40% of the 15 Gt CO2 of emissions remaining in 2050 are in heavy industry, where the slower pace of demonstration and  diffusion  of  mitigation  technologies  is  particularly  significant  (Figure 4.25).  A  further one-third of the residual emissions in 2050 are from aviation, shipping and trucks. Here the slower scale up and diffusion of advanced biofuels, hydrogen-based fuels and high-energy density batteries hinders progress. The absence of co-operation to support the deployment of  new  projects  in  emerging  market  and  developing  economies  means  that  emissions reductions there are much slower than in the NZE.

These  results  highlight  the  importance  for  governments  of  strengthening  international co-operation. A strong push is needed to accelerate innovation and the demonstration of key technologies, especially for complex technologies in emerging market and developing economies  where  costs  for  first-of-a-kind  projects  are  generally  higher,  and  to  address concerns about international trade and competitiveness so as to ensure a just transition for all.

4

Figure 4.25 ⊳ CO2 emissions in the Low International Co-operation Case and the NZE in selected sectors in 2050

<!-- image -->

CO2 emissions in 2050 in the Low International Co-operation Case are concentrated in the industry and transport sectors

Note: Other energy sector = fuel production and direct air capture.

<!-- image -->

<!-- image -->

## Tables for scenario projections

## General note to the tables

This annex includes global historical and projected data for the Net-Zero Emissions by 2050 scenario  for  the  following  data  sets:  energy  supply,  energy  demand,  gross  electricity generation and  electrical capacity, carbon  dioxide (CO2) emissions from  fossil fuel combustion and industrial processes, and selected economic and activity indicators.

The definitions for fuels and sectors are in Annex C. Common abbreviations used in the tables include:  EJ  =  exajoules;  CAAGR  =  compound average annual growth rate; CCUS = carbon capture, utilisation and storage. Consumption of fossil fuels in facilities without CCUS are classified as 'unabated'.

Both in the text of this report and in the tables, rounding may lead to minor differences between totals and the sum of their individual components. Growth rates are calculated on a compound average annual basis and are marked 'n.a.' when the base year is zero or the value exceeds 200%. Nil values are marked '-'.

To download the tables in Excel format go to: iea.li/nzedata .

## Data sources

The formal base year for the scenario projections is 2019, as this is the last year for which a complete picture of energy demand and production is available. However, we have used more recent data when available, and we include our 2020 estimates for energy production and demand in this annex. Estimates for the year 2020 are based on updates of the IEA's Global Energy Review reports which are derived from a number of sources, including the latest monthly data submissions to the IEA's Energy Data Centre, other statistical releases from national administrations, and recent market data from the IEA Market Report Series that cover coal, oil, natural gas, renewables and power.

Historical  data  for  gross  electrical  capacity  are  drawn  from  the  S&amp;P  Global  Market Intelligence World Electric Power Plants Database (March 2020 version) and the International Atomic Energy Agency PRIS database.

## Definitional note: A.1. Energy supply and transformation table

Total energy supply (TES) is equivalent to electricity and heat generation plus 'other energy sector' excluding electricity and heat, plus total final consumption (TFC) excluding electricity and heat. TES does not include ambient heat from heat pumps or electricity trade. Solar in TES includes solar PV generation, concentrating solar power and final consumption of solar thermal. Other renewables in TES include geothermal, and marine (tide and wave) energy for  electricity  and  heat  generation.  Hydrogen  production  and  biofuels  production  in  the other energy sector account for the energy input required to produce merchant hydrogen (mainly natural gas and electricity) and for the conversion losses to produce biofuels (mainly primary  solid  biomass)  used  in  the  energy  sector.  While  not  itemised  separately,  nonrenewable waste and other sources are included in TES.

I

## Definitional note: A.2. Energy demand table

Sectors comprising total final consumption (TFC) include industry (energy use and feedstock), transport, buildings (residential, services and non-specified other) and other (agriculture and other non-energy use). Energy demand from international marine and aviation bunkers are included in transport totals.

## Definitional note: A.3. Electricity tables

Electricity  generation  expressed  in  terawatt-hours  (TWh)  and  installed  electrical  capacity data expressed in gigawatts (GW) are both provided on a gross basis (i.e. includes own use by  the  generator).  Projected  gross  electrical  capacity  is  the  sum  of  existing  capacity  and additions, less retirements. While not itemised separately, other sources are included in total electricity generation.

## Definitional note: A.4. CO2 emissions table

Total  CO2  includes  carbon  dioxide  emissions  from  the  combustion  of  fossil  fuels  and non-renewable wastes, from industrial and fuel transformation processes (process emissions) as well as CO2 removals. Three types of CO2 removals are presented:

-  Captured  and  stored  emissions  from  the  combustion  of  bioenergy  and  renewable wastes (typically electricity generation).
-  Captured and stored process emissions from biofuels production.
-  Captured and stored carbon dioxide from the atmosphere, which is reported as direct air carbon capture and storage (DACCS).

The  first  two  entries  are  often  reported  as  bioenergy  with  carbon  capture  and  storage (BECCS). Note that some of the CO2 captured from biofuels production and direct air capture is used to produce synthetic fuels, which is not included as CO2 removal.

Total  CO2  captured  includes  the  carbon  dioxide  captured  from  CCUS  facilities  (such  as electricity generation or industry) and atmospheric CO2 captured through direct air capture but excludes that captured and used for urea production.

## Definitional note: A.5. Economic and activity indicators

The  emission  intensity  expressed  in  kilogrammes  of  carbon  dioxide  per  kilowatt-hour (kg CO2/kWh) is calculated based on electricity-only plants and the electricity component of combined heat and power (CHP) plants. 1

Other  abbreviations  used  include:  PPP  =  purchasing  power  parity;  GJ  =  gigajoules; Mt = million  tonnes;  pkm  =  passenger-kilometres;  tkm  =  tonnes-kilometres;  m   =  square 2 metres.

1 To derive the associated electricity-only emissions from CHP plants, we assume that the heat production of a CHP plant is 90% efficient and the remainder of the fuel input is allocated to electricity generation.

Table A.1: Energy supply and transformation

|                              | Energy supply (EJ)   | Energy supply (EJ)   | Energy supply (EJ)   | Energy supply (EJ)   | Energy supply (EJ)   | Shares (%)   | Shares (%)   | Shares (%)   | CAAGR (%)   | CAAGR (%)   |
|------------------------------|----------------------|----------------------|----------------------|----------------------|----------------------|--------------|--------------|--------------|-------------|-------------|
|                              | 2019                 | 2020                 | 2030                 | 2040                 | 2050                 | 2020         | 2030         | 2050         | 2020- 2030  | 2020- 2050  |
| Total energy supply          | 612                  | 587                  | 547                  | 535                  | 543                  | 100          | 100          | 100          | -0.7        | -0.3        |
| Renewables                   | 67                   | 69                   | 167                  | 295                  | 362                  | 12           | 30           | 67           | 9.3         | 5.7         |
| Solar                        | 4                    | 5                    | 32                   | 78                   | 109                  | 1            | 6            | 20           | 21          | 11          |
| Wind                         | 5                    | 6                    | 29                   | 67                   | 89                   | 1            | 5            | 16           | 17          | 9.6         |
| Hydro                        | 15                   | 16                   | 21                   | 27                   | 30                   | 3            | 4            | 6            | 2.9         | 2.2         |
| Modern solid bioenergy       | 31                   | 32                   | 54                   | 73                   | 73                   | 5            | 10           | 14           | 5.3         | 2.8         |
| Modern liquid bioenergy      | 4                    | 3                    | 12                   | 14                   | 15                   | 1            | 2            | 3            | 14          | 4.9         |
| Modern gaseous bioenergy     | 2                    | 2                    | 5                    | 10                   | 14                   | 0            | 1            | 3            | 10          | 6.4         |
| Other renewables             | 4                    | 5                    | 13                   | 24                   | 32                   | 1            | 2            | 6            | 11          | 6.7         |
| Traditional use of biomass   | 25                   | 25                   | -                    | -                    | -                    | 4            | -            | -            | n.a.        | n.a.        |
| Nuclear                      | 30                   | 29                   | 41                   | 54                   | 61                   | 5            | 8            | 11           | 3.5         | 2.4         |
| Unabated natural gas         | 139                  | 136                  | 116                  | 44                   | 17                   | 23           | 21           | 3            | -1.6        | -6.6        |
| Natural gas with CCUS        | 0                    | 1                    | 13                   | 31                   | 43                   | 0            | 2            | 8            | 37          | 16          |
| Oil                          | 190                  | 173                  | 137                  | 79                   | 42                   | 29           | 25           | 8            | -2.3        | -4.6        |
| of which non-energy use      | 28                   | 27                   | 32                   | 31                   | 29                   | 5            | 6            | 5            | 1.4         | 0.2         |
| Unabated coal                | 160                  | 154                  | 68                   | 16                   | 3                    | 26           | 12           | 1            | -7.9        | -12         |
| Coal with CCUS               | 0                    | 0                    | 4                    | 16                   | 14                   | 0            | 1            | 3            | 60          | 22          |
| Electricity and heat sectors | 233                  | 230                  | 240                  | 308                  | 371                  | 100          | 100          | 100          | 0.4         | 1.6         |
| Renewables                   | 36                   | 38                   | 107                  | 220                  | 284                  | 17           | 44           | 77           | 11          | 6.9         |
| Solar PV                     | 2                    | 3                    | 25                   | 61                   | 84                   | 1            | 10           | 23           | 24          | 12          |
| Wind                         | 5                    | 6                    | 29                   | 67                   | 89                   | 2            | 12           | 24           | 17          | 9.6         |
| Hydro                        | 15                   | 16                   | 21                   | 27                   | 30                   | 7            | 9            | 8            | 2.9         | 2.2         |
| Bioenergy                    | 9                    | 10                   | 18                   | 35                   | 39                   | 4            | 8            | 10           | 6.3         | 4.6         |
| Other renewables             | 4                    | 4                    | 14                   | 30                   | 42                   | 2            | 6            | 11           | 14          | 8.5         |
| Hydrogen                     | -                    | -                    | 5                    | 11                   | 11                   | -            | 2            | 3            | n.a.        | n.a.        |
| Ammonia                      | -                    | -                    | 1                    | 2                    | 2                    | -            | 0            | 0            | n.a.        | n.a.        |
| Nuclear                      | 30                   | 29                   | 41                   | 54                   | 61                   | 13           | 17           | 16           | 3.5         | 2.4         |
| Unabated natural gas         | 56                   | 55                   | 49                   | 4                    | 2                    | 24           | 21           | 0            | -1.1        | -11         |
| Natural gas with CCUS        | -                    | -                    | 1                    | 5                    | 5                    | -            | 1            | 1            | n.a.        | n.a.        |
| Oil                          | 9                    | 8                    | 2                    | 0                    | 0                    | 4            | 1            | 0            | -12         | -14         |
| Unabated coal                | 102                  | 100                  | 30                   | 0                    | 0                    | 43           | 12           | 0            | -11         | -34         |
| Coal with CCUS               | 0                    | 0                    | 3                    | 10                   | 7                    | 0            | 1            | 2            | 55          | 19          |
| Other energy sector          | 57                   | 57                   | 61                   | 76                   | 91                   | 100          | 100          | 100          | 0.7         | 1.5         |
| Hydrogen production          | -                    | 0                    | 21                   | 49                   | 70                   | 0            | 35           | 77           | 66          | 23          |
| Biofuels production          | 5                    | 6                    | 12                   | 15                   | 12                   | 10           | 20           | 13           | 8           | 2.7         |

IEA. All rights reserved.

A

Table A.2: Energy demand

|                         | Energy demand (EJ)   | Energy demand (EJ)   |   Energy demand (EJ) |   Energy demand (EJ) |   Energy demand (EJ) | Shares (%)   |   Shares (%) |   Shares (%) | CAAGR (%)   | CAAGR (%)   |
|-------------------------|----------------------|----------------------|----------------------|----------------------|----------------------|--------------|--------------|--------------|-------------|-------------|
|                         | 2019                 | 2020                 |                 2030 |                 2040 |                 2050 | 2020         |         2030 |         2050 | 2020- 2030  | 2020- 2050  |
| Total final consumption | 435                  | 412                  |                  394 |                  363 |                  344 | 100          |          100 |          100 | -0.4        | -0.6        |
| Electricity             | 82                   | 81                   |                  103 |                  140 |                  169 | 20           |           26 |           49 | 2.4         | 2.5         |
| Liquid fuels            | 175                  | 158                  |                  143 |                   96 |                   66 | 38           |           36 |           19 | -1.0        | -2.9        |
| Biofuels                | 4                    | 3                    |                   12 |                   14 |                   15 | 1            |            3 |            4 | 14          | 4.9         |
| Ammonia                 | -                    | -                    |                    1 |                    3 |                    5 | -            |            0 |            1 | n.a.        | n.a.        |
| Synthetic oil           | -                    | -                    |                    0 |                    2 |                    5 | -            |            0 |            1 | n.a.        | n.a.        |
| Oil                     | 171                  | 154                  |                  129 |                   77 |                   42 | 37           |           33 |           12 | -1.8        | -4.2        |
| Gaseous fuels           | 70                   | 68                   |                   68 |                   60 |                   53 | 16           |           17 |           15 | 0.1         | -0.8        |
| Biomethane              | 0                    | 0                    |                    2 |                    5 |                    8 | 0            |            1 |            2 | 25          | 13          |
| Hydrogen                | 0                    | 0                    |                    6 |                   12 |                   20 | 0            |            2 |            6 | 54          | 20          |
| Synthetic methane       | -                    | -                    |                    0 |                    1 |                    4 | -            |            0 |            1 | n.a.        | n.a.        |
| Natural gas             | 70                   | 67                   |                   58 |                   40 |                   20 | 16           |           15 |            6 | -1.4        | -4.0        |
| Solid fuels             | 92                   | 89                   |                   61 |                   46 |                   35 | 22           |           16 |           10 | -3.6        | -3.0        |
| Biomass                 | 39                   | 39                   |                   24 |                   25 |                   25 | 9            |            6 |            7 | -4.8        | -1.4        |
| Coal                    | 53                   | 50                   |                   38 |                   21 |                   10 | 12           |           10 |            3 | -2.8        | -5.3        |
| Heat                    | 13                   | 13                   |                   12 |                    9 |                    6 | 3            |            3 |            2 | -1.2        | -2.7        |
| Other                   | 3                    | 3                    |                    7 |                   11 |                   15 | 1            |            2 |            4 | 8.2         | 5.2         |
| Industry                | 162                  | 157                  |                  170 |                  169 |                  160 | 100          |          100 |          100 | 0.8         | 0.1         |
| Electricity             | 35                   | 35                   |                   47 |                   62 |                   74 | 22           |           28 |           46 | 3.0         | 2.5         |
| Liquid fuels            | 31                   | 31                   |                   31 |                   27 |                   23 | 20           |           18 |           15 | -0.2        | -0.9        |
| Oil                     | 31                   | 31                   |                   31 |                   27 |                   23 | 20           |           18 |           15 | -0.2        | -0.9        |
| Gaseous fuels           | 32                   | 32                   |                   35 |                   34 |                   28 | 20           |           21 |           18 | 1.0         | -0.4        |
| Biomethane              | 0                    | 0                    |                    1 |                    2 |                    4 | 0            |            0 |            3 | 22          | 15          |
| Hydrogen                | -                    | 0                    |                    3 |                    4 |                    5 | 0            |            2 |            3 | 44          | 15          |
| Unabated natural gas    | 32                   | 32                   |                   30 |                   22 |                    9 | 20           |           18 |            6 | -0.5        | -4.0        |
| Natural gas with CCUS   | 0                    | 0                    |                    1 |                    5 |                    7 | 0            |            1 |            4 | 38          | 18          |
| Solid fuels             | 58                   | 52                   |                   51 |                   40 |                   30 | 34           |           30 |           18 | -0.3        | -1.9        |
| Biomass                 | 10                   | 9                    |                   15 |                   19 |                   20 | 6            |            9 |           13 | 5.2         | 2.8         |
| Unabated coal           | 48                   | 44                   |                   35 |                   15 |                    3 | 28           |           20 |            2 | -2.3        | -9.0        |
| Coal with CCUS          | 0                    | 0                    |                    1 |                    5 |                    7 | 0            |            1 |            4 | 91          | 31          |
| Heat                    | 6                    | 6                    |                    6 |                    3 |                    2 | 4            |            3 |            1 | -1.2        | -4.5        |
| Other                   | 0                    | 0                    |                    1 |                    3 |                    4 | 0            |            1 |            2 | 33          | 14          |
| Iron and steel          | 36                   | 33                   |                   37 |                   36 |                   32 | 21           |           22 |           20 | 1.1         | -0.2        |
| Chemicals               | 22                   | 20                   |                   26 |                   26 |                   25 | 13           |           15 |           15 | 2.7         | 0.7         |
| Cement                  | 12                   | 16                   |                   11 |                   11 |                   10 | 10           |            7 |            7 | -3.3        | -1.3        |

Table A.2: Energy demand

|                            | Energy demand (EJ)   |   Energy demand (EJ) | Energy demand (EJ)   | Energy demand (EJ)   | Energy demand (EJ)   |   Shares (%) | Shares (%)   | Shares (%)   | CAAGR (%)   | CAAGR (%)   |
|----------------------------|----------------------|----------------------|----------------------|----------------------|----------------------|--------------|--------------|--------------|-------------|-------------|
|                            | 2019                 |                 2020 | 2030                 | 2040                 | 2050                 |         2020 | 2030         | 2050         | 2020- 2030  | 2020- 2050  |
| Transport                  | 122                  |                  105 | 102                  | 85                   | 80                   |          100 | 100          | 100          | -0.3        | -0.9        |
| Electricity                | 1                    |                    1 | 7                    | 22                   | 35                   |            1 | 7            | 44           | 17          | 11          |
| Liquid fuels               | 115                  |                   99 | 89                   | 53                   | 30                   |           94 | 87           | 38           | -1.0        | -3.9        |
| Biofuels                   | 4                    |                    3 | 11                   | 12                   | 11                   |            3 | 11           | 14           | 14          | 4.3         |
| Oil                        | 111                  |                   96 | 76                   | 35                   | 9                    |           91 | 74           | 12           | -2.2        | -7.4        |
| Gaseous fuels              | 5                    |                    5 | 6                    | 10                   | 15                   |            5 | 6            | 18           | 2.1         | 3.7         |
| Biomethane                 | 0                    |                    0 | 1                    | 1                    | 2                    |            0 | 0            | 2            | 23          | 11          |
| Hydrogen                   | 0                    |                    0 | 1                    | 6                    | 13                   |            0 | 1            | 16           | 92          | 34          |
| Natural gas                | 5                    |                    5 | 4                    | 2                    | 0                    |            5 | 4            | 0            | -1.5        | -11         |
| Road                       | 90                   |                   81 | 73                   | 57                   | 50                   |           77 | 72           | 63           | -0.9        | -1.6        |
| Passenger cars             | 47                   |                   41 | 30                   | 19                   | 17                   |           39 | 29           | 21           | -3.1        | -2.9        |
| Trucks                     | 27                   |                   25 | 28                   | 24                   | 22                   |           24 | 27           | 28           | 1.1         | -0.4        |
| Aviation                   | 14                   |                    8 | 13                   | 13                   | 14                   |            8 | 13           | 18           | 4.6         | 1.7         |
| Shipping                   | 12                   |                   11 | 11                   | 10                   | 10                   |           10 | 11           | 12           | 0.4         | -0.3        |
| Buildings                  | 129                  |                  127 | 99                   | 89                   | 86                   |          100 | 100          | 100          | -2.4        | -1.3        |
| Electricity                | 43                   |                   42 | 45                   | 51                   | 57                   |           33 | 46           | 66           | 0.7         | 1.0         |
| Liquid fuels               | 13                   |                   13 | 9                    | 4                    | 2                    |           10 | 10           | 2            | -3.2        | -6.0        |
| Biofuels                   | 0                    |                    0 | 0                    | 1                    | 1                    |            0 | 0            | 1            | 26          | 12          |
| Oil                        | 13                   |                   13 | 9                    | 4                    | 1                    |           10 | 9            | 1            | -3.4        | -7.7        |
| Gaseous fuels              | 30                   |                   28 | 23                   | 13                   | 6                    |           22 | 23           | 7            | -2.1        | -4.9        |
| Biomethane                 | 0                    |                    0 | 1                    | 2                    | 2                    |            0 | 1            | 2            | 29          | 11          |
| Hydrogen                   | -                    |                    0 | 2                    | 2                    | 2                    |            0 | 2            | 2            | 103         | 27          |
| Natural gas                | 30                   |                   28 | 19                   | 7                    | 1                    |           22 | 20           | 1            | -3.8        | -12         |
| Solid fuels                | 34                   |                   34 | 10                   | 7                    | 6                    |           27 | 10           | 7            | -11         | -5.5        |
| Modern biomass             | 5                    |                    5 | 9                    | 7                    | 6                    |            4 | 9            | 7            | 6.9         | 0.9         |
| Traditional use of biomass | 25                   |                   25 | -                    | -                    | -                    |           20 | -            | -            | n.a.        | n.a.        |
| Coal                       | 4                    |                    4 | 1                    | 0                    | 0                    |            3 | 1            | 0            | -12         | -21         |
| Heat                       | 7                    |                    7 | 6                    | 5                    | 4                    |            5 | 6            | 5            | -1.2        | -1.6        |
| Other                      | 2                    |                    3 | 5                    | 8                    | 11                   |            2 | 5            | 12           | 7.1         | 4.8         |
| Residential                | 91                   |                   90 | 67                   | 59                   | 58                   |           71 | 67           | 67           | -3.0        | -1.5        |
| Services                   | 38                   |                   36 | 32                   | 30                   | 28                   |           29 | 33           | 33           | -1.2        | -0.9        |
| Other                      | 22                   |                   23 | 22                   | 20                   | 18                   |          100 | 100          | 100          | -0.5        | -0.9        |

A

Table A.3: Electricity

|                        | Electricity Generation (TWh)   | Electricity Generation (TWh)   | Electricity Generation (TWh)   | Electricity Generation (TWh)   | Electricity Generation (TWh)   | Shares (%)   |   Shares (%) |   Shares (%) | CAAGR (%)   | CAAGR (%)   |
|------------------------|--------------------------------|--------------------------------|--------------------------------|--------------------------------|--------------------------------|--------------|--------------|--------------|-------------|-------------|
|                        | 2019                           | 2020                           | 2030                           | 2040                           | 2050                           | 2020         |         2030 |         2050 | 2020- 2030  | 2020- 2050  |
| Total generation       | 26 922                         | 26 778                         | 37 316                         | 56 553                         | 71 164                         | 100          |          100 |          100 | 3.4         | 3.3         |
| Renewables             | 7 153                          | 7 660                          | 22 817                         | 47 521                         | 62 333                         | 29           |           61 |           88 | 12          | 7.2         |
| Solar PV               | 665                            | 821                            | 6 970                          | 17 031                         | 23 469                         | 3            |           19 |           33 | 24          | 12          |
| Wind                   | 1 423                          | 1 592                          | 8 008                          | 18 787                         | 24 785                         | 6            |           21 |           35 | 18          | 9.6         |
| Hydro                  | 4 294                          | 4 418                          | 5 870                          | 7 445                          | 8 461                          | 17           |           16 |           12 | 2.9         | 2.2         |
| Bioenergy              | 665                            | 718                            | 1 407                          | 2 676                          | 3 279                          | 3            |            4 |            5 | 7.0         | 5.2         |
| of which BECCS         | -                              | -                              | 129                            | 673                            | 842                            | -            |            0 |            1 | n.a.        | n.a.        |
| CSP                    | 14                             | 14                             | 204                            | 880                            | 1 386                          | 0            |            1 |            2 | 31          | 17          |
| Geothermal             | 92                             | 94                             | 330                            | 625                            | 821                            | 0            |            1 |            1 | 13          | 7.5         |
| Marine                 | 1                              | 2                              | 27                             | 77                             | 132                            | 0            |            0 |            0 | 28          | 14          |
| Nuclear                | 2 792                          | 2 698                          | 3 777                          | 4 855                          | 5 497                          | 10           |           10 |            8 | 3.4         | 2.4         |
| Hydrogen-based         | -                              | -                              | 875                            | 1 857                          | 1 713                          | -            |            2 |            2 | n.a.        | n.a.        |
| Fossil fuels with CCUS | 1                              | 4                              | 459                            | 1 659                          | 1 332                          | 0            |            1 |            2 | 61          | 21          |
| Coal with CCUS         | 1                              | 4                              | 289                            | 966                            | 663                            | 0            |            1 |            1 | 54          | 19          |
| Natural gas with CCUS  | -                              | -                              | 170                            | 694                            | 669                            | -            |            0 |            1 | n.a.        | n.a.        |
| Unabated fossil fuels  | 16 941                         | 16 382                         | 9 358                          | 632                            | 259                            | 61           |           25 |            0 | -5.4        | -13         |
| Coal                   | 9 832                          | 9 426                          | 2 947                          | 0                              | 0                              | 35           |            8 |            0 | -11         | -40         |
| Natural gas            | 6 314                          | 6 200                          | 6 222                          | 626                            | 253                            | 23           |           17 |            0 | 0.0         | -10         |
| Oil                    | 795                            | 756                            | 189                            | 6                              | 6                              | 3            |            1 |            0 | -13         | -15         |

|                        | Electrical Capacity (GW)   | Electrical Capacity (GW)   | Electrical Capacity (GW)   | Electrical Capacity (GW)   | Electrical Capacity (GW)   | Shares (%)   |   Shares (%) |   Shares (%) | CAAGR (%)   | CAAGR (%)   |
|------------------------|----------------------------|----------------------------|----------------------------|----------------------------|----------------------------|--------------|--------------|--------------|-------------|-------------|
|                        | 2019                       | 2020                       | 2030                       | 2040                       | 2050                       | 2020         |         2030 |         2050 | 2020- 2030  | 2020- 2050  |
| Total capacity         | 7 484                      | 7 795                      | 14 933                     | 26 384                     | 33 415                     | 100          |          100 |          100 | 6.7         | 5.0         |
| Renewables             | 2 707                      | 2 994                      | 10 293                     | 20 732                     | 26 568                     | 38           |           69 |           80 | 13          | 7.5         |
| Solar PV               | 603                        | 737                        | 4 956                      | 10 980                     | 14 458                     | 9            |           33 |           43 | 21          | 10          |
| Wind                   | 623                        | 737                        | 3 101                      | 6 525                      | 8 265                      | 9            |           21 |           25 | 15          | 8.4         |
| Hydro                  | 1 306                      | 1 327                      | 1 804                      | 2 282                      | 2 599                      | 17           |           12 |            8 | 3.1         | 2.3         |
| Bioenergy              | 153                        | 171                        | 297                        | 534                        | 640                        | 2            |            2 |            2 | 5.7         | 4.5         |
| of which BECCS         | -                          | -                          | 28                         | 125                        | 152                        | -            |            0 |            0 | n.a.        | n.a.        |
| CSP                    | 6                          | 6                          | 73                         | 281                        | 426                        | 0            |            0 |            1 | 28          | 15          |
| Geothermal             | 15                         | 15                         | 52                         | 98                         | 126                        | 0            |            0 |            0 | 13          | 7.4         |
| Marine                 | 1                          | 1                          | 11                         | 32                         | 55                         | 0            |            0 |            0 | 34          | 16          |
| Nuclear                | 415                        | 415                        | 515                        | 730                        | 812                        | 5            |            3 |            2 | 2.2         | 2.3         |
| Hydrogen-based         | -                          | -                          | 139                        | 1 455                      | 1 867                      | -            |            1 |            6 | n.a.        | n.a.        |
| Fossil fuels with CCUS | 0                          | 1                          | 81                         | 312                        | 394                        | 0            |            1 |            1 | 66          | 25          |
| Coal with CCUS         | 0                          | 1                          | 53                         | 182                        | 222                        | 0            |            0 |            1 | 59          | 22          |
| Natural gas with CCUS  | -                          | -                          | 28                         | 130                        | 171                        | -            |            0 |            1 | n.a.        | n.a.        |
| Unabated fossil fuels  | 4 351                      | 4 368                      | 3 320                      | 1 151                      | 677                        | 56           |           22 |            2 | -2.7        | -6.0        |
| Coal                   | 2 124                      | 2 117                      | 1 192                      | 432                        | 158                        | 27           |            8 |            0 | -5.6        | -8.3        |
| Natural gas            | 1 788                      | 1 829                      | 1 950                      | 679                        | 495                        | 23           |           13 |            1 | 0.6         | -4.3        |
| Oil                    | 440                        | 422                        | 178                        | 39                         | 25                         | 5            |            1 |            0 | -8.3        | -9.0        |
| Battery storage        | 11                         | 18                         | 585                        | 2 005                      | 3 097                      | 0            |            4 |            9 | 42          | 19          |

## Table A.4: CO  emissions 2

|                              | CO 2 emissions (Mt CO 2 )   | CO 2 emissions (Mt CO 2 )   | CO 2 emissions (Mt CO 2 )   | CO 2 emissions (Mt CO 2 )   | CO 2 emissions (Mt CO 2 )   | CAAGR (%)   | CAAGR (%)   |
|------------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-------------|-------------|
|                              | 2019                        | 2020                        | 2030                        | 2040                        | 2050                        | 2020- 2030  | 2020- 2050  |
| Total CO 2 *                 | 35 926                      | 33 903                      | 21 147                      | 6 316                       | 0                           | -4.6        | n.a.        |
| Combustion activities (+)    | 33 499                      | 31 582                      | 19 254                      | 6 030                       | 940                         | -4.8        | -11         |
| Coal                         | 14 660                      | 14 110                      | 5 915                       | 1 299                       | 195                         | -8.3        | -13         |
| Oil                          | 11 505                      | 10 264                      | 7 426                       | 3 329                       | 928                         | -3.2        | -7.7        |
| Natural gas                  | 7 259                       | 7 138                       | 5 960                       | 1 929                       | 566                         | -1.8        | -8.1        |
| Bioenergy and waste          | 75                          | 71                          | - 48                        | - 528                       | - 748                       | n.a.        | n.a.        |
| Industry removals (-)        | 1                           | 1                           | 214                         | 914                         | 1 186                       | 75          | 28          |
| Biofuels production          | 1                           | 1                           | 142                         | 385                         | 553                         | 68          | 24          |
| Direct air capture           | -                           | -                           | 71                          | 528                         | 633                         | n.a.        | n.a.        |
| Electricity and heat sectors | 13 821                      | 13 504                      | 5 816                       | - 81                        | - 369                       | -8.1        | n.a.        |
| Coal                         | 10 035                      | 9 786                       | 2 950                       | 102                         | 69                          | -11         | -15         |
| Oil                          | 655                         | 628                         | 173                         | 6                           | 6                           | -12         | -14         |
| Natural gas                  | 3 131                       | 3 089                       | 2 781                       | 268                         | 128                         | -1.0        | -10         |
| Bioenergy and waste          | -                           | -                           | - 87                        | - 457                       | - 572                       | n.a.        | n.a.        |
| Other energy sector*         | 1 457                       | 1 472                       | 679                         | - 85                        | - 368                       | -7.4        | n.a.        |
| Final consumption*           | 20 647                      | 18 928                      | 14 723                      | 7 011                       | 1 370                       | -2.5        | -8.4        |
| Coal                         | 4 486                       | 4 171                       | 2 935                       | 1 186                       | 117                         | -3.5        | -11         |
| Oil                          | 10 272                      | 9 077                       | 6 973                       | 3 242                       | 880                         | -2.6        | -7.5        |
| Natural gas                  | 3 451                       | 3 332                       | 2 668                       | 1 453                       | 303                         | -2.2        | -7.7        |
| Bioenergy and waste          | 75                          | 71                          | 40                          | - 70                        | - 176                       | -5.6        | n.a.        |
| Industry*                    | 8 903                       | 8 478                       | 6 892                       | 3 485                       | 519                         | -2.0        | -8.9        |
| Iron and steel               | 2 507                       | 2 349                       | 1 778                       | 859                         | 220                         | -2.7        | -7.6        |
| Chemicals                    | 1 344                       | 1 296                       | 1 199                       | 654                         | 66                          | -0.8        | -9.5        |
| Cement                       | 2 461                       | 2 334                       | 1 899                       | 906                         | 133                         | -2.0        | -9.1        |
| Transport                    | 8 290                       | 7 153                       | 5 719                       | 2 686                       | 689                         | -2.2        | -7.5        |
| Road                         | 6 116                       | 5 483                       | 4 077                       | 1 793                       | 340                         | -2.9        | -8.9        |
| Passenger cars               | 3 121                       | 2 746                       | 1 626                       | 547                         | 85                          | -5.1        | -11         |
| Trucks                       | 1 835                       | 1 721                       | 1 614                       | 890                         | 198                         | -0.6        | -6.9        |
| Aviation                     | 1 019                       | 621                         | 783                         | 469                         | 210                         | 2.4         | -3.5        |
| Shipping                     | 883                         | 800                         | 705                         | 348                         | 122                         | -1.3        | -6.1        |
| Buildings                    | 3 007                       | 2 860                       | 1 809                       | 685                         | 122                         | -4.5        | -10         |
| Residential                  | 2 030                       | 1 968                       | 1 377                       | 541                         | 108                         | -3.5        | -9.2        |
| Services                     | 977                         | 892                         | 432                         | 144                         | 14                          | -7.0        | -13         |
| Total CO 2 removals          | 1                           | 1                           | 317                         | 1 457                       | 1 936                       | 79          | 29          |
| Total CO 2 captured          | 40                          | 40                          | 1 665                       | 5 619                       | 7 602                       | 45          | 19          |

*Includes industrial process emissions.

A

Table A.5: Economic and Activity Indicators

|                                          | Indicator   | Indicator   | Indicator   | Indicator   | Indicator   | CAAGR (%)   | CAAGR (%)   |
|------------------------------------------|-------------|-------------|-------------|-------------|-------------|-------------|-------------|
|                                          | 2019        | 2020        | 2030        | 2040        | 2050        | 2020- 2030  | 2020- 2050  |
| Population (million)                     | 7 672       | 7 753       | 8 505       | 9 155       | 9 692       | 0.9         | 0.7         |
| GDP (USD 2019 billion, PPP)              | 134 710     | 128 276     | 184 037     | 246 960     | 316 411     | 3.7         | 3.1         |
| GDP per capita (USD 2019, PPP)           | 17 558      | 16 545      | 21 638      | 26 975      | 32 648      | 2.7         | 2.3         |
| TES/GDP (GJ per USD 1 000, PPP)          | 4.543       | 4.578       | 2.973       | 2.164       | 1.716       | -4.2        | -3.2        |
| TFC/GDP (GJ per USD 1 000, PPP)          | 3.231       | 3.208       | 2.139       | 1.468       | 1.086       | -4.0        | -3.5        |
| TES per capita (GJ)                      | 79.77       | 75.74       | 64.33       | 58.38       | 56.03       | -1.6        | -1.0        |
| CO 2 intensity of electricity generation | 0.468       | 0.438       | 0.138       | -0.001      | -0.005      | -11         | n.a.        |
| (kg CO 2 per kWh)                        |             |             |             |             |             |             |             |

|                                       | Activity   | Activity   | Activity   | Activity   | Activity   | CAAGR (%)   | CAAGR (%)   |
|---------------------------------------|------------|------------|------------|------------|------------|-------------|-------------|
|                                       | 2019       | 2020       | 2030       | 2040       | 2050       | 2020- 2030  | 2020- 2050  |
| Industrial production                 |            |            |            |            |            |             |             |
| Primary chemicals (Mt)                | 538        | 529        | 641        | 686        | 688        | 1.9         | 0.9         |
| Steel (Mt)                            | 1 869      | 1 781      | 1 937      | 1 958      | 1 987      | 0.8         | 0.4         |
| Cement (Mt)                           | 4 215      | 4 054      | 4 258      | 4 129      | 4 032      | 0.5         | -0.0        |
| Transport                             |            |            |            |            |            |             |             |
| Passenger cars (billion vkm)          | 15 300     | 14 261     | 15 775     | 19 159     | 24 517     | 1.0         | 1.8         |
| Trucks (billion tkm)                  | 26 646     | 25 761     | 38 072     | 49 756     | 59 990     | 4.0         | 2.9         |
| Aviation (billion pkm)                | 8 506      | 5 474      | 10 271     | 11 573     | 14 566     | 6.5         | 3.3         |
| Shipping (billion tkm)                | 107 225    | 109 153    | 155 621    | 209 905    | 291 032    | 3.6         | 3.3         |
| Buildings                             |            |            |            |            |            |             |             |
| Services floor area (million m 2 )    | 49 670     | 49 825     | 58 867     | 68 576     | 78 157     | 1.7         | 1.5         |
| Residential floor area (million m 2 ) | 190 062    | 192 558    | 235 745    | 290 696    | 345 183    | 2.0         | 2.0         |
| Million households                    | 2 095      | 2 116      | 2 435      | 2 765      | 3 051      | 1.4         | 1.2         |

## Technology costs

## Electricity generation

Table B.1 ⊳ Electricity generation technology costs by selected region in the NZE

|                | Financing rate (%)   | Capital costs ($/kW)   | Capital costs ($/kW)   | Capital costs ($/kW)   | Capacity factor (%)   | Capacity factor (%)   | Capacity factor (%)   | Fuel, CO 2 and O&M ($/MWh)   | Fuel, CO 2 and O&M ($/MWh)   | Fuel, CO 2 and O&M ($/MWh)   | LCOE ($/MWh)   | LCOE ($/MWh)   | LCOE ($/MWh)   |
|----------------|----------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|------------------------------|------------------------------|------------------------------|----------------|----------------|----------------|
|                | All                  | 2020                   | 2030                   | 2050                   | 2020                  | 2030                  | 2050                  | 2020                         | 2030                         | 2050                         | 2020           | 2030           | 2050           |
| United States  | United States        | United States          | United States          | United States          | United States         | United States         | United States         | United States                | United States                | United States                | United States  | United States  | United States  |
| Nuclear        | 8.0                  | 5 000                  | 4 800                  | 4 500                  | 90                    | 80                    | 75                    | 30                           | 30                           | 30                           | 105            | 110            | 110            |
| Coal           | 8.0                  | 2 100                  | 2 100                  | 2 100                  | 20                    | n.a.                  | n.a.                  | 90                           | 170                          | 235                          | 220            | n.a.           | n.a.           |
| Gas CCGT       | 8.0                  | 1 000                  | 1 000                  | 1 000                  | 55                    | 25                    | n.a.                  | 50                           | 80                           | 105                          | 70             | 125            | n.a.           |
| Solar PV       | 3.7                  | 1 140                  | 620                    | 420                    | 21                    | 22                    | 23                    | 10                           | 10                           | 10                           | 50             | 30             | 20             |
| Wind onshore   | 3.7                  | 1 540                  | 1 420                  | 1 320                  | 42                    | 43                    | 44                    | 10                           | 10                           | 10                           | 35             | 35             | 30             |
| Wind offshore  | 4.5                  | 4 040                  | 2 080                  | 1 480                  | 42                    | 46                    | 48                    | 35                           | 20                           | 15                           | 115            | 60             | 40             |
| European Union | European Union       | European Union         | European Union         | European Union         | European Union        | European Union        | European Union        | European Union               | European Union               | European Union               | European Union | European Union | European Union |
| Nuclear        | 8.0                  | 6 600                  | 5 100                  | 4 500                  | 75                    | 75                    | 70                    | 35                           | 35                           | 35                           | 150            | 120            | 115            |
| Coal           | 8.0                  | 2 000                  | 2 000                  | 2 000                  | 20                    | n.a.                  | n.a.                  | 120                          | 205                          | 275                          | 250            | n.a.           | n.a.           |
| Gas CCGT       | 8.0                  | 1 000                  | 1 000                  | 1 000                  | 40                    | 20                    | n.a.                  | 65                           | 95                           | 120                          | 100            | 150            | n.a.           |
| Solar PV       | 3.2                  | 790                    | 460                    | 340                    | 13                    | 14                    | 14                    | 10                           | 10                           | 10                           | 55             | 35             | 25             |
| Wind onshore   | 3.2                  | 1 540                  | 1 420                  | 1 300                  | 29                    | 30                    | 31                    | 15                           | 15                           | 15                           | 55             | 45             | 40             |
| Wind offshore  | 4.0                  | 3 600                  | 2 020                  | 1 420                  | 51                    | 56                    | 59                    | 15                           | 10                           | 5                            | 75             | 40             | 25             |
| China          | China                | China                  | China                  | China                  | China                 | China                 | China                 | China                        | China                        | China                        | China          | China          | China          |
| Nuclear        | 7.0                  | 2 800                  | 2 800                  | 2 500                  | 80                    | 80                    | 80                    | 25                           | 25                           | 25                           | 65             | 65             | 60             |
| Coal           | 7.0                  | 800                    | 800                    | 800                    | 60                    | n.a.                  | n.a.                  | 75                           | 135                          | 195                          | 90             | n.a.           | n.a.           |
| Gas CCGT       | 7.0                  | 560                    | 560                    | 560                    | 45                    | 35                    | n.a.                  | 75                           | 100                          | 120                          | 90             | 115            | n.a.           |
| Solar PV       | 3.5                  | 750                    | 400                    | 280                    | 17                    | 18                    | 19                    | 10                           | 5                            | 5                            | 40             | 25             | 15             |
| Wind onshore   | 3.5                  | 1 220                  | 1 120                  | 1 040                  | 26                    | 27                    | 27                    | 15                           | 10                           | 10                           | 45             | 40             | 40             |
| Wind offshore  | 4.3                  | 2 840                  | 1 560                  | 1 000                  | 34                    | 41                    | 43                    | 25                           | 15                           | 10                           | 95             | 45             | 30             |
| India          | India                | India                  | India                  | India                  | India                 | India                 | India                 | India                        | India                        | India                        | India          | India          | India          |
| Nuclear        | 7.0                  | 2 800                  | 2 800                  | 2 800                  | 70                    | 70                    | 70                    | 30                           | 30                           | 30                           | 75             | 75             | 75             |
| Coal           | 7.0                  | 1 200                  | 1 200                  | 1 200                  | 50                    | n.a.                  | n.a.                  | 35                           | 50                           | 75                           | 65             | n.a.           | n.a.           |
| Gas CCGT       | 7.0                  | 700                    | 700                    | 700                    | 55                    | 50                    | n.a.                  | 45                           | 45                           | 50                           | 55             | 60             | n.a.           |
| Solar PV       | 5.8                  | 580                    | 310                    | 220                    | 20                    | 21                    | 21                    | 5                            | 5                            | 5                            | 35             | 20             | 15             |
| Wind onshore   | 5.8                  | 1 040                  | 980                    | 940                    | 26                    | 28                    | 29                    | 10                           | 10                           | 10                           | 50             | 45             | 40             |
| Wind offshore  | 6.6                  | 2 980                  | 1 680                  | 1 180                  | 32                    | 37                    | 38                    | 25                           | 15                           | 10                           | 130            | 70             | 45             |

Notes:  O&amp;M  =  operation  and  maintenance;  LCOE  =  levelised  cost  of  electricity;  kW  =  kilowatt;  MWh  = megawatt-hour; CCGT = combined-cycle gas turbine; n.a. = not applicable. Cost components and LCOE figures are rounded.

Sources: IEA analysis; IRENA Renewable Costing Alliance; IRENA (2020).

I

-  Major contributors  to  the  LCOE  include:  overnight  capital  costs;  capacity  factor  that describes  the  average  output  over  the  year  relative  to  the  maximum  rated  capacity (typical  values  provided);  the  cost  of  fuel  inputs;  plus  operation  and  maintenance. Economic lifetime assumptions are 25 years for solar PV, onshore and offshore wind.
-  Weighted average costs of capital (WACC) reflect analysis for utility-scale solar PV in the World Energy Outlook 2020 (IEA, 2020) and for offshore wind from the Offshore Wind Outlook 2019 (IEA, 2019). Onshore wind was assumed to have the same WACC as utilityscale solar PV. A standard WACC was assumed for nuclear power, coal- and gas-fired power plants (7-8% based on the stage of economic development).
-  Fuel, CO2 and O&amp;M costs reflect the average over the ten years following the indicated date in the projections.
-  The capital costs for nuclear power represent the 'nth-of-a-kind' costs for new reactor designs, with substantial cost reductions from the first-of-a-kind projects.

## Batteries and hydrogen

## Table B.2 ⊳ Capital costs for batteries and hydrogen production technologies in the NZE

|                                                    | 2020          | 2030        | 2050        |
|----------------------------------------------------|---------------|-------------|-------------|
| Battery packs for transport applications (USD/kWh) | 130 - 155     | 75 - 90     | 55 - 80     |
| Low-temperature electrolysers (USD/kW e )          | 835 - 1 300   | 255 - 515   | 200 - 390   |
| Natural gas with CCUS (USD/kW H 2 )                | 1 155 - 2 010 | 990 - 1 725 | 935 - 1 625 |

Notes: kWh = kilowatt-hour; kWe = kilowatt electric; CCUS = carbon capture, utilisation and storage; H2 = hydrogen. Capital costs for electrolysers and hydrogen production from natural gas with CCUS are overnight costs.

Source: IEA analysis.

<!-- image -->

## Definitions

This  annex  provides  general  information  on  terminology  used  throughout  this  report including: units and general conversion factors; definitions of fuels, processes and sectors; regional and country groupings; and abbreviations and acronyms.

## Units

Area

km 2

square kilometre

Mha

million hectares

Batteries

Wh/kg

Watt hours per kilogramme

Coal

Mtce

million tonnes of coal equivalent (equals 0.7 Mtoe)

Distance

km

kilometre

Emissions

ppm

parts per million (by volume)

tCO2

tonnes of carbon dioxide

Gt CO2-eq

gigatonnes of carbon-dioxide equivalent (using 100-year global

warming potentials for different greenhouse gases)

kg CO2-eq

kilogrammes of carbon-dioxide equivalent

g CO2/km

grammes of carbon dioxide per kilometre

kg CO2/kWh

kilogrammes of carbon dioxide per kilowatt-hour

Energy

EJ

exajoule

PJ

petajoule

TJ

terajoule

GJ

gigajoule

MJ

megajoule

boe

barrel of oil equivalent

toe

tonne of oil equivalent

ktoe

thousand tonnes of oil equivalent

Mtoe

million tonnes of oil equivalent

MBtu

million British thermal units

kWh

kilowatt-hour

MWh

megawatt-hour

GWh

gigawatt-hour

TWh

terawatt-hour

Gas

bcm

billion cubic metres

tcm

trillion cubic metres

Mass

kg

kilogramme (1 000 kg = 1 tonne)

kt

kilotonnes (1 tonne x 10 ) 3

Mt

million tonnes (1 tonne x 10 ) 6

Gt

gigatonnes (1 tonne x 10 9 )

I

E

Monetary

USD million

1 US dollar x 10 6

USD billion

1 US dollar x 10 9

USD trillion

1 US dollar x 10 12

USD/tCO2

US dollars per tonne of carbon dioxide

Oil

kb/d

thousand barrels per day

mb/d

million barrels per day

mboe/d

million barrels of oil equivalent per day

Power

W

watt (1 joule per second)

kW

kilowatt (1 watt x 10 ) 3

MW

megawatt (1 watt x 10 6 )

GW

gigawatt (1 watt x 10 ) 9

TW

terawatt (1 watt x 10 12 )

## General conversion factors for energy

|      | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|
|      | EJ                          | Gcal                        | Mtoe                        | MBtu                        | GWh                         |
| EJ   | 1                           | 238.8 x 10 6                | 23.88                       | 9.47.8 x 10 3               | 2.778 x 10 5                |
| Gcal | 4.1868 x 10 -9              | 1                           | 10 -7                       | 3.968                       | 1.163 x 10 -3               |
| Mtoe | 4.1868 x 10 -2              | 10 7                        | 1                           | 3.968 x 10 7                | 11 630                      |
| MBtu | 1.0551 x 10 -9              | 0.252                       | 2.52 x 10 -8                | 1                           | 2.931 x 10 -4               |
| GWh  | 3.6 x 10 -6                 | 860                         | 8.6 x 10 -5                 | 3 412                       | 1                           |

Note: There is no generally accepted definition of boe; typically the conversion factors used vary from 7.15 to 7.40 boe per toe.

## Currency conversions

| Exchange rates (2019 annual average)   | 1 US dollar (USD) equals:   |
|----------------------------------------|-----------------------------|
| British Pound                          | 0.78                        |
| Chinese Yuan Renminbi                  | 6.91                        |
| Euro                                   | 0.89                        |
| Indian Rupee                           | 70.42                       |
| Indonesian Rupiah                      | 14 147.67                   |
| Japanese Yen                           | 109.01                      |
| Russian Ruble                          | 64.74                       |
| South African Rand                     | 14.45                       |

Source: OECD National Accounts Statistics: purchasing power parities and exchange rates dataset, July 2020.

## Definitions

Advanced bioenergy: Sustainable fuels produced from non-food crop feedstocks, which are capable of delivering significant lifecycle greenhouse gas emissions savings compared with fossil  fuel  alternatives,  and  which  do  not  directly  compete  with  food  and  feed  crops  for agricultural land or cause adverse sustainability impacts. This definition differs from the one used for 'advanced biofuels' in US legislation, which is based on a minimum 50% lifecycle greenhouse gas reduction and which, therefore, includes sugar cane ethanol.

Agriculture: Includes all energy used on farms, in forestry and for fishing.

Agriculture,  forestry  and  other  land  use (AFOLU) emissions: Includes  greenhouse  gas emissions from agriculture, forestry and other land use.

Ammonia (NH3)  Is a compound of nitrogen and hydrogen. It can be used directly as a fuel in : direct combustion process, and in fuel cells or as a hydrogen carrier. To be a low-carbon fuel, ammonia  must  be  produced  from  low-carbon  hydrogen,  the  nitrogen  separated  via  the Haber process, and electricity needs are met by low-carbon electricity.

Aviation: This transport mode includes both domestic and international flights and their use of aviation fuels. Domestic aviation covers flights that depart and land in the same country; flights for military purposes are also included. International aviation includes flights that land in a country other than the departure location.

Back-up generation capacity: Households and businesses connected to a main power grid may also have back-up electricity generation capacity that, in the event of disruption, can provide  electricity.  Back-up  generators  are  typically  fuelled  with  diesel  or  gasoline  and capacity can be as little as a few kilowatts. Such capacity is distinct from mini-grid and offgrid systems that are not connected to a main power grid.

Biodiesel: Diesel-equivalent, processed fuel made from the transesterification (a chemical process that converts triglycerides in oils) of vegetable oils and animal fats.

Bioenergy: Energy  content  in  solid,  liquid  and  gaseous  products  derived  from  biomass feedstocks and biogas. It includes solid biomass, liquid biofuels and biogases.

Biogas: A mixture of methane, carbon dioxide and small quantities of other gases produced by anaerobic digestion of organic matter in an oxygen-free environment.

Biogases: Include biogas and biomethane.

Biomethane: Biomethane is a near-pure source of methane produced either by upgrading biogas (a process that removes any CO2 and other contaminants present in the biogas) or through  the  gasification  of  solid  biomass  followed  by  methanation.  It  is  also  known  as renewable natural gas.

Buildings: The  buildings  sector  includes  energy  used  in  residential,  commercial  and institutional buildings and non-specified other. Building energy use includes space heating and cooling, water heating, lighting, appliances and cooking equipment.

I

E

A. All rights reserved.

C

Bunkers: Includes both international marine bunkers and international aviation bunkers.

Capacity  credit: Proportion  of  the  capacity  that  can  be  reliably  expected  to  generate electricity during times of peak demand in the grid to which it is connected.

Carbon capture, utilisation and storage (CCUS)  The process of capturing CO2 emissions from : fuel  combustion,  industrial  processes  or  directly  from  the  atmosphere.  Captured  CO2 emissions can be stored in underground geological formations, onshore or offshore or used as an input or feedstock to create products.

Clean  energy: Includes  renewables,  energy  efficiency,  low-carbon  fuels,  nuclear  power, battery storage and carbon capture, utilisation and storage.

Clean cooking facilities: Cooking facilities that are considered safer, more efficient and more environmentally sustainable than the traditional facilities that make use of solid biomass (such  as  a  three-stone  fire).  This  refers  primarily  to  improved  solid  biomass  cookstoves, biogas systems, liquefied petroleum gas stoves, ethanol and solar stoves.

Coal: Includes both primary coal (including lignite, coking and steam coal) and derived fuels (including patent fuel, brown-coal briquettes, coke-oven coke, gas coke, gas-works gas, cokeoven gas, blast furnace gas and oxygen steel furnace gas). Peat is also included.

Concentrating  solar  power (CSP)   Solar  thermal  power/electric  generation  systems  that : collect and concentrate sunlight to produce high temperature heat to generate electricity.

Conventional  liquid  biofuels: Fuels  produced  from  food  crop  feedstocks.  These  liquid biofuels are commonly referred to as first generation and include sugar cane ethanol, starchbased ethanol, fatty acid methyl esther (FAME) and straight vegetable oil (SVO).

Decomposition analysis: Statistical  approach  that  decomposes  an  aggregate  indicator  to quantify the relative contribution of a set of pre-defined factors leading to a change in the aggregate  indicator.  This report  uses  an  additive  index  decomposition  of  the  type Logarithmic Mean Divisia Index (LMDI).

Demand-side integration (DSI)  Consists of two types of measures: actions that influence : load shape such as energy efficiency and electrification; and actions that manage load such as demand-side response.

Demand-side response (DSR)  Describes actions which can influence the load profile such as : shifting  the  load  curve  in  time  without  affecting  the  total  electricity  demand,  or  load shedding  such  as  interrupting  demand  for  short  duration  or  adjusting  the  intensity  of demand for a certain amount of time.

Dispatchable  generation: Refers  to  technologies  whose  power  output  can  be  readily controlled - increased to maximum rated capacity or decreased to zero - in order to match supply with demand.

Electricity demand: Defined as total gross electricity generation less own use generation, plus net trade (imports less exports), less transmissions and distribution losses.

Electricity generation: Defined as the total amount of electricity generated by power only or combined  heat  and  power  plants  including  generation  required  for  own  use.  This  is  also referred to as gross generation.

Energy sector CO2 emissions: Carbon  dioxide  emissions  from  fuel  combustion  (excluding non-renewable waste). Note that this does not include fugitive emissions from fuels, CO2 from transport, storage emissions or industrial process emissions.

Energy sector GHG emissions: CO2 emissions from fuel combustion plus fugitive and vented methane, and nitrous oxide (N2O) emissions from the energy and industry sectors.

Energy services: See useful energy.

Ethanol: Refers to bio-ethanol only. Ethanol is produced from fermenting any biomass high in carbohydrates. Today, ethanol is made from starches and sugars, but second-generation technologies will allow it to be made from cellulose and hemicellulose, the fibrous material that makes up the bulk of most plant matter.

Fischer-Tropsch synthesis: Catalytic production process for the production of synthetic fuels. Natural gas, coal and biomass feedstocks can be used.

Gases: Includes natural gas, biogases, synthetic methane and hydrogen.

Geothermal: Geothermal energy is heat derived from the sub-surface of the earth. Water and/or steam carry the geothermal energy to the surface. Depending on its characteristics, geothermal  energy  can  be  used  for  heating  and  cooling  purposes  or  be  harnessed  to generate clean electricity if the temperature is adequate.

Heat (end-use): Can be obtained from the combustion of fossil or renewable fuels, direct geothermal or solar heat systems, exothermic chemical processes and electricity (through resistance heating or heat pumps which can extract it from ambient air and liquids). This category  refers  to  the  wide  range  of  end-uses,  including  space  and  water  heating,  and cooking in buildings, desalination and process applications in industry. It does not include cooling applications.

Heat  (supply): Obtained  from  the  combustion  of  fuels,  nuclear  reactors,  geothermal resources and the capture of sunlight. It may be used for heating or cooling, or converted into  mechanical  energy  for  transport  or  electricity  generation.  Commercial  heat  sold  is reported under total final consumption with the fuel inputs allocated under electricity and heat sectors.

Hydrogen: Hydrogen is used in the energy system to refine hydrocarbon fuels  and  as  an energy carrier in its own right. It is also produced from other  energy  products  for  use  in chemicals production. As an energy carrier it can be produced from hydrocarbon fuels or from the electrolysis of water with electricity, and can be burned or used in fuel cells for electricity and heat in a wide variety of applications. To be low-carbon hydrogen, either the emissions associated with fossil-based hydrogen production must be prevented (for example by  carbon  capture,  utilisation  and  storage)  or  the  electricity  input  to  hydrogen  produced from water must be low-carbon electricity. In this report, final  consumption  of  hydrogen

I

E

A. All rights reserved.

C

includes demand for pure hydrogen and excludes hydrogen produced and consumed onsite by  the  same  entity.  Demand  for  hydrogen-based  fuels  such  as  ammonia  or  synthetic hydrocarbons are considered separately.

Hydrogen-based fuels: Include  ammonia and synthetic hydrocarbons (gases and liquids). Hydrogen-based is used in figures to refer to hydrogen and hydrogen-based fuels.

Hydropower: The energy content of the electricity produced in hydropower plants, assuming 100% efficiency. It excludes output from pumped storage and marine (tide and wave) plants.

Industry: The sector includes fuel used within the manufacturing and construction industries. Key industry branches include iron and steel, chemicals and petrochemicals, cement, and pulp and paper. Consumption of fuels for the transport of goods is reported as part of the transport sector, while consumption by off-road vehicles is reported under industry.

International  aviation  bunkers: Includes  the  deliveries  of  aviation  fuels  to  aircraft  for international  aviation.  Fuels  used  by  airlines  for  their  road  vehicles  are  excluded.  The domestic/international split is determined on the basis of departure and landing locations and not by the nationality of the airline. For many countries this incorrectly excludes fuels used by domestically owned carriers for their international departures.

International marine bunkers: Covers fuels delivered to ships of all flags that are engaged in international navigation. The international navigation may take place at sea, on inland lakes and waterways, and in coastal waters. Consumption by ships engaged in domestic navigation is excluded. The domestic/international split is determined on the basis of port of departure and port of arrival, and not by the flag or nationality of the ship. Consumption by fishing vessels and by military forces is excluded and included in residential, services and agriculture.

Investment: All  investment data and projections reflect spending across the lifecycle of a project, i.e. the capital spent is assigned to the year when it is incurred. Investments for oil, gas and coal include production, transformation and transportation; those for the power sector  include  refurbishments,  uprates,  new  builds  and  replacements  for  all  fuels  and technologies  for  on-grid,  mini-grid  and  off-grid  generation,  as  well  as  investment  in transmission and distribution, and battery storage. Investment data are presented in real terms in year-2019 US dollars unless otherwise stated.

Light-duty vehicles (LDV)  include passenger cars and light commercial vehicles (gross vehicle : weight &lt;3.5 tonnes).

Liquid biofuels: Liquid fuels derived from biomass or waste feedstocks and include ethanol and biodiesel. They can be classified as conventional and advanced liquid biofuels according to the bioenergy feedstocks and technologies used to produce them and their respective maturity.  Unless  otherwise  stated,  liquid  biofuels  are  expressed  in  energy-equivalent volumes of gasoline and diesel.

Liquids: Includes oil, liquid biofuels (expressed in energy-equivalent volumes of gasoline and diesel), synthetic oil and ammonia.

Low-carbon electricity: Includes renewable energy technologies, hydrogen-based generation,  nuclear  power  and  fossil  fuel  power  plants  equipped  with  carbon  capture, utilisation and storage.

Low-emissions  fuels: Include  liquid  biofuels,  biogas  and  biomethane,  hydrogen,  and hydrogen-based fuels that do not emit any CO2 from fossil fuels directly when used and also emit very little when being produced.

Marine: Represents the mechanical energy derived from tidal movement, wave motion or ocean current and exploited for electricity generation.

Merchant hydrogen: Hydrogen produced by one company to sell to others; equivalent to hydrogen reported in total final consumption.

Mini-grids: Small grid systems linking a number of households or other consumers.

Modern bioenergy: Includes modern solid biomass, liquid biofuels and biogases harvested from sustainable sources. It excludes the traditional use of biomass.

Modern  energy  access: Includes  household  access  to  a  minimum  level  of  electricity; household access to safer and more sustainable cooking and heating fuels, and stoves; access that enables productive economic activity; and access for public services.

Modern renewables: Includes all uses of renewable energy with the exception of traditional use of solid biomass.

Modern  solid  biomass: Refers  to  the  use  of  solid  biomass  in  improved  cookstoves  and modern technologies using processed biomass such as pellets.

Natural gas: Comprises gases occurring in deposits, whether liquefied or gaseous, consisting mainly of methane. It includes both 'non-associated' gas originating from fields producing hydrocarbons only in gaseous form, and 'associated' gas produced in association with crude oil as well as methane recovered from coal mines (colliery gas). Natural gas liquids (NGLs), manufactured gas (produced from municipal or industrial waste, or sewage) and quantities vented or flared are not included. Gas data in cubic metres are expressed on a gross calorific value basis and are measured at 15 °C and at 760 mm Hg ('Standard Conditions'). Gas data expressed in tonnes of oil equivalent, mainly for comparison reasons with other fuels, are on a net calorific basis. The difference between the net and the gross calorific value is the latent heat of vaporisation of the water vapour produced during combustion of the fuel (for gas the net calorific value is 10% lower than the gross calorific value).

Natural gas liquids (NGLs)  Liquid or liquefied hydrocarbons produced in the manufacture, : purification and stabilisation of natural gas. These are those portions of natural gas which are recovered as liquids in separators, field facilities or gas processing plants. NGLs include but are not limited to ethane (when it is removed from the natural gas stream), propane, butane, pentane, natural gasoline and condensates.

I

E

A. All rights reserved.

C

Network gases: Includes natural gas, biomethane, synthetic methane and hydrogen blended in a gas network.

Non-energy use: Fuels used for chemical feedstocks and non-energy products. Examples of non-energy products include lubricants, paraffin waxes, asphalt, bitumen, coal tars and oils as timber preservatives.

Nuclear: Refers to the primary energy equivalent of the electricity produced by a nuclear plant, assuming an average conversion efficiency of 33%.

Off-grid systems: Stand-alone systems for individual households or groups of consumers.

Offshore wind: Refers to electricity produced by wind turbines that are installed in open water, usually in the ocean.

Oil: Oil production includes both conventional and unconventional oil. Petroleum products include  refinery  gas,  ethane,  liquid  petroleum  gas,  aviation  gasoline,  motor  gasoline,  jet fuels,  kerosene,  gas/diesel  oil,  heavy  fuel  oil,  naphtha,  white  spirit,  lubricants,  bitumen, paraffin, waxes and petroleum coke.

Other energy sector: Covers the use of energy by transformation industries and the energy losses  in  converting  primary  energy  into  a  form  that  can  be  used  in  the  final  consuming sectors. It includes losses by gas works, petroleum refineries, coal and gas transformation and liquefaction, biofuels production and the production of hydrogen and hydrogen-based fuels. It also includes energy own use in coal mines, in oil and gas extraction, in direct air capture,  in  biofuels  production  and  in  electricity  and  heat  production.  Transfers  and statistical differences are also included in this category.

Power generation: Refers to fuel use in electricity plants, heat plants and combined heat and power (CHP) plants. Both main activity producer plants and small plants that produce fuel for their own use (auto-producers) are included.

Productive uses: Energy used towards an economic purpose: agriculture, industry, services and non-energy use. Some energy demand from the transport sector, e.g. freight, could also be considered as productive, but is treated separately.

Renewables: Includes bioenergy, geothermal, hydropower,  solar photovoltaics (PV), concentrating solar power (CSP), wind and marine (tide and wave) energy for electricity and heat generation.

Residential: Energy used by households including space heating and cooling, water heating, lighting, appliances, electronic devices and cooking equipment.

Services: Energy  used  in  commercial  facilities,  e.g.  hotels,  offices,  catering,  shops,  and institutional buildings, e.g. schools, hospitals, offices. Energy use in services includes space heating and cooling, water heating, lighting, equipment, appliances and cooking equipment.

Shale gas: Natural gas contained within a commonly occurring rock classified as shale. Shale formations are characterised by low permeability, with more limited ability of gas to flow through  the  rock  than  is  the  case  with  a  conventional  reservoir.  Shale  gas  is  generally produced using hydraulic fracturing.

Shipping/navigation: This  transport  sub-sector  includes  both  domestic  and  international navigation and their use of marine fuels. Domestic navigation covers the transport of goods or persons on inland waterways and for national sea voyages (starts and ends in the same country without any intermediate foreign port). International navigation includes quantities of  fuels  delivered  to  merchant  ships  (including  passenger  ships)  of  any  nationality  for consumption during international voyages transporting goods or passengers.

Solar photovoltaic (PV)  Electricity produced from solar photovoltaic cells. :

Solid  biomass: Includes  charcoal,  fuelwood,  dung,  agricultural  residues,  wood  waste  and other solid wastes.

Steam coal: Type of coal that is mainly used for heat production or steam-raising in power plants and, to a lesser extent, in industry. Typically, steam coal is not of sufficient quality for steel making. Coal of this quality is also commonly known as thermal coal.

Synthetic methane: Low-carbon synthetic methane is produced through the methanation of low-carbon hydrogen and carbon dioxide from a biogenic or atmospheric source.

Synthetic  oil: Low-carbon  synthetic  oil  produced  through  Fischer  Tropsch  conversion  or methanol synthesis from syngas, a mixture of hydrogen (H2) and carbon monoxide (CO).

Total  energy  supply (TES)   Represents  domestic  demand  only  and  is  broken  down  into : electricity and heat generation, other energy sector and total final consumption.

Total final consumption (TFC)  Is the sum of consumption by the various end-use sectors. : TFC  is  broken  down  into  energy  demand  in  the  following  sectors:  industry  (including manufacturing  and  mining),  transport,  buildings  (including  residential  and  services)  and other  (including  agriculture  and  non-energy  use).  It  excludes  international  marine  and aviation bunkers, except at world level where it is included in the transport sector.

Total final energy consumption (TFEC)  Is a variable defined primarily for tracking progress : towards  target  7.2  of  the  UN  Sustainable  Development  Goals.  It  incorporates  total  final consumption (TFC) by end-use sectors but excludes non-energy use. It excludes international marine and aviation bunkers, except at world level. Typically this is used in the context of calculating the renewable energy share in total final energy consumption (Indicator 7.2.1 of the Sustainable Development Goals), where TFEC is the denominator.

Total primary energy demand (TPED)  See total energy supply :

Traditional use of solid biomass: Refers to the use of solid biomass with basic technologies, such as a three-stone fire, often with no or poorly operating chimneys.

Transport: Fuels and electricity used in the transport of goods or people within the national territory irrespective of the economic sector within which the activity occurs. This includes fuel and electricity delivered to vehicles using public roads or for use in rail vehicles; fuel delivered to vessels for domestic navigation; fuel delivered to aircraft for domestic aviation; and  energy  consumed  in  the  delivery  of  fuels  through  pipelines.  Fuel  delivered  to international  marine  and  aviation  bunkers  is  presented  only  at  the  world  level  and  is excluded from the transport sector at a domestic level.

I

E

A. All rights reserved.

C

Trucks: Includes  medium  trucks  (gross  vehicle  weight  3.5-15  tonnes)  and  heavy  trucks (&gt;15 tonnes).

Useful energy: Refers to the energy that is available to end-users to satisfy their needs. This is also referred to as energy services demand. As result of transformation losses at the point of use, the amount of useful energy is lower than the corresponding final energy demand for most technologies. Equipment using electricity often has higher conversion efficiency than equipment using other fuels, meaning that for a unit of energy consumed electricity can provide more energy services.

Wind: electricity produced by wind turbines from the kinetic energy of wind.

Woody energy crops: Short-rotation plantings of woody biomass for bioenergy production, such as coppiced willow and miscanthus.

Variable renewable energy (VRE)  Refers to technologies whose maximum output at any : time depends on the availability of fluctuating renewable energy resources. VRE includes a broad array of technologies such as wind power, solar PV, run-of-river hydro, concentrating solar power (where no thermal storage is included) and marine (tidal and wave).

Zero-carbon-ready  buildings: A  zero-carbon-ready  building  is  highly  energy  efficient  and either uses renewable energy directly, or an energy supply that can be fully decarbonised, such as electricity or district heat.

Zero-emissions vehicles (ZEVs)  Vehicles which are capable of operating without tailpipe CO2 : emissions (battery electric vehicles and fuel cell vehicles).

## Regional and country groupings

Advanced economies: OECD regional grouping and Bulgaria, Croatia, Cyprus 1,2 ,  Malta and Romania.

Africa: North Africa and sub-Saharan Africa regional groupings.

Asia Pacific: Southeast Asia regional grouping and Australia, Bangladesh, China, India, Japan, Korea,  Democratic  People's  Republic  of  Korea,  Mongolia,  Nepal,  New Zealand,  Pakistan, Sri Lanka, Chinese Taipei, and other Asia Pacific countries and territories. 3

Caspian: Armenia, Azerbaijan, Georgia, Kazakhstan, Kyrgyzstan, Tajikistan, Turkmenistan and Uzbekistan.

Central and South America: Argentina, Plurinational State of Bolivia (Bolivia), Brazil, Chile, Colombia, Costa Rica, Cuba, Curaçao, Dominican Republic, Ecuador, El Salvador, Guatemala, Haiti,  Honduras,  Jamaica,  Nicaragua,  Panama,  Paraguay,  Peru,  Suriname,  Trinidad  and Tobago, Uruguay, Bolivarian Republic of Venezuela (Venezuela), and other Central and South American countries and territories. 4

China: Includes the (People's Republic of) China and Hong Kong, China.

<!-- image -->

Note: This map is without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Developing  Asia: Asia  Pacific  regional  grouping  excluding  Australia,  Japan,  Korea  and New Zealand.

Emerging  market  and  developing  economies: All  other  countries  not  included  in  the advanced economies regional grouping.

Eurasia: Caspian regional grouping and the Russian Federation (Russia).

Europe: European Union regional grouping and Albania, Belarus, Bosnia and Herzegovina, North Macedonia, Gibraltar, Iceland, Israel , 5 Kosovo, Montenegro, Norway, Serbia, Switzerland, Republic of Moldova, Turkey, Ukraine and United Kingdom.

European Union: Austria,  Belgium,  Bulgaria,  Croatia,  Cyprus 1,2 ,  Czech  Republic,  Denmark, Estonia,  Finland,  France,  Germany,  Greece,  Hungary,  Ireland,  Italy,  Latvia,  Lithuania, Luxembourg,  Malta,  Netherlands,  Poland,  Portugal,  Romania,  Slovak  Republic,  Slovenia, Spain and Sweden.

IEA (International  Energy  Agency) : OECD  regional  grouping  excluding  Chile,  Colombia, Iceland, Israel, Latvia, Lithuania and Slovenia.

Latin America: Central and South America regional grouping and Mexico.

Middle East: Bahrain, Islamic Republic of Iran (Iran), Iraq, Jordan, Kuwait, Lebanon, Oman, Qatar, Saudi Arabia, Syrian Arab Republic (Syria), United Arab Emirates and Yemen.

Non-OECD: All other countries not included in the OECD regional grouping.

Non-OPEC: All other countries not included in the OPEC regional grouping.

I

E

A. All rights reserved.

C

North Africa: Algeria, Egypt, Libya, Morocco and Tunisia.

North America: Canada, Mexico and United States.

OECD (Organisation  for  Economic  Co-operation  and  Development)   Australia,  Austria, : Belgium,  Canada,  Chile,  Colombia,  Czech  Republic,  Denmark,  Estonia,  Finland,  France, Germany,  Greece,  Hungary,  Iceland,  Ireland,  Israel,  Italy,  Japan,  Korea,  Latvia,  Lithuania, Luxembourg, Mexico, Netherlands, New Zealand, Norway, Poland, Portugal, Slovak Republic, Slovenia, Spain, Sweden, Switzerland, Turkey, United Kingdom and United States.

OPEC (Organisation of the Petroleum Exporting Countries)  Algeria, Angola, Republic of the : Congo (Congo), Equatorial Guinea, Gabon, the Islamic Republic of Iran (Iran), Iraq, Kuwait, Libya,  Nigeria,  Saudi  Arabia,  United  Arab  Emirates  and  Bolivarian  Republic  of  Venezuela (Venezuela).

Southeast Asia: Brunei Darussalam, Cambodia, Indonesia, Lao People's Democratic Republic (Lao  PDR),  Malaysia,  Myanmar,  Philippines,  Singapore,  Thailand  and  Viet Nam.  These countries are all members of the Association of Southeast Asian Nations (ASEAN).

Sub-Saharan Africa: Angola, Benin, Botswana, Cameroon, Republic of the Congo (Congo), Côte d'Ivoire, Democratic Republic of the Congo, Eritrea, Ethiopia, Gabon, Ghana, Kenya, Mauritius, Mozambique, Namibia, Niger, Nigeria, Senegal, South Africa, South Sudan, Sudan, United Republic of Tanzania (Tanzania), Togo, Zambia, Zimbabwe and other African countries and territories. 6

## Country notes

1 Note by Turkey: The information in this document with reference to 'Cyprus' relates to the southern part of the island. There is no single authority representing both Turkish and Greek Cypriot people on the island. Turkey recognises the Turkish Republic of Northern Cyprus (TRNC). Until a lasting and equitable solution is found within the context of the United Nations, Turkey shall preserve its position concerning the 'Cyprus issue'.

2 Note by all the European Union Member States of the OECD and the European Union: The Republic of Cyprus is  recognised by all members of the United Nations with the exception of Turkey. The information in this document relates to the area under the effective control of the Government of the Republic of Cyprus.

3 Individual data are not available and are estimated in aggregate for: Afghanistan, Bhutan, Cook Islands, Fiji, French  Polynesia,  Kiribati,  Macau  (China),  Maldives,  New  Caledonia,  Palau,  Papua  New  Guinea,  Samoa, Solomon Islands, Timor-Leste and Tonga and Vanuatu.

4 Individual data are not available and are estimated in aggregate for: Anguilla, Antigua and Barbuda, Aruba, Bahamas,  Barbados,  Belize,  Bermuda,  Bonaire,  British  Virgin  Islands,  Cayman  Islands,  Dominica,  Falkland Islands  (Malvinas),  French  Guiana,  Grenada,  Guadeloupe,  Guyana,  Martinique,  Montserrat,  Saba,  Saint Eustatius, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and Grenadines, Saint Maarten, Turks and Caicos Islands.

5 The statistical data for Israel are supplied by and under the responsibility of the relevant Israeli authorities. The use of such data by the OECD and/or the IEA is without prejudice to the status of the Golan Heights, East Jerusalem and Israeli settlements in the West Bank under the terms of international law.

6 Individual data are not available and are estimated in aggregate for: Burkina Faso, Burundi, Cabo Verde, Central  African  Republic,  Chad,  Comoros,  Djibouti,  Kingdom  of  Eswatini,  Gambia,  Guinea,  Guinea-Bissau, Lesotho, Liberia, Madagascar, Malawi, Mali, Mauritania, Réunion, Rwanda, Sao Tome and Principe, Seychelles, Sierra Leone, Somalia and Uganda.

## Abbreviations and Acronyms

AFOLU

agriculture forestry and other land use

APC

Announced Pledges Case

ASEAN

Association of Southeast Asian Nations

BECCS

bioenergy equipped with CCUS

BEV

battery electric vehicles

CCUS

carbon capture, utilisation and storage

CDR

carbon dioxide removal

CFL

compact fluorescent lamp

CH4

methane

CHP

combined heat and power; the term co-generation is sometimes used

CNG

compressed natural gas

CO

carbon monoxide

CO2

carbon dioxide

CO2-eq

carbon-dioxide equivalent

COP

Conference of Parties (UNFCCC)

CSP

concentrating solar power

DAC

direct air capture

DACCS

direct air capture with carbon capture and storage

DER

distributed energy resources

DSI

demand-side integration

DSO

distribution system operator

DSR

demand-side response

EAF

electric arc furnaces

EHOB

extra-heavy oil and bitumen

ETP

Energy Technology Perspectives

EU

European Union

EV

electric vehicle

FCEV

fuel cell electric vehicle

GDP

gross domestic product

GHG

greenhouse gases

GTL

gas-to-liquids

HEFA

hydrogenated esters and fatty acids

ICE

internal combustion engine

IEA

International Energy Agency

IIASA

International Institute for Applied Systems Analysis

IMF

International Monetary Fund

IOC

international oil company

IPCC

Intergovernmental Panel on Climate Change

LCC

LDVs

Low CCUS Case

light-duty vehicles

LCV

light-commercial vehicle

LED

light-emitting diode

I

E

A. All rights reserved.

C

| LNG    | liquefied natural gas                                         |
|--------|---------------------------------------------------------------|
| LPG    | liquefied petroleum gas                                       |
| MEPS   | minimum energy performance standards                          |
| NDCs   | Nationally Determined Contributions                           |
| NEA    | Nuclear Energy Agency (an agency within the OECD)             |
| NGLs   | natural gas liquids                                           |
| NGV    | natural gas vehicle                                           |
| NOC    | national oil company                                          |
| NO X   | nitrogen oxides                                               |
| N 2 O  | nitrous oxide                                                 |
| NZE    | Net-Zero Emissions Scenario                                   |
| OECD   | Organisation for Economic Co-operation and Development        |
| OPEC   | Organization of the Petroleum Exporting Countries             |
| PHEV   | plug-in hybrid electric vehicles                              |
| PLDV   | passenger light-duty vehicle                                  |
| PM     | particulate matter                                            |
| PM 2.5 | fine particulate matter                                       |
| PPP    | purchasing power parity                                       |
| PV     | photovoltaics                                                 |
| R&D    | research and development                                      |
| RD&D   | research, development and demonstration                       |
| SAF    | sustainable aviation fuel                                     |
| SDG    | Sustainable Development Goals (United Nations)                |
| SO 2   | sulphur dioxide                                               |
| SR1.5  | IPCC Special Report on the impacts of global warming of 1.5°C |
| STEPS  | Stated Policies Scenario                                      |
| T&D    | transmission and distribution                                 |
| TES    | total energy supply                                           |
| TFC    | total final consumption                                       |
| TFEC   | total final energy consumption                                |
| TPED   | total primary energy demand                                   |
| UEC    | unit energy consumption                                       |
| UN     | United Nations                                                |
| UNDP   | United Nations Development Programme                          |
| UNEP   | United Nations Environment Programme                          |
| UNFCCC | United Nations Framework Convention on Climate Change         |
| UK     | United Kingdom                                                |
| US     | United States                                                 |
| VRE    | variable renewable energy                                     |
| WEO    | World Energy Outlook                                          |
| WHO    | World Health Organization                                     |
| ZEV    | Zero-emissions vehicle                                        |

<!-- image -->

## Chapter 1: Announced net zero pledges and the energy sector

climatewatchdata (2021), https://www.climatewatchdata.org/ndc-overview.

European  Commission  (2018),  2018  Vision  for  a  long-term  EU  strategy  for  reducing greenhouse gas emissions , https://ec.europa.eu/clima/policies/strategies/2050\_en.

- IEA (International Energy Agency) (2021), Global Energy Review 2021 , https://www.iea.org/reports/global-energy-review-2021.
- - (2020a), Sustainable Recovery , https://www.iea.org/reports/sustainable-recovery/asustainable-recovery-plan-for-the-energy-sector.
- - (2020b), World Energy Outlook 2020 , https://www.iea.org/reports/world-energy-outlook2020.
- - (2020c), Energy Technology Perspectives 2020 , https://www.iea.org/reports/energytechnology-perspectives-2020.
- - (2020c), World Energy Balances 2020 edition: database documentation , http://wds.iea.org/wds/pdf/WORLDBAL\_Documentation.pdf.
- - (2020e), Special Report on Clean Energy Innovation ,  https://www.iea.org/reports/cleanenergy-innovation.

IPCC (Intergovernmental Panel on Climate Change) (2018), Global Warming of 1.5°C. An IPCC Special Report on the impacts of global warming of 1.5°C above pre-industrial levels , IPCC, https://www.ipcc.ch/sr15/.

WRI  and  WBCSD  (World  Resources  Institute  and  World  Business  Council  for  Sustainable Development) (2004), The Greenhouse Gas Protocol: A Corporate Accounting and Reporting Standard ,  WRI  and  WBCSD,  Washington,  DC,  https://ghgprotocol.org/sites/default/files/ standards/ghg-protocol-revised.pdf.

## Chapter 2: A global pathway to net-zero CO₂ emissions in 2050

Amann,  M.  et  al.  (2011),  "Cost-effective  control  of  air  quality  and  greenhouse  gases  in Europe: Modelling and policy applications", Environmental Modelling , Vol 26, pp. 1489-1501.

Anderson  et  al.  (2013), Getting  to  know  GIMF:  The  Simulation  Properties  of  the  Global Integrated  Monetary  and  Fiscal  Model , International  Monetary  Fund,  Washington,  DC, https://www.imf.org/external/pubs/ft/wp/2013/wp1355.pdf.

Assemblee  Nationale  (2021),  (Proposed  law  aiming  to  replace  domestic  flights  by  train), PROPOSITION DE LOI visant à replacer les vols intérieurs par le train , https://www.assemble e-nationale.fr/dyn/15/textes/l15b2005\_proposition-loi.

I

E

Aydin, E., D. Brounen and N. Kok (2018), "Information provision and energy consumption: Evidence from a field experiment", Energy Economics , Vol. 71, pp. 403-411., https://doi.org/10.1016/j.eneco.2018.03.008.

Byars, M., Y. Wei and S. Handy (2017), State-Level Strategies for Reducing Vehicle Miles of Travel , https://bit.ly/2LvA6nn.

Climate Assembly United Kingdom (2020), The path to net zero , https://www.climateassembly.uk/report/read/final-report.pdf.

Convention Citoyenne pour le Climat (2021), (Proposals of the Citizens Climate Convention), Les Propositions de la Convention Citoyenne pour le Climat , https://propositions.conventioncitoyennepourleclimat.fr/.

DEFRA (UK Department for Environment, Food &amp; Rural Affairs) (2012), London congestion charge  detailed  assessment ,  https://uk-air.defra.gov.uk/assets/documents/reports/cat09/ 0505171128\_London\_Congestion\_Charge\_Detailed\_Assessment.doc.

European Commission (2021), Urban Access Regulations in Europe , https://urbanaccessregulations.eu/countries-mainmenu-147.

Frank, S.  (2021),  "Land-based  climate  change mitigation  potentials within the agenda for sustainable  development", Environmental  Research  Letters , Vol.  16/2,  https://doi.org/ 10.1088/1748-9326/abc58a.

IEA  (International  Energy  Agency)  (2021), The  Role  of  Critical  Minerals  in  Clean  Energy Transitions ,  IEA,  https://www.iea.org/reports/the-role-of-critical-minerals-in-clean-energytransitions.

- (2020a), World Energy Balances 2020 edition: database documentation , http://wds.iea.org/wds/pdf/WORLDBAL\_Documentation.pdf.

- - (2020b), Outlook for Biogas and Biomethane: Prospects for organic growth , https://www.iea.org/reports/outlook-for-biogas-and-biomethane-prospects-for-organicgrowth.

- (2020c), World  Energy  Investment,  2020 , https://www.iea.org/reports/world-energyinvestment-2020.

- (2020d), Energy Technology Perspectives 2020: Special Report on Clean Energy Innovation , https://www.iea.org/reports/clean-energy-innovation.

- - (2019), The Future of Rail , https://www.iea.org/reports/the-future-of-rail.

IMF (International Monetary Fund) (2020a), June 2020: A Crisis Like No Other, An Uncertain Recovery , https://www.imf.org/-/media/Files/Publications/WEO/2020/Update/June/ English/WEOENG202006.ashx

- - (2020b), World Economic Outlook Database , April 2020 Edition, Washington DC.

IPCC (Intergovernmental Panel on Climate Change) (2019), Climate Change and Land: An IPCC Special  Report  on  Climate  Change,  Desertification,  Land  Degradation,  Sustainable  Land Management,  Food  Security,  and  Greenhouse  Gas  Fluxes  in  Terrestrial Ecosystems , https://www.ipcc.ch/srccl/.

- (2018), Global Warming of 1.5°C. An IPCC Special Report on the impacts of global warming of 1.5°C above pre-industrial levels and related global greenhouse gas emission pathways, in the context of strengthening the global response to the threat of climate change, sustainable development and efforts to eradicate poverty , https://www.ipcc.ch/sr15/.

- (2014), Climate Change 2014: Synthesis Report, Contribution of Working Groups I, II and III to  the  Fifth  Assessment  Report  of  the  Intergovernmental  Panel  on  Climate  Change , https://www.ipcc.ch/report/ar5/syr/.

Jochem et al. (2020), "Does free-floating carsharing reduce private vehicle ownership? The case of SHARE NOW in European cities", Transportation Research Part A: Policy and Practice , Vol. 141, pp. 373-295, https://doi.org/10.1016/j.tra.2020.09.016.

Laxton,  D.  et  al.  (2010), The  Global  Integrated  Monetary  and  Fiscal  Model  (GIMF)  Theoretical Structure , International Monetary Fund, Washington, DC, https://www.imf.org/ ~/media/Websites/IMF/imported-full-text-pdf/external/pubs/ft/wp/2010/\_wp1034.ashx.

Martin,  Shaheen  and  Lidiker  (2010),  "Carsharings  impact  on  household  vehicle  holdings: Results for a North American shared-use vehicle survey", Presented at 89th Annual Meeting of the Transportation Research Board, Washington DC, https://doi.org/10.3141/2143-19.

Newgate Research and Cambridge Zero (2021), Net Zero Public Dialogue , https://assets.publishing.service.gov.uk/government/uploads/system/uploads/attachment \_data/file/969401/net-zero-public-dialogue.pdf.

Oxford Economics (2020), Oxford Economics Global Economic Model , (database), https://www.oxfordeconomics.com/global-economic-model, August 2020 update, Oxford.

TFL (Transport for London) (2021), Congestion charge factsheet , https://content.tfl.gov.uk/ congestion-charge-factsheet.pdf.pdf.

Tools of Change (2014), Stockholm's Congestion Pricing ,  https://www.toolsofchange.com/ userfiles/Stockholm%20Congestion%20Pricing%20-%20FINAL%202014.pdf.

UNDESA (United Nations Department of Economic and Social Affairs) (2019), 2019 Revision of World Population Prospects , https://population.un.org/wpp/.

Wu, W. H. (2019), "Global advanced bioenergy potential under environmental protection policies  and  societal  transformation  measures", GCB  Bioenergy ,  Vol.  11,  pp.  1041-1055, https://doi.org/10.1111/gcbb.12614.

I

E

A. All rights reserved.

D

## Chapter 3: Sectoral pathways to net-zero emissions by 2050

IEA  (International  Energy  Agency)  (2021a), The  Role  of  Critical  Minerals  in  Clean  Energy Transitions , https://www.iea.org/reports/the-role-of-critical-minerals-in-clean-energytransitions.

- - (2021b), Global EV Outlook 2020, https://www.iea.org/reports/global-ev-outlook-2021.
- - (2020a), The  Oil  and  Gas  Industry  in  Energy  Transitions, https://www.iea.org/reports/ the-oil-and-gas-industry-in-energy-transitions.
- - (2020b), Energy Technology Perspectives 2020 , IEA, https://www.iea.org/reports/energytechnology-perspectives-2020.
- - (2019), Nuclear  Power  in  a  Clean  Energy  System ,  https://www.iea.org/reports/nuclearpower-in-a-clean-energy-system.

UNCTAD  (United Nations Conference on Trade and Development) (2018), Review of Maritime Transport 2018 , UNCTAD, https://unctad.org/en/PublicationsLibrary/ rmt2018\_en.pdf.

## Chapter 4: Wider implications of achieving net-zero emissions

Carbon Engineering (2021), https://carbonengineering.com/our-story/.

Diaz Anadon, L. (2012), 'Missions-oriented RD&amp;D institutions in energy between 2000 and 2010: A comparative analysis of China, the United Kingdom, and the United States', Research Policy , Vol. 41, pp. 1742-1756, https://doi.org/10.1016/j.respol.2012.02.015.

European  Cement  Research  Academy  (2012), ECRA  CCS  Project:  Report  on  phase  III , https://ecraonline.org/fileadmin/redaktion/files/pdf/ECRA\_Technical\_Report\_CCS\_Phase\_I II.pdf.

Feyisa, Dons &amp; Meilby (2014), "Efficiency of parks in mitigating urban heat island effect: an example  from  Addis  Ababa", Landscape  and  Urban  Planning , Vol. 123,  pp. 87-95, https://doi.org/10.1016/j.landurbplan.2013.12.008.

GLPGP (The Global LPG Partnership) (2020), Assessing Potential for BioLPG Production and use within the Cooking Energy Sector in Africa , https://mecs.org.uk/wpcontent/uploads/2020/09/GLPGP-Potential-for-BioLPG-Production-and-Use-as-CleanCooking-Energy-in-Africa-2020.pdf.

Greco, A. et al. (2019), "A review of the state of the art of solid-state caloric cooling processes at  room-temperature  before  2019", International  Journal  of  Refrigeration , pp.  66-88, https://doi.org/10.1016/j.ijrefrig.2019.06.034.

Gross,  R.  (2018),  'How  long  does  innovation  and  commercialisation  in  the  energy  sector take? Historical case studies of the timescale from invention to widespread commercialisation in the energy supply and end-use technology', Energy Policy , Vol. 123, pp. 682-299, https://doi.org/10.1016/j.enpol.2018.08.061.

- IEA  (International  Energy  Agency)  (2021a), The  Role  of  Critical  Minerals  in  Clean  Energy Transitions , https://www.iea.org/reports/the-role-of-critical-minerals-in-clean-energytransitions.
- - (2021b), Climate Resilience , https://www.iea.org/reports/climate-resilience.
- - (2021c), Enhancing Cyber Resilience in Electricity Systems , https://www.iea.org/ reports/enhancing-cyber-resilience-in-electricity-systems.
- - (2021d), Conditions and requirements for the technical feasibility of a power system with a high share of renewables in France towards 2050 , https://www.iea.org/reports/conditionsand-requirements-for-the-technical-feasibility-of-a-power-system-with-a-high-share-ofrenewables-in-france-towards-2050.
- - (2020a), World  Energy  Investment,  2020 , https://www.iea.org/reports/world-energyinvestment-2020.
- - (2020b), Sustainable Recovery: World Energy Outlook Special Report , https://www.iea.org/ reports/sustainable-recovery.
- - (2020c), Energy Technology Perspectives: Special Report on Carbon Capture Utilisation and Storage , https://www.iea.org/reports/ccus-in-clean-energy-transitions.
- - (2020d), Outlook for Biogas and Biomethane: Prospects for organic growth , https://www.iea.org/reports/outlook-for-biogas-and-biomethane-prospects-for-organicgrowth.
- - (2020e), The Oil and Gas Industry in Energy Transitions , https://www.iea.org/reports/theoil-and-gas-industry-in-energy-transitions.
- - (2020f), World Energy Outlook 2020 , https://www.iea.org/reports/world-energy-outlook2020.
- - (2020g), The Role of CCUS in Low-Carbon Power Systems , https://www.iea.org/ reports/the-role-of-ccus-in-low-carbon-power-systems.
- - (2020h), Power  Systems  in  Transition , https://www.iea.org/reports/power-systems-intransition/electricity-security-matters-more-than-ever.
- - (2020i), Energy Technology Perspectives 2020: Special Report on Clean Energy Innovation , https://www.iea.org/reports/clean-energy-innovation.
- - (2019a), The Future of Hydrogen , https://www.iea.org/reports/the-future-of-hydrogen.
- - (2019b), Offshore Wind Outlook 2019, https://www.iea.org/reports/offshore-windoutlook-2019.
- - (2017), Energy Access Outlook 2017: from  Poverty to Prosperity:  World  Energy  Outlook Special Report , https://www.iea.org/reports/energy-access-outlook-2017

I

E

A. All rights reserved.

D

Kamaya,  N.  (2011),  "A  lithium  superionic  conductor", Nature  Materials , pp.  682-686, https://doi.org/10.1038/nmat3066.

Liquid Gas Europe (2021), BioLPG: A Renewable Pathway Towards 2050 , https://www.liquidgaseurope.eu/news/biolpg-a-renewable-pathway-towards-2050.

Malhotra, A. and T. Schmidt (2020), "Accelerating Low-Carbon Innovation", Joule , pp. 22592267, https://doi.org/10.1016/j.joule.2020.09.004.

Material Economics (2019), Industrial Transformation 2050: Pathways to Net-Zero Emissions from EU Heavy Industry , University of Cambridge for Sustainability Leadership, Cambridge, United Kingdom.

Mazzucato, M. (2018), "Mission-oriented Innovation Policies: Challenges and Opportunities", Industrial  and  Corporate  Change,  Vol.  27/5,  pp.  803-815,  https://doi.org/10.1093/icc/ dty034.

NASEO and Energy Futures Initiative (2021), United States Energy &amp; Employment Report , https://www.usenergyjobs.org/.

NEA  (Nuclear Energy Agency) (2016), Cost Benchmarking  for Nuclear Power  Plant Decommissioning , https://doi.org/10.1787/acae0e3b-en.

OECD (Organisation for Economic Co-operation and Development) (2020), Environmentally related tax revenue , OECD Statistics, https://stats.oecd.org/.

- (2015), The Economic Consequences of Climate Change ,  https://www.oecd.org/env/theeconomic-consequences-of-climate-change-9789264235410-en.htm.

Tenova  (2018),  HYL  News,  https://www.tenova.com/fileadmin/user\_upload/HYL\_News\_-\_December\_2018.pdf.

Victor, D., Geels, F. and S. Sharpe (2019), Accelerating the Low Carbon Transition: The case for stronger, more targeted and co-ordinated international action ,  The Energy Transitions Commission, London.

Zemships  (2008), One  Hundred  Passengers  and  Zero  Emissions:  The  first-ever  passenger vessel to sail propelled by fuel cells , https://ec.europa.eu/environment/life/project/ Projects/index.cfm?fuseaction=home.s.

## Annex B: Technology costs

IEA (International Energy Agency) (2020), World Energy Outlook 2020 , https://www.iea.org/reports/world-energy-outlook-2020.

- (2019),  Offshore  Wind  Outlook  2019,  IEA,  Paris,  https://www.iea.org/reports/offshorewind-outlook-2019.

IRENA (International Renewable Energy Agency) (2020), Renewable Costing Alliance, IRENA, Abu Dhabi, https://www.irena.org/statistics, accessed 15 July 2020.

This publication reflects the views of the IEA Secretariat but does not necessarily reflect those of individual IEA member countries. The IEA makes no representation or warranty, express or implied, in respect of the publication's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the publication. Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

This publication and any map included herein are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Revised version, October 2021 ( 4 th revision).

Information notice found at: www.iea.org/corrections

IEA. All rights reserved.

IEA Publications

International Energy Agency

Website: www.iea.org

Contact information: www.iea.org/about/contact

Typeset in France by IEA - May 2021 Cover design: IEA Photo credits: © ShutterStock