---
document_id: irena_re_capacity_stats_2023
title: "Renewable Capacity Statistics 2023"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IRENA"
year: 2023
original_file: "irena_renewable_capacity_statistics_2023.pdf"
tables_detected: 582
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## RENEWABLE CAPACITY

## STATISTICS 2023 STATISTIQUES DE CAPACITÉ RENOUVELABLE 2023 ESTADÍSTICAS DE CAPACIDAD RENOVABLE 2023

## Copyright © IRENA 2023

Unless otherwise stated, this publication and material featured herein are the property of the International Renewable Energy Agency (IRENA) and are subject to copyright by IRENA.

Material in this publication may be freely used, shared, copied, reproduced, printed and/or stored, provided that all such material is clearly attributed to IRENA and bears a notation that it is subject to copyright (© IRENA), with the year of the copyright.

Material contained in this publication attributed to third parties may be subject to third party copyright and separate terms of use and restrictions, including restrictions in relation to any commercial use.

ISBN: 978-92-9260-525-4

## About IRENA

The  International  Renewable  Energy  Agency  (IRENA)  is  an  intergovernmental  organisation  that  supports  countries  in  their transition to a sustainable energy future, and serves as the principal platform for international co-operation, a centre of excellence, and a repository of policy, technology, resource and financial knowledge on renewable energy. IRENA promotes the widespread adoption and sustainable use of all forms of renewable energy, including bioenergy, geothermal, hydropower, ocean, solar and wind energy, in the pursuit of sustainable development, energy access, energy security and low-carbon economic growth and prosperity. www.irena.org

## Acknowledgements

Prepared by: Arvydas Lebedys, Dennis Akande, Nazik Elhassan, Gerardo Escamilla, Iana Arkhipova and Adrian Whiteman. The authors also gratefully acknowledge the contribution to this dataset from ASOLMEX, Eurostat and national statistical focal points in countries.

For further information or to provide feedback, please contact the IRENA Statistics team (statistics@irena.org).

This report is available for download from: www.irena.org/Publications. Data can be downloaded at: www.irena.org/Data.

This report should be cited: IRENA (2023), Renewable capacity statistics 2023 , International Renewable Energy Agency, Abu Dhabi.

## Disclaimer

This publication and the material featured herein are provided 'as is', for informational purposes.

All reasonable precautions have been taken by IRENA to verify the reliability of the material featured in this publication. Neither IRENA nor any of its officials, agents, data or other third-party content providers or licensors provides any warranty, including as to the accuracy, completeness, or fitness for a particular purpose or use of such material, or regarding the non-infringement of third-party rights, and they accept no responsibility or liability with regard to the use of this publication and the material featured therein.

The information contained herein does not necessarily represent the views of the Members of IRENA, nor is it an endorsement of any project, product or service provider. The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

## FOREWORD

Highlighting the continued progress toward the energy transition in the global power generation mix, this latest edition of Renewable capacity statistics reaffirms renewables as the de-facto energy choice for new power generation, despite the effects of recent global crises and geopolitical shocks on the energy sector.

By the end of 2022, renewables accounted for 40% of global installed power capacity. Yet, as we draw closer to a world in which renewable energy accounts for half of total capacity, many energy planning questions  must  be  addressed  to  establish  renewables  as  the  most  significant  source  of  electricity generation - including in the context of grid flexibility and adaptation to variable renewable power.

2022 has seen the largest increase in renewable energy capacity to date - the world added almost 295 gigawatts (GW) of renewables, increasing the stock of renewable power by 9.6% and contributing an unprecedented 83% of global power additions, largely due to the growth of solar and wind power, and the further decommissioning of fossil fuel power plants in several large economies. Solar power alone accounted for almost two-thirds of the renewable additions with a record 192 GW, while 75 GW of wind energy was added, slowing from the 111 GW added in 2020.

A  record  year  for  renewable  capacity  additions  is  encouraging  for  countries  around  the  world redesigning their national energy planning strategies to favour renewables. There is, however, much more potential to increase the role of renewables; to stay on the pathway to limit global temperature increases  to  1.5°C  of  pre-industrial  levels,  the  world  needs  to  see  more  than  1  000  GW  of  annual renewable capacity additions until 2050, with solar power representing more than half of this figure. While this is an ambitious target - as the gap between what is needed and what is implemented widens - the capacity progress reported here for 2022 reflects ongoing global efforts to transform the power sector.

Looking ahead, we hope to see a much faster pace of growth in the stock of renewable power plants and distributed electricity generation around the world.

This report should serve not only as a valuable resource to track progress, but also as a glaring reminder of the work that lies ahead to achieve a just, inclusive and sustainable future for all.

Francesco La Camera Director-General International Renewable Energy Agency

## TABLE OF CONTENTS TABLE DES MATIÈRES TABLA DE CONTENIDOS

## Total capacity - Capacité totale - Capacidad total

Total renewable energy Total énergies renouvelables Total energías renovables

| Total énergies renouvelables                                                                   | 2   |
|------------------------------------------------------------------------------------------------|-----|
| Total energías renovables                                                                      |     |
| Hydropower                                                                                     |     |
| Hydroélectricité                                                                               | 6   |
| Hidroeléctrica                                                                                 |     |
| Renewable hydropower (including mixed plants)                                                  |     |
| Hydroélectricité renouvelable (y compris les centrales mixtes)                                 | 9   |
| Hidroeléctrica renovable (incluidas las plantas mixtas)                                        |     |
| Pure pumped storage                                                                            |     |
| Accumulation par pompage                                                                       | 12  |
| Hidroeléctrica de bombeo pura                                                                  |     |
| Marine energy                                                                                  |     |
| Énergie marine                                                                                 | 13  |
| Energía marina                                                                                 |     |
| Wind energy                                                                                    |     |
| Énergie éolienne                                                                               | 14  |
| Energía eólica                                                                                 |     |
| Onshore wind                                                                                   |     |
| energy                                                                                         |     |
| Énergie éolienne terrestre                                                                     | 17  |
| Energía eólica terrestre                                                                       |     |
| Offshore wind energy Énergie éolienne maritime                                                 | 20  |
| Energía eólica marina                                                                          |     |
| Solar energy                                                                                   |     |
| Énergie solaire                                                                                | 21  |
| Energía solar                                                                                  |     |
| Solar photovoltaic                                                                             |     |
| Solaire photovoltaïque                                                                         | 25  |
| Solar fotovoltaica                                                                             |     |
| Concentrated solar power                                                                       |     |
| Solaire thermique à concentration                                                              | 29  |
| Energía solar termoeléctrica                                                                   |     |
| Bioenergy                                                                                      |     |
| Bioénergie                                                                                     | 30  |
| Bioenergía                                                                                     |     |
| Solid biofuels and renewable waste                                                             |     |
|                                                                                                | 33  |
| Biocombustibles solides et déchets renouvelables Biocombustibles sólidos y residuos renovables |     |

2

6

9

| Bagasse                                                                                                              |    |
|----------------------------------------------------------------------------------------------------------------------|----|
| Bagasse                                                                                                              | 35 |
| Bagazo                                                                                                               |    |
| Renewable municipal waste                                                                                            |    |
| Déchets municipaux renouvelables                                                                                     | 36 |
| Residuos municipales renovables                                                                                      |    |
| Other solid biofuels                                                                                                 |    |
| Autres biocarburants solides                                                                                         | 37 |
| Otros biocombustibles sólidos                                                                                        |    |
| Liquid biofuels                                                                                                      |    |
| Biocarburants liquides                                                                                               | 39 |
| Biocarburantes líquidos                                                                                              |    |
| Biogas                                                                                                               |    |
| Biogaz                                                                                                               | 40 |
| Biogás                                                                                                               |    |
| Geothermal energy                                                                                                    |    |
| Énergie géothermique                                                                                                 | 42 |
| Energía geotérmica                                                                                                   |    |
| Off-grid capacity - Capacité hors réseau - Capacidad aislada                                                         |    |
| Total renewable energy                                                                                               |    |
| Total énergies renouvelables                                                                                         | 44 |
| Total energías renovables                                                                                            |    |
| Hydropower                                                                                                           |    |
| Hydroélectricité                                                                                                     | 46 |
| Hidroeléctrica                                                                                                       |    |
| Solar photovoltaic                                                                                                   |    |
| Solaire photovoltaïque                                                                                               | 47 |
| Solar fotovoltaica                                                                                                   |    |
| Other renewable energy                                                                                               |    |
| Autres énergies renouvelables                                                                                        | 49 |
| Otras energías renovables                                                                                            |    |
| Other indicators - Autres indicateurs - Otros indicadores                                                            |    |
| Renewable energy share of electricity capacity                                                                       |    |
| La part d'énergie renouvelable dans la puissance installée Proporción de energía renovable en la capacidad eléctrica | 52 |

## NOTES TO THE TABLES

The renewable power capacity data shown in these tables represents the maximum net generating capacity of power plants and other installations that use renewable energy sources to produce electricity. For most countries and technologies, the data reflects the capacity installed and connected at the end of the calendar year. The data is presented in megawatts (MW) rounded to the nearest one megawatt, with figures between zero and 0.5MW shown as a 0.

Data has been obtained from a variety of sources, including: the IRENA questionnaire; official statistics; industry association reports; and other reports and news articles. Numbers followed by the letter 'o' are figures that have been obtained from official sources such as national statistical offices, government departments, regulators and power companies. The letter 'u' follows figures that have been obtained from unofficial sources, such as industry associations and news articles. The letter 'e' follows figures that have been estimated by IRENA from a variety of different data sources. All data from the IRENA questionnaire is presented without any indicator.

Data are available for download at www.irena.org/statistics.

## NOTES À PROPOS DES TABLEAUX

Les données sur les capacités électriques renouvelables présentées dans ces tableaux représentent la capacité maximale nette de génération des centrales électriques et autres installations utilisant des sources d'énergie renouvelables pour produire de l'électricité. Pour la plupart des pays et technologies, les données reflètent la capacité  installée  et  connectée  à  la  fin  de  l'année  civile.  Les  données  sont  exprimées  en  mégawatts  (MW) arrondies à l'unité la plus proche ; les valeurs inférieures à 0,5 MW apparaissent comme 0.

Les données proviennent de sources multiples, y compris : le questionnaire IRENA ; les statistiques officielles ; des rapports d'associations de l'industrie ; et d'autres rapports et articles de presse. Les valeurs suivies de la lettre "o"  ont  été  obtenues  à  partir  de  sources  officielles  (par  exemple  instituts  statistiques  nationaux,  agences gouvernementales,  régulateurs,  compagnies  d'électricité).  La  lettre  "u"  correspond  à  des  valeurs  venant  de sources non officielles comme des rapports d'associations de l'industrie ou des articles de journaux. La lettre "e" correspond à des valeurs qui ont été estimées par l'IRENA à partir de sources diverses. Toutes les données venant du questionnaire IRENA sont présentées sans indication.

Les données sont téléchargeables sur le site www.irena.org/statistics.

## NOTAS A LAS TABLAS

Los  datos  de  capacidad  de  generación  eléctrica  con  energías  renovables  que  se  muestran  en  estas  tablas representan la capacidad máxima de generación neta de las centrales eléctricas y otras instalaciones que utilizan fuentes de energías renovables para producir electricidad. Para la mayoría de los países y las tecnologías, los datos reflejan la capacidad instalada y conectada al final del año natural. Los datos se presentan en megavatios (MW) redondeados al megavatio entero más cercano, con cifras entre cero y 0,5 MW representadas como un 0.

Los datos se han obtenido a partir de una variedad de fuentes, incluyendo: el cuestionario de IRENA; estadísticas oficiales;  informes  de  las  asociaciones  industriales;  y  otros  informes  y  artículos  de  noticias.  Los  números acompañados de la letra "o" son cifras que se han obtenido a partir de fuentes oficiales, como oficinas nacionales de estadística, departamentos gubernamentales, reguladores y compañías eléctricas. La letra "u" acompaña a cifras que se han obtenido a partir de fuentes no oficiales, tales como asociaciones industriales y artículos de noticias. La letra "e" acompaña a números que han sido estimados por IRENA a partir de diversas fuentes de datos. Todos los datos provenientes del cuestionario de IRENA se presentan sin ningún indicador.

Los datos están disponibles para su descarga en www.irena.org/statistics.

## COUNTRIES, AREAS AND REGIONS SHOWN IN THE TABLES PAYS, ZONES ET RÉGIONS FIGURANT DANS LES TABLEAUX PAÍSES, ZONAS Y REGIONES MOSTRADAS EN LAS TABLAS

## Label/En-tête/Rótulo

## English

## Français

## Español

## WORLD

## WORLD

## MONDE

## MUNDO

| AFRICA                  | AFRICA                      | AFRIQUE                    | ÁFRICA                    |
|-------------------------|-----------------------------|----------------------------|---------------------------|
| Algeria                 | Algeria                     | Algérie                    | Argelia                   |
| Angola                  | Angola                      | Angola                     | Angola                    |
| Benin                   | Benin                       | Bénin                      | Benín                     |
| Botswana                | Botswana                    | Botswana                   | Botsuana                  |
| Burkina Faso            | Burkina Faso                | Burkina Faso               | Burkina Faso              |
| Burundi                 | Burundi                     | Burundi                    | Burundi                   |
| Cabo Verde              | Cabo Verde                  | Cabo Verde                 | Cabo Verde                |
| Cameroon                | Cameroon                    | Cameroun                   | Camerún                   |
| Cent Afr Rep            | Central African Republic    | République centrafricaine  | República Centroafricana  |
| Chad                    | Chad                        | Tchad                      | Chad                      |
| Comoros                 | Comoros                     | Comores                    | Comoras                   |
| Congo DR                | Democratic Republic of the  | République démocratique du | República Democrática del |
|                         | Congo                       | Congo                      | Congo                     |
| Congo Rep               | Congo                       | Congo                      | República del Congo       |
| Cote d Ivoire           | Côte d'Ivoire               | Côte d'Ivoire              | Côte d'Ivoire             |
| Djibouti                | Djibouti                    | Djibouti                   | Djibouti                  |
| Egypt                   | Egypt                       | Égypte                     | Egipto                    |
| Eq Guinea               | Equatorial Guinea           | Guinée équatoriale         | Guinea Ecuatorial         |
| Eritrea                 | Eritrea                     | Érythrée                   | Eritrea                   |
| Eswatini                | Eswatini                    | Eswatini                   | Eswatini                  |
| Ethiopia                | Ethiopia                    | Éthiopie                   | Etiopía                   |
| Gabon                   | Gabon                       | Gabon                      | Gabón                     |
| Gambia                  | Gambia                      | Gambie                     | Gambia                    |
| Ghana                   | Ghana                       | Ghana                      | Ghana                     |
| Guinea                  | Guinea                      | Guinée                     | Guinea                    |
| Guinea Bissau           | Guinea-Bissau               | Guinée-Bissau              | Guinea-Bisáu              |
| Kenya                   | Kenya                       | Kenya                      | Kenia                     |
| Lesotho                 | Lesotho                     | Lesotho                    | Lesoto                    |
| Liberia                 | Liberia                     | Libéria                    | Liberia                   |
| Libya                   | Libya                       | Libye                      | Libia                     |
| Madagascar              | Madagascar                  | Madagascar                 | Madagascar                |
| Malawi                  | Malawi                      | Malawi                     | Malawi                    |
| Mali                    | Mali                        | Mali                       | Malí                      |
| Mauritania              | Mauritania                  | Mauritanie                 | Mauritania                |
| Mauritius               | Mauritius                   | Maurice                    | Mauricio                  |
| Mayotte                 | Mayotte                     | Mayotte                    | Mayotte                   |
| Morocco                 | Morocco                     | Maroc                      | Marruecos                 |
| Mozambique              | Mozambique                  | Mozambique                 | Mozambique                |
| Namibia                 | Namibia                     | Namibie                    | Namibia                   |
| Niger                   | Niger                       | Niger                      | Níger                     |
| Nigeria                 | Nigeria                     | Nigéria                    | Nigeria                   |
| Reunion                 | Réunion                     | Réunion                    | Reunión                   |
| Rwanda                  | Rwanda                      | Rwanda                     | Rwanda                    |
| Saint Helena            | Saint Helena, Ascension and | Sainte-Hélène, Ascension   | Santa Helena, Ascensión   |
| Sao Tome Prn            | Sao Tome and Principe       | Sao Tomé-et-Principe       | Santo Tomé y Príncipe     |
| Senegal                 | Senegal                     | Sénégal                    | Senegal                   |
| Seychelles Sierra Leone | Seychelles Sierra Leone     | Seychelles Sierra Leone    | Seychelles Sierra Leona   |
| Somalia                 | Somalia                     | Somalie                    | Somalia                   |
| South Africa            | South Africa                | Afrique du Sud             | Sudáfrica Sudán del Sur   |
| South Sudan             | South Sudan                 | Soudan du Sud              | Sudán                     |
| Sudan                   | Sudan                       | Soudan                     |                           |

## Label/En-tête/Rótulo

## English

Tanzania

United Republic of Tanzania

Togo

Togo

Tunisia

Tunisia

Uganda

Uganda

Westn Sahara

Western Sahara

Zambia

Zambia

Zimbabwe

Zimbabwe

## ASIA

## ASIA

Afghanistan

Bangladesh

Bhutan

Brunei Darsm

Cambodia

China

China HK SAR

China Mac SAR

Chinese Taipei

India

Indonesia

Japan

Kazakhstan

Korea DPR

Korea Rep

Kyrgyzstan

Lao PDR

Malaysia

Maldives

Mongolia

Myanmar

Nepal

Pakistan

Philippines

Singapore

Sri Lanka

Tajikistan

Thailand

Timor Leste

Turkmenistan

Uzbekistan

Viet Nam

Afghanistan

Bangladesh

Bhutan

Brunei Darussalam

Cambodia

China

China, Hong Kong Special

Administrative Region

China, Macao Special

Administrative Region

Chinese Taipei

India

Indonesia

Japan

Kazakhstan

Democratic People's Republic of Korea

Republic of Korea

Kyrgyzstan

Lao People's Democratic

Republic

Malaysia

Maldives

Mongolia

Myanmar

Nepal

Pakistan

Philippines

Singapore

Sri Lanka

Tajikistan

Thailand

Timor-Leste

Turkmenistan

Uzbekistan

## Français

## Español

République-Unie de Tanzanie  República Unida de Tanzania

Togo

Togo

Tunisie

Túnez

Ouganda

Uganda

Sahara occidental

Sahara occidental

Zambie

Zambia

Zimbabwe

Zimbabue

## ASIE

## ASIA

Afghanistan

Bangladesh

Bhoutan

Brunéi Darussalam

Cambodge

Chine

Chine, région administrative spéciale de Hong Kong

Chine, région administrative spéciale de Macao

Taipei chinois

Inde

Indonésie

Japon

Kazakhstan

République démocratique populaire de Corée

République de Corée

Kirghizistan

République démocratique populaire lao

Malaisie

Maldives

Mongolie

Myanmar

Népal

Pakistan

Philippines

Singapour

Sri Lanka

Tadjikistan

Thaïlande

Timor-Leste

Turkménistan

Ouzbékistan

Viet Nam

Viet Nam

## C AMERICA + CARIB

## CENTRAL AMERICA AND THE AMÉRIQUE CENTRALE ET CARIBBEAN CARAÏBES

Anguilla

Anguilla

Antigua Barb

Antigua and Barbuda

Aruba

Aruba

Bahamas

Bahamas

Barbados

Barbados

Belize

Belize

BES Islands

Bonaire, Sint Eustatius and

Saba

Br Virgin Is

British Virgin Islands

Cayman Is

Cayman Islands

Costa Rica

Costa Rica

Cuba

Cuba

Curacao

Curacao

Dominica

Dominica

Dominican Rep

Dominican Republic

Anguilla

Antigua-et-Barbuda

Aruba

Bahamas

Barbade

Belize

Bonaire, Saint-Eustache et

Saba

Îles Vierges britanniques

Îles Caïmanes

Costa Rica

Cuba

Curaçao

Dominique

République dominicaine

Afganistán

Bangladesh

Bután

Brunei Darussalam

Camboya

China

China, región administrativa especial de Hong Kong

China, región administrativa especial de Macao

China Taipéi

India

Indonesia

Japón

Kazajstán

República Popular Democrática de Corea

República de Corea

Kirguistán

República Democrática Popular

Lao

Malasia

Maldivas

Mongolia

Myanmar

Nepal

Pakistán

Filipinas

Singapur

Sri Lanka

Tayikistán

Tailandia

Timor-Leste

Turkmenistán

Uzbekistán

Viet Nam

## CENTROAMÉRICA Y EL CARIBE

Anguila

Antigua y Barbuda

Aruba

Bahamas

Barbados

Belice

Bonaire, San Eustaquio y Saba

Islas Vírgenes Británicas

Islas Caimán

Costa Rica

Cuba

Curacao

Dominica

República Dominicana

## Label/En-tête/Rótulo

## English

El Salvador

El Salvador

Grenada

Grenada

Guadeloupe

Guadeloupe

Guatemala

Guatemala

Haiti

Haiti

Honduras

Honduras

Jamaica

Jamaica

Martinique

Martinique

Montserrat

Montserrat

Nicaragua

Nicaragua

Panama

Panama

Puerto Rico

Puerto Rico

St Barth

Saint Barthélemy

St Kitts Nevis

Saint Kitts and Nevis

St Lucia

Saint Lucia

St Maarten

Sint Maarten

St Martin

Saint Martin

St Vincent Gren

Saint Vincent and the

Grenadines

Trinidad Tobago

Trinidad and Tobago

Turks Caicos

Turks and Caicos Islands

US Virgin Is

United States Virgin Islands

## EURASIA

## EURASIA

Armenia

Azerbaijan

Georgia

Russian Fed

Türkiye

## EUROPE

Albania

Andorra

Austria

Belarus

Belgium

Bosnia Herzg

Bulgaria

Croatia

Cyprus

Czechia

Denmark

Estonia

Faroe Islands

Finland

France

Germany

Gibraltar

Greece

Holy See

Hungary

Iceland

Ireland

Italy

Kosovo*

Latvia

Liechtenstein

Lithuania

Luxembourg

Malta

Moldova Rep

Monaco

Armenia

Azerbaijan

Georgia

Russian Federation

Türkiye

## Français

## Español

El Salvador

El Salvador

Grenade

Granada

Guadeloupe

Guadalupe

Guatemala

Guatemala

Haïti

Haití

Honduras

Honduras

Jamaïque

Jamaica

Martinique

Martinica

Montserrat

Montserrat

Nicaragua

Nicaragua

Panama

Panamá

Porto Rico

Puerto Rico

Saint Barthélemy

San Bartolomé

Saint-Kitts-et-Nevis

Saint Kitts y Nevis

Sainte-Lucie

Santa Lucía

Saint Martin (partie

néerlandaise)

San Martín (parte neerlandesa)

Saint Martin (partie française)  San Martín (parte francesa)

Saint-Vincent-et-les

Grenadines

San Vicente y las Granadinas

Trinité-et-Tobago

Trinidad y Tabago

Îles Turques-et-Caïques

Islas Turcas y Caicos

Îles Vierges américaines

Islas Vírgenes Estadounidenses

## EURASIE

## EURASIA

Arménie

Azerbaïdjan

Géorgie

Fédération de Russie

Türkiye

## EUROPE

## EUROPE

Albania

Albanie

Andorra

Andorre

Austria

Autriche

Belarus

Bélarus

Belgium

Belgique

Bosnia and Herzegovina

Bosnie-Herzégovine

Bulgaria

Bulgarie

Croatia

Croatie

Cyprus

Chypre

Czech Republic

République tchèque

Denmark

Danemark

Estonia

Estonie

Faroe Islands

Îles Féroé

Finland

Finlande

France

France

Germany

Allemagne

Gibraltar

Gibraltar

Greece

Grèce

Holy See

Saint-Siège

Hungary

Hongrie

Iceland

Islande

Ireland

Irlande

Italy

Italie

Kosovo*

Kosovo*

Latvia

Lettonie

Liechtenstein

Liechtenstein

Lithuania

Lituanie

Luxembourg

Luxembourg

Malta

Malte

Republic of Moldova

République de Moldova Monaco

Monaco

Armenia

Azerbaiyán

Georgia

Federación de Rusia

Türkiye

## EUROPA

Albania

Andorra

Austria

Belarús

Bélgica

Bosnia-Herzegovina

Bulgaria

Croacia

Chipre

República Checa

Dinamarca

Estonia

Islas Feroe

Finlandia

Francia

Alemania

Gibraltar

Grecia

Santa Sede

Hungría

Islandia

Irlanda

Italia

Kosovo*

Letonia

Liechtenstein

Lituania

Luxemburgo

Malta

República de Moldavia Mónaco

## Label/En-tête/Rótulo

## English

Montenegro

Montenegro

Netherlands

Netherlands

North Macedonia

North Macedonia

Norway

Norway

Poland

Poland

Portugal

Portugal

Romania

Romania

San Marino

San Marino

Serbia

Serbia

Slovakia

Slovakia

Slovenia

Slovenia

Spain

Spain

Sweden

Sweden

Switzerland

Switzerland

UK

United Kingdom of Great

Britain and Northern Ireland

Ukraine

Ukraine

## MIDDLE EAST

## MIDDLE EAST

Bahrain

Iran IR

Iraq

Israel

Jordan

Kuwait

Lebanon

Oman

Qatar

Saudi Arabia

Palestine

Syrian AR

United Arab Em

Yemen

## N AMERICA

Bermuda

Canada

Greenland

Mexico

St Pierre Mq

USA

## OCEANIA

Amer Samoa

Australia

Christmas Is

Cocos Is

Cook Is

Fiji

Fr Polynesia

Guam

Kiribati

Marshall Is

Micronesia

Nauru

New Caledon

New Zealand

Niue

Norfolk Is

Nth Mariana Is

Palau

Bahrain

Iran (Islamic Republic of)

Iraq

Israel

Jordan

Kuwait

Lebanon

Oman

Qatar

Saudi Arabia

State of Palestine

Syrian Arab Republic

United Arab Emirates

Yemen

## NORTH AMERICA

Bermuda

Canada

Greenland

Mexico

Saint Pierre and Miquelon

United States of America

## OCEANIA

American Samoa

Australia

Christmas Island

Cocos (Keeling) Islands

Cook Islands

Fiji

French Polynesia

Guam

Kiribati

Marshall Islands

Micronesia (Federated States

of)

Nauru

New Caledonia

New Zealand

Niue

Norfolk Island

Northern Mariana Islands

Palau

## Français

## Español

Monténégro

Montenegro

Pays-Bas

Países Bajos

Macédoine du Nord

Macedonia del Norte

Norvège

Noruega

Pologne

Polonia

Portugal

Portugal

Roumanie

Rumania

Saint-Marin

San Marino

Serbie

Serbia

Slovaquie

Eslovaquia

Slovénie

Eslovenia

Espagne

España

Suède

Suecia

Suisse

Suiza

Royaume-Uni de Grande-

Bretagne et d'Irlande du Nord  Irlanda del Norte Ukraine Ucrania

Reino Unido de Gran Bretaña e

## MOYEN-ORIENT

## MEDIO ESTE

Bahreïn

République islamique d'Iran

Iraq

Israël

Jordanie

Koweït

Liban

Oman

Qatar

Arabie saoudite

État de Palestine

République arabe syrienne

Émirats arabes unis

Yémen

## AMÉRIQUE DU NORD

Bermudes

Canada

Groenland

Mexique

Saint-Pierre-et-Miquelon

États-Unis d'Amérique

## OCÉANIE

Samoa américaines

Australie

Île Christmas

Îles Cocos

Îles Cook

Fidji

Polynésie française

Guam

Kiribati

Bahréin

Irán (República Islámica del)

Iraq

Israel

Jordania

Kuwait

Líbano

Omán

Qatar

Arabia Saudita

Estado de Palestina

República Árabe Siria

Emiratos Árabes Unidos

Yemen

## NORTEAMÉRICA

Bermudas

Canadá

Groenlandia

México

San Pedro y Miquelón

Estados Unidos de América

## OCEANÍA

Samoa americana

Australia

Isla de Navidad

Islas Cocos

Islas Cook

Fidji

Polinesia francesa

Guam

Kiribati

Îles Marshall

Islas Marshall

Micronésie (États fédérés de)  Micronesia (Estados Federados de)

Nauru

Nouvelle-Calédonie

Nouvelle-Zélande

Nioué

Ile Norfolk

Îles Mariannes du Nord

Palaos

Nauru

Nueva Caledonia

Nueva Zelandia

Niue

Isla Norfolk

Islas Marianas del Norte

Palau

## Label/En-tête/Rótulo

## English

## Français

## Español

Papua N Guin

Papua New Guinea

Papouasie-Nouvelle-Guinée

Papua Nueva Guinea

Pitcairn

Pitcairn

Pitcairn

Pitcairn

Samoa

Samoa

Samoa

Samoa

Solomon Is

Solomon Islands

Îles Salomon

Islas Salomón

Tokelau

Tokelau

Tokelau

Tokelau

Tonga

Tonga

Tonga

Tonga

Tuvalu

Tuvalu

Tuvalu

Tuvalu

Vanuatu

Vanuatu

Vanuatu

Vanuatu

Wallis Fut Is

Wallis and Futuna Islands

Wallis-et-Futuna

Wallis y Futuna

## S AMERICA

## SOUTH AMERICA

## AMÉRIQUE DU SUD

## SUDAMERICA

Argentina

Argentina

Argentine

Argentina

Bolivia

Bolivia (Plurinational State of)

Bolivie (État plurinational de)  Bolivia (Estado Plurinacional de)

Brazil

Brazil

Brésil

Brasil

Chile

Chile

Chili

Chile

Colombia

Colombia

Colombie

Colombia

Ecuador

Ecuador

Equateur

Ecuador

Falklands Malv

Falkland Islands (Malvinas)

Îles Falkland (Malvinas)

Islas Malvinas (Falkland)

Fr Guiana

French Guiana

Guyane française

Guayana Francesa

Guyana

Guyana

Guyana

Guyana

Paraguay

Paraguay

Paraguay

Paraguay

Peru

Peru

Pérou

Perú

South Georgia

South Georgia and the South Sandwich Islands

Géorgie du Sud-et-les Îles

Sandwich du Sud

Georgia del Sur y las Islas

Sandwich del Sur

Suriname

Suriname

Suriname

Surinam

Uruguay

Uruguay

Uruguay

Uruguay

Venezuela

Venezuela (Bolivarian Republic Venezuela (République of) bolivarienne du)

La República Bolivariana de Venezuela

Source: UN Standard Country or Area Codes for Statistical Use (M49 List)

http://unstats.un.org/unsd/methods/m49/m49.htm.

Note: (*) Throughout this publication, the designation Kosovo* is without prejudice to positions on status and in line with the United Nations Security Council Resolution 1244 (1999).

Total capacity

Capacité totale

Capacidad total

## Total renewable energy Total énergies renouvelables Total energías renovables

| CAP (MW)               | 2013         | 2014         | 2015         | 2016         | 2017         | 2018          | 2019          | 2020           | 2021          | 2022           |
|------------------------|--------------|--------------|--------------|--------------|--------------|---------------|---------------|----------------|---------------|----------------|
| World                  | 1 566 487    | 699 064      | 852 777      | 2 018 264    | 2 186 038    | 2 359 398     | 2 543 378     | 2 813 159      | 3 077 238     | 3 371 793      |
| Africa                 | 30 718       | 32 653       | 34 971       | 37 716       | 43 064       | 48 437        | 50 553        | 53 877         | 56 111        | 58 783         |
| Algeria                | 253          | 266          | 329          | 568          | 662          | 686           | 686           | 667            | 587           | 599            |
| Angola                 | 964          | 1 032        | 1 033        | 1 765        | 2 458        | 3 126         | 3 460         | 3 794          | 3 794         | 4 078          |
| Benin                  | 1            | 1            | 2            | 3 3          | 3            | 3             | 3             | 3              | 3             | 28             |
| Botswana Burkina Faso  | 2 38         | 2 39         | 2 41         | 43           | 3 80         | 4 95          | 6 98          | 6 98           | 6 98          | 6 128          |
| Burundi                | 57           | 58           | 58           | 59           | 57           | 57            | 57            | 57             | 65            | 80             |
| Cabo Verde Cameroon    | 33 736       | 33 738       | 33 740       | 33 742       | 33 744       | 35 746        | 35 826        | 35 827         | 35 827        | 35 827         |
| Cent Afr Rep           | 19           | 19           | 19           | 19           | 19           | 19            | 19            | 19             | 19            | 19             |
| Chad Comoros           | 2            | 2            | 2            | 3 1          | 3 1          | 3 1           | 3 1           | 4 1            | 4 1           | 4 5            |
| Congo DR               | 1 2 515      | 1 2 516      | 1 2 529      | 2 543        | 2 558        | 2 732         | 2 741         | 2 741          | 2 741         | 2 742          |
| Congo Rep              | 206          | 207          | 207          | 213          | 227          | 227           | 227           | 227            | 227           | 227            |
| Cote d Ivoire Djibouti | 607 0        | 608 0        | 609 0        | 609 0        | 887 0        | 892 0         | 892 0         | 892 0          | 892 20        | 892            |
| Egypt                  | 3 457        | 3 457        |              | 3 681        | 3 802        | 4             | 5 690         | 5 934          | 6 258         | 20             |
|                        |              |              | 3 658        |              |              | 793           |               |                | 127           | 6 322          |
| Eq Guinea              | 126          | 126          | 126          | 126          | 126          | 127           | 127 12        | 127            |               | 127            |
| Eritrea Eswatini       | 1 186        | 9 169        | 9 169        | 10 169       | 12 169       | 12 169        | 169           | 12 169         | 12 179        | 12 179         |
| Ethiopia               | 2 224        | 2 230        | 2 619        | 2 649        |              | 4 451         | 4 451         | 4              | 4 759         | 5 589          |
| Gabon                  | 332          | 332          | 333          | 333          | 4 366 333    | 333           | 333           | 713 333        | 333           | 333            |
| Gambia                 | 3            | 3            | 3            | 3            | 3            | 3             | 4             | 4              | 4             | 4              |
| Ghana                  | 590          | 1 593        | 623          | 1 627        | 1 632        | 658           | 1 665         |                | 1 691         | 1 691          |
| Guinea                 | 1 129        | 129          | 1 369        | 369          | 370          | 1 370         | 366           | 1 688 591      | 817 1         | 816 1          |
| Guinea Bissau Kenya    | 1 096        | 1 267        | 0 1 563      | 0 1 632      | 0 1 674      | 1 2 060       | 1 2 086       | 1 2 303        | 2 475         | 2 659          |
| Lesotho                | 75           | 75           | 75           | 75           | 75           | 75            | 75            | 75             | 75            | 75 95          |
| Liberia Libya          | 4 5          | 4 5          | 4            | 26           | 95 5         | 95            | 95            | 95             | 95 6          | 6              |
| Madagascar             | 167          | 170          | 5 173        | 5 175        | 177          | 5 197         | 5             | 5              | 197           | 197            |
| Malawi                 | 396          | 399          | 403          | 403          | 410          | 418           | 197 472       | 197            | 552           | 553            |
| Mali                   | 351          | 359          | 360          | 361          | 362          | 363           | 364           | 473 414        | 445           | 585            |
| Mauritania             | 22           | 23           | 53           | 69           | 69           | 121           | 122           | 122            | 122           | 123            |
| Mauritius Mayotte      | 145 13       | 145 13       | 171 13       | 187 13       | 194 15       | 236 16        | 261 17        | 269 19         | 271 30        | 271 30         |
| Morocco                | 1 837        | 2 143        | 2 307        | 2 417        | 2 539        | 3 272         | 3 272         | 3 522          | 3 638         | 3 727          |
| Mozambique             | 2 209        | 2 211        | 2 214        | 2 217        | 2 219        | 2 260         | 2 260         | 2 266          | 2 272         | 2 316 533      |
| Namibia Niger          | 345 5        | 347 6        | 351 7        | 383 8        | 427 9        | 452 27        | 504 27        | 508 27         | 508 27        | 62             |
| Nigeria                | 2 133        | 2 135        | 2 137        | 2 139        | 2 140        | 2 140         | 2 149 436     | 2 150          | 2 154         | 2 158          |
| Reunion Rwanda         | 348 62       | 359          | 380          | 383 111      | 384 116      | 428 121       | 136           | 445 146        | 463           | 463 151        |
| Sao Tome Senegal       | 2            | 77 2         | 106 2        | 2            | 3 134        | 3 175         | 3 253         | 3 357          | 146 3 423     | 3 446          |
| Prn Seychelles         | 32 6         | 34           | 34 7         | 63           | 9            |               | 11            |                | 19            | 24             |
| Sierra Leone           | 55           | 7            |              | 8            |              | 10 99         | 99            | 13             | 99            | 104            |
| Somalia                |              | 90           | 90           | 91           | 99 10        | 11            | 11            | 99 19          | 27            | 51             |
| South Africa           | 2 1 501      | 2 2 711      | 3 3 430      | 7 4 652      | 6 552        | 7 911 1       | 8 014         | 9 523          | 10 288        | 10 445         |
| South Sudan Sudan      | 0 1 536      | 0 1 538      | 0 1 541      | 0 1 547      | 0 1 557      | 1 740         | 1 1 761 675   | 1 1 798        | 1 1 817       | 14 1 871 677   |
| Tanzania               | 641          | 652          | 659          | 664          | 667          | 670           |               | 677 74         | 677           |                |
| Togo Tunisia           | 67 272       | 67 312       | 67 330       | 67           | 68 349       | 70 375        | 72 391 178    |                | 124 406       | 124 508        |
| Uganda                 | 746          | 766          | 782          | 340 784      | 827          | 907           | 1             | 406 1 195      | 1 197         | 1 222          |
| Zambia Zimbabwe        | 2 302 860    | 2 302 861    | 2 311 876    | 2 431 880    | 2 441 886    | 2 442 1 190   | 2 538 1 193   | 2 539 1 195    | 2 844 1 209   | 3 303 1 222    |
| Asia                   | 553 519      | 632 769      | 722 330      | 813 555      | 921 587      | 1 026 685     | 1 126 196     | 301 702 1      | 455 365       | 1 630 282      |
| Afghanistan            | 294          | 299          | 303          | 349          | 371          | 371           | 380           | 380            | 388           | 492            |
| Bangladesh Bhutan      | 329 1 488    | 356 1 488    | 385 1 615    | 402 1 615    | 434          | 456           | 507 2 335     | 555 2 335      | 718 2 335     | 775 2 335      |
| Brunei Darsm           | 1            | 1            | 1            |              | 1 615 1      | 1 615 1       | 1             | 1              | 5 1           | 5              |
| Cambodia China         | 717          | 975          | 977 103      | 1 981        | 1 061 856    | 1 412 463     | 1 507 844     | 1 690 625      | 749           | 1 840 799      |
| China HK SAR           | 359 516      | 414 651      | 479          | 541 016 17   | 620 47       | 695 47        | 758 143       | 899 1 145      | 020 234 1     | 160 149        |
| Chinese Taipei         | 3 501        | 1 3 71       | 1 4          | 4 90         | 4 944        | 5 940 118 195 | 7 128         | 9 248 134 455  | 149 11 147    | 13 813         |
| India                  | 63 589       | 751 889      | 015 78 579   | 411 411      | 105 253      |               | 480 428       |                | 240 122       | 162 963        |
| Indonesia Japan        | 8 261 46 084 | 8 417 56 103 | 8 574 67 486 | 9 064 76 219 | 9 459 84 187 | 9 805 91 309  | 10 300 99 272 | 10 507 106 858 | 11 111        | 12 481 117 528 |
| Kazakhstan             | 2 608        | 2 805        | 2 893        | 2 951        | 3 015        | 3 369         | 4 214         | 4 997          | 537 856 5 422 | 5 954          |
| Korea DPR              | 4 289        | 4 304        | 4 490        | 4            | 4 796        | 4 828         | 4 832         | 4 907          | 4             | 4 917          |
| Korea Rep              | 4 330        | 5            | 7 217        | 9            | 11 442       | 13 951        | 18            | 20 411         | 917 24 365    | 27 241         |
|                        |              |              |              | 733 354      |              | 3 673         | 054 3 673     |                |               |                |
| Kyrgyzstan             | 3 572        | 716 3 671    | 3 677 4 355  | 3 677        | 3 689        |               |               | 3 674          | 3 674 8 932   | 3 674 9 622    |
| Lao PDR Malaysia       | 2 968 5 718  | 3 253 6 397  |              | 4 931 7 991  | 5 184 7 339  | 5 554 7 521   | 6 381 7 962   | 8 165 8 571    | 8             | 044            |
|                        | 3            |              | 7 563 6      | 9            | 12           |               | 22            |                |               | 9 37           |
| Maldives               |              | 5            |              |              | 180          | 18 251        | 276           | 28             | 898 32        | 380            |
| Mongolia               | 85 2 865     | 85 043       | 85 3 267     | 3            | 400          | 409           | 3             | 3              | 3             | 3 466          |
| Myanmar                | 761          | 3 778        | 834          | 97 346 854   | 3 1 000      | 3 1 121       | 452 1 241     | 280 448        | 280 444 2 095 | 2 342          |
| Nepal Pakistan         |              |              |              | 8 807        | 9 223        | 12 203        |               | 1 378          |               |                |
|                        | 7 564        |              |              |              |              |               | 12 345        | 12 565         | 12 887        | 13 943         |
|                        |              | 7            | 8 126        |              |              |               |               |                |               |                |
|                        |              | 915          |              |              |              |               |               |                |               |                |

## Total renewable energy Total énergies renouvelables Total energías renovables

| CAP (MW)               | 2013              | 2014              | 2015          | 2016             | 2017          | 2018          | 2019            | 2020               | 2021              | 2022          |
|------------------------|-------------------|-------------------|---------------|------------------|---------------|---------------|-----------------|--------------------|-------------------|---------------|
| Philippines            | 4 857             | 5 281             | 5             | 6 272            | 6 424         | 6 596         | 6 772           | 6 986              | 7                 | 7 670         |
| Singapore              | 172               | 209               | 625 251       | 307              | 327           | 380           | 479             | 531                | 314 694           | 846           |
| Sri Lanka              | 1 729             | 1 834             | 1 878         | 1 963 5          | 2 061 5       | 2 195         | 2 334           | 2 454 5            | 2 720 5           | 2 857 5 274   |
| Tajikistan             | 4 814 6           | 5 035 7           | 5 033 7       | 039 9            | 039 10        | 5 153 11      | 5 273 11        | 273 11             | 274 12            |               |
| Thailand               | 677               | 373               | 902           | 369              | 147           | 215           | 700             | 845                | 197               | 12 197        |
| Timor Leste            | 1 1               | 1 1               | 1 1           | 1                | 1             | 1             | 1               | 1                  | 1                 | 1             |
| Turkmenistan           | 1 823             | 1 872             |               | 1                | 1 861         | 1             | 1 1 912         | 1 009              | 2 2 156           | 2 2 305       |
| Uzbekistan Viet Nam    | 14 901            | 15 263            | 1 882 16 208  | 1 883 17 485     | 1 18 217      | 1 919 18 715  | 26 077          | 2 38 379           | 42 727            | 45 326        |
| C America + Carib      | 9 825             | 10 405            | 11 862        | 13 457           | 14 272        | 15 064        | 16 234          | 16 797             | 17 646            | 18 052        |
| Anguilla               | 0                 | 1                 | 1             | 2                | 2             | 1             | 2               | 2                  | 2                 | 2             |
| Antigua Barb           | 0                 | 0                 | 3             | 4                | 4             | 9             | 9               | 17                 | 17                | 17            |
| Aruba                  | 32                | 37                | 38            | 38 1             | 38            | 46            | 46              | 46                 | 46                | 46            |
| Bahamas Barbados       | 1 0               | 1 1               | 1 3           | 15               | 1 16          | 1 17          | 2 33            | 2 49               | 2 64              | 3 70          |
| Belize                 | 65                | 66                | 66            | 66               | 74            | 93            | 99              | 99                 | 99                | 99            |
| BES Islands            |                   | 11                |               |                  | 16            | 17            |                 | 18                 | 18                | 18            |
| Br Virgin Is           | 11 1              | 1                 | 11            | 13 1             | 1             | 1             | 18 2            | 2                  | 2                 | 2             |
| Cayman Is              |                   |                   | 1             | 3                | 9             | 10 3          | 11 3            | 13                 | 14                | 14            |
| Costa Rica             | 2 174             | 2 245             | 2 359         | 2 894            | 3 010         | 075           | 144             | 3 124              | 3 189             | 3 138         |
| Cuba                   | 555               | 596               | 629           | 610              | 675           | 758           | 1 085           | 1 252              | 1 281             | 1 293         |
| Curacao Dominica       | 33                | 38                | 40            | 41               | 58            | 59            | 62 7            | 63                 | 63                | 63            |
| Dominican Rep          | 7 723             | 7 734             | 7 745         | 8 872            | 8 906         | 7 1 053       | 1 350           | 7 1 428            | 7 1 637           | 7 1 833       |
| El Salvador            | 974               | 1 010             | 924           | 982              | 1 169         | 1 281         | 1 486           | 1 593              | 1 775             | 1 796         |
| Grenada Guadeloupe     | 1                 | 1 141             | 1 148         | 2 148            | 2 153         | 3 158         | 3 185           | 4 188              | 4                 | 4             |
| Guatemala              | 144               | 775               | 178           | 667              |               | 863           | 870             | 870                | 199               | 203           |
|                        | 1 646             | 1                 | 2             | 2                | 2 753         | 2             | 2               | 2                  | 2 872             | 2 878         |
| Haiti Honduras         | 58 839            | 58 905            | 58 1 369      | 58 1 476         | 59 1 604      | 80 1 701      | 81 1 742        | 81 1 861           | 81 1 877          | 81 1          |
| Jamaica                | 103               |                   | 108           | 189              | 217           | 217           | 254             | 254                | 254               | 877           |
| Martinique Montserrat  | 65                | 105 66            | 70            | 71               | 73            | 112           | 129 0           | 131 0              | 132 1             | 254 132 1     |
| Nicaragua Panama       | 556 1 548         | 596 1 715         | 613 2         | 661 2            | 674 2 227     | 676 2 292     | 733             | 733                | 734               | 734 2 614     |
| Puerto Rico            | 272               | 276               | 053 407       | 164 443          | 502           | 505           | 2 314 537       | 2 343 583          | 2 554 690         | 841           |
| St Barth               |                   |                   |               | 0                | 0             | 0             | 0               | 0                  | 0                 | 0             |
| St Kitts Nevis         | 3                 | 3                 |               |                  | 3             | 3             | 3               | 4                  | 4                 | 4             |
| St Lucia               | 0                 | 0                 | 3             | 3 1              | 1             | 4             | 4               | 4                  | 4                 | 4             |
| St Martin              | 1                 | 2                 | 1 3           | 2                | 0             | 0             | 1               | 1                  | 1                 | 1             |
| St Vincent Gren Tobago | 6                 | 6                 | 6             | 7                | 7             | 7             | 8               | 9                  | 9                 | 9             |
| Trinidad Turks Caicos  | 4                 | 4                 | 4 0           | 4 0              | 4 0           | 4 0           | 4 1             | 4 1                | 4 1               | 4 1           |
| Eurasia                | 81 301            | 84 322            | 88 118        | 91 182           | 96 186        | 100 194       | 103 586         | 109 909            | 115 570           | 118 989       |
| Armenia                | 1 292             | 1                 | 1 289         | 1                | 1 332         | 1 357         | 1 389           | 1 446              | 1 556             | 1 645         |
| Azerbaijan             | 1 125             | 301 1 120         | 1 154         | 316 1 184        | 1 194         | 1 277         | 1 289           | 1 296              | 1 316             | 1 339         |
| Georgia Fed            | 2 705             | 2 380             | 2 378         | 2 450            | 2 744         | 2 716         | 2 607           | 2 753              | 3 006             | 3 127         |
| Russian Türkiye        | 50 629 25 551     | 51 581 27 940     | 51 781 31 516 | 51 787 34 446    | 52 170 38 746 | 52 614 42 230 | 53 913 44 389   | 55 219 49 195      | 56 462 53 230     | 56 880 55 998 |
| Europe                 | 418               | 439 891           | 465 018       | 491 344          | 512 865       | 537 352       | 574             | 609 048            | 651               | 708 582       |
|                        | 916               |                   |               |                  |               |               | 571             |                    | 292               |               |
| Albania Andorra        | 1 782 51          | 1 726 51          | 1 799 51      | 1 914 51         | 2 049 51      | 2 107 52      | 2 177 53        | 2 409 54           | 2 531 55          | 2 537 55      |
| Austria                | 17 192            | 17 839            | 18 473 97     | 19 336           | 19 596 300    | 20 376 390    | 20 774 415      | 21 156             | 22 110            | 23 424 597    |
| Belarus                | 74 5              | 81 5              | 6 368         | 222 6 695        |               | 8 300         | 9 511           | 491 11 273         | 488 11            | 13 089        |
| Belgium Bosnia         | 754               | 982               |               |                  | 7 419         |               |                 |                    | 888               |               |
| Herzg Bulgaria         | 1 703 4           | 1 719 4           | 1 725 4       | 1 776 4 145      | 1 808 4 289   | 1 886 4 316   | 1 930 4 319     | 1 953 4 364        | 2 030 4           | 2 081 5 205   |
| Croatia                | 095 2             | 123 2             | 136 2         | 2                | 2 916         | 2             | 3               | 3                  | 3                 | 3 593         |
| Cyprus                 | 475 192           | 577 221           | 713 244       | 793 252 4 212    | 278           | 979 289       | 068 322         | 255                | 532 490           | 635           |
| Czechia                | 4 095             | 4 6               | 4             | 7 410            | 278           | 4 271         | 4 373           | 400 4 451          | 485 4             | 4 934         |
|                        | 6                 | 170 750           | 214 7 109     |                  | 4 8 194       | 8 902         | 9               | 9                  | 552 10            | 11 734        |
| Denmark Estonia        | 584 519           | 561               | 594           | 607              | 615           | 609           | 180 716         | 664 829            | 882 1             | 1 178         |
| Faroe Islands Finland  | 5                 | 5                 | 60 6 142      | 6                | 60 7 512      | 56 7 563      | 7               | 8                  | 012 9             | 63 12 095     |
|                        | 48                | 60                |               | 60               | 036           | 743           | 53 53           | 59                 | 63 564 60         | 65 381        |
| France                 | 516 38 914 83 766 | 747 40 784 90 325 | 43 027 97 851 | 746 45 058 436   | 514           | 905           | 890 625 125 068 | 774 55 964 131 686 | 394 138 567       | 378           |
| Germany Greece         | 7 672             | 8 010             | 8 138         | 104 8 424        | 8 686         | 50 9 020      | 9 923           | 10 921             | 12                | 13 968        |
|                        |                   |                   |               |                  | 48 112        | 118           |                 |                    | 456               | 148           |
| Hungary                | 749               | 1 024             | 1 077         | 1 048            |               |               | 2 288           | 3 024              |                   | 3 926         |
| Iceland                | 2 652             | 2 653             | 2 658         | 2                | 1 224 2 711   | 1 630 2 862   | 2 869           | 2 879              | 3 906 2 880 4 819 | 2 880 5 099   |
| Ireland                | 2 227             | 2 592 49          | 2 760 50      | 659 3 117 51 195 | 3 676 52 128  | 4 046         | 4 528           | 4 741              |                   | 59 891        |
| Italy                  | 48 857 44         | 526 44            | 417 44        |                  | 121           | 53 161 121    | 54 373 139      | 55 493 154         | 56 856            | 259 1 965     |
| Latvia                 | 1 761             | 1 778             | 1 782         | 81 1 778         | 796           | 1 779         | 1 826           | 1 826              | 1                 |               |
|                        |                   |                   |               |                  | 787           |               |                 |                    |                   |               |
| Kosovo*                | 527               | 545               |               |                  | 1             | 836           | 859             |                    | 259 823 1 159     | 1 617         |
| Lithuania Luxembourg   |                   |                   | 693           |                  | 318           | 324           |                 | 937                |                   | 572           |
|                        |                   | 225               |               | 768              |               |               |                 |                    | 504               |               |
|                        | 211               |                   |               | 301              |               |               |                 |                    |                   |               |
|                        |                   |                   |               |                  |               |               | 386             | 430                |                   |               |
|                        |                   |                   | 239           |                  |               |               |                 |                    |                   |               |

## Total renewable energy Total énergies renouvelables Total energías renovables

| CAP (MW)                 | 2013          | 2014             | 2015          | 2016          | 2017              | 2018           | 2019          | 2020          | 2021          | 2022          |
|--------------------------|---------------|------------------|---------------|---------------|-------------------|----------------|---------------|---------------|---------------|---------------|
| Malta                    |               |                  |               |               | 116               |                |               |               |               | 210           |
| Moldova Rep              | 32 67         | 58 69            | 78 69         | 98 71         | 82                | 137 106        | 160 110       | 193 116       | 210 158       | 197           |
| Montenegro               | 631           | 655              | 665           | 671           | 750               | 752            | 800           | 821           | 821           | 841           |
| Netherlands              | 4 169         | 4 661            | 5 748         | 7 203         | 7 937             | 9 867          | 12 567        | 18 661        | 23 598        | 32 839        |
| North Macedonia          | 624           | 682              | 716           | 720           | 731               | 740            | 751           | 829           | 831           | 831           |
| Norway                   | 32 002        | 32 252           | 32 394        | 32 814        | 33 251            | 34 396         | 35 912        | 37 999        | 39 406        | 39 650        |
| Poland                   | 5 116         | 5 638            | 6 919         | 7 881         | 7 982             | 8 301          | 9 360         | 12 275        | 16 457        | 21 242        |
| Portugal Romania         | 11 143 10 098 | 11 573 11 152    | 12 153 11 212 | 13 208 11 162 | 13 541 11 145     | 13 753 11 169  | 14 118 11 169 | 14 208 11 121 | 15 074 11 120 | 16 329 11 141 |
| Serbia                   | 2 331         | 2 422            | 2 439         | 2 460         | 2 480             | 2 694          | 2 910         | 2 928         | 2 957         | 3 054         |
| Slovakia                 | 2 359         | 2 380            | 2 384         | 2 397         | 2 385             | 2 330          | 2 431         | 2 377         | 2 406         | 2 406         |
| Slovenia                 | 1 367         | 1 404            | 1 419         | 1 409         | 1 479             | 1 474          | 1 512         | 1 612         | 1 704         | 1 878         |
| Spain Sweden             | 46 819 645    | 46 850           | 47 708        | 47 798        | 47 948            | 48 283         | 54 601        | 57 313        | 62 011        | 67 909        |
| Switzerland              | 24 14 409     | 25 528 14 638    | 26 869 15 040 | 27 805 16 259 | 28 179 17 049     | 29 180 17 470  | 31 156 17 826 | 32 049 18 337 | 34 603 18 813 | 38 044 19 514 |
| UK                       | 19 878        | 24 770           | 30 690        | 38 108        | 39 918            | 43 726         | 46 337        | 47 261        | 48 896        | 52 418        |
| Ukraine                  | 5 769         | 6 048            | 6 105         | 6 199         | 6 530             | 7 455          | 12 189        | 13 764        | 14 921        | 14 921        |
| Middle East              | 14 498        | 15 962           | 15 859        | 16 732        | 17 093            | 18 567         | 21 616        | 22 944        | 25 296        | 28 539        |
| Bahrain                  | 1             | 6                |               | 7             | 7                 |                |               | 10            | 12            |               |
| Iran IR                  | 10 380        | 10 954           | 6 10 411      | 10 783        | 11 367            | 7 11 638       | 10 803        | 11 901        | 11 929        | 12 12 045     |
| Iraq                     | 2 304         | 2 311            | 2 311         | 2 311         | 1 594             | 1 594          | 11 1 594      | 1 594         | 1 594         | 1 599         |
| Israel                   | 473           | 686              | 837           | 968           | 1 068             | 1 408          | 2 200         | 2 711         | 3 650         | 4 470         |
| Jordan Kuwait            | 17            | 17               | 153           | 514           | 624               | 1 009          | 1 588         | 1 996         | 2 169         | 2 555 106     |
| Lebanon                  | 3 288         | 4 292            | 6 298         | 33 318        | 44 331            | 55 347         | 106 368       | 106           | 106           | 732           |
| Oman                     | 1             | 1                | 2             | 2             | 8                 | 8              | 59            | 382 162       | 482 188       | 688           |
| Palestine                |               | 3                | 12            | 25            | 35                | 40             | 82            | 118           | 178           | 192           |
| Qatar                    | 1 21          | 23               | 23            | 24            | 24                | 24             | 24            | 24            | 24            | 824           |
| Saudi Arabia             | 22 857        | 24 1 501         | 24            | 24 1 501      | 37 1 497          | 87 1 499       | 113           | 113           | 443 1 530     | 443 1 557     |
| Syrian AR United Arab Em | 128           | 136              | 1 579 136     | 142           | 356               | 599            | 1 500 1 919   | 1 509 2 062   | 2 734         |               |
| Yemen                    | 2             | 5                | 60            | 80            | 100               | 250            | 250           | 257           | 257           | 3 058 257     |
| N America                | 272 514       | 287 223          | 309 137       | 332 863       | 349 336           | 368 701        | 390 682       | 422 895       | 460 098       | 489 226       |
| Canada                   | 86 766        | 89 508           | 95 612        | 97 484        | 98 638            | 99 945         | 100 650       | 100 890       | 103 190       | 105 775       |
| Greenland Mexico         | 91 15 229     | 91 16 647        | 91 17 423     | 91 19 114     | 91 19 892         | 91 23 068      | 91 26 121     | 92 28 522     | 92 30 669     | 92 31 683     |
| St Pierre Mq USA         | 1 170 427     | 180 976          | 196 010       | 216 174       | 230 714           | 245 596        | 263 820       | 293 392       | 326 147       | 351 676       |
| Oceania                  | 24 051        | 25 572           | 26 729        | 27 685        | 28 909            | 31 121         | 36 381        | 43 811        | 49 376        | 54 620        |
| Amer Samoa Australia     | 2 16 068      | 2 17 370         | 2 18 415      | 4 19 339      | 4 20 492          | 5 22 645       | 5 27 826      | 5 35 177      | 5 40 410      | 5 45 516      |
| Cook Is                  | 1             | 2                | 3             | 3             | 3                 | 5              | 6             | 6             | 6             | 6             |
| Fiji                     | 191           | 191              | 193           | 195           | 210               | 211            | 211           | 211           | 219 94        | 219           |
| Fr Polynesia             | 65            | 72               | 76            | 79            | 83                | 85             | 89            | 92            |               | 94            |
| Guam Kiribati            | 1             | 1 1              | 32            | 35            | 37                | 38             | 40            | 42 3          | 43 3          | 105 3         |
| Marshall                 | 1             | 1                | 2             | 3 2           | 3                 | 3 2            | 3             |               | 2             | 2             |
| Is                       | 1             | 2                | 1 2           | 2             | 2                 |                | 2 4           | 2 4           |               |               |
| Micronesia Nauru         | 1 0           | 0                |               | 1             | 2                 | 4              |               | 2             | 4 3           | 4 3           |
| New                      | 119 7         | 120 7            | 0             |               | 1 142             | 1 144          | 2 175         | 193           |               | 194           |
| Caledon New Zealand      | 272           | 473 0            | 123 7 520 0   | 125 7 529 0   | 7 550             | 7 595 0        | 7 629 1       | 7 684 1       | 196 8 000     | 8 066 1       |
| Niue Palau               | 0             | 1                |               |               | 0                 |                |               |               | 1             | 4             |
| Papua N                  | 1 308         | 309              | 1 327         | 2 328         | 2 328             | 3 328          | 3 329         | 3 329         | 4 330         | 333           |
| Guin Samoa Solomon Is    |               |                  |               | 17            |                   | 27             | 28 4          | 29            |               | 29            |
|                          | 9             | 13               | 14            |               | 27                |                |               |               | 29            | 5             |
| Tokelau                  | 1 1           | 2 1              | 2 1           | 3 1           | 4 1               | 4 1 7          | 1 8           | 4 1 8         | 4 1           | 1 15          |
| Tonga Tuvalu             | 3 0           | 3 0 8            | 4 2           | 4 2           | 7 2               | 2              | 2             | 2             | 8 2           | 2             |
|                          | 7             |                  | 8             | 9             | 10                |                | 12            | 12            | 12            | 12            |
| Vanuatu                  |               |                  |               |               |                   | 11             |               |               |               |               |
| S                        | 161 146       | 170 267          | 178 754       |               | 725               | 278            |               | 232 176       |               | 719           |
| America                  |               |                  |               | 193 728       | 202               | 213            | 223 559       |               | 246 485       | 264           |
|                          | 10 580        | 10 589           | 10 657        | 10 709        | 10 749            |                | 12 690        | 14 069        | 15 020        | 15 076        |
| Argentina Bolivia        | 592 835       | 628 445          | 638 112 641   | 669 121 374   | 796 417           | 11 477 923     | 1 057 144     | 1 068 150 493 | 1 244 161 136 | 1 299 175 262 |
| Brazil Chile             | 99 7 678      | 106 8 329 11 134 | 8 452 11 757  | 9 299 11      | 128 10 289 12 071 | 136 579 10 856 | 575 11 498    | 12 619        | 14 890 12     | 17 910        |
| Colombia Ecuador         | 10 075 2 388  | 2 440            | 2 599         | 4             | 4 714             | 12 194 5 266   | 12 291 5      | 12 387 5 298  | 557 5 300     | 13 435 5 394  |
| Falklands                |               |                  | 1             | 888 640       | 1                 | 1              | 277 3         | 3             | 3             | 3             |
| Malv Fr Guiana           | 1             | 1                | 168           | 1             | 168               |                |               | 179           | 179           | 179           |
| Guyana                   |               | 158 55           | 55            | 168 46        | 48                |                |               | 53            | 53            | 53            |
|                          | 158 55        |                  |               | 849           | 849               | 168 51         | 171 53 832    |               | 8 832         | 832           |
| Paraguay                 | 8 849         | 8 849            | 8 849         | 8             |                   | 8 849          | 8             | 8 832         |               |               |
|                          |               |                  |               |               | 8                 |                |               |               |               | 8             |

Peru

3 784

4 055

4 647

5 725

5 820

6 100

6 289

6 345

6 431

6 431

## Total renewable energy Total énergies renouvelables Total energías renovables

| CAP (MW)      | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   |
|---------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| South Georgia | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      |
| Suriname      | 181    | 186    | 188    | 188    | 189    | 190    | 190    | 191    | 191    | 193    |
| Uruguay       | 2 016  | 2 441  | 2 888  | 3 267  | 3 708  | 3 719  | 3 728  | 3 732  | 3 741  | 3 745  |
| Venezuela     | 14 954 | 14 955 | 15 214 | 16 905 | 16 905 | 16 904 | 16 906 | 16 906 | 16 906 | 16 906 |

## Hydropower Hydroélectricité Hidroeléctrica

| CAP (MW)                  | 2013         | 2014         | 2015         | 2016              | 2017                   | 2018              | 2019 2020    | 2021          | 2022        |
|---------------------------|--------------|--------------|--------------|-------------------|------------------------|-------------------|--------------|---------------|-------------|
| World                     | 1 137 292    | 1 175 663    | 210 331      | 245 935           | 1 270 950 1            | 293 744 1 312 084 | 1 334 078    | 1 362 715     | 392 598     |
| Africa                    | 28 655       | 28 679       | 29 207       | 31 131 34         | 221 35 585             | 36 290            | 37 111       | 37 592        | 38 851      |
| Algeria                   | 228          | 228          | 228          | 228               | 228 228                | 228               | 209          | 129           | 129         |
| Angola                    | 953          | 969          | 969          | 1 700 2           | 393 3 061              | 3 395             | 3 729        | 3 729         | 3 729       |
| Benin Burkina             | 1 32         | 1 32         | 1            | 1                 | 1 1 32 32              | 1 35              | 1 35         | 1 35          | 1 35        |
| Faso Burundi              | 51           | 51           | 32 51        | 32 51             | 48 48                  | 48                | 48           | 48            | 63          |
| Cameroon                  | 733          | 733          | 733          | 733               | 732 732                | 812               | 812          | 812           | 812         |
| Cent Afr Rep              | 19           | 19           | 19           | 19                | 19 19 1                | 19 1              | 19           | 19 1          | 19          |
| Comoros Congo DR          | 1 2 515      | 1 2 515      | 1 2 528      | 1 2 540           | 1 2 551 2              | 2 719             | 1 2 719      | 2 719         | 1 2 719     |
| Congo Rep                 |              | 194          |              | 201               | 709 214 214            | 214               | 214          | 214           | 214         |
| Cote d Ivoire             | 194 604      | 604          | 194 604      | 604               | 879 879                | 879               | 879          | 879           | 879         |
| Egypt                     | 2 800        | 2 800        | 2 800        | 2 800 2           | 800 2 832              | 2 832             | 2 832        | 2 832         | 2 832       |
| Eq Guinea                 | 126          | 126          | 126          | 126               | 126 127                | 127               | 127          | 127           | 127         |
| Eswatini Ethiopia         | 62           | 62           | 62 2 159     | 62 2 159          | 62 62                  | 62                | 62           | 62            | 62          |
|                           | 1 972        | 1 972        |              |                   | 3 817 3 817            | 3 817             | 4 071        | 4 071         | 4 821       |
| Gabon                     | 330          | 330          | 330          | 330               | 330 330                | 330               | 330          | 330           | 330 1       |
| Ghana Guinea              | 1 580 129    | 1 580 129    | 1 584 369    | 1 584 1 369       | 584 1 584 369          | 1 584 364         | 1 584 589    | 1 584 814     | 584 814     |
| Kenya                     |              |              |              |                   | 369 843 846            |                   |              | 860           |             |
| Lesotho                   | 822 75       | 822 75       | 828 75       | 832 75            | 75 75                  | 851 75            | 858 75       | 75            | 868 75      |
| Liberia                   | 4            | 4            | 4            | 26                | 92 92                  | 92                | 92           | 92            | 92          |
| Madagascar                | 162          | 163          | 164          | 164               | 164 164                | 164               | 164          | 164           | 164         |
| Malawi                    | 372          | 372          | 372          | 373               | 373 373                | 373               | 373          | 392           | 392         |
| Mali                      | 315          | 315          | 315          | 315               | 315 315                | 315               | 315          | 315           | 315 61      |
| Mauritius                 | 61 770       | 61 1 770     | 61 1 770     | 60 1 770          | 60 60 1 770            | 60                | 61 770       | 61 1 770      | 1 770       |
| Morocco Mozambique        | 1 2 190      | 2 190        | 2 190        | 190               | 1 770 2 190 2 190      | 1 770 2 190       | 1 2 190      | 2 194         | 2 194 351   |
| Namibia                   | 330          | 330          | 330          | 2 347             | 347 347                | 347               | 351          | 351           |             |
| Nigeria                   | 2 110        | 2 110        | 2 111        | 2 111             | 2 111 2 111            | 2 111             | 2 111        | 2 111         | 2 111       |
| Reunion                   | 134 60       | 134          | 134          | 133               | 133 133                | 133 110           | 133          | 134           | 134 125     |
| Rwanda Sao Tome Prn       | 2            | 66 2         | 94 2         | 98 2              | 99 99 2 2              | 2                 | 120 2        | 120 2         | 2           |
| Sierra Leone South Africa | 54 2 135     | 56 2 133     | 56 2 148     | 56 3 3            | 61 61 480 3 480        | 61 3 480          | 61 3 480     | 61 484        | 61 484      |
| Sudan                     | 1 322        | 1 322        | 1 322        | 147 1 322         | 1 322 1 482            | 1 482             | 1 482        | 3 1 482       | 3 1 482     |
| Tanzania                  | 571          | 571          | 576          | 582               | 583 583                | 589               | 589          | 589           | 589 67      |
| Togo                      | 67           | 67           | 67           |                   | 67 67 66               | 67                | 67           | 67            | 66          |
| Tunisia                   | 62           | 62           | 62           | 67 62             | 62                     | 66                | 66           | 66            | 1 032       |
| Uganda                    | 692          | 692          | 695          | 695               | 707 744 398            | 1 004             | 1 011        | 1 011         | 3 164       |
| Zambia                    | 2 260        | 2 260        | 2 268        | 2 388 2           | 398 2 1 081            | 2 399             | 2 400        | 2 705         |             |
| Zimbabwe                  | 758          | 758          | 773          | 777               | 781                    | 1 081             | 1 081        | 1 081         | 1 081       |
| Asia                      | 451 249      | 479 637      | 500 109      | 516 272 531       | 237 544 221            | 554 632           | 570 238      | 594 474       | 619 681     |
| Afghanistan Bangladesh    | 277 230      | 280 230      | 284 230      | 329 230           | 349 349 230 230 1      | 349 230           | 349 230      | 357 230 2 334 | 459 230     |
| Bhutan Cambodia           | 1 488 683    | 1 488 929    | 1 614 930    | 1 614 930 332     | 1 614 614 980          | 2 334 1           | 2 334 1 330  | 1 330         | 2 334 1 332 |
| China                     | 280          | 304 860      | 319 530      |                   | 1 330 352 261          | 330 358 040       | 370 280      | 390 920       | 413 500     |
| China HK SAR              | 440          |              |              | 070 1 4 691       | 343 775 1 691          | 1 694             | 1 4 695      | 1 4           | 1 4 696     |
| Chinese Taipei            | 4 683        | 1 4 683      | 1 4 691      |                   | 4 50                   | 1 4 695 50        |              | 696           | 52 002      |
| India                     | 44 174 5 177 | 45 406 5 242 | 104 5 322    | 4 49 5 703        | 521 102 5 773          | 279 5 976         | 50 764 6 141 | 51 565 6 602  | 6 689       |
| Indonesia Japan           | 48 932       | 49 597       | 47           | 47 622 5 666 50   | 50                     | 50 033            | 50 041       | 50 019        | 50 025      |
|                           | 2 588        | 2 675        | 50 035 2 678 | 117 50 2 696 2 4  | 014 037 726 2          | 2 778             | 2 785        | 2 807         | 2 807       |
| Kazakhstan Korea DPR      | 4 283        | 4 293        | 4 467        | 701               | 756 4 761 4 790        | 4 790             | 4 865        | 4 865         | 4 865       |
| Korea Rep                 | 6 452 3 572  | 6 467 3 671  | 6 471        | 6 6               | 489 6 490 3            | 6 509 3 673       | 6 506 3 674  | 6 541         | 6 512       |
| Lao PDR                   | 2 928        | 3            | 3 677 4 313  | 485 3 677 3 889   | 689 673 5 414          | 6 241             | 8 025        | 3 674 8 793   | 3 674 9 483 |
| Kyrgyzstan Malaysia       | 4 535        | 212 4 761    | 5 742        | 4                 | 5 136 6                | 6                 | 6 197        | 6 211         | 6 211       |
| Mongolia                  | 29           | 29           | 29           |                   | 6 145                  | 185               | 29           | 29            | 29          |
| Myanmar                   | 2 812        | 2 985        | 3 198        | 6 121 31 264      | 165 31 3               | 3                 | 3 304        | 3 304         | 3 304       |
| Nepal                     | 744          | 759          | 814          | 3 3               | 31 304 304 1 059       | 31 304 1 180      | 1 302        | 1 992         | 2 219       |
| Pakistan                  | 7 089        | 7 220 3 594  | 7 220        |                   | 939 9 904 3 719        | 9 921             | 10 043       | 10 043        | 833         |
|                           | 3 579        |              | 3 613        | 834 7 7           | 404                    | 3 761             | 3 780        | 3 783         | 3 773       |
| Philippines Sri Lanka     | 1 622        | 1 670        | 1 689        | 252 3 623 3 1 728 | 632 1 747              | 1                 | 1 799 5 273  | 1 799         | 10 1 846    |
| Tajikistan Thailand       | 4 814 3 575  | 5 035 3 608  | 5 033 3 639  | 5 5               | 1 798 039 5 3          | 815 5 273 3 667   | 3 669        | 5 274 3 670   | 5 274 3 670 |
|                           |              |              |              | 039 3 649 3 0     | 153 649                |                   |              |               | 0           |
| Timor Leste               | 0            |              | 0 1          |                   | 667 0 1                | 0                 | 0 1          | 0             | 2           |
|                           | 1            | 0            |              | 1                 | 0                      |                   |              | 2             |             |
| Turkmenistan Uzbekistan   | 1 822        | 1 1 871      | 1 880        | 880 131           | 1                      | 1 1 908           | 2 005 20 817 | 2 052         | 2 052       |
| Viet Nam                  | 14 718       | 15 069       | 15 905       | 1 17 17           | 1 858 1 915 809 17 989 | 20 326            |              | 21 582        | 21 857      |
| C America + Carib         | 6 338        | 6 561        | 6 833        | 7 650 7           | 886 8 073              | 8 146             | 8 271        | 8 310         | 8 265       |
| Belize Costa Rica         | 38           | 38           | 38           | 38 256            | 2                      | 2                 | 57 2 332     | 57            | 57 2 331    |
|                           | 1 762        | 1 782        | 1 811        |                   | 38 57                  | 57 343            |              | 2             |             |
|                           |              |              |              | 2                 |                        |                   |              |               |             |
| Cuba                      | 63           | 63           | 63           | 2 350 66          | 373 64                 | 72                | 72           | 379 72        | 72          |
|                           |              |              |              | 66 7              |                        | 7                 |              | 7             |             |
|                           |              |              | 7            |                   | 7                      |                   |              |               | 7           |
| Dominica                  |              | 7            |              |                   | 7                      |                   | 7            |               |             |
|                           | 7            |              |              |                   |                        |                   |              |               |             |

## Hydropower Hydroélectricité Hidroeléctrica

| CAP (MW)               | 2013           | 2014           | 2015           | 2016          | 2017                 | 2018                    | 2019 2020        | 2021             | 2022             |
|------------------------|----------------|----------------|----------------|---------------|----------------------|-------------------------|------------------|------------------|------------------|
| Dominican Rep          | 614            |                |                |               | 617                  | 617                     |                  |                  | 627              |
| El Salvador            | 487            | 617 488        | 617 494        | 617 494       | 574                  | 618 574 573             | 625 573          | 625 572          | 572              |
| Guadeloupe             | 9              | 9              | 9              | 9             | 11 438               | 11 11                   | 11 1             | 11               | 11               |
| Guatemala              | 997            | 1 001          | 1 087          | 1 392         | 1 1 502 78           | 1 574                   | 577              | 1 579            | 1 581            |
| Haiti                  | 56             | 56             | 56             | 56            | 56                   | 78                      | 78               | 78               | 78               |
| Honduras               | 558            | 624            | 656            | 670           | 676 714              | 729                     | 837              | 849              | 849              |
| Jamaica                | 30             | 30             | 30             | 30            | 30 30 142            | 30                      | 30               | 30               | 30               |
| Nicaragua Panama       | 120 1 494      | 120 1 623      | 138 1          | 142 1 769     | 142 1 777            | 157 1 792               | 157 1 811        | 159 1 789        | 159 1 789        |
| Puerto                 | 98             | 98             | 725 98         | 98            | 1 801                | 98                      | 98               | 98               |                  |
| Rico                   |                |                |                |               | 98                   | 98 6                    |                  |                  | 98               |
| St Vincent Gren        | 6              | 6              | 6              | 6             | 6                    | 6                       | 6                | 6                | 6                |
| Eurasia Armenia        | 77 923 1 289   | 79 731 1 298   | 82 111 1 287   | 82 994 1 312  | 84 131 85 1 327 1    | 248 85 336 1 336        | 862 88 811 1 336 | 89 707 1 336     | 89 919 1 336     |
| Azerbaijan             | 1 084          | 1 078          | 1 103          | 1 105         | 1 106 1 131          | 1 145                   | 1 149            | 1 157            | 1 177            |
| Georgia                | 2 705          | 2 380          | 2 378          | 2 430         | 2 723 2 702          | 695 2 583               | 2 727            | 2 967            | 3 080            |
| Russian Fed            | 50 556         | 51 332         | 51 475         | 51 466        | 51                   | 52 295                  | 52 614           | 52 754           | 52 754           |
| Türkiye                | 22 289         | 23 643         | 25 868         | 26 681        | 51 795 27 273 28 291 | 28 503                  | 30 984           | 31 493           | 31 572           |
| Europe                 | 211 126        | 211 876        | 214 429        | 217 888       | 219 572 220 610      | 221 536                 | 223 065          | 224 498          | 225 280          |
|                        | 1 781          | 1 725          | 1 798          | 1 913         | 105                  | 2                       | 2 387            | 2                | 2 507            |
| Albania                |                |                |                |               | 2 047 2              | 162                     |                  | 507              |                  |
| Andorra                | 46             | 46             | 46             | 46            | 46 46 14 516         | 46                      | 46               | 46               | 46               |
| Austria Belarus        | 13 383         | 13 532         | 13 650         | 14 116        | 14 150 95            | 14 597                  | 14 635           | 14 748 96        | 14 969           |
| Belgium                | 32 1 426       | 33 1 428       | 34 1 419       | 74 1 416      | 95 1 414 1 415       | 95 411                  | 96 1 413         | 1 418            | 96 1 419         |
| Bosnia Herzg           | 2 122          |                | 2 137          |               | 2 211                | 1                       | 2 249            | 2 257            |                  |
| Bulgaria               | 3 203          | 2 131 3 219    | 3 219          | 2 180 3 223   | 2 236 3 372 3        | 2 239 379 3 378         | 3 376            | 3 369            | 2 257 3 369      |
| Croatia                | 2 178          | 2 180          | 2 195 2        | 2 192         | 2 200 2 264          | 2 200                   | 2 200            | 2 201            | 2 201            |
| Czechia                | 2 252          | 2 252          | 260            | 2 262         | 2 193 2 265          | 2 265                   | 2 265            | 2 285            | 2 286            |
| Denmark Estonia        | 9 8            | 9              | 7 6            | 9             | 7 7                  | 7 7                     | 7                | 7 6              | 5 10             |
| Faroe Islands          | 39             | 5 39           | 39             | 6 39          | 7 39 40              | 6 40                    | 8 40             | 40               | 40               |
| Finland                | 3 108          | 3 132          | 3 133          | 3 133         | 3 156 3 727          | 152 3 157               | 3 164            | 3 171            | 3 171            |
| France                 | 25 645         | 25 576         | 25 552         | 25 621        | 25 707 25            | 25 868                  | 25 955           | 26 291           | 26 291           |
| Germany                | 11 239         | 11 234         | 11 255         | 11 207        | 11 120 10            | 684 10 733              | 10 808           | 10 844           | 10 937           |
| Greece                 | 3 238          | 3 389          | 3 392          | 3 392         | 3 392 3              | 409 3 412               | 3 417            | 3 421            | 3 423 60         |
| Hungary                | 57             | 57             | 57             | 57            | 57                   | 57 58                   | 58               | 60               |                  |
| Iceland Ireland        | 1 984 529      | 1 984 529      | 1 987 529      | 1 987 529     | 1 995 2 529          | 099 2 104 529 529       | 2 114 529        | 2 114 529        | 2 114 529        |
| Italy                  | 22 009         | 22 098         | 22 220         | 22            | 22 426 22            | 499 22 541              | 22 695           | 22 750           | 22 781           |
| Kosovo*                | 43             | 43             |                | 298 78        | 80                   | 80 95                   | 110              | 110              | 110              |
| Latvia                 | 1 587 876      | 1 588          | 43 1 588       | 1 564         | 1 564 1              | 565 1 587               | 1 586            | 1 587            | 1 608            |
| Lithuania              |                | 877            | 877            | 877           | 877                  | 877 877                 | 877              | 877              | 877              |
| Luxembourg Moldova Rep | 1 134 64       | 1 330 64       | 1 330          | 1 330 64      | 1 331 1 64           | 330 1 330 64 64         | 1 331 64         | 1 331 64         | 1 328 64         |
|                        | 630            | 653            |                |               | 675                  | 676 676                 | 697              | 697              | 697              |
| Montenegro Netherlands | 37             | 37             | 64 662         | 668           | 37                   | 37 37 678               | 37               | 37               |                  |
| North Macedonia        | 617            | 630            | 37 658         | 37 661        | 671 31               | 674 530                 | 687 33           | 689              | 36 689           |
| Norway                 | 31 033         |                | 372            | 31            | 912 390              | 32 797                  | 732              | 075              | 34 118           |
| Poland                 | 2 355          | 31 240 2 364   | 31 2 370       | 817 2 385     | 32 2 2 391 7 236     | 2 397 7 262             | 2 400            | 34 2 398         | 2 401            |
| Portugal Romania       | 5 661 6 610    | 5 715          | 6 168          | 6 960 6       | 7 226 6 692 6        | 701 6                   | 7 241 6 652      | 7 255 6 662      | 7 592 6 661      |
| Serbia                 | 2 931          | 6 613 3 017    | 6 730 3 022    | 734 3 030     | 038                  | 686 3                   | 3 082 2 529      | 3 085            |                  |
| Slovakia               | 2 523          | 2 523          | 2 522          | 2 524         | 3 3 2                | 043 074 528 2 527       |                  | 2 531            | 3 097            |
| Slovenia               | 1 299          | 1 296          | 1 295          | 1 293         | 2 523 1 347 1        | 343 1 351               | 1 352            | 1 352            | 2 531 1 354      |
| Spain Sweden           | 19 185 494     | 19 223 996     | 20 053         | 20 080        | 20 079 20 16         | 080 20 114 16 462       | 20 117 406       | 20 132           | 20 132           |
| Switzerland            | 16 13 817      | 15 13 744      | 16 329 13 815  | 16 466 14 806 | 502 16 15 353        | 431 15                  | 16 15 594        | 16 407 15 594    | 16 407 15 610    |
| UK                     | 4 453          | 4 474          | 4 677          | 4 733         | 15 770               | 542 574 4 773           | 4 776            | 4 794            | 4 795            |
| Ukraine                | 5 489          | 5 851          | 5 883          | 6 079         | 4 4 6 213            | 773 6                   | 6 334            | 6 662            | 6 662            |
|                        |                |                |                |               | 6                    | 243 325                 |                  |                  |                  |
| European               | 146 307        | 464            | 454            | 973           | 625                  | 151 056                 | 151 320          | 151              | 642              |
| Union                  |                | 146            | 148            | 149           | 150 150              | 627                     |                  | 933              | 152              |
| Middle East            | 13 930         | 15 094         | 15 669         | 15 891        | 15 545               | 15 691                  | 16 084           | 16 082           | 16 082           |
| Iran IR Iraq           | 10 265 2 514 7 | 10 785 2 514 7 | 11 278 2 514 7 | 11 578 2 514  | 11 953 12 1 797      | 15 774 099 12 182 1 797 | 12 193 1 797     | 12 193 1 797 306 | 12 193 1 797 306 |
| Israel Jordan          | 12             | 12             | 16             | 7 16          | 7 16                 | 1 797 7 16              | 7 306            | 14               |                  |
| Lebanon Syrian         |                |                | 282            |               | 282                  | 16 282 282              | 16               | 282              | 14 282           |
|                        | 282 850        | 282 1 494      | 1 572          | 282 1 494     | 1 490 1              | 490 1 490               | 282 1 490        | 1 490            | 1 490            |
| AR N America           | 188 928        | 190 300        | 194 081        | 195 823       | 196 402 197          | 092 197 605             | 197 886          | 199 194          | 200 085 83 553   |
|                        | 75 511 91      |                | 79 405         | 80 304 91     | 80 831 91            | 81                      | 81 404 91        | 82 740           | 91               |
| Canada Greenland       |                | 75 474 91      | 91             |               | 81 396               | 399                     |                  |                  |                  |
| Mexico                 | 11 633         | 464            | 223            | 12 580        | 12 628               | 91 13                   | 13 301           |                  |                  |
|                        |                |                |                |               |                      | 91 301                  |                  | 13               | 13 303           |
|                        |                |                |                |               |                      |                         |                  | 91               |                  |
| USA                    | 101 693        | 102 270        | 361            |               | 12 643 962           | 102 814                 | 103 090          | 303 060          | 139              |
|                        |                | 12             |                | 848           |                      |                         |                  |                  |                  |
|                        |                |                | 12 102         | 102           | 102 851 102          |                         |                  | 103              | 103              |

## Hydropower Hydroélectricité Hidroeléctrica

| CAP (MW)      | 2013    | 2014    | 2015    | 2016    | 2017    | 2018    | 2019    | 2020    | 2021    | 2022    |
|---------------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
| Oceania       | 14 211  | 14 211  | 14 229  | 14 230  | 14 234  | 14 486  | 14 496  | 14 499  | 14 499  | 14 502  |
| Australia     | 8 271   | 8 271   | 8 271   | 8 271   | 8 271   | 8 523   | 8 523   | 8 523   | 8 523   | 8 523   |
| Fiji          | 138     | 138     | 138     | 138     | 138     | 138     | 138     | 138     | 138     | 138     |
| Fr Polynesia  | 47      | 47      | 47      | 47      | 48      | 48      | 48      | 48      | 48      | 48      |
| Micronesia    |         | 1       | 1       | 1       | 1       | 1       | 1       | 1       | 1       | 1       |
| New Caledon   | 78      | 78      | 78      | 78      | 78      | 78      | 78      | 81      | 81      | 81      |
| New Zealand   | 5 427   | 5 426   | 5 426   | 5 426   | 5 426   | 5 426   | 5 434   | 5 434   | 5 434   | 5 434   |
| Papua N Guin  | 240     | 240     | 258     | 258     | 258     | 258     | 258     | 258     | 258     | 261     |
| Samoa         | 9       | 9       | 9       | 9       | 12      | 13      | 14      | 14      | 14      | 14      |
| Solomon Is    | 0       | 0       | 0       | 0       | 0       | 0       | 0       | 0       | 0       | 0       |
| Vanuatu       | 1       | 1       | 1       | 1       | 1       | 1       | 1       | 1       | 1       | 1       |
| S America     | 144 931 | 149 575 | 153 663 | 164 056 | 167 722 | 172 737 | 177 744 | 178 112 | 178 358 | 179 934 |
| Argentina     | 11 110  | 11 112  | 11 182  | 11 244  | 11 247  | 11 292  | 11 314  | 11 348  | 11 350  | 11 359  |
| Bolivia       | 501     | 494     | 495     | 495     | 620     | 666     | 736     | 736     | 736     | 736     |
| Brazil        | 86 019  | 89 194  | 91 651  | 96 930  | 100 333 | 104 482 | 109 143 | 109 318 | 109 426 | 109 814 |
| Chile         | 6 095   | 6 446   | 6 500   | 6 672   | 6 685   | 6 680   | 6 683   | 6 773   | 6 807   | 7 289   |
| Colombia      | 9 868   | 10 900  | 11 501  | 11 611  | 11 731  | 11 842  | 11 926  | 11 954  | 11 958  | 12 563  |
| Ecuador       | 2 264   | 2 248   | 2 408   | 4 447   | 4 516   | 5 066   | 5 076   | 5 098   | 5 099   | 5 191   |
| Fr Guiana     | 119     | 119     | 119     | 119     | 119     | 119     | 119     | 119     | 119     | 119     |
| Guyana        | 2       | 2       | 2       | 2       | 2       | 2       | 2       | 2       | 2       | 2       |
| Paraguay      | 8 810   | 8 810   | 8 810   | 8 810   | 8 810   | 8 810   | 8 810   | 8 810   | 8 810   | 8 810   |
| Peru          | 3 544   | 3 651   | 4 139   | 5 179   | 5 112   | 5 230   | 5 387   | 5 406   | 5 503   | 5 503   |
| South Georgia | 0       | 0       | 0       | 0       | 0       | 0       | 0       | 0       | 0       | 0       |
| Suriname      | 180     | 180     | 180     | 180     | 180     | 180     | 180     | 180     | 180     | 180     |
| Uruguay       | 1 538   | 1 538   | 1 538   | 1 538   | 1 538   | 1 538   | 1 538   | 1 538   | 1 538   | 1 538   |
| Venezuela     | 14 881  | 14 881  | 15 138  | 16 829  | 16 829  | 16 829  | 16 829  | 16 829  | 16 829  | 16 829  |

## Renewable hydropower (including mixed plants) Hydroélectricité renouvelable (y compris les centrales mixtes) Hidroeléctrica renovable (incluidas las plantas mixtas)

| CAP (MW)                         | 2013                | 2014                | 2015                | 2016                | 2017                        | 2018                          | 2019                  | 2020 2021             | 2022                |
|----------------------------------|---------------------|---------------------|---------------------|---------------------|-----------------------------|-------------------------------|-----------------------|-----------------------|---------------------|
| World                            | 029 562             | 066 193             | 098 429             | 129 001             | 1 151 109 1                 | 173 386 1 191 478             | 1 212 899             | 1 235 010             | 255 540             |
| Africa                           | 26 791              | 26 815              | 27 343              | 28 268              | 31 025 32 389               | 33 094                        | 33 915                | 34 396                | 35 655              |
| Algeria                          | 228                 | 228                 | 228                 | 228                 | 228 e 228                   | e 228 e                       | 209 o                 | 129 e                 | 129 e               |
| Angola                           | 953 u 1             | 969 u 1             | 969 e               | 1 700 u 1           | 2 393 u 3 061 e 1 1         | 3 395 e                       | 3 729 e 1 e           | 3 729 e 1 e           | 3 729 e             |
| Benin Burkina Faso               | 32 o                | 32 o                | 1 32 o              | 32 o                | 32 o 32                     | 1 e e 35 e                    | 35 e                  | 35 e                  | 1 e 35 e            |
| Burundi Cameroon                 | 51 o 733 o          | 51 o e              | 51 o 733            | 51 o 733            | 48 e 48 732 e               | e 48 e e 812 e                | 48 e 812 e            | 48 e 812 e            | 63 e                |
| Cent Afr Rep                     | 19 e                | 733 19 e            | e 19 e              | e 19 e              | 732 19 e 19                 | e 19 e                        | 19 e                  | 19 e                  | 812 e 19 e          |
| Comoros                          | 1 e                 | 1 e                 | 1 e                 | 1 e                 | 1 e 1                       | e 1 e                         | 1 e                   | 1 e                   | 1 e                 |
| Congo DR                         | 2 515 e             | 2 515 e             | 2 528 e             | 2 540 e             | 2 551 e 709 214             | u 2 719                       | 2 719 e               | 2 719 e               | 2 719 e             |
| Congo Rep                        | 194 e               | 194 e               | 194 e               | 201 u               | 2 u 214                     | e u 214 e                     | 214 e                 | 214 e                 | 214 e               |
| Cote d Ivoire Egypt              | 604 o 2 o           | 604 o 2 o           | 604 o 2             | 604 o 2             | 879 u 879 800               | e 879 e                       | 879 e 2               | 879 e                 | 879 o               |
|                                  | 800                 | 800                 | 800 o               | 800 o               | 2 o e                       | o 2 832 o                     | 832 e                 | 2 832 e               | 2 832 e             |
| Eq Guinea                        | 126 o               | 126 o               | 126 o               | 126 o               | 2 832 126 127               | o 127 e e                     | 127 e                 | 127 e                 | 127 e               |
| Eswatini Ethiopia                | 62                  | 62                  | 62                  | 62 e                | 62 e 62 3 817               | e 62                          | 62 e 4 071            | 62 e                  | 62 e                |
| Gabon                            | 1 972 e             | 1 972 e             | 2 159 e             | 2 159               | 3 817 330                   | e 3 817 e 330 e               | 330 e                 | 4 071                 | 4 821 e             |
|                                  | 330 e               | 330 e               | 330 e               | 330 e               |                             | e                             |                       | 330 e                 | 330 e               |
| Ghana                            | 1 580 o             | 1 580 o 129 o       | 1 584 o             | 1 584 o             | 330 e 1 584 o 1 584 369 e   | e 1 584 e                     | 1 584 o               | 1 584 e               | 1 584 o 814 e       |
| Guinea                           | 129 o 822           |                     | 369 o               | 369 o               | 369 846                     | e 364 e                       | 589 e                 | 814 e                 |                     |
| Kenya Lesotho                    | e                   | 822 e 75            | 828 e               | 832 e               | 843 e 75                    | e 851 e e e                   | 858 e                 | 860 e                 | 868 e 75 e          |
| Liberia                          | 75 4 e              | 4 e                 | 75 e 4 e            | 75 e 26 e           | 75 e 92 e 92                | 75 e 92 e                     | 75 e 92 e             | 75 e 92 e             | 92 e                |
| Madagascar                       | 162 o               | 163 o               | 164 o               | 164 o               | e 164                       | e 164 e                       | 164 e                 | 164 e                 | 164 e               |
| Malawi                           | 372 e               | 372 e               | 372 e               | 373 e               | 164 373 e 373               | e 373 e                       | 373 e                 | 392 e                 | 392 e               |
| Mali                             | 315 e               | 315 e               | 315 e               | 315 e               | 315 e 315 60                | e 315 e                       | 315 e                 | 315 e                 | 315 e               |
| Mauritius                        | 61                  | 61                  | 61                  | 60 o                | o 60                        | o 60 o                        | 61 o                  | 61 o                  | 61 e                |
| Morocco                          | 1 306               | 1 306 2 190 e       | 1 306 2 190 e       | 1 306 e             | 1 306 1 306 2 190 e         | 1 306 e e e                   | 1 306 e               | 1 306 e 2 194         | 1 306 o 2 194 o     |
| Mozambique                       | 2 190 e 330         | 330                 | 330                 | 2 190 347           | 2 190 347                   | 2 190 347                     | 2 190 e               | o 351 e               | 351 e               |
| Namibia Nigeria                  | 2 110 o             |                     |                     |                     | 347 o 2 111 o               | o 2 111                       | 351 u                 |                       | 2 111 e             |
| Reunion Rwanda                   | 134 o               | 2 110 o 134 o       | 2 111 o 134 o       | 2 111 o 133 o       | 2 111 o 133 133 o 99 e      | e 133 o                       | 2 111 e 133 o         | 2 111 e 134 o         | 134 e 125 e         |
| Sao Tome                         | 60 o 2 o            | 66 o o              | 94 o                | 98 o                | o 99 e 2 2                  | 110 e e 2 e                   | 120 e 2 e             | 120 e                 | 2 e                 |
| Prn Sierra Leone                 | 54 e                | 2 56 e              | 2 o 56              | 2 e 56              | e 61 e 61                   | e 61 e                        | 61 e                  | 2 e 61 e              | 61 e                |
| South Africa                     | 735 e 1             | 733                 | e 748               | e 748               | 748 748                     | e 748 e                       | 748 e                 | 752 e                 | 752 e               |
| Sudan                            | 322 o               | e 1 322             | e 322               | e 1 322             | e 1 322 o e                 | o 1 482 o                     | 1 482 o               | 1 482 e               | 1 482 e e           |
| Tanzania                         | 571 e               | o 571 e             | 1 o 576 e           | o 582 e             | 1 482 583 67                | e 589 e 67 e                  | 589 e                 | 589 e 67              | 589 67 e            |
| Togo Tunisia                     | 67 o 62 o           | 67 o 62             | 67 o 62             | 67 o 62             | 583 67 o o 66               | o o 66                        | 67 e 66 o             | e 66 o                | 66 e                |
| Uganda                           | 692 e 2 260 o       | o 692               | o 695               | o 695               | 62 e 744                    | o e 1 004 e 2 399 e           | 1 011 e               | 1 011 o 2 705 e       | 1 032 e 3 164 e     |
| Zambia                           |                     | e 2 260 o           | e 2 268             | e 2 388 o           | 707 398 o 2 398             | o                             | 2 400 e               |                       |                     |
|                                  | 758                 |                     | o 773 e             | 777 e               | 2 781 e 1 081               | e 1 081 e                     |                       | 1 081 e               | 1 081 e             |
| Zimbabwe                         |                     | 758                 |                     |                     | 466                         | 489 064                       | 1 081 e 504           |                       |                     |
| Asia Afghanistan                 | 395 214 277 e       | 422 420             | 441 772             | 454 274 329 e       | 570 478 954 349 e 349       | e 349 e                       | 641 349 e             | 522 807 357 u         | 538 693 459 u       |
| Bangladesh Bhutan                | 230 o 1 488 o 683 o | 280 e 230 o 1 488 o | 284 e 230 o 1 614 o | 230 o 1 614 o 930 o | 230 o 230 1 614 o 980 o     | e 230 o 2 334 1 330 327 750 o | 230 o 2 334 e 1 330 o | 230 o 2 334 o 1 330 o | 230 o 2 334 e 1 332 |
| Cambodia                         |                     | 929 o               | 930 o               |                     |                             | u o                           |                       |                       |                     |
| China                            | 258 908             | 282 750             | 296 500             | 305 380             | 314 385                     | 1 614 o 1 330 o 322 271 1     | 339 960 o             | 354 530 o             | o 367 710 o         |
| China HK SAR                     | 2 081 o             | 1 2 081 o           | 1 2 089 o           | 1 2 089 o           | 1 2 089 o e                 | 1 2 093 45 494                | 1 2 093 o             | 1 2 094 o 46 779 e    | 1 e 2 094           |
| Chinese Taipei India             | 39 388 e 5 177 e    | 40 621 e e          | 42 319 e            | 42 836 e            | 2 092 o 44 45 316 e 5 773 o | o o 5 976 o                   | 45 979 e 6 141 o      | 6 602 o               | o 47 217 e 6 689 o  |
| Indonesia Japan                  | 27 813              | 5 242               | 5 322 e             | 5 666 e 28 193      | 735 5 703 e 120 e 726       | 28 139                        | 28 147 o              | 28 125 o 2 807        | 28 211              |
| Kazakhstan                       | 2 588 o             | 27 873 2 675 o      | 28 111 2 678        | 2 696               | 28 28 2                     | e o u 2 778 e                 | 2 785                 |                       | o 2 807             |
| Korea DPR                        | 4 283 o 1 752       | 4 293               | 4 467 o             | 4 701 o             | 143 2 756 4 4 790 1 790     | o 4 790 o 1 809               | 4 865 o 1 806 o       | 4 865 o               | 4 865 e             |
| Korea Rep Kyrgyzstan             | 3 572               | 1 767 3 671         | 1 771 3 677         | 1 785 3 677         | 761 o 1 789 689             | 3 673                         | 3 674                 | 1 841 o 3 674         | 1 812 3 674         |
| Lao PDR                          | 2 928 u             | 3 212               | 4 313               | 4 889 u             | 3 3 673 u                   | o e 6 241 e 6 185             | 8 025 e               | 8 793 e               | o 9 483             |
| Malaysia                         | 4 535 e             | 4 761               | 5 742               | 6 121 e             | 5 136 414 145 e             | u 31                          | 6 197 e               | 6 211 e               | 6 211               |
| Mongolia                         | 29 e                | u 29                | u 29                | 31 e                | 6 165 31 e 304              | e e e                         | 29                    | 29                    | e 29                |
| Myanmar                          | 2 812 e             | e 2 985             | e e 3 198 e         |                     | 5 6 e 3                     | o 3 304                       | 3 304 e               | 3 304 e               | e 3 304             |
| Nepal                            | 744 o               | e e 759             | 814                 | 3 264 e 834 o       | 31 3 304 1 059 9 904        | e e 1 180 e                   | 1 302 e               | 1 992 e               | 2 219               |
| Pakistan                         | 7 089 e             | o 7 220 e           | o 7 220 e           | 7 252 e             | o e                         | e 9 921 e o                   | 10 043 e              | 043 e                 | e e 833 e           |
|                                  | 2 843 o             | 2 858               | 2 877 o             | 2 887 o             | 939 7 o e                   | e 3 025                       | 3 044 o               | 10 3 047 e            | 3 037 1 846 e       |
| Philippines Sri Lanka            | 1 622 e             | o 1 670             | 1 689 e             | 1 728 e             | 404 2 896 983 1 747         | o 1 5 273                     | 1 5                   | 1 799 e               | 10 o                |
| Tajikistan                       | 4 814 3 015 o       | e 5 035 3 048 o     | 5 033 o 3 079 o     | 5 039 3 089 o       | 2 1 5 5 o 3                 | 815 e e 3 107 o               | 799 e 273 3 109 o     | 5 274 e               | 5 274 3 110 e       |
| Thailand                         |                     |                     | 0 e                 | 0 e                 | 3 e                         | 798 e 153 e 107 o 0 e         | 0 e                   | 3 110 e 0 e           | 0 e                 |
| Timor Leste                      | 0 o                 | 0 e                 |                     |                     | 039 0                       |                               | 0 e                   |                       | 2                   |
|                                  | 1                   | 1                   | 1                   | 1                   | 089 1                       | 1 e                           | 1                     | 2 e                   |                     |
|                                  |                     | 1 871               | 1 880               | 1 880               | 1 858                       | 1 908                         | 2 005                 | 2 052                 | 052                 |
| Turkmenistan Uzbekistan Viet Nam | 1 822 14 718 e      | 069 e               | 15 905 e            | 17 131 e            | 1 1 915 17 809 e 17         | o e 20 326 e                  | 20 817 e              | 21 582 e              | 2 857 e             |
| C America + Carib                | 6 338               | 15                  |                     | 7 650               | 989 8 073                   | 8 146                         |                       |                       | 21 8 265            |
|                                  |                     | 6 561               | 6 833               |                     | 7 886                       |                               | 8 271                 | 8 310                 |                     |
| Belize Costa Rica                | 38 u                |                     |                     | 38 u 2              | 2                           | 57                            | 57 2 332              | 57                    | 57 2 331            |
|                                  | 1 762               | 38 u 1 782          | 38 u 1 811          | 256                 | 38 u 350 66                 | u 2 343                       | u o                   | u 2 379               | u                   |
| Cuba                             | 63                  | 63                  | 63                  |                     | 57 u 2 373 o 64             | o 72 o                        | 72 u                  | o 72                  | o 72                |
|                                  |                     | o                   |                     | 66                  |                             | o                             |                       |                       | e 7 e               |
|                                  | 7                   |                     | 7 o                 |                     |                             | 7                             | 7 o                   | 7 o                   |                     |
| Dominica                         |                     | 7                   |                     |                     | o 7 o                       |                               |                       |                       |                     |
|                                  | o                   |                     |                     | 7 o                 | o                           |                               |                       |                       |                     |
|                                  |                     |                     |                     |                     | 7                           |                               |                       |                       |                     |

## Renewable hydropower (including mixed plants) Hydroélectricité renouvelable (y compris les centrales mixtes) Hidroeléctrica renovable (incluidas las plantas mixtas)

| CAP (MW)                    | 2013          | 2014          | 2015          | 2016            | 2017              | 2018             | 2019             | 2020                | 2021              | 2022            |
|-----------------------------|---------------|---------------|---------------|-----------------|-------------------|------------------|------------------|---------------------|-------------------|-----------------|
| Dominican Rep               | 614 o         | o             |               |                 | 617 o             |                  | 618              |                     | 625               | 627 e           |
| El Salvador                 | 487 e         | 617 488 e     | 617 o 494 e   | 617 o 494 e     | 574 e             | 617 e 574 e      | e 573 o          | 625 o 573 e         | e 572 e           | 572 e           |
| Guadeloupe                  | 9             | 9             | 9             | 9               | 11                | 11 e             | 11 o             | 11 e                | 11 e              | 11 e 1          |
| Guatemala Haiti             | 997 56 e      | 1 001 56 e    | 1 087 56 e    | 1 392 o 56      | 1 438 o 56 e      | 1 502 o 78 u     | 1 574 o 78 e     | 1 577 o 78 e        | 1 579 o 78 e      | 581 o 78 e      |
| Honduras                    | 558 o         | 624 o         | 656 o         | e 670 e         | 676 e             | 714 e            | 729 e            | 837 e               | 849 e             | 849 e           |
| Jamaica                     | 30            | 30            | 30            | 30              | 30                | 30 e             | 30 e             | 30 e                | 30 e              | 30 e            |
| Nicaragua Panama            | 120 1         | 120           | 138           | 142 o 1         | 142 o 1 o         | 142 o 1          | 157 o 1 792      | 157 o 1 811         | 159 o 1           | 159 e           |
| Puerto Rico                 | 494 98 o      | 1 623 98 o    | 1 725 98 o    | 769 98 o        | 777 98 o          | 801 98 o         | 98 o             | 98 o                | 789 98 o          | 1 789 98 o      |
| St Vincent Gren             | 6             | 6             | 6             | 6               | 6                 | 6 e              | 6 e              | 6 u                 | 6 u               | 6 e             |
|                             |               |               |               |                 | 82 915            |                  | 646              | 87 595              |                   |                 |
| Eurasia                     | 76 707        | 78 515        | 80 895        | 81 778          |                   | 84 032           | 84               |                     | 88 351            | 88 563          |
| Armenia                     | 1 289 o 1 084 | 1 298 o 1 078 | 1 287 o 1 103 | 1 312 o         | 1 327 1           | 1 336 o          | 1 336 e          | 1 336 e 1 149 o     | 1 336 e           | 1 336           |
| Azerbaijan                  |               |               |               | 1 105           | 106 u             | 1 131 o          | 1 145            |                     | 1 157             | 1 177           |
| Georgia Russian Fed         | 2 705 49 340  | 2 380 50 116  | 2 378 50 259  | 2 430 50 250    | 2 723 50 486      | 2 695 50 579     | 2 583 51 079     | 2 727 51 398        | 2 967 51 398      | 3 080 51 398    |
| Türkiye                     | 22 289        | 23 643        | 25 868        | 26 681          | 27 273 o          | 28 291           | 28 503           | 30 984              | 31 493            | 31 572          |
| Europe                      | 183 396       |               |               |                 |                   | 192              | 193 176          | 700                 | 809               | 196 590         |
|                             |               | 183 677       | 186 049       | 189 296         | 191 108           | 249              |                  | 194                 | 195               |                 |
| Albania                     | 1 781         | 1 725         | 1 798         | 1 913           | 2 047             | 2 105            | 2 162            | 2 387               | 2 507             | 2 507           |
| Andorra                     | 46 o          | 46 o          | 46 o          | 46 o            | 46 o              | 46 o             | 46 o             | 46 e                | 46 e              | 46              |
| Austria                     | 13 383        | 13 532        | 13            | 14 116          | 14 150            | 14 516           | 14 597           | 14 635              | 14 748            | 14 969          |
| Belarus                     | 32            | 33            | 650 34        | 74              | 95                | 95 o             | 95 e             | 96                  | 96 e              | 96              |
| Belgium                     | 119           | 121           | 112 o         | 109             | 107               | 108              | 104              | 106                 | 111               | 112             |
| Bosnia Herzg Bulgaria       | 1 702 o 2 339 | 1 711 o 2 355 | 1 717         | 1 760 o 2 359   | 1 791 2           | 1 816 2 515 o    | 1 819 2 514 e    | 1 829 2 512 o       | 1 837 2 505 o     | 1 837 2 505     |
| Croatia                     | 2 178         | 2 180         | 2 355 2 195   | 2 192           | 508 e 2 193       | 200              | 2 200 o          | 2 200 o             | 2 201 o           | 2 201           |
| Czechia                     | 1 080         | 1             | 1             | 1               | 1                 | 2 1 093          | 1                | 1                   |                   | 1 114           |
| Denmark                     | 9             | 080 9         | 088 7         | 090 9           | 093 7             | 7                | 094 7            | 094 7               | 1 113 7           | 5               |
| Estonia                     | 8             | 5             | 6             | 6               | 7                 | 7 e              | 6 o              | 8                   | 6                 | 10              |
| Faroe Islands               | 39 o          | 39 o          | 39 o          | 39 o            | 39 o              | 40 o             | 40               | 40 e                | 40 e              | 40              |
| Finland                     | 3 108 23 838  | 3 132         | 3 133         | 3 133           | 3 156             | 3 152            | 3 157            | 3 164               | 3 171 24 564      | 3 171 24 564    |
| France Germany              | 5 589         | 23 849        | 23 824        | 23 893          | 23 979 5          | 23 999 5 329     | 24 141 5 378     | 24 227 5 454        | 5                 | 5 583           |
| Greece                      | 3 238         | 5 580 3 389   | 5 589 3 392   | 5 629 3 392     | 627 3 392 e       | 3 409 o          | 3 412            | 3 417 o             | 490 3 421 o       | 3 423           |
| Hungary                     | 57            | 57            | 57            | 57              | 57 e              | 57 o             | 58               | 58 o                | 60                | 60              |
| Iceland                     | 1 984         | 1 984         | 987           | 1 987           | 1 995             | 2 099            | 2 104            | 2 114               | 2 114 e           | 2 114           |
| Ireland                     | 237 052       | 237           | 1 237         | 237             | 237 e             | 237 o            | 237 18 601       | 237 18              | 237 809           | 237 840         |
| Italy                       | 18 43         | 18 116        | 18 238        | 18 316          | 18 486            | 18 558 o 80      | 95               | 755 110             | 18 110            | 18 110          |
| Kosovo* Latvia              | 1 587         | 43 1 588      | 43 1 588      | 78 1 564        | 80 1 564          | 1 565            | 1 587            | 1 586               | 1 587             | 1 608 117       |
| Lithuania                   | 116 34        | 117           | 117           | 117             | 117 e 35          | 117 o            | 117 o 34         | 117 o 35            | 117               | 32              |
| Luxembourg Moldova Rep      | 64            | 34 64         | 34 64         | 34 64           | 64 o              | 34 64 o          | e 64 e           | 64                  | 35 o 64 e         | 64              |
|                             | 630           | 653           | 662           | 668             | 675               | 676              | 676              | 697                 | 697 o             | 697             |
| Montenegro                  | 37            | 37            | 37            | 37              | e                 | 37 e             | 37 o             | 37 o                | 37                | 36              |
| Netherlands North Macedonia | 617 033       | 630           | 658 31        | 661 31          | 37 671            | 674              | 678 797 o        | 687 33 732          | 689 34 075        | 689 34 118      |
| Norway Poland               | 31 949        | 31 240        | 372           | 817             | 31 912            | 32 530 968       | 32 974           | 977 e               | 975               | 978             |
| Portugal                    | 5 661 6 518   | 958 5 715     | 964 6 168     | 972 6 960       | 967 226           | 7 236            | e 7 262 6 595    | 7 241 6 561         | 7 255 o           | 7 592           |
| Romania                     |               | 6 521         | 6 638 2 408   | 6 642           | 7 6 600           | 6 609            |                  |                     | 6 571 2 471 e     | 6 570           |
| Serbia Slovakia             | 2 317         | 2 403 1 607   | 1 606         | 2 416 1         | 2 424 607         | 2 429 1 612      | 2 460 1 611      | 2 468 e 1 613       | 1 615             | 2 483 1 615     |
| Slovenia                    | 1 607 1 119   | 1 116         | 1 115         | 608 1           | 1 1 167           | 1 163            | 1 171            | 1 172               | 1 172             | 1 174           |
| Spain                       | 15 854        | 892           | 722           | 113 16          | 748               | 748              | 782              | 16 785              | 16 801            | 16 801          |
| Sweden                      | 16 395 13 361 | 15 15 897     | 16 230 346    | 749 16 367      | 16 502            | 16 16 431        | 16 16 462 15 012 | 406 e               | 16 407 e 15 032 o | 16 407          |
| Switzerland UK              | 2 009         | 13 288        | 16            | 14 279 2 133    | 16 e 14 826 2 170 | 14 980 o 2 173   | e 2 173 o        | 16 15 032 o 2 176 o | 2 194 o           | 15 048 2 195    |
|                             |               | 2 030         | 13 2 077      |                 | e                 |                  | 4 816            | 4 819               |                   |                 |
| Ukraine                     | 4 627         | 4 665         | 4 697         | 4 658           | 4 704             | 4 734            |                  |                     | 4 823 u           | 4 823 e         |
|                             | 373           |               |               |                 |                   |                  | 401              |                     |                   |                 |
| European Union              | 123           | 123 385       | 125 363       | 126 963         | 831               | 127 972          | 128              | 128 665             | 129 278           | 129 987         |
| Middle East                 | 13 690        | 14 854        | 14 389        |                 | 127 14 265        | 14 411           | 14 494           | 14 504              | 14 502            | 14 502          |
| Iran IR                     | 10 265        | 10 785        | 10 238 e      | 14 611 10 538 e | 10 913 e          |                  | 11 142           | 11 153 1 557        | 11 153 e 1 557    | 11 153 1 557    |
| Iraq                        | 2 274 e 7 e   | 2 274 e 7     | 2 274 7       | 2 274 e 7 e     | 1 557 e 7 e       | 11 059 e 1 557 e | e 1 557 e        | e e 6               | e 6               | e 6             |
| Israel Jordan               | 12 o          | o 12 o        | e e           |                 |                   | 7 e              | 7 e              | o                   | e                 | e e 14          |
|                             | 282 e         | 282 e         | 16 u 282 e    | 16 u 282 e      | 16 u 282 e        | 16 u             | 16 u 282 e       | 16 e 282 e          | 14 e 282 e        | e 282 e         |
| Lebanon Syrian AR           | 850 o         | 1 494 o       | 1 572 o       | 1 494 o         | 1 490 o           | 282 e 1 490 o    | 1 490 e          | 1 490 e 178 446     | 1 490 e 179 763   | 1 490 e 180 621 |
| N America                   | 170 068       | 171 350       | 175 041       | 176 622         | 177 169           | 177 839 81 222   | 178 403 81 222   | 81 227 u 91 e       | 82 563 91         | 83 376 91       |
| Canada Greenland            | 75 337 91     | 75 300 91     | o             | 80 130 91 o     | 80 657 91 o       | 91               | 91               |                     | u                 | e               |
|                             |               | o             | 79 231 91     |                 | 12 628            |                  |                  |                     |                   |                 |
| Mexico                      | o 11 633      | 12 464        | 223           | 12 580          |                   | e 12 643         | o 13 301         | 13 301              | e 13 303 o        | e 13 303        |
|                             | 007           | 83 494 o      | 12 83 495 o   | o               |                   | 83 883 o         | 83 789           | 83 827 o            |                   | e 83 851 o      |
|                             | o             |               |               | 83 821          | 83 792 o          |                  | o                |                     | o                 |                 |
| USA                         | 83            |               |               |                 |                   |                  |                  |                     | 83 806            |                 |

## Renewable hydropower (including mixed plants) Hydroélectricité renouvelable (y compris les centrales mixtes) Hidroeléctrica renovable (incluidas las plantas mixtas)

| CAP (MW)      | 2013     | 2014     | 2015     | 2016     | 2017      | 2018      | 2019      | 2020      | 2021      | 2022      |
|---------------|----------|----------|----------|----------|-----------|-----------|-----------|-----------|-----------|-----------|
| Oceania       | 13 401   | 13 401   | 13 419   | 13 420   | 13 424    | 13 676    | 13 686    | 13 689    | 13 689    | 13 692    |
| Australia     | 7 461    | 7 461    | 7 461    | 7 461    | 7 461     | 7 713 o   | 7 713 o   | 7 713 o   | 7 713 o   | 7 713 e   |
| Fiji          | 138 u    | 138 u    | 138 u    | 138 u    | 138 u     | 138 u     | 138 e     | 138 e     | 138 e     | 138 e     |
| Micronesia    |          | 1 o      | 1 o      | 1 o      | 1 o       | 1 o       | 1 o       | 1 o       | 1 e       | 1 e       |
| New Caledon   | 78 o     | 78 o     | 78 o     | 78 o     | 78 o      | 78 o      | 78 e      | 81 o      | 81 e      | 81 e      |
| New Zealand   | 5 427    | 5 426    | 5 426    | 5 426    | 5 426     | 5 426     | 5 434     | 5 434     | 5 434 o   | 5 434 e   |
| Papua N Guin  | 240 u    | 240 e    | 258 e    | 258 e    | 258 e     | 258 e     | 258 e     | 258 e     | 258 e     | 261 e     |
| Samoa         | 9 o      | 9 o      | 9 o      | 9 o      | 12 o      | 13 e      | 14 u      | 14 e      | 14 e      | 14 e      |
| Solomon Is    | 0 o      | 0 o      | 0 o      | 0 o      | 0 o       | 0 o       | 0 e       | 0 e       | 0 e       | 0 e       |
| Vanuatu       | 1 o      | 1 e      | 1 e      | 1 e      | 1 e       | 1 e       | 1 e       | 1 e       | 1 e       | 1 e       |
| S America     | 143 957  | 148 601  | 152 689  | 163 082  | 166 748   | 171 763   | 176 770   | 177 138   | 177 384   | 178 960   |
| Argentina     | 10 136 o | 10 138 o | 10 208 o | 10 270 o | 10 273 e  | 10 318 e  | 10 340 e  | 10 374 e  | 10 376 e  | 10 385    |
| Bolivia       | 501 o    | 494 o    | 495 o    | 495 o    | 620 o     | 666 e     | 736 o     | 736 e     | 736 e     | 736 e     |
| Brazil        | 86 019   | 89 194 o | 91 651 o | 96 930 o | 100 333 o | 104 482 o | 109 143 o | 109 318 o | 109 426 o | 109 814 o |
| Chile         | 6 095 o  | 6 446 o  | 6 500 o  | 6 672 o  | 6 685 e   | 6 680 o   | 6 683 o   | 6 773 o   | 6 807 o   | 7 289 o   |
| Colombia      | 9 868    | 10 900   | 11 501 e | 11 611 e | 11 731 o  | 11 842 o  | 11 926 e  | 11 954 e  | 11 958 o  | 12 563 e  |
| Ecuador       | 2 264 o  | 2 248 o  | 2 408 o  | 4 447 o  | 4 516 e   | 5 066 o   | 5 076 o   | 5 098 o   | 5 099 o   | 5 191     |
| Fr Guiana     | 119 o    | 119 o    | 119 o    | 119 o    | 119 o     | 119 o     | 119 o     | 119 e     | 119 o     | 119       |
| Guyana        | 2 e      | 2 e      | 2 o      | 2 e      | 2 e       | 2 e       | 2 o       | 2 e       | 2 e       | 2 e       |
| Paraguay      | 8 810    | 8 810    | 8 810    | 8 810    | 8 810     | 8 810 o   | 8 810     | 8 810 o   | 8 810 e   | 8 810 e   |
| Peru          | 3 544 o  | 3 651 o  | 4 139 o  | 5 179 o  | 5 112 o   | 5 230 o   | 5 387 o   | 5 406 o   | 5 503 o   | 5 503 o   |
| South Georgia | 0        | 0        | 0        | 0        | 0         | 0         | 0         | 0 e       | 0 e       | 0 e       |
| Suriname      | 180      | 180      | 180      | 180      | 180 e     | 180 e     | 180 e     | 180 e     | 180 e     | 180 e     |
| Uruguay       | 1 538    | 1 538    | 1 538    | 1 538    | 1 538     | 1 538 o   | 1 538 e   | 1 538 o   | 1 538 e   | 1 538 o   |
| Venezuela     | 14 881 o | 14 881 u | 15 138 u | 16 829 e | 16 829 e  | 16 829 e  | 16 829 e  | 16 829 e  | 16 829 e  | 16 829 e  |

## Pure pumped storage Accumulation par pompage

## Hidroeléctrica de bombeo pura

| CAP (MW)                   | 2013       | 2014       | 2015         | 2016         | 2017         | 2018         | 2019         | 2020         | 2021         | 2022         |
|----------------------------|------------|------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|--------------|
| World                      | 107 729    | 109 471    | 111 902      | 116 934      | 119 841      | 120 357      | 120 606      | 121 179      | 127 705      | 137 058      |
| Africa                     | 1 864      | 1 864      | 1 864        | 2 863        | 3 196        | 3 196        | 3 196        | 3 196        | 3 196        | 3 196        |
| Morocco                    | 464        | 464        | 464          | 464          | 464 o        | 464          | 464 e        | 464 e        | 464 e        | 464 o        |
| South Africa               | 1 400 u    | 1 400 u    | 1 400 u      | 2 399 u      | 2 732 u      | 2 732 e      | 2 732 e      | 2 732 e      | 2 732 u      | 2 732 e      |
| Asia                       | 56 035     | 57 218     | 58 338       | 61 998       | 64 668       | 65 268       | 65 568       | 65 598       | 71 668       | 80 988       |
| China                      | 21 533     | 22 110     | 23 030       | 26 690       | 29 390 e     | 29 990       | 30 290       | 30 320 u     | 36 390 o     | 45 790 o     |
| Chinese Taipei             | 2 602 o    | 2 602 o    | 2 602 o      | 2 602 o      | 2 602 o      | 2 602 o      | 2 602 o      | 2 602 o      | 2 602 o      | 2 602 o      |
| India                      | 4 786 o    | 4 786 o    | 4 786 o      | 4 786 o      | 4 786 o      | 4 786 e      | 4 786 o      | 4 786 e      | 4 786 e      | 4 786 e      |
| Japan                      | 21 119     | 21 724     | 21 924       | 21 924       | 21 894       | 21 894 e     | 21 894 o     | 21 894 o     | 21 894 o     | 21 814 o     |
| Korea Rep                  | 4 700      | 4 700      | 4 700        | 4 700        | 4 700 o      | 4 700 o      | 4 700 o      | 4 700 o      | 4 700 o      | 4 700 o      |
| Mongolia                   | 0          | 0          | 0            | 0            | 0            | 0            | 0 e          | 0            | 0            | 0            |
| Philippines                | 736 o      | 736 o      | 736 o        | 736 o        | 736 o        | 736 o        | 736 o        | 736 o        | 736 e        | 736 o        |
| Thailand                   | 560 o      | 560 o      | 560 o        | 560 o        | 560 o        | 560 o        | 560 o        | 560 o        | 560 e        | 560 e        |
| Eurasia                    | 1 216      | 1 216      | 1 216        | 1 216        | 1 216        | 1 216        | 1 216        | 1 216        | 1 356        | 1 356        |
| Russian Fed                | 1 216      | 1 216      | 1 216        | 1 216        | 1 216        | 1 216        | 1 216        | 1 216        | 1 356 e      | 1 356        |
| Europe                     | 27 730     | 28 199     | 28 380       | 28 592       | 28 464       | 28 360       | 28 360       | 28 365       | 28 689       | 28 689       |
| Belgium                    | 1 307      | 1 307      | 1 307        | 1 307        | 1 307        | 1 307        | 1 307        | 1 307        | 1 307        | 1 307        |
| Bosnia Herzg               | 420 o      | 420 o      | 420          | 420 o        | 420 o        | 420 e        | 420 o        | 420 o        | 420 o        | 420          |
| Bulgaria                   | 864        | 864        | o 864        | 864          | 864 e        | 864 o        | 864 e        | 864 o        | 864 o        | 864          |
| Czechia                    | 1 172      | 1 172      | 1 172        | 1 172        | 1 172        | 1 172        | 1 172        | 1 172 o      | 1 172 o      | 1 172        |
| France                     | 1 808      | 1 728      | 1 728        | 1 728        | 1 728        | 1 728 o      | 1 728        | 1 728        | 1 728 o      | 1 728        |
| Germany                    | 5 650      | 5 654      | 5 666        | 5 578        | 5 493        | 5 355        | 5 355        | 5 354        | 5 354        | 5 354        |
| Ireland                    | 292        | 292        | 292          | 292          | 292 e        | 292 o        | 292          | 292 o        | 292 e        | 292          |
| Italy                      | 3 957      | 3 982      | 3 982        | 3 982        | 3 940        | 3 940 o      | 3 940        | 3 940 e      | 3 940 e      | 3 940        |
| Lithuania                  | 760        | 760        | 760          | 760          | 760 e        | 760 o        | 760 o        | 760 o        | 760 o        | 760          |
| Luxembourg                 | 1 100      | 1 296      | 1 296        | 1 296        | 1 296 e      | 1 296 e      | 1 296 e      | 1 296 o      | 1 296 o      | 1 296        |
| Poland                     | 1 406      | 1 406      | 1 406        | 1 413        | 1 423        | 1 423        | 1 423 e      | 1 423 e      | 1 423        | 1 423        |
| Romania                    | 92         | 92         | 92           | 92           | 92           | 92           | 92 e         | 92 o         | 92 e         | 92           |
| Serbia                     | 614        | 614        | 614          | 614          | 614          | 614 o        | 614 e        | 614 e        | 614 e        | 614          |
| Slovakia                   | 916 180    | 916 180    | 916          | 916 180      | 916 e 180 e  | 916 180      | 916 e 180 e  | 916 e 180    | 916 e 180 o  | 916 180      |
| Slovenia Spain             | 3 331      | 3 331      | 180 3 331    | 3 331        | 3 331        | 3 331        | 3 331        | 3 331        | 3 331        | 3 331        |
| Sweden                     | 99         | 99         | 99           | 99           |              |              |              |              |              |              |
| Switzerland                | 456        | 456        | 469          | 527          | 527 e        | 562          | 562          | 562 e        | 562 o        | 562          |
| UK                         | 2 444      | 2 444      | 2 600        | 2 600        | 2 600        | 2 600        | 2 600 o      | 2 600 o      | 2 600 o      | 2 600        |
| Ukraine                    | 862        | 1 186      | 1 186        | 1 421        | 1 509 o      | 1 509 o      | 1 509 e      | 1 515        | 1 839        | 1 839 e      |
| European Union Middle East | 22 934 240 | 23 079 240 | 23 091 1 280 | 23 010 1 280 | 22 794 1 280 | 22 655 1 280 | 22 655 1 280 | 22 654 1 580 | 22 654 1 580 | 22 654 1 580 |
| Iran IR                    |            |            | 1 040        | 1 040        | 1 040        | 1 040 o      | 1 040 e      | 1 040 e      | 1 040 o      | 1 040 e      |
| Iraq                       | 240        |            |              | e            |              |              |              | 240 e        |              | 240          |
| Israel                     |            | 240        | 240          | 240          | 240 e        | 240 e        | 240 e        | 300 u        | 240 e 300 e  | e 300 e      |
| N America                  | 18 860 174 | 18 950     | 19 040       | 19 201       | 19 233       | 19 253       | 19 202       | 19 440       | 19 431       | 19 465       |
| Canada                     | 18         | 174        | 174 18 866   | 174 o        | 174 e 19 059 | 174 e        | 177          | 177 e        | 177 e        | 177 e 19 288 |
| USA                        | 686        | 18 776     |              | 19 027       |              | 19 079       | 19 025       | 19 263 o     | 19 254 o     | o            |
| Oceania                    | 810        | 810        | 810          | 810          | 810          | 810          | 810          | 810          | 810          | 810          |
| Australia                  | 810        | 810        | 810          | 810          | 810          | 810          | 810 o        | 810 o        | 810 o        | 810 e        |
| S America                  | 974        | 974        | 974          | 974          | 974          | 974          | 974          | 974          | 974          | 974          |
|                            |            |            | 974          |              |              |              |              |              |              |              |
| Argentina                  | 974 o      | 974 o      | o            | 974 o        | 974 o        | 974 o        | 974 o        | 974 o        | 974 o        | 974          |

## Marine energy Énergie marine Energía marina

| CAP (MW)            | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   |
|---------------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| World               | 510    | 513    | 512    | 523    | 527    | 527    | 525    | 523    | 523    | 524    |
| Asia                | 259    | 259    | 259    | 259    | 259    | 259    | 260    | 260    | 260    | 260    |
| China               | 4      | 4      | 4      | 4      | 4      | 4      | 4 e    | 5 u    | 5 e    | 5 e    |
| Korea Rep           | 255 o  | 255 o  | 255    | 255    | 255 o  | 255 o  | 256    | 256 o  | 256 o  | 256 o  |
| Singapore           | 0      | 0      | 0      | 0      | 0 e    | 0 o    | 0 e    | 0 e    | 0 e    | 0 e    |
| Eurasia             | 2      | 2      | 2      | 2      | 2      | 2      | 2      | 2      | 2      | 2      |
| Russian Fed         | 2 u    | 2 u    | 2 u    | 2 u    | 2 u    | 2 o    | 2 e    | 2      | 2 e    | 2      |
| Europe              | 228    | 231    | 230    | 241    | 245    | 246    | 243    | 241    | 241    | 241    |
| Faroe Islands       |        |        | 0 u    |        |        |        |        | 0 o    | 0 e    | 0      |
| France              | 218    | 220    | 218    | 220    | 219    | 218    | 214    | 212    | 211    | 211    |
| Italy               | 0 u    | 0 u    | 0 u    | 0 u    | 0 e    | 0 e    | 0 e    | 0 u    | 0 e    | 0      |
| Netherlands         | u      | 0 u    | 2 u    | 2 e    | 2 e    | 2 e    | 2 u    | 2 e    | 2 e    | 2      |
| Norway              | 0 u    | 0 u    | 0 u    | 0 u    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0      |
| Portugal            | 0      | 1      |        |        | 0      | 0      |        |        |        |        |
| Spain               | 0 u    | 0 u    | 0 u    | 5      | 5      | 5      | 5 e    | 5 e    | 5 e    | 5      |
| Sweden              | 0 u    | 0 u    | 0 u    | 0 u    | 0 e    | 0 e    |        |        |        |        |
| UK                  | 8      | 9      | 9      | 13     | 18     | 20     | 22     | 22     | 22     | 22     |
| European Union (27) | 219    | 222    | 221    | 227    | 227    | 226    | 221    | 219    | 218    | 218    |
| N America           | 20     | 20     | 20     | 20     | 20     | 20     | 20     | 20     | 20     | 21     |
| Canada              | 20     | 20     | 20     | 20     | 20     | 20 e   | 20 e   | 20 e   | 20 e   | 21 e   |
| USA                 | 0 u    | 0 e    | 0 u    | 0 u    | 0 o    |        |        |        |        |        |
| Oceania             | 1      | 1      | 1      | 1      | 1      |        | 0      | 0      | 0      | 0      |
| Australia           | 1      | 1      | 1      | 1      | 1 e    |        | o      |        | e      |        |
| New Zealand         |        |        |        |        |        |        | 0 o    | 0 o    | 0 e    | 0 e    |
| S America           | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      |
| Brazil              | 0      | 0      | 0      | 0      | 0      | 0 o    | 0 o    | 0 o    | 0 o    | 0 o    |

## Wind energy Énergie éolienne Energía eólica

| CAP (MW)                    | 2013    | 2014    | 2015    | 2016      | 2017     | 2018      | 2019      | 2020       | 2021         | 2022      |
|-----------------------------|---------|---------|---------|-----------|----------|-----------|-----------|------------|--------------|-----------|
| World                       | 300 027 | 349 466 | 416 347 | 467 028   | 514 423  | 564 513   | 620 841   | 731 656    | 824 171      | 898 824   |
| Africa                      | 1 742   | 2 399   | 3 320   | 3 831     | 4 578    | 5 472     | 5 529     | 6 515      | 7 370        | 7 685     |
| Algeria                     |         | 10      | 10      | 10        | 10       | 10        | 10        | 10         | 10           | 10        |
| Cabo Verde                  | 27      | 27      | 27      | 27        | 27       | 28        | 28        | 28         | 28           | 28        |
| Chad Djibouti               |         |         |         | 1         | 1        | 1         | 1         | 1          | 1 20         | 1 20      |
| Egypt                       | 555     | 555     | 755     | 755       | 755      | 1 130     | 1 132     | 1 380      | 1 640        | 1 643     |
| Eritrea Ethiopia            | 1 171   | 1 171   | 1 324   | 1 324     | 1 324    | 1 324     | 1 324     | 1 324      | 1 324        | 1 404     |
| Gambia                      | 1       | 1       | 1       | 1         | 1        | 1         | 1         | 1          | 1            | 1         |
| Ghana Kenya                 | 6       | 6       | 0 26    | 0 26      | 0 26     | 0 336     | 0 336     | 0 336      | 0 436        | 0 436     |
| Madagascar                  | 0       | 0       | 0       | 0         | 0        | 0         | 0         | 0          | 0            | 0         |
| Mauritania                  | 4       | 4       | 34      | 34        | 34       | 34        | 34        | 34         | 34           | 34        |
| Mauritius Morocco           | 1 495   | 1 797   | 1 797   | 11 902    | 11 1 022 | 11 1 225  | 11 1 225  | 11 1 435   | 11 1 471     | 11 1 556  |
| Namibia                     | 0       | 0       |         | 0         | 5        | 5         | 5         | 5          | 5            | 5         |
| Reunion                     | 15      | 15      | 0 15    | 17        | 17       | 17        | 17        | 17         | 17           | 17        |
| Senegal                     |         |         |         |           |          |           | 55        | 159        | 159          | 159       |
| Seychelles Somalia          | 6       | 6       | 6       | 6         | 6        | 6         | 6         | 6          | 6            | 6         |
| South Africa                | 2 257   | 2 569   | 3 1 079 | 3 1 473   | 4 2 094  | 4 2 094   | 4 2 094   | 4          | 4 2 956      | 4 3       |
| Tanzania                    |         |         |         |           |          |           |           | 2 516 2    | 2            | 103       |
| Tunisia                     | 200     | 233     | 240     | 240       | 240      | 245       | 245       | 245        | 245          | 2 245     |
| Asia                        | 99 542  | 124 336 | 161 804 | 184 185   | 205 016  | 229 094   | 257 671   | 332 298    | 384 945      | 425 674   |
| Afghanistan Bangladesh      | 0 2     | 0 2     | 0 3     | 0 3       | 0 3      | 0 3       | 0 3       | 0 3        | 0            | 0 3       |
| Bhutan                      |         |         |         | 1         |          |           |           |            | 3            |           |
| Cambodia                    | 0       | 0       | 1 0     | 0         | 1 0      | 1 0       | 1 0       | 1 0        | 1 0          | 1 0       |
| China                       | 76 731  | 96 819  | 131 048 | 148 517   | 164 374  | 184 665   | 209 582   | 282 113    | 328 973      | 365 964   |
| China HK SAR Chinese Taipei | 614     | 637     | 647     | 682       | 1 692    | 1 713     | 1 845     | 1          | 1            | 1 1 581   |
| India                       | 18 420  | 22 465  | 25 088  | 28 700    | 32 848   | 35 288    | 37 505    | 937 38 559 | 1 033 40 067 | 41 930    |
| Indonesia                   | 1 2 646 | 1 2 753 | 1 2 808 | 1 3 247   | 1 3 483  | 144 3 498 | 154 3 954 | 154 4 367  | 154 4 467    | 154 4 577 |
| Japan Kazakhstan            | 4       | 53      | 72      | 98        | 112      | 121       | 284       | 486        | 684          | 1 108     |
| Korea DPR                   | 0       | 0       | 0       | 0         | 1        | 1         | 1         | 1          | 1            | 1         |
| Korea Rep                   | 576 1   | 612 1   | 847     | 1 067     | 1 215    | 1 420     | 1 494     | 1 636      | 1 708 1      | 1 893     |
| Maldives Mongolia           | 51      | 51      | 1 51    | 1 51      | 1 101    | 1 156     | 1 156     | 1 156      | 156          | 1 156     |
| Myanmar                     |         |         | 0       | 0         | 0        | 0         | 0         | 0          | 0            | 0         |
| Nepal                       | 0       | 0       | 0       | 0         | 0        | 0 1       | 0 1       | 0 1        | 0 1          | 0 1       |
| Pakistan Philippines        | 106 33  | 206 337 | 308 427 | 591 427   | 789 427  | 186 427   | 236 443   | 236 443    | 335 443      | 435 443   |
| Singapore                   |         |         |         |           | 0        | 0         | 0         | 0          | 0            | 0         |
| Sri Lanka                   | 81      | 121     | 131     | 131       | 131      | 128       | 128       | 179 1      | 252          | 252       |
| Thailand                    | 223     | 225     | 234     | 507       | 628      | 1 103     | 1 507     | 507        | 1 545        | 1 545     |
| Uzbekistan Viet Nam         | 53      | 53      | 136     | 160       | 1 205    | 1 237     | 1 375     | 1 518      | 1 4 118      | 1 4 628   |
| C America + Carib           | 797     |         | 1 282   | 1 523     | 1        |           |           | 1 965      | 1            | 2 036     |
|                             |         |         |         |           | 603      |           | 1 940     |            | 992          |           |
| Antigua Barb                |         | 920     | 30      |           |          | 1 712     |           | 4          | 4 30         | 4 30      |
| Aruba Barbados              | 30 0    | 30 0    | 0       | 30 0      | 30 0     | 30 0      | 30 0 0    | 30 0 0     | 0 0          | 1 0       |
| Belize BES Islands Is       | 0 11    | 0 11    | 0 11    | 0 11 1    | 0 11     | 0 11      | 11        | 11         | 11           | 11        |
| Br Virgin                   | 1       | 1       | 1       |           | 1        | 1         | 1         | 1          | 1            | 1         |
| Costa Rica                  | 144     | 193     | 272     | 365       | 378      | 408       | 411       | 394        | 394          | 390       |
| Cuba Curacao                | 12      | 12      | 12      | 12 30     | 12       | 12        | 12        | 12 47      | 12           | 12 47     |
|                             | 30      | 30      | 30      |           | 47       | 47        | 47        |            | 47           |           |
| Dominica Dominican Rep      | 0 85    | 0 85    | 0       | 0 135     | 0 135    | 0         | 0         | 0          | 0            | 0         |
| El Salvador                 |         |         | 85      |           |          | 183       | 370       | 370 36     | 370          | 54        |
| Grenada                     | 0       | 0       |         |           | 0        | 0         | 0         | 0          | 54           | 417 0     |
| Guadeloupe                  |         | 23      | 0       | 0         | 26       |           | 42        |            | 0            | 52        |
| Guatemala                   | 23      |         | 27      | 26        | 76       | 26        |           | 42         | 52 107       |           |
| Haiti                       |         |         | 76      | 76        |          | 107       | 107       | 107        | 0            | 107 0     |
| Honduras                    | 152     | 152     | 156     | 179       | 229 99   | 0 229     | 0 239     | 0 239      | 239          | 239 99    |
| Jamaica                     | 39 1    | 39 1    | 39      | 99        | 1        | 99 1      | 99 13     | 99 15      | 99           | 14        |
| Martinique Nicaragua Panama | 147 20  | 186     | 1 186   | 1 186 270 | 186 270  | 186 270   | 186 270   | 186 270    | 14 186       | 186 270   |
| Puerto Rico                 |         | 55      | 253 100 |           | 99       | 99        |           | 99         | 270 99       | 99        |
| St Kitts                    |         |         |         |           | 2        |           |           |            | 2            | 2         |
| Nevis Trinidad              | 100 2   | 99 2    | 2       | 99 2      | 0        | 2 0       | 99 2 0    | 2          |              | 0         |
| US Virgin Is                | 0       | 0       | 0 0     | 0 0       | 0        | 0         | 0         | 0 0        | 0 0          | 0         |
| Tobago                      |         |         |         |           |          |           |           |            |              |           |

## Wind energy Énergie éolienne Energía eólica

| CAP (MW)                  | 2013       | 2014        | 2015       | 2016          | 2017        | 2018       | 2019        | 2020        | 2021         | 2022         |
|---------------------------|------------|-------------|------------|---------------|-------------|------------|-------------|-------------|--------------|--------------|
| Eurasia                   | 2 775      | 3 645       | 4 525      | 5 801         | 6 566       | 7 146      | 7 783       | 9 868       | 12 652       | 13 712       |
| Armenia                   | 3          | 3           | 3          | 3             | 3           | 3          | 3           | 3           | 3            | 3            |
| Azerbaijan                | 3          | 3           | 8          | 16            | 16          | 66         | 66          | 66          | 66           | 66 29        |
| Georgia Russian Fed       | 10         | 10          | 11         | 20 11         | 20 11       | 20 52      | 21 102      | 21 945      | 21 1 955     | 2 218        |
| Türkiye                   | 2 760      | 3 630       | 4 503      | 5 751         | 6 516       | 7 005      | 7 591       | 8 832       | 10 607       | 11 396       |
| Europe                    | 118 170    | 130 198     | 143 015    | 155 727       | 170 616     | 181 787    | 196 104     | 207 910     | 222 034      | 240 624      |
| Austria                   | 1 675      | 2 110       | 2 489      | 2 730         | 2 887       | 3 133      | 3 224       | 3 226       | 3 408        | 3 736        |
| Belarus                   | 7          | 9           | 22         | 62            | 84          | 92 3       | 112         | 112         | 112 4        | 112          |
| Belgium                   | 1 769      | 1 933       | 2 181      | 2 334         | 2 779       | 305        | 3 864       | 4 673       | 948          | 5 251        |
| Bosnia Herzg Bulgaria     | 0 683      | 0 699       | 0 699      | 0 699         | 0 698       | 51 699     | 87 703      | 87 703      | 135 704      | 135 704      |
| Croatia                   | 254        |             | 418        | 483           | 576         | 586        | 646         | 801         | 987          | 1 043        |
| Cyprus                    | 147        | 339 147     | 158        | 158           | 158         | 158        | 158         | 158         | 158          | 158          |
| Czechia                   | 262        | 278         | 281        | 282           | 308         | 316        | 339         | 339         | 339          | 339          |
| Denmark                   | 4 819      | 4 886       | 5 077      | 5 245         | 5 489       | 6 123      | 6 111       | 6 267       | 7 021        | 7 088        |
| Estonia                   | 248        | 275         | 300        | 310           | 312         | 310        | 316         | 317         | 315          | 315          |
| Faroe Islands             | 9          | 20          | 20         | 20            | 20          | 16         | 13          | 19          | 23           | 23           |
| Finland                   | 447        | 627         | 1 005      | 1 565         | 2 044       | 2 041      | 2 284       | 2 586       | 3 257        | 5 614        |
| France                    | 8 156      | 9 201       | 10 298     | 11 567        | 13 499 55   | 14 900     | 16 427      | 17 514      | 18 740       | 21 120       |
| Germany                   | 33 477     | 38 614      | 44 580     | 49 435        | 580         | 58 721     | 60 742      | 62 201      | 63 833       | 66 315       |
| Greece                    | 1 809      | 1 978       | 2 091      | 2 370         | 2 624       | 2 877      | 3 589       | 4 119       | 4 649        | 4 879        |
| Hungary Iceland           | 329 2      | 329         | 329        | 329           | 329 2       | 329        | 323 2       | 323 2       | 324          | 324 2        |
| Ireland                   | 1 923      | 3 2 283     | 3 2 451    | 3 2 802       | 3 319       | 2 3 674    | 4 126       | 4 307       | 2 4 339      | 4 619        |
| Italy                     | 8 542      | 8 683       | 9 137      | 9 384         | 9 737       | 10 230     | 10 679      | 10 871      | 11 254       | 11 780       |
| Kosovo*                   | 1          | 1           | 1          | 1             | 34          | 34         | 34          | 34          | 139          | 139          |
| Latvia                    | 66         | 69          |            | 70            | 77          | 78         | 78          | 78          | 77           | 136          |
| Lithuania                 | 279        | 288         | 68 436     | 509           | 518         | 533        | 534         | 540         | 671          | 814          |
| Luxembourg Malta          | 58 0       | 58 0        | 64 0       | 120 0         | 120 0       | 123 0      | 136 0       | 153 0       | 136 0        | 165 0        |
| Moldova Rep Montenegro    | 1          | 1           | 1          | 2             | 9 72        | 33 72      | 35 118      | 41 118      | 73 118       | 102 118      |
| Netherlands               | 2 713      | 2 865       | 3 391      | 4 257         | 4 202       | 4 393      | 4 484       | 6 648       | 7            | 309          |
| North Macedonia           |            | 37 859      | 37         | 37            | 37          | 37 710     | 37 2 914    | 37          | 769 37       | 9 37         |
| Norway Poland             | 818 3 429  | 3 836       | 867 4 886  | 883 5 747     | 1 207 5 759 | 1 5 766    | 5 837       | 4 030 6 298 | 5 049 6 967  | 5 134 7 987  |
| Portugal                  | 4 610      | 4 857       | 4 937      |               | 5 124       | 5 172      | 5 223       | 5 122       | 5 427        | 5 455        |
| Romania                   | 2 773      | 3 244       | 3 130      | 5 124 3 025   | 3 030       | 3 032      | 3 038       | 3 013       | 3 015        | 3 015        |
| Serbia                    | 1          | 1           | 10         | 17            | 25          | 227        | 398         | 398         | 398          | 398          |
| Slovakia                  | 5 2        | 3           | 3          | 3             | 4           | 3          | 4 3         | 4 3         | 4            | 4            |
| Slovenia Spain            | 958        | 3 22 925    | 3 22 943   | 3 22 990      | 3 23 124    | 3 23 405   | 25 590      | 26 819      | 3 27 908     | 3 308        |
|                           | 22         | 5           |            |               |             |            | 8           | 976         | 12 116       | 29 557       |
| Sweden                    | 4 194      | 088         | 5 819      | 6 435         | 6 611       | 7 300      | 681 75      | 9 87        |              | 14           |
| Switzerland UK            | 60         | 60          | 60         | 75            | 75          | 75         | 23 882      | 485         | 87           | 87           |
| Ukraine                   | 11 282 362 | 13 074 514  | 14 306 514 | 16 126 526    | 19 585 553  | 21 605 621 | 1 258       | 24 1 402    | 25 730 1 761 | 28 537 1 761 |
| European Union            | 105 667    | 115 659     | 127 217    | 138 019       | 148 956     | 157 255    | 167 211 775 | 177 132     | 188 453 1    | 204 122      |
| Middle East               | 122        | 165         | 286        | 423           | 504         | 609        |             | 923         | 029          | 1 053        |
| Bahrain Iran IR           | 1 108      | 1           |            | 1             | 1           | 1          | 1           | 1           | 1            | 1            |
| Israel                    | 6          | 149 6       | 1 153      | 191           | 259         | 282        | 305 27      | 308 27      | 310          | 342          |
| Jordan                    | 1          | 1           | 6 118      | 27 198        | 27 198      | 27 280     | 373         | 518         | 27 622       | 27 614       |
|                           | 2          | 2           | 2          | 2             | 12          | 12         | 12          | 12          | 12           | 12           |
| Kuwait                    | 2          |             | 3          |               |             |            | 3           |             | 3            | 3            |
| Lebanon Oman              |            | 3           |            | 3             | 3           | 3          |             | 3           |              |              |
| Saudi Arabia              |            |             |            |               | 3           | 3          | 50 3        | 50          | 50           | 50 3         |
| Syrian AR                 | 1          | 1           | 1 2        | 1             | 1           | 1          | 1           | 3 1         | 3 1          | 1            |
| United Arab Em N America  | 1 70 122   | 2 76 693    | 87 252     | 97 526 11 973 | 104 261 250 | 113 369    | 123 322     | 138 795     | 154 477      | 163 469      |
| Canada                    | 7 801      | 9 694 2 569 | 11 214     | 4             | 12 4 180    | 12 816 0   | 13 413      | 13 627 0    | 14 304 0     | 15 295 0     |
| Greenland Mexico          | 2 122 1    |             | 3 271      | 051           |             | 5 887      | 0 6 073     | 6 504       | 7 154        | 7 312        |
| St Pierre Mq USA          | 60 198     | 64 430      | 72 767     | 81 502        | 87 831      | 94 666     | 103 836     | 118 664     | 133 019      | 140 862      |
| Oceania                   | 3 894      | 4 530       | 4 921      | 5 065         | 5 553       | 6 184      | 7 022       | 9 346       | 9 917        | 11 100       |
| Australia                 | 3 221      | 3 797       | 4 181      | 4 324         | 4 812       | 5 442 0    | 6 279       | 8           | 8            | 10 134       |
|                           |            |             |            | 0             | 0           |            | 0           | 603         | 951          | 0            |
| Cook Is Fiji Fr Polynesia | 0 10       | 0 10        | 0 10       | 10            | 10          |            |             | 0           | 0 10         | 10           |
|                           | 0          | 0           | 0          | 0             | 0           | 10         | 10 0        | 10          |              |              |
| Guam Marshall Is          |            |             |            | 0             | 0           | 0          | 0           | 0           | 0            | 0            |
|                           |            |             |            |               |             |            |             | 0 0         | 0 0          | 0 0          |
|                           |            |             |            |               |             | 0          |             |             |              |              |
|                           |            |             |            |               |             | 0          |             |             |              |              |
|                           |            |             |            |               |             |            | 0           |             |              |              |

## Wind energy Énergie éolienne Energía eólica

| CAP (MW)       | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   |
|----------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Micronesia     |        |        |        |        |        | 1      | 1      | 1      | 1      | 1      |
| New Caledon    | 38     | 38     | 38     | 38     | 38     | 38     | 38     | 38     | 38     | 38     |
| New Zealand    | 622    | 681    | 688    | 689    | 689    | 689    | 689    | 689    | 912    | 912    |
| Samoa          |        | 1      | 1      | 1      | 1      | 1      | 1      | 1      | 1      | 1      |
| Tokelau        |        |        |        |        |        |        | 0      | 0      | 0      | 0      |
| Tonga          | 0      | 0      | 0      | 0      | 0      | 0      | 1      | 1      | 1      | 1      |
| Vanuatu        | 3      | 4      | 4      | 4      | 3      | 3      | 3      | 3      | 3      | 3      |
| S America      | 2 863  | 6 579  | 9 942  | 12 946 | 15 726 | 19 140 | 20 695 | 24 035 | 29 755 | 33 471 |
| Argentina      | 190    | 215    | 187    | 187    | 227    | 750    | 1 609  | 2 624  | 3 292  | 3 309  |
| Bolivia        | 0      | 3      | 3      | 27     | 27     | 27     | 27     | 27     | 128    | 131    |
| Brazil         | 2 202  | 4 888  | 7 633  | 10 129 | 12 304 | 14 843 | 15 438 | 17 198 | 21 161 | 24 163 |
| Chile          | 301    | 736    | 910    | 1 039  | 1 305  | 1 524  | 1 620  | 2 149  | 3 137  | 3 830  |
| Colombia       | 18     | 18     | 18     | 18     | 18     | 18     | 18     | 18     | 18     | 18     |
| Ecuador        | 19     | 21     | 21     | 21     | 21     | 21     | 21     | 21     | 21     | 21     |
| Falklands Malv | 1      | 1      | 1      | 1      | 1      | 1      | 3      | 3      | 3      | 3      |
| Guyana         | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      |
| Peru           | 1      | 143    | 240    | 240    | 240    | 372    | 372    | 409    | 409    | 409    |
| South Georgia  | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      | 0      |
| Uruguay        | 59     | 481    | 857    | 1 211  | 1 511  | 1 511  | 1 514  | 1 514  | 1 514  | 1 514  |
| Venezuela      | 71     | 71     | 71     | 71     | 71     | 71     | 71     | 71     | 71     | 71     |

## Onshore wind energy Énergie éolienne terrestre Energía eólica terrestre

| CAP (MW)                                 | 2013           | 2014         | 2015       | 2016          | 2017             | 2018         | 2019          | 2020           | 2021            | 2022           |
|------------------------------------------|----------------|--------------|------------|---------------|------------------|--------------|---------------|----------------|-----------------|----------------|
| World                                    | 292 856        | 340 974      | 404 630    | 452 686       | 495 586          | 540 923      | 592 539       | 697 285        | 769 912         | 835 624        |
| Africa 4 7                               | 1 742 3        | 2 399        | 320        | 3 831         | 578              | 5 472 5      | 529           | 6 515          | 7 370           | 685            |
| Algeria                                  |                | 10           | 10         | 10            | 10 e             | 10 e         | 10 e          | 10 e           | 10 e            | 10 e           |
| Cabo Verde Chad u                        | 27             | 27           | 27         | 27 1          | 27 1 e 1         | 28 e e       | 28 e 1 e      | 28 e 1 o       | 28 e 1 e        | 28 e 1 e       |
| Djibouti Egypt                           |                | 555 o        | 755 o      | 755 o 1 e     | o 1 e            | 1 130 o 1 e  | 1 132 e 1 e   | 1 380 e 1 e    | 20 u 640        | 20 e 643 e 1   |
| 1                                        | 555 o          |              |            |               | 755              |              |               |                | 1 e             |                |
| Eritrea Ethiopia                         | 1 e 171        | 1 e 171      | 1 e 324    | 324 u         | 324 e            | 324 e        | 324 e         | 324            | 1 e 324         | e 404 e        |
| Gambia Ghana                             | 1 o            | 1 o          | 1 o        | 1 o           | 1 o              | 1 e          | 1 e           | 1 e            | 1 e 0 e         | 1 e 0 o        |
| Kenya                                    | 6 o            | 6 o          | 0 o 26 e   | 0 e 26 e      | 0 e 26 e         | 0 e 336 e    | 0 e 336 e     | 0 e 336 e      | 436 e           | 436 e          |
| Madagascar                               | 0 o            | 0 o          | 0 o        | 0 o           | 0 e              | 0 e          | 0 e           | 0 e            | 0 e             | 0 e            |
| Mauritania Mauritius                     | 4 o 1          | 4 o 1        | 34 o 1     | 34 o          | 34 o 11 e        | 34 e 11 e    | 34 e 11 e     | 34 e 11 e      | 34 e 11 e       | 34 e 11 e      |
| Morocco 1 1                              | 495            | 797          | 797        | 11 o 902 o    | 022 o 1          | 225 o 1      | 225 e         | 1 435 e        | 1 471 e         | 556 e          |
| Namibia                                  | 0 e 15 o       | 0 e          | 0 e        | 0 e           | 5 u              | 5 e          | 5             | 5 e            | 5 e             | 5 e            |
|                                          |                | 15 o         |            |               |                  |              | 17            |                |                 |                |
| Reunion Senegal                          |                |              | 15 o       | 17 o          | 17 e             | 17 o         | e 55 o        | 17 e 159 o     | 17 e 159 e      | 17 e 159 e     |
| Seychelles Somalia                       | 6 o 2          | 6 o 2        | 6 o        | 6 o           | 6 o              | 6 e          | 6 e           | 6 e            | 6 o             | 6 e 4 e        |
|                                          | u              | u            | 3 u        | 3 u           | 4 u              | 4 e          | 4 e           | 4              | 4 e             |                |
| South Africa 2                           | 257 o 1        | 569 o        | 079 o      | 1 473 o       | 094 o 2          | 094 o 2      | 094 e         | 2 516 u        | 2 956 e         | 103 u          |
| Tanzania Tunisia                         | o              |              |            | 240 o         | 240 o            |              |               | 2 u            | 2 e             | 3 2 e          |
|                                          | 200            | 233 o        | 240 o      |               |                  | 245 o        | 245 o         | 245 o          | 245 e           | 245 e          |
| Asia                                     | 99 055         | 123 820      | 161 082    | 182 506       | 202 010          | 224 261      | 251 373       | 322 884        | 357 127         | 393 178        |
| Afghanistan                              | 0 e 2 o        | 0 e          | 0 e        | 0 e           | 0 e              | 0 e          | 0 e           | 0 e            | 0 e             | 0 e 3 o        |
| Bangladesh Bhutan                        |                | 2 o          | 3 o        | 3 o           | 3 o              | 3 e          | 3 o 1 e       | 3 o 1 e        | 3 o 1 e         | 1 e            |
| Cambodia                                 | 0 e            | 0 e          | 1 u 0 e    | 1 e 0 e       | 1 e 0 e          | 1 e 0 e      | 0 e           | 0 e            | 0 e             | 0 e            |
| China China HK SAR                       | 76 314         | 96 379       | 130 489    | 147 037       | 161 586 1        | 180 077 1    | 203 652 e 1   | 273 123 o 1    | 302 583 e 1     | 335 504 e 1 e  |
| Chinese Taipei India                     | 614 o          | 637 o 22     | 647 o      | 682 o         | 684 o            | 705 o        | 717 o         | 809 o          | 796 o 067 o     | 836 o 930 o    |
|                                          | 18 420 o       | 465 o o      | 25 088 o   | 28 700 o      | 32 848 o         | 35 288 o     | 37 505 o      | 38 559 o       | 40              | 41             |
| Indonesia Japan                          | 1 o 2 596      | 1 2 703      | 1 o 2 755  | 1 o 3 187     | 1 o 3 418        | 144 o 3 433  | 154 o 3 886   | 154 e 4 306 o  | 154 o 4 406 o   | 154 o 4 516 o  |
| Kazakhstan Korea                         | 4 0            | 53           | 72         | 98            | 112              | 121 o        | 284 e         | 486            | 684 1           | 1 108 1 e      |
| DPR Korea Rep                            | u 571          | 0 u 602      | 0 u 837    | 0 u 027       | 1 o 170          | 1 e 347      | 1 1 421       | 1 e 500 o      | e 1 572         | 1 757 e        |
| 1                                        | 1 u            |              |            | 1             | 1                |              | e             | 1              | o               |                |
| Maldives Mongolia                        | 51             | 1 e          | 1 e        | 1 e           | 1 e 101 e        | 1 e          | 1 e 156 e     | 1 e 156        | 1 e 156         | 1 e 156        |
|                                          | e              | 51 e         | 51 e 0 e   | 51 e 0        | 0 e              | 156 o 0 e    | 0 e           | 0 e            | 0 e             | 0 e            |
| Myanmar                                  | 0 u            | 0            |            | e 0           | 0 e              | 0 o          | 0             | 0 e            | 0               | 0 e            |
| Nepal Pakistan                           | 106 e 33 o     | u 206 e      | 0 u 308 e  | u 591 e 427 o | 789 e 427 o      | 186 e 1      | o 236 e       | 1 236          | e 335           | 435 e 443 o    |
| Philippines                              |                | 337 o        | 427 o      |               | 0 u              | 1 427 o      | 443 o 0       | e 443 o 0 e    | 1 e 443 e e     | 1 0 e          |
| Singapore Sri Lanka                      | 81 o 223       | 121 225      | 131        | 131 o 507     | 131 o o          | 0 e 128 o    | e 128 e 507 o | 179 o 507 o    | 0 252 o 1 545 o | 252 e 1 545 e  |
| Thailand                                 |                | o            | o 234      |               | 628              | 1 103 o 1    |               | 1              |                 | 1              |
| Uzbekistan Viet Nam                      | 37             | 37 u         | 37 u       | 61 e          | 1 o 106 e        | 1 o 138 u    | 1 e 275 e     | 1 419          | 1 e 3 124 e     | 3 534 e        |
|                                          |                |              |            |               |                  |              |               | e              |                 |                |
| C America + Carib                        |                | 920          | 1 282      | 1 523         | 1 603            | 1 712        | 1 940         | 1 965          | 1 992           | 2 036          |
|                                          | 797            |              |            |               |                  |              |               |                |                 |                |
| Antigua Barb Aruba                       | 30 30          |              | 30         | 30            | 30 30            | e 30         | o             | 4 u 30 e       | e e             | 4 30           |
| Barbados Belize BES Islands Br Virgin Is | 0 u 0 u 11 o 1 | 0 u 0 u 11 o | 0 u 0 u 11 | 0 u 0 u 11    | 0 u 0 u 11 o 1 o | 0 u 0 u 11 o | 0 u 0 u 11 o  | 0 u 0 u 11 o   | u 0 e 11 o 1    | 0 1 u 0 u 11   |
| Costa Rica                               | o              | 1 o          | o 1 o      | o 1 o         |                  | 1            | 1 o           | 1              |                 | 1              |
|                                          |                | 193 12       |            | 365           |                  | o o          | 411 o         | o o            | o               | o              |
| Cuba                                     | 144 12         |              | 272 12     | 12            | 378 12           | 408 12       | 12            | 394 12         | 394 o 12        | o 390 o 12 e   |
| Curacao Dominica                         | 30 0           | 30           | 30         | 30            | 47 o 0 o         | e 47 0       | 47 o          | 47 0 e         | 47 o            | 47             |
|                                          |                | 0            | 0          | 0             |                  | o o          | 0 e           | o              | 0               | 0 e            |
| Dominican Rep                            | 85             | o 85         | o 85       | o 135         | 135 o            | 183 o        | o             | o              | e 370           | o 417 o        |
| El Salvador                              | o              |              |            | o u           |                  |              | 370           | 370 36 o 0 e   | 54 o            | 54 e           |
| Grenada                                  | 0              | 0 u 23       | 0 27       | 0 26          | 0 u 26           | 0 u 26       | 0 e 42        | 42             | 0 52            | 0 e 52         |
| Guadeloupe Guatemala                     | 23             |              | u          |               |                  | 107 o        | 107 o         | 107            | e               |                |
| Haiti                                    | u              |              | 76         | 76            | 76               |              |               | 0              | 107 o 0 e       | 107 o          |
|                                          | 152 o          | 152          | e          | 179 e         | 229 e            | 0 u 229 e    | 0 e 239 e     | o e 239 e      | 239 e           | 0 e e          |
| Honduras                                 |                |              | 156        | 99            | 99               |              |               | 99 o           |                 | 239            |
| Jamaica                                  | 39             | 39           | 39         |               | 1 e              | 99 e         | 99 e          |                | 99 e            | 99 e           |
| Martinique Nicaragua                     | 1 o 147        | 1 o 186      | 1 o 186    | 1 o 186 270   | 186 270          | 1 o 186 o    | 13 186 o      | 15 186 o 270 e | 14 186 e 270 o  | 14 e 186 e 270 |
| Panama                                   | 20             | 55           | 253        | o             | 99 o             | 270 o        | 270           |                |                 |                |
| Puerto Rico                              |                | 99           | 100        | 99            |                  | 99 o         | 99 o          | 99 o           | 99 o            | 99 o 2 e       |
| St Kitts Nevis                           | 2              | 2            |            | 2             | 2 u              | 2 e          | 2 e           | 2 e            | 2 e             |                |
| Trinidad                                 | 100 o          | o            | o 2        | 0             | 0                | 0 e          | 0 e           | 0 e            | 0               | 0 e            |
|                                          | 0              |              | 0          |               | 0 o              | 0 e          | 0 e           | 0 e            | 0               | 0 e            |
| US Virgin Is                             |                | 0 o          | 0          | 0             |                  |              |               |                |                 |                |
| e e                                      |                |              |            |               |                  |              |               |                |                 |                |
| Tobago                                   |                |              | o          | o             |                  |              |               |                |                 |                |
|                                          | o              |              |            |               |                  |              |               |                |                 |                |

Marshall Is

## Onshore wind energy Énergie éolienne terrestre Energía eólica terrestre

e

u

u

e

e

e

e

e

e

e

e

o

o

e

e

e

e

e

| CAP (MW)                    | 2013              | 2014        | 2015          | 2016           | 2017       | 2018           | 2019           | 2020         | 2021         | 2022           |
|-----------------------------|-------------------|-------------|---------------|----------------|------------|----------------|----------------|--------------|--------------|----------------|
| Eurasia                     | 2 775             | 3 645       | 4 525         | 5 801          | 6 566      | 7 146          | 7 783          | 9 868        | 12 652       | 13 712         |
| Armenia                     | 3                 | 3           | 3             | 3 o            | 3 e        | 3 o            | 3 e            | 3 e          | 3            | e 3            |
| Azerbaijan Georgia          | 3                 | 3           | 8             | 16 u           | 16 u       | 66 o           | 66 e 21        | 66 21 o      | 66 21 o      | 66 29          |
| Russian Fed                 | 10                | 10 e        | 11 e          | 20 11 e        | 20 11 e    | 20 52 e        | 102 e          | 945          | 1 955        | o 2 218        |
| Türkiye                     | 2 760             | 3 630       | 4 503         | 5 751          | 6 516      | 7 005          | 7 591          | 8 832        | 10 607       | 11 396         |
| Europe                      | 111 486           | 122 223     | 132 019       | 143 094        | 154 814    | 163 060        | 174 129        | 182 983      | 195 635      | 209 961        |
| Austria                     | 1 675             | 2 110       | 2 489         | 2 730          | 2 887      | 3 133          | 3 224          | 3 226        | 3 408        | 3 736          |
| Belarus                     | 7                 | 9           | 22            | 62             | 84         | 92             | 112            | 112          | 112          | 112            |
| Belgium Bosnia Herzg        | 1 061 1 0 o       | 1 225 0 o   | 1 469 o       | 1 622 0 o      | 902 0 o    | 2 119 51       | 2 308 87       | 2 411 87     | 2 687 135    | 2 990 u 135    |
| Bulgaria                    | 683               | 699         | 0 699         | 699            | 698        | 699            | 703            | 703          | 704          | 704            |
| Croatia                     | 254               | 339         | 418           | 483            | 576        | 586            | 646            | 801          | 987          | 1 043          |
| Cyprus                      | 147               | 147         | 158           | 158            | 158        | 158            | 158 o          | 158 o        | 158          | 158            |
| Czechia                     | 262               | 278         | 281           | 282            | 308        | 316            | 339            | 339          | 339          | 339            |
| Denmark                     | 3 548 4           | 3 615       | 3 806         | 3 974          | 225        | 4 422          | 4 410          | 4 566        | 4 715        | 4 782          |
| Estonia                     | 248               | 275         | 300           | 310            | 312        | 310            | 316            | 317          | 315          | 315            |
| Faroe Islands               | 9 o               | 20 o        | 20 o          | 20 o           | 20 e       | 16 o           | 13 o           | 19 o         | 23           | 23             |
| Finland France              | 421 e 8 156 13    | 601 e 9 201 | 973 e 10 298  | 1 533 e 11 567 | 1 971 497  | 1 968 o 14 898 | 2 211 16 425   | 2 513 17 512 | 3 184 18 738 | u 5 541        |
| Germany                     | 32 969 o          | 37 620 o    | 41 297 o      | 45 303         | 50 174 2   | 52 328         | 53 187         | 54 414       | 56 046       | 20 638 58 186  |
| Greece                      | 809               |             | 091           | 2 370          | 624        | 877            | 3 589          | 4 119        | 4 649        | 879            |
|                             | 1                 | 1 978       | 2             |                |            | 2              |                |              |              | 4              |
| Hungary Iceland             | 329               | 329         | 329           | 329 3          | 329 u 2    | 329 o          | 323 2          | 323          | 324          | 324 2          |
| Ireland                     | 2 1 898 3         | 3 2 258     | 3 2 426       | 2 776          | 294        | 2 3 649        | 4 101          | 2 4 282      | 2 e 4 314    | 4 594          |
| Italy                       | 8 542             | 8 683       | 9 137         | 9 384          | 9 737      | 10 230         | 10 679         | 10 871       | 11 254       | 11 750         |
| Kosovo*                     | 1                 | 1           | 1             | 1              | 34         | 34             |                | 34           | 139          | 139            |
| Latvia                      | 66                | 69          | 68            | 70             | 77         | 78             | 34 78          | 78           | 77           | 136            |
| Lithuania                   | 279               | 288         | 436           | 509            | 518        | 533            | 534            | 540          | 671          | o 814          |
| Luxembourg                  | 58                | 58          | 64 0          | 120 0          | 120 0      | 123 e          | 136 0          | 153          | 136 0        |                |
| Malta Moldova Rep           | 0 1               | 0 1         | o 1           | 2 o            | 9 o        | 0 33           | e 35           | 0 e          |              | e 0 102        |
| Montenegro                  | 2 485 o           | 2 637 o     | 3             | 3 300          | 72 u       | 72             | 118 u          | 41 118 e     | 73 118       | u 118          |
| Netherlands North Macedonia | 3                 | 37          | 034 37        | 37             | 245 37 u   | 3 436 37       | 3 527 u 37 o   | 4 188 37 o   | 5 310 37     | 6 090 u 37     |
| Norway Poland               | 816 e 1 205 3 429 | 857 3 836   | 865 e 4 886 4 | 881 e 5 747    | o 5 759    | 1 708 5 766    | 2 912 5 837    | 4 028 6 298  | 5 043 6 967  | 5 068 7 987    |
| Portugal                    | 4 608             | 4 855 3     | 935 3         | 5 124          | 5 124      | 5 172          | 5 215          | 5 097        | 5 402        | 5 430          |
| Romania                     | 2 773             | 244 1       | 130           | 3 025          | 3 030 u    | 3 032          | 3 038          | 3 013        | 3 015        | 3 015          |
| Serbia                      | 1                 |             | 10 e          | 17             | 25 u       | 227            | 398            | 398          | 398 o        | 398            |
| Slovakia Slovenia           | 5                 | 3           | 3             | 3              | 4          | 3              | 4              | 4            | 4            | 4              |
|                             | 2 22 953          | 3           | 3             | 3              | 3 119      | 3              | 3              | 3            | 3            | 3              |
| Spain                       | e 3 982           | 22 920 875  | 22 938 e 606  | 22 985 6 232   | 23 408     | 23 400         | 25 585 8 478   | 26 814 9 773 | 27 903       | 29 303 14 364  |
| Sweden Switzerland          | 60                | 4 60        | 5 60          | 75             | 6 75 u     | 7 097 75 o     | 75 e           | 87 o o       | 11 923 87 u  | 87             |
| UK                          | 7 586 362         | 8 573 514   | 9 212 514     | 10 833 526     | 12 597 553 | 13 425 621 o   | 13 994 1 258 o | 14 102 1 402 | 14 474 1 761 | 14 690 u 1 761 |
| Ukraine European Union      | 102 681           | 112 186     | 121 316       | 130 681        | 140 144    | 146 711        | 155 126        | 162 590      | 173 316      | 187 373        |
| Middle East                 |                   |             | 286           | 423            | 504        | 609            | 775            | 923          | 1 029        | 1 053          |
|                             | 122               | 165         |               | 1              | 1          | 1 e            | 1              | 1            |              | 1              |
| Bahrain Iran IR             | 1 e 108           | 1 e 149     | 1 e 153       | e 191          | e 259 o    | 282 o          | e 305          | e 308        | 1 e 310 o    | 342            |
| Israel                      | 6 e               | 6 o         | 6 e           | 27 e           | 27 e       | 27 e           | 27 e 373       | 27 e         | 27 e         | 27 614         |
| Jordan                      | 1 o 2             | 1 o 2       | 118 o         | 198 o          | 198 o      | 280 o          | u 12 e         | 518 o 12 e   | 622 u        |                |
| Kuwait                      | u 2               | e 3 u       | 2 e 3 e       | 2 e            | 12 e       | 12 e           | 3              | 3            | 12 e 3       | 12 3           |
| Lebanon                     |                   |             |               | 3              | 3          | 3 e            | e              |              | e            |                |
| Oman Saudi Arabia           | u                 |             |               | e              | e          | 3 e            | 50             | e 50 e       | 50 e         | 50 3           |
| Syrian AR Em                | 1 e 1 e           | 1 e 2 e     | 1 e 2 e       | 1 e u          | 3 u 1 e u  | 1 e u          | 3 o 1 e        | 3 e 1 e      | 3 e 1 e      | 1              |
| United Arab N America       | 122               | 693         | 252           | 497            | 231        |                | u              |              | 436          |                |
|                             | 70                | 76          | 87            | 97             | 104        | 113 340        | 123 292        | 138 765      | 154          | 163 428        |
| Canada                      | 7 801             | 9 694       | 11 214        | 11 973         | 12 250     | 12 816 u 0 o   | 13 413 u 0 o   | 13 627 0     | 14 304 0     | 15 295 0       |
| Greenland Mexico            | 2 122             | 2 569       | 3 271         | 4 051          | 4 180      | 5 887          | 6 073          | e 6 504      | e 7 154      | 7 312          |
| St Pierre Mq USA            | 1 u 60 198 o      | 64 430 o    | 72 767 o      | 81 473 o       | 87 801 o   | 94 637 o       | 103 806 o      | 118 634 o    | 132 978 o    | 140 820        |
| Oceania                     | 3 894             | 4 530       | 4 921         | 5 065          | 5 553      | 6 184          | 7 022          | 9 346        | 9 917        | 11 100         |
| Australia                   | 3 221             | 3 797       | 4 181 0 e     | 4 324 0 e      | 4 812 0 e  | 5 442 0        | 6 279          | 8 603 o      | 8 951 o      | 10 134         |
| Cook Is Fiji                | 0 e 10            | 0 e 10 u    | 10 u          | 10 u 0 e       | 10 u       | e 10           | 0 e 10         | 0 e 10       | 0 e 10       | 0 10           |
| Fr Polynesia                | u 0 e             | 0 e         | e             |                |            | o 0 e          | o 0            | o            | o            |                |
|                             |                   |             | 0             |                | 0 e        |                |                |              |              |                |
| Guam                        |                   |             | o             |                | o          | 0 e            | e              | 0 e          | 0 e          | 0              |
|                             |                   |             |               |                |            |                | 0              | 0 e          | 0            | 0              |
|                             |                   |             |               | 0              | 0          |                | e              |              |              |                |
|                             |                   |             |               |                |            |                |                |              | e            | e              |

0

u

0

e

0

e

0

e

0

## Onshore wind energy Énergie éolienne terrestre Energía eólica terrestre

| CAP (MW)       | 2013    | 2014    | 2015    | 2016     | 2017     | 2018     | 2019     | 2020     | 2021     | 2022     |
|----------------|---------|---------|---------|----------|----------|----------|----------|----------|----------|----------|
| Micronesia     |         |         |         |          |          | 1 u      | 1 e      | 1 e      | 1 e      | 1 e      |
| New Caledon    | 38 o    | 38 o    | 38 o    | 38 o     | 38 o     | 38 o     | 38 e     | 38 e     | 38 e     | 38 e     |
| New Zealand    | 622     | 681     | 688     | 689      | 689      | 689 o    | 689 o    | 689      | 912 o    | 912 e    |
| Samoa          |         | 1 o     | 1 o     | 1 o      | 1 o      | 1 o      | 1 e      | 1 e      | 1 e      | 1 e      |
| Tokelau        |         |         |         |          |          |          | 0 o      | 0 e      | 0 e      | 0 e      |
| Tonga          | 0 e     | 0 e     | 0 u     | 0 u      | 0 u      | 0 u      | 1 u      | 1 e      | 1 e      | 1 e      |
| Vanuatu        | 3 o     | 4 o     | 4 o     | 4 o      | 3 o      | 3 o      | 3 o      | 3 e      | 3 e      | 3 e      |
| S America      | 2 863   | 6 579   | 9 942   | 12 946   | 15 726   | 19 140   | 20 695   | 24 035   | 29 755   | 33 471   |
| Argentina      | 190 o   | 215 o   | 187 o   | 187 o    | 227 e    | 750 e    | 1 609 o  | 2 624 e  | 3 292 e  | 3 309    |
| Bolivia        | 0       | 3 o     | 3 o     | 27 o     | 27 o     | 27 o     | 27 o     | 27 o     | 128 o    | 131 o    |
| Brazil         | 2 202 o | 4 888 o | 7 633 o | 10 129 o | 12 304 o | 14 843 o | 15 438 o | 17 198 o | 21 161 o | 24 163 o |
| Chile          | 301     | 736     | 910     | 1 039    | 1 305 o  | 1 524 o  | 1 620 o  | 2 149 o  | 3 137 o  | 3 830 o  |
| Colombia       | 18 o    | 18 o    | 18 o    | 18 o     | 18 o     | 18 o     | 18 o     | 18       | 18       | 18       |
| Ecuador        | 19      | 21 o    | 21 o    | 21 o     | 21 o     | 21 e     | 21 o     | 21 o     | 21 o     | 21       |
| Falklands Malv | 1 e     | 1 e     | 1 o     | 1 o      | 1 o      | 1 o      | 3 e      | 3 e      | 3 e      | 3 e      |
| Guyana         | 0       | 0       | 0       | 0        | 0        | 0 e      | 0 e      | 0 e      | 0 e      | 0 e      |
| Peru           | 1       | 143     | 240 o   | 240 o    | 240 o    | 372 e    | 372 e    | 409 e    | 409 o    | 409 e    |
| South Georgia  | 0       | 0       | 0       | 0        | 0        | 0        | 0        | 0 e      | 0 e      | 0 e      |
| Uruguay        | 59 o    | 481     | 857     | 1 211    | 1 511 o  | 1 511 o  | 1 514 o  | 1 514 o  | 1 514 e  | 1 514 o  |
| Venezuela      | 71 u    | 71 u    | 71 u    | 71 u     | 71 u     | 71 u     | 71 u     | 71 e     | 71 e     | 71 e     |

## Offshore wind energy Énergie éolienne maritime Energía eólica marina

| CAP (MW)            | 2013   | 2014   | 2015    | 2016    | 2017    | 2018    | 2019   | 2020    | 2021     | 2022     |
|---------------------|--------|--------|---------|---------|---------|---------|--------|---------|----------|----------|
| World               | 7 171  | 8 492  | 11 718  | 14 342  | 18 837  | 23 590  | 28 303 | 34 371  | 54 259   | 63 200   |
| Asia                | 488    | 516    | 722     | 1 680   | 3 006   | 4 833   | 6 298  | 9 414   | 27 818   | 32 496   |
| China               | 417    | 440    | 559     | 1 480   | 2 788 u | 4 588 u | 5 930  | 8 990 o | 26 390 o | 30 460 o |
| Chinese Taipei      |        |        |         |         | 8 u     | 8 u     | 128 o  | 128 o   | 237 o    | 745 o    |
| Japan               | 50     | 50     | 53      | 60      | 65 u    | 65 u    | 68     | 61      | 61 e     | 61 o     |
| Korea Rep           | 5      | 11     | 11      | 41      | 46 e    | 73 u    | 73 u   | 136 u   | 136 e    | 136 e    |
| Viet Nam            | 16 e   | 16 u   | 99 u    | 99 o    | 99 o    | 99 e    | 99 u   | 99 e    | 994 e    | 1 094 e  |
| Europe              | 6 684  | 7 976  | 10 996  | 12 633  | 15 802  | 18 727  | 21 975 | 24 927  | 26 399   | 30 663   |
| Belgium             | 708    | 708    | 712     | 712     | 877     | 1 186   | 1 556  | 2 262   | 2 262 o  | 2 262    |
| Denmark             | 1 271  | 1 271  | 1 271   | 1 271   | 1 264   | 1 701   | 1 701  | 1 701 o | 2 306    | 2 306    |
| Finland             | 26 u   | 26 u   | 32 u    | 32 u    | 73      | 73 o    | 73     | 73 u    | 73 u     | 73       |
| France              |        |        |         |         | 2 u     | 2 o     | 2 u    | 2 u     | 2 u      | 482      |
| Germany             | 508 o  | 994 o  | 3 283 o | 4 132 o | 5 406   | 6 393   | 7 555  | 7 787   | 7 787    | 8 129    |
| Ireland             | 25     | 25     | 25      | 25      | 25 u    | 25 o    | 25     | 25 o    | 25 e     | 25       |
| Italy               |        |        |         |         |         |         |        |         |          | 30       |
| Netherlands         | 228 o  | 228 o  | 357 o   | 957 o   | 957 u   | 957 u   | 957 u  | 2 460   | 2 460    | 3 220    |
| Norway              | 2 u    | 2 u    | 2 u     | 2 u     | 2 o     | 2 u     | 2 u    | 2 e     | 6 u      | 66       |
| Portugal            | 2      | 2      | 2       |         |         |         | 8      | 25      | 25 u     | 25       |
| Spain               | 5 u    | 5 u    | 5 u     | 5 u     | 5 u     | 5       | 5 o    | 5 e     | 5 o      | 5        |
| Sweden              | 212    | 213    | 213     | 203     | 203 e   | 203     | 203 u  | 203 u   | 193      | 193      |
| UK                  | 3 696  | 4 501  | 5 094   | 5 293 o | 6 988   | 8 181   | 9 888  | 10 383  | 11 256   | 13 848   |
| European Union (27) | 2 985  | 3 472  | 5 900   | 7 337   | 8 812   | 10 545  | 12 085 | 14 542  | 15 137   | 16 749   |
| N America           |        | 0      | 0       | 29      | 29      | 29      | 29     | 29      | 41       | 41       |
| USA                 |        | 0 u    | 0 u     | 29 o    | 29 o    | 29 o    | 29 o   | 29 o    | 41 o     | 41 o     |

## Solar energy Énergie solaire Energía solar

| CAP (MW)               | 2013      | 2014      | 2015       | 2016       | 2017       | 2018       | 2019         | 2020         | 2021       | 2022         |
|------------------------|-----------|-----------|------------|------------|------------|------------|--------------|--------------|------------|--------------|
| World                  | 140 514   | 180 712   | 228 920    | 301 082    | 395 947    | 489 306    | 592 245      | 720 429      | 861 537    | 053 115      |
| Africa                 | 716       | 1 709     | 2 242      | 3 455      | 5 200      | 8 150      | 9 493        | 10 819       | 11 628     | 12 641       |
| Algeria                | 25        | 28        | 91         | 330        | 423        | 448        | 448          | 448          | 448        | 460          |
| Angola                 | 11        | 12        | 13         | 13         | 13         | 13         | 13           | 13           | 13         | 297          |
| Benin Botswana         | 2         | 0 2       | 1 2        | 3 3        | 3 3        | 3 4        | 3 6          | 3 6          | 3 6        | 28 6         |
| Burkina Faso           | 6         | 7         | 8          | 10         | 47         | 62         | 62           | 62           | 62         | 92           |
| Burundi Cabo Verde     | 3 6       | 3 6       | 3 6        | 4 6        | 5 6        | 5 8        | 5 8          | 5 8          | 13 8       | 13 8         |
| Cameroon               | 4         | 6         | 7          | 9          | 12         | 14         | 14           | 14           | 14         | 14           |
| Cent Afr Rep           | 0         | 0         | 0          | 0          | 0          | 0          | 0            | 0            | 0          | 0            |
| Chad                   | 0         | 0         | 0          | 0          | 0          | 0          | 0            | 1            | 1          | 1 4          |
| Comoros Congo DR       | 0         | 1         | 1          | 3          | 5          | 20         | 20           | 20           | 20         | 20           |
| Congo Rep              | 0         | 0         | 0          | 0          | 1          | 1          | 1            | 1            | 1          | 1            |
| Cote d Ivoire Djibouti | 3 0       | 4 0       | 5 0        | 5 0        | 8 0        | 13 0       | 13 0         | 13 0         | 13 0       | 13 0         |
| Egypt                  |           |           | 36         |            |            |            | 647          |              |            |              |
|                        | 35        | 35        |            | 59         | 180        | 764        | 1            | 1 643        | 1 663 0    | 1 724        |
| Eq Guinea Eritrea      | 0         | 8         | 8          | 0 9        | 0 11       | 0 12       | 0 12         | 0 12         | 11         | 0 11         |
| Eswatini               | 1         | 1         | 1          | 1          | 1          | 1          | 1            | 1            | 11         | 11           |
| Ethiopia               | 3         | 9         | 10         | 14         | 12         | 12         | 12           | 20           | 21         | 21           |
| Gabon                  | 1         | 1         | 1 2        | 1 2        | 1          | 1          | 1            | 1 3          | 1 3        | 1            |
| Gambia Ghana           | 2 3       | 2 5       |            | 34         | 2          | 2 66       | 3            | 95           | 98         | 3            |
| Guinea                 | 0         | 0         | 30 0       | 0          | 39 0       | 1          | 72 1         | 2            | 2          | 98 2         |
| Guinea Bissau          |           |           | 0          | 0          | 0          | 1          | 1            | 1            | 1          | 1            |
| Kenya                  | 7         | 17        | 31         | 36         | 46         | 107        | 127          | 147          | 218        | 307 0        |
| Lesotho Liberia        | 0 0       | 0 0       | 0 0        | 0 0        | 0 2        | 0 3        | 0 3          | 0            | 0          | 3            |
| Libya Madagascar       | 5         | 5         | 5          | 5          | 5          | 5          | 5            | 3 5          | 3 6        | 6            |
| Malawi                 | 5 5       | 7 8       | 9 12       | 11 12      | 13 19      | 33 26      | 33 80        | 33 82        | 33 141     | 33 143       |
| Mali                   | 3         | 4         | 5          | 5          | 7          | 7          | 8            | 59           | 89         | 229          |
| Mauritania             | 18        | 18        | 18         | 35         | 35         | 87         | 88           | 88           | 88         | 89           |
| Mauritius              | 3 13      | 3 13      | 19         | 26         | 33         | 75 16      | 99 17        | 108 19       | 110 30     | 110 30       |
| Mayotte Morocco        | 35        | 40        | 13 200     | 13 202     | 15 204     | 734        | 734          | 774          | 854        | 858          |
| Mozambique Namibia     | 5 15      | 7 16      | 10         | 13         | 15 75      | 56 99      | 56 151       | 61 151       | 64 151     | 108 176      |
| Niger                  | 5         | 6         | 21 7       | 36 8       | 9          | 27         | 27           | 27           | 27         | 62           |
| Nigeria                | 15        | 16        | 17         | 18         | 19         | 19         | 28           | 28           | 33         | 37           |
| Reunion                | 156       | 167       | 187        | 186        | 188        | 190        | 199          | 207          | 224        | 224          |
| Rwanda Sao Tome Prn    | 1 0       | 10        | 11         | 12         | 17         | 22 0       | 25 0         | 25 0         | 25         | 25           |
| Senegal                | 7         | 0 9       | 0 9        | 0 38       | 0 109      | 150        | 173          | 173          | 0 240      | 0 263        |
| Seychelles             | 0         | 1         | 1          | 2          | 3          | 4          | 5            | 7            | 13         | 18           |
| Sierra Leone Somalia   | 0         | 0 0       | 0 0        | 0 5        | 4 7        | 4 7        | 4 7          | 4 16         | 4 24       | 9 47         |
| South Africa Sudan     | 262       | 1 164     | 1 353      | 2 176      | 3 451      | 4 805      | 4 908        | 5 994        | 6 316      | 6 326        |
| South                  | 0         | 0         | 0          | 0          | 0          | 1          | 1            | 1 117        | 1          | 14 190       |
| Sudan                  | 15        | 17        | 20         | 26         | 36         | 59         | 80 15        |              | 136        |              |
| Tanzania Togo          | 4 0       | 11 0      | 13 0       | 12 0       | 13         | 17 4       | 5            | 15 7         | 15 57      | 15 57        |
| Tunisia                | 10        | 17        | 28         | 38         | 1          | 64         | 80           | 95           | 95         | 197          |
| Uganda                 | 19        | 20        | 22         | 24         | 47 44      | 67         | 78           | 88           |            | 94           |
| Zambia                 | 0         | 0         |            | 0          | 0          | 1          | 96           |              | 90 96      | 96           |
| Zimbabwe               | 2         | 3         | 0 3        | 3          | 5          | 9          | 12           | 96 14        | 28         | 41           |
| Asia                   | 36 225    | 60 691    | 90 581     | 140 489    | 211 853    | 276 406    | 332 854      | 410 326      | 485 413    | 597 573      |
| Afghanistan            | 17 94     | 18        | 19 147     | 20 164     | 22 196     | 22 218     | 31 269       | 31 317       | 31         | 33 537       |
| Bangladesh Bhutan      |           | 120 0     |            |            | 0          |            | 0            |              | 480        | 0            |
| Brunei                 | 0 1       | 1 9       | 0 1        | 0 1        | 1          | 0 1        | 1            | 0 1          | 0 5        | 5            |
| Darsm Cambodia China   | 6         |           | 12         | 18         | 29         | 29         | 124          | 315 964      | 376        | 456 032      |
| China HK SAR           | 17 759    | 28 399    | 43 549     | 77 819     | 130 832 1  | 175 262 1  | 204 971 89   | 253 91       | 306 973 95 | 393 95       |
| Chinese Taipei India   | 1         | 3         | 884 5 693  | 1 9        | 1 768 252  | 2 738 453  | 4 35         | 5 817 385    | 7          | 9 724 63 146 |
|                        | 410 599   | 636       |            | 245        | 98         | 65         | 150 203 155  | 185          | 700 684    |              |
| Indonesia              | 38        | 773 42    | 79         | 979 88     | 18         | 27         |              | 39           | 49         | 291          |
| Japan                  | 13 599 16 | 23 339 76 | 34 150 144 | 42 040 157 | 49 500 175 | 56 162 490 | 63 192 1 150 | 69 764 1 719 | 225 74 191 | 78 833       |
|                        |           |           | 23         |            |            |            |              |              | 1 923      | 2 031        |
| Kazakhstan Korea DPR   | 6         | 11        | 3 615      | 32 4       | 35 5 835   | 38 8       | 42           | 42           | 52         | 52 20 975    |
| Korea Rep Lao PDR      | 1 555 0   | 2 481     | 2          | 502 2      | 8          | 099 34     | 11 952 34    | 14 575 34    | 18 161 34  | 34           |
| Malaysia               | 139       |           | 266        |            | 394        | 545        | 894          | 1 483        | 1 787      | 1 933        |
|                        |           | 2 205     |            | 344 7      | 11         | 16         | 21           | 27           | 31         | 36           |
| Maldives Mongolia      | 2 5       | 4 5       | 5 5        | 15         | 48         | 64         | 89           |              |            | 195          |
|                        | 4         |           | 21         |            | 44         | 48         | 88           | 95 84        | 95 80      | 103          |
| Myanmar                | 11        | 6 12      | 13         | 32 14      | 55         | 55         | 54           | 70           |            | 117          |
|                        |           |           |            |            |            |            |              |              | 97         |              |
| Nepal                  |           |           |            |            |            |            |              |              |            |              |

## Solar energy Énergie solaire Energía solar

| CAP (MW)                  | 2013      | 2014     | 2015     | 2016           | 2017     | 2018      | 2019         | 2020      | 2021       | 2022        |
|---------------------------|-----------|----------|----------|----------------|----------|-----------|--------------|-----------|------------|-------------|
| Pakistan                  | 101       |          |          |                | 655      |           |              |           | 1          | 1 243       |
| Philippines               | 3         | 165 28   | 266 173  | 590 784        | 908      | 680 917   | 755 982      | 854 1 058 | 077 1 377  | 1 625       |
| Singapore                 | 12        | 25       | 46       | 97             | 116      | 161       | 272          | 333       | 487        | 572         |
| Sri Lanka                 | 13        | 22       | 37       | 80             | 156      | 231       | 351          | 431       | 624        | 714         |
| Tajikistan Thailand       | 829       | 1 304    | 1 425    | 2 451          | 2 702    | 2 967     | 2 988        | 0 2 988   | 0 3 065    | 0 3 065     |
| Timor Leste               | 1         | 1        | 1        | 1              | 0        | 0         | 0            | 0         | 0          | 0           |
| Uzbekistan                | 1         | 1        | 1        | 2              | 3        | 4         | 4            | 4         | 104        | 253         |
| Viet Nam                  | 5         | 5        | 5        | 5              | 8        | 105       | 4 993        | 16 660    | 16 660     | 18 474      |
| C America + Carib         | 277       | 333      | 1 031    | 1 238          | 1 605    | 1 976     | 2 495        | 2 799     | 3 581      | 3 987       |
| Anguilla                  | 0         | 1        | 1        | 2              | 2        | 1         | 2            | 2         | 2          | 2           |
| Antigua Barb              | 0         | 0        | 3        | 4              | 4        | 9         | 9            | 13        | 13         | 13          |
| Aruba Bahamas             | 2 1       | 5        | 6 1      | 6 1            | 6 1      | 14 1      | 14 2         | 14 2      | 14 2       | 14 3        |
| Barbados                  | 0         | 1 1      | 3        | 15             | 16       | 17        | 33           | 49        | 64         | 69          |
| Belize                    | 0         | 0        | 0        | 0              | 1        | 1         | 7            | 7         | 7          | 7           |
| BES Islands               |           |          | 0        | 2              | 5        | 6         | 7            | 7         | 7          | 7           |
| Br Virgin Is              | 0         | 0        | 1        | 1              | 1        | 1         | 1            | 1         | 1          | 1           |
| Cayman Is                 |           |          |          | 3              | 9        | 10        | 11           | 13        | 14         | 14          |
| Costa Rica                | 13        | 17       | 22       | 24             | 28       | 28        | 48           | 57        | 74         | 74          |
| Cuba                      | 11        | 22       | 24       | 37             | 65       | 128       | 159          | 217       | 246        | 258         |
| Curacao                   | 3         | 8        | 10       | 11             | 11       | 12        | 15           | 16        | 16         | 16          |
| Dominica Dominican Rep    | 0 8       | 0 15     | 0 25     | 1 73           | 1 106    | 0 205     | 0 315        | 0 386     | 0 594      | 0 742       |
| El Salvador               | 13        | 13       | 24       | 25             | 121      | 198       | 403          | 478       | 643        | 664         |
| Grenada                   | 1         | 1        | 1        | 2              | 2        | 3         | 3            | 4         | 4          | 4           |
| Guadeloupe                | 67        | 67       | 67       | 68             | 70       | 70        | 81           | 85        | 86         | 90          |
| Guatemala                 | 3         | 10       | 93       | 93             | 99       | 101       | 101          | 101       | 101        | 105         |
| Haiti                     | 1         | 2        | 2        | 2              | 3        | 3         | 3            | 3         | 3          | 3           |
| Honduras Jamaica          | 5         | 5 4      | 396 7    | 417            | 454 56   | 514 56    | 518 93       | 525 93    | 529 93     | 529 93      |
| Martinique                | 2 62      | 63       | 65       | 28 67          | 68       | 71        | 76           | 76        | 78         | 78          |
| Montserrat                | 1         |          |          |                |          | 14        | 0 16         | 0 16      | 1          | 1 16        |
| Nicaragua Panama          | 4         | 1 6      | 1 49     | 1 93           | 14 147   | 188       | 219          | 229       | 16 462     | 522         |
| Puerto Rico               | 74        | 79       | 209      | 244            | 302      | 305       | 337          | 381       | 488        | 639         |
| St Barth                  |           |          |          | 0              | 0        | 0         | 0            | 0         | 0          | 0           |
| St Kitts Nevis            | 1         | 1        | 1        | 1              | 1        | 1         | 1            | 2         | 2          | 2           |
| St Lucia                  | 0         | 0        | 1        | 1              | 1        | 4         | 4            | 4         | 4          | 4           |
| St Martin St Vincent Gren | 1 0       | 2 0      | 3        | 2 1            | 0 1      | 0 1       | 1            | 1 3       | 1 4        | 1           |
| Trinidad Tobago           | 4         | 4        | 1 4      | 4              | 4        | 4         | 2 4          | 4         | 4          | 4 4         |
| Turks Caicos US Virgin Is | 1         | 5        | 0 9      | 0 9            | 0 5      | 0 10      | 1 10         | 1 10      | 1 10       | 1 10        |
| Eurasia                   | 21        | 48       | 316      | 937            | 3 678    | 5 652     | 7 358        | 8 243     | 9 761      | 11 618      |
| Armenia                   |           |          |          | 1              | 2        | 17        | 50           | 106       | 217        | 306         |
| Azerbaijan Georgia        | 1         | 2        | 5        | 25             | 28       | 35        | 33           | 35        | 48         | 51          |
| Russian Fed               | 1         | 5        | 61       | 0 76           | 1 225    | 1 535     | 3 276        | 5 1 428   | 18 661     | 18          |
| Türkiye                   | 19        | 41       | 250      | 834            | 3 422    | 5 064     | 1 5 996      | 6 668     | 1 7 817    | 1 816 9 426 |
| Europe                    | 84 189    | 91 095   | 99 604   | 106 173        | 112 299  | 121 603   | 142 272      | 162 795   | 190 143    | 227 799     |
| Albania                   | 1         | 1 0      | 1        | 1              | 1        |           | 14           | 21        | 23         | 29          |
| Andorra Austria           |           |          | 0        | 0              | 0        | 1 1       | 2 702        | 3         | 4 783      | 4           |
| Belarus                   | 626       | 785      | 937 6    | 1 096 47       | 1 269 80 | 1 455     | 1            | 2 043     | 2 160      | 548 269     |
| Belgium                   | 902       | 4 015    |          |                | 621      | 154       | 154 637      | 160 5 573 | 6          | 3 6 898     |
| Bosnia Herzg              | 2 1       | 3 7      | 3 132 8  | 3 329 14 1 030 | 3 16     | 4 000 1   | 4            | 35        | 012        | 107         |
| Bulgaria                  | 1 039 19  | 1 029 33 | 1        | 56             | 1 031    | 18        | 22 1         | 1         | 57 1       | 948         |
| Croatia                   |           |          | 028      |                | 60       | 033 68    | 044 85       | 100       | 275        | 1 182       |
| Cyprus                    | 35        | 64 067   | 48 76    |                | 110      |           | 151          | 109 229   | 138        | 464         |
| Czechia                   | 2 064 571 | 2 607    | 2 075    | 84 2           | 075 906  | 118       | 2 1          | 2 1       | 315 2      | 2 627 2 490 |
| Denmark                   |           |          | 782      | 068 851        | 2        | 2 081 998 | 111          | 172 304   | 246 1 704  |             |
| Estonia                   | 2         |          | 7        | 10             | 15       | 32        | 080 121      | 208       | 395        | 535         |
| Faroe Islands             |           |          |          |                |          |           |              |           | 0          | 0           |
| Finland                   |           | 3        |          |                | 82       |           |              | 0         | 425        | 591         |
| France                    | 9 5 277   | 11 6 034 | 17 7 138 | 39 7           | 8 610    | 140 9 672 | 0 222 10 817 | 318 065   | 14         | 419         |
| Germany                   | 36 710    | 37 900   | 39 224 2 | 702 40 679     | 42 293 2 | 45 158    | 48 914       | 12 53 671 | 819 59 373 | 17 66 554   |
| Greece                    | 2 579     | 2 596    | 604      | 2 604          | 606      | 2 652     | 2 834        | 3 288     | 4 277      | 5 557       |
| Hungary                   |           |          | 172      | 235            | 344      | 728       | 1 400        | 2 131     | 2 968      | 2 988 7     |
| Iceland                   |           | 89       |          | 4              | 4        |           | 7            |           |            |             |
|                           | 35        |          | 3        |                | 17       | 5         | 58           |           |            | 135         |
| Ireland                   | 1 1       | 1 2      | 2        |                |          | 32 20 114 |              | 7 90      | 7          |             |
|                           | 190       |          |          | 6 289          | 688      |           | 20 871       | 656       | 22         |             |
|                           |           | 600      |          | 19             |          |           |              | 21        | 135 600    | 083         |
| Italy                     |           |          |          |                |          |           |              |           |            | 25          |
|                           |           | 18       | 18 907   |                | 19       |           |              |           |            |             |
|                           | 18        |          |          |                |          |           |              |           |            |             |

## Solar energy Énergie solaire Energía solar

| CAP (MW)               | 2013 2014   | 2015                | 2016      | 2017         | 2018           | 2019            | 2020           | 2021         | 2022             | 2022             |
|------------------------|-------------|---------------------|-----------|--------------|----------------|-----------------|----------------|--------------|------------------|------------------|
| Kosovo*                |             | 0                   |           | 7            |                |                 |                |              |                  |                  |
| Latvia 1               |             |                     | 2         | 1            | 7 2            | 10 3            | 10 5           | 10 7         | 10 56            | 10 56            |
| Lithuania              | 68          | 69 69               | 70        | 74           | 82             | 103             | 164            | 255          | 568              | 568              |
| Luxembourg             | 95          | 110 116 75          | 122 94    | 128 112      | 131 132        | 160 155         | 187 188        | 277 206      | 319 206          | 319 206          |
| Malta Moldova Rep      | 29          | 55 1 1              | 2         | 2            | 3              | 5               | 4              | 14           | 19               | 19               |
| Montenegro             | 1           | 2 3 007             |           | 3            | 4              | 5               | 6              | 7            | 26               | 26               |
| Netherlands            | 650 1       | 1 526               | 3 2 135   | 2 911        | 4 608 7        | 226             | 11 108         | 14 911       | 22 590           | 22 590           |
| North Macedonia Norway | 7           | 15 17 13 15         | 17 27     | 17 45        | 21 68          | 26 120          | 94 160         | 94 205       | 94               | 94               |
| Poland                 | 11 2        | 27 108              | 187       | 287          | 562            | 1 539           | 3 955          | 7 416        | 321 11 167       | 321 11 167       |
| Portugal               | 296 1       | 415 447 1 326       | 513 1 372 | 579 1 374    | 667 1 386      | 901 1 398       | 1 100 1 383    | 1 646 1 394  | 2 536            | 2 536            |
| Romania                | 761         | 293 16              |           | 18           | 21             |                 | 31             |              | 1 414            | 1 414            |
| Serbia                 | 10          | 13 533              | 17        |              |                | 23              |                | 52           | 137              | 137              |
| Slovakia Slovenia      | 533 187 223 | 533 238             | 533       | 528 247      | 472 247        | 590 278         | 535 370        | 537 461      | 537 632          | 537 632          |
| Spain                  | 7 001       | 7 008               | 233 7 017 | 027          | 7 068          | 11 111          | 12 440         | 019          | 20 518           | 20 518           |
| Sweden                 | 6 994       | 60 104              | 153       | 7 244        | 428            | 714             | 1 107          | 16           | 2 606            | 2 606            |
| Switzerland            | 43 1        | 061 1 394           | 1 664     | 1 906        | 2 173          | 2 498           | 2 973          | 1 606 3 449  | 4 134            | 4 134            |
| UK                     | 756 2 937   | 528 9 601           | 11 914    | 760          | 13 059         | 13 224          | 13 462         | 799          |                  |                  |
| Ukraine                | 748         | 5 819 841           | 955       | 12 1 200     | 2 003          | 5 936           | 7 331          | 13 8 062     | 14 412 8 062     | 14 412 8 062     |
| European               | 80 051      |                     | 91 890    | 96           |                |                 |                | 164 675      | 200 647          | 200 647          |
| Union (27)             | 83 976 633  | 88 080              |           | 627          | 104 459        | 120 645         | 138 941        |              | 12               | 12               |
| Middle East Bahrain 6  | 1 5         | 884 1 103 5         | 1 610     | 2 236 6      | 3 461 6        | 6 261 9         | 7 433 10       | 9 681        | 882 11 12        | 882 11 12        |
| Iran IR                | 1 30        | 9 9                 | 43        | 184          | 286            | 346             | 430            | 456          | 539 42           | 539 42           |
| Iraq Israel            | 446         | 37 37 656 796       | 37 906    | 37 1 006     | 37 1 346       | 37 2 138        | 37             | 37 3 591     | 4 411            | 4 411            |
| Jordan                 | 0           | 0 6                 | 287       | 397          | 700            | 1 186           | 2 652 1 448    | 1 521        | 1 914 93         | 1 914 93         |
| Kuwait                 | 0           | 3                   |           | 32           | 43             | 93              | 93             | 93           |                  |                  |
| Lebanon                | 2           | 2 5 11              | 31 24     | 37           | 55             | 76              | 90             | 190          | 440 638          | 440 638          |
| Oman 2                 | 1           | 1 2                 |           | 8 35         | 8              | 9               | 112            | 138          | 192              | 192              |
| Palestine 5            | 1 2         | 3 12 4 4            | 25        | 5            | 40 5           | 82 5            | 117 5          | 178 5        | 805              | 805              |
| Qatar Saudi Arabia     | 22          | 24 24               | 24        | 34           | 84             | 109             | 109            | 439          | 440 60           | 440 60           |
| Syrian AR              |             |                     |           | 0 355        | 1              | 2               | 12             | 33           | 040              | 040              |
| United Arab Em         | 126 2       | 133 134 60          | 141 80    | 100          | 598            | 1 918 250       | 2 061 257      | 2 733        | 3 257            | 3 257            |
| Yemen                  |             | 5                   |           |              | 250            |                 |                | 257          |                  |                  |
| N America 731          | 13 645      | 129 27              | 38        | 828          |                | 69 656          | 86 493         | 107 192      | 126 443          | 126 443          |
| Canada 2 665           | 1 210       | 20 1 843 2          | 043 519   | 47           | 57 664         | 3 327           | 3 342 0        | 3 630 1      | 4 401 1 9 026    | 4 401 1 9 026    |
| Greenland 633          | 109 12 326  | 174                 | 287       | 2 932 1 126  | 3 095 0 2 582  | 0 4 742 61      | 6 709 76 441   | 8 171 95     | 113 015          | 113 015          |
| Mexico USA 434 860     | 4 610       | 18 112 24 237 6 079 | 35 6      | 43 770 7 576 | 51 987 13      | 587 293         | 18 357         | 391 23 342   | 27 400           | 27 400           |
| Oceania Amer Samoa 4   | 2           | 5 358 2             | 6 689     | 4 7          | 8 881 5        | 5 12 970        | 5 17 986       | 5 22         | 5 26             | 5 26             |
| Australia              | 4 568       | 5 287 5 2           | 2 946 3   | 354 3        | 8 626 5        | 6               | 6              | 870 6        | 792 6            | 792 6            |
| Cook Is 3              | 1           |                     |           | 8            | 8              |                 | 9              |              | 9                | 9                |
| Fiji 6 Fr              | 1           | 2 4 25 28           | 32 35     | 35           | 37             | 8 41            | 45 41          | 9 46         | 46               | 46               |
| Polynesia Guam         | 17          | 32                  |           | 36           | 38             | 40              |                | 43           | 105              | 105              |
| Kiribati 3             | 1           | 1 1 2 1             |           | 3 2          |                |                 | 3              | 3            | 3                | 3                |
| Marshall 2             | 1           | 1 1                 |           | 2            | 3 2            | 3 2             | 2 3            | 2 3          | 2                | 2                |
| Is Micronesia 2 1      | 1 1         | 1 0 0               |           |              | 2              | 3               |                |              | 3 3              | 3 3              |
| Nauru New Caledon 9    | 0 3         | 3 7                 | 53        | 1            | 1              | 2 59 117        | 2 74           | 3 77         | 75               | 75               |
| New Zealand            |             | 22 37               |           | 26           | 28             |                 | 144 1          | 237          | 1                | 1                |
| Niue 0                 | 9 0         | 0 0                 |           | 70 0 2       | 91 0 3         | 1 3             | 3              | 1            | 303              | 303              |
| Palau 2 1              | 1           | 1 1 1               |           | 1            | 1              | 3               |                | 4            | 4 4              | 4 4              |
| Papua N Guin Samoa 7   | 0           | 0 5                 |           |              |                | 14 2            | 3              | 4 14         | 14               | 14               |
| Solomon Is 2           | 0           | 3 1 1 1             |           | 14           | 14             | 1               | 14             | 2 1          | 4                | 4                |
| Tokelau                | 1           | 3                   |           | 3 1          |                |                 | 2 1 7          |              | 1                | 1                |
| 1                      | 1           | 1                   |           | 7            | 3 1 7          | 7               |                |              | 14               | 14               |
| Tonga 4                | 3           | 4 2                 |           |              |                | 2 5             |                | 7            | 2                | 2                |
| Tuvalu Vanuatu         | 0 0         | 0                   |           |              |                |                 |                | 2            | 5                | 5                |
|                        |             | 0                   |           | 2 3          | 2              |                 |                |              |                  |                  |
| S America              | 198         | 0                   |           | 2 2          | 4              |                 | 2 5            | 5 795        |                  |                  |
|                        |             | 465                 | 9         | 3 672        | 5 512          | 562             | 164            |              | 773              | 773              |
|                        |             |                     | 921       | 589 9        |                | 8               | 13             | 20           | 32               | 32               |
|                        |             |                     | 1         |              | 191            | 442             | 764 120        | 1 071 170    | 1 104            | 1 104            |
| Argentina Bolivia 6    | 8           | 8 6 6 46            | 128       | 9 8 1 207    | 70 2 435 2 137 | 120 4 635 2 654 | 8 291 3 205 86 | 14 197 4 468 | 170 24 079 6 250 | 170 24 079 6 250 |
| Brazil Chile           | 6           | 21 576              | 1         | 1 809 11 26  |                |                 |                | 184          | 457              | 457              |
| Colombia 2             | 13          | 221 1               | 125 26    |              | 13 27          | 26 28           | 28             | 28           |                  |                  |
| Ecuador                | 15          |                     |           |              |                |                 |                |              | 29               | 29               |
|                        | 1 4         | 1 26 26             |           | 0            | 0              | 0               |                | 0            | 0                | 0                |
| Falklands              |             |                     |           | 47           |                | 47              | 0 55           |              | 55               | 55               |
|                        | 37          |                     |           |              |                |                 |                |              |                  |                  |
|                        |             |                     |           |              |                |                 |                |              | 55               |                  |
|                        |             |                     |           |              | 47             |                 |                |              |                  |                  |
|                        |             | 37                  |           |              |                |                 |                |              |                  |                  |
|                        |             | 0 47                |           |              |                |                 |                |              |                  |                  |
|                        |             |                     | 0 47      |              |                |                 |                |              |                  |                  |
| Malv Fr Guiana         |             |                     |           |              |                |                 |                |              |                  |                  |

## Solar energy Énergie solaire Energía solar

| CAP (MW)   |   2013 |   2014 |   2015 |   2016 |   2017 |   2018 |   2019 |   2020 |   2021 |   2022 |
|------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Guyana     |      1 |      1 |      2 |      2 |      3 |      6 |      8 |      8 |      8 |      8 |
| Paraguay   |      0 |      0 |      0 |      0 |      0 |      0 |      0 |      0 |      0 |      0 |
| Peru       |    109 |    130 |    135 |    146 |    298 |    324 |    335 |    335 |    332 |    332 |
| Suriname   |      1 |      6 |      6 |      7 |      8 |      9 |      9 |      9 |      9 |     12 |
| Uruguay    |      2 |      4 |     64 |     89 |    243 |    248 |    253 |    258 |    266 |    270 |
| Venezuela  |      2 |      3 |      5 |      5 |      5 |      4 |      5 |      5 |      5 |      5 |

## Solar photovoltaic Solaire photovoltaïque Solar fotovoltaica

| CAP (MW)                      | 2013          | 2014           | 2015           | 2016            | 2017             | 2018           | 2019           | 2020           | 2021             | 2022           |
|-------------------------------|---------------|----------------|----------------|-----------------|------------------|----------------|----------------|----------------|------------------|----------------|
| World                         | 136 572       | 176 113        | 224 070        | 296 112         | 390 878          | 483 495        | 585 868        | 713 918        | 855 162          | 046 614        |
| Africa                        | 651           | 1 544          | 1 917          | 3 030           | 4 675            | 7 165          | 8 408          | 9 734          | 10 543           | 11 556         |
| Algeria                       |               | 3              | 66 e           | 305 e           | 398 e            | 423 e          | 423 e          | 423 e          | 423 e            | 435 u          |
| Angola                        | 11 e          | 12 e           | 13 e           | 13 e            | 13 e             | 13 e           | 13 e           | 13 e           | 13 e             | 297 e          |
| Benin Botswana                | 2 e           | 0 2 e          | 1 2 e          | 3 3 e           | 3 3 e            | 3 4 e          | 3 e 6 e        | 3 e 6 e        | 3 e 6 e          | 28 e 6 e       |
| Burkina Faso                  | 6 e           | 7 e            | 8 e            | 10 e            | 47 e             | 62 e           | 62 e           | 62 e           | 62 e             | 92 e           |
| Burundi Cabo Verde            | 3 e           | 3 e 6          | 3 e            | 4 e             | 5 e              | 5 e 8 e        | 5 e 8 e        | 5 e e          | 13 e 8 e         | 13 e           |
| Cameroon                      | 6 4 e         | 6 e            | 6 7 e          | 6 9 e           | 6 12 e           | 14 e           | 14 e           | 8 14 e         | 14 e             | 8 e 14 e       |
| Cent Afr Rep                  | 0 e           | 0 e            | 0 e            | 0 e             | 0 e              | 0 e            | 0              | 0 e            | 0 e              | 0 e            |
| Chad                          | 0 e           | 0 e            | 0 e            | 0 e             | 0 e              | 0 e            | 0 e            | 1 u            | 1 e              | 1 e            |
| Comoros Congo DR              | 0 e           | 1 e            | 1 e            | 3 u             | 5 u              | 20 e           | 20 e           | 20 e           | 20 e             | 4 20 e         |
| Congo Rep                     | 0 e           | 0 e            | 0 e            | 0 e             | 1 e              | 1 e            | 1 e            | 1 e            | 1 e              | 1 e            |
| Cote d Ivoire                 | 3 e           | 4 e            | 5 e            | 5 e             | 8 e              | 13 e           | 13 e           | 13 e           | 13 e             | 13 e           |
| Djibouti                      | 0 e           | 0 e            | 0 e            | 0 u             | 0 u              | 0 u            | 0 u            | 0 e            | 0 e              | 0 e            |
| Eq Guinea                     |               |                |                | 0 e             | 0 e              | 0 e            | 0 e            | 0 e            | 0 e              | 0 e            |
| Eritrea Eswatini              | 0 e 1 e       | 8 e 1 e        | 8 e 1 e        | 9 e             | 11 e             | 12 e           | 12 e           | 12 e           | 11 e             | 11 e           |
| Ethiopia                      | 3             | 9              | 10             | 1 e 14          | 1 e 12           | 1 e 12         | 1 e 12         | 1 e 20         | 11 e 21          | 11 e 21 e      |
| Gabon                         | 1 e           | 1 e            |                | e               | 1 e              |                | 1 e            | 1 e            | 1 e              |                |
| Gambia                        | 2 e           | 2 e            | 1 e 2 e        | 1               | 2                | 1 e            |                | 3 e            | 3 e              | 1 e 3 e        |
| Ghana                         | 3 o           | 5 o            | 30 o           | 2 e 34 o        | e 39 o           | 2 e 66 o       | 3 e 72 o       | 95 o           | 98 o             | 98 o           |
| Guinea Guinea Bissau          | 0 e           | 0 e            | 0 e 0 e        | 0 e 0 e         | 0 e              | 1 e            | 1 e            | 2 e            | 2 e              | 2 e 1 e        |
| Kenya                         | 7 e           | 17 e           | 31 e           | 36 e            | 0 e 46 e         | 1 o 107 e      | 1 e 127 e      | 1 e 147 e      | 1 e              | 307 e          |
| Lesotho                       | 0 e           | 0 e            | 0 e            | 0 e             | 0 e              | 0 e            | 0 e            | 0 e            | 218 e 0 u        | 0 e            |
| Liberia                       | 0 u           | 0 u            | 0 u            | 0 u             | 2 u              | 3 u            | 3 e            | 3 e            | 3 e              | 3 e            |
| Libya Madagascar              | 5 u 5 e       | 5 u 7 e        | 5 u 9 e        | 5 u 11 e        | 5 u 13 e         | 5 e 33         | 5 e 33 e       | 5 e 33 e       | 6 u 33 e         | 6 e 33 e       |
| Malawi                        | 5 e           | 8 e            | 12 e           | 12 e            | 19 e             | 26 e           | 80 e           | 82 e           | 141 e            | 143 e          |
| Mali                          | 3 e           | 4 e            | 5 e            | 5 e             | 7 e              | 7 e            | 8 e            | 59 e           | 89 e             | 229 e          |
| Mauritania                    | 18 o 3 e      | 18 o           | 18 o           | 35 o            | 35 o             | 87 u           | 88 u           | 88 e           | 88 e             | 89 e 110 e     |
| Mauritius Mayotte             | 13            | 3 e 13         | 19 e 13        | 26 e 13 o       | 33 e 15 o        | 75 e 16        | 99 e 17        | 108 e 19       | 110 e 30         | 30             |
| Morocco                       | 15            | 20             | 20             | 22              | 24 o             | 194 o 56 e     | 194 o 56 e     | 234 61 o       | 314 e 64 o       | 318 e 108 o    |
| Mozambique                    | 5 e           | 7 e            | 10 e           | 13 e e          | 15 e             | 99 u           | 151 u          | 151 e          | 151 e            | 176 e          |
| Namibia Niger                 | 15 e 5 e      | 16 e           | 21 e           | 36              | 75 e             | 27 u           | 27 u           | 27 e           | 27 e             | 62 e           |
| Nigeria                       | 15 e          | 6 e 16 e       | 7 e            | 8 e 18          | 9 u 19 e         | 19 u           | 28 e           | 28 e           | 33 e             | 37 e           |
| Reunion                       | 156 o         | 167 o          | 17 e           | e 186 o         | 188 o            | 190 o          | 199 u          | 207 e          | 224 e            | 224 e          |
| Rwanda                        | 1 e           | 10 e           | 187 o 11 e     | 12 e            | 17 e             | 22 e           | 25 e           | 25 e           | 25 e             | 25 e           |
| Sao Tome Prn                  | 0 e           | 0 e            | 0 e            | 0 e             | 0 e              | 0 e            | 0 e 173 e      | 0 e            | 0 e              | 0 e            |
| Senegal Seychelles            | 7 e           | 9 e            | 9 e            | 38 e            | 109 e 3 e        | 150 e 4 e      | 5 e            | 173 e 7 e      | 240 e 13 e       | 263 e 18 e     |
| Sierra Leone                  | 0 o 0 u       | 1 o 0 u        | 1 o 0 u        | 2 o 0 u         | 4 u              | 4 u            | 4 e            | 4 e            | 4 u              | 9 e            |
| Somalia                       |               | 0 e            | 0 e            | 5 e             | 7 e              | 7 e            | 7 e            | 16 u           | 24 u             | 47 u 5         |
| South Africa                  | 262 e 0 e     | 1 064 e        | 1 253 e        | 1 976 e         | 3 151 e          | 4 405 e        | 4 408 e 5 1 u  | 494 e 1 e      | 5 816 e          | 826 e 14 u     |
| South Sudan Sudan             | 15 u          | 0 e 17         | 0 e            | 0 u u           | 0 u              | 1 e 59 u       | 80 u           | 117 u          | 1 u 136 u        | 190 e          |
| Tanzania                      | 4 e           | u 11 e         | 20 u 13 e      | 26 12 e         | 36 u 13 e        | 17 e           | 15 e           | 15 e           | 15 e             | 15 e           |
| Togo Tunisia                  | 0 e           | 0 e 17 e       | 0 e            | 0 e             | 1 e              | 4 e            | 5 e 80 u       | 7 o            | 57 u 95 e        | 57 e 197       |
|                               | 10 e          | e              | 28 e           | 38 e            | 47 e             | 64 e           | 78 e           | 95 e           |                  | e              |
| Uganda Zambia                 | 19 e 0 e      | 20 0 e         | 22 e 0 e       | 24 e 0 e e      | 44 e 0 e         | 67 e 1 e       | 96 e           | 88 e 96 e      | 90 e 96 o        | 94 e 96        |
| Zimbabwe                      | 2 e           | 3              | 3              |                 |                  |                | 12             |                | 28               | u 41 e         |
|                               |               |                |                | 3               | 5 e              | 9              | e              | 14 e           |                  |                |
| Asia                          |               |                |                |                 |                  | e              |                |                | e                |                |
|                               | 36 055        | e 60 346       | e 90 236       | 140 125         | 211 488          | 275 827        | 332 111        | 409 433        | 484 496 31 e     | 596 530 33 e   |
| Afghanistan Bangladesh Bhutan | 17 e 94 e 0 e | 18 e 120 e 0 e | 19 e 147 e 0 e | 20 e 164 e 0 e  | 22 e 196 e 0 e   | 22 e 218 e 0 e | 31 e 269 e 0 e | 31 e 317 e 0 e | 480 e 0 e        | 537 e 0 e      |
| Brunei Cambodia               | 1 6           | 1 u 9          | 1 u 12 e       | 1 18            | 1 u 29 e         | 1 u 29 e       | 1 u 124 e      | 1 u 315 e      | 5 u 376 e        | 5 u 456        |
| Darsm China                   | e             | e 388          |                | u e             |                  |                | 575 e          | 418 o          | 403 e            | e 436 e        |
| China HK SAR                  | 17 748        | 28             | 43 538         | 77 788          | 130 801 1        | 175 016 1      | 204 89         | 253 91         | 306 95           | 392 95         |
| Chinese Taipei                | 410 o         | 636 o          | 884 o          | 1 245 o 9 651 e | 1 768 o 17 923 e | 2 738 o        | 4 150 o        | 5 817 o        | 7 700 o 49 342 e | 9 724 o        |
| India Indonesia               | 1 446 e 38 e  | 3 444 e 42 e   | 5 365 e 79 e   | 88              | 98 e             | 125 e 65 o     | 34 861 e 155 o | 043 e 185 o    | 225 o            | 62 804 e 291 o |
| Japan                         | 13 599        | 23 339         | 34 150         | e 42 040        | 49 500           | 27 56 162      | 63 192         | 39 69 764 o    | 74 191 o         | 78 833 o       |
| Kazakhstan                    | 16 6 u        | 76 11          | 144 23         | 157 32          | 175 35 u         | 490 o          | 1 150 e        | 1 719          | 1 923 e          | 2 031 52 e     |
| Korea DPR                     |               |                |                |                 | 5 835            | 38 u           | 42 u           | 42 e           | 52 e             |                |
| Korea Rep                     | 1 555         | u 2 481        | u 3 615        | u 4 502 o e     | 8 e              | 8 099          | 11 952         | 14 575 o       | 18 161 o         | 20 975         |
| Lao PDR                       | 0 e           | 2 e            | 2 e            | 2               |                  | 34 e           | 34 e           | 34 e           | 34 e             | o 34 e 1 933 e |
| Malaysia                      | 139 o 2       | 205 e 4        |                | 344 e 7 o       | 394 e 11 o       | 545 e 16       | 894 e 21 u     | 1 483 e 27 u   | 1 787 e          | 36 o           |
| Maldives                      |               |                | 266 e 5        |                 |                  |                |                |                | 31 u             |                |
| Mongolia                      | o 5 4         | o 5            | o 5 e          | 15              | 48 e             | o 64 e         | 89 e 88 u      | 95 84 e        | 95 80            | 95 103         |
| Myanmar                       | e o 11 o      | e 6 12         | 21 o           | e 32 14         | 44 o 55 e        | 48 o 55        | 54 e           | 70 e           | 97               | 117            |
|                               |               | o o            | 13 o           | o e             |                  | e 680 e        |                |                | e e e            | e e            |
| Nepal Pakistan                | 101 e         | e              | 266 e          | 590             | 655 e            |                | 755            | 854            | 1 077            | 243 e          |
|                               |               |                |                | e               |                  |                |                | e              |                  |                |
|                               |               |                |                |                 |                  |                | e              |                |                  |                |
|                               |               | 165            |                |                 |                  |                |                |                | 1                | 1              |

## Solar photovoltaic Solaire photovoltaïque Solar fotovoltaica

| CAP (MW)                        | 2013    | 2014      | 2015       | 2016       | 2017       | 2018       | 2019       | 2020        | 2021       | 2022       |
|---------------------------------|---------|-----------|------------|------------|------------|------------|------------|-------------|------------|------------|
| Philippines                     | 3       |           |            | 784        | 908 o      | 917        | 982        | 1           | 1 377 e    | 1 625 o    |
| Singapore                       | o 12 o  | 28 o 25 o | 173 o 46 o | o 97 o     | 116 o      | o 161 o    | o 272 o    | 058 o 333 o | 487 o      | 572 o      |
| Sri Lanka                       | 13 e    | 22 e      | 37 e       | 80 e       | 156 e      | 231 e      | 351 e      | 431 e       | 624 e      | 714 e      |
| Tajikistan                      | 824     | 1 299     | 1 420      | 2 446      | 2 697      | 2 962 o    | 2 983 o    | 0 2 983 o   | 0 3 060 o  | 0 3 060 e  |
| Thailand Timor Leste            | 1 u     | 1 u       | 1 u        | 1 u        | 0 u        | 0 u        | 0 u        | 0 u         | 0 u        | 0 u        |
| Uzbekistan                      | 1       | 1         | 1          | 2          | 3          | 4          | 4 e        | 4 e         | 104 e      | 253        |
| Viet Nam                        | 5 e     | 5 e       | 5 e        | 5 e        | 8 e        | 105 e      | 4 993 e    | 16 660 e    | 16 660 e   | 18 474 e   |
| C America + Carib               | 277     | 333       | 1 031      | 1 238      | 1 605      | 1 976      | 2 495      | 2 799       | 3 581      | 3 987      |
| Anguilla                        | 0 e     | 1 e       | 1 e        | 2 e        | 2 e        | 1 e        | 2 e        | 2 e         | 2 e        | 2 e        |
| Antigua Barb                    | 0       | 0         | 3          | 4 e        | 4 e        | 9 e        | 9 e        | 13 e        | 13 e       | 13 e       |
| Aruba                           | 2 e     | 5 e       | 6          | 6          | 6          | 14 e       | 14 e       | 14 e        | 14 e       | 14 e       |
| Bahamas Barbados                | 1 e 0 u | 1 e       | 1 e        | 1 e 15     | 1 e 16 u   | 1 e 17 u   | 2 e 33 u   | 2 e 49 u    | 2 e 64 u   | 3 u 69 u   |
| Belize                          | 0 u     | 1 u 0 u   | 3 u 0 u    | u 0 u      | 1 u        | 1 u        | 7 u        | 7 e         | 7 e        | 7 u        |
| Islands                         |         |           |            |            |            |            | 7 o        |             |            |            |
| BES                             |         |           | 0          | 2 o        | 5 o        | 6 o        |            | 7 o         | 7 o        | 7 o        |
| Br Virgin Is                    | 0 o     | 0 o       | 1 o        | 1 o        | 1 o        | 1 o        | 1 o 11 u   | 1 o         | 1 o        | 1 o        |
| Cayman Is Costa Rica            | 13 o    | 17 o      | 22 o       | 3 u 24 o   | 9 u 28 o   | 10 u 28 o  | 48 e       | 13 o 57 e   | 14 74 e    | 14 74 e    |
| Cuba                            | 11      | 22        | 24         | 37         | 65 u       | 128 u      | 159 u      | 217 u       | 246        | 258 e      |
| Curacao                         | 3 o     | 8 o       | 10 o       | 11 o       | 11 o       | 12 o       | 15 o       | 16 o        | 16 o       | 16 o       |
| Dominica                        | 0       | 0         | 0          | 1          | 1          | 0 e        | 0 e        | 0 e         | 0 e        | 0 e        |
| Dominican Rep                   | 8       | 15        | 25         | 73         | 106        | 205        | 315 o      | 386 o       | 594 e      | 742 e      |
| El Salvador                     | 13 e    | 13 e      | 24 e       | 25 e       | 121        | 198        | 403 o      | 478 e       | 643 e      | 664 e      |
| Grenada                         | 1 o     | 1 o       | 1 o        | 2          | 2          | 3 o        | 3 o        | 4           | 4 e        | 4 e        |
| Guadeloupe                      | 67 3 e  | 67        | 67         | 68         | 70         | 70 o       | 81 o       | 85 o        | 86 101 e   | 90 105 e   |
| Guatemala                       |         | 10 e      | 93 e       | 93 e       | 99 e       | 101 e      | 101 e      | 101 e       |            |            |
| Haiti                           | 1 e     | 2 e       | 2 e        | 2 e        | 3 e        | 3 e        | 3 e 518 e  | 3 e         | 3 e        | 3 e        |
| Honduras                        | 5 e 2 e | 5 e 4 e   | 396 e 7 e  | 417 e 28 e | 454 e      | 514 e 56 e | 93 e       | 525 e 93 e  | 529 e 93 e | 529 e 93 e |
| Jamaica Martinique              | 62      | 63 o      | 65         | 67         | 56 e       | 71         | 76         | 76          | 78         | 78         |
| Montserrat                      |         |           |            |            | 68         |            | 0 u 16 o   | 0 e         | 1          | 1 e        |
| Nicaragua Panama                | 1 o 4   | 1 6       | 1 49       | 1 93       | 14 o 147 o | 14 o 188 e | 219 u      | 16 o 229 e  | 16 e 462 o | 16 e 522 e |
| Puerto Rico                     | 74 o    | 79 o      | 209 o      | 244 o      | 302 e      | 305 o      | 337 o      | 381 e       | 488 e      | 639 e      |
| St Barth                        |         |           |            | 0 o        | 0 o        | 0 o        | 0 e        | 0           | 0 e        | 0 e e      |
| St Kitts Nevis St Lucia         | 1 o 0   | 1 e       | 1 e        | 1 e        | 1 e        | 1 e        | 1 e 4      | 2 e         | 2 e        | 2 4        |
|                                 |         | 0         | 1          | 1          | 1          | 4 u        | e          | 4 o         | 4 e        | 1          |
| St Martin                       | 1       | 2         | 3          | 2 o        | 0 o        | 0 e        | 1 o        | 1           | 1          |            |
| St Vincent Gren Trinidad Tobago | 0 4     | 0         | 1          | 1 4        | 1 4        | 1 e        | 2          | 3           | 4 4        | 4          |
| Turks Caicos                    |         | 4         | 4 o        | e          | u          | 4          | 4 u        | 4           | e          | 4 e        |
| US Virgin Is                    | 1 e     | 5 e       | 0 9 e      | 0 9 e      | 0 5 e      | 0 u 10     | 1 10       | 1 e 10      | 1 10       | 1 10 e     |
| Eurasia                         | 20      | 47        | 315        | 936        | 3 677      | 5 651      | 7 357      | 8 242       | 9 760      | 11 617     |
| Armenia                         | 1       |           |            | 1          | 2          | 17 35      | 50 33      | 106 35      | 217 48     | 306 51     |
| Azerbaijan Georgia              |         | 2 u       | 5          | 25 0 u     | 28 u       | o o 1 u    | o 3 u      | 5           | 18         | 18         |
| Russian Fed                     | 1 u     | 5 e       | 61         | 76         | 1 u 225 e  | 535 e      | 1 276 e    | e 1 428     | e 1 661 e  | 1 816      |
| Türkiye                         | 18      | 40        | e 249      | e 833      | 3 421 o    | 5 063      | 5 995      | 6 667       | 7 816      | 9 425      |
| Europe                          | 81 878  | 88 783    | 97 292     | 103 861    | 109 987    | 119 291    | 139 951    | 160 474     | 187 822    | 225 478    |
| Albania                         | 1 e     | 1 e 0 o   | 1 e 0      | 1 0        | 1 0        | 1 e 1 o    | 14 2 o     | 21 3        | 23 4       | 29 4       |
| Andorra Austria                 |         |           | o 937      | o 096      | o          |            | 702        | o           | e          | 548        |
| Belarus                         | 626     | 785 4     | 6          | 1 47       | 1 269 80   | 1 455 154  | 1 154      | 2 043 160   | 2 783 160  | 3 269      |
| Belgium                         | 2 902 o | 015       | 132        | 329 14     | 3 621      | 000 18     | 4 637 22   | 5 573       | 6 012      | 6 898      |
| Bosnia Bulgaria                 | 1 1 039 | 3 7 o 029 | 3 8 o      | 3 o 1 030  | 16 031     | 033        | 1 044      | 35 o 1 100  | 57         | 107        |
| Herzg Croatia                   | 19      | 1 33      | 1 028 48   | 56         | 60         | 4 o 68     | 85         |             | 1 275 138  | 1 948 182  |
|                                 |         |           |            | 84         | 110        | 1 118      | 151        | 109         |            |            |
| Cyprus                          | 35      | 64        | 76         |            | 1          | 081        | 2 111      | 229         |            | 464        |
| Czechia                         | 064 571 | 2 067 607 | 075        | 2          | 075 906    | 2 998      | 1          | 2 172 1 304 | 315 1      | 2 627 490  |
|                                 | 2       |           | 2 782      | 851        | 2          |            |            |             |            | 2          |
| Denmark Estonia                 | 2       | 3         | u          | 068 10     | 15         | o 32       | 080 121    | 208         | 2 246      | 535        |
| Faroe                           | u       | u         | 7          |            |            |            | 0          | 0           | 704 395 0  | 0          |
| Islands                         |         |           |            |            | 82         |            |            | 318         | e          |            |
| Finland France                  | 9 5 277 | 11 034    | 17 7 138   | 39 7       | 8 610      | 140 672    | 222 10 808 | o 056       | 425 14 810 | 591 17 410 |
| Germany                         | 36 708  | 6 37 898  | 39 222     | 702 677    | 291        | 9 45 156   | 48 912     | 12 53 669   | 59 371     | 66 552     |
| Greece                          | 2 579   | 2 596     | 2 604      | 40 2 604   | 42 2 606   | 2 652      | 2 834      | 3 288       | 4 277      | 5 557      |
| Hungary                         | 35      | 89        |            | 235        | 344        | 728        | 1 400      | 2 131       | 2 968      | 2 988      |
| Iceland                         | 1       | 1         | 172 3      | 4          | 4          | 5          | 7          | 7           | 7          | 7          |
|                                 |         |           |            |            | 17         |            | 58         |             |            | 135        |
| Ireland                         | 1       | 2         | e 2        | e 6        | e          | 32         |            | 90          | 135        |            |
|                                 |         | e         |            |            |            | e          | e o        | e e         | e e        |            |
|                                 | e       |           | 18         |            |            |            | 20         |             |            |            |
|                                 | 185     |           |            | 19         |            |            | 865        | 21          |            |            |
| Italy                           | 18      |           |            |            | 682        | 108        |            | 650         |            |            |
|                                 |         |           |            |            |            |            |            |             |            | 25 077     |
|                                 |         | 18 594    | 901        | 283        | 19         | 20         |            | 22 594      |            |            |

## Solar photovoltaic Solaire photovoltaïque Solar fotovoltaica

| CAP (MW)                      | 2013                 | 2014               | 2015           | 2016              | 2017               | 2018                              | 2019                   | 2020                      | 2021                      | 2022                |
|-------------------------------|----------------------|--------------------|----------------|-------------------|--------------------|-----------------------------------|------------------------|---------------------------|---------------------------|---------------------|
| Kosovo*                       |                      |                    | 0 o            | 2                 | 7                  | 7 o                               | 10                     | 10 e                      | 10                        | e 10                |
| Latvia                        |                      |                    |                | 1                 | 1                  | 2                                 | 3                      | 5                         | 7                         | 56                  |
| Lithuania Luxembourg          | 68 95                | 69 110             | 69 116         | 70 122            | 74 128             | 82 131                            | 103 160                | 164 187                   | 255 277                   | 568 319             |
| Malta                         | 29                   | 55                 | 75             | 94                | 112                | 132                               | 155                    | 188                       | 206                       | 206                 |
| Moldova Rep o                 |                      | 1                  | 1              | 2                 | 2 o                | 3                                 | 5                      | 4                         | 14                        | 19                  |
| Montenegro                    | 1 e                  | 2 e                | 3              | 3 e               | 3                  | 4                                 | 5                      | 6                         | 7                         | e 26                |
| Netherlands                   | 650                  | 1 007 1            | 526            | 2 135             | e 2 911 4          | 608 7                             | 226                    | 11 108                    | 14 911                    | 22 590              |
| North Macedonia               | 7                    | 15                 | 17             | 17                | 17                 | 21                                | 26 o                   | 94                        | 94                        | e 94                |
| Norway Poland                 | 11 u 2               | 13 u 27            | 15 u 108       | 27 u 187          | 45 u 287           | 68 562                            | 120 1 539              | 160 3 955                 | 205 7 416                 | 321 11 167          |
| Portugal                      | 296                  | 415                | 447            | 513               | 579                | 667                               | 901                    | 1 100                     | 1 646                     | 2 536               |
| Romania                       | 761 1                | 1 293              | 1 326 e        | 1 372             | 374 1 18           | 386 21 e                          | 1 398                  | 1 383                     | 1 394 52                  | 1 414               |
| Serbia                        | 10 e                 | 13 e               | 16             | 17 e              | e                  |                                   | 23 e                   | 31                        |                           | 137 537             |
| Slovakia Slovenia             | 533 187              | 533 223            | 533 238        | 533               | 528 247            | 472 247                           | 590 278                | 535 370                   | 537                       | 632                 |
| Spain                         | 4                    | 4 697              | 704            | 233 4             | 723                | 764                               | 807                    |                           | 461                       |                     |
|                               | 4 690                |                    | 4              | 713               |                    | 4                                 | 8                      | 10 136                    | 13 715                    | 18 214              |
| Sweden                        | 43                   | 60                 | 104            | 153               | 244                | 428                               | 714                    | 1 107                     | 1 606                     | 2 606               |
| Switzerland UK                | 756 1                | 1 061              | 1 394          | 1 664             | 906 o              | 2 173 059                         | 2 498 224              | 2 973 o                   | 3 449                     | e 4 134             |
|                               | 2 937 748            | 819                | 9 601 o        | 11 914 o          | 760 1 200 o        | 003 o                             | 13 5 936 o             | 13 462 o                  | 13 799                    | 14 412              |
| Ukraine                       |                      | 5 528 o            | 841            | 955               | 12                 | 13 2                              |                        | 7 331                     | 8 062                     | u 8 062             |
| European Union (27)           | 77 740               | 81 664             | 85 767         | 89 578            | 94 315             | 102 147                           | 118 323                | 136 620                   | 162 354                   | 198 326             |
| Middle East 527               | 2 130                | 778                | 996            | 1 504 6           | 3 6                | 305 5 813 6 u                     | 6 9 o                  | 990 10 o                  | 9 239 11 u                | 12                  |
| Bahrain Iran IR               | 1 e 1                | 5 u 9              | 5 e 9          | u 43              | e 184 o            | 286 e                             | 346 e                  | 430 e                     | 456 e                     | 539 e 42            |
| Iraq                          | 30 o 440             | 37 o               | 37 e           | 37 e              | 37 e               | 37 e                              | 37 e                   | 37 e                      | 37 e                      | e                   |
| Israel Jordan                 | 1 0 o                | 650 0 o            | 790 6 o        | 900 287 u         | 000 1 397 u        | 340 1 700 u                       | 890 1 186 u            | 2 410 1 448 u             | 3 349 1 521 e             | 4 169 1 914 e       |
| Kuwait                        | 0 o                  | 2 o                | o              | o                 | o                  | 43                                | 43 o                   |                           | 43                        | 43 e                |
| Lebanon                       | 2 e                  | 5 e                | 3 11 e         | 31 24 e           | 32 37 e            | 55 o                              | 76 o                   | 43 e 90 e                 | e 190 o                   | 440 e               |
| Oman                          | 1 u                  | 1 e                | 2 e            | 2                 | 8                  | 8                                 | 9 e                    | 112 e                     | 138                       | 638 e 192           |
| Palestine                     | 1                    | 3 4                | 12             | e 25              | e 35               | e 40                              | 82 o                   | 117 e                     | e 178 e                   | e 805               |
| Qatar                         | 2 u                  | u 24 e             | 4 e 24         | 5 u               | 5 e                | 5 e 34 e                          | 5 e 59                 | 5 e 59                    | 5 e 389 e                 | u 390               |
| Saudi Arabia Syrian AR        | 22 u                 |                    | e              | 24 e              | 34 e 0 u           | 1 u                               | e 2 u                  | e 12                      | 33                        | e 60                |
| United Arab Em                | 26 e                 | 33 e o             | 33 e           | 40 e              | 255 u e            | 498 o                             | 1 818 o                | 1 961 u                   | 632 e e                   | 2 940 u             |
| Yemen                         | 2 o                  | 5                  | 60 o           | 80 o              | 100                | 250                               | 250 e                  | 257                       | 257                       | 257                 |
| N                             |                      |                    |                |                   |                    | u                                 |                        | e                         | 2                         | e                   |
| America                       | 12 358               | 18 463             | 25 285         | 36 973            | 46 070             | 55 890                            | 67 881                 | 84 728                    | 105 695                   | 124 946             |
| Canada 1 210 Greenland Mexico | 2 932 109 o 11 039 o | 1 843 174 o 16 445 | 2 519 287 o    | 2 665 633 o       | 3 1 126 o 42 012 o | 095 3 327 0 o 2 566 o 50 229 o    | 3 0 o 4 725 o 59 829 o | 342 u 0 6 692 o 74 693 o  | 3 630 8 154 o 93 911 o    | 1 9 009 o 111 535 o |
| USA o Oceania                 | 4 607                | o 5 355            | 22 479 o 6 076 | 33 676 6 857      | 7 574              | 8 878 13 290                      |                        | 18 354                    | 23 339                    | 27 397              |
| Amer Samoa                    | 2 o                  | 2 o 5 284          | 2 o            | 4 6               | 4 e 7 352          | 5 e 8                             | 5 e 12 967             | 5 e 17 983                | 5 e 22 867                | 5 e 26 789          |
| Australia                     | 4 565                |                    | 5 943          | e 686 3 e         | 3 e                | 623 u                             | 6 u                    |                           | 6 e                       | u 6                 |
| Cook Is                       | 1 e 1 u              | 2 e 2 u            | 3 e u          | 6 u               | 8 u                | 5 8 u                             | 8                      | 6 e 9 u                   | 9                         | e 9 u               |
| Fiji                          |                      | 25 o               | 4 o            | 32 o              | 35                 | 37 o                              | u 41 o                 | 45 o                      | u 46 e                    | 46                  |
| Fr Polynesia                  | 17 o 1 o             | 1 o                | 28 32 o        | 35                | o 36 e 3 u         | 38                                | 40 e                   | 41 e                      | 43                        | e 105 e             |
| Guam Kiribati                 | 1 o                  | 1 u                | 2 u            | o 3 u             |                    | e 3 e                             | 3 e                    | 3 e                       | e 3 e                     | 3                   |
| Marshall Is                   | 1 e                  | 1 e 1              | 1 e e          | 2 2               | 2 e 2              | 2 e 2                             | 2 e 3                  | 2 e                       | 2 e 3 e                   | e 2 e               |
| Micronesia Nauru              | 1 e 0 e              | e                  | 1 0            | e 1               | e 1                | u 1                               | e 2 e                  | 3 e 2 e                   | 3                         | 3 e 3 e             |
| New Caledon                   | 3 o                  | 0 e o              | e 7            | e e 9             | e 26               | e 28                              | 59 o                   | 74 o                      | e 77                      | 75 o                |
| New Zealand                   | 9                    | 3                  | o 37           | o 53              | o 70 0 e           | o 91                              | 117 1 u                | 144                       | o 237 o                   | 303                 |
| Niue                          | 0 e                  | 22 0 e 1           | 0              | 0 e 2 u           | 2 u                | 0 3                               | 3 u                    | 1 e                       | 1                         | o 1                 |
| Palau                         | 1 o                  | u                  | e 1            | 1 u               | 1                  | e e 1 u                           | 3 e                    | 3 e 3                     | e 4 e 4 e                 | e 4                 |
| Papua N                       | 0 e                  | e                  | u 1            |                   | 14                 |                                   |                        | 14                        |                           | e 4 14              |
| Guin Samoa                    | 0 e 1 e              | 0 3 e 1            | u 5 1          | 7 2               | u e 3 e            | 14 e 3 e                          | 14 e 2 e               | e 2                       | 14 e 2 e                  | e 4                 |
| Solomon Is                    |                      | e                  | e 1            | 1                 | 1 e                | 1 e                               | 1 e                    | e e 1 e                   | 1 e                       | e e 1 e             |
| Tokelau                       | 1 u                  | u                  | e              | e e               | 7 o                |                                   |                        | 7 e                       |                           | 14                  |
| Tonga                         | 3 o                  | 1 o                | u 4 o 2        | u 4 2             | 2                  | 7 u                               | 7 e 2 e                | 2 e                       | 7 2                       | 2                   |
| Tuvalu                        | 0 o                  | 3 o                | 0              | o 2               | o 3 e              | 2 e 4 u                           | 5 u                    | 5 u                       | e 5                       | e 5                 |
| Vanuatu                       | 0 e                  | 0 0 e              | o              | o                 |                    |                                   |                        |                           | e                         | e e                 |
| S                             | 198                  | 465                | e              | e 589             |                    |                                   |                        | 164                       | u                         |                     |
|                               |                      |                    | 921            |                   | 672 9 e            | 512                               | 562                    |                           | 687                       | 665                 |
| America                       |                      | 8                  |                | 1                 | 3                  | 5                                 | 8                      | 13                        | 20                        | 32                  |
|                               |                      | o                  | 9 o            | 9 o               |                    | 191 e                             | 442 o                  | 764 e                     | 1 071 e 170 e             | 1 104 170 e 24 e    |
| Argentina Bolivia Brazil      | 8 o 6 e 8 1 1        | 6 e 21 e 221       | 6 e 46 e 576   | 6 e 128 e 1 125 2 | e 207 e 2 809 o 11 | 70 o 120 435 e 4 635 2 137 o 2 13 | o o 8 654 o 3 26 28 o  | 120 e 291 o 205 o 86 28 o | 14 197 4 360 o 184 e 28 o | o 079 6 142 457     |
| Chile Colombia Ecuador        | 13 e 15 1            |                    | 1 26 o         | 26 o              | 26 o               | 27                                |                        |                           |                           | o 29                |
|                               | 4 o                  |                    |                |                   | 0 o                |                                   |                        |                           |                           |                     |
|                               |                      | 1 26 o             |                | 0                 |                    | e                                 |                        | 0 e                       | 0                         | o 0                 |
| Falklands                     | 37 o                 |                    | 0              |                   |                    | 0                                 | 0                      |                           |                           | e                   |
| Fr Guiana                     |                      |                    | 47             | 47 o              | 47 o               | o 47 o                            | e 47 o                 | 55 e                      | 55                        |                     |
|                               |                      | 37                 |                |                   |                    |                                   |                        |                           |                           |                     |
| Malv                          |                      |                    |                |                   |                    |                                   |                        |                           |                           |                     |
|                               |                      |                    | o o            |                   |                    |                                   |                        |                           |                           |                     |
|                               |                      | o                  |                |                   |                    |                                   |                        |                           |                           |                     |
| 55                            | 55                   | 55                 | 55             | 55                | 55                 | 55                                | 55                     | 55                        | 55                        | 55                  |
|                               | e                    |                    |                | o                 |                    |                                   |                        |                           |                           |                     |

## Solar photovoltaic Solaire photovoltaïque Solar fotovoltaica

| CAP (MW)   | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   |
|------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Guyana     | 1      | 1      | 2      | 2      | 3      | 6 e    | 8 e    | 8 e    | 8 e    | 8 e    |
| Paraguay   | 0 o    | 0 o    | 0 o    | 0 o    | 0 o    | 0 o    | 0 o    | 0 e    | 0 e    | 0 e    |
| Peru       | 109 e  | 130 e  | 135 e  | 146 e  | 298 e  | 324 o  | 335 o  | 335 e  | 332 o  | 332 e  |
| Suriname   | 1 e    | 6 e    | 6 e    | 7 e    | 8 e    | 9 o    | 9 e    | 9 e    | 9 e    | 12 e   |
| Uruguay    | 2 o    | 4 o    | 64 o   | 89 o   | 243 o  | 248 o  | 253 o  | 258 o  | 266 o  | 270 o  |
| Venezuela  | 2      | 3      | 5      | 5      | 5      | 4 e    | 5 o    | 5 e    | 5 e    | 5 e    |

## Concentrated solar power Solaire thermique à concentration Energía solar termoeléctrica

| CAP (MW)            | 2013    | 2014    | 2015    | 2016    | 2017    | 2018    | 2019    | 2020    | 2021    | 2022    |
|---------------------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
| World               | 3 942   | 4 599   | 4 850   | 4 970   | 5 069   | 5 811   | 6 377   | 6 511   | 6 375   | 6 501   |
| Africa              | 65      | 165     | 325     | 425     | 525     | 985     | 1 085   | 1 085   | 1 085   | 1 085   |
| Algeria             | 25 o    | 25 o    | 25 o    | 25 o    | 25 e    | 25 e    | 25 e    | 25 e    | 25 e    | 25 e    |
| Egypt               | 20      | 20      | 20      | 20      | 20 o    | 20 e    | 20 e    | 20 e    | 20 e    | 20 e    |
| Morocco             | 20      | 20      | 180     | 180     | 180 o   | 540     | 540     | 540     | 540 e   | 540 e   |
| South Africa        |         | 100 o   | 100 o   | 200 o   | 300 o   | 400 o   | 500 u   | 500 o   | 500 e   | 500 e   |
| Asia                | 170     | 345     | 345     | 365     | 365     | 580     | 744     | 894     | 918     | 1 044   |
| China               | 11      | 11      | 11      | 31 u    | 31 u    | 246 u   | 396 u   | 546 u   | 570 u   | 596 u   |
| India               | 154 u   | 329 u   | 329 u   | 329 u   | 329 u   | 329 u   | 343 u   | 343 u   | 343 u   | 343 e   |
| Korea Rep           | 0 e     | 0 e     | 0 e     | 0 e     | 0 e     |         |         |         |         |         |
| Mongolia            |         |         |         |         |         |         |         |         |         | 100     |
| Thailand            | 5       | 5       | 5       | 5       | 5       | 5 e     | 5 e     | 5 e     | 5 e     | 5 e     |
| Eurasia             | 1       | 1       | 1       | 1       | 1       | 1       | 1       | 1       | 1       | 1       |
| Türkiye             | 1 o     | 1 o     | 1 o     | 1 o     | 1 o     | 1 o     | 1 e     | 1 e     | 1 e     | 1       |
| Europe              | 2 311   | 2 312   | 2 312   | 2 312   | 2 312   | 2 312   | 2 321   | 2 321   | 2 321   | 2 321   |
| France              |         |         |         |         |         |         | 9 o     | 9 e     | 9 e     | 9       |
| Germany             | 2       | 2       | 2       | 2       | 2 e     | 2       | 2       | 2 e     | 2 e     | 2       |
| Italy               | 5 o     | 6 o     | 6 o     | 6 o     | 6 o     | 6 e     | 6 e     | 6 e     | 6 e     | 6       |
| Romania             |         |         |         |         | 0       | 0       | 0 e     | 0 e     |         |         |
| Spain               | 2 304   | 2 304   | 2 304   | 2 304   | 2 304   | 2 304   | 2 304   | 2 304 o | 2 304 o | 2 304   |
| European Union (27) | 2 311   | 2 312   | 2 312   | 2 312   | 2 312   | 2 312   | 2 321   | 2 321   | 2 321   | 2 321   |
| Middle East         | 106     | 106     | 106     | 106     | 106     | 156     | 448     | 442     | 442     | 442     |
| Israel              | 6 e     | 6 e     | 6 e     | 6 e     | 6 e     | 6 e     | 248 u   | 242 o   | 242 e   | 242 e   |
| Kuwait              |         |         |         |         |         |         | 50 e    | 50 e    | 50 e    | 50 e    |
| Saudi Arabia        |         |         |         |         |         | 50 u    | 50 e    | 50 e    | 50 e    | 50 e    |
| United Arab Em      | 100 o   | 100 o   | 100 u   | 100 u   | 100 u   | 100 e   | 100 e   | 100 e   | 100 e   | 100 e   |
| N America           |         |         |         |         |         | 1 774   |         |         | 1 497   |         |
|                     | 1 286   | 1 667   | 1 758   | 1 758   | 1 758   |         | 1 775   | 1 765   |         | 1 497   |
| Mexico              |         |         |         |         |         | 16      | 17      | 17      | 17      | 17 e    |
| USA                 | 1 286 o | 1 667 o | 1 758 o | 1 758 o | 1 758 o | 1 758 o | 1 758 o | 1 748 o | 1 480 o | 1 480 o |
| Oceania             | 3       | 3       | 3       | 3       | 2       | 3       | 3       | 3       | 3       | 3       |
| Australia           | 3       | 3       | 3       | 3       | 2       | 3       | 3       | 3       | 3 e     | 3 e     |
| S America           |         |         |         |         |         |         |         |         | 108     | 108     |

Chile

108

108

o

## Bioenergy Bioénergie Bioenergía

| CAP (MW)            | 2013        | 2014        | 2015        | 2016        | 2017    | 2018        | 2019         | 2020         | 2021         | 2022         |
|---------------------|-------------|-------------|-------------|-------------|---------|-------------|--------------|--------------|--------------|--------------|
| World               | 84 879      | 90 745      | 96 484      | 105 424     | 111 006 | 118 194     | 124 199      | 133 236      | 141 302      | 148 912      |
| Africa              | 1 256       | 1 356       | 1 440       | 1 502       | 1 581   | 1 735       | 1 746        | 1 757        | 1 847        | 1 847        |
| Angola              |             | 51          | 51          | 51          | 51      | 51          | 51           | 51           | 51           | 51           |
| Burkina Faso        | 0           | 0           | 1           | 1           | 1       | 1           | 1            | 1            | 1            | 1            |
| Burundi             | 4           | 4           | 4           | 4           | 4       | 4           | 4            | 4            | 4            | 4            |
| Chad Congo DR       | 2           | 2 0         | 2           | 2           | 2       | 2 3         | 2            | 2            | 2            | 2            |
| Congo Rep           | 0 12        | 12          | 0 12        | 0 12        | 2 12    | 12          | 3 12         | 3 12         | 3 12         | 3 12         |
| Egypt               | 67          | 67          | 67          | 67          | 67      | 67          | 79           | 79           | 123          | 123          |
| Eswatini            | 123         | 106         | 106         | 106         | 106     | 106         | 106          | 106          | 106          | 106          |
| Ethiopia            | 71          | 71          | 119         | 145         | 205     | 290         | 290          | 290          | 335          | 335          |
| Gabon               | 7           |             | 1           | 1           | 1       | 1           | 1 8          | 1            | 1            | 1            |
| Ghana Kenya         | 56          | 8 56        | 8 58        | 8 84        | 8 85    | 8           | 88           | 8 99         | 8 99         | 8 99         |
| Liberia             | 0           | 0           |             | 0           | 0       | 88          | 0            | 0            | 0            | 0            |
|                     |             |             | 0           |             |         | 0           |              |              |              |              |
| Madagascar Malawi   | 0 19        | 0 19        | 0 19        | 0 19        | 0 19    | 0 19        | 0 19         | 0 19         | 0 19         | 0 19         |
| Mali                | 32          | 40          | 40          | 40          | 40      | 40          | 40           | 40           | 40           | 40           |
|                     | 80          |             |             | 91          |         |             | 91           |              | 91           | 91           |
| Mauritius Morocco   | 1           | 80          | 91          | 7           | 91 7    | 91 7        | 7            | 91 7         | 7            | 7            |
| Mozambique          | 14          | 1 14        | 5 14        | 14          | 14      | 14          | 14           | 14           | 14           | 14           |
| Namibia             | 0           | 0           | 0           | 0           | 0       | 0           | 0            | 0            | 0            | 0            |
| Nigeria             | 8           | 9           | 9           | 10          | 10      | 10          | 10           | 10           | 10           | 10           |
| Reunion             | 44          | 44          | 45          | 46          | 46      | 87          | 87           | 87           | 87           | 87           |
| Rwanda              | 1           | 1           | 1           | 1           | 1       | 1           | 1            | 1            | 1            | 1            |
| Senegal             | 25          | 25          | 25          | 25          | 25      | 25          | 25           | 25           | 25           | 25           |
| Sierra Leone        |             | 34          | 34          | 34          | 34      | 34          | 34           | 34           | 34           | 34           |
| South Africa Sudan  | 246 199     | 246 199     | 251 199     | 256 199     | 260 199 | 265 199     | 265 199      | 265 199      | 265 199      | 265 199      |
| Tanzania            | 66          | 70          | 70          | 70          | 70      | 70          | 70           | 70           | 70           | 70           |
| Uganda              | 36          | 54          | 65          | 65          | 76      | 96          | 96           | 96           | 96           | 96           |
| Zambia Zimbabwe     | 43          | 43          | 43          | 43          | 43      | 43          | 43           | 43 100       | 43 100       | 43           |
|                     | 100         | 100         | 100         | 100         | 100     | 100         | 100          |              |              | 100          |
| Asia                | 18 550      | 21 210      | 24 018      | 30 345      | 33 663  | 37 596      | 41 806       | 49 636       | 57 240       | 63 370       |
| Bangladesh Cambodia | 3 28        | 4 36        | 5           | 5 32        | 5 52    | 5 53        | 5 53         | 5 45         | 5 43         | 5 52         |
| China               | 6 089       | 6 653       | 34 7 977    | 9 269       | 11 234  | 13 235      | 16 537       | 23 583       | 29 753       | 34 088       |
| China HK SAR        |             |             |             | 17          | 45      | 45          | 52           | 52           | 52           | 52           |
| Chinese Taipei      | 396         | 396         | 395         | 395         | 395     | 397         | 393          | 400          | 408          | 408          |
| India Indonesia     | 4 180 1 701 | 5 030 1 729 | 5 478       | 8 895 1 775 | 9 417   | 10 137      | 10 226 1 884 | 10 532 1 896 | 10 592 2 270 | 10 670 3 005 |
| Japan               | 1 514       | 1 630       | 1 734 1 901 | 2 213       | 1 849 2 | 1 875 3 033 | 3 506        | 4 099        | 4 592        | 5 476        |
| Kazakhstan          | 0           | 0           | 0           | 0           | 608 1   | 1           | 2            | 8            | 8            | 8            |
| Lao PDR             | 40          | 40          | 40          | 40          | 40      | 105         | 105          | 105          | 105          | 105          |
| Malaysia            | 1 045       | 1 431       | 1 555       | 1 526       | 800     | 810         | 883          | 891          | 900          | 900          |
| Maldives Myanmar    | 49          |             | 48          |             |         |             | 0 59         | 0 59         | 0 59         | 0 59         |
| Nepal               |             | 52 7        |             | 49 7        | 52      | 57          |              | 6            |              | 6            |
| Pakistan            | 7 269       | 325         | 7 333       | 375         | 7 375   | 7 433       | 7 433        | 433          | 6 433        | 433          |
| Philippines         | 131         | 143         | 233         | 259         | 276     | 341         | 393          | 513          | 519          | 633          |
| Singapore           | 160         | 183         | 205         | 210         | 211     | 219         | 206          | 198          | 206          | 275          |
| Sri Lanka           | 13          | 20 796      | 20 3        | 24          | 26      | 37          | 40 4         | 45           | 45           | 45           |
| Thailand            | 2 610       | 2           | 165         | 322         | 728     | 4 037       | 097          | 241          | 476          | 476          |
| Viet Nam            | 125         | 136         | 161         | 3 188       | 3 195   | 384         | 383          | 4 384        | 4 367        | 4 367        |
| C America + Carib   | 1 772       | 1 954       | 2 076       | 2 417       | 2 513   | 2 638       | 2 931        | 3            | 3 040        | 3 040        |
|                     |             |             |             |             |         |             |              | 039          |              |              |
| Aruba               | 28          | 2 28        | 2 28        | 2 28        | 2 36    | 2 36        | 2 36         | 2 36         | 2 36         | 2            |
| Belize Costa Rica   | 38          | 36          | 37          | 43          | 47 532  | 60          | 79           | 80           | 80           | 36 80        |
| Cuba Dominican Rep  | 470         | 499         | 530         | 495         | 47      | 554         | 842 47       | 951          | 951 47       | 951 47       |
| El Salvador         | 16 270      | 16 305      | 17 202      | 47 259      | 270     | 47 305      | 305          | 47 300       | 301          | 301          |
| Guadeloupe          |             |             |             |             | 31      | 35          | 35           |              |              | 35           |
| Guatemala           | 31          | 31          | 31 873      | 31 1 056    | 1 091   | 1           | 1            | 35 1 036     | 35           | 1 036        |
| Honduras            | 598 124     | 714 124     | 161         | 210         | 210     | 103 210     | 036 221      | 221          | 1 036        | 221          |
| Jamaica             |             |             |             | 32          | 32      |             |              |              | 221          | 32           |
| Martinique          | 32          |             | 32 3        |             | 3       | 32 40       | 32 40        | 32           | 32           | 40           |
| Nicaragua           | 2           | 32 2        |             | 3           | 177     | 179         |              | 40 220       | 40 220       |              |
| Panama              | 134 30      | 134 30      |             | 177         | 33 2    |             | 220 33 2     |              | 33           | 220 33       |
| Puerto Rico         |             |             | 134 27      | 32          |         | 33 2        |              | 33           |              | 5            |
| St Lucia            |             |             |             | 2 0         | 0       | 0           | 0            | 5 0          | 5 0          | 0            |

## Bioenergy Bioénergie Bioenergía

| CAP (MW)                   | 2013             | 2014         | 2015             | 2016       | 2017       | 2018             | 2019             | 2020         | 2021             | 2022             |
|----------------------------|------------------|--------------|------------------|------------|------------|------------------|------------------|--------------|------------------|------------------|
| Eurasia                    | 1 406            | 1 628        | 1 679            | 1 767      | 1 887      | 2 005            | 2 201            | 2 515        | 3 054            | 3 330            |
| Azerbaijan                 | 37               | 37           | 38               | 38         | 43         | 45               | 45               | 45           | 45               | 45               |
| Russian Fed                | 1 197            | 1 370        | 1 370            | 1 370      | 1 373      | 1 373            | 1 373            | 1 373        | 1 373            | 1 373            |
| Türkiye                    | 172              | 221          | 271              | 359        | 472        | 587              | 784              | 1 097        | 1 637            | 1 912            |
| Europe                     | 31 473           | 33 187       | 34 617           | 35 600     | 37 039     | 39 850           | 41 155           | 41 774       | 41 431           | 41 694           |
| Albania                    |                  |              |                  |            | 1          | 1                | 1                | 1            | 1                | 1                |
| Andorra                    | 5                | 5            | 5                | 5          | 5          | 5                | 5                | 5            | 5                | 5                |
| Austria                    | 1 507            | 1 411        | 1 396            | 1 393      | 1 290      | 1 271            | 1 249            | 1 251        | 1 171            | 1 171            |
| Belarus                    | 35               | 35           | 35               | 40         | 41         | 48               | 53               | 123          | 120              | 120              |
| Belgium                    | 965              | 913          | 943              | 923        | 912        | 887              | 906              | 922          | 817              | 828              |
| Bosnia Herzg               |                  |              |                  | 1          | 1          | 1                | 2                | 2            | 2                | 2                |
| Bulgaria                   | 34               | 40           | 54               | 57         | 52         | 69               | 57               | 48           | 47               | 47               |
| Croatia                    | 24               | 25           | 53               | 63         | 87         | 115              | 127              | 135          | 154              | 157              |
| Cyprus                     | 10               | 10           | 10               | 10         | 10         | 13               | 13               | 13           | 13               | 13               |
| Czechia                    | 690              | 745          | 771              | 773        | 802        | 782              | 830              | 846          | 854              | 854              |
| Denmark                    | 1 185            | 1 248        | 1 243            | 1 305      | 1 791      | 1 774            | 1 982            | 2 086        | 2 150            | 2 151            |
| Estonia                    | 261              | 278          | 281              | 281        | 281        | 259              | 273              | 296          | 296              | 318              |
| Faroe Islands Finland      | 1 952            | 1 977        | 1 987            | 2 009      | 2 230      | 2 230            | 2 227            | 0 2 706      | 0 2 711          | 0 2 719          |
| France                     | 1 409            | 1 465        | 1 534            | 1 660      | 1 712      | 1 937            | 2 011            | 1 931        | 2 044            | 2 051            |
| Germany                    | 7 964            | 8 202        | 8 429            | 8 660      | 8 982      | 9 662            | 9 994            | 10 320       | 9 825            | 9 880            |
| Greece                     | 46               | 47           | 51               | 58         | 64         | 82               | 88               | 97           | 109              | 109              |
| Hungary                    | 328              | 549          | 519              | 427        | 491        | 513              | 504              | 509          | 551              | 551              |
| Ireland                    | 66               | 70           | 70               | 72         | 103        | 103              | 107              | 107          | 108              | 108 3            |
| Italy Latvia               | 3 344 108        | 3 359 121    | 3 367 126        | 3 439 143  | 3 450 154  | 3 491 134        | 3 454 158        | 3 439        | 3 420            | 416 165          |
|                            |                  |              |                  |            |            |                  |                  | 156          | 152              |                  |
| Lithuania Luxembourg       | 64 23            | 71 23        | 71 24            | 72 25      | 79 36      | 104 36           | 105              | 116          | 116 56           | 118 56           |
| Malta                      | 3                | 3            | 3                | 5          | 5          | 5                | 56 5             | 56 5         | 5                | 5                |
| Moldova Rep                | 2                | 3            | 3                | 3          | 6          | 6                | 6                | 7            | 6                | 12               |
| Netherlands Macedonia      | 769              | 752          | 792              | 772 5      | 785        | 827              | 818              | 866          | 879              | 902 10           |
| North Norway               | 140              | 140          | 4 140            | 87         | 7 87       | 8 87             | 10 81            | 10 77        | 10 77            | 77               |
| Poland                     | 735              | 816 561      | 961              | 974        | 968 582    | 1 004            | 1 010            | 1 045        | 1 100            | 1 111 717        |
| Portugal Romania           | 551 46           | 94           | 577 118          | 587        |            | 648              | 702              | 715 165      | 717              | 142              |
| Serbia                     | 4                | 5            | 5                | 123        | 140 13     | 141 17           | 139 28           | 31           | 140 36           | 36               |
| Slovakia                   |                  |              |                  | 10         | 246        | 243              | 226              | 225          | 250              | 250              |
| Slovenia                   | 214 59           | 237          | 242              | 253        | 62         | 60               | 60               | 67           | 67               | 68               |
| Spain                      | 1 013            | 62 1 032     | 63 1 035         | 60 1 037   | 1 045      | 1 057            | 1 112            | 1 264 4      | 1 278            | 1 278            |
| Sweden                     | 4 013            | 4 483        | 4 716            | 4 850      | 822        | 5 021            | 5 299            | 560          | 4 474            | 4 474            |
| Switzerland                | 232              | 229          |                  |            | 4          | 242              | 241              | 245          |                  |                  |
| UK                         |                  |              | 240              | 241        | 242        | 869              |                  |              | 245              | 245              |
| Ukraine                    | 3 642 31         | 4 129 50     | 4 697 53         | 5 121 60   | 5 385 73   | 6 98             | 7 036 180        | 7 115 212    | 7 150 275        | 7 251 275        |
| European Union Middle East | 27 458 53        | 28 663 60    | 29 513 81        | 30 107 88  | 31 258 88  | 32 630 86        | 33 678 86        | 34 111 84    | 33 667 84        | 33 823 101       |
| Iran IR                    | 7                | 11           | 11               | 11         | 11         | 11               | 11               | 11           | 11               |                  |
| Israel                     | 14               | 17           | 28               | 28         | 28         | 28               | 28               | 26           | 26               | 11 26            |
| Jordan                     | 4                | 4            | 13               | 13         | 13         | 13               | 13               | 13           | 13               | 13               |
| Lebanon Palestine          | 2                | 2            | 2                | 9          | 9          | 7                | 7                | 7            | 7 0              | 7                |
| Qatar                      | 19               | 19           | 19               | 19         | 0 19       | 0 19             | 0 19             | 0 19         | 19               | 0                |
| Syrian AR                  | 7                | 7            | 7                | 7          | 7          | 7                | 7                | 7            | 7                | 19               |
| United Arab Em             | 1                |              | 1                | 1          |            |                  | 1                |              |                  | 7 18             |
| Yemen                      |                  | 1            |                  |            | 1          | 1                |                  | 1            | 1 0              | 0                |
|                            |                  |              |                  | 16 521     | 590        |                  |                  |              | 14 990           | 960              |
| N America                  | 15 217           | 15 692 2 651 | 16 334           | 2 696      | 16 2 779   | 16 379           | 15 692           | 15 537 2 674 |                  | 14               |
| Canada Mexico              | 2 398 542 12 277 | 627 12 414   | 2 628 736 12 969 | 925 12 901 | 973 12 838 | 2 792 971 12 616 | 2 668 971 12 053 | 974 11 889   | 2 674 982 11 334 | 2 682 982 11 296 |
| USA                        | 1 025            | 1 036        | 1 039            | 1 074      | 1 090      | 1 090            | 1 090            | 1 096        | 1 104            | 1 105            |
| Oceania                    |                  |              |                  | 864        |            |                  |                  |              |                  |                  |
| Australia                  | 817              | 824          | 826              | 42         | 864        | 864              | 864 54           | 875          | 876              | 877              |
| Fiji New                   | 42               | 42           | 42               |            | 54 0       | 54               |                  | 54           | 61               | 61 0             |
| Caledon New Zealand        | 0 144            | 0 148        | 0 149            | 0 146      | 150        | 0 150            | 0 150            | 0 144        | 0 144            | 144              |
| Papua N Guin Samoa         |                  |              |                  | 18         | 18         |                  |                  |              | 18               | 18 1             |
|                            | 18               | 18           | 18               |            |            | 18               | 18               | 18           |                  |                  |
| Solomon Is                 | 1                |              |                  | 1          | 1          |                  |                  | 1            | 1                | 1                |
|                            | 3                | 1            | 1 3              |            | 3          | 1                | 1                | 1            | 1                |                  |
| Vanuatu                    |                  | 3            |                  | 3          |            | 3                | 3                | 3            | 3                | 3                |

## Bioenergy Bioénergie Bioenergía

| CAP (MW)   | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   |
|------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| S America  | 14 128 | 14 623 | 15 202 | 16 111 | 16 555 | 16 816 | 17 492 | 17 799 | 18 511 | 19 465 |
| Argentina  | 246    | 228    | 254    | 243    | 241    | 217    | 298    | 307    | 281    | 278    |
| Bolivia    | 85     | 126    | 134    | 142    | 142    | 160    | 174    | 185    | 211    | 261    |
| Brazil     | 11 601 | 12 343 | 13 311 | 14 187 | 14 574 | 14 819 | 15 358 | 15 686 | 16 351 | 17 206 |
| Chile      | 1 267  | 926    | 466    | 463    | 466    | 467    | 502    | 452    | 438    | 490    |
| Colombia   | 187    | 215    | 237    | 257    | 310    | 320    | 320    | 329    | 397    | 397    |
| Ecuador    | 101    | 144    | 144    | 146    | 152    | 152    | 152    | 152    | 153    | 153    |
| Fr Guiana  | 2      | 2      | 2      | 2      | 2      | 2      | 5      | 5      | 5      | 5      |
| Guyana     | 51     | 51     | 51     | 42     | 42     | 42     | 42     | 42     | 42     | 42     |
| Paraguay   | 39     | 39     | 39     | 39     | 39     | 39     | 22     | 22     | 22     | 22     |
| Peru       | 131    | 131    | 133    | 160    | 170    | 174    | 195    | 195    | 187    | 187    |
| Suriname   |        |        | 2      | 2      | 2      | 2      | 2      | 2      | 2      | 2      |
| Uruguay    | 417    | 419    | 429    | 429    | 417    | 422    | 422    | 422    | 422    | 422    |

## Solid biofuels and renewable waste Biocombustibles solides et déchets renouvelables Biocombustibles sólidos y residuos renovables

| CAP (MW)                               | 2013          | 2014            | 2015             | 2016            | 2017                 | 2018                 | 2019                 | 2020                   | 2021                   | 2022                |
|----------------------------------------|---------------|-----------------|------------------|-----------------|----------------------|----------------------|----------------------|------------------------|------------------------|---------------------|
| World                                  | 68 727        | 73 259          | 78 242           | 86 295          | 91 243               | 97 317               | 102 293              | 110 052                | 117 852                | 124 979             |
| Africa                                 | 1 244         | 1 345           | 1 414            | 1 467           | 1 542                | 1 651                | 1 651                | 1 662                  | 1 707                  | 1 707               |
| Angola                                 |               | 51 e            | 51               | 51              | 51 e                 | 51 e                 | 51 e                 | 51 e                   | 51 e                   | 51 e                |
| Burundi                                | 4 o           | 4 e             | e 4 e            | e 4 e           | 4 e                  | 4 e                  | 4 e                  | 4 e                    | 4 e                    | 4 e                 |
| Chad                                   | 2 o           | 2 o             | 2 o              | 2 o             | 2 o                  | 2 o                  | 2 o                  | 2 o                    | 2 e                    | 2 e                 |
| Congo DR Congo Rep                     | 0 e 12 e      | 0 e             | 0 e              | 0 e e           | 2 e                  | 3 e                  | 3 e                  | 3 e                    | 3 e 12 e               | 3 e                 |
| Egypt                                  | 67            | 12 e 67         | 12 e 67          | 12 67           | 12 e 67              | 12 e 67              | 12 e 67              | 12 e 67 e              | 67 e                   | 12 e 67 e           |
| Eswatini                               | 123           | 106             | 106              | 106 e           | 106 e                | 106 e                | 106 e                | 106 e                  | 106 e                  | 106 e               |
| Ethiopia                               | 71            | 71              | 119              | 145             | 205                  | 290                  | 290 e                | 290                    | 335                    | 335 e               |
| Ghana                                  | 7 e           | 8               | 8 e              | 8 e             | 8 e                  | 8 e                  | 8 e                  | 8 e                    | 8 e                    | 8 e                 |
| Kenya                                  | 56 u          | e 56 u          | 56 u             | 82 u            | 83 u                 | 86 u                 | 86 u                 | 97 u                   | 97 u                   | 97 u                |
| Liberia                                | 0 u           | 0 u             | 0 e              | 0               | 0 e                  | 0 e                  | 0 e                  | 0 e                    | 0 e                    | 0 e                 |
| Madagascar                             | 0 o           | 0 o             | 0 o              | u 0 o           | 0 e                  | 0 e                  | 0 e                  | 0 e                    | 0 e                    | 0 e                 |
| Malawi                                 | 19 u          | 19 u            | 19 u             | 19 u            | 19 u                 | 19 u                 | 19 u                 | 19 u                   | 19 u                   | 19 u                |
| Mali                                   | 32 o          | 40 e            | 40 e             | 40 e            | 40 u                 | 40 e                 | 40 e                 | 40 e                   | 40 e                   | 40 e                |
| Mauritius                              | 77 o          | 77 o            | 87 o             | 87 o            | 87 o                 | 87 o                 | 87 e                 | 87 e                   | 87 e                   | 87 e                |
| Mozambique                             | 14 e          | 14 e            | 14 e             | 14 e            | 14 e                 | 14 e                 | 14 e                 | 14 e                   | 14 e                   | 14 e                |
| Namibia                                | 0             | 0               | 0                | 0 e             | 0 e                  | 0 e                  | 0                    | 0 e                    | 0 e                    | 0 e                 |
| Nigeria                                | 8 u           | 9 u             | 9 u              | 10 u            | 10 u                 | 10 u                 | 10 e                 | 10 e                   | 10 e                   | 10 e                |
| Reunion                                | 42 e          | 42 e            | 42 e             | 42 e            | 42 e                 | 42 e                 | 42 e                 | 42 e                   | 42 e                   | 42 e                |
| Rwanda                                 | 1 e           | 1 e             | 1 e              | 1 e             | 1 e                  | 1 e                  | 1 e                  | 1 e                    | 1 e                    | 1 e                 |
| Senegal                                | 25 e          | 25 e            | 25 e             | 25 e            | 25 e                 | 25 e                 | 25 e                 | 25 e                   | 25 e                   | 25 e                |
| Sierra Leone                           | 242 e         | 34 e            | 34 e             | 34 e            | 34 e                 | 34 e                 | 34 e 242 e           | 34 e                   | 34 e                   | 34 e 242 e          |
| South Africa                           |               | 242 e           | 242 e            | 242 e           | 242 e                | 242 e                |                      | 242 e                  | 242 e                  | 199 e               |
| Sudan                                  | 199 e 66 o    | 199 e           | 199 e            | 199 e           | 199 e                | 199 e                | 199 e 70 e           | 199 e                  | 199 u                  | 70 e                |
| Tanzania Uganda                        | 36 e          | 70 o 54 e       | 70 o             | 70 o 65 e       | 70 e 76 e            | 70 e 96 e            | 96 e                 | 70 e 96 e              | 70 e 96 o              | 96 e                |
| Zambia                                 | 43 e          | 43 e            | 65 e e           | 43 e            | 43 e                 | 43 e                 | 43 e                 | 43 e                   | 43 o                   | 43                  |
| Zimbabwe                               | 100 e         |                 | 43 100 e         | 100 e           | 100 e                | 100 e                | 100 e                | 100 e                  |                        | e 100 e             |
| Asia                                   | 900           | 100 e           | 22 685           | 28 829          | 930                  | 35 622               | 39 582               | 945                    | 100 e                  | 59 869              |
|                                        | 17            | 20 008          | 0 o              | 0 o             | 31 0 o               | 0 o                  | 0 o                  | 46 0 o                 | 53 963 0 o             | 0 o 51 u            |
| Bangladesh Cambodia China China HK SAR | 28 o 5 896    | 36 o 6 343      | 33 o 7 646 393 o | 31 o 8 920 393  | 51 o 10 780 28 393 o | 51 o 12 605 28 395 o | 51 e 15 738 28 391 o | 44 e 22 298 o 28 399 o | 42 e 28 042 o 28 407 o | 32 161 e 28 e 407 o |
| Chinese Taipei India                   | 396 o 4 175 o | 396 o           | 5 469 o          | o 8 885         | 405 o                | 124 o                | 212 o                | 518 o                  | 10 578 o               | 656 o               |
| Indonesia                              | 1 683 o       | 5 023 o 1 709 o | 1 679            | o 1 711         | 9 1 748 o            | 10 1 766 e           | 10 1 771 e           | 10 1 775 e             | 2 135 e                | 10 2 870 e          |
| Japan                                  | 1 504         | 1 615           | o 1 878          | o 2 179         | 2 561                | 2 974                | 3 436                | 4 022 o                | 4 507 o                | 5 382 o             |
| Korea Rep                              | 93            | 124             | 255              | 1 256           | 1 853                | 1 899                | 2 056                | 1 730 e                | 1 940 e                | 1 846 e             |
| Lao PDR                                | 40            | 40 o            | 40 o             | 40 o            | 40 e                 | 105 o                | 105 e                | 105 e                  | 105 e                  | 105 e               |
| Malaysia                               | o 1 030 o     | 1 413           | 1 o              | 1 468 o         | 738 o                | 740 e                | 780 e                | 780 e                  | 780 e                  | 780 e               |
| Maldives Myanmar                       | 47 e          | o               | 535              | 48              |                      |                      | 0 o 57 e             | 0 e 57 e               | 0 e                    | 0 e 57 e            |
| Nepal                                  | 7             | 51 e 7          | 46 e 7           | 7               | 51 e 7 e             | 55 e 7 e             | 7 e                  | 6 e                    | 57 e 6                 | 6                   |
| Pakistan                               | e 260         | e 316           | e 324            | e e             |                      | 423 e                | 423 e                | 423 o                  | e 423                  | e 423               |
| Philippines                            | e 100 o       | e 112 o         | e 202 o          | 365 e 219 o     | 365 e 235 o          | 287 o                | 339 o                | 457 o                  | e 463 o                | e 578               |
|                                        | 160 e 13      | 183 e 20 o      | 205 e 20         | 210             | 211 e                | 219 e                | 206 e 40 o           | 198 e 45 o             | 206 e 45 u             | o 275 e 45 e        |
| Singapore Sri Lanka                    | o             | o               |                  | e 24            | 26 o                 | 37 o                 |                      |                        |                        |                     |
| Thailand Viet Nam                      | 2 345 o 125 e | 485 136 e       | o 793 o 161 e    | o 2 887 o 186 e | 253 o 186 e          | 532 o 375 e          | 567 o 374 e          | 3 684 o 375 e          | 841 o e                | 3 841 e 358 e       |
|                                        |               | 2               |                  |                 |                      |                      | 3                    |                        | 3 358                  |                     |
|                                        |               |                 | 2                |                 | 3                    | 3                    |                      |                        |                        |                     |
| C America + Carib                      | 1 759         | 1 941           | 2 059            | 2 386           | 2 478                | 2 597                | 2 889                | 2 993                  | 2 995                  | 2 995               |
| Aruba Belize                           | 28            | 2 28            | 2 28             | 2 28            | 2 36                 | 2 36                 | 2 36                 | 2 e 36 u               | 2 e 36 u               | 2 e 36 u            |
| Costa Rica Cuba                        | 34 470        | 34 498          | 34 530           | u 40 495        | u 45 532 e           | u 57 o 554           | u 76 o 841           | 76 e 951 e             | 76 e 951               | 76 e 951 e          |
| Dominican                              | 15 e          | 15 e            | o 15 e           | o 45 e          | 45 e                 | e 45 e 298           | e 45 e               | 45 e                   | e 45                   | 45 e                |
| Rep El Salvador                        | 263           | 298 31          | 195              | 252             | 263                  | 31                   | 298                  | 294 o 31 e             | e 295                  | 295 e 31 e          |
| Guadeloupe                             | 31            |                 | 31               | 31              | 31 u                 |                      | 31                   |                        | o 31                   |                     |
| Guatemala                              | 597           | 713             | 869              | 053             | 1 o                  | e 096 206            | e 029 o              | 029 o                  | e 030 o                | 1 030               |
| Honduras                               | 123           | 123             | 161              | 1 206           | 084 206 o            | o o                  | 1 218 o              | 218 o                  | 1 218 o                | o 218 o             |
|                                        |               | 32              | o                | o o 32          | 32                   | 1 32 e               | 32 e                 | 1 32 e                 | 32 e                   | 32 e                |
| Jamaica                                | o 32          | o               | 32               |                 |                      |                      |                      | 39 o                   |                        |                     |
| Martinique                             | 2             | 2               | 2 o              | 2               | 2 o                  | 39 o                 | 39 o                 |                        | 39 o                   | 39 o                |
| Nicaragua                              |               | 134             |                  |                 | 177                  | 177 o                | 218 o                | 218 o                  | 218 e                  | 218 e               |
|                                        | 134           |                 | 134 o            | o 177           |                      |                      |                      |                        |                        |                     |
| Panama                                 | o o 30        | o o 30          | 27               | 24              | 25 o                 | 25 e                 | 25 e                 | 25 e 0 e               | 25 o                   | 25 e 0 e            |
| St Lucia                               |               |                 |                  | 0 e             | 0 e 498              | 0 e 547              | 0 e 1 633            | 1 750                  | 0 e 2 052              | 2 203               |
| Eurasia                                | 1 244         | 1 417 37        | 1 419 37         | 1 462 37 e      | 1 42                 | 1 44                 | 44 e                 | 44                     | 44 e 1 373             | 44                  |
| Azerbaijan Russian Türkiye             | 37 1 197      | 1 370           | 1 370 e 12       | 1 370 e         | 1 373 e              | o 1 373 e            | 1 373 e              | 1 373 e 334            | e 636                  | 1 373               |
| Fed                                    | e 10          | e 10            |                  | 55              | 83                   | 130                  | 216                  |                        |                        | 786                 |

## Solid biofuels and renewable waste Biocombustibles solides et déchets renouvelables

## Biocombustibles sólidos y residuos renovables

e

e

o

e

e

e

o

e

e

e

e

e

e

e

e

o

o

e

e

e

o

e

o

| CAP (MW)                 | 2013               | 2014                 | 2015                 | 2016           | 2017           | 2018           | 2019               | 2020           | 2021           | 2022         |
|--------------------------|--------------------|----------------------|----------------------|----------------|----------------|----------------|--------------------|----------------|----------------|--------------|
| Europe                   | 19 384             | 20 545               | 21 453               | 22 031         | 23 027         | 25 141         | 25 703             | 25 703         | 25 851         | 26 020       |
| Albania                  |                    |                      |                      |                | 1 u            | 1 u            | 1 u                | 1 e            | 1 e            | 1            |
| Andorra                  | 5                  | 5 o                  | 5                    | 5              | 5 o            | 5 o            | 5                  | 5 e            | 5 e            | 5            |
| Austria                  | o 1 307 e          | 1 221 e              | o 1 202 e            | o 1 188 e      | 1 108 e        | 1 094 o        | o 1 085 e          | 1 086 e        | 1 005 e        | 1 005        |
| Belarus                  | 13                 | 13                   | 13                   | 13             | 13             | 16             | 16                 | 86             | 83             | 83           |
| Belgium                  | 764                | 681                  | 716                  | 691 e          | 685            | 652            | 665 o              | 700            | 594            | 605          |
| Bosnia Herzg             |                    |                      |                      |                |                | 0              | 1                  | 1              | 1              | 1            |
| Bulgaria Croatia         | 30 7               | 30 8                 | 34 25                | 19 26          | 23 42          | 33 e 65        | 24 e 76            | 15 80          | 14 95          | 14 98        |
| Czechia                  | 329 e              | 378 e                | 403 e                | 404 e          | 430 e          | 413 e          | 462 e              | 480 e          | 484 e          | 484          |
| Denmark                  | 1 085 e            | 1 152 e              | 1 139 e              | 1 198 e        | 1 683 e        | 1 666 e        | 1 862 e            | 1 954 e        | 2 022 e        | 2 023        |
| Estonia                  | 255                | 270                  | 270                  | 270 e          | 270 e          | 250            | 265                | 285 o          | 285            | 307          |
| Finland                  | 1 864 e            | 1 877 e              | 1 885 e              | 1 895          | 2 114 e 249    | 2 114 o 1      | 2 111 1            | 2 590 1 e      | 2 595 o e      | 2 603        |
| France                   | 1 098              | 1 109                | 1 131                | 1 232          | 1              | 450            | 488                | 370            | 1 470          | 1 470        |
| Germany                  | 2 553 o            | 2 533 o              | 2 554 e e            | 2 579 o e      | 2 605 e        | 2 648 e        | 2 682 e 13         | 2 595 e        | 2 634 e        | 2 689        |
| Greece Hungary           | 265                | 486                  | 2                    | 2              | 3 e            | 12             | 425                | 14 424         | 16 466         | 16           |
| Ireland                  | 13                 |                      | 447 e                | 351 e          | 409            | 437            | 48                 | 48             | 48 e           | 466          |
| Italy                    | e 024              | 16 e                 | 16                   | 16             | 47 e           | 47 e           | 1                  | o 1 128        | 1 120          | 48           |
|                          | 1 55               | 1 033                | 1 031                | 1 094          | 1 092          | 1 145          | 124                | e              |                | 1 116        |
| Latvia                   |                    | 63                   | 66                   | 81             | 94             | 73             | 97 e               | 96             | 95 o           | 108          |
| Lithuania Luxembourg     | 48 13              | 51                   | 50 13                | 47             | 54             | 69 24 e        | 70 44 e            | 80 44 o        | 79 o 44 o      | 81 44        |
| Netherlands              | 539                | 12 515               | 549                  | 13 548         | 23 561         | 620            | 617                | 661            | 675            | 698          |
| North Macedonia          |                    |                      |                      |                |                | 1 o            | 2 o                | 2 e            | 2 e            | 2            |
| Norway                   | 123                | 123                  | 123                  | 77             | 77 e           | 77 e           | 74 u               | 66             | 70             | 70           |
| Poland                   | 582                | 629                  | 745                  | 749            | 738            | 778            | 777                | 784            | 848            | 848          |
| Portugal Romania         | 496 35             | 495 79               | 511 104              | 519 107        | 512 119        | 577 119        | 630 119            | 644 136        | 644 e 109      | 644 111      |
| Serbia                   | 179                | 159                  |                      |                |                | 154            | 2 144              | 2 e 143        | 2 e 169 e      | 2 169        |
| Slovakia                 | 30                 |                      | 151                  | 160            | 155            |                | e 34               | e              |                |              |
| Slovenia                 | 770                | 30                   | 30                   | 30             | 33             | 32             |                    | 35             | 36             | 37 001       |
| Spain Sweden             | 3 460 e            | 790 3 959 e          | 789 4 138            | 789 333 e      | 793 273 e      | 793 4 484 e    | 839 o 402 e        | 989 3 565 e    | 1 001 3 479 e  | 1 3 479      |
| Switzerland              | 199                | 197                  | e                    | 4 212          | 4 212          | 212 o          | 4 211 o            | 211 o          | 211 e          | 211          |
| UK                       | 2 228              | 2 598                | 211 3 069            | 3 348          | e 3 566 o      | 5 032          | 5 204              | 5 276          | 5 297          | 5 328        |
| Ukraine                  | 17                 | 35                   | 35                   | 39             | 39             | 52 o           | 87                 | 109            | 152 u          | 152          |
| European Union (27)      | 16 874             | 17 644               | 18 071               | 18 412         | 19 188         | 19 857         | 20 214             | 20 057         | 20 139         | 20 277       |
| Middle East              | 18                 | 18                   | 18                   | 18             | 18             | 18             | 18                 | 15             | 15             | 30           |
| Israel Qatar United Arab | 3 15               | 3 e                  | 3 e e                | e e            | e e            | e 15 e         | 3 e e              | o              |                |              |
| Em                       | e                  | 15 e                 | 15                   | 3 15           | 3 15           | 3              | 15                 | 15 e           | 15 e 0 o       | 15 15 0      |
| Yemen N America Canada   | 12 523 2 129 e 505 | 12 873 2 381 e 591 o | 13 538 2 357 e 700 o | 13 712 2 424 e | 13 713 2 503 e | 13 495 2 515 e | 12 997 2 391 e 916 | 12 950 2 391 e | 12 536 2 391 e | 12 521 2 399 |
| Mexico USA               | o 9 889 o          | 9 902 o              | 10 482 o             | 878 o 10 411 o | 917 o 294 o    | 916 o 10 065 o | o 9 690 o          | 917 o 9 642 o  | 917 o 9 229 o  | 917 9 205    |
| Oceania                  |                    |                      |                      |                | 10             |                |                    |                |                |              |
|                          | 753                | 754                  | 754                  | 830            | 847            | 847            | 847                | 845            | 853            | 853          |
|                          |                    | 598                  |                      |                |                |                |                    |                |                |              |
| Australia Fiji           | 597 42             | 42                   | 598 42               | 674 o 42       | 674 e 54 u     | 674 e 54 u     | 674 e 54 e         | 678 e 54       | 678 e 61 e     | 678 61       |
| New Zealand Papua N Guin | u 99               | u 99                 | u 99                 | u 99           | 104            | 104            | 104                | e 98           | 98 o           | 98           |
| Samoa Solomon Is         | 15 u               | 15 u                 | 15 u 1 u             | 15 u           | 15 u           | 15 u           | 1 e                | 1              | 1 1            |              |
|                          | 1 e                | 1 e                  |                      | 1 u            | 1 u            | 400            | 15 e               | 15 e 1 e e     | 15 e e         | 15 1         |
|                          |                    |                      |                      |                |                | 1 u            |                    |                | e              | 1            |
| S America                | 901                | 359                  | 903                  |                | 190            |                | 974                |                |                |              |
|                          | 13                 | 14                   | 14                   | 15 561 226     | 16             | 16             | 16                 | 17 189         | 17 878         | 18 781       |
| Argentina                | 229 e 85           | 211 e 126 o          | 237 e 134 o          | e 142          | 220 e 142 o    | 194 e 160      | 254 e              | 252 e 180      | 212 e          | 206 256      |
| Bolivia                  | o 424              | 12 145 884           | 13 088 o e           | o 13 722 e     | 14 307 o       | o 14 512 o     | 169 o 14 981 o     | o              | 206 e 894 o    | 702          |
| Brazil Chile             | 11 1 240 e         | e 215 u              | 417 u                | 410 e 253 u    | 410 e 306 u    | 410 e 316 u    | 442 o              | 15 229 o 396 o | 15 375 o       | 16 426       |
|                          | 187 u              |                      | 237                  |                |                |                | 316 e              | 319 e          | 387 e          | 387          |
| Colombia Ecuador         | 101 o              | 144 o                | 144 o                | 144 o          | 144 e          | 144 e          | 144 o              | 144 o          | 144 o          | 144          |
|                          | 2 o                | 2 o                  | 2 o                  | 2 o            | 2 o            | 2 o            | 5 o                | 5 e            | 5 o            | 5 42         |
| Fr Guiana                | 51                 | 51                   | 51                   | 42             | 42             | 42             | 42                 | 42 e           | 42 e           |              |
| Guyana                   | 39                 | 39                   | 39                   | 39             | 39             | 39 e           | 20 e               | 20             | 20 e           | 20 177       |
| Peru                     | 126                | 126                  | 126                  | 153 o          | 163 o          | 163 o          | 185 o              | e 185 e        | 177 o          |              |
| Paraguay                 | o                  | o                    | o 2                  | 2              | 2              | 2 e            | 2 e                | 2 e            | 2 e            | 2            |
| Suriname Uruguay         | 416 o              | 416 o                | 426 o                | 426 o          |                | 415 o          | 415 e              | 415 o          | 415 e          | 415          |
|                          |                    |                      |                      |                | 415 o          |                |                    |                |                |              |

## Bagasse Bagasse Bagazo

| CAP (MW)                                    | 2013            | 2014             | 2015           | 2016               | 2017              | 2018                | 2019                | 2020             | 2021              | 2022           | 2022           | 2022           | 2022           | 2022           | 2022           |
|---------------------------------------------|-----------------|------------------|----------------|--------------------|-------------------|---------------------|---------------------|------------------|-------------------|----------------|----------------|----------------|----------------|----------------|----------------|
| World                                       | 14 980          | 15 966           | 17 040         | 17 899             | 18 450            | 19 213              | 19 913              | 20 327           | 20 590            | 21 028         | 21 028         | 21 028         | 21 028         | 21 028         | 21 028         |
| Africa 1                                    | 1 190           | 1 299 1          | 367            | 1 419              | 493               | 1 575               | 1 575               | 586              | 1 631             | 1 631          | 1 631          | 1 631          | 1 631          | 1 631          | 1 631          |
| Angola                                      |                 | 51 e             | 51 e           | 51 e               | 51 e              | 51 e                | 51 e                | 51 e             | 51 e              | 51 e           | 51 e           | 51 e           | 51 e           | 51 e           | 51 e           |
| Burundi                                     | 4               | 4 e o            | 4 e            | 4 e                | o 4 e             | 4 e                 | 4 e                 | 4 e              | 4 e               | 4 e            | 4 e            | 4 e            | 4 e            | 4 e            | 4 e            |
| Chad Congo Rep                              | 2 o 5 e         | 2 5 e            | 2 o 5 e        | 2 o 5              | 2 o 5 e           | 2 o 5 e             | 2 o 5 e             | 2 o 5 e          | 2 e 5 e           | 2 e 5 e        | 2 e 5 e        | 2 e 5 e        | 2 e 5 e        | 2 e 5 e        | 2 e 5 e        |
| Egypt                                       | 67              | 67               | 67             | e 67               | 67                | 67                  | 67                  | 67 e             | 67 e              | 67 e           | 67 e           | 67 e           | 67 e           | 67 e           | 67 e           |
| Eswatini                                    | 106             | 106              | 106            | 106 e              | 106 e             | 106 e               | 106 e               | 106 e            | 106 e             | 106 e          | 106 e          | 106 e          | 106 e          | 106 e          | 106 e          |
| Ethiopia                                    | 71              | 71               | 119            | 145                | 205               | 265                 | 265                 | 265              | 310               | 310 e          | 310 e          | 310 e          | 310 e          | 310 e          | 310 e          |
| Kenya                                       | 56 u            | 56 u             | 56 u           | 82 u               | 83 u              | 86 u                | 86 u                | 97 u             | 97 u              | 97 u           | 97 u           | 97 u           | 97 u           | 97 u           | 97 u           |
| Malawi                                      | 19 u            | 19 u             | 19 u           | 19 u               | 19 u              | 19 u                | 19 u                | 19 u             | 19 u              | 19 u           | 19 u           | 19 u           | 19 u           | 19 u           | 19 u           |
| Mali Mauritius                              | 32 o o          | 40 e 77          | 40 e 87 o      | 40 e 87 o          | 40 u 87 o         | 40 e 87 o           | 40 e 87 e           | 40 e 87 e        | 40 e 87 e         | 40 e 87 e      | 40 e 87 e      | 40 e 87 e      | 40 e 87 e      | 40 e 87 e      | 40 e 87 e      |
| Mozambique                                  | 77 e            | o e              | e              |                    | 14 e              | 14 e                | 14 e                | 14 e             | 14 e              | 14 e           | 14 e           | 14 e           | 14 e           | 14 e           | 14 e           |
| Nigeria                                     | 14 5 u          | 14               | 14 5           | 14 e 5 u           | 5 u               | 5 u                 | 5 e                 | 5 e              | 5 e               | 5 e            | 5 e            | 5 e            | 5 e            | 5 e            | 5 e            |
| Reunion                                     | 42 e            | 5 u 42 e         | u 42 e         | 42 e               | 42 e              | 42 e                | 42 e                | 42 e             | 42 e              | 42 e           | 42 e           | 42 e           | 42 e           | 42 e           | 42 e           |
| Rwanda                                      | 1 e             | 1 e              | 1              | 1 e                | 1 e               | 1 e                 | 1 e                 | 1 e              | 1 e               | 1 e            | 1 e            | 1 e            | 1 e            | 1 e            | 1 e            |
| Senegal                                     | 25 e            | 25 e             | e 25 e         | 25 e               | 25 e              | 25 e                | 25 e                | 25 e             | 25 e              | 25 e           | 25 e           | 25 e           | 25 e           | 25 e           | 25 e           |
| Sierra Leone                                |                 | 32 u             | 32 e           | 32 e               | 32 e              | 32 e                | 32 e                | 32 e             | 32 e              | 32 e           | 32 e           | 32 e           | 32 e           | 32 e           | 32 e           |
| South Africa                                | 242 e           | 242 e            | 242 e          | 242 e              | 242 e             | 242 e               | 242 e               | 242 e            | 242 e             | 242 e          | 242 e          | 242 e          | 242 e          | 242 e          | 242 e          |
| Sudan                                       | 199 e           | 199 e            | 199 e          | 199 e              | 199 e             | 199 e               | 199 e               | 199 e            | 199 u             | 199            | 199            | 199            | 199            | 199            | 199            |
| Tanzania                                    | 46 o            | 46 o             | 46 o           | 46 o               | 46 e              | 46 e                | 46 e                | 46 e             | 46 e              | e 46 e         | e 46 e         | e 46 e         | e 46 e         | e 46 e         | e 46 e         |
| Uganda                                      | 36 e            | 54 e             | 65 e           | 65 e               | 76 e              | 96 e                | 96 e                | 96 e             | 96 o              | 96 e           | 96 e           | 96 e           | 96 e           | 96 e           | 96 e           |
| Zambia                                      | 43 e            | 43 e             | 43 e           | 43 e               | 43 e              | 43 e                | 43 e                | 43 e             | 43 o              | 43 e           | 43 e           | 43 e           | 43 e           | 43 e           | 43 e           |
| Zimbabwe                                    | 100             | 100              | 100 e          | 100 e              | 100 e             | 100 e               | 100 e               | 100 e            | 100 e             | 1 606          | 1 606          | 1 606          | 1 606          | 1 606          | 1 606          |
| Asia                                        | 787             | 854              | 940            | 977                | 997               | 1 350               | 1 377               | 457 1            | 440               |                |                | 1              |                |                |                |
| Cambodia                                    | 16 o            | 16 o             | 16 o           | 16 o               | 36 o              | 36 o                | 36 e                | 27 e             | 27 e              | 27 o           | 27 o           | 27 o           | 27 o           | 27 o           | 27 o           |
| Indonesia Lao PDR                           | 208 o 40 o      | 219 o 40 o       | 219 o 40 o     | 219 o 40 o         | 219 o 40 e        | 219 o 105 o         | 219 e 105 e         | 219 e 105 e      | 219 105 e         | 352 e 105 e    | 352 e 105 e    | 352 e 105 e    | 352 e 105 e    | 352 e 105 e    | 352 e 105 e    |
| Myanmar                                     | 47 e            | 51 e             | 46 e           | 48 e               | 47 e              | 52 e                | 54 e                | 54 e             | 54 e              | 54 e           | 54 e           | 54 e           | 54 e           | 54 e           | 54 e           |
| Nepal                                       | 6 e             | 6 e              | 6 e            | 6 e                | 6 e               | 6 e                 | 6 e                 | 6 e              | 6 e               | 6 e            | 6 e            | 6 e            | 6 e            | 6 e            | 6 e            |
| Pakistan                                    | 254 e           | 306 e            | 314 e          | 314 e              | 314 e             | 372 o               | 372 o               | 372 o            | 372 e             | 372 e          | 372 e          | 372 e          | 372 e          | 372 e          | 372 e          |
| Philippines Viet Nam                        | 92 o 125        | 92 o 125 e       | 149 o 150 e    | 161 o 174 e        | 161 o e 174 e     | 208 o 353 u         | 233 o 352 e         | 321 o 353 e      | 321 o 336 e       | 355 o 336 e    | 355 o 336 e    | 355 o 336 e    | 355 o 336 e    | 355 o 336 e    | 355 o 336 e    |
| C America + Carib                           | 1 746           | 1 925            | 2 010          |                    | 2 379             | 2                   | 2 788               | 2 892            | 2 895             | 2 895          | 2 895          | 2 895          | 2 895          | 2 895          | 2 895          |
|                                             |                 |                  |                | 2 292              |                   | 498                 |                     |                  |                   | 36 u           | 36 u           | 36 u           | 36 u           | 36 u           | 36 u           |
| Belize 36 u Costa Rica                      | 28 34           | 28 34            | 28 34          | 28 u 40            | 40                | 36 u 53 o           | 36 u 71 o           | u 71 o           | 36 71 o           | 71 o           | 71 o           | 71 o           | 71 o           | 71 o           | 71 o           |
| Cuba                                        | 470 o           | 498 o            | 529 o          | 494                | 531 e o           | 553 e 44 e          | 841 e               | 950              | 950 o             | 950 e          | 950 e          | 950 e          | 950 e          | 950 e          | 950 e          |
| Dominican Rep                               | 14 263          | 14               | 14             | 44 o 252           | 44                | 298                 | 44                  | 44 e             | 44 e 295          | 44 e e         | 44 e e         | 44 e e         | 44 e e         | 44 e e         | 44 e e         |
| El Salvador                                 | 30              | 298              | 195            |                    | 263               | 30 e                | 298                 | 294 o            | o                 | 295 e          | 295 e          | 295 e          | 295 e          | 295 e          | 295 e          |
| Guadeloupe Guatemala 1                      | 594             | 30 711           | 30 867         | 30 1 050 o         | 30 081 o          | 1 094 o             | 30 e 1 026 o        | 30 e 026 o       | 30 e 1 027 o      | 30 027 o       | 1              | 1              | 30 027 o       | 30 027 o       | 30 027 o       |
| Honduras                                    | 118 o           | 118 o            | 122            | 122 o              | 122 o             | 122 o               | 132 o               | 132 o            | 132 o             | 132 o          | 132 o          | 132 o          | 132 o          | 132 o          | 132 o          |
| Jamaica                                     | 32              | 32               | o 32           | 32                 | 32                | 32 e                | 32 e                | 32 e             | 32 e              | 32 e           | 32 e           | 32 e           | 32 e           | 32 e           | 32 e           |
| Martinique                                  |                 |                  | o              |                    |                   | 37 o                | 37 o                | 37 o             | 37 o              | 37 o           | 37 o           | 37 o           | 37 o           | 37 o           | 37 o           |
| Nicaragua                                   | 134 o           | 134 o            | 134            | 177                | 177               | 177 o               | 218 o               | 218 o            | 218 e             | 218            | 218            | 218            | e              | 218            | 218            |
| Panama                                      | 30              | 30               | 27             | 24                 | 25 o              | 25 e                | 25 e                | 25 e             | 25                | 25             | 25             | 25             | 25             | 25             | 25             |
|                                             |                 |                  |                |                    |                   |                     |                     |                  | o                 |                |                |                | e              |                |                |
| Europe                                      |                 |                  |                |                    |                   |                     |                     |                  |                   |                |                |                |                |                |                |
| 2                                           |                 |                  | 2              | 2                  |                   | 2                   | 2                   |                  | 2                 |                |                | 2              | 2              |                |                |
| Portugal 2 European Union (27) 74 N America | 72 705          | 72 796           | 2 74 912       | 2 74 977           | 986               | 2 111 986           | 2 111 986           | 986              | 2 111 986         | 986            | 986            | 986            | 986            | 986            | 986            |
| Mexico USA                                  | 478 o 227 o     | 569 o 227 o      | 685 o 227 o    | 796 o 181 o        | 816 o 170 o       | 816 o 170 o         | 816 o 170 o         | 816 o 170 o      | 816 o 170 o       | 816 170        | 816 170        | 816 170        | o o            | 816 170        | 816 170        |
| Oceania                                     | 453             | 453              | 453            | 529                | 529               | 529                 | 529                 | 533              | 541               | 541            | 541            | 541            | 541            | 541            | 541            |
|                                             | 424             | 424 29 u         | 424            | 500 o              | 500 o             | 500 o 29 u          | 500 e 29 e          | 504 29           | 504               | 504 37         | 504 37         | 504 37         | e              | 504 37         | 504 37         |
| Australia Fiji                              | 29 u            |                  | 29 u           | 29 u               | 29 u              |                     |                     | o e              | o 37 e            |                |                |                |                |                |                |
| S America                                   | 10 099          | 10 638           | 11 355         | 11 702             | 12 064            | 12 272              | 12 656              | 12 870           | 13 095            | e 13 367       | e 13 367       | e 13 367       | e 13 367       | e 13 367       | e 13 367       |
|                                             |                 |                  |                | 45 e               |                   |                     |                     |                  |                   | 54             | 54             | 54             | 54             | 54             | 54             |
| Argentina Bolivia                           | 64 e 85 o 9 435 | 47 e 126 o 9 881 | 64 e 134 o     | 142 o              | 50 e 142 o 11 168 | 50 e 160 o 11 348 o | 56 o 169 o 11 714 o | e 180 o 11 913 o | 57 195 e 12 064 o | 256 e 12 277 o | 256 e 12 277 o | 256 e 12 277 o | 256 e 12 277 o | 256 e 12 277 o | 256 e 12 277 o |
| Brazil Colombia Ecuador                     | 187 u 101 o     | 215 u 144 o      | 10 237 u 144 o | 10 874 253 u 144 o | 306 u 144 e       | 316 u 144 e         | 316 e 144 o         | 319 e 144 o      | 387 e 144 o       | 387 144        | 387 144        | 387 144        | 387 144        | 387 144        | 387 144        |
|                                             |                 |                  | 549            |                    |                   |                     |                     |                  |                   | e              | e              | e              | e              | e              | e              |
| Guyana                                      | 51              | 51               | 51             | 42                 | 42                | 42                  | 42 20               | 42 20            | 42                | 42 20          | 42 20          | 42 20          | 42 20          | 42 20          | 42 20          |
| Paraguay                                    | 39              | 39               | 39             | 39                 | 39                | 39                  |                     | e e              | 20                |                |                |                |                |                |                |
|                                             |                 |                  |                |                    |                   |                     | e                   |                  |                   | 177            | 177            | 177            | 177            | 177            | 177            |
|                                             | 10              | 126              | 126            |                    |                   | 163 o               | 185                 | 185 e 10         |                   | 10             | 10             | 10             | 10             | 10             | 10             |
|                                             |                 |                  |                |                    |                   |                     | 10                  |                  |                   |                |                |                |                |                |                |
| o o                                         |                 |                  |                |                    |                   |                     |                     |                  |                   |                |                |                |                |                |                |
| 10                                          |                 |                  |                |                    |                   |                     |                     |                  |                   |                |                |                |                |                |                |
|                                             | 126             |                  |                |                    |                   |                     |                     | o e              | e                 | 10             |                |                |                |                |                |
|                                             | o               |                  |                |                    | o                 | 10                  |                     |                  | o                 | 177            |                |                |                |                |                |
| Uruguay                                     |                 |                  | 10             | 153 10             | 163 10            |                     |                     |                  |                   | o              |                |                |                |                |                |
| Peru                                        |                 |                  | o              |                    |                   |                     |                     |                  |                   |                |                |                |                |                |                |
|                                             |                 |                  |                |                    |                   |                     |                     |                  | e                 |                |                |                |                |                |                |
|                                             |                 | o                |                |                    |                   |                     |                     |                  |                   |                |                |                |                |                |                |
|                                             |                 |                  |                | o                  |                   |                     |                     |                  |                   |                |                |                |                |                |                |
|                                             |                 |                  |                |                    |                   |                     |                     |                  | e                 |                |                |                | e e            |                |                |
|                                             |                 |                  |                |                    |                   | e                   |                     |                  |                   |                |                |                |                |                |                |

## Renewable municipal waste Déchets municipaux renouvelables

## Residuos municipales renovables

| CAP (MW)               | 2013        | 2014        | 2015      | 2016      | 2017        | 2018        | 2019        | 2020        | 2021        | 2022        |
|------------------------|-------------|-------------|-----------|-----------|-------------|-------------|-------------|-------------|-------------|-------------|
| World                  | 8 617       | 8 827       | 9 746     | 10 620    | 11 545      | 12 750      | 14 248      | 16 971      | 19 349      | 21 929      |
| Africa                 |             |             |           |           |             | 25          | 25          | 25          | 25          | 25          |
|                        |             |             |           |           |             |             | e           |             |             | 25 o        |
| Ethiopia               |             |             |           |           |             | 25          | 25          | 25          | 25          |             |
| Asia                   | 3 183       | 3 446       | 3 995     | 4 535     | 5 329       | 6 383       | 7 840       | 10 528      | 13 007      | 15 483      |
| China                  | 1 700       | 1 893       | 2 342     | 2 870     | 3 640       | 4 575       | 6 009       | 8 682 o     | 11 022 o    | 13 406 e    |
| Chinese Taipei India   | 315 o 105 o | 315 o 124 o | 315 o     | 315 o     | 315 o 146 o | 316 o 159 o | 316 o 165 o | 316 o 188 o | 316 o 217 o | 316 o 261 o |
| Indonesia              | 13 o        | 18 o        | 137 o 8 o | 139 o 8 o | 8 o         | 8 o         | 8 o         | 8 e         | 14 o        | 14 o        |
| Japan                  | 852         | 876         | 900       | 919       | 935         | 958         | 975         | 963 o       | 1 033 o     | 1 026 o     |
| Korea Rep              | 38          | 50          | 95        | 77        | 54          | 64          | 64          | 54 e        | 60 e        | 45 e        |
| Malaysia               | 9           | 9           | 7 o       | 7 o       | 7 o         | 7 o         | 7 o         | 7 o         | 7 o         | 7 e         |
| Maldives               |             |             |           |           |             |             | 0 o         | 0 e         | 0 e         | 0 e         |
| Myanmar Singapore      | 128 o       | 128 o       | 128 o     | 128 o     | 0 u 128 o   | 0 e 128 o   | 0 e 128 o   | 0 e 128 o   | 0 e 128 o   | 0 e 197 o   |
| Sri Lanka              | 24          | o           | 66 o      | o         | 96 o        | 159 o       | o           | 5 o o       | 5 u         | 5 e         |
| Thailand Viet Nam      | o           | 33          |           | 73 1 u    | 1 e         | 11 e        | 157 11 e    | 167 11 e    | 194 o 11 e  | 194 e 11 e  |
| C America + Carib      | 2           | 4           | 4         | 4         | 4           | 4           | 4           | 4           | 4           | 4           |
| Aruba Martinique       | 2 o         | 2 2 o       | 2 2 o     | 2 2 o     | 2 2 o       | 2 2 o       | 2 2 o       | 2 e 2 o     | 2 e 2 o     | 2 e 2 o     |
| Eurasia                | 37          | 37          | 37        | 37        | 42          | 45          | 46          | 46          | 57          | 56          |
| Azerbaijan Türkiye     | 37          | 37          | 37        | 37 e      | 42          | 44 o 1      | 44 e 2      | 44 2        | 44 e 13     | 44 12       |
|                        |             |             |           |           | 889         | 014         | 105         |             | 015         | 134         |
| Europe                 | 4 197       | 4 147       | 4 514     | 4 779     | 4           | 5           | 5           | 5 140       | 5           | 5           |
| Albania                |             |             |           |           | 1 u         | 1 u         | u           | e           | 1           |             |
| Andorra                | 5 o         | 5 o         | 5 o       | 5 o       | 5 o         | 5 o         | 1 5         | 1           | e 5 e       | 1           |
| Austria                | 290         | 262         | 263       | 271       | 271         | 270         | o 272       | 5 e 270     | 240         | 5 240       |
| Belgium                | 124         | 124         |           |           |             |             |             |             |             |             |
|                        |             |             | 124       | 125       | 125         | 125         | 126         | 136         | 146         | 145         |
| Czechia Denmark        | 23          | 23          | 23        | 28 166    | 28 e 182    | 28 o 181    | 28 181      | 28 e 177    | 28 e 175    | 28 176      |
| Estonia                | 166 105     | 163 105     | 166 105   | 105       | 105 e       | 85          | 85          | 85 o        | 85          | 85          |
| Finland                | 113 e       | 126 e       | 134 e     | 148 e     | 148 e       | 148 o       | 148         | 148         | 197 o       | 267         |
| France                 | 647         | 645         | 603       | 621       | 625         | 622         | 613         | 560         | 572         | 572         |
| Germany                | 930         | 944         | 962       | 979       | 1 004       | 1 063       | 1 084       | 1 024       | 1 068       | 1 068       |
| Hungary Ireland        | 18 8        | 19          | 25        | 29 11     | 23 41       | 23 41       | 23 41       | 27 41       | 28 41 o     | 28 41       |
| Italy                  | 418         | 11 413      | 11 415    | 409       | 408         | 412         | 396         | o 402       | 418         | 418         |
| Lithuania              | 5           | 5           | 5         | 8         | 9           | 7           | 7           | 17          | 21          | 19          |
|                        | 10          | 9           |           | 9         | 9           | 9 e         | 9 e         | 9 o         | 9 o         | 9           |
| Luxembourg Netherlands | 325         | 325         | 9 338     | 338       | 334         | 389         | 389         | 390         | 390         | 413         |
| Norway                 | 44          | 44          | 44        | 50        | 50 e        | 50 e        | 47          | 46          | 43          | 43          |
| Poland                 |             |             | 8         | 22        | 30          | 43          | 45          | 50          | 45          | 45          |
| Portugal               | 38          | 39          | 40        | 42        | 41          | 41          | 41          | 41          | 41 o        | 41          |
| Slovakia               | 3 117       | 6 117       | 6         | 10        | 6           | 6           | 6 e         | 6 e         | 6 e         | 6           |
| Spain Sweden           | 340         | 230         | 117 438   | 117 564   | 121 567     | 121 566     | 121 o 568   | 121 623     | 133 386     | 133 386     |
| Switzerland            | 199         | 197         | 211       | 212       | 212 e       | 212 o       | 211 o       | 211 o       | 211 e       | 211         |
| UK                     | 273         | 340         | 465       | 514       | 545         | 568         | 661         | 723         | 727         | 755         |
| European Union         | 3 680       | 3 564       | 3 792     | 4 000     | 4 078       | 4 180       | 4 182       | 4 156       | 4 029       | 4 121       |
| Middle East            | 18          | 18          | 18        |           |             | 18          | 18          | 15          |             |             |
| Israel Qatar           |             |             |           | 18        | 18          |             | 3           |             | 15          | 30          |
|                        | 3 15        | 3 e 15 e    | 3 e 15 e  | 3 e 15 e  | 3 e 15 e    | 3 e 15 e    | e 15        | 15          | 15 e        | 15 e        |
| United Arab Em         | e           |             |           |           |             |             | e           | e           |             | 15 o        |
| Canada Mexico          | 39 27       | 39 21       | 39 15     | 39        | 38 100      | 38 e 100    | 38 e 100    | 38 e 100    | 38 e 100    | 38 e 100    |
| USA                    | 1 114       | 1 115       | 1 124     | 81 1 124  | 1 123       | 1 117 o     | 1 060 o     | 1 061       | 1 058 o     | e 1 025 o   |
| Oceania                |             |             |           |           | o           |             |             | o           |             |             |
|                        | o           | o           | o         | o         |             |             |             |             |             |             |
|                        |             |             |           |           |             |             |             |             | 0           | 0           |
| Australia              |             |             |           |           |             |             |             |             | 0 o         | 0 e         |
| S America              |             |             |           | 3         | 3           | 5           | 13          | 14          | 30          | 35          |
| Brazil                 |             |             |           | 3 o       | 3 o         | 5 o         | 13 o        | 14 o        | 30 o        | 35 o        |

## Other solid biofuels Autres biocarburants solides Otros biocombustibles sólidos

| CAP (MW)                | 2013       | 2014       | 2015       | 2016       | 2017         | 2018         | 2019          | 2020        | 2021        | 2022          |
|-------------------------|------------|------------|------------|------------|--------------|--------------|---------------|-------------|-------------|---------------|
| World                   | 45 130     | 48 466     | 51 457     | 57 777     | 61 248       | 65 354       | 68 131        | 72 754      | 77 912      | 82 022        |
| Africa                  | 55         | 46         | 46         | 48         | 50           | 50           | 51            | 51          | 51          | 51            |
| Congo DR                | 0 e        | 0 e        | 0 e        | 0 e        | 2 e          | 3 e          | 3 e           | 3 e         | 3 e         | 3 e           |
| Congo Rep               | 7 e        | 7 e        | 7 e        | 7 e        | 7 e          | 7 e          | 7 e           | 7 e         | 7 e         | 7 e           |
| Eswatini Ghana          | 17 7 e     | 8 e        | 8 e        | 8 e        | 8 e          | 8 e          | 8 e           | 8 e         | 8 e         | 8 e           |
| Liberia                 | 0 u        | 0 u        | 0 e        | 0 u        | 0 e          | 0 e          | 0 e           | 0 e         | 0 e         | 0 e           |
| Madagascar Namibia      | 0 o 0      | 0 o 0      | 0 o 0      | 0 o 0 e    | 0 e 0 e      | 0 e 0 e      | 0 e 0         | 0 e 0 e     | 0 e 0 e     | 0 e 0 e       |
| Nigeria                 | 3 u        | 4 u        | 4 u        | 5 u        | 5 u          | 5 u          | 6 e           | 6 e         | 6 e         | 6 e           |
| Sierra Leone Tanzania   | 20 o       | 2 e 24 o   | 2 e 24 o   | 2 e 24 o   | 2 e 24 e     | 2 e 24 e     | 2 e 24 e      | 2 e 24 e    | 2 e 24 e    | 2 e 24 e      |
| Zimbabwe                | 1 e        | 1 e        | 1 e        | 1 e        | 1 e          | 1 e          | 1 e           | 1 e         | 1 e         | 1 e           |
| Asia                    | 931        | 708        | 17 750     | 317        | 604          | 888          | 366           | 960         | 39 516      | 780           |
|                         | 13         | 15         |            | 23         | 25           | 27           | 30            | 34          |             | 42            |
| Bangladesh              |            |            | 0 o        | 0 o        | 0 o          | 0 o          | 0 o           | 0 o         | 0 o         | 0 o           |
| Cambodia                | 12 o       | 20 o       | 17 o       | 15 o       | 15 o         | 15 o         | 15 o          | 17 o        | 15 o        | 24 u          |
| China China HK SAR      | 4 196      | 4 450      | 5 304      | 6 050      | 7 140 28     | 8 030 28     | 9 729 28      | 13 617 o 28 | 17 021 o 28 | 18 755 e 28 e |
| Chinese Taipei          | 81 o       | 81 o       | 79 o       | 79 o       | 79 o         | 79 o         | 75 o          | 83 o        | 91 o        | 91 o          |
| India                   | 4 070 o    | 4 899 o    | 5 332 o    | 8 746 o    | 9 258 o      | 9 965 o      | 10 046 o      | 10 331 o    | 10 361 o    | 10 395 o      |
| Indonesia               | 1 462 o    | 1 472 o    | 1 452 o    | 1 484 o    | 1 522 o      | 1 540 e 2    | 1 545 e       | 1 548 e     | 1 902 e     | 2 504 e       |
| Japan                   | 652        | 739        | 978        | 1 260      | 1 626        | 016          | 2 461         | 3 059 o     | 3 474 o     | 4 356 o       |
| Korea Rep               | 55         | 74         | 160        | 1 179      | 1 799        | 1 835        | 1 992         | 1 676 e     | 1 880 e     | 1 801 o       |
| Malaysia                | 1 022 o    | 1 404 o    | 1 528 o    | 1 462 o    | 732 o        | 734 e        | 774 e         | 774 e       | 774 e       | 774 e         |
| Myanmar Nepal           | 0 e 1 e    | 0 e 1 e    | 0 e 1 e    | 0 e 1 e    | 3 e 1 e      | 3 e 1 e      | 3 e 1 e       | 3 e         | 3 e         | 3 e           |
| Pakistan                | 6 e        | 10 e       | 10 e       | 51 e       | 51 e         | 51 e         | 51 e          | 51 o        | 51 e        | 51 e          |
| Philippines             | 8 o        | 20 o       | 53 o       | 58 o       | 74 o         | 80 o         | 107 o         | 136 o       | 142 o       | 223 o         |
| Singapore Sri Lanka     | 32 e 13 o  | 55 e 20 o  | 77 e       | 82 e       | 83 e         | 91 e         | 78 e 40 o     | 70 e 40 o   | 78 e 40 o   | 78 e 40 e     |
| Thailand                | 2          | 2 452      | 20 o 2 727 | 24 o 2 815 | 26 o 3 157 o | 37 o 3 373 o | 3 410 o       | 3 517 o     | 3 647 o     | 3 647 e       |
| Viet Nam                | 321        | 11 u       | 11 u       | 11 u       | 11 u         | 11 u         | 11 e          | 11 e        | 11 e        | 11 e          |
| C America + Carib       | 10         | 11         | 45         | 90         | 95           | 95           | 96            | 96          | 96          | 96            |
| Costa Rica              |            |            |            |            | 5            | 5            |               | 5 e         | 5 e         | 5 e           |
| Cuba Dominican Rep      | 2 e        | 1 2 e      | 1 o 2 e    | 1 o 2 e    | 1 o 2 e      | 1 e 2 e      | 5 1 e 2 e     | 1 e 2 e     | 1 e 2 e     | 1 e 2 e       |
| Guadeloupe Guatemala    | 1 3        | 1          | 1          | 1 3        | 1 u 3        | 1 e 3 o      | 1 e 3 o       | 1 e 3 o     | 1 e 3 o     | 1 e 3 o       |
| Honduras                | o          | 3          | 3          |            |              |              | 86 o          |             |             | 86            |
| St Lucia                | 6          | 6 o        | 39 o       | 84 o 0 e   | 84 o 0 e     | 84 o 0 e     | 0 e           | 86 o 0 e    | 86 o 0 e    | o 0 e         |
| Eurasia                 | 1 207      | 1 380      | 1 382      | 1 425      | 1 456        | 1 501        | 1 587         | 1 704       | 1 995       | 2 147         |
| Russian Fed Türkiye     | 1 197 e 10 | 1 370 e 10 | 1 370 e 12 | 1 370 e 55 | 1 373 e 83   | 1 373 e 129  | 1 373 e 214   | 1 373 e 332 | 1 373 e 623 | 1 373 775     |
| Europe                  | 15 187     | 16 398     | 16 937     | 17 250     | 18 135       | 20 125       | 20 596        | 20 561      | 20 834      | 20 884        |
| Austria                 | 1 017 e    | 959 e      | 939 e      | 917 e      | 838 e        | 824 o        | 813 e         | 816 e       | 765 e       | 765           |
| Belarus                 | 13         | 13         | 13         | 13         | 13           | 16           | 16            | 86          | 83          | 83            |
| Belgium Bosnia Bulgaria | 640        | 558        | 591        | 566 e      | 559          | 526 0        | 539 o 1       | 564 1       | 448 1       | 460           |
| Herzg                   | 30         | 30         | 34         | 19         | 23           | 33 e         | 24            | 15          | 14          | 1 14          |
| Croatia                 | 7          | 8          | 25         | 26         | 42           | 65           | e 76          | 80          | 95          |               |
| Czechia                 | 306        | 355 e      | 380        | 376        | 402          | 385 e        |               | 452         | 456         | 98            |
| Denmark Estonia         | e 919 e    | 989 e      | e 973 e    | e 1 032 e  | e 1 501 e    | 1 485 e      | 434 e 1 681 e | e 1 777 e   | e 1 848 e   | 456 1 848 222 |
| Finland                 | 150 1 751  | 165 751    | 165 1 751  | 165        | 165          | 165 966      | 180 963       | 200 442     | 200 398     |               |
| France                  | 451        | 1 465      | 528        | 1 747 612  | 1 966 624    | 1 828        | 1 875         | 2 810 e     | 2 899       | 2 336 899     |
|                         | 1 623 o    | 1 589      | 1 592      | 1 600 o    | 1 601 e      | 1 585 e      | 1 598 e       | 1 571 e     | e 1 566 e   | 1 621         |
| Germany Greece          |            | o          | e 2 e      | 2 e        | 3 e          | 12           | 13            | 14          | 16          | 16            |
| Hungary Ireland         | 247 5 e    | 467 5      | 422 5 e    | 322 5 e    | 386          | 414 5 e      | 402 7         | 397 7       | 438 7       | 438 7         |
| Italy                   | 606        | e 620      | 616        | 685        | 5 e 684      | 733          | 728           | 726         |             | 698           |
| Latvia                  | 55         | 63         | 66         | 81         | 94           | 73           | 97            | 96          | e 702 95    | 108           |
|                         | 43         | 46         | 45         | 39         | 45           | 62           | 63            | 63          | o 58        | 62            |
| Lithuania               | 4          | 4          | 4          | 4          | 15           | 15           | e 35          | e 35        | 35          | 35            |
| Luxembourg Netherlands  | 215        | 190        | 210        | 210        |              | 231          | 228           | o 271       | o o         | 285           |
| North Macedonia         |            |            |            |            | 226          | 1            | 2 o           | 2 e         | 285 2 e     | 2             |
| Norway                  | 79         |            | 79         | 27         | 27           | 27           | 27 u          | 20          | 27          | 27            |
| Poland                  | 582        | 79         | 737        | 727        | e 709        | o e 735      | 732           | 734         | 803         | 803           |
| Portugal                | 458        | 629 456    | 469        | 475        | 469          | 534          | 587           | 601         | 601 e       | 601           |
| Romania                 | 35         | 79         | 104        | 107        | 119          | 119          | 119           | 136         | 109         | 111           |
| Serbia                  |            |            |            |            |              |              | 2             | 2           | 2 e         | 2 163         |
| Slovakia                | 176        | 153        | 145        | 150        |              | 148          | 138           | e 137       | 163         |               |
| Slovenia                | 30         | 30         |            | 30         | 149 33       | 32           | 34            | 35          | 36          | 37            |
| Spain                   | 653        | 673        | 30 672     | 672        | 672          | 672          | 718           | 868         | 867         | 867           |

## Other solid biofuels Autres biocarburants solides Otros biocombustibles sólidos

| CAP (MW)            | 2013    | 2014    | 2015    | 2016    | 2017    | 2018    | 2019    | 2020    | 2021    | 2022    |
|---------------------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
| Sweden              | 3 120 e | 3 729 e | 3 700 e | 3 769 e | 3 706 e | 3 918 e | 3 834 e | 2 942 e | 3 093 e | 3 093   |
| UK                  | 1 955   | 2 258   | 2 604   | 2 834   | 3 020   | 4 463   | 4 543   | 4 553   | 4 569   | 4 573   |
| Ukraine             | 17      | 35      | 35      | 39      | 39 o    | 52 o    | 87      | 109     | 152 u   | 152 e   |
| European Union (27) | 13 122  | 14 008  | 14 205  | 14 337  | 15 036  | 15 565  | 15 921  | 15 791  | 15 999  | 16 045  |
| Middle East         |         |         |         |         |         |         |         |         | 0       | 0       |
| Yemen               |         |         |         |         |         |         |         |         | 0 o     | 0 e     |
| N America           | 10 639  | 10 902  | 11 449  | 11 492  | 11 468  | 11 255  | 10 813  | 10 766  | 10 355  | 10 373  |
| Canada              | 2 090 e | 2 342 e | 2 318 e | 2 385 e | 2 465 e | 2 477 e | 2 353 e | 2 353 e | 2 353 e | 2 361 e |
| Mexico              | 0 o     | 1 o     | 1 o     | 1 o     | 1 o     | 1 o     | 1 o     | 1 o     | 2 o     | 2 o     |
| USA                 | 8 548 o | 8 560 o | 9 130 o | 9 106 o | 9 002 o | 8 778 o | 8 459 o | 8 411 o | 8 000 o | 8 009 o |
| Oceania             | 299     | 300     | 300     | 300     | 317     | 317     | 317     | 312     | 312     | 312     |
| Australia           | 173     | 174     | 174     | 174     | 174 e   | 174 e   | 174 o   | 174 e   | 174 e   | 174 e   |
| Fiji                | 12 u    | 12 u    | 12 u    | 12 u    | 24 u    | 24 u    | 24 e    | 24 e    | 24 e    | 24 e    |
| New Zealand         | 99      | 99      | 99      | 99      | 104     | 104     | 104     | 98      | 98 o    | 98 e    |
| Papua N Guin        | 15 u    | 15 u    | 15 u    | 15 u    | 15 u    | 15 u    | 15 e    | 15 e    | 15 e    | 15 e    |
| Samoa               |         |         |         |         |         |         |         | 1 e     | 1 e     | 1 e     |
| Solomon Is          | 1 e     | 1 e     | 1 u     | 1 u     | 1 u     | 1 u     | 1 e     | 1 e     | 1 e     | 1 e     |
| S America           | 3 802   | 3 721   | 3 548   | 3 856   | 4 124   | 4 122   | 4 306   | 4 305   | 4 753   | 5 380   |
| Argentina           | 165 e   | 164 e   | 173 e   | 181 e   | 170 e   | 144 e   | 197 e   | 195 e   | 155 e   | 152 e   |
| Bolivia             |         |         |         |         |         |         |         |         | 11 e    |         |
| Brazil              | 1 989   | 2 264   | 2 539 o | 2 846 e | 3 136 o | 3 159 o | 3 255 o | 3 301 o | 3 801 o | 4 390 o |
| Chile               | 1 240 e | 884 e   | 417 e   | 410 e   | 410 e   | 410 e   | 442 o   | 396 o   | 375 o   | 426 o   |
| Colombia            |         |         |         |         | 0 o     | 0 o     |         |         |         |         |
| Fr Guiana           | 2 o     | 2 o     | 2 o     | 2 o     | 2 o     | 2 o     | 5 o     | 5 e     | 5 o     | 5       |
| Guyana              |         |         | 0       | 0       | 0       | 1       | 1       | 1 e     | 1 e     | 1 e     |
| Suriname            |         |         | 2       | 2       | 2       | 2 e     | 2 e     | 2 e     | 2 e     | 2 e     |
| Uruguay             | 406 o   | 406 o   | 416 o   | 416 o   | 405 o   | 405 o   | 405 e   | 405 o   | 405 e   | 405 o   |

## Liquid biofuels Biocarburants liquides Biocarburantes líquidos

| CAP (MW)            | 2013   | 2014   | 2015   | 2016   | 2017   | 2018   | 2019   | 2020   | 2021   | 2022   |
|---------------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| World               | 2 001  | 2 298  | 2 378  | 2 282  | 2 317  | 2 382  | 2 607  | 2 532  | 2 544  | 2 557  |
| Africa              | 0      | 0      | 0      | 0      | 0      | 41     | 41     | 41     | 41     | 41     |
| Burkina Faso        | 0 u    | 0 u    | 0 u    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    |
| Reunion             |        |        |        |        |        | 41 o   | 41 o   | 41 o   | 41 o   | 41 e   |
| Tanzania            |        | 0 u    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    |
| Asia                |        | 356    | 361    | 360    | 359    | 348    | 348    | 293    | 329    | 329    |
| Korea Rep           |        | 356    | 361    | 360    | 359    | 348    | 348    | 293 e  | 329 e  | 329 e  |
| Eurasia             |        | 7      | 7      | 7      | 12     | 19     | 19     | 23     | 23     | 23     |
| Türkiye             |        | 7      | 7      | 7      | 12     | 19     | 19     | 23     | 23     | 23     |
| Europe              | 1 879  | 1 797  | 1 865  | 1 792  | 1 813  | 1 791  | 2 128  | 2 104  | 2 081  | 2 081  |
| Austria             | 6      | 1      | 3      | 3      | 1      | 1      | 1      | 0      | 0      | 0      |
| Belgium             | 50     | 51     | 49     | 45     | 45     | 45     | 45 e   | 23     | 19     | 19     |
| Denmark             | 7      |        | 1      | 0      | 1      | 1      |        |        |        |        |
| France              |        |        | 3      | 4      | 0      | 0      | 0      | 15     | 10     | 10     |
| Germany             | 263    | 232    | 232    | 231    | 230    | 230    | 231    | 231 e  | 230    | 230    |
| Italy               | 1 003  | 990    | 1 000  | 993 e  | 987    | 971    | 948    | 932    | 919 e  | 919    |
| Poland              | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0      |
| Slovenia            | 1      | 1      | 1      | 1      | 1      | 1      | 1 o    | 1      | 1 e    | 1      |
| Spain               |        |        |        |        |        | 6      | 6 e    | 6 e    | 6 e    | 6      |
| Sweden              | 548    | 522    | 576    | 515    | 547    | 535    | 895    | 895 e  | 895 e  | 895    |
| European Union (27) | 1 879  | 1 797  | 1 865  | 1 792  | 1 813  | 1 832  | 2 169  | 2 145  | 2 122  | 2 122  |
| N America           | 115    | 115    | 115    | 115    | 125    | 175    | 62     | 62     | 62     | 62     |
| USA                 | 115 o  | 115 o  | 115 o  | 115 o  | 125 o  | 175 o  | 62 o   | 62 o   | 62 o   | 62 o   |
| Oceania             | 3      | 3      | 3      | 3      | 3      | 3      | 3      | 3      | 3      | 3      |
| Fiji                | 0 u    | 0 u    | 0 u    | 0 u    | 0 u    | 0 u    | 0 e    | 0 e    | 0 e    | 0 e    |
| New Caledon         | 0 o    | 0 o    | 0 o    | 0 o    | 0 o    | 0 o    | 0 e    | 0 e    | 0 e    | 0 e    |
| Solomon Is          |        | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    | 0 e    |
| Vanuatu             | 3 e    | 3 e    | 3 e    | 3 e    | 3 e    | 3 e    | 3 e    | 3 e    | 3 e    | 3 e    |
| S America           | 4      | 19     | 27     | 4      | 5      | 5      | 5      | 5      | 5      | 18     |
| Brazil              | 4      | 19     | 27     | 4 o    | 5 o    | 5 o    | 5 o    | 5 o    | 5 o    | 18 o   |

## Biogas Biogaz Biogás

| CAP (MW)                   | 2013         | 2014         | 2015     | 2016     | 2017         | 2018      | 2019         | 2020      | 2021       | 2022       |
|----------------------------|--------------|--------------|----------|----------|--------------|-----------|--------------|-----------|------------|------------|
| World                      | 14 151       | 15 188       | 15 863   | 16 847   | 17 446       | 18 495    | 19 300       | 20 652    | 20 906     | 21 376     |
| Africa                     | 11           | 11           | 26       | 35       | 38           | 43        | 54           | 54        | 99         | 99         |
| Burkina Faso               |              |              | 1 o      | 1 o      | 1 o          | 1 e       | 1 e          | 1 e       | 1 e        | 1 e        |
| Egypt                      |              |              |          |          |              |           | 12 o         | 12 e      | 56 e       | 56 e       |
| Gabon                      |              |              | 1 e      | 1 e o    | 1 e 0 e      | 1 e 0 o   | 1 e          | 1 e o     | 1 e 0 e    | 1 e        |
| Ghana Kenya                | 0 e          | 0 e          | 0 o 3 e  | 0 3 e    | 2 e          | 2 e       | 0 e 2 e      | 0 2 e     | 2 e        | 0 o 2 e    |
| Mauritius                  | 3            | 3            | 3        | 3 o 7    | 3 e 7        | 3 e 7     | 3 e 7        | 3 e 7     | 3 e 7 e    | 3 e        |
| Morocco Nigeria            | 1 o          | 1 o          | 5 o      | 0 u      | 0 u          | 0 u       | 0 e          | 0 e       | 0 e        | 7 e 0 e    |
| Reunion                    | 2 o          | 2 o          | 3 o      | 4 o      | 4 e          | 4 o       | 4 e          | 4 e       | 4 e        | 4 e        |
| South Africa               | 4 e          | 4 e          | 9 e      | 14 e     | 18 e         | 23 u      | 23 e         | 23 e      | 23 e       | 23 e       |
| Tanzania                   | 1 o          | 1 o          | 1 o      | 1 u      | 1 e          | 1 e       | 1 e          | 1 e       | 1 e        | 1 e        |
| Asia                       | 650          | 846          | 972      | 1 157    | 1 374        | 1 626     | 1 876        | 2 398     | 2 948      | 3 173      |
| Bangladesh                 | 3 o          | 4 o          | 4 o      | 5 o      | 5 o          | 5 o       | 5 o          | 5 o       | 5 e        | 5 e        |
| Cambodia                   |              |              | 2 e      | 2 e      | 2 e          | 2 e       | 2 e          | 2 e       | 2 e        | 2 e        |
| China                      | 193          | 310          | 331      | 350      | 454          | 630       | 799          | 1 285 o   | 1 711 o    | 1 928 e    |
| China HK SAR Taipei        |              |              |          | 17       | 17           | 17        | 24           | 24        | 24         | 24 e       |
| Chinese India              | 6 o          | 7 o          | 1 o 10 o | 1 o 10 o | 1 o 13 e     | 1 e 14 e  | 1 o 14 e     | 1 o 14 e  | 1 e 14 e   | 1 e 14 e   |
| Indonesia                  | 18 o         | 19 o         | 55 o     | 64 e     | 101 e        | 109 e     | 112 o        | 120 e     | 135 e      | 135 e      |
| Japan                      | 10           | 15           | 23       | 34       | 47           | 59        | 70           | 77 o      | 85 o       | 94 o       |
| Kazakhstan                 | 0            | 0            | 0        | 0        | 1 o          | 1 o       | 2 e          | 8         | 8 e        | 8          |
| Korea Rep                  | 99           | 121          | 113      | 129      | 136 o        | 140       | 139          | 117 e     | 131 e      | 131 e 0 e  |
| Lao PDR Malaysia           | 14 o         | 18 o         | 20 o     | 58 o     | 62 o         | 0 o 70 o  | 0 o 103 e    | 0 o 111 e | 0 o 120 e  | 120 e      |
| Myanmar                    | 1 e          | 1 e          | 1 e      | 1 e      | 1 e          | 1 e       | 1 e          | 1 e       | 1 e        | 1 e        |
| Pakistan                   | 9 e e        | 9 e          | 9        | 10 e     | 10 e         | 10 e      | 10 e         | 10 e      | 10 e       | 10 e       |
| Philippines                | 31           | 31 e         | e 31 e   | 40 e     | 42 e         | 54 e      | 54 o         | 56 e      | 56 e       | 56 o       |
| Sri Lanka                  |              |              | 0 o      | 0 o 435  | 0 o          | 0 o       | 0 e o        | 0 e       | 0 u 635    | 0 e        |
| Thailand                   | 266          | 312          | 373      | 2 e      | 475 9 e      | 505 o 9 e | 530 9 e      | 557 o 9 e | o 9 e      | 635 e 9 e  |
| Viet Nam C America + Carib | 14           | 13           | 16       | 31       | 35           | 42        | 43           | 46        | 45         | 45         |
| Costa Rica                 | 4            | 2            | 3        | 3 1      | 3 1          | 3 o       | 4            | 5         | 5 o 1      | 5 o 1 e    |
| Cuba                       | 1 o          | 1 e          | 1 e      | e        | e            | 1 e 2 e   | 1 e          | 1 e 2 e   | e          | e          |
| Dominican Rep El Salvador  | 6            | 1 o 6        | 2 o 7    | 2 o 7    | 2 o 7        | 7         | 2 e 7        | 7 o       | 2 e 7 e    | 2 7 e      |
| Guadeloupe                 | 0            | 0            |          | 0        | 0            | 5 o       | 5 o          | 5 o       | 5 e        | 5 e        |
| Guatemala                  | 1            | 1            | 0 4      | 4        |              | 7 o       | 7 o          | 7 o       |            |            |
| Honduras                   | 1 o          | 1 e          | 0 e      | 4 e      | 7 4 e        | 4 e       | 4 e          | 4 e       | 6 o 4 e    | 6 o 4 e    |
| Martinique                 |              |              | 1        | 1 o      | 1 o          | 1         | 1            | 1         | 1 e        | 1 e        |
| Nicaragua                  |              |              |          | 0 e      | 0 e          | 2 e       | 2 e          | 2 e       | 2 e        | 2 e        |
| Panama Puerto Rico         |              |              | o        | 8 2 o    | 8 o 2 o      | 8 e 2 o   | 8 o 2 o      | 8 e 5 e   | 8 o 5 o    | 8 5 o      |
| Eurasia                    | 162          | 204          | 253      | 298      | 378          | 440       | 549          | 742       | 979        | 1 104      |
| Azerbaijan                 |              | 204          | 1 252    | 1 297    | 1 377        | 1 o 438   | 1 e          | 1         | 1          | 1          |
| Türkiye                    | 162          |              | 299      | 11 777   |              | 12 917    | 548          | 741       | 979        | 1 103      |
| Europe Austria             | 10 210 194 e | 10 845 189 e | 11       | 202      | 12 200       | 175 o     | 13 324 164 e | 13 966    | 13 499 166 | 13 593 166 |
| Belarus                    | 22           | 22           | 191 e 22 | e 27     | 180 e 28     | 33 o      | 38 e         | 165 e 37  | e 37 e     | 37         |
| Belgium Herzg              | 151          | 181          | 179      | 188      | 183          | 190       | 197 1        | 199       | 204        | 204        |
| Bosnia Bulgaria            | 4            | 10           | 20       | 1 u 38   | 1 e 29       | 1 36 e    | 33 e         | 1 33 e    | 1 33 o     | 1 33       |
| Croatia                    | 17           | 17           | 28       | 37 o     | 45 o         | 51 o      | 52 e         | 55 o      | 59 o       | 59         |
| Cyprus                     | 10           | 10           | 10       | 10       | 10 e         | 13 o      | 13 o         | 13 o      | 13 e       | 13         |
| Czechia                    | 361 o        | 367 o        | 368 o    | 369 o    | 372 o        | 369 o     | 368 e        | 366 e     | 370 e      | 370        |
| Denmark                    | 93 e         | 96 e         | 104 e    | 107 e    | 108 e        | 108 e     | 121 e        | 132 e     | 128 e      | 128        |
| Estonia Islands            | 6 e          | 8 e          | 11 e     | 11 e     | 11 e         | 9 e       | 8 e          | 11 e      | 11 o       | 11         |
| Faroe                      | 88           | 100 e        | 102 e    | 114 424  | 116          | 116       | 116          | 0 o 116 o | 0 e 116 e  | 0 116      |
| Finland France             | e 311        | 356 5 437 o  | 400 643  | 850      | 463          | 487       | 523 081      | 546 494 e | 564 6 961  | 571 961    |
| Germany                    | 5 148 o u    | u            | 5 o u    | 5 o 56 u | 6 147 o 62 u | 6 784 o u | 7 o 75       | 7 83 e    | e 92 e     | 6 92       |
| Greece Hungary             | 46           | 47           | 49 72    | 76       | 82           | 70        | o 79         | 85        | 85         | 85         |
| Ireland                    | 63 52 o      | 63 53 o      | 53 o     | 56       | 56           | 76 57     | 59 e         | 59        | 60 e       | 60         |
| Italy                      | 1 317 e      | 1 336        | 1 336    | o 352    | o 1          | 1 375     | 1 382        | o 1       | 1 382      | 1 382      |
| Latvia                     | 53           | 58 e         | 60 e     | 1 62 e e | 372 60       | 61        | 61 e         | 379 60 e  | 57 o       | 57         |
| Lithuania Luxembourg       | 16 10        | 20           | 21 12    | 25 12    | 25 e         | 35 o      | 35 o         | 36 e 12 o | 37 e       | 37 12      |
|                            |              | 10           |          |          | 12           | 12        | 12 e         |           | 12 o       |            |
| Malta Moldova              | 3 2          | 3            | 3        | 5        | e 5          | e 5 e     | 5 e          | 5 e       | 5 e        | 5 12       |
| Rep Netherlands            |              | 3            | 3 244 e  | 3 224    | 6            | 6         | 6 201        | 7 e       | 6 e        | 204        |
| North                      | 230 e        | 237          | e        |          | 224 e        | 207 u     | e            | 205       | 204        |            |
|                            |              | e 17         | 4        | 5 10     | 7            | 7 10 e    | 8 7          | 8         | 8          | 8 7        |
|                            |              |              |          |          |              | o         |              | 11        | 7          |            |
| Norway                     |              |              | 17       |          | 10 e         |           |              | o         | e          |            |
| Macedonia                  | 17           |              |          |          |              |           |              |           |            |            |

## Biogas Biogaz Biogás

| CAP (MW)            | 2013    | 2014    | 2015    | 2016    | 2017    | 2018    | 2019    | 2020    | 2021    | 2022    |
|---------------------|---------|---------|---------|---------|---------|---------|---------|---------|---------|---------|
| Poland              | 153 o   | 187 o   | 216 o   | 225 o   | 229 e   | 225 e   | 233 e   | 261 e   | 251 e   | 262     |
| Portugal            | 55      | 66      | 66      | 68      | 70      | 71      | 72      | 71      | 73 e    | 73      |
| Romania             | 11      | 15      | 14      | 16      | 22      | 22      | 20      | 30      | 32      | 32      |
| Serbia              | 4       | 5       | 5       | 10      | 13      | 17      | 26      | 29      | 34      | 34      |
| Slovakia            | 35      | 78      | 91      | 93      | 91      | 89      | 82      | 82 e    | 81      | 81      |
| Slovenia            | 28      | 31      | 32      | 29      | 27      | 27      | 25      | 30      | 30      | 30      |
| Spain               | 243     | 243     | 245     | 248     | 251     | 258     | 267     | 269     | 271     | 271     |
| Sweden              | 5 e     | 2 e     | 2 e     | 2 e     | 2 e     | 2 o     | 2 e     | 100 e   | 100 e   | 100     |
| Switzerland         | 33      | 32      | 29      | 29 o    | 30      | 30      | 30      | 34 o    | 34 e    | 34      |
| UK                  | 1 414   | 1 531   | 1 628   | 1 774   | 1 819 o | 1 837   | 1 832   | 1 839   | 1 853   | 1 923   |
| Ukraine             | 14 o    | 15 o    | 18 o    | 21 o    | 34 o    | 46 o    | 93      | 103     | 123 e   | 123 e   |
| European Union (27) | 8 706   | 9 221   | 9 576   | 9 903   | 10 257  | 10 941  | 11 295  | 11 908  | 11 406  | 11 424  |
| Middle East         | 35      | 42      | 62      | 69      | 70      | 68      | 68      | 69      | 69      | 71      |
| Iran IR             | 7       | 11      | 11 e    | 11 e    | 11 e    | 11 e    | 11 e    | 11 e    | 11 o    | 11 e    |
| Israel              | 11 e    | 14 e    | 25 e    | 25 e    | 25 e    | 25 e    | 25 e    | 26 e    | 26 e    | 26 e    |
| Jordan              | 4 o     | 4 o     | 13 u    | 13 u    | 13 e    | 13 e    | 13 e    | 13 e    | 13 e    | 13 e    |
| Lebanon             | 2 u     | 2 u     | 2 u     | 9 e     | 9 e     | 7 e     | 7 e     | 7 e     | 7 e     | 7 e     |
| Palestine           |         |         |         |         | 0       | 0 e     | 0 e     | 0 e     | 0 e     | 0 e     |
| Qatar               | 4 e     | 4 e     | 4 e     | 4 e     | 4 e     | 4 e     | 4 e     | 4 e     | 4 e     | 4 e     |
| Syrian AR           | 7 e     | 7 e     | 7 e     | 7 e     | 7 e     | 7 e     | 7 e     | 7 e     | 7 e     | 7 e     |
| United Arab Em      | 1 o     | 1 o     | 1 o     | 1 o     | 1 o     | 1 e     | 1 u     | 1 u     | 1 e     | 3 e     |
| N America           | 2 579   | 2 704   | 2 681   | 2 694   | 2 752   | 2 708   | 2 633   | 2 525   | 2 391   | 2 377   |
| Canada              | 269 e   | 271 e   | 272 e   | 272 e   | 277 e   | 277 e   | 277 e   | 283 e   | 283 e   | 283 e   |
| Mexico              | 36      | 36      | 36      | 47 o    | 57 o    | 55 o    | 55 o    | 57 o    | 64 o    | 65 e    |
| USA                 | 2 273 o | 2 397 o | 2 373 o | 2 375 o | 2 419 o | 2 376 o | 2 301 o | 2 184 o | 2 043 o | 2 029 o |
| Oceania             | 269     | 279     | 282     | 241     | 240     | 240     | 240     | 247     | 248     | 249     |
| Australia           | 220     | 226     | 228     | 190 o   | 190 o   | 190 o   | 190     | 197 o   | 198 o   | 199 e   |
| New Zealand         | 45      | 49      | 50      | 47      | 46 o    | 46 o    | 46 o    | 46 e    | 46 e    | 46 e    |
| Papua N Guin        | 4 u     | 4 u     | 4 u     | 4 u     | 4 u     | 4 u     | 4 e     | 4 e     | 4 e     | 4 e     |
| S America           | 223     | 245     | 272     | 546     | 360     | 411     | 513     | 605     | 628     | 666     |
| Argentina           | 17 o    | 17 o    | 17 o    | 17 o    | 21 o    | 23 o    | 44 o    | 55 e    | 69 e    | 73      |
| Bolivia             |         |         |         |         |         |         | 5 o     | 5 o     | 5 o     | 5 o     |
| Brazil              | 173     | 178 o   | 196 o   | 461 o   | 262 o   | 302 o   | 372 o   | 452 o   | 452 o   | 486 o   |
| Chile               | 27      | 42      | 49      | 53      | 56 o    | 57 o    | 60 o    | 55 o    | 64 o    | 64 o    |
| Colombia            |         |         |         | 4       | 4       | 4 o     | 4 o     | 9 o     | 9       | 9       |
| Ecuador             |         |         |         | 2 o     | 7 o     | 7 o     | 7 o     | 7 o     | 8 o     | 8       |
| Paraguay            | 0 e     | 0 e     | 0 e     | 0 e     | 0 e     | 0 e     | 2 o     | 2 e     | 2 e     | 2 e     |
| Peru                | 5       | 5 o     | 7 o     | 7 o     | 7 o     | 10 o    | 10      | 10 o    | 10 o    | 10 o    |
| Uruguay             | 1       | 2 e     | 2 e     | 2 e     | 2 e     | 8 e     | 8 e     | 8 e     | 8 e     | 8 o     |

## Geothermal energy Énergie géothermique Energía geotérmica

| CAP (MW)               | 2013    | 2014       | 2015     | 2016       | 2017       | 2018       | 2019       | 2020       | 2021         | 2022         |
|------------------------|---------|------------|----------|------------|------------|------------|------------|------------|--------------|--------------|
| World                  | 10 983  | 11 424     | 12 085   | 12 405     | 13 025     | 13 471     | 14 089     | 14 417     | 14 696       | 14 877       |
| Africa                 | 213     | 373        | 626      | 660        | 680        | 691        | 691        | 870        | 870          | 956          |
| Ethiopia               | 7       | 7          | 7        | 7          | 7          | 7 e        | 7 o        | 7          | 7            | 7 o          |
| Kenya                  | 206 o   | 366 o      | 619 o    | 653 o      | 673 o      | 684 o      | 684 o      | 863 o      | 863 o        | 949 o        |
| Asia                   | 3 728   | 3 854      | 3 896    | 4 001      | 4 226      | 4 375      | 4 540      | 4 540      | 4 700        | 4 711        |
| China                  | 26      | 26         | 26       | 26         | 26         | 26         |            |            |              |              |
| Chinese Taipei         |         |            |          |            |            | 0 o        | 0 o        | 0 o        | 5 o          | 5 o          |
| Indonesia              | 1 344 o | 1 404 o    | 1 438 o  | 1 533 o    | 1 808 o    | 1 948 o    | 2 131 o    | 2 131 o    | 2 286 o      | 2 343 o      |
| Japan                  | 512     | 508        | 516      | 526        | 476        | 473        | 481        | 481 o      | 481 o        | 431 o        |
| Philippines            | 1 847 o | 1 916 o    | 1 916 o  | 1 916 o    | 1 916 o    | 1 928 o    | 1 928 o    | 1 928 o    | 1 928 o      | 1 932 o      |
| Thailand               | 0       | 0          | 0        | 0          | 0          | 0 e        | 0 o        | 0 o        | 0 e          | 0 e          |
| C America + Carib      | 641     | 637        | 640      | 629        | 665        | 665        | 722        | 723        | 723          | 724          |
| Costa Rica             | 218     | 218        | 217      | 207        | 207        | 207 o      | 262 o      | 262 o      | 262 o        | 263 o        |
| El Salvador            | 204     | 204        | 204      | 204        | 204        | 204 o      | 204 o      | 204 o      | 204 e        | 204 e        |
| Guadeloupe             | 15      | 12         | 15       | 15         | 15 u       | 15 e       | 15 o       | 15 e       | 15 e         | 15 e         |
| Guatemala              | 49      | 49         | 49       | 49         | 49         | 49 o       | 52 o       | 49 o       | 49 o         | 49 o         |
| Honduras               |         |            |          |            | 35 o       | 35 o       | 35 o       | 39 o       | 39 o         | 39 o         |
| Nicaragua              | 155     | 155        | 155      | 155        | 155        | 155 o      | 153 o      | 153 o      | 153 e        | 153 e        |
| Eurasia                | 390     | 483        | 702      | 899        | 1 138      | 1 357      | 1 596      | 1 687      | 1 750        | 1 765        |
| Russian Fed Türkiye    | 79 311  | 78 405     | 78 624   | 78 821     | 74 1 064 o | 74 1 283   | 81 1 515   | 74 1 613 o | 74 1 676 o   | 74 1 691     |
| Europe                 | 1 461   | 1 503      | 1 503    | 1 507      | 1 558      | 1 617      | 1 622      | 1 627      | 1 634        | 1 634        |
| Austria                | 1       | 1          | 1        | 1          | 1          | 1          | 1 e        | 1 o        | 1 e          | 1            |
| Croatia                | 15      | 15         |          |            | 16         | 10         | 10 o       | 10 o       | 10 o         | 10           |
| France                 |         | 29         | 15 29    | 16         | 32         | 16         | 16         | 16         | 16 e         | 16           |
| Germany Hungary        | 26      |            |          | 33         |            | 35         | 40         | 40 e       | 46           | 46           |
|                        |         |            |          |            | 3 u        | 3 e        | 3          | 3 o        | 3 e          | 3            |
| Iceland                | 665     | 665        | 665      | 665        | 710        | 756        | 756        | 756        | 757          | 757          |
| Italy                  | 729     | 768        | 768      | 767        | 767        | 767 e      | 767        | 772        | 772          | 772          |
| Portugal               | 25      | 25         | 25       | 25         | 29         | 29         | 29         | 29         | 29 o         | 29           |
| Romania                |         | 0 o        | 0 o      | 0 o        | 0 o        | 0          | 0 u        | 0 o        | 0 e          | 0            |
| European Union (27)    | 811     | 849        | 852 3    | 857        | 863        | 876 3 429  | 881        | 886        | 892 656      | 892 3 712    |
| N America              | 3 430   | 3 327      | 448      | 3 443      | 3 468      |            | 3 589      | 3 606      | 3            | 1 059        |
| Mexico                 | 823 2   | 813 514 o  | 906 2 o  | 926        | 985        | 985        | 1 034      | 1 034      | 1 059 o      | e 2 653      |
| USA                    | 607     | 2          | 542      | 2 517 o    | 2 483 o    | 2 444 o    | 2 555 o    | 2 572 o    | 2 597 o      | o            |
| Oceania Australia      | 1 120   | 1 246 0    | 1 270 0  | 1 265 0    | 1 265      | 1 289      | 1 289      | 1 323      | 1 323        | 1 323        |
|                        | 0 1 070 |            | 1        |            | 0 e        |            | 0 u        | 0 e        | 0 e          | 0 e          |
| New Zealand            | 50 e    | 1 196 50 e | 220 50 e | 1 215 50 e | 1 215 50 e | 1 239 50 e | 1 239 50 e | 1 273 50 e | 1 273 o 50 e | 1 273 e 50 e |
| Papua N Guin S America |         |            |          |            | 24         | 48         | 40         | 40         | 40           | 51           |
| Chile                  |         |            |          |            | 24 o       | 48         | 40 o       | 40 o       | 40 o         | 51 o         |

Off-grid capacity

Capacité hors réseau Capacidad aislada

## Total renewable energy Total énergies renouvelables Total energías renovables

| CAP (MW)                       | 2013            | 2014            | 2015                    | 2016                  | 2017                 | 2018                    | 2019           | 2020           |                | 2021 2022               |
|--------------------------------|-----------------|-----------------|-------------------------|-----------------------|----------------------|-------------------------|----------------|----------------|----------------|-------------------------|
| World                          | 5 532.411       | 6 523.984       | 7 214.308               | 7 750.937             | 7 617.277            | 9 496.025               | 9 916.695      | 10 436.724     | 11 199.017     | 12 435.683              |
| Africa                         | 445.584         | 529.948         | 650.581                 | 770.207               | 873.564 1            | 023.496                 | 1 144.181      | 1 238.443      | 1 144.181      | 1 422.508               |
| Algeria                        |                 | 11.300          | 59.296                  | 98.396                | 98.396               | 111.196                 | 111.196        | 111.196        | 111.196        | 123.196                 |
| Angola                         | 32.458          | 34.821          | 35.726                  | 36.236                | 48.656               | 48.656                  | 48.656         | 48.656         | 48.656         | 48.656                  |
| Benin                          |                 |                 |                         | 1.500                 | 1.500                | 1.500                   | 1.500          | 1.540          | 1.500          | 1.540                   |
| Botswana Burkina Faso          | 0.415 6.450     | 0.560 7.150     | 0.853 8.150             | 1.926 10.150          | 2.061 12.150         | 2.366 27.150            | 2.366 29.650   | 2.365 29.650   | 2.366 29.650   | 2.365 29.650            |
| Burundi                        | 7.803           | 8.003           | 8.303                   | 9.303                 | 10.303               | 10.303                  | 10.303         | 10.303         | 10.303         | 10.303                  |
| Cabo Verde                     | 0.151           | 0.305           | 0.618                   | 0.674                 | 0.735                | 0.801                   | 0.846          | 0.846          | 0.846          | 0.846                   |
| Cameroon                       | 3.900           | 5.900           | 7.700                   | 9.300                 | 11.896               | 14.492                  | 14.492         | 14.617         | 14.492         | 14.617                  |
| Cent Afr Rep                   | 0.500           | 0.500           | 0.500                   | 0.500                 | 0.500                | 0.500                   | 0.516          | 0.516          | 0.516          | 0.516                   |
| Chad DR                        | 0.050           | 0.050           | 0.172                   | 1.273                 | 1.273                | 1.290                   | 1.290 164.487  | 1.327 164.487  | 1.290 164.487  | 1.327 164.487           |
| Congo Congo Rep                | 98.349 0.230    | 98.568 0.460    | 111.732 0.460           | 114.297 0.460         | 129.095 0.570        | 154.587 0.720           | 0.720          | 0.720          | 0.720          | 0.720                   |
| Cote d Ivoire                  | 2.908           | 3.834           | 5.059                   | 5.059                 | 8.278                | 13.144                  | 13.144         | 13.144         | 13.144         | 13.144                  |
| Djibouti                       | 0.300           | 0.300           | 0.300                   | 0.362                 | 0.362                | 0.362                   | 0.362          | 0.362          | 0.362          | 20.362                  |
| Egypt                          | 20.000          | 20.000          | 21.000                  | 35.000                | 35.000               | 49.200                  | 35.200         | 37.000         | 35.200         | 71.000                  |
| Eq Guinea                      |                 |                 |                         | 0.154                 | 0.348                | 0.348                   | 0.330          | 0.319          | 0.330          | 0.183                   |
| Eritrea                        | 0.860           | 8.684           | 8.684                   | 9.839                 | 12.179               | 12.429                  | 12.427         | 12.414         | 12.427         | 11.632                  |
| Eswatini                       | 2.478           | 2.504           | 2.504                   | 2.504                 | 2.504                | 2.504                   | 2.504          | 2.504          | 2.504          | 2.504                   |
| Ethiopia                       | 4.623           | 10.410          | 11.169                  | 15.325                | 13.779               | 13.631                  | 13.631         | 21.469         | 13.631         | 22.469                  |
| Gabon                          | 1.600           | 1.600           | 2.800                   | 2.887                 | 2.887                | 2.887                   | 2.887          | 2.887          | 2.887          | 2.887                   |
| Gambia                         | 1.995           | 2.000           | 2.000                   | 2.000                 | 2.002                | 2.002                   | 2.002          | 2.002          | 2.002          | 2.122                   |
| Ghana                          | 6.774           | 9.624           | 13.903                  | 15.141                | 15.877               | 15.881                  | 15.881         | 15.881         | 15.881         | 16.028                  |
| Guinea Guinea Bissau           | 2.291           | 2.291           | 2.293 0.312             | 2.453 0.312           | 2.652 0.312          | 2.915 1.169             | 3.606 1.169    | 4.222 1.169    | 3.606 1.169    | 4.333 1.169             |
| Kenya                          | 12.368          | 20.901          | 35.044                  | 40.483                | 52.714               | 60.782                  | 76.257         | 106.771        | 76.257         | 131.772                 |
| Lesotho                        | 0.343           | 0.343           | 0.343                   | 0.343                 | 0.343                | 0.343                   | 0.343          | 0.343          | 0.343          | 0.393                   |
| Liberia                        | 4.050           | 4.090           | 4.107                   | 4.169                 | 6.591                | 6.768                   | 6.768          | 6.768          | 6.768          | 6.768                   |
| Libya Madagascar               | 4.900 8.985     | 4.900 11.630    | 4.900 14.660            | 4.900 16.660          | 5.110                | 5.110 18.760            | 5.110 18.760   | 5.111 18.760   | 5.110 18.760   | 6.333 18.760            |
| Malawi                         | 5.965           | 8.234           | 12.657                  | 12.957                | 18.760 20.037        | 27.244                  | 81.323         | 82.635         | 81.323         | 83.923                  |
| Mali                           | 35.346          | 43.755 7.551    | 44.783 7.566            | 45.314                | 47.154               | 47.398                  | 48.233 25.609  | 48.370         | 48.233         | 79.011 25.609           |
| Mauritania                     | 7.400           | 0.107           |                         | 24.166                | 24.166               | 25.466                  | 4.815          | 25.609         | 25.609         |                         |
| Mauritius Morocco              | 0.126 20.000    | 23.800          | 0.134                   | 0.915                 | 3.287 27.895         | 3.440 27.895            | 27.903         | 4.148 28.000   | 4.815 27.903   | 3.380 28.000            |
| Mozambique                     | 5.175           | 7.900           | 23.800 11.060           | 25.870 14.060         | 16.060               |                         | 16.060         | 21.501         | 16.060         | 30.708                  |
| Namibia                        | 13.402          | 14.180          | 14.180                  | 14.180                | 14.198               | 16.060 21.951           | 23.891         | 23.891         | 23.891         | 23.891                  |
| Niger                          | 5.000           | 6.000           | 7.000                   | 8.000                 | 9.041                | 20.041                  | 20.041         | 20.041         | 20.041         | 20.041                  |
| Nigeria                        | 22.900          | 24.600          | 26.400                  | 27.830                | 28.030               | 28.195                  | 37.174         | 37.643         | 37.174         | 37.643                  |
| Reunion Rwanda                 | 2.532           | 3.075           | 3.655                   | 4.865                 | 6.731                | 11.665                  | 1.340 15.106   | 1.340 15.272   | 1.340 15.106   | 1.340 15.272            |
| Sao Tome Prn                   | 0.063           | 0.098 7.000     | 0.119 7.000             |                       | 0.316 7.000          | 0.334                   | 0.334          | 0.334          | 0.334          | 0.334 7.000             |
| Senegal                        | 7.000 0.068     |                 |                         | 0.157 7.000           |                      | 7.000                   | 7.000          | 7.000          | 7.000          |                         |
| Seychelles Sierra              | 0.634           | 0.068 0.645     | 0.068                   | 0.068 0.734           | 0.068 8.720          | 1.022 9.136             | 1.022 9.136    | 1.022 9.136    | 1.022 9.136    | 1.022 9.176             |
| Leone Somalia                  | 2.200           | 2.300           | 0.670 2.970             | 7.470                 | 10.444               | 10.618                  | 10.618         | 19.088         | 10.618         | 50.588                  |
| South Africa                   | 7.948           | 9.391           |                         | 10.142                | 12.924               | 12.785 0.737            | 13.213         | 12.978         | 13.213         | 12.875 2.061            |
| South Sudan                    | 0.160           | 0.160           | 9.866                   | 0.428                 | 0.449                |                         | 0.835          | 0.835          | 0.835 80.199   |                         |
| Sudan Tanzania                 | 14.666 34.974   | 16.584          | 0.160 19.911            | 26.219                | 35.800               | 59.478 58.764           | 80.199 56.846  | 116.840 56.846 | 56.846         | 135.570 56.846          |
|                                | 0.007           | 46.248          | 53.675                  | 53.161                | 54.838               |                         | 5.460          | 6.460          | 5.460          | 6.493                   |
| Togo                           |                 | 0.022           | 0.062                   | 0.082                 | 0.972                | 3.490                   | 7.076          | 7.076          | 7.076          |                         |
| Tunisia Uganda                 | 1.555 27.500    | 1.563 29.000    | 1.710 34.500            | 2.060 36.500          | 2.076 39.400         | 2.076 39.240            | 39.360         | 39.520         | 39.360         | 7.076 39.839            |
| Zambia                         | 2.667           | 2.667           | 1.917                   |                       | 1.951                | 2.081                   | 9.921          | 9.921          | 9.921          | 9.949                   |
| Zimbabwe                       | 3.515           | 4.272           | 4.130                   | 1.951 4.472           | 5.174                | 5.584                   | 5.263          | 5.588          | 5.263          | 4.779                   |
| Asia                           |                 |                 |                         | 6 108.761             | 5                    | 378.304                 | 7              | 8 032.762      |                | 830.846                 |
|                                | 4 413.627       | 5 259.184       | 5 738.516               |                       | 831.090              | 7                       | 644.120        |                | 7 644.120      | 9                       |
| Afghanistan                    | 41.140 98.494   | 46.109 124.615  | 50.127 148.983          | 54.814 156.444        | 58.416 180.794       | 57.948 175.078          | 57.482 197.143 | 56.914 187.425 | 57.482 197.143 | 59.076 188.128          |
| Bangladesh Bhutan Brunei Darsm | 8.353           | 8.353 0.014     | 8.353 0.014             | 8.353 0.014           | 8.353 0.015          | 8.590 0.015             | 8.590 0.016    | 8.590 0.027    | 8.590 0.016    | 8.610 0.047             |
| Cambodia                       | 2.798           | 2.992           | 4.995                   |                       | 5.777                | 5.220                   | 4.995 826.710  | 4.468 866.470  | 4.995 826.710  | 5.032                   |
| China                          | 935.774         | 586.930 201.010 |                         | 5.673 710.490 566.152 | 747.190              |                         | 081.682        | 238.922        | 081.682        |                         |
| India                          | 508.330 655.872 | 1 1 671.392     | 655.530 355.564 682.078 | 1 689.607             | 805.507 2 726.910    | 786.950 079.650 671.190 | 2 682.150      | 2 744.610      | 2 2 682.150    | 945.990 774.857 851.580 |
| Indonesia                      | 1               |                 | 1 1                     | 1 99.689              | 1 1 116.656          | 2 281.060               | 2 608.000      | 2 807.000      | 608.000        | 2 3 885.256             |
|                                | 15.262          | 71.255          | 86.517                  |                       |                      |                         |                |                |                |                         |
| Kazakhstan Korea DPR           | 6.339           | 11.158          | 22.994                  | 31.734                | 35.380               | 38.380                  | 41.380         | 41.380         | 41.380         | 41.380                  |
| Lao PDR                        | 2.475           | 2.907           | 3.259                   | 3.414                 |                      |                         | 3.704          | 3.704          | 3.704          | 3.709                   |
| Malaysia                       | 732.706         | 1 102.060 1     | 240.795 6.206           | 1 246.117 8.895       | 3.414 534.907 12.198 | 3.704 539.957           | 539.987        | 540.171        | 539.987        | 540.202 37.212          |
| Maldives                       | 3.160           | 5.289           |                         | 8.583                 | 8.583                | 17.885                  | 22.012         | 28.112         | 22.012         |                         |
| Mongolia                       | 8.583 55.809    | 8.583           | 8.583 75.584            | 88.119                | 102.289              | 8.583 110.740           | 8.583 113.730  | 8.577 109.744  | 8.583          | 8.571 105.695           |
| Myanmar                        |                 | 61.811          |                         |                       |                      |                         |                |                | 113.730        |                         |
| Nepal                          | 52.380 17.753   | 56.387 18.353   | 61.872                  | 63.973 21.653         | 33.362               | 106.174 34.428          | 106.101 35.514 | 113.371 38.825 | 106.101 35.514 | 119.418 38.863          |
| Pakistan                       | 31.567          | 32.007          | 18.520                  |                       | 105.248 44.601       |                         | 89.426         |                | 89.426         | 87.387                  |
|                                |                 |                 | 35.370                  | 44.320                |                      | 53.806                  |                | 89.329         |                |                         |
|                                |                 |                 |                         |                       |                      | 14.274                  |                |                |                | 13.963                  |
| Sri Lanka                      | 13.041          |                 |                         |                       |                      |                         |                |                |                |                         |
|                                |                 |                 |                         |                       | 14.078               |                         | 14.243         | 13.963         |                |                         |
|                                |                 | 13.218          |                         | 13.815                |                      |                         |                |                |                |                         |
|                                |                 |                 | 13.464                  |                       |                      |                         |                |                |                |                         |
| 14.243                         |                 |                 |                         |                       |                      |                         |                |                |                |                         |
| Philippines                    |                 |                 |                         |                       |                      |                         |                |                |                |                         |

## Total renewable energy Total énergies renouvelables Total energías renovables

| CAP (MW)                              | 2013              | 2014                | 2015                 | 2016                 | 2017                 | 2018                             | 2019                 | 2020                 | 2021               | 2022                |
|---------------------------------------|-------------------|---------------------|----------------------|----------------------|----------------------|----------------------------------|----------------------|----------------------|--------------------|---------------------|
| Tajikistan                            | 43.200            |                     |                      |                      | 43.200               | 44.160                           | 44.160               | 44.160               |                    |                     |
| Timor Leste                           | 1.073             | 43.200 1.051        | 43.200 1.018         | 43.200 1.012         | 0.697                | 0.697                            | 0.697                | 0.685                | 44.160 0.697       | 45.260 0.795        |
| Uzbekistan                            | 1.000             | 1.000               | 1.000                | 2.200                | 3.025                | 3.325                            | 3.325                | 3.325                | 3.325              | 3.325               |
| Viet Nam                              | 178.518           | 189.490             | 214.490              | 240.490              | 240.490              | 336.490                          | 154.490              | 82.990               | 154.490            | 66.490              |
| C America + Carib                     | 74.600            | 79.750              | 86.029               | 85.760               | 96.232               | 106.982                          | 107.009              | 114.522              | 107.009            | 138.198             |
| Antigua Barb                          |                   |                     |                      | 0.010                | 0.414                | 0.414                            | 0.414                | 0.414                | 0.414              | 0.414               |
| Bahamas                               | 0.025             | 0.126               | 0.147                | 0.200                | 0.146                | 0.115                            | 0.058                | 0.058                | 0.058              | 0.058               |
| Belize                                | 0.179             | 0.185               | 0.189                | 0.189                | 0.196                | 0.196                            | 0.790                | 0.790                | 0.790              | 0.790               |
| Br Virgin Is Costa Rica               | 0.519             | 0.519               | 1.286                | 1.447                | 1.447 4.500          | 1.455 4.500                      | 1.775 6.081          | 1.975 6.140          | 1.775 6.081        | 1.975 6.140         |
| Cuba                                  |                   |                     |                      |                      | 0.467                | 0.835                            | 8.900                | 9.124                | 8.900              | 9.847               |
| Curacao Dominica                      | 0.004 0.010       | 0.004 0.010         | 0.004 0.010          | 0.004                | 0.004                | 0.004                            | 0.004                | 0.004                | 0.004              | 0.004 0.010         |
| Dominican Rep                         | 18.254            | 20.310              | 22.591               | 0.010 24.701         | 0.010 33.949         | 0.010 39.951                     | 0.010 40.143         | 0.010 40.178         | 0.010 40.143       | 63.105              |
| El Salvador                           | 12.545            | 12.545              | 12.545               | 12.545               | 12.418               | 14.856                           | 4.016                | 4.016                | 4.016              | 4.016               |
| Guatemala                             | 2.560             | 5.434               | 8.308                | 8.308                | 8.308                | 8.308                            | 8.308                | 8.308                | 8.308              | 8.308               |
| Haiti                                 | 0.831             | 0.927               |                      | 1.195                | 1.275                | 1.318                            | 1.371                | 1.371                | 1.371              | 1.371               |
| Honduras                              | 5.156             | 5.170               | 1.154                | 9.140                | 4.525                | 4.537                            | 5.947                | 12.970               |                    |                     |
| Jamaica                               | 0.006             | 0.008               | 9.070 0.013          | 0.013                | 0.013                | 0.013                            | 0.013                |                      | 5.947              | 12.996 0.013        |
|                                       |                   |                     |                      |                      |                      |                                  |                      | 0.013                | 0.013              |                     |
| Nicaragua                             | 0.400             | 0.400               | 0.400                | 0.010                | 0.010                | 1.912                            | 4.312                | 4.312                | 4.312              | 4.312               |
| Panama                                | 34.011            | 34.011              | 30.211               | 27.711               | 28.211               | 28.211                           | 24.520               | 24.520               | 24.520             | 24.520              |
| Puerto Rico St Kitts Nevis            |                   | 0.001               | 0.001                | 0.001                | 0.062 0.001          | 0.070 0.001                      | 0.070 0.001          | 0.042 0.001          | 0.070 0.001        | 0.042 0.001         |
| St Lucia US Virgin Is                 | 0.100             | 0.100               | 0.100                | 0.176 0.100          | 0.176 0.100          | 0.176 0.100                      | 0.176 0.100          | 0.176 0.100          | 0.176 0.100        | 0.176 0.100         |
| Middle East Iran IR 0.378 Iraq 30.840 | 38.981            | 53.050 0.378 37.840 | 108.394 0.378 37.840 | 128.551 0.378 37.840 | 148.596 0.378 37.840 | 303.153 0.378 37.840 0.623 2.400 | 306.298 0.378 37.840 | 315.685 0.378 37.840 | 306.298 37.840     | 320.540 0.378 0.378 |
| Jordan 0.141 Kuwait                   | 2.400             | 0.236 3.390         | 0.557                | 0.593                | 0.588                | 7.880                            | 0.670 7.880          | 2.385 7.880          | 2.400 7.880        | 0.670 7.890         |
|                                       | 2.061             | 2.400               | 2.400 3.397          | 2.400 3.507          |                      |                                  |                      | 2.400                | 0.011              | 2.400               |
|                                       |                   |                     |                      |                      |                      |                                  | 2.400                |                      |                    | 0.011               |
| Oman                                  |                   |                     |                      |                      | 2.400 3.527          |                                  |                      |                      |                    |                     |
| Lebanon                               |                   | 0.014               |                      | 0.011                | 0.011                | 0.011                            | 0.011 1.833          | 0.011 1.833          | 1.833 0.014        | 1.833               |
| Palestine Saudi Arabia Syrian AR      |                   | 0.600               | 0.014 3.208          | 0.014 0.600          | 0.014                | 0.014 0.600                      | 0.014 0.600          | 0.014 0.600 5.597    |                    | 0.014 2.600         |
| Em Yemen Oceania                      | 0.600 0.192 2.369 | 3.192               | 0.600                |                      | 0.600 3.238          |                                  |                      | 256.747              |                    | 5.897 256.792       |
|                                       |                   | 5.000               | 60.000               | 3.208 80.000         | 100.000              | 3.407                            | 4.672 250.000        |                      | 0.600              |                     |
| United Arab                           |                   |                     |                      |                      |                      | 250.000                          |                      |                      | 4.672 250.000      |                     |
|                                       | 152.033           |                     | 158.297              | 162.702              | 164.827              | 167.283                          | 170.782              | 171.170              | 170.782            | 174.269             |
| Amer Samoa Cook Is Fiji               | 0.047             | 154.429             | 0.047                | 1.504 0.047          | 1.854 0.047          | 1.854 1.869                      | 1.854 2.606          | 1.854 2.606          | 1.854 2.606        | 1.854 2.606         |
| Fr Polynesia                          | 1.168 1.848       | 0.047 1.402 2.948   | 2.648 3.148          | 4.651 3.248 1.397    | 4.718 3.548 1.397    | 5.131 3.448                      | 5.222 3.548          | 5.324 3.548 1.397    | 5.222 3.548 1.397  | 5.904               |
| Kiribati Marshall                     | 0.502 0.480 0.388 | 0.743 0.650         | 1.389                |                      | 0.710                | 1.397 0.727                      | 1.397                |                      |                    | 3.548 1.397         |
| Is Micronesia                         |                   | 0.388               | 0.650                | 0.650 0.388          | 0.388 0.009          | 0.395                            | 0.727                | 0.727                | 0.727              |                     |
| Nauru                                 |                   |                     |                      |                      |                      |                                  | 0.395                | 0.395                | 0.395              | 0.727 0.395 0.158   |
|                                       | 0.008             | 0.008               | 0.388 0.008          | 0.008                |                      | 0.009                            | 0.167                | 0.158                |                    |                     |
| New Caledon                           | 0.500             | 0.500               | 0.500                | 0.500                | 0.575                | 0.607                            | 0.656                | 0.711                | 0.167              | 0.869               |
| Palau                                 |                   |                     |                      | 0.170                | 0.170                | 0.170                            |                      |                      | 0.656              | 0.235               |
| Papua N Samoa                         |                   |                     |                      | 146.186              | 146.152 0.039        | 145.915 0.039                    | 0.235 147.653        | 0.235                | 0.235              | 148.394 0.262       |
| Guin                                  | 145.046 0.014     | 145.296 0.014       | 145.835 0.014        | 0.014                |                      |                                  | 0.197                | 147.767 0.262        | 147.653 0.197      |                     |
| Solomon Is                            | 1.489             | 1.765               | 1.765                | 1.946                | 2.321                | 2.321                            | 2.208                | 2.208                | 2.208              | 3.918               |
| Tokelau Tonga                         | 0.021 0.234       | 0.021 0.234         | 0.021 0.240          | 0.021                | 0.021 0.277          | 0.021 0.437                      | 0.021                | 0.021                | 0.021              | 0.021 0.437         |
| Tuvalu Vanuatu                        | 0.192 0.096       | 0.192 0.221         | 1.308 0.336          | 0.277 1.316          | 1.321 1.280          | 1.332 1.611                      | 0.437 1.332 2.127    | 0.437 1.332 2.188    | 0.437 1.332        | 1.332 2.212         |
|                                       |                   |                     |                      |                      |                      |                                  |                      |                      | 2.127              |                     |
| S America                             |                   |                     |                      | 0.379                | 502.968              |                                  |                      |                      |                    |                     |
|                                       | 407.586 3.695     | 447.623             | 472.491              | 494.956 4.753        | 4.753                | 516.807 4.753                    | 544.305 13.509       | 564.142 13.509       | 544.305 13.509     | 549.322             |
| Argentina Bolivia                     | 73.705 0.721      | 6.237 96.035 0.721  | 4.748 105.735 3.930  | 105.735 4.091        | 105.735 7.212        | 123.160 7.227                    | 128.550 7.241        | 139.550 7.241        | 128.550 7.241      | 139.550 7.241       |
| Brazil Chile Colombia                 | 0.765 1.442 7.200 | 0.765 1.477 10.250  | 0.765 1.840 12.250   | 0.765                | 0.765 6.937 12.320   | 0.765 8.994                      | 0.765 16.937         | 1.445 24.085 13.879  | 0.765 16.937       | 2.225 28.182        |
| Ecuador                               | 0.340             | 0.340               | 0.410                |                      | 0.410                | 13.879                           | 13.879               |                      | 13.879             | 14.902              |
| Falklands Malv                        |                   |                     |                      | 1.897 12.320 0.410   |                      | 0.410                            | 0.410                | 0.410                | 0.410              | 0.410               |
| Fr Guiana                             | 1.211             | 1.211               | 1.211                |                      | 1.211                | 1.211                            |                      | 4.311                |                    |                     |
| Guyana                                | 46.496            |                     | 47.151               | 1.211 37.787         |                      |                                  | 4.311 38.563         |                      | 4.311              | 4.311               |
|                                       | 0.057             | 46.706 0.057        | 0.057                | 0.057                | 37.800 0.057         | 38.419                           | 0.057                | 38.563 0.057         | 38.563 0.057       | 38.563 0.057        |
| Paraguay Peru                         | 195.845           | 205.543             | 214.442              |                      |                      |                                  | 222.219              | 222.219              |                    | 213.819             |
|                                       | 0.256             |                     |                      | 244.947              | 238.135 0.256        | 0.057 224.136                    | 0.256                |                      | 222.219            | 0.256               |
| South Georgia Suriname                | 0.943             | 0.256 1.195         | 0.256 2.845          | 0.256 3.310          | 4.312                | 0.256 4.906                      | 4.906                | 0.256 5.562          |                    | 5.562               |
|                                       | 0.520             | 1.340               |                      |                      | 7.575                |                                  | 17.212               |                      |                    | 18.754              |
| Uruguay                               |                   |                     | 1.361                | 1.927                |                      | 13.554                           |                      | 17.565               | 0.256 4.906 17.212 |                     |
| Venezuela                             | 74.390            |                     |                      |                      |                      | 75.080                           |                      |                      |                    |                     |
|                                       |                   |                     |                      |                      |                      |                                  |                      |                      | 75.490             | 75.490              |
|                                       |                   |                     |                      | 75.490               | 75.490               |                                  |                      |                      |                    |                     |
|                                       |                   | 75.490              | 75.490               |                      |                      |                                  |                      |                      |                    |                     |
|                                       |                   |                     |                      |                      |                      |                                  |                      | 75.490               |                    |                     |
|                                       |                   |                     |                      |                      |                      |                                  |                      | 75.490               |                    |                     |

## Hydropower Hydroélectricité Hidroeléctrica

| CAP (MW)               | 2013             | 2014             | 2015              | 2016             | 2017             | 2018              | 2019              | 2020              | 2021              | 2022              |
|------------------------|------------------|------------------|-------------------|------------------|------------------|-------------------|-------------------|-------------------|-------------------|-------------------|
| World                  | 695.634          | 707.822          | 752.178           | 763.570          | 785.066          | 1 736.421         | 758.905           | 1 793.867         | 806.081           | 802.194           |
| Africa                 | 172.775          | 176.206          | 199.651           | 203.558          | 239.174          | 249.664           | 262.314           | 274.280           | 280.046           | 279.826           |
| Angola                 | 21.659 u         | 22.859 u         | 22.859 u          | 22.859 u         | 35.279 u         | 35.279 e          | 35.279 e          | 35.279 e          | 35.279 e          | 35.279 e          |
| Burkina Faso           |                  |                  |                   |                  |                  |                   | 2.500 u           | 2.500 e           | 2.500 e e         | 2.500 e           |
| Burundi Cameroon       | 1.603 o 0.300 o  | 1.603 o 0.300 e  | 1.603 o 0.300 e   | 1.603 o 0.300 e  | 1.603 e 0.300 e  | 1.603 e 0.300 e   | 1.603 e 0.300 e   | 1.603 e 0.300 e   | 1.603 0.300 e     | 1.603 e 0.300 e   |
| Cent Afr Rep           | 0.200 e          | 0.200 e          | 0.200 e           | 0.200 e          | 0.200 e          | 0.200 e           | 0.200 e           | 0.200 e           | 0.200 e           | 0.200 e           |
| Congo DR               | 97.800 e         | 97.800 e         | 110.900 e         | 110.900 e        | 121.700 e        | 131.700 u         | 141.600 u         | 141.600 e         | 141.600 e         | 141.600 e         |
| Eswatini               | 1.700            | 1.700            | 1.700             | 1.700 e          | 1.700 e          | 1.700 e           | 1.700 e           | 1.700 e           | 1.700 e           | 1.700 e           |
| Ethiopia               | 1.279 e          | 1.279 e          | 1.279 e           | 1.279            | 1.279            | 1.279 e           | 1.279 e           | 1.279             | 1.279             | 1.279 e           |
| Gabon Guinea           | 0.200 e 2.220 o  | 0.200 e 2.220    | 0.200 e           | 0.287 e 2.220 o  | 0.287 e 2.220 e  | 0.287 e 2.220 e   | 0.287 e 2.220 e   | 0.287 e 2.220 e   | 0.287 e 2.220 e   | 0.287 e 2.000 e   |
| Kenya                  | 5.139 e          | o 5.779 e        | 2.220 o 5.779 e   | 9.299 e          | 15.419 e         | 15.419 e          | 15.419 e          | 27.219 e          | 29.219 e          | 29.219 e          |
| Lesotho                | 0.180            | 0.180            | 0.180 e           | 0.180            | 0.180            | 0.180 e           | 0.180 e           | 0.180 e           | 0.180 e           | 0.180 e           |
| Liberia                | 4.000 e          |                  | 4.000 e           | e 4.000 e        | e 4.000 e        | 4.000 e           | 4.000 e           | 4.000 e           | 4.000 e           | 4.000 e           |
| Madagascar             | 3.574 o          | 4.000 e 4.219 o  | 5.249 o           | 5.249 o          | 5.349 e          | 5.349 e           | 5.349 e           | 5.349 e           | 5.349 e           | 5.349 e           |
| Malawi                 | 1.400            | 1.400            | 1.400 e           | 1.700 e          | 1.700 e          | 2.350 e           | 2.000 e           | 2.000 e           | 2.000             | 2.000 e           |
| Mozambique             | e                | e                |                   |                  |                  | 1.060 e           | 1.060 e           | 1.060 e           | e 4.826 o         | 4.826 o           |
| Nigeria                | 0.275 e          | 0.900 e          | 1.060 e 0.400 o   | 1.060 e 0.400 o  | 1.060 e 0.400 o  | 0.400 o           | 0.400 e           | 0.400 e           | 0.400 e           | 0.400 e           |
| Rwanda                 | 1.840 o          | 1.840 o          | 1.840 o           | 1.840 o          | 2.276 o          | 2.276 e           | 2.276 e           | 2.442 u           | 2.442 e           | 2.442 e           |
| Sierra Leone           | 0.250 e          | 0.250 e          | 0.250 e           | 0.250 e          | 4.890 e          | 4.890 e           | 4.890 e           | 4.890 e           | 4.890 e           | 4.890 e           |
| South Africa           | 7.204 e          | 7.500 e          | 7.650 e           | 7.650 e          | 7.650 e          | 7.650 e           | 7.650 e           | 7.650 e           | 7.650 e           | 7.650 e           |
| Tanzania               | 8.800 e          | 8.800 e          | 14.620 e          | 14.620 e         | 15.420 e         | 15.420 e          | 15.420 e          | 15.420 e          | 15.420 e          | 15.420 e          |
| Uganda                 | 9.000 e          | 9.000 e          | 12.500 e          | 12.500 e         | 12.800 e         | 12.640 e          | 12.600 e          | 12.600 e          | 12.600 o          | 12.600 e e        |
| Zambia                 | 2.607 o 1.545    | 2.607 o 1.570    | 1.857 o 1.605 e   | 1.857 o          | 1.857 o 1.605 e  | 1.857 o 1.605 e   | 2.497 u 1.605     | 2.497 e           | 2.497 e e         | 2.497 1.605       |
| Zimbabwe               |                  |                  |                   | 1.605 e          |                  |                   | e                 | 1.605 e           | 1.605             | e                 |
| Asia                   | 294.512          | 304.967          | 321.475           | 330.715          | 335.478          | 1                 |                   | 1                 | 1                 | 1 310.301         |
| Afghanistan            | 24.197 e         | 27.646 e         | 31.095 e          | 34.544 e         | 37.993 e         | 274.668 37.993 e  | 286.046 37.993 e  | 308.342 37.993 e  | 310.693 38.108 u  | 38.138 u 8.335 e  |
| Bhutan India           | 8.078 o 82.169 e | 8.078 o 83.377 e | 8.078 o 84.079 e  | 8.078 o 84.675 e | 8.078 o 84.675 e | 8.315 o 84.675 e  | 8.315 o 84.675 o  | 8.315 o 84.675 e  | 8.335 o 84.675 e  | 84.675 e          |
| Indonesia Lao PDR      | 11.515 e 2.005 u | 12.764 e         | 14.457 e 2.005 u  | 14.887 e         | 14.887 e         | 944.880 o 2.005 u | 944.880 o         | 964.300 o         | 964.300 o 2.005 e | 964.300 o 2.005 e |
|                        | 0.172 e          | 2.005 u          | 0.580 e           | 2.005 u          | 2.005 u          |                   | 2.005 e 0.737 e   | 2.005 e           | 0.737 e           | 0.737 e           |
| Malaysia               |                  | 0.532 e          |                   | 0.655 e          | 0.688 e          | 0.688 e           |                   | 0.737 e           |                   |                   |
| Mongolia Myanmar       | 2.992 e 2.974 e  | 2.992 e 3.165 e  | 2.992 e 6.890 e   | 2.992 e          | 2.992 e 6.890 e  | 2.992 o 6.890 e   | 2.992 e 6.890 e   | 2.992 6.890 e     | 2.992 6.890 e     | 2.992 6.890 e     |
| Nepal                  | 42.168 o         | 45.456 o         | 49.102 o          | 6.890 e 51.012 o | 52.257 o         | 52.257 e          | 53.506            | 54.376 e          | 55.492 e          | 57.240 e          |
|                        | 16.874 e         |                  |                   |                  | 19.825 e         |                   | e 19.905 e        | 21.911 e          | 21.911            | 21.911            |
| Pakistan Philippines   | 9.595 o          | 17.339 e         | 17.339 e 12.595 o | 19.789 e         | 12.595 o         | 19.825 e 20.595 o | 30.595 o          | 30.595 o          | e 30.595 e        | e 28.425 o        |
| Sri Lanka              | 5.248 e          | 9.595 o 5.493 e  | 5.738 e           | 12.595 o 6.068 e | 6.068 e          | 6.068 e           | 6.068 e           | 6.068 e           | 6.068 e           | 6.068 e           |
|                        | 43.200           | 43.200           | 43.200            | 43.200           | 43.200           | 44.160 e          | 44.160 e          | 44.160            | 45.260 u          | 45.260            |
| Tajikistan Timor Leste | 0.325 o          | 0.325 e          | 0.325 e           | 0.325 e          | 0.325 e          | 0.325 e           | 0.325 e 43.000 e  | 0.325 e           | 0.325 e           | 0.325 e           |
| Viet Nam C America +   | 43.000 e 1.323   | 43.000 e         | 43.000 e          | 43.000 e         | 43.000 e 1.808   | 43.000 e 1.888    | 3.815             | 43.000 e 3.835    | 43.000 e 3.835    | 43.000 e 3.835    |
| Carib Belize           | 0.150            | 1.610            | 1.886             | 1.677            | 0.150 u          | 0.150             | 0.150 u           | 0.150 u           | 0.150 u           | 0.150 u           |
| Cuba Rep               | u                | 0.150 u          | 0.150 u           | 0.150 u          |                  | u                 | 1.900 o           | 1.900 u           | 1.900             | 1.900 e 1.685 e   |
| Dominican El Salvador  | 0.633 o e        | 0.920 o 0.140 e  | 1.196 o 0.140 e   | 1.317 o          | 1.448 o 0.140 e  | 1.528 0.140 e     | 1.665 o 0.030 o   | 1.685 o 0.030 e   | 1.685 e 0.030 e   |                   |
| Honduras               | 0.140            |                  |                   | 0.140 e          | 0.070 e          | 0.070 e           | 0.070             | 0.070             |                   | 0.030 e e         |
|                        | 0.400            | 0.400            | 0.400             | 0.070 e          |                  |                   | e                 | e                 | 0.070             | 0.070             |
| Nicaragua              |                  |                  |                   |                  |                  |                   |                   |                   | e                 |                   |
| Oceania                | 76.714           | 77.039           | 77.039            | 77.192           | 77.192           | 77.192            | 77.192            | 77.192            | 77.192            | 77.192            |
| Fiji                   | 0.130 u          | 0.130 u          | 0.130             | 0.130 u          | 0.130 u          | 0.130 u           | 0.130 e           | 0.130 e           | 0.130 e           | 0.130             |
| Papua N Guin           | 76.395 u         | 76.645 e         | u 76.645 e        | 76.645 e         | 76.645 e         | 76.645 e          | 76.645 e          | 76.645 e          | 76.645 e          | e 76.645          |
| Solomon Is             | 0.189 o          | 0.189 o          | 0.189 o           | 0.339 o          | 0.339 o          | 0.339 o           | 0.339 e           | 0.339 e           | 0.339 e           | e 0.339           |
| Vanuatu                |                  | 0.075 e          | 0.075             | 0.078            |                  | 0.078 e           | 0.078 e           | 0.078 e           | 0.078             | e 0.078           |
| S America              |                  |                  | e                 | e                | 0.078 e          |                   | 128.198           | 128.878           | e                 | e                 |
|                        | 148.970          | 146.660          | 150.787           | 149.088          | 130.074          | 131.669           |                   |                   | 132.975           | 129.700           |
| Argentina              | 3.600 o          | 6.136 o          | 4.026 o           | 4.055 o          | 4.055 e          | 4.055 e           | 4.055 e           | 4.055 e           | 4.055 e           |                   |
| Bolivia Chile          | 8.000 0.765 o    | 0.765 o          | 1.200 0.765 o     | 1.200 0.765 o    | 1.200 0.765 o    | 0.800 e 0.765 o   | 0.800 o 0.765 o   | 0.800 e 1.445 o   | 0.800 e 1.445 o   | 0.800 e 2.225 o   |
| Colombia               |                  | 3.660 o          | 0.318 e 5.660 o   | 0.318 e 5.660    | 5.318 o 5.660 e  | 5.318 o 6.060 o   | 9.405 e 6.060 o   | 9.405 e           | 13.502 o 6.060 o  | 13.502 e 6.060    |
| Ecuador                | 4.400 o          | 1.050 o          | 1.050             | o                |                  |                   |                   | 6.060 o           | 1.050             | 1.050             |
| Fr Guiana              | 1.050 o          |                  |                   | 1.050 o          | 1.050 o          | 1.050 o           | 1.050 o           | 1.050 o           | o                 |                   |
| Guyana                 | 2.175 e          | 2.330 e          | o 2.330 o         | 2.330 e          | 2.330 e          | 2.330 e           | 2.350 o 102.073 o | 2.350 e           | 2.350 e 102.073 o | 2.350 e o         |
| Peru South Georgia     | 127.920 o 0.250  | 131.659 o 0.250  | 134.228 o 0.250   | 132.500 0.250    | 108.456 o 0.250  | 110.061 o 0.250   | 0.250             | 102.073 o 0.250 e | 0.250             | 102.073 0.250     |
|                        |                  |                  |                   | o                |                  |                   | e                 |                   | e                 | e                 |
| Suriname Venezuela     |                  | 0.810 u          | 0.150 u           | 0.150 0.810      | 0.180 e 0.810 e  | 0.180 e 0.800 e   | 0.180 1.210       | 0.180 e 1.210 e   | 0.180 e 1.210 e   | 0.180 e 1.210 e   |
|                        | 0.810 o          |                  |                   | e                |                  |                   |                   |                   |                   |                   |
|                        |                  |                  | 0.810             |                  |                  |                   |                   |                   |                   |                   |
|                        |                  |                  |                   |                  |                  |                   | o                 |                   |                   |                   |

## Solar photovoltaic Solaire photovoltaïque Solar fotovoltaica

| CAP (MW)                               | 2013                               | 2014                            | 2015                      | 2016                      | 2017                                      | 2018                      | 2019                      | 2020                      |                           | 2021 2022                         | 2021 2022                         |
|----------------------------------------|------------------------------------|---------------------------------|---------------------------|---------------------------|-------------------------------------------|---------------------------|---------------------------|---------------------------|---------------------------|-----------------------------------|-----------------------------------|
| World                                  | 1 054.435 1                        | 389.343 1                       | 761.905                   | 2 118.541                 | 2 578.736                                 | 3 286.489 3               | 827.555                   | 4 213.258 4               | 573.488 5                 | 051.785                           | 051.785                           |
| Africa                                 | 181.323                            | 237.256                         | 332.574                   | 445.872                   | 510.669                                   | 649.621                   | 757.551                   | 839.847                   | 922.017                   | 998.366                           | 998.366                           |
| Algeria                                |                                    | 1.100                           | 49.096                    | 88.196 e                  | 88.196 e                                  | 101.196 e                 | 101.196 e                 | 101.196 e                 | 101.196 e                 | 113.196 u                         | 113.196 u                         |
| Angola                                 | 10.799 e                           | 11.962 e                        | e 12.867 e                | 13.377 e                  | 13.377 e                                  | 13.377 e                  | 13.377 e                  | 13.377 e                  | 13.377 e                  | 13.377 e                          | 13.377 e                          |
| Benin Botswana                         | 0.415 e                            | 0.560 e                         | 0.853 e                   | 1.500 1.926 e             | 1.500 2.061 e                             | 1.500 2.366 e             | 1.500 e 2.366 e           | 1.540 o 2.365 e           | 1.540 e 2.365 e           | 1.540 e 2.365 e                   | 1.540 e 2.365 e                   |
| Burkina Faso                           | 6.300 e                            | 7.000 e                         | 8.000 e                   | 10.000 e                  | 12.000 e                                  | 27.000 o                  | 27.000 e                  | 27.000 e                  | 27.000 e                  | 27.000 e                          | 27.000 e                          |
| Burundi                                | 2.200 e                            | 2.400 e                         | 2.700 e                   | 3.700 e                   | 4.700 e                                   | 4.700 e                   | 4.700 e                   | 4.700 e                   | 4.700 e                   | 4.700 e                           | 4.700 e                           |
| Cabo Verde                             | 0.151                              | 0.305                           | 0.618                     | 0.674                     | 0.735                                     | 0.801 e                   | 0.846 u 14.192 e          | 0.846 e                   | 0.846 e                   | 0.846 e                           | 0.846 e                           |
| Cameroon                               | 3.600 e                            | 5.600 e                         | 7.400 e                   | 9.000 e                   | 11.596 e                                  | 14.192 e                  | 0.316                     | 14.317 e                  | 14.317 e 0.316 e          | 14.317 e                          | 14.317 e                          |
| Cent Afr Rep Chad                      | 0.300 e 0.050 e                    | 0.300 e 0.050 e                 | 0.300 e                   | 0.300 e 0.173 e           | 0.300 e 0.173 e                           | 0.300 e 0.190 e           | 0.190 e                   | 0.316 e 0.227             | 0.227 e                   | 0.316 e 0.227 e                   | 0.316 e 0.227 e                   |
| Congo DR                               | 0.389 e                            | 0.608 e                         | 0.172 e 0.672 e           | 3.237 u                   | 5.235 u                                   | 19.927 e                  | 19.927 e                  | 19.927 e                  | 19.927 e                  | 19.927 e                          | 19.927 e                          |
| Congo Rep Cote d Ivoire                | 0.230 e                            | 0.460 e                         | 0.460 e                   | 0.460 e                   | 0.570 e 8.278 e                           | 0.720 e 13.144 e          | 0.720 e 13.144 e          | 0.720 e 13.144 e          | 0.720 e                   | 0.720 e 13.144 e                  | 0.720 e 13.144 e                  |
| Djibouti                               | 2.908 e 0.300 e                    | 3.834 e 0.300 e                 | 5.059 e 0.300 e           | 5.059 e 0.362 u           | 0.362 u                                   | 0.362 u                   | 0.362 u                   | 0.362 e                   | 13.144 e 0.362 e          | 0.362 e                           | 0.362 e                           |
| Egypt                                  | 15.000                             | 15.000                          | 16.000 o                  | 30.000 o                  |                                           | 44.200 o                  | 30.200 o                  | 32.000 o                  | 30.500 o                  | 66.000 u                          | 66.000 u                          |
| Eq Guinea                              |                                    |                                 |                           | 0.154 e                   | 30.000 o 0.348 e                          | 0.348 e                   | 0.330 e                   | 0.319 e                   | 0.183 e                   | 0.183 e                           | 0.183 e                           |
| Eritrea                                | 0.035 e 0.778 e                    | 7.859 e 0.804 e                 | 7.859 e 0.804 e           | 9.014 e                   | 11.354 e                                  | 11.604 e                  | 11.602 e 0.804 e          | 11.589 e 0.804 e          | 10.807 e 0.804 e          | 0.804 e                           | 0.804 e                           |
| Eswatini                               |                                    |                                 |                           | 0.804 e                   | 0.804 e                                   | 0.804 e                   |                           |                           |                           |                                   |                                   |
| Ethiopia Gabon                         | 3.344                              | 9.131                           | 9.890 1.400 e             | 14.040                    | 12.494                                    | 12.346                    | 12.346                    | 20.184                    | 21.184                    | 21.184 e 1.400 e                  | 21.184 e 1.400 e                  |
| Gambia                                 | 1.400 e 1.995 e                    | 1.400 e 2.000 e                 | 2.000 e                   | 1.400 e 2.000 e           | 1.400 e 2.002 e                           | 1.400 e                   | 1.400 e 2.002 e           | 1.400 e 2.002 e           | 1.400 e 2.002 e           | 2.122 e                           | 2.122 e                           |
| Ghana                                  | o                                  |                                 |                           |                           |                                           | 2.002 e                   | 7.587 o                   | 7.587 o                   | 7.734 o                   | 7.734 o                           | 7.734 o                           |
| Guinea                                 | 0.071 e                            | 1.350 o                         | 5.609 o                   | 6.847 o                   | 7.583 o                                   | 7.587 o                   | 1.386 e                   | 2.002 e                   | 2.333 e                   | 2.333 e                           | 2.333 e                           |
| Guinea Bissau                          | 6.675 e                            | 0.071 e                         | 0.073 e 0.312 e           | 0.233 e 0.312 e           | 0.432 e 0.312 e                           | 0.695 e 1.169 o           | 1.169 e                   | 1.169 e                   | 1.169 e                   | 1.169 e                           | 1.169 e                           |
| Kenya                                  |                                    | 14.568 e                        | 28.661 e                  | 30.580 e                  | 36.581 e                                  | 44.759 e                  | 60.234 e                  | 78.948 e                  | 101.949 e                 | 101.949 e                         | 101.949 e                         |
| Lesotho Liberia                        | 0.163 e 0.040 u                    | 0.163 e 0.040 u                 | 0.163 e 0.057 u           | 0.163 e 0.059 u           | 0.163 e 2.406 u                           | 0.163 e                   | 0.163 e 2.583 e           | 0.163 e 2.583 e           | 0.213 u 2.583 e           | 0.213 e 2.583 e                   | 0.213 e 2.583 e                   |
| Libya                                  | 4.900 u                            | 4.900 u                         | 4.900 u                   | 4.900 u                   | 5.110 u                                   | 2.583 u 5.110 e           | 5.110 e                   | 5.111 e                   | 6.333 u                   | 6.333 e                           | 6.333 e                           |
| Madagascar                             | 5.000 e                            | 7.000 e                         | 9.000 e                   | 11.000 e                  | 13.000 e                                  | 13.000                    | 13.000                    | 13.000 e                  | 13.000 e                  | 13.000 e                          | 13.000 e                          |
| Malawi Mali                            | 4.565 e 3.346 e                    | 6.834 e 3.755 e                 | 11.257 e 4.783 e          | 11.257 e 5.314 e          | 18.337 e 7.154 e                          | 24.894 e                  | 79.323 e 8.233 e          | 80.635 u                  | 80.623 e 39.011 e         | 81.923 e 39.011                   | 81.923 e 39.011                   |
|                                        | 3.000 o                            |                                 |                           |                           | 19.766 o                                  | 7.398 e                   | 21.209 u                  | 8.370 e 21.209 e          | 21.209 e                  | e 21.209 e                        | e 21.209 e                        |
| Mauritania Mauritius                   | 0.126 e                            | 3.151 o 0.107 e                 | 3.166 o 0.134 e           | 19.766 o 0.915 e          | 3.287 e                                   | 21.066 u 3.440 e          | 4.815 e                   | 4.148 e                   | 3.380 e                   | 3.380 e                           | 3.380 e                           |
| Morocco                                | 15.000                             | 18.800                          | 18.800                    | 20.870                    | 22.895 o                                  | 22.895 o                  | 22.903 o                  | 23.000                    | 23.000 e                  | 23.000 e                          | 23.000 e                          |
| Mozambique                             | 4.900 e                            | 7.000 e                         | 10.000 e                  | 13.000 e                  | 15.000 e                                  | 15.000 e                  | 15.000 e                  | 20.441 o                  | 22.924 o                  | 25.882 o                          | 25.882 o                          |
| Namibia Niger                          | 13.400 e 5.000 e                   | 14.178 u 6.000 e                | 14.178 e                  | 14.178 e                  | 14.187 u 9.041 u                          | 21.940 u u                | 23.880 u 20.041 u         | 23.880 e 20.041 e         | 23.880 e 20.041 e         | 23.880 e 20.041 e                 | 23.880 e 20.041 e                 |
|                                        |                                    |                                 | 7.000 e                   | 8.000 e                   |                                           | 20.041                    |                           |                           | 26.908 e                  | 26.908 e                          | 26.908 e                          |
| Nigeria Reunion                        | 15.400 e                           | 15.600 e                        | 17.000 e                  | 17.200 e                  | 17.400 e                                  | 17.565 u                  | 26.439 u 1.340 u          | 26.908 u 1.340 e          | 1.340 e                   | 1.340 e                           | 1.340 e                           |
| Rwanda                                 | 0.692 e                            | 1.235 e                         | 1.815 e                   | 3.025 e                   | 4.455 e                                   | 9.389 e                   | 12.830 e                  | 12.830 e                  | 12.830 e                  | 12.830 e                          | 12.830 e                          |
| Sao Tome Prn Senegal                   | 0.063 e 7.000 e                    | 0.098 e 7.000 e                 | 0.119 e                   | 0.157 e 7.000 e           | 0.316 e 7.000 e                           | 0.334 e 7.000 e           | 0.334 e 7.000 e           | 0.334 e 7.000 e           | 0.334 e 7.000 e           | 0.334 e 7.000 e 1.022 e           | 0.334 e 7.000 e 1.022 e           |
| Seychelles Sierra Leone                | 0.068 o 0.384 u                    | 0.068 o                         | 7.000 e 0.068 o           | 0.068 o 0.484 u           | 0.068 e 3.830 u                           | 1.022 e 4.246 u           | 1.022 e 4.246 e           | 1.022 e 4.246 e           | 1.022 e 4.286 u           | 4.286 e                           | 4.286 e                           |
| Somalia                                |                                    | 0.395 u                         | 0.420 u                   | 4.670 e                   | 6.894 e                                   | 7.068 e                   | 7.068 e                   | 15.538 u                  | 23.538 u                  | 47.038 u                          | 47.038 u                          |
| South Africa                           | 0.744 e                            | 0.100 e 1.891 e                 | 0.170 e 2.216 e           | 2.492 e                   | 5.274 e                                   | 5.135 e                   | 5.563 e                   | 5.328 e                   | 5.225 e                   | 5.225                             | 5.225                             |
| South Sudan                            | 0.160 e                            | 0.160 e                         | 0.160 e                   | 0.428 u                   | 0.449 u                                   | 0.737 e                   | 0.835 u 80.199 u          | 0.835 e                   | 1.278 u 135.570 u         | e 2.061                           | e 2.061                           |
| Sudan                                  | 14.666 u 3.674 e                   | 16.584 u 11.188 e               | 19.911 u                  | 26.219 u                  | 35.800 u                                  | 59.478 u                  | 15.141 e                  | u 15.141 e                | 15.141 e                  | u 135.570 e                       | u 135.570 e                       |
| Tanzania Togo                          |                                    |                                 | 12.795 e                  | 12.256 e                  | 13.133 e                                  | 17.059 e 3.490 o          | 5.460 o                   | 116.840 6.460 o           | 6.493 u                   | 15.141 e 6.493 e                  | 15.141 e 6.493 e                  |
| Tunisia                                | 0.007 e 1.555 e                    | 0.022 e 1.563 e                 | 0.062 e 1.710 e           | 0.082 e 2.060 e           | 0.972 e 2.076 e                           | 2.076 e                   | 7.076 u                   | 7.076 e                   | 7.076 e                   | 7.076                             | 7.076                             |
| Uganda                                 | 18.500 e                           | 20.000 e                        | 22.000 e                  | 24.000 e                  | 26.600 e                                  | 26.600 e                  | 26.760 e 7.424 e          | 26.920 e 7.424 e          | 27.079 e 7.424 o          | e 27.239 e                        | e 27.239 e                        |
| Zambia Zimbabwe                        | 0.060 e 1.970 e                    | 0.060 e 2.702 e                 | 0.060 e 2.525 e           | 0.094 e 2.867 e           | 0.094 e 3.569 e                           | 0.224 e 3.979 e           | 3.658 e                   | 3.983 e                   | 3.174 e                   | 7.452 3.174 e                     | 7.452 3.174 e                     |
|                                        |                                    |                                 |                           |                           |                                           |                           |                           |                           |                           | u                                 | u                                 |
| Asia                                   |                                    |                                 |                           |                           |                                           |                           |                           |                           |                           |                                   |                                   |
| Afghanistan 20.170                     | 766.463 1 16.843 e 18.363 e        | 016.769 1 18.932                | 220.579 1 e               | 428.854 e                 | 1 784.953 2 20.323 e                      | 198.476 19.855 e 19.389   | 2 613.792 e               | 2 891.784 18.821 u        | 3 162.769 3 18.821 u      | 539.985 20.838 u                  | 539.985 20.838 u                  |
| Bangladesh 149.394 Bhutan Brunei Darsm | 94.074 e 119.495 e 0.275 e 0.548 e | 142.333 0.275 e 0.014 u 0.742 e | e 0.275 e 0.014 u 1.245 e | e 0.275 e 0.014 u 1.923 e | 173.744 e 168.028 0.275 e 0.015 u 2.027 e | e 0.275 e 0.015 u 1.470 e | 190.093 e 0.275 e 0.016 u | 180.075 e 0.275 e 0.027 u | e 0.275 e 0.047 u 1.364 e | 176.901 180.778 e 0.275 e 0.047 u | 176.901 180.778 e 0.275 e 0.047 u |
| Cambodia China                         |                                    |                                 |                           |                           |                                           |                           | 1.245 e e                 | 0.718 e o                 | 412.800 e                 | 1.282 e e                         | 1.282 e e                         |
| India                                  | 297.800 269.577 e                  | 337.800 381.328 e               | 357.800 486.114 e         | 367.800 637.861 e         | 376.800 e                                 | 385.800 e                 | 394.800 130.378 e         | 403.800 190.378 e         | 367.173 e                 | 421.800 722.113 e                 | 421.800 722.113 e                 |
| Indonesia                              | 29.357 e                           | 32.628 e                        | 41.621 e                  | 41.720 e                  | 870.886 1 43.023 e 116.656                | 098.628 41.050 o          | 1 50.010 o                | 1 61.490 o                | 1 69.750 o                | 1 69.750 o                        | 1 69.750 o                        |
|                                        | 15.262                             | 71.255                          | 86.517                    | 99.689                    |                                           | 281.060                   | 608.000                   | 807.000                   | 885.256 e                 | 885.256                           | 885.256                           |
| Kazakhstan Korea DPR                   | 6.139 u                            | 10.958 u                        | 22.794 u                  | 31.534 u                  | 34.780 u                                  | 37.780 u                  | 40.780 u                  | 40.780 e                  | 40.780 e                  | 40.780 e                          | 40.780 e                          |
| Lao PDR                                | 0.470 e                            | 0.902 e                         | 1.254 e                   | 1.409 e                   | 1.409 e                                   | 1.409 e                   | 1.409 e                   | 1.409 e 7.794 e           | 1.414 u                   | 1.414 e 7.825 e                   | 1.414 e 7.825 e                   |
| Malaysia                               | 0.004 o                            | 1.528 e                         | 2.415 e                   | 2.462 e                   | 2.579 e                                   | 7.629 e                   | 7.610 e                   |                           | 7.825 e                   |                                   |                                   |
| Maldives                               | 1.753 o                            | 3.882 o                         | 4.799 o                   | 7.488 o                   | 10.791 o                                  | 16.478 o                  | 20.605 u                  | 26.705 u                  | 30.805 u 4.585            | 35.805 o 4.585                    | 35.805 o 4.585                    |
| Mongolia                               | 4.585 e                            | 4.585 e                         | 4.585 e                   | 4.585 e                   | e                                         | o                         | 4.585 e                   | 4.585                     |                           |                                   |                                   |
| Myanmar                                | 4.209 o                            | 6.271 o                         | 20.819 o                  | 32.008 o                  | 4.585 43.781 o                            | 4.585 47.542 o            | 48.482 o                  | 44.496 o                  | 40.447 e                  | 40.447 e                          | 40.447 e                          |
| Nepal                                  | 10.143 o                           | 10.862 o                        | o                         | 12.892 e                  | e                                         | 53.748 e                  | 52.396 e                  | 58.796 e                  | 59.844 e 15.699 e         | 61.979 e                          | 61.979 e                          |
| Pakistan                               | 0.318 e                            | 0.453 e                         | 12.701 0.602 e            | 0.611 e 1.895 o           | 52.922 12.284 e 2.176 o                   | 13.350 e                  | 14.356 e 13.001 o         | 15.661 e 12.904 o         | 12.904 e                  | 15.699 e 13.132 o                 | 15.699 e 13.132 o                 |
|                                        | 1.047 o                            | 1.487 o                         | 1.850 o                   |                           |                                           | 3.381 o                   |                           |                           |                           |                                   |                                   |
| Philippines Sri Lanka                  | 7.793 e                            | 7.725 e                         | 7.726 e                   | 7.747 e                   | 8.010 e                                   | 8.206 e                   | 8.175 e                   | 7.895 e                   | 7.895 e 0.369             | 7.895 e 0.470 u                   | 7.895 e 0.470 u                   |
| Timor                                  | 0.748 u                            | 0.726 u                         | 0.693 u                   | 0.687 u                   | 0.372 u                                   | 0.372 u                   | 0.372 u                   | 0.360 u                   | u                         | 3.325                             | 3.325                             |
| Uzbekistan                             | 1.000                              | 1.000                           | 1.000                     | 2.200                     | 3.025                                     | 3.325                     | 3.325 e                   | 3.325                     | 3.325 e                   |                                   |                                   |
|                                        |                                    |                                 | 4.490 e                   |                           |                                           | 4.490 e                   |                           |                           |                           |                                   |                                   |
|                                        | 4.518 e                            | 4.490 e                         |                           |                           |                                           |                           | 4.490 e                   |                           |                           | 4.490 e                           | 4.490 e                           |
|                                        |                                    |                                 |                           |                           |                                           |                           |                           |                           | 4.490                     |                                   |                                   |
| Viet Nam                               |                                    |                                 |                           |                           |                                           |                           |                           | e                         |                           | e                                 |                                   |
|                                        |                                    |                                 |                           | 4.490 e                   | 4.490 e                                   |                           |                           |                           |                           |                                   |                                   |
|                                        |                                    |                                 |                           |                           |                                           |                           |                           | 4.490                     |                           |                                   |                                   |
| Leste                                  |                                    |                                 |                           |                           |                                           |                           |                           |                           |                           |                                   |                                   |

## Solar photovoltaic Solaire photovoltaïque Solar fotovoltaica

| CAP (MW)          | 2013             | 2014             | 2015             | 2016            | 2017            | 2018            | 2019            | 2020            | 2021            | 2022                |
|-------------------|------------------|------------------|------------------|-----------------|-----------------|-----------------|-----------------|-----------------|-----------------|---------------------|
| C America + Carib | 26.226           | 30.806           | 36.204           | 38.142          | 43.385          | 52.007          | 49.806          | 57.299          | 62.250          | 80.975              |
| Antigua Barb      |                  |                  |                  | 0.010 e         |                 |                 |                 | 0.414 e         | e               | e                   |
|                   |                  |                  |                  |                 | 0.414 e         | 0.414 e         | 0.414 e         |                 | 0.414           | 0.414               |
| Bahamas           | 0.025 e          | 0.126 e          | 0.147 e          | 0.200 e         | 0.146 e         | 0.115 e         | 0.058 e         | 0.058 e         | 0.058 e         | 0.058 u             |
| Belize            | 0.009 u          | 0.015 u          | 0.019 u          | 0.019 u         | 0.026 u         | 0.026 u         | 0.620 u         | 0.620 e         | 0.620 e         | 0.620 u             |
| Br Virgin Is      | 0.019 o          | 0.019 o          | 0.786 o          | 0.947 o         | 0.947 o         | 0.955 o         | 0.974 o         | 1.174 o         | 1.174 o         | 1.174 o             |
| Costa Rica        |                  |                  |                  |                 |                 |                 | 1.581 e         | 1.640 e         | 1.640 e         | 1.640 e             |
| Cuba              |                  |                  |                  |                 | 0.467 u         | 0.835 u         | 7.000 u         | 7.224 u         | 7.947           |                     |
| Curacao           | 0.004 o          | 0.004 o          | 0.004 o          | 0.004 o         | 0.004 o         | 0.004 o         | 0.004 o         | 0.004 o         | 0.004 o         | 7.947 e 0.004 o     |
| Dominican Rep     | 1.500            | 3.000            | 4.500            | 6.173           | 15.192          | 20.992          | 21.047 o        | 21.062 o        | 25.290 e        | 43.989 e            |
| El Salvador       | 12.405 e         | 12.405 e         | 12.405 e         | 12.405 e        | 12.278          | 14.716          | 3.986 o         | 3.986 e         | 3.986 e         | 3.986 e             |
| Guatemala         | 2.560 e          | 5.434 e          | 8.308 e          | 8.308 e         | 8.308 e         | 8.308 e         | 8.308 e         | 8.308 e         | 8.308 e         | 8.308 e             |
| Haiti             | 0.831 e          | 0.927 e          | 1.154 e          | 1.195 e         | 1.275 e         | 1.294 e         | 1.347 e         | 1.347 e         | 1.347 e         | 1.347 e             |
| Honduras          | 5.156 e          | 5.156 e          | 5.156 e          | 5.156 e         | 0.541 e         | 0.553 e         | 1.963 e         | 8.986 e         | 8.986 e         | 9.012 e             |
| Jamaica           | 0.006 e          | 0.008 e          | 0.013 e          | 0.013 e         | 0.013 e         | 0.013 e         | 0.013 e         | 0.013 e         | 0.013 e         | 0.013 e             |
| Nicaragua         |                  |                  |                  |                 |                 |                 | 2.400 o         | 2.400 o         | 2.400 e         | 2.400 e             |
| Panama            | 3.711            | 3.711            | 3.711            | 3.711           | 3.711 o         | 3.711 e         | 0.020 u         | 0.020 e         | 0.020 o         | 0.020 e             |
| Puerto Rico       |                  |                  |                  |                 | 0.062 e         | 0.070 o         | 0.070 o         | 0.042 e         | 0.042 e         | 0.042 e             |
| St Kitts Nevis    |                  | 0.001 e          | 0.001 e          | 0.001 e         | 0.001 e         | 0.001 e         | 0.001 e         | 0.001 e         | 0.001 e         | 0.001 e             |
| Middle East       | 32.641           | 45.710           | 101.054          | 121.211         | 141.256         | 295.813         | 298.958         | 308.335         | 308.385         | 313.185             |
| Iran IR           | 0.378            | 0.378            | 0.378            | 0.378           | 0.378           | 0.378 e         | 0.378 e         | 0.378 e         | 0.378 e         | 0.378 e             |
| Iraq              | 29.500 o         | 36.500 o         | 36.500 e         | 36.500 e        | 36.500 e        | 36.500 e        | 36.500 e        | 36.500 e        | 36.500 e        | 39.000 e            |
| Jordan Lebanon    | 0.141 o 0.061 e  | 0.236 o 0.390 e  | 0.557 o 0.397 e  | 0.593 o 0.507 e | 0.588 o 0.527 e | 0.623 o 4.880 o | 0.670 o 4.880 o | 2.375 o 4.880 e | 2.375 e 4.890 o | 2.375 e 4.890 e     |
| Oman              |                  |                  |                  | 0.011           | 0.011 e         | 0.011 e         | 0.011 e         | 0.011 e         | 0.011 e         | 0.011               |
| Palestine         |                  |                  |                  | e               |                 |                 | 1.833 o         | 1.833 e         | 1.833 e         | e 1.833 e           |
| Saudi Arabia      |                  | 0.014 e          | 0.014            | 0.014 e         | 0.014 e         | 0.014 e         | 0.014           | 0.014 e         | 0.014 e         | 0.014 e             |
| Syrian AR         |                  |                  | e                |                 |                 |                 | e               |                 |                 | 2.000               |
| United Arab Em    | 0.192 e          | 3.192 e          | 3.208 e          | 3.208 e         | 3.238 u         | 3.407 o         | 4.672 o         | 5.597 u         | 5.597 e         | 5.897 u             |
| Yemen             | 2.369 o          | 5.000 o          | 60.000 o         | 80.000 o        | 100.000 e       | 250.000 u       | 250.000 e       | 256.747 e       | 256.787 e       | 256.787 e           |
| Oceania           | 6.195            | 8.266            | 12.174           | 16.426          | 18.551          | 21.006          | 24.505          | 24.893          | 25.775          | 27.992              |
| Amer Samoa        |                  |                  |                  | 1.504 e         | 1.854 e         | 1.854 e         | 1.854 e         | 1.854 e         | 1.854 e         | 1.854 e             |
| Cook Is           | 0.047 e          | 0.047 e          | 0.047 e          | 0.047 e         | 0.047 e         | 1.869 u         | 2.606 u         | 2.606 e         | 2.606 e         | 2.606 e             |
| Fiji              | 1.014 u          | 1.248 u          | 2.494 u          | 4.497 u         | 4.564 u         | 4.977 u         | 5.068 u         | 5.170 u         | 5.459 u         | 5.750 u             |
| Fr Polynesia      | 1.600 o          | 2.700 o          | 2.900 o          | 3.000 o         | 3.300 o         | 3.200 o         | 3.300 o         | 3.300 o         | 3.300 e         | 3.300 e             |
| Kiribati          | 0.502 o          | 0.743 o          | 1.389 o          | 1.397 o         | 1.397 o         | 1.397 e         | 1.397 e         | 1.397 e         | 1.397 e         | 1.397 e             |
| Marshall Is       | 0.480 e          | 0.650 e          | 0.650 e          | 0.650 e         | 0.710 e         | 0.726 e         | 0.726 e         | 0.726 e         | 0.726 e         | 0.726 e             |
| Micronesia        | 0.388 e          | 0.388 e          | 0.388 e          | 0.388 e         | 0.388 e         | 0.395 u         | 0.395 e         | 0.395 e         | 0.395 e         | 0.395 e             |
| Nauru             | 0.008 e          | 0.008 e          | 0.008 e          | 0.008 e         | 0.009 e         | 0.009 e         | 0.167 e         | 0.158 e         | 0.158 e         | 0.158 e             |
| New               | 0.500 o          | 0.500 o          | 0.500 o          | 0.500 o         | 0.575 o         | 0.607 o         | 0.656 o         | 0.711 o         | 0.786 o         | 0.869 o             |
| Caledon Palau     |                  |                  |                  | 0.170 o         | 0.170 o         | 0.170 e         | 0.235 u         | 0.235 e         | 0.235 e         | 0.235 e             |
| Papua N Guin      | 0.339 e 0.014 e  | 0.339 e 0.014 e  | 0.878 u          | 1.229 u         | 1.195 u 0.039 e | 0.958 u 0.039 e | 2.696 e 0.197 e | 2.810 e 0.262 u | 3.346 e 0.262 e | 3.437 e 0.262 e     |
| Samoa Solomon Is  | 0.800 e          | 1.076 e          | 0.014 e 1.076 e  | 0.014 e 1.107 e | 1.482 e         | 1.482 e         | 1.369 e         | 1.369 e         | 1.369 e         | 3.079 e             |
| Tokelau           | 0.021 u          | 0.021 u          | 0.021 u          | 0.021 u         | 0.021 e         | 0.021 e         | 0.021 e         | 0.021 e         | 0.021 e         | 0.021 e             |
| Tonga             | 0.234 o          | 0.234 o          | 0.240 o          | 0.277 o         | 0.277 o         | 0.437 u         | 0.437 e         | 0.437 e         | 0.437 e         | 0.437 e             |
| Tuvalu            | 0.192 o          | 0.192 o          | 1.308 o          | 1.316 o         | 1.321 o         | 1.332 o         | 1.332 o         | 1.332 e         | 1.332 e         | 1.332 e             |
| Vanuatu           | 0.056 e          | 0.106 e          | 0.261 e          | 0.301 e         | 1.202 e         | 1.533 u         | 2.049 u         | 2.110 u         | 2.092 u         | 2.134 u             |
|                   |                  |                  |                  | 68.036          | 79.922          |                 | 82.943          | 91.100          |                 |                     |
| S America         | 41.587           | 50.536           | 59.320           |                 |                 | 69.566          |                 |                 | 92.292          | 91.282              |
| Argentina         | 0.026 o          | 0.024 o          | 0.618 o          | 0.606 o         | 0.606 e         | 0.606 e         | 2.030 o         | 2.030 e         | 2.030 e         |                     |
| Bolivia           | 5.535 e          | 5.535 e          | 5.535 e          | 5.535 e         | 5.535 e         | 4.860 o         | 5.250 o         | 5.250 e         | 5.250 e         | 5.250 e             |
| Brazil            | 0.721 e          |                  |                  | 4.091 e         | 7.212 e         | 7.227 e         |                 | 7.241 o         | 7.241 o         | 7.241 e             |
| Colombia          | 1.383            | 0.721 e 1.418    | 3.930 e 1.463    | 1.520           | 1.520           | 3.577           | 7.241 o 7.473   | 14.621          | 14.621 e        | 14.621 o            |
| Ecuador           | 0.400 o          | 1.940            | 1.940            | 2.010           | 2.010           | 3.169 o         | 3.169 o         | 3.169 o         | 3.192 o         | 4.192               |
| Malv              |                  |                  |                  |                 |                 |                 |                 |                 |                 |                     |
| Falklands         |                  |                  | 0.070 o          | 0.070 o         | 0.070 o         | 0.070 o         | 0.070 e         | 0.070 e         | 0.070 e         | 0.070 e             |
| Fr Guiana Guyana  | 0.161 o 1.016    | 0.161 o 1.061    | 0.161 o 1.476    | 0.161 o 1.652   | 0.161 o 1.665   | 0.161 o 1.684   | 0.161 o 1.808   | 0.161 e 1.808 e | 0.161 1.808 e   | 0.161 1.808 e 0.057 |
| Paraguay          | 0.057 o          | 0.057 o          | 0.057 o          | 0.057 o         | 0.057 o         | 0.057 o         | 0.057 o         | 0.057 e         | 0.057 e         | e                   |
| Peru              | 28.525 e 0.943 e | 34.484 e 1.195 e | 38.914 e 1.195 e | 46.147 e 1.660  | 53.379 e 2.632  | 39.675 3.226    | 45.746 3.226    | 45.746 e 3.882  | 45.746 o e      | 45.746 e 3.882      |
| Suriname          |                  |                  |                  |                 |                 |                 | o               | o               | 3.882 o         | e                   |
| Uruguay           | 0.520            | 0.540            | 0.561            | 1.127           | 1.675           | 2.254 o 3.000   | 3.712 3.000     | 4.065 3.000     | 5.234 3.000 e   | 5.254 o 3.000 e     |
|                   | 2.300            | 3.400            | 3.400            |                 |                 |                 | o               |                 |                 |                     |
| Venezuela         |                  |                  |                  | 3.400           | 3.400           | e               |                 | e               |                 |                     |

## Other renewable energy Autres énergies renouvelables Otras energías renovables

| CAP (MW)                           |                   | 2013                        | 2014                     | 2015                   | 2016                   | 2017                   | 2018                     | 2019                      | 2020 2021               |                         | 2022                  |
|------------------------------------|-------------------|-----------------------------|--------------------------|------------------------|------------------------|------------------------|--------------------------|---------------------------|-------------------------|-------------------------|-----------------------|
| World                              |                   | 4 426.819                   | 4 700.225                | 4 868.826              | 4 253.475              | 4 473.115              | 4 330.235                | 4 429.599                 | 4                       | 819.448 5               | 581.704               |
| Africa                             | 3 782.342 91.486  | 116.486                     | 118.356                  | 120.777                | 123.721                | 124.211                | 124.316                  | 124.316                   |                         | 144.316                 | 144.316               |
| Algeria                            |                   | 10.200                      | 10.200                   | 10.200                 | 10.200                 | e 10.000 e             | 10.000                   | e                         | 10.000 e                | 10.000 e                | 10.000 e              |
| Burkina Faso                       | 0.150 u           | 0.150                       | u 0.150                  | 0.150                  | e 0.150                | e 0.150 e              | 0.150 e                  | 0.150                     | e 0.150                 | e                       | 0.150 e               |
| Burundi                            | e 4.000 o         | 4.000                       | u e 4.000 e              | 4.000                  | e 4.000 e 1.100        | 4.000 1.100            | e                        | 4.000 e e                 | 4.000 e 1.100 o         | 4.000 e 1.100 e         | 4.000 e 1.100         |
| Chad                               | e 0.160 e         | 0.160 e                     | 0.160 e                  | 1.100 0.160            | u e                    | e 2.160 e 2.960        | e 1.100 e                | 2.960 e                   | 2.960 e                 | 2.960 e                 | e 2.960 e             |
| Congo DR Djibouti                  | o                 | 5.000 o                     | 5.000 o                  | 5.000                  | o                      | 5.000 o                | 5.000 o                  | 5.000 o                   | 5.000 o                 | 20.000 u 5.000 e        | 20.000 e 5.000 e      |
| Egypt Eritrea                      | 5.000 o e 0.825 e | 0.825 e                     | 0.825 e                  | 0.825 e                | 0.825                  | e 0.825                | e                        | 0.825 e                   | 0.825 e                 | 0.825 e                 | 0.825 e               |
| Ethiopia                           |                   |                             | 1.200                    | e                      | 0.006 u                | 0.006 e                | 0.006 e                  | 0.006 e                   | 0.006                   | 0.006                   | 0.006 e               |
| Gabon Ghana                        | e 6.774 e         | 8.274 e                     | 8.294 e                  | 1.200 8.294            | e e                    | 1.200 e 8.294 e        | 1.200 e 8.294 e          | 1.200 e 8.294 e           | 1.200 e 8.294 e         | 1.200 e 8.294 e         | 1.200 e 8.294 e       |
| Kenya                              | e 0.554 e         | 0.554 e                     | 0.604                    | e                      | 0.604 e                | 0.714 e                | 0.604 e                  | 0.604 e                   | 0.604 e                 | 0.604 e                 | 0.604 e               |
| Liberia                            |                   | 0.010 u 0.050 0.411 o       | u 0.050                  | e                      | 0.110 u                | 0.185 e                | 0.185 e                  | 0.185 e                   | 0.185 e                 | 0.185 e                 | 0.185 e               |
| Madagascar                         | o                 | 0.411                       | o 0.411                  | o                      | 0.411 o                | 0.411 e                | 0.411 e                  | 0.411 e                   | 0.411 e                 | 0.411 e                 | 0.411 e               |
| Mali                               | e 32.000 o        | 40.000                      | e 40.000                 | e                      | 40.000 e               | 40.000 u               | 40.000 e                 | 40.000 e                  | 40.000 e                | 40.000 e                | 40.000 e              |
| Mauritania Morocco                 | 4.400 o 5.000     | 4.400 5.000                 | o 4.400                  | o 4.400                | o 4.400                | o 4.400                | e                        | 4.400 e                   | 4.400 e                 | 4.400 e                 | 4.400 e               |
| Namibia                            | u 0.002 u         | 0.002                       | u                        | 5.000                  | 5.000                  | 5.000                  | 5.000                    | 5.000 e                   | 5.000 e 0.011 e         | 5.000 e 0.011 e         | 5.000 e 0.011 e       |
| Nigeria                            |                   |                             |                          | 0.002 u                | 0.002 u                | 0.011 u                | 0.011 e                  | 0.011                     |                         | 10.335                  | 10.335 e              |
|                                    | e 7.500 e u       | 9.000 e                     | 9.000                    | e                      | 10.230 e               | 10.230 e               | 10.230 e                 | 10.335 e 3.550 e          | 10.335 e                | e                       | 3.550 e               |
| Somalia Tanzania                   | 2.200 u 22.500 o  | 2.200 u 26.260 u            | 26.260                   | 2.800 u e              | 2.800 u 26.285 e       | 3.550 u                | 3.550 e e                | 26.285 e                  | 3.550 26.285 e          | 3.550 e 26.285          | 26.285                |
| Asia                               | o                 | 3                           | 196.462                  | 4                      | 349.192                | 26.285 e               | 26.285                   |                           |                         | e                       | e                     |
|                                    | 3 352.652         | 937.448                     | 4                        |                        | 3                      | 710.659 3              | 905.160                  | 3 744.282                 | 3 832.636               | 4 210.880               | 4 980.560             |
| Afghanistan u Bangladesh o         | 0.100 e 4.420 o   | 0.100 e 5.120 o             | 0.100                    | e o                    | 0.100 e 7.050 o        | 0.100 e 7.050 o        | 0.100 e 7.050 e          | 0.100 e 7.050 o           | 0.100 e 7.350 o         | 0.100 e 7.350 e         | 0.100 e 7.350 e       |
| Cambodia                           | e 2.250 e         | 2.250 249.130               | 6.650 e 3.750            | e                      | 3.750 e                | 3.750 e                | 3.750 e                  | 3.750 e                   | 3.750 e                 | 3.750 e 493.430 e       | 3.750 e 524.190 e     |
| China                              |                   | 210.530 584.028 o           | 297.730                  |                        | 342.690                | 370.390                | 401.150 e                | 431.910 e                 | 462.670 o               |                         |                       |
| India                              | o                 | 736.305 o o                 | 785.371                  | o                      | 843.616 o              | 849.946 e              | 896.347 685.260          | 866.629 e 687.260 e       | 963.869 e               | 963.869 e               | 968.069 e             |
| Indonesia 1                        | o 615.000 o       | 1 626.000 0.200             | 626.000                  | o 1                    | 633.000 e 1            | 669.000 e 1            | e 1                      | 1 0.600 e                 | 718.820 e 2             | 082.810 e 2 0.600       | 817.530 e 0.600 e     |
| Korea DPR Lao PDR                  | u                 | 0.200 u                     | 1 u                      | 0.200 u                | 0.200 u                | 0.600 o                | 0.600 e 0.290 o          | 0.290 o                   | 0.600 e 0.290 o         | e 0.290 o               | 0.290 e               |
| Malaysia                           | o                 | 732.530 o 1 100.000 1.407 u | o 1 237.800              | o 1                    | 243.000 o              | 531.640 o              | 531.640 e                | 531.640 e                 | 531.640 e               | 531.640 e               | 531.640 e             |
| Maldives Mongolia                  | u e               | 1.407 1.006 e 1.006         | e e                      | 1.407 e 1.006 e        | 1.407 e                | 1.407 e 1.006 e        | 1.407 e 1.006 o          | 1.407 e                   | 1.407 e 1.000           | 1.407 e 0.994           | 1.407 e 0.994         |
| Myanmar                            | e                 | 48.626 e 52.375 0.069 u     | e 47.875                 | e                      | 1.006 e 49.221 e       | 51.618 e               | 56.308 e                 | 1.006 e 58.358 e          | 58.358 e                | 58.358 e                | 58.358 e              |
| Nepal                              |                   | e                           |                          | 0.069 u e              | 0.069 u 1.253          | 0.069 e 1.253 e        | 0.169 o                  | 0.199 o 1.253 e           | 0.199 e 1.253 e         | 0.199 e 1.253           | 0.199 e 1.253         |
| Pakistan                           | e                 | 0.561                       | 0.069 u 0.561 e 20.925 e | 0.579                  | e                      |                        | 1.253 e                  |                           |                         | e                       | e                     |
|                                    | u                 | 20.925 e 131.000 e          |                          | e                      | 29.830 e               | e                      | e                        | 45.830 o                  | 45.830 e                | 45.830                  | 45.830                |
| Philippines Viet Nam               |                   | 142.000                     | 20.925 e                 |                        | 193.000 e              | 29.830 193.000 e       | 29.830 289.000 e         | 107.000 e                 | 35.500 e                | 19.000                  | o 19.000 e            |
| C America + Carib                  | e                 | 47.051 47.334               | 47.939                   | 167.000 e              | 45.941                 | 51.039                 | 53.087                   | 53.388                    | 53.388                  | e e 53.388              | 53.388                |
| Belize                             | u 0.020 o 0.500   | u 0.020 o                   | u 0.020 o 0.500          | u o                    | 0.020 u 0.500 o        | 0.020 u 0.500 o        | 0.020 u 0.500 o          | 0.020 u 0.801             | 0.020 u 0.801 o         | 0.020 e 0.801 o         | 0.020 u 0.801         |
| Br Virgin Is Costa Rica            |                   | 0.500                       |                          |                        |                        | 4.500                  | 4.500                    | o 4.500 0.010 e           | 4.500 e                 | 4.500 e                 | o 4.500 e             |
| Dominica                           | o 0.010 o         | 0.010                       | o e                      | 0.010 o                | 0.010                  | 0.010 o                | 0.010 o                  |                           | 0.010 e 17.431 e        | 0.010 e                 | 0.010 e               |
| Dominican Rep                      | 16.121 e          | 16.390                      | 16.895                   | e                      | o 17.211 e             | e                      | 17.431 e                 | 17.431 e                  |                         | 17.431 e                | 17.431                |
| Haiti                              | e                 |                             |                          |                        |                        |                        |                          |                           |                         | 0.024                   |                       |
| Honduras                           |                   |                             |                          |                        |                        | 17.309                 | 0.024 u                  | 0.024 e                   | 0.024 e                 | e                       | e 0.024 e             |
| Nicaragua                          | 30.300            | 0.014                       | e 3.914                  | e                      | 3.914 e 0.010 e        | 3.914 e 0.010 e        | 3.914 e 1.912 e          | 3.914 e 1.912 e 24.500 e  | 3.914 e 1.912 e         | 3.914 e 1.912 e         | 3.914 e 1.912 e       |
| Panama St Lucia                    | 0.100             | 30.300                      | 26.500                   |                        | 24.000 0.176 e         | 24.500 o 0.176 e       | 24.500 e 0.176 e         | 0.176 e                   | 24.500 e 0.176 e        | 24.500 o 0.176 e        | 24.500 e 0.176 e      |
| US Virgin Is                       | o                 | 0.100                       | o 0.100                  | o                      | 0.100 o                | 0.100 o                | 0.100 e                  | 0.100 e                   | 0.100 e                 | 0.100 e                 | 0.100 e               |
| Middle East                        | 5.000             | 6.000                       | 6.000                    |                        | 6.000                  | 6.000                  | 6.000                    | 6.000                     |                         | 6.015                   | 6.015                 |
|                                    |                   | u                           |                          |                        |                        |                        |                          |                           | 6.010                   |                         |                       |
| Jordan Kuwait                      | 2.400 u 2.000 u   | 2.400 e 3.000 u 0.600 e     | 2.400 3.000              | e e                    | 2.400 e 3.000 e        | 2.400 e 3.000 e        | 2.400 e 3.000 e          | 2.400 e 3.000 e           | 0.010 o 2.400 e 3.000 e | 0.010 o 2.400 e 3.000 e | 0.010 e 2.400 e 3.000 |
| Lebanon Syrian AR Yemen            | e e               |                             | 0.600                    | e                      | 0.600 e                | 0.600 e                | 0.600 e                  | 0.600 e                   |                         | 0.600 e                 | e 0.600 e             |
|                                    | 0.600 69.124      | 69.124                      | 69.084                   |                        | 69.084                 |                        | 69.085 69.085            | 69.085                    | 0.600 e                 | 0.005 o                 | 0.005 e 69.085        |
| Oceania                            | u u e             |                             | 0.024 u                  |                        | 0.024 u                | 69.084 0.024 u         | 0.024 u 0.248 e          | 0.024 e 0.248 e           | 0.024 e                 | 69.085 0.024 e          | 0.024 e               |
| Fiji Fr Polynesia                  | 0.024 0.248 e     | 0.248                       | e 68.312 e               | 0.024 u 0.248 e        | 0.248 e 0.248          | e                      |                          | 0.001 e                   | 0.248 e 0.001 e         | 0.248 e 0.001           | 0.248 e 0.001         |
| Marshall Is Papua N Solomon Is     | 68.312 0.500      | 0.500 e                     | 68.312 0.500             | e                      | 68.312 e               | 68.312 e 0.500 u       | 0.001 u 68.312 e 0.500 u | 68.312 0.500              | 68.312 e 0.500 e        | e 68.312 e              | e 68.312 e            |
| Vanuatu                            | e e e             | e e 0.040 e                 |                          | u                      | 0.500 u                |                        |                          | e e                       |                         | 0.500 e                 |                       |
|                                    |                   | 0.040                       | e                        |                        |                        |                        |                          |                           |                         |                         | 0.500 e               |
| Guin                               |                   |                             |                          |                        |                        |                        |                          |                           |                         |                         |                       |
| S America o                        | 217.029 0.069 o   | 0.077                       | 250.427 o 0.104          | 262.384 o              | 277.832 0.092          | 292.972 e 0.092        | 315.572 e                | 333.164 7.424 o           | 344.164 7.424 e         | 335.764 7.424 e         | 328.340 133.500 e     |
| Argentina Bolivia Colombia Ecuador | o                 | 60.170 90.500 o             | 0.059 o 4.650 o 0.340 e  | 99.000 0.059 o 4.650 o | 0.092 o 99.000 0.059 o | 99.000 0.099 o 4.650 o | 117.500 o 0.099 o        | 122.500 o 0.059 e 4.650 o | 133.500 0.059 4.650     | 133.500 e 0.059 4.650   | 0.059 4.650           |
|                                    |                   | 0.059 2.400 0.340 e         |                          |                        | 4.650 o                |                        | 4.650 e                  |                           | e                       |                         | o                     |
|                                    |                   |                             |                          |                        |                        |                        |                          |                           | o                       | e o                     |                       |
| Falklands Fr Guiana                | e                 |                             |                          | 0.340 o                | 0.340 o                | 0.340 o                | 0.340 o                  | 0.340                     | 0.340                   | 0.340 e                 | 0.340 e 3.100         |
|                                    |                   |                             |                          |                        |                        |                        |                          |                           | e 3.100                 |                         |                       |
|                                    |                   |                             |                          |                        |                        |                        |                          | e                         |                         |                         |                       |
|                                    |                   |                             |                          |                        |                        |                        |                          |                           | 3.100                   |                         |                       |
| Malv                               |                   |                             |                          |                        |                        |                        |                          | 3.100 o                   | e                       | o                       |                       |

## Other renewable energy Autres énergies renouvelables Otras energías renovables

| CAP (MW)      | 2013       | 2014     | 2015     | 2016     | 2017     | 2018     | 2019     | 2020     | 2021     | 2022     |
|---------------|------------|----------|----------|----------|----------|----------|----------|----------|----------|----------|
| Guyana        | 43.305     | 43.315   | 43.345   | 33.805   | 33.805   | 34.405   | 34.405   | 34.405 e | 34.405 e | 34.405 e |
| Peru          | o 39.400 o | 39.400 o | 41.300   | 66.300 o | 76.300 o | 74.400 e | 74.400 e | 74.400 e | 66.000 o | 66.000 e |
| South Georgia | 0.006      | 0.006    | 0.006    | 0.006    | 0.006    | 0.006    | 0.006    | 0.006 e  | 0.006 e  | 0.006 e  |
| Suriname      |            |          | 1.500    | 1.500    | 1.500    | 1.500 e  | 1.500 e  | 1.500 e  | 1.500 e  | 1.500 e  |
| Uruguay       |            | 0.800 e  | 0.800 e  | 0.800 e  | 5.900 e  | 11.300 e | 13.500 e | 13.500 e | 13.500 e | 13.500 o |
| Venezuela     | 71.280 u   | 71.280 u | 71.280 u | 71.280 u | 71.280 u | 71.280 u | 71.280 u | 71.280 e | 71.280 e | 71.280 e |

Other indicators Autres indicateurs Otros indicadores

## Renewable energy share of electricity capacity La part d'énergie renouvelable dans la puissance installée Proporción de energía renovable en la capacidad eléctrica

| %                       | 2013      | 2014       | 2015      | 2016          | 2017                     | 2018               | 2019 2020      | 2021           | 2022           |
|-------------------------|-----------|------------|-----------|---------------|--------------------------|--------------------|----------------|----------------|----------------|
| World                   | 27.2      | 28.2       | 29.5      | 30.8          | 32.1                     | 33.1 34.5          | 36.6           | 38.3           | 40.2           |
| Africa                  | 19.0      | 19.5       | 20.0      | 20.0          | 21.1 21.6                | 21.7               | 22.5           | 22.9           | 23.6           |
| Algeria                 | 1.6       | 1.6        | 1.8       | 2.8           | 3.2 3.1                  | 2.8                | 2.6            | 2.3            | 2.3            |
| Angola                  | 44.5      | 43.9       | 42.9      | 56.0          | 56.8 59.6 1.9            | 61.8               | 64.0           | 64.0           | 65.6           |
| Benin                   | 0.4       | 0.7        | 1.7       | 1.7           | 1.7 0.4                  | 1.1 0.6            | 1.1            | 1.1            | 8.6            |
| Botswana Burkina Faso   | 0.5 15.0  | 0.2 13.3   | 0.2 12.1  | 0.4 12.8      | 0.4 21.6 24.7            | 22.4               | 0.6 22.4       | 0.7 20.1       | 0.7 24.7       |
| Burundi                 | 73.7      | 73.7       | 73.8      | 74.2          | 53.2 53.2                | 53.2               | 53.2           | 56.2           | 61.3           |
| Cabo Verde              | 23.3      | 23.3       | 18.7      | 18.9          | 18.9 20.0                | 20.1               | 20.1           | 20.1           | 20.1           |
| Cameroon Rep            | 57.7      | 57.8       | 55.5      | 55.6          | 51.3 51.4                | 54.0               | 54.0           | 53.9           | 53.9           |
| Cent Afr                | 50.2      | 46.5       | 46.5      | 46.5          | 46.5 46.5                | 46.6               | 46.6           | 21.0           | 21.0           |
| Chad                    | 0.7       | 0.7        | 0.8       | 1.1           | 1.1 1.2 6.3              | 1.2                | 1.3            | 1.3            | 1.3            |
| Comoros                 | 6.3       | 6.3        | 6.3       | 6.3           | 6.3 98.9                 | 6.3                | 6.3            | 6.3            | 20.1           |
| Congo DR                | 98.9      | 98.9       | 98.9      | 98.9          | 98.9 34.7                | 99.0               | 99.0           | 99.0           | 99.0           |
| Congo Rep Cote d Ivoire | 32.7      | 32.7       | 32.7      | 33.4          | 34.7 40.1                | 34.7               | 27.5           | 27.5 39.0      | 27.5           |
| Djibouti                | 39.0      | 36.3       | 33.5      | 31.5          | 40.2 0.3                 | 39.7               | 39.7           |                | 36.1           |
|                         | 0.2       | 0.2        | 0.2       | 0.3           | 0.3                      | 0.3                | 0.3            | 14.2           | 14.2           |
| Egypt                   | 10.6      | 10.6       | 10.4      | 9.5           | 8.4 8.6                  | 9.7                | 10.0           | 10.5           | 10.6           |
| Eq Guinea Eritrea       | 36.1 0.6  | 36.1       | 36.1      | 33.8          | 31.8 31.8 5.7            | 31.8               | 31.8           | 31.7           | 31.7           |
| Eswatini                | 94.9      | 5.9 94.5   | 5.2 94.5  | 5.8 94.5      | 5.6 94.5 94.5            | 5.7 94.5           | 5.7 94.5       | 5.3 94.8       | 5.3 94.8       |
| Ethiopia                | 92.1      | 92.1       | 94.8      | 96.4          | 97.8 98.1                | 97.7               | 97.8           | 97.9           | 98.2           |
| Gabon                   | 54.8      | 55.3       | 55.2      | 53.0          | 53.5 54.4                | 54.4               | 54.4           | 54.4           | 54.4           |
| Gambia                  | 3.3       | 3.5        | 3.6       | 3.6           | 3.6 3.2                  | 3.7                | 3.7            | 3.1            | 3.2            |
| Ghana                   | 56.6      | 56.7       | 57.1      | 46.2          | 41.2 40.7                | 32.1               | 31.5           | 31.6           | 31.6           |
| Guinea                  | 38.0      | 38.0       | 61.1      | 62.0          | 60.3 60.0                | 61.7               | 61.1           | 65.6           | 65.6           |
| Guinea Bissau Kenya     | 65.3      | 65.4       | 1.1 65.3  | 1.1 66.2      | 1.1 4.0 67.6 71.9        | 4.0 72.1           | 4.0 75.4       | 4.0 76.7       | 4.0 77.9       |
| Lesotho                 | 99.8      | 99.8       | 99.8      | 99.8          | 99.8 99.8                | 99.8               | 99.8           | 99.8           | 99.8           |
| Liberia                 | 4.2       | 4.2        | 4.2       | 21.1          | 49.1 49.2                | 49.2               | 49.2           | 49.2           | 49.2           |
| Libya                   | 0.1 30.6  | 0.1 24.9   | 0.1       | 0.1           | 0.0 0.0 24.1             | 0.0                | 0.0            | 0.1            | 0.1 24.1       |
| Madagascar Malawi       | 93.5      | 93.5       | 25.2 93.8 | 25.4 91.8     | 23.6 81.3                | 24.1 78.1          | 24.1 78.2      | 24.1 80.7      | 80.7           |
| Mali                    | 51.3      | 50.5       | 50.2      | 46.2          | 77.6 44.1 21.2           | 44.2               | 47.4           | 49.2           | 56.0           |
| Mauritania              | 9.1 18.7  | 8.8        | 11.3      | 14.3          | 44.1 14.3                | 20.8               | 20.8           | 19.5           | 19.7           |
| Mauritius Mayotte       | 14.4      | 18.9 14.5  | 21.6      | 22.6          | 21.5 27.0 13.3 13.7      | 29.0 14.5          | 29.6 15.8      | 29.8           | 29.8 23.3      |
| Morocco                 | 24.9      | 26.7       | 14.3 28.2 | 11.9 28.9     | 28.7 29.8                | 30.5               | 33.0           | 23.3 33.1      | 33.6           |
| Mozambique              | 98.0      | 97.5       | 90.5      | 78.6          | 79.0                     | 79.0               | 79.1           | 79.1           | 79.4           |
| Namibia                 | 65.9      | 62.4       |           | 67.7          | 81.8 71.1                | 73.3               | 73.5           | 73.5           | 74.4           |
| Niger                   | 1.9       | 2.3        | 62.7 2.7  | 3.0           | 70.0 2.6 7.4             | 7.1                | 7.1            | 7.1            | 12.1           |
| Nigeria                 | 21.3 40.2 | 20.2 43.9  | 20.2      | 17.1          | 17.0 16.4                | 16.4 48.7          | 16.3           | 16.4           | 16.4 50.2      |
| Reunion                 | 53.5      |            | 45.3      | 45.5          | 45.5 48.2 50.5           |                    | 49.2           | 50.2           | 50.3           |
| Rwanda                  | 8.1       | 59.0       | 51.7      | 52.9          | 51.5                     | 54.3 5.6           | 56.1 5.6       | 56.1           | 5.6            |
| Sao Tome Prn Senegal    | 5.4       | 6.9 5.6    | 6.4 5.5   | 6.5           | 5.5 5.6 16.0 15.2        | 20.7               | 26.9           | 5.6 30.4       | 29.1           |
| Seychelles              | 6.9       | 7.6        | 7.8       | 8.2 7.1       | 7.6 9.0                  | 9.6 41.7           | 10.8           | 15.5           | 18.7           |
| Sierra Leone Somalia    | 59.9 2.7  | 66.7       | 55.4      | 55.5          | 57.5 11.5 12.3           | 49.1 9.6 14.3      | 41.7           | 41.7           | 42.9 32.3 17.0 |
| South                   | 3.3       | 2.8        | 3.6       | 8.5 9.3       |                          | 9.6 14.2           | 16.0 16.1      | 20.4 16.8      |                |
| Africa South Sudan      | 0.2       | 5.8 0.2    | 7.2 0.2   | 0.5           | 0.6 47.4                 | 0.5 47.7           | 0.5            | 0.8            | 7.8 49.2       |
| Sudan                   | 46.4      |            |           | 46.1          | 0.3                      |                    | 48.2           |                |                |
| Tanzania                | 38.4      | 46.5 40.0  | 46.5 41.6 |               | 46.2 33.7                | 33.9               | 33.9           | 48.4 33.9      | 33.9           |
| Togo Tunisia            | 27.9 6.0  | 27.9       | 27.9      | 38.2 6.5      | 38.2 28.2 28.9 6.5       | 29.5 7.2           | 30.0 6.7       | 36.1           | 36.1           |
| Uganda                  | 88.2      | 6.2        | 6.6 85.2  | 27.9          | 7.3                      |                    | 92.1           | 6.7 92.1       | 7.7 92.2       |
| Zambia Zimbabwe         | 97.0      | 84.9       | 93.1      | 85.2 83.8     | 89.8                     | 92.0 82.9 49.8     | 82.9           | 84.5           | 86.3           |
|                         | 41.8      | 94.2 41.8  | 42.2      | 42.3          | 85.8 82.2 82.3 42.5 49.8 |                    | 49.9           | 50.2           | 49.4           |
| Asia                    | 24.2      |            |           | 28.6          | 30.4                     | 33.1               | 35.7           | 37.6           | 39.8           |
|                         |           | 25.7       | 27.2 56.1 |               |                          | 31.7 61.1          |                |                |                |
| Afghanistan Bangladesh  | 55.4 2.9  | 55.8 2.8   | 2.8       | 59.6 2.6      | 61.1 2.8 2.3             | 57.9 2.4           | 57.9 2.3       | 58.3 3.0       | 64.0 3.1       |
| Bhutan Brunei           | 99.3 0.1  | 99.3 0.1   | 99.3 0.1  | 99.5          | 99.5 99.5 0.1 0.1        | 99.7 0.1           | 99.6 0.1       | 99.6 0.4       | 99.6 0.4       |
| Darsm Cambodia          | 61.1      | 63.5       | 58.0      | 0.1 57.2 33.1 | 55.3 63.3 35.2           | 60.6               | 55.9           | 57.5           | 52.5           |
| China China HK SAR      | 28.5      |            | 31.7 0.0  |               | 0.4                      |                    |                | 42.9 1.4       | 45.3 1.3       |
| Taipei                  |           | 30.3       |           |               |                          | 37.7 1.4           | 40.8 1.4       |                |                |
| Chinese                 | 7.2       | 0.0        | 8.3       | 0.2           |                          | 36.6 0.5 11.3 28.1 |                | 18.6           | 22.3           |
| India                   | 22.5      | 7.7        | 22.7      | 8.9           | 10.0 27.1                | 13.3 29.0          | 16.0           | 31.5           | 33.7           |
| Indonesia               | 15.7      | 22.9       | 15.7      | 24.8 15.5     | 15.2 15.1                |                    | 29.9           | 15.5           | 15.4           |
| Japan Kazakhstan        | 15.1 12.7 | 15.4       | 20.8      | 22.7 13.3     | 24.8 13.6                | 14.8 28.8          | 14.4 30.1 20.4 | 31.1           | 32.8 23.4      |
|                         |           | 17.7       | 13.5      |               | 26.5                     | 17.8               |                |                | 59.4           |
| Korea DPR Korea Rep     | 59.2 4.7  | 13.4       | 60.3 7.0  | 8.3           | 14.8 59.0 10.8           | 59.0 13.5          | 59.4 14.9      | 21.8 59.4      | 19.3           |
|                         | 81.8      | 59.3       |           | 61.5          | 61.8 9.2                 |                    | 85.3           | 17.1           | 79.9           |
| Kyrgyzstan Lao PDR      | 100.0     | 5.7 82.3   | 85.3 77.7 | 85.3 72.4     | 85.3 74.7                | 85.3 77.3          | 81.3           |                | 83.7           |
|                         | 18.7      | 100.0 21.6 | 24.2      | 25.7          | 85.4 73.4 22.2           | 21.9               | 23.2           | 79.9 82.6 23.0 | 23.3           |
| Malaysia                |           |            |           |               | 22.6 3.3                 | 4.0                |                | 5.8            | 6.6            |
| Maldives                | 2.2       | 3.6        | 4.2       | 4.0           |                          |                    | 5.1            |                |                |
|                         |           |            |           |               | 5.4                      |                    |                |                |                |

## Renewable energy share of electricity capacity La part d'énergie renouvelable dans la puissance installée Proporción de energía renovable en la capacidad eléctrica

| %                            | 2013       | 2014      | 2015           | 2016                | 2017                | 2018      | 2019 2020      | 2021      | 2022      |
|------------------------------|------------|-----------|----------------|---------------------|---------------------|-----------|----------------|-----------|-----------|
| Mongolia                     |            |           |                | 8.3                 | 13.9                | 18.4      |                |           |           |
| Myanmar                      | 7.4 72.6   | 7.4 68.9  | 7.4 65.7       | 65.6                | 59.1 54.9           | 19.4 53.6 | 18.4 45.3      | 18.0 45.2 | 22.9 44.6 |
| Nepal                        | 93.4       | 93.6      | 94.0           | 94.1 33.5           | 94.9 95.5           | 95.9      | 96.3           | 97.5      | 97.8      |
| Pakistan                     | 31.0       | 31.6      | 31.6           | 28.0                | 29.1 32.8           | 31.4      | 31.7           | 31.4      | 31.1      |
| Philippines                  | 27.2       | 28.5      | 29.1           | 28.2 2.3            | 27.6                | 26.4      | 26.5           | 26.5      | 26.4      |
| Singapore                    | 1.4        | 1.6       | 1.9            |                     | 2.4 2.8             | 3.8       | 4.4            | 5.7       | 6.8       |
| Sri Lanka Tajikistan         | 52.3       | 45.3 92.3 | 47.3 92.3      | 48.7                | 50.0 51.9 87.5 87.8 | 51.7 88.0 | 53.0 88.0      | 57.7 88.0 | 58.9 88.0 |
| Thailand                     | 93.8 19.8  | 20.6      | 21.2           | 87.5 21.8           | 20.7 21.8           | 22.3      | 22.1           | 22.1      | 21.1      |
| Timor Leste                  | 0.3        | 0.3       | 0.3            | 0.3                 | 0.2 0.2             | 0.2       | 0.2            | 0.2       | 0.2       |
| Turkmenistan                 | 0.0        | 0.0       | 0.0            | 0.0 13.1            | 0.0 0.0             | 0.0       | 0.0            | 0.0       | 0.0 12.8  |
| Uzbekistan Viet Nam          | 14.0 45.7  | 14.2 45.5 | 13.3 42.7      | 42.8                | 12.6 13.5 41.7 41.2 | 12.0 47.7 | 12.3 55.8      | 13.0 56.1 | 57.1      |
| C America + Carib            | 26.0       | 27.0      | 29.6           | 32.3                | 34.0 34.9           | 36.4      | 36.9           | 38.3      | 39.0      |
| Anguilla                     | 0.2        | 4.0       | 4.0            | 7.3                 | 7.3 4.6             | 6.0       | 6.0            | 6.0       | 6.0       |
| Antigua Barb                 | 0.3        | 0.3       | 2.8            | 4.2                 | 5.1 9.7             | 9.7       | 26.5           | 26.5      | 26.5      |
| Aruba                        | 11.2       | 12.8      | 13.2           | 13.2 13.2 0.2       | 15.5                | 15.0      | 15.0           | 15.0      | 17.4      |
| Bahamas                      | 0.1        | 0.2       | 0.2            | 0.2                 | 0.2                 | 0.3       | 0.3            | 0.3       | 0.3       |
| Barbados                     | 0.2        | 0.6       | 1.2            | 5.4                 | 6.1 49.2            | 11.2      | 15.7           | 19.5      | 19.1      |
| Belize                       | 41.5       | 41.7      | 41.7           | 5.9 44.5            |                     | 51.7      | 51.7           | 51.7      | 51.7      |
| BES Islands                  | 29.2       | 29.2      | 29.7           | 41.7 32.5           | 36.0 37.6           | 39.0      | 32.5           | 32.5      | 32.5      |
| Br Virgin Is Is              | 1.0        | 1.0       | 2.4            | 2.7                 | 2.0 2.0             | 2.4       | 2.7            | 2.7       | 2.7       |
| Cayman                       |            |           |                | 1.6                 | 4.8 5.4             | 6.0       | 6.8            | 7.3       | 7.3       |
| Costa Rica Cuba              | 77.8 9.1   | 78.3      | 79.6           | 83.5 9.4            | 86.0 86.2 10.4      | 86.9      | 86.8 18.8      | 87.1 18.9 | 88.0 18.7 |
| Curacao                      | 18.0       | 9.6       | 10.0           |                     | 11.4 26.1 26.4      | 16.6 23.3 | 23.7           | 23.7      | 23.7      |
| Dominica                     | 26.1       | 19.9 26.1 | 17.7 26.1      | 18.0 27.2           | 27.2 26.4           | 26.4      | 25.0           | 25.0      | 25.0      |
| Dominican Rep                | 13.5       | 13.5      | 14.3           | 16.7                | 17.6 20.6           | 24.9      | 26.0           | 28.0      | 30.9      |
| El Salvador                  | 56.3       | 57.2      | 55.0           | 56.5                | 60.7 62.9           | 66.3      | 67.4           | 69.7      | 70.0      |
| Grenada                      | 1.1        | 1.5       | 2.1            | 4.2                 | 4.3 4.8             | 5.8       | 6.6            | 6.3       | 6.3       |
| Guadeloupe                   | 29.8       | 25.2      | 27.5           | 26.4                | 27.0 27.6           | 30.9 69.7 | 31.3           | 32.5      | 32.9      |
| Guatemala                    | 55.4       | 57.5      | 58.3           | 63.2 13.0           | 67.4 69.6           |           | 69.7           | 69.7      | 69.7      |
| Haiti                        | 12.9 45.9  | 13.0      | 13.0           |                     | 13.1 17.1 61.2 62.1 | 17.1 63.0 | 17.1 64.7      | 17.1 64.9 | 17.1 63.1 |
| Honduras Jamaica             | 10.6       | 46.3 10.8 | 59.7 10.8      | 59.9 17.5           | 19.5 19.5           | 18.8      | 17.5           | 17.4      | 17.4      |
| Martinique Montserrat        | 11.9       | 13.4      | 14.0           | 14.3                | 14.6 20.8           | 23.8 3.5  | 24.1           | 24.2 12.6 | 25.0 12.6 |
| Nicaragua                    | 43.1       | 44.9      | 45.6           | 47.3                | 45.4 45.5           | 45.2      | 3.5 45.2       | 45.4      | 45.4      |
| Panama                       | 59.8       | 59.9      | 63.1           | 63.7 7.8            | 64.5 60.0           | 56.0      | 58.0           | 63.9      | 67.3 13.3 |
| Puerto Rico St Barth         | 4.9        | 5.0       | 7.2            | 0.1                 | 8.7 8.8 0.1 0.1     | 9.0 0.1   | 9.7 0.1        | 11.3 0.1  | 0.1       |
| St Kitts Nevis               | 4.8        | 4.7       | 4.7            | 5.4                 | 5.4 4.9             | 4.9       | 6.2            | 6.2       | 6.2       |
| St Lucia                     | 0.1        | 0.1       | 0.9            |                     | 1.1 4.3             | 4.3       | 4.3            | 4.3       | 4.3       |
| St Martin                    | 4.4        | 5.0       | 7.9            | 1.1 3.1 12.8        | 0.2 0.2             | 0.9       | 1.7            | 1.7       | 1.7       |
| St Vincent Gren              | 11.8       | 11.8      | 12.2           | 0.2                 | 14.4 15.4 0.2       | 19.2      | 16.5           | 17.3      | 17.3 0.2  |
| Trinidad Tobago Turks Caicos | 0.2        | 0.2       | 0.2            | 0.0                 | 0.2 0.2             | 0.2 1.0   | 0.2 1.0        | 0.2 1.0   | 1.0       |
| US Virgin Is                 | 0.3        | 1.6       | 0.0 2.8        | 2.9                 | 0.5 2.1 3.0         | 3.0       | 3.0            | 3.0       | 3.0       |
| Eurasia                      | 25.4       | 24.5      | 25.9           | 25.4                | 26.1 26.9           | 27.3      | 28.6           | 29.6      | 30.1      |
| Armenia                      | 31.6       | 31.7      | 36.5           | 36.9                | 37.2 37.8           | 38.3      | 39.3           | 38.5      | 39.8 16.0 |
| Azerbaijan                   | 15.0       | 15.2      | 14.8           | 15.0                | 15.0 16.3           | 16.9      | 17.0           | 16.5 75.2 | 76.0      |
| Georgia Russian Fed          | 79.6 21.0  | 77.4      | 72.3 20.5      | 72.6 19.5 43.9      | 74.8 74.6 19.5      | 73.8 19.7 | 73.5 20.2      | 20.6      | 20.7      |
| Türkiye                      | 39.9       | 19.8 40.2 | 43.1           | 19.5 45.5           | 47.7                | 48.6      | 51.3           | 53.3      | 53.9      |
| Europe                       | 38.1       | 39.3      | 41.2           | 42.9                | 44.4 45.4           | 47.8      | 49.8           | 51.8      | 53.8      |
| Albania                      | 94.8       | 94.6      | 94.8 100.0     | 95.1 96.2           | 95.4 95.5 96.8      | 95.7 96.9 | 96.1 96.9      | 96.3 97.0 | 96.3 97.0 |
|                              | 100.0 72.1 | 100.0     | 74.7           |                     | 96.8 79.5           | 80.2      | 80.3           |           | 82.2      |
| Andorra Austria              |            | 73.4      |                | 76.7                | 78.6 3.8            |           |                | 80.7      |           |
| Belarus Belgium              | 0.8 27.5   | 0.8       | 1.0            | 2.2 31.3 40.8       | 2.9 33.6            | 4.1 39.8  | 4.8 43.9       | 4.3       | 5.2 47.5  |
| Bosnia Herzg                 | 42.8       | 28.6 43.0 | 30.1 43.1      |                     | 36.5 40.6           | 42.2 38.5 |                | 45.3      | 44.0      |
| Bulgaria                     | 35.3       | 36.2      | 37.9           |                     | 41.6 39.5 38.1 59.5 | 65.1      | 42.5 39.7      | 43.4 40.4 | 43.8      |
| Croatia Cyprus               | 57.6 11.3  |           |                | 38.6                | 58.7 16.1           | 17.7      |                | 71.6 24.5 | 72.4 29.8 |
| Czechia                      | 19.4       | 58.5 12.8 | 56.9 13.9 19.3 | 57.6 14.3 19.2      | 15.5                | 19.8      | 69.8 21.1      | 21.6      | 23.1      |
|                              | 47.7 17.8  | 19.0      | 50.8 20.7      |                     | 19.2 19.2 57.2      | 61.3 26.1 | 20.7 62.9 30.3 | 65.9      | 68.5      |
| Denmark Estonia              |            | 49.5 18.5 |                | 52.1                | 59.4 24.2 21.6      |           |                | 42.0      | 45.1      |
| Faroe Islands                | 43.7       |           | 46.4           | 23.6 46.3           | 46.3                | 40.4      | 36.0           |           | 35.4      |
| Finland                      | 33.0       | 48.0      | 36.8           | 41.2                | 44.8                | 45.0      | 50.2           | 35.4 52.6 | 59.4      |
| France                       | 29.9       |           | 32.5           | 33.8                | 44.0                | 39.4      | 40.9           | 42.6      | 44.6      |
| Germany                      | 45.2       | 35.3 31.3 | 48.1           | 43.6 36.1 52.3 44.7 | 37.6 52.0           | 54.0      | 56.3           |           | 58.6      |
| Greece                       | 40.7 8.9   | 45.7 42.4 | 43.0           | 50.2 44.0 12.0      | 46.1                | 48.5 22.9 | 52.5 28.2      | 57.2 60.1 | 59.2 33.6 |
| Hungary                      | 95.9       | 11.8      | 12.5           |                     | 13.8                | 96.1      | 96.1           |           |           |
|                              |            | 95.9      | 95.8           |                     | 17.5 96.1           |           |                | 33.7 95.8 | 95.8      |
| Iceland Ireland              |            |           |                | 95.8 31.1           |                     | 40.7      |                | 43.2      | 44.6      |
|                              | 25.1       | 28.0      | 28.5           | 95.9 34.6           |                     |           | 42.2           |           |           |
|                              |            |           |                |                     | 36.8                |           |                |           |           |

## Renewable energy share of electricity capacity La part d'énergie renouvelable dans la puissance installée Proporción de energía renovable en la capacidad eléctrica

| %                   | 2013      | 2014          | 2015          | 2016           | 2017      | 2018      | 2019      | 2020      | 2021      | 2022      |
|---------------------|-----------|---------------|---------------|----------------|-----------|-----------|-----------|-----------|-----------|-----------|
| Italy               | 39.2      |               |               | 44.8           | 45.6      |           |           |           |           | 49.2      |
| Kosovo*             | 4.6       | 40.7 4.6      | 43.1 4.6      | 8.2            | 8.6       | 46.1 8.6  | 46.7 9.7  | 47.7 10.7 | 48.5 16.7 | 16.7      |
| Latvia              | 60.6      | 60.8          | 60.8          | 60.7           | 61.1      | 61.0      | 62.1      | 62.0      | 62.0      | 63.9      |
| Lithuania           | 12.2      | 13.5          | 19.3          | 20.9           | 23.7      | 24.9      | 25.4      | 26.8      | 31.2      | 38.8      |
| Luxembourg Malta    | 11.6 4.8  | 11.1 8.5      | 11.8 11.7     | 17.6 17.1      | 18.6 16.5 | 18.9 18.8 | 21.7 21.3 | 23.8 24.6 | 26.8 26.3 | 29.8 26.3 |
| Moldova Rep         | 2.2       | 2.3           | 2.3           | 2.3            | 2.7       | 3.5       | 3.6       | 3.8       | 5.1       | 6.3       |
| Montenegro          | 73.7      | 74.4          | 74.7          | 74.9           | 76.9      | 77.0      | 78.0      | 78.5      | 78.5      | 78.9      |
| Netherlands         | 13.7      | 14.7          | 17.0          | 21.0           | 23.5      | 28.1      | 33.8      | 44.0      | 49.9      | 58.3      |
| North Macedonia     | 36.0      | 38.8          | 40.0          | 39.5           | 39.8      | 40.1      | 40.5 97.2 | 42.9 97.4 | 42.9      | 42.9      |
| Norway              | 95.5 14.3 | 95.7 15.7     | 95.7          | 97.0 20.7      | 97.0 18.6 | 97.1 19.3 | 21.5      | 24.9      | 97.8 31.1 | 98.2 36.9 |
| Poland Portugal     | 59.0      | 60.5          | 18.5 61.9     | 64.1           | 64.7      | 64.9      | 65.4      | 65.6      | 70.6      | 72.0      |
| Romania             | 44.2      | 46.9          | 47.3          | 47.6           | 47.5      | 47.6      | 53.7      | 54.3      | 59.5      | 60.3      |
| Serbia              | 32.8      | 33.4          | 33.4          | 33.7           | 33.4      | 35.2      | 36.9      | 37.0      | 36.4      | 35.1      |
| Slovakia            | 27.9      | 29.4          | 30.6          | 31.0           | 31.1      | 30.6      | 31.5      | 30.8      | 32.1      | 32.1      |
| Slovenia            | 39.8      | 40.7          | 42.3          | 39.9           | 40.9      | 38.8      | 39.5      | 41.0      | 41.8      | 41.7      |
| Spain               | 44.2      | 44.1          | 44.7          | 45.1           | 46.2      | 46.5      | 49.8      | 52.9      | 55.9      | 58.2      |
| Sweden              | 65.0      | 65.9          | 67.7          | 69.0           | 70.8      | 70.8      | 72.8      | 71.9      | 75.8      | 77.5      |
| Switzerland         | 76.1      | 76.4          | 76.7          | 78.0           | 78.9      | 79.2      | 79.5      | 81.4      | 81.8      | 82.3      |
| UK                  | 21.3      | 25.7          | 31.9          | 36.6           | 38.1      | 40.5      | 44.4      | 45.5      | 46.4      | 48.1      |
| Ukraine             | 10.3      | 10.7          | 10.8          | 10.7           | 12.2      | 14.2      | 21.7      | 23.8      | 25.2      | 25.2      |
| European Union (27) | 70.4      | 71.2          | 72.3          | 73.2           | 74.2      | 75.1      | 76.3      | 78.0 7.2  | 79.4      | 80.9      |
| Middle East Bahrain | 5.7 0.0   | 5.9 0.1       | 5.6 0.1       | 5.7 0.1        | 5.7 0.1   | 6.2 0.1   | 7.0 0.1   | 0.1       | 7.7 0.1   | 8.4 0.1   |
| Iran IR             | 14.8      | 15.0          | 14.0          | 14.1           | 14.4      | 14.3      | 14.3      | 14.0      | 13.8      | 13.7      |
| Iraq                | 8.5       | 9.0           | 7.4           | 7.2            | 6.1       | 5.9       | 5.9       | 5.5       | 5.3       | 5.1 20.8  |
| Israel Jordan       | 3.2 0.5   | 4.2 0.4       | 4.8 3.5       | 5.5 12.0       | 6.0 14.5  | 7.8 19.2  | 11.3 27.2 | 13.5 33.3 | 17.1 35.3 | 39.1      |
| Kuwait              | 0.0       | 0.0           | 0.0           | 0.2            | 0.2       | 0.3       | 0.5       | 0.5       | 0.5       | 0.5       |
| Lebanon             | 8.1       |               | 8.1           |                | 8.8       | 9.3       | 10.0      | 10.1      | 13.7      | 20.8      |
| Oman                | 0.0       | 8.2 0.0       |               | 8.6 0.0        | 0.1       | 0.1       | 0.6       | 1.5       | 1.8       | 6.3       |
| Palestine Qatar     | 0.4 0.2   | 2.1           | 0.0 7.0       | 13.5           | 18.1 0.2  | 20.1      | 33.9      | 42.4      | 52.7      | 54.6 7.2  |
| Saudi Arabia        | 0.0       | 0.3 0.0       | 0.3 0.0       | 0.3 0.0        | 0.0       | 0.2 0.1   | 0.2 0.1   | 0.2 0.1   | 0.2 0.5   | 0.5       |
| Syrian AR           | 10.4      | 15.4          | 16.5          | 16.0           | 15.4      | 14.9      | 14.9      | 14.9      | 15.1      | 15.3      |
| United Arab Em      | 0.4       | 0.5           | 0.5           | 0.5            | 1.1       | 1.9       | 5.8       | 5.9       | 7.6       | 7.9       |
| Yemen               | 0.2       | 0.3           | 3.8           | 5.0            | 6.2       | 14.1      | 13.4 28.6 | 13.6      | 12.8      | 12.8      |
| N America           | 21.5 64.7 | 22.4          | 24.0          | 25.5 66.4      | 26.4 66.9 | 27.3      |           | 30.4 67.1 | 32.3      | 33.8 68.9 |
| Canada Greenland    | 48.7 23.7 | 65.5 48.7     | 66.3 48.7     | 48.7 26.2      | 48.7      | 67.2 48.8 | 67.2 48.8 | 48.9      | 68.6 48.9 | 48.9      |
| Mexico St Pierre Mq | 2.3       | 25.0          | 25.7          |                | 26.5      | 25.8      | 27.8      | 29.6      | 30.5      | 31.0      |
| USA                 | 16.0      | 16.8          | 18.2          | 19.9           | 21.0      | 22.0      | 23.5      | 25.7      | 27.7      | 29.5      |
| Oceania Amer Samoa  | 30.4 6.6  | 31.4 6.6      | 30.5 6.6      | 32.1 10.6      | 34.1 9.7  | 35.6 11.5 | 39.3 11.5 | 43.2 11.5 | 45.0 11.5 | 47.0 9.9  |
| Australia Cook Is   | 24.3      | 25.5          | 24.7          | 26.4           | 28.6      | 30.5      | 35.1      | 40.0      | 42.2      | 44.5      |
|                     | 5.6       | 11.8          | 17.8          | 14.3           | 14.3      | 21.0      | 23.4      | 23.4      | 23.4      | 23.4      |
| Fiji Fr Polynesia   | 61.3 23.5 | 61.3 25.6     | 55.9 26.4     | 56.1           | 57.9 28.3 | 58.0 28.8 | 55.1 29.7 | 55.1 30.5 | 56.1      | 56.1 30.2 |
| Guam                | 0.2       |               |               | 27.4 7.4       | 6.9       | 7.3       | 8.7       | 9.0       | 30.2      | 20.0      |
| Kiribati            | 7.1       | 0.3 10.3      | 6.1 26.1      | 30.4           | 30.4      | 30.4      | 30.4      | 30.4      | 9.3 30.4  | 30.4      |
| Marshall            | 2.0       | 3.4           | 3.4           |                | 5.5 7.1   | 5.6 9.8   | 5.6 10.4  | 5.6       | 5.6 10.4  | 5.8 10.4  |
| Is Micronesia Nauru | 2.2       |               |               | 5.3            | 4.1       | 4.7       | 9.3       | 10.4 9.3  |           |           |
| New                 | 2.1 18.2  | 5.7 1.8       | 6.7 1.8       | 7.7            | 14.9      | 15.1      | 17.7      | 19.1      | 10.9      | 11.8      |
| Caledon New Zealand | 73.3      |               |               | 5.7            | 78.2      | 78.3      | 78.4      |           | 19.4 78.3 | 19.2      |
| Niue                | 2.6       | 12.9          | 13.1          | 13.3 78.1 14.1 | 14.1      | 14.1      | 31.1      | 77.6 31.1 |           | 78.4      |
| Palau               | 1.9       | 73.8 14.1 3.4 | 76.8 14.1 3.4 |                | 6.2       | 7.2       | 9.3       | 9.3       | 31.1      | 31.1      |
| Papua N Guin        | 35.5      |               | 34.8          |                | 33.7      | 33.7      | 31.9      | 30.6      | 13.6 30.6 | 13.6      |
| Samoa               | 22.2      | 34.5          | 31.0          | 6.2 34.7       | 45.7      | 45.8      | 47.3      | 48.0      | 48.0      | 30.8 48.0 |
| Solomon Is          | 2.9       | 28.4          | 4.8           | 34.5           | 6.7       | 6.6       | 6.4       | 6.4       | 6.4       | 9.2       |
| Tokelau             | 86.8      |               | 86.8          |                | 87.8      | 87.8      | 88.0      | 88.0      | 88.0      | 88.0      |
| Tonga               | 17.2      | 4.0 86.8 14.5 | 19.2          | 6.4            | 30.1      | 30.9      | 34.7      | 34.7      | 31.2      | 46.3      |
|                     | 3.9       |               | 28.1          | 87.8 22.5      | 41.5      | 41.7      | 41.7      | 42.4      | 42.4      | 42.4      |
| Tuvalu              | 22.7      |               | 25.9          |                | 30.0      | 35.5      | 34.7      | 34.3      | 34.3      | 34.4      |
| Vanuatu             |           | 5.0 25.7      |               | 41.5 28.8      |           |           |           |           |           |           |
| S America           | 63.6      | 64.2          | 64.5          |                | 66.1      | 67.0      | 67.5      | 67.8      | 68.6      | 70.0      |
|                     |           |               |               | 65.4           |           |           |           | 33.1      | 34.6      | 34.7      |
| Argentina Bolivia   | 32.9 29.5 | 32.3 27.9     | 31.2 26.3     | 31.0 27.3      | 29.3 31.6 | 29.4 35.7 | 31.5 30.1 | 30.3      |           | 32.6      |
| Brazil              | 78.8      | 79.5          |               |                | 81.4      | 83.2      | 83.3      | 83.0      |           | 84.3      |
|                     |           |               | 80.0          | 80.8           |           |           |           |           |           |           |
|                     |           |               |               |                |           |           |           |           | 31.4 83.3 |           |
| Chile               | 42.5      | 42.9          | 42.6          | 41.2           | 45.7      | 46.8      | 47.8      | 50.7      | 54.1      | 58.6      |

## Renewable energy share of electricity capacity La part d'énergie renouvelable dans la puissance installée Proporción de energía renovable en la capacidad eléctrica

| %              |   2013 |   2014 |   2015 |   2016 |   2017 |   2018 |   2019 |   2020 |   2021 |   2022 |
|----------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Ecuador        |   43.4 |   42.6 |   43.3 |   56.4 |   58.6 |   60.8 |   60.8 |   60.8 |   60.3 |   61.1 |
| Falklands Malv |   16.8 |   16.8 |   15.6 |   15.6 |   15.6 |   15.6 |   30.8 |   19.9 |   19.9 |   19.9 |
| Fr Guiana      |   58.2 |   54.2 |   53.2 |   50.6 |   47.7 |   47.8 |   48.2 |   47.6 |   47.6 |   47.6 |
| Guyana         |   14.7 |   15.5 |   16.7 |   15.1 |   14.5 |   14.9 |   14.8 |   14.6 |   13   |   13   |
| Paraguay       |   99.8 |   99.8 |   99.8 |  100   |  100   |  100   |   99.7 |   99.7 |   99.7 |   99.7 |
| Peru           |   35.6 |   37.3 |   39.3 |   40.3 |   40.7 |   41.5 |   42.5 |   42.7 |   43   |   42.1 |
| South Georgia  |   57.4 |   57.4 |   57.4 |   57.4 |   57.4 |   57.4 |   57.4 |   57.4 |   57.4 |   57.4 |
| Suriname       |   37.7 |   35.9 |   36.1 |   36.1 |   35.9 |   36.1 |   36.1 |   35.7 |   33.1 |   33.3 |
| Uruguay        |   61.3 |   65.7 |   72.4 |   83.5 |   81.8 |   75.8 |   76   |   76   |   76.1 |   76.1 |
| Venezuela      |   49.3 |   48.9 |   48.8 |   51.3 |   51.1 |   50.9 |   50.4 |   50.4 |   50.4 |   50.4 |

<!-- image -->

IRENA Headquarters Masdar City P.O. Box 236 Abu Dhabi United Arab Emirates www.irena.org