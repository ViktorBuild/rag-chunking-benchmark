---
document_id: iea_electrification_2024
title: "Electrification in Clean Energy Transitions"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IEA"
year: 2024
original_file: "iea_electrification_clean_energy_transitions.pdf"
tables_detected: 49
converted_with: "Docling v2.32 (TableFormer)"
---

## Electrification Special Report

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 3 2 M ember countries, 1 4 A ssociation countries and beyond.

## IEA M ember

This publication , as well as any data and map included herein  are without prejudice , to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

countries:

Australia

Austria

Belgium

Canada

Czech Republic

Denmark

Estonia

Finland

France

Germany

Greece

Hungary

Ireland

Italy

Japan

Korea

Latvia

Lithuania

Luxembourg

Mexico

Netherlands

New Zealand

Norway

Poland

Portugal

Slovak Republic

Spain

Sweden

Switzerland

Republic of Türkiye

United Kingdom

United States

## IEA Association

countries:

Argentina

Brazil Chile Colombia Costa Rica Israel

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

IEA Accession countries:

Romania

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Foreword by IEA Executive Director, Dr Fatih Birol

Electricity is becoming ever more central to modern economies and vital to our daily lives. It powers everything from air conditioning and advanced manufacturing to digital communications and artificial intelligence - and is critical for prosperity and growth.

Two years ago, the International Energy Agency (IEA) said the world was entering the Age of Electricity. Today, the data confirm this: Electricity is playing an ever-greater role in meeting global energy needs, providing a growing share of the energy services used by consumers, and supporting a higher share of economic activity.

This special report was developed at the request of Türkiye and Australia, in the framework of the strategic partnership between the President of COP31 and the IEA. They invited the IEA to deliver analysis that examines the potential for greater electrification and assesses the benefits, key enabling conditions and remaining challenges, in order to provide a robust and data-driven basis for further action.

Disruptions to energy flows due to the conflict in the Middle East have caused the second major supply shock this decade, once again highlighting the vulnerabilities that can come with dependence on imported fuels. At the same time, record temperatures in many parts of the world underscore the challenge of addressing climate change. Electrification can play a key role in helping countries respond to both of these challenges - strengthening energy security while driving efforts to reduce emissions.

There is already considerable momentum around the world. Electricity demand from data centres and air conditioners is rising fast, and sales of electric cars and heat pumps have grown strongly in recent years. In many regions, these trends are accelerating. Electrification also represents a major economic opportunity, supporting growth in sectors ranging from grid equipment and power generation to end-use technologies.

The benefits  can  extend to  all  regions,  although  countries  will  naturally  pursue  different pathways according to their circumstances and goals. For countries where access to modern energy services remains limited, expanding access to electricity must remain a top priority.

The findings of this report highlight the scale of the electrification opportunity. Thanks to remarkable advances in technologies and broadening policy frameworks, the report shows that  tapping  today's  cost-effective  electrification  potential  would  put  the  world  within striking distance of the goal of a 35% share of electricity in global energy consumption by 2035. Stronger action to achieve this goal can support energy security by reducing imports, but policy makers must also pay attention to new energy security risks, including in critical mineral and energy technology supply chains.

This  potential  exists  today,  but  more  action  will  be  needed  to  maximise  the  benefits  of electrification. These benefits are multiplied when electricity is supplied increasingly from low-emissions sources, and when investment in grids, resilience, storage and other sources of flexibility keeps pace with rising demand.

<!-- image -->

I would like to thank the governments of Türkiye and Australia for inviting the IEA to act as a strategic partner of COP31. In addition to this report on electrification, we are also delivering new analysis to support efforts to improve energy efficiency in buildings and to cut global growth in waste.

The Age of Electricity  is  already  taking  shape,  but  accelerating  electrification  will  require concerted action  from  governments,  plus  all  the  financial  and  innovative  capacity  of  the private sector. I hope the insights this report offers will inform international discussions going into COP31, and beyond. I would like to thank the IEA team who developed this analysis under the guidance of Laura Cozzi, and led by Thomas Spencer and Alex Martinos.

Dr Fatih Birol Executive Director International Energy Agency

<!-- image -->

4

## Foreword by COP31 President-Designate, Murat Kurum

The world is entering the Age of Electricity. At COP31, we will flick the switch.

Under  our  strategic  partnership,  the  COP31  Presidency  invited  the  International  Energy Agency to outline the opportunities and challenges of moving faster towards an electrified world. This report is a critical framework for the COP31 Presidency's global target to reach a 35% share of electricity in final energy consumption by 2035.

We need this target. Until now, electrification has not been underpinned by a clear global goal. The economics are shifting in electrification's favour. But global policymaking has not kept pace, and electrification still needs to be mainstreamed in many national climate and investment plans. The COP31 Presidency's 35-by-35 target provides a clear global direction and can help drive collective progress. It also complements existing targets on renewables, energy efficiency, grids, and finance, and completes the architecture of the energy transition.

This  report  shows  where  we  are  and  that  the  target  is  within  reach.  Much  of  the electrification  we  need  can  already  be  done  cost-effectively  with  technologies  available today. But cost-effectiveness alone will not close the gap. Progress will require collective action  from  governments,  businesses,  investors,  subnational  governments,  international organizations, civil society organisations and other partners. Together, we need to support infrastructure,  strengthen  enabling  policies  and  incentives,  mobilise  investment,  raise awareness, and support households and businesses in making the switch. We must also take into account that access and system readiness remain deeply uneven across regions.

The  long-term  benefits  are  clear.  Electrification  advances  energy  efficiency,  economic development and energy access. Amid heightened volatility in global energy markets, it is also an energy security priority. This report shows how by 2035, greater electrification could cut the world's energy import bills by more than USD 500 billion every year. Those are savings our citizens will feel, and the resilience our economies need. And as we face a super El Niño and another year of record-breaking temperatures, the urgency of reducing emissions and keeping 1.5 °C alive is clear. Greater electrification can make an important contribution to this effort, while delivering wider benefits for our economies and societies. We cannot afford to miss this opportunity.

The Age of Electricity is already taking shape. Antalya will be the moment we commit to it together. I invite all partners to draw on this report and work together towards the 35-by-35 target, building momentum for electrification on the road to COP31 and beyond.

H. E. Murat Kurum Minister of Environment, Urbanization and Climate Change Government of Türkiye COP31 President-Designate

<!-- image -->

## Foreword by COP31 President of Negotiations, Chris Bowen

Electrification  offers  many  benefits  at  once:  it  strengthens  energy  security,  supports economic development, improves affordability and lowers emissions.

This Special Report on Electrification arrives at a critical moment. The global energy shock has  prompted  many  countries  to  seek  ways  to  strengthen  energy  security,  while  still delivering affordable and reliable energy. The analysis by the International Energy Agency (IEA)  shows  that  electrification  acts  on  each  of  these  challenges,  while  also  supporting economic growth and lowering emissions. Australia is pleased to contribute support for this important work by the IEA, to elevate electrification and strengthen the evidence base for its deployment.

Electrified economies, powered with clean energy, and backed by modern grids and storage, are an enduring answer. A significant finding of the report is that we already have the means to  deliver  an  electrified  world  today.  For  our  homes,  businesses  and  communities, substantial cost-effective electrification potential can be achieved with technologies that are already commercial.

As  COP31  President  of  Negotiations,  Australia  has  heard  growing  recognition  of  the electrification opportunity among all Parties. Electrification enables the clean energy we are deploying to flow into more sectors of our economies. It means more people can access clean, efficient electricity for productive uses. That is why it resonates across a broad range of national circumstances. It is not limited to any one region, level of development or energy system.  While  countries  will  pursue  different  pathways  based  on  their  circumstances, electrification is a practical way to advance objectives that are widely shared.

Realising this opportunity will require investment in grids, storage and system flexibility, and policies to support the uptake of electrified technologies. In Australia's case, electrification is being championed by households across the country. Australia has world-leading uptake of  rooftop  solar  and  home  batteries,  with  electric  vehicle  sales  overtaking  conventional petrol cars for the first time in August. Our national experience shows how a pragmatic policy approach paired with a strong enabling environment translates into tangible outcomes.

Driven by technology, economics and investment, the clean energy transition has become unstoppable. The shift to an electrified world is well underway. The challenge is deployment, at speed and scale.

I thank the IEA for this timely and rigorous work. Their independent analysis and expertise are vital to informing international engagement and decision-making. This report will be an important contribution to deliberations at Pre-COP, COP31 and in the years ahead.

H. E. Chris Bowen Minister for Climate Change and Energy Government of Australia COP31 President of Negotiations

I

This report was designed and directed by Laura Cozzi , Director for Sustainability, Technology and  Outlooks,  of  the  International  Energy  Agency  (IEA),  in  co-operation  with  other directorates and offices in the IEA. The lead authors and co-ordinators of the report were Thomas Spencer and Alex Martinos . Modelling and analysis teams were led by Stéphanie Bouckaert (electricity demand) and Brent Wanner (electricity supply). End-use electrification analysis was led by Anthony Vautrin ; electricity supply analysis was led by Max Schoenfisch .

Key  contributions  were  from: Oskaras  Alsauskas (transport), James  Bragg (industrial ecosystem), Eric  Buisson (critical  minerals), Gavin  Cook (emissions), Davide  D'Ambrosio (data  science), Michael  Drtil (electricity  grids), Eric  Fabozzi (electricity  grids), Sangitha Harmsen (demand flexibility), Vincent Jacamon (buildings), Brieuc Nerincx (energy prices), Nikolaos  Papastefanakis (electricity  supply), Arthur  Roge (energy  access), Rebecca  Ruff (employment  and  energy  imports), Gabriel  Saive (policy analysis), Nicholas  Salmon (industry), Siddharth  Singh (emerging  and  developing  economies)  and Agrata  Verma (technology supply chains).

Other contributions were from: Jay  Barlow , Paul  Barraqué , Christine  Brandstätt , Jacopo Cavagna Leïlou Daunit Nouhoun Diarra  Hugh Hopewell Arthur Jongejans Luca Lo Re Teo , , , , , , Lombardo Emily Mason , , Vera O'Riordan , Marina Petrelli , Apostolos Petropoulos , Martin Scheubrein , Martí Serra i Oliveras and Ryota Taniguchi .

Edmund Hosker carried editorial responsibility.

Marina Dos Santos , Reka Koczka , and Eleni Tsoukala provided essential support.

Valuable comments and feedback were provided by members of senior management and other  colleagues  within  the  IEA,  in  particular:  Alessandro  Blasi,  Paolo  Frankl,  Tim  Gould, Timur Gül, Brian Motherway, and Maria Sicilia.

Valuable input to the report and analysis was provided by Paul Hugues and David Wilkinson (independent consultants).

Essential support was provided by the IEA's Communications and Digital Office, particularly Jethro  Mullen,  Maria  Ahmad,  Poeli  Bojorquez,  Curtis  Brainard,  Gaelle  Bruneau,  Astrid Dumond, Liv Gaunt, Julia Horowitz, Isabelle Nonain-Semelin, Lucile Wall and Wonjik Yang. IEA's Office of the Legal Counsel, Office of Management and Administration and Energy Data Centre provided assistance throughout the preparation of the report.

The work could not have been completed without the support and co-operation provided by Australia (Department of Climate Change, Energy, the Environment and Water) and Ireland (Department of Climate, Energy and the Environment), and by other supporters of the IEA Clean Energy Transitions Programme. This project also benefited from the support of the Government  of  Turkiye  (Ministry  of  Environment,  Urbanization  and  Climate  Change  and Ministry of Energy and Natural Resources).

## Peer reviewers

Many senior government officials and international experts provided input and reviewed preliminary drafts of the report. Their comments and suggestions were of great value. They include:

Gilda Amorosi

Microsoft

Harmeet Bawa

Hitachi Energy

Anne-Sophie Cerisola

Independent Climate Action Consultant

Rebecca Collyer

European Climate Foundation

Paul Durrant

Department for Energy Security and Net Zero, United Kingdom

Bilal Düzgün

Ministry of Energy and Natural Resources, Turkey

Martha Ekkert

Federal Ministry for the Environment, Climate Action, Nature Conservation and Nuclear Safety, Germany

Maj Estrid Emmertsen

Ministry of Foreign Affairs, Denmark

Antonia Gawel

Google

Craig Glazer

PJM Interconnection

Nathalie Grisey

RTE, France

Michael Hackethal

Federal Ministry for Economic Affairs and Climate Action, Germany

Selwin Hart

United Nations

Edwin Heasen

ENTSO-E

Nathan Hernandez

Department of Energy, United States

David Higgins

Department of Climate Change, Energy, the Environment and Water, Australia

Tom Howes

Directorate-General for Energy, European Commission Iberdrola

Francisco Laveron

Youngjoo Lee

Ministry of Foreign Affairs, Republic of Korea

Eoin McShane

Department of Climate, Energy and the Environment, Ireland

Vincent Minier

Schneider Electric

Isabel Murray

Department of Natural Resources, Canada

Motoko Ogawa

Ministry of Foreign Affairs, Japan

Jose Ignacio Perez-Arriaga

Comillas Pontifical University's Institute for Research in Technology, Spain

Maria Gemma Pisano

Terna

Vicky Pollard

Directorate-General for Climate Action, European Commission

Elizabeth Press

Accelerated Partnership for Renewables in Africa

Davide Puglielli

ENEL

Jan Rosenow

University of Oxford

Jesse Scott

Hertie School

Okan U urlu ğ

Ministry of Environment, Urbanisation and Climate Change, Turkey

Charles Weymuller

EDF

This  work  reflects  the  views  of  the  International  Energy  Agency  Secretariat  but  does  not necessarily  reflect  those  of  individual  IEA  Member  countries  or  of  any  particular  funder, supporter or collaborator. Neither the IEA nor any funder, supporter or collaborator that contributed  to  this  work,  makes  any  representation  or  warranty,  express  or  implied,  in respect of its contents, including its completeness or accuracy, and shall not be responsible for any use of, or reliance on, the work.

This  document  and  any  map  included  herein  are  without  prejudice  to  the  status  of  or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

## Comments and questions are welcome and should be addressed to:

Laura Cozzi

Directorate of Sustainability, Technology and Outlooks

International Energy Agency 9, rue de la Fédération 75739 Paris Cedex 15 France

E-mail: electrification@iea.org

<!-- image -->

I

| Forewords............................................................................................................................... 3   | Forewords............................................................................................................................... 3    | Forewords............................................................................................................................... 3                                                        | Forewords............................................................................................................................... 3   |
|----------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------|
| Acknowledgements.................................................................................................................            | Acknowledgements.................................................................................................................             | Acknowledgements.................................................................................................................                                                                 | 7                                                                                                                                            |
| Executive summary...............................................................................................................             | Executive summary...............................................................................................................              | Executive summary...............................................................................................................                                                                  |                                                                                                                                              |
|                                                                                                                                              | The Age of Electricity 1.1 Introduction...................................................................................................... | The Age of Electricity 1.1 Introduction......................................................................................................                                                     | 24                                                                                                                                           |
|                                                                                                                                              |                                                                                                                                               | Electricity's growing role in economies and energy systems ...........................                                                                                                            | 27                                                                                                                                           |
|                                                                                                                                              | 1.2                                                                                                                                           | 1.2.1 Electricity in the                                                                                                                                                                          | global energy system.................................................. 27                                                                    |
|                                                                                                                                              |                                                                                                                                               | 1.2.2 Differences in electrification by sector and by region...........................                                                                                                           | 30                                                                                                                                           |
|                                                                                                                                              |                                                                                                                                               | 1.2.3                                                                                                                                                                                             |                                                                                                                                              |
|                                                                                                                                              | 1.3                                                                                                                                           | Deployment of electrification technologies..........................................                                                                                                              | 33                                                                                                                                           |
|                                                                                                                                              |                                                                                                                                               | Expanding and evolving electricity supply........................................................                                                                                                 | 34                                                                                                                                           |
|                                                                                                                                              | 1.4                                                                                                                                           | Impact of the current energy crisis ..................................................................                                                                                            | 36                                                                                                                                           |
|                                                                                                                                              | 1.5                                                                                                                                           | The policy landscape for                                                                                                                                                                          | electrification............................................................ 40                                                               |
|                                                                                                                                              |                                                                                                                                               | 1.5.1 Policies                                                                                                                                                                                    | .................................................................................................. 40                                        |
|                                                                                                                                              |                                                                                                                                               | 1.5.2 Nationally Determined Contributions...................................................                                                                                                      | 43                                                                                                                                           |
|                                                                                                                                              | 1.6                                                                                                                                           | Scenario definitions..........................................................................................                                                                                    | 45                                                                                                                                           |
| 2                                                                                                                                            | Electrification in end-uses                                                                                                                   | Electrification in end-uses                                                                                                                                                                       | 47                                                                                                                                           |
|                                                                                                                                              | 2.1                                                                                                                                           | Outlooks for electrification in IEA scenarios.....................................................                                                                                                | 48                                                                                                                                           |
|                                                                                                                                              |                                                                                                                                               | 2.1.1 Drivers of electrification........................................................................                                                                                          | 48                                                                                                                                           |
|                                                                                                                                              |                                                                                                                                               | 2.1.2 High-level electrification                                                                                                                                                                  | outcomes ...................................................... 49                                                                           |
|                                                                                                                                              |                                                                                                                                               | 2.1.3 Implications for electricity demand ......................................................                                                                                                  | 50                                                                                                                                           |
|                                                                                                                                              | 2.2                                                                                                                                           | Economic electrification potential                                                                                                                                                                | ................................................................... 51                                                                       |
|                                                                                                                                              |                                                                                                                                               | 2.2.1 Economic potential                                                                                                                                                                          | by sector................................................................ 51                                                                 |
|                                                                                                                                              |                                                                                                                                               | 2.2.2 Economic potential                                                                                                                                                                          | by region ............................................................... 53                                                                 |
|                                                                                                                                              |                                                                                                                                               | 2.2.3 Sensitivity of economic potential to changing conditions.....................                                                                                                               | 54                                                                                                                                           |
|                                                                                                                                              |                                                                                                                                               | electrification ........................................................................................ 2.2.5 Demand flexibility and cost-effective electrification ............................ | 56 58                                                                                                                                        |
|                                                                                                                                              | 2.3                                                                                                                                           |                                                                                                                                                                                                   | 61                                                                                                                                           |
|                                                                                                                                              | Drivers of electrification in emerging market and developing economies.......                                                                 | Drivers of electrification in emerging market and developing economies.......                                                                                                                     |                                                                                                                                              |
|                                                                                                                                              |                                                                                                                                               | 2.3.1 Transport...............................................................................................                                                                                    | 61                                                                                                                                           |
|                                                                                                                                              |                                                                                                                                               | 2.3.2 Buildings................................................................................................                                                                                   | 63                                                                                                                                           |
|                                                                                                                                              |                                                                                                                                               | 2.3.3 Industry .................................................................................................                                                                                  | 64                                                                                                                                           |
|                                                                                                                                              | 2.3.4 Agriculture.............................................................................................                                | 2.3.4 Agriculture.............................................................................................                                                                                    | 65                                                                                                                                           |

I

3

4

| 2.4                      | Transport electrification...................................................................................          | Transport electrification...................................................................................          |   67 |
|--------------------------|-----------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|------|
|                          | 2.4.1                                                                                                                 | Transport technologies .........................................................................                      |   68 |
|                          | 2.4.2                                                                                                                 | Transport strategies ..............................................................................                   |   72 |
|                          | 2.4.3                                                                                                                 | Transport potential ...............................................................................                   |   79 |
| 2.5                      | Buildings electrification ....................................................................................        | Buildings electrification ....................................................................................        |   80 |
|                          | 2.5.1                                                                                                                 | Buildings technologies ..........................................................................                     |   81 |
|                          | 2.5.2                                                                                                                 | Buildings strategies ...............................................................................                  |   83 |
|                          | 2.5.3                                                                                                                 | Buildings potential ................................................................................                  |   87 |
| 2.6                      | Industry electrification .....................................................................................        | Industry electrification .....................................................................................        |   88 |
|                          | 2.6.1                                                                                                                 | Industry technologies............................................................................                     |   89 |
|                          | 2.6.2                                                                                                                 | Industry strategies.................................................................................                  |   90 |
| Powering electrification | Powering electrification                                                                                              | Powering electrification                                                                                              |   97 |
| 3.1                      | Introduction......................................................................................................    | Introduction......................................................................................................    |   98 |
| 3.2                      | Electricity generation .......................................................................................        | Electricity generation .......................................................................................        |   98 |
|                          | 3.2.1                                                                                                                 | HES with the NZE mix..........................................................................                        |  100 |
|                          | 3.2.2                                                                                                                 | HES with the STEPS mix.......................................................................                         |  107 |
|                          | 3.2.3                                                                                                                 | HES with the CPS mix ..........................................................................                       |  112 |
| 3.3                      | Grids ............................................................................................................... | Grids ............................................................................................................... |  114 |
|                          | 3.3.1                                                                                                                 | Grid expansion in the High Electrification Scenario ............................                                      |  115 |
|                          | 3.3.2                                                                                                                 | Grid lead times and implementation challenges ................................                                        |  116 |
|                          | 3.3.3                                                                                                                 | Solutions to accelerate grid expansion and modernisation................                                              |  119 |
| Implications             | Implications                                                                                                          | Implications                                                                                                          |  123 |
| 4.1                      | Introduction....................................................................................................      | Introduction....................................................................................................      |  124 |
| 4.2                      | Energy security and resilience........................................................................                | Energy security and resilience........................................................................                |  124 |
|                          | 4.2.1                                                                                                                 | Import dependence.............................................................................                        |  124 |
|                          | 4.2.2                                                                                                                 | Electricity security...............................................................................                   |  128 |
|                          | 4.2.3                                                                                                                 | Resilience ............................................................................................               |  131 |
| 4.3                      | Industrial ecosystem and secure supply chains..............................................                           | Industrial ecosystem and secure supply chains..............................................                           |  135 |
|                          | 4.3.1                                                                                                                 | The industrial ecosystem for electrification........................................                                  |  135 |
|                          | 4.3.2                                                                                                                 | Critical minerals...................................................................................                  |  138 |
|                          | 4.3.3                                                                                                                 | Manufacturing of technologies related to electrification ...................                                          |  141 |
| 4.4                      |                                                                                                                       | Investment, affordability and employment....................................................                          |  144 |
|                          | 4.4.1 Investment ..........................................................................................           | 4.4.1 Investment ..........................................................................................           |  144 |

I

|                                                                                                                                      | 4.4.2                                                                                                                                | Electrification and employment.......................................................... 152                                         |
|--------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------|
| 4.5                                                                                                                                  | Emissions........................................................................................................ 155                | Emissions........................................................................................................ 155                |
|                                                                                                                                      | 4.5.1                                                                                                                                | CO 2 emissions...................................................................................... 155                             |
|                                                                                                                                      | 4.5.2                                                                                                                                | Air pollution emissions........................................................................ 158                                  |
| 4.6                                                                                                                                  | Inclusive electrification................................................................................... 159                     | Inclusive electrification................................................................................... 159                     |
|                                                                                                                                      | 4.6.1                                                                                                                                | Electricity access gap........................................................................... 159                                |
|                                                                                                                                      | 4.6.2                                                                                                                                | Reliable electrification can unlock productive uses and foster                                                                       |
|                                                                                                                                      |                                                                                                                                      | economic development ...................................................................... 163                                      |
|                                                                                                                                      | 4.6.3                                                                                                                                | Productive uses can strengthen the case for electrification ............... 166                                                      |
|                                                                                                                                      | 4.6.4                                                                                                                                | Making use of decentralised technologies.......................................... 168                                               |
| Annexes                                                                                                                              | Annexes                                                                                                                              | Annexes                                                                                                                              |
| Annex A. Definitions............................................................................................................ 175 | Annex A. Definitions............................................................................................................ 175 | Annex A. Definitions............................................................................................................ 175 |
| Annex B. References ........................................................................................................... 193  | Annex B. References ........................................................................................................... 193  | Annex B. References ........................................................................................................... 193  |

<!-- image -->

## The Age of Electricity

Electricity  plays  a  central  and  growing  role  in  powering  modern  economies.  Its  rapid growth and increasing economic importance can bring major benefits for competitiveness, energy security and energy transitions. Global  electricity  demand  has  grown  faster  than global  GDP  and  nearly  twice  as  fast  as  overall  energy  demand  in  recent  years.  Already electrified end-uses such as air conditioning, data centres and advanced manufacturing are expanding quickly, while sales of electric vehicles have surged.

Electricity is therefore the main source of energy for activities that generate nearly half the world's GDP. Globally, one-fifth of the increase in the revenues of manufacturing companies since 2020 has come from electrification-related sectors. Around half of these revenues flow to companies headquartered in Europe, Japan, Korea and North America, driven by their strong  positions  in  grid  equipment,  generation  and  end-use  technologies.  Companies headquartered in China account for the vast majority of the remainder. These shares have remained broadly the same since 2020. High value-added sectors like digital and financial services, artificial intelligence and advanced manufacturing are powered by electricity, as are key technologies like chips and robotics.

Even so, around 730 million people today still lack access to electricity, constraining their ability to meet basic energy needs and limiting opportunities for economic development. This is one of the reasons for large variations in electricity use around the world. Total per capita electricity consumption is 200 kilowatt-hours (kWh) per year in sub-Saharan Africa; advanced economies consume on average around 7 000 kWh per capita, as does China.

Amid  two  ongoing  energy  supply  shocks  and  persistent  concerns  around  energy affordability,  many  countries  are  looking  to  electrification  as  a  tool  to  boost  energy security: 25 have announced new electrification-related policies since February 2026. Sales of electrification-related technologies have jumped, particularly in markets most exposed to disruptions in energy shipments through the Strait of Hormuz. In addition, electrification is the main opportunity to bring down emissions across transport, industry and buildings.

This report was developed at the request of Türkiye and Australia, in the framework of the strategic  partnership  between  the  President  of  COP31  and  the  IEA. It  explores a  High Electrification Scenario that achieves the goal of increasing the share of electricity in global final  energy  consumption to 35% by 2035 - in line with the objective announced by the COP31  President.  It  analyses  electrification  potential  by  sector,  implications  for  energy security and climate goals, and broader benefits and trade-offs.

## Cost-effective technologies bring 35% electrification within striking distance

New  sector-by-sector  analysis  by  the  IEA  shows  that  it  is  cost-effective  to  raise electrification levels to around 33% of global energy consumption today. This analysis is based  on  2025  technology  costs,  energy  prices  and  financing  conditions;  continued technology cost declines will increase this potential. This would bring the world close to the

goal, currently under international discussion, of reaching a global electrification rate of 35%, up from 23% today. This trajectory for electrification, reaching 35% by 2035, is derived from the IEA's energy sector pathway to net zero emissions globally by 2050. Electrification rates differ across countries depending on the structure of their economies and energy systems, and their policy goals. Countries do not all reach the same endpoint in global electrification pathways.

The greatest potential lies in the transport sector, underpinned by the 90% reduction in lithium-ion battery prices since 2010. Our analysis finds that around half of oil-based road transport  demand  could  be  electrified  competitively  today.  If  battery  prices  continue  to move down the cost curve as in recent years, this would rise to over four-fifths.

Buildings offer major potential for the electrification of space and water heating. The sector is already quite electrified due to the rapid growth of end-uses that only run on electricity, such  as  cooling,  appliances,  data  centres  and  information  technology  equipment.  But electrification  rates  are  much  lower  for  end-uses  such  as  heating,  which  can  be  met  by multiple fuels.  Our  analysis  estimates  that  half  of  global  space  heating  demand  could  be electrified competitively.

In  industry,  the  key  sectors  with  near-term  electrification  potential  are  textiles,  food processing, pulp and paper, and some chemicals production. IEA analysis finds that around 40% of energy consumption in low- and medium-temperature applications in industry can be electrified cost-effectively.

## Near-term priorities differ, but all regions have untapped potential

All regions  around  the  world  have  substantial  cost-effective  potential  to  increase electrification rates above today's levels. Specific opportunities differ depending on local energy costs, taxes, financing conditions, infrastructure availability and industrial strategies. Energy importers see the greatest potential, because consumers in these regions typically face higher fuel prices. Tapping cost-effective potential in Europe would raise electrification rates by almost 15 percentage points compared with today; the Middle East, a major energyexporting region, would see a smaller increase of 5 percentage points.

Advanced economies and China typically have high heating needs and large fleets of cars; in both of these uses, electrification can be cost-effective today. Globally, the majority of heating  demand  comes  from  advanced  economies  and  China,  and  heat  pumps  are competitive in around 75% of these markets today. Many countries have both heating and cooling  needs,  and  traditional  heating-only  markets  are  seeing  emerging  demand  for  air conditioning  as  temperatures  rise.  In  these  markets,  reversible  heat  pumps  are  a  costeffective solution for providing both heating and cooling. Three out of four cars on the road globally are in advanced economies and China, and around half of road transport demand in these countries is cost-effective to electrify today. In Europe, one in three cars sold were electric in the first half of 2026, a substantial increase compared with 2025.

In emerging and developing economies, light industry and dense and often polluted cities provide strong opportunities for electrification. The rapid growth of housing, infrastructure, cars and appliances provides scope to electrify from the outset. In Southeast Asia, the share of electric cars in total sales increased by around 10 percentage points in the first half of 2026,  bringing  it  to  a  level  comparable  with  Europe.  In  many  emerging  and  developing economies, dense cities mean that daily commute distances are far shorter than the range offered by electric cars and motorcycles available on the market today. High levels of air pollution and fuel imports provide additional incentives to electrify. Heat for light industry and for cooking and water heating in buildings provides further opportunities. For countries that  do  not  yet  have  full  access  to  modern  energy,  expanding  access  to  electricity  and supporting the growth of productive uses in agriculture and manufacturing are key to raising electrification rates.

## Electrification can bring major energy security benefits

Electrification can be a key pillar of strategies to diversify energy consumption in end-uses and deliver significant benefits for energy security. Today, electric cars, motorcycles, trucks and buses together avoid around 2.3 million barrels of oil demand per day (mb/d). This is more than the amount that bypassed the Strait of Hormuz via the United Arab Emirates' Habshan-Fujairah pipeline in summer 2026, providing an important lifeline to oil markets. By 2035, electric cars are set to account for around half of global sales in a scenario based on today's policy settings, up from a quarter today. By 2035, electric vehicles avoid oil demand of around 10 mb/d, equivalent to the total oil production of Russia.

The  High  Electrification Scenario  sees  these  trends  accelerate,  with  electrification extending  to  additional  end-uses  and  regions. In  this  scenario,  importers  reduce  their import bills by around a quarter by 2035 compared with 2025, or USD 400 billion per year. Assessed  against  the  higher  energy  prices  that  prevail  in  2026,  this  rises  to  more  than USD 500 billion. Global avoided oil demand due to electric vehicle adoption in this scenario rises to 18 mb/d by 2035, of which four-fifths occurs in fuel-importing regions.

For fuel exporters, electrification can support a more diversified energy mix and improved economic resilience. Some fuel exporters consume large amounts of energy domestically, supported by low energy prices. In some cases, below-market energy prices also represent substantial forgone fiscal resources; reforming energy pricing has often proven politically challenging.  For  these  countries,  electrification  can  offer  an  opportunity  to  tap  domestic renewable  resources,  which  are  often  significant;  develop  technologies  such  as  nuclear power;  improve  energy  efficiency;  and  support  the  rationalisation  of  energy  pricing. Electrification can therefore be part of strategies to promote greater economic diversification and resilience.

How electricity demand is met matters, but importers see reductions in import bills across a range of electricity generation scenarios. Very little oil is  used in electricity generation globally, and so the electrification of transport in the High Electrification Scenario leads to reductions in oil imports  regardless of the electricity generation  mix. In the specific case

where a heat pump replaces natural gas for heating, its efficiency gains are large enough to lower total natural gas demand, even when all additional electricity generation required is supplied by natural gas. However, the overall impact of electrification on natural gas demand and imports is influenced by evolutions in the electricity generation mix.

## Electrification cuts emissions, but by itself is not enough for climate targets

Building on the wide availability of cost-effective technologies, electrification is a critical strategy to reduce emissions in end-uses. The combustion of fossil fuels in end-use sectors accounts  for  around  18.5 billion  tonnes  of  carbon  dioxide  emissions  globally,  and  these emissions  have  increased  by  around  5%  since  2015.  In  the  High  Electrification  Scenario, end-use emissions fall by 40% by 2035.

Efficiency, renewables deployment and electrification are three mutually reinforcing goals; alongside other technologies, these are critical to pathways that return temperatures to below 1.5 °C in the longer term. An electrification goal of 35% by 2035 is aligned with and supports  the  goals  of  doubling  efficiency  improvements  and  tripling  global  renewables capacity. Because electric technologies waste less energy, they support the efficiency goal. Energy efficiency  measures also make electrification easier  and  more  affordable.  Tripling renewables helps meet additional electricity demand with low-emissions sources. Net zero pathways,  however,  also  require  action  on  technologies  like  nuclear  power,  bioenergy, carbon  capture  and  storage,  and  low-emissions  fuels  like  hydrogen  and  its  derivatives  although  the  precise  mix  depends  on  national  circumstances.  After  2035,  electrifying additional end-uses requires technological innovation to unlock further potential.

## The foundations for clean electrification are taking shape …

The global electricity mix has undergone profound changes over the past decade, but the transition is far from complete. The share of generation from low-emissions sources rose from 33% in 2015 to 42% in 2025, with renewables and nuclear providing nearly 70% of the increase in global electricity generation over this timeframe. Solar PV deployment increased more  than  tenfold  and  wind  deployment  more  than  doubled.  In  2025,  the  increase  in low-emissions generation matched global electricity demand growth. Coal- and natural gasfired generation also increased over the past decade. Electricity generation still accounts for around 14 billion tonnes of CO₂ emissions annually, and these emissions have yet to peak .

## … but maximising the benefits demands systems thinking

Electrification cuts emissions  under  today's  policy  settings, but cleaner electricity multiplies its impact. Raising electricity's share of final energy consumption to 35% pushes electricity demand growth to 1 400 terawatt-hours per year to 2035, nearly twice the pace of  the  past  decade.  If  low-emissions  sources  of  electricity  continue  to  grow  in  line  with today's policy settings, their growth is just sufficient to meet all additional electricity demand in aggregate. As a result, emissions from electricity generation decline modestly, reinforcing emissions  reductions  in  end-uses.  However,  a  pathway  to  net  zero  emissions  by  2050

requires a much faster expansion of low-emissions supply, with annual solar PV additions doubling to over 1 200 gigawatts (GW) by 2035, wind additions increasing by two-and-a-half times to around 400 GW and nuclear power making a strong comeback.

Secure,  reliable  and  affordable  electrification  requires  low-emissions  generation,  grids, digital capabilities, storage and other flexibility options to develop together. Grids need to be modernised and expanded 40% faster to 2035 than over the past decade to connect new supply and rapidly growing demand in the High Electrification Scenario. Delays would lead to longer  connection  queues,  greater  congestion  and  curtailment,  and  increased  risks  to reliability.  On  a  pathway  to  net  zero,  for  example,  battery  storage  capacity  rises  almost tenfold,  reaching  around  2 900 GW  by  2035,  helping  to  shift  electricity  across  the  day. Demand response can complement this by moving vehicle charging, heating and cooling, and suitable  industry  processes  away  from  periods  of  system  stress.  Together,  storage  and demand  response  can  support  affordable  electrification  by  tapping  lower-cost  variable renewables  and  making  fuller  use  of  existing  infrastructure.  This  requires  co-ordinated planning of generation, networks, storage and demand, supported by the right incentives, smart-grid capabilities, and robust cybersecurity safeguards.

## Emerging risks in electrification supply chains also need to be managed

Many  countries  are  concerned  that  electrification  could  create  new  dependencies  on technology supply chains, but the nature of this risk is different. Critical minerals and supply chains  for  some  electrification  technologies,  such  as  batteries,  are  characterised  by  high levels  of  geographical concentration. Reducing exposure to these supply dependencies is essential,  as  is  ensuring  a  level  playing  field.  At  the  same  time,  unlike  combustion-based technologies, which depend on continuous flows of input fuels, any disruptions to supply chains for electrification technologies would not affect the operation of equipment already installed in energy systems. However, potential remote control of digitally connected energy assets can be a source of risk, highlighting the significance of cybersecurity safeguards.

Electrification technologies increasingly overlap with those in other strategic areas, such as artificial intelligence, robotics and advanced manufacturing. For this reason, strengthening innovation and manufacturing capacities in electrification technologies will be important for broader economic security. Balancing the benefits of international trade with efforts to diversify supply chains will remain a critical challenge for policy makers.

## Key barriers remain

Although electrification can be cost-effective in many contexts today, barriers remain in terms of consumer convenience and awareness, infrastructure and market readiness, and access to finance. Consumers often lack the means to account for longer-term savings from electrification,  or  access  to  affordable  finance  if  needed  to  cover  higher  upfront  costs. Electrification requires infrastructure upgrades: in many markets, permitting and building are  slow,  and  planning  is  fragmented.  In  some  emerging  and  developing  economies,  the unreliability or high cost of grid electricity supply is a key barrier. Energy taxes, subsidies and

prices  also  influence  the  cost  attractiveness  of  electrification  options.  Reflecting  these barriers, the global electrification rate rises to around 30% by 2035 in a scenario based on today's policy settings, highlighting the action that would still be needed to meet the global goal under discussion.

Although  an  increasing  number  of  countries  have  sector-specific  policies  such  as  EV support  schemes,  to  date  very  few  have  comprehensive,  cross-sectoral  electrification strategies. Deeper electrification will require more integrated approaches to energy system planning  that  better  co-ordinate  economy-wide  electrification,  electricity  transitions  and enabling infrastructure.

## Electrification can help improve energy affordability with the right policies

While electrification can deliver lower-cost energy services, it can require large upfront investments that may be a barrier. In the High Electrification Scenario, global investment in end-use electrification sees a threefold increase to around USD 1 trillion by 2035. In contrast to investments in electricity generation and networks, investments in end-use electrification are often undertaken by many actors, such as households, businesses and public authorities. Some may have limited access to capital or pay high costs for it; some may discount future benefits. This means that policy measures such as subsidies, investment support, awareness campaigns and regulations may be needed.

Electricity can deliver energy services more cheaply because of the greater efficiency of electric technologies. While electricity typically costs more per unit of energy consumed than fuels like natural gas or gasoline, technologies that consume electricity are often much more efficient than their conventional equivalents. EVs are around three-times more efficient than internal combustion engine vehicles; the efficiency gains for heat pumps over conventional boilers  can  be  greater  still.  As  a  result,  electrification  technologies  can  save  consumers money across their operating lifetime.

Attention needs to be paid to how the benefits and costs of electrification are distributed. Average household energy bills in the High Electrification Scenario fall by around 15% by 2035 compared with today, benefiting from the greater efficiency and lower operational costs  of  electrical  technologies.  But  to  realise  these  gains,  individual  households  need  to make large, one-off investments in new heating equipment or vehicles. Such costs can place a major burden on lower-income households; policies that aim to push higher electrification may need to be accompanied by targeted measures for such households.

Electrification presents an employment opportunity, but care needs to be taken to bridge emerging skills gaps. Today, the electricity sector is the largest energy employer, with annual employment growth since 2019 well above average for the energy sector and the economy as a whole. Skilled trades such as electricians, welders and grid line workers are critical in the electricity sector, and some labour markets have started to see shortages of skilled workers. Looking ahead, accelerating electrification in line with the High Electrification Scenario would create a major opportunity to expand and upskill the workforce in occupations linked to electrification, potentially doubling current employment in these roles.

## Key actions :

- 1. Develop cross-cutting electrification strategies and policy frameworks . Electrification has broad energy system impacts and depends on infrastructure readiness, appropriate energy  pricing  and  taxation,  and  financial  incentives.  Cross-cutting  strategies  can integrate  these  elements  while  considering  co-benefits  and  trade-offs.  High-level electrification targets can help guide different actors.
- 2. Identify priorities for cost-effective electrification in line with national circumstances and policy goals. All countries will have different priorities depending on their energy system structure and broader energy policy goals. Priority setting can identify which electrification segments to target.
- 3. Pursue  full  access  to  electricity  and  clean  cooking. For  countries  lacking  access  to electricity, the top priority is increasing access. Improving access to clean cooking also contributes to electrification by increasing the overall energy efficiency.
- 4. Support  consumers  where  needed. Electrification  can  lower  energy  bills,  but  some households and businesses may need appropriate policy frameworks to support upfront investments in electrification.
- 5. Identify and address energy price distortions . Reducing price gaps between electricity and its alternatives can boost the attractiveness of electrification. Fossil fuel subsidies or high electricity taxes can be targets for reform, although care needs to be taken with the distributional and fiscal implications.
- 6. Build out diversified supply chains . Electrification entails increasing reliance on critical minerals  and  electric  technologies;  in  some  cases,  their  supply  chains  are  highly concentrated. Secure and diversified supply chains support greater electrification.
- 7. Enhance electricity system readiness .  Accelerated electrification can add to pressure on grids that often already face congestion and long permitting timelines. Scaling up investment in generation and grids, and in smarter and more flexible electricity systems, is critical to ensuring electrification is affordable and secure.
- 8. Invest  in  skills  and  labour .  Electrification  raises  the  demand  for  skilled  workers  and specialised  university  graduates  like  electrical  engineers.  Investments  in  skills  and training can ensure the supply of workers keeps pace with this opportunity.
- 9. Seize  energy  security  benefits  but  watch  for  emerging  electricity  security  threats . Electrification can help diversify energy mixes and reduce import bills; at the same time, emerging  threats  to  electricity  security,  including  cyber  risks,  natural  disasters  and climate hazards, need to be considered.
- 10. Co-operate  internationally .  Electrification  supports  global  goals  like  the  doubling  of energy efficiency and tripling of renewables capacity, and it is a key pillar of pathways to reach the temperature goals of the Paris Agreement.

<!-- image -->

## The Age of Electricity

Growing role of electricity in economies and energy systems

## S U M M A R Y

- · The  rapid  growth  and  increasing  economic  importance  of  electricity  have  major implications for economic competitiveness, energy security, and climate mitigation. Its central and growing role in energy systems and economies means we have entered the Age of Electricity.
- · Electricity demand increased by more than 3% per year from 2015 to 2025 - nearly twice as fast as overall energy demand growth. This results from increasing demand for cooling, appliances, manufactured goods, digital services and artificial intelligence. It also reflects rapid growth in the electrification of transport, with electric vehicles (EVs) accounting for nearly 25% of new car sales in 2025, up from less than 1% in 2015. The effects of conflict in the Middle East may further boost demand.
- · Investments  in  generation,  grids  and  end-use  electrification  are  set  to  reach USD 2 trillion in 2026, accounting for around 60% of all energy investment. The global revenues  of  companies  involved  in  supporting  the  growth  of  electrification  have increased very rapidly, at 15% per year since 2020.
- · Globally, electricity today accounts for only 23% of total final energy consumption. However,  electric  end-use  technologies  are  typically  much  more  efficient  than combustion-based ones, which generate large amounts of waste heat. This means that electricity's share in meeting the energy services delivered to consumers is nearly 40%  -  much  higher  than  its  share  in  total  final  energy  consumption.  Moreover, electricity disproportionately powers high value-added sectors: as a result, it is the main source of energy for activities that generate more than 45% of the world's gross domestic product.
- · The share of electricity in energy consumption varies widely across regions, shaped by a mix of structural and policy-related factors. It is highest in East Asia and lowest in Africa, where many people still lack access to modern sources of energy and where the electricity demand of households and businesses that have access remains low.
- · End-use sectors account for 55% of global energy-related carbon dioxide emissions. The efficiency of electricity and its ability, especially when accompanied by growing deployment  of  low-emissions  technologies  to  generate  power,  to  expand  clean energy use in end-use sectors mean that it has a key part to play in displacing emitting fuels and reducing emissions. It is also critical to achieving the international goals of tripling renewables capacity and doubling the rate of efficiency improvements.
- · Policies  supporting  electrification  remain  focused  on  sector-specific  goals,  such  as increasing  the  uptake  of  EVs.  There  are  currently  few  comprehensive  national strategies that address the wider energy system implications of electrification.

## 1.1 Introduction

As an energy carrier, electricity has many benefits. It is versatile, can be precisely controlled, and is clean at the point of use. Its versatility means it can be converted into many energy services:  mechanical  energy  in  motors  for  transport  and  industry;  cooling,  heating  and lighting  in  homes and offices; chemical energy in industries like aluminium smelting; and information processing in smartphones and data centres. Electricity is so controllable that it powers devices  from  individual  transistors  measuring  only  tens  of  atoms  across  to  highspeed  rail  power  cars,  with  power  delivery  ranging  from  one-millionth  of  a  watt  for  a transistor to millions of watts for a high-speed train. Electricity can be converted to energy services much more efficiently than other fuels and produces no direct emissions when used: its system-wide emissions depend on the generation mix.

Electricity has been critical to economic growth over the past century. As a general-purpose technology,  it  has  brought  economy-wide  benefits.  The  electrification  of  manufacturing drove large productivity gains; electricity use in households dramatically improved welfare and freed up labour (especially among women) to participate in the wider economy; and electricity  powered  the  information  technology  revolution.  With  the  rise  of  artificial intelligence (AI) and advanced manufacturing, electricity is set to remain key to economic growth in this century, too.

However, the world is  not  making  the  most  of  electricity.  More  than  700 million  people globally  still  lack  access  to  electricity,  constraining  their  ability  to  meet  basic  needs  and limiting their opportunities for social and economic development. Even in countries with full access, electricity still accounts for a relatively modest share of total energy usage.

Momentum to expand the role of electricity across the energy system is gathering pace, supported  by  structural,  technological  and  policy-related  factors.  Sectors  powered  by electricity are becoming increasingly important in modern economies - the rise of AI and data centres, air conditioning, and electrified advanced manufacturing are examples of this trend. Improvements in cost and performance continue: for example, the cost of lithium-ion battery  packs  has  decreased  by  over  90%  since  2010,  transforming  the  economics  of transport  electrification.  The  global  revenues  of  companies  operating  in  the  broader electrification value chain have grown by a remarkable 15% per year since 2020, highlighting the  growing  economic  importance  of  electric  technologies  and  the  infrastructure  that supports them. The energy shock arising from the current conflict in the Middle East is likely to provide an additional boost to electrification, as the 2022 energy crisis did.

As energy-related carbon dioxide (CO2) emissions continue to rise, electrification is also a key pillar of energy transition strategies addressing end-use sectors, which account for over half of global energy sector emissions: it is more efficient than fuel combustion technologies, and it can make use of low-emissions technologies like solar photovoltaics (PV) and wind power to help countries meet their emissions reduction targets.

Electrification does, however, raise new energy security challenges, including those related to supply chain concentration, and its application to new end-uses may raise affordability challenges if not well managed. Its continuing growth requires the development of enabling grid infrastructure, while its contribution to reducing emissions depends in large part on the deployment  of  low-emissions  generation  technologies.  Although  many  countries  have sector-specific policies in place to support electrification, for example focusing on electric vehicle (EV) adoption, few countries have comprehensive national strategies that consider all aspects of electrification across the energy system.

This  is  a  special  IEA  report  prepared  at  the  request  of  the  governments  of  Türkiye  and Australia in their respective roles as President and President of Negotiations of the United Nations Framework Convention on Climate Change Conference of the Parties (COP) 31. It takes stock of this dynamic landscape, showing how electricity is used today, and what the opportunities are for accelerating the electrification of energy systems. It also discusses how the challenges and benefits of electrification play out across different economies.

-  Chapter 1 looks at how electricity's role in economies and energy systems has grown, and how it varies by sector and by region. It examines the rapid adoption of related technologies, and how the energy crisis resulting from the conflict in the Middle East may impact this. It also considers the current policy landscape for electrification, and the importance of electrification for global climate goals. This chapter also sets out the definitions for the scenarios used in this report.
-  Chapter 2 looks  at  the  outlook  for  increased  electrification  across  different  energy end-use sectors, exploring the implications  of  the  High  Electrification  Scenario  (HES) developed  for  this  report.  It  considers  the  electricity  technologies  and  strategies relevant to electrification of the transport, buildings and industry sectors, and examines the specific drivers of electrification in emerging market and developing economies.
-  Chapter 3 considers  the  implications  for  power  generation  of  the  rapid  growth  in demand arising from electrification. It analyses how the increased demand for electricity in the HES can be met through different electricity supply cases with differing mixes of power generation technologies. It also examines the implications of electricity demand growth for the development and expansion of power grids.
-  Chapter 4 looks at the wider implications and trade-offs involved in the rapid growth of electrification, addressing in turn electricity security and resilience; industrial ecosystems and supply chains; affordability, investment and employment; emissions; and inclusive electrification.

1

## Box 1.1 ⊳ Country groupings used in this report

Countries around the world have different development levels, economic structures and energy systems. In general, however, countries with similar development levels share characteristics relevant to electrification (Figure 1.1). Advanced economies tend to have high rates of private car ownership; the transport sector therefore represents a larger electrification  opportunity  than  in  other  countries.  Emerging  market  and  developing economies  often  combine  significant  cooling  needs  with  low  air  conditioner  (AC) ownership, and many households in these countries are set to buy their first AC in the next  decade.  In  developing  countries  without  full  access  to  electricity,  electrification implies  bringing  electricity  access  to  all  households,  and  electrifying  industries  like agricultural processing could yield large development benefits.

This report uses the following three country groupings as an analytical framework, while acknowledging  that  within  these  groups  there  is  substantial  diversity,  and  that  each country will have its own individual priorities, preferences and pathways.

-  Advanced economies and China: we group the People's Republic of China (hereinafter China)  with  advanced  economies,  as  its  economy  stands  out  as  already  highly electrified today, with cutting-edge technological capacities.
-  Other emerging market and developing economies with full access: includes other emerging market and developing economies (excluding China) with electricity access rates of over 90%.
-  Other  emerging  market  and  developing  economies  with  access  gaps: includes developing countries in Africa and Asia where electricity access rates are less than 90%.

Figure 1.1 ⊳ Key indicators across country groupings in this report, 2025

<!-- image -->

Note:  EMDE  =  emerging  market  and  developing  economies;  GDP  =  gross  domestic  product;  PPP  = purchasing power parity; TFEC = total final energy consumption; avg. = average; temp. = temperature.

## 1.2 Electricity's growing role in economies and energy systems

## 1.2.1 Electricity in the global energy system

Global  demand  for  electricity  grew  to  over  28 500 terawatt-hours  (TWh)  in  2025.  It  has increased at an average annual rate of more than 3% over the last ten years - nearly twice as fast as growth in overall energy demand - and has been accelerating in recent years. The total increase in demand over the last decade of around 7 500 TWh is nearly equivalent to the current combined electricity demand of North America and the European Union. For these reasons, the IEA has said that the world has entered the Age of Electricity.

Figure 1.2 ⊳ Electricity demand by sector and by region, 2015-2025

<!-- image -->

IEA. CC BY 4.0.

Electricity demand increased at an average annual rate of more than 3% from 2015 to 2025 driven by strong growth in buildings and non-energy-intensive industry, and led by China

Note: TWh = terawatt-hour; C &amp; S America = Central and South America; Other includes other energy sector; Other Buildings includes data centres, lighting, and desalination.

1

Most electricity is consumed in the buildings and industry sectors, which together account for 90% of all electricity demand (Figure 1.2). Buildings accounted for over 45% of growth in electricity demand over the last decade, led by electric appliances and cooling, while industry was responsible for 40% of growth, led by non-energy-intensive sectors.

The geography of electricity demand is evolving. China alone accounted for over 60% of global increase in the demand for electricity from 2015 to 2025, driven by strong growth in the  buildings  sector  and  in  industry  sub-sectors  such  as  advanced  manufacturing.  Other emerging market and developing economies also saw increased electricity demand, with annual  growth  over  the  period  averaging  around  5%  in  both  India  and  Southeast  Asia. Electricity  demand was largely unchanged in Europe, and in Japan and Korea. It grew by around 1% annually in North America, where the rapid expansion of data centre capacity has accelerated demand growth in recent years.

In this report, the rate of electrification is calculated as the percentage share of electricity in total  final  energy  consumption.  Even  with  the  rapid  global  growth  in  electricity  demand, electricity  currently  accounts  for  just  23%  of  the  world's  final  energy  consumption.  For comparison, the combined share of coal, oil and natural gas in total final energy consumption stands at just over 60% today (down from over 65% in 2010).

Figure 1.3 ⊳ Global consumption of final and useful energy by product and share of electricity in final energy, useful energy and GDP, 2025

<!-- image -->

IEA. CC BY 4.0.

Because of electricity's efficiency and productivity benefits, its role in powering useful energy and GDP is larger than its share of final energy consumption

Notes: EJ  =  exajoule.  Useful  energy  can  be  higher  than  final  energy  for  electricity  as  heat  pumps  and  air conditioners transfer energy to and from the environment, resulting in efficiencies above 100% for those technologies.

However, electrical end-use technologies are typically much more efficient in converting final energy  into  energy  services  than  their  combustion-based  alternatives,  which  involve

substantial losses of waste heat (Figure 1.3). This means that the contribution of electricity to meeting underlying energy needs is higher: electricity meets almost 40% of demand for useful energy (see Box 1.2 for a definition of useful energy).

Electricity accounts for a still higher share of economic activity because of its central role in high-value  economic  sectors  such  as  advanced  manufacturing,  digital  services  and  AI.  In 2015, electricity was the key source of energy for sectors accounting for around 40% of the global economy. By 2025, that number had risen to over 45% - around twice electricity's share in total final energy consumption (Figure 1.3). Electricity's efficiency benefits and its role  in  powering  high  value-added  sectors  underline  how  important  it  is  for  economic competitiveness.

## Box 1.2 ⊳ Clarifying the energy definitions used in this report

Total energy supply (TES) refers to the primary supply of energy resources to the energy system, prior to any transformation processes. The energy system takes primary energy sources such as coal, oil or solar irradiation, transforms them into energy products such as electricity, coking coal or gasoline, and distributes these products to users for final consumption in the  industry,  transport,  buildings  and  agriculture  sectors  (Figure 1.4). Today, fossil fuels make up nearly 80% of TES. 1

Around 40% of TES serves as an input to electricity generation: this includes coal and natural  gas,  renewable  resources  such  as  hydropower,  wind  and  solar,  and  nuclear energy. The production of electricity through the combustion of fuels - primarily fossil fuels - involves substantial energy losses in the form of waste heat (typically in the order of 50-65%). However, in energy accounting, primary non-combustion energy resources such as wind and solar PV are transformed into electricity without any conversion losses. This means, for example, that solar PV in primary energy supply is equal to the electrical output of solar PV plants.

Total  final  energy  consumption involves  the  use  of  energy  products  by  end-users  to produce energy services, and excludes non-energy uses. Final energy consumption with combustion technologies also entails substantial energy losses as waste heat. Equipment and  devices  powered  by  electricity  involve  much  lower  levels  of  loss.  An  internal combustion engine (ICE) vehicle, for example, converts only around 25-35% of the energy contained in gasoline into motion, while electric cars convert around 85-90% of electrical energy into motion.

Useful energy refers to the energy available for end-users to satisfy their need for energy services  such  as  heating,  cooling,  lighting  and  mobility.  Ultimately,  it  is  these  energy services that improve consumer welfare.

1 Total energy supply is equal to total energy demand.

1

Figure 1.4 ⊳ Global energy flows from primary to useful energy by energy carrier and sector, 2025

<!-- image -->

Notes: Elec. generation = electricity generation. Other transformation includes heat production and other energy sector. Other fuels include district heat, hydrogen and others. Other end-uses include non-energy use and agriculture. Traditional use of biomass is not included, and losses are shown on a net basis.

## 1.2.2 Differences in electrification by sector and by region

Electricity accounted for 23% of total final energy consumption in 2025, but electrification rates varied widely across sectors and countries (Figure 1.5).

Globally, in the buildings sector, the rate of electrification is high and has risen fast, increasing from around 25% in 2000 to nearly 40% in 2025. This is primarily due to rapid growth in the number of air conditioners and other appliances powered almost exclusively by electricity. In parallel, other end-uses, such as cooking and space and water heating, have also seen a gradual shift towards equipment powered by electricity.

In  the  industry  sector,  electrification  rates  have  risen  rapidly  since  2010,  driven  by  the electrification  of  non-energy-intensive  sectors,  alongside  the  faster  growth  of  already electrified sectors, such as advanced manufacturing.

In the transport sector, electricity has historically played a limited role outside the rail sector. However, the fast-growing adoption of electric road vehicles has led the share of electricity

in transport energy consumption to rise from 1% in 2015 to nearly 2% in 2025, and its share of useful energy to rise to 4%, reflecting its efficiency benefits. The low level of electrification in transport reflects the fact that, despite rapid growth in sales, EVs still account for a small share of the large stock of vehicles on the road. It also reflects the difficulty of electrifying long-distance aviation and shipping.

Figure 1.5 ⊳ Electricity consumption as a share of total final energy consumption, by sector and by region, 2000-2025

<!-- image -->

IEA. CC BY 4.0.

Electricity's share of total final energy consumption rose from 17% in 2000 to 23% in 2025; the rate of electrification varies widely by sector and by region

There  are  significant  geographical  differences  in  how  electrification  rates  have  evolved. These are determined by factors related to economic structure, energy system structure, climate  and  policy.  For  example,  regions  with  high  cooling  needs  may  have  higher electrification  rates  than  would  otherwise  be  the  case,  because  cooling  is  almost  always delivered by electric technologies. Regions with very limited access to electricity use little electricity;  they  also  often  meet  substantial  shares  of  their  energy  needs  with  highly inefficient  traditional  use  of  biomass,  which  inflates  final  energy  consumption  and  thus lowers the electrification rate. Care should therefore be taken in interpreting differences in electrification  rates  between  regions,  which  can  be  driven  by  multiple  factors,  not  all  of which are linked to policy. A country's economy-wide electrification rate reflects both the degree  of  electrification  within  individual  sectors  and  the  relative  contribution  of  those sectors to total final energy consumption (Figure 1.6).

Major economies in East and Southeast Asia have high rates of electrification. In Japan and Korea, electricity accounts for around one third of final energy consumption. Both countries are heavily reliant on fossil fuel imports and hence have relatively high fuel prices in sectors relevant to electrification; both also have large export-oriented manufacturing sectors which

1

are highly electrified, and climates that lead to significant cooling as well as heating demand, stimulating  the  adoption  of  air-to-air  heat  pumps,  which  can  provide  both  heating  and cooling. Since 2000, the electrification rate in China and Southeast Asia has also increased rapidly,  supported  by  the  expansion  of  advanced  manufacturing  and  reduced  use  of traditional forms of biomass.

Several fossil fuel producing and exporting regions - including North America and the Middle East - have lower average electrification rates and have seen slower increases in those rates in recent decades. Low consumer prices for oil products and natural gas have in many cases led to relatively slow adoption of electrified end-use technologies. The average electrification rate in Europe of around 24% is also lower than in East Asia, despite Europe's high reliance on energy imports and resulting high fuel prices. The reasons for this include a high level of heating demand which has largely been met through the use of natural gas, with domestic natural production and then dependence on gas imports from Russia helping to lock in high shares of gas-fired heating equipment. European industry also has a relatively small share of highly electrified sub-sectors, and equivalent industries in Europe are less electrified than their counterparts in Japan and Korea: in the machinery sector, for example, the difference is around 16 percentage points.

Figure 1.6 ⊳ Share of total final energy consumption and electrification rate, by sector and by region, 2025

<!-- image -->

IEA. CC BY 4.0.

Overall electrification rates reflect both the degree of electrification within individual sectors and the relative contribution of those sectors to total final energy consumption

Note: Other includes agriculture and forestry.

In Africa, the rate of electrification remains persistently low: it rose by only 2 percentage points since 2000 to just over 12% in 2025, half the global average. This reflects limited access to electricity in the  region  (see  Chapter 4).  Rapid  population  growth  has  outpaced

improvements in access, and in 2025 more than 600 million people across the continent still lacked access to electricity. Heavy reliance on inefficient forms of biomass also serves to push down Africa's rate of electrification.

## 1.2.3 Deployment of electrification technologies

The last decade has seen an acceleration in the global deployment of many technologies related  to  electrification  (Figure 1.7).  This  includes  those  used  where  demand  is  growing rapidly (like air conditioners and data centres), and those that facilitate the electrification of multi-fuel  end-use  sectors  (like  electric  vehicles  and  heat  pumps).  This  trend  has  been reinforced by rising levels of investment in key supporting technologies, notably grids and storage.  Innovation  and  manufacturing  advances  have  led  to  sharp  price  declines  and improved performance for critical technologies such as batteries, boosting market uptake. This  increase  in  deployment  has  been  underpinned  in  many  regions  by  policy  support, motivated by concerns about energy security, climate change and industrial strategy.

Figure 1.7 ⊳ Trends in deployment of selected electrification technologies, 2019-2025

<!-- image -->

Deployment of many key electrification-related technologies has accelerated, led by enduses such as road transport and supported by increased investment in grids and storage

Note: Data for electric (elec.) 2/3-wheelers, cars and trucks show number of units sold; for residential air conditioner (AC) units, number of units shipped; for heat pumps, shipments in MW capacity; for data centres, annual  change  in  server  capacity  in  MW;  for  desalination,  annual  addition  of  seawater  reverse  osmosis capacity in million m  per day; for electric motors, sales in non-energy-intensive industries, three-year rolling 3 average in MW; for power grids, investment in USD (2025, MER); for battery storage, annual capacity additions in MW.

In the transport sector, the change has been most evident for road transport, with very rapid growth in sales of EVs. Global electric car sales increased 40-fold over the decade from 2015

1

to reach more than 20 million in 2025, and EVs now account for around one in four of all new cars sold. Over 10 million electric two- and three-wheelers - around 15% of the global total -  are  also  now  sold  every  year,  nearly  all  in  developing  Asia.  Despite  technical  and  cost challenges, sales of electric freight trucks are meanwhile growing rapidly in several markets. EVs now help to avoid 2.3 million barrels per day of oil demand - more than the amount of oil that bypassed the Strait of Hormuz via the Habshan-Fujairah pipeline in mid-2026.

In the buildings sector, the market for air conditioners has expanded rapidly in recent years, with shipments reaching nearly 200 million units in both 2024 and 2025, fuelled by strong growth in emerging market and developing economies. Global sales of heat pumps have also grown briskly, increasing at an average annual rate of over 4% since 2019. Newer sources of electricity consumption are also having a significant impact on demand. For example, data centre server capacity increased at an average annual rate of around 17% from 2015 to 2025, notably in advanced economies and China. In regions reliant on desalination to meet water needs, new capacity additions for highly efficient electrified reverse osmosis technologies have also added to demand. At the same time, investment in electrification in industry (for uses such as low-temperature heat) is rising, while some sub-sectors that are already highly electrified are growing rapidly.

This  faster  pace  of  change  in  many  end-use  sectors  is  being  accompanied  by  rising investment  in the electricity sector. Investment  in power  grids rose from  around USD 315 billion in 2015 to USD 450 billion in 2025, driven by expanding system needs and the rising cost of equipment such as transformers and cables. Stationary battery storage is growing particularly fast: annual capacity additions in 2025 were nearly 100 times higher than  in  2015,  with  almost  120 gigawatts  (GW)  added  in  one  year.  Total  investment  in electricity supply and grids is set to reach USD 1.6 trillion in 2026. When the investment costs associated with end-use electrification are included, this rises to USD 2 trillion, representing around 60% of total global energy investment (IEA, 2026a).

## 1.3 Expanding and evolving electricity supply

Over the past decade, solar PV and wind have been the largest sources of growth in global electricity  generation,  together  meeting  over  half  of  new  electricity  demand.  The  next biggest contributors were natural gas and coal, with hydropower, bioenergy and nuclear power making smaller contributions (Figure 1.8). Global solar PV generation increased more than 11-fold over the last decade, while wind power more than tripled; and from 2024 to 2025, renewables accounted for more than 95% of total electricity generation growth (IEA, 2026b). This marks a change from the previous decade, when growth in electricity supply was dominated by coal and natural gas, followed by hydro and wind, with solar PV playing only a limited role. Other low-emissions fuels have also advanced: bioenergy has seen steady growth in the last two decades, while nuclear power has reversed its previous decline and achieved modest growth over the past ten years. The share of oil in electricity generation has  meanwhile  continued  to  shrink.  Fossil  fuels  remain  important  in  meeting  electricity demand, but the majority of growth now comes from renewable energy sources.

Figure 1.8 ⊳ Change in global electricity generation by source, 2005-2025

<!-- image -->

Solar PV and wind met over half of new electricity demand over the past decade, in contrast to the decade before, when coal and gas grew strongest

Note: TWh = terawatt-hours; PV = photovoltaics.

This change reflects the maturation and rapid scaling up of clean power technologies. Solar PV deployment approached 600 GW in 2025 alone, more than ten times the annual level a decade earlier, while wind power additions neared 140 GW, more than double the level ten years before. Manufacturing capacity for both technologies has expanded even faster than deployment in recent years, helping reduce costs and ease supply constraints, though also creating pressure on manufacturers in some markets (see Chapter 4, Section 4.3). The rapid expansion in both utility-scale and behind-the-meter battery storage is facilitating this shift by improving the ability of power systems to integrate higher shares of variable renewables.

Despite the strong growth of low-emissions sources of electricity, the power sector remains central to the overall outlook for fossil fuel use. Although less than 5% of oil is used in power generation, around two-thirds of all coal consumed in the energy sector is used to generate electricity, as is around 40% of natural gas. Most regions have shifted away from using oil for power generation since the oil crises in the 1970s, but coal has long been the largest source of electricity globally and remains so today, despite a declining share over the past decade. The contribution of natural gas to the generation mix remains significant, having recently flattened out after decades of growth.

The evolution of electricity supply has a direct bearing on total coal and gas demand, and a more limited but still relevant role for oil in some regions. Faster growth in low-emissions electricity  would  reduce  fossil  fuel  use  in  the  power  sector  and  increase  the  emissions reductions associated with electrification. However, the pace of this shift depends on how quickly low-emissions sources of power and grids can be scaled up to meet rising electricity demand securely and affordably. Recent years have seen a jump in leading indicators for the

1

deployment of gas-fired power in some regions, with global orders for gas turbines growing by 70% in 2025, driven by increases in the United States to power data centres and in Europe (IEA, 2026a).

## 1.4 Impact of the current energy crisis

The conflict in the Middle East and disruptions to shipping through the Strait of Hormuz have had a damaging effect on global energy supplies. Governments and consumers, especially in fuel-importing  countries,  have  faced  supply  scarcity  concerns  and  higher  energy  prices, notably for refined petroleum products and for shipments of liquefied natural gas (LNG).

Table 1.1 ⊳ Selected electrification policies announced since March 2026

| Country           | Policy response example                                                          |
|-------------------|----------------------------------------------------------------------------------|
| Europe            |                                                                                  |
| France            | Introduction of national electrification plan                                    |
| Ireland           | Additional EV subsidy for those scrapping older vehicles                         |
| Netherlands       | Support for replacement of gas boilers with heat pumps                           |
| Spain             | Reintroduction of tax deduction for EVs and installation of home charging points |
| Sweden            | Support for electrification of public vehicle fleets                             |
| United Kingdom    | Promotion of EV adoption and acceleration of rollout of plug-in solar PV         |
| Asia Pacific      |                                                                                  |
| Australia         | Step-up in public EV charging expansion                                          |
| India             | Promotion of shift to electric cookstoves                                        |
| Indonesia         | Acceleration of conversion of gasoline-powered motorcycles to electricity        |
| Myanmar           | Introduction of an ICE-vehicle-to-EV trade-in scheme                             |
| Viet Nam          | Reduction of special consumption tax on EVs                                      |
| Rest of the world |                                                                                  |
| Canada            | Launch of national electricity strategy                                          |
| Chile             | Provision of preferential credit for taxis and buses to shift to electric models |
| Kenya             | Implementation of EV import duty waiver                                          |

Since March, around 25 countries have introduced structural policies to boost electrification, including measures to support EV purchases and heat pump installation

Notes:  EV  =  electric  vehicle;  PV  =  photovoltaics;  ICE  =  internal  combustion  engine.  Table  shows  selected examples only. Some initiatives, such as national energy strategies in Canada and France, were in development before March 2026.

Source: IEA 2026 Energy Crisis Policy Response Tracker.

There  are  some  signs  the  crisis  may  be  adding  to  the  existing  momentum  behind electrification. Many of the new policies introduced by governments in response to these events  focus  on  measures  to  ease  immediate  pressures  on  consumers.  But  longer-term

structural  measures  have  also  been  introduced,  including  policy  responses  supportive  of accelerated electrification in around 25 countries, according to the IEA's 2026 Energy Crisis Policy  Response  Tracker . For  example,  several  countries  have  introduced  or  increased incentives for electric vehicle purchases, the scrapping of ICE vehicles, the electrification of public  vehicle  fleets  and  the  development  of  EV  charging  infrastructure.  Other  measures support the introduction of heat pumps and electric cookstoves. Such policy measures are most  widespread  in  regions  with  a  high  degree  of  dependence  on  fuel  imports,  such  as Europe and Southeast Asia (Table 1.1). In addition, national electrification strategies - which were already under consideration before the crisis, but have now been framed in part as crisis responses - have been launched in 2026 in Canada and in France, while the European Commission published an Electrification Action Plan in July 2026 (see Section 1.5.1).

Figure 1.9 ⊳ Year-on-year change in selected energy technology deployment, March-June 2026 versus March-June 2025

<!-- image -->

IEA. CC BY 4.0.

Initial data signals faster technology deployment in many regions, including accelerating sales of electric cars and installation of behind-the-meter battery storage

Note: BTM = behind-the-meter; Oth. Asia Pacific = Other Asia Pacific.

Source: IEA analysis based on data from EV Volumes, ACEA, CPCA and Benchmark Minerals.

The  2026  crisis  may  also  have  contributed  to  further  acceleration  in  the  rollout  of electrification-related technologies such as electric vehicles, heat pumps and battery storage systems as consumers and markets react to higher fuel prices and the reality of shortages in fuel supply in some regions. In much of the world, including many countries with greater exposure to the crisis such as in Africa, Asia, Europe and Latin America, initial data offer evidence that the deployment of electrification-related technologies is speeding up further

1

(Figure 1.9).  By  contrast,  while  China  remains  the  largest  market  for  such  technologies, deployment there has slowed in part due to recent policy shifts, including a scaling back of tax exemptions for EVs. Deployment of some technologies, including EVs, has also declined in the United States because of policy changes.

The acceleration is clearest for technologies with shorter lead-times, especially smaller-scale consumer  equipment  including  individual  passenger  vehicles,  rooftop  solar  power  and behind-the-meter battery storage. Any speeding up of the development of larger industrialand utility-scale facilities such as wind farms and grid-scale battery storage is likely to take longer to appear in deployment data, though it could show up sooner in project development pipelines.

-  Electric  cars: sales  of  electric  cars  outside  China  rose  by  more  than  35%  in  the  four months from March to June 2026 compared with the same period in 2025, with notable growth in much of Asia, Europe and Latin America. Countries seeing rapid growth over this period include Viet Nam (up nearly 90% year-on-year), India (over 115%), Australia (over 120%) and Brazil (over 155%). Sales have been boosted by several factors including high fuel prices, supportive policies and the growing availability of low-cost models. In China, electric car sales declined by more than 15% in the same period, though this was in the context of an overall auto market downturn, which led to a reduction in total car sales of around 25% year-on-year from March to June 2026.
-  Battery storage: stationary battery storage has continued to grow rapidly in 2026. Early signs point to an increase since March in the uptake of smaller-scale behind-the-meter projects, with installations rising by nearly 30%, driven in part by heightened concerns about high electricity prices. Central and South America and much of the Asia Pacific region  have  seen  notably  strong  growth,  with  policy  measures  supporting  rapid adoption  in  Australia,  for  example.  Utility-scale  projects  have  also  seen  continued growth, but the new capacity coming onstream this year is from projects that pre-date the crisis.
-  Heat pumps: initial data, while incomplete, point to an uptick in heat pump sales in some regions. Europe saw an increase in sales in 2025 and Q1 2026; preliminary data from several countries indicate this trend continued into Q2 2026. In Japan, Q2 sales were up by  16%,  mainly  driven  by  reversible  air-to-air  heat  pumps;  this  continues  a  wellestablished trend, which has perhaps been supported by warmer-than-usual temperatures, as these types of heat pumps are also used for cooling. In the United States, Q2 sales were up by around 6%; in China, they were down by 8%.

Many countries, notably in Africa and Asia, have seen sharp rises in imports of electrification technologies  from  China  in  2026,  offering  a  further  indicator  of  increased  demand (Figure 1.10). China is the world's leading manufacturer of many technologies, and current weaknesses  in  its  domestic  market  are  also  likely  to  have  spurred  companies  there  to increase exports.

Figure 1.10 ⊳ Year-on-year change in selected energy technology imports, March-June 2026 versus March-June 2025

<!-- image -->

IEA. CC BY 4.0.

Many regions have seen notable rises in imports of electrification technologies, providing a further signal of increased demand for electrification

Notes: Batteries covers lithium-ion batteries (HS code 850760); solar PV equipment covers modules and cells (HS codes 854143 and 854142). Data are based on values of imports from China in USD.

Source: IEA Analysis based on data from Global Trade Tracker.

The latest data highlight a rise in imports of lithium-ion batteries from China (used both for EVs and for stationary storage). In the four-month period from March to June 2026, total imports (by value) were over 30% higher than during the same period in 2025, though part of this growth, particularly the sharp rise in exports from China in March, reflected frontloading ahead of the reduction in export tax rebates for batteries from 1 April. Markedly rapid increases over the four-month period were seen in imports by some African and Asian countries. Exports of electric cars from China also rose by nearly 130% over the same period (CAAM, 2026).

Imports of solar PV equipment (including modules and cells) also rose in the four months from March to June 2026, compared with the same period in 2025, with imports to Southeast Asia growing by around 90% and imports to Africa growing by almost 100%. Chinese export data reveal an even sharper increase in the same period. As with batteries, the rise in exports from China in March was linked to changes in export tax rebates, which have been cancelled for solar PV products from 1 April. Imports into India declined, due to the rise in domestic manufacturing there, and imports to the Middle East also fell, reflecting the impact of conflict in the region.

<!-- image -->

1

## 1.5 The policy landscape for electrification

## 1.5.1 Policies

The  electricity  sector  is  central  to  energy  planning  in  most  countries,  but  the  focus  has typically been on the outlook for electricity supply rather than on demand. Although many regions  and  countries  have  incentive  and  public  investment  programmes  to  support  the electrification of specific end-uses, overarching cross-sectoral electrification strategies are a rarity. Further strengthening of policies has a key role to play in supporting electrification: the  interaction  between  supply,  demand  and  infrastructure  means  that  sector-specific electrification policies need to be combined with cross-sectoral strategies that co-ordinate infrastructure planning,  implementation  timelines  and  cost  recovery,  while  ensuring consistent price signals and incentives across sectors and energy carriers.

From national energy and climate plans in Europe to China's five-year energy plans, energy strategies  usually  prioritise  power  capacity  planning,  with  clear  directions  and  short-  to medium-term targets for specific generation technologies. Nearly all G20 members, which together  account  for  around  80%  of  global  total  final  energy  consumption,  have  such framework strategies in place (Figure 1.11).

Figure 1.11 ⊳ G20 energy consumption covered by electricity generation strategies and end-use electrification strategies

<!-- image -->

Share of total final energy consumption covered by a strategy

IEA. CC BY 4.0.

Most electricity policy frameworks in major economies prioritise electricity supply planning; few also cover strategies for end-use sectors

Note: Countries have been weighted by their share in G20 energy consumption.

Although many countries produce projections of future electricity demand to inform the expansion  of  power  capacity,  these  projections  generally  take  the  form  of  indicative scenarios. This contrasts with the more clearly defined objectives that are often established

for  power  generation  expansion.  But  while  broader  electrification  plans  are  limited  in number, they are starting to appear. France's 2026 electrification plan, which builds on its 2026-2035 multiannual energy plan, aims to increase electrification from 27% of total final consumption in 2023 to 38% by 2035, supported by 22 targeted measures; Canada's National Strategy for an Electrified Economy, published in May 2026, seeks to accelerate economywide electrification; and the European Commission's Electrification Action Plan, published in July 2026, focuses on reducing electricity prices and proposes an indicative electrification target of 46% by 2040. The lack of broad national plans for electrification may increase the risk of a mismatch between electricity supply and its consumption in end-use sectors, with consequences that could include overcapacity, price volatility, negative prices, and lower levels of grid and power generation investment.

Table 1.2 ⊳ Electricity incentives and regulatory policy landscape

|                                                                                          | North America                                                                            | C &S America                                                                             | Europe                                                                                   | Africa                                                                                   | Middle East                                                                              | Eurasia                                                                                  | Asia Pacific (AE)                                                                        | Asia Pacific (EMDE)                                                                      | World                                                                                    |
|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------|
| Incentives and investments                                                               | Incentives and investments                                                               | Incentives and investments                                                               | Incentives and investments                                                               | Incentives and investments                                                               | Incentives and investments                                                               | Incentives and investments                                                               | Incentives and investments                                                               | Incentives and investments                                                               | Incentives and investments                                                               |
| Buildings                                                                                | ◔                                                                                        | ◑                                                                                        | ◕                                                                                        | ○                                                                                        | ◔                                                                                        | ◔                                                                                        | ◕                                                                                        | ◕                                                                                        | ◑                                                                                        |
| Industry                                                                                 | ○                                                                                        | ○                                                                                        | ◔                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ◑                                                                                        | ○                                                                                        | ○                                                                                        |
| Transport                                                                                | ◔                                                                                        | ◕                                                                                        | ◕                                                                                        | ◕                                                                                        | ◑                                                                                        | ◕                                                                                        | ●                                                                                        | ◕                                                                                        | ◑                                                                                        |
| Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           | Performance-based and prescriptive regulations                                           |
| Buildings                                                                                | ◔                                                                                        | ○                                                                                        | ◕                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ◑                                                                                        | ◔                                                                                        |
| Industry                                                                                 | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        |
| Transport                                                                                | ○                                                                                        | ○                                                                                        | ◕                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ○                                                                                        | ◔                                                                                        |
| Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% | Share of energy demand with policy implemented: ○ <10% ◔ 10-39% ◑ 40-69% ◕ 70-99% ● 100% |

Sector-specific policies, regulations and mandates seek to accelerate the electrification of specific end-uses; these remain uneven across regions and sectors

Notes:  AE  =  advanced  economies;  EMDE  =  emerging  market  and  developing  economies.  Incentives  and investments  include  government  programmes  directed  towards  efficient  appliances;  electricity  and  fuel switching use in industry; electric vehicles. Fuel switching regulations include fossil fuel boiler bans; industrial electrification mandates; zero-emission vehicle mandates; internal combustion engine sales bans.

Source: IEA Global Energy Policies Hub.

Regulations and mandates that seek to accelerate the electrification of specific end-uses are more common. These include policies such as support for EVs or subsidies for purchasing heat  pumps.  In  the  United  Kingdom,  for  example,  the  zero-emission  vehicle  mandate requires  car  manufacturers  to  sell  an  increasing  share  of  EVs  each  year.  Chile's  National

1

Electromobility  Strategy  similarly  requires  all  new  car  sales  to  be  electric  from  2035. However, these sector-specific policies remain uneven across regions and sectors (Table 1.2).

In general, most sector-specific policies target electrification indirectly by creating incentives, putting taxes on other fuels, or implementing performance standards that favour electric technologies.  Explicit  restrictions  on  fossil  fuel-based  heating  are  also  being  used  to encourage the electrification of space heating. For example, the Netherlands announced in 2022 that heat pumps would become the standard for heating from 2026, while France, following  the  recent  crisis,  announced  a  ban  on  gas  boilers  in  new  buildings  from  2027 alongside subsidies for heat pump installations. The new EU ETS2 emissions trading system, which will cover upstream buildings emissions and indirectly support consumption of lowemissions electricity, is set to be fully implemented in January 2028.

The policy  landscape  remains  dynamic,  with  new  measures  being  brought  forward  while some  existing  measures  are  revised  or  withdrawn.  For  example,  Canada  announced  in February  2026  its  intention  to  strengthen  its  fuel-economy  standards and  to  develop  a National Charging Infrastructure Strategy; it also reinstated its federal purchase incentives for EVs. These measures are intended to help offset the repeal of Canada's Electric Vehicle Availability Standard, which would have required EVs to account for 60% of sales by 2030 and 100% by 2035. Similarly, the December 2025 draft revision of the European Union's Ecodesign  for  Sustainable  Products  Regulation  replaces  the  previously  implied  2029  gas boiler ban with efficiency requirements and a more gradual phase-out.

Figure 1.12 ⊳ Share of government energy spending directed towards end-use electrification, 2015 and 2025e

<!-- image -->

The share of government energy spending supporting end-use electrification increased nearly fivefold between 2015 and 2025; almost all of it was directed at road transport

Notes:  2025e  =  estimated  values  for  2025.  Government  energy  spending  data  cover  G20  economies  and include programmes supporting transport electrification, heat pump adoption, electricity uses in industry, and electricity demand reduction.

<!-- image -->

Alongside  standards  and  market-based  incentives,  direct  government  financial  backing  is used  to  support  electrification  in  many  countries,  mostly  through  programmes  that incentivise road transport and buildings electrification (Figure 1.12). Government spending on electrification has grown from about USD 7 billion in 2015 to less than USD 80 billion in 2025. The great majority of this support has been targeted at road transport electrification, with many new programmes introduced after the COVID-19 pandemic, though support for EVs has been reduced in 2026 as they have become more competitive (IEA, 2026c).

In  the  residential  sector,  government  support  has  focused  on  more  efficient  electric appliances and on facilitating a shift from oil and natural gas heating to electric alternatives by lowering upfront capital investments. Spending has risen from USD 0.7 billion in 2015 to USD 1.6 billion in 2025. The United Kingdom's renewable heat incentives account for a large share of this spending, but the total also reflects programmes in France, Germany and Japan supporting heat pump installation in existing and new buildings. Government support for industrial electrification remains less common, with most programmes offering a broader set of options to improve firms' energy efficiency rather than specifically targeting electrification.

## 1.5.2 Nationally Determined Contributions

Nationally Determined Contributions (NDCs) provide a way for countries to express their climate ambitions at the international level under the Paris Agreement. Although the primary purpose of NDCs is to set out headline targets for the reduction of greenhouse gas emissions, an  increasing  number  of  countries  are  complementing  these  overarching  targets  with descriptions of key implementing pillars, sub-targets and measures. This practice can help to guide implementation and give signals to investors and national policy makers.

Although increased electrification, in the context of power systems with growing levels of low-emissions generation, is central to reducing emissions in end-use sectors, it remains only partially  reflected  in  NDCs.  While  NDCs  increasingly  recognise  the  importance  of  clean electricity supply, particularly through commitments aligned with the COP28 global goal of tripling renewable  energy  capacity by 2030, explicit objectives for shifting energy consumption towards electricity are much less frequent (Figure 1.13). As a result, the role of electrification in reducing emissions across transport, buildings and industry is often implied rather than directly articulated, limiting the visibility of electrification as a central strategy.

Electrification is not yet underpinned by explicit international benchmarks, and this absence is clearly reflected in the latest round of NDCs. The end-use electrification targets that do appear  in  new  NDCs  remain  concentrated  on  a  narrow  set  of  applications,  with  road transport accounting for the overwhelming majority. Targets addressing electric vehicles and their supporting infrastructure appear in around 46% of new NDCs and cover more than half of  global  transport  emissions.  By  contrast,  explicit  targets  for  electrification  in  buildings, industry or indirect end-uses are far less common.

1

Explicit references to electrification or to a shift of energy consumption in specific end-uses towards electricity remain scarce in new NDCs. The concept features far more as an implicit consequence of other targets such as those relating to EVs than as an objective in its own right. No new NDC includes a quantified target for raising the overall share of electricity in total final consumption, and only six contain a qualitative pledge, while the vast majority make no reference to the issue at all. Furthermore, the qualitative pledges cover only around 3% of total global energy-related CO2 emissions from total final consumption and make little reference to associated emissions reductions.

This concentration underscores a broader imbalance in how  new  NDCs  approach electrification. Many continue to place greater emphasis on transforming electricity supply than on stimulating demand for clean electricity across the wider economy. The result is a persistent gap in NDCs  between  ambitious  power-sector  supply  commitments  and comparatively underdeveloped demand-side strategies.

Figure 1.13 ⊳ Coverage of key electrification targets in new NDCs and associated share of global emissions

<!-- image -->

IEA. CC BY 4.0.

Electrification remains largely underrepresented in new NDCs, with few explicit targets and limited coverage of emissions, except in the transport sector

Notes: NDC = nationally determined contributions. New NDCs include submissions made after the conclusion of the first Global Stocktake at COP28, which was held in Dubai, United Arab Emirates, from 30 November to 13 December 2023. Where a Party has submitted more than one NDC during this period, only its most recent submission is counted. The European Union and its Member States are treated as a single Party. The United States of America is excluded from the count, as it is no longer a Party to the Paris Agreement following its withdrawal, which took effect on 27 January 2026 in accordance with Article 28, paragraphs 1 and 2 of the Agreement.  'Indirect'  refers  to  electricity-derived  energy  carriers  and  processes  such  as  hydrogen  and hydrogen-based fuels, e-fuels, electrified district heating, electricity-intensive industrial feedstocks, and other electricity-demanding decarbonisation technologies including carbon capture and direct air capture.

## S P O T L I G H T

## Relationship between electrification and previous COP goals

In 2023, COP28 adopted a set of energy goals intended to guide energy transitions and climate policies. These included specific goals for doubling the rate of energy efficiency improvement  and  tripling  the  installed  capacity  of  renewables  by  2030.  They  also included objectives related to putting in place net zero energy systems by mid-century; transitioning away from fossil fuels in energy systems, in a just, orderly and equitable manner; and accelerating the reduction of emissions from road transport. Electrification is closely related to all these goals and objectives.

Over half of global energy-related emissions - around 55% - come from end-uses: in other words, from the combustion of fuels in cars and trucks, in factories, and in homes and offices. Around 90% of oil demand, 50% of natural gas demand, and 30% of coal demand occur in end-uses. The efficiency  of  electricity  and  -  if  generated  from  lowemissions sources such as renewables - its potential to expand clean energy use in final consumption sectors mean that electrification is critical  to  addressing  end-use  sector emissions. Other measures also have a part to play, including the deployment of biofuels, low-emissions hydrogen and hydrogen-based fuels, and carbon capture and storage. But electrification  options  are  scalable,  commercially  available,  and,  in  many  cases,  costeffective: they therefore account for a large portion of end-use emission reductions in strong climate action scenarios.

Electrification  is  also  closely  related  to  the  goals  of  doubling  the  rate  of  efficiency improvements and tripling renewables capacity by 2030. In most applications, electricity is far more efficient than the incumbent fossil fuel-powered technology. Electrification therefore helps lower energy consumption while meeting the same economic needs and thus helps to deliver on the goal of doubling efficiency improvements. The tripling of renewables capacity implies a much greater use of renewables in power generation, and strong policy support for electrification sends an investment signal for increased supply of renewables by creating expectations of rising demand, if the right policies are in place. Similarly, the COP29 Grids and Storage Pledge supports key enablers of electrification, including by promoting the deployment of storage to improve electricity system flexibility and the expansion and modernisation of electricity networks.

## 1.6 Scenario definitions

The IEA analysis in this report is based around multiple scenarios, none of which is a forecast. These scenarios make  different assumptions about policy settings and technology deployment, but share the same pathways for population and economic growth. Chapter 2, which  discusses  the  outlook  for  electrification  in  end-use  sectors,  introduces  the  High Electrification Scenario:

-  The High Electrification Scenario (HES):  this  scenario  sets  out  a  pathway  to  a  global electrification  rate  of  35%  by  2035,  based  on  a  detailed  analysis  of  electrification potential. This level of electrification for end-uses, when combined with other actions such as on efficiency, is aligned with the IEA's Net Zero Emissions by 2050 Scenario, which limits warming to 1.5 °C by 2100. Like all IEA scenarios, the HES reflects a detailed assessment of the technical and economic potential for electrification of end-uses by sector and region through technologies such as electric vehicles and heat pumps. It also sees strong growth in already electrified end-uses such as air conditioning, data centres, appliances and advanced manufacturing. Driven by rising incomes, growth in these uses is  particularly  strong  in  emerging  market  and  developing  economies,  where  many consumers are set to make their first purchases of appliances and equipment. However, the HES does not make any assumptions about how the level of electricity demand that it foresees is met.

The implications of different electricity generation mixes for energy demand and aggregate emissions are explored in Chapter 3 using multiple cases. The Net Zero Emissions by 2050 (NZE) Scenario maps out an ambitious pathway for the global energy sector to achieve net zero CO2 emissions by 2050, consistent with a long-term goal of limiting the rise in global average temperatures to 1.5 °C. The Stated Policies Scenario (STEPS) reflects the prevailing direction of travel of today's policies and technology trends. The Current Policies Scenario (CPS) is anchored solely in measures already enacted in law, with no policy renewals or new policies assumed. Alongside this view of the policy landscape, the CPS also offers a generally cautious  perspective  on  the  speed  at  which  new  energy  technologies  are  deployed  and integrated into the energy system.

<!-- image -->

<!-- image -->

## Electrification in end-uses

Unlocking potential

## S U M M A R Y

- · This report explores a High Electrification Scenario (HES) in which, thanks to increases across all sectors and regions, the global electrification rate rises to 35% of global final energy consumption by 2035. For end-uses, this is aligned with pathways to achieve net  zero  emissions  by  2050.  Due  to  their  higher  efficiency,  electric  technologies provide over 50% of useful energy by 2035 in this scenario. In the HES, growing use of electricity across the energy system means that 1 400 terawatt-hours of electricity demand is added annually - twice the annual increase over the last decade.
- · There is substantial potential today to expand electrification cost effectively, based on  2025  energy  prices,  technology  costs  and  financing  conditions.  The  global electrification rate would rise to 33% if this potential were fully tapped. Currently, this potential is not fully exploited due to non-cost barriers and the need for enabling infrastructure. Continued improvements in technology costs, or policy interventions such as tax changes or subsidies, can help expand the cost-effective potential.
- · Under today's conditions, all regions have substantial potential to expand electrification  cost-effectively,  although  the  extent  differs  depending  on  relative energy prices, energy taxation choices, financial conditions, infrastructure availability, technology costs and industrial priorities.
- · Fuel-importing regions have greater potential because they tend to have higher fuel prices. Exploiting today's cost-effective potential would raise electrification rates by almost 15 percentage points in Europe versus 5 percentage points in the Middle East.
- · In transport, nearly 25% of car sales and 15% of two/three-wheeler sales in 2025 were electric.  Based  on  current  market  trends  and  policy  settings,  electrification  avoids around  10 million  barrels  per  day  (mb/d)  of  oil  demand  by  2035.  In  the  HES, electrification accelerates across all road transport segments: by 2035, avoided oil demand rises to 18 mb/d, supported by a quadrupling of public charging.
- · In the HES, rapid growth of already electrified uses in buildings is complemented by the  increasing  electrification  of  space  and  water  heating.  For  regions  lacking  full access to modern energy, improving access to electricity and clean cooking has the largest effect on raising the electrification rate.
- · In industry, the key end-uses with near-term potential for electrification are low- and medium-temperature heat and non-electrified motors. In India, for example, almost 30%  of  industrial  heat  demand  is  below  150 °C.  In  the  HES,  electrification  makes significant inroads in both these areas in all regions and countries. Over the longer term, deeper electrification of industry depends in part on continued investment in innovation.

## 2.1 Outlooks for electrification in IEA scenarios

## 2.1.1 Drivers of electrification

Electrification increases across all IEA scenarios. In scenarios based on today's policy settings, the electrification rate rises to slightly less than 30% by 2035, up from 23% today. More rapid electrification to reach a rate of 35% in the High Electrification Scenario (HES) depends on tapping  economic  potential  across  all  sectors  and  regions,  accelerating  innovation,  and implementing supporting policies that expand the scope for electrification.

The increasing electrification rate across IEA scenarios is the result of three evolving factors:

-  Higher  activity  in  electricity-only  end-uses: Many  end-uses  can  in  practice  only  be powered by electricity.  For  example,  gasoline  cannot  directly  power  transistors  in  a laptop, and coal cannot directly power the compressor in a residential air conditioner. Across  all  IEA  scenarios,  electricity  consumption  grows  faster  than  total  energy consumption because the use of goods and services already powered by electricity also grows  faster.  These  end-uses  include  appliances  and  air  conditioners  in  homes  and offices, some manufacturing processes, and data centres and other digital infrastructure. The faster growth of these end-uses - especially in emerging market and developing economies - contributes to the overall increase in the rate of electrification. In addition, expanding access to electricity in countries without full access enables more people to benefit from electricity-powered end-uses.
-  The electrification of multi-fuel end-uses: Most end-uses can be powered by multiple fuels.  Coal,  natural  gas  or  electricity  can  provide  low-temperature  heat  in  industry; gasoline or electricity can power motorbikes and cars; and diesel or electricity can power agricultural pumps. Across all scenarios, the electrification of multi-fuel end-uses means that  consumers  opt  for  the  electric  option  over  others  for  economic,  security, convenience,  performance  or  other  reasons,  or  for  a  combination  of  reasons.  This includes consumers that opt to switch from a non-electric to an electric technology, such as a household trading in its gasoline car and buying an electric vehicle (EV) instead. It also includes consumers in emerging market and developing economies that access an energy  service  for  the  first  time  via  an  electric  technology:  a  farmer  purchasing  an electric rather than a diesel pump for their first irrigated field, for example. The key distinction is that the end-use can practically be met by multiple fuels, and the consumer opts to adopt the electric one.
-  Efficiency: Efficiency measures in end-uses help to slow demand growth for all fuels, especially  for  combustion-based  fuels  where  end-uses  typically  have  more  scope  to improve efficiency  than  for  electricity   Reducing  total  final  energy  consumption,  the . denominator of the electrification rate, therefore contributes to increasing the overall electrification rate. Key efficiency measures include fuel-economy standards, buildings retrofits, minimum  energy  performance  standards  (MEPS)  and  energy  efficiency investments in factories. The stringency of such measures varies across IEA scenarios and is strongest in the HES.

<!-- image -->

In the HES, all three levers contribute to increasing the electrification rate to 35% by 2035. In the buildings and industry sectors, activity grows rapidly in already electrified end-uses like air  conditioning and electricity-powered manufacturing processes. Among multi-fuel enduses, the electrification of transport through the deployment of electric vehicles is the largest driver of the increase in the electrification rate. Efficiency improvements are spread across industry, transport and buildings. In addition, the world makes swift progress in extending electricity and clean cooking access to those who currently lack it.

## 2.1.2 High-level electrification outcomes

Figure 2.1 ⊳ Electrification rate by sector and by regional grouping, STEPS and HES, 2025 and 2035

<!-- image -->

IEA. CC BY 4.0.

All sectors and regions electrify rapidly to 2035 in the HES,

with the fastest increases in the transport sector, and in other EMDE excluding China

Note: AE = advanced economies; EMDE = emerging market and developing economies; STEPS = Stated Policies Scenario; HES = High Electrification Scenario.

Electrification rates rise across all three end-use sectors, in aggregate increasing to 35% in the HES by 2035 compared to today (Figure 2.1). The transport sector is at present much less electrified than the buildings and industry sectors, and it sees the largest relative rise, with the electrification rate in the HES increasing from 2% today to 13% by 2035. EV sales growth is led by cars, two/three-wheelers and city buses, but strong policies and the development of supporting infrastructure in the HES also help to accelerate the electrification of trucks and  intercity  buses.  By  2035,  there  are  700 million  electric  cars  on  the  road,  up  from 80 million today. In buildings, electrification is led by the uptake of heat pumps in regions with significant heating needs. By 2035, heat pump sales quadruple in the HES, and the heat pump stock across regions reaches 4 000 gigawatts (GW). In addition, the electrification of cooking is advanced by the deployment of induction cookstoves. In industry, the HES sees

2

the much wider adoption of electric technologies that are already competitive today in many countries, including the production of low- and medium-temperature heat in non-energyintensive industries and the generation of mechanical energy.

Electrification rates rise across all economies in the HES, but the pace and priorities differ by country.  Compared  to  the  trajectories  implied  by  existing  policies,  emerging  market  and developing economies outside China see the largest increases. In economies without full access to electricity, strong progress on improving access in the HES leads to a step change in the efficiency of residential energy use, with electricity and other modern fuels replacing the extremely inefficient traditional use of biomass (see Chapter 4).

## 2.1.3 Implications for electricity demand

Existing end-uses such as appliances, space cooling, data centres and industrial motors see rapid activity growth in the HES. The growing use of electricity in multi-fuel end-uses such as passenger cars, residential heating, or low- and medium-temperature industrial heat adds considerably to this. Global electricity demand from transport, industrial heat, and heating and  cooking  in  buildings  grows  by  9 200 terawatt-hours  (TWh)  by  2035  in  the  HES  equivalent  to  more  than  total  electricity  demand  in  Europe  and  North  America  in  2025 (Figure 2.2). EVs and industrial heat contribute the most to this increase. A strong focus on improving energy efficiency across the energy system helps to counteract part of the rising power demand that comes with electrification.

Figure 2.2 ⊳ Annual electricity demand growth by regional grouping in the STEPS and HES, 2015-2025 and 2025-2035

<!-- image -->

IEA. CC BY 4.0.

In the HES, electricity demand growth accelerates to 2035, and almost doubles compared to the last decade

Note: TWh = terawatt-hour; EMDE = emerging market and developing economies.

Electricity demand growth accelerates across all IEA scenarios to 2035, reflecting the growing importance of electricity in the global economy and in energy systems. From 2015 to 2025, electricity demand grew by 750 TWh per year on average, led by growth in emerging market and developing economies, notably China. In the Stated Policies Scenario (STEPS), this jumps to an annual average increase of around 925 TWh to 2035. In the HES, almost 1 400 TWh of electricity  demand  is  added  per  year  -  more  than  total  current  electricity  demand  in Southeast Asia - as the acceleration of electrification outweighs improvements in efficiency. Without strong efficiency efforts, this increase would be even higher.

## 2.2 Economic electrification potential

## 2.2.1 Economic potential by sector

For  this  report,  we  have  conducted  detailed  analysis  of  the  electrification  potential  in different sectors, end-uses and regions. We start this analysis with a snapshot of the situation today, considering energy prices, taxes and subsidies by region; technology costs by region; and financing costs by region. The analysis looks at residential buildings, road transport and low- and medium-temperature heat in industry, and it assesses how much of their current fuel consumption can be electrified cost-effectively.

The analysis focuses on the perspective of individual consumers making decisions to invest in electrification. It does not consider the system-wide costs and benefits of electrification, such as its implications for infrastructure, energy security, local air pollution and so on. How these costs and benefits impact on consumers depends on different policy choices; they are addressed further in Chapter 4.

The results of this analysis are shown in Figure 2.3. In this figure, a negative value on the vertical axis means that the end-use could be electrified cost-effectively, while a positive value indicates that the end-use is not competitive under today's conditions.

Our analysis shows that there is substantial cost-effective potential for electrification based on today's technology costs, energy prices and financial conditions. About half of residential fuel consumption and half of oil-based road transport could be electrified competitively, and almost 40% of fossil fuel-based low- and medium-temperature heat in industry. If the costeffective  potential  for  electrification  were  exploited  fully,  the  global  electrification  rate would reach 33% in 2035, up from 23% in 2025.

However, electrification potential is determined by a range of factors, of which the direct cost to the user is only one. In practice, a variety of barriers mean that currently, this headline potential is not fully exploited; these include a lack of enabling infrastructure, limitations in consumer awareness and restricted access to finance in certain markets. The extent to which the domestic availability of electric technologies is actively promoted varies from country to country. Policy changes, reductions in technology costs or changes in energy prices take time to translate into shifts in electrification rates, given the time required to replace stocks of energy-consuming equipment.

2

Figure 2.3 ⊳ Global economic potential for electrification by sector and end-use, as a share of fuel-based energy consumption, 2025

<!-- image -->

IEA. CC BY 4.0.

There is substantial cost-effective potential for electrification based on today's technology costs, energy prices and financial conditions

Notes:  MWh  =  megawatt-hour.  The  electrification  potential  curve  displays  the  share  of  fossil-fuel  based consumption  that  can  be  electrified  at  different  electricity  price  premiums  (computed  against  the  local electricity price for the sector as a reference). Traditional use of biomass is not included. A negative premium means that electrification is cost competitive. The levelised cost of technologies is assessed at a regional level based on local electricity and fossil fuel price, discount rate, investment cost and utilisation rate. Light-duty vehicles include passenger cars and light commercial vehicles. Heavy-duty vehicles include buses, medium freight trucks and heavy freight trucks.

It follows that there is substantial scope for policies to shape the economic competitiveness of  electrification  options.  Policy  support  is  not  solely  a  question  of  providing  financial incentives to support the take-up of electric technologies or innovation, though it could take that  form.  For  example,  in  some  cases  electric  technologies  would  be  competitive  if distortions such as fuel subsidies or high taxes on electricity were removed, or if the reliability of electricity systems could be assured in places where it is lacking today.

## 2.2.2 Economic potential by region

The competitive electrification potential of each region is shaped by local demand structures, reflecting factors such  as  levels of industrialisation, vehicle  ownership  and  average temperatures.  It  is  also  affected  by  regional  economic  conditions,  including  fuel  prices, equipment cost and access to finance. Figure 2.4 displays the electrification rate today in selected regions and compares it to the electrification rate that would be reached if today's cost-competitive electrification potential were to be fully tapped. It captures the efficiency gains  from  switching  to  electricity,  which  lowers  total  final  energy  consumption  and indirectly increases the electrification rate, but it keeps all other factors as they are today, including activity levels, efficiency levels and access to clean cooking.

Figure 2.4 ⊳ Electrification rates and competitive electrification potential, selected regions, 2025

<!-- image -->

IEA. CC BY 4.0.

Tapping the competitive electrification potential across regions would increase the global electrification rate to 33%, up from 23% today

Notes: C &amp; S America = Central and South America. The competitive potential column shows the electrification rate if all competitively electrifiable demand today is electrified, accounting for efficiency gains and keeping all else equal. 35% = electrification rate in the High Electrification Scenario by 2035.

<!-- image -->

2

Full exploitation of today's cost-competitive potential results in an electrification rate higher than today's level in all regions; the increases range from around 5 percentage points in the Middle East to almost 15 percentage points in Europe and India. Passenger cars, heating and cooking deliver most of the potential. More policy support would unlock further potential in industry beyond low- and medium-temperature heat.

Countries in East Asia already have some of the highest electrification rates in the world, but this  rate  could  increase  to  over  40%  with  further  cost-competitive  electrification  of  road transport,  space  heating,  and  gas-  and  oil-based  low-temperature  industrial  heat.  In Southeast Asia and India, the electrification rate could rise from 25% and 19% today to 37% and 32% respectively, with transport electrification playing a major role: average electric two/three-wheelers and cars are now cheaper in these countries over their usual ownership period than internal combustion engine (ICE) alternatives. In Europe, the electrification rate could increase to more than 35%: recent policy changes in several European countries have expanded the cost-effective potential for the electrification of heating and transport. Further potential exists in countries with low electricity prices, such as the Nordic countries. In the Middle East, energy subsidies limit the potential; in Africa, the rate of electrification rises, but is constrained by high levels of traditional use of biomass.

## 2.2.3 Sensitivity of economic potential to changing conditions

The  cost-competitiveness  of  electrification  is  heavily  influenced  by  factors  including government policies, the cost of finance, the effects of innovation, and changes in energy markets. Figure 2.5 analyses the economic potential for electrification under three sensitivity cases designed to highlight areas for policy consideration:

-  Lower discount rates: Discount rates and borrowing rates are lowered by 2 percentage points when they are higher than 7%, and 1 percentage point in all other cases. This sensitivity captures the potential effect of more favourable financing conditions as well as greater consumer awareness of the long-term benefits of electrification. 1
-  Lower investment cost: The electric equipment cost in each sector is lowered by 15% compared to today. This models the impact of battery pack cost reductions in transport; innovation, market development, and policy incentives for large-scale industrial heat pumps; and lower installation costs or better heat pump sizing in buildings.
-  More favourable fuel price: The end-user electricity price is reduced by 10% and the competing fossil fuel price is increased by 10%. This case captures the potential effect of  a  tax  rebalancing  between  electricity  and  fossil  fuels  or  changes  in  the  electricity generation mix (see Chapter 3).

1 For some economic actors, in particular households, discount rates may be higher than the cost of capital, reflecting behavioural biases, lack of financial literacy and information, or risk aversion. Greater consumer awareness can therefore lower the implicit discount rates that consumers use to assess costs and benefits.

These  levers  increase  the  cost-competitive  potential  for  electrification  in  the  residential sector by about 10 percentage points, have limited impact in industry, and almost double the  potential  in  transport.  In  road  transport,  lower  investment  costs  deliver  the  largest improvements in competitiveness. A 15% reduction in capital costs makes electric cars and two/three-wheelers  cheaper  on  average  globally  over  their  ownership  period  than  ICE vehicles. In buildings and transport, fuel prices remain a primary driver of competitiveness. Rebalancing prices makes the greatest difference in regions with significant usage - due to high heating needs, for example - where a small difference in fuel costs can lead to large savings and help offset higher investment costs. Across all sectors, lower discount rates have only a limited impact: they help deliver savings in the longer term, but do relatively little to improve the case for upfront investment in electrification.

Figure 2.5 ⊳ Sensitivity of the economic potential for electrification to changing conditions, by sector, as a share of fuel-based energy consumption, 2025

<!-- image -->

IEA. CC BY 4.0.

All sectors show sensitivities to changing economic conditions.

Transport shows the highest sensitivity to reductions in upfront costs and electricity prices.

Notes: WACC = weighted average cost of capital. CAPEX = capital expenditure. 'Benchmark' refers to the potential under the conditions described in Figure 2.3. 'WACC' refers to the sensitivity case where discount rates and borrowing rates are lowered by 2 percentage points when they are higher than 7% and 1 percentage point otherwise. 'CAPEX' refers to the sensitivity case where electric technologies' CAPEX is reduced by 15%. 'Fuel price' refers to the sensitivity case where electricity price is reduced by 10% and conventional fuel prices are increased by 10%.

<!-- image -->

2

## 2.2.4 Higher efficiencies of electric technologies and cost-effective electrification

Electricity requires large, expensive infrastructure to generate, transport and distribute it. In the past, demand was relatively inflexible and large-scale storage options were limited; as a result, electricity infrastructure was largely sized to meet peak rather than average demand. Because of these factors, electricity is almost always more expensive per unit of final energy consumption than fuels like natural gas or gasoline.

However, technologies that consume electricity are often substantially more efficient than their conventional equivalents. A heat pump uses the input energy to harvest more energy from the ambient air, meaning that the ratio of output energy service to input energy is higher  than  one  (typically  it  is  three  to  five).  By  contrast,  a  gas  boiler  converts  chemical energy in the input fuel to heat with an efficiency of less than one. Electric vehicles have an efficiency of around 85%-90%, compared to around 25%-35% for ICE vehicles.

These interactions mean that electricity is often more expensive than other fuels on a final energy basis, but cheaper in terms of delivering energy services to consumers (Figure 2.6). On a final energy basis, on average across the world, one US dollar buys 17 kilowatt-hours (kWh) of gas or 10 kWh of oil but only 7 kWh of electricity. On the other hand, with an electric heat  pump,  one  US  dollar  buys  22 kWh  of  heating  services  compared  to  16 kWh  from  a natural  gas  boiler.  For  an  electric  vehicle,  one  US  dollar  buys  almost  7 kWh  of  mobility services (motive energy) compared to about 2 kWh from an ICE vehicle.

Figure 2.6 ⊳ Average energy service delivered per USD for selected technologies, 2025

<!-- image -->

On a final energy basis, electricity is typically more expensive than other fuels, but with greater efficiency, electric technologies can deliver cheaper energy services

Notes: kWh = kilowatt-hour; ICE = internal combustion engine; EV = electric vehicle. Global average fuel prices for 2025 weighted by demand are used. The analysis assumes a boiler efficiency of 90%, a heat pump efficiency of 300%, an ICE efficiency of 25%, and an EV efficiency of 90%.

## Box 2.1 ⊳ Measuring what matters: Electrification of final versus useful energy

The lives of consumers are improved by the energy services that equipment delivers after consuming energy products like petrol, natural gas or electricity: movement enabled by petrol  in  a  vehicle,  heat  generated  by  natural  gas  in  a  boiler,  or  cooling  provided  by electricity in an air conditioning unit. However, measuring the consumption of energy products is far easier than measuring the consumption of the resulting energy services. For this reason, energy balances take the final consumption of energy products as the last step in the energy value chain and ignore the process of converting these products into useful energy.

Because electricity is converted into useful demand more efficiently than other fuels, its share in final energy consumption is lower than in useful demand. Globally, for example, electricity today accounts for 23% of final energy consumption but supplies almost 40% of useful energy. In the HES, electricity meets 35% of final energy consumption by 2035, but over 50% of useful energy.

A 35% electrification rate by 2035 in the HES sees most progress in end-uses that can switch  from  other  fuels  to  electricity.  By  2035,  around  40%  of  the  stock  of  heating equipment  and  of  cars  is  electrified,  up  from  today's  levels  of  around  20%  and  6% respectively (Figure 2.7).

Figure 2.7 ⊳ Electricity share in final energy consumption, useful energy and equipment stock in the HES, 2025 and 2035

<!-- image -->

Electric technologies are highly efficient and provide more than half of useful energy in 2035; their share in the stock of heating equipment and cars grows strongly

Note: 35% = refers to electrification rate in the High Electrification Scenario by 2035.

<!-- image -->

2

## 2.2.5 Demand flexibility and cost-effective electrification

Electrified  technologies  can  also  provide  benefits  to  the  electricity  system  by  acting  as flexible  sources  of  demand.  This  flexibility  can  lower  the  costs  of  electrification  at  the individual and system level, and support electricity system transitions while strengthening electricity  security.  For  example,  time-of-use  tariffs  and  automated  signals  sent  through electricity networks have been developed in France since the 1960s, partly to support the expansion of the nuclear fleet and optimise its operation. Today, around 15 million French consumers subscribe to a time-of-use tariff.  The  automated  signal  sent  to  electric  water heaters avoids more than 3 GW of evening peak electricity demand (RTE, 2026).

In many  regions,  substantial growth  in electricity generation  from  wind  and  solar photovoltaics  (PV)  is  translating  into  predictable  patterns  of  low  -  or  even  negative  electricity prices at midday and price spikes in the evening. In more than 60 markets, the incidence of negative prices has increased substantially in recent years, rising from 110 hours per year on average in 2019 to over 450 hours in 2025.

Figure 2.8 ⊳ Summer net load for selected regions in 2025 and global hourly demand response activation in the HES, 2035

<!-- image -->

IEA. CC BY 4.0.

Low-cost renewable electricity shifts flexible demand towards midday and decreases variations in net load

Notes: The curves reflect average 24-hour patterns over summer months. The shaded area represents the 10th-90th percentile range. Shifted electricity demand shows the demand response of flexible end-uses, and is relative to the average electricity demand.

While the impact of growing shares of variable renewables depends on market structures and system operation decisions, output from non-dispatchable sources is set to continue rising almost everywhere. This creates a challenge for balancing electricity systems - and an opportunity for electrification. Solar PV follows distinct patterns that tend to repeat every

day, especially during summer months. This offers an opportunity to design or adjust timeof-use tariffs and incentivise flexible demand to operate when it benefits the system the most. In the HES, flexible demand equivalent to around 10% of average demand is shifted to periods  of  high  renewables  output  in  2035,  helping  to  balance  the  system  and  allowing consumers to benefit from lower prices (Figure 2.8).

Flexible demand offers several benefits. For consumers, it can lower costs by allowing them to  consume  electricity  when  it  is  cheap  (provided  that  flexible  tariffs  and  appropriate regulations are in place). For system operators, flexible demand can remove the need for more  expensive  flexibility  options  and  help  avoid  the  opportunity  cost  of  increasing curtailment. For network planners, flexible demand can help to optimise network utilisation and so reduce or defer the requirement for expensive investments in grids, though there may still be a need for structural investment to support sustained load growth, reliability or asset  renewal.  Making  distributed  technologies  such  as  electric  vehicles  (EVs)  and  heat pumps  flexible  is particularly important  because  distribution  network  upgrades  are expensive; today, nearly two-thirds of investment in grids is in distribution networks, and these costs make up a significant share of consumer bills.

Figure 2.9 ⊳ Typical ranges of savings on energy bills for selected technologies due to flexible operation, 2025

<!-- image -->

IEA. CC BY 4.0.

The flexible operation of selected technologies that support electrification could lead to savings of up to USD 300 on annual energy bills for households

Notes: MER = market exchange rate. The ranges are calculated for a fully electrified representative household with an annual electricity consumption of 4.5 MWh for space heating, 1.7 MWh for water heating and 2 MWh for charging a passenger car.

For consumers that own an EV, heat pump or electric resistance water heater, savings from flexible  operations  could  account  for  as  much  as  15-30%  of  the  costs  of  operating  the

2

technology, or more in some instances. This could make a critical difference to the costeffectiveness  of  these  technologies,  provided  that  consumers  can  access  the  benefits  of lower  wholesale  prices.  Among  flexible  end-uses,  EVs  offer  the  largest  savings  potential because  smart  charging  can  shift  large  amounts  of  demand  to  hours  when  electricity  is cheapest.  Water  heating  can  also  shift  demand  through  the  use  of  storage  tanks.  Space heating has significant potential in regions where it is a major residential end-use, but the degree  to  which  demand  can  be  shifted  depends  on  how  long  a  building  can  maintain comfort before occupants notice a temperature drop. Buildings that are better insulated and provide greater thermal inertia therefore offer more potential for flexibility (Figure 2.9).

However,  the  expansion  of  demand-side  flexibility  depends  on  user  awareness  and acceptance, enabling infrastructure such as interoperable digital controls with appropriate privacy safeguards, and incentives and market frameworks. In the HES, these elements are all in place by 2035. By that year, the average electricity demand from EVs and heat pumps is about 450 GW, but their contribution at peak demand is much higher at around 900 GW (Figure 2.10). This difference indicates the potential that could be rescheduled to hours with lower  electricity  prices,  even  if  some  demand  could  not  be  shifted  because  it  would  be needed to meet immediate charging or heating needs. The equivalent of 15% of total peak electricity demand can be controlled from the demand side in the HES. This potential for demand flexibility compares to 2 900 GW of installed battery capacity in the HES by 2035, and 1 600 GW of natural gas power plants.

Figure 2.10 ⊳ Annual average and peak load from heat pumps and electric vehicles in the HES, 2025 and 2035

<!-- image -->

IEA. CC BY 4.0.

By 2035, EVs and heat pumps consume 900 GW at peak winter demand, offering potential to control around 15% of the peak from the demand side

Notes: GW = gigawatt. Load of heat pumps and electric vehicles is calculated at winter peak demand.

## 2.3 Drivers of electrification in emerging market and developing economies

Emerging market and developing economies are characterised by growing and urbanising populations that are highly sensitive to affordability concerns, and by relatively large shares of  gross  domestic  product  (GDP)  that  come  from  agriculture  and  primary  sectors.  Cost competitiveness  remains  central  to  the  uptake  of  electrification  and  other  technologies (Section 2.2),  but  it  is  not  the  only  factor.  This  section  examines  structural  drivers  of electrification in emerging market and developing economies that go beyond affordability. These structural drivers span the core sectors of the economy, including transport, buildings, industry and agriculture. In addition, Box 2.2 takes a closer look at trends in the electrification of desalination in the Middle East and North Africa, which account for 40% of the global capacity of this critical technology.

## 2.3.1 Transport

Key  structural  drivers  beyond  cost  that  influence  the  uptake  of  electrified  transport  in emerging market and developing economies include commuting distances, urban population density,  weather,  fuel  import  dependence,  air  quality  concerns  and  the  absence  of  a domestic legacy automotive industry.

Figure 2.11 ⊳ Average distance travelled per capita per day by region, 2025

<!-- image -->

IEA. CC BY 4.0.

The average distance travelled per capita per day in EMDE tends to be shorter than in advanced economies, falling well within the typical ranges of electric two-wheelers

Notes:  km  =  kilometres.  This  analysis  considers  passenger  kilometres  travelled  per  capita  per  day  across motorised vehicles and rail.

The  average  daily  distance  travelled  in  emerging  market  and  developing  economies  is significantly lower than in advanced economies and China (Figure 2.11). This is partly a result

<!-- image -->

2

of lower incomes, but it is also influenced by urban sprawl and density (Figure 2.12). Lower travel distances mean that electric two/three-wheelers can meet transport needs despite their lower ranges compared to passenger cars. Popular electric two/three-wheeler models already have battery ranges that are around ten-times the average distance travelled per day in emerging  market  and  developing  economies.  Two/three-wheelers  are  also  more affordable over their lifetime than electric cars: consumers can often recover their additional upfront cost within 3-6 years of use in most regions (Figure 2.17).

Figure 2.12 ⊳ Urban population density and urbanisation rate by region, 2025

<!-- image -->

Emerging market and developing economies tend to have substantially denser urban areas than advanced economies

Note: C &amp; S America = Central and South America; Other dev Asia = Other developing Asia.

Fuel import dependence and balance-of-payments pressures are also important considerations. Several emerging market and developing economies - notably in Southeast Asia, South Asia and parts of Africa - are net importers of oil. In smaller and less economically diversified emerging market and developing economies, oil import bills have a bigger effect on  trade  balances  and  foreign  exchange  reserves  than  in  more  diversified  high-income economies. This in turn prompts policy support for electrification. For example, Ethiopia has seen high EV sales, partly owing to policy choices designed to mitigate rising oil import bills (Box 2.4).

Air  quality  concerns  are  another  important  consideration.  Over  60%  of  the  more  than 4.5 million premature deaths from ambient air pollution occur every year in emerging market and developing economies excluding China. Tailpipe emissions from ICE vehicles are a key contributor, leading cities such as Delhi to adopt  measures  to  promote  transport electrification.

Industrial and infrastructure development are also relevant in this context. Emerging market and developing economies without a domestic legacy automotive industry focused on ICE technologies are likely to face less political and policy resistance to the local production or import of EVs. On the other hand, in countries - particularly in Africa - that rely on imports of used ICE vehicles, the lack of used EV options may act as a barrier. Meanwhile, countries that need to expand rail and public transport systems may be able to electrify from the outset and avoid being locked into legacy infrastructure.

## 2.3.2 Buildings

A  typical  household  in  emerging  market  and  developing  economies  has  fewer  modern appliances  than  that  in  advanced  economies.  Electrification  is  set  to  increase  in  these countries as households and commercial establishments buy more appliances. Several other structural factors also influence electrification trends in emerging market and developing economies:  these  include  relatively  low  space  and  water  heating  needs,  relatively  high cooling needs and extensive solar generation potential.

Figure 2.13 ⊳ Solar irradiation and temperature conditions by region

<!-- image -->

IEA. CC BY 4.0.

Countries in the EMDE grouping are often characterised by high solar irradiation and few days with low temperatures. This presents an opportunity to electrify certain end-uses.

Notes: Solar irradiation is weighted by population. The number of days is averaged over the past decade and considers daily temperatures weighted by population.

Around  three-quarters  of  the  global  population  lives  in  tropical  and  subtropical  regions, mostly in emerging market and developing economies. These regions are characterised by moderate temperatures in winter and therefore have low heating needs (Figure 2.13). As a result,  countries in these regions have largely not become locked into natural gas boilerbased heating systems. Where space heating is required on a limited number of cold days,

2

inexpensive electric space heaters can be viable alternatives. The climate of these regions means that demand for water heating is also relatively low. Water is often heated today with liquefied petroleum gas (LPG), biomass or small electric water heaters. The lack of extensive combustion-based  water  heating  infrastructure  makes  further  electrification  easier  and cheaper than it would otherwise be.

High  solar  potential  in  many  emerging  market  and  developing  economies  opens  up  the possibility of thermal solar water heating. It also creates opportunities to improve electricity access  in  rural  communities  through  solar  mini-  and  microgrids  (see  Chapter 4).  Where households already have electricity access, the alignment between peak solar power and peak cooling demand could help balance grids and strengthen the case for rooftop systems. There is also scope for low-cost solar power to support the electrification of daytime uses in businesses and homes, with all the potential benefits that this implies (see Chapter 4). From now until 2035, 80% of energy consumption growth is set to occur in regions with average solar irradiation above 4.5 kilowatt-hours per square metre (kWh/m ) per day. 2

## 2.3.3 Industry

Unlike advanced economies and China, many emerging market and developing economies do not have large industrial bases, and industries with low-temperature heat requirements tend to be predominant. These industries offer more scope for technologically viable and cost-competitive electrification than heavy industry. However, unreliable central electricity supplies often mean that end-uses widely electrified elsewhere - such as motors - are still met by fossil fuels in some countries.

In  addition  to  the  reliability  of  supply,  industry  electrification  in  emerging  market  and developing economies is likely to be influenced by factors including the timing of the buildout of new industrial infrastructure, the structure of the sector itself, energy security concerns and supply chain considerations.

In  the  HES,  around  45-60%  of  expected  industrial  capacity  in  emerging  market  and developing economies in 2050 is set to be built in the 2040s, compared with less than 30% in advanced economies and China (Figure 2.14). As electric technologies improve and costs fall,  this  creates  an  opportunity  for  these  economies  to  electrify  new  facilities  from  the outset, rather than rely on fossil fuel-based systems that could require costly retrofits at a later stage.

The structure of industry is another important consideration. Some 40% of industrial energy demand in emerging market and developing economies other than China is in non-energyintensive industries, compared to around 24% in advanced economies and China. Many of these  non-energy-intensive  industries  use  low-temperature  heat  for  applications  such  as dairy production, food processing and textiles. These applications require hot water, lowpressure steam and heat for drying, making them well suited to electrification. Industrial heat pumps and electric boilers may be viable alternatives, particularly for new facilities or when existing equipment is replaced.

Figure 2.14 ⊳ Industrial capacity stock by construction period and region in the HES, 2050

<!-- image -->

IEA. CC BY 4.0.

Around 45-60% of industrial capacity that will exist in EMDE by mid-century will be built in the 2040s, by which time electric technologies are likely to have advanced further

Note: In this figure, industrial capacities refer to steel, cement and aluminium production capacities.

As is the case with advanced economies, energy security considerations may also shape the pace of electrification in emerging and developing economies. Fuel price fluctuations can impact industrial competitiveness, and geopolitical events can disrupt supply, as has recently been the case due to the conflict in the Middle East. Electrification that draws on domestic resources can therefore strengthen energy security by reducing exposure to price volatility and supply disruptions.

Supply chains and trade competitiveness are further considerations for countries. Industries in emerging market and developing economies are increasingly seeking global markets for their products. Many multinational corporations now have emission reporting and reduction requirements along their entire supply chains, and more may add them in the future. There are  also  trade  instruments  to  take  into  account,  such  as  the  Carbon  Border  Adjustment Mechanism, which applies tariffs on carbon-intensive products imported into the European Union. In this context, electrification and the use of low-emissions electricity may open up export opportunities that would not otherwise be available.

## 2.3.4 Agriculture

In Europe and North America, agriculture accounts for 1-2% of GDP, but its share in South Asia and sub-Saharan Africa is 17-19%. In these regions, the electrification of the agricultural sector could have an outsized impact on the overall rate of electrification of the economy.

<!-- image -->

2

Key priorities include irrigation and the scaling up of cold chain storage and refrigeration. Irrigation is critical for emerging market and developing economies, especially those in arid and semi-arid regions or along major river basins. In many such countries, energy demand from  irrigation  can  be  significant  and  is  often  met  by  diesel  generators.  Solar-powered off-grid and grid-connected water pumps offer one possible solution where grid electricity is unavailable or unreliable, especially since high solar irradiation often coincides with periods when demand for irrigation is high. India's PM-KUSUM scheme aims to address this issue and has led to the deployment of over two million solar pumps, many of which have replaced diesel alternatives (PIB, 2026).

Cold chain storage and refrigeration have a vital part to play in limiting post-harvest losses in emerging market and developing economies. In many countries, the absence of electricitydependent cold  storage,  refrigerated  transport  and  processing  infrastructure  contributes significantly to food waste and income loss for farmers. In sub-Saharan Africa, for example, around  15%  of  fruit  and  vegetables  are  lost  on  average  on  farms  due  to  the  lack  of appropriate  storage  infrastructure  (FAO,  2019).  Solar-powered  off-grid  or  grid-connected cold storage and refrigeration would help reduce waste and therefore improve food security.

## Box 2.2 ⊳ How electrification is transforming desalination

As populations and economies grow, water needs are rising, placing increasing pressure on freshwater resources. Over 3 billion people live in highly water-stressed areas today, and 85% of them live in emerging market and developing economies. Desalination was initially concentrated in the Gulf region in the 1970s to produce freshwater; its use has since expanded as related technologies have developed.

Around  40%  of  global  desalination  capacity,  including  the  world's  largest  plants,  is located in the Middle East and North Africa (MENA) today. Multi-effect distillation and multi-stage  flash  -  the  thermal  desalination  technologies  which  have  historically dominated in the MENA region - rely mostly on natural gas (or sometimes oil, especially in Gulf countries) for the thermal processes, while electricity powers auxiliary steps such as pumping.

In recent  decades,  electricity-powered  membrane  technologies  (especially  reverse osmosis) have quickly gained market share in the MENA region (Figure 2.15). The last major  new  thermal  plant  in  the  region  was  added  in  Qatar  in  2018.  Thermal  plants typically use up to ten times more energy than reverse osmosis for the core desalination process,  which  means  that  electrified  desalination  offers  significant  energy-saving potential. With reverse osmosis and other membrane-based plants now accounting for over  60%  of  installed  capacity  in  the  region  and  more  than  80%  globally,  electricity consumption for desalination has doubled since 2010.

Figure 2.15 ⊳ Net desalination capacity additions by technology in the Middle East and North Africa, 1975-2025

<!-- image -->

Note: other electrified includes desalination processes using nanofiltration, electrodialysis and electrodeionisation.

Source: IEA analysis based on GWI DesalData (2026).

## 2.4 Transport electrification

Transport accounts for more than one-quarter of global energy consumption and two-thirds of global oil consumption. Road transport is responsible for nearly three-quarters of total transport energy consumption  and  increasingly uses electric technologies that are commercially  available  today.  Meanwhile,  long-distance  aviation  and  shipping  generally require energy-dense fuels that cannot easily be replaced with today's electric technologies; rail electrification has been taking place since the late 19 th century, and almost half of global rail energy demand is already met by electricity. Against this backdrop, the analysis below focuses on road transport.

Global  transport  activity  rises  substantially  across  all  IEA  scenarios  to  2035  (Figure 2.16), driven  primarily  by  increasing  incomes  in  emerging  market  and  developing  economies. Higher  incomes  boost  private  vehicle  ownership,  increase  passenger  travel  demand  and stimulate freight activity as households consume more goods and industrial output expands. Today, per capita passenger road transport activity in advanced economies and China is 60% higher than in emerging market and developing economies with full access to electricity, and more than three-times higher than in those without full access. The gap is even larger for freight transport. As incomes increase, these disparities gradually narrow, although transport demand remains shaped by factors such as economic structure, national infrastructure and urban geography (Section 2.3).

2

Figure 2.16 ⊳ Road transport activity by region, 2015-2035

<!-- image -->

Both passenger and freight transport activity increase globally by 25% in all scenarios over the next decade, led by activity growth in emerging market and developing economies

Note: pkm = passenger-kilometres; tkm = tonne-kilometres.

## 2.4.1 Transport technologies

One in every four cars sold in 2025 was electric (i.e. battery electric or plug-in hybrid), with sales  supported  by  strong  policy  incentives,  falling  battery  costs  and  a  rapidly  expanding range of models. Lithium-ion battery prices have fallen by 90% since 2010, while the number of electric car models available globally increased by 25% in the last year alone. In China, where 70% of  battery  electric  cars  sold  in  2025  were  already  cheaper  than  the  average conventional car, consumers benefit from both lower upfront costs and lower running costs. As a result, electric car sales reached 13 million in China in 2025, accounting for close to 55% of all new car sales.

Beyond China, the economics of electric vehicles (EVs) are improving. While electric cars still have a higher purchase price in many regions outside China, their lower running costs help offset this difference over time. These lower running costs of electric cars stem largely from the higher efficiency of electric drivetrains; battery electric cars typically use around 70-80% less  energy  per  kilometre  than  comparable ICE vehicles and can save drivers USD 200 to USD 1 500 per year in fuel  costs,  with  the  scale  of  savings  depending  on  factors  such  as energy prices, usage patterns, charging conditions and vehicle characteristics. On the other hand,  EVs  currently  tend  to  depreciate  faster  than  comparable  ICE  vehicles,  with  some estimates indicating that electric cars retain around 5-15 percentage points less value after eight years of ownership (Schloter, 2022). While depreciation trends for EVs and ICE vehicles are  gradually  converging  in  some  markets  (Cox  Automotive,  2026),  higher  depreciation

remains an important cost consideration and can offset part of the savings from lower fuel and maintenance costs, particularly over shorter ownership periods.

Markets where the competitiveness of electric cars is improving relative to ICE cars, such as Australia, Korea and parts of Europe, have recently seen significant growth in EV uptake. In both Australia and Korea, electric car sales rose by 110% in the first half of 2026 compared to the first half of 2025. In Europe, they grew by around 30% year-over-year. However, in markets where gasoline prices are relatively low, such as the Middle East or North Africa, payback periods can still be as long as 15 years - near the average car lifetime.

However, in Europe, Latin America and Southeast Asia, buyers of electric cars can on average recover the additional upfront cost within a typical eight-year ownership period (Figure 2.17). Together with China, these regions account for over 40% of global passenger car energy use. As battery costs continue to decline and affordable electric models become more widely available, and as charging infrastructure expands, the economic case for EVs will strengthen further. In some countries, vehicle-to-grid operations may provide an additional boost to EV economics. The high sales share of electric cars already observed in markets such as China, Europe and parts of Southeast Asia could therefore increasingly become achievable in many other regions and countries.

Figure 2.17 ⊳ Payback period of EVs by mode compared to equivalent ICE powertrain in key regions, 2025

<!-- image -->

IEA. CC BY 4.0.

Regions accounting for more than 40% of global energy use from cars have seen the electric car payback period fall below 8 years

Notes: Financial support and subsidies were not taken into account. Analysis considers the capital, financing, maintenance  and  fuel  costs,  as  well  as  discount  rate  and  resale  value  of  the  vehicle  over  an  eight-year ownership period for private vehicles and a ten-year period for commercial vehicles. Depreciation for EVs is considered to be slightly faster than for ICE vehicles. The payback period reflects the time required for savings from lower running costs to offset the higher upfront costs of a battery electric vehicle. Developed Asia Pacific grouping includes Japan, Korea, Australia and New Zealand.

<!-- image -->

2

Electric  two/three-wheelers  -  a  primary  mode  of  transport  across  much  of  Africa  and developing Asia - are among the most economically attractive vehicle segments to electrify, especially for commercial uses. Their smaller batteries and relatively modest price premium compared with ICE models enable payback periods of below eight years in many markets, and as little as three to five years in China and parts of Africa, Latin America and Southeast Asia. Electric models accounted for 15% of global two/three-wheeler sales in 2025, rising to more than 20% in Viet Nam, and around 50% in China. In India, EVs accounted for over 65% of  three-wheeler sales, while in Türkiye, nearly all three-wheelers sold today are already electric  (Box 2.3).  However,  significant  untapped  potential  remains,  with  take-up  still constrained by concerns over financing, reliability and resale value, limited availability of electric  models  from  established  manufacturers,  and  policy  frameworks  that  have  often prioritised passenger cars.

While the upfront costs of electric heavy freight trucks remain substantially higher than for diesel trucks, falling battery prices and significant fuel savings are steadily improving their competitiveness. In China, where electric truck purchase prices can be three times lower than  elsewhere,  the  payback  period  for  electric  heavy  freight  trucks  can  be  as  low  as three years,  while  in  Europe  and  North  America  it  is  over  ten years.  Together  with deployment  of  depot  and  corridor  charging  infrastructure,  this  is  helping  to  accelerate adoption in China, where electric heavy-duty trucks (i.e. medium and heavy freight trucks) accounted for 25% of new heavy-duty truck sales in 2025. However, in many economies, deployment remains constrained not only by vehicle costs, but also by the availability of depot charging infrastructure and grid connection capacity.

## Box 2.3 ⊳ Türkiye's emerging electromobility ecosystem

Türkiye emerged as one of Europe's fastest growing electric vehicle (EV) markets in 2025, with electric car sales that were over 30 times higher than in 2022. Growth has been driven by favourable incentives, a wider range of models, expanding charging infrastructure, domestic EV production and more affordable vehicles.

New conventional vehicles are subject to a Special Consumption Tax (ÖTV), ranging from 70%  to  220%  of  the  pre-tax  vehicle  value  depending  on  engine  size.  In  2025,  EVs benefited  from  lower  ÖTV  rates  of  25%  to  75%,  based  on  their  battery  size  and  tax category. EVs generally face the standard 20% value-added tax rate. EV financing has also been expanded, with customers able to access loans of up to TRY 1.75 million, equivalent to over USD 40 000 in 2025, four times the regulated limit for non-EVs. Istanbul and Izmir also provide parking privileges and licence plate benefits for battery electric vehicles.

In  2025,  Türkiye  recorded  an  electric  car  sales  increase  of  over  120%  compared  with 2024. With sales of around 240 000 EVs, it became the fourth-largest electric car market in Europe (Figure 2.18). Electric cars accounted for more than 20% of passenger car sales in 2025, with shares recorded in the first half of 2026 remaining close to 20%, despite absolute electric car sales declining by around 20% year-on-year. Domestic manufacturer

Togg has become an important driver of Türkiye's passenger EV transition, with models at  competitive  prices  that  were,  on  average,  20%  cheaper  than  conventional  cars.  In 2025, Togg sold approximately 39 000 vehicles, surpassing EV sales of Tesla and BYD. Its expanding model portfolio is strengthening domestic EV production, with Togg gaining a market share of around 30% of total electric car sales for the first half of 2026.

Figure 2.18 ⊳ Electric vehicle sales in Türkiye and sales shares in Türkiye and Europe for selected vehicle types, 2021-2025

<!-- image -->

Source: IEA analysis based on data from EV Volumes and ACEA.

Türkiye is the largest market for electric two-wheelers in Europe, with 2025 sales growing by 1.5% to 59 000. The country is also the dominant European market for electric threewheelers, accounting for around 95% of the 115 000 electric three-wheelers sold in the region;  globally,  the  country  is  the  third  largest  market  for  electric  three-wheelers. Electric models now represent nearly all new three-wheeler sales in Türkiye, reflecting their growing use in urban deliveries, logistics, and short-distance commercial transport.

The charging ecosystem is also developing rapidly. By the first half of 2026, Türkiye had around  50  000  public  charging  points,  an  increase  of  40%  from  2025  (European Commission, 2026). Government support remains active through the Electric Vehicle Fast Charging Infrastructure Support Program, reopened in 2025 to accelerate fast charging deployment and improve coverage across the country. Türkiye's Medium-Term Program for 2025 to 2027 and Strategic Plan for 2024 to 2028 both prioritise stronger EV charging infrastructure,  smart  grid  integration  and  wider  access  to  public  charging  stations. Türkiye has a target of 100 000 public charging stations by 2028 (Government of Türkiye, 2024).

2

To date, the number of electric cars on Türkiye's roads has surpassed 500 000, with over 80 000 added in the first half of 2026. Overall, Türkiye is transitioning rapidly toward electric mobility, supported by strong EV sales growth, differentiated vehicle taxation, expanding charging infrastructure, increasing model availability and growing domestic production. These developments are positioning Türkiye as an increasingly important EV market  in  Europe.  By  2030,  the  government  aims  for  EVs  to  account  for  35%  of  the automobile market, and to have 2.5 million electric vehicles on the road, positioning the country as an increasingly important EV market.

## 2.4.2 Transport strategies

Electrification opportunities vary widely across regions, reflecting differences in how people and goods move. In advanced economies and China, passenger transport is dominated by cars,  and  vehicle  ownership  levels  are  much  higher  than  in  other  emerging  market  and developing economies (Figure 2.19). As a result, cars offer by far the largest electrification opportunity in advanced economies and China, where electrifying the car fleet could reduce today's  transport  energy  demand  by  around  35%  and  increase  the  share of  electricity  in global transport energy use from over 2% to around 27%.

Figure 2.19 ⊳ Vehicle ownership rates and average passenger- and tonnekilometres by aggregate region, 2025

<!-- image -->

Note: Heavy-duty trucks include medium freight trucks and heavy freight trucks.

Two/three-wheelers play a much larger role in emerging market and developing economies with  full  access  to  electricity,  where  ownership  rates  average  around  170  vehicles  per

1 000 people.  This  is  mainly  because  two/three-wheelers  are  more  affordable  than  cars, although  other  factors  -  including  dense  and  congested  urban  environments,  shorter average trip distances and established motorcycle-based mobility systems - all help to make them  a  primary  means  of  transport  across  many  parts  of  Africa  and  Asia  (Section  2.3). Electrifying this segment in emerging market and developing economies with full access to electricity  could  reduce  their  transport  energy  demand  by  around  5%  and  raise  global transport electrification by a further 2 percentage points.

Public transport is also used more intensively in emerging market and developing economies than in advanced economies. Bus utilisation averages around 600 000 passenger-kilometres per vehicle in emerging market and developing economies with access gaps, which is 65% higher than in advanced economies and China. Even though demand is gradually shifting to cars as private vehicle ownership grows with income, buses are set to remain an important transport mode in emerging market and developing economies in the long term. Full bus fleet  electrification  would  reduce  transport  energy  demand  in  emerging  market  and developing economies with access gaps by around 15%, while adding 1 percentage point to the  share  of  electrification  in  global  transport.  Rail,  another  public  transport  mode,  can further amplify electrification benefits (Box 2.5).

Emerging market and developing economies excluding China also make the most intensive use of heavy-duty trucks, with freight activity reaching 450 000 tonne-kilometres per vehicle, compared  with  around  380 000 tonne-kilometres  in  advanced  economies  and  China. Growing  industrialisation  and  expanding  trade  underpin  this  higher  utilisation.  However, there are cost and other non-technological barriers to the electrification of trucks in these markets, including gaps in infrastructure and the high number of smaller, and often capitalconstrained, operators. Measures such as fleet aggregation, innovative leasing models and battery-as-a-service offerings could help reduce upfront costs and boost the use of electric heavy-duty trucks (ITF, 2025).

## Electrification of second-hand markets

Imported  second-hand  cars  account  for  a  noticeable  share  of  vehicle  registrations  in emerging market and developing economies. More than 6 million used cars were imported globally in 2025, accounting for around 7% of car registrations. Imports play an especially important role in Africa (40% of car registrations), Eurasia (30%) and the Middle East (20%). Almost all these cars use internal combustion engines; electric car adoption in these regions remains low not only because of affordability constraints, a lack of charging infrastructure and demand-side policy hurdles, but also because very few used EVs are available today.

However, electric vehicles are accounting for a growing share of new car sales in important exporting markets, including China, the European Union and Korea, which together account for around one-third of global used car exports. As these markets mature and EV stocks rise, a growing number of electric cars will flow into second-hand markets, creating a new channel for  electrification  in  emerging  market  and  developing  economies.  High  upfront  costs compared to conventional options and the limited availability of charging infrastructure are

2

likely to remain major barriers, but the relatively rapid rate of depreciation of EVs compared to ICE vehicles will help make second-hand EVs a more attractive proposition. Assuming a vehicle is purchased after eight years of ownership and operated for a further eight years, a used electric  car  could  deliver  more  than  USD 3 000  in  lifetime  savings  compared  with  a similar ICE vehicle in the main used-car importing regions. By contrast, purchasing a new electric car today still carries an average cost premium of around USD 1 000 over the first eight years of ownership.

Figure 2.20 ⊳ Used car sales in the main importing regions in 2025, and electric cars available for potential export in the main exporting regions across scenarios, 2025-2035

<!-- image -->

IEA. CC BY 4.0.

Potential volumes of used electric car exports grow 40 times by 2035 in the STEPS and 45 times in the HES in main exporting markets, boosting transport electrification in importing regions

Notes: Main importing regions include markets accounting for more than 70% of global used car imports today. Main exporting regions include markets accounting for more than 80% of global used car exports today. Cars available for potential export are cars that have reached the end of life in the primary market, and would be either scrapped or exported to a secondary market.

Countries accounting for more than 80% of the global used-car export market added around 1 million electric cars aged eight years or older to their pool in 2025 and scrapped or exported fewer than 100 000 electric cars. This is modest compared with the nearly 4 million annual used imported car sales in major importing countries, but the number of used electric cars scrapped  or  exported  annually  rises  to  more  than  2.5 million  in  the  STEPS  and  around 3 million in the HES over the next decade (Figure 2.20). This growing pool of used EVs in advanced  economies  and  China  has  significant  potential  to  help  emerging  market  and developing economies access electric mobility at affordable prices. However, realising this potential will depend on grid capacity and charging infrastructure. Policies on battery health

certification,  warranty  transferability  and  minimum  environmental,  safety,  and  battery performance  standards  for  imported  EVs  are  needed,  together  with  policies  supporting battery collection, recycling and end-of-life management.

## Box 2.4 ⊳ Ethiopia's transport electrification as an energy security strategy

Ethiopia has emerged as a fast-growing EV market in Africa. Its rapid uptake of EVs has been driven by a strong policy push to reduce dependence on imported oil and make greater use of the country's abundant hydropower resources, which generate more than 95%  of  its  electricity.  Ethiopia  imports  all  its  petroleum  products.  Fuel  imports  have exceeded  USD 4 billion  annually  in  recent  years,  accounting  for  around  20%  of  the country's total import bill and placing significant pressure on foreign currency reserves. To help reduce its dependence on oil imports, Ethiopia imposed prohibitively high import taxes  on  ICE  vehicles  in  2024  that  functionally  served  as  a  ban,  while  providing preferential import treatment for electric alternatives.

Figure 2.21 ⊳ EV stock and oil savings in Ethiopia, 2022-2025

<!-- image -->

Note: EV = electric vehicle.

Source: IEA analysis based on Government of Ethiopia (2025).

Although it is highly concentrated in terms of generation sources and heavily subsidised, Ethiopia's low-cost domestic electricity provides EVs with both economic and environmental advantages, while offering an avenue to reduce fuel imports. As a result, Ethiopia  has  around  115 000  EVs  on  its  roads  today,  mostly  two/three-wheelers (Government of Ethiopia, 2025). EV adoption has accelerated in recent years, reducing Ethiopia's  oil  demand  by  nearly  700  barrels  per  day  and  its  gasoline  demand  by

2

approximately  4%  (Figure 2.21).  EV  growth  has  been  particularly  strong  for  types  of vehicles that are used very frequently, such as commercial two/three-wheelers, taxis and buses, where lower operating costs make electrification especially attractive. In urban centres such as Addis Ababa, electrified public transport is also helping to improve air quality.

Ethiopia's  shift  to  electromobility  is  partially  driven  by  EV  imports  from  China,  but Ethiopia is also seeking to develop its own EV industry. The country has the capacity to assemble more than 80 000 EVs annually, mostly two/three-wheelers. Plans foresee an expansion from 17 EV assembly plants today to 60 by 2030, supported by exemptions from  import  duties  and  other  taxes  for  locally  assembled  EVs.  The  charging  network today consists of only around 100 stations and is concentrated in Addis Ababa, but the government is implementing a nationwide charging infrastructure programme and aims to have more than 2 200 charging stations in place by 2030, with charging corridors along major highways.

The country plans to expand its electric car and bus fleet to over 150 000 vehicles by 2030, which could cut its oil  demand by 5% of today's total, further reducing import dependence. The strategy is supported by plans for a rapid expansion in electricity supply led by the Grand Ethiopian Renaissance Dam, which has significantly increased domestic generating  capacity  and  enabled  electricity  exports  to  neighbouring  countries.  Major challenges remain, however. Nearly half of the population still lacks reliable access to electricity,  and  only  around  22%  have  legal  metered  grid  connections.  Expanding electricity access will be critical to overcoming infrastructure and supply-chain constraints and unlocking Ethiopia's full electrification potential.

## Charging infrastructure

Transport electrification depends on adequate charging infrastructure. Charging requirements  differ  widely  across  regions  due  to  variations  in  vehicle  fleets  and  travel patterns. In the HES, public charging deployment expands rapidly, rising from more than 7 million charging points globally in 2025 to about 30 million by 2035 (Figure 2.22). However, EV stocks grow even more rapidly, doubling the number of vehicles served by each public charging point globally.

This rise in vehicles per charging point does not necessarily indicate a growing infrastructure gap. As EV markets mature, charging speeds continue to improve, allowing each charger to be used more intensively and to serve more vehicles. The average power of public chargers increased by 15% year-over-year in 2025 to nearly 50 kilowatts, helping to reduce charging times (IEA, 2026a).

The vehicle mix in each country largely determines charging needs. In emerging market and developing economies excluding China, two/three-wheelers account for more than 90% of the EV fleet. They require less public charging infrastructure than cars due to their smaller batteries, lower energy demand and shorter travel distances. Most charging is done at home

or at the workplace, while battery-swapping networks provide an alternative in several Asian markets. As EV use rises, however, charging during peak periods will increase pressure on local electricity networks. In power systems such as India, where solar PV shares are growing rapidly and demand is increasingly concentrated in the evening and at night, smart charging, time-of-use  tariffs  and  vehicle-to-grid  systems  can  shift  demand  to  off-peak  periods  and improve grid utilisation, while strengthening the economic case for EVs.

Figure 2.22 ⊳ Public charging infrastructure and public charging point-to-EV ratio in the HES, 2025 and 2035

<!-- image -->

IEA. CC BY 4.0.

Public charging needs rise more than four times by 2035 and charging infrastructure is used more intensively, reducing charger-to-vehicle ratios and narrowing regional differences

Notes: Light-duty vehicles include passenger cars and light commercial vehicles. Heavy-duty vehicles include buses, medium freight trucks and heavy freight trucks. Public charging points include public chargers for lightduty vehicles and opportunity chargers for heavy-duty vehicles.

By contrast, regions where cars dominate mobility require denser public charging networks to  support  larger  batteries  and  higher-power  charging.  For  trucks  and  buses,  the  main requirement is dedicated high-capacity charging at depots, fleet hubs and along key freight corridors: the challenge here is to ensure that charging stations are established in the right locations and are powerful enough to meet user needs.

There  is  no  single  model  for  charging  infrastructure  deployment.  Regions  dominated  by two/three-wheelers can achieve high levels of electrification with relatively modest public charging networks, while those relying on electric cars, trucks and buses require larger and more power-intensive charging infrastructure, which calls for greater strategic planning.

<!-- image -->

2

## Box 2.5 ⊳ Rail can deliver electrification benefits

Transport  modes  differ  sharply  in  the  amount  of  energy  they  use  to  meet  the  same mobility needs. Cars consume around 1 600 kilojoules (kJ) per passenger-kilometre (pkm) on average today, while electrification can cut this by around 70%. Rail needs only around 200  kJ/pkm.  Despite  this  efficiency  advantage,  rail  accounts  for  just  10%  of  global passenger transport activity, less than 1 percentage point higher than a decade ago. For every percentage point of global passenger activity shifted from cars to rail, global oil demand would decline by more than 200 000 barrels per day.

Figure 2.23 ⊳ Passenger transport efficiency range by mode in 2025 and passenger rail electrification share by region, 2000-2025

<!-- image -->

Note: MJ = megajoule; pkm = passenger kilometre.

This  degree  of  efficiency  is  achieved  partially  thanks  to  rail's  high  electrification  rate. Passenger rail electrification has reached nearly 80% globally, up by around 10 percentage points over the last decade, compared with an electrification rate of just 1% in passenger road transport (Figure 2.23). Increasing use of rail can have implications for efficiency, for the fuel mix (and thus for energy security) and for emissions. A larger role for rail can also improve air quality, reduce noise and congestion, and expand access to  affordable  mobility.  But  these  gains  require  substantial  long-term  investment  in infrastructure.  They  also  depend  on  policies  that  raise  utilisation:  transit-oriented planning, integrated ticketing, reliable firstand last-mile connections, and complementary measures such as congestion charges, low- and zero-emission zones, awareness campaigns, and park-and-ride facilities linked to rail networks.

## 2.4.3 Transport potential

Transport electrification is already reducing global oil demand: it displaced around 2.5 million barrels per day (mb/d) in 2025, with electric cars accounting for over half of this total. As electrification accelerates, oil demand displacement rises to 9 mb/d by 2035 in the Current Policies Scenario (CPS) and 11 mb/d in the STEPS. In the HES, savings reach 18 mb/d by 2035.

Electric cars deliver the largest contribution, avoiding 5 mb/d of oil demand by 2030 and more than 10 mb/d by 2035 in the HES, with three-quarters of these savings occurring in advanced  economies  and  China.  The  electrification  of  buses  and  two/three-wheelers  is particularly  important  in  other  emerging  market  and  developing  economies,  reducing  oil demand  by  around  1.5 mb/d  by  2035.  Freight  electrification  also  plays  an  increasingly significant  role:  it  accounts  for  around  one-quarter  of  oil  savings  by  2035  in  advanced economies and China, and in other emerging market and developing economies with full access, it reduces global oil demand by 4.5 mb/d. Rail electrification also contributes, with electric non-urban rail displacing around 1 mb/d of oil demand by 2035 in the HES.

Figure 2.24 ⊳ Reduced oil demand from electrification by region and mode in the HES, 2025 and 2035, and reduced oil demand as a share of transport oil demand by region and scenario, 2035

<!-- image -->

IEA. CC BY 4.0.

Transport electrification could cut oil use by nearly 20 mb/d by 2035, or around a third of today's global transport oil demand

Notes: CPS = Current Policies Scenario; mb/d = million barrels per day. International bunkers are excluded from the right-hand figure.

By 2035, transport electrification reduces oil demand in the HES by an amount equivalent to 40% of current transport oil consumption in advanced economies and China, and it reduces consumption by an even higher percentage in emerging market and developing economies with an electricity access gap. In emerging market and developing economies with full access,

2

electrification cuts oil demand by an amount equivalent to around 30% of current transport oil consumption (Figure 2.24). This fall in oil demand in the HES reduces exposure to oil price volatility,  strengthens  energy  security  and  generates  around  USD 230 billion  in  oil  import savings globally by 2035.

Capturing these benefits requires a step change in electrification across all transport modes. In the HES, the share of electric car sales increases from 30% in 2025 in advanced economies and China, and 7% in other emerging market and developing economies, to nearly 100% worldwide by 2035, compared with sales shares of 65% in advanced economies and China and over 25% in other emerging market and developing economies in the STEPS. The share of travel activity accounted for by electric cars rises from around 5% of the total for cars today to 50% by 2035 in the HES. Electric buses and two/three-wheelers follow a similar trajectory. Around 35% of road freight activity is also electrified, roughly double the level achieved in the STEPS, while 80% of non-urban rail activity is electrified in the HES by 2035, compared to around 65% in the STEPS.

Realising the full benefits of transport electrification requires continued improvements in EV affordability  achieved  through  further  reductions  in  battery  costs  and  the  provision  of cheaper EV models by manufacturers. Targeted financial support could help address the high upfront costs of heavier vehicles, such as trucks and buses, particularly in emerging market and  developing  economies,  where  access  to  affordable  finance  remains  limited.  As  EV markets mature, the focus of policies should expand to also cover charging infrastructure deployment.

## 2.5 Buildings electrification

The buildings sector is already highly electrified: nearly 40% of its energy consumption is met by  electricity.  However,  much  of  this  comes  from  end-uses  where  there  is  typically  no alternative  to  using  electricity,  such  as  domestic  appliances,  information  technology equipment and data centres. The electrification rate of end-uses such as heating and cooking, which  can  use  either  electricity  or  other  fuels,  stands  at  only  15%.  There  is  significant potential to increase the electrification of these end-uses, which are concentrated in the residential sector: the electrification rate in this sector is 30% today, compared with almost 60% in the services sector. The analysis below therefore focuses primarily on the residential sector.

The buildings sector as a whole currently accounts for around 3 billion tonnes of carbon dioxide (Gt CO2) of direct emissions from fuel combustion, which is less than emissions from transport or industry. In addition to electricity, the buildings sector makes significant use of natural gas (slightly more than 20% of the sector's total energy consumption), oil (10%) and traditional  use  of  biomass  (15%).  The  last  of  these  is  particularly  prevalent  in  countries without access to modern cooking fuels, where wood and agricultural waste are used for cooking in highly inefficient and polluting stoves, with major negative effects on development and welfare.

Figure 2.25 ⊳ Floorspace, air conditioner and appliance stock, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

India and Southeast Asia account for a significant share of new floorspace and household appliance growth, particularly for air conditioners

Key  drivers  of  energy  demand  in  the  buildings  sector  are  projected  to  increase  by  2035 (Figure 2.25). Floorspace is set to expand by around 40 billion square metres in the next ten years from 220 billion square metres today. Air conditioners and appliances grow even more quickly over the decade: the stock of air conditioners increases by 45%, and the appliance stock expands by 2 billion units.

Globally, high air conditioner (AC) ownership is currently concentrated in relatively cool and affluent countries. Many of the warmest emerging market and developing economies still have  low  levels  of  ownership,  pointing  to  large  unmet  cooling  needs.  As  incomes  and temperatures rise, AC uptake is set to grow: by 2035, around half of households have cooling access,  with  nearly  90%  of  new  residential  AC  stock  added  in  emerging  market  and developing economies. China remains a major source of air conditioning demand growth, while India and Southeast Asia's combined share of the global stock rises from less than 10% today to 20% by 2035. Activity in fast-growing household services, from cooling and fans to appliances for uses such as cleaning or food and medicine storage, is also set to increase substantially. As a result of these developments, energy services are increasingly met with electricity rather than other fuels in the buildings sector in the HES, lifting the electrification rate.

## 2.5.1 Buildings technologies

The key end-uses in the buildings sector with substantial electrification potential are space heating,  water  heating  and  cooking.  In  each  of  these  end-uses,  cost-competitive  electric technologies exist and are already being widely deployed.

2

Figure 2.26 ⊳ Levelised cost of using heat pumps versus gas boilers for residential space heating in selected heating markets, 2025

<!-- image -->

IEA. CC BY 4.0.

Heat pumps are competitive in heating markets that account for more than half of global space heating demand

Notes: PPP = purchasing power parity; UK = United Kingdom; NZ = New Zealand. The columns represent the levelised  cost  for  the  more  competitive  option,  and  the  dots  represent  the  levelised  cost  for  the  less competitive option. The data points are aggregated and based on country average conditions.

In high-intensity heating applications, such as space and water heating in cold climates, heat pumps are the main technology for buildings electrification. Around 110 GW of heat pumps are already deployed annually across the buildings sector, up by around 30% since 2020. Heat pumps have higher capital costs than alternative technologies such as gas boilers, but are three  to  five  times  more  efficient  (Figure 2.26).  Their  greater  efficiency  means  that  heat pumps can have lower lifetime costs than gas boilers despite higher upfront costs, but this depends critically on the price ratio of electricity to natural gas. In markets where energy taxation favours natural gas over electricity, or where the price of natural gas is unusually low, the greater efficiency of heat pumps is often not enough to produce the fuel savings needed to offset their higher upfront costs.

Policies can effectively lower electricity prices and thus improve electricity-to-gas price ratios (Section 4.4.2). For example, policies that lead to better-insulated buildings reduce the size of the heat pumps needed in those buildings, lowering the expenditure required to buy the heat pump. Costs are not the only consideration: installing heat pumps requires specialised labour, can be disruptive for users, and in some places may be hindered by policy instability. Nonetheless,  IEA  analysis  indicates  that  heat  pumps  are  competitive  today  in  countries accounting  for  more  than  half  of  global  space  heating  demand,  and  that  most  of  these countries feature low electricity-to-gas price ratios. Heat pumps are also making inroads in the  services  sector,  where  large  heat  pumps  and  advanced  heating,  ventilation  and  air conditioning (HVAC) systems are increasingly being deployed as electrified alternatives to conventional boilers.

In  lower-intensity  heating  applications  -  in  countries  with  milder  winters,  for  example  electric resistance water and space heaters provide a widely available electrified technology. Resistance  heaters  have  low  capital  costs,  but  they  do  not  offer  a  substantial  efficiency benefit compared  to  gas  boilers.  This  means  they  require  electricity  to be  priced competitively compared to alternatives. The main advantages of resistance heaters in lowintensity  heat  markets  are  the  simplicity  of  installation  and  ease  of  operation.  In  places without connections to a gas grid, they are often used to replace much more inconvenient and polluting fuels, such as wood, agricultural waste and coal.

Electric stoves are more efficient and contribute less to indoor air pollution than gas stoves, and are vastly more efficient than traditional biomass stoves. With an electric cookstove, around 80 to 85% of the input energy is directed to cooking, compared with around 50% for a gas or LPG stove, and around 10% for a traditional wood stove. This means that the total cost of ownership for an electric cookstove across its lifetime can be up to 10% lower than for  an  LPG  stove  in  emerging  market  and  developing  economies,  despite  higher  upfront costs.  In  many  such  countries,  however,  lack  of  access  to  electricity,  unreliable  supply, cultural  preferences,  lack  of  awareness,  and  difficulty  in  accessing  finance  all  hold  back electrified cooking. Cooking is time-sensitive, so unreliable electricity supply is a particularly significant barrier to uptake.

## 2.5.2 Buildings strategies

Figure 2.27 ⊳ Buildings electrification rate by sub-sector and region, 2025

<!-- image -->

Space heating in advanced economies and China offers the most potential for electrification: it consumes most energy and currently has a low electrification rate

Notes: EJ = exajoule. Traditional use of biomass is not allocated to specific end-uses due to limitations in data availability but is largely used for cooking and to a lesser extent for water heating.

The  relative  importance  of  space  heating,  water  heating  and  cooking  differs  by  region (Figure 2.27). In advanced economies and China, by far the most important target for further electrification is space heating, which accounts for more energy consumption than water

2

heating and cooking combined, and currently has an electrification rate of slightly more than 15%.  There  is  also  scope  for  significant  further  electrification  of  cooking,  where  the electrification rate is currently less than 30%. In emerging market and developing economies with full access, electrification potential is spread more evenly among space heating, water heating and cooking, with electrification rates of less than 15% for all three of these enduses. In emerging market and developing economies without full access, by far the greatest potential lies in using electricity for cooking and heating instead of traditional biomass. In these economies, the traditional use of biomass still accounts for three-quarters of total energy consumption in the buildings sector. Displacing this requires access to modern forms of energy, including LPG as well as electricity (Section 4.6.1).

In the HES, electrification rates rise across all end-uses and regions, but the main drivers vary by country grouping (Figure 2.28). In advanced economies and China, the largest gains come from space heating: heat pumps increasingly replace fossil fuel boilers, and the electrification rate for space heating increases from around 15% today to 27% by 2035 in the HES. This reflects  the  economic  competitiveness  of  heat  pumps  and  the  support  from  regulatory requirements and financial incentives in a number of countries. In other emerging market and developing economies, electrification increases the most for water heating and cooking, with some of the gains in cooking coming from wider access to clean cooking. This can shift households  away  not  just  from  fossil  fuels,  but  also  from  traditional  polluting  cooking methods, bringing improvements in efficiency, health and local air quality.

Figure 2.28 ⊳ Share of electricity in energy and useful energy demand by residential end-use and by region in the HES, 2025-2035

<!-- image -->

IEA. CC BY 4.0.

Electrification rates almost double by 2035 for space heating in advanced economies and China, and for cooking and water heating in emerging market and developing economies

Note: 'All end-uses' also includes electric-only end-uses.

## Leveraging growing cooling needs for heating electrification

Reversible heat pumps can provide both heating and cooling, and many buildings need both services.  For  example,  around  75%  of  households  across  North  America,  China  and developed Asia Pacific use cooling in the summer and heating in the winter. As summers become hotter in Europe, demand for cooling is growing in a number of countries there, too. Whether households are considering replacing end-of-life air conditioning units or installing air conditioning for the first time, reversible heat pumps offer an opportunity for them to meet both cooling and heating needs with the same piece of equipment, and in the process to electrify heating demand previously met by natural gas or other fuels.

Figure 2.29 ⊳ Share of households with residential space heating and cooling in 2025, and share of households owning a heat pump in 2025 versus share replacing cooling equipment by 2035

<!-- image -->

IEA. CC BY 4.0.

The use of reversible heat pumps to meet demand for air conditioning in major heating markets would also boost heating electrification

Note: NAM = North America; DAP = Developed Asia Pacific; AC = air conditioner.

The potential to speed up the electrification of heating through the adoption of reversible heat pumps is considerable, and would make a major contribution towards increasing energy efficiency  and  reducing  emissions.  In  North  America,  developed  Asia  Pacific,  and  China, nearly half of all households are set to replace their air conditioning units before 2035, but only  a  limited  number  of  these  households  already  have  a  heat  pump.  Replacing  air conditioning  units  with  reversible  heat  pumps  that  provide  heating  as  well  as  cooling presents a clear opportunity to boost the electrification of heating. In Europe, around 15% of households are set to replace their air conditioners or install one for the first time between now and 2035 (Figure 2.29). Since the vast majority of these households do not currently own a heat pump, there is a significant opportunity here to speed up the electrification of heating. The debate around air conditioning in parts of Europe risks overlooking the potential

2

for reversible heat pumps to serve Europe's growing cooling needs while also electrifying Europe's much greater heating demand. Europe's natural gas consumption for heating today is nearly 10 times larger than its electricity consumption for cooling: nearly half of its energy demand for space heating is currently met by natural gas, and space heating accounts for more than a quarter of Europe's total natural gas demand.

## Box 2.6 ⊳ Heat pumps for water heating in Japan

Water heating accounts for nearly 20% of energy demand in buildings in Japan, compared with  just  over  10%  in  advanced  economies  on  average.  This  higher  share  of  demand reflects cultural preferences and makes water heating a priority for electrification and energy efficiency.

In  2000,  water  heating  in  Japan  relied  heavily  on  fossil  fuels,  with  less  than  10%  of households  equipped  with  electric  water  heaters.  EcoCute  heat  pump  water  heaters were  subsequently  introduced  to  improve  building  energy  efficiency  while  reducing emissions. These water heaters use the substantial efficiency gains offered by heat pump technology to heat water much more efficiently than conventional electric resistance heaters.

Figure 2.30 ⊳ Sales of EcoCute water heaters in Japan, 2005-2024, and water heating energy demand by fuel in Japan, 2025

<!-- image -->

Nearly all electric water heaters sold in Japan today are heat pump water heaters; their growing market share is increasing the electrification rate and cutting emissions

Note: Other includes solar thermal, district heat, geothermal and modern bioenergy.

Deployment expanded rapidly, with EcoCute capturing around 10% of the water heater market within a decade of its introduction. Around 10 million units have been sold: the brand now accounts for nearly all electric water heaters sold in Japan, and for 15% of all

water  heaters  sold  in  the  country.  Early  market  uptake  was  supported  by  targeted policies, including financial incentives. More recently, Japan has renewed its efforts to improve  water  heating  efficiency  through  a  dedicated  programme  promoting  highefficiency water heating technologies. Although heat pump water heating pilot projects existed in Japan prior to EcoCute, the innovative use of CO2 as a refrigerant delivered additional  efficiency  gains  and  is  regarded  as  a  key  factor  behind  the  technology's commercial success.

## Water heating and cooking in emerging market and developing economies

For emerging market and developing economies that have already achieved full access to electricity,  the  electrification  of  cooking  and  water  heating  offers  additional  benefits  for energy security and affordability. Today, imported fuels account for nearly 25% of energy demand for cooking and water heating in emerging market and developing economies, and in some countries, they cover more than 60% of demand. Recent experience has shown that when countries depend on imported fuel, it can accelerate switching to electric cookstoves to avoid energy supply disruptions. For example, the disruption to LPG flows via the Strait of Hormuz  has  triggered  the  introduction  of  fuel-switching  incentives  in  heavily  impacted markets such as India and Indonesia. India launched a programme to procure and deploy 500 000 induction cooktops; Indonesia is also seeking to speed up the deployment of electric stoves (IEA, 2026b). However, reliable, affordable electricity supply is essential if this shift is to strengthen resilience rather than creating new vulnerabilities within power systems. For water heating applications, pairing electricity-powered equipment such as resistance water heaters with other efficient solutions such as solar thermal water heaters can help reduce grid requirements.

## 2.5.3 Buildings potential

In buildings, the central challenge is to combine the increasing electrification of end-uses with effective management of electricity demand growth, especially during peak hours when heating  and  cooling  demand  surges  due  to  extreme  temperatures.  Demand  is  already growing  rapidly  from  electric-only  end-uses  such  as  air  conditioning,  data  centres  and appliances, driven by higher incomes, urbanisation and digitalisation. Continued improvements in efficiency standards have played a pivotal role in limiting the impact of this growth on electricity systems and will remain essential in the decade ahead. By 2035, in the HES, efficiency gains in electric appliances, lighting and space cooling save almost 4 000 TWh of  electricity,  helping  to  balance  the  additional  demand  created by further electrification (+2 000 TWh).  At  the  same  time,  the  superior  efficiency  of  electric  technologies  enables substantial energy savings: by 2035, 18 exajoules (EJ) of fuel demand are avoided due to electrification. This includes including 140 billion cubic metres of natural gas, and 3.7 EJ of traditional use of biomass (Figure 2.31).

<!-- image -->

2

Figure 2.31 ⊳ Change in demand for electricity and fossil fuels in the buildings sector in the HES by 2035

<!-- image -->

IEA. CC BY 4.0.

By 2035, the additional electricity demand in the buildings sector due to fuel switching is almost three-times lower than the amount of fuel displaced

Notes: Act. = Activity effect; Elec. = Electrification effect; Eff. = Energy efficiency effect; Other includes both activity and efficiency effects. 'Other end-uses' includes lighting, desalination and data centres. Traditional use of biomass is allocated to cooking in this figure. Electricity demand from EV charging is included in the transport sector.

## 2.6 Industry electrification

The industry sector accounts for nearly 40% of total final  energy consumption globally. 2 Major  fuels  used  in  industry  include  coal  (around  one-third  of  sectoral  consumption), electricity (28%) and natural gas (one-fifth). Direct emissions from the sector are responsible for more than 40% of total emissions from end-uses.

The industry sector has already adopted electric technologies in some processes, with highly efficient  electric  motors  gaining  ground.  However,  the  pace  of  electrification  remains relatively slow, even though there is now scope to electrify almost 40% of fossil fuel-based low- and medium-temperature heat in industry cost-effectively. The growth in the share of electricity in industrial energy consumption in the last decade - from 24% in 2015 to 28% in 2025 - has mostly been driven by activity growth in highly electrified sub-sectors in Asia, rather than by technological shifts. Progress in the next decade will depend on the further deployment  of  electric  technologies  where  it  brings  competitive  advantage,  as  well  as continuing policy support.

2 This  excludes  industry  use  of  energy  commodities  for  non-energy  uses,  such  as  oil  products  for  plastics production.

Figure 2.32 ⊳ Key indicators of industrial production by region in the STEPS, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Advanced economies and China dominate global industrial production today, although production in some sectors, such as urea for fertilisers, is more evenly spread

Note: PPP = purchasing power parity.

Industrial production is dominated today by advanced economies and China, which together account  for  60%  of  global  industrial  value  added  (Figure 2.32).  Trajectories  for  future industrial production differ by product and region. For cement, sharply increasing demand in emerging market and developing economies is just enough to offset the structural decline in  demand  in  advanced  economies  and  China,  stemming  from  the  maturity  of  their infrastructure  stock.  For  other  industrial  products,  such  as  chemicals  and  high-tech equipment,  global  demand  continues  to  grow  strongly.  Overall,  value  added  from  the industry sector increases by almost one-third between 2025 and 2035.

## 2.6.1 Industry technologies

Electricity is used today mainly for motor systems, cooling and lighting, as well as for fully electrified technologies such as aluminium smelters and electric arc furnaces. About threequarters of industrial energy consumption is in the form of heat, of which electricity provides only  about  15%.  Electric  technologies  can  supply  heat  more  efficiently  than  combustion alternatives, but the relative efficiency advantage of electricity drops as the temperature of the heat increases. Around 60% of heat in industry - or close to a quarter of total energy consumption in industry - is consumed at high temperatures , where the relative efficiency 3 of electrical and non-electrical technologies can vary by application (Figure 2.33). Even so, a

3 In  this  report,  high-temperature heat refers to heat consumed above 400 °C, medium-temperature heat refers to heat between 150 °C and 400 °C, and low-temperature heat refers to heat below 150 °C.

2

growing  range  of  high-temperature  processes  can  be  electrified.  Resistance  heating  is already widely used to produce glass, as is induction heating for metals. Electric arc furnaces are the established route for scrap-based steelmaking, and plasma  and emerging rotodynamic  heaters  have  the  potential  to expand  the  range  of  high-temperature applications  that  can  be  electrified. In cement  production,  pre-calcination  and  clay calcination are the nearest-term candidates, with fully electric kilns at an earlier stage. In addition to improving energy efficiency, these technologies can provide faster heating and more precise temperature control.

Figure 2.33 ⊳ Efficiency, energy service demand and operating temperatures of key direct electrification technologies, 2025

<!-- image -->

IEA. CC BY 4.0.

Many different technologies are needed to electrify industry sectors; they do not all offer significant efficiency advantages compared to conventional technologies

Notes:  Emerging  high-temperature  heat  technologies  include  resistance  heaters,  induction  heaters  and rotodynamic heaters. The bubble size reflects non-electrified service demand in 2025. The y-axis shows the efficiency  of  each  electric  technology  relative  to  the  conventional  technology  it  replaces.  Values  above  1 indicate that the electric technology is more efficient than the typically fuel-based alternative providing the same energy service.

## 2.6.2 Industry strategies

The HES sees some of the fastest growth in electrification in uses where electricity offers the largest advantages: energy for non-thermal applications and low-temperature heat. These uses  are  particularly  important  in  non-energy-intensive  industries,  where  the  global electrification rate jumps from 40% to over 50% by 2035 in the HES.

Figure 2.34 ⊳ Electrification rate in industry by region and key industrial subsector in the STEPS and the HES, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Emerging market and developing economies see lower shares of electrification than advanced economies and China, but there are still opportunities for them to electrify

Note:  AE  =  advanced  economies;  EMDE  =  emerging  market  and  developing  economies;  Transp. equip.  = manufactured transportation equipment.

## Electrifying low-temperature heat

For low-temperature heat, industrial heat pumps provide significant efficiency advantages. Adoption rates have been highest in sub-sectors like food, tobacco, pulp and paper, as well as in parts of the chemicals industry (IEA, 2026c). To be competitive, heat pumps need to be deployed in applications that have high utilisation rates; if they are used less frequently, their high upfront cost is not economically justifiable. Increased deployment can help modularise and standardise heat pumps, leading to opportunities to reduce capital costs (McKinsey &amp; Company, 2024).

Heat pumps are already cost competitive compared to gas boilers in regions which together account  for  over  three-quarters  of  global  energy  demand  for  low-temperature  heat (Figure 2.35). The main factors which determine cost-competitiveness are the relative cost of electricity compared to natural gas or coal, financing costs, and (in some applications) the ability  to  provide  cooling  simultaneously.  In  major  energy-producing  regions  like  North America, Eurasia and the Middle East, wide electricity and natural gas price gaps mean heat pumps struggle to compete. In developing Asia, particularly in countries with limited access to gas, heat pumps are more competitive, but high financing costs may act as a disincentive. Heat pumps may also face competition from technologies using coal that is cheaper than gas, although the difficulty of transporting coal and managing air pollution emissions means that coal presents challenges for smaller industrial users.

<!-- image -->

2

Even though heat pumps are competitive in several regions, deployment rates remain low: high upfront costs can be difficult for small and medium-sized enterprises to manage, and technical experience with installing and operating heat pumps may be limited. Competitive projects seeking to use heat pumps can also be delayed by difficulties accessing the grid or the need to upgrade existing grid connections to accommodate the additional load from a heat pump (Box 2.7). Government financial assistance can help address high upfront costs that hinder deployment, while training and knowledge-sharing can help increase technical expertise, as has been demonstrated successfully in New Zealand (IEEFA, 2025).

Figure 2.35 ⊳ Levelised cost of heat from industrial heat pumps and gas boilers by region, 2025

<!-- image -->

IEA. CC BY 4.0.

Heat pumps are competitive for low-temperature heat production in some regions, but not in others including North America, Africa, the Middle East and Eurasia

Notes: MWh = mega watt-hour; C &amp; S America = Central and South America; DAP = Developed Asia Pacific; ME = Middle East. The assumed coefficient of performance for the heat pump is 3.5.

Heat  pumps  can  be  deployed  at  higher  temperatures,  sometimes  using  alternative configurations,  if  a  source  of  waste  heat  is  available.  For  example,  mechanical  vapour recompression (sometimes referred to as an open-cycle heat pump) can be used to upgrade steam at low pressures and redeploy it at higher pressures; this technology has applications in the non-ferrous metals sector and other light industries.

## Box 2.7 ⊳ Low-temperature heat in India

Unlike heavy industries such as steel and cement that require very high temperatures, sectors including dairy, food processing, textiles, pharmaceuticals and beverages rely on hot  water,  low-pressure  steam  and  drying  processes,  making  them  well  suited  to electrification.  This  low-temperature  heat  (below  150 °C)  accounts  for  almost  30%  of

industrial heat demand in India, and its provision offers an important opportunity for electrification and decarbonisation.

India's textile sector is increasingly viewed as one of the most promising candidates for the  electrification  of  low-temperature  heat  because  dyeing,  washing  and  finishing processes typically require temperatures below 170 °C. A recent detailed case study of an Indian textile plant concluded that heat pumps and electric boilers could technically meet most wet-processing heat demand and substantially reduce emissions when paired with renewable electricity (Global Efficiency Intelligence, 2025). Industrial facilities across textile clusters in Gujarat, Rajasthan and Tamil Nadu have already adopted electric waterheating systems and heat-recovery technologies to preheat process water and produce steam, prompted by rising fuel costs and by energy-efficiency programmes supported by India's Bureau of Energy Efficiency.

Innovation efforts are currently focused on steam-generating heat pumps developed by Indian Institute of Technology Madras and Aspiration Energy, which were demonstrated at DCM Shriram's sugar plant in Uttar Pradesh and subsequently deployed at WABCO India for process-heating applications. These examples show the technical feasibility of supplying industrial low-temperature heat using electricity.

## Electrifying mechanical energy supplied today by fuels

Around 9 EJ of the non-thermal energy consumed today in non-energy-intensive industries comes from fuels other than electricity, particularly for operating motors. Electricity has long been the most cost-competitive fuel in these applications,  especially  for  motors:  electric motors are several times more efficient than those powered by diesel or natural gas. There is  particularly strong potential for further electrification of these applications in emerging market and developing economies, which account for half of the global share of non-electric fuels  used  for  non-thermal  applications.  However,  challenges  remain:  conventional  fuels often  continue  to  be  used  in  mechanical  applications  because  electricity  supply  is unavailable, unreliable or expensive.

## Flexibility is key for expanding electrification to a wider range of applications

Above 150 °C, achieving cost parity in baseload operations is more challenging because the efficiency of electric technologies at these temperatures is much closer to the efficiency of conventional technologies. At medium temperatures, however, electric boilers can be used to supply steam, and new approaches to high-temperature heat are also emerging. In the chemicals sector, electricity can replace oil products and gas in supplying process heat for steam cracking; it can also replace them for high-temperature applications in the rest of industry through a range of electric technologies, including resistance heaters, rotodynamic heaters,  arc  furnaces  and  induction  heaters.  Some  of  these  technologies  are  already commonplace - electric arc furnaces and induction furnaces, for instance, produce about 30%  of  crude  steel  by  recycling  scrap.  However,  in  many  cases  these  high-temperature heating technologies are only now being deployed in large-scale trials.

2

For  electrification  to  be  competitive,  technologies  which  operate  at  higher  temperatures generally need the cost of electricity to be close to or less than the cost of the fossil fuel they are replacing. On average, this is not the case in most markets. However, electricity systems with high proportions of renewables are increasingly providing very low-priced wholesale electricity during certain periods. Tapping into this flexibility where technically feasible could change the economics of electrification in this context (Section 2.2.5).

Different  industries  might  achieve  this  flexibility in different ways.  Where  possible, operational processes should be scheduled to correspond to periods of low prices. This could pose technical challenges, particularly for high-temperature processes which in many cases are  likely  to  operate  continuously;  it  could  also  be  commercially  challenging,  particularly where companies have invested in expensive equipment and want to achieve the highest possible  utilisation  rates.  One  alternative  is  hybrid  operation,  where  electric  boilers  are added  to  an  existing  fleet  of  gas  or  coal  boilers.  Thermal  storage  is  also  an  increasingly promising  solution:  it  can  be  used  at  a  wide  range  of  temperatures,  although  highertemperature applications are typically higher cost.

Flexibility is also key for indirect electrification via onsite hydrogen production. 4 In general, even when operating flexibly, indirect electrification using hydrogen is not cost-competitive today (IEA, 2026d). However, in countries with large agriculture sectors reliant on ammonia imports,  particularly  in  parts  of  Asia  and  Africa,  producing  ammonia  from  domestic renewables could be an effective diversification strategy and help protect local industries from price spikes.

## The importance of technology innovation

Further  technology  development  in  support  of  electrification  is  important  in  all  end-use sectors, but it is especially vital in the industry sector. Innovation can help accelerate the uptake of existing or commercially mature technologies by reducing costs and improving performance: for instance, research into thermal fluids could improve the efficiency of heat pumps and increase the temperature range in which they operate. Innovation also plays a crucial role in developing new technologies. Many direct electrification technologies which are deployed in the long term in the HES currently are still not mature. These may still face a particularly challenging phase in the innovation cycle when the scale of investments needed and the length of time before a project can reach the market are both substantial. Policy makers can help by supporting project finance for first-of-a-kind technologies like hydrogenbased direct reduction of iron.

4 In the context of industry, indirect electrification refers to using electricity to produce hydrogen and then using that hydrogen in a process like direct reduction of iron or ammonia production.

## The importance of grid connection processes for industrial electrification

In some markets, a lack of timely and cost-effective access to the grid is a major barrier to  industrial  electrification.  Even  though  other  consumers  of  electricity  like  EVs  and households see greater total growth in electricity demand in the HES than any individual industrial sub-sector, the size of the grid connection required by industrial consumers is much larger than for other sources of demand. For industries in areas where the grid is highly congested, accessing the grid often depends  on operational studies by transmission  system  operators  (TSOs)  or  requires  network  capacity  expansion  and upgrades to meet voltage, power quality and reliability requirements. This introduces risk for capital investments in electrification and can delay connection by several years. Some markets have responded by overhauling their connection processes: in the Netherlands, for instance, end-users that are willing to accept curtailment during periods of peak grid connection can receive faster connection times, and Germany has moved to prioritising connection for consumers by project maturity rather than on a first-come, first-served basis.

Figure 2.36 ⊳ Typical grid connection size and electricity demand growth by key consumers in the HES by 2035, and cost structure in industrial electricity prices

<!-- image -->

Notes: MW = megawatt; TWh = terawatt-hour; EU = European Union; H2-DRI = hydrogen-based direct reduced iron; EVs = electric vehicles; MER = market exchange rate; O&amp;M = operation and maintenance; Capital recovery includes generation and grids; Other costs includes CO2 prices, taxes, subsidies and other surcharges. EV connection capacity represents the average across the global stock of chargers, including residential, fast and ultra-fast chargers.

<!-- image -->

2

Network prices can play a key role in determining the competitiveness of electrification. Generally,  three  types  of  network  charges  are  levied  on  industrial  consumers  of electricity for network access: an upfront charge, sometimes levied if a facility expands the scale of its grid connection; a capacity charge, usually proportional to the maximum power associated with an industrial facility (charged per megawatt [MW]); and a usage charge,  proportional  to  the  amount  of  electrical  energy  consumed  (charged  per megawatt-hour [MWh]). These charges vary within and between networks based on local conditions.  For  flexible  industrial  consumers,  the  relative  contribution  of  network charges to their total energy costs increases, due to their flexibility increasing utilisation of lower wholesale prices (Figure 2.36). The network charges are therefore particularly important for these consumers, and high charges could result in very flexible users paying a substantial amount for a connection they may not use very often. However, setting charges too low can redirect costs to other electricity consumers. TSOs thus need to carefully  calibrate  charges  to  reflect  genuine  constraints  in  the  grids  they  operate. Dynamic network prices are becoming an increasingly effective tool to achieve this goal; transparency and predictability in setting network charges also have a major part to play in reducing the risk of upfront investment in electrification.

<!-- image -->

## Powering electrification

Electricity supply and enabling infrastructure

## S U M M A R Y

- · The global electricity mix has undergone profound change, but electricity generation remains the largest source of energy-related emissions. The share of low-emissions sources rose from 33% in 2015 to 42% in 2025, with renewables and nuclear providing nearly  70%  of  the  increase  in  global  generation.  Annual  solar  photovoltaics  (PV) deployment increased more than tenfold and wind deployment more than doubled over  the  past  decade.  Yet  electricity  generation  still  emits  14 gigatonnes  of  CO₂ annually, and these emissions have yet to peak.
- · Higher electrification would push electricity demand growth to nearly twice the pace of  the  past  decade.  In  the  High  Electrification  Scenario,  electricity's  share  of  final energy  consumption  reaches  35%  by  2035,  driving  an  increase  of  more  than 15 000 terawatt-hours  in  global  electricity  generation,  equivalent  to  nearly  half  of today's  output.  How  this  additional  demand  is  met  has  major  implications  for emissions, fuel use and infrastructure needs.
- · Emissions from electricity generation decline even if the supply mix develops in line with  today's  policy  settings.  In  this  case,  continued  growth  in  solar  PV,  wind  and nuclear allows low-emissions sources to meet all of the additional demand associated with  higher  electrification  in  aggregate.  This  reinforces  the  emissions  reductions achieved in end-uses, although there is additional fossil-fuelled generation in some regions, and the decline in power sector emissions remains limited.
- · Aligning  electricity  supply  with  a  pathway  to  net  zero  by  2050  would  multiply  the emissions  benefits  of  electrification.  Annual  solar  PV  additions  double  to  over 1 200 gigawatts (GW) by 2035, wind additions expand two-and-a-half times to around 400 GW, and nuclear power makes a strong comeback. This enables low-emissions sources to meet all additional demand and displace existing fossil-fuelled generation, bringing much deeper reductions in electricity sector emissions and fuel use.
- · Generation,  grids,  storage,  digital  technologies  and  demand  flexibility  need  to develop together. Global networks reach 115 million kilometres by 2035, expanding around  40%  faster  than  over  the  past  decade  to  connect  new  supply  and  rapidly growing demand. Anticipatory investment, faster permitting, cross-border co-ordination, automation and grid-enhancing technologies can accelerate connections and make better use of existing networks. System flexibility also expands substantially,  with  battery  storage  reaching  around  2 900 GW  and  flexible  electric vehicles, heat pumps, cooling and industrial processes helping to integrate variable renewables, ease congestion and limit curtailment.

<!-- image -->

## 3.1 Introduction

Increased  electrification  means  more  demand  for  electricity,  which  requires  scaling  up electricity generation and reinforcing grids. At the same time, electrified technologies can provide flexibility for the electricity system, helping it to make better use of existing and new generation and grid assets, and potentially moderating some of the additional investment needed to meet this demand growth.

The overall impact of electrification on fuel demand and emissions depends in part on how incremental electricity demand is met. The pace at which low-emissions sources develop will inevitably reflect market conditions, technology readiness, supply chains and - crucially policy  frameworks. As the landscape for low-emissions technologies continues to evolve, there  are  multiple  possible  pathways  for  electricity  supply  to  meet  the  level  of  demand foreseen  in  the  High  Electrification  Scenario  (HES),  and  each  of  these  has  different implications. This chapter explores these issues.

## 3.2 Electricity generation

Meeting the electricity demand growth associated with electrification in the HES will require a faster scale-up of electricity supply. Total global electricity generation grew at around 2.9% per year between 2015 and 2025, but meeting demand in the HES would require it to expand by around 4% per year to 2035, with annual output growth doubling from an average of around 810 terawatt-hours (TWh) over the past decade to around 1 600 TWh in the coming decade. In cumulative terms, this implies increasing annual electricity generation by over 15 000 TWh from 2025 to 2035, and reaching a level of global electricity generation in 2035 that is almost 50% higher than today.

Over the past decade, low-emissions sources have provided the vast majority of growth in global electricity supply, reflecting strong policy support and sustained improvements in cost competitiveness (see Spotlight on the increasing cost-competitiveness of solar PV and wind). Since 2015, low-emissions generation has increased by an average of about 560 TWh per year, with output expanding by 700 TWh per year in the past five years. Solar photovoltaics (PV)  and  wind  have  been  the  largest  contributors  to  low-emissions  growth,  accounting respectively for 45% and 35% of the total since 2015; hydropower (11%), bioenergy (6%) and nuclear power (5%) have contributed the rest. Together, these technologies have met more than two-thirds of the total growth in global electricity generation since 2015. However, coal and natural gas have accounted respectively for 16% and 18% of total generation growth globally over the past decade, and the increase in their use means that electricity sector emissions have yet to peak at the global level.

Over  the  next  decade,  the  global  electricity  generation  mix  will  evolve  in  response  to changing  market  conditions,  policy  frameworks  and  system  needs.  These  factors  will influence the pace at which renewables and nuclear power expand, as well as the extent to which coal, natural gas and oil contribute to electricity supply. There are many possible mixes

that could provide the more than 15 000 TWh of generation growth between 2025 and 2035 in the HES, each with different implications for fuel use, infrastructure needs and emissions in the electricity sector. Three electricity supply cases - built around the electricity mixes of IEA  World  Energy  Outlook  scenarios  -  illustrate  potential  outcomes  (see  Chapter 1  for scenario  definitions).  They  are  analytical  cases  rather  than  projections.  Each  meets  the electricity demand with a different supply mix, and our analysis considers the implications of each for generation, fuel use and emissions (see Chapter 4 for the discussion on emissions in both end-uses and electricity generation).

In all three cases, the growth of low-emissions sources accelerates compared to today. In two of the three cases, all incremental electricity demand is met with low-emissions sources in aggregate. The biggest emission reductions are achieved with the electricity supply mix based  on  the  Net  Zero  Emissions  by  2050  (NZE)  Scenario:  in  this  case,  low-emissions generation not only meets all growth in demand but also displaces a significant amount of current  fossil-fuelled  generation  (Figure 3.1).  Under  the  mix  based  on  the  Stated  Policies Scenario (STEPS), low-emissions sources in aggregate would cover all incremental electricity demand, while the mix based on the Current Policies Scenario (CPS) would cover about 85%, with the remainder provided by fossil fuels.

Figure 3.1 ⊳ Low-emissions generation by electricity supply case relative to growth in total generation in the HES, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Growth in low-emissions generation would have to accelerate for it to meet all of the additional electricity demand by 2035 in the HES

Note: NZE = Net Zero Emissions by 2050 Scenario; STEPS = Stated Policies Scenario; CPS = Current Policies Scenario; TWh = terawatt-hour; HES = High Electrification Scenario.

The following sections introduce and describe each case in more detail.

<!-- image -->

3

## 3.2.1 HES with the NZE mix

The HES with the NZE mix case (referred to below as the NZE mix case) applies to the HES the generation  mix  of  the  Net  Zero  Emissions  by  2050  (NZE)  Scenario,  a  normative  global pathway consistent with limiting global warming to 1.5 °C.

Over the past decade, global low-emissions generation has expanded considerably, even as coal- and gas-fired output has continued to grow in absolute terms. Between 2015 and 2025, coal-fired generation rose by around 1 320 TWh, and natural gas-fired generation grew by around 1 440 TWh. Over the same period, solar PV output increased more than elevenfold, adding almost 2 500 TWh; wind generation more than tripled, adding close to 1 900 TWh; and nuclear power output grew by over 10%, adding over 280 TWh. As a result, the share of low-emissions sources in the mix rose from 33% in 2015 to 42% in 2025. This was driven by a rapid  scale-up  in  deployment:  annual  solar  PV  capacity  additions  increased  from 56 gigawatts (GW) in 2015 to nearly 630 GW in 2025, while annual wind additions grew from 66 GW to close to 160 GW.

Over the next decade, growth in global low-emissions generation far exceeds rising electricity demand  in  the  NZE  mix  case.  Growth  in  solar  PV  and  wind  power  alone  exceeds  total electricity generation growth to 2035, and hydropower and nuclear generation also rise. As a  result,  the  aggregate  growth  in  low-emissions  generation  exceeds  the  increase  in  total generation, and fossil-fuelled generation enters a steep decline. Solar PV generation grows sixfold  from  around  2 700 TWh  in  2025  to  more  than  16 000 TWh  by  2035,  retaining  its position as the largest source of growth; wind generation more than quadruples to nearly 12 000 TWh; nuclear generation grows by roughly 2 000 TWh, and hydropower by around 1 300 TWh. Coal-fired generation falls by roughly 7 800 TWh, or around 70%, between 2025 and 2035, more than reversing the growth of the past four decades; gas-fired generation falls by around 4 000 TWh, or close to 60%. The share of low-emissions sources in total generation rises to almost 90% by 2035.

Achieving the scale of expansion of low-emissions sources seen in the NZE mix case requires annual additions of solar PV, wind and nuclear to reach levels well above those currently being achieved (Figure 3.2). Annual solar PV additions double from the level seen in 2025 to over 1 200 GW by 2035, building on the momentum of the past decade. Wind additions accelerate even more sharply, increasing two-and-a-half times to around 400 GW a year, with both onshore and offshore segments contributing. Nuclear power is already making a comeback: despite the downward trend in annual additions in recent years, nearly 90 GW of nuclear  capacity  was  under  construction  globally  in  July  2026,  the  highest  level  in  over 30 years. Even so, a sustained increase in new project development and construction starts is needed to raise annual nuclear capacity additions from around 3 GW today to more than 40 GW by 2035 in the NZE mix case.

Achieving these deployment rates will depend not only on investment in new capacity, but also  on  the  ability  to  connect  new  projects  to  the  grid  in  a  timely  manner.  Lengthy  and complex procedures, overlapping administrative requirements and limited capacity within

permitting authorities  are  already  delaying  some  projects  and  raising  their  costs.  Clearer timelines, greater digitalisation, better co-ordination between authorities and streamlined permitting processes will be essential if deployment is to be accelerated. The importance of such reforms is increasingly recognised in places such as Australia, Europe and India, which have been taking steps to simplify and accelerate permitting for renewable energy projects, while recent reforms in Canada and the United States aim to make nuclear licensing more efficient, timely and predictable. Canada has also released a Nuclear Energy Strategy, which aims to accelerate nuclear deployment  through clear build targets and improved co-ordination.

Figure 3.2 ⊳ Capacity additions and change in electricity generation by source in the HES with the NZE mix case, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Growth in low-emissions supply exceeds the increase in electricity demand, and coal- and gas-fired generation falls sharply by 2035

Notes:  GW  =  gigawatt;  PV  =  photovoltaics.  Other  renewables  include  bioenergy  and  renewable  waste, concentrating solar power, geothermal and marine. Other includes non-renewable waste and other sources.

Over  the  past  decade,  low-emissions  generation  has  met  the  majority  of  new  electricity demand,  complemented  by  natural  gas  and  coal,  although  in  different  proportions  in different  regions.  Between  2015  and  2025,  low-emissions  sources  grew  by  one-third  in advanced economies, and by around two-thirds in other emerging market and developing economies,  while  almost  tripling  in  China  (Figure 3.3).  At  the  same  time,  coal-fired generation decreased by 40% in advanced economies, but increased by more than 40% in both China and other emerging market and developing economies; and gas-fired generation grew  by  around  20-25%  in  both  advanced  economies  and  other  emerging  market  and developing  economies,  while  it  more  than  doubled  in  China.  Overall,  the  share  of low-emissions sources in generation rose from 41% to 52% in advanced economies between

3

2015 and 2025, from 27% to 41% in China and from 27% to 32% in other emerging market and developing economies.

In the NZE mix case, electricity generation grows by around 70% in other emerging market and developing economies between 2025 and 2035, compared with roughly 40% in advanced economies  and  China,  reflecting  stronger  demand  growth  in  relative  terms  across  these economies. However, low-emissions generation expands even more rapidly than demand for electricity. Solar PV output in other emerging market and developing economies grows close to twelvefold, and wind almost ninefold; while in advanced economies and China, solar PV grows roughly fivefold and wind fourfold. As a result, the share of low-emissions sources rises above 90% by 2035 in advanced economies and China, and to nearly 80% in other emerging market and developing economies.

Figure 3.3 ⊳ Electricity generation by regional grouping in the HES with the NZE mix case, 2015-2035

<!-- image -->

Low-emissions sources dominate the generation mix in both regional groupings by 2035

Notes:  EMDE  =  emerging  market  and  developing  economies.  Other  renewables  include  bioenergy  and renewable waste, concentrating solar power, geothermal and marine. Other includes non-renewable waste and other sources.

In the NZE mix case, coal-fired generation falls sharply by 2035 in both regional groupings, dropping by more than three-quarters in advanced economies and China, and by around 60% in  other  emerging  market  and  developing  economies.  Over  the  same  period,  gas-fired generation falls by more than 80% in advanced economies and China, and by a quarter in other emerging market and developing economies. Together, coal and gas account for less than 10% of electricity generation in advanced economies and China in 2035, and about 20% in other emerging market and developing economies, with the remaining coal and gas plants mainly providing flexibility, seasonal balancing and backup power rather than bulk electricity.

Globally, this reallocation of generation from fossil fuels to low-emissions sources drives a sharp fall in power sector fuel demand and emissions intensity in the NZE mix case. Between 2025 and 2035, low-emissions generation grows by almost 29 000 TWh, far outpacing the over 15 000 TWh increase in total generation. This leads to a reduction from 2025 levels in demand for natural gas in power generation of around 900 billion cubic metres (bcm), or around 60%; and to an even bigger reduction in coal demand of over 2 600 million tonnes of coal equivalent (Mtce), or more than 70% (Figure 3.4).

Figure 3.4 ⊳ Natural gas demand and coal demand for electricity generation in the HES with the NZE mix case, 2025 and 2035

<!-- image -->

Note: bcm = billion cubic metres; Mtce = million tonnes of coal equivalent.

As a result of the changes in the electricity generation mix, the global average emissions intensity  of  electricity  generation  falls  from  around  440 grammes  of  carbon  dioxide  per kilowatt-hour (g CO2 per kWh) in 2025 to just over 70 g CO2 per kWh by 2035 in the HES with the  NZE  mix  case.  By  comparison,  modern  natural  gas-fired  power  plants  typically  emit around 450 g CO₂ per kWh, while coal-fired units emit around 950 g CO₂ per kWh. Despite the substantial increase in electricity generation, total emissions from the sector fall from 14 gigatonnes (Gt) of CO₂ in 2025 to 3.5 Gt  in  2035,  a  reduction  of  75%,  complementing emissions reductions in end-use sectors (see Chapter 4).

<!-- image -->

3

## S P O T L I G H T

## The increasing cost-competitiveness of solar PV and wind

The falling costs of solar PV and wind power have played an important part in their rapid expansion. This decline is most readily visible in the levelised cost of electricity (LCOE), a measure  that  spreads  the  total  cost  of  building  and  running  a  power  plant  over  the electricity it generates across its economic lifetime, compressing decades of development and operating costs into a single metric. The LCOEs shown represent only the technology costs and do not include any financial subsidies.

Since 2010, the LCOE has fallen by 90% for solar PV and 70% for wind power. The costs of battery storage have also fallen by 90% over the last 15 years, making battery storage an important pairing for solar PV in particular. The LCOEs for these technologies have been driven down by innovation, better manufacturing and economies of scale. In most regions, the LCOE of wind and solar PV now sits well below that of conventional coal- or gas-fired plants. Between 2025 and 2035, costs are projected to fall by a further 40% for solar PV, 35% for batteries and 10% for onshore wind.

Assessing  the  competitiveness  of  power  technologies,  especially  those  with  different operating characteristics, requires looking beyond the LCOE alone and taking account of the value each technology contributes to the power system. The value-adjusted levelised cost of electricity (VALCOE), developed for the IEA Global Energy and Climate Model, does this by combining the generation cost of a technology with its simulated value to the system in terms of energy, capacity and flexibility. As such, it is a more complete metric of competitiveness. The VALCOE  for individual technologies can enable comparisons with system average generation costs as an indicator of affordability and can be complemented by comparisons of total system costs, including those published in the  World  Energy  Outlook  (IEA,  2025a).  However,  the  VALCOE  does  not  assign  grid expansion costs to individual technologies and does not include emissions that are not priced in markets.

Solar PV and wind operate differently from traditional sources of electricity, including coal-  or  gas-fired  power  plants.  Their  output  varies  with  weather  conditions,  which means that their annual capacity factors, availability during critical times and ability to adapt to system needs tend to be lower than those of conventional plants. The value of solar PV and wind depends on their output profile relative to demand, the type and cost of other sources in the system and the availability of sources of flexibility. It also depends on the extent of the cannibalisation effect, which occurs when simultaneous output from many solar PV or wind projects puts downward pressure on wholesale electricity prices and, in turn, reduces the market value of those projects. This effect is already evident in several  markets,  where  growing  renewable  output  is  contributing  to  an  increasing number of hours with very low or negative prices (IEA, 2026).

Despite these effects, solar PV and wind are still among the most competitive power technologies  in  major  markets  today,  based  on  the  VALCOE.  New  solar  PV  is  more

competitive than gas or coal in the European Union today, and on a par with new coalfired power in China (Figure 3.5). Onshore and offshore wind power are also competitive with coal- and gas-fired power in those two major markets.

Figure 3.5 ⊳ LCOE and VALCOE of selected power technologies in selected regions, 2025

<!-- image -->

Solar PV and wind are competitive with dispatchable sources in major markets today

Notes: LCOE = levelised cost of electricity; VALCOE = value-adjusted levelised cost of electricity. MWh = megawatt-hour; MER = market exchange rate. 4-hr refers to battery storage duration. Battery storage is assessed at 20% of the level of solar PV capacity, e.g. 100 MW of solar PV plus 20 MW/80 MWh of battery storage. 24/7 refers to the ability to provide power in all hours of the day and all week. Availability factor is the share of nameplate capacity that can be reliably expected to generate electricity during times of peak demand. While VALCOE incorporates flexibility, energy and capacity values, it does not assign grid expansion costs to individual technologies and does not include emissions that are not priced in markets.

Combining solar PV with battery or other forms of storage can increase its system value and  its  services,  principally  by  shifting  electricity  from  periods  of  abundant  solar

<!-- image -->

3

generation to periods of higher demand. This combination can become more competitive than standalone solar PV once the additional value provided by greater dispatchability outweighs the cost of the battery. However, batteries have a limited duration, meaning that such a configuration cannot provide constant output through prolonged periods. Solar PV combined with four-hour storage therefore offers greater dispatchability and a broader range of system services than solar PV alone but remains different from a fully dispatchable plant with continuous availability.

A hybrid portfolio combining solar PV, wind and battery storage is another option, and can supply electricity around the clock at a cost that is increasingly comparable to that of dispatchable  power  plants  such  as  coal  and  gas  (IEA,  2025b).  The  LCOE  from  such  a portfolio currently ranges from around USD 80 per megawatt-hour (MWh) in China to around USD 120/MWh in the European Union. Ensuring reliability requires oversizing the system relative to its firm output and adding storage to manage weather variability. To deliver  100 megawatts  (MW)  of  firm  capacity,  for  example,  a  project  might  combine 400 MW  of  solar  PV,  200 MW  of  onshore  wind  and  300 MW/1 200 MWh  of  battery storage. However, such a system will generate substantial surplus electricity above the guaranteed  100 MW,  and  this  surplus  can  be  used  for  a  variety  of  purposes. Such configurations are beginning to emerge in practice, including to power mining operations in remote locations.

Renewables targets, competitive auctions and streamlined permitting frameworks are now  in  place  across  most  major  electricity  markets.  By  2025,  124  countries  had established national targets for renewable electricity (REN21, 2026). However, barriers still constrain how fast renewables and other low-emissions sources can scale up, and they need to be overcome to realise the significant increase in the pace of deployment described in the HES with the NZE mix. The constraints include:

-  Grid  infrastructure  -  with  the  planning  and  delivery  of  new  and  modernised infrastructure failing to match the pace of demand growth arising from increased electrification in many regions (see Section 3.3). The required investment in grids is also an important factor in the affordability of electrification (see Chapter 4).
-  Policy  and  regulatory  frameworks  -  with  market  designs  in  many  countries  still reflecting a generation mix based primarily on conventional dispatchable technologies, and not yet adequately rewarding the technologies and solutions, such as  battery  storage  and  demand  response,  that  provide  the  flexibility  and  system services needed to integrate high shares of variable renewables (IEA, 2025c).
-  Finance - with many emerging market and developing economies lacking access to affordable  finance  for  investments  in  power  generation,  storage  and  grids  (IEA, 2023).

Addressing these challenges cost-effectively requires investment in demand response and other forms of demand-side flexibility alongside investment in generation, storage and grids (see Spotlight on demand flexibility in Chapter 2).

## 3.2.2 HES with the STEPS mix

The HES with the STEPS mix is a case (referred to below as the STEPS mix case) that applies the generation mix of the Stated Policies Scenario (STEPS), an exploratory scenario reflecting the prevailing direction of travel of today's policies.

Over the past decade, global low-emissions generation has expanded considerably, though not enough to cover all new demand. Policies already in place or under serious discussion point to this trend coming to an end, and to low-emissions sources in aggregate meeting all growth in electricity demand to 2035. With the STEPS mix, growth for solar PV, wind and nuclear power together accounts for 90% of growth in total generation in the HES between 2025  and  2035  (Figure 3.6).  Solar  PV  output  quadruples  to  over  10 700 TWh,  and  wind generation  increases  by  around  two-and-a-half  times  to  roughly  7 300 TWh.  Nuclear generation  rises  by  over  1 250 TWh,  and  hydropower  by  nearly  1 250 TWh.  Gas-fired generation increases by around 2 000 TWh to 2035, but this is balanced by a reduction in coal-fired generation of roughly the same amount. The share of low-emissions sources in the mix rises from 42% in 2025 to over 60% by 2035.

Figure 3.6 ⊳ Capacity additions and change in electricity generation by source in the HES with the STEPS mix case, 2015-2035

<!-- image -->

Solar PV, wind and nuclear account for most of the growth in generation to 2035. Gas-fired generation also increases while coal-fired generation declines.

Notes:  GW  =  gigawatt;  PV  =  photovoltaics.  Other  renewables  include  bioenergy  and  renewable  waste, concentrating solar power, geothermal and marine. Other includes non-renewable waste and other sources.

Annual capacity additions of solar PV, wind and nuclear power all rise above 2025 levels, though by less than in the NZE mix. Solar PV additions increase by around 20% to roughly 750 GW a year by 2035, a considerably slower rate of growth than over the past decade.

3

Wind additions rise by one-quarter to over 190 GW a year, continuing to expand as they have over the past decade. Nuclear capacity additions increase more sharply in relative terms, rising more than tenfold from the subdued pace of 2025 to reach around 35 GW a year by 2035.

Figure 3.7 ⊳ Electricity generation by regional grouping in the HES with the STEPS mix case, 2015-2035

<!-- image -->

Low-emissions sources reach nearly 70% of generation in advanced economies and China and close to 50% in other emerging market and developing economies by 2035

Notes:  EMDE  =  emerging  market  and  developing  economies.  Other  renewables  include  bioenergy  and renewable waste, concentrating solar power, geothermal and marine. Other includes non-renewable waste and other sources.

Between 2025 and 2035, total generation expands by 40% in advanced economies and China, and by around 60% in other emerging market and developing economies. Solar PV is the fastest-growing  source  in  both  regional  groupings  and  wind  power  among  the  fastest growing. In advanced economies and China, solar PV output grows by around three-and-ahalf  times,  and  wind  by  around  two-and-a-half  times;  in  other  emerging  market  and developing economies, solar PV grows roughly sixfold, and wind more than triples. However, while coal-fired generation falls by around 30% in advanced economies and China, it rises slightly  in  other  emerging  market  and  developing  economies.  While  gas-fired  generation remains broadly stable in advanced economies and China, it increases by around 60% in other emerging market and developing economies. Oil demand for electricity generation continues to decline from its already low level, though small island systems face particular difficulties in shifting away from oil use (see Spotlight on meeting electrification needs in small island states). Overall, combined coal- and gas-fired generation declines by around 20% in advanced economies and China after rising by 12% over the past decade, while it grows by

one-third  in  other  emerging  market  and  developing  economies,  continuing  the  pace  of recent growth. The net result is that the share of low-emissions sources rises from 47% in 2025 to nearly 70% by 2035 in advanced economies and China, and from 32% to close to 50% in other emerging market and developing economies (Figure 3.7).

Although  growth  in  low-emissions  generation  of  over  15 000 TWh  broadly  matches  the increase in total generation, there is a significant shift in the STEPS mix within remaining fossil generation away from coal and oil and towards gas. By 2035, this shift leads to an increase in power sector natural gas demand of around 300 bcm, or around 20%, and to a reduction in coal demand of around 800 Mtce, or around 20% (Figure 3.8). Oil demand for the power sector also declines globally.

Figure 3.8 ⊳ Natural gas demand and coal demand for electricity generation in the HES with the STEPS mix case, 2025 and 2035

<!-- image -->

Meeting the 2035 HES demand with the STEPS mix would increase the use of natural gas in the power sector by around 300 bcm, while decreasing coal use by around 800 Mtce

As a result, the global average emissions intensity of electricity generation in the STEPS mix falls  from  about  440 g CO2  per  kWh  in  2025  to  around  250 g CO2  per  kWh  by  2035.  The decline in intensity more than offsets the effect of higher electricity output, lowering total emissions from electricity generation by 15% over the period.

<!-- image -->

3

## S P O T L I G H T

## Meeting electrification needs in small island states

Small island systems are seeing a rise in electricity demand driven by tourism, commercial activity, cooling needs, desalination and the gradual electrification of end-uses. However, they face specific challenges in meeting this demand due to their size, limited economies of scale, geographic isolation and - in most cases - reliance on imported fossil fuels. As price takers in international fuel markets, islands are exposed to volatile fuel prices, high transport costs and supply-chain disruptions that affect both power generation and enduse sectors.

Across  the  small  island  systems  we  have  analysed,  oil  remains  the  largest  source  of electricity generation, although its share of generation has declined by around 20% over the  past  decade  (Figure 3.9).  Over  the  same  period,  gas  generation  has  increased  by around 45% and coal use has doubled, while remaining limited in absolute terms. Coal use has been supported by rising imports, while the growth in gas generation reflects domestic oil and gas production in Cuba, Papua New Guinea, and Trinidad and Tobago. The  rest  of  the  selected  islands  are  net  importers  of  fossil  fuels.  Solar  PV  and  wind generation  has  been  growing  steadily,  while  the  use  of  biofuels  and  hydro  has  been broadly stable.

Figure 3.9 ⊳ Electricity generation mix by technology and share of energy supply by source in selected islands, 2015-2024

<!-- image -->

Islands remain highly dependent on importing fossil fuels,

despite gradual growth in renewables for the power sector over the past decade

Note: Data included in this figure are for Cook Islands*, Cuba, Curaçao, Dominican Republic, Fiji*, French Polynesia*, Haiti, Jamaica, Kiribati*, Mauritius, New Caledonia*, Palau*, Papua New Guinea*, Samoa*, Solomon Islands*, Tonga*, Trinidad and Tobago, and Vanuatu*. Data is estimated for entries denoted with an asterisk (*).

In recent years, islands have been prioritising energy security, reliability, resilience and affordability,  while  also  seeking  to  reduce  their  exposure  to  imported  fuel  costs  and supply  disruptions  where  practicable.  Policy  efforts  are  focused  on  reducing  diesel dependence  and  energy  costs  while  achieving  energy  autonomy  or  increasing  selfsufficiency  through renewable electricity targets, fuel diversification, electrification  of end-uses and energy efficiency measures. Electrification can strengthen energy security in islands if accompanied by accelerated deployment of local renewable sources, storage and more resilient power systems. Many islands are also seeking concessional finance and international support to fund clean energy infrastructure.

Achieving these objectives comes with certain challenges. Many islands operate small and relatively isolated grids with limited or no interconnection, low system inertia and few  options  to  balance  supply  and  demand  across  a  wider  network.  This  can  make reliability difficult to maintain, especially when demand fluctuates seasonally. In systems historically designed around diesel or fuel oil units, conventional generators often need to remain online to provide capacity reserves, balancing services, voltage control and frequency  stability,  even  when  renewable  generation  is  available.  This  may  limit  the amount  of  solar  PV  and  wind  that  can  be  integrated  and  can  contribute  to  rising curtailment where storage and grid flexibility are not yet sufficient. Additional challenges include limited land availability, competition between utility-scale and rooftop solar PV, the  difficulty  of  developing  demand-side  flexibility,  and  the  growing  vulnerability  of power infrastructure to extreme weather and climate impacts.

There  is  no  single  way  forward  for  a  set  of  islands  with  different  characteristics  and energy systems which range from interconnected island grids to isolated grids and minigrids.  However, many islands are now moving from diesel generation towards hybrid systems  that  combine  local  renewable  resources  with  storage  units  such  as  pumped hydro  and  batteries.  While  small  grids  have  limited  capacity  to  balance  diverse  and intermittent sources of power, higher shares of renewables can be supported through technologies such as solar-battery mini-grids, hybrid renewable systems, smart controls and  grid-forming  battery  storage.  These  technologies  can  be  complemented  where needed  by  synchronous condensers, dynamic reactive-power support, upgraded protection and black-start capability.

El Hierro in the Canary Islands illustrates both the potential and the complexity of island power transitions. The island uses a hybrid system of wind and pumped hydro while keeping diesel plant available as backup. This hybrid system has facilitated the use of renewables  in  an  isolated  island  grid  and  made  possible  extended  periods  of  100% renewable electricity supply. This case shows not only that high renewable shares are technically  possible  in  small  island  systems,  but  also  that  storage,  system  operation, backup capacity and careful balancing remain central to maintaining reliability.

<!-- image -->

3

## 3.2.3 HES with the CPS mix

The HES with the CPS mix case applies the generation mix of the Current Policies Scenario (CPS), an exploratory scenario anchored solely in measures already enacted in law, with no new policies assumed.

With the CPS mix, renewables and nuclear power account for the majority of the additional generation in the HES  to 2035, complemented  by  growth  in  gas-fired generation (Figure 3.10).  Solar  PV  generation  grows  by  around  three-and-a-half  times  to  roughly 10 000 TWh,  while  wind  generation  grows  by  around  two-and-a-half  times  to  about 7 000 TWh. Nuclear generation increases by around 1 200 TWh, and hydropower by a similar amount. Coal-fired generation falls slightly over the period, while gas-fired generation grows by around 2 700 TWh. The share of low-emissions sources in the mix rises from 42% in 2025 to around 55% by 2035.

Figure 3.10 ⊳ Capacity additions and change in electricity generation by source in the HES with the CPS mix case, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Solar and wind capacity continues to grow at roughly the current pace. Solar PV and wind provide most additional generation to 2035, but gas-fired generation also rises substantially.

Notes:  GW  =  gigawatt;  PV  =  photovoltaics.  Other  renewables  include  bioenergy  and  renewable  waste, concentrating solar power, geothermal and marine. Other includes non-renewable waste and other sources.

Under the CPS mix, annual solar PV capacity continues to grow roughly at the current pace until 2035, while wind additions rise by around 5% from their 2025 level to roughly 170 GW a year. Nuclear capacity additions increase from around 3 GW to close to 35 GW a year.

In  the  CPS  mix  case,  low-emissions  generation  continues  to  expand  in  both  regional groupings. Total generation grows by over 60% in other emerging market and developing economies between 2025 and 2035, compared with 45% in advanced economies and China

(Figure 3.11). Solar PV and wind remain the fastest-growing sources: in advanced economies and China, solar PV output more than triples, and wind more than doubles; in other emerging market  and  developing  economies,  solar  PV  grows  around  fivefold  and  wind  generation roughly triples, though gas-fired generation grows the most in absolute terms.. The share of low-emissions sources rises from 47% to around 65% in advanced economies and China, and from 32% to around 45% in other emerging market and developing economies.

Figure 3.11 ⊳ Electricity generation by regional grouping in the HES with the CPS mix case, 2015-2035

<!-- image -->

The low-emissions share of generation rises in both regional groupings, but coal and gas continue to provide most of the electricity in other EMDE in 2035

Notes:  EMDE  =  emerging  market  and  developing  economies.  Other  renewables  include  bioenergy  and renewable waste, concentrating solar power, geothermal and marine. Other includes non-renewable waste and other sources.

Coal-fired generation declines by about 5% between 2025 and 2035 in advanced economies and China. It rises by over 15% in other emerging market and developing economies, which marks a significant slowdown from its growth of around 40% in those countries between 2015  and  2025.  Gas-fired  generation  continues  to  increase  in  both  regional  groupings, although at very different rates. In advanced economies and China, it rises by around 15% to 2035,  compared  to  about  25%  over  the  past  decade.  In  other  emerging  market  and developing economies, it increases by around two-thirds, growing three times as fast as it did over the past decade. Overall, these trends continue the geographical shift seen over the past  decade,  with  growth  in  fossil  fuel  generation  increasingly  concentrated  in  other emerging market and developing economies, and with a transition in both regional groupings from coal towards natural gas.

Growth in low-emissions generation of around 14 000 TWh to 2035 meets about 85% of increase  in  total  generation,  so  some  of  the  increase  has  to  be  met  through  fossil  fuel

3

generation. While coal demand declines by around 5% (170 Mtce), demand for natural gas in the power sector rises by 430 bcm between 2025 and 2035 - an increase of around 30% (Figure 3.12).

Figure 3.12 ⊳ Natural gas demand and coal demand for electricity generation in the HES with the CPS mix case, 2025 and 2035

<!-- image -->

The  global  average  emissions  intensity  of  electricity  generation  consequently  falls  from around 440 g CO₂ per kWh in 2025 to 290 g CO₂ per kWh in 2035. However, the reduction in intensity is offset by higher electricity generation, leaving total emissions virtually unchanged at around 14 Gt of CO₂ in 2035 .

## 3.3 Grids

Electricity grids risk becoming a central constraint on how far and how fast electrification can proceed. Networks of overhead lines, underground cables, transformers, substations and many other components have to work together to deliver electricity to consumers at all times. Electrification raises the stakes on both sides of the system. On the demand side, electric vehicles (EVs), heat pumps, industrial equipment, data centres and other new loads need timely connections and sufficient local network capacity. On the supply side, new solar PV, wind, storage and other power plants also need grid access to meet rising electricity demand. If grid expansion and modernisation fail to deliver what is needed, new generation and  loads  will  be  delayed  in  connection  queues,  congestion  and  curtailment  will  rise, electrification will be slowed, and ultimately costs for consumers will increase.

The challenge extends beyond building more high-voltage transmission lines, which remain essential  to  move  electricity  long  distances  from  power  plants  to  demand  centres,

interconnect regions with complementary resources and demand patterns, deliver electricity directly to large industrial users and help strengthen resilience. Lower-voltage distribution networks, which account for the majority of installed lines today, are also critical to deliver power to households, businesses and smaller industrial users. Electrification brings these distribution grids to the centre of the electricity security challenge. They need to be able to accommodate higher peak loads, bidirectional flows from rooftop solar PV and batteries, and more variable consumption patterns from EV charging, heat pumps and data centres. In some countries, they also need to connect millions of households and businesses for the first time. As new lines are particularly capital-intensive, the buildout of grids is an important part of the affordability discussion for electrification (see Chapter 4, Section 4.4).

## 3.3.1 Grid expansion in the High Electrification Scenario

Global electricity networks today stretch more than 85 million kilometres (km), with around 80 million km in distribution networks and over 5 million km in transmission networks. They have  expanded  by  around  30%  over  the  past  decade,  extending  their  length  by  around 20 million km. This expansion has created nearly 2 million km of new distribution lines each year on average, together with nearly 150 000 km of new transmission lines, not including replacement  lines.  In  regions  such  as  sub-Saharan  Africa,  much  of  this  new  distribution network in recent years has delivered electricity to communities for the first time, expanding electricity access.

Figure 3.13 ⊳ Average annual grid expansion in the HES with the NZE mix, 2015-2025 and 2025-2035

<!-- image -->

Advanced economies and China Other EMDE with access gaps Other EMDE with full access

IEA. CC BY 4.0.

Grids expanded by 2 million km each year in the past decade: a pace that increases by 40% to 2035 in the HES

Note:  km  =  kilometre;  EMDE  =  emerging  market  and  developing  economies;  full  access  =  regions  with electricity access rates of over 90%.

3

In  the  HES,  the  pace  of  grid  expansion  accelerates  further,  driven  primarily  by  increasing electricity demand and, to a lesser degree, the connection and integration of new variable renewables. By 2035, global grids reach around 115 million km in the NZE mix, with annual grid  expansion  around  40%  faster  than  over  the  past  decade  (Figure 3.13).  As  electricity demand is the main driver of grid expansion, this expansion is only modestly higher than in other electricity supply cases. The scale of the grid expansion in the HES reflects the need to size transmission and distribution assets to accommodate peak demand.

Advanced economies and China accounted for 30% of grid expansion over the past decade, adding  an  annual  average  of  over  half  a  million  new  kilometres  in  distribution  networks alone,  with  another  65 000  new  kilometres  in  transmission  networks.  Today,  advanced economies and China account for around half of the total length of grids worldwide. Grid expansion in these countries accelerates further through to 2035 in the NZE mix, accounting for over 40% of global grid growth, with an average of 1 million new kilometres added each year to distribution networks and a near-tripling of the current level of annual transmission expansion.  In  advanced  economies,  this  reflects  a  return  to  stronger  electricity  demand growth with the electrification of end-use sectors, along with the need to modernise ageing networks. In China, it reflects continued demand growth and the rapid deployment of new generation.

Other emerging market and developing economies with full access- including those with electricity  access  rates  of  over  90%  -  accounted  for  60%  of  grid  expansion  over  the  past decade. They are responsible today for nearly half of all grids worldwide - over 35 million km in total - and they provide half of the new kilometres added globally to grids through to 2035 in the NZE mix, including an average of over 1 million km of new distribution grids each year. This increase is mainly driven by rising demand for electricity and growing electrification of end-uses.

Other emerging market and developing economies with access gaps - including parts of subSaharan Africa and Southeast Asia - account for a smaller but still significant part of the growth in electricity networks. Over the past decade, they have added more than 150 000 km of new grids each year, or about 10% of the global total, mostly in lower-voltage distribution networks. Despite this strong growth, they still account for only 5% of total grid lines today. Grids in these economies expand at twice the historical rate through to 2035, adding an average of 300 000 km of new lines each year. This expansion is driven by growing electricity demand from a wide range of  sources  and  includes  significant  expansion  of  low-voltage distribution to support access to electricity for those who still lack it.

## 3.3.2 Grid lead times and implementation challenges

Grids are increasingly recognised by governments, regulators and industry players as a core enabler of electrification. This has prompted higher investment, regulatory and permitting reforms, and new manufacturing investment in a number of markets. However, more action is required if grids are to expand through to 2035 in line with the needs of the HES. Increasing electrification requires grids to be planned, permitted and delivered early enough to connect new generation and serve rising demand, but many grid projects face long lead times.

Major transmission projects are inherently complex: high-voltage lines can extend across hundreds of kilometres and involve multiple jurisdictions, public authorities, landowners and other stakeholders. Before construction can begin, route studies, environmental assessments, public consultations, land-use agreements and technical approvals may take several years. As a result, major grid projects can require 5-13 years to plan, permit and complete, compared with 1-5 years for renewable power projects and less than two years for EV charging infrastructure (Figure 3.14).

Figure 3.14 ⊳ Typical development time for electricity grids, solar PV, wind and EV charging stations

<!-- image -->

IEA. CC BY 4.0.

Electricity grid deployment is complex, involves many stakeholders and can take many years, which makes planning critical to support clean energy transitions

Notes: Ranges reflect typical projects commissioned in the last five years. Distribution line = 1-36 kV overhead line; transmission is split between high-voltage line = 36-220 kV overhead line and extra-high-voltage line = 220-765 kV overhead line. To date, India has not deployed offshore wind projects.

Distribution  lines  generally  have  shorter  development  periods  than  major  transmission projects,  but  delivery  can  still  be  complex  and  costly.  This  is  particularly  true  in  densely populated urban areas, where limited space, underground construction, traffic disruption, utility crossings and  co-ordination  with  local authorities can  delay implementation. Concentrated demand from charging hubs and hyperscale data centres, rising peak loads and increasingly bidirectional power flows are placing additional strain on networks that often still lack real-time visibility, automated control and the digital capabilities needed to make full use of demand-side flexibility (see Chapter 2).

Where  grid  connections  are  challenging  or  slow  to  develop,  streamlined  permitting  and administrative procedures for new generation can materially shorten project development timelines  and  accelerate  renewable  deployment,  particularly  for  distributed  resources. Where permitting requirements are simplified or removed,  projects can move from predevelopment  to  commissioning  in  months  rather  than  years.  Türkiye's  licence-exempt

3

framework  illustrates  this  effect.  It  allows  consumers  to  generate  electricity  without  a generation licence when output primarily serves their own demand and settles generation against consumption through hourly metering. Facilities can be located either at the point of consumption or elsewhere, with surpluses injected into the distribution system while deficits supplied from the grid under the applicable tariff. This flexibility is important for industrial consumers, including hard-to-abate sectors with limited land or rooftop space. It enables projects to be developed where resource conditions are more favourable while offsetting generation against demand at main production sites. Installed renewable capacity under the mechanism increased from almost zero in 2014 to around 23 GW in 2024, almost entirely solar PV, equivalent to nearly 20% of Türkiye's total installed power capacity.

## Box 3.1 ⊳ Hyperscale data centres are reshaping grid planning and operation

The rapid growth of hyperscale data centres creates challenges that differ from those of most  conventional  electricity  loads.  Individual  campuses  can  require  hundreds  of megawatts  of  power  or  more,  often  clustered  geographically,  and  can  move  from announcement to operation in two to three years. Major network reinforcements usually take  much longer than this to plan,  permit  and  build.  This  mismatch,  combined  with uncertainty  over  which  projects  will  materialise,  complicates  forecasting  and  grid planning.

Data centres also require highly reliable, near-continuous power. Buying in renewables can make an important contribution, but meeting demand securely requires a portfolio of generation, storage, grid capacity and flexibility rather than individual sources alone. If the resources implied by this portfolio do not expand in parallel, rapid load growth risks increasing adequacy  pressures and prolonging reliance on existing dispatchable generation. Co-location with generation and behind-the-meter supply could accelerate the  availability  of  power  supply,  but  it  raises  questions  over  transmission  access, reliability responsibilities and cost allocation. Large data centres can also affect stability: multiple  facilities may  transfer  rapidly  to  batteries  or  backup  generation  during disturbances, causing sudden demand reductions. In the light of these issues, regulators are considering connection charges, minimum payments and stranded-asset protections to reduce the risk that the costs of grid investments triggered by very large loads are shifted to other consumers.

At the same time, data centres can become active grid resources. Selected computing workloads  can  be  shifted  in  time  or  from  one  location  to  another,  while  batteries, uninterruptible  power  supplies  and  on-site  generation  can  reduce  grid  withdrawals, potentially  provide  ancillary  services  and,  where  rules  allow,  export  power  during emergencies.  Google,  for  example,  reports  1 GW  of  contracted  data-centre  demand response in the United States (Google, 2026). Realising this potential calls for technical requirements and market arrangements that reward dependable flexibility.

To meet the demands now being placed on grids, network planning needs to move beyond reacting to individual connection requests and look well into the future. It must anticipate where generation, storage and demand are likely to emerge, and co-ordinate modernisation and expansion across the power system, taking account of developments such as the rapid growth of data centres (Box 3.1). In interconnected systems, grid planning should extend beyond national borders, with neighbouring countries co-ordinating infrastructure needs, interconnector  development  and  system  operation  to  make  the  best  possible  use  of complementary resources and strengthen regional security  of  supply,  making  use  where appropriate of regional power pools and co-ordinated cross-border planning. Without such forward-looking co-ordination, security of supply could be affected where demand growth outpaces grid delivery capacity.

The challenge is not limited to the ability of grids to transmit power. As networks operate closer to their limits, and as more solar PV, wind and battery storage are connected through electronic converters, other technical constraints can become increasingly important. These include  maintaining  stable  voltage  and  frequency,  ensuring  that  systems  can  withstand sudden disturbances, and providing sufficient strength for protection equipment to operate correctly.  Maintaining  reliability  requires  these  needs  to  be  assessed  alongside  network capacity. Greater digitalisation and automation can improve real-time operation, but they also increase the importance of cyber security and resilience.

## 3.3.3 Solutions to accelerate grid expansion and modernisation

Governments,  regulators  and  industry  are  stepping  up  action,  while  grid  operators  are accelerating  network  expansion  and  modernisation.  Where  operational  headroom  and system  security  allow,  grid-enhancing  technologies  can  unlock  the  capacity  of  existing networks  much  faster,  complementing  new  lines  and  making  better  use  of  existing infrastructure. Dynamic line rating, topology optimisation, power-flow control, reconductoring and voltage uprating could unlock 450-700 GW of additional hosting capacity (IEA, 2026). Dynamic line rating could raise line capacity by 20-30% for around 90% of the year; power-flow control has unlocked more than 2 GW in northern England; the Victorian Big Battery in Australia adds 250 MW of peak transfer capacity; and TenneT's reconductoring programme is increasing capacity on parts of the Dutch transmission network by 60%.

Flexibility has a central part to play in complementing network expansion and getting the most out of grids. Flexible alternating current transmission systems (FACTS) can help address grid constraints that go beyond the physical capacity of power lines. Technologies such as enhanced  static  synchronous  compensators  (eSTATCOMs)  and  other  advanced  powerelectronic  solutions  can  stabilise  voltage,  manage  power  flows  and  respond  rapidly  to disturbances,  helping  the  grids  to  operate  within  secure  limits.  In  addition,  demand response,  storage,  smart  charging  and  automated  operation  can  ease  constraints,  while flexible or non-firm connections could be used to allow earlier connection in exchange for limited curtailment, thus enabling 750-900 GW of additional hosting capacity and helping to reduce near-term bottlenecks (IEA, 2026).

Regulatory  frameworks  are  also  adapting.  Anticipatory  and  integrated  planning  is  being strengthened  through  initiatives such as Australia's Integrated System  Plan, India's transmission plan for 500 GW of renewable capacity, Japan's Organisation for Cross-regional Coordination of Transmission Operators master plan, and national transmission studies in the United States. Investment frameworks increasingly allow network companies to build ahead of demand, supported by clearer cost recovery and risk sharing. Permitting reforms include maximum timelines, one-stop shops, digital tools and better-resourced authorities. Connection reforms are replacing 'first come, first served' approaches with readiness-based requirements,  and  steps  are  being  taken  to  ensure  earlier  community  engagement  and clearer benefit-sharing.

Figure 3.15 ⊳ Investment by selected power transformer and high-voltage cable manufacturers, 2015-2025

<!-- image -->

IEA. CC BY 4.0.

Grid equipment manufacturers' capital expenditure has risen significantly, supported by clearer project pipelines and greater confidence about future demand

Notes:  The  index  is  based  on  reported  capital  expenditure  and  disclosed  manufacturing  investments  by selected major power transformer and high-voltage cable manufacturers. Company disclosures differ in scope and may cover business-unit, segment or company-wide expenditure where more detailed manufacturing data are unavailable.

Source:  IEA  analysis  based  on  company  annual  reports,  financial  statements,  investor  presentations  and official investment announcements.

Industry  is  responding  through  new  procurement  models  and  additional  manufacturing investment. Framework  agreements,  capacity reservations and longer-term supplier partnerships  are  becoming  more  common  as  demand  increases  for  transformers,  highvoltage cables, high-voltage direct current systems  and  flexible alternating current transmission equipment. Our analysis of major manufacturers indicates that reported capital expenditure among the companies assessed was around six-times higher for high-voltage

cable  manufacturers  in  2025  than  in  2015,  and  around  seven-times  higher  for  power transformer manufacturers (Figure 3.15). Even so, expanding factories, securing materials and developing skilled workforces take time, and delivery periods and costs remain under pressure.

The  biggest  challenge  now  is  implementation  rather  than  a  lack  of  available  solutions. Implementation depends on governments and regulators creating the conditions that enable plans to be translated into investable projects, supported  by  effective permitting, appropriate frameworks for anticipatory investment, capable delivery institutions and crossborder co-operation. It also depends on system operators taking action to ensure that closer integration  of  networks,  generation,  storage  and  demand  planning  can  support  more efficient  system  development  and  operation,  making  maximum  use  of  digitalisation, flexibility and  proven  grid-enhancing  technologies.  And  it  needs  to  be  underpinned everywhere by adequate manufacturing capacity and a skilled workforce. Faster and more co-ordinated progress will help electrification reach its full potential in all parts of the world.

<!-- image -->

3

<!-- image -->

## Implications

## Benefits and trade-offs

## S U M M A R Y

- · In  the  High  Electrification  Scenario  (HES),  major  fuel-importing  regions  see  large reductions in import bills by 2035, equivalent to around USD 400 billion or 25% of current import bills, with transport electrification reducing oil imports by 15 million barrels per day by 2035. Higher natural gas generation to meet additional electricity demand could partially offset, but not fully reverse, natural gas import reductions.
- · Peak electricity demand increases by 1 900 gigawatts by 2035 in the HES, underlining the importance of electricity security. Batteries, smart grids, demand management and back-up generation can help provide the additional daily and seasonal flexibility needed.  Measures  to  increase  resilience  can  help  with  the  growing  risks  to  the electricity  system  posed  by  cyberattacks  and  natural  disasters,  now  sharpened  by trends like digitalisation/artificial intelligence and climate change.
- · Electrification presents a significant industrial opportunity. Revenues from electrification-related sectors account for one-fifth of the growth in global industrial revenues  since  2020. Around  half  of these  revenues  come  from  companies headquartered  in  Europe,  Japan,  Korea  and  North  America,  highlighting  that electrification-related  industrial  leadership  is  more  diverse  than  often  understood. Risks come from concentration and supply weaknesses in specific areas, notably the supply of critical minerals. Once deployed, however, many electrification technologies provide long-lived domestic energy supply, reducing continuous import needs.
- · Electrification  requires  substantial  upfront  investments,  but  these  need  to  be balanced against lower fuel costs. Some electrification investments may require policy support to lower upfront costs or facilitate access to affordable capital. In the HES, energy bills across the world are lower in 2035 than today.
- · Electrification  lowers  total  energy  sector  carbon  dioxide  emissions  in  all  the  cases analysed in this report. The HES reduces end-use emissions by 40% by 2035, and total energy  sector  emissions  drop  by  more  than  half  in  a  case  where  electrification  is accompanied with faster transitions in electricity generation. It also reduces local air pollution and avoids 240 000 premature deaths annually.
- · Today,  around  730 million  people  lack  access  to  electricity,  largely  in  sub-Saharan Africa. Improving access to electricity, and stimulating productive uses, are the main contributors to raising electrification  rates  in  these  countries.  Where  the  principal problem  is a lack of grid reliability, distributed energy resources like solar photovoltaics are cheaper than diesel generators and have an important part to play, but  their  use  should  complement  rather  than  replace  efforts  to  improve  grid reliability.

## 4.1 Introduction

This chapter examines the broader implications of accelerated electrification, looking at the benefits  it  offers,  assessing  the  risks  and  trade-offs  that  it  involves,  and  identifying  the enabling conditions that it requires. It considers how increased electrification can strengthen energy  security  by  reducing  dependence  on  imported  fossil  fuels,  while  recognising  that growing dependence on electricity makes it ever more important that electricity systems are secure, reliable and resilient. It assesses key risks to electricity systems, including those that stem from potential cyberattacks and natural disasters. It also assesses the industrial and supply-chain foundations  of electrification, the expanding  ecosystem  of  companies, technologies and infrastructure that support it, and the risks associated with concentrated critical mineral and technology supply chains.

The  chapter  then  turns  to  the  economic,  social  and  environmental  consequences  of electrification. It examines how electricity prices, household energy bills, investment needs and employment could evolve as electricity takes on a larger role in final energy use. It then assesses the potential for electrification to reduce carbon dioxide (CO2) and air pollutant emissions,  making  clear  that  aggregate  impacts  are  also  influenced  by  how  additional electricity demand is supplied. It ends by focusing on inclusive electrification, highlighting the continuing electricity access gap, the importance of reliable supply for productive uses and economic development, and the role that decentralised technologies can play alongside the further development of grids.

## 4.2 Energy security and resilience

## 4.2.1 Import dependence

Recent energy shocks have affected the availability and price of fuels that import-dependent regions rely on, and have provided a reminder that electrification can help strengthen energy security by reducing dependence on imported fuels; meet energy needs with less energy input; increase reliance on domestically produced electricity; and reduce exposure to global commodity markets. The scale of the impact on importing regions depends on the extent of their electrification and the degree to which their electricity is produced from domestically sourced fuels.  These  benefits  should  not  however  obscure  the  continuing  importance  of global  trade  in  energy  commodities  and  technologies,  and  the  need  to  treat  secure  and resilient markets and supply chains as key components of energy security.

## Impacts of end-use electrification for importers

Electrification of end uses replaces direct fuel use with electricity, reducing end-use demand for oil, natural gas and coal. In the High Electrification Scenario (HES), importing countries reduce their oil  imports  in  2035  by  15 million  barrels  per  day  (mb/d)  from  today's  level, mostly  as  a  result  of  transport  electrification.  In  addition,  electrification  in  buildings  and industry  avoids  annual  natural  gas  imports  of  120 billion  cubic  metres  (bcm)  by  2035.

Avoided annual coal imports of 100 million tonnes of coal equivalent (Mtce) are proportionally smaller than those for oil and gas because much of end-use coal demand is concentrated in industrial applications, some of which are difficult to electrify (Figure 4.1). The reduction in imports is greater in the HES than in the Stated Policies Scenario (STEPS): accelerated electrification under the HES represents avoided imports over and above those in the STEPS of 5 mb/d, 90 bcm of natural gas, and around 40 Mtce of coal.

Figure 4.1 ⊳ Avoided imports resulting from end-use electrification by fuel and sector in the HES by 2035 compared to 2025

<!-- image -->

In the HES, imports of 15 mb/d of oil, 120 bcm per year of natural gas, and 100 Mtce per year of coal are avoided in 2035 compared with 2025

Note: mb/d = million barrels per day; bcm = billion cubic metres; Mtce = million tonnes of coal equivalent.

The rapid adoption of electric vehicles (EVs) is the main cause of the reduction in oil imports in  the  HES  (Figure 4.2).  EVs  account  for  over  80%  of  avoided  oil  imports  in  advanced economies and China, and around three-quarters in other emerging market and developing economies. Around 50% of the natural gas displacement in advanced economies and China reflects the deployment of heat pumps, which reduce direct fossil fuel use for space and water heating by replacing  gas-fired  heating  systems  with  electric  alternatives.  Industrial electrification is the largest contributor to reductions in coal imports in advanced economies and China, driven by the electrification of industrial heat and process applications. Industrial electrification also plays a substantial role in reducing coal imports in emerging market and developing  economies  outside  of  China,  although  electrification  of  buildings  is  the  main driver for reducing coal demand in these countries, reflecting the continued use of coal for heating and cooking.

4

Figure 4.2 ⊳ Avoided fuel imports resulting from electrification of end-uses by region in the HES in 2035 compared to 2025

<!-- image -->

IEA. CC BY 4.0.

EVs account for most avoided oil imports; heat pumps deliver nearly half of the reductions in natural gas imports; industrial electrification is the main source of coal displacement

Notes:  AE  =  advanced  economies;  EMDE  =  emerging  market  and  developing  economies.  Includes  all countries/regions  that  were  net  importers  of  oil,  natural  gas  or  coal  in  2025.  Avoided  imports  reflect reductions  in  direct  fossil  fuel  use  from  end-use  electrification  over  2025-2035;  they  do  not  incorporate assumptions on the electricity generation mix. Import implications associated with different electricity supply mixes are assessed separately (Figure 4.4).

Figure 4.3 ⊳ Avoided import bill from end-use electrification in the HES in 2035 as a share of the 2025 import bill, by net-importing region

<!-- image -->

IEA. CC BY 4.0.

At 2025 import prices, reduced imports in the HES yield savings by 2035 of around 40% of the 2025 import bill in China, 25% in other EMDE, and 20% in advanced economies

In the HES, reduced imports save advanced economies and China USD 300 billion per year by 2035 at 2025 import prices, and other emerging market and developing economies over USD 100 billion  (Figure 4.3).  These  savings  are  equivalent  to  nearly  30%  and  over  25%, respectively, of the 2025 fuel import bills for these two regional groupings. They are over USD 75 billion larger than those in the STEPS for advanced economies and China, and around USD 70 billion  more  than  those  for  other  emerging  market  and  developing  economies. Compared to the STEPS, the large difference in imports in emerging market and developing economies outside China is due to the acceleration of transport electrification in the HES.

## Aggregate impacts for importers

These  demand-side  import  reductions  need  to  be  considered  alongside  the  additional electricity  demand  in  the  HES  that  results  from  increased  electrification  of  transport, buildings and industry. Chapter 3 assesses three cases with different assumptions about how the electricity sector could meet this additional demand. Even in the two electricity supply cases where fossil fuel consumption by the power sector is higher in 2035 than it was in 2025, this increase is more than offset by lower direct fossil fuel use in end-use sectors. As a result, the overall effect of electrification is to reduce fossil fuel imports (Figure 4.4).

Figure 4.4 ⊳ Avoided imports from end-use electrification in the HES and by electricity supply case in 2035

<!-- image -->

IEA. CC BY 4.0.

End-use electrification reduces fossil fuel imports even in the supply mix cases where electricity demand increases fossil fuel use in the power sector

Notes: STEPS = Stated Policies Scenario; CPS = Current Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario; elec. = electrification. Includes all countries/regions that were net importers of oil, natural gas or coal in 2025. CPS mix, STEPS mix and NZE mix refer to the electricity supply cases set out in Chapter 3.

4

The scale of the net reduction depends on how the additional electricity is generated. Even with the Current Policies Scenario (CPS) electricity mix, net imports of oil, natural gas and coal  in  importing  countries  are  lower  in  2035  than  in  2025:  an  increase  in  power  sector natural gas consumption offsets part of the reduction in direct use, but the net effect remains a decline in imports. With the STEPS mix, the increase in power-sector natural gas use is smaller,  resulting  in  a  larger  net  decline  in  natural  gas  imports.  With  the  NZE  mix,  the reductions are much  larger, with a swifter transition to low-emissions generation substantially reducing power sector demand for both natural gas and coal.

## 4.2.2 Electricity security

Modern  economies  are  already  heavily  dependent  on  continuous  supplies  of  electricity. Electricity systems  are  becoming  more  variable  and  complex  as  the  share  of  solar photovoltaics  (PV)  and  wind  in  generation  rises.  The  electrification  of  end-uses  adds complexity to the challenge of ensuring electricity security by increasing both the level and the variability of demand. Managing this transition is achievable, but requires a broad set of measures  to  maintain  adequacy,  make  power  systems  more  flexible,  and  strengthen resilience.

## Capacity adequacy

Adequacy is the ability of the power system to meet demand at all times. Ensuring electricity security starts with maintaining adequate supply and power infrastructure to meet peaks in demand. By 2035, peak electricity demand across markets is 1 900 gigawatts (GW) higher in the HES than today. This increase is equivalent to 40% of today's total global peak demand. The relative increase is smaller in advanced economies and China than in emerging market and developing economies outside China, which see their combined peak electricity demand increase by 70% overall compared to today (Figure 4.5).

Peak electricity demand reflects particular patterns of concentrated demand, including for heating in cold weather, cooling in hot weather and EV charging in the evening. Today, for example, space cooling accounts for just 10% of annual electricity demand, but is responsible for 30% of aggregated global peak demand because demand is concentrated in hot summer periods.  By  2035,  the  residential  air  conditioner  stock  is  set  to  increase  by  almost  half compared  to  today.  This  concentration  of  demand  can  place  additional  strain  on  power systems during heat waves. In advanced economies and China in particular, rising cooling needs  are,  however,  partly  offset  by  efficiency  gains  resulting  from  improved  building insulation and equipment efficiency.

Notwithstanding the pressures that arise from growing demand for cooling, peak demand growth in the HES is largely driven by the transport and industry sectors, which electrify rapidly. Although varying climates and demand structures mean that peak demand differs from one country to another, peak hours are in general set to shift from cooling hours to evening hours, when cars are plugged in and start charging. Smart charging and demand flexibility both offer potential to help smooth out peaks.

Figure 4.5 ⊳ Total peak electricity demand by economic grouping in the HES, 2025 and 2035

<!-- image -->

IEA. CC BY 4.0.

Peak electricity demand in 2035 is much higher than today. In the absolute, the increase is largest in advanced economies and China, but the relative increase is biggest in EMDE.

Note: GW = gigawatt.

In systems with high shares of variable renewables, adequacy must be assessed against peak residual load as well as peak demand. Peak residual load describes the periods when residual load - demand less generation from variable renewables - is highest. Meeting demand when variable renewable output is low requires an adequate level of dispatchable capacity and grid  infrastructure,  although  storage  and  demand-side  flexibility  are  also  playing  an increasingly  important  role.  Today,  most  dispatchable  capacity  is  provided  by  coal  and natural  gas,  with  low-emissions  hydropower  and  nuclear  power  making  a  significant contribution  in some  regions.  Other  low-emissions  options  that  scale  up  alongside hydropower and nuclear power to meet demand in the HES include geothermal, bioenergy, fossil fuels with carbon capture, utilisation and storage, and generators co-firing hydrogen or hydrogen-based fuels, while batteries are also set to play a bigger role by 2035.

## Flexibility

Flexibility  is  the  ability  of  an  electricity  system  to  balance  supply  and  demand  across  all timescales,  maintaining  security  of  supply.  Short-term  flexibility  is  needed  to  manage changes in supply and demand within and between days, while seasonal flexibility addresses imbalances over longer periods. Power system flexibility needs increase rapidly in the HES as electrification  boosts  seasonal  variations  in  demand,  and  as  rising  shares  of  variable renewables  raise short-term balancing needs. Expanding and reinforcing grids and interconnectors can moderate the increase in flexibility needs by connecting geographically dispersed demand and supply to help smooth out fluctuations in load and renewable output.

4

The HES sees flexibility needs increase with all of  the electricity supply mixes covered in Chapter 3, but most of all with the NZE mix, which has by far the fastest growth in the share of variable renewables in electricity supply. By 2035, global short-term flexibility needs in the NZE mix are around four-times higher than in 2025, and seasonal flexibility needs are around one-third higher. Dispatchable thermal and hydropower plants have historically provided most flexibility, but newer supply- and demand-side options play a growing role in the HES. Batteries  and  demand  response  emerge  as  the  main  sources  of  short-term  flexibility, together accounting for almost 60% of supply in 2035. Seasonal balancing continues to be provided  primarily  by  hydropower  and  thermal  power  plants,  including  low-emissions thermal power plants such as nuclear or bioenergy plants, supplemented by flexible demand and renewables curtailment (Figure 4.6).

Figure 4.6 ⊳ Development of global short-term and seasonal flexibility needs and supply in the HES to 2035

<!-- image -->

Solar is the main driver of short-term flexibility needs, while electrification raises seasonal needs. Batteries and demand response become critical sources of short-term flexibility.

Notes: 2035 shows the HES with the NZE mix case set out in Chapter 3. Thermal includes fossil fuels, nuclear, bioenergy, hydrogen and ammonia. Curtailment refers to the curtailment of wind and solar PV generation. Other includes concentrating solar power, geothermal, marine and waste.

The steep increase in short-term flexibility needs to 2035 is driven by the growth of solar PV and wind, which requires power systems to manage larger changes in output within and between days. In the NZE mix, solar PV and wind increase to more than four times their 2025 level, and the combined share of wind and solar PV in the electricity mix rises from 17% in 2025 to nearly 60% by 2035. The less pronounced rise in seasonal flexibility needs stems from the increasing electrification of end-uses: electric heating and growing air-conditioner use raise the level of demand and make it more temperature-sensitive, particularly in systems with substantial heating and cooling loads.

In  response  to  these  increases  in  flexibility  needs,  global  storage  capacity  rises  to  over 1 500 GW by 2030 in the NZE mix, including batteries, pumped storage hydropower and thermal storage. Batteries account for most of the increase, supported by falling costs, short development times and their suitability for integrating solar PV and wind. Annual battery additions rose from 5 GW in 2020 to 117 GW in 2025, and installed capacity increased from around 19 GW to almost 300 GW. Battery capacity grows to around 2 900 GW by 2035.

Batteries  and  demand  response  are  the  main  sources  of  short-term  flexibility  by  2035. Batteries  provide  around  30%  of  short-term  flexibility,  while  demand  response  provides around a quarter, in particular through smart charging of electric vehicles. Batteries shift electricity within the day, while demand response moves consumption towards periods of abundant supply or lower system needs. However, batteries provide less than 1% of seasonal flexibility because they are poorly suited to shifting electricity over longer periods.

Hydropower - especially pumped storage and reservoir hydro - remains an important source of low-emissions flexibility across both hourly and seasonal timescales, although its share declines  as  other  resources  expand  faster.  In  2025,  hydropower  supplied  around  60%  of short-term and 40% of seasonal flexibility; both shares fall to around a quarter by 2035 in the NZE  mix.  Its  contribution  remains  geographically  concentrated,  constrained  by  water resources  and  reservoir  capacity;  seasonal  hydropower  output  is  sensitive  to  water availability and weather conditions.

Thermal plants supplied around 25% of short-term and 60% of seasonal flexibility in 2025. By 2035, their short-term share in the NZE mix falls below 10%, but they remain the largest single  source  of  seasonal  flexibility,  providing  around  one-third  of  the  total.  Their  role increasingly shifts from bulk generation towards seasonal balancing and secure capacity.

Renewables curtailment provides around 10% of short-term flexibility and around one-third of  seasonal  flexibility  in  the  NZE  mix  by  2035.  Although  curtailment  usually  reflects constraints  in  grids,  storage  or  other  flexibility  options,  eliminating  it  entirely  may  be uneconomic.

Long-duration demand flexibility also contributes around 10% to seasonal balancing by 2035, primarily from electrolysers, which tend to run more at those times of year when renewables have a high share in generation and prices are lower.

## 4.2.3 Resilience

Electricity security focuses on ensuring sufficient capacity and flexibility to meet demand; resilience is the ability of the electricity system to withstand disruptions that affect the supply of electricity, to limit their impacts and to recover quickly when they occur.

Risks  to  the  electricity  system  come  in  multiple  forms.  Natural  hazards,  such  as  weather conditions or earthquakes, present a physical risk which may cause damage to equipment. The incidence of extreme weather events is increasing as the climate changes. Malicious attacks,  conflict  and  other  geopolitical  events  also  pose  physical  risks  to  the  supply  of

electricity.  Cyber  risks  present  a  non-physical  threat,  and  these  risks  are  increasing  as electricity  systems  become  more  digitally  connected  and  decentralised.  The  growing deployment  of  smart  devices  expands  the  number  of  potential  points  of  vulnerability, emphasising the importance of robust cybersecurity standards, enhanced oversight across the electricity value chain, and diverisifed supply chains and suppliers for key electrification technologies (see Section 4.3). All these kinds of risk can both damage specific assets and disrupt electricity system operations.

Figure 4.7 ⊳ Power outages and operational disruption of energy infrastructure caused by extreme weather events in 2023

<!-- image -->

IEA. CC BY 4.0.

Extreme temperatures, storms, floods, droughts and wildfires were responsible for reported power cuts to more than 210 million households

Notes: One dot represents one tracked event. Customers affected represent outage instances, not unique customers, as the same customer may be affected more than once.

Sources: IEA analysis based on CRED (2025), GDACS (2026) and ReliefWeb (2025).

An IEA dataset of extreme weather impacts on the energy sector shows that in 2023 nearly 300  events  of  extreme  temperatures,  storms,  floods,  droughts  and  wildfires  caused operational disruptions of critical energy infrastructure, and were responsible for reported power cuts to more than 210 million households (Figure 4.7). The dataset emphasises how electricity  networks  are  especially  vulnerable  to  extreme  weather  events:  damage  to substations and electricity grids or the pre-emptive shutting off of power lines, e.g. during high winds in wildfire-prone areas, together account for around 85% of the incidents.

Extreme  heat  presents  an  increasingly  significant  risk  for  electricity  systems  because  it simultaneously drives up cooling demand and drives down the performance of electricity

grids and power generation. High temperatures and associated conditions frequently impair electricity supply: the efficiency of generation output may be reduced by thermal derating; transmission line transfer capacity may erode as conductor resistance increases and lines sag; and hydropower and wind output may be decreased by lower levels of rainfall and wind speed. Both the number and duration of heatwaves have grown as the climate has warmed -  IEA  analysis  indicates  that  the  number  of  people  across  the  world  exposed  to  high temperatures has almost tripled since the early 1980s (ECMWF, 2025).  By 2035, extreme 1 heat is set to further increase peak electricity demand, contributing to a 10% increase over baseline  peak  demand  in  some  regions,  while  reducing  available  power  supply  through thermal derating by up to 5% in others (Figure 4.8). For some regions where these effects coincide, these impacts could erode nearly two-thirds of typical planning reserve margins for electricity systems. It is therefore important that these effects are incorporated into capacity adequacy assessments and future electricity system planning.

Figure 4.8 ⊳ Impact of extreme heat on peak demand and derated power supply by region, 2035

<!-- image -->

IEA. CC BY 4.0.

The effects of extreme temperatures on peak demand and capacity derating vary by region and are an important consideration in capacity planning

Notes: NZ = New Zealand; C &amp; S America = Central and South America. The results presented here are derived from the STEPS and cover regions where heat-related derating compounds with peak demands for cooling. The  capacity  losses  estimated  here  are  defined  as  the  difference  between  capacity  available  at  the temperatures that generators experience during peak demand under extreme heat vs those during median peak hours over 30 weather years.

Awareness of the number and nature of these various threats to electricity supply has been growing  in  recent  years.  Countries  are  already  implementing  measures  to  enhance  the

1 Based on data from the Copernicus Climate Change Service.

4

resilience of power systems. These measures can be broadly categorised as being concerned with governance, system design, infrastructure hardening, operational practices or enhanced monitoring (Table 4.1). Many measures address multiple types of risk simultaneously while also delivering broader system benefits, including improved operational  performance.  For  example,  dynamic  line  rating,  redundant  transmission corridors and enhanced system monitoring can help manage the challenges of increasingly electrified systems not just by improving network flexibility but also by optimising the use of existing infrastructure and supporting the integration of variable renewable generation.

Table 4.1 ⊳ Types of energy resilience measures and selected examples

| Type of measure   | Description                                                            | Examples                                                                                                                                                                                                                                             |
|-------------------|------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Governance        | Implementing policies, regulations and standards to support resilience | • Cybersecurity standards and incident reporting requirements • Emergency response tabletop and field exercises • Interagency resilience planning for critical infrastructure dependencies                                                           |
| System design     | Improving the system's configuration and architecture                  | • Increased grid interconnections and alternative power flow routes • Microgrids with local generation and storage for critical sites • Adopting grid-forming inverters • Automatic protection that isolates failures and prevents cascading outages |
| Hardening         | Increasing the robustness of structures and systems                    | • Designing assets for higher operating temperatures • Use of fire-resistant and anti-sparking components • Raising the level of assets and increasing the number of flood barriers • Use of hail-resistant glass for solar PV                       |
| Operational       | Putting in place procedures for management of a system or asset        | • Dynamic line rating • Spare part stocks • Black-start and system restoration plans • Workforce surge and mutual aid arrangements                                                                                                                   |
| Monitoring        | Anticipating threats and understanding the strain on assets            | • Battery thermal monitoring • Water-level flood sensors • Satellite and remote sensing for damage, vegetation and intrusion monitoring • Automatic fault detection and rapid shut-off systems                                                       |

Note: PV = photovoltaic.

## 4.3 Industrial ecosystem and secure supply chains

## 4.3.1 The industrial ecosystem for electrification

The rise of electrification creates fast-growing demand for a core set of technologies ranging from  heat  pumps,  batteries  and  electric  vehicles  through  to  solar  PV  and  wind  power equipment. However, the expanding role of electricity also depends on a wider industrial ecosystem  to  supply  vital  enabling  technologies,  components  and  infrastructure.  This ecosystem includes a broad range of equipment used in electricity generation, grids, power electronics,  digitalisation  and  other  sectors.  Some  of  these  value  chains  may  be  less immediately visible, but they are no less essential to the expansion of electrification in the energy system. Countries are likely to continue to pursue technological leadership across various sectors in search of economic security and industrial competitiveness.

Figure 4.9 ⊳ Revenues among listed companies in the electrification ecosystem by sector grouping, 2020-2025

<!-- image -->

IEA. CC BY 4.0.

Electrification generated USD 2.6 trillion in revenues among listed companies in 2025, with renewables, electric vehicles and batteries accounting for less than half of the total

Notes: Revenues are expressed in nominal USD and are not adjusted for inflation. Revenues reported in other currencies are converted to USD using the average exchange rate over the reporting period. Renewable energy equipment includes capital equipment for solar, wind, hydro, geothermal and green hydrogen production, and  includes  inverters.  Other  power  generation  equipment  includes  capital  equipment  for  coal,  gas,  and nuclear generation. Grid equipment, power electronics and digitisation includes any equipment used for the transport and control of electricity in physical infrastructure up to the point of end-use consumption, including digital technologies and semi-conductors specifically for power sector applications where relevant. End-use electrification and efficiency covers specifically capital equipment or technologies for industry and buildings, including for heating, cooling, and other energy saving measures. Electric vehicles and batteries also include electric vehicle charging equipment and batteries used for power sector applications. Critical minerals include copper, lithium, cobalt, nickel, rare earth elements, graphite and uranium mining and processing.

Source: IEA analysis based on Bloomberg (2026) Terminal data.

4

Assessing revenues by company can help show how different markets are structured, and who holds comparative advantage. Revenues across the broader electrification ecosystem have more than doubled in the last five years, growing at an annual average rate of 16% (Figure 4.9), and they accounted for 22% of total revenue growth among listed industrial companies during this period. Although revenues among listed manufacturers of renewable energy equipment, electric vehicles and batteries are significant, they make up less than half of the USD 2.6 trillion of global revenues generated by companies linked to electrification in 2025.  The  majority  was  generated  by  activity  in  other  sectors  within  the  broader electrification ecosystem, including the production of grid equipment, power electronics and digitalisation, other power generation equipment, end-use electrification and efficiency, and critical minerals mining and refining.

Figure 4.10 ⊳ Revenues among listed companies in the electrification ecosystem by region of headquarters, 2020-2025

<!-- image -->

Across the wider industrial ecosystem for electrification, non-Chinese listed companies earn more revenues than Chinese listed companies - but the gap has closed somewhat

Notes: Revenues are expressed in nominal USD and are not adjusted for inflation. Revenues reported in other currencies are converted to USD using the average exchange rate over the reporting period.

Source: IEA analysis based on Bloomberg (2026) Terminal data.

Today, the world's largest and most technologically advanced companies operating in these sectors are located in China, Europe, Japan, Korea and North America. Different regions have technological  and  market  leadership  in  different  sectors.  The  total  revenues  of  listed, electrification-linked  companies  headquartered  outside  China  are  larger  than  those  of companies headquartered in China. However, revenues for listed companies headquartered outside China increased by 1.9 times from 2020 to 2025, compared to 2.4 times for those headquartered in China (Figure 4.10).

Companies headquartered in Europe, Japan and Korea, and North America lead the market for other power generation equipment, particularly for gas turbines. While China energised

its first home-grown F-class gas turbine in 2023, domestic production has historically relied on  licensing  and  joint  ventures  with  foreign  companies.  Documented  exports  of  Chinese F-class turbines remain limited - so far, to a 150-megawatt (MW) project in Kazakhstan while non-Chinese firms including Siemens Energy, GE Vernova, Mitsubishi Heavy Industries, Baker  Hughes  and  Doosan  Enerbility  have  historically  accounted  for  the  vast  majority  of global capacity additions and new orders.

Meanwhile, Europe is home to some of the world's leading manufacturers of key grid-related equipment  such  as  transformers,  high-voltage  direct  current  (HVDC)  systems,  flexible alternating  current  transmission  systems  (FACTS),  cables,  semi-conductors  and  other technologies for grid digitalisation and automation. Together, these European companies generated  over  USD 160 billion  in  2025  -  roughly  40%  of  the  global  total  for  grid-based equipment.  Japanese,  Korean  and  North  American  companies  generated  an  additional USD 80 billion. Chinese companies have strong capabilities in many segments of the market for grid equipment, but face varying levels of access to foreign markets because of utility qualification requirements, procurement preferences, security of supply and cybersecurity concerns and, in some cases, explicit regulatory restrictions that have been put in place for sensitive applications.

Figure 4.11 ⊳ Global revenues among listed companies in the electrification ecosystem by region of headquarters and sector grouping, 2025

<!-- image -->

Different regions are leaders in different parts of the ecosystem: Europe leads in grid equipment, China in EVs and batteries, and North America in other power generation

Notes: Bubbles and labels correspond to total annual revenues in nominal USD for 2025. Critical minerals = critical minerals and uranium mining and processing; EVs = electric vehicles; Grid equipment = grid equipment, power electronics and digitalisation.

Source: IEA analysis based on Bloomberg (2026) Terminal data.

Markets for the refining and processing of copper, cobalt, lithium, graphite and rare earth elements are heavily concentrated in China (see Section 4.3.2). The distribution of revenues

4

from mining is much more diverse. The concentration of refined material production in China is lowest for copper, which has a market size far greater than that of all other key critical minerals used in clean technology manufacturing combined. Recent trade restrictions on critical minerals have, however, demonstrated that chokepoints in small markets can have severe knock-on implications if those markets control critical inputs to broader industries. For example, around USD 6.5 trillion of economic value is enabled by rare earth elements. Specific chokepoints in energy technology supply chains therefore remain a cause of concern, even though the wider industrial ecosystem for electrification retains an important degree of geographical diversity (Figure 4.11).

## 4.3.2 Critical minerals

The  transition to an electricity-centred energy  system  requires  the  deployment  of electrification technologies on a significant scale. Manufacturing this equipment rests in turn on secure access to a select group of critical minerals. The concentration of their supply chains represents a material risk to electrification. Copper is fundamental to grids, motors and transformers; lithium, nickel and cobalt to battery storage; and rare earth elements to the  permanent  magnets  used  in  EVs  and  wind  turbines.  As  electrification  accelerates, demand for these minerals climbs strongly out to 2035: in the HES, the contribution of grids to  copper  demand  growth  between  2025  and  2035  is  over  three-times  greater  than  in 2015-2025, while the increase in lithium demand for EVs also triples (Figure 4.12). More fundamentally, electrification shifts energy from a flow-based system of continuous fossil fuel supply to a stock-based system of long-lived equipment and recoverable materials.

Figure 4.12 ⊳ Copper, lithium and rare earth demand growth by end-use and scenario, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

In all scenarios, electrification drives demand growth for key minerals, including copper, battery materials and rare earths

Critical  mineral  supply  chains  remain  highly  concentrated,  particularly  in  refining  and processing, leaving markets vulnerable to disruptions in a small number of supplier countries. Supply concentration in refining continued to increase in 2025 for most minerals. Excluding rare earths, the share of the top refining country for key electrification minerals rose to 72% in  2025  from  70%  in  2023  (Figure 4.13).  Over  the  past  two  years,  the  leading  refiners  Indonesia for nickel and China for other key minerals - have accounted for more than threequarters  of  total  growth  in  refined  supply,  and  virtually  all  growth  in  the  supply  of manganese, nickel and graphite came from the dominant supplier. Rare earths were the exception:  new  capacity  in  the  United  States  and  higher  output  in  Malaysia  produced  a modest decline in concentration, indicating that targeted policy and investment support can bring about a degree of diversification.

Figure 4.13 ⊳ Average shares of the three largest producing countries in mining of key electrification minerals, 2023-2035

<!-- image -->

IEA. CC BY 4.0.

Refined mineral supply is more concentrated than mined supply,

with announced projects suggesting only limited improvement over the next decade

Notes: Shares represent the average across copper, lithium, nickel, cobalt, magnet rare earths and batterygrade refined graphite. For each mineral, countries are ranked by mining or refining output, and shares are averaged across minerals.

The economic risks of concentrated supply chains became clear in 2025 when China's April export  controls  on  seven  heavy  rare  earth  elements  disrupted  downstream  industries. Although implementation has been suspended until November 2026, the expanded controls announced in October 2025 - extending restrictions to products made using Chinese-sourced rare  earths  or  technologies  -  could  place  an  estimated  USD 6.5 trillion  per  year  of downstream production outside China at risk across the automotive, high-tech, defence and energy sectors. Additional controls on cathode materials, precursors and graphite anodes could strain battery supply chains, with controls on graphite putting over USD 300 billion per year of downstream production at risk. The number of mineral commodity categories subject to Chinese export controls has tripled since 2023.

4

Diversification efforts remain skewed upstream. Looking at the demand and supply balance outside the largest producer helps to illustrate this: by 2035, announced rare earth refining capacity located elsewhere would only be sufficient to process around two-thirds of mined supply outside  the  top  producer.  Furthermore,  planned  magnet  production  only  absorbs one-third of this mined rare earth volume; for lithium, planned cathode capacity is roughly one-third of projected mining capacity outside the largest producer. New projects outside dominant suppliers also carry capital costs 20% to over 150% higher and operating costs around 50% higher.

Projected supply-demand balances have improved for some minerals but remain strained: the  copper  supply  deficit  projected  for  2035  has  narrowed  from  around  30%  to  25%  as projects in the Democratic Republic of the Congo (DRC) and Zambia advance, though deficits for copper and lithium are still expected to persist. Copper market tightness is prompting closer scrutiny of substitution and secondary supply. Aluminium, a partial substitute, faces its own constraints: around 8% of supply last year came from the Persian Gulf, where conflict is currently limiting exports and raising prices. The copper-to-aluminium price ratio has been favourable to aluminium much of the past five years without triggering a major tipping point. Persistent aluminium supply pressures are likely to slow substitution further (Figure 4.14). Secondary  supply  offers  greater  potential:  copper  scrap  met  18%  of  demand  in  2025 (excluding direct use of scrap), up from 17% in 2024, and with stronger collection could meet over one-third of demand by 2050 in the STEPS.

Figure 4.14 ⊳ Historical copper and aluminium prices, price ratio and material demand for grids

<!-- image -->

IEA. CC BY 4.0.

Despite the price differential, substitution of copper by cheaper aluminium remains slow and seems unlikely to offset fully the demand surge related to electrification

Diversification, innovation and international co-operation are all essential as part of a set of actions to overcome the potential risks to critical mineral supplies, but none offers a quick fix. Well-designed policy tools, demand-side measures and action to close technology and skills gaps are all needed. Recycling could nearly double its contribution: there is scope to lift average recycling rates from around 10% today to close to 20% by 2040 if steps are taken to boost collection and sorting, and to harmonise extended producer responsibility schemes together with material-specific recovery and labelling requirements.

The additional cost of diversification can be viewed as a mineral security premium, a form of economic insurance against supply disruption, that could be absorbed with limited impact on final consumers. For example, critical minerals represent around one-quarter of batterycell costs but only about 3% of an average EV's price, and rare earths account for roughly 40% of magnet costs yet under 1% of a vehicle's value; a tripling of rare earth prices would raise the cost of a car by just 0.1%.

## 4.3.3 Manufacturing of technologies related to electrification

The increasing electrification of energy systems relies on the widespread deployment of the technologies and underlying materials and components that underpin electricity generation, storage and end-uses. The supply chains for these technologies differ markedly from those for fossil fuels, and the differences have broad implications for energy security and resilience.

The rapid expansion of several key technologies such as solar PV, batteries, EVs and heat pumps has been accompanied by increasing concentration across large parts of their supply chains, including for critical minerals (see Section 4.3.2). Levels of geographic concentration vary  across  the  value  chain,  with  upstream  and  intermediate  segments  typically  more concentrated than final assembly. In the solar PV supply chain, for example, China accounts for  around  75%  of  global  module  production  capacity,  but  as  much  as  95%  of  wafer manufacturing. The position is similar for batteries, with China holding roughly 80% of global capacity for cell assembly and around 96% of anode active materials. This uneven distribution limits  resilience:  downstream  diversification  cannot  offset  highly  concentrated  upstream inputs.

While  wind  power  manufacturing  capacity  outside  China  is  sufficient  to  meet  global non-Chinese demand, its supply chains remain exposed to constraints in critical inputs such as  permanent  magnets  and  the  rare  earth  elements  used  to  produce  them.  Heat  pump production  is  also  relatively  widely  distributed,  but  remains  exposed  to  the  risk  of bottlenecks  for  key  components  such  as  rotary  compressors.  Such  concentration  creates vulnerabilities that allow even small disruptions, whether as a result of trade policy changes, natural disasters or industrial accidents, to ripple quickly across global markets, affecting availability, prices and deployment timelines, with risks rising as electrification scales up.

<!-- image -->

4

Figure 4.15 ⊳ Geographic distribution of existing and committed manufacturing capacity for selected energy technologies, 2024-2030

<!-- image -->

IEA. CC BY 4.0.

Manufacturing remains highly concentrated, with China retaining a dominant share across key technologies, while heat pumps show greater regional diversification

Note: PV = photovoltaics.

Despite the high levels of concentration observed across these technology supply chains, increasing electrification is reshaping the nature of energy security by shifting dependence from  traded  fuels  to  technologies,  materials  and  infrastructure,  and  in  the  process  is reformulating some long-standing energy security risks. Traditional energy security has often centred on the continuous flow of fuels across borders, where disruptions can rapidly affect prices and availability. By contrast, supply chain disruptions to electrification technologies do not affect the stocks of equipment, components and materials already embedded in energy systems. Despite the risks posed by highly concentrated markets, electrification technologies,  once  deployed,  contribute  to  domestic  energy  supply  over  long  periods, reducing the need for continuous imports, and shifting part of the security challenge from fuel procurement to technology availability and system resilience.

However,  electrified  technologies  also  create  new  security  challenges  linked  to  the information technology systems that manage power generation, transmission, distribution and  use.  As  power  systems  rely  more  heavily  on  digital  controls,  sensors,  inverters  and connected devices, exposure to cyber risk is growing in scale and complexity. Cyberattacks on critical infrastructure rose by around 30% in 2023. Approximately 420 million incidents globally  were  recorded  that  year.  The  figures  include  a  sharp  increase  in  the  number  of attacks targeted at energy utilities. Some of these cybersecurity and system-control risks are closely linked to concentrated technology supply chains.

The high concentration of electrification technology supply chains also has wider economic implications. As these technologies scale up, they create major manufacturing opportunities,

making them a strategic priority for many governments and industries. In some cases, the cost reductions that large-scale manufacturing has brought about have helped to speed up the adoption of particular technologies. However, a narrow focus on the lowest-cost imports from highly concentrated markets risks deepening vulnerability to upstream disruptions and excessive reliance on dominant suppliers. For example, each month of a halt in battery supply chain exports from China could lead to an estimated loss in output of USD 17 billion from electric car factories elsewhere, with facilities in the European Union accounting for over half of  the  losses.  A  narrow  focus  also  risks  weakening  the  domestic  capabilities  needed  to compete in strategic technologies, since lower near-term costs may come at the expense of future innovation, manufacturing capacity and market leadership (IEA, 2026).

## An overhang of manufacturing capacity

Substantial  manufacturing  capacity  is  leading  to  well-supplied  markets  for  electrification technologies (Figure 4.16). This offers opportunities for accelerated deployment, but it also weighs on profitability and future investment. Intense competition and sustained overcapacity have led to weak and volatile margins, especially in China. Solar PV prices have at  times  fallen  below  production  costs;  the  ten  largest  firms  recorded  losses  of  around USD 4.5 billion in 2024. Global spending on manufacturing capacity for six key electrification technologies fell from nearly USD 250 billion in 2023 to nearly USD 210 billion in 2025, mainly due to weaker solar PV and wind investment in China. Persistently low margins could further dampen capacity expansion, process upgrades and innovation, weakening competitiveness and resilience.

Figure 4.16 ⊳ Existing and committed manufacturing capacity for the solar PV, battery and electric vehicle supply chains, 2024-2030

<!-- image -->

Demand

IEA. CC BY 4.0.

Existing manufacturing capacity remains well above current demand for all key clean energy technologies, but planned manufacturing capacity expansions are slowing

4

The  widening  gap  between  capacity  and  demand  has  driven  a  significant  build-up  of inventories. Global solar PV module output exceeded demand by around 50% in 2023 and 30%  in  2025,  leaving  inventories  in  Europe  and  North  America  at  roughly  twice  annual installations,  or  about  eight  times  normal  levels.  Similar  pressures  are  visible  in  EVs  and batteries: in the first three-quarters of 2025, Chinese EV exports were around 350 000 units higher than overseas sales, and global EV battery inventories reached an estimated 30% of annual demand at the end of 2024.

These imbalances are prompting trade and industrial policy responses from some importers exposed  to  an  overhang  of  manufacturing  capacity  elsewhere.  In  the  United  States,  for example,  announced trade-weighted tariffs and duties on solar PV products averaged 169% in 2025, rising to 315% for imports from China. These trade tensions underline the risks that persistent  overcapacity  brings  not  only  for  near-term  profitability  but  also  for  future investment, manufacturing location and supply-chain resilience.

## 4.4 Investment, affordability and employment

## 4.4.1 Investment

Alongside investment in generation, networks and storage, electrification requires investment in end-use sectors. This includes the upfront costs of technologies like EVs and EV  chargers,  heat  pumps,  and  electric  boilers.  In  contrast  to  investments  in  electricity generation  and  networks,  investments  in  electrification  are  often  undertaken  by  small businesses,  public  bodies  and  individual  households,  making  cost  particularly  important. Some  electrification  investments  may  already  be  commercially  attractive  under  today's conditions,  but  others  require  new  infrastructure  to  be  put  in  place  or  policy  support  to facilitate access to capital or lower its cost.

## Investment in end-uses

Around USD 320 billion is currently invested each year in electrification across the industry, transport and buildings sectors (Figure 4.17). By 2035, this rises to around USD 1 trillion in the HES. The largest share of these investments occurs in the transport sector in the form of EV purchases by households and businesses. These increase in the HES from USD 125 billion to around  USD 530 billion  by  2035,  supported  by  around  USD 175 billion  of  annual investment in charging infrastructure. In the buildings sector, investments in the electrification of space heating are the dominant driver of growth. Investments in industry electrification see the largest relative increase, growing by nearly seven times by 2035, albeit from a low level today.

Figure 4.17 ⊳ Average annual incremental electrification investments by sector in the HES, 2020-2035

<!-- image -->

IEA. CC BY 4.0.

Meeting the 35% target requires a step change in electrification investment,

with incremental spending of over USD 1 trillion across end-use sectors

## Investment in generation and grids

Global investment in the electricity sector has already increased by over 70% in the last five years,  rising  from  around  USD 865 billion  in  2020  to  USD 1.5 trillion  in  2025.  In  the  HES, annual spending on electricity generation, battery storage and transmission and distribution grids rises in the NZE mix from around USD 1.5 trillion today to around USD 2.5 trillion by 2035, with much of the additional investment flowing into low-emissions generation, storage and grids (Figure 4.18).

Generation remains the largest component of overall power sector investments, rising from around USD 560 billion in 2020 to USD 960 billion in 2025, and in the HES with the NZE mix case, it climbs further to around USD 1.5 trillion by 2035, most of it in renewables. Battery storage  shows  the  fastest  relative  growth,  expanding  from  a  very  small  base  of  around USD 5 billion in 2020  to USD 80 billion in 2025, and  continuing to rise to around USD 125 billion in 2035 as storage becomes increasingly important for integrating variable renewables and supporting system flexibility.

Grid investment increased from around USD 295 billion in 2020 to USD 450 billion in 2025. In the HES with the NZE mix case, it increases further to around USD 930 billion by 2035, reflecting  the  need  to  expand,  reinforce  and  modernise  transmission  and  distribution networks to keep pace with faster electrification.

4

Figure 4.18 ⊳ Investment in electricity generation, battery storage and grids in the HES, 2020-2035

<!-- image -->

IEA. CC BY 4.0.

Annual investment in electricity generation, storage and grids has risen to around USD 1.5 trillion today, rising to USD 2.5 trillion by 2035 to support faster electrification

Notes: HES = High Electrification Scenario; MER = market exchange rate. 2035 shows the HES with the NZE mix set out in Chapter 3.

## Combined end-use and electricity generation investments by region

Advanced economies and China see the largest absolute investments in the HES, reflecting their economic size and relatively high level of energy consumption compared with other emerging market and developing economies (Figure 4.19). They are also already investing substantially in generation, grids and electrified end-uses like EVs, and investment doubles between today and 2035. In contrast, investments in electrification in other emerging market and developing economies (both with full access and with access gaps) increase by around three times across the same timeframe relative to today. For these countries, the largest increases  in  investment  relative  to  the  levels  of  today  are  in  EVs  (including  two/threewheelers) and in related infrastructure, and in grids and energy storage. Across all country groups, generation and grid investments account for the majority of total investments.

Figure 4.19 ⊳ Annual average investment in electrification by country grouping in the HES, 2020-2035

<!-- image -->

IEA. CC BY 4.0.

Investments in electrification increase across all country groupings: advanced economies and China see the largest absolute rise

Notes: MER = market exchange rate; AE = advanced economies; EMDE = emerging market and developing economies. In this figure, projections for the HES assume the NZE mix set out in Chapter 3. Electricity prices and bills

## Electricity pricing

End-user electricity prices are shaped first by the underlying cost of providing electricity, including generation, storage and electricity grids. These structural costs comprise capital investment, fuel and CO2 costs, operation and maintenance expenditures, and the costs of modernising,  expanding  and  operating  transmission  and  distribution  networks.  In  most regions,  electrification  and  the  transition  to  low-emissions  power  systems  are  shifting electricity  systems  towards  more  capital-intensive  cost  structures,  with  a  larger  share  of costs linked to upfront investment and a smaller share to fuel expenditures.

The  implications  for  end-user  prices  differ  by  region.  In  some  markets,  including  the European Union, there are opportunities to reduce electricity prices as average electricity system  costs  decline  (Figure 4.20).  Downward  pressure  comes  from  reduced  reliance  on natural  gas  and  other  fossil  fuels  in  power  generation,  together  with  continued  cost reductions for low-emissions electricity technologies such as battery storage or renewables. Higher electricity demand also helps spread fixed costs over a larger volume of electricity sales,  reducing  the  cost  per  unit,  though  the  extent  of  this  depends  on  how  much  new investment is needed to meet demand growth. Making the most of demand flexibility and smart grid options could lower the investment required to meet growing demand.

In other regions, notably China and India, average system costs increase relative to today as rising  electricity  demand  and  the  expansion  of  generation,  storage  and  grids  require substantial new investment. The increase is evident both under today's policy settings and

4

in the HES, despite the different generation mix in each scenario. The extent to which these structural costs are reflected in end-user prices in all regions also depend on market and regulatory arrangements. In addition, where carbon pricing contributes to electricity costs, part or all of the impact on consumers can be offset through revenue recycling schemes.

Figure 4.20 ⊳ Electricity system costs by component in selected regions, in the STEPS and HES, 2025 and 2035

<!-- image -->

- Grid-related costs
- Capital costs for power plants and storage
- O&amp;M power plants and storage costs
- Fuel and CO₂ costs for power plants

IEA. CC BY 4.0.

Higher investment needs reshape electricity system costs, but declining fossil fuel use and higher electricity demand help improve recovery of fixed costs and moderate the growth

Notes: CO2 = carbon dioxide; MWh = megawatt-hour; MER = market exchange rate; O&amp;M = operation and maintenance. Grid-related costs include capital recovery costs for electricity transmission and distribution systems and grid operation and maintenance costs. In this figure, projections for the HES assume the NZE mix set out in Chapter 3.

A  second  important  determinant  of  end-user  electricity  prices  is  the  policy  treatment through  taxes,  levies  and  subsidies.  These  components  can  materially  influence  the competitiveness of electrification and account for very different shares of consumer prices across fuels, sectors and country groupings. In some advanced economies, taxes make up as much as 30% of residential electricity prices and nearly 20% of industrial electricity prices, while  in  others  they  are  close  to  zero.  In  emerging  market  and  developing  economies, electricity  tax  shares  range  from  zero  to  almost  40%  for  both  residential  and  industrial consumers. Subsidies also affect end-user prices and vary widely across countries, ranging from targeted support for vulnerable consumers to extensive measures that lower electricity tariffs for broad groups of households and industrial users. As a result, policy choices can have a significant effect on the relative cost of electricity compared with competing fuels, independent of underlying system costs.

In a number of countries, and in emerging market and developing economies in particular, natural  gas  and  oil  are  taxed  less  than  electricity  or  are  subsidised.  This  tax  treatment

inevitably  weakens  incentives  to  electrify.  Among  high-income  countries,  the  European Union  stands  out  as  a  region  with  relatively  high  taxes  on  electricity,  particularly  for households. Reductions in value-added tax (VAT) and excise taxes could lower residential electricity  prices  by  around  20%  and  industrial  electricity  prices  by  around  10%  in  2035, helping boost the competitiveness of electric applications (Figure 4.21).

Such reforms could strengthen the economic case for electrification but would need to be designed  carefully  given  their  implications  for  public  revenues  and  the  distribution  of benefits  across  consumers,  including  whether  support  reaches  those  most  exposed  to affordability pressures.

Figure 4.21 ⊳ Potential impact of reducing taxes on residential and industrial electricity in the European Union in the HES, 2035

<!-- image -->

IEA. CC BY 4.0.

Reducing VAT and excise taxes could cut EU electricity prices further in 2035 in the HES, especially for households

Notes:  The  tax  reduction  assumes  a  lowering  of  VAT  and  excise  duties  to  their  legal  minimums  in  all  EU member countries. NZE mix refers to the electricity supply case set out in Chapter 3.

## Household energy bills

The  cost  of  household  energy  services  is  determined  by  spending  on  fuels  and  on investments in durable energy technologies such as cars or heating equipment. Across the world today, an electric car can on average save consumers around USD 550 per year in operating costs,  although  this  saving  will  be  greater  in  regions  with  higher  fuel  prices  or where drivers travel longer distances on average per year. Heat pumps also have significant potential to save households money on their bills, thanks to their superior efficiency. As a result, in the HES with the NZE mix, household energy bills at the global level are lower by 2035 than they are today and lower than projected in the STEPS for the same year. This is primarily because  of  efficiency improvements  coming  from  both  electrification  and

4

dedicated measures to improve efficiency, such as buildings retrofits, in combination with changes  in  fuel  prices  by  2035.  On  average,  this  reduction  essentially  offsets  increased investments in electrified energy technologies by households in the aggregate (Figure 4.22).

Figure 4.22 ⊳ Global household energy bills and annual investments in electrified technologies and efficiency by households in the STEPS and HES, 2025-2035

<!-- image -->

IEA. CC BY 4.0.

In the HES, lower average energy bills essentially offset higher average investment needs for households in the aggregate

Notes: MER = market exchange rate. In this figure, 2035 projections for the HES assume the NZE mix set out in Chapter 3. Other includes natural gas, district heat, coal and renewables.

Spending on fuels is a current, recurring expenditure undertaken by all households every year. Investments are undertaken infrequently by individual households: once every eight years for a car on average, or once every 10 to 20 years for a new heating system. Each year, therefore,  only  a  certain  share  of  households  will  invest  in  new  energy-consuming equipment.  On  average,  purchasing  an  electric  car  and  installing  a  heat  pump  still  costs around USD 13 000 more upfront in advanced economies than opting for a gasoline car and a natural gas boiler (Figure 4.23). However, projected fuel, maintenance and resale value savings accumulated over an eight-year period recover most of this upfront cost premium. For individual households making substantial investments in electrification, it can therefore take several years for these investments to pay back. For some households, payback periods may be too long or too uncertain to justify the investment, or the household may find it difficult to access the capital to fund it.

Figure 4.23 ⊳ Electric car and heat pump investment cash flow analysis of an average household in advanced economies, 2025

<!-- image -->

Over eight years, fuel and maintenance savings from electric cars and heat pumps can offset around two-thirds of the average household's electrification investment

Notes: Investment cost reflects the combined upfront cost difference between purchasing an electric car and a heat pump and purchasing conventional fossil fuel alternatives. Operating savings represent the discounted fuel and maintenance cost savings over the analysis period. Electric car resale savings reflect the difference in residual value between an electric car and a comparable gasoline alternative after eight years of ownership: electric cars are more expensive to purchase and this offsets the fact they currently depreciate faster than gasoline alternatives.

Low-income  households  face  a  particular  challenge  (Figure 4.24).  They  have  constrained incomes  and  limited  savings  to  self-fund  investments,  and  the  size  of  electrification investments relative to their income can be substantial. For example, for a household in the first (poorest) income quintile in China, the upfront cost of a heat pump could be more than half of annual income. Technology learning and cost reductions could help in the future, but even with the cost reductions seen in the HES, a heat pump would still cost above 35% of annual income in 2035. In the European Union, the shares are lower but remain substantial.

In some markets, such as for EVs, investment costs can differ substantially across different classes of the same product. The case of EVs in China illustrates this well. The average price of battery electric car in China is around USD 25 000, but there is wide variation around this average (JATO, 2025). Some of the best-selling battery electric models in China cost less than USD 10 000. Considering the average EV price, purchasing an EV could require as much as five years of income for the poorest quintile in China, but only around two years of income for a cheaper model. Compared to EVs, there is relatively little product differentiation for equipment such as heat pumps and so investment costs do not differ substantially between different  models  and  brands.  This  highlights  that  policy  targeting  inclusive  electrification should  consider  not  only  income  differences,  but  also  the  characteristics  of  individual markets and technologies.

4

Overall, the analysis highlights that electrification investments may be challenging for lowincome households, who may lack access to savings or affordable finance to cover the cost of the investment. This means that targeted policies may be needed to support electrification in low-income households (and for other capital-constrained actors, like small and medium enterprises).

Figure 4.24 ⊳ Investment cost of a heat pump and an electric car as a share of annual income by household income quintile, 2025-2035

<!-- image -->

IEA. CC BY 4.0.

| Heat pump installation   | Heat pump installation   | Heat pump installation   | Electric vehicle purchase   | Electric vehicle purchase   | Electric vehicle purchase   |
|--------------------------|--------------------------|--------------------------|-----------------------------|-----------------------------|-----------------------------|
| 60%                      | European Union           | China                    | 600%                        | European Union              | China                       |
| 50%                      |                          |                          | 500%                        |                             |                             |
| 40%                      |                          |                          | 400%                        |                             |                             |
| 30%                      |                          |                          | 300%                        |                             |                             |
| 20%                      |                          |                          | 200%                        |                             |                             |
| 10%                      |                          |                          | 100%                        |                             |                             |
|                          | 2025 2035 2035           | 2025 2035 2035           |                             | 2025 2035 2035              | 2025 2035 2035              |
|                          | STEPS HES                | STEPS HES                |                             | STEPS HES                   | STEPS HES                   |
|                          | 1st quintile             | 2nd quintile             | 3rd quintile                | 4th                         | quintile                    |

For a low-income household, one-off investments in electrification technologies can be a substantial share of annual income, and so require policy support

Notes:  HP  =  heat  pump;  EV  =  electric  vehicles.  Income  values  are  based  on  cut-off  thresholds  between quintiles, resulting in four reported income levels.

## 4.4.2 Electrification and employment

Electricity now accounts for more employment in the energy sector than fuel supply. Since 2019, electricity-related employment has grown by 4% on average each year, well above the 1.5% average of the energy sector and the economy overall. Employment in generation, transmission,  distribution  and  storage  has  risen  by  3.9 million  since  2019,  and  has  been responsible for over two-thirds of all additional energy jobs. The construction of new power generation has been the primary driver of growth: solar PV accounts for half of the new power sector jobs created since 2019, and nuclear power, grids and storage for a further quarter.  The  shift  to  electrification  is  also  changing  the  composition  of  the  workforce  in related sectors: for example, vehicle manufacturing employment continues to rise, with jobs related to EVs increasing by nearly 800 000 in 2024.

Skilled  trades  -  a  category  that  includes  electricians,  grid  line  workers,  solar  installers, welders, and others - is the largest occupational group in the electricity sector. It has also

been the fastest growing in recent years, with an annual growth rate of more than 5% since 2019 (Figure 4.25). This is unlikely to change: accelerating electrification in line with a highelectrification scenario would require doubling today's workforce in occupations linked to electrification. The sector's structural dependence on skilled technical roles leaves it highly exposed to labour shortages, and the strains are already evident (Box 4.1). In the European Union, electricians, welders, pipefitters and other trades have consistently been among the top ten occupations with the most widespread shortages (EURES, 2025) since 2019, while the United States is already short of 80 000 electricians today (Forbes, 2025). Meanwhile, demand  for  electrical  engineers  and  technicians  in  the  energy  sector  continues  to  rise, underpinned  by  growing  demand  for  specialised  roles  such  as  power-system  engineers, commissioning specialists, and workers manufacturing transformers, switchgear and other grid equipment. Labour shortages are particularly marked in sectors with a higher share of high-skilled workers, such as grids and nuclear.

Figure 4.25 ⊳ Annual employment growth by industry and by selected occupational group, 2019-2024

<!-- image -->

IEA. CC BY 4.0.

Since 2019, annual employment in electrification has grown 2.5-times faster than the energy sector average. Electricians and other trades are the fastest growing occupation

Note: CAAGR = compound average annual growth rate.

These  workforce  challenges  are  being  compounded  by  demographic  trends:  the  energy workforce  is  older  than  the  economy-wide  average,  and  too  few  qualified  workers  are entering the sector to replace retirees and meet growing demand. For every young worker entering, there are 1.6 and 1.4 workers approaching retirement in nuclear and grid roles respectively,  compared  to  an  economy-wide  average  of  1.2.  The  pressure  is  greatest  in advanced economies, where, across the whole energy sector, there are 2.5 workers nearing

4

retirement  for  every  worker  under  25,  compared  with  a  ratio  of  about  1:1  in  emerging market and developing economies.

Addressing  these  workforce  shortages  will  require  policies  that  both  expand  the  talent pipeline  and  improve  the  attractiveness  of  energy  careers.  Effective  measures  include reducing  barriers  to  training  through  financial  support  and  apprenticeships,  increasing awareness of vocational pathways, and attracting more women into technical occupations where they  remain  significantly  underrepresented.  Close  collaboration  between  industry and  education  providers  is  essential  to  align  training  with  emerging  skill  needs,  while competitive wages, job security and safe working conditions remain critical for attracting and retaining talent.

## Box 4.1 ⊳ Data centre expansion intensifies demand for electrical workers

The rapid expansion of data centres is adding to an already strained market for electrical workers. Data centres, transmission infrastructure and power generation all compete for the  same  pool  of  electricians,  line  workers,  heating,  ventilation  and  air  conditioning technicians and electrical engineers - occupations that are already facing shortages as demand rises and a large share of the workforce approaches retirement. Electricians are especially sought after because electrical work accounts for 45% to 70% of a data centre's construction costs (IBEW, 2025). This competition is reflected in rising pay, with data centres often having the financial means to outcompete other sectors - many pay up to 30% more than the rate for typical electrician jobs in the construction sector (ITIF, 2026).

As skilled  labour  constraints  emerge  as  a  bottleneck  to  artificial  intelligence  (AI)  data centre  deployment,  major  technology  companies  are  beginning  to  invest  directly  in workforce development. OpenAI, Meta and Google have launched initiatives to support the recruitment and training of skilled trades workers. These developments point to a broader shift in the way workforce capacity is being considered as part of longer-term infrastructure planning. Issues such as the size and composition of the talent pipeline, the nature of vocational education and training, the attractiveness of careers in skilled trades, and the representation of different demographic  groups are becoming increasingly prominent in discussions about the development and scaling up of energy and digital infrastructure systems. Experience from past workforce mobilisation efforts shows that raising the profile of critical occupations can materially expand the talent pipeline.  So  far,  however,  efforts  to  attract  young  people  into  electrical  careers  have remained fragmented and small in scale, despite growing recognition that building this talent pipeline is essential to accelerating electrification.

## 4.5 Emissions

## 4.5.1 CO2 emissions

Energy-related CO2 emissions arise from both end-use demand and electricity generation. This section first examines how end-use emissions from transport, industry and buildings evolve in the HES, before considering how different electricity supply mixes affect power sector emissions. It then looks at the combined implications of these trends for total energy sector CO2 emissions.

## End-use emissions

Over  the  last  decade,  emissions  from  end-use  sectors  have  grown  by  roughly  5%  from 20 gigatonnes (Gt) to 21 Gt of CO2, and they now account for over half of energy-related CO2 emissions  (Figure 4.26).  This  increase  largely  reflects  emissions  growth  in  industry  and transport, with the latter outweighing the former. In industry, the rise in emissions has been driven by expanding activity in energy-intensive sectors such as steel and chemicals in Asia, while in transport it stems from growing car ownership, particularly in emerging market and developing economies. Emissions from buildings have remained broadly stable since 2015. Although end-use CO2 emissions increased by 1 Gt over the last decade, emissions intensity per gigajoule of energy use decreased by almost 10% as a result of efficiency improvements in vehicles, heating and cooking equipment, appliances, and industrial processes.

Figure 4.26 ⊳ End-use CO2 emissions and CO2 emissions intensity, 2015-2025

<!-- image -->

Note: Gt = gigatonne; CO2 = carbon dioxide.

4

In the HES, CO2 emissions decrease by roughly 40% in end-use sectors to 2035 (Figure 4.27). The decrease is biggest in the transport sector, highlighting the importance of electrification for meeting the 28th Conference of the Parties (COP28) goal of accelerating the reduction of emissions from road transport, but the buildings and industry sectors also contribute. Other measures  such  as  the  deployment  of  biofuels,  hydrogen  and  hydrogen-based  fuels,  and efficiency improvements also help reduce emissions in end-use sectors in the HES. While electrification  plays  the  largest  role  in  reducing  end-use  emissions,  these  additional measures are critical to ensure that the transformation in end-use sectors is aligned with net zero by 2050 pathways.

Figure 4.27 ⊳ Reductions of direct CO2 emissions from end-uses by sector and by lever in the HES, 2025 and 2035

<!-- image -->

IEA. CC BY 4.0.

CO2 emissions in end-use sectors fall 40% by 2035, with electrification contributing almost 5 Gt, mostly from transport, and other measures including efficiency contributing 3 Gt

Notes: Gt CO2 = gigatonnes of carbon dioxide. Other includes measures such as increases in efficiency, biofuels, and the deployment of hydrogen and hydrogen-based fuels.

## Emissions from electricity generation

Over 40% of energy-related CO2 emissions come from the generation of electricity. How electrification impacts aggregate emissions depends largely on how the additional electricity demand in the HES is met. To illustrate the potential pathways, different electricity supply cases were explored in Chapter 3. The three cases - matching the electricity demand of the HES  with  the  electricity  supply  mixes  of  the  CPS,  STEPS  and  NZE  Scenario  -  reflect progressively faster deployment of low-emissions generation, and they produce different outcomes  for  electricity  sector  CO2  emissions.  Global  CO2  emissions  from  electricity

generation stood at 14 gigatonnes (Gt) in 2025: they fall by 75% with the NZE mix, decline modestly with the STEPS mix and remain broadly flat with the CPS mix.

Figure 4.28 ⊳ CO2 emissions from electricity generation by electricity supply case in the HES, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Accelerating electrification and the pace of growth in low-emissions generation lead to a range of outcomes for CO2 emissions from electricity generation and the wider energy sector

Notes: Gt CO2 = gigatonnes of carbon dioxide. CPS mix, STEPS mix and NZE mix refer to the electricity supply cases set out in Chapter 3.

## Economy-wide CO2 emissions

Total energy sector emissions, combining end-use sectors and electricity generation supply cases in the HES, decline in cases to 2035 (Figure 4.29). In the CPS supply mix case, total electricity sector emissions are held at their 2025 level, with lower CO2 intensity of electricity generation offsetting the effect of higher electricity demand in end-use sectors in the HES. This  effect  is  more  pronounced  in  the  STEPS  supply  mix  case,  which  sees  the  emissions intensity of generation fall by 40% compared to today. The CPS and STEPS supply cases result in falls in total energy sector emissions of about 20% and 25% respectively by 2035. Emissions reductions are greatest in the case where the electrification rate of the HES is combined with the NZE mix: this cuts global energy-related CO2 emissions in 2035 by more than half from their level in 2025.

<!-- image -->

4

Figure 4.29 ⊳ Direct CO2 emissions from end-use sectors and from electricity generation supply cases in the HES, 2025 and 2035

<!-- image -->

IEA. CC BY 4.0.

End-use electrification in the HES leads to a decline in overall energy-related CO2 emissions in 2035 when combined with any of the electricity supply mix cases

Notes: Gt CO2 = gigatonnes of carbon dioxide; g CO₂ per kWh = grammes of carbon dioxide per kilowatt -hour; Other includes emissions from other energy sector and heat production in the power sector. CPS mix, STEPS mix and NZE mix refer to the electricity supply cases set out in Chapter 3.

## 4.5.2 Air pollution emissions

Ambient air pollution results in part from the combustion of fossil fuels to meet demand for mobility, heating and cooling, and industrial production. Exposure to ambient air pollution is estimated to cause around 13 000 premature deaths each day, with nearly 90% of deaths occurring  in  emerging  market  and  developing  economies.  In  addition  to  its  severe consequences for human health, air pollution also constrains economic growth: the World Bank estimates its economic costs at around 4.7% to 6.5% of gross domestic product (GDP) each year (World Bank, 2025).

In the HES, air pollutant emissions from the combustion of oil, natural gas and coal across end-use  sectors  decline  by  30%  over  the  next  decade,  compared  with  8%  in  the  CPS (Figure 4.30). The combustion of oil-derived fuels in passenger vehicles is the largest source of nitrogen oxide emissions globally. Nearly two-thirds of the emissions reductions in the HES come from transport electrification. The largest reductions in air pollutant emissions occur in advanced economies and China, where emissions fall by nearly 50% over the next decade in  the  HES.  Other  emerging  market  and  developing  economies  with  full  access  and  with access gaps both see emissions rise in the CPS, driven by a 20% increase in energy demand, with 65% of the increase met by fossil fuels. In the HES, air pollution in other emerging market and  developing  economies  declines  by  20%.  The  reductions  achieved  through  end-use electrification in the HES avoid roughly 240 000 premature deaths from ambient air pollution

each year relative to the CPS: nearly two-thirds of the avoided deaths are in other emerging market and developing economies.

Figure 4.30 ⊳ Air pollution emissions from fossil fuel use in end-uses by region in the CPS and HES, 2025-2035

<!-- image -->

The High Electrification Scenario reduces end-use air pollutant emissions by 30%, with transport electrification delivering nearly two-thirds of the reductions

Notes: Mt = million tonnes. Air pollution emissions include sulphur dioxide (SO2), nitrogen oxides (NOx) and fine particulate matter (PM2.5).

## 4.6 Inclusive electrification

## 4.6.1 Electricity access gap

For many emerging market and developing economies, the pathway to electrification begins with access to electricity. Access to affordable and reliable electricity supports education, healthcare and productive economic activity, and it is essential for economic development and improved living standards. Around 1.1 billion people worldwide have gained access to electricity since 2010, raising the global electrification rate from 80% fifteen years ago to 91% in  2025.  Developing  Asia  has  made  the  greatest  progress,  providing  electricity  access  to around 800 million people since 2010. Indonesia and India achieved universal access in 2020 and 2021 respectively.

Despite this, around 730 million people worldwide still lack access to electricity, and over 80% of those still without access live in sub-Saharan Africa. Although countries such as Kenya, Nigeria  and  Rwanda  have  made  notable  progress  in  expanding  electricity  access,  rapid population growth has meant that the total number of people without access in sub-Saharan Africa  has  remained broadly unchanged over the past decade. In 19 sub-Saharan African countries, population growth has outpaced the expansion of electricity access since 2015, resulting in an increase in the number of people without electricity.

4

Figure 4.31 ⊳ Population without access to electricity by region, 2010-2025

<!-- image -->

Despite substantial progress since 2010, around 730 million people still lack access to electricity in 2025, over 80% of whom live in sub-Saharan Africa

While  recent  policy  developments,  falling  technology  costs  and  multilateral  efforts  have improved the outlook, more than 510 million people are projected to remain without access to electricity in 2050 in the STEPS, nine out of ten of whom will live in sub-Saharan Africa. By replicating, in countries that still face electricity access gaps, the fastest rates of progress historically  achieved  in  countries  with  similar  socioeconomic  conditions,  the  Accelerating Clean Cooking and Electricity Services Scenario (ACCESS) finds that universal access could be achieved by around 2035,  with an average of around 80 million people gaining access each 2 year  between  now  and  2035  (Figure 4.32).  Most  new  connections  would  occur  in  subSaharan Africa, with around 70 million people benefiting annually. Of those gaining access, 45% would be connected through the grid, 30% through mini-grids and 25% through solar home systems. Achieving this would require average annual investment of approximately USD 23 billion.

The  additional  electricity  demand  from  households  gaining  access  under  the  ACCESS  is relatively modest in absolute terms. By 2035, newly connected households consume around 160 terawatt-hours (TWh), equivalent to 0.6% of today's global electricity demand, and to 10% of total residential electricity demand in those countries that currently have access gaps. The impact, however, varies significantly by region. Sub-Saharan Africa accounts for around 90 TWh - over half the total - equivalent to about 20% of the region's current total electricity demand. This raises the electrification rate in the region, but its increase is also supported by the efficiency benefits of access to clean cooking solutions (Box 4.2).

2 For explanation and definition of the Accelerating Clean Cooking and Electricity Services Scenario (ACCESS), see World Energy Outlook 2025 (IEA, 2025).

Figure 4.32 ⊳ Population lacking electricity access by scenario, 2010-2050, and electricity demand from new access in the ACCESS, 2035

<!-- image -->

If the fastest historical examples are replicated, universal access could be reached around 2035, with newly connected households increasing total electricity demand by 160 TWh

This relatively limited increase in electricity demand indicates that achieving universal access is not primarily constrained by the technical feasibility of installing the required electricity generation  capacity.  Instead,  the  main  barriers  are  mobilising  sufficient  investment  in challenging  contexts,  expanding  and  strengthening  electricity  infrastructure,  establishing supportive policy, regulation and institutional frameworks, and ensuring that electrification is accompanied by productive uses of electricity that stimulate economic activity, increase household incomes and enable households to afford this new service.

## Box 4.2 ⊳ The role of electricity in clean cooking, and clean cooking in electrification

Nearly 2 billion people still lack access to clean cooking globally, half of whom live in subSaharan Africa, around 45% in developing Asia and a further 3% in Latin America. These households rely on firewood, animal waste or kerosene to cook over open fires or on basic  stoves.  Such  methods  produce  harmful  smoke  with  severe  consequences  for health,  development  and  the  environment.  The  lack  of  access  to  clean  cooking contributes to 2.5 million premature deaths due to household air pollution globally each year. Households that lack access to modern cooking fuels spend an average of four hours per day collecting fuel and cooking: this has far-reaching impacts on productivity and education, with women and children bearing the greatest burden. Traditional cooking methods  also  emit  1.2 Gt  carbon  dioxide  equivalent  (CO2-eq)  annually  from  direct emissions and forest degradation, which is comparable to the combined emissions of international aviation and shipping.

4

Traditional cooking methods are highly inefficient, typically wasting 85%-95% of the input energy. As a result, the traditional use of biomass for cooking accounts for almost 5% of global total final energy consumption (TFEC), a disproportionately high share relative to the energy service it provides. In sub-Saharan Africa, biomass used for cooking accounts for half of all energy consumption. In countries with the largest access gaps, this share can reach three-quarters. Clean cooking solutions - electricity, liquefied petroleum gas (LPG), biogas, bioethanol and advanced biomass cookstoves - deliver the same cooking service while consuming 3- to 18-times less energy, depending on the technology. By gaining  access  to  clean  cooking,  households  can  therefore  realise  significant  energy efficiency gains.

In  the  ACCESS  scenario,  universal  access  to  clean  cooking  is  achieved  around  2040. Despite  continued  population  growth,  annual  residential  cooking  energy  demand  in emerging  market  and  developing  economies  falls  by  more  than  50%,  dropping  from around  23  exajoules  (EJ)  in  2025  to  11 EJ  in  2035.  Although  population  growth  adds around 3 EJ of demand over this period, this increase is more than offset by around 15 EJ of  savings  from  the  efficiency  gains  associated  with  the  transition  to  clean  cooking (Figure 4.33).

Figure 4.33 ⊳ Residential cooking energy demand in EMDE and population cooking with electricity by region in the ACCESS, 2025-2035

<!-- image -->

Note: EJ = exajoules; EMDE = emerging market and developing economies.

Almost 20% of the population gaining access to clean cooking in the ACCESS by 2035 around 340 million people - do so by using electric cookstoves. In parallel, households that already have access to clean cooking technologies which do not involve electricity for  example, LPG cookstoves - increasingly adopt electric cooking. By 2035, the total

number of people cooking with electricity globally increases by around 715 million, with 65%  of  this  growth  taking  place  in  advanced  economies  or  emerging  market  and developing economies that have already reached universal access. Electricity's share of total cooking demand rises from 6% to 18% over the same period: 3 percentage points of this gain reflect adoption of electric cooking, and the remainder reflects a fall in total cooking  demand as households switch to other clean fuels that use energy far more efficiently.

## 4.6.2 Reliable electrification can unlock productive uses and foster economic development

Many  emerging  market  and  developing  economies  stand  to  benefit  immensely  from  an expansion  of  economic  activities  as  people  gain  access  to  electricity.  As  discussed  in section 2.3,  several  areas  of  activity  offer  particular  opportunities  in  agriculture  and  light industry,  including  pumped irrigation, agro-processing, cold chains, and industrial motors and  low-temperature  heat.  These  opportunities  often  remain  under-developed  where households and businesses lack access to electricity or where electricity supply is unreliable.

In  many emerging market and developing economies, final electricity demand per capita remains very low, even where access rates have expanded (Figure 4.34). This reflects that electricity is still used only to a limited extent for productive activities. Economy-wide final electricity  demand  in  sub-Saharan  Africa  stood  at  around  350  kilowatt-hours  (kWh)  per capita  in  2025,  lower  than  in  any  other  developing  region. 3 This  is  less  than  the  average annual  electricity  consumption  of  a  single  household  refrigerator  in  the  United  States. Demand per capita also remains below this benchmark in Haiti, Myanmar and Yemen. Even among households with electricity access, average demand remains low and has actually declined over the past decade in sub-Saharan Africa. This partly reflects the growing share of newly  connected  households,  which  tend  to  consume  less  electricity  than  those  already connected.

Most  emerging  market  and  developing  economies  have  seen  growth  in  final  electricity demand per  capita  over  time,  but  no  comparable  increase  has  occurred  in  sub-Saharan Africa: in this region, per capita electricity consumption has not increased at all during the 21 st century. This is a sign not only that access rates are not improving in the aggregate in this  region,  but  also  that  current  levels  of  access  are  not  supporting  a  virtuous  circle  of increased productive use of electricity and increased capacity to pay for it. In part, it reflects unreliable supply, which limits the use of electricity in productive activities and constrains household consumption. Unreliable supply can prevent even established, highly competitive electric technologies, such as industrial motors, from displacing fossil-fuelled equipment (see section 2.3).

3 This considers the total population and not only those with access. Excluding South Africa, the per capita electricity consumption of Sub-Saharan Africa is around 200 kWh.

4

Figure 4.34 ⊳ Final electricity demand per capita by sector and region, and by country and access rate, 2025

<!-- image -->

IEA. CC BY 4.0.

Electricity demand per capita remains low in many developing economies. In most subSaharan African countries, it is below the consumption of a refrigerator in the United States

Notes: MWh = megawatt-hour; US = United States; LAC = Latin America and the Caribbean; SE Asia = Southeast Asia; Oth dev ASIA = other developing Asia excluding Southeast Asia, China, and India; SSA = sub-Saharan Africa;  ME  =  Middle  East.  Air  conditioner  and  refrigerator  values  represent  average  annual  electricity consumption per unit in US households in 2025.

Enterprise survey data show that the median firm in sub-Saharan Africa experiences 37 hours without grid electricity per month, compared with 19 hours in the Middle East and North Africa,  11  hours  in  Asia  and  5  hours  in  Latin  America.  These  regional  figures  hide  higher numbers in individual countries: for example, the median firm experiences 45 hours without electricity per month in Pakistan and 18 hours in the Dominican Republic. In Chad, Mali and Zambia, median outage durations exceed 240 hours per month, which is equivalent to being without electricity one in every three days. Unreliable electricity supply is not confined to countries with large access gaps: there are also frequent outages in countries with universal electricity access, including Bangladesh, Egypt and Iraq.

Direct economic impacts include lost sales and lower utilisation of productive assets, while indirect impacts include higher operating costs, disrupted production and  reduced competitiveness. Across emerging market and developing economies, estimated sales losses associated with power outages amount to around USD 240 billion, roughly equivalent to the GDP of Hungary (Figure 4.35). Almost half of these losses occur in sub-Saharan Africa, where they are equal to almost 6% of the region's GDP. The highest sales losses due to power outages  are  incurred  in  Brazil  (USD 55 billion),  South  Africa  (USD 48 billion)  and  Nigeria (USD 14 billion): these three countries together account for around half of the total.

Figure 4.35 ⊳ Median enterprise outage hours per month and associated estimated sales losses by region, latest available year

<!-- image -->

IEA. CC BY 4.0.

Sales losses from unreliable electricity supply amount to USD 240 billion, equal to the total GDP of Hungary

Notes: SSA = sub-Saharan Africa; Dev Asia = developing Asia; LAC = Latin America and the Caribbean; MENA = Middle East and North Africa. Sales losses are estimates based on the World Bank Enterprise Survey question: 'Please estimate the losses that resulted from power outages either as a percentage of total annual sales or as total annual losses'. Surveys are nationally representative for enterprises in the formal sector with at least 5 employees.

Source: IEA analysis based on World Bank Enterprise Survey database (2026).

To cope with power outages, firms also incur indirect costs to acquire, operate and maintain generators, diverting capital from alternative productive investments. Estimated spending on  generators  by  firms  amounts  to  USD 6 billion  a  year,  and  fuel  and  operational  costs account for another USD 59 billion (Rentschler et al., 2019). In some countries, generators provide  up  to  half  of  the  electricity  used  by  enterprises.  Drawing  the  same  amount  of electricity from a reliable grid supply would be much cheaper: electricity from generators typically costs 3 to 5 times as much as power from the grid in sub-Saharan Africa.

Improving the reliability of supply is central to efforts to unlock productive activities that drive economic development, yet action is often constrained by the weak financial health of utilities. Around 75% of utilities in sub-Saharan Africa and 45% in developing Asia are in poor financial  health,  limiting  their  ability  to  invest  in  network  maintenance  and  expansion (Figure 4.36). Unreliable supply limits electricity consumption by households and businesses, preventing utilities from increasing the revenues needed to strengthen their balance sheets and  make  these  investments.  Breaking  this  cycle  through  tariff  and  broader  regulatory reforms,  targeted  investment,  and  greater  domestic  and  international  public  finance  is essential.

4

Figure 4.36 ⊳ Share of enterprises' electricity coming from diesel generators and utilities by profitability status in selected country/region

<!-- image -->

IEA. CC BY 4.0.

Many enterprises in sub-Saharan Africa and developing Asia rely on their own generators, diverting electricity demand away from already financially constrained utilities

Notes: PNG = Papua New Guinea. Enterprise source of electricity is based on the latest available World Bank Enterprise Survey. Utility profitability is calculated as the peak load-weighted average net profitability across utilities using the UPBEAT database.

Sources: IEA analysis based on World Bank Enterprise Survey database (2026); World Bank UPBEAT database (2026).

## 4.6.3 Productive uses can strengthen the case for electrification

While access to reliable  and  affordable  electricity  can  unlock  productive  uses  that  foster economic development, productive uses can in turn strengthen the case for electrification. For example, an industrial or commercial consumer can provide an anchor load sufficient to improve  the  business  case  for  expanding  or  modernising  the  grid  in  a  particular  area, ensuring a minimum level of demand and revenue. Mini-grids remain capital-intensive, and systems serving mainly residential customers may struggle to recover their upfront costs because household electricity consumption is often low and concentrated in a short evening peak. Pairing these decentralised systems with a stable anchor load whenever possible would help to improve both viability and affordability.

Around 70% of people without access to electricity live in rural areas of sub-Saharan Africa, often far from existing network infrastructure. This remoteness creates a strong case for decentralised  electrification.  IEA  least-cost  electrification  analysis  indicates  that,  in  the ACCESS scenario, 30% of those gaining access by 2035 are connected through mini-grids. Agriculture,  which  is  largely  concentrated  in  these  rural  areas,  could  help  improve  the economics  of  rural  electrification  by  creating  productive  electricity  demand.  The  sector accounts for a substantial share of economic activity in sub-Saharan Africa, but electricity at present makes up less than 15% of its total energy demand. Potential productive uses of

electricity  span  the  entire  agricultural  value  chain  and  include  irrigation  pumping,  crop processing, cold storage and refrigeration, milk chilling and egg incubation. The potential electricity  demand  for  these  activities  could  reach  a  total  of  around  19 TWh  across sub-Saharan Africa. Much of this demand would arise during daylight hours, particularly for irrigation and crop processing, aligning well with solar PV generation.

Figure 4.37 ⊳ Potential electricity demand for irrigation by electrification status in sub-Saharan Africa

<!-- image -->

IEA. CC BY 4.0.

Almost two-thirds of the potential electricity demand for irrigation lies in unelectrified areas; over 40% is far from the grid and could support mini-grid development

Note: GWh = gigawatt-hour; Reliable electricity is based on a geospatial nighttime lights analysis, where a settlement pixel is statistically brighter than surrounding uninhabited land on at least 75% of observed nights per year, filtering out background noise from moonlight, weather, and sensor effects.

Sources: IEA analysis based on Spatial Production Allocation Model (SPAM) 2020 v2.2; Earth Engine (2025); and Farthing et al. (2023).

4

Across the region, IEA geospatial analysis of crop types, water requirements, rainfall and evaporation estimates the potential electricity demand for irrigation at 14.4 TWh per year, equivalent to three-quarters of the region's total potential electricity demand in agriculture (Figure 4.37). India has already demonstrated at scale the scope for electrifying irrigation through its PM KUSUM programme: this has supported the deployment of more than two -million solar pumps,  many  of  which  have  replaced  diesel-powered  alternatives.  In sub-Saharan Africa, demand is concentrated in the Sahel around the Niger-Nigeria border, East Africa and South Africa. An overlay of night-time lights, population and grid network data  indicate  that  around  9.4 TWh  of  this  potential  lies  in  areas  that  are  currently unelectrified. Of this, around one-third is within reach of existing grid infrastructure, while around 6 TWh lies in areas far from the grid, where it could provide anchor loads to support the deployment of decentralised systems.

Almost 80% of the communities gaining access to electricity through mini-grids in the ACCESS scenario live in agricultural areas. The level and profile of agricultural loads could lift capacity utilisation and revenues, making some projects viable in areas where residential demand alone would not justify investments, and enabling households to gain access to electricity at a lower cost. Electrification could in turn make agriculture more productive, resilient and cost-effective. Irrigation would raise yields, reduce dependence on rainfall and cut operating costs where electric pumps replace diesel-powered alternatives; cold storage and processing would reduce post-harvest losses and add value locally. For rural households, this would translate into higher and more stable incomes, significant time savings and improved food security.

Realising  this  potential  means  ensuring  that  farmers  and  agribusinesses  have  access  to finance, equipment and technical support. However, while agriculture can provide a valuable anchor load in some rural areas, it will not be able to do so in every community. In locations with  limited  agricultural  potential,  other  productive  uses  may  be  required  to  support affordable rural electrification projects.

## 4.6.4 Making use of decentralised technologies

The rapid deployment of solar PV and batteries in recent years has created new opportunities to  expand  electricity  access  and  improve  the  reliability  of  electricity  services,  while  also introducing new challenges for electricity systems. Trade flows of technologies such as solar PV and batteries provide a means to track the latest trends in countries where installation data lag or are lacking. These show that imports of solar PV to developing Asia increased fivefold  between  2020  and  2025,  and  those  to  Africa  increased  ninefold  (Figure 4.38). 4 Import  volumes  do  not  translate  directly  into  capacity  additions,  as  some  modules  may remain  in  inventories,  be  re-exported  to  other  countries,  or  await  installation.  They  do, however, give a good general idea of the scale of capacity additions in particular regions and countries.

4 Chinese trade data are used as a proxy for global trends, as China accounted for around 70% of global solar PV module and cell exports in 2025.

Figure 4.38 ⊳ PV module and cell imports by selected destination regions and countries, 2017-2025

<!-- image -->

Solar PV imports have increased fourteenfold since 2017, reaching 360 GW in 2025, with particularly strong growth in Asia and sub-Saharan Africa

Notes: MW = megawatt; Other dev Asia = Developing Asia excluding India and China; LAC = Latin America and the Caribbean; DRC = Democratic Republic of the Congo. Analysis based on Chinese export data.

Source: IEA analysis based on GACC (2026).

Several countries have recorded particularly rapid growth. India has increased its imports ninefold since 2020  and is now the biggest importer of solar PV; Indonesia's imports have 5 risen from around 115 MW in 2020 to more than 28 GW in 2025, making it the second-largest importer; and Pakistan's imports have increased tenfold, and it has become the third-largest importer among emerging market and developing economies. Growth has also accelerated sharply in sub-Saharan Africa, led by Nigeria, which imported more than 2.6 GW in 2025 after a twelvefold increase since 2020, and Ethiopia, which has seen imports rise from 85 MW in 2024 to 2.5 GW in 2025. Other countries have also recorded notable growth, including Kenya and Tanzania. In total, sub-Saharan Africa outside South Africa imported 35 GW of solar PV modules and cells between 2017 and 2025.

The expansion  of  solar  PV  has  been  accompanied  by  the  growing  availability  and  use  of batteries. Around 70% of global battery production is destined for EVs, but stationary battery storage accounts for around 15% of the total, and demand is rising rapidly as battery costs fall. Imports by emerging market and developing economies have tripled over the past five years, and they surged by almost 50% in 2025. As batteries become more affordable and widely available, they are increasingly deployed alongside solar PV: this allows households and businesses to store excess generation for use when solar output is low. Reflecting this trend, sales of solar kits in sub-Saharan Africa increased by around 15% in 2025.

5 This includes only imports of cells and panels.

4

The recent wave of solar PV and battery deployment in emerging market and developing economies is opening up new electrification pathways and delivering a range of potential benefits.  Utility-scale  projects  expand  national  generation  capacity  and  help  meet  rising electricity demand rapidly and at lower cost, while solar-based mini-grids and solar home systems  extend  electricity  access  to  rural  households  located  far  from  existing  grid infrastructure.

Figure 4.39 ⊳ Capacity, consumption and emissions of generators in sub-Saharan Africa, 2024

<!-- image -->

IEA. CC BY 4.0.

Generators remain widespread in sub-Saharan Africa, consume around 290 kb/d of oil and emit around 45 Mt CO2 a year

Note: kb/d = thousand barrels per day.

Sources:  IEA  analysis  based  on  CEPII-BACI  (2026);  World  Bank  Enterprise  Survey  database  (2026);  and Afrobarometer Rounds 9 and 10 (2026).

A significant proportion of imported solar panels is being purchased directly by households, farmers and small businesses, sometimes together with battery storage, to upgrade their electricity  service  (Box 4.3).  These  systems  enable  users  to  consume  more  electricity, improve the reliability of their electricity supply, support productive use of energy and, in some cases, replace small generators previously used for back-up power. Generators are expensive to buy and maintain, and replacing them with solar PV and battery systems can lower energy bills and reduce oil consumption, easing pressure on foreign exchange reserves in countries that depend heavily on imported oil (see section 2.3). In sub-Saharan Africa, for instance, around 125 GW of diesel and petrol generators are mostly used to provide back-up power where grid supply is unreliable and to support industry and agriculture: they consume around 290 thousand barrels per day (kb/d) of oil, equivalent to almost 15% of the region's final consumption of oil products (Figure 4.39). Solar PV and battery systems involve broadly the same upfront costs as small generators but cost much less to run: at average oil prices,

their total lifetime costs are typically around half those of a small generator, although this varies by country.

Despite these benefits, this new wave of solar PV also brings challenges. Where electricity generated by decentralised solar installations is exported to the grid, it changes power flows within distribution networks,  making  their  operation  more  complex.  High  levels  of distributed  generation  can  create  voltage,  protection,  fault-level  and  reverse-power-flow challenges  in  networks  originally  designed  for  largely  one-way  power  flows.  Against  this background, accommodating higher shares of decentralised solar systems requires a re-think of  distribution  system  operating  principles,  together  with  investment  to  reinforce  and modernise the infrastructure. Even where decentralised solar systems are not connected to the grid, widespread adoption can create challenges where it is driven by poor reliability of electricity supply: unreliable grid service encourages households and businesses to invest in decentralised solar, reducing their demand for grid electricity; lower electricity sales then erode utility revenues, reducing the financial resources available to maintain and modernise the network and potentially further affecting service quality.

## Box 4.3 ⊳ Development of distributed solar PV and batteries in Pakistan

Pakistan stands out as an example of rapid adoption of distributed energy technologies. In the five-year period from 2021 to 2025, the country imported approximately 51 GW of solar panels, comparable to the total installed capacity in Argentina. Given the scale and speed of this adoption, it is challenging to establish how much of this capacity has been  installed  and  where.  Estimation  methods  include  on-the-ground  surveys,  utility data analysis and satellite imagery analysis. In 2025, the installed distributed solar PV capacity in Pakistan was estimated to be in the order of 28-38 GW, with rooftop systems accounting for roughly 80% of this capacity, and the residential sector accounting for half of all installations (Ember, 2026; PRIED, 2026).

Several factors led to this rapid uptake. Electricity tariffs  increased  substantially  after 2019, while grid reliability  deteriorated.  As  a  result,  major  outages  in  2021  and  2023 prompted many households and businesses to turn to self-generation. At the same time, solar  PV  costs  have  fallen  sharply  over  the  past  decade,  making  the  technology increasingly affordable and cost-competitive. Adoption was further supported by a netmetering scheme which incentivised consumers to feed excess electricity back into the grid. Similar factors are leading to a rapid uptake of distributed energy resources in other countries.  A  notable  example  is  South  Africa,  where  distributed  solar  PV  capacity  is estimated to have increased from just over 1 GW in 2020 to 7.5 GW in 2025 against a backdrop of grid load shedding and utility price increases (Dippenaar &amp; Bekker, 2026).

Pakistan  also  imported  almost  USD 300 million  worth  of  batteries  in  2025,  up  from USD 120 million in 2022 (Figure 4.40). It is reasonable to assume that the same factors contributing to rapid solar PV uptake in Pakistan are also driving the boom in battery sales, and that many of these batteries are being paired with solar PV. Combining solar

4

PV  with  batteries  enables  households  and  small  businesses  to  shift  daytime  solar generation  to  the  evening  while  maintaining  electricity  supply  during  frequent  grid outages.

Figure 4.40 ⊳ Imports of solar PV and lithium-ion batteries in Pakistan, 2018-2025

<!-- image -->

Source: IEA analysis based on GACC (2026).

The rapid uptake of distributed energy technologies in Pakistan has improved electricity reliability for consumers that can afford them, but is also creating new challenges for the power  sector  by  reducing  electricity  purchases  from  the  grid.  Because  utilities  must continue  to  recover  large,  fixed  capacity  payments  owed  to  independent  power producers, declining grid sales increase the cost-recovery burden they face. This creates a risk that those costs will have to be passed on to their remaining consumers through higher  tariffs,  unless  utilities  can  absorb  those  costs  themselves  or  persuade  the government to subsidise them. The result could be to reinforce an unequal cycle in which consumers able to afford solar and battery systems reduce their dependence on the grid and  benefit  from  more  reliable  electricity,  while  those  unable  to  make  the  upfront investment  remain  reliant  on  electricity  supply  that  is  becoming  less  reliable  and increasingly expensive.

<!-- image -->

<!-- image -->

## Definitions

This  annex  provides  general  information  on  terminology  used  throughout  this  report including: units and general conversion factors; definitions of fuels, processes and sectors; regional and country groupings; and abbreviations and acronyms.

## Units

| Area                              | km 2                                               | square kilometres                                                                                                                                                                                                                  |
|-----------------------------------|----------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Distance                          | km pkm                                             | kilometre passenger-kilometre tonne-kilometre                                                                                                                                                                                      |
|                                   | kg CO 2 -eq g CO 2 /km g CO 2 /kWh kg CO 2 /kWh MJ | kilogrammes grammes grammes of carbon dioxide per kilowatt-hour kilogrammes of carbon dioxide per kilowatt-hour megajoule (1 joule x 10 6 ) (1 joule x 10 9 )                                                                      |
| Energy                            | GJ TJ PJ EJ W kW MW GW TW kWh MWh                  | gigajoule terajoule (1 joule x 10 12 ) petajoule (1 joule x 10 15 ) exajoule (1 joule x 10 18 ) watt (1 joule per second) kilowatt (1 watt x 10 3 ) megawatt (1 watt x 10 6 ) gigawatt (1 watt x 10 9 ) terawatt (1 watt x 10 12 ) |
|                                   | MBtu Wh/kg                                         | million British thermal units watt hours per kilogramme                                                                                                                                                                            |
| Energy density Energy equivalence | boe mboe/d                                         | barrel of oil equivalent                                                                                                                                                                                                           |

<!-- image -->

|            | Mtce btce    | million tonnes of coal equivalent (equals 0.7 Mtoe) billion tonnes of coal equivalent   |
|------------|--------------|-----------------------------------------------------------------------------------------|
| Mass       | kg           | kilogramme                                                                              |
|            | t            | tonne (1 tonne = 1 000 kg)                                                              |
|            | kt           | kilotonne (1 tonne x 10 3 )                                                             |
|            | Mt           | million tonnes (1 tonne x 10 6 )                                                        |
|            | Gt           | gigatonne (1 tonne x 10 9 )                                                             |
| Monetary   | USD million  | 1 US dollar x 10 6                                                                      |
|            | USD billion  | 1 US dollar x 10 9                                                                      |
|            | USD trillion | 1 US dollar x 10 12                                                                     |
|            | USD/t CO 2   | US dollars per tonne of carbon dioxide                                                  |
| Volumetric | bcm          | billion cubic metres                                                                    |
|            | tcm          | trillion cubic metres                                                                   |
|            | barrel       | one barrel of crude oil                                                                 |
|            | kb/d         | thousand barrels per day                                                                |
|            | mb/d         | million barrels per day                                                                 |

## General conversion factors for energy

|      | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|
|      | EJ                          | Mtoe                        | MBtu                        | bcme                        | Mtce                        | TWh                         |
| EJ   | 1                           | 23.88                       | 9.478 x 10 8                | 27.78                       | 34.12                       | 277.8                       |
| Mtoe | 0.04187                     | 1                           | 3.968 x 10 7                | 1.163                       | 1.429                       | 11.63                       |
| MBtu | 1.0551 x 10 -9              | 2.520 x 10 -8               | 1                           | 2.931 x 10 -8               | 3.60 x 10 -8                | 2.931 x 10 -7               |
| bcme | 0.036                       | 0.860                       | 3.412 x 10 7                | 1                           | 1.228                       | 10                          |
| Mtce | 0.02931                     | 0.700                       | 2.778 x 10 7                | 0.8141                      | 1                           | 8.141                       |
| TWh  | 0.0036                      | 0.086                       | 3 412 x 10 6                | 0.1                         | 0.1228                      | 1                           |

Note: There is no generally accepted definition of barrel of oil equivalent (boe); typically the conversion factors used vary from 7.15 to 7.40 boe per tonne of oil equivalent. Conversions to and from billion cubic metres of natural gas equivalent (bcme) are given as representative multipliers but may differ from the average values obtained by converting natural gas volumes between International Energy Agency (IEA) balances due to the use of country-specific energy densities. Lower heating values (LHV) are used throughout.

## Currency conversions

| Exchange rates (2025 annual average)   |   1 US dollar (USD) equals: |
|----------------------------------------|-----------------------------|
| British Pound                          |                        0.76 |
| Chinese Yuan Renminbi                  |                        7.19 |
| Euro                                   |                        0.88 |
| Indian Rupee                           |                       87.16 |
| Japanese Yen                           |                      149.66 |

Source: World Bank Data: Official exchange rate (Local Currency Units per USD, period average), https://data.worldbank.org/indicator/PA.NUS.FCRF, accessed September 2026.

## Definitions

Agriculture: Includes all energy used on farms, in forestry and for fishing.

Ammonia (NH3)   A  compound  of  nitrogen  and  hydrogen  (NH3)  that  is  an  industrially : produced  input  to  fertiliser  manufacturing,  resulting  in  substantial  carbon  dioxide  (CO2) emissions from the use of fossil fuel inputs to generate the input hydrogen. With properties similar  to  liquefied  petroleum  gas,  ammonia  can  also  be  used  directly  as  a  fuel  in  direct combustion processes, as well as in fuel cells, and can be cracked to release its hydrogen content. As it can be made from low-emissions hydrogen, ammonia has the potential to be a low-emissions fuel if the production process, including nitrogen separation, is powered by low-emissions  energy.  Produced  in  such  a  way,  ammonia  is  considered  a  low-emissions hydrogen-based liquid fuel.

Anchor load: A  stable, sizeable electricity demand (e.g. an agribusiness or industrial user) that underpins the business case for a grid extension or mini-grid.

Aviation: This transport mode includes both domestic and international flights and their use of aviation fuels. Domestic aviation covers flights that depart and land in the same country; flights for military purposes are included. International aviation includes flights that land in a country other than the departure location.

Back-up generation capacity: Households and businesses connected to a main power grid may also have a source of back-up power generation capacity that, in the event of disruption, can  provide  electricity.  Back-up  generators  are  typically  fuelled  with  diesel  or  gasoline. Capacity can be as little as a few hundred watts. Such capacity is distinct from mini-grid and off-grid systems that are not connected to a main power grid.

Battery storage: Energy  storage  technology  that  uses  reversible  chemical  reactions  to absorb, store and release electricity on demand.

Behind-the-meter (BTM)   Electricity  generation,  storage  or  flexible  demand  resources : located on the customer side of the electricity meter.

Biodiesel: Diesel-equivalent  fuel  made  from  the  transesterification  of  vegetable  oils  and animal fats, hydrogenated vegetable oil (HVO), thermal processes such as gasification and fermentation.

Bioenergy: Energy  content  in  solid,  liquid  and  gaseous  products  derived  from  biomass feedstocks  and  biogas.  It  includes  solid  bioenergy,  liquid  biofuels  and  biogases.  Excludes hydrogen produced from bioenergy, including via electricity from a biomass-fired plant, as well as synthetic fuels made with CO2 feedstock from a biomass source .

Biogas: A  mixture  of  methane,  CO2  and  small  quantities  of  other  gases  produced  by anaerobic digestion of organic matter in an oxygen-free environment. It includes landfill gas and sewage sludge gas, and it can be upgraded by removing non-methane constituents, principally CO2.

Biogases: Include both biogas and biomethane.

A

Biogasoline: Includes all liquid biofuels used as a substitute for gasoline.

Biojet kerosene: Kerosene substitute produced from biomass. It includes conversion routes such as hydro-processed esters and fatty acids (HEFA) and biomass gasification with FischerTropsch. It excludes synthetic kerosene produced from biogenic carbon dioxide.

Biomethane: Biomethane is a near-pure source of methane produced either by 'upgrading' biogas (a process that removes any carbon dioxide and other contaminants present in the biogas) or through the gasification of solid biomass followed by methanation. It is also known as renewable natural gas.

Buildings: The  buildings sector includes energy used in residential and services buildings. Services  buildings  include  commercial  and  institutional  buildings  and  other  non-specified buildings. Building energy use includes space heating and cooling, water heating, lighting, appliances  and  cooking  equipment.  It  also  includes  energy  used  by  data  centres  and desalination plants.

Bunkers: Include both international marine bunker fuels and international aviation bunker fuels.

Capacity adequacy: The ability of the power system to provide sufficient available capacity to meet electricity demand during all expected operating conditions, including periods of peak demand and peak residual load.

Carbon Border Adjustment Mechanism (CBAM)  An EU measure applying a carbon price to : selected  carbon-intensive  imports,  affecting  the  competitiveness  of  electrified  vs  fossilbased production.

Carbon capture, utilisation and storage (CCUS)   The  process  of  capturing  carbon  dioxide : emissions  from  fuel  combustion,  industrial  processes  or  directly  from  the  atmosphere. Captured CO2 emissions can be stored in underground geological formations, onshore or offshore, or used as an input or feedstock in manufacturing.

Carbon dioxide (CO2)   A  gas  consisting  of  one  part  carbon  and  two parts  oxygen.  It  is  an : important greenhouse (heat-trapping) gas.

Clean cooking systems: Cooking  solutions  that  release  less  harmful  pollutants,  are  more efficient and environmentally sustainable than traditional cooking options that make use of solid  biomass,  coal  or  kerosene.  It  refers  to  improved  cook  stoves,  biogas/biodigester systems, electric stoves, liquefied petroleum gas, natural gas or ethanol stoves.

Clean energy: In power ,  clean energy includes: renewable energy sources; nuclear power; fossil fuels fitted with CCUS; hydrogen and ammonia; battery storage; and electricity grids. In efficiency ,  clean  energy  includes  energy  efficiency  in  buildings,  industry  and transport, excluding domestic navigation. In end-use applications , clean energy includes: direct use of renewables; electric vehicles; electrification in buildings, industry and international marine transport; CCUS in industry and direct air capture. In fuel supply , clean energy includes lowemissions fuels, direct air capture and measures to reduce the emissions intensity of fossil fuel production.

Coal: Consists of both primary coal, i.e. lignite, coking and steam coal, and derived fuels, e.g. patent fuel, brown-coal briquettes, coke-oven coke, gas coke, gas works gas, coke-oven gas, blast furnace gas and oxygen steel furnace gas. Peat is also included.

Coking coal: A type of coal that can be used for steel making (as a chemical reductant and a source of heat), where it produces coke capable of supporting a blast furnace charge. Coal of this quality is commonly known as metallurgical coal.

Concentrating solar power (CSP)  Thermal power generation technology that collects and : concentrates sunlight to produce high temperature heat to generate electricity.

Critical minerals: A  wide  range  of  minerals  and  metals  that  are  essential  for  key  energy, digital and other modern technologies, but whose supply chains are vulnerable to disruption. While definitions and criteria vary across countries, they typically include chromium, cobalt, copper, gallium, germanium, graphite, lithium, manganese, molybdenum, nickel, platinum group metals, zinc, and rare earth elements.

Curtailment: The reduction of electricity generation below the level that could otherwise be produced, typically from variable renewables, due to network constraints, power system operational requirements or market conditions.

Data centres: Facilities that house information technology (IT) equipment, such as servers, storage  systems  and  networking  equipment,  and  are  equipped  with  cooling  and  other auxiliary systems to keep the IT equipment operating under optimal conditions.

Decomposition analysis: A  statistical  method  that  decomposes  an  aggregate  indicator  to quantify the relative contribution of a set of pre-defined factors leading to a change in the aggregate indicator. The World Energy Outlook uses an additive index decomposition of the type Logarithmic Mean Divisia Index (LMDI).

Demand-side response (DSR)  Describes actions which can influence the load profile such as : shifting the load curve in time without affecting total electricity demand, or load shedding such as interrupting demand for a short duration or adjusting the intensity of demand for a certain amount of time.

Desalination: The production of freshwater from seawater or brackish water.

Direct air capture (DAC)   A  type  of  CCUS  technology  that  captures  CO2  directly  from  the : atmosphere using liquid solvents or solid sorbents. It is generally coupled with permanent storage  of  the  CO2  in  deep  geological  formations  or  its  use  in  the  production  of  fuels, chemicals, building materials or other products. When coupled with permanent geological CO2 storage, DAC is a carbon removal technology, and it is known as direct air capture and storage (DACS).

Dispatchable generation: Electricity from technologies whose power output can be readily controlled  up  to  the  nameplate  capacity,  i.e. increased  to  maximum  rated  capacity  or decreased to zero, in order to help match supply with demand.

A

Distributed energy resources (DER) : Small-scale electricity generation, storage and controllable  loads  (e.g.  rooftop  solar  PV,  batteries,  EVs)  located  close  to  electricity consumers, either behind-the-meter or connected to distribution networks.

Electric arc furnace: Furnace that heats material by means of an electric arc. It is used for scrap-based  steel  production  but  also  for  ferroalloys,  aluminium,  phosphorus  or  calcium carbide.

Electric vehicles (EVs)  Electric vehicles include battery electric vehicles (BEVs) and plug-in : hybrid electric vehicles (PHEVs).

Electricity demand: Defined as total gross electricity generation less own use generation, plus net trade (imports less exports), less transmission and distribution losses.

Electricity generation: Defined as the total amount of electricity generated by power only or combined heat  and power plants  including  generation  required  for  own  use  and  before curtailment. This is also referred to as gross generation.

Electrification rate: The share of electricity in total final energy consumption.

Electrolysis: Process of converting electric energy to chemical energy. Most relevant for the energy sector is water electrolysis, which splits water molecules into hydrogen and oxygen molecules. The resulting hydrogen is called electrolytic hydrogen.

End-use sectors: Include industry, transport, buildings and other, i.e. agriculture and other non-energy use.

Energy demand:

See total energy supply.

Energy-intensive industries: Includes production and manufacturing in the branches of iron and steel, chemicals, non-metallic minerals (including cement), non-ferrous metals (including aluminium), and paper, pulp and printing.

Energy-related and industrial process CO2 emissions: Carbon  dioxide  emissions  from  fuel combustion, industrial  processes,  and  fugitive  and  flaring  CO2  from  fossil  fuel  extraction. Unless otherwise stated, CO2 emissions in the World Energy Outlook refer to energy-related and industrial process CO2 emissions.

Energy services: A  personal  or  societal  gain  from  the  use  of  energy.  Includes, inter  alia, heating,  cooling,  lighting,  entertainment,  mobility,  nourishment,  hygiene  and  education. Also see useful energy.

Flexible AC transmission systems (FACTS): Power-electronic  devices  that  control  voltage, power flow and stability on alternating current (AC) networks, helping grids operate closer to their limits.

Fossil fuels: Coal, oil and natural gas. Total fossil fuel use is equal to unabated fossil fuels plus fossil fuels with CCUS and non-energy use of fossil fuels.

Gases:

See gaseous fuels.

Geothermal: Heat derived from the sub-surface of the earth, usually using a working fluid such  as  water  and/or  steam  to  bring  the  energy  to  the  surface.  Depending  on  its characteristics,  geothermal  energy  can  be  used  for  heating  and  cooling  purposes  or  be harnessed to generate clean electricity if the temperature is adequate.

Grid-enhancing technologies (GETs) : Hardware  and  software  (e.g.  dynamic  line  rating, power-flow control, topology optimisation, reconductoring) that improve utilization of grid capacity.

Heat (end-use)  Can be obtained from the combustion of fossil or renewable fuels, direct : geothermal or solar heat systems, exothermic chemical processes and electricity (through resistance heating or heat pumps which can extract heat from ambient air and liquids). This category  refers  to  the  wide  range  of  end-uses,  including  space  and  water  heating,  and cooking in buildings, desalination and process applications in industry. It does not include cooling applications.

Heat (supply) : Obtained  from  the  combustion  of  fuels,  nuclear  reactors,  large-scale heat pumps,  geothermal  or  solar  resources.  It  may  be  used  for  heating  or  cooling,  or converted into mechanical energy for transport or electricity generation. Commercial heat sold is reported under total final consumption with the fuel inputs allocated under power generation.

Heat pump: A  device  that  uses  electricity  to  move  heat  from  a  lower-  to  a  highertemperature source, delivering heating (or, when reversible, cooling) at efficiencies typically 3-5 times that of combustion equipment.

Heavy-duty trucks (HDTs) : Include both  medium  freight  trucks  (gross  weight 3.5 to 15 tonnes) and heavy freight trucks (gross weight &gt;15 tonnes).

Heavy-duty vehicles (HDVs) : Includes HDTs and buses.

Heavy industries:

Iron and steel, chemicals and cement.

Hydrogen: Hydrogen is used in the energy system as an energy carrier, as an industrial raw material,  or  is  combined  with  other  inputs  to  produce  hydrogen-based  fuels.  Unless otherwise stated, hydrogen in this report refers to low-emissions hydrogen.

Hydrogen-based fuels: Includes  ammonia  and  synthetic  hydrocarbons  (gases  and  liquids) that derive their energy content from a pure, or nearly pure, hydrogen feedstock. If produced from low-emissions hydrogen, these fuels are low-emissions hydrogen-based fuels.

Hydropower: Refers to the electricity produced in hydropower projects. It excludes output from pumped storage and marine (e.g. tidal and wave technologies).

Improved cook stoves: Intermediate and advanced improved biomass cook stoves (ISO tier &gt; 1). It excludes basic improved stoves (ISO tier 0-1).

Industry: The sector includes fuel used within the manufacturing and construction industries. Key  industry  branches  include  iron  and  steel,  chemicals  and  petrochemicals,  cement, aluminium, and pulp and paper. Use by industries for the transformation of energy into

A

another form or for the production of fuels is excluded and reported separately under other energy sector. There is an exception for fuel transformation in blast furnaces and coke ovens, which are reported within iron and steel. Consumption of fuels for the transport of goods is reported as part of the transport sector, while consumption of fuels by off-road vehicles is reported under the specific sector. For instance, fuels consumed by bulldozers as a part of industrial operations is reported in industry.

International aviation bunkers: Include  the  deliveries  of  aviation  fuels  to  aircraft  for international  aviation.  Fuel  used  by  airlines  for  their  road  vehicles  are  excluded.  The domestic/international split is determined on the basis of departure and landing locations and not by the nationality of the airline. For many countries this incorrectly excludes fuels used by domestically owned carriers for their international departures.

International marine bunkers: Include the quantities delivered to ships of all flags that are engaged in international navigation. The international navigation may take place at sea, on inland  lakes  and  waterways,  and  in  coastal  waters.  Consumption  by  ships  engaged  in domestic navigation is excluded. The domestic/international split is determined on the basis of  port  of  departure  and  port  of  arrival,  and  not  by  the  flag  or  nationality  of  the  ship. Consumption by fishing vessels and by military forces is excluded and instead included in the residential, services and agriculture category.

Investment: Energy investment is the capital expenditure in fuel supply, the power sector, energy  efficiency  and  other  end-use.  Fuel  supply  investment  includes  the  production, transformation and transport of oil, gas, coal, low-emissions fuels and direct air capture. Power  sector  investment  includes  new  construction  and  refurbishment  of  generation, electricity  grids  (transmission  and  distribution),  and  battery  storage.  Energy  efficiency investment  includes  efficiency  improvements  in  buildings,  industry  and  transport.  Other end-use investment includes equipment for the direct use of renewables and other lowemissions fuels, electric vehicles, public electric vehicle chargers, electrification in buildings, industry  and  international  marine  transport,  and  CCUS  in  industry.  Data  and  projections reflect capital expenditure over the lifetime of projects and are presented in real terms in year-2024  US  dollars  converted  at  market  exchange  rates  unless  otherwise  stated.  Total investment reported for a year reflects the amount spent in that year.

Levelised cost of electricity (LCOE)  An indicator of the expected average production cost for : each  unit  of  electricity  generated  by  a  technology  over  its  economic  lifetime.  The  LCOE combines into a single metric all the cost elements directly associated with a given power technology, including construction, financing, fuel, maintenance and costs associated with a carbon price. It does not include network integration or other indirect costs. For a more complete indicator, see value-adjusted levelised cost of electricity (VALCOE).

Light-duty vehicles (LDVs)   Include  passenger  cars  and  light  commercial  vehicles  (gross : vehicle weight &lt; 3.5 tonnes).

Light industries: Include  non-energy-intensive  industries:  food  and  tobacco;  machinery; mining and quarrying; transportation equipment; textiles; wood harvesting and processing and construction.

Liquid biofuels: Liquid  fuels  derived  from  biomass  or  waste  feedstock,  including  ethanol, biodiesel  and  biojet  fuels.  Unless  otherwise  stated,  biofuels  are  expressed  in  energyequivalent volumes of gasoline, diesel and kerosene.

Low-emissions electricity: Includes  output  from  renewable  energy  technologies,  nuclear power, fossil fuels fitted with CCUS, hydrogen and ammonia.

Low-emissions fuels: Include modern bioenergy, low-emissions hydrogen and low-emissions hydrogen-based fuels.

Low-emissions hydrogen: Includes  hydrogen  that  is  produced  through  water  electrolysis with electricity generated from a low-emissions source, e.g. solar, wind and nuclear power. Hydrogen produced from biomass or from fossil fuels with CCUS technology is also counted as  low-emissions  hydrogen.  Production  from  fossil  fuels  with  CCUS  is  included  only  if upstream emissions are sufficiently low, if capture at high rates is applied to all CO2 streams associated with the production route, and if all CO2 is permanently stored to prevent its release into the atmosphere. The same principle applies to low-emissions feedstocks and hydrogen-based fuels made using low-emissions hydrogen and a sustainable carbon source of biogenic origin or directly captured from the atmosphere.

Low-emissions hydrogen-based fuels: Fuels produced from low-emissions hydrogen. Includes ammonia, methanol and other synthetic hydrocarbons (gases and liquids) made from low-emissions hydrogen when any carbon inputs, e.g. from CO2, are not from fossil fuels or fossil-derived process emissions.

Marine energy: Mechanical energy harvested from ocean currents, tidal movement or wave motion and exploited for electricity generation.

Mini-grids: Small electric grid systems, not connected to main electricity networks, linking a number of households and/or other consumers.

Modern energy access: Includes household access to a minimum level of electricity, initially equivalent to 250 kilowatt-hours (kWh) annual demand for a rural household and 500 kWh for an urban household; household access to less harmful and more sustainable cooking and heating  fuels,  and  improved/advanced  stoves;  access  that  enables  productive  economic activity; and access for public services.

Modern gaseous bioenergy: See biogases.

Modern renewables: Include all renewables with the exception of the traditional use of solid biomass.

Modern solid bioenergy: Includes all solid bioenergy products except the traditional use of biomass. It also includes the use of solid bioenergy in intermediate and advanced improved biomass cook stoves (ISO tier &gt; 1), requiring fuel to be cut into small pieces or often using processed biomass such as pellets.

Natural gas: A gaseous fossil fuel, consisting mostly of methane. Occurs in deposits, whether liquefied  or  gaseous.  In  IEA  analysis  and  statistics,  it  includes  both  non-associated  gas

A

originating  from  fields  producing  hydrocarbons only in gaseous form, and associated gas produced in association with crude oil production, as well as methane recovered from coal mines.  Natural  gas  liquids,  manufactured  gas  (i.e.  produced  from  municipal  or  industrial waste, or sewage) and quantities vented or flared are not included. Natural gas data in cubic metres  are  expressed  on  a  gross  calorific  value basis  and  are  measured  at  15 °C  and  at 760 mm Hg (Standard Conditions). Natural gas data expressed in tonnes of oil equivalent, mainly  to  allow  comparison  with  other  fuels,  are  on  a  net  calorific  basis.  The  difference between the net and the gross calorific value is the latent heat of vaporisation of the water vapour produced during combustion of the fuel.

Non-energy-intensive industries: See other industry.

Non-energy use: The use of energy products as raw materials for the manufacture of nonenergy products, e.g. natural gas used to produce fertiliser, as well as for direct uses that do not  involve  using  the  products  as  a  source  of  energy,  or  as  a  transformation  input e.g. lubrication, sealing, roading surfacing, preservation or use as a solvent. Note that for biofuels, only the amounts specifically used for energy purposes, a small part of the total, are included in energy statistics. Therefore, the non-energy use of biomass is not taken into consideration and the quantities are null by definition.

Non-renewable waste: Non-biogenic waste, such as plastics in municipal or industrial waste.

Nuclear power: Refers to the electricity produced by a nuclear reactor, assuming an average conversion efficiency of 33%.

Off-grid systems: Mini-grids and stand-alone systems for individual households or groups of consumers not connected to a main grid.

Offshore wind: Refers to electricity produced by wind turbines that are installed in open water, usually in the ocean. Includes fixed offshore wind (fixed to the seabed) and floating offshore wind.

- Oil: A liquid fuel. Usually refers to fossil fuel mineral oil. Includes oil from both conventional and unconventional oil production. Petroleum products include refinery gas, ethane, liquid petroleum gas, aviation gasoline, motor gasoline, jet fuel, kerosene, gas/diesel oil, heavy fuel oil, naphtha, white spirits, lubricants, bitumen, paraffin, waxes and petroleum coke.

Other energy sector: Covers  the  use  of  energy  by  transformation  industries  and  energy losses  in  converting  primary  energy  into  a  form  that  can  be  used  in  the  final  consuming sectors. It includes losses in low-emissions hydrogen and hydrogen-based fuels production, bioenergy  processing,  gas  works,  petroleum  refineries,  coal  and  gas  transformation  and liquefaction. It also includes energy own use in coal mines, in oil and gas extraction and in electricity and heat production. Transfers and statistical differences are also included in this category. Fuel transformation in blast furnaces and coke ovens are not accounted for in the other energy sector category.

Other industry: A category of industry branches that includes construction, food processing, machinery, mining, textiles, transport equipment, wood processing and remaining industry. It is sometimes referred to as non-energy-intensive industry.

Passenger car: A  road  motor  vehicle,  other  than  a  moped  or  a  motorcycle,  intended  to transport passengers. It includes vans designed and used primarily to transport passengers. Light  commercial  vehicles,  motor  coaches, urban buses  and mini-buses/mini-coaches  are excluded.

Passenger-kilometre (pkm)   A  unit  used  in  the  transport  sector  to  quantify  the  distance : travelled by passengers. One pkm represents one passenger traveling one kilometre.

Plastic collection rate: Proportion  of  plastic  that  is  collected  for  recycling  relative  to  the quantity of recyclable waste available.

Power generation: Refers to electricity generation and heat production from all sources of electricity,  including  electricity-only  power  plants,  heat  plants,  and  co-generation,  i.e. combined heat and power plants. Both main activity producer plants and small plants that produce fuel for their own use, i.e. auto-producers, are included.

Process emissions: CO2 emissions produced from industrial processes which chemically or physically  transform  materials.  A  notable  example  is  cement  production,  in  which  CO2  is emitted when calcium carbonate is transformed into lime, which in turn is used to produce clinker.

Process heat: The use of thermal energy to produce, treat or alter manufactured goods.

Productive uses: Energy used towards an economic purpose: agriculture, industry, services and non-energy use. Some energy demand from the transport sector, for example. freight, could be considered as productive, but is treated separately.

Rare earth elements (REEs)  A group of seventeen chemical elements in the periodic table, : specifically the fifteen lanthanides plus scandium and yttrium. REEs are vital inputs for key energy technologies, including wind turbines, electric vehicle motors and electrolysers.

Renewables: Include bioenergy, geothermal, hydropower, solar photovoltaics, concentrating solar power, wind and marine (tidal and wave) energy for electricity and heat generation.

Residential: Energy used by households including space heating and cooling, water heating, lighting, appliances, electronic devices and cooking.

Residual (net) load: Electricity demand less generation from variable renewables.

Reversible heat pump: A heat pump able to provide both heating and cooling with the same unit, allowing air conditioning demand to be met while electrifying heating.

Road transport: This refers to all road vehicle types, i.e. passenger cars, two/three-wheelers, light commercial vehicles, buses and medium and heavy freight trucks.

Self-sufficiency: Corresponds to indigenous production divided by total energy supply.

Services: A  component  of  the  buildings  sector.  It  represents  energy  used  in  commercial facilities, e.g. offices, shops, hotels, restaurants, and in institutional buildings such as schools, hospitals and public offices. Energy use in services includes space heating and cooling, water heating, lighting, appliances, cooking, data centres and desalination.

A

Shipping/navigation: This transport mode  includes  both  domestic  and  international navigation and their use of marine fuels. Domestic navigation covers the transport of goods or people on inland waterways and for national sea voyages (starts and ends in the same country without any intermediate foreign port). International navigation includes quantities of  fuels  delivered  to  merchant  ships,  including  passenger  ships,  of  any  nationality  for consumption during international voyages transporting goods or passengers.

Smart charging: Controlled electric vehicle charging that shifts demand to periods of low prices or abundant supply, reducing system stress and consumer costs.

Solar: Includes solar photovoltaics (PV), concentrating solar power (CSP), and solar heating and cooling.

Solar home systems (SHS)   Small-scale  photovoltaic  and  battery  stand-alone  systems,  i.e. : with capacity higher or equal to 10 watt peak (Wp) supplying electricity for single households or small businesses. They are most often used off-grid, but also where grid supply is not reliable. Although all SHS are included in the IEA access to electricity definition and historic counting, only solar home systems from 25 Wp in rural areas and 50 Wp in urban areas are deployed in the IEA scenarios for population gaining access. It excludes solar systems smaller than 10 Wp, i.e. multi light systems and solar lanterns.

Solar photovoltaics (PV)  Electricity produced from solar photovoltaic cells including utility-: scale and small-scale installations.

Solid bioenergy: Includes charcoal, fuelwood, dung, agricultural residues, wood waste and other solid biogenic wastes.

Technology readiness level (TRL)  A 1-9 scale describing the maturity of a technology from : concept to commercial deployment.

Tonne-kilometre (tkm)   A  unit  used  in  the  transport  sector  to  quantify  the  amount  of : cargo  or  freight  transported  over  a  distance.  One  tkm  represents  one  metric  tonne (1 000 kilograms) of cargo being transported over a distance of one kilometre.

Total energy supply (TES) : Represents domestic demand only, and is equivalent to electricity and heat generation plus the other energy sector, excluding electricity, heat and hydrogen, plus total final consumption, excluding electricity, heat and hydrogen. TES does not include ambient heat from heat pumps or electricity trade.

Total final consumption (TFC)  Is the sum of consumption by the various end-use sectors. : TFC  is  broken  down  into  energy  demand  in  the  following  sectors:  industry  (including manufacturing,  mining,  chemicals  production,  blast  furnaces  and  coke  ovens);  transport; buildings  (including  residential  and  services);  and  other  (including  agriculture  and  other non-energy use). It excludes international marine and aviation bunkers, except at world level where it is included in the transport sector.

Total final energy consumption (TFEC)  Is a variable defined primarily for tracking progress : towards  target 7.2  of the United  Nations  Sustainable  Development  Goals  (SDG).  It

incorporates total final consumption by end-use sectors, but excludes non-energy use. It excludes international marine and aviation bunkers, except at world level. Typically this is used  in  the  context  of  calculating  the  renewable  energy  share  in  total  final  energy consumption (indicator SDG 7.2.1), where TFEC is the denominator.

Traditional use of biomass: Refers to the use of solid biomass with basic technologies, such as a three-stone fire or basic improved cook stoves (ISO tier 0-2), often with no or poorly operating chimneys.  Forms  of  biomass  used  include  wood,  wood  waste,  charcoal, agricultural residues and other bio-sourced fuels such as animal dung.

Transport: Includes fuels and electricity used in the transport of goods or people within the national territory irrespective of the economic sector within which the activity occurs. This includes: fuel and electricity delivered to vehicles using public roads or for use in rail vehicles; fuel  delivered  to  vessels  for  domestic  navigation;  fuel  delivered  to  aircraft  for  domestic aviation; and  energy  consumed  in  the  delivery  of fuels through  pipelines. Energy consumption from marine and aviation bunkers is presented only at the world level and is excluded from the transport sector at a domestic level.

Trucks: Includes all size categories of commercial vehicles: light trucks (gross vehicle weight &lt; 3.5 tonnes); medium freight trucks (gross vehicle weight 3.5-15 tonnes); and heavy freight trucks (gross vehicle weight &gt; 15 tonnes).

Useful energy: Energy available to end-users to satisfy their need for energy services. As a result of transformation losses at the point of use, the amount of useful energy is lower than the corresponding final energy demand for most technologies. See energy services.

Value-adjusted levelised cost of electricity (VALCOE)  A more complete metric to evaluate : the competitiveness of power generation technologies, which includes all direct technology costs (LCOE) combined with the estimated value of three services provided to the system: energy, flexibility and capacity.

Variable renewable energy (VRE)  Sources of renewable energy, usually electricity, where : the  maximum  output  of  an  installation  at  a  given  time  depends  on  the  availability  of fluctuating environmental inputs. VRE includes a broad array of technologies such as wind power, solar PV, run-of-river hydro, concentrating solar power where no thermal storage is included, and marine (tidal and wave).

Vehicle-to-grid (V2G)  System that allows electricity to flow in two directions between an : electric vehicle and the grid, providing flexibility and system services.

Zero emissions vehicles (ZEVs)  Vehicles that operate without tailpipe CO2 emissions, i.e. : battery electric, plug-in hybrids and fuel cell vehicles.

Annex A

## Regional and country groupings

Advanced economies: Organisation  for  Economic  Co-operation  and Development  (OECD) grouping and Bulgaria, Croatia, Cyprus 1,2 , Malta and Romania.

Africa: North Africa and sub-Saharan Africa regional groupings.

Asia Pacific: Southeast  Asia  regional  grouping  and  Australia,  Bangladesh,  Democratic People's Republic of Korea (North Korea), India, Japan, Korea, Mongolia, Nepal, New Zealand, Pakistan, The People's Republic of China (China), Sri Lanka, Chinese Taipei, and other Asia Pacific countries and territories. 3

Caspian: Armenia, Azerbaijan, Georgia, Kazakhstan, Kyrgyzstan, Tajikistan, Turkmenistan and Uzbekistan.

Central and South America: Argentina,  Plurinational  State  of  Bolivia  (Bolivia),  Bolivarian Republic  of  Venezuela  (Venezuela),  Brazil,  Chile,  Colombia,  Costa  Rica,  Cuba,  Curaçao, Dominican Republic, Ecuador, El Salvador,  Guatemala,  Guyana,  Haiti,  Honduras,  Jamaica, Nicaragua,  Panama,  Paraguay,  Peru,  Suriname,  Trinidad  and  Tobago,  Uruguay  and  other Central and South American countries and territories. 4

China: Includes (The People's Republic of) China and Hong Kong, China.

Developing Asia: Asia  Pacific  regional  grouping  excluding  Australia,  Japan,  Korea  and New Zealand.

Emerging market and developing economies: All other countries not included in the advanced economies regional grouping.

Eurasia: Caspian regional grouping and the Russian Federation (Russia).

Europe: European Union regional grouping and Albania, Belarus, Bosnia and Herzegovina, Gibraltar,  Iceland,  Israel ,  Kosovo ,  Montenegro,  North  Macedonia,  Norway,  Republic  of 5 6 Moldova, Serbia, Switzerland, Türkiye, Ukraine and United Kingdom.

European Union: Austria,  Belgium,  Bulgaria,  Croatia,  Cyprus 1,2 ,  Czech  Republic,  Denmark, Estonia,  Finland,  France,  Germany,  Greece,  Hungary,  Ireland,  Italy,  Latvia,  Lithuania, Luxembourg,  Malta,  Netherlands,  Poland,  Portugal,  Romania,  Slovak  Republic,  Slovenia, Spain and Sweden.

IEA (International Energy Agency) : Australia, Austria, Belgium, Canada, Czechia, Denmark, Estonia,  Finland,  France,  Germany,  Greece,  Hungary,  Ireland,  Italy,  Japan,  Korea,  Latvia, Lithuania, Luxembourg, Mexico, New Zealand, Norway, Poland, Portugal, Slovak Republic, Spain, Sweden, Switzerland, The Netherlands, Türkiye, United Kingdom and United States.

Latin America and the Caribbean (LAC) : Central and South America regional grouping and Mexico.

Middle East: Bahrain, Islamic Republic of Iran (Iran), Iraq, Jordan, Kuwait, Lebanon, Oman, Qatar, Saudi Arabia, Syrian Arab Republic (Syria), United Arab Emirates and Yemen.

Figure A.1 ⊳ Main country groupings

<!-- image -->

Note: This map is without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Non-OECD: All other countries not included in the OECD regional grouping.

Non-OPEC: All other countries not included in the OPEC regional grouping.

North Africa: Algeria, Egypt, Libya, Morocco and Tunisia.

North America: Canada, Mexico and United States.

OECD (Organisation for Economic Co-operation and Development)  IEA grouping plus Chile, : Colombia, Costa Rica, Iceland, Israel, Latvia and Slovenia.

OPEC (Organization of the Petroleum Exporting Countries) : Algeria, Angola, Bolivarian Republic of Venezuela (Venezuela), Equatorial Guinea, Gabon, Iraq, Islamic Republic of Iran (Iran), Kuwait, Libya, Nigeria, Republic of the Congo (Congo), Saudi Arabia and United Arab Emirates.

OPEC+: OPEC grouping plus Azerbaijan, Bahrain, Brunei Darussalam, Kazakhstan, Malaysia, Mexico, Oman, Russian Federation, South Sudan and Sudan.

Southeast Asia: Brunei Darussalam, Cambodia, Indonesia, Lao People's Democratic Republic (Lao  PDR),  Malaysia,  Myanmar,  Philippines,  Singapore,  Thailand  and  Viet Nam.  These countries  are  all members  of  the  Association  of  Southeast  Asian  Nations  (ASEAN). Timor-Leste joined ASEAN on 26 October 2025 and is excluded from this WEO grouping for this publication, but is included in aggregate within the overarching Asia Pacific group.

Sub-Saharan Africa: Angola, Benin, Botswana, Cameroon, Côte d'Ivoire, Democratic Republic of the Congo (DRC), Equatorial Guinea, Eritrea, Ethiopia, Gabon, Ghana, Kenya, Kingdom of Eswatini,  Madagascar,  Mauritius,  Mozambique,  Namibia,  Niger,  Nigeria,  Republic  of  the

A

Congo  (Congo),  Rwanda,  Senegal,  South  Africa,  South  Sudan,  Sudan,  United  Republic  of Tanzania  (Tanzania),  Togo,  Uganda,  Zambia,  Zimbabwe  and  other  African  countries  and territories. 7

## Country notes

- 1 Note by Republic of Türkiye: The information in this document with reference to 'Cyprus' relates to the southern part of the island. There is no single authority representing both Turkish and Greek Cypriot people on the island. Türkiye recognises the Turkish Republic of Northern Cyprus (TRNC). Until a lasting and equitable solution is found within the context of the United Nations, Türkiye shall preserve its position concerning the 'Cyprus issue'.

2 Note by all the European Union Member States of the OECD and the European Union: The Republic of Cyprus is  recognised by all members of the United Nations with the exception of Türkiye. The information in this document relates to the area under the effective control of the Government of the Republic of Cyprus.

3 Individual data are not available and are estimated in aggregate for:  Afghanistan, Bhutan, Cook Islands, Fiji, French  Polynesia,  Kiribati,  Macau  (China),  Maldives,  New  Caledonia,  Palau,  Papua  New  Guinea,  Samoa, Solomon Islands, Timor-Leste, Tonga and Vanuatu.

4 Individual data are not available and are estimated in aggregate for: Anguilla, Antigua and Barbuda, Aruba, Bahamas, Barbados, Belize, Bermuda, Bonaire, Sint Eustatius and Saba, British Virgin Islands, Cayman Islands, Dominica, Falkland Islands (Malvinas), Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and Grenadines, Saint Maarten (Dutch part), Turks and Caicos Islands.

5 The statistical data for Israel are supplied by and under the responsibility of the relevant Israeli authorities. The use of such data by the OECD and/or the IEA is without prejudice to the status of the Golan Heights, East Jerusalem and Israeli settlements in the West Bank under the terms of international law.

6 This designation is without prejudice to positions on status, and is in line with United Nations Security Council Resolution 1244/99 and the Advisory Opinion of the International Court of  Justice on Kosovo's declaration of independence.

7 Individual data are not available and are estimated in aggregate for: Burkina Faso, Burundi, Cabo Verde, Central African Republic, Chad, Comoros, Djibouti, Gambia, Guinea, Guinea-Bissau, Lesotho, Liberia, Malawi, Mali, Mauritania, Sao Tome and Principe, Seychelles, Sierra Leone and Somalia.

## Abbreviations and acronyms

AC

air conditioner (buildings)

AC

alternating current (electricity)

ACCESS

Accelerating Clean Cooking and Electricity Services Scenario

ASEAN

Association of Southeast Asian Nations

BTM

behind-the-meter

CAAGR

compound average annual growth rate

CAPEX

capital expenditure

CBAM

Carbon Border Adjustment Mechanism

CCUS

carbon capture, utilisation and storage

CO2

carbon dioxide

CO2-eq

carbon-dioxide equivalent

COP

CPS

Conference of the Parties (UNFCCC)

Current Policies Scenario

CSP

concentrating solar power

DAC

direct air capture

DER

distributed energy resources

DRI

direct reduced iron

EMDE

emerging market and developing economies

ETS

emissions trading system

EU

European Union

EU ETS

European Union Emissions Trading System

EV

electric vehicle

FACTS

Flexible AC transmission systems

FAO

Food and Agriculture Organization of the United Nations

GDP

gross domestic product

GEC

Global Energy and Climate (IEA model)

GHG

greenhouse gases

H2

hydrogen

H2-DRI

hydrogen-based direct reduced iron

HDV

heavy-duty vehicle

HES

High Electrification Scenario

HVAC

heating, ventilation and air conditioning

HVDC

high-voltage direct current

ICE

internal combustion engine

IEA

International Energy Agency

IPCC

Intergovernmental Panel on Climate Change

IT

Information technology

LCOE

levelised cost of electricity

LDV

light-duty vehicle

LED

light-emitting diode

LNG

liquefied natural gas

LPG

liquefied petroleum gas

MENA

Middle East and North Africa

MEPS

minimum energy performance standards

MER

market exchange rate

N2O

nitrous oxide

NDC

Nationally Determined Contribution

NOC

national oil company

NOX

nitrogen oxides

NPV

net present value

NZE

Net Zero Emissions by 2050 Scenario

O&amp;M

operation and maintenance

PHEV

plug-in hybrid electric vehicles

PM

particulate matter

PM2.5

fine particulate matter

PPA

power purchase agreement

PPP

purchasing power parity

PV

photovoltaics

Annex A

A

| SDG    | Sustainable Development Goals (United Nations)        |
|--------|-------------------------------------------------------|
| SHS    | solar home systems                                    |
| SME    | small and medium enterprises                          |
| SO 2   | sulphur dioxide                                       |
| STEPS  | Stated Policies Scenario                              |
| T&D    | transmission and distribution                         |
| TES    | total energy supply                                   |
| TFC    | total final consumption                               |
| TFEC   | total final energy consumption                        |
| TPED   | total primary energy demand                           |
| TRL    | technology readiness level                            |
| TSO    | transmission system operator                          |
| UN     | United Nations                                        |
| UNFCCC | United Nations Framework Convention on Climate Change |
| US     | United States                                         |
| V2G    | Vehicle-to-grid                                       |
| VALCOE | value-adjusted levelised cost of electricity          |
| VAT    | value-added tax                                       |
| VRE    | variable renewable energy                             |
| WACC   | weighted average cost of capital                      |
| WEO    | World Energy Outlook                                  |
| ZEV    | zero emissions vehicle                                |

<!-- image -->

## References

## Chapter 1: The Age of Electricity

CAAM (China Association of Automobile Manufacturers) (2026), https://en.caam.org.cn/

IEA (International Energy Agency) (2026a), World Energy Investment 2026,

https://www.iea.org/reports/world-energy-investment-2026

IEA (2026b), Electricity Mid-Year Update 2026,

https://www.iea.org/reports/electricity-mid-year-update-2026

IEA (2026c), Global Electric Vehicle Outlook,

https://www.iea.org/reports/global-ev-outlook-2026

## Chapter 2: Electrification in end-uses

Cox Automotive (2026), EV vs. ICE: Depreciation and residual values explained, https://www.coxautoinc.eu/ev-hub/industry-ev-hub/resources/ev-vs-ice-depreciation-andresidual-values-explained/

European Commission (2026), European Alternative Fuels Observatory, https://alternativefuels-observatory.ec.europa.eu/transport-mode/road/turkey/infrastructure

FAO (Food and Agriculture Organization) (2019), The State of Food and Agriculture, https://openknowledge.fao.org/server/api/core/bitstreams/11f9288f-dc78-4171-8d0292235b8d7dc7/content

Global Efficiency Intelligence (2025), Electrification of Heating in India's Textile Industry: National, State, Cluster, and Plant-Level Assessment, https://www.globalefficiencyintel.com/electrification-of-heating-in-indias-textile-industry

Government of Ethiopia (2025), Ethiopia E-Mobility Strategy and Implementation Plan, https://www.motl.gov.et/sites/default/files/resource/V4\_Oct%2010\_E-mobility%20 Strategy%20and%20Implementation%20Plan.pdf

Government of Türkiye (2024), 2024-2028 Strategic Plan, https://enerji.gov.tr/Media/Dizin/SGB/tr/Kurumsal\_Politikalar/ETKB\_2024-2028\_Stratejik\_Plani.pdf

IEA (International Energy Agency) (2026a), Global EV Outlook 2026, https://www.iea.org/reports/global-ev-outlook-2026

IEA (2026b), Energy crisis threatens world's most vulnerable as cooking fuel shortages grow, https://www.iea.org/commentaries/energy-crisis-threatens-world-s-mostvulnerable-as-cooking-fuel-shortages-grow

IEA (2026c), Heat Pump Monitor 2026, https://www.iea.org/reports/heat-pump-monitor-2026

## IEA (2026d), Global Hydrogen Review,

https://www.iea.org/reports/global-hydrogen-review-2026

IEEFA (Institute for Energy Economics and Financial Analysis) (2025), Australia lagging behind New Zealand on cutting industrial energy costs, https://ieefa.org/resources/ australia-lagging-behind-new-zealand-cutting-industrial-energy-costs

ITF (International Transport Forum) (2025), Financing the Electrification of Heavy-Duty Vehicles, https://www.itf-oecd.org/financing-heavy-duty-vehicle-electrification

McKinsey &amp; Company (2024), Industrial heat pumps: Five considerations for future growth, https://www.mckinsey.com/industries/industrials/our-insights/industrial-heat-pumps-fiveconsiderations-for-future-growth

PIB (2026), PM-KUSUM Benefits Reach Over 21.77 Lakh Farmers Across the Country, https://www.pib.gov.in/PressReleasePage.aspx?PRID=2244667&amp;reg=1&amp;lang=1

RTE (Le résau de transport d'électricité) (2026), Baromètre des flexibilités de consommation 2026, https://www.rte-france.com/donnees-publications/ publications/barometre-flexibilites-consommation-electricite#Barometre

Schloter, L. (2022), Empirical analysis of the depreciation of electric vehicles compared to gasoline vehicles, Transport Policy: https://doi.org/10.1016/j.tranpol.2022.07.021

## Chapter 3: Powering electrification

Google (2026), A new milestone for smart, affordable electricity growth, https://blog.google/innovation-and-ai/infrastructure-and-cloud/global-network/demandresponse-data-center-milestone/

IEA (International Energy Agency) (2026), Electricity 2026, https://www.iea.org/reports/electricity-2026

IEA (2025a), World Energy Outlook, https://www.iea.org/reports/world-energy-outlook-2025

IEA (2025b), Energy and AI, https://www.iea.org/reports/energy-and-ai

IEA (2025c), Electricity Market Design, https://www.iea.org/reports/electricity-market-design

IEA (2023), Scaling Up Private Finance for Clean Energy in Emerging and Developing

Economies, https://www.iea.org/reports/scaling-up-private-finance-for-clean-energy-inemerging-and-developing-economies

REN21 (2026), Renewable-based Economy Tracker 2026, https://www.ren21.net/renewables-based-economy-tracker/

## Chapter 4: Implications

Afrobarometer (2026), Round 9 and 10, https://www.afrobarometer.org/data/data-sets/

CRED (Centre for Research on the Epidemiology of Disasters) (2025), (database) accessed July 2026, https://public.emdat.be/

Dippenaar, J. A., &amp; Bekker, B. (2026), Who pays for rooftop solar? Cost shifts, stakeholder perspectives and policy tensions in South Africa, Energy Policy, vol. 216, https://doi.org/10.1016/j.enpol.2026.115365

ECMWF (European Centre for Medium-Range Weather Forecasts) (2025). (database) accessed July 2026, https://cds.climate.copernicus.eu/

Ember (2026), The solarisation of Pakistan's energy economy, https://ember-energy.org/latest-insights/the-solarisation-of-pakistans-energy-economy/

EURES (European employment services) (2025), Report on labour shortages and surpluses. European Labour Authority,  https://www.ela.europa.eu/en/publications/labour-shortagesand-surpluses-europe-2025

Farthing, A., Rosenlieb, E., Steward, D., Reber, T., Njobvu, C., Moyo, C., Quantifying agricultural productive use of energy load in Sub-Saharan Africa and its impact on microgrid configurations and costs, Applied Energy, vol. 343, https://www.sciencedirect.com/science/article/pii/S0306261923004956

Forbes (2025), Solving the Electrician Shortage, https://www.forbes.com/councils/forbeshumanresourcescouncil/2025/10/21/solving-theelectrician-shortage-a-data-driven-mobility-strategy/

GACC (General Administration of Customs People's Republic of China) (2026), (database) accessed July 2026, http://stats.customs.gov.cn/indexEn

GDACS (Global Disaster Alert and Coordination System) (2026), (database) accessed July 2026, https://www.gdacs.org/

IBEW (International Brotherhood of Electrical Workers) (2025), The DATA CENTER Surge: A New Generation of IBEW Jobs,  https://ibew.org/electrical\_worker/the-data-center-surgea-new-generation-of-ibew-jobs/

IEA (International Energy Agency) (2026), Energy Technology Perspectives 2026, https://www.iea.org/reports/energy-technology-perspectives-2026

ITIF (Information Technology &amp; Innovation Foundation) (2026), Construction Industry Facing a 439,000-Worker Shortage Driven by the Growth of Data Centers, https://itif.org/publications/2026/01/12/construction-industry-facing-worker-shortagedriven-by-growth-of-data-centers/

<!-- image -->

B

I

JATO (2025), The Global BEV Transition: same destination, different speeds across regions, https://www.jato.com/resources/news-and-insights/the-global-bev-transition-samedestination-different-speeds-across-regions

PRIED (Policy Research Institute for Equitable Development) (2026), Solar adoption patterns in Pakistan, https://www.priedpk.org/energy-monitors

ReliefWeb (2025), (database) accessed July 2026, https://reliefweb.int/disasters

World Bank (2026), Enterprise Surveys Database, accessed July 2025, https://www.enterprisesurveys.org/en/data

World Bank (2025), Accelerating Access to Clean Air for a Livable Planet, https://www.worldbank.org/en/publication/accelerating-access-to-clean-air-for-a-livableplanet

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual M ember countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject to the IEA's Notice for CC-licenced Content, this work is licenced under a Creative Commons Attribution 4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA - September 202 6 Cover design: IEA Photo credits: Shutterstock

## Electrification Special Report

The world is entering a new Age of Electricity. Since 2019, electricity  demand  has  grown  more  than  twice  as  fast  as overall energy use, driven by electric vehicles, heat pumps, air conditioning, industrial electrification, data centres and  artificial  intelligence.  This  landmark  report  from  the International  Energy  Agency  (IEA)  was  developed  at  the request  of  Türkiye  and  Australia  in  the  framework  of  the strategic partnership between the IEA and COP31. It provides a  comprehensive  assessment  of  how  far  and  how  fast electrification can advance across sectors and regions, and what it means for energy security, affordability and emissions.

The  analysis  sets  out  the  drivers  of  the  growing  role  of electricity in energy systems and introduces a High Electrification  Scenario  to  explore  a  pathway  by  which electricity reaches 35% of final energy consumption by 2035. The report examines electrification potential across transport,  buildings  and  industry.  It  assesses  the  impact of  electrification  on  energy  security  and  emissions  and analyses the implications of different electricity generation cases to meet rising demand.

In addition, this report also addresses the enabling conditions and broader consequences of electrification: adequate and resilient  electricity  systems,  investment  and  affordability, critical  minerals,  and  universal  access  to  electricity  and clean cooking in emerging and developing economies. The report combines IEA data and scenario modelling with clear and practical insights for policymakers.

<!-- image -->