---
document_id: irena_green_hydrogen_policy_2020
title: "Green Hydrogen: A Guide to Policy Making"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IRENA"
year: 2020
original_file: "irena_green_hydrogen_policy_making_2020.pdf"
tables_detected: 22
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

<!-- image -->

## © IRENA 2020

Unless  otherwise  stated,  material  in  this  publication  may  be  freely  used,  shared,  copied,  reproduced, printed and/or stored, provided that appropriate acknowledgement is given of IRENA as the source and copyright holder. Material in this publication that is attributed to third parties may be subject to separate terms of use and restrictions, and appropriate permissions from these third parties may need to be secured before any use of such material.

Citation: RENA (2020), I Green Hydrogen: A guide to policy making , International Renewable Energy Agency, Abu Dhabi

ISBN: 978-92-9260-286-4

## ABOUT IRENA

The International Renewable Energy Agency (IRENA) serves as the principal platform for international co-operation, a centre of excellence, a repository of policy, technology, resource  and  financial  knowledge,  and  a  driver  of  action  on  the  ground  to  advance the  transformation  of  the  global  energy  system.  An  intergovernmental  organisation established in 2011, IRENA promotes the widespread adoption and sustainable use of all  forms  of  renewable  energy,  including  bioenergy,  geothermal,  hydropower,  ocean, solar and wind energy, in the pursuit of sustainable development, energy access, energy security and low-carbon economic growth and prosperity.

www.irena.org

## ACKNOWLEDGEMENTS

The report benefited from the reviews and comments of experts, including Cédric Philibert (independent consultant), Matthias Deutsch (Agora Energiewende), Frank Wouters (EU-GCC Clean Energy Technology Network), Ruud Kempener (European Commission - DG Energy), Antonello  di  Pardo  (GSE  S.p.A.),  Jose  Miguel  Bermudez  and  Peerapat  Vithayasrichareon (IEA), Pierpaolo Cazzola and Matteo Craglia (ITF), Karl Hauptmeier (Norsk e-Fuel), Massimo Santarelli (Polytechnic University of Turin), Duncan Gibb (REN21), Thierry Lepercq (Soladvent), Hergen  Thore  Wolf  (Sunfire  GmbH),  Kirsten  Westphal  (SWP),  Ad  van  Wijk  (TU  Delft), Rina Bohle Zeller and Andrew Gordon Syme Mcintosh (Vestas).

IRENA colleagues Dolf Gielen, Diala Hawila, Emanuele Taibi, Paul Durrant, Raul Miranda, Barbara  Jinks,  Nicholas  Wagner,  Sufyan  Diab,  Jinlei  Feng  and  Abdullah  Abou  Ali  also provided valuable input.

The  report  was  authored  by  Emanuele  Bianco  and  Herib  Blanco  under  the  guidance  of Rabia Ferroukhi.

Available for download: www.irena.org/publications

For further information or to provide feedback: publications@irena.org

## DISCLAIMER

This publication and the material herein are provided 'as is'. All reasonable precautions have been taken by IRENA to verify the reliability of the material in this publication. However, neither IRENA nor any of its officials, agents, data or other third-party content providers provides a warranty of any kind, either expressed or implied, and they accept no responsibility or liability for any consequence of use of the publication or material herein.

The information contained herein does not necessarily represent the views of all Members of IRENA. The mention of specific companies or certain projects or products does not imply that they are endorsed or  recommended  by  IRENA  in  preference  to  others  of  a  similar  nature  that  are  not  mentioned.  The designations employed, and the presentation of material herein, do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

## CONTENT

| INTRODUCTION . . . . . . . . . .                | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                         | 04   |
|-------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------|------|
| ABOUT THIS GUIDE .                              | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                             | 05   |
| 1.                                              | GREEN HYDROGEN: STATUS, DRIVERS AND BARRIERS                                                                                          | 06   |
|                                                 | 1.1. Different shades of hydrogen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                               | 08   |
|                                                 | 1.2. Drivers of the new wave of green hydrogen. . . . . . . . . . . . . . . . . . . . . . .                                           | . 10 |
|                                                 | 1.3. Barriers to the uptake of green hydrogen. . . . . . . . . . . . . . . . . . . . . . . . .                                        | . 13 |
|                                                 | 1.4. Policies to support green hydrogen. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                    | . 16 |
| 2.                                              | PILLARS FOR GREEN HYDROGEN POLICY MAKING . . . . .                                                                                    | . 18 |
|                                                 | 2.1. Policy pillar 1: National strategies . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                             | . 19 |
|                                                 | 2.2. Policy pillar 2: Establish policy priorities for green hydrogen . . . . . . . .                                                  | . 26 |
|                                                 | 2.3. Policy pillar 3: Guarantee of origin scheme . . . . . . . . . . . . . . . . . . . . . . .                                        | . 29 |
|                                                 | 2.4. Policy pillar 4: Governance system and enabling policies . . . . . . . . . . .                                                   | . 31 |
| 3.                                              | SUPPORTING POLICIES FOR GREEN HYDROGEN . . . . . . .                                                                                  | 34   |
|                                                 | 3.1. Policy support for electrolysis . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                              | . 36 |
|                                                 | 3.2. Policy support for hydrogen infrastructure . . . . . . . . . . . . . . . . . . . . . . .                                         | . 38 |
|                                                 | 3.3. Policy support for hydrogen in industrial applications . . . . . . . . . . . . . .                                               | 40   |
|                                                 | 3.4. Policy support for synthetic fuels in aviation . . . . . . . . . . . . . . . . . . . . . .                                       | . 42 |
|                                                 | 3.5. Policy support for hydrogen use in maritime shipping . . . . . . . . . . . . . .                                                 | 44   |
| 4.                                              | CONCLUSIONS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | 48   |
| References .                                    | References .                                                                                                                          |      |
| Photograpghs Abbreviations and units of measure | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                 | 50   |
| .                                               | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                         | . 51 |

## FIGURES

| Figure 1.1   | Green hydrogen production, conversion and end uses across the energy system . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .              | 07   |
|--------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|
| Figure 1.2   | Selected shades of hydrogen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                        | 08   |
| Figure 1.3   | Hydrogen production cost depending on electrolyser system cost, electricity price and operating hours . . . .                                                              | . 14 |
| Figure 1.4   | Number of hydrogen policies at a global level by segment of the value chain . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                            | . 16 |
| Figure 2.1   | Steps leading to the formulation of a national strategy .                                                                                                                  | 20   |
| Figure 2.2   | Government hydrogen-related initiatives announced between June 2018 and November 2020 . . . . . . . . . . . . . . . . . .                                                  | 22   |
| Figure 2.3   | Main aspects and instruments mentioned in the EU hydrogen strategy . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | 25   |
| Figure 2.4   | Hydrogen as a complement to alternative ways to decarbonise end uses . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .         | 27   |
| Figure 2.5   | Guarantees of origin lifecycle emissions (Illustrative) . .                                                                                                                | 30   |
| Figure 3.1   | Selected barriers and policies for segments of the hydrogen value chain . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .    | 35   |

## TABLES

| Table 2.1   | Examples of guarantee of origin schemes..................                             | 29   |
|-------------|---------------------------------------------------------------------------------------|------|
| BOXES       |                                                                                       |      |
| Box 1.1     | Roles for green hydrogen in different energy transition scenarios . . . . . . . . . . | . 12 |
| Box 1.2     | Key cost components for green hydrogen . . .                                          | . 14 |
| Box 1.3     | Hydrogen emissions from grid-powered electrolysis .                                   | . 15 |
| Box 2.1     | The EU hydrogen strategy                                                              | 24   |

## INTRODUCTION

The  world  is  facing  the  major  challenge  of  climate change. In 2015  the    global  community  committed  to taking  action  to  keep  global  temperature  rise  this  century well below  2°C  above  pre-industrial  levels. A  growing number of countries are pledging to reach net-zero carbon dioxide  (CO )  emissions  by  mid-century  with  the  goal  of 2 limiting temperature rise to 1.5°C. Achieving the deep or full decarbonisation  of  economies  will  require  concerted  and wide-ranging action across all economic sectors.

We have barely begun such emission reductions. It  has been estimated that 8.8% less CO2 was emitted in the first six months of 2020 than in the same period in 2019, following the  COVID-19  pandemic  and  the  consequent  lockdowns (Liu et  al. ,  2020).  But  for  continued  long-term  reduction, the  need  for  structural  and  transformational  changes  in our global energy production, consumption and underlying socio-economic systems cannot be understated.

Dramatic emission reductions are both technologically feasible  and  economically  affordable. IRENA's  Global Renewables Outlook report offers a perspective for reaching net-zero emissions in the 2050-2060 timeframe. The Deeper Decarbonisation Perspective suggests possibilities  for  accelerated  action  to  bring  down  CO 2 emissions while bringing an economic payback of between USD 1.5 and USD 5 for every USD 1 spent on the energy transition (IRENA, 2020a).

The  energy  transformation  requires  a  major  shift  in electricity  generation  from  fossil  fuels  to  renewable sources  like  solar  and  wind,  greater  energy  efficiency and the widespread  electrification of energy uses from cars to heating and cooling in buildings. Still,  not all  sectors  or  industries  can  easily  make  the  switch  from fossil  fuels  to  electricity.  Hard-to-electrify  (and  therefore hard-to-abate)  sectors  include  steel,  cement,  chemicals, long-haul  road  transport,  maritime  shipping  and  aviation (IRENA, 2020b).

Green hydrogen an provide a link between growing and sustainable  renewable  electricity  generation  and  the hard-to-electrify  sectors  (IRENA,  2018). Hydrogen  in general is a suitable energy carrier for applications remote from electricity grids or that require a high energy density, and  it  can  serve  as  a  feedstock  for  chemical  reactions  to produce a range of synthetic fuels and feedstocks.

Additional benefits of green hydrogen include: the potential for additional system flexibility and storage, which support further  deployment  of  variable  renewable  energy  (VRE); contribution to energy security; reduced air pollution; and other  socio-economic  benefits  such  as  economic  growth and job creation, and industrial competitiveness.

Nevertheless, green hydrogen  will have to overcome several barriers to fulfil its full potential. Chief among those barriers is cost.

Overcoming the barriers and transitioning green hydrogen from  a  niche  player  to  a  widespread  energy  carrier  will require dedicated policy in each of the stages of technology readiness, market  penetration and  market  growth. An integrated policy approach  is needed  to overcome the  initial  resistance  and  reach  a  minimum  threshold for  market  penetration,  resting  on  four  central  pillars: building national hydrogen strategies, identifying policy priorities, establishing a governance system and enabling policies, and creating a system for guarantee of origin for green hydrogen.

## ABOUT THIS GUIDE

This publication is the first of a series of briefs that aim to guide  policy  makers  in  the  design  and  implementation  of policy  to  support  green  hydrogen  as  one  of  the  feasible methods of decarbonising the energy sector.

This guide is composed of three chapters. The first focuses on the status and drivers of green hydrogen and the barriers it faces. The second chapter explores the pillars of national policy making to support hydrogen, and the third presents the main policy recommendations in different segments of the green hydrogen value chain.

The forthcoming brief is due to be published and will address the supply side, covering electrolysis and infrastructure. The following briefs will first explore specific policies for different uses of green hydrogen in the hard-to-abate sectors, including industrial applications and  long-haul transport (aviation, maritime  shipping).  Selected  policy  recommendations  for these  uses  are  presented  here  in  the  third  chapter.  Future briefs  will  explore  niche  applications  for  hydrogen,  such  as power generation and heating, and land transport.

Each of the policy briefs will present relevant case studies to highlight previous experiences and provide potential starting points for governments, exploring policies to support greater  use  of  green  hydrogen.  They  will  also  offer  policy recommendations,  which  can  be  adapted  and  tailored  for specific countries depending on their context and priorities beyond the energy system, such as economic development objectives.

Some of the necessary policy tools already exist in energy sector and only need to be expanded in scope. However, in other cases dedicated attention might be needed.

## I R ENA'S WORK ON GREEN HYDROGEN AND HARD TO ABATE SECTORS.

This report is part of IRENA's ongoing programme of work to provide its members countries and the wider community with  expert  analytical  insights  into  the  potential  options, enabling conditions and policies that could deliver the deep decarbonisation of economies.

IRENA's annual Global Renewable Outlook provides detailed global and  regional roadmaps  for  emission  reductions alongside assessment of the socioeconomic implications. The 2020  edition  includes  Deep  Decarbonisation  Perspectives detailing options for achieving net-zero or zero emissions.

The 2021 edition  will  include  further  detailed  analysis  of  a pathway consistent with a 1.5-degree goal.

Building  on  its  technical  and  socio-economic  assessment IRENA is analysing specific facets of that pathway including the policy and financial frameworks needed. One particular focus is on the potential of green hydrogen.

Recent and upcoming publications include:

- •   'Hydrogen: A renewable energy perspective' (2019);
- ·   'Reaching zero with renewables' (2020) and its supporting briefs on industry and transport;
- ·   'Green  hydrogen cost reduction: Scaling up electrolysers to meet the 1.5°C climate goal' (forthcoming);
- ·   'Renewable energy policies in a time of transition: Heating and cooling' (forthcoming)
- •   and the subsequent briefs to this report.

These  reports  complement  IRENA's  work  on  renewablesbased electrification, biofuels and synthetic fuels and all the options for specific hard-to-abate sectors

This  analytical  work  is  supported  by  IRENA's  initiatives to convene  experts  and  stakeholders,  including  IRENA Innovation Weeks, IRENA Policy Days and Policy Talks, and the IRENA Collaborative Platform on Green Hydrogen. These bring together a broad range of member countries and other stakeholders to exchange knowledge and experience.

5

1

The first industrial water electrolyser was developed in 1888

## 001 GREEN HYDROGEN: STATUS, DRIVERS AND BARRIERS

H

Henry Cavendish discovered the element in

Most abundant chemical structure in the universe

Hydrogen

1766

1.01

## Hydrogen means

'Creator (-gen) of water (hydro-)': its combustion releases only water

<!-- image -->

H2O

O

<!-- image -->

Green  hydrogen  is  an  energy  carrier  that can  be  used  in  many  different  applications (Figure 1.1). However, its actual use is still very limited.  Each  year  around  120  million  tonnes of  hydrogen  are  produced  globally,  of  which two-thirds  are  pure  hydrogen  and  one-third is in a mixture  with  other  gases  (IRENA, 2019a). Hydrogen output is mostly used for  crude  oil  refining  and  for  ammonia  and methanol synthesis, which together represent almost 75% of the combined pure and mixed hydrogen demand.

Today's hydrogen production is mostly based on  natural  gas  and  coal,  which  together account  for  95%  of  production.  Electrolysis produces  around  5%  of  global  hydrogen, as  a  by-product  from  chlorine  production. Currently,  there  is  no  significant  hydrogen production  from  renewable  sources:  green hydrogen has been limited to demonstration projects (IRENA, 2019a).

<!-- image -->

FIGURE 1.1 Green hydrogen production, conversion and end uses across the energy system

<!-- image -->

Source: IRENA.

* The term synthetic fuels refers here to a range of hydrogen-based fuels produced through chemical processes with a carbon source (CO and CO2 captured from emission streams, biogenic sources or directly from the air). They include methanol, jet fuels, methane and other hydrocarbons. The main advantage of these fuels is that they can be used to replace their fossil fuel-based counterparts and in many cases be used as direct replacements - that is, as drop-in fuels. Synthetic fuels produce carbon emissions when combusted, but if their production process consumes the same amount of CO2, in principle it allows them to have net-zero carbon emissions.

## 1.1.   DIFFERENT SHADES OF HYDROGEN

Hydrogen  can  be  produced  with  multiple processes and energy sources; a colour code nomenclature  is  becoming  commonly  used to facilitate discussion (Figure 1.2). But policy makers should design policy using an objective measure of impact based on life-cycle greenhouse  gas  (GHG)  emissions,  especially since  there  might  be  cases  that  do  not  fully fall  under  one  colour  ( e.g. mixed  hydrogen sources, electrolysis with grid electricity) (see Section 2.3).

<!-- image -->

FIGURE 1.2 Selected shades of hydrogen

<!-- image -->

Note: SMR = steam methane reforming.

- * Turquoise hydrogen is an emerging decarbonisation option.

<!-- image -->

REY

ROGEN

LUE

ROGEN

UOISE

OGEN

<!-- image -->

<!-- image -->

BLUE

HYDROGEN

<!-- image -->

<!-- image -->

GREEN

HYDROGEN

GREY  HYDROGEN 1 is  produced  with  fossil  fuels  (i.e.  hydrogen  produced  from  methane  using steam methane reforming (SMR) or coal gasification). The use of grey hydrogen entails substantial CO2 emissions, which makes these hydrogen technologies unsuitable for a route toward net-zero emissions.

During early stages of the energy transition, the use of BLUE HYDROGEN (i.e. grey hydrogen with carbon capture and storage [CCS]) could facilitate the growth of a hydrogen market. Around three-quarters of hydrogen is currently produced from natural gas. Retrofitting with CCS would allow the continued use of existing assets while still achieving lower GHG emissions. This is an option is to produce hydrogen with lower GHG emissions while reducing pressure on the renewable energy capacity installation rate to produce green hydrogen. Notably, industrial processes like steel production may require a continuous flow of hydrogen; blue hydrogen could be an initial solution while green hydrogen ramps up production and storage capacity to meet the continuous flow requirement. TURQUOISE GREEN BLUE HYDROGEN HYDROGEN HYDROGEN TURQUOISE GREEN

However,  blue  hydrogen  has  limitations  that  have  so  far  restricted  its  deployment:  it  uses  finite resources, is exposed to fossil fuel price fluctuations, and does not support the goals of energy security. Moreover, blue hydrogen faces social acceptance issues, as it is associated with additional costs for CO 2 transport and storage and requires monitoring of stored CO . In addition, CCS capture efficiencies are 2 expected to reach 85-95% at best, 2  which means that 5-15% of the CO  will still be emitted. And these 2 high capture rates have yet to be achieved. HYDROGEN HYDROGEN

In sum, the carbon emissions from hydrogen generation could be reduced by CCS but not eliminated. Moreover, these processes use methane, which brings leakages upstream, and methane is a much more potent GHG per molecule than CO . This means that while blue hydrogen could reduce CO  emissions, it 2 2 does not meet the requirements of a net-zero future. For these reasons, blue hydrogen should be seen only as a short-term transition to facilitate the uptake of green hydrogen on the path to net-zero emissions.

TURQUOISE HYDROGEN combines  the  use  of  natural  gas  as  feedstock  with  no  CO   production. 2 Through the process of pyrolysis, the carbon in the methane becomes solid carbon black. A market for carbon black already exists, which provides an additional revenue stream. Carbon black can be more easily stored than gaseous CO . At the moment, turquoise hydrogen is still at the pilot stage. (Philibert, 2 2020; Monolith, 2020).

Among the different shades of hydrogen, GREEN HYDROGEN - meaning hydrogen produced from renewable energy - is the most suitable one for a fully sustainable energy transition.  The most established  technology  options  for  producing  green  hydrogen  is  water  electrolysis  fuelled  by renewable electricity. This technology is the focus of this report. Other renewables-based solutions to produce hydrogen exist. 3  However, except for SMR with biogases, these are not mature technologies at commercial scale yet (IRENA, 2018). Green hydrogen production through electrolysis is consistent with the net-zero route, allows the exploitation of synergies from sector coupling, thus decreasing technology costs and providing flexibility to the power system. Low VRE costs and technological improvement are decreasing the cost of production of green hydrogen. For these reasons, green hydrogen from water electrolysis has been gaining increased interest. GREEN HYDROGEN

- 1 Sometimes referred to as black or brown hydrogen.
- 2 An alternative route to SMR could be a process called autothermal reforming, for which it is estimated that a possible capture rate up to 94.5% of the CO2 emitted is possible (H-Vision, 2019).
- 3 For example, biomass gasification and pyrolysis, thermochemical water splitting, photocatalysis, supercritical water gasification of biomass, combined dark fermentation and anaerobic digestion.

## 1.2. DRIVERS OF THE NEW WAVE OF GREEN HYDROGEN

There  have  been  several  waves  of  interest in  hydrogen  in  the  past.  These  were  mostly driven  by  oil  price  shocks,  concerns  about peak oil demand or air pollution, and research on alternative fuels. Hydrogen can contribute to energy security by providing another energy  carrier  with  different  supply  chains, producers  and  markets;  this  can  diversify the  energy  mix  and  improve  the  resilience of  the  system.  Hydrogen  can  also  reduce air pollution when used in fuel cells, with no emissions  other  than  water.  It  can  promote economic growth and job creation given the large investment needed to develop it as an energy carrier from an industrial feedstock.

<!-- image -->

As a result, more and more energy scenarios are  giving  green  hydrogen  a  prominent  role, albeit  with  significantly  different  volumes  of penetration  (see  Box  1.1).  The  new  wave  of interest  is  focused  on  delivering  low-carbon solutions  and  additional  benefits  that  only green  hydrogen  can  provide.  The  drivers  for green hydrogen include:

Low variable renewable energy (VRE)  electricity  costs. The  major cost driver for green hydrogen  is the  cost  of  electricity.  The  price  of  electricity procured from solar PV and onshore wind plants has  decreased  substantially  in  the  last  decade. In 2018, solar energy was contracted at a global average price of 56 USD/MWh, compared with 250 in 2018. Onshore wind prices also fell during that period, from 75 USD/MWh in 2010 to 48 in 2018 (IRENA, 2019b). New record-low prices were marked in 2019 and 2020 around the world: solar PV was contracted at USD 13.12/MWh in Portugal (Morais, 2020) and USD 13.5/MWh in the United Arab  Emirates  (Abu  Dhabi)  (Shumkov,  2020); onshore wind was contracted at USD 21.3/MWh in  Saudi  Arabia  (Masdar,  2019)  while  in  Brazil, prices ranged between USD 20.5 and 21.5/MWh (BNEF, 2019). With the continuously decreasing costs of solar photovoltaic and wind electricity, the production of green hydrogen is increasingly economically attractive. 1.

<!-- image -->

Technologies ready to scale up. Many  of  the  components  in the hydrogen value chain have already been deployed on a small scale and  are  ready  for  commercialisation,  now requiring investment to scale up. The capital cost  of  electrolysis  has  fallen  by  60%  since 2010  (Hydrogen  Council,  2020),  resulting  in a decrease of hydrogen cost from a range of USD 10-15/kg to as low as USD 4-6/kg in that period.  Many  strategies  exist  to  bring  down costs  further  and  support  a  wider  adoption of  hydrogen  (IRENA,  forthcoming).  The  cost of fuel cells 4 for vehicles has decreased by at least 70% since 2006 (US DOE, 2017). 2.

<!-- image -->

- 4 Fuel cells use the same principles as an electrolyser, but in the opposite direction, for converting hydrogen and oxygen into water in a process that produces electricity. Fuel cells can be used for stationary applications ( e.g. centralised power generation) or distributed applications ( e.g. fuel cell electric vehicles). Fuel cells can also convert other reactants, such as hydrocarbons, ethers or alcohols.

While  some  technologies  have  not  been  demonstrated at scale yet (such as ammonia-fuelled  ships) (IRENA, 2020b), scaling up green hydrogen could make those pathways more attractive as production costs decrease.

<!-- image -->

Benefits  for  the  power  system. As  the  share of VRE  rapidly increases in various markets around  the  world,  the  power  system  will  need more  flexibility.  The  electrolysers  used  to  produce  green hydrogen  can  be  designed  as  flexible  resources  that  can quickly ramp up or down to compensate for fluctuations in VRE production, by reacting to electricity prices (Eichman, Harrison and Peters, 2014). Green hydrogen can be stored for long periods, and can be used in periods when VRE is not available for power generation with stationary fuel cells or hydrogen-ready gas turbines. Flexible resources can reduce VRE  curtailment,  stabilise  wholesale  market  prices  and reduce the hours with zero or below zero electricity prices (or negative price), which increases the investment recovery for renewable generators and facilitates their expansion. Finally, hydrogen is suitable for long-term, seasonal energy storage, complementing pumped-storage hydropower plants. Green hydrogen thus supports the integration of higher shares of VRE  into  the  grid,  increasing  system  efficiency  and  costeffectiveness. 3.

<!-- image -->

Broader  use  of  hydrogen. Previous  waves  of interest  in hydrogen  were  focused  mainly  on expanding  its  use  in  fuel  cell  electric  vehicles (FCEVs). In contrast, the new interest covers many possible green hydrogen uses across the entire economy, including the  additional  conversion  of  hydrogen  to  other  energy carriers  and  products,  such  as  ammonia,  methanol  and synthetic liquids. These uses can increase the future demand for hydrogen and can take advantage of possible synergies to decrease costs in the green hydrogen value chain. Green hydrogen can, in fact, improve industrial competitiveness, not only for the countries that establish technology leadership in its deployment, but also by providing an opportunity for existing  industries  to  have  a  role  in  a  low-carbon  future. Countries with large renewable resources could derive major economic  benefits  by  becoming  net  exporters  of  green hydrogen in a global green hydrogen economy. 5.

<!-- image -->

<!-- image -->

nterest of multiple stakeholders. I As a result of all  the  above points, interest in hydrogen is now widespread in both public and private institutions.

Government  objectives  for  net-zero  energy systems. By mid-2020, seven countries had already  adopted  net-zero  GHG  emission  targets in legislation, and 15 others had proposed similar legislation or policy documents. In total, more than 120 countries have announced net-zero emissions goals (WEF, 2020). Among them is the People's Republic of China (hereafter 'China'), the largest GHG emitter, which recently pledged to cut its net carbon emissions to zero within 40 years. While these net-zero  commitments  have  still  to  be  transformed  into practical actions, they will require cutting emissions in the 'hard-to-abate' sectors where green hydrogen can play an important role. 4.

These include energy utilities, steel makers, chemical companies, port authorities, car and aircraft manufacturers, shipowners and airlines, multiple jurisdictions and countries aiming  to  use  their  renewable  resources  for  export  or to  use  hydrogen  to  improve  their  own  energy  security. These  many  players  have  also  created  partnerships  and ongoing initiatives to foster collaboration and co ordination of efforts. 6

However, green hydrogen still faces barriers.

- 5 System flexibility is here defined as the ability of the power system to match generation and demand at any timescale.
- 6 The Hydrogen Council is an example of a private initiative. Launched in 2017, it has 92 member companies (by October 2020). The Hydrogen Initiative under the Clean Energy Ministerial is an example of a public initiative, where nine countries and the European Union are collaborating to advance hydrogen. The Fuel Cell and Hydrogen Joint Undertaking is an example of private-public partnership in the European Union.

## Box 1.1 Roles for green hydrogen in different energy transition scenarios

The role given to green hydrogen in existing regional and global energy transition scenarios differs greatly due to a number of factors.

First, not all scenarios aim for the same GHG reduction target. The more ambitious the GHG reduction target, the greater is the amount of green hydrogen expected in the system. For low levels of decarbonisation, renewable power and electrification might be enough. But with deeper decarbonisation targets, green hydrogen would play a larger role in the future energy mix.

Second, not all scenarios rely on the same set of enabling policies. The removal of fossil fuel subsidies, for example, would increase the space for carbon-free solutions.

Third, the technology options available vary between scenarios. Scenarios that give greater weight to the social, political and sustainability challenges of nuclear, carbon capture, use and storage, and bioenergy anticipate limited contributions from those technologies to the energy transition, and thus require greater green hydrogen use.

Fourth,  the  more  end  uses  for  green  hydrogen  included  in  a  scenario,  the  higher  the hydrogen  use  will  be.  Scenarios  that  cover  all  hydrogen  applications  and  downstream conversion to other energy carriers and products provide more flexibility in ways to achieve decarbonisation. More hydrogen pathways also help create larger economies of scale and faster deployment, leading to a virtuous circle of increasing both demand and supply.

Finally,  cost  assumptions,  typically  input  data  including  capital  and  operating  costs (Quarton  et  al.,  2019)  differ  between  scenarios.  Those  with  the  highest  ambitions  for hydrogen deployment are those with the most optimistic assumptions for cost reduction.

For all these reasons, the role of green hydrogen varies widely between scenarios. However, as more and more scenarios are being developed to reach zero or net-zero emissions, green hydrogen is more prominently present in scenarios and public discourse.

<!-- image -->

## 1.3. BARRIERS TO THE UPTAKE OF GREEN HYDROGEN

Green hydrogen faces barriers that prevent its full contribution to  the  energy  transformation.  Barriers  include  those  that apply to all shades of hydrogen, such as the lack of dedicated infrastructure ( e.g. transport and storage infrastructure), and those mainly related to the production stage of electrolysis, faced  only  by  green  hydrogen  ( e.g. energy  losses,  lack  of value recognition, challenges ensuring sustainability and high production costs).

- 1.    HIGH  PRODUCTION  COSTS Green  hydrogen  produced using electricity from an average VRE plant in 2019 would be two to three times more expensive than grey hydrogen (see Box  1.2). In addition, adopting green hydrogen technologies for end uses can be expensive. Vehicles with fuel cells and hydrogen tanks cost at least 1.5 to 2 times more than their fossil fuel counterparts (NREL, 2020). Similarly, synthetic fuels for aviation are today, even at the best sites in the world, up to eight times more expensive than fossil jet  fuel  (IRENA, 2019a). Box 1.2 provides examples of the production and transport costs of green hydrogen.

The key issue, however, is not the total capacity needed, since global renewable potential is in orders of magnitude higher  than  the  hydrogen  demand,  and  green  hydrogen developers  are  likely  to  first  select  areas  with  abundant renewable  energy  resources.  The  key  issue  is  whether the  annual  pace  of  development  of  the  solar  and  wind potential will be fast enough to meet the needs for both the electrification  of  end-uses  and  the  development of a global supply chain in green hydrogen, and the cost that this additional capacity will entail.

- 2.   LACK OF DEDICATED INFRASTRUCTURE. Hydrogen has to date been produced close to where it is used, with limited dedicated  transport  infrastructure.  There  are  only  about 5 000 kilometres (km) of hydrogen transmission pipelines around  the  world  (Hydrogen  Analysis  Resource  Center, 2016), compared with more than 3 million km for natural gas. There are 470 hydrogen refuelling stations around the world (AFC TCP, 2020), compared with more than 200 000 gasoline and diesel refuelling stations in the United States and the European Union. Natural gas infrastructure could be  repurposed  for  hydrogen  (IRENA,  IEA  and  REN21, forthcoming), but not all regions of the world have existing infrastructure. Conversely, synthetic fuels made from green hydrogen may be able to use existing infrastructure, though it might need to be expanded.
- 3.   ENERGY LOSSES. Green hydrogen incurs significant energy losses  at  each  stage  of  the  value  chain.  About  30-35%  of the energy used to produce hydrogen through electrolysis is lost (IRENA, forthcoming). In addition, the conversion of hydrogen  to  other  carriers  (such  as  ammonia)  can  result in  13-25% energy loss, and transporting hydrogen requires additional  energy  inputs,  which  are  typically  equivalent  to 10-12%  of  the  energy  of  the  hydrogen  itself  (BNEF,  2020; Staffell et  al. ,  2018;  Ikäheimo et  al. ,  2017).  Using  hydrogen in fuel  cells  can  lead  to  an  additional  40-50%  energy loss.  The  total  energy  loss  will  depend  on  the  final  use  of hydrogen. The higher the energy losses, the more renewable electricity  capacity is  needed to produce green hydrogen.
- 4.   LACK  OF  VALUE  RECOGNITION. There  is  no  green hydrogen market, no green steel, no green shipping fuel and  basically  no  valuation  of  the  lower  GHG  emissions that  green  hydrogen  can  deliver.  Hydrogen  is  not  even counted in official  energy  statistics  of  total  final  energy consumption, and there are no internationally recognised ways of differentiating green from grey hydrogen. At the same time, the lack of targets or incentives to promote the use of green products inhibits many of the possible downstream  uses  for  green  hydrogen.  This  limits  the demand for green hydrogen.
- 5.   NEED  TO  ENSURE  SUSTAINABILITY. Electricity  can  be supplied from a renewable energy plant directly connected to  the  electrolyser,  from  the  grid,  or  from  a  mix  of  the two. Using only electricity from a renewable energy plant ensures that the hydrogen is 'green' in any given moment. Grid-connected electrolysers can produce for more hours, reducing  the  cost  of  hydrogen.  However,  grid  electricity may  include  electricity  produced  from  fossil  fuel  plants, so any CO2 emissions associated with that electricity will have to be considered when evaluating the sustainability of hydrogen. As a result, for producers of hydrogen from electrolysis, the amount of fossil fuel-generated electricity can  become  a  barrier,  in  particular  if  the  relative  carbon emissions are measured based on national emission factors. Box  1.3  discusses  how  to  ensure  that  grid-connected electrolysers deliver hydrogen with minimum emissions.

<!-- image -->

## Box 1.2 Key cost components for green hydrogen

Green hydrogen competes both with fossil fuels and with other shades of hydrogen. It is important, therefore, to understand the factors that determine the cost of green hydrogen.

The  production  cost  of  green  hydrogen  depends  on the investment cost of the electrolysers, their capacity factor,  which is a measure of how much the electrolyser 7 is actually used, and the cost of electricity produced from renewable energy.

At  a  given  price  of  electricity,  the  electricity  component in  hydrogen's  final  cost  depends  on  the  efficiency  of  the process. For example, with an electrolyser efficiency of 0.65 and electricity price of USD 20 per megawatt hour (MWh), the electricity component of the total cost would go up to USD 30/MWh of hydrogen, equivalent to USD 1/kg. 8

By 2020, the investment cost for an alkaline electrolyser is about USD 750-800 per kilowatt (kW). If the capacity factor of the green hydrogen facility is low, such as below 10%  (fewer  than  876  full  load  hours  per  year),  those investment  costs  are  distributed  among  few  units  of hydrogen, translating into hydrogen costs of USD 5-6/kg or higher, even when the electrolyser is operating with zero-priced  electricity.  In  comparison,  the  cost  of  grey hydrogen is about USD 1-2/kg of hydrogen (considering a price range of natural gas of around USD 1.9/thinspace-/thinspace5.5 per gigajoule  [GJ]).  If  load  factors  are  higher,  however, investment  costs  make  a  smaller  contribution  to  the per-kg  green  hydrogen  cost.  Therefore,  as  the  facility load  factor  increases,  the  electrolyser  investment  cost contribution to the final hydrogen production cost per kg drops and the electricity price becomes a more relevant cost component.

Given today's relatively high electrolyser costs, low-cost electricity  is  needed  (in  the  order  of  USD  20/MWh)  to produce green hydrogen at prices comparable with grey hydrogen (see Figure 1.3). The objective of green hydrogen producers is  now  to  reduce  these  costs,  using  different strategies (IRENA, forthcoming). Once electrolysers costs have fallen, it will be possible to use higher-cost renewable electricity to produce cost-competitive green hydrogen.

Transporting hydrogen generates additional costs. Transport costs are a function of the volume transported, the distance and the energy carrier. At low volumes, the cost of transporting compressed hydrogen 1 000 km in a truck is around USD 3.5/kg. For large volumes, shipping green ammonia is the lowest-cost option and adds only USD 0.15/kg of hydrogen (without considering conversion costs,  i.e.  cracking).  Similar  low  costs  can  be  achieved using large pipelines (around 2 000 tonnes per day) over short  distances  (BNEF,  2020).  Hydrogen  transport  by pipeline can be one-tenth of the cost of transporting the same energy as electricity (Vermeulen, 2017).

## FIGURE 1.3 Hydrogen production cost depending on electrolyser system cost, electricity price and operating hours

<!-- image -->

<!-- image -->

Notes: Efficiency = 65% (lower heating value). Fixed operational cost = 3% of the capital costs. Lifetime = 20 years. Interest rate = 8.0%. Fossil fuel range: grey hydrogen, considering fuel costs of USD 1.9-5.5/GJ for coal and natural gas. Source: IRENA, forthcoming.

- 7 The capacity factor can span between 0 and 100% and represents the average full load hours of use of the electrolyser as a percentage of the total number of hours in a year (8 760). For example, a capacity factor of 50% indicates an average use of 4 380 hours.
- 8 1 kg of hydrogen contains around 33.33 kilowatt hours (kWh).

## Box 1.3 Hydrogen emissions from grid-powered electrolysis

For hydrogen from electrolysis to have lower overall emissions than grey hydrogen, CO 2 emissions per unit of electricity need to be lower than 190 grams of CO  per kilowatt 2 hour (gCO2/kWh) (Reiter and Lindorfer, 2015). Only a few countries (mostly benefiting from hydropower) have average CO2 emissions per kWh below that threshold and thus can ensure the sustainability of electrolytic hydrogen. Most other countries are currently above that threshold.

However, electrolysers can be designed to be flexible demand-side resources and can be ramped down or turned off when the national power mix is above a certain threshold of CO2 emissions, if tracked, and then turned back on when renewable production is higher, and  in  particular  when  VRE  production  would  otherwise  be  curtailed.  In  general,  low electricity  prices  are  a  proxy  for  high  renewable  energy  production  (IRENA,  2020c), so  electricity  prices  may  be  naturally  the  signal  for  electrolyser  activities.  Moreover, when electricity  prices  are  too  high  to  produce  competitive  hydrogen,  the  electrolyser would shut down anyway. The significant (for some countries) and increasing renewable energy share of electricity production will also decrease the carbon footprint of electrolytic hydrogen production.

A hybrid model can also be used, where off-grid VRE generation is the main source of electricity, but grid electricity can top up production to decrease the impact of initial investment  costs  while  causing  only  a  small  increase  in  the  carbon  footprint  of  the electrolysis plant.

Power  purchase  agreements  with  grid-connected  VRE  plants  may  also  ensure  the sustainability of electricity consumption and at the same time make green hydrogen an additional driver for the decarbonisation of the power grid.

<!-- image -->

## 1.4. POLICIES TO SUPPORT GREEN HYDROGEN

Historically,  every  part  of  the  energy  system  has  enjoyed some form of policy support. This has been and is still true for  fossil  fuels  (which  are  supported  with  both  direct  and indirect subsidies) and for renewable energy sources, across all sectors  -  power,  heating  and  cooling,  and  transport (IRENA, IEA and REN21, 2018). The hydrogen sector has also received some attention from policy makers with dedicated policies.  But  more  dedicated  policy  support  is  needed  at each stage of technology readiness, market penetration and market growth.

Most countries include FCEVs with battery electric vehicles in  their  zero-emission  vehicle  policies.  This  gives  FCEVs the  opportunity  to  benefit  from  incentives  given  to  zeroemission vehicles in general, without the need for policies that specifically promote hydrogen use.

## Status of policy support for green hydrogen

By 2019, hydrogen was being promoted in at least 15 countries and the European Union with supporting policies (other than standardisation  processes  or  national  strategies). 9   These policies directly or indirectly promoted hydrogen use across various  end  uses.  However,  due  to  previous  focus  on  land transport uses for hydrogen, about two-thirds of the policies targeted the transport sector (Figure 1.4).

The past two years, however, represented a game-changing moment  for  green  hydrogen  policies,  with  interest  rising around the world. Many countries (including Austria, Australia,  Canada,  Chile,  France,  Germany,  Italy,  Morocco, the Netherlands, Norway, Portugal and Spain, along with the European Union) announced, drafted or published national hydrogen strategies and post-COVID-19 recovery packages that included support measures for clean hydrogen.

FIGURE 1.4 Number of hydrogen policies at a global level by segment of the value chain

<!-- image -->

Source: IRENA analysis based on IEA (2019)

- 9 Belgium, Canada, China, France, Germany, Iceland, Italy, Japan, the Netherlands, Norway, New Zealand, Republic of Korea, Spain, United Kingdom and United States.

The change is not just quantitative (with pledges in the order of the billions of USD), but also qualitative: the emphasis of these  new  strategies  has  shifted  to  industry  and  product differentiation  and  future  competitiveness,  away  from  the previous focus on hydrogen use in transport.

Indeed,  hydrogen  can  cater  for  a  wide  range  of  uses,  as shown in Figure 1.1. It is important to prioritise the sectors where its use can add the most value to avoid diluting efforts or  putting  hydrogen  in  competition  with  more  immediate decarbonisation solutions, such as battery electric vehicles. When green hydrogen has achieved higher shares of final energy  consumption,  policy  priorities  should  expand  and evolve (see Section 2.2).

## The stages of green hydrogen policy support

As the penetration of green hydrogen technologies increases and costs come down, policies will have to evolve accordingly. The briefs following this report use the concept of policy stages to reflect the evolution of policy needs with the increased deployment of green hydrogen. Here are the three basic stages and the overall milestones for each:

<!-- image -->

First stage: Technology readiness. At this stage, green  hydrogen  is  a  niche  technology with  little  use  except  in  demonstration  projects;

it is mostly  produced  on-site  with  limited  infrastructure development. The largest barrier to greater use is cost. The main role of policy makers is to encourage and accelerate further deployment of electrolysers. This can be done in part through  long-term  signals,  such  as  a  commitment  to  netzero  emissions,  which  offer  certainty  to  the  private  sector and improve the business case for green hydrogen.

As important, however, are shorter-term policies that help to close the investment and operational cost gaps. These include research  and  development  (R&amp;D)  funding,  risk  mitigation policies and co-funding of large prototypes and demonstration projects  to  decrease  the  cost  of  capital.  In  addition,  end uses  still  at  the  demonstration  stage  may  need  dedicated mission-driven  innovation  programmes  with  clear  timelines and collaboration with the private sector to accelerate their commercialisation. Supportive governance systems and guidelines should also be put in place at this stage, ensuring that the growth of green hydrogen is sustainable.

<!-- image -->

Second stage: Market penetration. At this stage, some  applications  are  operational  and able  to  prove  what  green  hydrogen  can  do  and at what cost. Scaling up these technologies and developing experience  through  learning-by-doing  reduces  costs  and helps close the profitability gap. This stage also begins to see benefits  from  synergies  between  applications,  increasing hydrogen  demand  and  realising  economies  of  scale  for production  and  infrastructure.  These  synergies  can  take place in industrial clusters, hydrogen valleys ( e.g. cities)  or hubs ( e.g. ports).

Industrial  users  can  drive  the  development  of  dedicated 'green hydrogen corridors' that connect regions generating low-cost  renewable  energy  with  demand  centres.  Most of  this  infrastructure  is  not  developed  from  scratch,  but  is repurposed from existing natural gas networks and power grids.  The  first  international  trading  routes  for  hydrogen (or its  derived products) are established at this stage, and the existence of multiple producers and users leads to the creation  of  a  real  global  market  for  hydrogen.  As  the  use of green hydrogen grows, it becomes necessary to ensure that  sufficient  renewable  electricity  generating  capacity is  available,  so  that  green  hydrogen  production  does  not displace more efficient direct electrification.

<!-- image -->

Third stage: Market growth. At this stage, green hydrogen becomes a well-known and widely used energy  carrier  and  is  close  to  reaching  its  full potential. It has become competitive both on the supply side and in its end uses. Direct incentives are no longer needed for most applications and private capital has replaced public support in driving hydrogen growth. There is full flexibility in  converting hydrogen to other energy carriers, making it possible to use the most convenient alternative depending on  the specific conditions in each  region. The  power system has been decarbonised and only green hydrogen is being  deployed.  Most  natural  gas  infrastructure  has  been repurposed to transport pure hydrogen. 3 STAGE

Currently,  green  hydrogen  is  at  the  first  stage  for  most sectors.  Some  regions  may  be  more  advanced  in  specific sectors  or  uses,  while  still  being  immature  in  others.  For instance, California is ahead in FCEV deployment, but has no large-scale electrolysis industry, while Germany has focused on converting natural gas infrastructure to hydrogen. These cases  illustrate  how  progress  will  be  mixed  in  individual countries and that each country should not necessarily focus at the onset on all end uses of green hydrogen.

The stage approach described here provides the background for the policy pillars discussed in the second chapter.

<!-- image -->

Transitioning  green  hydrogen  from  a  niche player  to  a  widespread  energy  carrier  will require an integrated policy approach to overcome initial resistance and reach a minimum  threshold  for  market  penetration. That policy approach should have four central pillars: national  hydrogen  strategies,  policy priority setting, guarantees  of  origin, and enabling policies.

Long-term  commitment  from  government  is necessary to make available the private capital required for the transition to green hydrogen.

In addition to the four pillars presented in this chapter,  successful  hydrogen  policy  making should  include  the  same  elements  that  have been  necessary  to  assist the deployment of  renewable  energy  solutions  in  the  power sector.  These  inlude,  for  example,  long-term commitments. Long-term signals are essential for  private  and  institutional  investors  to  take the risk of investing in a novel technology, and this is particularly true for green hydrogen. The large  levels  of  investment  that  are  required mean that, in  general,  public  capital  alone  is not enough to move hydrogen from niche to mainstream.

International collaboration on energy has been  beneficial  for  countries  in  many  ways, as  demonstrated  in  the  R&amp;D  and  aligning  of national  agendas  to  accelerate  the  energy transition.  Collaboration  on  the  deployment of  hydrogen-related  solutions  (e.g.  upgrade of the gas grid in a cluster of countries) allows the sharing of risks, lessons learned and best practices,  which  translates  into  lower  costs. Collaboration on safety and standards enables countries  to  speak  a  common  language  and execute projects that cross borders, as well as enabling replication.

The following sections explore in greater detail the  four  policy  pillars  needed  to  support  a green hydrogen transition.

<!-- image -->

<!-- image -->

<!-- image -->

## 2.1. POLICY PILLAR 1: NATIONAL STRATEGIES

Recently announced hydrogen strategies result  from  a  long  process  and  mark  the beginning  of  a  new  wave  of  policies.  The strategy process usually starts with the establishment of R&amp;D programmes to understand the fundamental principles of the technology,  to  develop  the  knowledge  base that will inform future stages, and to explore multiple  technologies  and  possibilities  given that, at this early stage, the end applications are far from clear.

The  next  step  is  usually  a vision document that clarifies the 'why': 'why hydrogen', 'why this jurisdiction', and 'why now'. The  vision  document  represents  a  beacon that guides  research,  industry  efforts  and early demonstration programmes. Such vision  documents  are  often  co-created  by governments  and  private  actors  attracted by  the  growth  prospects  of  breakthrough applications.

The  strategy  covers  not  only  specific  direct policies (such as feed-in premiums for green hydrogen), but also includes integrating and  enabling  policies that are needed  to ensure  deployment  across  the  system,  such as  those  that  support  the  development  of  a skilled  workforce.  The  strategy  is  informed by  extensive  scenario  modelling,  often  with input from academia and industry. It sets the level  of  ambition  that  will  guide  the  work  in subsequent stages.

Next is a roadmap that goes one step further. It defines an integrated plan with the activities needed  to  better  assess  the  potential  for hydrogen. It identifies the short-term actions needed to advance deployment, and defines the  research  areas  with  the  highest  priority and  the  applications  where  demonstration projects are most needed.

Finally, the strategy itself defines the targets, addresses  concrete  policies and  evaluates their coherence with existing energy policy.

Throughout the process of preparing the strategy (Figure 2.1), public-private partnerships are  often  formed.  They  serve as  a  platform  to  exchange  information  to advance technological progress, create consensus,  align  views,  develop  incentives and co-ordinate activities. Public-private partnerships can reduce the risks during early  deployment,  facilitating  the  transition from demonstration to commercialisation. They  allow  companies  to  build  experience while  providing  the  benefits  of  first-mover advantage  in  case  of  success.  The  objective should be to reach a point where no further public  support  is  needed.  This  model  has already been successful in mobility and in the European  Union  (through  the  Fuel  Cells  and Hydrogen Joint Undertaking) to demonstrate hydrogen technologies for multiple pathways.

P1 National Strategies

<!-- image -->

## FIGURE 2.1. Steps leading to the formulation of a national strategy

## R&amp;D PROGRAMMES

## VISION DOCUMENT

- · Support basic and exploratory research
- · Start 'moonshot' programmes
- · Showcase potential/end goal
- · Align private and public views
- · Aim for technology leadership

## ROADMAP

<!-- image -->

- · Define major milestones and targets
- · Highlight benefits and added value
- · Present indicative timeline for scaling up
- · Showcase actions to advance
- • Create Information platforms

<!-- image -->

## PUBLIC-PRIVATE PARTNERSHIP

- • Create general consensus on the vision
- • Co-ordinate future efforts

<!-- image -->

A follow-up to the strategy is a set of analyses to  assess  the  impact  of  the  introduction  or change of specific policies. The analyses assess the economic, social and environmental consequences  of  the  implementation  of  the proposed  measures  in  the strategy. They evaluate  alternative  timelines  and  scopes,  as well  as  interactions  with  other  technologies. After  these  analyses,  the  actual  regulations and laws are introduced, followed by regular revisions to adjust them according to progress and latest trends.

## STRATEGY

<!-- image -->

- • Define key targets
- · Ensure coherence with rest of energy policy
- · Introduce direct, integrating and enabling measures
- · Introduce a timeline

<!-- image -->

<!-- image -->

This process from R&amp;D to strategy is far from linear or quick. Moreover, countries can skip the public-facing steps described here and issue a national hydrogen strategy while keeping the investigation activities confidential.

Public support for R&amp;D programmes on hydrogen was triggered by the oil crisis in the 1970s,  with  leading  efforts  from  the United States and Europe .  At  about the same time, platforms for international collaboration were established, such as the International Journal of Hydrogen  Energy  (1976).  Support  from federal  governments  started  in Canada in the early 1980s and in Japan in 1992 (Behling, Williams and Managi, 2015). The United States was one of the leading countries, establishing a public-private partnership in 1999 (California) and issuing a vision document and a roadmap in 2002 (US DOE, 2002).

Other  countries  have  developed  their  vision or  roadmap  documents,  with  final  strategies expected  in  the  next  years.  For  example, New Zealand published  its  vision  document in  2019,  which  outlined  the  potential  uses  of hydrogen and explored in a non-quantitative manner some of the issues around its use. The anticipated next stage is a roadmap to identify the steps towards making the use of hydrogen possible in the wider economy.

R&amp;D  programmes  are  still  very  active  and necessary  today, with one  of the largest recently  being  adopted  in China . China  is exploring solutions to use hydrogen in cities: the  previous  subsidies  for  FCEVs  are  being replaced by pilot demonstrations in selected cities for an initial phase of four years. A focus will  be  on  research  into  and  application  of critical components, and support from central government  will  be  in  the  form  of  financial awards  to  these  cities  rather  than  purchase subsidies for consumers.

The pace of action is accelerating. In the last two years, given the new wave of interest in hydrogen,  many  countries  have  progressed through the steps in Figure 2.1 and have issued their own  national  strategies  (Figure  2.2). France first published a hydrogen strategy in 2018,  which  was  updated  in  June  2020.  The European  Union established a High-Level Working  Group  on  hydrogen  in  2002  (with 19 stakeholders from the research community, industry,  public  authorities  and  end  users), issuing  its  vision  document  one  year  later (European Commission, 2003). It established the  Fuel  Cell  Technology  Platform  in  2004, which paved the way for the inception of the Fuel  Cells  and  Hydrogen  Joint  Undertaking (FCH JU, 2017).

<!-- image -->

<!-- image -->

T

W

O

FIGURE 2.2. Government hydrogen-related initiatives announced between June 2018 and November 2020

<!-- image -->

Notes: Hydrogen policies are evolving rapidly. Information on this figure has been kept as detailed and complete as possible at the time of writing, however more countries may have announced, drafted and published vision, roadmap and strategy documents.

With the arrival of the new wave of interest, the European Union finally released its overall green hydrogen strategy (Box 2.1), with some policies scheduled for introduction in 2021.

Many countries are expected to publish their hydrogen  strategies in the coming  years. Progress is expected in Latin America, following the launch of Chile's national strategy, in the Arabian  Peninsula  and  in the  member  states  of  the  European  Union, following  the  EU  strategy.  Austria  and  Italy, for  example,  already  included  hydrogen  as part of their national energy and climate plans (NECPs); the aim for European countries is to achieve a co-ordinated roll-out and to ensure that the strategies fit within their overall NECPs and the European Union strategy.

Developing the optimal zero or net-zero CO2 emissions strategy -including the most  effective  green  hydrogen  strategy  is  a  challenging  task.  There  are  competing decarbonisation solutions for most applications  and  end  uses,  and  the  relative costs  and  benefits  of  each  solution  will  be constantly  changing  according  to  the  pace of innovation and development of each specific  technology.  Governments,  therefore, have difficult choices to make  on which technologies will be the best fit for the future of  their  countries,  while  avoiding  numerous possible  pitfalls,  such  as  locking  in  slower  or less efficient pathways to reducing emissions. For this reason, establishing policy priorities is an  important  component  of  green  hydrogen policy making.

Activities are also taking place at the subnational  level.  Roadmaps  and  strategies have been  released by California (United States), provinces in the North of the Netherlands, and by South Australia, Western Australia, Victoria, Queensland and Tasmania, together with the Australian national strategy (COAG, 2019).

<!-- image -->

P1 National Strategies

<!-- image -->

<!-- image -->

## Box 2.1 The EU hydrogen strategy

The EU strategy aims for an integrated view of the hydrogen value chain, and establishes a supporting governance system and policy framework to promote hydrogen deployment (Figure 2.3).

The ambition of EU policymakers is to make the European industry a global leader, both in green hydrogen equipment and zero-carbon heavy industry. For this reason, the strategy identifies green hydrogen as the only shade of hydrogen compatible with a net-zero emission system.

The  strategy  aims  to  create  at  least  6  GW  of  electrolyser  capacity  by  2024,  enough  to produce up to 1 Mt/yr of green hydrogen. That would increase to 40 GW in EU countries by 2030, with an additional 40 GW of electrolyser capacity in southern and eastern neighbours (e.g. Ukraine or Morocco), from which the European Union could import green hydrogen.

The strategy sets a number of actions, including not only regulatory changes indicated by impact assessments, but also supporting investments designed to kick-start deployment.

The strategy adopts a staged approach, similar to the one followed in this report:

<!-- image -->

(2020-2024): Scale-up electrolyser capacity to 6 GW and produce up to 1 Mt/yr of renewable hydrogen. The focus is on decarbonising applications that already use hydrogen and facilitating the uptake of green hydrogen in new end-use applications. The hydrogen supply would be mostly local to avoid the need for extensive infrastructure while planning for infrastructure expansion. Some existing hydrogen production is retrofitted with carbon capture.

<!-- image -->

2025-2030): Scale-up electrolyser capacity to 40 GW in EU countries ( and  produce  up  to  10  Mt/yr  of  renewable  hydrogen.  An  additional 40 GW of capacity may be commissioned in neighbouring regions, via co-operation. Transporting the green hydrogen will require a pan-European grid infrastructure  that  could  be  largely  based  on  existing  natural  gas  infrastructure. International trade with neighbouring regions can also be developed. It is assumed that  the  hydrogen  market  will  be  efficient  in  allocation,  with  unhindered  crossborder trade.

<!-- image -->

2030-2050):  Green  hydrogen  reaches  maturity  and  is  deployed  at ( large  scale  across  all  hard-to-abate  sectors  where  alternatives  have  a higher cost. E-fuels made from hydrogen would be used in a wide range of sectors, including aviation and shipping.

2050

Reaching the 2030 goals is estimated to require investment of EUR 24-42 billion for  electrolyser capacity,  in  addition  to  EUR  220-340  billion  for 80-120 GW of additional renewable power generation  capacity,  EUR  65  billion  for  infrastructure and EUR 11 billion for retrofitting existing natural gas plants.

<!-- image -->

2020

2025

2030

FIGURE 2.3. Main aspects and instruments mentioned in the EU hydrogen strategy

## SUPPLY

## INFRASTRUCTURE

## DEMAND

- · Use of life cycle CO2 thresholds
- · Threshold for low carbon
- · Use of certification schemes
- · Adoption of tenders
- · Reform of gas market legislation
- · Repurposing gas infrastructure
- · Provide equal access to all stakeholders
- · Revision of ETS
- · Introduction of 'Carbon Contract for Difference'
- · Market-based support schemes
- · Quotas of green hydrogen in end uses

## INVESTMENT

<!-- image -->

Important Projects of Common European Interest (IPCEI); REACT-EU; InvestEU programme; European Regional Development Fund and the Cohesion Fund

## RESEARCH AND INNOVATION

<!-- image -->

Larger and more efficient electrolysers; innovative production technologies; assess the repurposing of natural gas infrastructure; environmental impact; safety and materials

## INTERNATIONAL DIMENSION

<!-- image -->

Partnerships with neighbouring regions; IPHE, CEM, MI, IEA, IRENA; global trading; trade policy to avoid market distortions; Euro as benchmark for hydrogen trading

Notes: CEM = Clean Energy Ministerial; ETS = emissions trading system; IPHE = International Partnership for Hydrogen and Fuel Cells in the Economy; MI = Mission Innovation; REACT-EU = Recovery Assistance for Cohesion and the Territories of Europe.

Source: European Commission, 2020.

## 2.2.   POLICY PILLAR 2: ESTABLISH POLICY PRIORITIES FOR GREEN HYDROGEN

Individual  countries  have  specific  conditions. As  a  result,  national  green  hydrogen  policy makers should carefully assess, in order to set up their policy priorities, key factors for each segment of the hydrogen value chain. These include  the  size  of  the  country's  renewable resources,  the  maturity  of  its  energy  sector, the current level of economic competitiveness and the potential socio-economic effects.

## 1. Hydrogen is not a full substitute for fossil fuels

P2 Establish Policy Priorities

For  example,  a  region  with  good  renewable energy  resources  could  use  electrolysis  to make green hydrogen cost-competitive, while in other  cases  policy  makers  may  identify more value in importing hydrogen instead and focusing  their  efforts  on  other  technologies underpinning the energy transition.

As countries  develop  their  net-zero  emission and  green  hydrogen  strategies,  it  may  be useful  to  remember  three  basic  concepts  to set up policy priorities.

<!-- image -->

The first concept to be kept in mind is that, despite the great promise of green hydrogen and  its  suitability  to  replace  fossil  gases,  it is  not  a  complete  substitute  for  fossil  fuels. Instead,  it  is  just  one  of  several  possible decarbonisation alternatives (Figure 2.4) that should  be  carefully  weighed  when  setting priorities. Similarly, the selection of the supporting  policies  must  take  into  account the relative costs and  benefits of green hydrogen compared to other decarbonisation solutions  for  specific  end  uses,  especially given continuing progress in competing technologies.

In many  cases,  direct  electrification using renewable energy, along with energy efficiency,  will  be  a  faster  and  more  costeffective solution to decarbonising the energy system  than  using  green  hydrogen.  In  the transport sector, for example,  the rapidly declining cost and technological improvement of batteries have made electric vehicles a very attractive solution for the decarbonisation of  the  sector.  Use  of  hydrogen  in  FCEVs  will still be possible for specific uses, for example where  the  electricity  grid  is  unavailable.  The two  transport  subsectors  where  fewer  lowcarbon  alternatives  to  green  hydrogen  exist are  international  aviation  and  shipping,  so  it will most likely be part of a low-carbon future for these subsectors.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

FIGURE 2.4. Hydrogen as a complement to alternative ways to decarbonise end uses

|                | RENEWABLES                                                                 |                                                       | DIRECT ELECTRIFICATION                                     | GREEN ENERGY EFFICIENCY                      |
|----------------|----------------------------------------------------------------------------|-------------------------------------------------------|------------------------------------------------------------|----------------------------------------------|
| HEATING        | • Solar water heaters, direct geothermal use, biomass (low- grade heating) | • Heat pumps                                          | • Retrofit of buildings • Technological advancement        | • High-grade heating                         |
| INDUSTRY       | • Solar drying, biomass (productive uses)                                  | • Electric industrial application (e.g. arc furnaces) | • Use of best available technologies                       | • Steelmaking refineries • Chemical industry |
| LAND TRANSPORT | • Biofuels                                                                 | • Battery electric vehicles                           | • Performance standards • Travel avoidance • Engine design | • FCEVs                                      |
| SHIPPING       | • Biofuels • Wind energy                                                   | • Short-distance shipping                             | • Ship design • Operation optimisation • Travel avoidance  | • Green ammonia • Methanol                   |
| AVIATION       | • Biojet fuels                                                             | • Short-distance aviation                             | • Plane design • Travel avoidance                          | • Hydrogen and synthetic fuels for aviation  |

Based on: IRENA, IEA and REN 21, forthcoming, and IRENA, 2020b.

## 2. The need to identify the highestvalue applications

Once  the  decision  to  promote  green  hydrogen  has  been made,  policy  decisions  include  what  applications  should be prioritised and how quickly to make the shift from fossil fuels to green hydrogen. Policy makers should identify the highest-value  applications  for  a  given  amount  of  green hydrogen, in order to focus their policy efforts where they could provide the most immediate advantages and enable economies of scale.

One potential role for green hydrogen policy is to support and then accelerate a shift to green hydrogen in industrial applications where  hydrogen  is  already  used,  such  as refining  and  the  production  of  ammonia  and  methanol. Notably, the demand from these facilities is large enough to enable economies of scale in production and infrastructure, making the shift to green hydrogen even more cost-effective in these applications compared to distributed applications.

For example, 2 250 tonnes per day of green hydrogen could be used to meet the heat demand for buildings in a city with more of a million people. Instead, the same amount could be  used  to  power  a  single  green  ammonia  plant.  In  this case, using the hydrogen to make ammonia would avoid the high infrastructure costs and large amount of time needed to  convert  thousands  of  homes  to  hydrogen.  At  the  same time, heat demand in residential buildings can be met more easily  by  other  solutions  such  as  heat  pumps  powered  by renewable electricity (IRENA, IEA and REN21, forthcoming).

Another option to consider is to combine various uses that can  benefit  production  by  achieving  larger  economies  of scale.  These  synergies  can  be  found  in  industrial  clusters, ports and cities (Roland, 2018). The synergies in such clusters help  create  a  virtuous  circle  between  supply  and  demand where large-scale production decreases costs, which in turn encourages demand within the same area. Higher demand then enables production to expand, further reducing costs and enabling even greater use.

<!-- image -->

<!-- image -->

<!-- image -->

Finally, when setting priorities, policy makers must carefully weigh both the economic gap compared to incumbent fossil fuel options and the urgency of the need to reduce emissions, in particular where  options other than green hydrogen are virtually non-existent. For instance, green hydrogen used for the direct reduction  of  iron  (DRI) 10 is  one  of  the  few options  for  zero-emission  steel  production. But the technology is only in pilot stage and may take several years to reach the commercial stage. Similarly, synthetic fuels are one of the few  options  for  decarbonising  aviation,  but are  currently  far  away  from  reaching  cost parity with fossil jet fuel. Yet, despite this high cost,  efforts  need  to  start  today  to  reduce production costs and scale up production.

P2 Establish Policy Priorities

<!-- image -->

## 3. The principle of renewable energy additionality

Finally, the principle of additionality is crucial for the renewable  energy  used  for  green hydrogen production. In other words, if there are  other  productive  uses  for  the  electricity being generated from renewable sources, that electricity should not be diverted from those uses  to  produce  green  hydrogen.  Instead, green  hydrogen  should  be  produced  only from  additional  renewable  energy  capacity that  would  not  otherwise  be  commissioned and  electricity  that  would  not  be  otherwise consumed.

Failing to follow this principle of additionality would slow down the electrification of buildings, industry and transport with renewable energy that is critical for a successful energy transition, and actually cause  more  fossil  fuels  to  be  brought  into the  power  mix.  At  the  same  time,  as  more renewable capacity is constructed, more periods of excess generation will occur, which could  either  lead  to  VRE  curtailment  or  be productively  used  to  make  green  hydrogen. In this case, not only would the hydrogen then be used to decarbonise hard-to-abate sectors, its  production  would  also  increase  the  value of those generating assets and make it easier to  integrate  large  amounts  of  VRE  into  the electricity grid.

<!-- image -->

10   Iron is found in nature in combination with oxygen. The removal of this oxygen is called reduction. This reduction is done today with a mix of carbon monoxide (CO) and hydrogen (H2) in various proportions: the oxygen combined with CO and H2 then produces CO2 and H2O. Hydrogen can provide the same function alone, thus avoiding CO2 production.

<!-- image -->

## 2.3.   POLICY PILLAR 3: GUARANTEE OF ORIGIN SCHEME

Molecules  of  green  hydrogen  are  identical  to  those  of grey  hydrogen.  For  this  reason,  once  hydrogen  has  been produced, a certification system is needed that allows end users and governments to know the origin and quality of the hydrogen.

The schemes used to track origin are usually referred to as providing a 'guarantee of origin' (GO). 11  One example in the case  of  hydrogen  is  the  CertifHy  project  in  the  European Union. The scheme issued over 76 000 GOs for green or lowcarbon hydrogen, out of which 3 600 were used by 2019.

This  was  a  pilot  project  covering  less than 0.05% of the total EU market and less  than  4%  of  the  certificates  were actually from renewable energy. Table 2.1 presents  this  and  other  examples  of GO certification schemes. In particular, such schemes should be used to track CO2 emissions from the production to  the  use  of  hydrogen,  in  order  to recognise  when  and  where  the  use  of hydrogen  can  be  more  effective  for decarbonisation  purposes  than  direct electrification or the use of bioenergy.

<!-- image -->

Table 2.1. Examples of guarantee of origin schemes

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| BODY                                          | REFERENCE                                          | THRESHOLD                                        | QUALIFIED PROCESSES                                                                                                                                               |
|-----------------------------------------------|----------------------------------------------------|--------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| AFHYPAC                                       | None                                               | 100% renewable                                   | All renewable-based solutions                                                                                                                                     |
| Low Carbon Fuel Standard                      | Well-to-wheel emissions from new gasoline vehicles | 30% lower GHG, 50% lower NO x                    | Green hydrogen, catalytic cracking of biomethane or thermochemical conversion of biomass, including waste                                                         |
| CertifHy                                      | Grey hydrogen                                      | 60% lower GHG than reference (36.4 gCO 2 /MJ)    | Two labels: • 'Green hydrogen' if the hydrogen is made from renewable energy • 'Low carbon hydrogen' otherwise Hydrogen must meet the threshold with 99.5% purity |
| TÜV SÜD                                       | Grey hydrogen                                      | 35-75% lower than reference depending on process | Renewable electrolysis; biomethane steam methane reforming; pyro-reforming of glycerine                                                                           |
| Clean Energy Partnership                      | Grey hydrogen                                      | 100% renewable                                   | Renewable electrolysis; biomass                                                                                                                                   |
| REDII/thinspace 12                            | Transport fuels                                    | 70% reduction                                    | Renewable transport fuels of non-biological origin                                                                                                                |
| Technical Expert Group on Sustainable Finance | None                                               | 5.8 tCO 2 /tH 2 or 100 gCO 2 /kWh used as input  | Water electrolysis                                                                                                                                                |

Notes: REDII = Renewable Energy - Recast to 2030; NOx = nitrogen oxides; gCO2 /MJ = grams of carbon dioxide per megajoule; gCO2/thinspace/thinspace /kWh = grams of carbon dioxide per kilowatt hour; tCO2/thinspace/thinspace /tH2 = tonnes of carbon dioxide per tonne of hydrogen.

Sources: Jensterle et al., 2019; Velazquez Abad and Dodds, 2020.

- 11 For the purpose of this report, GO is used to define all schemes quantifying the GHG emissions of hydrogen or its derivatives.
- 12  This is applicable to all advanced renewable fuels, including hydrogen and its derived products.

T

W

O

The  previous  examples  show  that  there  is  still  no  single definition  for  the  certification  of  hydrogen,  meaning  that schemes  may  be  incompatible.  For  example,  the CO2 threshold limit below which hydrogen would be considered 'green' or 'low-carbon' varies widely (35-100%). Some of the schemes cover multiple hydrogen production technologies (e.g. Low Carbon Fuel Standard, CertifHy), while others focus specifically on green hydrogen (e.g. AFHYPAC).

The schemes also vary when it comes to end uses. Some cover all possible sectors (e.g. CertifHy), while others focus on  a  particular  application.  For  example,  the  Low  Carbon Fuel Standard only applies to use in vehicles. In addition, the references can be different: for example, the TÜV SÜD uses as baseline the production of grey hydrogen, while the REDII compares  emissions  against  the  reference  values  of  the incumbent technology (fossil fuels for transport). Finally, it should be noted how some of the schemes presented above are  part  of  a  legislative  requirement  to  obtain  incentives or  to  be  accounted  as  renewable  energy  (e.g.  LCFS  and REDII - both related to the transport sector), while others are voluntary schemes adopted by producers to guarantee their sustainability.

To be useful for producers, policy makers and end users, all GO schemes should provide a clear label for the hydrogen product to increase consumer awareness and accurately describe the value  of  the  commodity  (Veum et  al. ,  2019,  Mehmeti et  al. , 2018).  The  information  provided  should  clearly  differentiate between the various hydrogen production pathways.

A GO scheme should also be based on life  cycle  GHG  emissions, from  upstream  activities  such  as  electricity  generation  to transport  (see  Figure  2.5).  That  would  ensure  consistency and compatibility with GHG emission certification schemes for other commodities, such as electricity or fossil gas.

Green  hydrogen  solutions  could  then  be  compared  with other hydrogen shades, fossil fuels, direct electrification and use of bioenergy.

Biofuel certification schemes offer lessons on how to track and certify hydrogen. In biofuel certification schemes, some parts of the production chain can have default CO  reference 2 values. In this way, the process of certification is accelerated for new  applications. The  default values are regularly updated  to  reflect  technological  changes.  Producers  may still  apply  for  specific  audited  values,  if  they  believe  they have achieved better values than the reference ones.

The  transport  of  biofuels  is  also  accounted  for  in  biofuel certification  schemes  by  considering  how  and  how  far feedstocks and biofuels have been transported. Hydrogen GO  schemes  need  to  do  this  as  well,  since  hydrogen produced from a dedicated wind farm and then transported with diesel trucks may have a greater carbon footprint then hydrogen produced with grid electricity that is transported in a pipeline.

Lastly, GO  schemes  should  be  designed  to  allow  the international  trading  of  green  hydrogen,  helping  to  create a  global  market.  An  example of international collaboration is  the  Hydrogen  Production  Analysis  Task  Force  from  the International Partnership for Hydrogen and Fuel Cells in the Economy (IPHE, 2020). The task force is aiming to develop a harmonised methodology and terminology to define and standardise clean hydrogen across different countries and to facilitate the creation of a common scheme for GO.

GO  schemes  will  be  a  key  element  of  a  green  hydrogen system, at least until carbon-intensive hydrogen is no longer produced.  Other  enabling  policies  will  still be  needed, however, to drive growth in green hydrogen.

FIGURE 2.5. Guarantees of origin lifecycle emissions (Illustrative)

<!-- image -->

## 2.4.   POLICY PILLAR 4: GOVERNANCE SYSTEM AND ENABLING POLICIES

As  green  hydrogen  transitions  from  niche to  mainstream,  the  policies  that  drive  the transition must not only cover the deployment of  green  hydrogen (presented in Chapter 3), but also its integration into the broader energy system. It is economy-wide policies that affect the  sustainability  and  pace  of  the  transition. Civil society and industry must be involved in this new sector in order to reap its benefits.

A broad base of support can create an enabling environment  for green  hydrogen actors  to  provide  their  value  to  the  whole energy and social system. With these goals in mind, concrete actions that policy makers can take include:

- · Seeking  advice  from  civil  society  and industry. Civil society and industry can  provide  advice  to  policy  makers  on proposals, actions and amendments  to the  strategy  depending  on  progress.  An advisory council of experts who can provide high-quality input to government  could be  created.  The  council  should  include  a diverse  range  of  actors  from  academia, business  and  civil  society  to  ensure  that all interests  are  considered.  The  council could  use  sectoral  or  thematic  tables  to gather input from a broader range of stakeholders. Outcomes of the tables would be summarised and used as inputs for the council's recommendations to government. Italy's  'Hydrogen  Table'  is  an  example  of this policy. It involves companies and other stakeholders  operating  in  the  institutional and  research world, with the objective of  keeping  the  government  updated  on technological progress, identifying possible projects  in  the  hydrogen  value  chain  and their potential socio-economic effects, and maintaining international collaboration (MISE, 2020).
- · mplementing I measures to maintain industrial competitiveness and create export opportunities. Policy makers can  assess  which  elements  of  the  green hydrogen value chain can be manufactured domestically. This would include an assessment in each country of its existing national capacity compared to other countries and the actions needed to achieve  leadership.  In  some  cases,  as  in Canada,  Germany  and  South  Korea,  the strategy  could  also  set a national goal of  becoming  a  first  mover  to  develop  a domestic industry, thus enabling exports of the technologies to other regions. Countries (such as Australia, Chile, Portugal and some members of the Gulf  Cooperation  Council region) may also focus on using their vast domestic renewable resources to establish an exporting hydrogen sector and promote domestic economic growth.
- · dentifying I economic  growth  and  job creation opportunities. As part of a strategy,  policy  makers  should  assess  the value that the hydrogen sector would add to the economy and its effect on associated industries,  quantifying  the  number  of  jobs generated in equipment manufacturing, construction  and  operation,  and  indirectly in the supply chain and supporting industries. Examples  of  analyses  of  the employment  impact  of  green  hydrogen within  an  economy  are  common  across first-mover  countries,  and  they  are  used to inform national strategies. This was the  case,  for  example,  in  the  Netherlands (CE Delft, 2018; Government of the Netherlands,  2020).  In  addition,  the  local workforce  needs  to  be  able  to  perform the  new  jobs  that  will  be  created  in  these activities, and even in regulating the industry. Countries will therefore need education and training programmes  to ensure a match between the skills needed and those currently available.

P4 Governance system and enabling policies

P4 Governance system and enabling policies

- · ntroducing hydrogen as a part of energy I security. Not all countries enjoy the presence  of  large  reserves  of  fossil  fuels, meaning  that  the  continuity  of  supply  is governed  by  ever-changing  political  and economic factors. The production of green hydrogen  can  ease  the  demand  for  fossil fuels,  in  particular  for  industry  and  hardto-abate sectors, increasing the energy security of a country.
- · Setting international codes and standards. International standards make it possible  not  only  to  execute  cross-border projects,  but  also  to  reap  the  benefits  of learning-by-doing from foreign companies that  design  and  construct  the  equipment. This  will  enable  costs  to  decrease  more rapidly and will enhance safety as a result of  applying  best  practices,  among  other benefits for end consumers.
- · Building  or  repurposing  infrastructure. Policy  makers  should  assess  the  potential for repurposing existing natural gas pipelines  to  transport  hydrogen,  and  thus decrease  overall  costs.  They  also  need  to guide  the  development  of  the  hydrogen network  by  considering  the  locations  of potential demand clusters and supply centres.  Transparent  plans  and  timelines for hydrogen network backbones, storage, fuelling stations and port infrastructure can be useful at the early stages to indicate the future routes and identify possible hurdles. Plans to repurpose grid infrastructure can be found in the EU hydrogen strategy (European Commission, 2020).
- · Ensuring access to financing. Policy makers can provide direct dedicated funding from state budgets, or assist access to private capital by creating guidelines or new facilitating mechanisms. Public support may  be  needed  for  initial investments, in  order  to  attract  private  capital.  Given the versatility of hydrogen, there are multiple  ways  to  expand  existing  funding programmes to cover its development.
- · Collecting statistics. Hydrogen is not currently included in national energy balances,  because  it  is  considered  to  be a chemical  product.  Including  hydrogen supply and demand as a separate category in national energy balances (similar to electricity, fossil fuels  or  bioenergy)  will allow better identification of energy flows and provide a solid basis for further analysis.  Maintaining  a  central  repository of data on hydrogen deployment across  different  sectors  (such  as  MW  of electrolysis or number of FCEVs) can make  market  information  (such  as  prices, traded  volumes  and  share  of  green  and low-carbon hydrogen) openly available to  promote  transparency.  This  action  will also  require  international  co-operation  to align  the  methodology and ensure mutual comprehension.
- · Setting research priorities. By identifying technology needs, policy makers can prioritise the actions needed to close innovation gaps. A regular review of funding,  progress  and  priorities should be part of the process. Since many of the hydrogen pathways needed over the long term  are  still  in  their  early  stages,  policy makers should ensure the research agenda includes  key  demonstration  projects  to bridge the gap to commercialisation.

<!-- image -->

<!-- image -->

<!-- image -->

- · mplementing I carbon pricing. Green hydrogen  will  bring  major  GHG  emission reductions when used to replace fossil fuels for many end uses. However, in many cases this  benefit  is  not  reflected  in  commodity prices, reducing the economic incentive to produce  green  hydrogen.  By  internalising the  externalities  (such  as  the  impacts  of extreme weather events, including damage to  crops  and  other  assets)  in  the  form  of either  a  carbon  tax  (i.e.  a  predetermined price path)  or a trading  system  (i.e. a predetermined  limit  on  emissions  with  a variable price), policy makers will contribute to valuing this benefit and  closing the economic gap with fossil fuel pathways.
- · Phasing  out  fossil  fuel  subsidies. Fossil fuel  subsidies  are  responsible  for  various fiscal,  social  and  environmental  problems. These problems include harmful impacts on energy markets and greater fiscal burdens on governments, as well as environmental impacts. By phasing out fossil fuel subsidies, policy makers will help to close the economic gap with green hydrogen, while reducing  market  distortions  and  making the  real  price  of  fossil  fuels  clearer.  When energy subsidies are used to assist energyvulnerable populations or to guarantee competitiveness of national companies, careful planning of their phase-out should include  measures  to  avoid  energy  price spikes or excessive burdens on family and company budgets.

While  the  measures  described  here  can facilitate the deployment of green hydrogen, supporting  mechanisms  may  still  need  to be put in place. The next chapter provides examples of such measures.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

This chapter will present insights and recommendations for policy makers who are considering  kickstarting  the  green  hydrogen sector  in  their  jurisdictions.  Green  hydrogen is  at  an  early  stage  in  most  applications  and needs policy support to advance from niche to  mainstream  and  be  part  of  the  energy transition.  Some  barriers  to  the  deployment of green  hydrogen  in  various  sectors  are relatively consistent across end uses (as discussed in Section 1.3), the cost barrier being the main one.

Other  barriers  are  more  sector-specific  and call for a tailored approach (Figure 3.1).

Once  priorities  are  set,  policy  makers  need to address the barriers specific to the sectors where  green  hydrogen  is  expected  to  be deployed.  In  this chapter,  specific policies and  measures  are  presented  for selected segments of the hydrogen value chain. The  policy  briefs  that  are  due  to  follow  this publication will delve in greater detail for each of the mentioned elements.

<!-- image -->

<!-- image -->

<!-- image -->

FIGURE 3.1 Selected barriers and policies for segments of the hydrogen value chain

- -Capital cost
- -High cost
- -High cost

## BARRIERS

- -Electricity cost
- -Limited existing infrastructure
- -Lack of hydrogen market
- -Barriers to power market

<!-- image -->

## ELECTROLYSIS

- + Set capacity targets
- + Offer loans
- + Introduce feed-in premium
- -Technical limitations of users
- -Lack of investment

<!-- image -->

## INFRASTRUCTURE

- + Collaborate on global trading of hydrogen
- + Identify priorities for conversion
- -Lack of demand for green products
- -Global competition and carbon leakage

<!-- image -->

## INDUSTRY

- + Offer dedicated loans
- + Develop public procurement of green products
- -High cost
- -Technical barriers

## SHIPPING

- + Introduce fiscal incentives
- + Set targets for zero-emission vessels
- + Allow participation in ancillary markets
- + Align blending targets
- -Procurement of sustainable CO2
- -Policy focus on biofuels
- + Set targets
- + Review policy focus
- + Expand emissions trading system
- + Provide financing
- + Phase out high-emission technologies
- + Support infrastructure development

<!-- image -->

<!-- image -->

## 3.1. POLICY SUPPORT FOR ELECTROLYSIS

Green  hydrogen  is  produced  via  electrolysis from renewable electricity. Electrolysis is a developed  and  commercialised  process, with various technologies available, each with benefits and barriers to uptake (IRENA, forthcoming).  While  electrolysis  technology is mature, about 95% of all the hydrogen used today is still produced from fossil fuels through SMR  or  coal  gasification  (grey  hydrogen). Water electrolysis for the production of green hydrogen is limited to about 200 MW of electrolyser capacity in few hundreds demonstration projects.

But green hydrogen production has the potential to grow quickly. The manufacturing capacity  to  build  electrolysers  is  increasing rapidly, and multiple projects have been announced  with  a  gigawatt  scale  (IRENA, forthcoming).

<!-- image -->

## Barriers

The greatest single barrier to the production of  green hydrogen is its cost - it is currently two to three times more expensive to produce than grey hydrogen (see Box 1.2).

A  market  for  green  hydrogen  thus  needs  to be created to enable cross-border trading and to  harness  the  power  of  market  forces.  This market will  need  to  incorporate  the  value  of sustainable  production,  which  would  in  turn accelerate the uptake of electrolysers as green hydrogen becomes a valuable asset.

## Policy recommendations

All these barriers can be overcome  with carefully designed policies. Costs can be brought  down  through  economies  of  scale, innovation, efficiency gains and improvements in the manufacturing of electrolysers. Several  policies  can  accelerate  the  growth in  electrolyser  capacity  and  green  hydrogen production, and thus help achieve these cost reductions. Meanwhile, other policies can increase  the  financial incentives  for green hydrogen  production  by  closing  the  current large  gap  between  the  costs  of  producing green and grey hydrogen. These policies include:

Another  barrier  to  the  wider  use  of  green hydrogen  is  the  lack  of  recognition  of  the value  that  it  can  provide.  Hydrogen  is  not publicly traded: the hydrogen currently being used  comes  mostly  from  on-site  generation and bilateral agreements between companies.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

- n Setting targets for electrolyser capacity , such  as  the  European  Union's  goal  of increasing electrolyser capacity to 80 GW (40 GW in Europe, 40 GW in neighbouring countries) by 2030 (European Commission, 2020). Similar to renewable energy targets, these goals will inform the private sector of the countries' commitments and help attract investment.
- n Tackling  high  capital  cost. Government loans,  capital  grants  and  other  forms  of financial assistance can make the business case for the installation of electrolysers. For example, the United Kingdom has awarded USD  9.8  million  for  a  feasibility  study  to scale up the size of electrolysers to 100 MW and to increase manufacturing capacity to 1 GW/yr by 2025 (Element Energy, 2020).
- n Improving tax schemes for electrolysers. The  cost  of  green  hydrogen  production could be lowered by reducing the taxes  and  fees  on  the  electricity  used by electrolysers. Lowering corporate, business and sales taxes on green hydrogen  could  also  improve  revenues and the rate of return on projects.
- n Paying  a  premium  for  green  hydrogen through feed-in tariffs or other subsidies. Subsidies for renewable biogas and biomethane  are  already  in  place  in  six European countries, and could potentially be extended to green hydrogen. The SDE++  programme  in  the  Netherlands  is set to provide subsidies for the production of hydrogen from electrolysis (RVO, 2020).
- n Ensuring additionality of renewables generation. As the production of hydrogen  grows,  measures  must  be  put in place to ensure  that the electricity used  by  electrolysers  is  as  low  carbon as  possible  and  that  enough  renewable electricity  is  available  for  both  the  direct electrification of end uses and the production  of  hydrogen.  Policy  makers may  need  to  set  ambitious  targets  for the growth of renewable generation capacity. In addition, policy makers could consider incentives and market rules that encourage  electrolyser  operators  to  use renewable electricity that would otherwise be  curtailed;  one  strategy  would  be  to locate electrolysers in areas with recurrent grid congestion.
- n Increasing support for research to improve  electrolyser  efficiencies  and  to optimise and standardise designs for large-scale  electrolysers  to  bring  down electrolyser cost

<!-- image -->

<!-- image -->

## 3.2.   POLICY SUPPORT FOR HYDROGEN INFRASTRUCTURE

Vast  renewable  resources  are  available  to  be  exploited  to produce  green  hydrogen.  A  large  share  of  the  potential, however, such as that of solar PV, is found in deserts at great distances from where the hydrogen could be used. Even when electrolysers  are  located  closer  to  demand,  the  hydrogen may still  need to be transported. As a result, various forms of infrastructure will be needed to store and transport green hydrogen and hydrogen-based synthetic fuels.

Hydrogen  can  be  transported  by  truck,  ship  or  pipeline. Hydrogen has a low energy content by volume in the gaseous state (three times less than methane for example), but, once pressurized, it can be transported through pipelines with the same energy flow as natural gas. To ship hydrogen, it can be liquified or converted to ammonia or liquid organic hydrogen carriers  (LOHC),  for  greater  energy  content  by  volume. Those  conversions  require  additional  energy  consumption for liquefaction and continuous cooling.

As for storage, hydrogen can be stored in steel tanks or in underground geological formations. While not all countries have suitable underground formations, the overall available capacity is vast. For example, the potential hydrogen storage capacity in Europe is about 2 500 Mt, or 82.8 petawatt hours (Caglayan et al. ,  2019). Moreover, when hydrogen is converted to  LOHCs,  green  methanol  or  synthetic  hydrocarbons,  the fuels  can  be  stored  and  transported  using  existing  tanks, pipelines and other infrastructure.

The use of existing natural gas infrastructure for the transport and  storage  of  green  hydrogen  would  lower  the  overall cost of the transition, both in terms of reduced investment in  hydrogen  infrastructure  and  avoided  investment  in  the expansion of the electricity grid. In fact, in the early stages of the energy transition, green hydrogen could be blended at low shares with natural gas in existing pipelines and uses. As green hydrogen production and use increases, however, new infrastructure will be needed.

<!-- image -->

<!-- image -->

## Barriers

Challenges in transporting and storing hydrogen  will continue  to  evolve  as  the  production  of  green  hydrogen expands.

In  early  stages,  the  possibility  could  exist  to  blend  most of the hydrogen produced into existing natural gas infrastructure or use it on-site or close by. Even these uses come with challenges and costs, however. While some parts of the gas grids can deal with high shares of hydrogen, many pipelines  can  handle  only  limited  percentages.  Similarly, many  downstream  gas  applications, such as turbines, cannot  handle  high  shares  of  hydrogen,  and  a  pipeline  fit for hydrogen would still be useless if end uses are not ready. Similarly, countries currently have different blending limits, for example, which hinders transport across borders.

Later  stages  would  require  the  widespread  conversion  of gas networks, appliances and industrial users to hydrogen. Germany  is  already  planning  to  convert  5 900  km  of  its natural gas pipelines to hydrogen (around 15% of the total national network), with the first 1 200 km to be completed by 2030 (DW, 2020). Such conversion requires investment in new compression stations and pressure regulators.

In  addition,  new  hydrogen  pipelines  might  still  be  needed to connect the hydrogen production centres to the demand  centres.  When  renewable  resources  are  located at  great  distances  from  the  demand  centres,  it  might  be preferable  to  turn  the  green  hydrogen  into  ammonia  on the  spot  and  then  transport  the  ammonia,  rather  than the  hydrogen.  To  achieve  that,  facilities  will  be  needed  to convert  hydrogen  to  ammonia  and  other  energy  carriers and fuels.

<!-- image -->

## Policy recommendations

Realising  the  potential of green  hydrogen will  require  careful  policy  attention  to  meet the challenges of transport and storage. It is important  to  begin  now  to  plan  the infrastructure  of  the  future;  similar  to  the planning  of  the  power  grid,  the  effects  of such planning will be seen decades from now. Policy makers should consider:

- n Kicking  off  international  collaboration on global trading of hydrogen. Importing hydrogen from regions with low-cost renewables might be attractive  for  some countries. There is currently limited infrastructure  for  this  and  it  is  not  yet  clear how to best transport hydrogen over long distances.  Agreements  and  co-operation are  needed  in  the  short  term  to  start piloting  routes  and  carriers  to  make  sure a  global  supply  chain  is  established  over time.

## n

- Aligning standards and blending targets. Gas  composition,  and  hydrogen  content in particular, needs  to be harmonised among neighbouring countries to facilitate trading across borders. It will be necessary to  create  international  standards  for  the operation  and  design  of  ships  and  other facilities needed to transport green hydrogen  and  related  products.  Those standards should include sustainability criteria, operational safety standards, pipeline integrity requirements, fuel specifications and appliance compatibility standards.  If  blending  targets  are  being considered, aligning them across countries will facilitate trading.
- n Financing  infrastructure  development. To achieve significant expansion, the capital needs might be beyond the capabilities of the operator, and additional funds from public and private capital sources  may  be  needed.  Policies  should be put in place to facilitate capital flows for this network expansion and repurposing.
- n Identifying priorities for conversion programmes. The hydrogen blending limit is defined by the least tolerant elements in a  gas  network.  Some  end  uses  are  more sensitive  to  low  levels  of  blending.  These need  to  be  surveyed  to  determine  the extent of potential pipeline conversion programmes,  which  could  also  promote the use of hydrogen-ready equipment.

<!-- image -->

<!-- image -->

<!-- image -->

## 3.3. POLICY SUPPORT FOR HYDROGEN IN

## INDUSTRIAL APPLICATIONS

Converting to green hydrogen can significantly reduce  carbon  emissions  from  the  industrial sector, which is currently responsible for about  one-quarter  of  all  energy-related  CO 2 emissions  (or  8.4  GtCO /yr).  Four  industries 2 in particular -iron and steel, chemicals and  petrochemicals,  cement  and  lime,  and aluminium -account for around threequarters of total industrial emissions (IRENA, 2020b).

Grey hydrogen is currently used as a feedstock to  produce  methanol  and  ammonia.  Green hydrogen could replace much  of it with no changes in equipment or technology, eliminating the emissions associated with the production of grey hydrogen.

Over 70% of global steel is produced via the blast furnace/basic oxygen furnace (BF-BOF) route,  which  relies  mostly  on  coal.  Most  of the  remaining  steel  is  produced  from  direct reduction  of  iron  (DRI)  or  steel  scrap  in  an electric  arc  furnace  (EAF),  with  fossil  fuels providing both the reducing agent and energy for  DRI  and  the  electricity  for  the  furnace.  A structural  shift  in  iron  and  steel  making  is needed, with renewables displacing fossil fuels  for  both  energy  and  reducing  agents. One option  is  to  apply  alternative  processes that  can  use  renewable  energy  and  green hydrogen (IRENA, 2020b).

<!-- image -->

<!-- image -->

<!-- image -->

## Barriers

The  principal  barriers  to  the  greater  use  of green  hydrogen  in  industry  are  high  costs, investors'  confidence,  competitiveness  and  a lack of policy focus

The cost differential between hydrogen-based and fossil fuel-based processes will vary by  location  and  application.  But  at  present the use  of green  hydrogen  is  significantly more  expensive  than  fossil fuels, unless a carbon  price  or  other  adjustment  is  applied. Green  ammonia  (ammonia  made  from  green hydrogen) is two or three times more expensive than grey ammonia, and green methanol is three  to  four  times  more  expensive  than grey methanol. Hydrogen-based industrial processes, moreover, are not yet fully proven at scale. Investors making large capital investment decisions typically lack sufficient information to fully assess the risks associated with investing in green hydrogen activities.

Commodities  such  as  steel  and  chemicals are  traded  globally  and  are  often  important components of national trade policies. The  competitiveness  of  national  industries is therefore a major concern for both governments  and  companies.  If  some,  but not  all,  countries  impose  emission  limits  on industrial processes, thus raising costs in those  countries,  industrial production  may shift to areas without the same rules, reducing production costs but causing GHG emissions to increase (this phenomenon is also known as 'carbon  leakage').  Industrial  energy  policies tend  to  focus  on  energy  efficiency.  While improved energy efficiency is needed, policy makers should move their focus onto the fuel shift  that  is  required  for  the  uptake  of  green hydrogen - a policy that is often missing.

<!-- image -->

## Policy recommendations

To  overcome  these  barriers,  policy  makers  must  adopt measures to close the cost gap between current industrial processes  and  the  use  of  green  hydrogen,  encourage markets  for  green  hydrogen  and  address  problems  like carbon leakage. Such policies include:

- n Adapting  industrial  policy  for  green  hydrogen. The adaptation includes two steps. First, making sure there are  policies  that  promote  fuel  shifts  and  do  not  just focus on marginal improvements, which are not enough to  achieve  net-zero  emissions  on  their  own.  This  could be  done,  for  instance,  by  setting  ambitious  long-term targets for GHG emission reductions by type of industry that cannot be achieved by energy efficiency alone, and including green hydrogen in the supported technologies. Governments might also combine decreasing CO2 emission targets with a carbon trading scheme, allowing companies  that  cut  emissions  below  the  target  to  sell the  surplus  to  companies  with  higher  emissions.  For example,  Canada's  output-based  pricing  system  sets targets  of  80-95%  GHG  emission  reductions  for  the steel, chemical and refinery industries. Facilities that are below the thresholds are given surplus credits that can be traded (Turcotte, Gorski and Riehl, 2019).
- n Planning  to  phase  out  high-emission  technologies. Governments can develop strategies to transition industries  in  stages.  The  steel  industry  could  begin reducing emissions by using an increasing share of green hydrogen  in  existing  blast  furnaces,  but  then  switch to fluidised bed furnaces to enable that share to reach 100%.
- n Providing  loans,  grants  or  dedicated  funds. These measures  are  needed  to  make  investment  in  green pathways  more  financially  attractive.  For  example,  the Energy  and  Climate  Fund  in  Germany  has  allocated EUR  45  million  to  help  decarbonise  the  steel,  cement and  chemical  industries,  and  Germany's  2020  budget includes EUR 445 million specifically to support greater industrial use of green hydrogen by 2024 (BMU, 2020; BMWi,  2020). In Sweden  the HYBRIT  project has benefited from a contribution from the government to build a pilot green hydrogen steel plant (HYBRIT, 2020).
- n Recognising  the  value  of green  products. Policy makers should recognise the higher social value of these products and reward them accordingly. Available policy tools for the early stages include price premiums, feedin-tariffs  or  carbon  contracts  for  difference  in  price, which  can  guarantee  investors  a  higher  price  for  CO 2 emission reductions than the prevailing price in current CO2 trading schemes.
- n Kickstarting markets for low-carbon products. Governments could, through public procurement, preferentially buy steel or other products made sustainably  through  the  use  of  green  hydrogen,  or require  a  higher  share  of  those  products  in  the  overall material mix.
- n Addressing carbon leakage. Policies to support green hydrogen should go in tandem with policies to address carbon leakage that take into account fair international competition,  ease  of  implementation  and  the  risk  of windfall profits, while still providing demand-side abatement incentives ( e.g. material efficiency and replacement). Possible policies include cross-border adjustments  or  tax  rebates  to  reduce  or  eliminate  the competitive advantages of industrial facilities that have lower production costs and higher emissions than 'greener' facilities.

<!-- image -->

<!-- image -->

## 3.4. POLICY SUPPORT FOR SYNTHETIC FUELS IN AVIATION

Aviation accounts for 2.5% of global energyrelated  emissions.  It  is  dependent  on  high energy  density  fuels  due  to  the  mass  and volume limitations of aircraft.

Synthetic jet fuels produced from green hydrogen  could  play  a  role  as  drop-in  fuels, complementing  biojet  fuels  in  decarbonising the aviation sector (IRENA, 2020b). Synthetic jet  fuels  are  produced  from  hydrogen  and  a source  of  carbon  (usually  in  the  form  of  CO or CO2) and are hydrocarbons with the same physical  properties  of  refined  products  from fossil fuels.

The  amount  of  synthetic  fuel  needed  for aviation  (and  thus  the  overall  cost  of  the energy transition of the aviation sector) could be  reduced  further  through  greater  aircraft energy  efficiency,  lower  demand  for  longdistance travel ( e.g. through shifts to trains or reduced air travel, wider use of teleworking and teleconferencing), and direct electrification of short-haul flights. Electric propulsion could be feasible for small planes and short-haul flights. The direct use of hydrogen in airplanes is also under consideration.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Barriers

Synthetic fuels for aircrafts are very expensive, currently  up  to  eight  times  more  expensive than  fossil jet fuel. The  cost  components include electricity costs, the cost of electrolysers and synthesis plants, operational costs  and  the  costs  to  procure  the  carbon needed.  At  the  time  of  writing  there  is  no market that values the sustainable low-carbon character  of  molecules  that  are  otherwise indistinguishable  from  fossil-derived  ones.  In addition,  the  sustainability  of  synthetic  fuels depends  on  the  source  of  the  carbon  used (CO and CO2captured from emission streams, biogenic  sources  or  directly  from  the  air), which could increase costs.

Most countries have mitigation targets for the transport sector as a whole. This might focus efforts on other modes of transport, delaying the preparation for mitigating emissions from aviation.  Moreover,  targets  focus  mostly  on biofuels, missing the opportunity to promote the use of synthetic fuels, which would widen the technology portfolio and potentially decrease costs in the long term.

<!-- image -->

<!-- image -->

## Policy recommendations

To take advantage of the opportunity to cut emissions from aviation using synthetic fuels, policy makers can consider:

- n Setting explicit targets for reducing emissions  in  aviation. Renewable  fuels for  aviation  should  be  explicitly  counted towards meeting transport sector decarbonisation  targets.  They  could  also be  given  extra weight  to  reflect their higher costs and give them a slight priority, as in the EU REDII, which has a multiplier of 1.2  for  renewable  fuels  used  for  shipping and aviation when calculating performance against the targets (European Parliament, 2018).
- n Providing financial incentives to reduce the  cost  gap  between  fossil  fuels  and synthetic fuels. Possible strategies include eliminating subsidies for fossil fuels, providing  grants  for  investing  in synthetic  fuel  production  and  expanding existing emissions trading systems, such as the EU ETS, to cover aviation. The policies should be aimed at creating a market that values the emission reductions from using synthetic  fuels.  Even  in  the  long  term, however,  synthetic  fuels  might  not  reach cost  parity  with  fossil  fuels,  so  blending mandates  could  be  a  practical  interim option.
- n Focusing more on synthetic fuels. Efforts to reduce CO2 emissions have focused so far  on  energy  efficiency  (which  delivers lower  fuel  consumption,  lower  fuel  costs and higher profits), and on biofuels. Sustainable  aviation  fuels,  as  a  concept, include both biofuels and synthetic fuels. Policies should aim to promote both energy carriers.
- n Guaranteeing a sustainable carbon source. The environmental impact of synthetic  fuels  is defined  by  both  the electricity  and  CO   source.  CO   sources 2 2 that are compatible with a net-zero emissions system, namely biogenic or directly  captured  from  the  air,  should  be promoted.  Ensuring  that  synthetic  fuels are environmentally sustainable requires a certification system for both the hydrogen and the CO2 used in the production process.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 3.5. POLICY SUPPORT FOR HYDROGEN USE IN MARITIME SHIPPING

Maritime shipping is already the most efficient form  of  freight  transport;  it  uses  30%  less energy for a given weight and distance than rail  transport  and  90%  less  than  heavy-duty trucks. But the 95 000 ships currently in use, which carry 80-90% of all global trade, emit substantial  amounts  of  CO 2 -930  MtCO2 in  2015,  equivalent  to  2.8%  of  total  global energy-related emissions. With heavy fuel oil providing more than three-quarters of the fuel used by ships, ships are also major emitters of sulphur,  particulates  and  other  air  pollutants (IRENA, 2020b).

Around  20%  of  the  global  shipping  fleet  is responsible for 85% of the net GHG emissions associated with the shipping sector. Therefore, a limited number of interventions might have a large impact in decarbonising the shipping sector.  Electrification  via  batteries  or  fuel cells  could  play  an  important role for shortdistance vessels. Biofuels are an immediately available option to decarbonise the shipping sector,  either  in  blends  or  as  drop-in  fuels. However,  their  potential  is  currently  limited (IRENA, 2020b).

Green hydrogen could play an important role, but  its adoption  would  require  substantial adaptations to existing onboard and onshore infrastructure. In addition, green  ammonia is  emerging as one of the most feasible lowcarbon fuel pathways. Leading manufacturers are working  on  engines  that  can  run  on ammonia and are anticipated in 2024.

<!-- image -->

<!-- image -->

## Barriers

As in other sectors, higher costs are a barrier. A recent study indicates that at least  USD  1  trillion  in  investment  is  needed to  decarbonise  international  shipping,  using green ammonia as the main fuel (Raucci et al. , 2020). Beyond costs, there also are technical and practical barriers. For the same amount of energy, ships would need fuel tanks three to four times larger than existing tanks in order to  use  ammonia,  and  40%  larger  for  liquid hydrogen. Larger tanks would cut into cargo space,  reducing  the  amount  of  cargo  that could be carried by ships by about 10-15% in typical bulk carriers.

In addition, ammonia is caustic and corrosive, and thus requires special fuel handling, while liquefying hydrogen requires considerable additional energy. These  fuels would  also require a new bunkering infrastructure.

<!-- image -->

## 3.5.2. Policy recommendations

Many of the policies already described in this report to reduce the cost gap between fossil fuels and green hydrogen and its related fuels will also help make these green synthetic fuels more economically viable for use in ships, from carbon taxes to economies of scale that bring down  the  price  of  renewable  electricity  and ammonia plants.

Beyond those general policies, there are specific steps that governments can take to accelerate the decarbonisation  of maritime shipping. While these policies can  be  implemented  either  domestically  or internationally, they  will have  the  greatest impact at the international level. Policy makers should consider:

- n Implementing  fiscal  incentives. Taxes based on the tonnage of cargo could be set lower for cargos carried by ships that have  lower  GHG  emissions,  as  Norway and Portugal have done. In addition, 28  of  the  100  largest  ports  in  the  world charge port fees that vary depending on ships' environmental  impacts,  with  five of  them  including  GHG  emissions  among those impacts (ITF, 2019). Other possible policy  instruments  could  be  charging  all ships  a  fixed  levy  based  on  their  fossil fuel consumption, or adding shipping to emissions trading systems, as the European Union will do in 2022 (Reuters, 2020). Such  financial incentives would help  close  the  cost  gap  between  fossil fuels and green alternatives.
- n Creating  demand  for  green  maritime fuels. Governments  can  set  targets  for a required number of zero-emission vessels, for example. Or they could mandate  increasing levels of synthetic fuels to be blended  into current ship fuels, or ambitious levels of market-based measures.

## n Support infrastructure development.

- Making supplies of green hydrogen, ammonia  or  methanol  available  at  just a  few  ports  around  the  world  would  be enough to bring large reductions in global emissions,  since  just  seven  countries  are currently  responsible  for  nearly  60%  of global bunker fuel sales (the largest being Singapore, the United States and the United  Arab  Emirates)  (IRENA,  2019c). That could simplify the logistics and lower the costs of making alternative fuels available. Ports would need to be adapted to deliver hydrogen or ammonia.
- n Support international policy and regulations. If only one or a few countries enact policies to limit maritime emissions, then much of the shipping business would simply move to other countries. As a result, coordinated  action  by  many  countries  is needed to cut emissions from international shipping. In addition, an international regulatory framework for these alternative fuels  needs  to  be  put  in  place.  It  should include  GOs  and  accurate  measurements of GHG emissions for the fuels.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 4

Maturity of relevant technology

## CONCLUSIONS

<!-- image -->

National pledges to achieve net-zero emissions

Broader use of hydrogen

Power system flexibility benefits

Low renewable energy cost

Extensive base of interested stakeholders

Global interest is rising in green hydrogen as one of the solutions for an energy transition toward zero or net-zero emissions. There have been several waves of interest in hydrogen in the past. However, this new wave places a broader focus on creating a link between renewable electricity and hardto-electrify end uses. Its drivers include: low renewable electricity costs, the maturity of relevant technology, power system flexibility benefits, national pledges to achieve net-zero emissions, and a more extensive base of interested stakeholders.

Indeed,  the  last  two  years  have  witnessed increased  momentum  for  green  hydrogen, with many countries around the world implementing national hydrogen strategies or announcing their intentions to do so. Measures to  support  green  hydrogen  have  even  been included in post-COVID-19 recovery packages. Although interest in green hydrogen is reaching unprecedented levels, several barriers are still impeding its full contribution to the energy transition. The primary obstacle is the high cost of green hydrogen compared to grey  hydrogen  and  fossil  fuel  sources. Other  barriers  include  the  lack  of  dedicated infrastructure,  the  lack  of  value  recognition for reduced GHG emissions, and other barriers related  to  the  development  of  an  emerging industry.

While the hydrogen sector has received attention from governments, more dedicated policy support is needed to ensure technology readiness, market  penetration  and  market growth. IRENA  has identified four pillars for  green  hydrogen  policy  making:  national hydrogen strategies, policy priorities for green hydrogen,  guarantee  of  origin  systems,  and enabling policies.

National hydrogen strategies define a country's level of ambition for hydrogen and outline the amount of  support  required  to  achieve  such ambition. They serve as a reference for private actors  in  the  hydrogen  industry,  helping  to encourage increased levels of financing. Effective  national  strategies  should  lay  out  a clear pathway to increasing hydrogen uptake.

A  wide  range  of  end  uses  can  utilise  green hydrogen.  To  avoid  diluting  efforts,  national policy makers should identify the applications that provide the highest value and prioritise  action  towards  them.  By  doing  so, governments  can  ensure  their  policy  efforts provide  more  immediate  benefits,  creating higher demand for green hydrogen.

Guarantee of origin schemes should be based on  lifecycle  GHG  emissions.  They  should  be designed  to  allow  policy  makers  and  end users to understand the impact of this energy carrier,  ensure  consistency  and  compatibility with  GHG  emissions  for  other  commodities, and allow comparison with other energy sources.

Enabling  policies  are  economy-wide  policies that can help to level the playing field between hydrogen and fossil fuels. These policies should be applied to allow hydrogen actors to provide value to the entire energy system, and to broader economic and social systems.

This guide  lays  out  key  recommendations to accelerate the proliferation of green hydrogen.  A  series of sectoral briefs will follow  this  publication.  The  first  brief  will  be dedicated to the supply side (electrolysis and infrastructure), followed by briefs focusing on the hard-to-abate sectors (industry and longhaul  transport).  These  briefs  aim  to  guide policy makers in designing and implementing policies to support green hydrogen. They  will  analyse  the  status  of  associated technologies,  outline  sector-specific  barriers and costs, and provide a wide range of policy recommendations  according  to  the  stage  of implementation.

<!-- image -->

## REFERENCES

## AFC TCP (Advanced Fuel Cells Technology Collaboration

Programme) (2020) , Energy Technology Perspectives 2020 , International Energy Agency, Paris, www.iea.org/reports/energytechnology-perspectives-2020.

Behling, N., M. Williams and S. Managi (2015) , 'Fuel cells and the hydrogen revolution: Analysis of a strategic plan in Japan', Economic Analysis and Policy , Vol. 48, pp. 204-221, www.doi. org/10.1016/j.eap.2015.10.002.

BMU (2020) , Neues Förderfenster im Umwelt  innovations  programm , https://www.bmu.de/pressemitteilung/bundesumweltministeriumfoerdert-projekte-zur-dekarbonisierung-der-industrie/.

BMWi (2020) , Bundeshaushalt 2020, Einzelplan 09: Bundesministerium für Wirtschaft und Energie , https://www.bmwi. de/Redaktion/DE/Artikel/Ministerium/haushalt-2020.html.

BNEF (Bloomberg New Energy Finance) (2020) , Hydrogen Economy Outlook , Bloomberg New Energy Finance.

BNEF (2019) , Renewable Energy Auctions Database , Bloomberg New Energy Finance. (Needs subscription).

Caglayan D. et al. (2019) , "Technical potential of salt caverns for hydrogen storage in Europe", International Journal of Hydrogen Energy, Vol. 45, pp. 6793-6805, https://doi.org/ 10.1016/j.ijhydene.2019.12.161.

CE Delft (2018) , Werk door groene waterstof [Work in Green Hydorgen], https://www.ce.nl/publicaties/2202/werk-doorgroene-waterstof.

COAG (Council of Australian Governments) (2019) , Australia's National Hydrogen Strategy , COAG Energy Council, www. industry.gov.au/sites/default/files/2019-11/australias-nationalhydrogen-strategy.pdf.

DW (Deutsche Welle) (2020) , 'Germany and hydrogen - €9 billion to spend as strategy is revealed', Deutsche Welle, https://www.dw.com/ en/germany-and-hydrogen-9-billion-to-spend-as-strategy-isrevealed/a-53719746

Eichman, J., K. Harrison and M. Peters (2014) , Novel Electrolyzer Applications: Providing More Than Just Hydrogen , National Renewable Energy Laboratory, www.nrel.gov/docs/fy14osti/61758.pdf.

Element Energy (2020) , 'Gigastack: Bulk Supply of Renewable Hydrogen - Public Report', Gigastack, (January), https://www. itm-power.com/news-item/new-factory-update-and-seniorproduction-appointment.

European Commission (2020) , COM (2020) 301 A Hydrogen Strategy for a Climate-Neutral Europe , European Commission, www.ec.europa.eu/energy/sites/ener/files/hydrogen\_strategy.pdf.

European Commission (2003) , Hydrogen Energy and Fuel Cells - A Vision of Our Future, European Commission, www.fch.europa. eu/sites/default/files/documents/hlg\_vision\_report\_en.pdf.

European Parliament (2018) , Directive (EU) 2018/2001 of the European parliament and of the council of 11 December 2018 on the promotion of the use of energy from renewable sources (recast).

FCH JU (Fuel Cells and Hydrogen Joint Undertaking) (2017)

,

Fuel Cell and Hydrogen Technology: Europe's Journey to a Greener World , Fuel Cells and Hydrogen Joint Undertaking, www.fch.europa.eu/sites/default/files/2017\_FCH%20Book\_ webVersion%20%28ID%202910546%29.pdf.

Government of the Netherlands (2020) , Government Strategy on hydrogen , https://www.government.nl/documents/ publications/2020/04/06/government-strategy-on-hydrogen.

H-Vision (2019) , Annexes to the H-vision Main Report , https:// www.deltalinqs.nl/h-vision-en.

HYBRIT (2020) , HYBRIT's next step receives support from Swedish Energy Agency , https://www.hybritdevelopment.com/ hybrits-next-step-receives-support-from-swedish-energy-agency.

Hydrogen Analysis Resource Center (2016) , Hydrogen Pipelines September 2016 , Hydrogen Tools, www.h2tools.org/sites/ default/files/imports/files//Hydrogen%2520Pipelines%2520 September%25202016.xlsx.

Hydrogen Council (2020) , Path to Hydrogen Competitiveness A Cost Perspective , Hydrogen Council, www.hydrogencouncil. com/wp-content/uploads/2020/01/Path-to-Hydrogen-Competitiveness\_Full-Study-1.pdf.

IEA (International Energy Agency) (2019) , The Future of Hydrogen , IEA, Paris.

Ikäheimo, J. et al. (2018) , 'Power-to-ammonia in future North European 100% renewable power and heat system', International Journal of Hydrogen Energy , Vol. 43, pp. 1729517308, www.sciencedirect.com/science/article/abs/pii/ S0360319918319931?via%3Dihub.

IPHE (International Partnership for Hydrogen and Fuel Cells in the Economy) (2020)

,

Terms of Reference: Hydrogen Production

, International Partnership for Hydrogen and

Analysis Task Force

Fuel Cells in the Economy.

## IRENA (International Renewable Energy Agency)

(forthcoming) , Green hydrogen cost reduction: Scaling up electrolysers to meet the 1.50C climate goal , International Renewable Energy Agency, Abu Dhabi.

IRENA (2020a) , Global Renewables Outlook: Energy Transformation 2050 (Edition: 2020), International Renewable Energy Agency, Abu Dhabi.

IRENA (2020b) , Reaching Zero With Renewables: Eliminating CO2 Emissions From Industry and Transport in Line With the 1.5°C Climate Goal , International Renewable Energy Agency, Abu Dhabi.

IRENA (2020c) , Power System Organisational Structures for the Renewable Energy Era , International Renewable Energy Agency, Abu Dhabi

IRENA (2019a) , Hydrogen: A Renewable Energy Perspective , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019b) , Renewable Energy Auctions: Status and Trends Beyond Price , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c) , Navigating the Way to a Renewable Future: Solutions to Decarbonise Shipping , International Renewable Energy Agency, Abu Dhabi.

IRENA (2018) , Hydrogen from Renewable Power Technology Outlook for The Energy Transition , International Renewable Energy Agency, Abu Dhabi.

IRENA, IEA and REN21 (Renewable Energy Policy Network for the 21st Century) (forthcoming) , Renewable Energy Policies in a Time of Transition: Heating and Cooling , IRENA, OECD/ IEA and REN21.

IRENA, IEA and REN21 (2018) , Renewable Energy Policies in a Time of Transition , IRENA, OECD/ IEA and REN21.

ITF (International Transport Forum) (2019) , 'Maritime Subsidies: Do They Provide Value for Money?', International Transport Forum Policy Papers, No. 70, OECD Publishing, Paris.

Jensterle, M. et al. (2019) , The Role of Clean Hydrogen in the Future Energy Systems of Japan and Germany , Adelphi.

Liu, Z. et al. (2020) , 'Near-real-time monitoring of global CO2 emissions reveals the effects of the COVID-19 pandemic', Nature Communications , www.nature.com/articles/s41467-020-18922-7.

Masdar (2019) , 'Dumat Al Jandal', Masdar website, 10 January, https://masdar.ae/en/masdar-clean-energy/projects/dumat-aljandal.

Mehmeti, A. et al. (2018) , 'Life cycle assessment and water footprint of hydrogen production methods: from conventional to emerging technologies', Environments, Vol. 5/2, p. 24, www.doi. org/10.3390/environments5020024.

MISE (2019) , Tavolo Idrogeno 2019 [Table on Hydrogen 2019], https://www.mise.gov.it/images/stories/documenti/Report\_ Tavolo\_Idrogeno.pdf.

Monolith (2020) , Monolith Materials Plans to Build Country's First Large Scale Carbon-Free Ammonia Plant , Monolith Materials, Nebraska, www.monolithmaterials.com/news/monolithmaterials-carbon-free-ammonia-plant.

Morais, L. (2020) , 'Portugal announces winners in 670-MW solar auction', Renewables Now, 8 September, www.renewablesnow. com/news/portugal-announces-winners-in-670-mw-solarauction-712816/.

NREL (National Renewable Energy Laboratory) (2020)

,

Gasoline Internal Combustion Engine Vehicle , NREL, www.atb. nrel.gov/transportation/2020/index.html?t=lg.

Philibert, C. (2020) , Methane Splitting and Turquoise Ammonia , Ammonia Energy Association, New York, www.ammoniaenergy. org/articles/methane-splitting-and-turquoise-ammonia/.

Quarton, C. et al. (2020) , The Curious Case of the Conflicting Roles of Hydrogen in Global Energy Scenarios , The Royal Society of Chemistry, www.pubs.rsc.org/en/content/articlepdf/2020/se/ c9se00833k.

Raucci, C. et al. (2020) , Aggregate investment for the decarbonisation of the shipping industry, https://www. globalmaritimeforum.org/content/2020/01/Aggregateinvestment-for-the-decarbonisation-of-the-shipping-industry.pdf.

Reiter, G. and J. Lindorfer (2015) , 'Global warming potential of hydrogen and methane production from renewable electricity via power-to-gas technology', The International Journal of Life Cycle Assessment , pp. 477-489, www.doi.org/10.1007/s11367-015-0848-0.

Reuters (2020) , 'EU lawmakers agree to include shipping emissions in EU carbon market', Reuters, https://www.reuters. com/article/us-climate-change-eu-shipping-idUSKBN2481UD.

Roland, B. (2018) , Fuel Cells and Hydrogen for Green Energy in European Cities and Regions , Fuel Cells and Hydrogen Joint Undertaking, www.fch.europa.eu/sites/default/files/181123\_ FCHJU\_Regions\_Cities\_Final\_Report\_FINAL.pdf.

RVO (2020) , Stimulation of sustainable energy production and climate transition (SDE++) , https://english.rvo.nl/subsidiesprogrammes/sde.

Shumkov, I. (2020) , 'Record low bid for 2-GW solar project shines in Abu Dhabi', Renewables Now, www.renewablesnow. com/news/record-low-bid-for-2-gw-solar-project-shines-in-abudhabi-696804/.

Staffell, L. et al. (2018) , The role of Hydrogen and Fuel Cells in the Global Energy System , The Royal Society of Chemistry, www. pubs.rsc.org/en/content/articlepdf/2019/ee/c8ee01157e.

Turcotte, I., Gorski, J. and Riehl, B. (2019) , 'Carbon Emissions: Who makes big polluters pay', The Pembina Institute , (November), p. 27.

US DOE (Department of Energy) (2017) , Fuel Cells SubProgram Overview , United States Hydrogen and Fuel Cells Program, www.hydrogen.energy.gov/pdfs/progress17/v\_0\_ papageorgopoulos\_2017.pdf.

US DOE (2002) , National Hydrogen Energy Roadmap , Department of Energy, www.hydrogen.energy.gov/pdfs/ national\_h2\_roadmap.pdf.

Velazquez Abad, A. and P. E. Dodds (2020) , 'Green hydrogen characterisation initiatives: Definitions, standards, guarantees of origin, and challenges', Energy Policy , Vol. 138, www.doi. org/10.1016/j.enpol.2020.111300.

Vermeulen U., (2017) , Turning a Hydrogen Economy into Reality , 28th Meeting Steering Committee IPHE, The Hague, 21 November 2017.

Veum, K. et al. (2019) , Roadmap for Building a Dual Hydrogen Certification Infrastructure for Guarantees of Origin and for Certification of Renewable Hydrogen in Transport , Fuel Cells and Hydrogen Joint Undertaking.

WEF (World Economic Forum) (2020) , Insight Report: The NetZero Challenge: Fast-Forward to Decisive Climate Action , World Economic Forum in collaboration with Boston Consulting Group, www3.weforum.org/docs/WEF\_The\_Net\_Zero\_Challenge.pdf.

## PHOTOGRAPHS

page 8:

Hydrogen storage tank; petrmalinak; shutterstock

page 8:

remotevfx.com; shutterstock

page 10:

Hydrogen Pilot Plant, Loy Yang, Victoria, Australia;

Dorothy Chiron; shutterstock

page 12:

First hydrogen train in the Netherlands, Groningen, Netherlands; Sander van der Werf; shutterstock

page 12:

hramovnick; shutterstock

page 12:

Strip steel production workshop; zhengzaishuru; shutterstock

page 12:

Hydrogen fuel tanks on display at the Washington Auto Show, Washington D.C., USA; Nicole Glass Photography; shutterstock

page 12:

Hydrogen Fuel cell bus; alexfan32; shutterstock

page 12:

BMW I Vision Hydrogen NEXT concept Prototype Car at IAA, fuel cell, Frankfurt, Germany; Grzegorz Czapski; shutterstock

page 13:

Hydrogen energy storage with renewable energy sources; petrmalinak; shutterstock

page 15:

Hydrogen plant refinery under construction; Sergio Bertino; shutterstock

page 15:

remotevfx.com; shutterstock

page 19:

Hydrogen fuel cell; luchschenF; shutterstock

page 21:

Hydrogen train, Groningen, Netherlands; Sander van der Werf; shutterstock

page 21:

Hydrogen train at the main train station in Groningen, Netherlands; Sander van der Werf; shutterstock

page 23:

diyanski; shutterstock

page 24:

Official seat of the European Parliament, Strasbourg, France; olrat; shutterstock

page 26:

Car sharing Driver fueling a hydrogen-powered car, Hamburg, Germany; Hadrian; shutterstock

page 26:

Hydrogen Energy Project Hastings, Victoria, Australia; Dorothy Chiron; shutterstock

page 28:

Marine fuel station for boats and yachts, Rovinj, Croatia; Fesus Robert; shutterstock

page 28:

eischilebt; shutterstock

page 28:

Wind farm in Germany; Stephan Langhans; shutterstock

page 32:

Alexander Kirch; shutterstock

page 33:

Hydrogen logo on gas stations fuel dispenser; Alexander Kirch; shutterstock

page 33:

Hydrocracking installation; diyanski; shutterstock

page 34:

Gas carrier in port; Wojciech Wrzesien; shutterstock

page 34:

Modern hydrogen car; Mr Doomits; shutterstock

page 36: Hydrogen fuel cell; luchschenF; shutterstock

page 37:

Hydrogen Pilot Plant, Loy Yang, Victoria, Australia; Dorothy Chiron; shutterstock

page 37:

Wind turbines; zhengzaishuru; shutterstock

page 38:

Natural gas pipeline construction work; Maksim Safaniuk; shutterstock

page 39: Mariestad, Sweden; Daniel E Beckman; shutterstock

page 39:

photocreo; envatoelements

page 40:

Electric arc furnace shop EAF; D.Alimkin; shutterstock

page 42:

Maxim Blinkov; shutterstock

page 42:

Refueling of aircraft; Standard store88; shutterstock

page 43:

aapsky; shutterstock

page 44:

Gdansk bay, Poland; Klara Bakalarova; shutterstock

page 45:

Freight Transportation; Aun Photographer; shutterstock

<!-- image -->

## ABBREVIATIONS

| ATR      | Autothermal reforming                                                |
|----------|----------------------------------------------------------------------|
| CCS      | Carbon capture and storage                                           |
| CCUS     | Carbon capture, use and storage                                      |
| CEM      | Clean Energy Ministerial                                             |
| CO 2     | Carbon dioxide                                                       |
| DRI      | Direct reduced iron                                                  |
| ETS      | Emissions trading system                                             |
| FCEV     | Fuel cell electric vehicle                                           |
| GO       | Guarantee of origin                                                  |
| H 2      | Hydrogen                                                             |
| IEA      | International Energy Agency                                          |
| IPHE     | International Partnership for Hydrogen and Fuel Cells in the Economy |
| IRENA    | International Renewable Energy Agency                                |
| LOHC     | Liquid organic hydrogen carriers                                     |
| MI       | Mission Innovation                                                   |
| NECP     | National energy and climate plan                                     |
| REACT-EU | Recovery Assistance for Cohesion and the Territories of Europe       |
| VRE      | Variable renewable energy                                            |

## UNITS OF MEASURE

| EJ   | Exajoule       |
|------|----------------|
| g    | Gram           |
| GJ   | Gigajoule      |
| Gt   | Gigatonne      |
| GW   | Gigawatt       |
| kg   | Kilogram       |
| km   | Kilometre      |
| kW   | Kilowatt       |
| kWh  | Kilowatt hour  |
| Mt   | Million tonnes |
| MW   | Megawatt       |
| MWh  | Megawatt hour  |
| t    | Tonne          |
| TWh  | Terawatt hour  |

<!-- image -->

## GREEN HYDROGEN

A GUIDE TO POLICY MAKING

www.irena.org

ISBN 978-92-9260-286-4