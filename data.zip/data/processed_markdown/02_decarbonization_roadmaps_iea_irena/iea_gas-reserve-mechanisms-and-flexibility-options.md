---
document_id: iea_gas-reserve-mechanisms-and-flexibility-options
title: "Iea Gas-Reserve-Mechanisms-And-Flexibility-Options"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_gas-reserve-mechanisms-and-flexibility-options.pdf"
tables_detected: 23
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Gas Reserve Mechanisms and Flexibility Options

Enhancing gas supply security in a changing global market

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 14 Association countries and beyond.

## IEA M ember countries:

This publication, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. International Energy Agency Website: www.iea.org

IEA Accession countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Chile Colombia Costa Rica Brazil Israel

Romania

## IEA A ssociation countries:

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Abstract

Two major gas supply crises in the last five years have fundamentally challenged long-held assumptions about gas supply security and exposed deep vulnerabilities in  an  increasingly  interconnected  but  geopolitically  more  complex  global  gas market.  This  evolving  landscape,  combined  with  reduced  supply  flexibility  and growing weather sensitivity, calls for stronger gas supply security frameworks built on closer international cooperation, new reserve mechanisms and greater market flexibility.

This report focuses on gas reserve mechanisms and flexibility options that can strengthen  gas  system  resilience  against  short-term  supply  disruptions. It identifies practical measures that gas-importing countries can implement over the next  five  years  to  reinforce  supply  security  through  a  combination  of  physical reserve assets, flexible commercial arrangements and policy-based mechanisms, complementing longer-term efforts to diversify supply sources and enhance gas infrastructure.

The report also explores how governments can advance international cooperation by strengthening coordination and dialogue, increasing transparency, enhancing market flexibility and jointly exploring new voluntary reserve mechanisms. The IEA stands ready to support these efforts.

## Acknowledgements

This report was prepared by the Gas and Coal Markets Division (GCM) of the International Energy Agency (IEA).

The  report  was  designed  and  directed  by  Akos  Losz.  The  lead  authors,  in alphabetical  order,  were  Akos  Losz,  Frederick  Ritter  and  Yutaka  Shirakawa. Earlier work by Gergely Molnar on the same topic greatly influenced and was incorporated into the current analysis.

Dennis Hesseling, Head of GCM, Keisuke Sadamori, former Director of the IEA's Energy Markets and Security (EMS) Directorate, and Brian Motherway, Acting Director of EMS provided strategic guidance and direction for the report.

Other IEA colleagues who provided valuable feedback, analysis or data for the report include Gergely Molnar, Carole Etienne, Carina Gwennap, Yu Kawasaki, Mizuno  Tetsuya,  Joel  Couse,  David  Martin,  Jason  Elliot,  Ronan  Graham, Jeseung Choi, Tim Gould, Peter Zeniewski, Tomoya Iwaki, Deniz Ugur, Giulio Santi, Ryo Yamasaki and Philippe Rose.

Peer  reviewers  provided  essential  feedback  that  improved  the  quality  of  the work. They include Ana Stanic (E&amp;A Law), Anne-Sophie Corbeau (Center on Global Energy Policy, Columbia University), Boaz Moselle (Compass Lexecon), Carole  Le  Henaff  (Storengy),  Harry  Whitaker  (Shell),  Hendrik  Diers  (EWI, University  of  Cologne),  Hitoshi  Nishizawa  (JERA),  Jonathan  Stern  (Oxford Institute  for  Energy  Studies),  Laurent  David  (GIIGNL),  Luis  Agosti  (Compass Lexecon), Margaret Skwara (Natural Resources Canada), Maria Teresa Nonay Domingo  (Enagas),  Melanie  Sawaryn  (BP),  Michael  Stoppard (Stoppard Energy), Mike Fulwood (Oxford Institute for Energy Studies), Patricia Roberts (LNG  Insights  Ltd),  Ricardo  Fernandez  (ACER)  and  Thomas  Curry  (US Department of Energy).

Several other experts provided valuable input through workshop discussions, consultations  and  responses  to  specific  inquiries  during  the  drafting  process. They include Aaron Koh (Energy Market Authority, Singapore), Andrew Walker (Cheniere  Energy),  Emiko  Nakamura  (Mitsui  O.S.K.  Lines),  Frederic  Millet (Storengy), Jefferson Clarke (Poten &amp; Partners), Maciej Ciszewski (European Commission), Mathieu Brovelli (TotalEnergies), Takuya Tanabe (JERA Global Markets) and Tiak Boon Goh (Singapore GasCo).

The  IEA  Communications  and  Digital  Office  (CDO)  provided  support  in producing, launching and promoting the report. Particular thanks go to Jethro Mullen,  Astrid  Dumond,  Liv  Gaunt,  Isabelle  Nonain-Semelin,  Poeli  Bojorquez and Irina Paun.

Jenny  Vaughan  edited  the  report.  Sydnie  McCormick  provided  essential administrative support.

This report was made possible thanks to generous support from Japan's Ministry of Economy, Trade and Industry (METI).

The  individuals  and  organisations  that  contributed  to  this  report  are  not responsible for its contents. Any errors or omissions are the sole responsibility of the IEA.

## Table of contents

| Executive summary................................................................................................................7       |
|------------------------------------------------------------------------------------------------------------------------------------------|
| 1. Introduction.......................................................................................................................10 |
| 2. A gas market in transition................................................................................................12          |
| 2.1 Lessons from the 2022-2023 energy crisis....................................................................12                       |
| 2.2 The post-crisis gas market environment........................................................................13                     |
| 3. Flexibility options along gas and LNG value chains ..................................................... 19                           |
| 4. Physical gas reserves ...................................................................................................... 21       |
| 4.1 Underground gas storage..............................................................................................25              |
| 4.2 LNG tank storage .......................................................................................................... 31       |
| 4.3 LNG FSRU and FSU facilities .......................................................................................                  |
| 4.4 LNG floating storage on vessels....................................................................................40                |
| 5. Flexible commercial options for LNG.............................................................................45                    |
| 5.1 Existing LNG contracts..................................................................................................47           |
| 5.2 New LNG contracts ....................................................................................................... 53         |
| 5.3 Commercial innovation..................................................................................................59            |
| 5.4 LNG swaps....................................................................................................................67      |
| 6. Policy tools to create gas reserve mechanisms............................................................69                           |
| 6.1 Mandatory storage obligations ...................................................................................... 71              |
| 6.2 Strategic underground gas storage ............................................................................... 74                 |
| 6.3 Strategic cushion gas reserves ..................................................................................... 79              |
| 6.4 Buffer LNG schemes.....................................................................................................82            |
| 7. Options to increase international cooperation .............................................................. 90                       |
| 7.1 Lessons from the IEA oil emergency response framework ........................................... 90                                 |
| ........................................................................................................ 94                              |
| 7.2 Recommendations                                                                                                                      |

## Executive summary

Over the past five years, global gas markets have experienced two major energy crises  that  fundamentally  challenged  long-held  assumptions  about  gas  supply security and resilience. The 2022-2023 energy crisis following Russian Federation's full-scale invasion of Ukraine and the closure of the Strait of Hormuz during  the  2026  Middle  East  conflict  demonstrated  that  events  previously considered  extreme  can  materialise  with  significant  consequences  for  importdependent economies in both Europe and Asia.

The crises highlighted that well-functioning gas markets remain the first and most important line of defence against supply disruptions. Price signals, commercial incentives, and the international reallocation of liquefied natural gas (LNG) allowed supplies to move towards regions with the greatest need (and willingness to pay), helping to mitigate what could have been more severe and widespread physical shortages.  Market  flexibility  therefore  remains  an  essential  component  of  gas security.

At the same time, recent experience also showed that market-based reallocation alone may not always be sufficient during periods of acute stress. When global gas  supply  is  exceptionally  tight,  competition  for  available  cargoes  can  trigger extreme  price  volatility,  amplify  economic  impacts  and,  in  some  cases,  fail  to prevent physical shortages. These risks highlight the importance of maintaining physical  reserves,  emergency  response  arrangements,  and  coordinated  policy measures that can help bridge  the  most  acute  phase  of  a  crisis  until  markets rebalance.

Long-term supply security ultimately depends on adequate investment across the gas value chain, diversified supply sources, robust infrastructure, and appropriate contracting arrangements. These structural elements create the supply base upon which secure gas systems ultimately depend, but they are not the focus of this report.  Instead,  we  focus  on  a  complementary  set  of  measures  that  importing countries  -  and,  where  appropriate,  groups  of  importers  and  exporters  -  can implement in the medium term to strengthen resilience against short-term market shocks.  Many  of  these  measures  build  on  existing  infrastructure,  commercial arrangements, and market structures, allowing resilience to be enhanced without requiring major new physical investments.

Making gas markets more resilient does, however, come at a cost. Maintaining strategic reserves, securing commercial flexibility, and preserving unused capacity all involve premiums that are ultimately borne by consumers, taxpayers, or market participants. Yet recent crises have demonstrated that the economic and social costs of being underprepared may be substantially higher than failing to invest in

resilience measures. As with other forms of insurance, such investments involve upfront  costs  that  can  provide  significant  value  when  highly  disruptive  events occur.  Understanding  the  costs,  benefits,  trade-offs,  and  potential  unintended consequences of these measures is therefore essential to designing efficient and appropriate supply security frameworks.

There is no one-size-fits-all model for strengthening gas security; countries differ considerably  in  their  resource  endowment,  infrastructure,  geography,  import dependence,  market  design,  and  regulatory  frameworks.  As  such,  the  most appropriate mix of physical reserve mechanisms, commercial flexibility, and policy tools will vary according to national market conditions, risk profile, and security objectives. Many of the concepts presented in the report warrant further technical analysis, economic assessment, and international dialogue to better understand their  costs,  benefits,  trade-offs,  and  implementation  challenges.  By  identifying practical options to strengthen short- to medium-term resilience, this report aims to catalyse continued discussion and cooperation among governments, industry, and international organisations. Its main findings are summarised below.

##  The global gas market has become structurally and geopolitically more complex.

The global gas market has become structurally more complex since the 20222023  energy  crisis.  This  growing  complexity  reflects  increased  geopolitical risks,  trade fragmentation, and greater weather sensitivity of gas flows and demand. In addition, supply flexibility has been reduced because of decreased pipeline import optionality in Europe. As a result, future supply disruptions and price volatility remain significant risks, despite expectations of stronger LNG supply in the coming years. This increasingly complex environment calls for stronger gas supply security frameworks built on closer international cooperation,  new  reserve  mechanisms,  and  greater  market  flexibility.  The expected easing of market conditions later this decade may provide a valuable opportunity for governments to strengthen resilience, build strategic buffers, and deepen international cooperation before the next major disruption occurs.

##  Physical reserves are essential but are not sufficient.

Physical  gas  reserves  remain  a  cornerstone  of  gas  security,  but  existing storage assets alone cannot fully address future supply risks. While underground gas storage (UGS), LNG tanks, and floating storage assets offer opportunities  to  strengthen  resilience,  their  effectiveness  is  constrained  by geography,  infrastructure,  commercial  incentives,  and  technical  limitations. Developing new storage infrastructure requires significant investment and long lead  times.  Therefore,  physical  reserves  need  to  be  complemented  by commercial flexibility enhancements and policy-based mechanisms to strengthen overall system resilience.

##  Commercial flexibility can be further strengthened.

Commercial flexibility is a critical complement to physical reserves because it enables  available  LNG  to  move  more  efficiently  during  market  disruptions. Increasing  contractual  flexibility,  encouraging  commercial  innovation,  and facilitating  greater  use  of  LNG  swaps  could  strengthen  market  flexibility, improve the allocation of  available  supply,  enhance  system  resilience,  and help moderate price volatility without requiring new physical infrastructure.

-  Policy-based reserve mechanisms  should  be  tailored to national circumstances while offering significant scope for cross-border schemes and knowledge sharing.

Policy-based reserve mechanisms should be tailored to national circumstances rather than follow a single model. Options such as mandatory storage obligations, strategic reserves, and buffer LNG schemes each offer distinct advantages but also involve different costs, governance arrangements, and operational trade-offs. Beyond domestic policies, there is considerable scope to strengthen gas security through cross-border reserve arrangements,  shared  infrastructure,  coordinated  emergency  planning,  and greater knowledge sharing. Combining national measures with regional and international cooperation can improve resilience while making more efficient use of existing assets.

##  Closer  international  cooperation  is  essential  for  strengthening  gas security.

International cooperation, as a complement to national measures, is essential to strengthening gas security in an increasingly interconnected but geopolitically  complex  market  environment.  While  not  directly  applicable  to gas, the International Energy  Agency's  (IEA)  oil emergency  response framework  provides  valuable  lessons  for  developing  voluntary  gas  reserve mechanisms. Governments can most effectively advance international cooperation  in  these  areas  by  strengthening  coordination  and  dialogue, increasing transparency, working together to enhance market flexibility, and jointly exploring new types of voluntary reserve mechanisms. The IEA stands ready  to  support  further  analysis,  knowledge  sharing,  and  international collaboration to strengthen gas security, including through its Working Party on Natural Gas and Sustainable Gases Security (GWP).

## 1. Introduction

Over the past five years, the global gas market has experienced two major energy crises. In 2022-2023, a sharp reduction in Russian pipeline gas supplies to Europe following Russian Federation (hereafter, 'Russia')'s full-scale invasion of Ukraine triggered record high gas prices, an unprecedented reconfiguration of global LNG trade  flows,  intense  competition  for  flexible  cargoes,  and  significant  demand destruction across gas-importing economies. While the acute phase of that gas supply shock has since eased - and the market is expected to transition toward a more comfortably supplied state in the second half of the decade - gas market risks and vulnerabilities remain significant. These vulnerabilities were laid bare in 2026  when  LNG  flows  through  the  Strait  of  Hormuz  were  disrupted,  including interruptions to LNG exports from the world's second largest LNG supplier, Qatar. The events of 2026 serve as a reminder that even in a more structurally balanced market environment, economies dependent on imported gas remain exposed to sudden supply disruptions and price volatility.

Governments in these countries have an extensive toolkit to address gas supply security  risks,  including  diversifying  supply  sources  and  building  long-term contract portfolios; supporting investments in supply capacity and infrastructure, including storage; maintaining adequate gas and LNG stocks; enhancing demandside flexibility; addressing vulnerabilities related to chokepoints and bottlenecks; ensuring  robust  regulatory  and  market  frameworks;  and  establishing  plans  to manage supply emergencies.

This report focuses on a relatively narrow subset of this toolkit, centred on reserve mechanisms and flexibility options, which governments can deploy in the short to medium term to enhance gas supply security.

Specifically, the report considers three areas for such mechanisms:

-  Physical assets
-  Flexible commercial arrangements
-  Policy mechanisms

The 2022-2023 crisis also exposed the risks of uncoordinated international action and zero-sum dynamics during an emergency. The recent disruptions affecting LNG flows through the Strait of Hormuz further reinforced those risks, highlighting the importance of international coordination in managing supply shocks that can rapidly propagate through interconnected gas and LNG markets globally. As such,

the international dimension, including potential areas for closer coordination and cooperation among  like-minded importers and exporters across physical, commercial, and policy-based mechanisms, is also explored in detail in this report.

## Figure 1.1 Overview of gas reserve mechanisms and flexibility options

<!-- image -->

IEA. CC BY 4.0.

A  post-crisis  market  environment  offers  an  opportune  window  to  strengthen strategic  buffers  and  policy  frameworks  for  gas  security  globally.  The  rapid expansion of global LNG supply between now and 2030 - albeit with some delays due to the conflict in Iran - could significantly increase market liquidity, improve the  affordability  of  gas,  and  shift  the  balance  of  power  towards  buyers  in  the second  half  of  this  decade.  A  period  of  looser  market  conditions,  however,  is unlikely to be permanent. The IEA's long-term scenarios indicate that global gas and LNG demand could continue to grow beyond 2030, while a prolonged period of  lower  prices  could  reduce  the  investment  incentives  for  new  LNG  export capacity as well as upstream and midstream gas infrastructure. Given long project lead  times,  insufficient  investment  in  the  coming  years  could  set  the  stage  for renewed market tightness in the early to mid-2030s, particularly if demand turns out to be higher than expected.

The events of 2026 demonstrate that even during periods of improving supply availability, geopolitical disruptions affecting key  LNG  exporters  or  critical chokepoints can quickly tighten markets. Taking advantage of more favourable conditions  expected  in  the  late  2020s  to  build  reserves,  enhance  resilience, strengthen international cooperation, and establish durable security mechanisms can therefore reduce future vulnerabilities and help avoid more costly interventions later.

## 2. A gas market in transition

## 2.1 Lessons from the 2022-2023 energy crisis

In 2022-2023, the global natural gas market experienced a major supply shock following Russia's full-scale invasion of Ukraine. 1  Early signs of market stress had already emerged in 2021, as the state-owned Russian gas supplier, Gazprom, halted spot market sales and refrained from filling its European storage facilities during the injection season, leading to a period of 'artificial tightness'. The crisis deepened significantly after the invasion, in 2022 and 2023. Between 2021 and 2023, Russian pipeline natural gas deliveries to Europe fell by around 125 bcm/yr (close to 75%), as importers struggled to secure alternative pipeline volumes at short notice.

As a result, European buyers turned to the LNG market to secure new supply, increasing LNG imports by more than 60% in 2022 (Figure 2.1). With global LNG supply unable to fill the sudden spike in demand, Europe drew LNG cargoes away from  other  markets  to  fill  the  sizeable  supply  gap,  triggering  a  significant reconfiguration  of  global  LNG  trade.  But  LNG  trade  flexibility  alone  could  not sufficiently rebalance the European market, even with UGS fully utilised and with relatively mild winter weather reducing heating demand. The remaining adjustment came through price-driven demand reductions, particularly in energyintensive  industrial  sectors  and  economically  vulnerable  households  and  small businesses, at a substantial social and economic cost.

The crisis underscored a structurally and geopolitically more complex global gas market, revealing the need to strengthen international supply security frameworks. While a wave of new LNG supply in the second half of this decade is set to ease market conditions, this period  of  relative  comfort  may  be  temporary,  or,  in  the event of renewed geopolitical disruption, even illusory, as demonstrated by the 2026  Middle  East  crisis.  Policymakers  should  therefore  look  beyond  the  early 2030s,  when  market  fundamentals  could  start  tightening  again,  and  use  any periods of interim reprieve to accelerate the design and implementation of gas reserve mechanisms and other security instruments.

1 For a more comprehensive analysis of the origins of the crisis and the resulting gas market lessons, please refer to the Gas Market Lessons from the 2022-2023 Energy Crisis report.

Figure 2.1  Year-on-year change in LNG imports by region, 2022 vs. 2021

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from ICIS LNG Edge.

The crisis also highlighted the risk of zero-sum dynamics taking hold during global crises, which can harm gas market participants worldwide. While competition for a commodity such as natural gas under normal market conditions supports the efficient allocation of resources, strengthened dialogue and coordination among like-minded LNG importers and exporters can help mitigate the most damaging effects of bidding wars under emergency conditions.

The close link between gas supply security and affordability was also revealed during this period, demonstrating that price shocks rendering gas unaffordable can deprive some end users of access to gas in ways that can resemble the effects of a  physical  supply  disruption,  particularly  in  energy-intensive  industries  and  in developing  countries.  While  governments  can  develop  backstops  to  balance consumer  protection  and  demand-side  responses  to  tight  market  conditions, collective tools beyond the national level can play a complementary role to ensure future gas supply security and affordability.

## 2.2 The post-crisis gas market environment

In 2024 and 2025, the global gas market gradually rebalanced, albeit with some reversals along the way. In the second half of the decade, a wave of new LNG supply is set to bring about a transition from a relatively tight to a relatively wellsupplied market. However, this temporary easing of market conditions should not lead to complacency. Disruption risks remain, as demonstrated by the war in Iran and the effective closure of the Strait of Hormuz starting on 28 February 2026, which hampered global energy flows, including of LNG supplies. The global gas market is expected to enter a period of greater supply abundance, but within a

structurally more complex and volatile market framework shaped by longer-term trends  that  predate  recent  geopolitical  disruptions.  This  complexity  reflects  the erosion  of  key  flexibility  mechanisms  along  the  upstream,  midstream,  and downstream parts of the value chain that previously helped absorb shocks and stabilise prices during periods of market imbalance (see next section). As a result, the resilience of gas supply systems cannot be taken for granted, even under more favourable supply-demand conditions.

## Reduced flexibility in Europe

At the centre of this structural shift lies Europe, which had served as the global gas market's balancing region of last resort since the 2010s. The loss of around 125 bcm/yr of Russian pipeline gas supply since 2021 has removed not only a major  source  of  imports,  but  also  a  uniquely  price-responsive  form  of  supply flexibility.  The  remaining  roughly  15  bcm/yr  (equivalent  to  around  5%  of  the European Union's total gas supply) is set to be phased out by the end of 2027. This  loss  has  been  compounded  by  the  phase-down  of  production  at  the Groningen  gas  field  in  the  Netherlands  and  the  effective  exhaustion  of  swing capacity  in  Norway.  At  the  same  time,  European  gas  storage  is  increasingly reserved  for  supply  security  rather  than  market-driven  flexibility  following  the introduction of mandatory storage fill targets under the EU Gas Storage Regulation in 2022. In parallel, the phase-out of coal-fired generation is reducing the scope for gas-to-coal switching in the power sector, narrowing the adjustment options on the demand side as well, although the impact has been partly offset by the rapid expansion of renewable electricity generation, which has reduced the overall need for fuel switching.

Europe has significantly expanded its LNG import infrastructure, adding more than 50 bcm/yr of regasification capacity since the 2022-2023 energy crisis. However, this has only partially offset the loss of other sources of supply flexibility. Unlike indigenous  production  or  flexible  pipeline  gas  imports,  additional  LNG  import capacity does not increase gas supply availability, it only enhances the region's ability to attract and absorb more LNG cargoes.

## Geopolitical risks

Beyond Europe, the global gas market is becoming increasingly complex and less predictable. Geopolitical risks have intensified, as demonstrated by Russia's fullscale invasion of Ukraine, which severely disrupted global gas supplies, as well as  an  increase  in  the  number  of  attacks  and  sabotage  targeting  energy infrastructure. These included an attack on the Nord Stream 1 and Nord Stream 2 pipelines  in  the  Baltic  Sea  in  September  2022,  when  explosions  rendered  the entire 55 bcm/yr Nord Stream 1 system and one of the two 27.5 bcm/yr sections

of  the  completed  (but  uncommissioned)  Nord  Stream  2  project  inoperable.  In October  2023,  the  2.6 bcm/yr  Balticconnector  gas  pipeline  linking  Estonia  and Finland  was  damaged  by  a  ship  dragging  its  anchor,  and  was  shut  down  for approximately seven months, in what authorities treated as a suspected act of sabotage. Since Russia's full-scale invasion of Ukraine in 2022, Russian strikes have  repeatedly  targeted  Ukraine's  energy  infrastructure,  including  upstream assets, gas pipelines, UGS sites, gas-fired power plants and combined heat and power units. In March 2025, the Sudzha gas metering station on the Russian side of the border - the only operational entry point for Russian gas into the Ukrainian transit corridor at the time - was also damaged in a targeted attack.

In the Middle East, Israel's conflict with Hamas prompted production suspensions and heightened security concerns at Israel's offshore gas fields due to rocket fire in late 2023, while the 12-day Israel-Iran conflict in June 2025 saw strikes on Iran's South Pars gas facilities  and  a  gas  processing  plant.  The  start  of  the  broader regional conflict in February 2026 further escalated risks to energy infrastructure across the Gulf, as military strikes targeted gas facilities in several countries. In Qatar, airstrikes on the Ras Laffan complex in March 2026 heavily damaged two LNG  liquefaction  trains  with  a  combined  capacity  of  17  bcm/yr,  requiring  an estimated  three  to  five  years  to  repair.  The  Pearl  gas-to-liquid  plant  was  also struck, which will take at least one year to repair. In the United Arab Emirates, the Shah gas field, the largest sour gas field in the world, was struck in March, while the  Habshan  gas  complex,  which  processes  more  than  half  of  the  country's domestic gas supply, sustained repeated attacks and extensive damage in March and April  2026.  In  Iran,  airstrikes  on  gas  processing  plants  and  petrochemical facilities at the Assaluyeh industrial hub disrupted output from several production phases of the South Pars gas field and severely curtailed petrochemical activity.

Beyond direct attacks on gas infrastructure, the effective closure of the Strait of Hormuz  blocked  about  20%  of  global  LNG  trade  for  several  months,  while widespread oil production curtailments reduced associated gas production across the region, particularly in Iraq and Saudi Arabia. At the start of the conflict, Israel also  suspended  production  at  the  offshore  Leviathan  and  Karish  fields  as  a precautionary measure, leading to a temporary disruption of pipeline gas exports to Egypt and Jordan. Both fields resumed operations in April 2026. These events demonstrate that armed conflict can disrupt natural gas supply not only through direct  attacks  on  gas  infrastructure,  but  also  indirectly  through  impacts  on  oil production and downstream industrial facilities.

Geopolitical instability poses a risk not only to physical energy infrastructure but also  to  critical  maritime  trade  routes.  Since  October  2023,  regular  attacks  on commercial shipping in the Red Sea by Houthi rebels in Yemen have forced fleet operators to divert cargoes, including most LNG shipments, away from the Suez

Canal onto the much longer route around Africa. In March 2026, meanwhile, the Russian-flagged LNG carrier Arctic Metagaz , carrying a sanctioned LNG cargo, was heavily damaged in a drone strike in the Mediterranean, marking the first known targeted attack on an LNG carrier.

## Greater interconnectivity

The growing interconnectivity among regional markets, driven by the expansion of flexibly traded LNG, has improved market flexibility and liquidity. At the same time, it  has  also  heightened the risk of contagion,  allowing price shocks and market imbalances to spread more rapidly and widely across regions.

During the  2022 gas crisis  in  Europe,  extreme  price  spikes  at  European  hubs spilled over not only into European power prices and industrial activity, but also into  Asian  LNG  markets,  pushing  spot  prices  to  record  levels  and  pricing  out several emerging buyers. In Pakistan, for example, some LNG suppliers cancelled contracted LNG cargoes to Pakistani buyers and diverted volumes toward higherpriced European markets, exacerbating gas shortages in the country. Similarly, Egypt introduced demand-rationing measures, including dimming streetlights and curbing  gas  use,  to  maximise  LNG  exports  to  Europe.  Finally,  the  June  2025 Israel-Iran conflict triggered simultaneous price increases at both European and Asian benchmarks, highlighting how security risks in one region can have nearimmediate global price impacts in an increasingly interconnected global market.

## Trade fragmentation

While greater interconnectivity allows price signals to reverberate rapidly across regions, growing fragmentation in international trade is adding friction to global gas flows, reducing the overall efficiency of global gas market adjustment. This includes the expanded use of international sanctions, as well as restrictive trade policies and tariffs that increasingly affect - or explicitly target - natural gas and LNG  flows.  Economic  sanctions  often  pursue  clear  geopolitical  and  security objectives, such as curtailing Russia's ability to finance and sustain its war against Ukraine. However, they also increase complexity in global gas trade and reduce flexibility in market adjustment. Since 2023, successive rounds of US sanctions have  targeted  Russian  LNG  export  infrastructure,  including  Arctic  LNG  2  and, since January 2025, the smaller Portovaya and Vysotsk LNG facilities on the Baltic Sea, severely constraining exports and shipping operations.

In  parallel,  the  European  Union  has  progressively  tightened  restrictions  on Russian LNG. The 14th sanctions package, adopted in June 2024, prohibited LNG transshipment in EU ports to non-EU destinations. In May 2025, the European Commission's  REPowerEU  roadmap  set  out  the  objective  of  phasing  out  the

remaining Russian energy imports, including both pipeline gas and LNG, by the end of 2027. Subsequent legal measures supported this objective, including the 19th sanctions package, adopted in October 2025, which introduced a phased ban on Russian LNG imports. That ban applies to imports under short-term contracts from April 2026 and to imports under long-term contracts from January 2027. The REPowerEU  Gas  Regulation,  which  entered  into  force  in  February  2026, established a legally binding phase-out of Russian pipeline gas and LNG imports by 1 November 2027. The European Union's 20th sanctions package, adopted in April 2026, introduced additional restrictions, including a prohibition on maintenance and other services for Russian LNG tankers and ice-breakers, and a ban on LNG terminal services to Russian entities.

Trade fragmentation has also intensified in the Asia Pacific region. Since February 2025, the People's Republic of China (hereafter, 'China') has imposed retaliatory tariffs on US LNG - at one point reaching 125% before being reduced to 25%. Those measures led to a complete halt of direct LNG shipments from the United States  to  China  between  early  2025  and  mid-2026,  with  contracted  volumes redirected or resold into other markets instead.

The EU's Methane Regulation, although not designed as a trade measure, has been identified as a potential non-tariff barrier that may impact LNG trade flows in the medium term. The measure, which entered into force in 2024, seeks to reduce methane  emissions  across  the  gas  value  chain  in  line  with  the  EU's  broader climate  and  decarbonisation  objectives.  It  requires  more  stringent  monitoring, reporting, and verification on EU gas importers, which some stakeholders have suggested creates friction within the global LNG market.

## Growing weather sensitivity

Finally, gas flows and gas demand are becoming increasingly weather-sensitive, reflecting  their  growing  exposure  to  weather-related  disruptions  and  the  rising share of variable renewables in power systems. Severe drought conditions in 2024 forced  the  Panama  Canal  to  impose  water-level  restrictions  that  reduced  the number of LNG cargo transits by more than 80% compared with the five-year average. Earlier weather shocks also had lasting effects: severe cold spells in Northeast Asia and Texas in early 2021, followed by a long and cold spring season in Europe, caused short-term disruptions and drew down gas inventories, setting the stage for tight market conditions ahead of the 2022-2023 energy crisis. More recently, prolonged heatwaves across South and Southeast Asia in the second quarter of 2024 pushed electricity demand for cooling higher, supporting stronger LNG import demand for power generation and elevated regional prices. At the same  time,  greater  reliance  on  variable  renewables  has  increased  short-term volatility in gas-fired generation, as well as in wholesale gas and power prices. In November and December 2024, for example, extended ' dunkelflaute ' episodes

across northwestern Europe - characterised by simultaneously low wind speeds and low solar generation - occurred during a period of elevated power demand. This  led  to  notable  increases  in  gas-fired  generation,  highlighting  the  growing balancing role of gas in renewables-heavy energy systems.

Gas is also increasingly required when nuclear or hydro power are hampered by dry spells. During a 2022 heatwave in Europe, for example, a drought in France reduced  river  levels  and  elevated  water  temperatures,  ultimately  constraining nuclear  output  that  had  already  been  reduced  due  to  maintenance  outages. Similar  heatwave-induced  droughts  forced  hydropower  generation  to  decline significantly across Europe during the same period. Such weather-related volatility is likely to increase the importance of gas as a balancing fuel during episodes of low renewable output, even in markets where overall gas demand is declining.

Taken together, the above developments indicate that in today's less predictable market environment, the deployment of new reserve mechanisms and flexibility options, along with stronger international cooperation, are critical to enhancing global gas supply security and system resilience.

## 3. Flexibility options along gas and LNG value chains

Flexibility  exists  throughout  the  gas  value  chain,  from  upstream  production through midstream infrastructure and trade to end-use consumption, though not every segment of the supply chain is equally suitable, or available for governments to leverage in order to enhance system flexibility. We explore some of the key flexibility levers in the section below.

## Production flexibility

Supply-side flexibility determines how much natural gas can be made available to the  market,  but  it  is  generally  limited  to  a  small  number  of  swing  fields  and  is increasingly constrained in major LNG-importing regions, including Europe and Asia. Several factors have reduced pipeline-based flexibility in Europe, including the sharp decline in flexible pipeline gas supplies from Russia since 2022; the progressive phase-down of production at the Groningen field in the Netherlands, which was previously a major source of upstream flexibility; and the plateauing and expected decline of production from key North Sea fields, some of which also provide flexible output. In Asia, meanwhile, gas fields have demonstrated limited ability to adjust production in response to demand fluctuations, while production in South and Southeast Asia has been in long-term decline.

LNG liquefaction facilities also offer limited operational flexibility. Outside planned maintenance periods and unplanned outages, liquefaction plants typically operate close  to  capacity,  leaving  little  scope  for  rapid  supply  increases.  Over  the 2021-2025 period, utilisation of available LNG export capacity averaged around 85% worldwide. In principle, future LNG projects could be developed with spare liquefaction capacity to provide additional supply flexibility, potentially backed by importers  as  a  cost-effective  alternative  to  storage  investments  closer  to  their home  market.  However,  no  major  LNG  project  has  been  developed  with  this objective to date. As a result, supply-side flexibility across the global gas system remains limited. This represents one of the biggest bottlenecks in the LNG value chain.  Moreover,  it  is  typically  outside  the  direct  control  of  governments,  as decisions on production and liquefaction utilisation reside with upstream producers and LNG exporters.

## Demand flexibility

Demand-side flexibility allows gas consumption to be reduced temporarily through a number of measures, including fuel switching; market-based demand response; behavioural  changes;  or  administrative  restrictions. Governments  can  also influence demand flexibility through measures such as efficiency improvements, pricing reforms, conservation campaigns, and emergency response programmes. While demand response can be a key element of gas market flexibility, certain types  of  demand  adjustments,  particularly  administrative  restrictions,  can  be socially and economically costly and are typically reserved for emergencies.

Fuel-switching options are becoming more limited in markets that are phasing out coal, while administrative measures usually prioritise protecting households and critical services  by  curtailing  industrial  demand  first.  As  such,  downstream flexibility can play a role in responding to supply disruptions and enhancing system resilience, but some demand-side measures involve economic and social tradeoffs or are primarily designed for crisis situations rather than to provide a durable source of system flexibility.

## Midstream flexibility

Midstream  flexibility  mechanisms  enable  the  timely  and  efficient  allocation  of natural gas and LNG to market participants. Destination-free LNG cargoes and LNG reload infrastructure,  for  example,  are  key  sources  of  locational  flexibility within  the  midstream  segment  of  the  LNG  value  chain.  Underground  storage facilities provide critical seasonal flexibility, particularly in Europe, while short-term balancing  can  be  supported  by  linepack  management,  fast-cycling  salt  cavern storage,  floating  LNG  storage,  and  contractual  flexibility.  LNG  tank  storage  at import terminals provides operational flexibility, helping to manage cargo arrivals, regasification schedules, send-out rates, and short-term market imbalances. For LNG-dependent import markets in Asia with limited underground storage, terminal tank capacity and large regasification capacity help to strengthen supply security by improving short-duration resilience. In markets with winter peak demand, such as Japan and Korea, LNG tanks also provide seasonal flexibility.

While opportunities to enhance flexibility exist across all segments of the gas value chain,  the  midstream  segment  offers  a  particularly  broad  set  of  physical, commercial, and policy levers that governments can use to strengthen system flexibility. As such, it is the primary focus of the analysis that follows.

## 4. Physical gas reserves

Physical gas reserves are an essential component of gas system resilience. This chapter examines the main forms of physical gas reserves that can enhance gas security  and  system  flexibility:  UGS,  LNG  tank  storage,  floating  storage  and regasification units (FSRUs) and floating storage units (FSUs), and LNG floating storage  on  conventional  carriers. 2  Together,  these  tools  form  the  core  set  of physical  reserve  options  that  can  be  deliberately  expanded  and  strategically mobilised by governments as part of national or international reserve mechanisms and supply security frameworks.

Figure 4.1 Physical storage capacity in operation and under construction worldwide, end of 2024

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from the International Group of Liquefied Natural Gas Importers (2025), Annual Report 2025; and CEDIGAZ (2026), UGS Dataset.

Other  sources  of  physical  flexibility  exist  in  gas  systems.  One  is  linepack management (Box 1), which relies on pressure variations within high-pressure transmission pipelines to temporarily store and release gas. Linepack management is a critical  operational  flexibility  tool,  and  plays  a  central  role  in intraday  balancing,  especially  in  highly  meshed  transmission  systems  such  as those  in  Europe.  However,  linepack  management  falls  primarily  within  the operational  remit  of  gas  transmission  system  operators  (TSOs),  who  already

2 FSUs are purpose-built vessels or LNG carriers that have been permanently converted into dedicated storage facilities and remain moored at a fixed location, typically as part of LNG import infrastructure. By contrast, LNG floating storage on conventional carriers refers to standard LNG carriers that temporarily hold cargoes on board without being converted into dedicated storage assets.

optimise linepack as part of normal system balancing and reliability management. As such, it is treated here as a background source of system flexibility rather than as a distinct reserve instrument for policy design and is not examined in detail. Nevertheless, experience sharing between European TSOs and their counterparts in Asia could help transfer best practices, as well as support more effective system balancing and better linepack utilisation during supply emergencies.

## Box 4.1 Linepack management: The hidden flexibility embedded in gas transmission systems

Linepack refers to the quantity of gas stored within a transmission pipeline system. In practice, operators can increase or decrease the amount of gas physically held in the network by adjusting pressure within permitted technical and safety limits. This  makes  linepack  the  most  immediate  and  continuously  available  source  of flexibility in many pipeline gas systems.

Although linepack is not usually classified alongside dedicated storage infrastructure,  it  performs  an  essential  balancing  function.  When  demand  rises unexpectedly over the course of a day, gas can temporarily be withdrawn from the transmission network through a controlled reduction in pressure. Conversely, when inflows exceed offtake, TSOs can rebuild linepack by increasing system pressure. In this way, the transmission network itself functions as a short-duration storage buffer.

The main benefit of linepack is its speed and operational responsiveness. Unlike underground  storage  or  LNG-based  flexibility  tools,  linepack  can  be  adjusted almost  instantaneously  and  does  not  require  separate  injection  or  withdrawal infrastructure beyond the normal operation of compressors, valves, and control systems.  It  is  therefore  especially  important  for  managing  intraday  demand fluctuations  and  maintaining  system  balance  between  nominations  and  actual flows.  In  liberalised  gas  markets,  linepack  also  helps  absorb  small  imbalances created by shippers, supporting market-based balancing regimes and reducing the need for costlier balancing options.

The volume of gas that can be stored as linepack depends on pipeline diameter, network length, operating pressure, compressor configuration, and the permissible pressure range within the system. Highly meshed, high-pressure networks with large-diameter transmission lines can hold substantial quantities of gas in linepack terms.  In  the  United  Kingdom,  for  example,  the  transmission  system  operator reports  average  and  maximum  linepack  swings  during  peak  winter  periods  of around 15-20 mcm/d and 30-40 mcm/d, respectively (equivalent to roughly 5% to 15%  of  average  winter  demand)  over  the  past  five  winters.  However,  these volumes cannot be withdrawn repeatedly without being replenished by upstream

flows,  storage  withdrawals  or  imports.  In  this  sense,  linepack  complements dedicated reserve infrastructure, instead of replacing it.

From a policy perspective, linepack is best understood as an embedded source of system flexibility rather than a substitute for seasonal or strategic stockholding. While  it  can  address  hourly  or  daily  imbalances,  it  cannot  address  structural shortages,  cover  prolonged  supply  disruptions,  or  provide  the  multi-week  or seasonal reserve capacity required for security planning.

Another  option  is  peak-shaving  LNG  plants,  which  liquefy  gas  during  off-peak periods and vaporise it during periods of peak demand. Peak-shaving plants have historically  played  a  useful  role  in  some  local  or  regional  gas  systems  (e.g.  in Canada, China, and the United States). However, they are typically small in scale, often dedicated to specific local demand centres, and differ in both economics and system  function  from  the  large-scale  reserve  instruments  considered  in  this chapter. For these reasons, they are not assessed further in this study.

The tools covered in this chapter also differ in the extent to which they can support reserve mechanisms, particularly those involving multiple countries or spanning regions. Under appropriate regulatory and commercial conditions, UGS and LNG tanks can provide dedicated reserve capacity and host stocks on behalf of other countries or market participants. By contrast, floating LNG assets tend to offer more limited reserve volumes but can provide valuable rapid-response capability, particularly where permanent infrastructure is lacking or where emergency import access is required at short notice. LNG floating storage occupies a still narrower niche: although costly and generally unsuitable for long-duration reserve building, it  can  provide  temporary  buffering  capacity  during  periods  of  extreme  market dislocation or infrastructure bottlenecks.

These different tools illustrate that there is no single model for developing and maintaining  physical  gas  reserves.  The  following  sections  assess  the  key characteristics of the main physical reserve tools, with a particular focus on their suitability for strategic use.

## Table 4.1 Overview of physical gas reserve and LNG flexibility options

|                 | Underground gas storage                                                                                       | Underground gas storage                                                                                                | Underground gas storage                                                                    | LNG tank storage                                                                                                      | FSRUs and FSUs                                                                                                                                                                                                                                 | LNG floating storage                                                                                                                                                                                                                         |
|-----------------|---------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                 | Depleted fields                                                                                               | Aquifers                                                                                                               | Salt caverns                                                                               |                                                                                                                       |                                                                                                                                                                                                                                                |                                                                                                                                                                                                                                              |
| Description     | Former gas reservoirs repurposed for storage in porous rock formations.                                       | Water-bearing formations converted into gas storage reservoirs.                                                        | Artificial caverns in salt formations created by solution mining.                          | Cryogenic tanks storing LNG at -162°C at LNG import terminals.                                                        | Floating units used to import LNG; FSRUs include regasification, FSUs require onshore regasification.                                                                                                                                          | Conventional LNG carriers used for offshore LNG storage.                                                                                                                                                                                     |
| Primary purpose | Seasonal storage and large-scale system balancing.                                                            | Seasonal storage where depleted fields are unavailable.                                                                | Short-term balancing and peak demand management.                                           | Operational buffer with partial seasonal role in LNG- dependent markets.                                              | Fast-track LNG import infrastructure for regular and emergency access to LNG.                                                                                                                                                                  | Commercial optimisation during market dislocations.                                                                                                                                                                                          |
| Advantages      | • Proven geology reduces risk. • Large available capacity. • Large potential working gas capacity.            | • Broad geographic availability of aquifers, including where no depleted fields exist. • Large potential working gas   | • High withdrawal and injection rates. • Lower cushion gas requirement (~20%).             | • Typically located near demand centres. • High deliverability to the gas grid.                                       | • Fast-track deployment (< 1 year) possible with existing infrastructure and government support. • Redeployable assets. • High send-out rates (about 5 bcm/yr).                                                                                | • Highly flexible and mobile. • No fixed infrastructure required for storage. • Can utilise ageing vessels nearing retirement.                                                                                                               |
| Limitations     | • Low cycling capability. • Long lead time (five to seven years). • High cushion gas requirement (about 50%). | • Greater geological uncertainty. • Possible environmental issues. • High cushion gas requirement (about 50% or more). | • Small working gas capacity. • Limited suitable geology.                                  | • High unit cost vs. underground storage. • Long construction time (up to five years). • Limited volumetric capacity. | • Limited storage capacity (0.1 bcm per unit). • Limited vessel availability. • Not suitable for long- term storage.                                                                                                                           | • Limited storage capacity (0.1 bcm per unit). • Operational complexity. • Technical constraints (e.g. cargo ageing and boil-off). • Not suitable for long- term storage.                                                                    |
| Estimated cost  | USD 0.5 million - USD 1.0 billion per bcm of working gas capacity (excluding cushion gas).                    | USD 0.5 million - USD 1.0 billion per bcm of working gas capacity (excluding cushion gas).                             | USD 0.5 million - USD 1.0 billion per bcm of working gas capacity (excluding cushion gas). | USD 150 million - USD 250 million per 180 000 m³ storage tank (about 0.1 bcm of gas equivalent).                      | • Newbuild FSRU: USD 300 million - USD 420 million. • Conversion: USD 200 million. • Charter rate: USD 100 000 - USD 200 000 per day (USD 35 million - USD 70 million per year). • Onshore infrastructure: USD <100 million to several hundred | • Newbuild LNG carrier: USD 250 million. • Cost of old LNG carrier at scrap value: USD 15 million - USD 20 million. • Additional cost of converting an old LNG carrier to an FSU more suitable for storage: USD 14 million - USD 20 million. |

Note: Working gas is the volume of gas in underground storage that can be regularly injected and withdrawn during normal operations.  Cushion  gas  is  the  volume  of  gas  permanently  held  in  a  UGS  reservoir  to  maintain  pressure  and  ensure deliverability; it is not withdrawn during normal operations but may be recoverable under specific circumstances, including as part of the closure and decommissioning of a storage facility.

## 4.1 Underground gas storage

UGS is a key source of gas system flexibility, both regionally and globally, helping to balance seasonal demand variability with more stable gas production profiles throughout the year. On shorter timescales, UGS facilities can also provide daily flexibility  through  their  withdrawal  capacity  and  proximity  to  demand  centres, making them one of the fastest midstream flexibility levers available to mitigate demand swings and price volatility.

Globally, UGS  facilities are predominantly  developed  from  depleted  fields (accounting  for  more  than  80%  of  operational  capacity),  followed  by  aquifers (about  10%),  and  salt  caverns  (less  than  10%). 3 Depleted  fields  offer  the advantage  of  being  proven  gas-bearing  formations,  providing  greater  certainty regarding  their  technical  suitability  for  conversion  into  UGS  facilities.  Where depleted  fields  are  not  available,  aquifers  can  provide  an  alternative,  although more  rigorous  testing  is  typically  required  to  confirm  permeability  and  storage performance,  and  higher  cushion  gas  requirements  generally  make  aquifers  a more  costly  option.  Both  depleted  fields  and  aquifers  are  typically  used  for seasonal balancing and tend to have relatively low cycling capability.

Salt  caverns,  by  contrast,  are  better  suited  to  managing  short-term  demand fluctuations due to their high injection and withdrawal rates, allowing for multiple cycles per year. The working gas capacity of salt caverns is generally smaller than that of depleted fields or aquifers and they account for less than 10% of working gas  capacity  globally,  but  they  provide  roughly  25%  of  global  deliverability, reflecting their superior cycling capability relative to other types of UGS facilities.

While UGS facilities act as a key lever of supply-side flexibility in the global gas market, they are capital-intensive, requiring subsurface analysis, above ground infrastructure, and the purchase of cushion gas for the facility to be operational. Recently completed UGS facilities had reported capex of between USD 500 million and  USD  1  billion  per  bcm  of  working  gas  capacity,  excluding  cushion  gas. Furthermore, UGS facilities have relatively long lead times, often requiring five to ten years to develop, depending on local conditions and the type of facility. As such, the maximum UGS capacity that will be available to the market in 2030 is already broadly known today and defined by existing capacity and investments that have already been committed. Developing new UGS capacity can therefore fit into long-term energy system planning but will have little impact on short-term market dynamics.

## Global distribution of UGS capacity

Underground gas storage capacity, totalling about 445 bcm globally at the end of 2024, is unevenly distributed across the world. Regions with mature gas markets

3 CEDIGAZ (2025), Underground Gas Storage in the World - 2025 Status.

and  highly  seasonal  gas  demand  patterns  account  for  the  largest  operational capacity: North America has about 37% of operation capacity, Europe has about 33%,  and  Eurasia  has  about  20%.  Asia  holds  only  about  9%  of  global  UGS capacity, although the region, led by China, has increased its UGS capacity in recent years.

The United States and Russia are the two largest individual UGS markets, with about 135 bcm and 75 bcm of storage capacity, respectively. In Russia, UGS capacity in operation accounted for about 14% of domestic demand in 2024, down one  percentage  point  from  2010.  In  the  United  States,  however,  this  share declined from about 18% to 14% over the same period, as growth in capacity additions  remained  below  growth  in  demand.  (Taking  into  account  feedgas requirements for LNG exports further reduces this ratio). However, both countries are also major gas producers and net exporters, setting them apart from Europe and Asia, the world's two largest LNG importing poles. While Europe and Asia rely on  LNG as a key element of gas supply, their  available  UGS  capacities  differ markedly: Europe has around 150 bcm of UGS capacity (of which about 105 bcm is located in the European Union), whereas the Asia Pacific region has only about 38 bcm, including about 31 bcm in China.

The prospects for  UGS capacity growth are predominantly in Asia. Out of the approximately 64 bcm of UGS capacity that were under construction globally by the end of 2024, China alone accounted for more than half (around 36 bcm). The remaining  share  was  spread  between  relatively  mature  gas  markets  across Europe, Eurasia, North America, and the Middle East. In terms of geology, most of the total capacity under construction was being developed in depleted fields (around 80%), with the rest mostly accounted for by salt caverns.

<!-- image -->

## Europe

Sizeable  UGS  capacity  has  long  been  a  central  feature  of  the  European  gas market,  having  been  developed  in  response  to  highly  seasonal  gas  demand patterns across the continent well before market liberalisation. It has subsequently become  integrated  into  the  unique  regulatory  structure  of  a  large,  liquid,  and liberalised gas market, particularly in the European Union (and members of the Energy Community). EU rules on third-party access (TPA) to gas infrastructure, including storage facilities, ensure that UGS is used to its full potential in market balancing.

Over the past decade, capacity additions, mainly concentrated in Czechia, Italy, Poland, and Türkiye, have been limited relative to the total capacity in operation. Capacity additions were partly offset by closures, primarily in Germany, Ireland, and the United Kingdom (although the Rough facility in the UK, which closed in 2017, was subsequently reopened in 2022 with reduced capacity). Between 2016 and 2023, overall working gas capacity in the European Union increased by only around  1  bcm,  or  1%,  on  a  net  basis,  while  in  the  broader  European  region, including Türkiye, Ukraine, and the United Kingdom, it grew by around 5 bcm, or 4%. More facilities could be closed in the coming years, driven by the phase-out of  low-calorific  gas  (L-gas)  originally  supplied  from  the  Groningen  field  in  the Netherlands, which will reduce the need for dedicated L-gas storage sites, as well as by limited commercial interest in small, ageing, and slow-cycling facilities in mature markets, particularly in Germany.

Still, with close to 7 bcm of new UGS capacity under construction as of the end of 2024 (mostly  concentrated  in  southern  and  southeastern  Europe,  with  notable additions  in  Bulgaria,  Italy,  Romania,  and  Türkiye),  total  European  storage capacity is expected to remain relatively stable in the medium term.

The potential repurposing of existing UGS sites for hydrogen storage has also gained attention, as the European Union and the United Kingdom seek to support the development of a hydrogen economy. However, the ongoing reassessment of hydrogen demand and deployment timelines in view of high costs suggests that large-scale conversion of UGS assets remains a long-term possibility rather than an imminent prospect.

## Asia Pacifc

Compared  with  the  leading  UGS  regions,  Asia  Pacific  relies  much  less  on underground storage to balance its gas market. The region's legacy gas markets, including in Japan and Korea, have limited suitable geological formations for largescale underground storage facilities. In South and Southeast Asia, where gas and especially LNG - demand is projected to grow rapidly in the medium term,

limited pipeline infrastructure and the absence of strong seasonal heating demand have also constrained opportunities for UGS  development.  Nevertheless, depleted gas fields in the region could provide suitable geological formations for future storage projects as gas use and LNG import dependence grow over time.

UGS capacity in the Asia Pacific region is overwhelmingly concentrated in China, which more than quadrupled its storage capacity between 2015 and 2024 to reach an estimated 31 bcm, largely in depleted field formations. A comparable volume of additional capacity is currently under construction, alongside further early-stage expansion  plans,  driven  by  storage  mandates  introduced  in  2018  and  an implementation  plan  issued  in  2021  to  help  boost  the  pace  of  UGS  capacity additions. As residential and commercial gas demand grows in China, alongside rising domestic production and increasing pipeline and LNG imports, underground storage is increasingly important for balancing seasonal demand and enhancing supply security,  especially  during  peak  winter  months.  Outside  of  China,  UGS capacity in Asia Pacific remains limited to Australia, New Zealand, and a handful of small-scale facilities in Japan.

## Third-party access to underground storage facilities

The effective use and integration of UGS into market balancing also depends on the regulatory framework that storage operators must adhere to. In this respect, TPA  rules  have  become  essential  to  extracting  the  full  flexibility  and  market benefits from UGS infrastructure. In practice, these rules require storage operators to  offer  available  capacity  to  eligible  third  parties  on  transparent  and  nondiscriminatory terms.

In the European Union, third-party access to UGS infrastructure was introduced under the Third Energy Package in 2009 and became mandatory in the following years  as  member  states  transposed  the  relevant  gas  market  directives  into national  law.  The  package  established  an  obligation  for  member  states  to implement a TPA regime, while providing a choice between two models: regulated third-party access and negotiated TPA. 4  Under regulated TPA, national regulators set  cost-reflective  storage  tariffs,  which  are  periodically  revised  and  adjusted. Under negotiated TPA, storage operators are free to negotiate access terms and prices with individual users. In both models, the fundamental principles underpinning third-party access - namely transparency, non-discrimination, and effective market competition - still apply, although facility-level exemptions can be granted under strictly defined conditions.

In the United States, the principle of open access was established in the 1990s through a series of Federal Energy Regulatory Commission orders that introduced

4 Derogations to third-party access exist under certain criteria, but represent the exception as opposed to the rule.

unbundling requirements for pipeline and storage assets owned by companies engaged in interstate operations. Interstate storage operators have since been required to offer available capacities to third parties on a non-discriminatory basis.

Over time, open access has also been extended to storage infrastructure owned by intra-state operators, broadening the role of these facilities in market balancing and  optimisation.  While  this  evolution  was  not  driven  by  a  single  regulatory mandate  at  the  state  level,  the  strengthening  of  federal  safety  and  oversight standards across all storage facilities encouraged state regulators to adopt more robust regulatory oversight and open access principles at the state level as well. 5

In China, gas market reforms began later than in Europe and North America, and efforts  to  introduce  third-party  access  have  taken  place  in  stages.  Initial  trial measures on fair and open access to oil and gas infrastructure were introduced in 2014. A more decisive step came with the creation of the China Oil and Gas Piping Network  Corporation  (PipeChina)  in  2019.  The  transfer  of  ownership  of  key pipeline  assets  from  the  country's  three  national  oil  companies  to  the  newly established independent state-owned midstream operator represented a significant move toward unbundling and created the institutional basis for wider application of TPA principles. While effective implementation and enforcement of TPA rules remain uneven, China's regulatory commitment to unbundling and to open access demonstrates the importance of third-party access in unlocking the broader market and system benefits of UGS facilities.

Transparent, non-discriminatory third-party access to storage capacity is not only critical to integrating UGS into competitive gas markets at the national and regional level,  but  also  determines  the  extent  to  which  storage  infrastructure  can  be mobilised as part of international cooperation frameworks and cross-border gas reserve mechanisms.

## Underused storage capacity in Europe

European UGS facilities are typically operated close to capacity. Over the past decade, the maximum combined EU storage fill level averaged more than 90% ahead of the winter heating season, and it reached at least 95% in five of those years.  Since  2022,  these  high  storage  levels  have  been  supported  by  the European  Union's  Gas  Storage  Regulation,  which  required  member  states  to ensure that UGS facilities on their territory were filled to at least 80% of capacity by 1 November 2022, and then 90% in subsequent years. The regulation has been extended  through  2027,  with  the  90%  target  maintained,  while  introducing additional flexibility around the filling trajectory and timing of compliance.

5 US Department of Transportation, Protecting Our Infrastructure of Pipelines Enhancing Safety (PIPES) Act of 2016 .

Figure 4.3 European UGS capacity and average maximum utilisation by country, 2024

<!-- image -->

IEA. CC BY 4.0.

Note: Ukrainian fill rate corresponds to four-year average maximum in 2022-2025, in line with data availability; Swedish fill rate corresponds to five-year average maximum in 2021-2025, in line with data availability. Source: IEA analysis based on CEDIGAZ (2026), UGS Dataset; Gas Infrastructure Europe (2026), AGSI+ Database.

Ukraine, however, remains a notable outlier in Europe, with a vast but heavily underutilised UGS system. With 31 bcm of working gas storage capacity, Ukraine had the world's third-largest UGS capacity at the end of 2024, behind the United States and Russia, although China and Canada were only slightly behind and China  has  since  been  on  track  to  move  into  third  place.  Ukraine's  extensive infrastructure reflects the country's higher domestic gas demand during and after the Soviet era, as well as its former role as a major transit corridor for Russian pipeline gas deliveries to the European Union. As a result, Ukraine's UGS capacity significantly exceeds current domestic requirements.

Between 2022 and 2025, maximum storage fill levels in Ukraine averaged only around 32%. Out of a total working gas capacity of 31 bcm, this implies an annual average  of  around  21  bcm  of  unused  UGS  capacity.  Around  25  bcm  of  the country's total capacity is in western Ukraine, with an additional 2 bcm in central Ukraine, under firm Ukrainian control. Approximately 4 bcm is located closer to eastern entry points for Russian gas, including facilities in partly or fully occupied territory.

Ukraine has undertaken regulatory reforms that have made the country's storage facilities  more  attractive  for  European  market  participants.  In  2020,  Ukraine harmonised elements of its regulatory framework with EU rules and significantly reduced the cost of storing gas for EU-based traders, including by cutting transport tariffs  and  allowing  temporarily  stored  gas  to  be  exempt  from  customs  duties. These reforms enabled European companies to use Ukraine's UGS facilities as overflow  capacity  and  store  up  to  10  bcm  of  gas  in  Ukraine  during  a  market oversupply period in 2020, when EU storage sites filled rapidly ahead of the winter.

Current rules allow duty-free warehousing of gas in Ukrainian storage for up to three years, potentially enabling multi-year stockbuilding when market conditions are favourable.

In the summer of 2023, EU storage facilities were once again near capacity well ahead of the winter heating season and market conditions, in principle, would have allowed for that oversupply to be stored in Ukrainian facilities. In April of that year, Ukraine's  state-owned  gas  storage  operator,  Ukrtransgaz,  was  certified  as  a European storage operator, paving the way for it to hold strategic gas reserves for EU member states, which received strong support from Ukrainian authorities and industry. But heightened security risks, including potential infrastructure damage and  the  loss  of  control  over  facilities,  due  to  the  war  with  Russia  significantly reduced commercial appetite for utilising Ukrainian storage capacity. As a result, foreign-held inventories reached less than 3 bcm at their peak in 2023 and were negligible in 2024 and 2025.

In October 2025, Ukraine's state-owned oil and gas company Naftogaz proposed that part of the country's spare UGS capacity could be used to develop an EUwide strategic natural gas reserve. While Ukraine's underutilised and geographically  well-positioned  storage  capacity  could  potentially provide  a valuable flexibility asset for Europe - and indirectly benefit Asian LNG importers as well - such a mechanism would require a clear governance framework, publicsector involvement in financing, and robust arrangements to manage security and political risks. In practice, it would likely only be feasible after the end of the war.

## 4.2 LNG tank storage

LNG  storage  tanks  provide  an  additional  pathway  for  storing  natural  gas  in physical form, although their use for long-term storage remains relatively limited. By cooling natural gas to around -162°C, its volume is reduced by a factor of roughly 600, allowing large quantities of gas to be stored in liquid form in insulated cryogenic tanks at LNG terminals. While LNG tank storage is primarily designed to  smooth  operational  flows  at  regasification  facilities,  it  also  constitutes  an important, albeit relatively limited, form of physical gas reserves in the global gas system.

Most onshore LNG import terminals are equipped with storage tanks that allow operators  to  decouple  the  timing  of  LNG  cargo  arrivals  from  the  regasification send-out  to  the  pipeline  network.  These  tanks  provide  short-term  buffering capacity that can accommodate fluctuations in shipping schedules, variations in daily  demand,  and  temporary  operational  disruptions.  In  systems  with  limited UGS, particularly in Japan and Korea, LNG tanks can also play a broader role in balancing  seasonal  demand  or  providing  a  strategic  buffer  against  supply disruptions.

In volumetric terms, LNG tank storage represents the second-largest form of gas storage globally after UGS. At the end of 2024, the total working capacity of LNG storage tanks located at onshore regasification terminals was roughly 50 bcm of natural gas equivalent worldwide. This is only a fraction of global UGS capacity which  was  around  445  bcm  in  2024  -  reflecting  the  fact  that  LNG  tanks  are primarily  designed  for  operational  flexibility  rather  than  long-term  stockholding. However, when combined with the high mobility of LNG cargo delivery, they can nonetheless function as a physical buffer in the global gas-LNG system.

The distribution of LNG storage capacity broadly mirrors the geography of LNG import infrastructure. More than 80% (42 bcm) of global onshore LNG storage capacity is in Asia, where LNG plays a central role in gas supply. Globally, an additional 5 bcm of LNG storage capacity was under construction at the end of 2024, with approximately 95% of these additions located in Asia. 6

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from the International Group of Liquefied Natural Gas Importers (2025), Annual Report 2025.

LNG storage tanks are relatively complex structures compared with tanks used for oil  or  oil  product  storage  and,  unlike  UGS,  require  purpose-built  containment structures  rather  than  relying  primarily  on  existing  geological  formations.  LNG tanks are designed to safely contain LNG at cryogenic temperatures and typically use single-containment, double-containment, or full-containment designs, depending on safety requirements and site conditions. Modern tanks are usually full-containment structures, consisting of a stainless steel or nickel steel inner tank surrounded by a reinforced concrete outer shell and thermal insulation to minimise LNG boil-off. Due to this complexity, LNG storage tanks are relatively expensive.

6 Liquefaction terminals also contain LNG storage tanks. However, the aggregate storage capacity at liquefaction plants estimated at around 10 bcm of gas equivalent - is much smaller than at regasification terminals, and these tanks are designed primarily to smooth export operations rather than to provide reserve capacity for importing markets. As such, they are excluded from the scope of this study.

Based on recent project data, a standard 180 000 m³ LNG tank typically costs between USD 150 million and USD 250 million, depending on site conditions, engineering specifications, and local construction costs. On an energy-equivalent basis, this corresponds to a unit cost that is at least five to ten times higher than that of oil storage and two to four times higher than that of UGS.

<!-- image -->

Tank  sizes  vary  across  terminals,  but  most  modern  onshore  LNG  tanks  have capacities in the range of 160 000 to 200 000 m³ of LNG (equivalent to roughly 0.10  to  0.12  bcm  of  natural  gas).  Onshore  regasification  terminals  in  Europe typically operate two to four storage tanks, while large-scale facilities in northeast Asia, where LNG tanks can also serve seasonal roles, may have many more. As a  result,  total  storage  capacity  at  individual  LNG  terminals  generally  ranges between 0.2 and 0.5 bcm of natural gas equivalent, depending on terminal size and configuration.

The  role  of  LNG  tank  storage  varies  significantly  across  regions,  reflecting differences  in  gas  market  structure,  infrastructure  availability,  and  demand patterns.

Asia Pacific relies more heavily on LNG tank storage than any other region. China, Japan, and Korea - the world's three largest holders of LNG tank storage capacity - together account for nearly 90% of Asia's capacity and 70% of the global total.

China has the largest LNG tank storage capacity in the world, with over 15 bcm of total capacity at the end of 2024. This reflects the rapid expansion of the country's LNG import infrastructure in recent years (in anticipation of rapid growth in LNG demand), as well as China's extensive truck-based LNG distribution networks, which benefit from additional storage capacity at import terminals to support inland deliveries.

In Japan and Korea, LNG tanks serve not only as operational buffers but also as a  partial  substitute  for  seasonal  gas  storage.  Both  countries  lack  large-scale underground  storage  formations,  and  inventories  accumulated  in  LNG  tanks ahead of the winter heating season contribute to supply security during periods of peak  demand.  With  around  12  bcm  of  LNG  tank  capacity  distributed  across roughly 190 tanks at 37 import terminals, Japan has the world's second-largest LNG storage system after China. Korea ranks third globally, with around 9 bcm of storage capacity, more than the entire LNG tank storage capacity of Europe. Other Asian importing countries also rely on LNG tanks as their primary storage buffer due  to the absence  of  underground  storage  infrastructure,  although  their capacities are considerably smaller. Much of the remaining LNG tank capacity in Asia  is  concentrated  in  India  (1.9  bcm),  Chinese  Taipei  (1  bcm),  Thailand (0.7 bcm), and Singapore (0.5 bcm).

In  Europe,  LNG  tank  storage  plays  a  more  limited  role  in  overall  gas  system flexibility because the region already possesses extensive underground storage infrastructure. LNG tanks at European regasification terminals, which have around 6  bcm of total  capacity,  are  therefore  used  primarily  for  operational  balancing. Nevertheless, certain markets stand out. Spain has 2.2 bcm of LNG tank capacity, while the United Kingdom has 1.3 bcm of LNG tank capacity, relatively large when compared with their LNG demand. The reason for the comparatively larger storage capacities is because their underground storage capacity is limited. In the case of the  United  Kingdom,  the  infrastructure  also  supports  gas  security  in  northwest Europe  through  pipeline  interconnections  with  continental  Europe.  Together, Spain and the United Kingdom account for around 56% of Europe's total LNG tank storage capacity but only about 20% of LNG demand on the continent, reflecting their extensive, and at times underutilised, LNG import infrastructure.

In  some  cases,  underutilised  LNG  storage  tanks  are  used  by  third  parties  for commercial optimisation, reloading operations, or regional trading activities. For example, Indonesia's Arun LNG complex has four LNG storage tanks that were originally built to support LNG exports. They became partially idle after the terminal was converted into an import facility in 2015, and in 2021, TotalEnergies signed an agreement with the terminal owner to use two of Arun's four LNG storage tanks for  trading  and  portfolio  optimisation  in  the  Asian  LNG  market,  leveraging  the terminal's reloading infrastructure. Similarly, Spain's El Musel LNG terminal, which was completed in 2012 but was mothballed for a decade due to unfavourable market conditions, was restarted in 2023 as an LNG storage and reloading hub. By leveraging its available tank capacity, the facility now receives and reloads cargoes for redistribution to other European markets.

Under certain conditions, underutilised LNG tank capacity could also be mobilised as part of broader gas reserve arrangements. For example, countries with LNG storage  capacity  that  exceeds  domestic  operational  needs  could  host  LNG inventories  on  behalf  of  other  importing  markets.  Under  such  models,  LNG inventories could be rotated commercially during normal market conditions while

remaining  available  for  emergency  supply  in  the  event  of  supply  disruptions. Similar arrangements exist in oil markets, where IEA member countries can meet part of their minimum oil stockholding obligations through stocks held in another country, typically under bilateral government agreements. These arrangements can take the form of either direct ownership of stocks held abroad or ticketing arrangements, under which the ticket seller agrees to hold oil on behalf of the buyer in return for an agreed fee (see Section 7.1).

However, such arrangements would require sufficient reloading infrastructure to allow LNG to be re-exported to other destinations when needed, as well as thirdparty access to the LNG terminals hosting the relevant storage capacity. Of the approximately 50 bcm of onshore LNG tank capacity in operation at the end of 2024, only 14 bcm was located at terminals equipped with reloading infrastructure. Of this, less than 10 bcm was at terminals that also offer third-party access. Most of this capacity, 49%, is in Europe, led by Spain with around 2.2 bcm of capacity that combines reloading infrastructure and third-party access. Asia accounts for more than 80% of global LNG tank capacity, but only 47% of that capacity has both reloading infrastructure and third-party access, and Japan is the only country with  a  significant  LNG  tank  capacity  (more  than  3  bcm)  that  combines  these features. Asia's remaining such capacity is in Singapore (0.5 bcm), Thailand (0.4 bcm),  China  (0.3  bcm),  and  Indonesia  (0.2  bcm).  LNG  tank  capacity  with comparable features is negligible in the Americas and non-existent in the Middle East and Africa.

Figure 4.6 Top 10 countries by onshore LNG tank storage capacity, end of 2024

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from International Group of Liquefied Natural Gas Importers (2025), Annual Report 2025.

To  facilitate  such  arrangements,  governments  in  importing  countries  could encourage the development of reloading infrastructure and third-party access at a larger number of LNG terminals, particularly in Asia. Expanding these capabilities would  allow  a  greater  share  of  existing,  and  at  times  underutilised,  LNG  tank infrastructure to support supply security and enhance the strategic value of LNG storage assets without requiring major new investment. However, the relatively high capital cost of new LNG tanks and their limited volumetric capacity compared with underground storage mean that their role as large-scale strategic reserves is likely  to  remain  secondary.  Instead,  LNG  tanks  are  more  likely  to  serve  as supplementary reserve assets, complementing UGS  and other flexibility mechanisms in the global gas system.

## 4.3 LNG FSRU and FSU facilities

Floating storage and regasification units have emerged over the past two decades as a flexible alternative to conventional onshore LNG import terminals, particularly for countries seeking rapid access to LNG imports without the long lead times and relatively high capital costs associated with onshore facilities. FSRUs are either purpose-built vessels or converted LNG  carriers equipped with onboard regasification  systems.  LNG  is  stored  in  the  vessel's  cryogenic  tanks  and vaporised  on  board  before  being  sent  out  via  high-pressure  pipelines  to  the onshore transmission grid.

At the end of 2024, the global FSRU fleet comprised 52 operational vessels, with another  four  units  under  construction.  Most  modern  FSRUs  have  storage capacities  of  around  150  000  to  170  000  cubic  metres  of  LNG,  less  than  the storage capacity typically found at large onshore regasification terminals, which often feature two or more tanks of 160 000 to 200 000 cubic metres. The total LNG storage capacity of the FSRU fleet is approximately 7.7 million cubic metres of LNG, equivalent to around 5 bcm of natural gas in gaseous form. This is modest relative  to  UGS  capacity,  which  was  around  445  bcm  globally,  or  even  to cumulative onshore LNG tank capacity, which was around 50 bcm, at the end of 2024. Therefore, in volumetric terms, FSRUs do not represent a major storage resource on a global scale. Instead, the technology's main advantage lies in rapid deployment and operational flexibility.

Figure 4.7 Distribution of FSRU capacity by region, end of 2024

<!-- image -->

Source: IEA analysis based on data from International Gorup of Liquefied Natural Gas Importers (2025), Annual Report 2025.

While  conventional  onshore  LNG  import  terminals  typically  require  four  to  five years to build, FSRU-based terminals can be developed on significantly shorter timescales.  Where  suitable  port  infrastructure,  berthing  facilities,  and  nearby transmission grid connections already exist, and an FSRU vessel can be chartered from the existing fleet, an import terminal can be brought online within 12 months or less. Recent examples of such accelerated deployment completed in less than a year include Germany's Wilhelmshaven terminal, Italy's Piombino LNG terminal, and the Netherlands' Eemshaven terminal, all of which were completed during the 2022-2023 energy crisis. Earlier examples include Egypt's FSRU in Ain Sokhna in 2015, the country's first, which was completed in less than a year to address acute domestic gas shortages.

Where port and pipeline infrastructure must be constructed from scratch or no suitable  FSRU  vessel  is  readily  available,  total  project  lead  times  are  longer, typically  around  three  to  three-and-a-half  years.  Newly  built  FSRUs  generally require 30 to 36 months to construct and are mainly built in Korean shipyards, although a limited number have also been built in China. Conversion of an existing LNG  carrier  into  an  FSRU  -  a  process  carried  out  primarily  in  Singaporean shipyards - usually takes 18 to 24 months. Shore-side infrastructure can be built concurrently in order to accelerate the process, including mooring and berthing facilities,  high-pressure  gas  pipelines  connecting  to  the  transmission  network, metering stations, gas treatment facilities, emergency shutdown systems, and, in some cases, dredging works and breakwater reinforcement.

FSRU projects typically require lower upfront capital investment than conventional onshore regasification terminals. As of 2025, the cost of a newly built FSRU vessel was in the range of USD 300 million to USD 420 million, while the total cost of

converting an existing LNG carrier into an FSRU, including the cost of acquiring the  vessel  but  excluding  the  jetty  and  marine  infrastructure,  was  reported  at around USD 200 million. The cost of associated onshore and marine infrastructure varies widely depending on site conditions. For projects with well-developed port and pipeline infrastructure, additional investment can be less than USD 100 million,  whereas  greenfield  developments  requiring  extensive  marine works and new transmission connections can be several times higher.

Unlike  onshore  regasification  terminals,  FSRU  vessels  can  be,  and  often  are, chartered  from  specialised  fleet  operators  for  fixed  periods,  with  charter  rates ranging  between  USD  100  000  and  USD  300  000  per  day  in  recent  years, depending on market conditions, vessel specifications, and contract terms. This structure allows importers to convert what would otherwise be large upfront capital expenditure into operating expenditure (amounting to between USD 35 million and USD 70 million per year at prevailing charter rates). By contrast, a conventional onshore  LNG  import  terminal  with  storage  tanks  and  regasification  facilities typically requires total capital investment in the range of USD 500 million to more than USD 1 billion.

FSRUs can also be redeployed when no longer needed, reducing the risk of longterm  infrastructure  lock-in  compared  with  permanent  onshore  terminals.  This flexibility was recently demonstrated at France's Le Havre terminal, for example, where  an  FSRU-based  facility  was  commissioned  in  2023  to  reinforce  the country's gas safety net. However, as the acute phase of the 2022-2023 energy crisis passed and utilisation remained limited from 2024 onward, the terminal's operator decided to demobilise the FSRU vessel following a 2025 court ruling that confirmed that the facility was no longer needed and concurrently revoked the terminal's authorisation. The vessel is currently operating as a conventional LNG carrier,  and  the  terminal  was  dismantled  in  early  2026.  Similar  redeployments have been observed in several other markets in recent years, particularly where floating units were installed as emergency or transitional solutions.

Although FSRUs have higher per-unit operating costs than permanent onshore infrastructure  and  offer  less  storage  capacity,  they  have  nonetheless  been routinely deployed as backup or peak-supply facilities. In Brazil, for example, they were  deployed  to  supply  gas-fired  power  plants  during  periods  of  low  hydro availability,  and  in  the  United  Arab  Emirates  they  are  used  to  support  power generation during the peak summer months.

In other cases, floating terminals have been backed by public policy objectives related to energy security. Lithuania's FSRU terminal, which began operations in 2014, was initially developed, and publicly funded, as a strategic diversification tool before it started to receive regular deliveries from 2016. More recently, Ireland has advanced plans for a state-backed FSRU as part of its emergency gas supply

framework (see Section 6.4), and New Zealand is considering the development of a new LNG import terminal that includes FSRU-based designs to mitigate dry-year power risks. In such publicly supported schemes, the vessel is often state-owned or secured under long-term arrangements, and the cost of the project is justified not  purely  on  commercial  throughput  considerations,  but  as  insurance  against potentially far more costly economic disruptions in the event of a supply shortfall. FSRUs are not inherently suited to seasonal or strategic storage. Due to their limited  tank  capacity,  their  primary  value  lies  in  providing  LNG  import  and regasification capability at relatively high send-out rates, typically around 15 mcm/d or roughly 5 bcm/yr, rather than in providing extended reserve capacity.

Another key constraint on wider FSRU deployment is the limited availability of vessels in the near term. Of the more than 50 units in operation today, the vast majority are tied to medium- or long-term charters, leaving only a small number of ships potentially available for near-term redeployment. At the same time, the order book for newly built FSRUs remains limited, with only a handful of vessels under construction.  As  a  result,  global  floating  regasification  capacity  cannot  be expanded rapidly beyond the existing fleet without new investment commitments. Conversion of conventional LNG carriers into FSRUs remains technically feasible and has historically played an important role in expanding floating regasification capacity. However, conversion projects face several constraints, including the age and technical suitability of candidate vessels, as well as limited shipyard capacity, particularly in specialised yards, mainly in Singapore, that can install regasification modules.

FSUs represent a similar but distinct configuration compared with FSRUs. In an FSU-based  import  terminal,  the  vessel  provides  LNG  storage  only,  while regasification equipment and the associated high-pressure send-out systems are located onshore, at a jetty or on a separate offshore installation. Examples of this model include the Hidd terminal in Bahrain, the Melaka terminal in Malaysia, and the  Delimara  terminal  in  Malta.  Converting  an  LNG  carrier  into  an  FSU  is technically  less  complex and less costly than conversion into an FSRU, as no onboard regasification modules are required, and conversion costs typically range between USD 14 million and USD 20 million, in addition to the vessel's residual value  (see  Section  4.4).  At  the  same  time,  FSU-based  projects  require  more substantial shore-side investment in vaporisers, pumping systems, and utilities, which  can  offset  part  of  the  speed  and  cost  advantages  relative  to  FSRUs. Moreover,  because  regasification  infrastructure  is  fixed  onshore,  the  risk  of stranded assets may be higher if the facility is no longer required. As with FSRUs, expansion  of  the  FSU  fleet  through  LNG  carrier  conversion  is  subject  to constraints  related  to  vessel  availability, shipyard  capacity,  and  regulatory approvals. The number of operational FSUs remains limited at around 10 vessels globally, representing only a fraction of the already small FSRU fleet.

While FSRUs and FSUs have significantly lowered the barriers to entry into the LNG market, their role as physical reserve assets is inherently limited. Although FSRUs offer relatively high send-out capacity, which in some cases is comparable to  the  peak  withdrawal  rates  of  underground  storage  facilities,  their  onboard storage capacity is modest and generally sufficient for only several days to a few weeks of operation at full send-out rates. From a system flexibility perspective, an FSRU can resemble a fast-cycling storage asset if LNG cargoes are delivered and regasified  on  a  near  continuous  basis.  However,  unlike  UGS,  which  can accumulate  volumes  over  extended  periods  and  release  them  during  peak demand,  floating  terminals  provide  only  limited  buffering  capacity  and  are relatively expensive on a per-unit storage basis. Their systemic value therefore lies  less  in  stockholding  and  more  in  securing  access  to  global  LNG  supply, diversifying import channels, and providing rapid-response capacity in times of disruption. As such, they are complements to, rather than substitutes for, largescale seasonal or strategic storage infrastructure.

## 4.4 LNG floating storage on vessels

Floating storage - the use of vessels to hold energy commodities offshore or at anchor - is a widely used flexibility mechanism in oil markets but has historically played  a  much  more  limited  role  in  the  LNG  market.  LNG  held  'on  water'  is typically associated with commercial optimisation (for example, in anticipation of higher prices ahead of peak winter months), short periods of excess LNG supply, or terminal congestion, rather than deliberate stockpiling. Unlike FSUs, which are permanently  moored  assets  integrated  into  LNG  import  infrastructure,  floating storage in this context refers to conventional LNG carriers temporarily retaining cargoes while awaiting delivery.

## Floating storage as a temporary market-balancing mechanism

LNG  floating  storage  faces  several  technical  and  economic  challenges  that distinguish it from oil storage.

-  High  vessel  costs: LNG carriers  (LNGCs)  are  highly  specialised,  capitalintensive assets. Even in weak shipping markets, chartering LNG vessels for storage bears a significant cost. 7

7 The average construction cost of a standard 174 000 cubic metre LNGC was around USD 250 million in 2024, more than twice the cost of a very large crude carrier (VLCC), despite the latter being capable of transporting roughly three times as much fuel on an energy-equivalent basis. Daily spot charter rates for standard-size steam-turbine and tri-fuel diesel electric LNG carriers averaged around USD 23 000 and USD 43 000 in 2024, respectively, around 2.5 to 5 times higher than the average rate of a VLCC on an energy-equivalent basis.

-  Gas boil-off: LNG naturally evaporates over time. While modern vessels can reliquefy  boil-off  or  consume  it  as  fuel,  prolonged  storage  increases  either commodity losses or operational complexity. 8
-  Cargo quality changes: Extended storage can alter the composition of LNG through  the  so-called  ageing  (or  weathering)  process,  whereby  lighter chemical components in the gas boil off first, potentially resulting in off-spec cargoes. The extent of ageing varies across LNG sources, and tolerance for such deviations varies across terminals and among buyers.
-  Operational  and  regulatory  constraints: LNG  vessels  used  for  floating storage require continuous crewing and power supply, must comply with strict safety  and  regulatory  requirements,  and  may  face  limits  on  anchorage duration.

These constraints  mean that  LNG  floating  storage  is  best  suited  to  short-term buffering  rather  than  long-term  strategic  reserves.  While  traders  and  portfolio players routinely use floating storage to delay deliveries from shoulder seasons into peak demand periods, particularly when contango is present, 9  it is rarely used as a reserve mechanism for energy security purposes.

The cost of LNG floating storage - estimated as the shadow price of LNG carriers held idle at sea - is generally high and varies widely over time. The cost of LNG floating storage consists of two main components: vessel-related costs, including time charter or spot charter rates, and the opportunity cost of LNG lost through boil-off. 10

Vessel-related  costs  depend  chiefly  on  prevailing  charter  rates.  These  tend  to fluctuate widely on the spot market, although most LNG is transported under longterm charter contracts, typically at rates of around USD 70 000 to USD 90 000 per day. During balanced market conditions, such as in 2024-2025, monthly average spot LNG carrier charter rates ranged from USD 10 000 to USD 70 000 per day for standard tri-fuel diesel electric (TFDE) vessels. By contrast, during the tight shipping markets in 2021-2023, spot charter rates fluctuated between USD 30 000 and more than USD 300 000 per day on a monthly basis, averaging around three times higher than in 2024-2025.

8 Boil-off rates vary significantly by vessel design and type. The ageing fleet of steam-turbine LNG carriers have daily boiloff rates of around 0.15% of total cargo, while the most advanced ME-GI vessels equipped with full reliquefaction systems have boil-off rates of only 0.035% to 0.075% per day, around two to four times lower than those of steam turbine vessels. 9 Contango refers to a market structure in which futures prices are higher than the current spot price, creating an incentive to store gas or LNG and sell later. This price structure typically reflects expectations of tighter future supply, seasonal demand patterns, or storage-related constraints.

10 In addition to charter rates and the cost of boil-off gas, additional charges, such as fuel, insurance, and potential demurrage or terminal-related fees may apply, although these vary on a case-by-case basis.

The opportunity cost of boil-off gas depends on prevailing spot LNG prices, which have fluctuated over a similarly wide range since 2020, from around USD 2 to more than USD 50 per million British thermal unit (MBtu) on a monthly average basis.

Taken together, these two cost components suggest that the monthly cost of LNG floating storage rarely falls below USD 0.5 per MBtu and can at times reach or exceed USD 3 per MBtu, as was the case in late 2021 and late 2022. Over the 2021-2025 period, floating storage costs averaged more than USD 1 per MBtu per month.  Estimated  costs  are  somewhat  less  volatile  when  based  on  long-term charter  rates,  but  the  five-year  average  remains  broadly  similar,  at  just  over USD 1 per  MBtu  per  month.  On  a  commercial  basis,  these  costs  are  only sustainable for brief periods, when contango is sufficiently wide or the alternatives to floating storage are even costlier.

Figure 4.8 Estimated monthly cost of LNG floating storage

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from ICIS LNG Edge.

The  volumetric  'reserve'  capacity  that  LNG  floating  storage  can  provide  is relatively  limited,  and  any  estimate  of  this  volume  is  necessarily  imprecise. Indicators tracking LNG cargoes remaining at sea for more than 20 days provide a useful proxy for floating storage and delayed deliveries, although these cargoes are  typically  slow  steaming  towards  their  destination  rather  than  remaining stationary offshore. Under normal conditions, there is a structural baseline of LNG volumes on water associated with long transit times and logistical delays, rather than deliberate storage. This baseline volume is estimated to have increased from around 2 bcm in 2020 to around 4 bcm by 2025, reflecting the overall growth in LNG flows, longer average shipping distances, and increasingly complex trade patterns.

Figure 4.9 LNG on water for more than 20 days

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from Bloomberg.

Additional  LNG  volumes on top of this  baseline,  at  least  part  of  which  can  be classified as  floating storage, fluctuate widely over  time. However,  these incremental volumes reached or exceeded 3 bcm on very few occasions during periods of severe market dislocation, including in 2019, 2022, and 2023, when European  storage  sites  reached  near-full  capacity  ahead  of  the  withdrawal season, as well as during the 2020 Covid-19 crisis, when a combination of terminal closures,  falling  LNG  demand,  and  deliberate  efforts  by  at  least  one  major supplier,  Qatar,  to  avoid  production  curtailments  led  to  a  prolonged  period  of elevated LNG volumes parked on water.

These  episodes  demonstrate  that  floating  storage  can  expand  rapidly  when conditions  align,  but  such  expansions  have  historically  been  temporary  and market-driven, rather than the result of deliberate reserve building.

However, there is at least one recent case in which LNG floating storage was used for  an  extended  period  for  energy  security  purposes.  As  a  complement  to Singapore's Standby LNG Facility (see Section 6.4), Singapore LNG Corporation, the designated manager of the Standby LNG Facility (SLF) at the time, chartered an  LNG  carrier  alongside  an  FSRU  for  floating  LNG  storage.  These  vessels remained  largely  in  Singapore  waters  for  approximately  12  months,  between March 2022 and March 2023, and 8 months, between August 2022 and April 2023, providing an additional buffer during a period of heightened global market stress.

## Repurposing LNG carriers for strategic floating storage

The current LNG carrier fleet offers potential for more strategic uses of floating storage capacity. At the end of 2025, the active fleet of conventional LNG carriers comprised roughly 800 vessels, excluding small-scale carriers, bunkering vessels,

FSRUs, and FSUs. Of these, around 200 vessels were ageing steam turbinedriven LNG carriers, with a median age approaching 20 years. This segment of the fleet is highly fuel-inefficient, increasingly challenged  by  existing and forthcoming environmental regulations, and therefore faces accelerated retirement and demolition in the foreseeable future.

Over the past five years, an average of eight steam turbine LNG carriers per year have been laid up (i.e. withdrawn from active service but maintained in operational condition) and an average of five vessels per year have been scrapped, often from the  pool  of  previously  laid-up  ships.  The  pace  of  retirements  could  accelerate further as a wave of modern LNG carriers enters service to support the next phase of LNG liquefaction capacity expansion in the second half of the decade. Among the remaining active steam turbine fleet, around 50 vessels appear to be inactive (i.e. not currently under contract or routinely delivering cargoes), making them the most immediate candidates for retirement. The remainder are committed under existing charters, but only around 65 vessels could plausibly extend beyond 2030, leaving the rest highly vulnerable to removal from the fleet. A similar fate may also await  a  handful  of  older  vessels  propelled  by  dual-fuel  diesel  electric  (DFDE) engines that exceed 20 years of age.

In some cases, these older vessels slated for demolition could provide emergency storage capacity instead. Governments could, for example, purchase or charter ageing LNG carriers at close to scrap value and convert such vessels into FSUs or  incentivise  shipowners  to  delay  demolition  and  maintain  selected  vessel  in operational condition for future emergencies.

The market value of an ageing LNG carrier is close to scrap value, typically in the range of USD 15 million to USD 20 million, while conversion to an FSU would cost another USD  14  million to USD  20  million, depending  on  the  technical specification. 11 A converted FSU is still four to five times cheaper than constructing a new onshore LNG storage tank of similar capacity, which is estimated to cost between USD 150 million to USD 200 million.

The full cohort of LNG carriers at risk of retirement worldwide represents around 25 bcm of potential storage capacity, in natural gas equivalent terms. In practice, however, only a fraction of this capacity is likely to be suitable for strategic floating storage  in  the  near  term,  due  to  existing  charter  commitments,  operational constraints  (such  as  high  boil-off  rates  in  the  case  of  LNG  carriers),  high maintenance  requirements,  and  compatibility issues with modern  terminal infrastructure.

11 On this basis, the implied breakeven charter rates for ageing LNG carriers and converted FSUs are around USD 10 000 to USD 15 000 per day and USD 20 000 to USD 30 000 per day, respectively, assuming a 9% required rate of return and a five-year payback period.

## 5. Flexible commercial options for LNG

Flexible commercial arrangements are a second, critical pillar for building security buffers  against  unexpected  supply  disruptions  and  episodes  of  extreme  price volatility. These  include  more  flexible  traditional  LNG  contracts,  commercial innovation such as seasonal and call option-type LNG contracts, joint procurement and  portfolio  optimisation  arrangements,  and  physical  LNG  swaps  that  allow cargoes to be redirected more quickly during supply disruptions. Such commercial flexibility complements rather than replaces physical reserve assets. While physical storage  provides  the  gas  inventory  needed  to  withstand  supply  disruptions, contractual flexibility improves the allocation of available gas across markets and over time. By strengthening the ability of markets to adjust quickly to supply and demand shocks, greater flexibility can help dampen price swings and reduce the risk of physical shortages, while spreading the burden of adjustment more evenly across importing markets and regions. But such flexibility is not free, and the cost of having more options is reflected in commercial arrangements.

This  chapter  focuses  on  the  global  LNG  market,  which  provides  the  primary mechanism linking the world's main net importing regions, and allows gas flows to respond to shifting market signals across basins. While developments in pipeline gas  trade  can  influence  LNG  flows  indirectly,  pipeline  gas  remains  inherently constrained by fixed infrastructure and geography, meaning it is limited in its ability to deliver significant global rebalancing during periods of market stress. Moreover, in Europe, the flexibility of pipeline gas contracts was substantially expanded in the 2010s - through the renegotiation of legacy contracts that resulted in changes that mainly benefitted buyers - leaving relatively limited scope for further gains. In most Asian economies, by contrast, pipeline gas plays little or no role in the supply mix, apart from China, where buyer leverage is already reflected in contractual terms and, at times, in actual buyer behaviour. Against this backdrop, LNG stands out as the  segment of gas trade where additional commercial flexibility can still  deliver further improvements in market resilience in both Europe and Asia and therefore remains the focus of the analysis.

Since the early days of LNG trade in the 1960s, it has evolved from a rigid, point-topoint business model, characterised by inflexible long-term agreements with fixed volumes, fixed destinations, and limited scope for periodic adjustment. Today, it is a more flexible and increasingly global commodity market. This transition gained momentum  in  the  early  2000s,  driven  by  the  liberalisation  of  gas  markets,  the emergence of LNG portfolio players, and the availability of more flexible sources of LNG supply, for example, in Trinidad and Tobago and Equatorial Guinea.

Over the past decade, the pace of change has accelerated markedly, driven in particular by the rise of destination-flexible LNG exports from the United States and by the widening range of companies acting as portfolio players. Previously dominated by traditional oil majors that pioneered the model, this group of portfolio players  now  includes  trading  houses,  major  utilities,  state-controlled  exporters, and independent project developers.

Between 2016 - the year of the first publication of the IEA's Global Gas Security Review tracking LNG contract s - and 2024, the share of destination-flexible LNG contracts increased from 29% to 45% of total contracted volumes, largely driven by the expansion of LNG exports from the United States. This share is set to rise further and could reach around 52% by 2030, reflecting both the gradual expiry of destination-fixed legacy contracts and the continued growth of destination-flexible US LNG supply.  In  parallel,  the  share  of  LNG  procurement  contracts  held  by portfolio players  has  also  expanded  significantly,  rising  from  26%  of  total contracted volumes in 2016 to around 39% by 2024. Based on existing contracts, this  share  is  expected  to  increase  further  to  around  45%  by  2030,  potentially enabling  greater  flexibility,  pricing  diversity,  and  supply  optionality  for  LNG importers over the medium term.

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from IEA (2025), Gas 2025,

Despite this progress, important sources of contractual inflexibility remain in the existing LNG contract portfolio, notably in relation to:

-  Destination  restrictions ,  which  limit  buyers'  ability  to  redirect  cargoes  in response to changing market conditions and price signals, thereby constraining cross-regional arbitrage and market efficiency.

-  Volume-related provisions , including minimum take-or-pay (TOP) volumes, upward  and  downward  quantity  tolerances  (UQT  and  DQT)  and  make-up clauses, which can restrict buyers' ability to adjust contracted volumes in line with short-term demand fluctuations.
-  Profit  sharing  and  seller  consent  requirements , which  can  weaken incentives to resell LNG by reducing the economic upside of diversions or by introducing  administrative  and  information-sharing  burdens,  thereby  limiting the effective use of contractual flexibility in practice.

## 5.1 Existing LNG contracts

Long-term contracts remain a defining feature of global LNG trade and are likely to continue playing a central role, as they underpin investment in new liquefaction capacity by providing revenue certainty and supporting project financing. As of 2025,  around  60%  of  global  LNG  trade  was  conducted  under  long-term agreements, defined as contracts with a duration of 10 years or longer.

## The evolution of LNG contract flexibility

Until the 2010s, LNG trade was still largely structured around rigid point-to-point arrangements;  long-term  contracts  typically  included  provisions  that  limited buyers'  flexibility,  especially  in  relation  to  destination  and  TOP  volumes.  Such contractual structures were particularly prevalent in Asia, where more than 70% of total LNG imports in 2025 were supplied under long-term contracts and where buyers historically prioritised security of supply and stable delivery arrangements. This  was  reinforced  by  the  bilateral  nature  of  LNG  procurement  and  the  longstanding  commercial  relationships  between  buyers  and  sellers,  which  shaped contracting practices over several decades.

Over  the  course  of  the  last  25  years,  competition  authorities  in  key  importing regions have taken steps, with varying degrees of stringency, to remove or soften restrictive non-price provisions in LNG contracts to promote greater competition and market flexibility. These  efforts have focused mainly on destination restrictions, profit-sharing mechanisms, and seller consent requirements, which had  been  widely  used  in  earlier  contracts  to  limit  cross-regional  arbitrage  and preserve market segmentation. Progress differs by region, but overall contractual flexibility  has  improved  while  there  is  less  tolerance  for  clauses  that  constrain diversions and resale.

In the European Union, the phasing out of destination restrictions has been closely linked  to  market  liberalisation  and  the  enforcement  of  EU  competition  policy, notably  under  Articles  101  and  102  of  the  Treaty  of  the  Functioning  of  the European Union and its predecessor treaties. Early enforcement action included proceedings against Norwegian gas suppliers, which led to a commitment in 2002 by  Statoil  and  Norsk  Hydro  to  refrain  from  introducing  territorial  restrictions,

including destination clauses, in their gas supply contracts. This was followed by a  series  of  antitrust  investigations  targeting  territorial  and  resale  restrictions  in long-term gas and LNG contracts, including the 2002 settlement with Nigeria LNG (focused on LNG), the 2003 settlement involving Eni and Gazprom (focused on pipeline gas), and the 2007 Sonatrach decision, which required the deletion of territorial restrictions and limited the use of profit-sharing mechanisms to delivered ex ship (DES) contracts, where ownership and risk are transferred at the delivery point (covering both pipeline gas and LNG).

More  recently,  the  European  Commission's  2015  antitrust  investigation  into Russia's  Gazprom  (primarily  focused  on  pipeline  gas  contracts)  resulted  in  a commitment  decision  in  2018,  under  which  Gazprom  made  legally  binding commitments to address the Commission's competition concerns. That decision required Gazprom to remove contractual barriers to the free flow of gas, including destination restrictions, in Central and  Eastern Europe. By contrast, the Commission's  proceedings  against  Qatar  Petroleum,  launched  in  2018  and focused on LNG  destination restrictions, were closed in 2022  after the Commission  concluded  that  the  evidence  did  not  confirm  its  initial  concerns. Although these cases targeted specific suppliers, and often focused primarily on pipeline gas contracts, the underlying principles have shaped expectations for gas and LNG contracting practices more broadly among market participants. As such, after  more  than  two  decades  of  enforcement,  destination  clauses  have  been progressively eliminated in European gas supply contracts and are now generally considered incompatible with EU competition law. The Commission's approach has also significantly narrowed the scope for profit-sharing mechanisms.

Elsewhere, the Japan Fair Trade Commission (JFTC) published the results of a sector  inquiry in 2017  assessing  destination  clauses  and  other  restrictive provisions  in  long-term  LNG  contracts.  The  JFTC  concluded  that  destination restrictions  and  profit-sharing  requirements  in  so-called  free-on-board  (FOB) contracts are highly likely to raise concerns under Japan's Antimonopoly Act, as they can limit competition by preventing resale and reducing market liquidity. For DES  contracts,  the  JFTC  took  a  more  nuanced  view.  They  determined  that destination restrictions,  profit-sharing,  and  seller  consent  requirements  may  be justifiable given the seller's responsibility for arranging shipping and delivery. But they also emphasised that such clauses could still raise competition concerns if they go beyond what is necessary for operational purposes or effectively prevent redirection and resale in practice. The JFTC noted as well that overly strict and unilateral application of TOP provisions may violate the Antimonopoly Act where suppliers have already recovered their initial investment. While non-binding, the JFTC report prompted market participants to review their contracting practices, including existing legacy contracts. Although there are no publicly known cases of the  JFTC  investigating  specific  LNG  sales  contracts,  the  report's  findings nonetheless sent a clear signal to market participants to phase out problematic clauses from their contract portfolios (see Box 2 for details).

## Box 5.1   Japan's 2017 JFTC survey on LNG contracts

The Japan Fair Trade Commission published its Survey on LNG Trades in June 2017, based on information from LNG market participants concerning the use of destination clauses and other resale provisions in long-term LNG contracts. The assessment ultimately determined that the assumption that flexible contracts incur higher prices was not necessarily correct, as outlined in our overview below.

The JFTC's central competition concern was that destination restrictions and profitsharing clauses can have foreclosure effects, eliminating opportunities for LNG buyers  to  enter  the  market  as  suppliers  through  resale  and  reducing  trading opportunities  overall,  thereby  limiting  market  liquidity.  The  JFTC  assessed  that such clauses, if lacking necessity and rationality, could violate Japan's Antimonopoly Act.

The investigation highlighted the view that LNG reloading (i.e. unloading a cargo at  the  designated  destination  and  immediately  reloading  the  same  LNG  for  reexport to the desired destination) is not an effective alternative to diversion and resale  rights,  as  it  imposes  additional  costs  and  is  subject  to  infrastructure constraints.

The  JFTC  differentiated  its  assessment  based  on  delivery  terms.  For  FOB contracts, where ownership and risk are transferred to the buyer at the loading point,  the  JFTC  found  that  destination  restrictions  and  profit-sharing  clauses generally lack necessity and rationality, and therefore likely to violate antitrust laws. This reflects the principle that buyers bearing shipping and market risk should be able to optimise the placement of the cargo after the transfer of ownership.

For  DES  contracts,  the  JFTC  recognised  a  certain  degree  of  necessity  and rationality for destination restrictions and  profit-sharing clauses,  given  that ownership and risk remain with the seller until unloading and that such provisions may  help  recover  costs  associated  with  destination  changes.  However,  it  also emphasised  that  such  clauses  could  still  raise  competition  concerns  where diversion requests are unduly denied or where sellers attach restrictive conditions to diversion consent, effectively limiting resale. The JFTC noted that profit-sharing mechanisms  could  be  problematic  if  they  are  based  on  gross  rather  than  net profits, or if key parameters such as the calculation method and distribution ratio are  not  clearly  defined  in  advance,  as  this  may  discourage  resale  and  restrict market  participation.  The  JFTC  also  raised  concerns  about  requirements  to disclose detailed information on resale destinations and profit breakdowns in profitsharing arrangements.

The investigation also considered other standard contract features. For example, the report recognised the role of TOP arrangements in recovering initial investment in  new  LNG  projects.  But  it  also  noted  that  overly  strict  TOP  terms  imposed unilaterally  on  buyers  could  constitute  a  potential  abuse  of  market  power  and

violate  antitrust  laws,  particularly  where  suppliers  have  already  recovered  their initial investment.

It is often argued that flexibility comes at a price, and that relaxing overly restrictive provisions in existing contracts would lead to higher contract prices. However, the JFTC's systematic analysis found no evidence that long-term contracts containing more restrictive provisions on destination clauses, profit-sharing arrangements, or TOP obligations were associated with lower contract prices than contracts with more flexible terms.

While the JFTC's report is understood to be non-binding, it has nonetheless sent a clear policy signal that Japanese buyers should avoid anti-competitive clauses in  new  or  renewed  LNG  contracts  and  should  review  restrictive  provisions  in existing LNG SPAs.

It remains to be seen to what extent the JFTC could enforce a ruling if it determined that a particular LNG sales contract violates antitrust laws. However, even without issuing rulings on specific contracts, the JFTC's continued expression of its views in reports  can  significantly  influence  market  practices  by  strengthening  the negotiating position of buyers and encouraging more balanced contract terms.

LNG contracts  remain  confidential,  and  detailed  information  such  as  on  pricerelated  terms  is  rarely  disclosed.  Nevertheless,  the  limited  available  evidence suggests that some restrictive practices persist in  existing  legacy  contracts.  In Japan, the Japan Organization for Metals and Energy Security (JOGMEC), which is tasked with monitoring LNG contract terms, found that destination restrictions either  through  the  specification  of  destination  ports  or  through  profit-sharing requirements on diverted cargoes - still applied to 40% of contracted volumes under long-term LNG contracts in 2024. This represents a notable reduction from 57%  in  2020,  when  the  first  survey  was  published,  but  the  remaining  share appears relatively  high  considering  the  JFTC's  stated  preference  against  such clauses.  Most,  if  not  all,  of  these  restrictions  are  likely  concentrated  in  DES contracts, where such provisions may be justifiable. However, there is no available information to assess whether their application is necessary and reasonable in the remaining legacy contracts in Japan.

The Korea Fair Trade Commission has also examined destination restrictions in LNG  contracts,  including the possibility of investigating resale limitations, signalling to market participants the undesirability and potential scrutiny of such restrictions. However, no formal investigation has been reported to date.

## Remaining flexibility constraints in legacy LNG contracts

The above assessments point to the need for a careful and differentiated approach to addressing remaining inflexibilities in legacy LNG contracts. Where destination restrictions, profit-sharing clauses, and seller consent requirements persist in FOB contracts, they are increasingly difficult to justify  on  operational  grounds.  Such provisions may be challenged under existing competition rules in liberalised gas markets, addressed through arbitration, or renegotiated through standard price review  mechanisms  or  other  contract  reopener  clauses  included  in  most  LNG sales purchase agreements (SPAs).

Legacy DES  contracts present a more complex challenge for flexibility enhancements. Fixed destinations (or a limited list of permitted delivery points within the target market) were historically acceptable for many traditional Asian buyers. In the past, limited market liberalisation in Asian gas markets meant that buyers often had predictable domestic supply obligations, faced limited competition, and had little or no global trading capability. As a result, their trading needs remained relatively  modest,  and  they  were  therefore  generally  willing  albeit reluctantly - to accept fixed destination clauses.

While these conditions have weakened or disappeared in most LNG importing countries, and restrictive destination and profit-sharing clauses have likely been largely phased out of FOB contracts, many legacy DES contracts still reflect earlier market  realities  and  have  not  been  uniformly  challenged  or  renegotiated. However,  even  where  DES  contracts  remain  commercially  preferred,  rigid destination provisions have become increasingly outdated. In many cases, they could be amended within existing legacy contracts, justified by evolving market conditions and, where relevant, the guidance of competition authorities. Where destination terms are narrowly limited to a single terminal or a small number of ports within the destination market, the list of permitted delivery points could be expanded if agreed by the seller, for example to all terminals within the importing country or, where applicable, to a broader regional market (such as the JKTC market in Asia encompassing Japan, Korea, Chinese Taipei, and China). In DES contracts,  seller  consent  for  diversions  is  often  unavoidable  given  the  seller's responsibility for shipping and delivery logistics, but procedures can be streamlined, for example through time-bound response requirements and deemed consent provisions, under which diversion requests are automatically approved if the seller does not respond within a specified period.

Profit-sharing  mechanisms  may  be  more  defensible  in  DES  contracts  where diversions  impose  additional  operational  costs  on  the  seller.  In  principle,  welldesigned profit-sharing clauses can support efficient cargo diversions and lead to commercially efficient outcomes. In practice, however, there are few examples of profit  sharing  being  used  to  recover  the  seller's  additional  operating  costs.

Replacing profit-sharing formulas with a transparent fixed diversion fee could, in theory, preserve cost recovery while reducing administrative burdens, limiting the need for disclosure of commercially sensitive information and avoiding disputes linked to complex and often ambiguous calculation methodologies. It could also provide incentives to actively consider and implement resales, thereby supporting a more efficient allocation of LNG across markets. However, fixed diversion fees can be similarly difficult to establish in practice and are not widely used today in LNG markets.

TOP provisions, including minimum TOP volumes and DQT terms, are standard features of long-term LNG contracts. Compared with destination-related clauses, they are typically more difficult for sellers to revise. This is particularly true where contracts underpin project-financed liquefaction facilities, as lenders may restrict amendments that weaken revenue certainty.  Buyers  also  have  a  more  limited basis  to  challenge  such  provisions,  given  their  established  role  in  supporting investment in LNG supply. The JFTC noted in its 2017 report that sellers who have fully  recovered  their  initial  investment  may  violate  antitrust  laws  if  they  impose overly  strict  TOP  obligations  on  buyers.  In  practice,  negotiations  to  increase volumetric flexibility  are  possible,  but  they  often  require  buyers  to  compensate sellers for revising previously agreed volume commitments, for example through upward price adjustments, higher contracted volumes, or an extension of contract duration.  For  contracts  approaching  expiry,  particularly  those  linked  to  older legacy plants, offering a contract extension in exchange for more flexible terms, including on TOP and DQT provisions, can provide a viable pathway to phase in greater flexibility. In cases where buyers place a high value on additional volume flexibility  within  an  existing  contract,  the introduction  of  a  fixed  cancellation  fee could  also  be  considered,  although  this  may  turn  out  to  be  a  costly  option  for buyers.

Another  potential  area  of  concern  relates  to  possible  imbalances  in  cargo cancellation penalties between buyers and sellers. Evidence from recent market developments  suggests  that  such  asymmetries  can  exist  in  practice.  During Pakistan's energy crisis in 2022, for example, several contracted LNG cargoes were cancelled by suppliers, reportedly subject to penalties as low as 30% of the cargo value in cases of 'failure to deliver', while buyers are typically required to pay 100% of the contract price in the event of their 'failure to take' contracted volumes  outside  the  standard  downward  quantity  tolerance  ranges.  Such asymmetric provisions may create incentives for sellers to cancel deliveries and divert cargoes when spot market prices substantially exceed contract prices. In principle, contractual arrangements that value undelivered cargoes at prevailing market  prices  rather  than  fixed  contractual  penalties  could  help  mitigate  such incentives, although designing appropriate mechanisms is more complex in LNG markets given the potential divergence between spot LNG prices and contract

pricing  formulas.  To  the  extent  that  such  imbalances  persist  in  existing  legacy contracts, they may raise concerns about fairness and, if they result from an abuse of market power, warrant the attention of competition authorities.

## Balancing flexibility and contractual stability

Revising  existing  contracts  can  also  have  broader  implications  for  buyer-seller relations, investment incentives and, ultimately, supply security. In most cases, existing LNG contracts are private commercial arrangements, limiting the scope for direct government intervention beyond the application of competition law and established  legal  frameworks.  Therefore,  buyers'  desire  for  greater  flexibility needs to be carefully balanced against these broader considerations, ensuring that stable contractual relationships are maintained and that any revisions remain consistent with established legal frameworks and norms. Nevertheless, nearly 10 years after the landmark 2017 JFTC report, the continued presence of restrictive and potentially competition-distorting provisions in legacy LNG contracts warrants renewed  scrutiny and  more  systematic monitoring across LNG  importing countries, not only in Japan.

## 5.2 New LNG contracts

Signing  new  LNG  contracts  creates  opportunities  for  buyers  to  incorporate flexibility-enhancing  provisions.  This  can  help  optimise  LNG  trade  flows  under normal market conditions, while improving the ability of LNG volumes to respond quickly in periods of market stress.

At least four factors are creating new opportunities to secure more flexible LNG contracts going forward, which we will explore in depth in this section:

-  Growing volumes of destination-flexible LNG supply from the United States.
-  The expiry of legacy contracts.
-  The depreciation of legacy LNG projects.
-  Increasing volumes of unsold LNG held by portfolio players.

## Growing LNG supply from the United States

The rapid ramp-up of LNG exports from the United States since 2016 has marked a major shift in global LNG market flexibility. US LNG contracts generally do not include destination or resale restrictions, allowing cargoes to be redirected freely in response to market signals. In addition, US LNG offtakers retain the ability to cancel cargoes with relatively short notice, providing far greater downward volume flexibility  than  is  typically  available  in  other  long-term  LNG  contracts.  Both  the destination  and  downward  volume  flexibility  of  US  LNG  have  been  clearly

demonstrated in recent years. During the 2022-2023 energy crisis, for example, US LNG played the single largest role in bridging Europe's supply-demand gap, with more than 40 bcm of US-sourced LNG redirected to the European market in 2022, mainly from Asia. The downward volume flexibility of US LNG was also evident during the COVID-19 crisis in 2020, when around 170 US LNG cargoes were  cancelled  and  US  liquefaction  utilisation  rates  fell  sharply,  at  one  point dropping to around 30% at the height of the demand shock in mid-2020.

Looking ahead, US liquefaction capacity is projected to increase substantially,  from  around  150  bcm  at  the  end  of  2025  to nearly 300 bcm  by 2030,  based  on projects that have already reached a final investment decision.  A  further  increase to over 3 5 0 bcm is expected in the early 2030s, once all projects currently under construction become fully operational. While most operational  capacity  is  contracted to long-term offtakers, about 40% (more than 50 bcm) of the capacity currently under construction remains uncontracted, creating further  scope  for  new  long-term  agreements  on  flexible  terms.  However,  project developers often retain a  share  of  volumes  for  spot  and  short-term  sales,  allowing them to  capture  the  potential upside from market volatility. As a result, while a large share of future US liquefaction  capacity  is  expected  to  be  contracted  under  longterm  SPAs,  it  is  unlikely that all volumes will be committed on a long-term basis.

## Expiring legacy contracts

Global LNG supply has expanded significantly over the past several decades. With close  to  600  bcm  of  LNG  traded  in  2025,  the  market,  historically  underpinned largely by long-term contracts, has reached a scale at which a sizeable volume of LNG tied to legacy contracts expires each year.

According to the IEA's in-house database, LNG contracts covering around 120 bcm of primary LNG supply (sourced directly from production projects rather than supplier portfolios) are set to expire over the next five years, rising to more than 270 bcm over the next decade. The largest share of expiring volumes is linked to projects  in  the  Middle  East,  followed  by  Asia  Pacific,  where  LNG  SPAs  have historically  been  less  flexible.  As  a  result,  close  to  60%  of  expiring  contract volumes  are  destination-fixed  DES  agreements,  although  detailed  flexibilityrelated  provisions,  such  as  diversion  rights,  profit-sharing  arrangements,  and seller consent requirements, are typically not publicly disclosed.

Figure 5.2 Expiration of LNG contracts in effect in 2025

<!-- image -->

Expiring legacy contracts create a sizeable opportunity for buyers and sellers to recontract LNG on more flexible terms. In many cases, the underlying liquefaction projects will have largely or fully recovered their capital investments and repaid their  debt,  and  thus  can  offer  shorter  contract  durations,  lower  prices,  and enhanced flexibility, at least to the extent that feed gas supply can be sustained. Offering to extend existing contracts with ageing legacy plants in exchange for greater flexibility can represent a strong negotiating lever for buyers. In practice, however, contract negotiations are typically approached holistically, and flexibility provisions  may  sometimes  be  traded  away  in  favour  of  lower  pricing  or  other prioritised  contract  attributes.  On  the  other  hand,  if  sellers  refuse  the  buyer's preference for FOB delivery and insist on DES terms during SPA negotiations or renegotiations,  such  practices  would  warrant  careful  scrutiny  by  competition authorities,  as  it  could  amount  to  imposing  destination  restrictions  in  disguised form, especially if the seller holds a dominant position in the relevant market.

## Depreciated legacy plants

LNG liquefaction projects are highly capital-intensive assets, typically developed based on long-term SPAs that underpin investment decisions and facilitate access to financing. Historically, many initiatives have relied on project finance structures, with lenders requiring stable and predictable cash flows to support debt service. This has contributed to the widespread use of long-term LNG contracts with TOP provisions  requiring  relatively  rigid  volume  commitments  and  offering  limited flexibility, effectively allocating project and price risk to developers while placing volume risk largely on buyers. Contract durations have often been aligned with financing tenors, which typically range from around 15 to 20 years, reflecting the time needed to repay debt and recover upfront capital expenditure.

Once a liquefaction plant has repaid its debt and recovered its initial investment typically  after  15  to  20  years  of  operation  -  the  commercial  rationale  for  strict contractual rigidities diminishes. At this stage, sellers may have greater scope to offer shorter contract durations and more flexible volume and destination terms to gain competitive advantage, particularly where the plant continues to benefit from established infrastructure and relatively low operating costs. However, pricing and contractual  outcomes  remain  influenced  by  prevailing  market  conditions,  and there  is  no  guarantee  that  such  flexibility  will  materialise  in  practice.  A  recent survey  of  Japan's  long-term  LNG  contract  portfolio  by  JOGMEC  indicates,  for example, that TOP clauses still apply to more than 90% of Japan's contracted LNG volumes, according to data from the 2025 fiscal year. This remains true even though around half of global LNG export capacity - and more than 50% of the capacity in countries supplying LNG to Japan in 2025 - appears to be largely depreciated.

In 2025, around 335 bcm (49%) of global liquefaction nameplate capacity and an estimated 250 bcm (43%) of actual LNG output came from plants that were at least 15 years old. The corresponding figures for plants older than 20 years were approximately  200  bcm  (29%)  of  nameplate  capacity  and  135  bcm  (23%)  of supply. The contribution of ageing liquefaction assets is expected to increase in the coming years. By 2030, liquefaction capacity and projected output from plants older than 15 years are set to reach nearly 400 bcm and 300 bcm, respectively, while the figures for plants older than 20 years rise to more than 330 bcm and 240 bcm. The largest shares of legacy export capacity in 2025 were in the Middle East and Asia Pacific, which together accounted for around two-thirds of liquefaction capacity  aged  15  years  or  more,  overlapping  with  regions  where  a  significant volume of legacy contracts is also set to expire.

Figure 5.3 LNG liquefaction capacity and output from legacy plants, 2025 and 2030

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from ICIS LNG Edge.

This growing pool of mature and largely depreciated assets is likely to play an increasingly  important  role  in  shaping  contracting  dynamics,  offering  buyers opportunities to negotiate new supply contracts on more flexible terms, particularly with respect to TOP provisions, but also pricing, contract duration and other nonprice terms, provided that upstream gas availability and plant reliability can be maintained.

## Unsold portfolio volumes

Portfolio  players,  also  known  as  aggregators,  are  intermediaries  that  build diversified  LNG  supply  portfolios  by  holding  equity  positions  in,  or  contracting volumes  from,  multiple  liquefaction  projects  and  reselling  them  to  end  users through  a  combination  of  long-,  medium-,  and  short-term  contracts  and  spot market transactions. Unlike traditional sellers tied to a single production project, portfolio players can offer buyers a broader range of contractual options, including flexible  delivery  points,  shorter  contract  durations,  and  the  ability  to  adjust volumes. This can be particularly valuable for buyers seeking to diversify supply sources, manage demand uncertainty, and reduce exposure to regional supply disruptions.  Portfolio  suppliers  have  therefore  played  an  increasingly  important role in enhancing the operational flexibility of global LNG trade.

At the same time, portfolio players' commercial incentives do not always align with those  of  LNG  importing  countries  and  companies.  Trading  margins  typically benefit  from  price  volatility,  and  flexibility  is  often  priced  explicitly  into  contract terms. The growing role of portfolio suppliers is reflected in their rising share of global contracting activity, with procurement volumes increasing from around 26% of total LNG contracts in 2016 to around 39% by 2024. This share is projected to rise further to around 45% by 2030, assuming no additional contracts are signed.

The net long position of portfolio players - reflecting contracted supply volumes not covered by term sales commitments to end users - has also widened in recent years,  from  around  90  bcm  in  2020  to  more  than  115  bcm  in  2024.  That  has resulted in a growing pool of unsold LNG held within their portfolios. Based on existing contracts, this net long position is set to increase to around 220 bcm by 2030, representing around 54% of total volumes in aggregator portfolios.

Figure 5.4 Contractual position of LNG portfolio players, 2020-2030

<!-- image -->

IEA. CC BY 4.0.

Note: This graph represents LNG contract volumes signed by the end of 2025. Source: IEA analysis based on data from IEA (2025), Gas 2025,

As the next wave of liquefaction capacity comes online and market conditions are expected to loosen, portfolio players may become more willing to market these uncommitted  volumes  on  more  favourable  terms.  This  could  create  additional opportunities for buyers to secure LNG  supply  with enhanced  flexibility, particularly  through  shorter-duration,  destination-flexible  contracts  with  greater volume optionality.

Taken  together,  these  factors  -  some  of  which  overlap,  notably  contract expirations and the growing share of depreciated liquefaction capacity - create a sizeable pool of volumes that could be recontracted on more flexible terms. This provides a strong basis for buyers to secure greater flexibility in LNG contracts on an  individual  basis,  particularly  as  market  conditions  loosen  and  competition among suppliers intensifies.

There is  also  scope  for  buyers  to  secure  greater  flexibility  collectively  through deeper  cooperation,  within  the  bounds  of  applicable  competition  law.  Such initiatives  could  support  the  development  of  minimum  flexibility  standards  that participating buyers would voluntarily incorporate into their new LNG contracts.

In practice, these standards could include the elimination of destination and resale restrictions,  seller  consent  requirements,  and  profit-sharing  clauses  from  FOB contracts. For DES  contracts, collective standards could limit destination restrictions  to  broad  regional  boundaries,  avoid  any  resale  restrictions,  and establish  standardised  and  time-bound  seller  consent  procedures,  with  profitsharing mechanisms replaced by transparent diversion fees (although such feebased mechanisms are not widely known to be used in practice today). In the case of supply from mature and depreciated liquefaction plants, buyers could commit

to seek wide DQT ranges or more extensive cancellation rights in exchange for relatively  modest fees reflecting the lower capital recovery requirements of the underlying asset.

However, collective approaches to contract flexibility face practical, commercial, and  legal  constraints.  Monitoring  and  enforcement  are  complicated  by  the confidentiality of LNG SPAs, limiting transparency over the extent to which buyers adhere  to  agreed  standards.  Quantifying  the  share  of  supply  sourced  from depreciated legacy plants is also challenging, particularly for contracts signed with portfolio players. In addition, any coordination among buyers would need to be carefully  assessed  in  light  of  applicable  competition  law,  particularly  where  it involves coordination among companies that may compete in downstream gas markets.  Further  analysis  would  therefore  be  needed  before  such  collective approaches could be implemented effectively.

## 5.3 Commercial innovation

Beyond strengthening  flexibility  provisions  in  existing  and  new  LNG  contracts, market participants can also pursue commercial innovation. Scaling up the use of non-traditional contractual structures, such as seasonal LNG contracts, contracts with  cancellation  rights,  or  LNG  options  contracts,  can  complement  traditional LNG SPAs and spot market procurement and provide flexibility in a more targeted way.  Buyers  can  also  enhance  flexibility  and  resilience  through  joint  LNG procurement  and  trading  arrangements,  whereby  companies  pool  purchasing power,  share  portfolios  or  jointly  optimise  LNG  marketing  and  logistics  across different regional markets.

The  case  for  exploring  more  innovative  approaches  to  LNG  contracting  has strengthened in recent years. On the buyer side, LNG demand is becoming more uncertain and variable, shaped by weather sensitivity, geopolitical developments, market  volatility, and  policy uncertainty. Buyers  in Europe  and  Asia  are increasingly seeking to preserve security of supply without being locked into rigid long-term commitments that may become misaligned with future demand trends or regulatory constraints. At the same time, extreme price volatility since 2021 has reinforced  the  value  of  instruments  that  can  limit  exposure  to  spot  market disruptions while avoiding excessive TOP liabilities.

On the seller side, the current wave of liquefaction capacity growth is expected to loosen market conditions in the second half of this decade. In parallel, portfolio players  are  holding  a  large  and  growing  share  of  LNG  volumes  that  are  not committed  to  end  users.  These  suppliers  may  face  increasing  pressure  to monetise uncommitted volumes and reduce their exposure to downside price risk in a well-supplied market. This creates a stronger incentive to offer commercial

structures that provide buyers with greater volumetric flexibility (in exchange for an  explicit  premium),  while  offering  sellers  relatively  stable  revenues  amid  a potential softening of spot LNG prices.

## Seasonal LNG contracts

Unlike traditional LNG SPAs, which commit buyers to relatively stable year-round deliveries  with  limited  volume  flexibility,  seasonal  LNG  contracts  are  typically structured  to  cover  only  periods  of  predictable  peak  demand,  with  deliveries concentrated in a defined seasonal window, such as the peak winter months.

Such seasonal contracts could be particularly relevant for buyers with strongly seasonal gas consumption profiles and limited storage capacity, allowing them to secure incremental winter supply directly rather than relying on storage withdrawals or spot LNG procurement.

The  pricing  of  seasonal  LNG  contracts  would  likely  require  a  premium  over prevailing forward prices at the time of signing, reflecting the convenience benefit for buyers of avoiding storage costs ahead of the peak demand season, and the additional marketing challenge for sellers of having to place their LNG elsewhere during the remainder of the year. As a result, suppliers with extensive portfolio flexibility  and  access  to  a  diversified  customer  base  are  likely  to  be  the  best positioned counterparties to offer and scale seasonal LNG contracting.

Seasonal  contracts  have  begun  to  emerge  in  the  LNG  market,  although  they remain relatively limited. Recent examples include a five-year seasonal contract between the Australian firm Woodside and Japan's JERA, under which JERA will receive  three  LNG  cargoes  per  year  within  the  December-February  delivery window starting in 2027. JERA also signed a 10-year LNG supply agreement with India's  Torrent Power covering four LNG cargoes per year during India's peak summer months, also starting in 2027. While the number of seasonal contracts signed to date remains small, these deals suggest a preference for medium-term arrangements (ranging from five to ten years), although both shorter- and longerduration structures could also emerge depending on market conditions and buyer requirements.

Seasonal contracting could become more relevant across key importing regions. In Europe, LNG demand has become increasingly seasonal as the region relies more heavily on LNG to balance winter consumption peaks. Even with substantial underground  storage  capacity,  the  region  typically  requires  incremental  LNG imports in winter to complement storage withdrawals. Northeast Asia, including northern China, Japan, and Korea, can also experience demand spikes during the peak winter months. However, overall gas demand seasonality in northeast Asia is  less  pronounced  than  in  Europe,  and,  as  such,  seasonal  requirements  are

smaller. In South  and  Southeast  Asia,  seasonal  arrangements  may  gain importance as LNG demand rises in power systems that are sensitive to summer cooling loads and hydropower variability.

In principle, seasonal LNG contracts could also help facilitate intra-regional and inter-regional  balancing,  particularly  where  seasonal  demand  patterns  differ across geographies (Figure 5.5). Such complementary seasonal demand profiles could  be  leveraged  between  northeast  Asia,  with  peak  demand  during  the Northern Hemisphere winter, and South and Southeast Asia, the Middle East, or even Australia and New Zealand (once they develop LNG import infrastructure), where  peak  requirements  typically  occur  during  the  Northern  Hemisphere summer. JERA's recent complementary seasonal LNG contracts with Woodside and Torrent Power illustrate how such structures can leverage differing seasonal demand profiles across markets, in this case between Japan and India.

Figure 5.5 Monthly LNG imports relative to the annual average in geographies with complementary seasonal demand profiles, 2020-2025 average

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on data from ICIS LNG Edge.

## LNG contracts with extended cancellation rights

The volumetric  flexibility  embedded  in  traditional  LNG  SPAs  is  constrained  by minimum TOP obligations and limited to UQT and DQT tolerances, often subject to  make-up  provisions  in  subsequent  periods.  Cancelling  contracted  cargoes beyond these narrow limits typically does not make economic sense, as buyers would still be required to pay for most or all of the contracted volume even if it is not lifted.

US LNG offtake contracts introduced a commercial model in which a larger share of total costs is variable, thus making cargo cancellations economically feasible in a  wider  set  of  market  conditions.  Under  the  prevailing  tolling-type  agreements

currently  in  place,  buyers  of  US  LNG  pay  a  fixed  liquefaction  fee  (typically USD 2 to USD 3.5 per MBtu over long contract durations (typically 15 to 25 years). Conversely, the costs of feedgas, liquefaction fuel (typically around 15% of the Henry Hub price benchmark), and, in some cases, shipping remain variable. This structure  effectively  gives  buyers  the  ability  to  cancel  cargoes  when  market conditions do not support exports. In practice, the widespread difference between Henry Hub prices and prices in key importing markets in Europe and Asia following the  shale  revolution  meant  that  most  US  LNG  contracts  were  signed  with  an expectation  of  continuous  lifting.  However,  when  price  spreads  narrow  or  turn negative, buyers can cancel cargoes while remaining liable only for fixed tolling or liquefaction  fees,  thereby  limiting  their  downside  exposure.  This  mechanism played  an  important  role  during  the  demand  shock  triggered  by  the  Covid-19 pandemic, when more than 170 US LNG cargoes were cancelled between April 2020 and November 2020.

Outside the United States, however,  cancellation rights beyond  standard contractual  tolerances  have  historically  been  limited,  reflecting  the  greater difficulty of incorporating such flexibility into traditional integrated LNG projects. One notable exception was a short-term agreement between Greece's DEPA and TotalEnergies in 2022, under which the buyer (DEPA) retained the right to cancel scheduled cargoes in exchange for a fixed fee. The contract required the delivery of two LNG cargoes per month between November 2022 and March 2023, but local reports indicate that DEPA exercised its cancellation right for at least two cargoes in February 2023, reportedly paying approximately EUR 10 million per cancelled cargo (around USD 3 per MBtu).

These  examples  illustrate  the  potential  for  broader  use  of  LNG  contracts  with extended cancellation rights. In such structures, buyers commit to a base volume but retain the ability to cancel cargoes in exchange for a predefined fee, typically with an expectation of regular lifting under normal market conditions. Compared with traditional SPAs, this approach provides unlimited downward flexibility while preserving a degree of revenue certainty for sellers. Such arrangements could be extended to a wider range of LNG contracts, particularly those involving portfolio players  with  diversified  supply  sources  and  marketing  outlets.  For  sellers, cancellation fees can provide a stable revenue stream while reducing exposure to unsold volumes. For buyers, these structures offer a middle ground between rigid long-term commitments and fully flexible spot procurement, improving their ability to respond to demand uncertainty and short-term market developments.

## Call option-type LNG contracts

Another promising innovation is the wider use of call option-style LNG contracts, which  provide  buyers  with  the  right  -  but  not  the  obligation  -  to  receive  LNG cargoes  on  predefined  terms.  These  contracts  function  in  many  ways  like

insurance policies: buyers pay a fixed upfront premium to secure access to supply but may never need to exercise that right. Such structures allow buyers to secure access to supply capacity while limiting volume risk. In exchange, buyers pay an upfront option premium, similar to an insurance premium, for the right to request deliveries during a defined period. Cargoes are then expected to be lifted only when needed - potentially only in rare or extreme market circumstances. This premium compensates the seller for reserving volumes and bearing the risk that the buyer may not exercise the option, requiring the LNG to be marketed and sold elsewhere.

Call  option-type  LNG contracts can be particularly valuable where buyers face highly  uncertain  gas  and  LNG  demand,  for  example  due  to  decarbonisation policies  or  unpredictable  pipeline  gas  supplies.  They  are  also  useful  where importers require an  insurance-like mechanism  against  heightened  supply security risks, allowing them to secure access to LNG volumes without committing to firm offtake obligations.

From  the  seller's  perspective,  options  contracts  could  provide  a  stabilising revenue stream through option premiums, particularly in a well-supplied market environment where spot price volatility may not consistently generate attractive trading margins. For portfolio players holding significant uncommitted volumes, monetising optionality may be preferable to carrying full exposure to downside price cycles.

However, these contracts also come with implementation challenges. Sellers must manage the operational complexity of reserving cargo availability while optimising their broader  portfolios. Meanwhile,  buyers  need  robust  trading  and  riskmanagement capabilities  to  evaluate  whether  the  option  premium  offers  value relative  to  alternative  strategies  such  as  storage,  hedging  instruments,  or  spot market procurement.

The price of a call option, namely the option premium paid by buyers, depends on several variables, including contract duration, strike price, and the volatility of the underlying commodity. Higher volatility, longer contract durations, and lower strike prices generally increase the value of the option and therefore the premium that buyers must pay. Illustrative calculations suggest that such contracts could be relatively expensive, particularly when buyers seek to secure comparatively low strike  prices  or  long  contracts  during  periods  of  elevated  market  volatility.  In practice,  economically viable structures  are  more  likely  to  involve  higher  strike prices and shorter contract durations, with the option intended to be exercised only in  relatively  rare  circumstances,  reinforcing  its  role  as  insurance  rather  than  a routine supply source.

## Figure 5.6 Illustrative cost of LNG call options at different strike prices and contract durations

<!-- image -->

IEA. CC BY 4.0.

Note: Option premia are calculated using the Black-76 framework, treating the LNG procurement contract as a call option on a forward gas price. The underlying forward price is assumed to be USD 8/MBtu, and the risk-free rate is set at 3.5%. Volatility is derived from historical market data using daily European and Asian month-ahead gas price series over the 2016-2025 period. Annual volatility is first calculated separately for each calendar year as the standard deviation of daily log returns, annualised using the actual number of trading days in each year. The reported volatility is the simple average of these annual values.

This relatively high cost, particularly under conditions of elevated volatility, long contract  durations,  and  low  strike  prices  may  partly  explain  the  limited  use  of explicit  call  option-style  LNG  contracts  in  transactions  to  date.  Where  such instruments  are  intended  to  serve  broader  supply  security  objectives,  their deployment  is  likely  to  require  some  form  of  public  support.  In  such  cases, governments can help facilitate or incentivise their use, for example by mandating or supporting designated entities to include LNG call options in their portfolios to meet gas supply security requirements.

Beyond  bilateral arrangements, call option-style LNG  contracts could be developed  further  as  a  tool  for  collective  action  and  coordinated  emergency response. In principle, LNG options could be pooled across multiple buyers or even across multiple importing countries, creating a shared flexibility buffer that can be activated during supply emergencies.

The absence of a single, well-defined and flexible asset base, as is the case with strategic oil  stocks  under the IEA framework, has historically been a barrier to coordinated gas security mechanisms. A diversified portfolio of pooled LNG call options,  with  full  destination  flexibility,  could  in  principle  help  address  this  and function as a collectively managed 'virtual' emergency reserve. However, such a mechanism would raise numerous implementation and governance challenges, including  around  activation  triggers,  cost-sharing  arrangements,  enforcement

mechanisms,  allocation  rules,  and  the  simultaneous  exercise  of  options  by multiple  participants  during  widespread  supply  disruptions,  all  of  which  require further study.

If a period of abundant supply in the late 2020s were to materialise, it could create more favourable conditions for the development of such instruments, as sellers may be more willing to monetise optionality to secure additional revenue streams. At the same time, buyers and governments in import-dependent countries may view  the  associated  premiums  more  favourably  relative  to  alternative  supply security  measures,  such  as  building  strategic  underground  gas  reserves  or deploying  FSRU-based  import  infrastructure,  which  can  also  entail  significant costs.

## Joint LNG procurement and trading

An additional option for commercial innovation is collaborative LNG procurement and portfolio  optimisation  arrangements  between  buyers  (Asian  and  European ones  in  particular).  Such  arrangements  can  help  participants  better  manage demand uncertainty,  price  risks,  and  portfolio  flexibility  by  allowing  companies operating  in  different  markets  to  combine  their  procurement  strategies,  share contractual  volumes,  or  jointly  optimise  LNG  trading  and  marketing  activities. Given the right incentives, they could also enhance supply security by prioritising deliveries to their respective domestic markets in the event of supply emergencies.

One example of joint procurement across regions is between Tokyo Gas and the United  Kingdom's  Centrica,  who  together  secured  long-term  LNG  supply  from Mozambique  LNG.  The  project  is  only  expected  to  start  production  in  2029, following a suspension of construction between 2021 and January 2026 due to security concerns in northern Mozambique. Under the agreement, Tokyo Gas and Centrica would jointly purchase LNG volumes from Mozambique LNG, enabling them  to  leverage  their  respective  positions  in  the  Asian  and  European  gas markets. This structure allows the partners to optimise the destination of cargoes depending on regional market conditions, redirecting LNG between Europe and Asia  where  commercial  opportunities  or  supply  needs  are  greatest.  Such arrangements  can  help  buyers  diversify  supply  sources  and  respond  more effectively to supply disruptions affecting only one region.

Collaboration opportunities are not limited to procurement. A notable example is the LNG optimisation and trading joint venture established between JERA and France's  EDF  Trading.  The  partnership  combines  JERA's  substantial  LNG procurement portfolio and access to regasification infrastructure in Asia with EDF Trading's  global  trading  capabilities  and  market  presence  in  Europe  and  the Atlantic  basin.  Through  such  structures,  partners  can  jointly  manage  cargo scheduling,  optimise  shipping,  and  regasification  capacity,  and  market  LNG

volumes across multiple regions. By pooling portfolios and trading capabilities, these partnerships can improve operational efficiency, expand market access and help smooth supply-demand imbalances across regional markets.

There  may  be  further  scope  to  expand  such  cooperative  structures.  Crossregional partnerships between buyers in Europe and Asia could facilitate more efficient global balancing of LNG flows, particularly during periods of market stress when demand surges in one region can rapidly tighten supply elsewhere. Joint procurement arrangements could also enable smaller buyers or emerging LNG importers  to  participate  in  larger  projects  by  aggregating  demand,  while  joint trading  platforms  could  help  participants  optimise  increasingly  complex  LNG portfolios as destination flexibility becomes more widespread.

However, these structures  may  face  practical  constraints.  Aligning  commercial interests  between  partners  can  be  challenging,  particularly  when  participants operate in markets with different regulatory environments, demand profiles, or risk tolerances. Governance  arrangements  must  clearly  define  decision-making processes,  profit-sharing  mechanisms,  and  the  allocation  of  cargoes  during periods of market stress. Competition policy considerations and concerns about market  concentration  may  also  limit  the  extent  to  which  buyers  can  formally coordinate procurement strategies in certain jurisdictions.

Despite  these  challenges,  joint  procurement  and  trading  partnerships  illustrate how LNG buyers can adapt their commercial strategies to an increasingly flexible and  globally  interconnected  market.  By  combining  purchasing  power,  portfolio diversity  and  trading  expertise,  such  collaborations  can  enhance  both  supply security and commercial optimisation for participating companies. Governments in like-minded importing countries could support these arrangements by encouraging partnerships that allow portfolio optimisation under normal market conditions while providing incentives to prioritise supply security during crises.

As noted, commercial innovation is not a substitute for conventional long-term contracts,  which  will  remain  essential  for  financing  new  liquefaction  capacity. However, the expansion of seasonal contracts, portfolio contracts with cancellation rights, and call option-style contracts could help buyers strengthen supply  security  and  meet  seasonal  balancing  requirements  without  increasing their  exposure  to  rigid  TOP  obligations.  Deeper  cooperation  between  buyers through joint procurement and portfolio optimisation arrangements could further enhance flexibility by allowing participants to pool volumes, share infrastructure access, and coordinate trading strategies across regions. Over the medium term, the  growing  role  of  portfolio  players,  the  expiry  of  legacy  contracts,  and  the prospect of looser market conditions could create a favourable environment for such innovations to scale. If widely adopted, these approaches could form a third layer  of  LNG  procurement  between  traditional  LNG  SPAs  and  spot  market purchases, supporting both supply security and market efficiency in key importing regions.

## 5.4 LNG swaps

Agreements  between  two  or  more  parties  to  exchange  cargoes  or  delivery obligations, knows as physical LNG swaps, can enhance market flexibility and support more coordinated reserve or balancing mechanisms. Although swaps are primarily used to compensate for missing deliveries or economic optimisation, they can improve system efficiency, reduce shipping costs, and enable faster crossbasin rebalancing when regional supply-demand conditions shift abruptly. During periods of market stress, they can redirect volumes to the most affected markets more rapidly than negotiating new spot purchases or arranging reloading.

The main challenge for physical LNG swaps lies in aligning two counterparties' cargo  specifications,  shipping  and  terminal  schedules,  contractual  terms,  and credit arrangements  within a narrow  timeframe. This complexity is often compounded by residual contractual rigidities, including destination restrictions, seller consent requirements, and profit-sharing clauses. These remain prevalent in parts  of  the  legacy  contract  portfolio,  especially  in  DES  contracts  (see Section 5.1).  Their  gradual  removal  from  existing  and  future  LNG  SPAs  could therefore  facilitate  more  diversions  as  well  as  a  broader  use  of  LNG  swap arrangements over time.

Technical and operational parameters, including schedules, ship-shore compatibility,  and  LNG  quality,  must  also  be  closely  aligned  or  otherwise accommodated through operational adjustments.

Documentation,  compliance,  and  financial  requirements  are  similarly  complex, including  potential  amendments  to  bills  of  lading,  reissuance  of  certificates, amendments  to  letters  of  credit,  as  well  as  customs  treatment  and  sanctions screening requirements applicable to cargo origin, vessels, and counterparties. Streamlining these processes could facilitate the execution of physical LNG swap transactions in the future.

Some of these technical and administrative constraints could be eased, especially during periods of market stress or supply emergencies, on a temporary basis. Options for pre-established, standardised emergency frameworks include expedited  nomination  and  terminal  access  procedures;  shorter  notice  periods; simplified  documentation  requirements;  accelerated  customs  and  regulatory approvals;  temporary  widening  of  quality  tolerances  (within  safe  operational limits); and streamlined authorisation for ship-to-ship operations where relevant and properly regulated.

Market  transparency  around  potential  swap  opportunities  remains  limited  and largely confined to bilateral contacts. This could be improved through 'matchmaking' platforms enabling the exchange of non-binding expressions of interest,  particularly  as  the  number  of  spot  LNG  cargoes  available  for  swap

transactions  at  any  given  time  increases.  Such  platforms  could  focus  on standardised and non-sensitive parameters, including delivery windows, volume ranges,  destination  regions,  basic  quality  specifications,  and  the  existence  of seller consent requirements, without requiring disclosure of detailed contractual terms. The objective of these platforms would not only be to allocate cargoes, but also to reduce the time and transaction costs associated with identifying feasible counterparts for potential swap transactions.

Finally, easing the contractual and operational constraints that currently limit swap transactions  could  also  create  scope  for  more  advanced  policy  mechanisms, including arrangements that enable the exchange of LNG cargoes for LNG or gas held in storage in a third country. Such structures could support coordinated action among  partner  countries  during  supply  disruptions.  Some  of  these  potential mechanisms, and their implications for energy security and market functioning, are discussed further in Section 6.

## 6. Policy tools to create gas reserve mechanisms

This chapter discusses four main types of policy instruments that governments use  or  may  consider  using  to  strengthen  gas  supply  security  through  reserve mechanisms (see Table 2). Mandatory storage obligations require gas storage facilities to reach minimum fill levels by specific dates, typically ahead of the winter withdrawal season, to ensure sufficient inventories.  Strategic  underground  gas reserves  designate  a  portion  of  storage  capacity  or  volumes  for  use  only  in emergencies,  rather  than  for  commercial  balancing.  Strategic  cushion  gas reserves  refer  to  the  potential  use  of  part  of  the  cushion  gas  in  existing underground  storage  facilities  as  an  emergency  backstop  under  exceptional circumstances. Finally, various buffer LNG schemes provide contingency supply mechanisms by securing access to LNG cargoes or LNG import infrastructure that can be mobilised during periods of severe market tightness or supply disruption.

These  instruments  differ  in  their  objectives,  costs,  and  implications  for  market functioning. The choice among them depends on the structural characteristics of national  gas  systems.  Countries  with  large  underground  storage  systems  and liquid gas markets may prioritise measures that influence storage filling behaviour, while LNG-dependent economies with limited storage capacity may rely on importbased contingency mechanisms. This chapter provides an overview of the main features of each policy tool, including their advantages, limitations, and typical use cases.

## Table 6.1. Overview of policy tools for gas reserve mechanisms

|              | Mandatory storage obligations                                                                                                                                                                   | Strategic underground gas reserves                                                                                                                                                                                                 | Strategic cushion gas reserves                                                                                                                                                                                                                                                   | Buffer LNG schemes                                                                                                                                                                                                                                  |
|--------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Core concept | Regulatory requirement to reach minimum gas storage fill levels by specified dates (e.g. ahead of the heating season), often supported by intermediate targets to guide the filling trajectory. | Ringfencing of UGS capacity or volumes for emergency use only, with release subject to predefined conditions and government authorisation, and typically supported by public funding.                                              | Designating a portion of cushion gas in underground storage facilities as a publicly backed emergency reserve, with withdrawal permitted only under predefined emergency conditions.                                                                                             | Publicly backed contingency mechanisms that secure access to LNG cargoes or import capacity during emergencies, through contractual arrangements, dedicated infrastructure, or a combination of both.                                               |
| Pros         |  Ensures adequate inventories ahead of the winter season.  Utilises existing commercial storage capacity.                                                                                     |  Provides a guaranteed physical buffer in emergencies.  Can support storage economics where existing UGS sites are converted to strategic use.                                                                                   |  Immediately available emergency buffer within existing UGS facilities.  Cost-effective compared with building new strategic storage as no additional infrastructure or gas procurement is required.  No impact on market functioning and commercial storage operations under |  Flexible and scalable emergency supply option.  Can be implemented cost-effectively through contractual arrangements or existing infrastructure.  Can support security of supply without distorting market functioning under normal conditions. |
| Cons         |  May distort market price signals and exacerbate price spikes during the storage fill period.  Risk of crowding out commercial market activity.                                               |  High capex and long lead times if new facilities are developed from scratch.  Reduces storage available for commercial balancing when existing capacity is ringfenced.  Limited track record of use during actual emergencies. |  Reduced deliverability and risk of permanent reservoir damage if cushion gas is withdrawn.  Feasible volumes and withdrawal rates are site-specific and require detailed studies.                                                                                             |  Relies on LNG availability in tight global markets.  High commercial and governance complexity.  Limited track record of effectiveness in actual emergencies.                                                                                   |
| Use cases    | Markets with high reliance on storage for seasonal balancing, large storage capacity, and insufficient market incentives to ensure adequate refilling ahead of peak demand periods.             | Countries with surplus storage capacity and/or weak commercial storage economics.                                                                                                                                                  | UGS facilities at risk of closure where preserving storage assets provides system value and supports resilience.                                                                                                                                                                 | Economies with high reliance on LNG imports and limited storage capacity.                                                                                                                                                                           |
| Examples     | European Union.                                                                                                                                                                                 | Ten countries within the European Union.                                                                                                                                                                                           | Under study in the Netherlands.                                                                                                                                                                                                                                                  | Japan's SBL scheme; Singapore's SLF.                                                                                                                                                                                                                |

IEA. CC BY 4.0.

## 6.1 Mandatory storage obligations

Gas  storage  facilities  generally  operate  on  a  commercial  basis,  with  capacity holders weighing the opportunities to buy gas to store and sell later at a higher price. However, injection and withdrawal decisions can also be shaped by policy mechanisms, including through mandatory storage obligations.

Mandatory storage obligations are set by governments (or, in the European Union, through EU-level regulation) and typically require that a minimum storage fill level or volume be reached by a specified date, often ahead of a period of expected high withdrawals, such as the winter heating season in the Northern Hemisphere. By requiring higher inventories than might be achieved under purely commercial incentives, such obligations aim to strengthen supply security, limit the potential impact of geopolitical actions by state-owned suppliers, and ensure that storage facilities can effectively perform their balancing function.

Complementary  intermediate  targets  can  be  set  to  achieve  a  desired  filling trajectory. In some cases, indicative minimum levels for the end of the withdrawal season have also been implemented, although these present the drawback of potentially constraining the optimal use of storage withdrawals when they are the most  needed.  Mandatory  storage  obligations  differ  from  strategic  gas  storage arrangements in that they do not seek to reserve a specific volume for release only in predefined emergency situations. Rather than restricting withdrawals, their objective  is  to  maximise  the  utilisation  and  system  value  of  available  storage capacity.

The  rationale  for  mandatory  storage  obligations  lies  in  the  risk  that  storage facilities may not be adequately filled on a purely commercial basis when seasonal spreads are tight. In such circumstances, market incentives alone may not result in storage levels needed to provide sufficient security ahead of the peak winter season. While storage injections are generally incentivised when forward prices exceed  spot  prices  (i.e.  when  summer-winter  spreads  are  positive),  seasonal spreads may be insufficient to cover both direct and opportunity costs of storing gas. Low inventory levels, in turn, reduce the balancing potential of underground storage,  contributing  to  tighter  market  conditions  and  higher  price  volatility. Paradoxically, expectations of adequate future supply can weaken incentives to fill storage  ahead  of  the  withdrawal  season  by  compressing  seasonal  price spreads. The expected wave of new LNG supply in the remainder of the decade, for example, could structurally narrow seasonal spreads in Europe, weakening the market signal for storage injections.

In 2021, UGS levels in the European Union were below the five-year average at the end of the winter. Nevertheless, injections during the subsequent filling season remained  about  17%  below  the  five-year  average,  reflecting  relatively  benign

market expectations for the year ahead. Storage levels reached only about 77% ahead of the 2021/22 winter, compared with a five-year average peak above 90%. This  occurred  as  artificial  market  tightness  was  building,  driven  by  Gazprom's limited  injections  into  its  European  storage  facilities  and  Russia's  decision  to reduce short-term and spot gas sales to Europe. As a result, the continent entered the 2022 crisis period less well prepared to face an unexpected supply shock. 12

## Case study: The European Union's Gas Storage Regulation

In 2022,  the  European  Union  sought  to  strengthen  system  resilience  by maximising  the  use  of  its  underground  storage  facilities,  following  a  period characterised by sharply reduced injections into Gazprom-controlled gas storage sites in Europe, declining Russian pipeline gas deliveries to the continent, and below-average EU gas storage levels.

The  European  Union's  Gas  Storage  Regulation  was  adopted  in  June  2022  in response  to  these  events.  The  measure  introduced  a  binding  requirement  for member states with UGS to reach an 80% fill level by 1 November in 2022 and 90% in subsequent years, complemented by intermediate targets to support the filling trajectory during the injection season. 13  The regulation was adopted at the EU level, and allowed member states to choose the measures most appropriate for their national systems, which resulted in a range of approaches to achieving the target. These included administrative tools (e.g. stockholding obligations on specific entities and 'filling of last resort' mechanisms), as well as market-based measures  (e.g.  filling  subsidies). 14 Approaches  varied  in  their  effectiveness, efficiency, and cost. 15 Despite these differences, all member states with UGS met the 1 November storage target in both 2022 and 2023, with only one (Denmark) missing the target in 2024. The regulation was set to expire at the end of 2025, but an amendment has extended it, and the 90% storage target, through the end of 2027, while providing greater flexibility over the timing of storage filling.

Some observers have expressed concern that mandatory storage targets distort market price signals and put upward pressure on the cost of refilling storage, which remains the subject of ongoing debate. In response to stakeholder feedback, the revised  EU  framework  approved  in  September  2025  allows  member  states  to

12 For more on this, see Europe and the world need to draw the right lessons from today's natural gas crisis by IEA Executive Director Fatih Birol.

13 Member states without UGS on their territory must store the equivalent of 15% of their national consumption in facilities in other member states.

14 'Filling of last resort' refers to the appointment of an entity that is charged with filling storage as a last resort if market signals are insufficient to incentivise sufficient storage injections.

15 For more on this, see Study on the impact of the measures included in the EU and National Gas Storage Regulations from VIS Consultants.

deviate  from  filling  targets  under  unfavourable  market  conditions,  providing additional flexibility to reflect changing market fundamentals and price signals.

In 2025, the European Commission announced plans for an impact assessment of the EU's broader energy security framework, indicating that the future of storage rules  beyond  2027  could  be  addressed  with  a  more  permanent  regulatory structure.  While  discussions  are  at  an  early  stage,  a  key  issue  is  likely  to  be whether storage obligations should be integrated into a broader EU-level supply security or resilience framework. The extension to 2027 suggests that any longerterm arrangement would likely allow for a degree of flexibility in meeting targets. It also  suggests  that  alternative  benchmarks  may  be  set,  based  on  domestic consumption levels and the availability of alternative supply options, rather than the total storage capacity in a member state.

Given the ongoing conversation about the potential market-distorting and priceincreasing  effects  of  mandatory  storage  obligations,  there  is  growing  interest among EU member states and market participants in using strategic gas reserves as  an  alternative  or  complement  to  mandatory  storage  obligations  (see  next section).

## Case study: Korea's mandatory LNG reserve policy

Unlike  countries  in  the  European  Union,  Korea  does  not  have  UGS  facilities. Instead, the country uses LNG storage tanks at its seven LNG import terminals for short-term storage (those seven facilities have a total storage capacity of about 9 bcm). Korea has a mandatory LNG reserve policy requiring minimum inventories to be met at facilities run by the state-owned Korea Gas Corporation (KOGAS), which run five of the terminals, representing around 6.5 bcm of LNG tank storage capacity.

The  country's minimum  storage  rules were  introduced in 2016  with the establishment of the Urban Gas Business Act (which was later amended, notably in 2021) and spells out two requirements for KOGAS-operated facilities. The first is mandatory inventory volumes, which calls for KOGAS to maintain emergency LNG stocks equivalent to at least nine days of average demand, up from seven days, following the 2021 policy update. The second requirement is to maintain preventive reserves, defined as LNG tank storage capacity equivalent to at least 30 days of average demand. Based on Korean gas demand of about 60 bcm in 2025, this corresponds to mandatory inventory volumes of approximately 1.5 bcm and preventive reserve capacity of around 5 bcm.

## 6.2 Strategic underground gas storage

Strategic underground gas storage refers to the regulatory ringfencing of UGS capacity  or  working  gas  volumes  for  use  only  in  emergencies,  rather  than  for commercial  purposes.  Strategic  reserves  should  provide  emergency  capacity beyond commercially operated storage; they should not simply replace commercial inventories. This additionality can help address gaps in firm supply availability during periods of severe system stress, including for gas-fired power generation.

Strategic gas reserve volumes are generally held by a state entity or entrusted by state authorities to a gas market participant and typically represent only a portion of the available UGS capacity in a market. The cost of purchasing and maintaining strategic reserves is typically funded directly from state budgets or recovered from end users via network charges. The release of strategic storage volumes typically requires  government  authorisation  and  is  triggered  by  predefined  emergency market conditions.

As such, strategic gas reserves shift UGS capacity away from commercially driven operational signals  (such  as  pricing)  towards  security  of  supply  driven  signals, trading a degree of supply flexibility to create an emergency buffer for extreme market conditions. Given the fundamentally different functions of commercial and strategic  storage,  it  is  important  to  maintain  clear  operational  and  regulatory distinctions between the two. Preserving differentiated signals for commercial and strategic  storage  can  help  avoid  distorting  market  incentives  while  ensuring strategic reserves remain available for emergencies.

While much of the discussion around strategic underground gas storage focuses on the volume of gas that can be stored, responding to immediate supply shocks in the market rests on the ability to deliver gas as quickly as possible. Therefore, beyond working gas capacity,  maximum  withdrawal  rates  and  the  proximity  of storage facilities to demand  centres are also key considerations in the development of strategic underground gas reserves.

While some countries, particularly in Asia, may choose to develop new strategic storage facilities, others, especially in Europe, mostly rely on existing assets for strategic storage. Designating  all or part of the capacity at existing but underutilised  storage  sites  as  strategic  capacity  can  improve  deliverability  by maintaining higher storage fill levels, which support higher withdrawal rates. It can also improve the commercial viability of underground gas storage in markets such as the European Union, where narrow seasonal spreads often undermine storage revenues. However, some storage sites may be underutilised precisely because lower deliverability or less favourable locations limit their contribution to supply security. By contrast, the most suitable sites, particularly high-deliverability salt

cavern  facilities, are  often  already  in  strong  demand  for  commercial  use. Therefore,  while  supporting  commercially  challenged  storage  sites  may  be  an additional  benefit  of  strategic  storage,  security-of-supply  considerations  should remain the primary consideration in site selection to ensure that strategic reserves provide effective emergency buffer during actual emergencies.

## Case study: Strategic gas reserves in EU member states

Strategic gas reserves played a role in the gas security of at least six EU member states even before the 2022-2023 energy crisis. The use of such reserves has expanded further since 2022, with four of those six member states amending their existing frameworks, largely in response to the 2022 EU Gas Storage Regulation. An additional four member states introduced new strategic reserves after 2022 (Table 3). In total, an estimated 12 bcm of gas was held as strategic reserves across  the  European  Union  in  2025,  representing  around  3.5%  of  annual  gas consumption and 12% of working gas storage capacity (Table 4).

Table 6.2. Evolution of strategic gas reserve policies in selected EU member states

| Country   | Existing measure not amended   | Existing measure amended since 2022   | New measure introduced since 2022   |
|-----------|--------------------------------|---------------------------------------|-------------------------------------|
| Austria   |                                |                                       | x                                   |
| Bulgaria  | x                              |                                       |                                     |
| Czechia   |                                |                                       | x                                   |
| Estonia   |                                |                                       | x                                   |
| Germany   |                                |                                       | x                                   |
| Hungary   |                                | x                                     |                                     |
| Italy     | x                              |                                       |                                     |
| Latvia    |                                | x                                     |                                     |
| Poland    |                                | x                                     |                                     |
| Spain     |                                | x                                     |                                     |

Source: IEA analysis based on data from European Union Agency for the Cooperation of Energy Regulators (2023), ACER publishes a consultancy study on the impact of EU and national gas storage regulations.

The  financial  mechanisms  used  to  recover  the  costs  of  establishing  and maintaining strategic gas reserves within the EU vary across countries. In some cases, costs are passed directly to final consumers, either through supplier prices (Spain) or specific emergency levies (Hungary). In others (Austria, Czechia, and Latvia), they are funded from state budgets. Cost recovery can also be embedded in  regulated charges, such as transmission tariffs (Bulgaria), neutrality charges applied  at  system  exit  points  (Germany), 16  or  storage  and  transmission  tariffs

16 Germany's gas storage neutrality charge, which was introduced in 2022 to finance the cost of mandatory storage filling with a levy on network users at system exit points, was abolished on 1 January 2026 and replaced by direct financing from the federal budget.

(Bulgaria and Italy). Where a single entity such as a transmission system operator or  state  agency  is  responsible  for  stockholding,  which  is  the  case  in  most  EU countries with strategic gas reserves, these mechanisms typically ensure full cost recovery.  By  contrast,  in Spain,  where  obligations  are  placed  on  market participants, cost recovery depends on individual supplier pricing strategies and may  be  less  certain.  Penalties  for  non-compliance  are  applied  in  Germany, Hungary, and Spain.

Table 6.3.   Strategic gas reserves in selected EU member states

| Country   | Strategic reserve   | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       |
|-----------|---------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Austria   | 1.9 bcm             | In 2022, a government-funded strategic gas reserve was established under the management of Austrian Strategic Gas Storage Management GmbH, a subsidiary of the Austrian Gas Grid Management. The reserve is distributed across multiple storage sites with contracted withdrawal capacities, cannot be used for commercial purposes, and can be released by order of the energy minister with parliamentary consent; the framework is valid until 1 April 2027.                                                                                                                                                                   |
| Bulgaria  | 0.1 bcm             | Bulgartransgaz is required to maintain a strategic gas reserve of up to 70 mcm in the Chiren UGS facility to ensure security of supply upon order by the Minister of Energy; costs are recovered through transmission tariffs.                                                                                                                                                                                                                                                                                                                                                                                                    |
| Czechia   | 0.2 bcm             | In 2022, the Administration of State Material Reserves established a 2.4 TWh (approximately 0.2 bcm) state-owned strategic gas reserve. Gas can only be released from the facility with explicit government approval, and costs for procurement and maintenance are covered by the state budget.                                                                                                                                                                                                                                                                                                                                  |
| Estonia   | 0.1 bcm             | State-owned strategic gas stocks are managed by the Estonian Stockpiling Agency and stored in Latvia's Inčukalns UGS facility. The reserves can be released by the government or the Minister of Economic Affairs and Infrastructure; costs are recovered through a stockpiling fee collected from gas consumers.                                                                                                                                                                                                                                                                                                                 |
| Germany   | 0.0 bcm             | A market-based framework for strategic gas reserves was introduced in 2022, with Trading Hub Europe mandated to procure Strategic Storage-Based Options (SSBOs) from market participants. In exchange for a fee, providers must keep 20% of contracted volumes in storage for emergency call-off; release is authorised by the economy ministry in coordination with the regulator, BNetzA. Costs are recovered via a neutrality charge levied on network users; two auctions in 2022 secured 84 TWh of SSBOs, including 17 TWh (1.6 bcm) of call- off volumes, but these options have since expired with no subsequent auctions. |
| Hungary   | 1.9 bcm             | The Hungarian Hydrocarbon Stockpiling Association maintains two types of strategic gas reserves: security stocks (around 1.2 bcm) and special stocks (around 0.7 bcm). Volumes are set annually and releases are authorised by the Minister of Energy; costs are covered by a stockpiling fee paid by gas consumers (excluding households).                                                                                                                                                                                                                                                                                       |
| Italy     | 4.6 bcm             | The strategic storage operator (Stogit, a subsidiary of Snam) is required to maintain strategic gas reserves in underground storage. Stock levels are set annually by the Ministry of Environment and Energy Security, costs are recovered through regulated tariffs, and stocks can only be released in emergencies with ministerial approval.                                                                                                                                                                                                                                                                                   |
| Latvia    | 0.2 bcm             | State-owned strategic gas security reserves (1.8 TWh) are held by Latvenergo in the Inčukalns UGS facility; stocks cannot be sold and can only be released by decision of the Cabinet of Ministers, which reassesses volumes every two years. Procurement and transit costs are covered by the state budget, while storage tariffs are recovered through transmission tariffs at the national exit point.                                                                                                                                                                                                                         |
| Poland    | 1.3 bcm             | Gas importers must maintain mandatory emergency stocks equivalent to 30 days of average net imports. Stocks may be held domestically or abroad (with                                                                                                                                                                                                                                                                                                                                                                                                                                                                              |

| Country   | Strategic reserve   | Description                                                                                                                                                                                                                                                                                                                                                                                                                              |
|-----------|---------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|           |                     | firm cross-border capacity) and must be deliverable to the Polish system within 50 days; release is authorised by the Minister of Energy and implemented by the transmission system operator.                                                                                                                                                                                                                                            |
| Spain     | 1.7 bcm             | Suppliers and large consumers must maintain security stocks equivalent to around 20 days of prior-year consumption (10 days of strategic reserves and 10 days of system operating stocks), with additional user-level operational stocks varying seasonally. The government authorises the release of strategic stocks, while the Ministry for the Ecological Transition and the Demographic Challenge oversees system operating stocks. |

Note: Strategic reserve volume reflects current size or latest available data. Germany has a legal and framework in place to procure gas for strategic storage, but currently no gas volume is stored under the scheme.

As outlined above, several EU member states maintain strategic gas reserves while  also  complying  with  mandatory  storage  obligations  under  the  EU's  Gas Storage Regulation. But the two measures have potentially competing objectives, which  could  complicate  gas  storage  priorities  in  certain  countries.  Strategic reserves create an emergency buffer by reducing the storage capacity available for  commercial  use.  By  contrast,  mandatory  EU  storage  obligations  aim  to maximise the potential for commercial withdrawals, and therefore the flexibility value  of  storage  during  the  withdrawal  season,  even  if  this  limits  commercial flexibility during the injection season.

While  these  measures  are  not  inherently  incompatible,  their  objectives  may compete when storage capacity is constrained and strategic reserve requirements are high. In 2025, for example, strategic reserves accounted for about 50% of UGS capacity in Spain, 37% in Poland, 30% in Hungary, 24% in Italy, and 20% in Austria (Figure 6.1). However, LNG storage (in Spain), the option to store gas abroad (as in the case of Poland), and a market-based approach in Germany (where stocks are procured only when needed) provide some additional flexibility for the use of domestic storage capacity.

Additional  EU  member  states  are  exploring  the  creation  of  new  strategic  gas reserves. Germany, which has the legal framework in place but held no physical stocks in its strategic reserve as of 2026, is considering the establishment of a permanent publicly funded 24 TWh (2.2 bcm) emergency reserve, which would repurpose around 10% of the country's commercial UGS capacity for strategic use. The Netherlands also plans to establish a 5 TWh (0.5 bcm) strategic reserve at the Alkmaar UGS facility, by the winter of 2026/27 and it is exploring options to expand strategic storage beyond this initial target.

Figure 6.1 Underground storage capacity and strategic gas reserves in selected EU member states

<!-- image -->

IEA. CC BY 4.0.

Note: Underground storage capacity as of 31 December 2025. Size of strategic gas reserves based on latest available information. Estonia's strategic gas reserve is stored in Latvia.

Source: IEA analysis based on data from Gas Infrastructure Europe (2026), AGSI+ Database.

While strategic gas reserves have so far been implemented only at the memberstate level, they could feasibly be combined and operated at the EU level, backed by member states on a proportional basis. In 2025, Ukraine's state-owned oil and gas company, Naftogaz, proposed using Ukraine's spare UGS  capacity (estimated at more than 10 bcm) to establish EU-level strategic gas reserves. To date, no concrete progress has been made towards mutualising strategic storage at the supranational level. However, such a mechanism could offer the advantage of centralising the non-market function of underground gas storage, while allowing commercial storage to continue to respond to market signals.

## Case study: India's plan to build strategic gas reserves

Strategic  gas  reserves  are  not  commonly  deployed  outside  of  Europe.  As  a possible exception to this, India's Petroleum and Natural Gas Regulatory Board proposed  developing  strategic  UGS  in  depleted  fields  in  2023,  following  the extreme  price  volatility  during  the  2022-2023  crisis  and  the  resulting  demand curtailments in key sectors. The unpredictable market dynamics that played out during the crisis helped strategic storage gain importance as a potential lever in reducing exposure to price and supply shocks.

Despite early interest, the proposal and a plan for a feasibility study intended to evaluate costs, potential locations, timeliness, and business models, appears to have been shelved in 2025, notably linked to cost considerations. Instead, India has prioritised the expansion of LNG storage at regasification terminals as a less capital-intensive and better distributed potential alternative, which is considered more suitable for India's market context.

## 6.3 Strategic cushion gas reserves

Cushion gas refers to the volume of natural gas that must remain permanently in a UGS facility, in addition to the commercial (or working) gas volume, to maintain sufficient  reservoir  pressure  and  ensure  reliable  deliverability.  The  required volume of cushion gas varies by storage type, typically accounting for around 30% of  total  capacity  in  salt  caverns,  about  50%  in  aquifers,  and  50%  to  60%  in depleted gas fields.

Under normal operating conditions, cushion gas is not intended to be withdrawn, as doing so can impair storage performance, reduce withdrawal rates, and in some cases, compromise reservoir integrity. However, in the context of heightened gas supply security concerns following the 2022-2023 energy crisis, cushion gas has been discussed as a potential emergency backstop.

The concept of strategic cushion gas reserves refers to the designation of a portion of cushion gas in existing UGS facilities as a publicly backed reserve that could be withdrawn in clearly defined emergency situations.

The potential appeal of cushion gas lies in its immediate availability and, in most cases, its proximity (via existing UGS sites) to major demand centres. Designating existing  cushion  gas  volumes  as  a  strategic  reserve  can  be  a  cost-effective alternative to building dedicated strategic (working) gas reserves, as it does not require additional infrastructure investment or natural gas procurement. Compared with mandatory storage obligations, the risk of market distortion is also more limited, as strategic cushion gas reserves have no impact on supply-demand dynamics under normal market conditions.

However,  withdrawing  cushion  gas  from  operational  UGS  facilities  during emergencies  could pose significant technical, economic, and governance challenges, though feasible withdrawal amounts vary by facility and site-specific cushion  gas  requirements  and  would  necessitate  case-by-case  assessment. Reducing reservoir pressure below design thresholds can lower deliverability rates and degrade storage performance precisely when flexibility is most needed. In some  cases,  excessive  pressure  declines  may  cause  irreversible  damage  to storage facilities by increasing water ingress or compromising reservoir integrity. From an economic perspective, replenishing cushion gas and restoring normal storage  operations  can  be  costly  and  time-consuming,  potentially  requiring multiple  injection  seasons  and  gas  procurement  at  elevated  prices  if  adverse market  conditions  persist.  Strategic  cushion  gas  reserves  would  also  require clearly  defined  legal  and  regulatory  frameworks  and  compensation  schemes. Storage  operators  are  typically  bound  by  contractual  obligations  to  maintain minimum technical parameters, and without such safeguards, the designation of cushion gas as a strategic reserve could undermine the commercial viability of privately owned storage assets, potentially leading to storage closures.

Historically, storage operators and regulators have largely treated cushion gas as off-limits.  Documented cases of cushion gas withdrawal from commercial UGS facilities are limited and have generally occurred only after the cessation of storage operations at ageing sites. Examples include the closure of the Rough storage facility in the United Kingdom (with 3.3 bcm of working gas capacity and 5.2 bcm of recoverable cushion gas at the time) and the Southwest Kinsale gas storage facility  in  Ireland  (with  0.23  bcm  of  working  gas  and  approximately  0.4  bcm  of cushion gas), both of which ceased operations in 2017.

In  2022,  the  Rough  facility  reopened  with  a  reduced  working  gas  capacity  of 1.5 bcm. By 2025, however, its operator again signalled the potential closure of the site in the absence of government support for modernisation, citing financial losses  and  poor  operational  performance.  This  experience  illustrates  both  the technical feasibility and the economic and operational challenges associated with restoring UGS capacity once the cushion gas has been removed.

The  potential  use  of  cushion  gas  as  a  strategic  reserve  has  recently  been examined in greater detail in the Netherlands, providing one of the most developed examples of how such a mechanism could be implemented in practice, which we examine below.

## Case Study: Assessing the Potential Role of Strategic Cushion Gas Reserves in the Netherlands

The Dutch case illustrates both the potential benefits and the practical challenges associated with strategic cushion gas reserves. A 2025 industry-commissioned study  examined  the  potential  use  of  cushion  gas  for  strategic  storage  as  an alternative to permanently closing Norg, the country's largest underground gas storage facility, and immediately extracting its recoverable cushion gas. The Norg facility has a working gas capacity of about 6 bcm of L-gas and contains a further 17 bcm of low-calorific cushion gas, of which around 15 bcm is estimated to be recoverable over time. The study estimated that approximately 10 bcm can be withdrawn within a single year without modifications to existing surface infrastructure, and around 6 bcm could be recovered within six months or less.

The study concluded that designating part of Norg's cushion gas as a strategic reserve  could  represent  a  cost-effective  alternative  to  conventional  strategic storage  options,  while  preserving  the  operational  value  of  a  large  and  flexible storage site and avoiding the premature loss of a strategic asset. According to the study, implementation would require a pre-authorised emergency production plan that could be rapidly activated in emergency situations under the authority of the responsible minister.

At the same time, the study highlighted several important limitations and risks. It recognised that the strategic use of cushion gas would require public support, as

private  storage  operators  cannot  be  expected  to  bear  the  costs  and  risks  of maintaining a strategic reserve on a voluntary basis. The analysis also noted that changes in reservoir pressure could increase induced seismicity risks around the Norg  storage  site,  which  would  need  to  be  carefully  managed  and  monitored. (Norg is located near the Groningen gas field, where production was phased out between 2018 and 2023 due to increased induced seismicity).

In  addition,  the  study  underlined  challenges  related  to  gas  quality,  as  Norg  is designed for low-calorific L-gas storage, limiting its compatibility with the wider northwest European market, which is increasingly dominated by high-calorific Hgas. Nevertheless, the Norg facility continues to provide crucial flexibility for the shrinking L-gas market in parts of the Netherlands and, until the planned phase out of L-gas exports by 2030, also in parts of neighbouring France and Germany.

The concept of strategic cushion gas reserves could be applicable beyond the Netherlands, and the absence of induced seismicity risks and L-gas compatibility issues in most other parts of Europe could lower implementation barriers in other jurisdictions. However, given the risk of permanent damage to existing storage capacity that cushion gas withdrawals may cause, and the need for public support to  cover the associated costs and risks, the feasibility of strategic cushion gas reserves is likely limited to underground storage sites that are facing permanent closure.

Based on recent announcements by storage operators, European UGS facilities representing at least 9 bcm of working gas capacity are at risk of closure. Of this total, two facilities in Germany, with a combined working gas capacity of 1.5 bcm, have  already  filed  for  decommissioning  by  2027.  The  estimated  cushion  gas volume across the broader set of at-risk facilities in Europe is in the range of 20 bcm, representing a potentially significant strategic reserve largely concentrated in northwestern Europe.

Designating the cushion gas in underground storage facilities that are no longer commercially viable as strategic reserves -and providing appropriate compensation  to  their  operators  -  could  help  extend  the  operational  life  of uneconomic assets that nonetheless retain supply security value. However, the feasibility and cost-effectiveness of this approach relative to other options would require  detailed,  case-by-case  assessment.  In  particular,  the  deliverability  of cushion gas from ageing reservoirs under reduced pressure requires further study, as  storage  facilities  facing  the  highest  risk  of  closure  often  exhibit  operational challenges, including slow cycle times, reservoir quality issues, and other sitespecific technical limitations.

## 6.4 Buffer LNG schemes

In  the  wake  of  the  2022-2023  global  energy  crisis,  a  handful  of  countries implemented  various 'buffer LNG  schemes'.  Among  the  most  prominent examples are those adopted by Japan, Singapore, and Ireland.

These  schemes  aim  to  provide  governments  with  a  credible,  publicly  backed option to secure additional gas supply during periods of acute market stress, when commercial procurement alone is insufficient or prohibitively expensive. They are explicitly framed as contingency mechanisms, intended to ensure that LNG can be made available to priority end users during supply disruptions or episodes of extreme  market  tightness,  thereby  reducing  the  risk  of  physical  shortages, involuntary demand curtailment, or wider economic disruption. All three schemes involve public financial backing, whether through state ownership of assets, public funding of capacity, or government-mandated arrangements with private operators,  and  are  designed  to  operate  alongside  existing  commercial  LNG procurement and gas market structures, rather than replace them.

Despite these similarities, the schemes differ markedly in key elements of their design. Japan's Strategic Buffer LNG (SBL) scheme, for example, relies primarily on contractual and commercial arrangements. Singapore's Standby LNG Facility (SLF)  is  more  tightly  integrated  into  the  country's  power-sector  emergency framework, and physical LNG volumes are held on standby to safeguard electricity supply in a highly gas-dependent  power  system.  Ireland's  Strategic  Gas Emergency Reserve (SGER) relies on the development of a state-backed FSRUbased import and storage capacity, which can be refilled as needed, reflecting Ireland's limited gas infrastructure and heavy reliance on a single import route.

## Case study: Japan's Strategic Buffer LNG scheme

Japan  is  the  world's  second-largest  LNG  importer  after  China  and  is  almost entirely dependent on LNG imports to meet its natural gas demand. Natural gas plays an important role in Japan's energy system, accounting for roughly 20% of primary  energy  supply  and  about  30%  of  electricity  generation.  Domestic  gas production, at less than 2 bcm, accounts for only around 2% of total gas supply, and Japan  has no cross-border gas pipeline connections or large-scale underground gas storage facilities. 17  As a result, gas supply security in Japan is fundamentally tied to the availability of LNG cargoes (more than 80% of which are sourced under long-term contracts), as well as to around 300 bcm of regasification capacity (more than three times current demand). LNG tank storage capacity also

17 The combined working gas capacity of Japan's two small-scale underground storage sites is around 0.13 bcm, according to CEDIGAZ.

plays a significant role, offering the equivalent to about 12 bcm of natural gas, or around 13% of total demand, across Japan's 37 operational LNG import terminals.

Historically, Japan has attached great importance to gas and LNG supply security, reflecting its near-total import dependence and limited infrastructure flexibility. This has translated into a multi-layered strategy combining long-term LNG contracts, portfolio  diversification,  and  equity  participation  in  upstream  gas  and  LNG liquefaction projects. Public institutions, including the Japan Bank for International Cooperation,  JOGMEC,  and  Nippon  Export  and  Investment  Insurance,  have provided financing and risk mitigation for overseas LNG investments. At the same time,  Japanese  utilities  and  trading  houses  have  built  globally  diversified  LNG portfolios  to  reduce  exposure  to  individual  suppliers  and  trade  routes.  This security-oriented approach was further reinforced following the Fukushima Daiichi nuclear  accident  in  2011,  which  led  to  a  sharp  increase  in  gas-fired  power generation and LNG imports.

A renewed focus on LNG security emerged in the aftermath of a brief LNG supply crunch in early 2021, when a combination of unusually cold weather, LNG shipping bottlenecks, and constrained supply pushed utilities close to physical shortages. Those  constraints  forced  some  power  generators  to  curtail  output,  exposing vulnerabilities in Japan's LNG procurement and inventory management practices. The episode highlighted the risks of relying solely on commercial optimisation for gas  supply  security  and  prompted  a  comprehensive  review  by  the  Ministry  of Economy, Trade and Industry (METI), resulting in closer monitoring of LNG stocks, the introduction of new LNG procurement guidelines, and industry consultations to enhance cooperation during emergencies.

Japan weathered the 2022-2023 global energy crisis relatively well compared with other importing regions, thanks to a diversified LNG portfolio that includes a mix of  oil-indexed,  Henry  Hub-linked,  and  hybrid  LNG  contracts,  as  well  as  limited reliance on spot market procurement and short-term volumes. As a result, Japan's average LNG import price remained just below USD 15 per MBtu in 2022 at the height of the crisis, compared with around USD 34 per MBtu for the Asian spot LNG benchmark (JKM) and approximately USD 40 per MBtu for the European benchmark (TTF). The crisis nevertheless heightened concerns about extreme spot LNG price volatility, spillover effects from Europe into Asia, and geopolitical risks surrounding Russian LNG supplies from Sakhalin LNG, which accounts for about 9% of Japan's LNG imports.

Against this backdrop, the Japanese government moved to further reinforce its LNG supply security toolkit, culminating in the introduction of the SBL scheme under the Economic Security Promotion Act in 2022, which designated LNG as a critical  product  requiring  stable  supply.  METI  launched  the  SBL  ahead  of  the 2023/24 winter season, and it was implemented in late 2023.

The SBL framework is an innovative contractual reserve mechanism that provides emergency LNG supply flexibility at a lower cost than physical storage. Under the scheme,  METI  designates private LNG  importing companies  with strong procurement capabilities as certified supply providers, requiring them to secure additional LNG volumes beyond their normal commercial needs. Japanese energy company JERA was designated as the first, and, to date, only, SBL operator in November 2023. During the initial phase of the scheme (through January 2026), JERA was required to procure at least one additional LNG cargo per month during the  winter  season  from  December  to  February,  with  contractual  provisions ensuring that LNG could be delivered to Japan within 18 days in the event of an emergency. From January 2026, as the scheme shifted to year-round operation, the minimum SBL volume of one cargo per month was extended throughout the year, increasing the annual volume to around 1.2 bcm/yr, compared with about 0.3 bcm/yr under the initial phase.

The SBL is designed as a contractual and financial buffer, rather than a permanent physical stockpile of LNG. Under normal conditions, buffer LNG cargoes can be traded  or  resold  to  domestic  or  overseas  buyers,  but  they  remain  subject  to government  direction  if  supply  risks  materialise. Activation of the SBL  is discretionary  and  anticipatory:  METI  may  instruct  the  release  or  redirection  of buffer LNG when it judges that supply-demand conditions pose a material risk to energy security, including during periods of tight winter balances or heightened geopolitical uncertainty. As of May 2026, the SBL has not been formally activated to address a domestic supply emergency.

Allocation  decisions  are  coordinated  between  public  authorities  and  private stakeholders.  Any  losses  incurred  from  buffer  LNG  redirections  or  resales  are compensated  through  a  public  fund  managed  by  JOGMEC,  while  any  profits earned from buffer LNG transactions are returned to the fund. This structure is intended to ensure that private operators are willing to maintain buffer volumes without  bearing  disproportionate  commercial  risk,  effectively  sharing  tail-risk exposure more broadly while preserving market-based procurement and trading practices.

Japan's SBL scheme represents a hybrid model that combines public risk-sharing with  private-sector  procurement  and  trading.  While  distinct  from  infrastructurebased reserves such as Ireland's SGER or power-sector-focused mechanisms like Singapore's SLF, the SBL illustrates how contractual buffers can complement physical  capacity  and  long-term  contracting  in  strengthening  energy  security during periods of extreme stress.

Unlike the other buffer LNG schemes discussed in this chapter, Japan's SBL has the potential to be scaled up over time. One possible pathway would be to open the  scheme  to  participation  by  regional  partners  in  East  and  Southeast  Asia, allowing them to access buffer LNG in exchange for contributing to the cost of the mechanism.

## Case study: Singapore's Strategic LNG Facility

Singapore  produces  no  natural  gas  domestically  and  is  therefore  entirely dependent on imports to meet its gas demand, which was around 12 bcm in 2024. Natural gas plays a central role in the country's energy mix, accounting for about one-third  of  primary  energy  supply,  and  gas  remains  the  dominant  fuel  for electricity  generation.  Singapore  imports  gas  through  a  combination  of  LNG shipments and pipeline gas from neighbouring Indonesia and Malaysia. Net LNG imports  exceeded  8  bcm  in  2024  and  approached  9  bcm  in  2025,  more  than doubling since 2018, while pipeline gas imports declined by approximately 30% over the same period.

The power generation sector dominates Singapore's gas demand, accounting for more than 85% of total gas use, with most of the remainder consumed by industry. Residential and commercial sector use accounts for a much smaller share of gas use. Within the power sector, gas-fired generation is overwhelmingly dominant, accounting  for  almost  95%  of  electricity  output  in  2024,  underlining  the  strong linkage between gas supply security and electricity security in Singapore's energy system.

A cold spell  in  northeast  Asia  in  January  2021  sent  shockwaves  across  LNGimporting markets in Asia and triggered a brief but exceptionally sharp price spike. In response, the Asian spot LNG benchmark JKM rose temporarily above USD 30 per MBtu, the highest level on record at the time. Although Singapore was spared severe physical shortages, the episode underscored the vulnerabilities associated with global LNG market volatility, long supply chains, and reliance on a limited set of supply sources. Market conditions progressively tightened throughout the rest of the year, while Indonesia's announcement that pipeline gas supplies could end by 2023  (subsequently  extended  to  2028)  added  further  uncertainty  and exacerbated the price increases sparked by the cold spell. The episode ultimately prompted Singapore to seek backup options to enhance gas supply resilience, particularly  for  power  generation  companies  that  depend  on  an  uninterrupted supply of gas. In response, Singapore's Energy Market Authority (EMA) proposed and implemented the SLF in 2021 as a preemptive energy security measure to ensure that gas for power generation remains available during supply disruptions or adverse market conditions. The SLF was framed not as a price-stabilisation tool, but as an instrument to enhance the reliability of gas and electricity supply, allowing power generators to access additional LNG supplies when needed and for the regulator to coordinate such access in an emergency.

In October 2021, the EMA appointed Singapore LNG Corporation (SLNG) as the manager of the SLF. In this role, SLNG was responsible for procuring, managing, and facilitating the drawdown and replenishment of LNG supplies made available to licensed power  generation  companies.  SLNG's  mandate  also  included

coordination  with  generation  companies  and  the  gas  transporter,  PowerGas Limited, a subsidiary of Singapore Power, to ensure that gas can be sent out and delivered as instructed by the EMA in the event of a supply shortfall.

Based on publicly available information, there have been no confirmed instances to date in which power generation companies needed to use the SLF to address fuel  shortages.  To  support  the  system,  an  FSRU  and  an  LNG  carrier  were deployed as floating storage in Singapore in 2022, but this interim arrangement ended in early 2023.

In  May  2025,  Singapore's  government  established  the  state-owned  Singapore GasCo Pte  Ltd.  (GasCo)  to  centralise  the  procurement  of  natural  gas  for  the country's power generators and strengthen gas supply security and price stability. On 1 April 2026, GasCo assumed the role of SLF manager from SLNG and has since maintained physical buffer LNG stocks in Singapore's existing LNG storage tanks, complementing other energy stockpiles such as crude oil and diesel fuel. To increase storage and send-out capacity, SLNG has committed to developing a separate FSRU-based terminal, the second LNG import terminal in Singapore. The terminal located at Jurong Port has a nameplate capacity of 5 million tonnes per annum (around 7 bcm/yr) and is expected to start operations by 2030.

Although originally conceived as a temporary measure, the operational framework of  the  SLF  is  now  expected  to  remain  in  place  as  a  permanent  feature  of Singapore's energy market until further notice by the EMA, reflecting the country's ongoing commitment to maintaining buffer LNG capability.

Like  Japan's  and  Ireland's  buffer  LNG  schemes,  Singapore's  Standby  LNG Facility is a  publicly  backed  mechanism  to  safeguard  LNG  supply  during emergencies. However, unlike Japan's SBL, which relies primarily on contractual arrangements, and Ireland's SGER, which is anchored in state-owned physical import infrastructure, Singapore's SLF is more tightly integrated into the power sector and leverages existing LNG  terminal capacity and market-based procurement procedures to achieve its objectives.

## Case study: Ireland's Strategic Gas Emergency Reserve

Ireland's energy system is heavily dependent on natural gas, which accounted for about  one-third  of  the  primary  energy  mix  and  around  half  of  the  country's electricity mix in 2024, with gas-fired generation supplying up to 80% of Ireland's electricity during periods of peak demand. Despite this significant role, Ireland's domestic gas production is relatively limited, at around 1 bcm in 2024, accounting for roughly 20% of the country's total gas consumption of about 5 bcm. Following the closure of the Kinsale Head gas field in 2020, the Corrib field off Ireland's

northern  coast  remains  the  country's  only  source  of  domestic  gas  production. Output from this field has been in decline since 2017 due to depletion, with further declines expected in the coming years.

Consequently, around 80% of Ireland's natural gas supply is imported from the United Kingdom via two subsea interconnector pipelines that both originate at the same exit point in Moffat, Scotland. Ireland is among only a handful of EU member states without any underground gas storage infrastructure, following the closure of the Southwest Kinsale gas storage facility in 2017. This combination of high import dependence and the absence of storage means that Ireland does not meet the European Union's N-1 infrastructure standard, which requires member states to  be  able  to  satisfy  total  gas  demand  on  a  day  of  exceptionally  high  demand (defined as a 1-in-20-year event) even after the loss of the single largest piece of gas infrastructure.

Ireland has set out ambitious targets to decarbonise its energy system in line with EU objectives. The government's Climate Action Plan calls for a 51% reduction in greenhouse gas emissions by 2030 relative to 2018 levels, and climate neutrality by  2050.  Those  goals  will  require  a  diminishing  role  for  fossil  fuels,  including natural gas, over the coming decades. According to a 2022 demand projection by Gas Networks Ireland, the country's gas transmission system operator, annual gas consumption could fall by nearly 25% between 2024 and 2030 in the 'best estimate'  demand scenario, driven by the expansion of renewable generation, improvements in energy efficiency, and the electrification of heat and transport.

Given the expectation of diminishing natural gas use over time, supply security solutions with long lead times (for example, UGS investments or onshore LNG import terminals) are not relevant to the Irish context and are therefore difficult to justify  under  the  current  policy  framework.  Over  the  last  decade,  Ireland  has considered commercial FSRU initiatives, including the Shannon FSRU and Cork FSRU  projects,  to  supplement  pipeline  imports  and  enhance  supply  flexibility without locking in infrastructure. However,  none  of  these  initiatives have materialised on a commercial basis.

The 2022-2023 energy crisis highlighted Ireland's structural vulnerability to gas supply security risks and prompted the government to launch a comprehensive review as part of the Energy Security in Ireland to 2030 plan, which was approved in  November  2023.  Among  the  plan's  28  action  items,  one  called  for  the development of an SGER to protect against major supply disruptions and bring Ireland into compliance with the EU's N-1 infrastructure standard.

Following detailed studies by Gas Networks Ireland, the government determined that the best option for a strategic reserve would be a state-owned FSRU facility. The FSRU will be capable of receiving LNG shipments, storing them on board, and  regasifying  the  LNG  for  injection  into  Ireland's  gas  network  during  an

emergency. To avoid gas losses due to boil-off, the scheme envisages a minimum continuous send-out of gas from the FSRU into the Irish gas grid, with the facility refilled up to six times per year to replenish the injected volumes.

In March 2025, the government formally approved the development of the stateled SGER, to be owned and operated by Gas Networks Ireland on behalf of the government and run as a non-commercial, emergency-only facility. The SGER infrastructure will centre on an FSRU moored at a deep-water jetty, complemented by an onshore reception facility and a new connection to the national gas network. After  evaluating  multiple  potential  sites,  Cahiracon  along  the  Shannon  Estuary was selected as the preferred location due to its favourable deep-water access, proximity to existing infrastructure, and technical suitability.

The FSRU will act as a standby source of natural gas, activated only in the event of  a  significant  disruption  to  Ireland's  conventional  pipeline  imports.  In  such  a scenario, LNG would be supplied to the FSRU by ship, regasified, and delivered into  the  domestic  network  to  help  maintain  gas  supply  for  heating,  electricity generation,  and  industrial  uses  while  pipeline  routes  are  restored.  The  policy documents emphasise the temporary nature of the SGER. Once Ireland's energy system has sufficiently diversified and the risk of a major gas supply disruption have diminished, the FSRU could be decommissioned or repurposed, with the onshore  infrastructure  adapted  for  other  uses,  including  the  handling  of  lowemissions gases.

As  of  mid-2026,  legislative  and  regulatory  frameworks  are  being  updated  to support the development of the project. Those frameworks include amendments to Gas Networks Ireland's statutory functions to enable it to manage the reserve, as well as provisions for cost recovery and regulatory oversight. At the time of writing,  no  FSRU  vessel  has  been  secured,  and  the  timeline  for  the  start  of operations  is  uncertain,  although  reports  indicate  that  inquiries  for  available FSRUs for Ireland's SGER were made at the end of 2025.

Ireland's SGER differs from other buffer LNG schemes, for example Japan's and Singapore's,  in  several  respects.  Most  notably,  Japan  and  Singapore  already possess LNG import infrastructure and regasification capacity, whereas Ireland currently  has  no  LNG  import  terminals.  Unlike  Japan's  approach,  which  relies largely on contractual arrangements with designated private operators to procure and redirect LNG, Ireland's reserve is state-owned, state-operated, and tied to dedicated physical import and regasification infrastructure. Similarly, the SGER is not  designed  to  safeguard  a  particular  downstream  sector  (such  as  power generation in Singapore), but rather to provide system-wide gas supply continuity across the national economy in the event of a major supply disruption. But like the

schemes in Japan and Singapore, Ireland's SGER is framed as an emergencyonly mechanism and is backed by public funding, reflecting a shared emphasis on resilience to severe market shocks or supply curtailments.

## Prospective cross-regional buffer LNG schemes

In the future, mixed UGS-LNG buffer schemes could be developed on a crossregional basis, particularly between Europe and Asia, by leveraging UGS capacity in storage-rich  markets  to  enhance  security  of  supply  for  LNG-dependent importers. Under such arrangements, LNG-importing countries without sufficient domestic storage capacity (or countries that rely primarily on more costly LNG tank storage) could hold gas inventories in UGS facilities located in partner countries, particularly in Europe. Such arrangements could be carried out under predefined commercial  and  regulatory  frameworks.  In  normal  market  conditions,  these volumes could be commercially managed, while remaining contractually earmarked for emergency use.

In the event of a supply disruption, a cross-regional scheme could rely on preagreed swap-type mechanisms, whereby LNG suppliers or portfolio players with market  coverage  in  the  storage-hosting  country  deliver  LNG  cargoes  to  the importing  country  in  exchange  for  the  release  of  equivalent  gas  volumes  from storage. Price differentials could be settled in advance, or according to predefined contractual formulas.

Such arrangements would allow LNG importers to build strategic buffers in the form  of  stored  gas  rather  than  LNG,  thereby  reducing  storage  costs  while maintaining  access  to  physical  supply  during  crises.  At  the  same  time,  host countries could benefit from higher storage utilisation rates and improved market liquidity.  However,  the  commercial  viability  of  such  schemes  would  depend  on public support from LNG-dependent importers to cover the cost of procuring and storing  gas,  as  well  as  on  robust  contractual  design  and  effective  risk-sharing mechanisms  among  participants.  A  key  constraint is the limited pool of counterparties capable of both maintaining a strong market presence in European gas  markets  and  reliably  delivering  LNG  cargoes  to  Asian  buyers,  which  may restrict scalability and operational feasibility.

## 7. Options to increase international cooperation

Close international cooperation can complement national-level preparedness and is essential to strengthen gas security in a market environment that is increasingly interconnected  but  geopolitically fragile. The  IEA  oil emergency  response framework provides the most advanced example of collective action in energy security, combining a coordinated asset base, well-defined governance arrangements and tested stock release mechanisms. While fundamental differences between oil and gas markets limit the direct applicability of this model, its underlying principles offer valuable lessons for the development of voluntary gas reserve mechanisms among like-minded importing and exporting countries.

This chapter outlines a range of options to enhance international cooperation on gas  reserves  and  market  flexibility.  The  recommendations  cover  measures  to strengthen  coordination  and  dialogue,  increase  transparency,  enhance  market flexibility, and explore new reserve mechanisms. Taken together, they provide an extensive  set  of  options  for  governments  to  build  strategic  buffers,  enhance resilience, and support more coordinated and effective responses to gas supply disruptions.

## 7.1 Lessons from the IEA oil emergency response framework

The  oil  emergency  response  mechanism  under  the  IEA's  founding  treaty,  the Agreement on an International Energy Programme, is the most formalised system for the collective management of global energy supply emergencies. Introduced in 1974 following the 1973 oil crisis, the framework was designed to mitigate major oil supply disruptions through a combination of mandatory stockholding obligations, coordinated response mechanisms, and well-established governance arrangements.

The IEA oil emergency response system requires member countries to hold oil stocks equivalent to at least 90 days of net imports. Many countries hold stocks specifically for emergency purposes, which can be held directly by governments, by agencies (acting either on behalf of governments or industry), or by obligated industry  participants  fulfilling  minimum  stockholding  requirements  set  by  their respective  governments.  Emergency  oil  stocks  may  be  held  domestically  or abroad  under  bilateral  agreements  between  governments,  which  guarantee

access during emergencies. Emergency oil stocks can take the form of directly held  inventories  or  so-called  'ticketing'  arrangements,  under  which  the  seller agrees to hold a specified volume of oil on behalf of the buyer in exchange for an agreed  fee,  and  in  some  cases,  the  right  to  buy  the  stocks  under  specific circumstances.

The IEA framework allows countries to meet their stockholding obligations using either crude oil or refined petroleum products, depending on national circumstances. Countries with large refining sectors tend to hold a higher share of crude oil, which provides greater flexibility during crises. By contrast, countries with  limited  domestic  refining  capacity,  or  those  relying  heavily  on  imports  of refined products, typically maintain a larger share of their reserves in the form of petroleum products.

In the event of a significant supply disruption, the IEA can coordinate a collective response with member states, focused on the release of oil stocks. The roles and processes underpinning a stockdraw are well defined and well established. In the case of an actual or potential disruption, the IEA Secretariat first assesses the potential market impact and the need for a coordinated response. The decision to initiate  a  collective  action  can  be  made  in  a  matter  of  days,  following  an assessment of the scale of the disruption and prevailing market conditions, as well as  consultations  with  member  governments  and  industry  experts  (through  the IEA's Industry Advisory Board).

Following  this  consultation,  and  in  the  absence  of  objections  from  member countries  to  the  proposed  joint  action,  the  IEA  executive  director  issues  an activation notice accompanied by a press release. Member country shares of the collective action are calculated based on a proxy for their share of total IEA oil consumption, known as Base Period Final Consumption. Member countries are requested confirm the details of their intended contribution to a collective action within 24-48 hours after the activation notice.

Coordinated oil stock releases may be complemented by demand restraint, surge production, and/or fuel-switching measures. These emergency response procedures are regularly tested and evaluated through formal exercises and peer reviews.

The IEA emergency response system was designed to address sudden, shortterm oil supply disruptions, but it is not intended as a tool for price intervention or long-term supply management.

Since its creation, the IEA has undertaken six collective actions: in 1991 in the lead-up to the Gulf War; in 2005 following hurricanes Katrina and Rita; in 2011 during the Libyan civil war; in 2022 on two separate occasions during the Russian invasion of Ukraine and the ensuing energy crisis, and in March 2026 during the conflict in the Middle East.

The oil supply emergency framework offers important lessons for gas security, even  if its direct transferability to natural  gas  and  LNG  is  fundamentally constrained by structural differences between oil and gas markets. Oil is a globally fungible  commodity  that  is  relatively  easy  and  cost-effective  to  store  in  large volumes for extended periods. By contrast, gas storage is more complex, capitalintensive, and geographically constrained. Underground gas storage depends on suitable geological formations, while LNG storage requires specialised cryogenic infrastructure with significantly higher unit costs. As a result, replicating a universal stockholding obligation comparable to the IEA's 90-day oil requirement is neither technically nor economically feasible for most gas-importing countries.

Differences in market structure further limit direct transferability. Oil markets are highly  liquid and  globally  integrated,  with  well-developed  spot  trading  and relatively flexible logistics. Although the expansion of LNG trade has increased the interconnectivity of gas markets, natural gas remains more regionally segmented and infrastructure  dependent. Supply-side flexibility  is  also  more  limited  in  gas systems. While oil markets can often draw on spare production capacity in some exporting countries, gas production and LNG liquefaction typically operate close to the available maximum capacity, leaving little scope for rapid supply increases. The fungibility of oil also differs fundamentally from that of natural gas. A barrel of crude  oil  or  refined  petroleum  product  released  into  the  market,  regardless  of location, tends to have a broadly similar impact on global balances and prices. By contrast, the impact of additional gas supply is far more location-specific: releasing a given volume of gas in one region does not automatically alleviate tightness elsewhere, particularly where interconnection capacity or LNG import infrastructure is limited.

Despite these limitations, several core principles that underpin the oil emergency response framework are highly relevant for gas security.

-  Multilateral institutional framework and governance arrangements. One of the key strengths of the oil system lies in its pre-established, rules-based coordination mechanisms. Clearly defined procedures help enhance predictability,  reduce  uncertainty  and  enable  rapid  collective  action  during crises. The institutional architecture developed under the IEA oil emergency response  mechanism,  including  formal decision-making processes  and structured engagement with industry, provides a useful model for strengthening  coordination  in  gas  markets,  where  comparable  frameworks remain less developed.
-  Single,  well-defined  asset  base  for  collective  action. In  the  case  of  oil, emergency stocks held under the 90-day stockholding requirement provide a broad and relatively uniform foundation for coordinated response measures. By contrast, gas markets currently lack an equivalent shared asset base for collective action. Potential alternatives, such as jointly managed strategic gas

storage,  portfolios  of  gas  or  LNG  stocks  held  abroad,  or  pooled  LNG  calloption arrangements, could, in principle, serve a similar function. However, these  instruments  are  more  complex  to  implement,  depend  on  specific infrastructure conditions and availability, and are unlikely to reach the scale, uniformity, or accessibility of oil stocks.

-  Reliance  on  private  actors  for  public  policy  implementation. The  oil emergency  response system combines public policy frameworks with implementation  by  private  industry,  including  stockholding,  logistics,  and distribution. This hybrid model  is also relevant for gas, where  most infrastructure,  storage,  and  trading  activities  are  owned  and  operated  by private  entities.  Effective  gas  security  frameworks  therefore  require  close coordination between governments and market participants to ensure policy objectives are aligned with operational realities.
-  Interchangeability  of  multiple  types  of  reserves. The  oil  system  allows countries to meet their stockholding obligations using either crude oil or refined petroleum products, as well as through a combination of physical barrels and paper tickets, depending  on  national circumstances and  infrastructure constraints. Gas reserve mechanisms could draw lessons from this approach and explore how - and to what extent - different forms of reserves, such as gas held in underground storage and LNG stored in tanks, or physical volumes and call option-based 'paper' instruments, can be integrated into a broader reserve base to support collective action.
-  Cross-border  storage  and  ticketing  arrangements. Oil-style ticketing systems, under which one party holds stocks on behalf of another in exchange for a fee, could be adapted to gas in certain contexts. This may be particularly relevant for accessing underutilised physical storage assets, including underground storage capacity, for example, in Ukraine, or for LNG storage facilities with reloading capabilities, for example in Spain. Such arrangements could help optimise the use of existing infrastructure and provide additional flexibility without requiring domestic storage capacity.
-  Regular emergency reviews, exercises, and trainings. Under the IEA oil emergency framework, regular reviews, exercises, and training sessions are conducted to test procedures, identify bottlenecks, and strengthen preparedness across member countries. Comparable practices remain less developed in gas markets, where crisis response mechanisms are often less formalised or limited to the regional level. Similar reviews, joint exercises and training programmes - potentially complemented by scenario analysis and the sharing of best practices - could also be adopted in voluntary gas reserve mechanisms.

## 7.2 Recommendations

## Summary

The  recommendations  presented  in  the  report  focus  on  four  areas  where governments can advance international cooperation on gas reserves and market flexibility.

## 1. Cooperation and dialogue

-  Deepen cooperation through existing platforms, including through the IEA.
-  Establish other consultative forums and industry advisory bodies.
-  Conduct regular emergency exercises.
-  Undertake joint studies on reserve mechanisms.
-  Facilitate the exchange of best practices.

## 2. Transparency

-  Establish a framework for information sharing on reserve mechanisms and policies impacting gas security.
-  Strengthen data transparency via standardised and timely reporting.
-  Enhance LNG contract transparency within legal and confidentiality limits.

## 3. Deepening market flexibility

-  Support  the  development  of  LNG  reloading  infrastructure  and  third-party access.
-  Establish a working group on LNG swaps.
-  Facilitate the relaxation of restrictive clauses in legacy LNG contracts.
-  Encourage flexibility in new LNG contracts.

## 4. Developing voluntary gas reserve mechanisms

-  Assess the feasibility of a joint strategic gas reserve in Ukraine.
-  Enable cross-border stockholding arrangements.
-  Study options for strategic floating storage using existing LNG vessels.
-  Evaluate the use of cushion gas as strategic reserve.
-  Explore the development of cross-regional buffer LNG schemes.
-  Assess  the  feasibility  of  pooling  LNG  call  options  into  a  jointly  managed security buffer.

The recommendations presented below focus on four areas where governments can  most  effectively  advance  international  cooperation  on  gas  reserves  and market  flexibility:  coordination  and  dialogue,  transparency,  deepening  market flexibility, and the development of voluntary gas reserve mechanisms. They are intended to strengthen system resilience in the short to medium term, rather than address longer-term questions of supply adequacy or investment across the gas value chain. These recommendations are not the end point of the discussion, but rather a starting point for further work. Several of the concepts outlined in this chapter  would  benefit  from  additional  analysis  and  targeted  follow-up  studies, including on the feasibility and governance of joint strategic gas reserves, pooled LNG  call  options,  cross-regional  buffer  schemes,  cross-border  stockholding arrangements, and mechanisms to facilitate LNG swaps. The IEA stands ready to provide such a platform for deeper international cooperation, knowledge sharing, and analysis on these and other emerging gas security issues.

## Coordination and dialogue

Deepen cooperation through existing platforms, including the IEA's Natural Gas and Sustainable Gases Security Working Party (GWP).

Existing  multilateral  platforms  such  as  the  IEA's  GWP  provide  a  ready-made institutional foundation for strengthening coordination among gas-importing and exporting countries. 18  Expanding their role could help move beyond information exchange  towards more  structured coordination on reserve mechanisms, emergency response frameworks, and market developments. Deepened cooperation  could  focus  on  regular  engagement  at  both  technical  and  policy levels, enabling countries to align expectations on global gas market dynamics and share forward-looking assessments of supply security risks. Over time, such platforms could evolve into coordination hubs that facilitate collective responses among  like-minded  importers  and  exporters  during  supply  disruptions  on  a voluntary basis.

Establish additional consultative forums, such as industry advisory bodies, to strengthen public-private dialogue on policies related to market flexibility and gas reserve mechanisms.

Given that much of the flexibility in gas and LNG markets is controlled by private companies, including producers, portfolio players, utilities, and traders, effective gas  reserve  mechanisms  require  close  engagement  with  industry.  Dedicated consultative forums and industry advisory boards can help bridge the gap between public policy objectives and commercial realities, ensuring that reserve

18 The GWP was established in 2025 as a dedicated platform to support its members in addressing gas supply security challenges. It aims to strengthen the resilience of natural gas systems through enhanced market monitoring, improved data and information sharing, and closer coordination among member countries and other key stakeholders.

mechanisms and flexibility measures can be implemented and do not interfere with the functioning of liberalised energy markets. Such forums could also provide early feedback on regulatory proposals, identify unintended consequences, and support  the  development  of  novel  commercial  solutions,  such  as  buffer  LNG schemes or new types of contractual arrangements. Drawing on industry expertise is particularly important in areas where operational constraints are complex and significant, such as LNG shipping, trading, contracting, and storage operations.

## Conduct regular emergency exercises to simulate gas supply disruptions and test existing and proposed reserve tools and policy mechanisms.

Under  the  IEA  oil  emergency  response  framework,  emergency  exercises  and security reviews are conducted regularly to reinforce decision-making processes and strengthen coordination among member countries. Comparable exercises are less common in gas markets and, where they exist, are often limited to the national or  regional  level.  Expanding  the  use  of  joint  exercises  in  gas  systems  could therefore help strengthen emergency preparedness and inform the development of  voluntary  gas  reserve  mechanisms.  Simulations  could  cover  a  range  of disruption scenarios, including major LNG supply outages, infrastructure failures, geopolitical shocks, and extreme weather events. By involving public authorities and,  where  appropriate,  private  stakeholders,  such  exercises  can  help  test operational readiness, clarify decision-making processes, and identify bottlenecks in  activating  reserve  mechanisms.  Drawing  on  practices  from  established  oil emergency  frameworks,  regular  exercises  can  also  support  the  refinement  of coordination procedures and contribute to more timely, predictable, and effective responses during actual emergencies.

Undertake joint studies to assess the cost of various reserve mechanisms, evaluate  the  feasibility  of  innovative  technical  and  commercial  concepts, and explore governance models for shared strategic gas stocks.

The diversity and complexity of potential reserve mechanisms - from strategic underground storage and cushion gas reserves to contractual instruments and buffer LNG schemes - require a strong analytical foundation. Joint studies can help quantify the costs, benefits, and trade-offs of different approaches across regions with varying infrastructure and market structures, taking into account the high capital intensity and long lead times associated with many physical storage options.  Collaborative  research  can  also  explore  emerging  concepts,  such  as pooled  LNG  call  options,  cross-border  storage  arrangements,  buffer  LNG schemes, and floating LNG storage, which lack extensive real-world experience. It can  also  support  the  development  of  governance  frameworks  for  shared reserves,  partly  drawing  on  experience  from  more  established  oil  emergency management frameworks.

Facilitate the exchange of best practices among like-minded importers and exporters on emergency response frameworks, strategic gas reserves, LNG contracting, and operational practices.

Experience sharing is a low-cost, high-impact tool for strengthening gas reserve mechanisms  and  overall  system  resilience.  Countries  have  adopted  diverse approaches  to  managing  their  natural  gas  systems,  including  storage,  LNG contracting, and  emergency  response  plans.  The  systematic  exchange  of experiences  can  accelerate  the  adoption  of  effective  policy  tools  by  enabling countries  to  learn  from  each  other's  successes  and  challenges.  For  example, experience  from  Europe's  mandatory  storage  obligations  and  strategic  gas reserves,  Japan's  SBL  scheme,  and  Singapore's  Standby  LNG  Facility  offers valuable lessons for other import-dependent economies. In addition to policy and regulatory design, operational practices, such as linepack management and LNG terminal  operations,  could  also  benefit  from  greater  cross-border  knowledge sharing through structured exchanges,  including workshops  and  technical cooperation programmes.

## Transparency

Establish a framework  for regular information sharing with partner governments on current and planned gas reserve mechanisms and policy developments related to market flexibility.

Greater transparency and regular information sharing on existing and planned gas reserve mechanisms and policy measures related to market flexibility can reduce uncertainty, improve coordination, and help governments anticipate each other's actions,  particularly  during  periods  of  market  stress.  Enhanced  visibility  over national strategies, storage policies and contingency measures, while ensuring that commercially sensitive information is appropriately protected, would reduce the  risk  of  unintended  market  distortions  and  help  identify  opportunities  for cooperation.

Strengthen data transparency through standardised and timely reporting of gas and LNG stocks, the operational status of LNG tanks, and reloading capabilities at LNG import terminals.

Reliable and timely data is essential for well-functioning gas reserve mechanisms and  effective emergency  response.  However,  the  availability,  quality, and timeliness of reporting - particularly on gas storage levels, LNG inventories, and infrastructure availability in importing countries - remain uneven across regions. Improved transparency and more standardised reporting frameworks, potentially coordinated through international organisations, could enhance comparability and support coordination during crises. Greater data availability among participating

governments,  while  ensuring  that  confidentiality  is  appropriately  safeguarded, would also provide timely insights into system tightness and available flexibility levers, enabling more effective responses to supply disruptions.

Enhance transparency of LNG contracts by regularly reporting aggregated, non-confidential information on key LNG contract terms relevant to market flexibility.

While  LNG  contracts  are  confidential  and  specific  terms  are  commercially sensitive,  publishing  aggregated  information  on  destination  restrictions,  profitsharing clauses, seller consent requirements, volume flexibility, and cancellation rights  can  help  policymakers  assess  system  resilience  and  identify  structural constraints without compromising commercial confidentiality. Existing efforts, such as monitoring by JOGMEC, demonstrate the value of such approaches. Improved transparency  could  also  support  more  informed  decision-making  by  market participants, reduce information asymmetries, and facilitate the adoption of more flexible  contracting  practices  over  time  by  highlighting  trends  and  enabling  the benchmarking of contract structures across markets.

## Deepening market flexibility

Support  the  development  of  LNG  reload  infrastructure  and  third-party access  to  underutilised  LNG  import  terminals,  particularly  in  Asia,  to improve overall market flexibility, facilitate cross-border stockholding, and improve the utilisation of existing LNG storage assets.

Expanding  reloading  capabilities  and  ensuring  effective  third-party  access  to underutilised LNG terminals, where needed, would allow stored LNG volumes to be redirected across regions, improving the system's ability to respond to supply disruptions. This would also enable LNG inventories to be held on behalf of other countries  and  mobilised  when  needed,  similar  to  cross-border  stockholding arrangements in oil markets. Given that only a limited share of global LNG storage capacity currently combines reloading capability with third-party access (especially  in  Asia),  targeted  investments  and  regulatory  reforms  could  unlock significant additional flexibility. While LNG tanks are unlikely to serve as largescale strategic reserves, improved reloading infrastructure and third-party access could enhance their role as complementary buffer assets within the global gas security architecture.

Establish a working group on LNG swaps to identify measures to streamline and  facilitate  swap  transactions,  including  through  the  development  of 'matchmaking' platforms.

Physical LNG swaps can enhance market flexibility and enable faster reallocation of  supply  during  disruptions,  but  their  use  remains  constrained  by  operational,

contractual, and administrative complexities. A dedicated working group comprising policymakers and industry experts could identify practical solutions to reduce these barriers, including streamlining documentation, aligning procedures, and improving coordination among market participants. Priorities could include the development of pre-established emergency frameworks with expedited procedures,  simplified  documentation,  accelerated  regulatory  approvals  and, where  appropriate,  temporary  widening  of  quality  tolerances  during  supply emergencies. In parallel, 'matchmaking' platforms could facilitate the exchange of non-binding expressions of interest and enable faster identification of compatible counterparties. Such measures could lower transaction costs and support more effective use of swaps, including during supply disruptions.

## Facilitate  the  removal  or  relaxation  of  restrictive  clauses  in  legacy  LNG contracts,  including  through  public-private  dialogue  and  consultation among importers and exporters.

Legacy  LNG  contracts  may  still  contain  provisions  that  can  significantly  limit flexibility, including destination restrictions, profit-sharing clauses, seller consent requirements, and rigid volume commitments. Where these continue to persist and  no  longer  reflect  the  preferences  of  the  contracting  parties,  they  can  be addressed directly by market participants through renegotiation via price review and  reopener  clauses  or  arbitration.  Governments  can  support  this  process through  enhanced  market  monitoring,  competition  policy  enforcement,  and structured dialogue with industry. While preserving contract sanctity and maintaining incentives  for  long-term  investment  remain  essential,  targeted  and coordinated  efforts  could  gradually  reduce  these  rigidities  and  improve  market flexibility, especially during periods of market stress.

## Encourage  the  development  of  minimum  flexibility  standards  in  LNG contracts, potentially through coordinated buyer initiatives or platforms.

Establishing  common  expectations  for  LNG  contract  flexibility,  particularly  with respect  to  destination  flexibility, profit-sharing, seller consent,  and  volume flexibility, can help shift market norms over time. While formal standardisation may be  difficult,  voluntary  alignment  among  buyers,  potentially  through  coordinated platforms, could create collective leverage to promote more flexible terms in new LNG contracts. Such measures could improve market efficiency and resilience, but implementation would face commercial and legal constraints and would need to  comply  with  applicable  competition  law.  They  could  also  have  unintended effects on market structure and competition, including by favouring larger portfolio players  with  greater  access  to  diversified  supply  and  shipping  capacity  over smaller suppliers, and would therefore require careful analysis and further study.

## Options to create voluntary gas reserve mechanisms

Assess the feasibility of establishing a joint strategic gas reserve in Ukraine, including governance frameworks, financing, and risk mitigation mechanisms, subject to improved security conditions.

Ukraine's  large  and  underutilised  underground  gas  storage  capacity  offers  a potential opportunity to develop a shared strategic gas reserve for Europe and possibly for a broader group of LNG-importing countries. With around 10-15 bcm of  available  capacity,  such  a  mechanism  could  provide  a  sizeable  and  flexible reserve that can be called upon in emergency situations. However, its cost and feasibility  remain  uncertain  and  require  careful  assessment.  Key  challenges include the joint reserve's governance framework, including ownership of stocks, access rights, and release conditions; the allocation of financial responsibilities, including  funding  for  gas  procurement  and  risk-sharing  arrangements;  and  the management of security risks related to infrastructure. In addition, the extent to which a Ukraine-based joint reserve could support markets beyond Central and Eastern Europe, especially more distant LNG-dependent regions in Asia, would depend on the availability of cross-border capacities, cost-effective transit tariffs, and well-functioning LNG trade and swaps. While the ongoing war in Ukraine limits the feasibility of such a mechanism in the near term, a jointly managed reserve in Ukraine could, in a post-conflict environment, become a key element of regional and  potentially  inter-regional  gas  security  architecture  if  supported  by  robust institutional arrangements and public-sector backing.

Enable or expand  cross-border stockholding arrangements, allowing countries to store gas and LNG inventories in third countries under bilateral agreements or ticketing mechanisms, while ensuring access in emergencies.

Cross-border stockholding can increase the efficiency and utilisation of existing storage infrastructure and provide additional flexibility for countries with limited domestic storage capacity. Similar arrangements are already widely used in oil markets, where countries can meet part of their strategic stockholding obligations under the IEA's oil emergency response mechanism by holding stocks abroad under bilateral government agreements or through so-called ticketing mechanisms. Comparable approaches also exist within the European Union under the  EU  Gas  Storage  Regulation.  Building  on  such  models  and  extending  their application more broadly, particularly to countries without existing cross-border storage arrangements, would require tailored regulatory and commercial frameworks, given the more complex and infrastructure-dependent nature of gas storage. Key requirements include clearly defined and enforceable access rights during  emergencies,  sufficient  LNG  reloading  infrastructure  to  enable  the  reexport  of  stored  volumes,  and  robust  contractual  arrangements  to  ensure  that stored gas or LNG can be mobilised and redirected efficiently, potentially through

pre-arranged swap mechanisms. If these challenges can be overcome, and such arrangements can be demonstrated to be cost-effective, cross-border stockholding could meaningfully enhance supply security, particularly for LNGdependent economies in Asia.

## Develop strategic floating storage options by retaining ageing LNG carriers, including through public support, conversion to FSUs, or incentives to delay scrappage to preserve emergency storage capacity.

The ageing segment of the current LNG carrier fleet represents a potential source of flexible, short-term storage capacity in markets that already have access to LNG import  infrastructure.  Retaining  selected  vessels  for  strategic  use  (either  as converted FSUs or as conventional LNG carriers deployed for floating storage) could provide a relatively low-cost buffering option in the short term, complementing  existing  reserve  mechanisms  without  requiring  large  capital investments. Public support would likely be needed to incentivise shipowners to delay scrappage or convert vessels for storage purposes. Due to operational and technical  constraints,  including  boil-off,  maintenance  requirements,  and  high operating  costs,  floating  LNG  storage  is  not  suitable  for  long-term  reserves. However, where the necessary import infrastructure is  already  in  place,  it  can potentially provide short-term buffering capacity during acute market disruptions, when the rapid deployment of substitute volumes is critical.

## Evaluate the use of cushion gas as a strategic reserve, including appropriate compensation mechanisms for storage operators and technical feasibility assessments.

Cushion gas in underground storage facilities represents a potentially significant but complex source of emergency supply. Its use as a strategic reserve could provide  additional  flexibility  without  requiring  new  infrastructure  investment. However, tapping into cushion gas requires careful technical assessment to avoid damaging  storage  facilities,  reducing  deliverability  and  undermining  long-term system flexibility.  The  most  relevant  use  cases  are  likely  to  be  sites  at  risk  of permanent closure, where designating cushion gas as a strategic reserve could help preserve the supply security value of these assets that might otherwise be lost. Public support and compensation mechanisms would be essential to ensure that storage operators are not adversely affected and to maintain incentives for continued operation. At the same time, such measures would need to be carefully designed to avoid unintended consequences. The feasibility and costeffectiveness of this approach relative to alternative reserve options would require a detailed, case-by-case assessment. While not a universal solution, cushion gas could provide a valuable emergency  backstop  in specific circumstances, particularly for underutilised sites facing closure.

Explore cross-regional buffer schemes, based on underground storage and LNG swap mechanisms, enabling LNG importers to store gas abroad and access LNG in emergencies through pre-arranged exchanges.

Cross-regional buffer schemes could combine the cost advantages of underground  gas  storage  with  the  flexibility  of  LNG  supply.  By  storing  gas  in regions with abundant storage capacity, particularly in Europe, and accessing it in the form of LNG through swap arrangements during emergencies, LNG-importing countries with limited or high-cost domestic storage could build strategic buffers at lower  cost.  Such  arrangements  could  complement  commercial  portfolio flexibility by underpinning swap mechanisms with dedicated physical gas reserves that are available during supply emergencies. In the event of a disruption, such schemes would rely on pre-arranged swaps, whereby LNG suppliers or portfolio players deliver cargoes to the importing country in exchange for the release of equivalent gas volumes from storage in the host nation. This would allow importers to access physical supply without storing LNG domestically, while host countries could  benefit  from  higher  storage  utilisation  and  improved  market  liquidity. Implementation would require robust coordination and well-defined frameworks, including clear governance structures, reliable counterparties with global market reach,  and  effective  riskand  cost-sharing  mechanisms,  supported  where necessary  by  public  funding.  While  potentially  promising  and  scalable,  the feasibility  and  cost-effectiveness  of  such  schemes  would  need  to  be  carefully evaluated, and delivery times would need to remain sufficiently short to provide an effective response to supply disruptions in emergency situations.

Assess  the  feasibility  of  pooling  LNG  call  options  across  participating buyers  or  countries,  to  create  jointly  managed  flexibility  buffers  for emergency  response,  with  clear  allocation  rules,  activation  triggers,  and governance frameworks.

Pooling LNG call options could create a shared 'insurance mechanism' against supply disruptions, allowing participating countries to secure access to additional LNG volumes without committing to firm offtake obligations. In contrast to physical reserves,  such  a  mechanism  would  provide  flexibility  without  requiring  large upfront investments in storage infrastructure, making it particularly attractive for LNG-importing countries with limited domestic storage capacity. By aggregating demand for  optionality,  participating  countries  could  also  benefit  from  portfolio diversification  across  suppliers  and  delivery  points,  while  sharing  the  cost  of maintaining access to a potentially sizeable emergency supply buffer that could be drawn upon during localised supply disruptions. However, the cost, operational complexity  and  governance  challenges  of  such  pooled  instruments  remain underexplored and warrant further detailed analysis. Key questions include which countries or groups of countries would be most likely to participate and bear the associated  costs,  how  transparent  and  credible  activation  triggers  could  be

defined,  how  delivery  volumes  would  be  allocated  among  participants  during emergencies, how the cost of option premiums and exercised cargoes would be shared, and how the risk of multiple participants seeking to exercise their options simultaneously during major supply disruptions could be managed. In addition, implementation  would  require  coordination  with  LNG  suppliers  and  portfolio players capable of offering such optionality at scale, as well as alignment with competition policy frameworks.

## Abbreviations and acronyms

Bcm

Billion cubic metres

DES

Delivered ex ship

DFDE

Dual-fuel diesel electric

DQT

Downward quantity tolerance

EMA

Energy Market Authority (Singapore)

EU

European Union

EUR

Euro

FOB

Free-on-board

FSRU

Floating storage and regasification unit

FSU

Floating storage unit

GasCo

Singapore GasCo Pte Ltd.

GWP

Working Party on Natural Gas and Sustainable Gases Security (IEA)

IEA

International Energy Agency

JFTC

Japan Fair Trade Commission

JKM

Japan-Korea Marker (Asian LNG price benchmark)

JOGMEC

Japan Organization for Metals and Energy Security

KOGAS

Korea Gas Corporation

L-gas

Low-calorific gas

LNG

Liquefied natural gas

LNGC

LNG carrier

MBtu

Million British thermal units

Mcm

Million cubic metres

METI

Ministry of Economy, Trade and Industry (Japan)

PipeChina

China Oil and Gas Piping Network Corporation

SBL

Strategic Buffer LNG (Japan)

SGER

Strategic Gas Emergency Reserve (Ireland)

SLF

Standby LNG Facility (Singapore)

SLNG

Singapore LNG Corporation

SPA

Sales purchase agreement

SSBO

Strategic storage-based option

TFDE

Tri-fuel diesel electric

TPA

Third-party access

TSO

Transmission system operator

TTF

Title Transfer Facility (European gas price benchmark)

TOP

Take-or-pay

TWh

Terawatt-hour

UGS

Underground gas storage

UQT

Upward quantity tolerance

USD

United States dollar

VLCC:

Very large crude carrier

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual Member countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject  to  the  IEA's  Notice  for  CC-licenced  Content,  this  work is licenced under  a  Creative  Commons  Attribution  4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area. Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA - September 2026 Cover design: IEA Photo credits: © Shutterstock

<!-- image -->