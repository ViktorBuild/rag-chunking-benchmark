---
document_id: iea_japan_energy_review_2024
title: "Energy Policies of IEA Countries: Japan Review"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IEA"
year: 2024
original_file: "iea_japan_energy_policy_review.pdf"
tables_detected: 7
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 3 2 M ember countries, 1 4 A ssociation countries and beyond.

This publication , as well as any data and map included herein  are without prejudice , to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

## IEA M ember

countries:

IEA Accession countries:

Australia

Austria

Belgium

Canada

Czech Republic

Denmark

Estonia

Finland

France

Germany

Greece

Hungary

Ireland

Italy

Japan

Korea

Latvia

Lithuania

Luxembourg

Mexico

Netherlands

New Zealand

Norway

Poland

Portugal

Slovak Republic

Spain

Sweden

Switzerland

Republic of Türkiye

United Kingdom

United States

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

Brazil Chile Colombia Costa Rica Israel Romania

## IEA Association countries:

The European Commission also participates in the work of the IEA

<!-- image -->

## Table of contents

| Executive summary............................................................................................4         |                                                                                                                   |
|------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Energy policy landscape                                                                                                | .................................................................................10                               |
| Energy and climate strategy                                                                                            | ...........................................................................10                                     |
| End-use sectors ..............................................................................................22       |                                                                                                                   |
| Electricity.........................................................................................................38 |                                                                                                                   |
| Fuels                                                                                                                  | ...............................................................................................................50 |
| Recommendations..........................................................................................54            |                                                                                                                   |
| Focus areas.......................................................................................................62   |                                                                                                                   |
| Natural gas......................................................................................................62    |                                                                                                                   |
| Recommendation............................................................................................72           |                                                                                                                   |
| Hydrogen and ammonia..................................................................................74               |                                                                                                                   |
| Recommendation............................................................................................82           |                                                                                                                   |
| Geothermal energy .........................................................................................83          |                                                                                                                   |
| Recommendation............................................................................................90           |                                                                                                                   |
| Annexes.............................................................................................................92 |                                                                                                                   |

## Executive summary

Japan is reshaping its energy system, while balancing its multiple objectives and managing geopolitical and market volatility. Its  approach is pragmatic and deeply rooted in the long-standing S+3E principle: safety, energy security, economic efficiency and  environment. The  7th Strategic Energy  Plan and  the Green Transformation (GX) framework set out a strategy that links energy diversification, industrial competitiveness and innovation. This Energy Policy Review offers constructive  advice  on  how  Japan  can  translate  that  strategy  into  delivery,  paying particular attention to natural gas, hydrogen and ammonia, and geothermal energy.

The  GX  framework  aims  to  deliver  three  objectives  simultaneously:  stable energy  supply,  economic  growth  and  decarbonisation.  It  seeks  to  mobilise large-scale public and private investment, supported by the gradual introduction  of  carbon  pricing. It  frames  the  energy  transition  not  only  as  an emissions-reduction agenda, but also as a way to strengthen industrial competitiveness through efficiency, electrification, innovation and new fuels. Under the GX  Promotion  Strategy,  Japan  aims  to  mobilise  JPY 150 trillion  (around USD 1 trillion) of public and private investment over a ten-year period, while the 2023 GX Promotion Act provides a stable basis for long-term investment. Japan can further improve alignment and continuity across the innovation ecosystem and reinforce the effectiveness of carbon-pricing instruments to support its longer term objectives.

Japan's progress over the past decade provides a strong foundation; the next phase  would  benefit  from  more  technology-neutral  and  competitive  policy instruments. Energy consumption and greenhouse gas (GHG) emissions have fallen while economic output has grown, reflecting Japan's world-leading efficiency policies, strong  institutions  and  deep  innovation  base.  Yet  due  to  the  country's  unique structural circumstances, including its high import dependence (a self-sufficiency rate

of 16.3% in 2024), fossil fuels still account for over 80% of total energy supply. To address this challenge while maintaining flexibility and resilience, Japan's strategy supports a wide array of low-emissions technologies, including innovative options like hydrogen and ammonia, carbon capture and storage, advanced nuclear technologies, perovskite solar cells and  next-generation  geothermal  energy.  Wider  use  of competitive mechanisms that allow different technologies to compete on performance would improve cost-effectiveness and reinforce policy stability.

Natural  gas  remains  a  cornerstone  of  Japan's  energy  security,  and  greater transparency could strengthen an already resilient supply framework. Imported liquefied  natural  gas  (LNG)  accounts  for  around  one third  of  Japan's  electricity generation.  Diversification,  overseas  equity  participation,  long-term  contracts  and strategic LNG buffers have created resilience. Building on this foundation, enhanced third-party access  to  LNG  terminals  and  increased  information  disclosure  in low-competition  regions  would  support  more  efficient  infrastructure  use,  increase regulatory oversight and enhance market confidence, provided these measures are carefully calibrated to the country's security objectives.

Electricity sits at the intersection of rising demand, an evolving generation mix and affordability. Japan is already one of the most electrified economies in the IEA. After a decade of decline, electricity demand is expected to grow again, driven by data centres, semiconductors and wider electrification. This reinforces the importance of  accelerating  the  deployment  of  nuclear  energy  and  renewables.  Japan  has committed to ending new unabated coal and is phasing out inefficient units while maintaining sufficient thermal capacity for system  stability. To  attract timely investment and contain costs, the capacity, spot and balancing markets should send consistent and technology-neutral signals, including through stronger scarcity pricing and expanded market access for flexibility providers.

Accelerating  grid  modernisation  and  connection  is  essential  for  electricity security if Japan is to integrate more renewables, storage and new sources of demand. Renewables  supplied  nearly  one-quarter  of  electricity  in  2024  and  are projected to account for 40-50% of supply by 2040. Japan is already a global leader in installed solar capacity per unit of land area, while offshore wind is an important strategic priority. The dual-frequency grid, with 50 hertz (Hz) in eastern Japan and 60 Hz  in  western  Japan,  continues  to  constrain  interregional  flows,  and  the deployment of grid-scale battery storage remains modest despite a large number of applications  for  new  projects.  Stronger  incentives  to  modernise  and  expand  the

network  -  e.g.  through  performance based  regulation  and  targeted  investment -frameworks - and faster connection processes for new generation, storage and large loads, would help unlock investment and improve system flexibility.

Nuclear energy is regaining an important role in Japan's energy mix. A clear timetable for restarts and new builds would help system planning, operations and  investments. The  government  has  made  significant  efforts  to  raise  public awareness  and  acceptance  of  nuclear  power.  By  the  end  of  2025,  14  reactors, representing around 13 gigawatts (GW), had resumed operation and a further 12 GW were advancing through approval processes. Kansai Electric Power's 2025 decision to begin surveys for a replacement reactor at Mihama was a notable step towards possible new construction. However, long lead times and licensing uncertainties may deter investment. Japan can increase confidence by setting transparent licensing and deployment timelines for large-scale reactors and small modular reactors (SMRs), while continuing to prioritise nuclear restarts on the basis of assured safety and the understanding of local communities.

A policy push in buildings and transport would help sustain Japan's efficiency leadership and broaden the benefits of the transition. Japan has long been a global  leader  in  energy  efficiency,  particularly  through  its  Top  Runner  Program. Mandatory energy performance standards for new buildings took effect in 2025, but much of the existing building stock is under-insulated. A clearer roadmap towards zero-energy  buildings,  aligning  standards,  incentives,  finance  and  skills,  would support faster renovation. In transport, Japan's leadership in hybrids and its 'range of pathways'  approach  offer  flexibility.  Faster  charging  deployment  towards  its  2030 target,  clearer  life cycle  assessments,  stronger  price  signals  for  road  fuels  and  a sharper focus on zero-emission mobility would increase the sector's contribution.

Hydrogen and ammonia are distinctive pillars of Japan's strategy. Their impact will  depend  on  deploying  them  where  they  are  the  most  competitive  and needed. Japan published the world's first national hydrogen strategy in 2017 and has set clear supply targets to 2050, supported by a price-gap mechanism based on a 15-year contract for difference model. Japan should focus low-emissions hydrogen, ammonia and derived fuels in sectors with limited alternatives, including energy-intensive industry, while using early power sector demand carefully to anchor supply chains, build experience and reduce costs without locking in inefficient pathways.

Geothermal energy is a major domestic opportunity that could be unlocked through stronger risk-sharing, clearer permitting and local partnership. Japan has large untapped geothermal resources, yet installed electricity capacity remains below  1  GW  despite  an  estimated  technical  potential  of  around  100  GW  from conventional and next-generation resources. Development has been slowed by high early-stage  exploration  risk;  long  lead  times;  complex  permitting,  particularly  in national parks; and the need to build durable local acceptance. To reach its target of 1.5 GW by 2030, and a longer term ambition of around 7.7 GW, Japan could further strengthen a milestone-linked risk-sharing approach that crowds in private investment while streamlining permitting requirements according to project size, location and risk.

Japan is well-placed to demonstrate how a resource-constrained economy can advance  a  secure,  affordable,  technology-rich  energy  transformation. The priority  now is implementation. This requires stronger market signals; clearer links across  innovation  and  deployment;  faster  infrastructure  delivery;  and  consistent prioritisation of cost-effective pathways across sectors. Japan looks to advance its energy  policy goals with significant advantages,  including strong institutions, technological capabilities, well-developed policy frameworks and a long tradition of strategic  energy  planning.  Matched  by  timely  execution,  they  can  help  Japan strengthen  its  own  energy  security  and  competitiveness  while  offering  valuable lessons for the wider region and the world.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

<!-- image -->

Sources and notes for this infographic can be found in the annexes.

## Policy recommendations for Japan

## Energy policy landscape

- 1 Increase technology neutrality in energy policy to promote greater cost efficiency and bolster policy stability.
- 2 Strengthen alignment across the innovation ecosystem, in both the public and private sectors.
- 3 Pursue greater policy stability to improve predictability of costs and revenues to support expanding investment in the power sector.
- 4 Further enhance electricity grid development with a focus on incentivising grid modernisation and streamlined grid connection processes.
- 5 Establish clear timelines for deploying new nuclear projects, including licensing for large-scale and small modular reactors, and continue the prioritisation of nuclear restarts.
- 6 Accelerate road transport decarbonisation through a strategic mix of sustainable biofuels, electrification, charging infrastructure and smart charging.
- 7 Develop a roadmap and implement measures to achieve zero-energy buildings by 2050.

## Natural gas

Focus area

- 8 Enhance transparency and access conditions to support effective competition while safeguarding security of supply.

## Hydrogen and ammonia

Focus area

- 9 Prioritise low-emissions hydrogen, ammonia and hydrogen-derived fuels in sectors with limited decarbonisation alternatives while leveraging early demand creation in the power sector to support supply chain scale-up and cost reduction.

## Geothermal energy

Focus area

- 10

Further strengthen early-stage geothermal risk-sharing to crowd in private investment while streamlining permitting.

IEA. CC BY 4.0.

## Energy policy landscape

## Energy and climate strategy

## Energy and climate policy framework

Japan's  policy  framework  is  anchored  in  several  documents  adopted  in  February 2025: the 7th Strategic Energy Plan, the GX2040 Vision (Green Transformation) and the  Global  Warming  Countermeasure  Plan  to  achieve  Japan's  new  Nationally Determined  Contribution.  These  strategic  documents  provide  a  comprehensive roadmap for transforming Japan's energy landscape, guided by the 'S+3E' principle: safety, energy security, economic efficiency and environment. Applying this principle, Japan pursues 'triple breakthroughs' -the simultaneous achievement of decarbonisation, economic growth and energy security - positioning it as a leader in clean energy technologies and industrial decarbonisation.

Japan's international commitments reinforce domestic action. As a signatory to the Paris Agreement, Japan aligns its policies with global climate objectives, including pledges to accelerate renewable deployment and phase down unabated coal. These commitments shape the design of domestic instruments. Recognising that climate change  requires  global  co-operation,  Japan  established  the  Asia  Zero  Emission Community in 2022 to promote decarbonisation across Asia.

Japan's high dependence on imports (see the Fuels section) places energy security at the heart of domestic energy policy. The 7th Strategic Energy Plan sets out Japan's medium-term energy policy priorities through fiscal year (FY) 2040. 1 Among other topics, it addresses the following points:

1 The fiscal year in Japan is 1 April to 31 March.

- · Energy security: Diversification of energy sources and strategic reserves, as well as efforts to improve energy self sufficiency. -
- · Decarbonisation:  Expansion  of  renewables,  use  of  nuclear  power,  and  the development of hydrogen and ammonia.
- · Resilience and competitiveness: Large-scale investments in decarbonised power sources  and  grids,  promotion  of  the  use  of  distributed  energy  resources,  and digitalisation.

These  reflect  the  changes  in  Japan's  energy  landscape  since  the  adoption  of  the 6th Strategic  Energy  Plan,  including  increased  energy  security  concerns  and  the projected growth in electricity demand.

While the government has committed to phasing out unabated coal capacity and ending construction  of  new  unabated  coal-fired  power  generation,  it  stresses  coal's  role  in security of supply, given its cost, storability and low geopolitical risk. This reflects the challenge of managing the transition in a way that maintains adequate thermal capacity while progressively strengthening alignment with net zero pathways. Japan's strategy of maintaining thermal power capacity (kW) while reducing electricity output (kilowatthours; kWh) - primarily from inefficient coal-fired power - and promoting a range of decarbonisation  options -  including  hydrogen  and  ammonia  utilisation,  biomass co-firing, and carbon capture and storage (CCS) - represents a pragmatic, though not risk-free, attempt  to  reconcile  energy  security,  affordability  and  decarbonisation objectives.

The GX 2040 Vision outlines a long-term roadmap for Japan's Green Transformation while maintaining industrial competitiveness. Green Transformation is positioned as a growth-oriented  transition,  leveraging  technology  and  investment  to  revitalise  the Japanese economy while meeting climate targets and maintaining energy security. Its priorities include renewables; nuclear energy; hydrogen and ammonia; carbon capture, utilisation and storage; grids, system integration and demand side measures; and GX -investment  mechanisms.  The  2023  GX  Promotion  Act  -  the  GX 2040  Vision's legislative basis - has persisted through successive political cycles, establishing the policy stability and credibility necessary for long-dated investments.

The GX Promotion Strategy plans to mobilise JPY 150 trillion (USD 1 trillion) in investments  from  the  public  and  private  sectors  over  a  ten-year  period.  The government will provide an upfront investment of JPY 20 trillion (USD 133 billion) through  subsidies,  tax  reductions  and  research  support,  financed  by  issuing GX Economy Transition Bonds.

The  Ministry  of  Economy,  Trade  and  Industry  (METI)  and  its  Agency  for  Natural Resources and Energy (ANRE) lead policy formulation and implementation, supported by the Cabinet Secretariat for cross-sectoral co-ordination. Over 1 000 local governments including Tokyo, Osaka and Kanagawa announced their commitment to net zero carbon emissions by 2050. The GX League mobilises corporate action on decarbonisation and carbon-pricing readiness.

## Policy spotlight: The GX League

The GX League (Green Transformation League) is a voluntary initiative launched by the  Ministry  of  Economy,  Trade  and  Industry  in  2022  to  accelerate  corporate decarbonisation  and  prepare  businesses  for  Japan's  transition  to  a  low-carbon economy. It brings together companies, financial institutions and other stakeholders. Members commit to aligning their business strategies with Japan's 2050 carbon-neutrality goal and interim 2030 targets and share best practices on emissions reduction.  The  GX  League  serves  as  a  sandbox  for  emissions  trading,  allowing companies  to  test  mechanisms  before  the  full-scale  Emissions  Trading  System launches  in  FY2026-2028.  It  also  creates  a  structured  platform  for  consultation between industry and government.

## Trends and targets

Over the past decade, Japan has achieved a steady decline in GHG emissions while maintaining  modest  reductions  in  energy  consumption.  National  GHG  emissions (including carbon removals) fell by roughly 29% between FY2013 and FY2024, driven primarily by the gradual restart of nuclear reactors, rapid expansion of renewables especially solar photovoltaics (PV) and improvements in industrial energy efficiency.  Total  final  energy  consumption  decreased  at  a  slower  pace,  reflecting structural changes in Japan's economy, efficiency gains in buildings and transport, and  demographic  trends  such  as  population  decline.  Importantly,  emissions  and energy use have continued to decline even as real gross domestic product (GDP) grew  moderately  over  the  period,  indicating  a  clear  decoupling  between  Japan's economic  performance  and  its  energy related  carbon  footprint.  Despite  these -improvements,  Japan's  energy  mix  remains  carbon-intensive,  with  fossil  fuels particularly LNG -  still  accounting  for  a  large  share  of  electricity  generation. CO2 emissions  from  energy  use  accounted  for  over  86%  of  Japan's  total  GHG emissions in FY2024.

## Economy-wide emissions in Japan, FY2013-FY2040, and self-sufficiency rate in Japan and IEA net importer countries, FY2025

<!-- image -->

IEA. CC BY 4.0.

Note: Mt CO2-eq = million tonnes carbon dioxide equivalent. Sources: IEA analysis based on Japan, Ministry of the Environment, Japan's National Greenhouse Gas Emissions and Removals in FY2024, (accessed in June 2026); IEA (2026), World Energy Balances.

Japan's  Nationally  Determined  Contribution  sets  a  target  for  carbon  neutrality by 2050, targeting GHG reductions from FY2013 levels of 46% by FY2030, 60% by FY2035 and 73% by FY2040. The Outlook for Energy Supply and Demand in FY2040 published  alongside  the  7th  Strategic  Energy  Plan  provides  a  forecast  of  energy supply and demand for FY2040, presenting a range of possibilities based on multiple scenario analyses that take various uncertainties into account.

## Select energy indicators in Japan, FY2024, and outlook for FY2040

|                          | FY2024   | FY2040 outlook   |
|--------------------------|----------|------------------|
| Self-sufficiency rate    | 16.3%    | 30-40%           |
| Electricity generation   | 990 TWh  | 1 100-1 200 TWh  |
| Final energy consumption | 11.3 EJ  | 10.1-10.4 EJ     |

Notes: TWh = terawatt hour; EJ = exajoule.

Sources: Japan, Ministry of Economy, Trade and Industry (2025), Outlook for Energy Supply and Demand in FY2040, (accessed in June 2026); Japan, Ministry of Economy, Trade and Industry (2026), Comprehensive Energy Statistics, (accessed in June 2026).

## Energy taxation and carbon pricing

Japan's  energy  taxation  framework  is  structured  around  the  beneficiary-pays principle, aiming to ensure that energy users contribute to the costs of energy security and environmental protection. One core tax is the Petroleum and Coal Tax, which applies broadly to fossil fuels and is passed on to end-use energy products such as electricity, kerosene and city gas. Revenues from the Petroleum and Coal Tax fund fuel  stockpiling,  refining  and  distribution  measures,  resource  development,  energy efficiency  programmes,  and  renewable  energy  deployment.  The  Global  Warming Countermeasure Tax is Japan's national carbon tax. Introduced in October 2012 as an additional surcharge on top of the existing Petroleum and Coal Tax, it is applied to all fossil fuels upstream, based on their carbon content at a rate of JPY 289 per tonne of CO2 (t CO2) (about USD 2-3  /t CO2). The Electric Power Development Promotion Tax is levied on electricity sales and used to provide grants to municipalities hosting a  powerplant, enhance nuclear safety and support regulatory oversight of nuclear facilities. Starting in FY2028, a GX surcharge will be introduced to fuel importers and domestic extractors, in addition to the GX emissions trading.

Japan's GX Emissions Trading System, introduced by the Pro-Growth Carbon Pricing Concept, has a phased architecture. Phase 1 (FY2023-FY2025) involved voluntary participation of GX engaged firms and large emitters in emissions reporting without -binding caps. Phase 2 (FY2026-FY2032) introduced compliance obligations. Phase 3 will  launch  allowance  auctioning  for  the  power  sector  in  FY2033.  Revenues  from carbon pricing will be dedicated to redeeming GX Economic Transition Bonds, which mobilise around JPY 20 trillion in upfront investment for industrial decarbonisation. The government sees this mechanism as a GX investment mobilisation tool rather -than a near term emissions constraint mechanism. Some stakeholders argue that the --current design prioritises investment predictability over near term -emissions constraint and  recommend  accelerating  the  transition  from  free  allocation  to auctioning allowances and raising the effective carbon price.

Japan does not operate permanent energy price subsidies, but since 2023 it has intermittently deployed temporary electricity and gas price relief to mitigate inflation and fuel price spikes, including targeted support during high-demand months in 2025. The Transport section provides more details on fuel taxation.

## Energy research and development

Japan's  energy  innovation  system  differs  from  that  of  many  other  IEA  Member countries.  Public  research  and  development  (R&amp;D)  support  is  strongly  oriented toward long-term, mission-driven programmes, often implemented in close partnership  with  large  industrial  incumbents  and  aimed  at  developing  domestic technologies  for  global  deployment.  This  approach  has  delivered  world-leading capabilities  in  several  energy  technologies,  but  it  also  entails  trade-offs,  including limited flexibility to redirect funding and slower entry of new firms. Alongside strong public funding and a clear strategic orientation, Japan's energy innovation system reflects a number of structural characteristics that influence its overall performance. Co-ordination across  ministries and  programmes  can  be  complex,  long-term evaluation  practices  vary  across  initiatives  and  public  support  is  often  channelled through established actors rather than new entrants. Compared with peer countries, start-ups and venture capital currently play a more limited role in Japan's clean energy innovation  ecosystem.  Together  these  features  shape  the  pace  and  pathways through  which  R&amp;D  outcomes  are  translated  into  commercial  deployment,  with implications for how emerging technologies scale and compete internationally.

Japan  ranks  among  the  top  IEA  Member  countries  in  energy  R&amp;D  spending  in absolute terms, but places about 10th when comparing R&amp;D spending per unit of GDP. Japan's energy R&amp;D priorities are primarily defined through the GX Strategy; the Strategic Energy Plan; and cross ministerial science and technology strategies -led  by  METI,  ANRE,  the  Ministry  of  Education,  Culture,  Sports,  Science  and Technology, and the Cabinet Secretariat. Japan directs public energy R&amp;D funding toward technologies it identifies as strategic priorities, with a strong focus on applied research,  demonstration  and  early  deployment.  Priority  areas  include  hydrogen, ammonia and fuel cells, CCS technologies, advanced power generation and system technologies, nuclear energy, renewables, energy storage, and energy efficiency.

Japan views innovation as central to achieving its Green Transformation. Achieving the  changes outlined in the GX Vision, therefore, hinges on strengthening the full innovation  value  chain,  from  basic  research  to  large-scale  demonstration  and commercial  deployment.  Japan's early-stage innovations in solar cells (both perovskite and commercial silicon configurations), lithium-ion batteries and hydrogen fuel  cell  vehicles  have  all  emerged  from  a  strong,  policy-supported  innovation ecosystem. Perovskite solar cells (see the Policy spotlight) illustrate Japan's broader R&amp;D approach: long term  public  support,  close  industry  involvement,  and  a  clear -pathway from laboratory research to domestic manufacturing and early deployment.

Japan's  funding  instruments  include  the  Green  Innovation  Fund  (see  the  Policy spotlight) and complementary programmes such as the Moonshot R&amp;D system, the Strategic Energy Conservation Technology Innovation Program (2012-2024), and the Green  Growth  Strategy,  which  further  expand  support  for  high-risk,  high-impact innovation. These instruments are intended not only to enable timely future emissions reductions but also to position Japanese  firms to lead in emerging  global clean-technology markets, strengthen Japan's industrial competitiveness and crowd in  private  investment.  Systematic  ex post  evaluation  of  large  energy  R&amp;D programmes remains limited, making it harder to assess long-term cost-effectiveness and inform reprioritisation.

The  Ministry  of  the  Environment  (MOE),  in  its  Basic  Environment  Plan  (2024), positions  GX  as  a  core  policy  for  building  a  nature-based  'Regional  circular  and ecological sphere', committing to designate over 100 decarbonisation leading areas, achieve net zero CO  emissions from electricity use in the residential and commercial ₂ sectors by 2030, and scale region-led GX social implementation models nationwide.

## Policy spotlight: The Green Innovation Fund

Japan's Green Innovation Fund (GIF) of approximately JPY 2.8 trillion, established by the Ministry of Economy, Trade and Industry and managed by the New Energy and Industrial Technology Development Organization (NEDO), is a core pillar of the country's Green Transformation (GX). The GIF provides long-term, milestone-based support for research, development and demonstration, and for social implementation of  priority  fields  for  which  implementation  plans  have  been  formulated  within  the Green Growth Strategy or in the Basic Policy for Achieving GX, including hydrogen and ammonia supply chains, next-generation batteries, carbon capture and utilisation, sustainable aviation fuels, and low-carbon industrial processes. The GIF operates through public-private partnerships, requiring participating firms to commit to clear commercialisation pathways and emissions-reduction outcomes. By reducing investment risks and supporting multi-year demonstration projects, the GIF aims to accelerate breakthrough technologies, strengthen Japan's industrial competitiveness and mobilise substantial private investment.

Japan's nuclear energy R&amp;D and innovation agenda has a strong focus on safety enhancement and on next-generation light water reactors, SMRs, and high-temperature  gas-cooled  reactors  with  enhanced  safety  and  load-following capabilities.  The  Japan  Atomic  Energy  Agency  plays  a  central  role,  conducting research on advanced reactor systems, nuclear safety technologies, severe accident mitigation,  and  nuclear  fuel  cycle  and  waste  management.  Academic  institutions contribute through fundamental research, often in collaboration with the Japan Atomic Energy Agency and international partners.

## Policy spotlight: Perovskite solar cells

The 7th Strategic Energy Plan targets the installation of about 20 GW of perovskite solar  cells  (PSCs)  by  2040.  PSCs  offer  a  promising  solution  to  Japan's  structural limitations to continued large-scale deployment of solar photovoltaics (PV): a high proportion of mountainous and forested land and dense urban areas.

As an ultralight and flexible thin film technology, PSCs can be installed on building façades,  lightweight  roofs  and  other  surfaces  unsuitable  for  conventional  silicon modules.  Their  potential  for  low-cost  production  and  high  efficiency,  including  in tandem  structures  with  silicon,  makes  them  well-suited  to  Japan's  objective  of expanding distributed and building-integrated PV.

Japan has become a global frontrunner in PSC research and demonstration. The government, primarily through the Ministry of Economy, Trade and Industry (METI) and the New Energy and Industrial Technology Development Organization (NEDO), is providing substantial support for development and scale up. NEDO programmes are advancing large area coating techniques, durability improvements and pilot-scale manufacturing,  while  METI's  Green  Innovation  Fund  targets  next-generation  PV materials and domestic production to strengthen supply chain resilience. Japanese firms  such  as  Sekisui  Chemical,  Panasonic  and  Toshiba  are  moving  toward commercial prototypes, focusing on stability under humid conditions and integration into buildings, vehicles and infrastructure. Continued progress on durability, upscaling and cost reductions will be crucial to achieving widespread deployment.

## Committed sector-specific research, development and demonstration investment and support by NEDO under the GX Policy

Energy

Transport

Materials

Other

Steel + chemical

Automobile, batteries

Aviation

Ship

Semiconductor chips

Nuclear

Hydrogen + other

Households

Next-

generation renewables

<!-- image -->

IEA. CC BY 4.0.

Note: Planned funds range over a 10-15 year period.

Source: IEA analysis based on Japan, Ministry of Economy, Trade and Industry (2023), Sectorspecific Investment Strategy, (accessed in June 2026).

## Carbon capture and storage

Carbon capture and storage is a critical component of the government's plans for achieving net zero by 2050. CCS in Japan today is primarily a research, demonstration and early deployment activity, supported through innovation funding instruments rather -than a fully commercialised mitigation pathway. The 7th Strategic Energy Plan identifies CCS as a pathway for decarbonising thermal power generation and industrial processes that are resistant to fuel switching. The government is targeting a storage capacity of 120-240 million tonnes per annum (Mtpa) by 2050 to meet Japan's decarbonisation commitments.  Japan's  Tomakomai  CCS  project  with  an  estimated  capacity  of 0.18 Mtpa is the country's first full-chain CCS project, injecting 300 000 t CO2 from a local  oil  refinery  between  2016  and  2019  and  currently  continuing  post-injection monitoring. Plans for a commercial project in this region are also moving forward, aiming to start operation in 2030. The project will store 1.5-2.0 Mtpa of carbon and invest in synthetic fuels production through Idemitsu and the Japan Organization for Metals and Energy Security (JOGMEC).

The government aims to establish a supportive regulatory and social environment for CCS by 2030 and to develop full-scale  CCS  businesses  between  2030  and  2050. Companies  can  already  acquire  CCS  licences  through  a  public  tender  process.  In addition, JOGMEC is providing technical and engineering support to nine CCS projects,

with  a  planned  combined  storage  capacity  of  20  million  tonnes  (Mt)  per  year.  The projects were selected to test the feasibility of different segments of Japan's CCS value chain. The selected projects - which include transportation by pipeline and by ship represent a policy setting that promotes large-scale storage 'hubs', drawing CO2 from multiple, widespread sources.

Development of this model will need to manage uncertainty about storage potential across major projects' value chains. For instance, industrial users may choose to import low-emission fuels that use CCS in their country of origin or they may choose to use fossil  fuels  and  capture  the  carbon  onsite  for  later  transport  offshore.  Japan  must balance  the  need  to  reach  the  volumes  of  carbon  capture  required  to  justify  the development of large-scale hub infrastructure with the limits imposed by pipeline and maritime transport capacity.

Private sector co-ordination on carbon utilisation is supported by the Carbon Recycling Fund.  This  Fund  was  established  in  2019  as  a  cross-industry  platform  with  over 250 members, including businesses, prefectural and municipal governments, individuals, and academics. It has granted research funding to 93 projects (totalling around JPY 540 million), often providing recipients a launchpad to government funding. Funded projects have covered CO2 separation, conversion of CO2 to fuel and chemicals, and  research  into  market  design,  among  other  areas.  The  Carbon  Recycling  Fund supports an additional policy workstream across four pillars: 1) oceans and international;  2) energy  and  materials;  3) regional  and  agriculture;  and  4) innovation and education.

With government support, Japanese companies are assessing the feasibility of storing CO2 overseas, including in Malaysia and Oceania. Overseas storage circumvents some of Japan's domestic geological and social licensing concerns. Increased seismic risk resulting  from  CCS  operations,  the  potential  for  naturally  occurring  earthquakes  to cause CCS leakages, and a lack of exhausted oil and gas fields to serve as promising sites all increase the cost and complexity of CCS site survey and monitoring in Japan. But  transporting  large  amounts  of  captured  carbon  by  ship,  especially  over  long distances,  is  not  yet  an  established  technology.  Japan's  exploration  of  overseas CO2 storage reflects a pragmatic approach to managing domestic geological and social constraints, particularly in the near to medium term. In parallel, domestic CO2 utilisation is being pursued mainly as an innovation and industrial strategy, with the potential to create value-added  products and  support longer term decarbonisation. These approaches address different objectives and time horizons and their relative roles are likely to evolve as technologies, infrastructure and international supply chains mature.

## Skills, competencies and employment in the energy transition

Japan's  strategic  documents  recognise  that  an  effective  transition  requires  a workforce equipped with the adequate competencies. METI's Workforce Development  Plan  (2025)  outlines  a  comprehensive  approach  to  strengthening technical  skills  in  areas  such  as  hydrogen  and  ammonia  engineering,  battery manufacturing, energy management, grid digitalisation, and advanced manufacturing. Japan's strategic documents also highlight the need to maintain and renew competencies in nuclear safety, reactor operation, decommissioning, waste management, and advanced reactor R&amp;D.

Under the GX Promotion Act and the GX 2040 Vision, Japan emphasises a smooth human capital transition, supporting workers affected by structural change through reskilling  programmes,  career  mobility  assistance  and  targeted  support  for  firms transforming  their manufacturing  processes.  In  addition,  the government  has introduced  reskilling  support  in  GX-related  sectors,  launched  industry-academia programmes to expand engineering talent pipelines and promoted the participation of diverse  individuals  in  labour  mobility.  Japan's  strengths  include  strong  industrial training capacity, well-established technical colleges (KOSEN) and robust public-private partnerships.

However,  despite  growing  policy  attention,  Japan  faces  several  challenges  in developing  the  workforce  needed  for  a  rapid  and  equitable  energy  transition.  A persistent shortage of engineers, technicians and digital specialists, exacerbated by demographic ageing and declining enrolment in science, technology, engineering and mathematics  (STEM)  fields,  limits  the  pace  at  which  new  technologies  can  be deployed.  Labour  mobility  in  Japan  remains  low  by  OECD  standards,  limiting  the speed at which workers can transition from conventional manufacturing roles into emerging GX sectors during structural change. Small and medium-sized enterprises, which form much of Japan's industrial base, often  need support to enhance their financial  and  organisational capacity  to  invest in  reskilling.  Gender  gaps  in  STEM education  and  technical  careers  also  constrain  the  available  talent  pool.  If  not addressed, co-ordination challenges across ministries, gaps in skills forecasting, and limited integration between vocational training systems and emerging clean technology industries risk slowing the development of strategic competencies. -

## Financing the energy transition

Japan has placed financing at the centre of its GX Strategy, aiming to mobilise more than JPY 150 trillion in public and private investment over a ten-year period. Under the GX Promotion Act and the GX2040 Vision Strategy, the government combines large scale upfront public investment with long term institutional reforms to catalyse --private  capital.  The  Japan  Climate  Transition  Bonds  are  a  cornerstone  of  this approach (see the Policy spotlight).

## Policy spotlight: Japan Climate Transition Bonds

In  2024, Japan became the first country in the world to issue sovereign transition bonds, labelled Japan Climate Transition Bonds, as part of its strategy to mobilise over JPY 150 trillion in public and private investment for the Green Transformation (GX).  These  bonds  provide  upfront  public  financing  for  decarbonisation  projects across  energy,  industry  and  transport,  aligned  with  sector-specific  investment strategies under the GX framework. The government plans stable annual issuance and ensures transparency through detailed allocation and impact reporting. Japan Climate Transition Bonds also aim to deepen the domestic sustainable finance market by establishing clear expectations for credible transition pathways and by complementing Japan's wider green and transition finance guidelines.

Japan  has  also  taken  significant  steps  to  strengthen  its  domestic  green  finance ecosystem by developing comprehensive green and transition finance frameworks, aligned  with  international  standards.  METI,  the  MOE  and  the  Financial  Services Agency have issued national guidelines for transition bonds, transition loans, green bonds and green loans and offer subsidy schemes to reduce incremental costs for issuers, such as external reviews and verification.

Recognising  that  decarbonisation  requires  credible  pathways  for  hard to abate --industries  and  the  power  sector,  Japan  is  promoting  transition  finance  to  support technologically  grounded  emissions reduction  trajectories.  The  government  has -updated the Basic Guidelines on Climate Transition Finance, expanded the sectoral technology  roadmaps,  and  introduced  follow up  guidance  to  support  effective -implementation by financial institutions and corporate issuers. These instruments aim

to  crowd  in  private  capital,  expand  credible  financing  options  for  companies  at different  stages  of  decarbonisation,  and  ensure  that  Japan's  financial  system  is equipped to drive the large scale investment needed to meet its long term climate --and energy goals.

## End-use sectors

In 2024, buildings accounted for the largest share of total final energy consumption (TFEC) at 36.3%, closely followed by industry at 35.5% and transport at 28.1%. Oil (43%) remains the dominant fuel, followed by electricity (34%) and natural gas (12%). Japan has one of the highest shares of electricity in TFEC globally (34% 2 in 2024), and this share rose by 2 percentage points between 2010 and 2024. For comparison, the global electrification target in COP31 discussions is 35% by 2035.

## Total final energy consumption by sector and fuel in Japan, FY2010 and FY2024

Note: PJ = petajoule. Source: IEA (2026), World Energy Balances.

<!-- image -->

2 Calculated as electricity consumption divided by total final energy consumption, excluding nonenergy use.

## Policy spotlight: Japan's energy efficiency policy package

Japan  has  developed  one  of  the  world's  most  comprehensive  and  durable energy efficiency  policy -packages,  spanning  buildings,  transport,  industry  and appliances. It combines regulatory standards ('sticks'), financial incentives ('carrots'), and  sustained  public awareness  and  information  programmes  to  reduce  energy -consumption and emissions while supporting economic  competitiveness and innovation. Together these elements have delivered significant energy savings over several decades, forming a central pillar of Japan's energy security and decarbonisation strategies.

Regulatory  measures  are  at  the  core  of  this  framework.  Efficiency  performance standards  apply  across  a  wide  range  of  sectors,  including  minimum  energy performance  requirements for buildings, vehicle fuel economy  standards -and mandatory  energy efficient  design  for  equipment.  These  standards  are  regularly -revised to reflect technological progress and market developments. Complementing regulation, Japan deploys substantial financial support to accelerate the uptake of efficient technologies. Subsidies for building insulation; zero-energy buildings (ZEB) and  zero-energy  homes  (ZEH)  construction;  efficient  heating,  ventilation  and  air conditioning (HVAC) systems; industrial energy management upgrades; and clean energy  vehicles  help  reduce  upfront  costs  for  households  and  firms.  Awareness policies -  ranging  from  appliance  labelling  and  public  information  campaigns  to training  programmes  for  builders,  energy  managers  and  installers -  ensure  that efficiency is visible to consumers, public bodies and industry.

A prominent example of Japan's success is the Top Runner Program, which is widely regarded  as  an  international  benchmark  in  appliance  and  equipment  efficiency regulation. Introduced under the Energy Conservation Act, the Program identifies the most efficient product model in each category and uses it as the future mandatory performance baseline for all manufacturers. Over time, this dynamic, forward looking -structure has driven repeated cycles of innovation and performance improvement. The  Program  covers  dozens  of  product  categories,  including  vehicles,  HVAC systems, motors, lighting, consumer electronics and IT equipment, and has delivered considerable reductions in energy use, often exceeding 30% in major categories such as room air conditioners and refrigerators.

In the last 20 years, Japan has seen a consistent decrease in energy consumption across all end-use sectors. TFEC decreased by a quarter while economy-wide output increased  by  around  12%.  This  reduction  in  energy  demand  was  driven  by  a combination  of  economy-wide  energy  efficiency  improvements  (see  the  Policy spotlight) and a moderate decline in total population in recent years.

## Buildings

## Energy use in buildings

Energy consumption in buildings in Japan has moderately declined over the past decade, driven by demographic trends, strong appliance standards and behavioural changes  following  the  2011  energy  crisis.  Residential and  commercial/public buildings each represent roughly half of total building energy demand. In residential buildings, appliances (36%), space heating (27%) and water heating (25%) dominate consumption.

While Japan has been a global leader in energy-efficient products such as advanced HVAC systems, its buildings sector faces structural challenges related to the thermal performance of the existing stock. This reflects a long-standing policy emphasis on efficient  equipment  and  appliances,  combined  with  a  historically  more  flexible approach to regulating building envelopes. Although the average age of buildings in Japan is relatively low compared with other advanced economies, Japan historically prioritised  flexibility in building  design  and  rapid  construction,  with  mandatory insulation  and  whole-building  energy  performance  requirements  being  introduced more recently than in many peer countries. In addition, the culture of underheating introduced  during  the  post-World  War  2  energy  shortages  persists,  meaning  that gains from insulation are much smaller than in other countries. As a result, for a large share of dwellings - and particularly detached houses - scope remains for improved insulation performance.

Climate change is intensifying the need for cooling, especially in dense metropolitan regions. As the number of extreme heat days rises, peak electricity demand becomes more sensitive to cooling loads. The IEA Energy Efficiency 2025 publication reports the  growing  number  of  cooling  degree  days  and  electricity  demand  for  cooling  in Japan  since  2010.  This  trend  underscores  the  importance  of  high-performance building envelopes, shading and smart control technologies to moderate peaks.

## Heating and cooling

Japan's heating and cooling patterns reflect its varied climate, from the cold winters of Hokkaido to the subtropical conditions of Okinawa. Cooling demand is rising faster in some Japanese regions than in others, while overall heating demand is falling in Japan and other Asian economies. Improved thermal envelopes, shading, ventilation strategies and the deployment of advanced heat pumps are essential for reducing peak loads and improving comfort.

The  heating  and  cooling  sector  is  predominantly  served  by  individual  systems. Cooling demand is met primarily by electric air conditioning units. Natural gas is used for  cooling  in  the  commercial  sector,  accounting  for  about  40%  of  commercial buildings' cooling demand (or 30% across the whole buildings sector). Space heating relies on a mix of technologies, including electric heat pumps, kerosene heaters and city-gas boilers, with fuel use varying by region and dwelling type. Oil based fuels -remain  particularly  important  for  residential  space  heating,  especially  in  colder regions, contributing to Japan's comparatively high oil use in buildings relative to other IEA Member countries.

District heating and cooling systems remain limited in scale and are concentrated in dense urban districts serving clusters of offices, commercial developments, hotels and  residential  complexes.  District  heating  and  cooling  systems  have  maintained stable heat supply levels since the early 2000s, primarily using city gas and electricity. Decarbonisation  of  district  heating  and  cooling  schemes  relies  on  greening  the electricity and gas supply, alongside efforts to boost efficiency and integrate lower carbon heat sources.

Japan  is  a  global  leader  in  heat  pump  deployment,  with  widespread  adoption  of electric  heat  pumps  across  residential  and  commercial  buildings.  Reversible  air conditioners are common in homes, while commercial properties often use advanced variable  refrigerant-flow  systems.  Despite  this  progress,  a  significant  proportion  of older  homes  still  depend  on  less  efficient  heating  units  and  have  limited  thermal insulation, resulting in elevated winter peak electricity demand. Commercial building stock also includes many outdated HVAC systems, which are expensive to upgrade and less amenable to modern load-shifting and smart control.

## Policy framework

Japan has progressively strengthened its building energy efficiency policy framework over  several  decades,  with  a  strong  and  internationally  recognised  focus  on equipment standards, appliances and industrial energy efficiency. However, binding requirements for building envelopes and whole-building performance were introduced significantly later than in most other advanced economies. Recent reforms mark a significant shift. Amendments to the Building Energy Efficiency Act (2022) and the Building Standards Act (2024) made compliance with national energy conservation standards mandatory from 2025 for all new buildings, including residential ones. Prior to this reform, compliance with national energy conservation standards for residential buildings  was  largely  voluntary,  which  limited  uptake  despite  available  technical solutions. These reforms provide a stronger legal foundation for improving thermal performance and reducing energy demand in new construction while placing a greater emphasis  on  the  role  of  local  governments  in  implementing  them.  Prefectural governments play a growing role through local information campaigns, demonstration buildings, and simplified subsidy procedures for homeowners and small businesses.

The  recent  reforms  offer  clearer  and  more  predictable  compliance  pathways  for builders  and  developers.  In  Japan's  current  building  energy  efficiency  framework, performance grades are used to classify compliance levels under the Building Energy Efficiency Act. Grade 4 corresponds to the legally binding national minimum energy performance standard, covering thermal insulation and primary energy consumption, and has been mandatory for all new buildings since the 2022 amendment. Grade 5 serves as a higher performance benchmark, aligned with ZEH-equivalent insulation and energy performance levels. It is not a nationwide legal requirement but a policy reference and is selectively applied by some local governments, notably in 'leading decarbonisation regions' defined by the MOE.

The  government  provides  subsidies  for  ZEB  and  ZEH  construction,  supporting insulation upgrades, high-efficiency HVAC systems, building automation systems and onsite  renewable  energy  installations.  In  addition  to  large,  dedicated  subsidy programmes administered by METI; the Ministry of Land, Infrastructure, Transport and  Tourism;  and  the  MOE,  the  Green  Innovation  Fund  provides  complementary support for development and demonstration of selected advanced technologies such as high-performance façades, building-integrated PV and smart building controls.

Energy conservation policies include a mix of innovative behavioural measures and more  systematic  market-oriented  approaches.  These  include  the  Power-Saving

Challenge,  launched  in  2020,  which  uses  a  gamification  approach  to  encourage household energy savings, as well as the Energy Efficiency Communication Ranking, under  which  retailers  are  assessed  and  ranked  based  on  the  quality  of  their energy-saving  communication  and  consumer  programmes.  More  recently,  Japan launched  the  Home  Energy  Saving  Campaign  in  2025,  which  combines  financial incentives with information tools to accelerate the uptake of energy-efficient housing measures. Behavioural campaigns also remain an important pillar of policy, notably the long-running Cool Biz initiative, which promotes higher air conditioning temperature  set  points  (28°C)  and  lighter  clothing  to  reduce  cooling  demand, particularly in offices. Public awareness and capacity-building programmes include national campaigns on insulation benefits, heat pump efficiency and heat resilience measures; training for architects, builders and local officials; guidance documents for retrofitting older homes; and the dissemination of model ZEB and ZEH designs.

Energy  performance  labelling  and  voluntary  disclosure  schemes  are  increasingly used to make building energy performance more visible to occupants and investors. However, comprehensive mandatory disclosure at point of sale or rental has not yet been  implemented  nationwide.  These  measures  are  intended  to  make  energy performance more visible to occupants and investors, and to encourage renovation decisions based on life cycle cost considerations.

As cooling demand and peak loads increase, Japan is placing a greater emphasis on demand-side flexibility in buildings. While smart meters have been deployed at near universal scale, policy efforts are increasingly focused on expanding the use of digital solutions,  such  as  Home  Energy  Management  Systems  and  Building  Energy Management  Systems,  which  enable  real-time  monitoring  and  optimisation  of household appliances, distributed  energy  resources,  and  building  services.  These systems underpin the development of demand-response programmes, smart HVAC controls  and  dynamic  pricing,  but  their  uptake  remains  more  gradual  and  uneven compared with metering infrastructure. In parallel, building policy is also increasingly integrating  heat-resilience  measures,  including  insulation,  shading,  ventilation  and passive cooling, responding to rising heat-stress risks in urban areas.

Japan's research ecosystem  for building energy performance is broad and well-established. METI; the Ministry of Land, Infrastructure, Transport and Tourism; and the MOE jointly support research through NEDO and other agencies, focusing on  next-generation  building  envelopes,  advanced  heat  pumps,  demand-response compatible  HVAC  systems,  digital-twin  building  models  and  building-integrated renewable energy. The Green Innovation Fund plays a vital role in demonstration

projects.  Translating  these  research  efforts  into  widespread  improvements  in  the existing  building stock  will  require  stronger  links  between  innovation  programmes, renovation incentives and workforce training.

## Zero-energy buildings and zero-energy homes

Japan  has  built  a  comprehensive  ecosystem  around  ZEB  and  ZEH,  offering  a progressive set of performance categories: ZEB-oriented, ZEB-ready, nearly ZEB and full ZEB. These categories enable a gradual scaling of performance expectations and support incremental market transformation. Beyond direct energy savings, the ZEB and ZEH programmes play an important role in shaping the market by standardising high-performance  design  practices;  strengthening  supply  chains  for  insulation, windows and HVAC systems; and reducing costs through learning effects.

By the end of FY2024, around 1 900 non-residential buildings had achieved some form of ZEB certification, with ZEB-ready accounting for the majority. The cumulative certified  ZEB  floor  area  exceeded  20  million  m²,  reflecting  steady  but  still  partial market penetration relative to total new construction. Offices, logistics facilities and educational  buildings  have  been  dominant  categories,  supported  by  relatively favourable economics and strong corporate demand for energy-efficient facilities. In the residential sector, ZEH uptake has been at around 20% of annual new detached home construction, with substantial regional variation. Prefectures with strong local incentives and active municipal campaigns show noticeably higher levels.

Public  procurement  plays  an  important  role  in  accelerating  market  diffusion.  In principle, new national government buildings are required to meet at least ZEB-ready performance.  This  approach  strengthens  supply  chain  capability  and  encourages learning effects in design, construction and materials.

While Japan has significantly strengthened requirements for new buildings, emissions reductions  in  the  buildings  sector  will increasingly  depend  on  improving  the performance of the existing stock.

## Total rebuilds and energy-related renovations compared to average housing stock and share of zero-energy homes in new constructions, FY2020-FY2024

<!-- image -->

Notes: ZEH = zero-energy homes. 'Interventions' refers to renovations for the purpose of energy conservation, as well as all construction starts for rebuilding.

Sources: IEA analysis based on Japan, Ministry of Land, Infrastructure, Transport and Tourism (2025), Construction Statistics Survey, (accessed in June 2026); Japan, Ministry of Land, Infrastructure, Transport and Tourism (2025), Building Renovation and Renewal Survey, (accessed in June 2026); IEA (2026), Energy End-uses and Efficiency Indicators; ZEH Web, 2025 ZEH Conference, (accessed in June 2026).

## Renovation of existing buildings

Renovation remains the core challenge  for  achieving  deep  emissions  reductions  in Japan's  building  stock.  Most  residential  buildings  were  constructed  before  effective insulation  requirements  were  introduced,  and  many  of  them  have  great  potential  to strengthen high-performance insulation envelopes or efficient ventilation equipment.

Recent policy developments include the phased introduction of renovation-triggered energy  performance  requirements  from  FY2025  onwards  and  subsidies  to  support insulation upgrades and the replacement of inefficient HVAC equipment. For example, the Energy Conservation Subsidy and the Eco-Home grant promote building upgrades, efficient water heaters and window replacement. However, despite expanded subsidy programmes and recent regulatory steps, renovation activity has not yet reached the scale required to fully align the existing building stock with Japan's 2035, 2040 and 2050 climate  objectives.  Accelerating  progress  will  require  a  stronger  mix  of  regulatory drivers,  accessible  financing  tools  for  households  and  small  building  owners,  and expanded workforce capacity to deliver high-quality retrofits. Without sustained policy reinforcement, emissions reductions in the buildings sector will increasingly lag those achievable in other end-use sectors.

## Industry

Japan's industrial sector is pivotal to the Green Transformation because it combines high  energy  use  and  emissions  with  a  central  role  in  exports,  productivity  and economic security. Many core sectors, including steel, chemicals, cement, refining and advanced manufacturing, are both energy-intensive and globally exposed, so decarbonisation costs and policy credibility will strongly influence future investment and location decisions.

Industry contributed 28.8% of GDP (2023) and accounted for 36% of TFEC and 40% of energy-related emissions in 2024. Manufacturing (particularly in energy-intensive subsectors) dominates industrial energy demand; basic metals and chemicals alone account  for  more  than  half  of  industrial  energy  use.  Coal  remains  structurally important as an energy source and feedstock. It has supplied, on average, 40% of total energy demand in manufacturing over the past decade. This also reflects the prevalence of high-temperature processes that remain difficult to electrify.

Government policy anchors the industrial transition around a triple mandate: energy security,  economic  growth  and  decarbonisation.  Japan's  industry  energy  policy benefits from METI's mandate to direct industry and energy policy; energy policy is formulated with industrial sectors as a key concern. Green Transformation instruments are  designed  to  improve  investment  predictability  for  large  emitters  and  energyintensive sectors. Switching production processes in heavy industry is subject to long planning and investment cycles, as much of the equipment is CAPEX-intensive and tends to be depreciated over long time horizons. Making such investments attractive means Japan must preserve its stable industry policy environment.

The  GX  framework  includes  Sector-specific  Investment  Strategies  for  several energy-intensive industries such as steel, chemicals and cement. These roadmaps provide  useful  long-term  signals  on  expected  emissions-reduction  pathways  and investment needs, but they often emphasise particular technologies or fuels - such as hydrogen, ammonia or CCS - rather than defining outcomes in performance or cost  terms.  In  parallel,  major  public  support  instruments,  including  the  Green Innovation Fund, price-gap support schemes and GX-related transition finance, tend to be aligned with these predefined pathways, reinforcing technology-specific choices at the deployment stage. While this approach can accelerate first-of-a-kind projects and reduce early investment risk, it may also limit competition between alternative decarbonisation options.

Energy efficiency remains Japan's first lever of industry sector energy policy and a long-standing policy strength. Manufacturing energy intensity fell by 23% between 2014  and 2024.  The  Energy  Conservation  Act  (amended  2022)  applies  to  over 10 000 businesses and requires either an annual 1% intensity improvement or sector benchmarks, with escalation mechanisms for persistent underperformance (see also the energy efficiency Policy spotlight).

Deep decarbonisation of heavy industry will require a combination of major changes in production processes and improvements to supporting infrastructure. Electrification (including  expanded use of electric arc furnaces) becomes a key decarbonisation pathway  as  the  power  mix  becomes  cleaner.  Recent  legislation  introduced  2030 electrification-related  targets  for  selected  subsectors  (e.g.  cement  and  electric furnaces in iron and steel). Electricity demand in Japanese industry has declined over the past 20 years, but at a slower pace than overall industrial energy demand. Future electrification  will  also  rely  on  sufficient  grid  investments  and  rapid  connection processes (see the Electricity chapter). This becomes increasingly important as Japan continues  to  develop  sectors  that  attract  high  site-level  loads,  like  semiconductor industries. Further, many production processes with electrified heat and energy sources still rely on fossil fuels as feedstocks, particularly in chemicals  and  cement. Decarbonising these sectors will require additional low-emissions alternatives.

Fuel  switching  is  another  decarbonisation  path  for  high-temperature  heat  and feedstocks. Japan's strategic approach to alternative fuels emphasises low-emissions hydrogen and ammonia, among other options, supported on a sector basis by the sector-specific investment strategies and on a fuel basis by enabling policy instruments (see Focus Area on Hydrogen and ammonia). Although alternative fuels can be used for heat, electricity and process uses, current supplies are limited. Ultimately,  decarbonisation along electrolytic hydrogen-based routes could prompt multi-million tonne hydrogen demand.

Industry decarbonisation supports progress towards the three objectives of Japan's GX policy: energy security, economic growth and decarbonisation. Greater use of electrification; hydrogen; carbon capture, utilisation and storage; and other low-emissions technologies can strengthen energy security by diversifying  energy sources, reducing dependence on imported fossil fuels and broadening the range of potential  supplier  countries.  At  the  same  time,  the  development  and  domestic deployment  of  next-generation  technologies  can  support  economic  growth  and industrial  competitiveness  by  creating  new  value  chains  and  reinforcing  Japan's technological leadership in clean energy industries. These measures also contribute

to decarbonisation by reducing emissions from energy-intensive sectors such as steel, chemicals and cement, where alternative mitigation options remain limited. In this context, Japan's industrial policy seeks to align long-term emissions reductions with industrial resilience and secure energy supply while maintaining flexibility regarding technology pathways and future market developments.

## Transport

Transport  is  responsible  for  roughly  two fifths  of  Japan's  energy-related  GHG emissions  and  28%  of  final  energy  consumption.  Road  transport,  which  includes passenger cars, buses, two-/three-wheelers and road freight vehicles, accounts for around 85% of energy use and emissions within the transport sector. Given the size of  Japan's  vehicle  stock  and  relatively  slow  turnover,  road  transport  emissions reductions in the 2020s and early 2030s will continue to depend heavily on improving the performance and fuel mix of existing vehicles. Domestic maritime moves close to 40% of freight volumes, and rail (including the metro) carries 30% of all passenger movements (see the Policy spotlight).

## Car market shares by powertrain in Japan and IEA countries, FY2020 and FY2025

<!-- image -->

IEA. CC BY 4.0.

Notes: BEV = battery electric vehicle; PHEV = plug-in hybrid electric vehicle; FHEV = full hybrid electric vehicle; MHEV = mild hybrid electric vehicle. Automotive Industry Portal, (accessed in April 2026); Autovista, EV Volumes, (accessed in April

Sources: IEA analysis based on IEA (2025), What Next for the Global Car Industry; MarkLines, 2026).

Japan has adopted a 'range of pathways' approach to road transport decarbonisation, which includes 'electrified vehicles' , low-carbon fuels (especially for segments where 3 electrification remains hard) and hydrogen (prioritised for heavy-duty and long-distance commercial  applications).  The  so-called  'electrified  vehicles'  category  is  broader  in Japan compared to the IEA methodology, and includes BEVs, the so-called full hybrid electric  vehicles  (i.e.  vehicles  that  combine  an  internal  combustion  engine  with  an electric motor and a battery that cannot be recharged externally), PHEVs and fuel-cell electric vehicles (FCEV). This diversified 'range of pathways' approach is intended to reduce transition risks and strengthen resilience to fuel and mineral market volatility while  recognising  Japan's  unique  energy  mix  constraints.  This  approach  offers flexibility, but requires metrics to evaluate cost-effectiveness across pathways.

## Illustration of transport policy in Japan

<!-- image -->

Key  targets  for  Japan's  road  transport  sector  by  2030-2035  include  having  all passenger  car  sales  coming  from  clean  energy  vehicles  (so-called  'electrified' vehicles in Japanese policy documents), expanding domestic battery manufacturing to 150 gigawatt hours (GWh),  deploying  300 000  public charging plugs and 1 000 hydrogen  stations,  increasing  biofuel  use,  and  commercialising  synthetic  efuels. Japan is a global leader in hybrid vehicles sales (2024). Efficient hybrid vehicles have reduced road transport energy intensity and decreased oil demand.

3 Japanese definitions differ from IEA usage, where electrification typically refers to externally chargeable vehicles.

Japan also implements a range of other measures to decarbonise transport, including modal shifts in passenger and freight transportation, eco-driving, sustainable logistics systems, etc.

Japan's  automobile  sector  is  a  strategic  pillar  of  the  economy,  employing  over one million  people  and  accounting  for  about  one-fifth  of  manufacturing  output. Domestic manufacturers lead in battery innovation, commercial FCEV deployment and  fuel cell manufacturing. Hybrid vehicles, produced  mainly  by  Japanese companies, dominate domestic sales. Japanese original equipment manufacturers also  play  a  major  role  in  global  vehicle  production  and  technology  diffusion. Companies such as Toyota, Honda and Nissan account for a significant share of worldwide  vehicle  sales  and  operate  extensive  manufacturing  networks  abroad, meaning that technology choices made by Japanese original equipment manufacturers influence emissions outcomes well beyond Japan. Japan's diversified approach has supported incremental global emissions reductions, notably through the widespread uptake of hybrids.

## Fuel efficiency standards

Japan has one of the world's longest running energy efficiency regulatory frameworks for  transport.  The  Top  Runner  Program  (see  the  Policy  spotlight)  sets  mandatory efficiency  standards  using  the  most  efficient  vehicle  model  in  each  class  as  the benchmark. Manufacturers must meet these targets across their fleet within a set time frame, encouraging  continuous  innovation.  Successive  Top  Runner  fueleconomy standards for light-duty vehicles - i.e. passenger cars and light commercial vehicles -  have  contributed  to  the  reduction  in  fuel  intensity  over  the  past  two decades.  The  latest  standards  establish  targets  through  2030.  For  heavy duty -vehicles, Japan introduced a separate Top Runner framework in 2013 and updated it with 2025 standards; the next regulatory phase has not yet been defined. Thanks to successful efficiency policies in the transport sector, Japan has reduced oil imports by  18%  since  2000.  Building  on  the  success  of  the  Top  Runner  Program,  which delivered  substantial  efficiency  gains,  meeting  post-2030  targets  can  be  also supported  by  increasing  the  use  of  zero-emission  vehicles  and  further  improving efficiency in conventional and hybrid powertrains where it is technically feasible.

## Clean Energy Vehicle support programme

Japan's  Clean  Energy  Vehicle  (CEV)  programme  is  a  core  instrument  under  the Green Growth Strategy,  administered  by  METI  and  ANRE.  The  scheme  provides

purchase incentives for clean vehicle technologies, including BEVs, PHEVs, FCEVs and micromobility (Kei cars, small lightweight vehicles for short-distance travel), along with  supplementary  support  for  charging  and  hydrogen  refuelling  infrastructure. Subsidy levels vary by vehicle category and performance, with additional bonuses linked  to  the  installation  of  renewable-compatible  charging  equipment  and  smart charging capabilities. From FY2026, CEV subsidy caps were revised to incentivise high-quality, sustainable vehicle models:  up to JPY  1.3  million for BEVs, JPY 580 000 for  Kei car BEVs,  JPY  850 000  for  PHEVs  and  JPY 1.5 million  for FCEVs. Eligibility criteria include vehicle performance and convenience, life cycle sustainability (CO2 footprint, recycled materials, battery reuse), and cross-sectoral benefits. In FY2025, Japan spent about JPY 110 billion to fund purchase subsidies for BEVs and FCEVs.

Kei cars have played an important role in Japan's passenger car market, supported by long-standing regulatory and fiscal incentives, including relaxed parking requirements,  lower  vehicle  taxes  and  insurance  costs,  and  policies  favouring domestic production. Although several incentives were reduced after 2014, Kei cars continue to account for a significant share of new vehicle sales. Targeted incentives for electric Kei cars could, therefore, offer a cost-effective lever to accelerate vehicle electrification, particularly in urban and regional contexts where these vehicles are most prevalent, and where driving patterns suit them best.

The CEV programme supports the installation of public chargers for electric vehicles (EVs), with a target of 300 000 by 2030, up from around 68 000 in June 2025. While Tokyo and Osaka offer relatively good access to charging infrastructure, many rural areas  are  still  underserved,  resulting  in  coverage  gaps.  The  recent  slowdown  in charging  deployment,  despite  generous  subsidies,  suggests  that  non-financial barriers,  such  as  grid  connection  procedures,  site  availability  and  business  model viability, may increasingly constrain roll-out.

## Sustainable fuels and hydrogen

Japan is promoting sustainable fuels, targeting transport segments where electrification faces structural limits. Policy priorities focus on biofuels and synthetic fuels  for  aviation,  shipping  and  long distance  road  transport.  The  target  for  the -aviation  sector  is  to  replace  more  than  10%  of  fuel  consumption  with  sustainable aviation fuels by 2030. The Bioethanol Action Plan (2025) sets out a phased transition toward  E10  by  2030  and  E20  by  2040,  covering  vehicle  and  infrastructure compatibility,  misfuelling  prevention,  and  consumer  communication.  Sustainable

aviation  fuels  are  promoted  under  aviation  policy  frameworks  to  support  domestic production and international sourcing. Despite these initiatives, sustainable fuels still account for less than 1% of transport energy use, underlining the need for careful prioritisation and  scale up  to  ensure  that  limited  volumes  deliver  the  highest -decarbonisation impact.

## Policy spotlight: Rail

Rail is a keystone of Japan's net zero transport strategy for passenger and freight movement.  Japan  has  the  highest  share  of  rail  passenger  transport  among  IEA Member countries.  Rail  is  the  dominant  mode  of  travel  in  the  major  metropolitan regions,  carrying  far  more  passengers  than  private  cars.  Japan's  world-renowned high-speed rail network - the Shinkansen - offers fast, reliable and energy-efficient intercity travel. This strong reliance on rail is underpinned by high public acceptance and trust, supported by the network's reliability, safety and energy efficiency. With one of the IEA's most extensive usages of electricity as an energy source (over 90% in 2024) and high utilisation, Japan's railways deliver globally leading levels of energy efficiency.  The  sector  already  plays  a  critical  role  in  reducing  oil  dependence,  air pollution and congestion while enabling systemic decarbonisation through integration with  an  increasingly  renewable  electricity  mix  and  the  country's  push  toward digitalised, multimodal mobility services.

Despite these strengths, the sector faces several challenges. There has been little improvement in the number of passenger-kilometres travelled by rail in recent years. Demographic decline, uneven regional demand and the lack of demand drivers place fiscal pressure on passenger rail operators, especially in rural areas. Construction of new  railway  lines  is  challenging  in  mountainous  regions.  Freight  rail  capacity  is constrained in key east-west and north-south logistics corridors. These challenges also  present  substantial  opportunities  for  policy  action.  In  particular,  stronger co-ordination between rail investment and electricity system reforms; targeted support for low-carbon freight corridors; and deeper integration of rail with EV car sharing, buses and active mobility could further enhance rail's role in delivering a resilient, efficient, low-carbon transport system.

Japan positions FCEVs primarily in heavy duty and commercial applications, where -hydrogen's fast refuelling and long range offer potential advantages over batteries. Policy support concentrates on regional deployment clusters (including Fukushima, Tokyo/Kanagawa,  Aichi,  Hyogo  and  Fukuoka)  where  vehicle  roll-out,  hydrogen refuelling  infrastructure  and  fleet  demand  are  developed  in  parallel.  FCEVs  are supported  through  the  CEV  programme,  while  broader  hydrogen  supply chain development is addressed under the GX framework (see Focus Area on Hydrogen and  ammonia).  Uptake  remains  limited  to  date  (422  FCEVs  were  sold  in  2023), reflecting high vehicle and fuel costs and infrastructure constraints, reinforcing the importance of targeting FCEVs to use cases where they provide clear system value, particularly for buses, trucks and logistics fleets.

## Taxation

Several transport-related tax instruments, as well as the Petroleum and Coal Tax and Global Warming Countermeasure Tax (see the Energy taxation section), interact with subsidies to influence consumer choices. EVs and FCEVs currently benefit from the minimum  rate  of  the  annual  vehicle  ownership  tax  and  are  exempt  from  the weight-based  vehicle  tax  at registration and  at the first periodic inspection. Discussions are ongoing to reform this system.

At the same time, Japan has one of the lowest taxes on transport fossil fuels among IEA countries, which  also impacts consumer  choices.  Japan's  long-standing gasoline  tax  surcharge  of  25.1  JPY/L  (in  place  since  1974)  was  abolished  at  the end  of  2025.  The diesel fuel tax surcharge of 17.1  JPY/L (in place since 1976) ended  on 1  April  2026.  These  changes have reduced gasoline excise to 28.7 JPY/L and diesel excise  to  15 JPY/L.  In  addition,  the  government  launched a  Fuel  Price  Mitigation  subsidy in 2022 to counter surging oil prices. This subsidy, paid to fuel wholesalers, capped retail gasoline prices (targeting ~168-172 JPY/L) by offsetting part of the cost. The  subsidy  was  phased  down  in  late  2023,  expanded temporarily in late 2025 to facilitate the tax cut and reactivated in early 2026 amid a new price spike. Japan also operates  a  'tax-free  diesel'  programme  for  approved users in specific industries, including agriculture, forestry, fisheries and construction.  Relatively  low  fuel  taxation  moderates  operating  cost  signals  for vehicle  efficiency  and  electrification,  increasing  the  importance  of  subsidies  and other measures to drive behavioural change.

## Electricity

## System transformation

Japan has developed one of the most reliable electricity systems in the world, with some of the lowest outage rates. Following the Fukushima Daiichi accident in 2011, Japan's  reliance  on  imported  fossil  fuels  for  electricity  generation  has  increased, making energy security a central policy concern. The government is reforming the electricity sector to address its structural challenges: high import dependency, limited grid flexibility, the dual-frequency grid, and the need to integrate growing shares of variable renewable energy (VRE) while maintaining reliability and affordability.

Japan's liberalised electricity market is relatively young compared  to many IEA countries, although partial retail competition already started in 2000. The 2011 Fukushima accident triggered additional reforms and Japan's electricity market has undergone significant transformation over the past decade. Major milestones include the creation of a national system operators' co-ordinator in 2015, the full liberalisation of the retail competition in 2016 and the legal unbundling of utilities in 2020.

In  2026,  Japan's  thermal  and  nuclear  power  generation  capacity  continues  to  be dominated  by  incumbents  and  system  operation  remains  the  responsibility  of  ten regional transmission and distribution companies, each managing its own grid and integrating increasing shares of renewable energy. The Organization for Cross-regional Coordination of Transmission Operators (OCCTO) provides nationallevel  co-ordination,  overseeing  system  adequacy,  balancing  and  planning  crossregional transmission investment. However, the combination of regional autonomy and limited interconnection continues to constrain market integration.

Japan's electricity mix is expected to shift substantially again in the coming years. In 2024,  renewables  supplied  around  24%  of  electricity,  nuclear  10%  and  fossil fuel-based  thermal  power  continued  to  provide  the  majority,  supplying  almost two-thirds of all electricity. The Outlook for Energy Supply and Demand in FY2040 published  alongside  the  7th  Strategic  Energy  Plan  projects  renewables  to  rise  to approximately 40-50% by FY2040, driven especially by solar PV, which is projected to account for approximately 23-29% of the electricity mix. Nuclear power is expected to  double  its  share  in  electricity  supply,  while  thermal  generation  is  projected  to decline to approximately 30-40%.

A  secure  and  stable  electricity  supply  continues  to  be  the  priority,  with  thermal power as one of the anchors and balancing resources. Policy measures on coal, which  supplied  around  30%  of  electricity  in  2024,  focus  on  reducing  electricity generation from inefficient coal units, restrictions on new unabated capacity, and increased  co-firing  with  biomass  and  ammonia  (see  the  Fuels  and  Hydrogen sections for more details).

## Changes in electricity generation in Japan, FY2010-FY2025, and projected changes, FY2025-FY2040

<!-- image -->

IEA. CC BY 4.0.

Note: Electricity generation values for FY2025-FY2040 represent the generation ranges between scenarios provided in Japan's Outlook for Energy Supply and Demand in FY2040. Sources: IEA analysis based on IEA (2026), World Energy Balances; Japan, Ministry of Economy,

Trade and Industry, 7th Strategic Energy Plan, (accessed in April 2026).

This  shift  in  the  electricity  supply  mix  is  accompanied  by  a  reversal  in  electricity demand trends. Electricity demand has been declining since a peak in 2010, in part thanks to strong energy conservation policies (see End-use sectors chapter); in 2024, it  was lower than almost 30 years ago. Electricity demand is projected to return to growth in the years ahead, reversing previous trends despite continued conservation efforts. Growth will be mainly driven by data centres, semiconductor manufacturing and  GX-related  electrification.  OCCTO  estimates  national  demand  will  climb  5% by 2035 compared to FY2025, returning to 2014 levels.

## Policy spotlight: Community engagement for energy development

Japan centres community engagement in policy to support its system transformation. The  Ministry  of  Economy,  Trade  and  Industry  builds  elements  of  community engagement  into  its  power  system  design  and  legislative  frameworks,  while  the Ministry of the Environment directly oversees citizens' participation in environmental impact  assessments.  Local  and  prefectural  governments  serve  an  additional  role through local permitting; they often act as a conduit between citizens and developers. In recent policy action, Japan has attached new engagement requirements to feed-in premium eligibility, bolstered community outreach on geothermal development and continued to support social licensing activities for nuclear developments. There has also been growing activity related to offshore wind: projects ranging from Nagasaki to Hokkaido  are  demonstrating  robust  engagement  between  local  civic  groups  and developers.

## Electricity grids and system flexibility

Japan has one of the most efficient and reliable power networks in the IEA. Despite its mountainous and island geography, losses have been at or below 5% for over three decades. It, however, faces mounting operational strain as shifting demand patterns and growth in renewable generation reshape system requirements. A core structural  challenge  is  the  dual-frequency  grid,  with  eastern  Japan  operating  at 50 Hz and western Japan at 60 Hz. These two systems are connected only through limited frequency converter stations, which constrain power flows across regions and can increase the cost of integrating VRE.

These structural constraints have become more visible as VRE penetration rises and  new  loads  emerge  in  certain  regions.  The  number  of  times  renewable curtailment occurred increased more than sixfold between FY2020 and FY2024. In FY2024, Japan's overall national curtailment rate (1.4%) was quite low compared, for  example,  to  Australia's  (2.5%),  one  of  the  few  IEA  countries  to  share  the characteristics  of  an  isolated  grid  and  separate  supply  and  demand  centres. However, several Japanese regions, including Kyushu (with 4.8% curtailment in FY2024), Shikoku (3.2%) and Chugoku (2.3%) are particularly affected as they host high solar PV capacity, low local demand and limited transmission capacity. Data centres, semiconductors and digital industries are expected to increase peak load

on a national level by around 6 GW between FY2026 and FY2035 and intensify competition for grid capacity. At the same time, the demand outlook differs greatly by region. While electricity demand and peak demand in regions such as Hokkaido and  Tokyo  are  expected  to  grow  by  around  8%  between  FY2026  and  FY2035, Shikoku is projected to see a decline of roughly the same rate.

As  digital  and  electricity  infrastructure  become  increasingly  intertwined,  Japan established  the  'Watt-Bit'  initiative.  This  initiative  aims  to  encourage  effective collaboration  between  electricity  and  telecommunication  entities  and  integrate electricity  infrastructure  planning  with  digital  infrastructure  needs  such  as  data centres. To meet new demand for data centres, it will be important to tap Japan's regional renewable potential, and the growing use of VRE will require transmission expansion.

Limited  transmission  capacity  and  congestion  on  cross-regional  interconnection lines have become a key concern in Japan, including between Tohoku and Tokyo and Hokuriku and Chubu. Despite ongoing reinforcements, interregional transfer capacity  remains  insufficient  to  fully  smooth  regional  imbalances  in  supply  and demand. Japan uses  an indirect  auction  mechanism  that  generates  zonal  price differentials across regions as a means of providing price signals for transmission congestion  between  regions.  However,  within  regional  transmission  networks, congestion management is mainly handled through transmission system operator-led redispatch, and zonal pricing and locational marginal pricing remain under consideration as future options.

In light of the need for large-scale integration of renewable energy and enhanced system  resilience,  Japan  formulated  the  'Master  Plan  of  Nation-wide  Power Transmission Networks' in March 2023, outlining the future vision of the power grid. Building on the Master Plan, Japan is reinforcing congestion-prone interconnectors, upgrading  converter  stations and  preparing  new  high-voltage  direct  current corridors.  The  Master  Plan  estimates  investments  between  JPY 6  and  7 trillion, mainly  for  large  cross-regional  transmission  corridors,  by  2050.  These  large interregional transmission projects typically face long planning and implementation timelines, such as the 2 GW Hokkaido-Honshu interconnection with an estimated construction timeline of 6-10 years. Without proactive grid planning, grid development can be much slower than renewable deployment and the emergence of new loads, which generally have shorter lead times.

Much of Japan's grid infrastructure was built in the late 20th century. OCCTO has highlighted that the challenges associated with the ageing infrastructure cannot be addressed at the current pace of replacement. In addition, Japan's expansion of renewables  and  electrification  point  to  the  need  for  substantial  grid  expansion. A critical aspect of transmission and distribution investment is the framework for cost recovery and the extent to which it provides incentives for modernisation, upgrades and expansion. In 2023, Japan reformed the tariff regulation of transmission and distribution  companies  to  encourage  grid  investment,  moving  from  cost-plus  to  a system  that  approves  multi-year  revenue  caps  based  on  operators'  five year -investment plans, including network expansion, renewal and resilience investments. The regulatory framework for electricity networks is still evolving following the reform. One example is the introduction of generation-side transmission tariffs in 2024.

Japan's structural constraints and fragmented regional grids increase the need for system  flexibility  within  balancing  areas.  Japan's  flexibility  assets  are  currently mainly based on existing thermal power plants and pumped hydropower. However, this  is  about  to  change:  driven  by  subsidies  and  other  factors,  grid-scale  battery storage project applications surged to 171 GW by the end of 2025. However, only 1 GW of grid-scale batteries are connected to the grid. As clear operational rules and grid connection procedures are still being developed, this contributed to delays, and may also have encouraged speculative applications. As a result, Japan has started to introduce  interim  measures  to  improve  the  situation  and  accelerate  grid connection  processes.  Market  reforms  (see  below)  have  technically  opened additional  revenue  streams  for  batteries  and  other  distributed  flexibility  assets. However, frequent changes in the market design, limited price signals, and structural barriers such as high minimum bid sizes or unclear rules for small resources added to  uncertainty  and  limited  the  participation  potential.  The  integration  of  demand response is also progressing. As in most other markets, demand response is mainly driven by industrial consumers participating in capacity and balancing markets. From FY2026 onward, low-voltage resources can also participate in the balancing market.

## Electricity market

The  current  electricity  market  design  consists  of  short-term  and  mid-  to  long-term markets  as  well  as  complementary  mechanisms  to  secure  long-term  generation adequacy.  The  Japan  Electric  Power  Exchange  operates  the  electricity  markets  in Japan.  While  the  full  retail  liberalisation  and  the  creation  of  new  wholesale  market mechanisms have laid the groundwork for a more competitive system, challenges such as low liquidity in certain markets and insufficient price signals to secure investment in

capacity and flexibility still exist. In response, Japan is advancing a suite of reforms to strengthen  market  functioning  while  safeguarding  security  of  supply.  It  has  also progressively opened markets for all participants, including distributed resources.

Exchange-traded electricity volumes in Japan's long-term markets are relatively small compared with those in Europe, equivalent to around 10% of total electricity demand in Japan in FY2024. To facilitate access to baseload electricity for new market entrants, Japan established a baseload market that requires incumbents to sell part of their output into this market. Japan seeks to develop the medium- to long-term trading environment to improve the predictability of investments and fuel procurement and enable retailers stable access to medium- to long-term supply capacity. The spot market is the most important  platform  in  terms  of  trading  volumes,  accounting  for  around  40%  of  total electricity generation. It is split into ten bidding zones, corresponding to regional utility areas. Following record price spikes driven by extreme weather in the winter of 2021, Japan introduced price caps for the spot market which are set at JPY 200/kWh. On the other end of the scale, the spot market has a price floor at zero, limiting signals of oversupply to market participants. The balancing and ancillary service market for all products was launched in 2021 and fully rolled out by 2024. It continues to be subject to design changes.

Starting in 2020, Japan introduced complementary mechanisms to address investment gaps, ensure capacity adequacy in the long run and provide targeted support for lowemissions sources. The capacity market contracts future supply capacity four years before target delivery. Auctions have been held annually since 2020, including price caps.  Successful  bidders  are  required  to  provide  capacity  in  the  delivery  year  and receive capacity payments in return. Prices differ by region and reached, on average, more than 11 000 JPY/kW per year in FY2024, with regions such as Hokkaido and Tokyo reaching the price cap. Japan's capacity market volumes are set according to total capacity requirements, which are derived from peak demand and reserve margins.

In  addition,  in  FY2023,  Japan  introduced  a  Long-Term  Decarbonized  Capacity Auction as a core instrument to mobilise investment in firm, low-emissions electricity supply while safeguarding security of supply. It helps bridge the investment gap left by energy-only mechanisms, the capacity market and feed-in tariff/feed-in premium (FIT/FIP) schemes by providing long-term revenue certainty, lowering financing costs and enabling investment in technologies critical for decarbonisation and reliability. The Auction includes new capacity, such as LNG power plants and battery storage, as  well  as  the  retrofit  of  thermal  power  plants  and  safety  upgrades  of  existing nuclear power plants.

## The Auction's key design features include:

- · Long-term capacity contracts for a period of 20 years, with remuneration linked primarily to availability rather than energy output.
- · Separate, technology specific auction categories, with individual calls, caps and -conditions for each technology.
- · Strict delivery and performance requirements, including penalties for non-delivery, to reduce project risk and ensure it contributes to system adequacy.

Initial  experience with the Long-Term Decarbonized Capacity Auction underscores the need to maintain effective competition despite limited project pipelines for some technologies, notably for nuclear and power plants equipped with carbon capture, while also managing long term -consumer cost exposure, preserving strong investment  signals  and  ensuring  credible  emissions  outcomes  (through  clear definitions  and  monitoring).  It  is  also  important  to  align  auction  allocations  with permitting processes, grid development and fuel supply chains. There is also potential to  improve  the  cost-effectiveness  of  the  mechanism  through  greater  technology neutrality, i.e. competitive auctioning across a range of technologies, not only within individual technologies.

## Nuclear energy

## Overview

After more than a decade of uncertainty following the Fukushima Daiichi accident, nuclear energy is gradually regaining a clearer role in Japan's energy and climate strategy.  In  the  immediate  aftermath  of  2011,  Japan  took  all  commercial  reactors offline  and  introduced  comprehensive  safety  reviews  under  a  new,  substantially strengthened  regulatory  framework.  Nuclear  output  collapsed,  forcing  a  sharp increase in fossil fuel imports and raising concerns over energy security, electricity prices  and  emissions.  The  7th  Strategic  Energy  Plan  and  the  Outlook  for  Energy Supply and Demand in FY2040 now reaffirm nuclear power as a key decarbonised baseload  option,  and  the  government  aims  for  nuclear  to  provide  around  20%  of electricity generation by 2040. Most nuclear power plants have limited use of waste heat, also due to the lack of district heating networks.

METI and its ANRE are responsible for overall energy policy, including the strategic role  of  nuclear  in  the  power  mix.  The  Nuclear  Regulation  Authority  (NRA),

established as an independent body after Fukushima, oversees safety regulation under the Reactor Regulation Act, including design certification, operational licensing, ageing management and periodic inspections. Local governments play a decisive role: as a matter of policy, the central government does not proceed with restarts without the consent of host prefectures and municipalities, reflecting the importance of public acceptance.

Safety  and  public  trust  are,  therefore,  at  the  centre  of  Japan's  nuclear  policy. Current policy emphasises that restarts and long-term operation are contingent on rigorous  compliance  with  NRA  standards  and  ongoing  improvements  in  safety culture.  At  the  same  time,  the  government  seeks  to  communicate  how  nuclear contributes to the 'S+3E' principle (safety, energy security, economic efficiency and environment). See the Fuels chapter for a more in-depth discussion of nuclear fuel supply and fuel cycle policy.

Because nuclear projects - whether restarts with major safety upgrades, long-term refurbishments or new builds - require large upfront investments and long payback periods, the government is examining mechanisms to reduce revenue and cost risks for long-lived decarbonised power assets. Options under discussion include public credit  enhancement,  the  use  of  government  creditworthiness  to  support  loans alongside private finance, and new tools to hedge inflation and cost escalation risks. See also the Financing energy transition section.

## Nuclear restart

Maximising the restart of existing nuclear reactors will be critical to achieve Japan's long-term  electricity  mix  targets.  Reactor  restarts  have  progressed  gradually  but steadily as operators complete safety upgrades and navigate NRA reviews and local consent processes. As of May 2026, 15 reactors with a combined capacity of around 14.6  GW  had  resumed  operations.  Another  group  of  units  representing  roughly 10.5 GW is advancing through the approval process. Commercial operations at the world's biggest nuclear power plant also started in April 2026. In parallel, 21 reactors (about 16 GW) have been permanently shut down since 2011, highlighting the scale of capacity loss that must be offset to reach the government's nuclear generation targets.

Japan's regulatory system applies a phased approval process. When establishing or modifying a reactor facility, utilities must first obtain approval from the NRA for the basic design and safety measures. At this stage, applicants must demonstrate their technical capability to construct and operate the facility, outline a robust financial plan,

and show that the basic design can prevent and mitigate severe accidents in line with regulatory standards. Subsequent approvals cover detailed equipment design and operational safety measures, including onsite procedures, staffing and emergency preparedness. This staged approach is designed to ensure that safety is rigorously assessed  at  each  step,  from  design  to  operation,  with  clear  opportunities  for regulatory scrutiny and public oversight.

Local acceptance remains critical. Many of the reactors that have restarted or are under  review  are  located  in  regions  where  utilities  and  local  governments  have developed structured engagement processes with residents, including information sessions  on  safety  measures  and  emergency  planning.  Nevertheless,  public opinion remains  mixed,  and  the  pace  of  restarts  continues  to depend  on case-by-case  local  deliberations  as  well  as  operators'  ability  to  demonstrate continuous safety improvements.

## New construction

Japan is targeting a nuclear share of around 20% in electricity generation in FY2040, a level slightly below pre-Fukushima output. However, more than 20 reactors were permanently shut down following the Fukushima accident and a growing share of the remaining fleet is approaching retirement age. Aligning stated nuclear ambitions and maintaining nuclear electricity production over the longer term will, therefore, require the construction of new reactors to replace decommissioned capacity. Kansai Electric Power's decision to start surveys for the construction of a new nuclear power plant in 2025  to  replace  Mihama Nuclear  Power  Plant  marks  the  first  step  to  start  new constructions  since  the  Fukushima  accident.  Two  other  reactors  with  a  combined capacity of 2.8 GW are currently listed as under construction, and have either not been  fully  completed  or  are  awaiting  regulatory  approval.  Both  reactors  started construction  before  2011.  TEPCO's  Higashidori  project,  whose  construction  was initially launched in 2011, is suspended.

The 7th Strategic Energy Plan introduces the concept of replacing decommissioned nuclear power plants with next-generation advanced reactors, including designs with enhanced safety features such as advanced light water reactors, SMRs, high-temperature gas-cooled reactors and fast reactors. At this stage, operators and local stakeholders have not advanced any concrete proposals. Policy documents focus instead on developing the regulatory, financing, and R&amp;D frameworks that would be required if operators and communities choose to pursue such projects in the future.

## Decommissioning and ageing fleet management

As more reactors approach or pass 40 years of operation, ageing management and decommissioning have become central priorities. Under the Reactor Regulation Act, units must undergo detailed ageing reviews at 30 and 40 years, and operation beyond 40 years  requires  explicit  NRA  approval  based  on  material  degradation,  seismic resilience  and  safety  systems  assessments.  Even  when  national  policy  supports extended operation, the NRA may withhold approval if safety standards are not met.

The GX Decarbonized Power Source Act (June 2023) retains the 60-year operational limit  under  the  Electricity  Business  Act  but  introduces,  from  June  2025,  a  rule excluding periods of outage beyond an operator's control - such as lengthy regulatory reviews  or  court-ordered  shutdowns -  from  the  60-year  calculation.  This  aims  to provide more predictable utilisation horizons without weakening safety requirements.

## Nuclear generation and nuclear capacity without retirements and new constructions in Japan

<!-- image -->

IEA. CC BY 4.0.

Notes: Nuclear capacity includes plants with suspended operation. The suspended category includes plants undergoing the approval process. New constructions are not included. The chart excludes potential retirements from suspended and operational plants. The 2040 projections for nuclear generation are an average of the published lower and upper ranges for electricity generation.

Source: IEA analysis based on IEA (2026), Electricity Information; Japan, Ministry of Economy, Trade and Industry, 7th Strategic Energy Plan (accessed in April 2026); IAEA, Power Reactor Information System (accessed in April 2026).

With large-scale decommissioning underway -one reactor has completed decommissioning to date (Japan Power Demonstration Reactor) and the process for 26 reactors  has  started  or  is  scheduled  -  Japan  has  strengthened  its  institutional

framework.  Since  April  2024,  the  Nuclear  Reprocessing  and  Decommissioning Facilitation  Organization  has  been  responsible  for  'decommissioning  facilitation work',  including  comprehensive  management  of  decommissioning  across  Japan; addressing common issues faced by nuclear operators; and securing, managing and paying for  decommissioning funds. Operators are  required  to  contribute  funds  for these  activities.  While  this  does  not  replace  operators'  own  decommissioning obligations, it is intended to ensure consistent progress across the fleet and support the sharing of technical expertise on decommissioning practices across the industry.

## Renewable energy

Renewables, including solar PV, wind, bioenergy and geothermal, supplied 9% of all electricity in Japan in 2010. This share increased to around 24% in 2024. Japan aims to further raise it to around 40-50% by FY2040. Solar PV has been the main driver of renewable development since 2010: solar PV generation increased almost ten times more than wind output between 2010 and 2024. This expansion has positioned Japan as the leader in installed solar PV capacity per land area and flat area among major solar  PV  countries.  The  following  section  mainly  focuses  on  solar  PV  and  wind; geothermal energy is discussed in the Focus area on Geothermal energy. The Energy R&amp;D section includes a policy spotlight on perovskite solar cells.

Solar PV and wind generation in Japan and solar PV capacity by grid region, FY2019 and FY2025

<!-- image -->

IEA. CC BY 4.0.

Note: Regions listed in the right panel (from top to bottom): Hokkaido, Tohoku, Tokyo, Chubu, Hokuriku, Kansai, Chugoku, Shikoku, Kyushu and Okinawa. Sources: IEA analysis based on OCCTO (2026), Annual Reports, (accessed in June 2026); IEA (2026), World Energy Balances.

Japan revised  its  renewable  energy  support  scheme  following  the  rapid  solar  PV expansion under the FIT. It has now mainly shifted toward a more market-oriented framework  with  the  FIP  scheme  introduced  in  2022.  Under  FIP,  generators  can receive a premium in addition to a market reference price, encouraging production in periods  of  high  wholesale  prices  and  system  needs  while  limiting  any  burden  on electricity consumers. Japan has announced that from FY2027, FIT and FIP support will exclude ground-mounted commercial solar PV. METI sets FIP auction volumes annually,  considering:  deployment  targets,  expected  project  pipelines,  system constraints  (grid  capacity  and  curtailment  risk),  costs  to  consumers  and  market development outside FIP (power purchase agreements or merchant development).

Japan's mountainous terrain and limited land availability constrain the deployment of renewables,  especially  of  large  ground mounted  solar  PV.  Some  projects  have -sparked local backlash in some areas due to land degradation concerns, safety and disaster risk worries, and insufficient early communication with residents. As a result, Japan strengthened business discipline and the enforcement of existing regulations for renewable power plants. The goal is to reinforce community engagement, improve project discipline and introduce renewable energy that coexists with local communities. METI can suspend premium payments in case of non-compliance with relevant regulations. An inter-ministerial council, established in 2025, co-ordinates policy  responses  around  environmental  damage,  safety  concerns  and  community opposition around large solar PV installations. As a first result, Japan adopted the 'Mega-Solar  Countermeasure  Package'  in  late  2025.  In  addition,  since  2024, developers of large-scale projects must organise briefing sessions for local residents before  obtaining  project  certification  and  in  cases  of  major  changes  such  as ownership transfers.

Japan  has  also  reformed  grid  connection  rules  toward  a  more  pragmatic  and integration-friendly  approach  to  facilitate  renewable  energy  deployment.  Since FY2021, the government has introduced a non-firm or 'connect and manage' grid access policy to enable renewables to connect without waiting for grid reinforcements. From April 2022 onward, all new renewable generators receive by default non-firm contracts, but they accept the risk of curtailment during congestion. Solar PV and wind are prioritised in the curtailment priority following a reform in 2022. While the grid connection reforms opened the grid to rapid renewable growth, physical grid limits and  congestion  are  increasing  concerns.  As  a  consequence,  transmission  and distribution operators must disclose grid information such as grid capacity and supply and  demand  data  to  help  developers  target  less  congested  areas.  Information disclosure is not uniform and can take different shapes, including capacity maps.

Offshore wind is a strategic priority, with targets of 10 GW by 2030 and 30-45 GW by 2050, reflecting in part the limited availability of suitable onshore sites. Japan's deep coastal waters compared to other areas such as the North Sea adds complexity to  offshore  wind  deployment.  Floating  offshore,  which  is  still  in  its  early  stage  of commercialisation,  is  particularly  well-suited  to  these  conditions.  Japan  aims  to deploy  around  15  GW  of  floating  offshore  wind  capacity  by  2040.  The  first commercial-scale floating wind farm started operation in January 2026, supported by the Green  Innovation Fund. Support under the Fund  focuses not only on demonstration  projects  for  floating  offshore  wind,  but  also  on  the  development  of offshore wind technologies more broadly. Japan's offshore wind strategy also targets a  domestic  procurement  ratio  of  65%.  In  addition,  Japan  aims  to  transfer  its knowledge internationally, aiming to expand the total capacity of overseas floating capacity by domestic companies to 30 GW by 2040.

Japan has introduced a competitive auction framework for offshore wind under the Marine Renewable Energy Act, expanded in 2025 to include exclusive economic zone areas and centralised environmental assessments. Despite this strong policy push, Japan's  offshore  wind  sector  has  faced  delays  and  significant  barriers.  All  three projects from the first round of the auction withdrew following cost increases related to tight supply chains, inflation and exchange rates, as well as deteriorating financing conditions.  The  second  and  third  rounds  were  characterised  by  aggressive  zero premium  bidding  under  the  FIP  scheme.  The  successful  bids  continue  to  face  a challenging  environment,  with  rising  interest  rates,  inflation,  currency  depreciation and immature domestic supply chains. Lengthy permitting processes, limitations of government-led site surveys, grid congestion (with estimates of curtailment levels of up to 30% in Hokkaido without countermeasures), and high upfront grid connection and expansion costs further hinder development. Based on the experience of the first auction  rounds,  Japan  plans  to  revise  the  future  auction  scheme  to  ensure  the successful introduction of offshore wind in Japan's early stage of deployment while continuing to emphasise cost reduction. The close integration of industry and energy policy is also reflected in the support measures aimed at attracting manufacturing facilities of wind power equipment in Japan.

## Fuels

Fossil fuels account for more than 80% of total energy supply (TES), a share that has changed only marginally over the past two decades, apart from an increase following the Fukushima accident. Japan has very limited domestic fossil fuel resources and

production remains minimal. As a result, almost all fossil fuels are imported, making energy security a central policy concern. Energy policy thus seeks to reduce reliance on fossil fuels under the GX Vision while balancing this objective against the need to ensure security of supply across all time horizons. To maintain stable supplies of oil and natural gas, Japan promotes fossil fuel exploration and production with the direct involvement of domestic companies. The government aims to raise the independent development ratio of oil and natural gas to 50% or more by FY2030 and to 60% or more  by  FY2040,  compared  with  42.1%  in  FY2024.  The  Strategic  Energy  Plan positions fossil fuels as part of the transition energy mix, and Japan anticipates a continued role for natural gas, including as a feedstock of hydrogen production. The Focus area on Natural gas discusses natural gas in more detail.

## Oil

Japan is among the top six oil importers in the world and fully relies on imports for crude oil. In 2025, it imported around 2 350 thousand barrels per day (kb/d), with the United Arab Emirates and Saudi Arabia as its main trade partners. Net trade for oil products adds another 650 kb/d, with the United States being Japan's largest supplier for  oil  products,  followed  closely  by  Korea.  Japan  also  has  a  significant  refining capacity, which mainly delivers for domestic needs.

Emissions from oil represent around 35% of all of Japan's energy-related emissions. The main users of oil are transport and industry. While oil is the biggest energy source in  Japan  and  covers  around  half  of  total  final  consumption,  demand  continuously dropped over the ten-year period from 2014 to 2024 by more than 1 000 kb/d. The largest  decline  came  from  oil-fired  power  plants,  as  many  older  units  have  been mothballed.  Other  factors  helped  to  considerably  reduce  oil  demand.  One  of  the success stories are Japanese hybrid cars, which boosted vehicle efficiency and have been the main driver for reducing oil consumption in transport. While the use of oil in buildings is lower compared to other end-use sectors, Japan has one of the highest level of oil consumption for heating in the world. Increasing competitive pressure is also affecting the domestic petrochemical sector, contributing to lower oil demand amid a challenging economic environment.

Ensuring  a  stable  and  reliable  supply  of  oil  remains  a  central  priority  of  Japan's broader energy policy. Japan's oil strategy focuses on reducing vulnerability to global supply disruptions through the diversification of import routes and trading partners. In addition, Japan seeks to secure upstream interests by promoting oil production with the direct involvement of Japanese corporations.

## Coal

Japan has a phased transition policy that places coal as a secure and economically viable energy source. Japan is almost entirely dependent on imports to meet its coal demand and is  thus  the  world's  third-largest  coal  importer,  with  imports  reaching around 162 Mt in 2025. Australia is Japan's primary supplier, accounting for just over two-thirds  of  total  imports,  or  112  Mt  in  2025,  while  Indonesia  has  consistently provided a significant share, supplying around 29 Mt in 2025.

Ensuring a secure supply of coal continues to be a main priority for Japan, as coal has relatively low geopolitical risks and provides security of supply due to its ease of storage.  Japan  has  secured  a  large  share  of  its  imported  coal  through  long-term contracts. While spot purchases have been more common in recent years, Japan aims to maintain a stable procurement environment, targeting a 60% share of the independent development ratio for coal.

Coal is the second-largest contributor to TES after oil and accounts for around 40% of Japan's energy-related emissions. It is mainly used for electricity generation, which represents just under two-thirds of coal consumption. The remaining third is used in industry.  Between  2014  and  2024,  emissions  from  coal  combustion  declined  by around 75 Mt CO2-eq, driven primarily by reduced demand in the iron and steel sector. Japan was historically the world's third-largest steel producer but fell to fourth place in 2025 as output declined to levels not seen since the late 1960s, reflecting lower domestic demand, particularly from the construction sector, and intensifying global competitive pressures.

Policy efforts to reduce coal use focus mainly on the power sector, notably through the fade-out of inefficient units and restrictions on new unabated capacity, reflecting the direction of the 2024 G7  Climate, Energy and Environment Ministers' communiqué. Existing coal-fired power plants in Japan are among the most efficient in the world, with widespread deployment of ultra-supercritical compared with around 38%  for  conventional  plants.  Coal  use  in  power  generation  peaked  in  2017  and declined by 10% by 2024. Progress in reducing inefficient coal-fired generation has slowed  due  to  concerns  about  supply  capacity  shortages,  as  coal-fired  power  is considered important for grid stability due to its system inertia and ability to provide essential grid services. Japan, therefore, pursues the decarbonisation of coal-fired power  generation  on  the  premise  of  maintaining  a  secure  and  reliable  electricity supply, including through increased co-firing of solid biofuels and ammonia and the development of fuel-switching pathways.

Japan expects coal demand to persist in hard-to-abate industrial sectors  such  as steel, chemicals and cement. It recognises that, from the perspective of supply and demand, steel  production  through  the  reduction  of  iron  ore  using  coking  coal  will continue to be necessary. At the same time, the 7th Strategic Energy Plan supports the  gradual  deployment  of  decarbonisation  technologies  to  reduce  the  carbon footprint of coal use in these sectors, including the promotion of hydrogen-based and other innovative steelmaking processes. Carbon capture, utilisation and storage is also positioned as an  important lever for decarbonisation  in sectors where electrification is difficult (see the Industry chapter).

## Nuclear fuel

With no significant domestic uranium resources, Japan relies on diversified long-term import contracts with suppliers such as Australia, Canada and Kazakhstan. It also maintains strategic fuel inventories to reduce geopolitical and supply risks. Nuclear power is regarded as a quasi domestic energy source, as it can ensure a stable and -secure supply for several years based on domestic fuel stockpiles, given that nuclear reactors normally only need to be refuelled every 18 months.

Japan pursues a closed fuel cycle policy, aiming to reduce dependence on imported uranium, recover usable uranium and plutonium from spent nuclear fuel, manage waste disposal, and improve energy self-sufficiency. The Japan Nuclear Fuel Limited site in Rokkasho is the cornerstone of this strategy. Key facilities at the Rokkasho site include waste  storage  facilities; a uranium  enrichment  plant  (operational); a reprocessing plant that is nearing commercial readiness after significant construction delays (under testing, awaiting approval); and a MOX fuel fabrication plant (under construction, expected around 2030).

While most enriched uranium is currently imported, Japan's sole enrichment facility received a first delivery of uranium in October 2025 for the first time in 11 years. The current production capacity is expected to increase from 150 tonnes in 2025 to around 450 tonnes by early 2029. Domestic capacity expansion is part of Japan's strategy to improve energy security. The planned enrichment capacity corresponds to around 15% of domestic demand if nuclear electricity generation supplies around 20% of total electricity generation.

Japan  started  the  screening  process  for  potential  geological  disposal  sites  for radioactive waste. Radioactive waste management is an important aspect for nuclear acceptance in Japan.

## Bioenergy

Bioenergy  accounts  for  around  3%  of  TES  in  Japan,  which  is  among  the  lowest among IEA countries. Solid biofuels are, by far, the dominant fuel, whereas gaseous and  liquid  biofuels  play  a  minor  role.  Japan  aims  to  promote  the  technological development of advanced biofuels, including for use in aviation, maritime and road transport. As Japan has limited domestic feedstock, it plans to import bioethanol from countries with high domestic production to meet blending targets for road transport fuels. This  approach  also  supports  the  diversification  of  trading  partners,  as bioethanol supplier countries often differ from Japan's traditional oil-trading partners.

## Recommendations

<!-- image -->

## Increase technology neutrality in energy policy to promote greater cost efficiency and bolster policy stability

Japan's  policy framework  combines  ambitious  long term  climate  targets  with -extensive  technology specific  support  across  the  innovation  chain.  While  this  has -accelerated progress in priority areas such as hydrogen, ammonia, batteries, ZEBs and  next generation  renewables,  the  strong  reliance  on  targeted  subsidies  and -bespoke support schemes at the commercial deployment stage risks creating uneven incentives  across  technologies.  In  several  sectors,  including  power  generation, industrial decarbonisation and end use electrification, support is tied to predetermined -technology pathways rather than performance or cost effectiveness. This can weaken -competition,  slow  the  adoption  of  emerging  low cost  solutions,  and  reduce  the -system's ability to adapt as technologies and market conditions evolve.

To address these challenges, Japan could expand the use of technology neutral, -competitive mechanisms that allow a broad set of low emission solutions to compete -on equal terms. For example, the rules of Japan's low carbon capacity auctions could -be  modified  so  that  various  technologies  providing  firm,  flexible  or  dispatchable capacity would compete based on cost and emissions performance. Another example is technology neutral -industrial decarbonisation pathways that would support emissions  reductions  at  least  cost  rather  than  through  predetermined  fuels  or processes. Strengthening carbon intensity and performance based requirements in --public support schemes, and ensuring that pricing instruments - such as Emissions Trading  System  design,  incentives  and  auctions -  are  neutral  between  eligible

technologies, will further encourage efficient outcomes. These tools can coexist with targeted R&amp;D support, but deployment stage instruments should increasingly rely on -open competition.

A more technology neutral approach would improve cost efficiency, minimise the risk -of over compensation and avoid premature lock in to higher cost pathways. It would --enhance investor confidence by providing stable, predictable mechanisms insulated from shifts in specific technology preferences, and ultimately help protect consumers by ensuring that scarce public resources are allocated where they deliver the greatest emissions  reductions  per  yen  spent.  By  strengthening  competition  and  focusing support  on  performance  rather  than  prescribed  technology  choices,  Japan  can accelerate its transition while maintaining affordability and policy stability.

<!-- image -->

## Strengthen alignment across the innovation ecosystem, in both the public and private sectors

Japan has long been a global leader in energy and industrial innovation, underpinned by  substantial  public  investment;  strong  corporate  R&amp;D  capacity;  and  a  dense network of universities, research institutes and technology platforms. As the scope and  complexity  of  the  energy  transition  expand -  encompassing  digitalisation, electrification, hydrogen, CCS, advanced materials and system integration - ensuring strong alignment across the innovation ecosystem becomes increasingly important to sustain momentum and maximise impact.

Building  on  its  existing  strengths,  Japan  could  further  enhance  co-ordination  and information-sharing  across  ministries,  agencies  and  programmes,  with  a  view  to strengthening  continuity  along  the  full  innovation  chain,  from  basic  research  and applied R&amp;D to demonstration, early deployment and market formation. Strengthening  strategic  oversight  of  energy related  R&amp;D  funding  and  clarifying -linkages  between  large  public  funding  instruments,  such  as  the  Green  Innovation Fund,  sectoral  GX  initiatives  and  longer  term  industrial  strategies,  would  help reinforce predictable development pathways and crowd in private investment.

Encouraging interdisciplinary and cross-sector collaboration bringing together engineering, digital technologies, system integration and social sciences - would further support  the  development  of  integrated  solutions  suited  to  future  energy  systems. Deepening structured dialogue between public authorities and private actors, including established firms and emerging innovators, can help ensure that innovation priorities remain responsive to technological progress and market developments.

A more closely aligned and collaborative innovation ecosystem would support the timely commercialisation of strategic technologies, strengthen public-private partnerships and enhance Japan's ability to deploy competitive low-carbon solutions domestically  while  contributing  to global decarbonisation  through  international markets and standards.

<!-- image -->

## Pursue greater policy stability to improve predictability of costs and revenues to support expanding investment in the power sector

Japan's  electricity  system  is  undergoing  a  profound  transformation  as  renewable energy expands, electricity demand rises with electrification and digitalisation, and thermal generation operates with declining utilisation rates. Meeting the ambitions of the 7th Strategic Energy Plan will require substantial new investment in clean sources of electricity, long duration storage, system flexibility and transmission infrastructure. -Frequently adjusting market rules reflects the system's rapid evolution, but can make long-term  revenue  expectations  more  complex  for  investors.  Overlapping  support schemes and some constraints on price formation are additional factors that reduce the  predictability  of  costs  and  revenues,  which  can  discourage  capital intensive -projects and slow the replacement of ageing assets.

To  strengthen  predictability  and  improve  investment  conditions,  Japan  should streamline co-ordination across the capacity, spot and balancing markets and ensure these mechanisms send consistent, technology neutral signals for new resources. -This  includes  expanding  market  access  for  storage,  demand  response  and  other flexibility providers, and reducing distortions by allowing a more complete expression of scarcity pricing, such as increasing the upper limit on spot market bid prices and enabling  negative  prices.  These  changes,  together  with  stable  long term  market -design and transparent timelines for reforms, would help investors assess revenue streams more confidently and manage project risk more effectively.

Greater policy stability and a clearer investment framework would support continued deployment of clean and flexible resources, support cost efficient achievement of the -7th Strategic Energy Plan's goals and reduce the long term cost of capital for essential -power sector infrastructure. Over time, this would strengthen system reliability; lower consumer costs; and allow nuclear, renewables and storage projects to scale at the pace required to achieve Japan's energy security and decarbonisation objectives.

<!-- image -->

## Further enhance electricity grid development with a focus on incentivising grid modernisation and streamlined grid connection processes

Japan's power system is entering a period of growth driven by electrification, data centre expansion and the scaling up of renewable energy. However, long lead times for  grid  upgrades,  limited  regional  interconnection  and  protracted  grid  connection approval processes risk slowing the integration of wind, solar PV and battery storage. Existing grid assets remain heavily constrained and operational practices continue to evolve  to  better  support  the  flexibility  needs  of  a  system  with  significantly  higher shares  of  variable  renewables.  Without  clearer  investment  signals  and  faster connection  procedures,  transmission  bottlenecks  and  curtailment  risks  will  likely increase, raising system costs and undermining the reliability and economic efficiency of the energy transition.

This can be addressed by strengthening incentives for transmission and distribution operators to modernise existing assets and expand grid capacity where it delivers the greatest  system  value.  Performance based  regulation  and  targeted  investment -frameworks  can  help  accelerate  reinforcement  projects,  digitalisation  and  grid modernisation, covering next-generation equipment replacement as well as data-driven asset utilisation and  operational optimisation. At the same  time, streamlining grid connection procedures for new large loads (such as semiconductor facilities and data centres) and new sources of electricity and storage will be essential. Establishing clearer timelines, more  transparent processes  and  strengthened co-ordination  with  OCCTO  can  significantly  reduce  delays  and  increase  grid connection certainty.

The  combination  of  these  measures  would  bolster  electricity security, lower integration  costs  and  support  the  faster  deployment  of  renewables  and  storage. A more modern, agile grid will also improve affordability for consumers by reducing congestion, curtailment and unnecessary investment, and will provide the backbone for Japan's broader decarbonisation and economic growth ambitions.

<!-- image -->

## Establish clear timelines for deploying new nuclear projects, including licensing for large-scale and small modular reactors, and continue the prioritisation of nuclear restarts

Nuclear power plays a vital role in Japan's energy transition, as the country retains deep industrial and regulatory expertise across the nuclear value chain. Japan has made important progress recently in restarting reactors after rigorous safety reviews. The IEA praises the government for its efforts to engage local stakeholders and raise public awareness and acceptance of nuclear power. Ensuring continued progress on reactor  restarts  remains  critical,  provided  that  all  safety  requirements  and  local community engagement processes are fully met.

In addition to restarts, Japan's electricity system will require new nuclear projects to meet  growing  demand  (including  round the clock  supply  for  data  centres  and --energy intensive industries), replace nuclear reactors that are eventually retired and -ensure  system  reliability.  However,  long  project  lead  times  and  uncertainties surrounding  the  extensive  licensing  process  for  each  reactor,  including  design approval, create uncertainty for investors and limit the potential contribution of nuclear energy. To address these challenges, Japan should establish clear and transparent timelines  for  licensing  milestones  and  the  deployment  of  large scale  reactors  and -emerging SMR technologies. Strengthening policies to support innovative financing models,  nuclear  workforce  development  and  domestic  supply  chain  resilience, including  nuclear  fuel  security, can  further  reduce  project  risks  and  improve deliverability.

Greater  clarity  on  nuclear  deployment  timelines  would  facilitate  timely  investment decisions and improve long term system planning. This would support the delivery of -the new nuclear capacity needed to complement renewable energy, meet growing electricity demand and ensure the availability of 24/7 low carbon power. Over time, it -would  help  Japan  maintain  industrial  leadership,  strengthen  energy  security  and provide reliable foundations for an electrified, digitalised economy.

<!-- image -->

## Accelerate road transport decarbonisation through a strategic mix of sustainable biofuels, electrification, charging infrastructure and smart charging

Japan  has  adopted  a  comprehensive  and  flexible  approach  to  decarbonising transport, pursuing a range of technological pathways including BEVs, hybrids and plug-in  hybrids,  FCEVs,  and  the  use  of  low-  and  zero-carbon  fuels.  This  strategy reflects  Japan's  specific  circumstances,  including  energy  security  considerations, industrial structure and the importance of reducing emissions from the existing vehicle stock,  and  is  intended  to  mitigate  the  risks  associated  with  reliance  on  a  single technological solution.

At the same time, the breadth of policy support across multiple vehicle technologies and  fuels implies significant and  growing demands  on  public  finances and infrastructure development. In this context, it becomes more important to ensure that policy  instruments  are  guided  by  transparent  assessments  of  life cycle  emissions impacts,  cost-effectiveness  and  system  value.  Strengthening  such  assessments would help clarify the respective roles of different pathways over time while preserving flexibility and technological neutrality.

In  road  transport,  Japan's  long-standing  fuel-efficiency  standards  and  support  for hybrid  vehicles  have  delivered  substantial  reductions  in  fuel  consumption  and  oil dependence. However, as efficiency gains from conventional and hybrid powertrains approach technical limits, further emissions reductions after 2030 will increasingly depend  on  a  higher  uptake  of  vehicles  capable  of  operating  with  zero  tailpipe emissions and on continued reductions in the carbon intensity of electricity supply. Closer alignment between  transport electrification policies and power sector decarbonisation  trajectories  will,  therefore,  be  essential  to  maximise  the  climate benefits of vehicle electrification.

Regulatory and fiscal frameworks that continue to favour compact, efficient vehicles, including  Kei  cars  -  and  that  increasingly  differentiate  in  favour  of  zero-emission variants  within  this  segment  -  can  provide  a  cost-effective  lever  to  accelerate electrification  while  maintaining affordability for households. At the same time, the continued  roll-out  of  charging  infrastructure  will  be  a  critical  enabler  of  transport

electrification. Ensuring that charging infrastructure planning and support schemes explicitly take into account local needs will be important to ensure equitable access to electrification and avoid reinforcing regional disparities.

Japan's  strategy  for  FCEVs  and  hydrogen  infrastructure  is  explicitly  focused  on commercial vehicles and geographically concentrated deployment, reflecting infrastructure costs, utilisation challenges and hydrogen supply constraints. Maintaining  this  targeted  approach  while  regularly  reviewing  progress  against utilisation,  cost  and  emissions  benchmarks  would  help  ensure  public  support  is aligned with realistic market development and emissions-reduction outcomes.

Finally, low fuel taxation and extensive purchase and infrastructure subsidies mean that public support currently plays a significant role in transport decarbonisation, with comparatively less reliance on price-based incentives. Over time, closer alignment between fiscal measures, emissions objectives and technology performance could help  gradually  rebalance  the  policy  mix,  reducing  reliance  on  subsidies  while maintaining affordability.

Strengthening evaluation, transparency and sequencing within Japan's multi-pathway transport  strategy  would  thus  help  maximise  emissions  reductions,  contain  public costs  and  support  an  orderly  transition  consistent  with  Japan's  energy  security, industrial and climate objectives.

<!-- image -->

## Develop a roadmap and implement measures to achieve zero-energy buildings by 2050

Japan has taken major steps to strengthen efficiency requirements for new buildings, yet  the  existing  building  stock  (much  of  it  constructed  before  modern  insulation standards) remains far from aligned with the country's 2035, 2040 and 2050 climate objectives. Renovation rates are currently limited, and heat pump deployment and building automation uptake are progressing more slowly than needed. A long-term, co-ordinated strategy would help ensure that efficiency gains in new construction are complemented by steady improvements in the existing building stock.

Developing  a  clear  ZEB by 2050  roadmap  would  help  align  regulatory  measures, --financial incentives, information tools and workforce development, providing predictable signals to households, developers and industry while allowing flexibility in how performance outcomes are achieved. It would provide a structured pathway for progressively raising buildings' performance requirements and benchmarks at points

of  sale  or  lease  (including  demand-response  requirements  for  appliances  and equipment); accelerating deep renovations; and expanding the adoption of high efficiency heat pumps, digital controls and other sustainable heating and cooling -solutions. The roadmap should define milestones for 2030, 2035 and 2040; outline renovation trigger requirements and workforce training programmes; and integrate financial  support  for  low-income  households.  Continued  strengthening  of  energy performance  disclosure  and  consumer  awareness  would  also  drive  demand  for high performance buildings. -

A comprehensive ZEB roadmap, and its effective implementation, would lower energy bills,  reduce  peak  electricity  demand  and  facilitate  the  integration  of  renewable energy.  It  would  give  industry,  local  governments  and  households  the  clarity  and confidence needed to mobilise investment at scale, supporting Japan's broader goals for energy security, resilience and carbon neutrality.

## Focus areas

## Natural gas

## Strategic role of natural gas

Natural gas remains a central element of Japan's energy strategy, accounting for 21% of its primary energy (FY2024). LNG supplies 33% of electricity generation and nearly all city gas. Japan relies almost entirely on imported LNG, reflecting limited domestic resource  availability  and  geographic  constraints.  This  import  dependence  places security of supply at the heart of Japan's gas policy. At the same time, another key policy objective is reforming  the gas  market  to  improve  efficiency,  increase competition  and  lower  prices  for  consumers.  These  two  objectives  do  not  always move in the same direction, as measures to enhance security of supply - such as diversification, redundancy  or  long-term  contracting -  can  entail  higher  costs. Nevertheless, some policies can support both goals: a more flexible and competitive market does not automatically increase physical resilience, but it can contribute to energy  security  by  enabling  more  efficient  use  of  infrastructure,  encouraging innovation, and facilitating more diversified and responsive sourcing of gas.

The 7th Strategic Energy Plan positions gas as an 'important energy source', even as Japan pursues carbon neutrality by 2050, reflecting the government's view that a secure  and  affordable  transition  requires  a  pragmatic  role  for  LNG  alongside accelerating the deployment of renewables, nuclear power, hydrogen and CCS. As of 2023, 57% of imported LNG was used for power generation, 37% for city gas, and the remainder for other uses such as vehicles and gas-fired air conditioning. This end-use structure reflects LNG's strategic importance for electricity adequacy and for household and industrial gas supply.

The Outlook for Energy Supply and Demand in FY2040 projects the primary energy supply of natural gas to be 53-61 Mt (LNG-equivalent) under a scenario in which a 73% reduction in GHG emissions is achieved. However, in an alternative scenario where slower technological progress leads to a lower level of decarbonisation (around a 61% reduction), natural gas supply is estimated to increase to around 74 Mt. Given that  Japan relies  almost  entirely  on  LNG  imports  for  its  natural  gas  supply,  these projections  imply  a  similar  range  for  LNG  import  demand.  This  scenario-based outlook recognises that gas demand may remain structurally significant if renewables, hydrogen or CCS deployment lags, and reinforces why Japan continues to prioritise secure LNG procurement and infrastructure resilience in parallel to decarbonisation.

## Supply chain fundamentals

Japan's gas system is structurally different from many pipeline-connected markets. Its resilience depends heavily on LNG terminals, tank storage and shipping logistics rather than pipelines and large-scale underground storage. Japan has 45 receiving terminals with relatively low terminal utilisation (around 30% on a vaporiser capacity basis),  indicating  valuable  redundancy  for  supply  security  and  potential  scope  for optimising this capacity for more efficient use of assets.

Given Japan's mountainous geography and dispersed coastal demand hubs, building a  nationwide  pipeline  network  has  been  economically  challenging.  High-pressure pipelines (over 1 megapascal) total approximately 2 500 kilometres (km). City gas services cover only about 6% of Japan's land area, but nearly 50% of all households and business establishments.

## Security of supply

In  the  Japanese  context,  this  report  defines  security  of  gas  supply  as  the  ability  to ensure reliable procurement of natural gas at affordable prices under normal market conditions  as  well  as  during  periods  of  stress.  Security  of  supply  involves  inherent trade offs between reliability, affordability and cost. It, therefore, encompasses three -key dimensions. First, it distinguishes between levels of security measures: 1) those delivered  through  market based,  commercial  arrangements;  2) those  that  enhance -resilience  but  involve  additional  system  costs;  and  3) those  that  are  mandated  or supported by government intervention, often to manage low probability but high impact --risks. Second, it recognises different time horizons, ranging from short term security -(operational reliability and emergency response over the next few years) to long term -security (investment, diversification and system resilience over a 10-20-year horizon).

Japan's commitment to  gas  supply  security  has  been  relatively  consistent  across different governments. Key strategies for ensuring a stable supply of LNG include diversification of supplies, equity participation in LNG projects overseas, long-term contracts, enhancements to procurement practices to increase contractual flexibility, utilisation  of  tank  facilities  abroad,  joint  procurement  and  strengthening  of  trading, Strategic  Buffer  LNG  (SBL),  and  developing  LNG  frameworks  and  education  in growing Asian markets.

## Supply diversification and equity participation

Japan's LNG import portfolio is broadly diversified across regions, with approximately 40% from Australia - a result of energy security strategy to avoid over-reliance on Middle  East  suppliers  and  leverage  Japanese  equity  in  Australian  projects,  low geopolitical  risks  and  short  transportation  distances.  In  2025,  Japan  imported approximately 65 Mt of LNG from Australia, Malaysia, the United States, Indonesia and Qatar, among others. This portfolio diversification reduces dependence on any single supplier, but Japan remains exposed to global oil-indexed contract pricing and spot market volatility, shipping constraints, and potential disruptions in key maritime chokepoints. Qatar and the United Arab Emirates provide about 6% of supply via the Strait of Hormuz and Oman provides about 4%.

<!-- image -->

While  Australia  has  been  Japan's  key  LNG  supplier,  evolving  policies  including domestic  gas  security  measures  and  tightening  emissions  requirements  have increased uncertainty about the future availability of Australian LNG exports.

In addition to contracting, Japan has long pursued upstream equity participation in LNG projects as a strategic instrument to secure supply and reduce vulnerability to market  shocks.  The  Japan  Organization  for  Metals  and  Energy  Security  provides equity  injection,  financial  guarantees  and  technical  assistance  to  support  Japan's overseas  interests,  and  co-invests  equity  in  LNG  projects  alongside  Japanese companies, providing 'risk money' to secure supply. The Japan Bank for International Cooperation provides financing for LNG projects. The Nippon Export and Investment Insurance  provides  insurance  to  Japanese  companies  in  overseas  transactions. These  public  funds  help  lower  the  barriers  to  investment  and  encourage  private Japanese  companies  and  banks  to  participate  in  gas  liquefaction  projects.  This approach  contributes  to  strengthening  Japan's  bargaining  position,  diversifying procurement channels and improving long-term predictability of volumes. Japan has 'independent development ratio' targets: by 2030 and 2040, it aims for 50% and 60% or  more,  respectively,  of  its  oil  and  gas  supply  to  come  from  projects  in  which Japanese  companies  have  upstream  ownership  stakes  (including  any  domestic production),  from  42.1%  in  FY2024.  This  underlines  the  relevance  of  upstream participation within Japan's broader security strategy.

Although the Middle East energy crisis blocked LNG supplies from the region coming to the market, over the medium term, Southeast Asian countries may still turn to LNG as a cleaner backup for renewables, with demand expected to grow as spot prices fall  towards  2030.  The  region  needs  enhanced  systems  to  support  a  robust  LNG supply chain. Japan, with its global LNG expertise, can offer financial and technical support for upstream investments and LNG facilities in Southeast and South Asia, while sharing operational and  safety  know-how.  Japan  develops  educational programmes centred on LNG handling, legal frameworks and regulatory standards in Asia and other regions where energy demand is growing.

## Long-term contracts

Japan's cumulative long-term contract volumes represent one-third of the world's LNG liquefaction capacity (excluding portfolio players). The 2022 energy crisis caused global LNG prices to surge, with gas prices in Germany rising sixfold while prices in Japan remained more stable. This was largely due to Japan's reliance on long-term contracts linked to crude oil prices. Europe's spot LNG share has increased to around 50% since the 2022 crisis, whereas Japan's spot share has stayed near 20%.

Japan expects to continue its emphasis on long-term contracts to ensure adequate volumes and reduce exposure to future tightening market conditions. The IEA's World Energy Outlook 2025 reports that investment in new oil and gas fields has dropped

sharply over the past decade, with global exploration spending expected to remain around USD 50 billion in 2025 - about half of the level in 2015. According to METI's outlook,  new  investment  will  be  needed  after  the  mid-2030s  to  meet  global  LNG demand. This underpins Japan's strategy to prioritise long-term contracts to stimulate upstream investments.

## Long-term LNG contracts and overall imports in Japan and selected countries, FY2025

<!-- image -->

Short-term and spot Long-term Long-term contracts' share of natural gas supply (right axis)

IEA. CC BY 4.0.

Notes: Long-term contract amounts are LNG received under a contract with a duration of more than four years. UK = United Kingdom.

Sources: IEA analysis based on GIIGNL (2025), GIIGNL Annual Report, (accessed in May 2026); IEA (2026), World Energy Balances.

At  the  same  time,  Japan's  buyers  increasingly  operate  in  a  context  of  demand uncertainty: nuclear restarts, renewables growth and electrification trends can limit gas demand; procurement strategies, therefore, need to balance long-term security with flexibility. Some LNG contract clauses have historically constrained resale and optimisation,  and  policy  attention  has  focused  on  ensuring  contractual  flexibility compatible  with  competition  and  security  goals.  The  Gas  market  reform  section discusses contractual flexibility in more detail.

## Transportation and maritime security

LNG  shipping  is  a  critical  component  of  energy  security  for  all  LNG-importing countries, including Japan. While global LNG carrier construction capacity is currently sufficient,  it  is  concentrated  in  a  limited  number  of  countries.  Japan's  reliance  on seaborne energy imports also underscores the importance of secure and efficient

maritime routes. As with other LNG-importing countries, risk assessments consider potential  disruptions  at  key  chokepoints  (such  as  the  Strait  of  Hormuz).  Japan's diversified LNG procurement strategy, combined with measures such as contractual flexibility, adequate storage and well-functioning LNG terminal operations, supports the resilience of its supply system.

## Storage

Japan's gas resilience relies heavily on LNG tank capacity at terminals, which acts as an  operational  buffer  (11.6  billion  cubic  metres  [bcm],  which  is  equivalent  to approximately 46 days of domestic gas consumption) but they cannot be operated at 100% capacity in practice. Initiatives to increase usable storage capacity must respect operational requirements such as the need to maintain headroom for the next cargo, retain mandatory heel volumes and manage quality/safety constraints. Constructing new  LNG  tanks  within  existing  LNG-receiving  terminals  offers  cost  advantages compared to building new LNG-receiving terminals or installing floating storage and regasification  units.  Saibu Gas  and  JERA  are  collaborating  to  add  LNG  tanks  to LNG-receiving terminals and use them for trading purposes. Use of unused tanks as storage tanks (e.g. at the Bontang LNG terminal) can be a cost-effective solution. In the past, Kyushu Electric Power Company used idle tanks at the Arun LNG terminal in Indonesia as storage tanks.

Japan has small underground gas storage facilities in depleted fields, with a total capacity of just 0.1 bcm due to its unsuitable geology and remote locations. Southeast and South Asia, where energy demand is rising, have more depleted fields that could be  used  for  regional  storage  with  Japanese  support.  Japan  could  even  consider developing  regional  swap  agreements,  as  recent  developments  have  increased market liquidity, facilitated swap transactions and improved options for short-term, hub-based storage.

## Emergency response and strategic reserves

Japan lacked emergency response legislation for gas and LNG until the cold wave in early 2021, which prompted the creation of guidelines to ensure fuel supply during high demand and improve transparency. The plan includes updating LNG procurement, disclosing  tank  limits,  forecasting  supply  and  demand,  monitoring  inventories,  and implementing  government-led  fuel  arrangements.  The  Gas  Business  Act  was amended after the 2022 energy crisis to allow METI to restrict gas usage for large consumers  during  supply  shortages.  The  Information  disclosure  section  provides additional information on energy security measures.

The SBL is one of Japan's key instruments. It provides a mechanism for additional LNG procurement and storage as a resilience measure. Under the SBL policy, METI designates private LNG operators with extra procurement capacity to manage SBL operations. If a supply issue occurs, these companies are requested to sell LNG to utilities at risk, with government compensation for losses and costs. JERA became the first designated supplier in November 2023. Initially, the scheme was only applicable for three months in winter, but was expanded to a year-round basis in January 2026.

<!-- image -->

Source: IEA (2024), Secure gas and LNG value chains call for greater international co-operation.

## Gas market reform and competition

## Overview

Since 2017, Japan's gas market reform has aimed to secure stable supply, lower prices through competition, expand consumer choice and uses for natural gas while recognising the unique structure of Japan's gas sector. The Amended Gas Business Act (April 2017) split 'general gas utilities' (businesses that supplied city gas through pipelines) into producers, pipeline operators and retailers, each requiring separate notification and licensing.

To support network development and supply stability, pipeline operators continue to operate under regional monopolies and price regulation while being required to facilitate interconnection and, if necessary, comply with government orders to resolve disputes.

To boost third-party access, the three largest gas companies (Tokyo Gas, Osaka Gas and Toho Gas) are barred from operating pipelines alongside production and retail, with  legal  unbundling  effective  from  April  2022;  other  companies  retain  separate accounts. Each operator must ensure pipeline safety and co-operation rules are in place for disaster response, with regular training to maintain resilience post-liberalisation.

Japan  has  introduced  measures  to  support  competition  in  wholesale  supply.  The 'Start Up Wholesale' initiative was launched in FY2020 as a voluntary measure by former general gas utilities to support new entrants into household retail gas markets, including through 'one-touch wholesale' arrangements. According to METI, 27 start-up wholesale contracts have been concluded to date, and the government continues to monitor the implementation.

Gas retail  has  been  fully  liberalised,  ending  former  monopolies  and  allowing  new entrants.  This  encourages competition,  cuts  costs  and benefits  consumers.  Retail price  controls  have  mostly  been  abolished,  though  transitional  regulations  remain where competition is limited. METI is assessing the gas market reform, and the results of this review are expected to inform any further adjustments.

Japan's unbundling of gas infrastructure and the introduction of third-party access to LNG terminals  aim  to  spur  competition  and  lower  prices.  These  reforms  improve efficiency and consumer choice and can also have a positive impact on resilience: a more  open  market  can  encourage  innovative  sourcing  (including  portfolio  LNG sellers), which over time might enhance security through diversification.

## LNG terminals and third-party access

Japan has already introduced a formal third-party access regime for LNG terminals as part of its gas system reform. Operators of LNG terminals above a certain scale are required under the Gas Business Act to file terms and conditions for gas-tolling services.  An  annual  outlook  for  spare  capacity  is  disclosed  in  accordance  with Article 90 of the Act and Article 142(2) of its Enforcement Ordinance. Guidelines on proper gas trade also set out desirable transparency practices, including quantitative disclosure  of  spare  capacity  under  room-rent  and  room-share  methods, 4 prompt

4 Room rent method: Spare LNG tank capacity is calculated and disclosed on the basis of tanks (or -parts of tanks) that can be 'rented' by third parties. Room share method: Spare capacity is -calculated by assuming shared use of LNG tanks, with available capacity derived from average inventory levels and operational margins.

presentation  of  indicative  charges  once  confidentiality  agreements  are  concluded, and calculation of charges based on fee standards reflecting average inventory levels and tank occupancy.

In practice, while the effectiveness of third-party access is improving, there is room for further progress. According to METI, there were 24 third party -use requests/applications  for  LNG-receiving  terminals  as  of  2025,  up  from  2  in  2016. Capacity disclosures are often aggregated and not always sufficient for prospective users to assess terminal-level availability, inventory conditions or likely costs. Access conditions continue to be negotiated bilaterally, which raises transaction costs for new entrants and reduces comparability across terminals. Improving the granularity and consistency  of  information,  especially  terminal-level  inventories  and  use,  would strengthen the practical functioning of the existing third-party access framework and help ensure that the system's sizeable LNG infrastructure base supports security and competition,  leading  to  lower  prices  for  consumers.  Reporting  should  distinguish between  requests/applications and concluded arrangements, recognising that outcomes depend on operational constraints and contract structures.

Where  disputes  arise  over  third-party  access,  parties  can  request  mediation  or arbitration by the Electricity and Gas Market Surveillance Commission (EGC). The EGC was established under METI; its chair and commissioners hold the authority for report collection, onsite inspections, recommendations and formal dispute resolution. To date, there have not been any cases of formal mediation or arbitration related to LNG terminal  third-party  use.  However,  some  operators  have  approached  ANRE and/or  the  EGC  for  consultations  regarding  third-party  use  arrangements.  This underlines the importance of transparent information and predictable processes that reduce the need for case-by-case escalation.

## Contractual flexibility

Current  long-term  contracts  pose  challenges  for  Japanese  buyers,  especially regarding flexibility in trading surplus LNG. In 2017, the Japan Fair Trade Commission found that some LNG contract clauses such as destination restrictions, unreasonable profit-sharing requirements and certain take-or-pay terms - may violate the Antimonopoly Act in cases where they unfairly hinder switching after investment recovery. Most of Japan's long-term LNG contracts include take-or-pay terms, which are integral to LNG project economics. Future contracts could seek more flexibility while  maintaining  mechanisms  that  underpin  investment  and  safe  operations.  For example, flexibility could increase once initial capital costs are recovered.

## Information disclosure

Information disclosure in the natural gas sector plays an important role in supporting effective regulation, enabling  competition  and  ensuring  system  preparedness. However, the appropriate scope and granularity of disclosure depend on its intended purpose  and  must  reflect  Japan's  specific  market  structure,  policy  objectives  and security considerations. Transparency objectives related to system-level adequacy and emergency preparedness differ from those related to commercial price discovery and market entry. They should, thus, be dealt with separately.

Japan has established a framework for gas sector transparency through the  Gas Business Act and related regulations. They call for updating of LNG purchase and delivery  plans,  especially  during  periods  of  high  demand,  to  ensure  appropriate inventory levels; publicly disclosing LNG tank operation limits; preparing electricity supply and demand forecasts incorporating the latest weather forecasts and Japan Electric Power  Exchange  trading  volume  estimates;  disclosing  fuel  constraint information through the Power Generation Information Disclosure System (HJKS) and monitoring fuel inventories, among  other  measures.  In  addition, government authorities conduct supply risk assessments and co-ordinate preparedness measures with market participants. These arrangements primarily support security of supply.

Information disclosure in a country or region can bring benefits beyond the immediate area  covered.  In  particular,  this  applies  to  information  related  to  inventory  levels, which not only provides transparency to market participants, but also supports supply security assessments on a broader scale, particularly in times of market tightness. Increased transparency bolsters market confidence and aids resilience because it enables swifter response to supply issues and allows governments and industry to identify risks early and co-ordinate. In principle, measures should be designed with safeguards to avoid revealing commercially confidential data of individual companies.

In Japan, the EGC collects information necessary for monitoring gas transactions and publishes area-level data such as sales volumes, number of contracts and switching rates. Japan currently does not have a widely used public LNG price assessment that reflects  import  costs  and  can  support  benchmarking,  contract  negotiations  and hedging. In the future, as the procurement mix evolves toward more flexible contract structures,  Japan  could  consider  more  enhanced  reporting  of  LNG  import  price information and the publication of a Japanese LNG price assessment, with appropriate safeguards for commercially confidential data. This would strengthen price discovery and encourage more effective competition among suppliers and retailers.

## Decarbonising gas

Japan's 7th Strategic Energy Plan states that it is important to build a gas system that contributes to decarbonisation and that various approaches will be combined to  achieve  carbon  neutrality  in  city  gas  by 2050,  including  the  introduction  of  emethane  and  biogas.  The  government  has  highlighted  hydrogen  derivatives including e-methane and e-fuels - as part of a broader transition strategy, and has indicated that integrated regulatory and support policies will be used to reduce costs and expand use. The logic is that low-carbon gaseous fuels could leverage parts of existing infrastructure while reducing life cycle emissions, although scale, cost and certification remain significant challenges.

Reducing methane emissions across the LNG value chain is also becoming more prominent internationally. Japan supports the Coalition for LNG  Emission Abatement  toward  Net-zero,  a  voluntary,  market-based  mechanism  to  reduce methane emissions through transparency and the sharing of best practices across the  LNG  supply  chain.  Strengthening  methane  emissions  measurement  and disclosure can complement Japan's gas security strategy by improving environmental  performance  and  reducing  reputational  and  trade  risks  as  global methane policy tightens. See the Fuels section and the Focus area on Hydrogen and ammonia for more detailed discussions of low-carbon fuels.

## Recommendation

<!-- image -->

## Enhance transparency and access conditions to support effective competition while safeguarding security of supply

Japan has built a robust natural gas supply system with a strong and consistent focus on security of supply, reflecting its near total dependence on imported LNG -and exposure to global market and geopolitical risks. Through long term -contracting, diversified sourcing, extensive LNG  terminal infrastructure and strategic buffer arrangements, Japan has demonstrated a high level of resilience, including during recent periods of global gas market tightness. These achievements underscore  the  central  role  of  security  considerations  in  gas  policy  and  the importance  of  maintaining  measures  that  may  entail  additional  costs  but  deliver reliability. Building on this solid foundation, well designed transparency and access -frameworks can play a complementary role by enabling effective competition and supporting regulatory oversight, provided they are carefully calibrated to Japan's market structure and security objectives.

Japan has already implemented a legal framework for third-party access for LNG terminals, annual disclosure of spare capacity, and the establishment of a market regulator responsible for oversight and dispute resolution. These measures form a solid legal  and  institutional  foundation.  Practical  use  of  the  framework  has progressed,  with  METI  reporting  a  growing  number  of  third party  requests/ -applications. It has also concluded wholesale arrangements. However, information disclosure remains constrained in practice, limiting new entrants' ability to assess available  capacity,  compare  access  conditions  or  optimise  LNG  procurement. Japan  can  enhance  its  framework  by  extending  disclosure  requirements  and broadening access to information. Targeted transparency, such as more frequent disclosure of spare capacities, terminal-level inventories in low-competition regions, utilisation rates, and  overviews  of  third-party  access  requests,  would  lower transaction costs for new entrants and help regulators better monitor markets, spot barriers to entry and co-ordinate during supply stress.

Where access issues persist in regions with limited competition, authorities should enhance  third party  access  frameworks  so  that  they  operate  in  a  transparent, -non discriminatory -and effective manner  while recognising that operational constraints and long term contractual arrangements may legitimately limit access -in some cases. Greater clarity around access conditions, processes and outcomes can improve confidence in market governance and increase competition without undermining  security  of  supply  arrangements.  In  parallel,  introducing  reporting obligations for LNG  import  prices and  developing a Japanese  LNG  price assessment  that  maintains  necessary  commercial  confidentiality  would  improve wholesale price transparency.

More  effective  access  to  LNG  infrastructure  could  potentially  foster  greater competition, lower  procurement costs and support more efficient use of existing LNG capacity.  Over  time,  as  the  procurement  mix  evolves  toward  more  flexible contract structures, improved transparency and access frameworks would enhance Japan's gas market resilience, provide clearer price signals to market participants and ultimately benefit consumers through a more competitive, efficient and secure gas system. Regular review of disclosure practices and access outcomes can help ensure that they are proportionate and effective, aligned with market realities, and responsive to evolving risks and opportunities.

## Hydrogen and ammonia

## Strategic role

Japan has been a global pioneer in hydrogen and ammonia policy, having published the world's first national hydrogen strategy in 2017. Since then, the government has steadily expanded and refined its policy framework, which includes the revised Basic Hydrogen Strategy (2023) and the Hydrogen Society Promotion Act, which entered into  force  in  October  2024.  Hydrogen  and  ammonia  are  positioned  as  central components of Japan's Green Transformation, supporting the simultaneous objectives of energy security, economic growth and decarbonisation under the S+3E principle.

Japan's hydrogen strategy reflects the structural characteristics of its energy system. The country is highly dependent on imported energy, has limited domestic fossil fuel resources,  and  hosts  a  large  industrial  base  with  significant  energy  demand  and several  hard-to-abate  processes.  In  this  context,  hydrogen  and  ammonia  are envisaged  as  complementary  options  within  a  multi-pathway  transition,  alongside renewables;  nuclear  power;  energy  efficiency;  electrification;  and  carbon  capture, utilisation and storage.

Japan's hydrogen demand is currently almost entirely met by hydrogen produced from  unabated  fossil  fuels,  which  is  mainly  used  in  industry.  Total  supply  is approximately 1.8 Mt per year, largely produced from natural gas reforming or as industrial  by-products  and  consumed  onsite  within  refineries  and  petrochemical facilities. Ammonia is currently mainly used as fertiliser and chemical feedstock.

Japan's  hydrogen  strategy  envisages  deployment  across  multiple  sectors.  In  the power sector,  hydrogen  and  ammonia  are  expected  to  contribute  to  dispatchable capacity and system flexibility during the transition, complementing the expansion of variable  renewables  and  supporting  energy  security.  In  industry,  hydrogen  and ammonia are seen as key options for decarbonising processes such as steelmaking, chemicals and refining, where full electrification may be technically challenging or costly. In transport, hydrogen has been promoted for fuel-cell vehicles and heavy-duty applications, while hydrogen-based fuels are being explored for shipping and aviation. Looking ahead, clearer articulation of how hydrogen deployment is expected to evolve across sectors, particularly as electrification, storage and other low-carbon options advance, could help guide investment and ensure that hydrogen delivers maximum system value over time.

## Policy framework

Japan's hydrogen policy is anchored in a stable legal and institutional framework. The revised Basic Hydrogen Strategy sets hydrogen supply targets of about 3 Mt per year by 2030, 12 Mt by 2040 and 20 Mt by 2050. While the targets are technology neutral -(applicable  to any  type  of  hydrogen),  the  Strategy  introduces  parallel  policy mechanisms to steer the mix toward low emissions hydrogen. Recognising that cost -is one of the main barriers to widespread hydrogen and ammonia adoption, Japan's Long-term  Strategy  under  the  Paris  Agreement  (2021)  and  the  revised  Basic Hydrogen Strategy set up hydrogen supply cost objectives of 30 JPY per normal cubic metre (Nm 3 ) by 2030 and 20 JPY/Nm 3  by 2050 from around 100 JPY/Nm 3  today.

Japan's  stepwise  approach  emphasises  early  market  creation  and  scale  while gradually  decarbonising  existing  hydrogen  supply.  The  government  is  seeking  to stimulate demand across multiple sectors, including power generation, industry and transport, on the premise that large volume deployment would enable cost reductions, infrastructure development and learning effects across the hydrogen value chain. The Strategy also aims to position Japanese companies as leaders in emerging global hydrogen and ammonia markets.

At the same time, Japan expects a large share of its future low-emissions hydrogen supply to come from imports. To support the scale up of supply and improve cost -competitiveness, Japan is actively developing international supply chains, notably an ammonia project in the United States, in which Japanese firms hold significant equity stakes. Japan is also strengthening co-operation with other demand-side countries, such  as  Germany,  through  memoranda  of  understanding  that  cover  hydrogen distribution, liquefied hydrogen stations and industrial applications. Japan also develops bilateral partnerships (Australia, the Middle East) for low-emissions hydrogen supply.

The updated 6th Strategic Energy Plan sets a 1% target for ammonia and hydrogen as a share of the electricity generation mix by 2030. Japan's strategy of deploying ammonia and hydrogen to decarbonise thermal power generation can contribute to energy security by maintaining firm capacity and enhancing fuel diversification. At the same time, these applications involve relatively high fuel costs; they, therefore, benefit from being positioned within a broader, well co-ordinated decarbonisation strategy. Careful policy design and periodic review can help ensure that support for hydrogen and ammonia in the power sector is well-aligned with parallel efforts to accelerate renewable  energy  deployment,  strengthen  system  flexibility  and  advance  other

cost effective decarbonisation options. In this way, hydrogen and ammonia can play -a complementary role in the power system, supporting the energy transition while preserving optionality as technologies and costs continue to evolve.

The Hydrogen Society Promotion Act provides the legal foundation for implementation. It introduces a system for approving integrated supply and demand business plans, enables long-term financial support for eligible projects, and allows for special regulatory measures where necessary. Importantly, the Act requires that projects receiving support align with Japan's Green Transformation policy objectives and demonstrate credible supply and demand commitments.

This framework is reinforced by complementary instruments. The Green Innovation Fund provides milestone-based funding for research, development, demonstration and social implementation across the hydrogen and ammonia value chain, including production technologies, transport and storage, power generation, and industrial applications. The GX Promotion Act further supports long-term investment through the  issuance  of  GX  Economy  Transition  Bonds  and  the  introduction  of  carbonpricing mechanisms.

Together these instruments provide a high degree  of policy continuity and predictability, which has been instrumental in mobilising private sector interest and advancing project development.

## Market creation instruments

Japan has put in place a set of instruments to create demand for low-emissions hydrogen  and  ammonia  and  to  reduce  investment  risk  across  the  value  chain. These include  a contract  for  difference  (CfD)-type  price  gap  support  scheme,  a Long-Term Decarbonized Capacity Auction for the power sector, targeted measures for transport (see the Transport section), and dedicated support for hub development and infrastructure.

## Price gap support mechanism

Japan established a JPY 3 trillion (USD 19 billion) price gap support scheme, one of the largest globally in financial size, accounting for around 15% of the GX budget. The scheme takes the form of a 15-year CfD-type mechanism and targets suppliers developing  commercial-scale  supply  chains  for  low-emissions  hydrogen  and  its derivatives.

Eligibility requirements are designed to ensure that public support catalyses durable markets rather than short-lived pilot projects. Production projects must be backed by a major hydrogen or ammonia consumer, begin supply by FY2030, and commit to continuing supply for at least ten years beyond the support period. The CfD bridges the price gap between low-emissions hydrogen or ammonia and conventional fossil fuels, in line with Japan's hydrogen cost-reduction targets. Applicants are required to submit detailed business plans covering supply volumes, emissions profiles, timelines and demonstrated demand.

By  April 2026,  around  128 kilotonnes  (kt)/year  of  hydrogen  equivalent  had  been supported  under  the  CfD  scheme.  The  first  application  window,  which  closed  in March 2025, attracted  27  applications,  with  total  requested  funding  exceeding  the initial  budget envelope. METI assesses the applications with input from third-party experts and projects are selected on a rolling basis.

Six supply chain projects had been selected as of April 2026, providing early insight into the types of value chains Japan aims to prioritise. The two largest projects are ammonia co-firing projects at coal-fired power plants. The JERA-led project plans to import and use approximately 500 kt of ammonia per year, primarily at Japan's largest coal-fired  power  plant,  the  Hekinan  Thermal  Power  Station  (see  the  Innovation section). The Mitsui-led project in Hokkaido is designed to supply around 280 kt of ammonia per year, with part of the volume allocated to industrial furnaces.

Four other projects focus on industrial applications, with significantly smaller volumes than those in the power sector. By April 2026, these projects corresponded to more than  4 kt  per  year  of  low-emissions  hydrogen  and  around  20 kt  per  year  of low-emissions  ammonia  for  industrial  use.  Targeted  sectors  include  steelmaking, chemicals and textiles, the food industry, and non-metallic minerals. These projects provide  early  examples  of  credible  industrial  use  of  low-emissions  hydrogen, demonstrating how it can be integrated into existing industrial processes to produce low-emissions materials while leveraging domestic technological capabilities.

The  initial  CfD  awards  reflect  a  hydrogen  policy  that  seeks  to  cluster  demand, combine different support instruments and reduce risk across the entire value chain. Both  the  JERA-led  and  Mitsui-led  projects  also  secured  support  under  Japan's Long-Term Decarbonized Capacity Auction and the hub development programme for infrastructure (see below). In addition, these projects allocate part of their ammonia supply to nearby industrial users, reinforcing local demand aggregation.

Overall,  the  early  project  selections  demonstrate  the  operationalisation  of  Japan's hydrogen  policy  instruments  and  the  government's  ability  to  translate  long-term

strategic  objectives  into  concrete  project  support.  They  also  highlight  a  pragmatic focus on projects capable of delivering large volumes in the near term, particularly where existing infrastructure and demand can be leveraged. At the same time, the current portfolio underscores  the importance  of sequencing  and  learning. A substantial share of supported volumes is associated with ammonia use in the power sector,  reflecting  the  readiness  of  large-scale  demand  and  the  role  of  power generation in anchoring early supply chains. By contrast, domestic green hydrogen projects remain comparatively small in scale, consistent with higher production costs and current constraints on renewable electricity availability. This experience points to the value of periodic review and adjustment of support mechanisms as costs decline and additional decarbonisation options mature across sectors.

## Long-Term Decarbonized Capacity Auction

The Long-Term Decarbonized Capacity Auction (see the Electricity chapter) includes support  for  retrofitting  or  replacing  thermal  power  plants  through  hydrogen  or ammonia  co firing.  As  part  of  the  bidding  process,  applicants  must  submit  a -decarbonisation roadmap to 2050. Japan capped support at 1 GW in each of the first two auction rounds, although the full volume was not awarded. Three coal fired power -plants were successful in these rounds for ammonia co firing at a 20% blending ratio, -corresponding to around 770 megawatts (MW) of coal capacity effectively operating on ammonia. While the total coal fired capacity of these plants is larger, the effective -ammonia based capacity reflects the blending ratios. In addition, one power plant with -an  ammonia  blending  ratio  of  approximately  30%  was  selected,  with  effective ammonia-powered capacity of around 55 MW.

Most of the selected projects are expected to begin ammonia co firing by FY2030, -with the JERA project scheduled to start earlier, by FY2029. The first auction rounds did not account for variable costs, such as fuel prices. Following the initial outcomes, Japan revised the auction design to include compensation for the price difference between hydrogen or ammonia and conventional fuels such as LNG or coal, based on a reference annual utilisation rate of 40%. Applications for the third auction round closed in January 2026.

## Hub development and import infrastructure

Japan places a strong emphasis on cluster-based development to anchor the uptake of low-emissions hydrogen and ammonia. These hubs are expected to play a central role in enabling  domestic  value  chains  by  connecting  import  infrastructure,  storage, transport and multiple end users.

Under the Hydrogen Society Promotion Act, Japan established a dedicated support scheme to subsidise domestic transport and storage infrastructure serving multiple users. A total budget of JPY 219.6 billion (USD 1.46 billion) has been earmarked for FY2026-FY2030  to  support  the  engineering  and  infrastructure  phases  of  hub development. The subsidy covers up to 50% of eligible engineering, procurement and  construction  costs  for  infrastructure  facilities,  including  shared  pipelines, storage tanks and front-end engineering and design costs. Such supported assets are  required  to  have  a  planned  operational  life  of  at  least  ten  years  and  begin operation no later than FY2030.

The application and selection process mirrors that of the CfD scheme. As of April 2026, METI and the Ministry of Land, Infrastructure, Transport and Tourism had selected two import  hub  projects  for  funding.  Both  are  anchored  in  demand  mainly  from  power generation. As a result, they are aligned with the major projects supported under the CfD scheme and the Long-Term Decarbonized Capacity Auction, notably the Hekinan and  Tomakomai  projects.  These  projects  are  expected  to  create  diverse  and  high environmental value markets for products such as automotive components, cement and chemicals for semiconductors.

Many of Japan's major industrial clusters are located along the coastline, close to ports, and the two supported hubs are no exception. For these projects, the main infrastructure requirements  relate  to  storage  capacity  and  port  adaptations.  Given  the  cost  and technical complexity of hydrogen transport, Japan is exploring multiple carrier options, including ammonia, liquefied hydrogen, liquid organic hydrogen carriers, methanol and synthetic fuels. Carrier choices reflect trade-offs between  transport efficiency, infrastructure  readiness,  end-use  compatibility  and  opportunities  for  domestic  value creation. As the two selected import hubs are ammonia-based, Japan can draw on its extensive experience with LNG to develop port and storage infrastructure. Delivering ports, hubs and storage assets at scale requires close co-ordination among the central government, local authorities, utilities and private investors.

## Innovation, supply chain and demonstration projects

Japan is the world leader in demonstrating and testing large-volume fuel ammonia substitution  at  a  large-scale  coal-fired  power  plant.  In  2024,  a  NEDO supported -project  at  JERA's  Hekinan  Power  Plant  successfully  achieved  20%  ammonia co firing. JERA plans to increase the share of co-firing ratios and develop burners -

for 100% ammonia combustion. In March 2026, IHI and GE Vernova demonstrated 100% ammonia firing in a commercial-scale gas turbine. Japan also has the world's first commercial ammonia-fuelled vessel, in use since 2024.

As part of its GX policies, Japan promotes a close integration between industry and energy policy. This is also reflected in the support of a hydrogen supply chain that builds  upon  domestic  elements  such  as  manufacturing.  For  example,  Japan provides funding for seven projects, with a total investment of nearly JPY 151 billion (USD 1 billion), to develop the domestic manufacturing of electrolysers and fuel cells.

NEDO supports a range of activities across the hydrogen value chain. In shipping, it funds the 'Next-Generation Ship Development' project, which aims to accelerate the  implementation  of  hydrogen-fuelled  ships.  In  aviation,  NEDO  supports  the development  of  hydrogen  aircraft.  In  parallel,  it  backs  R&amp;D  on  hydrogen  and ammonia carriers, bunkering and port infrastructure, and safety standards to enable large volume imports. -

Improved co-ordination across the value chain can help distribute the cost premium of  low-emissions  hydrogen  and  its  derivatives  across  multiple  actors,  where  it represents a smaller share of final product costs. A typical example is the use of low-emissions steel in passenger vehicles, where the cost premium is often less than 2% of the total vehicle price. Low-emissions hydrogen and its derivatives thus offer a promising decarbonisation option in applications where direct electrification or other low-carbon alternatives are not technically or economically viable.

Japanese  steelmakers  are  also  actively  exploring  the  use  of  importing  hot briquetted  iron,  a  material  that  can  be  used  in  blast  or  electric  arc  furnaces. Approaches range from using natural gas-based routes to the use of renewable energy, as well as hydrogen over time.

## Emissions accounting

Japan places strong emphasis on life cycle carbon intensity. The Hydrogen Society Promotion Act establishes a certification framework that defines eligibility thresholds  for  low-emissions  hydrogen  and  ammonia,  including  a  benchmark  of 3.4 kg CO -eq per kilogramme of hydrogen on a well-to-gate basis. Compliance ₂

with this threshold is required for projects seeking price gap support. This threshold is aligned with the European Hydrogen and Gas Market Package, which sets a 70% GHG reduction target compared to a fossil fuel reference.

Detailed  methodological  guidance  is  being  further  refined  to  support  consistent carbon  intensity  assessment.  Current  approaches  focus  primarily  on  production emissions,  with  further  work  underway  to  clarify  methodologies  for  calculating carbon intensity to be used in upcoming projects. Japan has signalled its intention to  align  methodologies  with  relevant  ISO  standards  and  emerging  international practices, and to strengthen verification arrangements as the market matures.

As  international  markets  for  low-emissions  hydrogen  and  ammonia  develop, certification  frameworks  and  methodologies  to  assess  life cycle  emissions  are gaining importance in many countries. Robust and transparent approaches can help ensure  environmental  integrity  and  build  confidence  among  market  participants. Over time, greater convergence or mutual recognition of such frameworks could facilitate international trade and reduce transaction costs, particularly for countries developing global supply chains. The COP28 declaration on the mutual recognition of certification schemes, to which Japan is a signatory, is a positive step in this direction.

## International co-operation

Japan  plays  a  prominent  role  in  international  low-emissions  hydrogen  market development, including through its leadership in the Hydrogen Energy Ministerial Meeting  (HEM).  The  HEM,  first  convened  in  Tokyo  in  2018,  brings  together countries and organisations to discuss hydrogen policies and emerging issues. In 2025, Japan held the seventh HEM in Osaka alongside the Expo 2025 and the Ministerial Meeting on Sustainable Fuels. The HEM emphasised the importance of demand  creation,  co-ordinated  policy  support,  infrastructure  development,  safety, regulatory alignment and innovation. Japan's role as chair and organiser reinforced its position as a key advocate for hydrogen and ammonia in global decarbonisation strategies. Japan also plays an important role in the Asia Clean Energy Forum, the International  Hydrogen  Trade  Forum,  the  Clean  Energy  Ministerial  and  Mission Innovation.

## Recommendation

<!-- image -->

Prioritise low-emissions hydrogen, ammonia and hydrogen-derived fuels in sectors with limited decarbonisation alternatives while leveraging early demand creation in the power sector to support supply chain scale up and cost reduction -

Japan has positioned low-emissions hydrogen, ammonia and hydrogen-derived fuels as core pillars of its GX Strategy, reflecting their potential role in decarbonisation and energy security. In the near term, the power sector plays a critical role in creating large-volume  initial  demand,  enabling  first-of-a-kind  projects,  and  supporting  the establishment of large-scale international supply chains and economies of scale. At the  same  time,  the  supply  of  low-emissions  hydrogen  or  hydrogen-based  fuels remains  limited  and  costly,  and  domestic  production  potential  is  constrained, underscoring  the  importance  of  carefully  sequencing  deployment  to  maximise long-term decarbonisation impact and cost-effectiveness.

Building on the 7th Strategic Energy Plan, Japan could further clarify the sequencing of hydrogen and ammonia use across sectors, recognising the power sector's role as an  early  demand  anchor  in  the  near  term  while  ensuring  that  expanding  supply increasingly and measurably supports hard-to-abate sectors with limited alternatives, such as steel, chemicals, refining, shipping and aviation. Clear sectoral roadmaps with time-bound milestones can help distinguish between near-term scale-up needs and longer term prioritisation, guide the allocation of public support, and reduce the risk of prolonged reliance on high-cost applications once alternative decarbonisation options  become  available.  Strengthening  demand-side  signals -  through  price-gap support, emissions-intensity requirements, mandates and carbon pricing - will remain essential: it provides offtake certainty and underpins investment across the value chain.

Co-ordinated development of demand hubs and shared infrastructure will continue to be critical to implementing this approach in practice. Co-location of power generation and industrial users can allow large-volume demand from the power sector to support early supply chain development while progressively serving hard-to-abate industrial applications as markets mature. Early experience under Japan's CfD scheme, where certified projects combine ammonia use in power generation with supply to industrial end users,  illustrates  how  such  hybrid  demand  models  can  accelerate  learning, reduce costs and strengthen supply chain resilience. By aligning sectoral prioritisation with sequencing, infrastructure planning and robust governance, Japan can leverage the power sector to build scale while ensuring hydrogen and ammonia deployment remains aligned with long-term decarbonisation efficiency and system value.

## Geothermal energy

Japan  has  one  of  the  world's  largest  geothermal  resources,  with  an  estimated technical potential of nearly 23.5 GW based on conventional hydrothermal systems at depths up to 3 km.

Next-generation  geothermal  technologies  could  significantly  expand  this  technical potential by enabling deeper drilling to depths of 7-8 km and accessing more and much higher temperature reservoirs. Conventional systems in Japan already reach 250-300 °C,  with  evidence  of  superhot  conditions  above  350 °C  in  volcanic  areas, particularly in the Hokkaido, Tohoku, Chubu and Kyushu regions. This geological profile positions Japan as a strong candidate for next-generation geothermal deployment, with reservoir  temperatures  confirmed  to  exceed  500 °C  in  specific  volcanic  contexts. Ongoing  research  to  map  and  quantify  these  deep  resources  suggests  additional technical potential exceeding 77 GW. Geothermal energy, therefore, offers a strategically important domestic source of low-carbon, dispatchable power.

## Installed electricity capacity (2000-2024) and technical potential for conventional and next-generation geothermal energy in Japan

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on IEA (2026), Electricity Information; Japan, Ministry of Economy, Trade and Industry (2025), Interim Report of the Public-Private Council for the Promotion of NextGeneration Geothermal Energy.

Despite its vast potential, long-standing history and roughly 30% growth over the past decade,  geothermal  installed  capacity  remains  limited  compared  to  other  energy sources. For power, total installed capacity is about 0.6 GW, accounting for just 0.3% of Japan's power generation. For heat, 2.4 GW is installed (2.2 GW direct heat use

and 0.2 GW geothermal heat pumps, which capture low-enthalpy heat). This means that existing  geothermal  generation  capacity  represents  only  2-3%  of  current technical resource potential, or less than 1% of expected potential when including next-generation technologies. Further expansion has been hindered by high earlystage development risks; long development timelines; economic aspects; regulatory challenges, particularly in national parks; and public acceptance.

## Governance and policies

Geothermal governance in Japan is split across national agencies in collaboration with local and regional governments. The Ministry of the Environment regulates hot springs and natural parks, ANRE sets energy policy and targets, JOGMEC supports exploration and drilling, with legacy input from NEDO surveys, and the Institute of Advanced Industrial Science and Technology supports R&amp;D. Local governments play a  pivotal  role  in  permitting,  co-ordinating  community  buy-in  and  securing onsen (a common word used in Japan for thermal baths) council consents. Most geothermal projects are initiated and owned by private actors (such as electric utilities, mining companies or local developers). A significant share of early stage risk is temporarily -and selectively absorbed or mitigated by public instruments (see the Policy spotlight).

Japan's geothermal policy has evolved in several phases. Development surged after the 1973 oil crisis, with nationwide surveys conducted by NEDO, which culminated in the  construction  of  seven  power  plants  in  the  1990s.  Momentum  declined  under nuclear and thermal dominance until the 2011 Fukushima disaster, which renewed interest in geothermal. The post-2011 period saw JOGMEC taking over geothermal responsibilities from NEDO, a partial easing of restrictions in national parks, and the introduction of FIT. Small-scale (1-5 MW) binary geothermal projects, often near hot springs, have increased, but large-scale development has remained limited.

Growth  has  been  limited  though  by  a  complex  regulatory  framework  designed  to balance  energy  development,  environmental  protection  and  local  interests.  Key instruments  include  the  Hot  Spring  Act  (1948,  latest  amendment  2022),  which protects onsen resources and requires local government and Hot Springs Council approval for drilling. Roughly 80% of Japan's geothermal resources lie within national parks, where the Natural Parks Act imposes strict limits on development, although partial relaxations since 2012 have allowed limited projects in less restrictive zones.

Large-scale projects are further regulated under the Electricity Business Act (2017) and the Environmental Impact Assessment Law (2014), which impose stringent safety requirements and lengthy assessment processes. Following the Rankoshi blowout

incident,  Japanese authorities revised safety guidelines under the Hot Spring Act. Additional  challenges  include  unclear  resource  ownership,  overlapping  jurisdiction across ministries and agencies that can create conflicts and inefficiencies, and local opposition from hot spring operators.

## Policy spotlight: Geothermal Development Acceleration Package

The Committee on Resources and Fuels, which is in charge of geothermal policy, adopted the Geothermal Development Acceleration Package in 2024. The Package sets  out  policy  measures  covering  permitting  reform,  resource  assessments  and early-stage risk reduction. As part of its implementation, the Ministry of Economy, Trade  and  Industry  (METI)  launched  a  public-private  council  on  next-generation geothermal technologies in 2025 to accelerate their commercialisation by the early 2030s. The Council identified various challenges and is now  working with stakeholders to address these challenges while also aligning innovation priorities with public  funding  under  the  Green  Innovation  Fund  and  the  Japan  Organization  for Metals  and  Energy  Security  (JOGMEC)  (see  more  details  in  the  Next-generation geothermal development section).

The objective to reduce early-stage exploration risks is being realised through the Geothermal Frontier Project (2024), supported by METI and JOGMEC. Through this Project,  JOGMEC  leads  pre competitive  surveys,  drilling  and  discharge  testing  to -reduce  early stage  geological  risk.  Depending  on  project  structure  and  developer -preference, JOGMEC may subsequently transfer derisked wells to private developers for project development. The first two sites have been selected in Yuzawa City and Shizukuishi Town. JOGMEC also provides a suite of financial instruments, including subsidies for exploration and drilling surveys, equity capital, and debt guarantees, spanning the project life cycle from geological exploration to plant construction.

To resolve permitting bottlenecks and reduce lengthy development times (previously often  exceeding  ten  years),  the  government  has  also  established  a  'one-stop follow-up' framework uniting METI and its agencies, the Ministry of the Environment, the Forestry Agency, and local governments.

Recent  policy  initiatives  have  sought  to  accelerate  development  (see  the  Policy spotlight). The Outlook for Energy Supply and Demand in FY2030, published alongside the 6th Strategic Energy Plan (2021), targeted 1.5 GW of geothermal capacity by 2030. More  recently,  the  Outlook  for  Energy  Supply  and  Demand  in  FY2040,  published alongside  the  7th  Strategic  Energy  Plan  (2025),  sets  a  more  ambitious  goal  of approximately 11-24 TWh of geothermal generation annually by 2040.

Social acceptance remains critical, especially in hot spring tourism areas and national parks. The  government  supports  communities  through  JOGMEC-led  hot-spring monitoring, reservoir evaluation and low-impact development methods, while METI and JOGMEC facilitate  dialogue  via  symposia  and  study  groups  with  residents  and  hot spring  operators.  The  Institute  of  Advanced  Industrial  Science  and  Technology  and NEDO are developing plant designs that harmonise with local landscapes, ensuring that geothermal development aligns with environmental and cultural considerations.

## Conventional geothermal development

## Power

Conventional  geothermal  power  in  Japan  is  technically  proven  but  structurally constrained, accounting for less than 1% of installed capacity and power generation. Development has favoured small to mid-scale flash and binary plants, often added to existing fields rather than built as large greenfield projects. Japan currently operates nearly 100 geothermal power plants, accounting for just above 540 MW, of which only 23 power plants exceed 1 MW. Hatchobaru Power Plant remains the largest operating facility at 112 MW.

Geothermal  provides  high-capacity  factors,  baseload  and  dispatchable,  weatherindependent generation, yet its contribution remains limited by long lead times, high upfront drilling costs and exploration risk, making conventional geothermal a niche, location-specific resource.

Market design reinforces this pattern. Since 2012, FIT has been its primary revenue mechanism, providing long-term price certainty.  METI's  FIT  for  2025  ranges  from USD 256  per megawatt hour (MWh) for plants under 15 MW to USD 166/MWh for larger  units.  In  practice,  this  has  enabled  mainly  small  binary  projects,  while large-scale development remains constrained by exploration risk, permitting complexity  and  social  acceptance.  Although  Japan's  liberalised  electricity  market allows  bilateral  and  corporate  power  purchase  agreements  (see  the  Electricity

chapter), geothermal has not leveraged these options, particularly due to high upfront risk  and  long  lead  times  that  limit  bankability.  This  limits  the  ability  of  geothermal energy to link to large loads such as data centres, despite growing policy support under zero-emission and resilience-enhanced data centres, which encourages the use of renewable energy. Regional and local initiatives in Tohoku and Niigata Regions aim  to  attract  data  centres  based  on  their  climate  and  renewable  availability,  but geothermal energy is not explicitly integrated despite its potential.

Geothermal has also been largely excluded from competitive auctions, as is the case for solar and wind, and from other market-based instruments. The 2023 Long-Term Decarbonized Capacity Auction, managed by OCCTO, while theoretically open to geothermal,  excludes  almost  all  projects  because  FIT  plants  are  ineligible  due  to double subsidy, and the 100 MW threshold only captures Hatchobaru. This leaves public  intervention,  particularly  via  JOGMEC,  as  the  main  mechanism  to  derisk exploration and bridge early-stage financing gaps (see the Governance, policies and regulatory framework section).

Conventional geothermal can grow incrementally but is unlikely to scale rapidly under the current market and regulatory conditions. This structural reality drives growing policy interest in next-generation geothermal,  which  aims  to  unlock  Japan's high-temperature resources at scale.

## Heat

Japan's  geothermal  direct  use  is  currently  concentrated  entirely  on  low-enthalpy resources (&lt;150 °C). Hot springs dominate, with around 1 500 onsen bathing sites, alongside  smaller  but  established  applications  in  aquaculture,  greenhouses  and snow-melting,  particularly  in  colder,  rural  regions.  These  rely  on  relatively  simple systems, typically involving direct pipelines or heat exchangers, and are often linked to local economies and tourism.

Geothermal district  heating and  cooling  remains  marginal  in  Japan,  where  district heating itself is limited, serving just 140 districts via around 80 heat operators and accounting for less than 1% of total energy use, mostly in vertical high-rise networks rather than broad community grids. Small-scale geothermal pilots, such as in Tokyo, demonstrate technical feasibility, but have not scaled due to limited policy support, fragmented heat demand, high retrofit costs for legacy systems and a lack of heat planning integration.

Despite  narrow  deployment,  significant  potential  exists  for  geothermal  in  public buildings, residential clusters, agri-food processing  and  rural district heating, particularly to displace imported fossil fuels while supporting regional development. Growing interest  from  regional  energy  companies  signals  momentum,  but  scaling requires a policy focus on heat and cooling (beyond power), local co-ordination due to the local nature of heat, and business models such as heat purchase agreements.

## Cascading use of geothermal energy for heat

Japan  demonstrates  cascading  use  of  geothermal  heat,  where  residual  heat (50-100 °C)  from  power  production  is  used  for  heating,  which  increases  overall energy efficiency, lowers fuel use and generates local economic value. Greenhouses and onsen are the most prominent examples: Yamagawa Geothermal supplies waste heat  to  nearby  greenhouses  for  flowers  and  vegetables;  Okuhida  Onsengo  uses waste  heat from several plants to support indoor heating, aquaculture and greenhouse cultivation, reducing electricity costs and diversifying rural incomes; and Beppu uses residual heat for district cooling. Other applications exist in Hokkaido and Iwate.

While currently limited in scale, these cases show the potential to integrate power and heat,  particularly  where  electricity  alone  underutilises  the  available  geothermal resource. Targeted policy support could expand co-generation deployment, strengthen  community  acceptance,  and  improve  project  bankability  for  small  and mid-scale plants close to agricultural and industrial demand.

## Next-generation geothermal development

Next-generation geothermal policy in Japan aims to overcome the geographical and scale constraints of conventional geothermal, which is largely confined to national parks and  small  to mid-scale  capacities. Technologies  such  as  supercritical geothermal, which target deeper  and  high-temperature reservoirs, potentially exceeding  500 °C,  enhanced  geothermal  systems  and  closed-loop  systems  could vastly  expand  the  geographical  scope  and  enable  larger  scale  projects  with  a potential of 77 GW.

Next-generation geothermal technologies are being developed under a risk-sharing framework that  aims  to  crowd  in  private  investment.  Recognising  the  very  high geological uncertainty, deep  drilling costs and  unproven  reservoir behaviour associated  with  supercritical, enhanced  and  closed-loop  geothermal  systems, Japan's approach relies on public instruments to mitigate early-stage risks and enable

learning. Through  targeted  subsidies  under  the  Green  Innovation  Fund,  the government absorbs or mitigates a significant share of initial exploration risk while private developers remain involved from the early stages and progressively assume greater technical and financial responsibility as resource viability is clarified.

This  approach  reflects  a  deliberate  sequencing  of  risk  allocation:  public  support focuses  on  reducing  uncertainty  in  early  phases  that  are  difficult  to  finance commercially while project ownership, construction and long-term operational risks are intended to shift to private developers once projects reach defined development milestones.  By  partially  socialising  early-stage  risks  and  linking  support  to  clear technical and regulatory benchmarks, Japan seeks to accelerate the emergence of a commercially  viable  next-generation  geothermal  project  pipeline  while  preserving incentives for cost discipline, innovation and private capital mobilisation.

As part of the implementation of the challenges identified by the public-private council on  next-generation  geothermal  technologies  (see  the  Governance  and  policies section), METI and industry consolidated a national roadmap in 2025. The roadmap targets  early  demonstrations  by  2030,  initial  operation  in  the  early  2030s  and substantial scale-up toward mid-century. It includes indicative deployment pathways, aiming to develop roughly 7.7 GW of next-generation geothermal capacity between mid-2030 and 2050, with an initial capacity of around 1.4 GW targeted before 2040 under various scenarios. The roadmap focuses on key technical and non-technical priorities, including drilling and well design, thermal recovery, cost reduction, resource surveys,  and  regulatory  frameworks,  including  safety  guidelines  and  institutional reforms under the Hot Springs Act. Early-stage demonstrations are supported by the Green Innovation Fund (under METI), with a new public tender to be launched in June 2026 to allocate USD 691 million in subsidies over 2026-2030, covering up to twothirds of eligible survey and test-drilling costs.

International  collaboration  with  partners  such  as  the  United  States  Department  of Energy  and  METI  (via  a  memorandum  of  co-operation)  and  private  start-ups accelerates technological learning. For example, Chubu Electric Power is a strategic investor  in Eavor  Technologies  to  gain  early  practical  experience  from  their closed-loop system's pilot in Germany and knowledge that could be applied in Japan.

In co-ordination with the public-private council on next-generation geothermal, Japan is advancing several pilot and demonstration projects: Mitsui Oil Exploration Co., Ltd and Chevron are piloting an advanced closed-loop system in Hokkaido that extracts heat  without  direct  steam  production  to  lower  exploration  risk.  JOGMEC  has commissioned feasibility studies with private companies such as Toyo Engineering to

assess closed-loop designs and other next-generation concepts, generating critical technical data ahead of field deployment. These pilot and preparatory activities lay the groundwork for scaling Japan's next-generation geothermal capacity.

To support commercialisation, METI will establish a Study Group on the Appropriate Utilisation of Next-Generation Geothermal Energy, integrating expertise on underground structures, social acceptance, environmental impacts, risk assessment and regulatory pathways.

## Recommendation

<!-- image -->

## Further strengthen early-stage geothermal risksharing to crowd in private investment while streamlining permitting

Geothermal development is constrained primarily by high geological uncertainty, long lead times and complex permitting requirements rather than operating costs. Japan has  made  important  progress  in  addressing  these  barriers  through  JOGMEC-led pre-competitive drilling surveys, subsidies for exploration and test drilling, and the use of  equity  participation  and  debt  guarantees  to  reduce  early-stage  risks.  These instruments  have  supported  private  developers'  engagement  from  the  exploration phase  and  helped  advance  conventional  and,  to  some  extent,  next-generation, geothermal  projects.  To  further  expand  geothermal  deployment,  Japan  should continue evolving from predominantly subsidy-based support toward clearer, milestone-linked  risk-sharing  arrangements  that  strengthen  incentives  for  early private participation and learning. This could include scaling cost-shared exploration and drilling programmes, expanding the use of equity and guarantee instruments in pre-FID  phases,  and  clarifying  pathways  for  the  transfer  of  derisked  resources  to project developers. Support levels should reflect geological and technological risk and be  linked  to  transparent  development  milestones  to  improve  bankability  and  the efficient use of public funds.

International  experience  shows  the  effectiveness  of  differentiated  approaches  to managing early-stage geothermal risk. In Kenya, Geothermal Development Company leads  exploration  and  resource  confirmation  with  the  explicit  aim  of  transferring derisked resources to private developers. In New Zealand, early-stage risks are more structurally shared, with private developers directly engaged in exploration supported by strong public data, faster learning and institutional frameworks. In the United States,  the  Department  of  Energy  complements  these  models  through

cost-shared funding explicitly targeting the 'valley of death' between research and commercial  deployment.  These  experiences  show  that  while  public  support  is essential to managing early-stage geothermal risk, cost- and risk-sharing approaches are  effective  in  mobilising  private  investment,  expanding  project  pipelines  and accelerating  development  beyond  what  can  typically  be  achieved  through  purely public funding models. Japan's model represents a hybrid approach, combining public risk  mitigation  with  private  project  leadership,  but  it  could  further  increase  private early-stage exposure through clearer, cost-shared investment frameworks.

At  the  same  time,  permitting  remains  a  critical  bottleneck.  Despite  improvements under  METI's  'one-stop  follow-up'  framework,  geothermal  projects  still  require sequential  approvals  under  multiple  laws,  resulting  in  lengthy  timelines.  Large projects (&gt;10 MW) often exceed ten years for permitting alone, even with JOGMEC support,  then  approximately  an  additional  decade  is  required  for  exploration  and resource confirmation. Smaller projects, despite partial exemptions from environmental  impact  assessments,  still  typically  require  four  to  six  years.  These timelines are incompatible with Japan's target of expanding geothermal capacity from 0.6 GW to 1.5 GW by 2030 and risk constraining conventional and next-generation projects. Japan should continue streamlining and co-ordinating permitting procedures,  with  differentiated  requirements  by  project  size  and  risk,  clearer  and potentially  shorter  timelines,  and  early  engagement  with  local  authorities  and hot-spring stakeholders.

Strengthening  risk-sharing  mechanisms  in  parallel  with  permitting  reform  would accelerate project pipelines; improve learning effects; and enable geothermal energy to play a greater role as a domestic, dispatchable, low-carbon energy source.

## Annexes

## Acknowledgements

The IEA review team visited Tokyo on 2-6 March 2026 and met with government officials and public and private sector stakeholders across the energy sector. This report is based on information from these meetings, the review team's assessment of Japan's energy policy and detailed research carried out by the IEA. The team leader was  Harry  Kamian  (United  States),  and  the  members  of  the  review  team  were Oshada Mendis (Canada); Steve Refshauge (Australia); Hanna Sundqvist (Sweden); Nicholas Sherman (Nuclear Energy Agency); and Fabian Burkard, Dennis Hesseling, Elena Merle-Beral and Brent Wanner from the IEA Secretariat. Keisuke Sadamori provided valuable guidance and insights throughout the process. This Energy Policy Review benefited from close co-operation with the IEA Energy Security Review team, including Ronan Graham and Masayuki Takahasi.

Elena Merle-Beral managed the review and is the main author of the report, with large contributions from Fabian Burkard on electricity and other sections. Yutaka Shirakawa drafted the Gas chapter, under Dennis Hesseling's guidance; Martina Lyons drafted the Geothermal chapter; Brent Wanner, supported by Ryota Taniguchi, contributed to the  analysis  and  findings  on  electricity  and  nuclear  energy;  and  Russell  Conklin contributed to the section on buildings. Fabian Burkard, supported by Šimon Olmer, George Vamos and Emma Mares, designed and prepared the energy data sections and figures for the report and contributed to the analysis and drafting. The report benefited from reviews and insights from the following IEA staff: Oskaras Alsauskas, Heymi  Bahar,  Simon  Bennett,  Herib  Blanco,  Lucas  Boehle,  Federico  Callioni, Michael Drtil,  Carlos  Fernandez  Alvarez,  Roland  Gladushenko,  Tomoya  Iwaki, Mayuko Morikawa, Apostolos Petropoulos, Maria Sicilia, Keishi Takada, Jun Takashiro, Taube  Van  Melkebeke,  Anthony  Vautrin, Ryo  Yamasaki  and

Remme Uwe. Isabelle Nonain-Semelin and Astrid Dumond managed the editing and production processes and Poeli Bojorquez managed the design process. Jennifer Allain  edited  the  report.  Nicolette  Groot  supported  the  organisation  of  the review team's visit.

The IEA would like to thank the Ministry of Economy, Trade and Industry for excellent co-operation during the review and for their thoughtful insights, constructive discussions and valuable support throughout the review process. The team extends particularly warm thanks to Shinichi Kihara, METI's Director-General for Energy and Environmental Policy, and to Kentaro Oe and his team, including Shinobu Miyake, Tetsuro Mizutani, Tasuku Nakanishi, Yasuto Sugita, Ulara Kida and all the others for their hospitality, patience and dedication in organising the visit. Sincere thanks also go to Motoko Ogawa from the Ministry of Foreign Affairs for her help in organising this review.

The IEA would also like to thank the numerous individuals from the following public and private organisations who provided valuable insights for the report: ANRE; the Clean  Fuel  Ammonia  Association;  ENEOS;  the  Energy  Resource  Aggregation Business  Association;  the  Federation  of  Electric  Power  Companies  of  Japan; Idemitsu; IHI Corporation; INPEX; the Institute of Energy Economics, Japan (IEEJ); the  Japan  Chemical  Industry  Association;  the  Japan  Gas  Association;  the  Japan Geothermal Association; the Japan Hydrogen Association; the Japan Iron and Steel Federation;  the  Japan  Photovoltaic  Energy  Association;  the  Japan  Science  and Technology Agency; the Japan Wind Power Association; the Japan Electric Power Exchange;  JERA  Co;  JOGMEC;  Kawasaki  Heavy  Industries;  Keidanren  (Japan Business  Federation);  the  Ministry  of  the  Environment;  the  Ministry  of  Land, Infrastructure, Transport and Tourism; Mitsubishi Corporation; the New Energy and Industrial Technology Development Organization; the Nuclear Regulation Authority; OCCTO; the Petroleum Association of Japan; the Renewable Energy Institute; the Renewable Association for Sustainable Power Supply; Sumitomo Corporation; Tokyo Gas Co; the Transmission and Distribution Grid Council; and the University of Tokyo. Warmest  thanks  to  Nobuo  Tanaka  and  Hisashi  Yoshikawa  for  organising  a stakeholder roundtable at Canon Institute for Global Studies. Helpful insights from Akira Yabumoto, Ilia Beloly and Rin Watanabe are also acknowledged with gratitude.

## Abbreviations and acronyms

| ANRE   | Agency for Natural Resources and Energy                                       |
|--------|-------------------------------------------------------------------------------|
| BEV    | battery electric vehicle                                                      |
| CCS    | carbon capture and storage                                                    |
| CEV    | Clean Energy Vehicle                                                          |
| CfD    | contract for difference                                                       |
| EGC    | Electricity and Gas Market Surveillance Commission                            |
| EV     | electric vehicle                                                              |
| FCEV   | fuel cell electric vehicle                                                    |
| FIP    | feed-in premium                                                               |
| FIT    | feed-in tariff                                                                |
| FY     | fiscal year                                                                   |
| GDP    | gross domestic product                                                        |
| GHG    | greenhouse gas                                                                |
| GIF    | Green Innovation Fund                                                         |
| GX     | Green Transformation                                                          |
| HEM    | Hydrogen Energy Ministerial Meeting                                           |
| HVAC   | heating, ventilation and air conditioning                                     |
| IEA    | International Energy Agency                                                   |
| JOGMEC | Japan Organization for Metals and Energy Security                             |
| JPY    | Japanese yen (currency)                                                       |
| LNG    | liquefied natural gas                                                         |
| METI   | Ministry of Economy, Trade and Industry                                       |
| MOE    | Ministry of the Environment                                                   |
| NEDO   | New Energy and Industrial Technology Development Organization                 |
| NRA    | Nuclear Regulation Authority                                                  |
| OCCTO  | Organization for Cross-regional Coordination of Transmission Operators        |
| PHEV   | plug-in hybrid electric vehicle                                               |
| PSC    | perovskite solar cell                                                         |
| PV     | photovoltaic                                                                  |
| R&D    | research and development                                                      |
| S+3E   | safety, energy security, economic efficiency and environmental sustainability |
| SBL    | Strategic Buffer LNG                                                          |
| SMR    | small modular reactor                                                         |
| STEM   | science, technology, engineering and mathematics                              |
| TES    | total energy supply                                                           |
| TFEC   | total final energy consumption                                                |
| USD    | United States dollar (currency)                                               |
| VRE    | variable renewable energy                                                     |
| ZEB    | zero-energy building                                                          |
| ZEH    | zero-energy home                                                              |

## Units of measurement

bcm

billion cubic metres

EJ

exajoule

GW

gigawatt

GWh

gigawatt hour

Hz

hertz

kb/d

thousand barrels per day

km

kilometre

kt

kilotonne

kW

kilowatt

kWh

kilowatt hour

Mt

million tonnes

Mt CO2-eq

million tonnes carbon dioxide equivalent

Mtpa

million tonnes per annum

MW

megawatt

MWh

megawatt hour

Nm 3

normal cubic metre

PJ

petajoule

t

tonne

t CO2

tonne carbon dioxide

TWh

terawatt hour

See the IEA glossary for a further explanation of many of the terms used in this report.

## Infographic notes

Electrification : 'Other IEA countries' refer to the consumption-weighted average of all IEA countries except Japan.

Nuclear : Capacity requirements for 2040 targets are determined by IEA modelling, taking into account Japan's 220 TWh generation target for nuclear in 2040.

Hydrogen :  'Key  legislation' refers to measures outlined in the 2025 Energy White Paper and Hydrogen Society Promotion Act.

## Infographic sources

S+3Es : IEA analysis based on Japan, Ministry of Economy, Trade and Energy (2025), Basic Energy Plans, (accessed in May 2026).

LNG : IEA (2026), World Energy Balances; IEA (2026), Natural Gas Information.

Electrification : IEA (2026), World Energy Balances.

Nuclear: IEA analysis based on International Atomic Energy Agency (2026), Power Reactor Information System, (accessed in May 2026); Japan, Ministry of Economy, Trade  and  Industry  (2025),  Outlook  for  Energy  Supply  and  Demand  in  FY2040, (accessed in May 2026).

Efficiency : IEA (2026), World Energy Balances.

Geothermal : IEA  analysis  based  on  IEA  (2026),  Electricity  Information;  Japan, Ministry of Economy, Trade and Industry (2025), Interim Report of the Public-Private Council for the Promotion of Next-Generation Geothermal Energy, (accessed in May 2026).

Hydrogen : IEA analysis based on Japan, Ministry of Economy, Trade and Industry (2025),  2025  Energy  White  Paper,  (accessed  in  June  2026);  Japan,  Ministry  of Economy, Trade and Industry (2024), Hydrogen Society Promotion Act, (accessed in June 2026).

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual M ember countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject to the IEA's Notice for CC-licenced Content, this work is licenced under a Creative Commons Attribution 4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA September 202 6 Cover design: IEA

<!-- image -->

## Japan 2026

## Energy Policy Review

Government action plays a pivotal role in ensuring secure and sustainable  energy  transitions.  Energy  policy  is  critical  not just for the energy sector but also for meeting environmental, economic  and  social  goals.  Governments  need  to  respond to  their  country's  specific  needs,  adapt  to  regional  contexts and  help  address  global  challenges. In this context, the International Energy  Agency  (IEA)  conducts  Energy  Policy Reviews to support governments in developing more impactful energy and climate policies.

This Energy Policy Review was prepared in partnership between the  Government  of  Japan  and  the  IEA.  It  draws  on  the  IEA's extensive knowledge and the inputs of expert peers from IEA Member  countries  to  assess  Japan's  most  pressing  energy sector  challenges  and  provide  recommendations  on  how  to address them, backed by international best practices. The report also highlights areas where Japan's leadership can serve as an example in promoting secure and clean energy transitions. It also promotes the exchange of best practices among countries to foster learning, build consensus and strengthen political will for a sustainable and affordable energy future.