---
document_id: irena_weto_2021
title: "World Energy Transitions Outlook 2021: 1.5°C Pathway"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IRENA"
year: 2021
original_file: "irena_world_energy_transitions_outlook_2021.pdf"
tables_detected: 227
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## WORLD ENERGY TRANSITIONS OUTLOOK

1.5° C PATHWAY

## WORLD ENERGY RANSITONS OUTLOOK WORLD ENERGY TRANSITIONS OUTLOOK

## © IRENA 2021

Unless  otherwise  stated,  material  in  this  publication  may  be  freely  used,  shared,  copied, reproduced, printed and/or stored, provided that appropriate acknowledgement is given of IRENA as the source and copyright holder. Material in this publication that is attributed to third parties may be subject to separate terms of use and restrictions, and appropriate permissions from these third parties may need to be secured before any use of such material.

ISBN: 978-92-9260-334-2

## CITATION

IRENA  (2021), World Energy Transitions  Outlook:  1.5°C  Pathway ,  International  Renewable  Energy Agency, Abu Dhabi.

Available for download: www.irena.org/publications

For further information or to provide feedback: info@irena.org

## ABOUT IRENA

The  International  Renewable  Energy  Agency  (IRENA)  serves  as  the  principal  platform for  international  co-operation,  a  centre  of  excellence,  a  repository  of  policy,  technology, resource  and  financial  knowledge,  and  a  driver  of  action  on  the  ground  to  advance  the transformation  of  the  global  energy  system.  A  global  intergovernmental  organisation established  in  2011,  IRENA  promotes  the  widespread  adoption  and  sustainable  use  of  all forms of renewable energy, including bioenergy, geothermal, hydropower, ocean, solar and wind energy, in the pursuit of sustainable development, energy access, energy security, and low-carbon economic growth and prosperity. www.irena.org

## DISCLAIMER

This publication and the material herein are provided 'as is'. All reasonable precautions have been taken by IRENA to verify the reliability of the material in this publication. However, neither IRENA nor any of its officials, agents, data or other third-party content providers provides a warranty of  any  kind,  either  expressed  or  implied,  and  they  accept  no  responsibility  or  liability  for  any consequence of use of the publication or material herein.

The  information  contained  herein  does  not  necessarily  represent  the  views  of  all  Members  of IRENA. The mention of specific companies or certain projects or products does not imply that they are endorsed or recommended by IRENA in preference to others of a similar nature that are not mentioned. The designations employed, and the presentation of material herein, do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

T

## WORLD ENERGY TRANSITIONS OUTLOOK

## ACKNOWLEDGEMENTS

This publication was prepared by IRENA's Renewable Energy Roadmap (REmap), Policy, Finance and Socio-economics teams. The 1.5°C Scenario including a technology pathway and investment needs, was developed by Dolf Gielen, Ricardo Gorini, Rodrigo Leme and Gayathri Prakash, with significant support and contributions from Nicholas Wagner, Luis Janeiro, Maisarah Abdul Kadir, Sean Collins and Elisa Asmelash. The finance, policy and socio-economic analyses were developed by Rabia Ferroukhi, Diala Hawila, Divyam Nagpal, Costanza Strinati, Ulrike Lehr, and Xavier Garcia Casals.  This  publication  benefited  from  insights  and  contributions  by  Elizabeth  Press  who  also developed the Executive Summary.

Valuable input, support and comments were provided by IRENA experts: Paul Durrant, Seungwoo Kang,  Karan  Kochhar,  Martina  Lyons,  Trish  Mkutchwa,  Carlos  Ruiz  (end-use  and  bioenergy), Emanuele Taibi, Herib Blanco , Raul Miranda, Carlos Fernandez (power system transformation and hydrogen), Francisco Boshell, Arina Anise, Elena Ocenic (innovation and technology standards), Roland Roesch, Gabriel Castellanos, Gayathri Nair, Barbara Jinks (grid integration, greening the gas and shipping), Asami Miketa, Pablo Carvajal (power sector investment planning), Michael Taylor (renewable energy cost status and outlook), Simon Benmarraze, Paula Nardone, Josefine Axelsson (Renewable  Energy  Markets  and  Technology),  Sandra  Lozo  and  Kingsmill  Bond  (renewable energy finance), Emanuele Bianco (hydrogen policy), Sara Pizzinato (power sector restructuring), Jinlei  Feng (end-use policy), Stephanie Weckend and Kelly Tai (community energy and circular economy), Sufyan Diab (targets and NDCs), Michael Renner, Celia García-Baños and Bishal Parajuli (labour markets and socio-economics), Samah Elsayed (education and skills), Anastasia Kefalidou, Kathleen Daniel, Claire Kiss and Waiman Tsang (planning and programme).

Modelling of the funding structure of the energy transition was developed with the support of the Boston Consulting Group (BCG). Macro-econometric modelling (E3ME) results benefited from the support of Cambridge Econometrics (CE).

IRENA appreciates the insights and comments provided by Michael Hackethal, Ann-Katrin Siekemeier and  Linus  Herzig  from  the  German  Federal  Ministry  of  Economics  and  Technology  (BMWi),  Ruud Kempener, European Commission Directorate General for Energy (ENER) and Deger Saygin (consultant).

Valuable  support  and  inputs  were  also  provided  by  Laura  Secada  Daly.  The  publication, communications and editorial support were provided by Stephanie Clarke, Daria Gazzola, Nicole Bockstaller, Manuela Stefanides and Abdullah Abou Ali. The report was copy-edited by Steven B. Kennedy. The graphic design was done by weeks.de Werbeagentur GmbH.

IRENA  is  grateful  for  the  generous  support  of  the  Federal  Ministry  for  Economic  Affairs  and Energy of Germany, which made the publication of this document a reality.

<!-- image -->

<!-- image -->

## FOREWORD

We have no time. The window is closing and the pathway to a net zero future is narrowing. This was the message I delivered plainly and unambiguously when we released the World Energy Transitions Outlook preview at the Berlin Energy Transitions Dialogue earlier this year. Science is clear: 45% of global greenhouse gas emissions from 2010 levels must be reduced by 2030. Unfortunately, the recent trends show that the gap between where we are and where we should be is widening. We are on the wrong path, and we need to change the course now.

The choices we make in the coming years will have a far-reaching impact. They could bring us on a path toward the goals we set out in 2015 when we adopted the highly consequential international agreements on sustainable development and climate change. Or they could take us in the opposite direction to further warming, with profound and irreversible economic and humanitarian consequences.

It  is  unwise to make predictions or pre-empt outcomes at uncertain times. But several trends are shaping an unfolding energy transition and giving an indication of its direction. First, the costs of renewable technologies have plummeted to the point that new fossil-based electricity is no longer an attractive option. Second, the progress in the power sector is spilling over to end uses, allowing a re-imagining of possibilities with the abundance of renewable options at hand. Third, a consensus has  formed  that  an  energy  transition  grounded  in  renewable  sources  of  energy  and  efficient technologies is the only way to give us a fighting chance of limiting global warming by 2050 to 1.5°C. Only a few years ago, the renewables-centred approach espoused by IRENA was considered too progressive, idealistic or even unrealistic. Today, our vision has become mainstream, and accepted as the only realistic option for a climate-safe world. And this is reflected in the growing number of commitments to net zero strategies by countries in all corners of the world, creating unprecedented political momentum for a transformative change.

IRENA's World Energy Transitions Outlook outlines the avenues to take us out of the climate crisis toward a resilient and more equitable world. It clearly shows the options we have today and what gaps need to be filled. The analysis and options presented prioritise existing emission-reduction solutions and those with the highest chance to become viable in the coming years. It does not bet on unproven technologies or pending inventions but encourages much-needed innovation to perfect and advance the fastest path to emission reduction.

The Outlook offers a compelling path for decarbonising all energy uses, with electrification and energy  efficiency  as  primary  drivers,  enabled  by  renewables,  green  hydrogen  and  sustainable modern bioenergy.  But  a  scenario  and  its  assumptions,  however  rigorous  and  comprehensive, are only an instrument to inform policy making. To translate this vision of the energy future into reality, we need to transcend the limits of the existing infrastructure created for the fuels of the past. And these decisions are not made in a vacuum. Economic and human development goals, environmental concerns, and financial avenues must all be reconciled.

<!-- image -->

It is in this context that IRENA brings its unique value.

The Outlook shows that, when we look beyond the narrow confines of energy supply, a renewablesbased  transition  unlocks  a  range  of  valuable  benefits.  The  Outlook  thus  presents  the  policy frameworks necessary to advance a transition that is just and inclusive. It provides an improved understanding of structural changes and offers a quantitative framework for impacts such as gross domestic product (GDP), employment and welfare. The report also examines funding structures to show the necessary shift in capital markets.

And this knowledge provides the basis for IRENA to support countries in realising their priorities and turning their strategies into action. With our 164 Members, we see how collective action can drive progress worldwide and where overarching needs and gaps may exist.

This global reach is what gives the Agency the credibility - and privilege - to support international co-operation across the gamut of energy transition issues to help countries learn from each other and tap into the vast expertise of the Agency. And we are actively working with partners, including the private sector, to provide a dynamic platform that drives action, foresighted planning, holistic policy making and investment at scale.

The demands of our time are great and full of uncertainty. We are entering a new era of change, one  in  which  energy  transformation  will  drive  economic  transformation.  This  change  is  bringing unprecedented new possibilities to revitalise economies and lift people out of poverty. But the task ahead is daunting. I hope that this Outlook provides a fresh view on how to turn today's energy problems into tomorrow's solutions.

Our shared future will only be bright if we move together, taking everyone along towards a more resilient, equal, and just world.

<!-- image -->

Francesco La Camera

Director-General, IRENA

<!-- image -->

<!-- image -->

## TABLE OF CONTENTS

## 01

| Acknowledgements                                                | . . 03   |
|-----------------------------------------------------------------|----------|
| Foreword . . . . . . . .                                        | . . 04   |
| Executive Summary                                               | . . . 16 |
| A Way Forward . . . .                                           | . 250    |
| References. . . . . . . .                                       | . 252    |
| ANNEX A                                                         |          |
| Sector-specific transition strategies . . . . . . . . . . . . . | . 260    |
| References Annex A.                                             | . 295    |
| ANNEX B                                                         |          |
| Socio-economic footprint of the transition . . . . . . . .      | . 297    |

| LEVERAGING THE COMPETITIVENESS OF RENEWABLES TO HASTEN THE ENERGY TRANSITION ANDMINIMISE   | LEVERAGING THE COMPETITIVENESS OF RENEWABLES TO HASTEN THE ENERGY TRANSITION ANDMINIMISE   | LEVERAGING THE COMPETITIVENESS OF RENEWABLES TO HASTEN THE ENERGY TRANSITION ANDMINIMISE   |
|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------|
| CLIMATE CHANGE . .                                                                         | CLIMATE CHANGE . .                                                                         | . 38                                                                                       |
| 1.1                                                                                        | Energy transition trends.                                                                  | . 40                                                                                       |
| 1.2                                                                                        | The evolving policy landscape                                                              | . 47                                                                                       |
| 1.3                                                                                        | Renewable energy investments                                                               | . 48                                                                                       |
| 1.4                                                                                        | Jobs. . . . . .                                                                            | . 54                                                                                       |
| 1.5                                                                                        | Outlook for achieving the 1.5°C goal . . . . . . . .                                       | . 57                                                                                       |
| 1.6                                                                                        | Conclusion                                                                                 | . 61                                                                                       |

## 02

|   TECHNOLOGICAL AVENUES TO CLIMATE TARGETS . . . . . . | TECHNOLOGICAL AVENUES TO CLIMATE TARGETS . . . . . .      | . 64   |
|--------------------------------------------------------|-----------------------------------------------------------|--------|
|                                                    2.1 | Contextualising the 1.5°C climate pathway. .              | . 66   |
|                                                    2.2 | Achieving climate targets under the 1.5°C Scenario .      | . 72   |
|                                                    2.3 | Comparison of energy scenarios. . . . . . . . . . . . . . | . 91   |
|                                                    2.4 | Conclusion . . . .                                        | . 94   |

## 03

| INVESTMENT NEEDS ANDFINANCING   | INVESTMENT NEEDS ANDFINANCING                                                             | INVESTMENT NEEDS ANDFINANCING   |
|---------------------------------|-------------------------------------------------------------------------------------------|---------------------------------|
| FOR THE ENERGY TRANSITION .     | FOR THE ENERGY TRANSITION .                                                               | . . 96                          |
| 3.1                             | New investment priorities in the 1.5°C Scenario . . . . . . . . .                         | . . 99                          |
| 3.2                             | Funding structures for a climate safe 1.5°C future. .                                     | . 106                           |
| 3.3                             | The impact of the energy transition on financing risks and capital pools. . . . . . . . . | . 122                           |
| 3.4                             | Conclusion                                                                                | . 127                           |

## 04

|   COMPREHENSIVE POLICY FRAMEWORKFORTHEENERGY TRANSITION . . . . . . . . . . . . . . . . . . | COMPREHENSIVE POLICY FRAMEWORKFORTHEENERGY TRANSITION . . . . . . . . . . . . . . . . . .    |   128 |
|---------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|-------|
|                                                                                         4.1 | Cross-cutting policies enabling the energy transition . . . . . . . .                        |   133 |
|                                                                                         4.2 | Policies to support the technological avenues of the energy transition . . . . . . . . . . . |   149 |
|                                                                                         4.3 | Policies for structural change and a just transition . . . . . . . .                         |   180 |
|                                                                                         4.4 | Holistic global policy framework. . . . . . . . .                                            |   194 |
|                                                                                         4.5 | Conclusion . .                                                                               |   197 |

## 05

|   SOCIO-ECONOMICIMPACTSOFTHE ENERGYTRANSITION . . . . . . . . . | SOCIO-ECONOMICIMPACTSOFTHE ENERGYTRANSITION . . . . . . . . .    | . . . 198   |
|-----------------------------------------------------------------|------------------------------------------------------------------|-------------|
|                                                             5.1 | The climate policy basket.                                       | . . . 201   |
|                                                             5.2 | Socio-economic footprint results . . . . . . . . . . . . . . . . | . . . 207   |
|                                                             5.3 | Conclusion . . . .                                               | . . . 248   |

<!-- image -->

## LIST OF FIGURES

| FIGURE S.1   | Share of new electricity capacity, 2001-2020 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                              | . 18   |
|--------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|
| FIGURE S.2   | Global renewable energy employment, by technology, 2012-2019 . . . . . . . . . . . . . .                                                                                                                                  | . 19   |
| FIGURE S.3   | The WETO theory of change . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                     | . 22   |
| FIGURE S.4   | Carbon emissions abatements under the 1.5°C Scenario (%) . . . . . . . . . . . . . . . . . . .                                                                                                                            | . 23   |
| FIGURE S.5   | Evolution of emissions with phaseouts of coal and oil, 2021-2050 . . . . . . . . . . . . . .                                                                                                                              | . 25   |
| FIGURE S.6   | Total average yearly investment by source and type of financing as of 2019, PES and 1.5°C Scenario (2021-2030 and 2031-2050). . . . . . . . . . . . . . . . . . . . . . . . . .                                           | . 29   |
| FIGURE S.7   | Cumulative difference between costs and savings of 1.5°C Scenario compared to the PES, 2021-2050. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                   | . 30   |
| FIGURE S.8   | Energy sector jobs by technology under the PES and 1.5°C Scenario (million), global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . 32   |
| FIGURE S.9   | Energy sector jobs, by segment of value chain, in the 1.5°C Scenario and PES (excluding vehicles) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .             | . 32   |
| FIGURE S.10  | Jobs in renewable energy, by technology, in the 1.5°C Scenario and PES (million) . .                                                                                                                                      | . 33   |
| FIGURE S.11  | Structure of jobs in the 1.5°C Scenario by 2050 for a subset of renewable technologies by technology, segment of value chain and occupational requirements. . . . . . . . . . . .                                         | 33     |
| FIGURE S.12  | Structure of IRENA's Energy Transition Welfare Index. . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                                     | . 34   |
| FIGURE S.13  | Enabling policy framework for a just and inclusive energy transition . . . . . . . . . . . .                                                                                                                              | . 37   |
| FIGURE 1.1   | Global LCOE of newly commissioned utility-scale renewable power generation technologies, 2010 and 2020 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                        | . 41   |
| FIGURE 1.2   | Share of new electricity capacity, 2001-2020 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                            | . 42   |
| FIGURE 1.3   | New energy vs. old energy: S&P Global Clean Energy and Energy Indices, 24 May 2016 to 24 May 2021. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                            | . 44   |
| FIGURE 1.4   | Global investment in energy transition technologies, 2005-2020. . . . . . . . . . . . . . .                                                                                                                               | . 46   |
| FIGURE 1.5   | Global annual renewable energy investments by technology, 2005-2019 . . . . . . . .                                                                                                                                       | . 49   |
| FIGURE 1.6   | Global annual renewable energy investments by location, 2005-2019. . . . . . . . . . .                                                                                                                                    | . 50   |
| FIGURE 1.7   | Annual commitments to off-grid renewable energy by region, 2008-2019. . . . . . .                                                                                                                                         | . 51   |
| FIGURE 1.8   | Public annual renewable energy investments in emerging and developing countries by technology, 2005-2019. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                   | . 53   |
| FIGURE 1.9   | Global renewable energy employment by technology, 2012-2019. . . . . . . . . . . . . . .                                                                                                                                  | . 55   |
| FIGURE 1.10  | Projected trends in global CO 2 emissions under three scenarios, 2020-2050. . . . .                                                                                                                                       | . 58   |
| FIGURE 1.11  | Primary supply of fossil fuels (exajoules), 2018 to 2050, under the 1.5°C Scenario . . .                                                                                                                                  | . 60   |

| FIGURE 2.1   | Carbon emissions abatements under the 1.5°C Scenario (%) . . . . . . . . . . . . .                                                                                                              | . 66   |
|--------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|
| FIGURE 2.2   | Renewable and non-renewable share of total primary energy supply in 2018 and 2050, PES and the 1.5°C Scenario (EJ/year). . . . . . . . . . . . . . . . . . .                                    | . 67   |
| FIGURE 2.3   | Energy intensity improvement rate and contributions, by category, historical and under the 1.5°C Scenario, 2018-2050 . . . . . . . . . . . . . . . . . . . .                                    | . 70   |
| FIGURE 2.4   | Breakdown of total final energy consumption (TFEC) by energy carrier in 2018 and 2050 (EJ) in the 1.5°C Scenario . . . . . . . . . . . . . . . . . . . . . . . . . . .                          | . 71   |
| FIGURE 2.5   | Electricity generation and capacity by source, 2018 and 2050 (TWh/yr and GW) in the 1.5°C Scenario . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                | . 73   |
| FIGURE 2.6   | Emerging innovations that support the integration of VRE . . . . . . . . . . . . . .                                                                                                            | . 75   |
| FIGURE 2.7   | TFEC split by direct electricity and the use of green hydrogen and its derivative fuels, 2018 and 2050, in PES and the 1.5°C Scenario (EJ/yr) . . . .                                           | . 79   |
| FIGURE 2.8   | Electricity consumption by sector, 2018, 2030 and 2050 (TWh/yr) in the 1.5°C Scenario . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . 80   |
| FIGURE 2.9   | Hydrogen production costs resulting from low and high electricity cost assumptions . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .        | . 81   |
| FIGURE 2.10  | CO 2 emissions abatement options in the 1.5°C Scenario compared to PES in the industry, transport and building sectors . . . . . . . . . . . . . . . . . . . . . .                              | . 84   |
| FIGURE 2.11  | Primary bioenergy demand in 2018 and 1.5°C Scenario 2050 (EJ/yr) . . . . .                                                                                                                      | . 86   |
| FIGURE 2.12  | Amount of CO 2 (GtCO 2 ) yet to be removed in the 1.5°C Scenario . . . . . . . . .                                                                                                              | . 89   |
| FIGURE 2.13  | Shares of renewables in total primary energy in 2018 and 2050 in various energy scenarios. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .  | . 92   |
| FIGURE 2.14  | CO 2 emissions versus electrification rates in various energy scenarios. . . . .                                                                                                                | . 93   |
| FIGURE 3.1   | Total investment by technology: PES and 1.5°C Scenario (2021-2050). . . . .                                                                                                                     | 100    |
| FIGURE 3.2   | Annual average investments in power and end uses, historical (2017-2019) and needed to meet 1.5°C Scenario (USD billion/year) . . . . . . . . . . . . . . . . . .                               | 102    |
| FIGURE 3.3   | Energy transition technologies and their development stage . . . . . . . . . . . .                                                                                                              | . 111  |
| FIGURE 3.4   | Total average yearly investment by source and type of financing as of 2019, PES and 1.5°C Scenario (2021-2030 and 2031-2050). . . . . . . . . . . . . . . . . . . .                             | . 113  |
| FIGURE 3.5   | Number of renewable energy project transactions involving institutional investors by technology, 2009 - Q2 2019. . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                      | . 114  |
| FIGURE 3.6   | Annual global green bond issuance by region, 2014-2019 . . . . . . . . . . . . . . .                                                                                                            | . 121  |

## WORLD ENERGY

## TRANSITIONS OUTLOOK

| FIGURE 4.1   | Enabling policy framework for a just and inclusive energy transition . . . . .                                                                                                                     | 130   |
|--------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------|
| FIGURE 4.2   | Renewable energy components of NDCs, as of the first quarter of 2021 . .                                                                                                                           | 136   |
| FIGURE 4.3   | Global installed capacity of renewable power: historical trends and future projections based on targets . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .              | 137   |
| FIGURE 4.4   | Solutions and enabling infrastructure for the energy transition in heating and cooling . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | 138   |
| FIGURE 4.5   | Phase-out of coal in Germany by 2038. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                  | . 141 |
| FIGURE 4.6   | Share of households unable to keep home adequately warm, by income level, in selected countries, 2019 (%). . . . . . . . . . . . . . . . . . . . . . .                                             | 145   |
| FIGURE 4.7   | Roles of municipal governments in the energy transition . . . . . . . . . . . . . . .                                                                                                              | 153   |
| FIGURE 4.8   | Auction design for objectives beyond price discovery . . . . . . . . . . . . . . . . .                                                                                                             | 156   |
| FIGURE 4.9   | Unequal advance in different transition layers, with organisational structures lagging behind . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                  | 160   |
| FIGURE 4.10  | Misalignments in marginal pricing allocation mechanisms: Missing money and cannibalisation effects . . . . . . . . . . . . . . . . . . . . . . . . . . .                                           | 163   |
| FIGURE 4.11  | Global energy use for space cooling covered by MEPS in selected jurisdictions, 2018 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .              | 167   |
| FIGURE 4.12  | Cities with bus rapid transit systems, per year and cumulative, 1968-2020.                                                                                                                         | 169   |
| FIGURE 4.13  | Green hydrogen value chain. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                          | 173   |
| FIGURE 4.14  | Government hydrogen-related initiatives announced between June 2018 and February 2021. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                 | 175   |
| FIGURE 4.15  | Guarantees of origin and life-cycle emissions . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                    | 177   |
| FIGURE 4.16  | Distribution of material and human resource requirements for the development of a 50 MWwind farm. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                  | 185   |
| FIGURE 4.17  | Human resource requirements in the solar PV and wind industries . . . . . .                                                                                                                        | 188   |
| FIGURE 4.18  | Human resource requirements for the manufacturing and installation of solar water heaters. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           | 189   |
| FIGURE 4.19  | Overview of EU PV recycling operations, by year and by country, 2019. . .                                                                                                                          | 192   |

| FIGURE 5.1   | Cumulative difference between costs and savings of 1.5°C Scenario compared to the PES, 2021-2050. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                       | .209        |
|--------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------|
| FIGURE 5.2   | GDP difference between the 1.5°C Scenario and PES, with GDP drivers. . . . . . . . .                                                                                                                                                                                                                        | . 212       |
| FIGURE 5.3   | Differences in economic output between 1.5°C Scenario and PES, by sector . . . .                                                                                                                                                                                                                            | . 215       |
| FIGURE 5.4   | Effects of climate damages on global GDP under the 1.5°C Scenario and PES, for each scenario (left) and for the difference between both scenarios (right) . .                                                                                                                                               | . 217       |
| FIGURE 5.5   | Employment difference between the 1.5°C Scenario and PES, by driver . . . . . . . .                                                                                                                                                                                                                         | . 220       |
| FIGURE 5.6   | Employment difference by sector between the baseline and 1.5°C Scenario (thousands of jobs) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                       | . 221       |
| FIGURE 5.7   | Energy sector jobs by technology (left) and segment of value chain (right) under the PES and 1.5°C Scenario, global results (millions of jobs) . . . . . . . . . . . . . . . . . .                                                                                                                          | . 223       |
| FIGURE 5.8   | Evolution of energy sector jobs by technology under the PES and 1.5°C Scenario, including vehicles and associated recharging infrastructure . . . . . . . . . . . . . . . . . .                                                                                                                             | . 225       |
| FIGURE 5.9   | Jobs in renewable energy, by technology, in the 1.5°C Scenario and PES (million). . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                             | . 228       |
| FIGURE 5.10  | Renewable energy jobs, by segment of value chain, in the 1.5°C Scenario and PES. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                              | . 229       |
| FIGURE 5.11  | Evolution of the distribution of jobs in the energy sector, by education level, in the PES and 1.5°C Scenario . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                                                         | . 231       |
| FIGURE 5.12  | Structure of jobs in the 1.5°C Scenario by 2050 for a subset of renewable technologies, by technology, segment of value chain and occupational requirements. . . . . . . . . .                                                                                                                              | . 233       |
| FIGURE 5.13  | Structure of IRENA's Energy Transition Welfare Index. . . . . . . . . . . . . . . . . . . . . . . .                                                                                                                                                                                                         | . 234       |
| FIGURE 5.14  | Overall welfare (centre) and dimensional (blades) indices for the PES and 1.5°C Scenario by 2050, global results, multi-dimensional representation. . . . . . .                                                                                                                                             | . 235       |
| FIGURE 5.15  | Overall Energy Transition Welfare Index and dimensional contributions of the PES and 1.5°C Scenario by 2050, global results, unidimensional representation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                          | . 236       |
| FIGURE 5.16  | Relative improvement of the Energy Transition Welfare Index and its dimensional contributions by 2050, global results . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                                                       | . 237       |
| FIGURE 5.17  | Economic index under the 1.5°C Scenario and PES by 2050, by indicator, global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                                         | . 238       |
| FIGURE 5.18  | Social index under the 1.5°C Scenario and PES by 2050, by indicator, global results. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                                        | . 240       |
| FIGURE 5.19  | Environmental index under the 1.5°C Scenario and PES by 2050, .                                                                                                                                                                                                                                             |             |
| FIGURE 5.20  | by indicator, global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . Distributional index under the 1.5°C Scenario and PES Average                                                                                                                      | . 241       |
| FIGURE 5.21  | 2021-2050, by indicator, global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . Contributions to two access index indicators under the 1.5°C Scenario and PES by 2050, global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . 242 . 246 |
| FIGURE 5.22  | Ecosystem needs for supporting livelihoods with distributed renewable energy solutions . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                                          | . 247       |

<!-- image -->

## LIST OF TABLES

| TABLE S.1   | Overview of cross-cutting policies to enable the energy transition . . . . . . . . . .                                                                                            | . . 27   |
|-------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|
| TABLE S.2   | Overview of policies to support energy transition solutions. . . . . . . . . . . . . . . . .                                                                                      | . . 36   |
| TABLE 3.1   | Key investment risks and financial risk-mitigation tools to address them . . . . .                                                                                                | . 109    |
| TABLE 3.2   | TCFD recommendations regarding 'decision-useful' climate-related disclosure.                                                                                                      | . . 119  |
| TABLE 4.1   | Overview of cross-cutting policies to enable the energy transition . . . . . . . . . .                                                                                            | . 134    |
| TABLE 4.2   | Jurisdictions with net zero targets as of the first quarter of 2021 . . . . . . . . . . . .                                                                                       | . 135    |
| TABLE 4.3   | Results of auctions for coal plant phase-out in Germany . . . . . . . . . . . . . . . . . . .                                                                                     | . 142    |
| TABLE 4.4   | Overview of policies to support energy transition solutions. . . . . . . . . . . . . . . . .                                                                                      | . 150    |
| TABLE 4.5   | A dual approach to the procurement of electricity . . . . . . . . . . . . . . . . . . . . . . . .                                                                                 | . 165    |
| TABLE 4.6   | Overview of structural change and just transition policies . . . . . . . . . . . . . . . . . .                                                                                    | . . 181  |
| TABLE 5.1   | Elements included in the modelling of government fiscal balances (% of global cumulative fiscal balances 2021-2050) . . . . . . . . . . . . . . . . . . . . . . .                 | . 203    |
| TABLE 5.2   | Key economic and demographic trends of the PES ( compound annual growth rates). . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                 | . 210    |
| TABLE 5.3   | Global improvement in jobs in the 1.5°C Scenario over the PES, in relative and absolute terms . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . 219    |
| TABLE 5.4   | Global renewable energy jobs in the 1.5°C Scenario and differences with the PES . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .     | . 227    |

## LIST OF BOXES

| BOX 2.1   | Scenario comparison . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                | . . 92   |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|
| BOX 3.1   | De-risking investments in the energy transition . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                  | . 108    |
| BOX 3.2   | Funding sources at each stage of a technology revolution. . . . . . . . . . . . . . . .                                                                                                            | . .110   |
| BOX 3.3   | Institutional investors and the energy transition. . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                 | . . 114  |
| BOX 3.4   | Green taxonomy and climate-related risk disclosure . . . . . . . . . . . . . . . . . . . . .                                                                                                       | . . 118  |
| BOX 3.5   | Green bonds . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                          | . 120    |
| BOX 4.1   | Integrating innovation in buildings with district energy networks in the European Union. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .           | . 139    |
| BOX 4.2   | Germany's tender for coal being phased out by 2038 as part of its green recovery plan. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . . 141  |
| BOX 4.3   | Addressing energy poverty. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                     | . 144    |
| BOX 4.4   | The role of cities in the energy transition in end uses . . . . . . . . . . . . . . . . . . . .                                                                                                    | . 153    |
| BOX 4.5   | Auction design to support policy objectives beyond price. . . . . . . . . . . . . . . .                                                                                                            | . 156    |
| BOX 4.6   | Policies for off-grid renewable energy solutions. . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                  | . 157    |
| BOX 4.7   | Definitions of power system organisational structure and misalignments. . .                                                                                                                        | . . 161  |
| BOX 4.8   | Policies supporting the supply of green hydrogen. . . . . . . . . . . . . . . . . . . . . . .                                                                                                      | . 178    |
| BOX 4.9   | Policies and measures for the sustainable use of bioenergy. . . . . . . . . . . . . . .                                                                                                            | . 179    |
| BOX 4.10  | Fostering women's employment at the Ethiopian Electric Utility . . . . . . . . . .                                                                                                                 | . 190    |
| BOX 4.11  | Energy access skills . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                             | . . 191  |
| BOX 4.12  | European Waste Electrical and Electronic Equipment Directive (WEEE) for end-of-life management of PV. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                | . 192    |
| BOX 5.1   | Socio-economic footprint of the 1.5°C Scenario, 2030 and 2050: A snapshot                                                                                                                          | .200     |
| BOX 5.2   | Carbon pricing in IRENA's modelling exercise. . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                  | .204     |
| BOX 5.3   | Transition cost-benefit analyses. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                      | . 208    |
| BOX 5.4   | The energy transition's implications for jobs in road transport . . . . . . . . . . . .                                                                                                            | . 224    |
| BOX 5.5   | The hydrogen supply chain. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                     | . 226    |
| BOX 5.6   | Evolution of education levels necessary to support the energy transition. . .                                                                                                                      | . 230    |
| BOX 5.7   | Linking energy supply with livelihood services. . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                  | . 247    |

<!-- image -->

## TABLE OF CONTENTS | ANNEX

| ANNEX A    | Sector-specific transition strategies . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                   | .260   |
|------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|
| REFERENCES | Annex A . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                 | . 295  |
| ANNEX B    | Socio-economic footprint of the transition . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                          | . 297  |
| FIGURE A.1 | Total energy consumption and CO 2 emissions in transport. . . . . . . . . . . .                                                                                                       | . 267  |
| FIGURE A.2 | Emission reductions in transport in 2050. . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                         | . 273  |
| FIGURE A.3 | Total energy consumption and CO 2 emissions in industry. . . . . . . . . . . . . .                                                                                                    | . 276  |
| FIGURE A.4 | Emission reductions in industry in 2050. . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                        | . 284  |
| FIGURE A.5 | Total final energy consumption and CO 2 emissions in buildings . . . . . . .                                                                                                          | . 286  |
| FIGURE A.6 | Emission reductions in buildings in 2050. . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                         | . 294  |
| FIGURE B.1 | Potential transition implications of sub-optimal carbon pricing . . . . . . .                                                                                                         | . 297  |
| TABLE A.1  | Energy Sector: Indicators of progress - status in 2018 and targets for 2030 and 2050. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . 262  |
| TABLE A.2a | Transport: Indicators of progress - status in 2018 and targets for 2030 and 2050. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .     | . 268  |
| TABLE A.2b | Transport: Energy transition investments. . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                         | . 269  |
| TABLE A.3a | Industry: Indicators of progress - status in 2018 and targets for 2030 and 2050. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .      | . 278  |
| TABLE A.3b | Industry: Energy transition investments . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                       | . 280  |
| TABLE A.4a | Buildings: Indicators of progress - status in 2018 and targets for 2030 and 2050. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .     | . 288  |
| TABLE A.4b | Buildings: Energy transition investments . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                        | .290   |
| TABLE B.1  | Goalposts for the indicators in IRENA's Energy Transition Welfare Index.                                                                                                              | . 302  |

## TABLE OF CONTENTS | ANNEX

| DATA TABLES | TABLE B.2 Energy global   | EMPLOYMENT sector jobs for the 1.5°C Scenario and differences with PES over time, results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .   | .304    |
|-----------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|
| TABLE B.3                               | Renewable energy jobs by technology in the 1.5°C Scenario and differences with the PES, global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                  | . 305   |
| TABLE B.4                               | Renewable energy jobs by segment of value chain in the 1.5°C Scenario and differences with the PES, global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                | .306    |
| TABLE B.5                               | Energy sector jobs by educational requirement in the 1.5°C Scenario and differences with the PES, global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                  | .306    |
| DATA TABLES | WELFARE                   | DATA TABLES | WELFARE                                                                                                                                                                                       |         |
| TABLE B.6                               | Welfare and dimensional indexes for 1.5-S and PES, as well as the relative difference between both, for 2030 and 2050, global results . . . . . . . . . . . . . .                                           | . 307   |
| TABLE B.7                               | Economic index and its indicator's indexes for 1.5°C Scenario and PES, for 2030 and 2050, global results. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                           | . 308   |
| TABLE B.8                               | Social index and its indicators' indexes for 1.5°C Scenario and PES, for 2030 and 2050, global results. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                             | .309    |
| TABLE B.9                               | Environmental index and its indicators' indexes for 1.5°C Scenario and PES, for 2030 and 2050, global results . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                   | . 310   |
| TABLE B.10                              | Distributional index and its indicators' indexes for 1.5°C Scenario and PES, average 2021-2050, global results. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                   | . . 311 |
| TABLE B.11                              | Access index indicator's contributions for 1.5S and PES by 2050, global results                                                                                                                             | . . 311 |
| BOX A.1                                 | Status of battery technology . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                            | . 272   |

## EXECUTIVE SUMMARY

<!-- image -->

## Where are we in the energy transition?

The energy sector, known for its slow pace of change, is undergoing a dynamic transition. The imperatives of climate change, energy poverty and energy security to underpin development and industrial strategy have made the widespread adoption of renewables and related technologies an essential solution. Policy drivers, technology developments and international co-operation have moved these technologies from niche to mainstream, especially in the past decade. Even in the face of the turmoil caused by the COVID-19 pandemic, renewables-based systems demonstrated remarkable resilience, showing technical reliability of renewables-based electricity system with high share of solar and wind.

A  consensus  has  formed  that  an  energy  transition  grounded  in  renewable  sources  and technologies that increases efficiency and conservation is the only way to give us a fighting chance of limiting global warming to 1.5°C by 2050. Only  a  few  years  ago,  the  renewablescentred approach espoused by IRENA was considered idealistic. Today, even some of the most conservative energy players have realised it as the only realistic option for a climate-safe world. Such a profound and pervasive shift of views is rooted in undeniable evidence, not only of the world's  grave  problems,  but  also  of  trends  in  technology,  policy  and  markets  that  have  been reshaping the energy sector for over a decade.

For the past seven years, more renewable power was added to the grid annually than fossil fuels and nuclear combined. Renewable power technologies now dominate the global market for new electricity generation capacity, as they have become the cheapest sources of electricity in many  markets.  A  record  level  of  260  gigawatts  (GW)  of  renewables-based  generation capacity was added globally in 2020, more than four times the capacity added from other sources (IRENA, 2021a). This a promising trajectory for rapid decarbonisation of the power sector.

## WORLD ENERGY

## FIGURE S.1     Share of capacity, 2001-2020

<!-- image -->

Based on IRENA's renewable energy statistics.

Innovative  solutions  are  reshaping  the  energy  system  and  opening  new  possibilities  for  a decarbonised future much faster than expected. Innovations in technology, policy and markets are being implemented worldwide (IRENA, 2019a). Significant progress has been made in electric mobility, battery  storage,  digital  technologies  and  artificial  intelligence,  among  others.  These  shifts  are  also drawing greater attention to the need for sustainable exploitation and management of rare earths and other minerals, and investment in the circular economy. New and smart grids, ranging from minito super grids, bolstered by facilitative policies and markets, are enhancing the power sector's ability to  cope  with  the  variability  of  renewables.  Direct  uses  of  renewables  -  including  bioenergy  -  and green hydrogen are bringing much-needed solutions in transport, buildings and industry.

Of the 58 million energy jobs worldwide in 2019, some 20% were in the renewable sector. The change in global employment patterns reflects new trends in energy deployment. Employment grew from 7.3 million in 2012, when IRENA began monitoring jobs in renewables, to 11.5 million in 2019. During the same period, energy jobs were decreasing owing to growing automation, lack of competitiveness of some fuels and changing market dynamics. There is also growing evidence of the wider impacts of the shift toward renewables. Notably, the rise of renewables has improved the gender balance in the energy sector, with women accounting for 32% of jobs in renewables, compared with 22% in the oil and gas.

FIGURE S.2     Global renewable energy employment by technology, 2012-2019

<!-- image -->

<!-- image -->

The growing number of countries committing to net zero carbon strategies indicates a major shift  in  the  global  climate  discourse. Similar  trends  are  observed  at  all  levels  of  government and in the private sector, including in hard to abate and oil and gas sectors. As much of the world grapples with the economic downturn, investment in the energy transition can help align shortterm priorities with medium- and long-term development and climate objectives. This is a unique opportunity to instigate a lasting shift with foresighted and targeted investment in energy, most immediately in infrastructure, efficiency and renewables (IRENA, 2020b). Indeed, several countries have made significant commitments to appropriate public funds for these purposes and to support solutions such as electric mobility and clean hydrogen.

No less than 80% of the world's people live in countries that are net importers of fossil fuels. By contrast, every nation possesses some renewable potential that can be harnessed for greater energy  security  and  independence,  increasingly  at  least  cost  (IRENA,  2019b).  A  transformation of the global energy system aligned with the 1.5°C climate goal can become a great equaliser in a world that must become more resilient, just and inclusive. Such an energy system requires the rapid development and deployment of resilient technologies and investments in people and institutions.

Progress has been significant but uneven across geographies and communities. The longest strides have been made in a handful of countries and regions. In other areas, widespread energy poverty continues to hold back economic progress and social wellbeing. In 2020, Europe, U.S. and China accounted for the largest share of new renewable capacity, while Africa accounted for only 1% of the global total of new renewable capacity. This is even though the continent has the largest needs for expanded access to modern forms of energy and a renewable potential that far exceeds projected needs. Only USD 1 billion was invested in off-grid renewables between 2008 and 2019, despite being a major avenue for expanding access. Uneven deployment patterns are also mirrored in the concentration of jobs and industries, leaving behind large parts of the world.

Current plans fall woefully short of a 1.5°C goal. Based on existing government energy plans and targets,  including  the  first  round  of  Nationally  Determined  Contributions  (NDCs)  under  the  Paris Agreement, the policies in place will do no more than stabilise global emissions, with a slight drop as 2050 approaches. Despite clear evidence of human-caused climate change, widespread support for the Paris Agreement, and the prevalence of clean, economical, and sustainable energy options, energy-related CO  emissions 2 increased by 1.3% annually, on average, between 2014 and 2019.

Time is of the essence, and a rapid decline in emissions must begin now to preserve a fighting chance  to  hold  the  line  at  1.5°C. In  alignment  with  the  Intergovernmental  Panel  on  Climate Change's (IPCC) report on limiting global warming to 1.5°C by 2050, coal and oil should already have peaked, with natural gas peaking in 2025. The resources and technologies needed to accelerate the energy transition are available now . IRENA plots the way to a steep and continuous downward trajectory towards a 45% decline in carbon dioxide (CO ) emissions from 2010 levels by 2030, and 2 net zero by 2050, in line with IPCC's schedule.

IRENA's World Energy Transitions Outlook is  a  unique  1.5°C-compatible  pathway  that  also examines full socio-economic and policy implications, and provides insights on the structural changes  and  finance. Technologies  for  rapid  decarbonisation  are  increasingly  available,  but thinking related to the energy transition should not be confined within the energy silo. Realising the  transition's  far-reaching  potential  requires  systemic  innovation  that  considers  technologies and enabling frameworks in tandem. Renewables-based energy systems will instigate profound changes that will reverberate across economies and societies. Only by understanding these deep currents can we achieve optimal results from the transition process. This inaugural edition of the World Energy Transitions Outlook marshals IRENA's extensive knowledge to make this possible by providing policy makers with insights, tools and advice to chart the path ahead.

## IRENA's 1.5°C Scenario

The Planned  Energy  Scenario  (PES) is  the  primary  reference  case  for  this study, providing a perspective on energy system developments based on governments' current energy plans and other planned targets and policies, including Nationally Determined Contributions  (NDCs)  under  the  Paris Agreement.

PES

The 1.5°C Scenario (1.5-S) describes an energy  transition  pathway  aligned  with the  1.5°C  climate  ambition  -  that  is,  to limit global average temperature increase by  the  end  of  the  present  century  to 1.5°C,  relative  to  pre-industrial  levels.  It prioritises readily available technology solutions, which can be scaled up at the necessary pace for the 1.5°C goal.

<!-- image -->

## WORLD ENERGY

## TRANSITIONS OUTLOOK

The time imperative requires careful investment and policy choices in the coming decade. The window of opportunity to achieve the 2030 emission milestone set out by the IPCC is small, and the choices made in the coming years will determine whether a 1.5°C future remains within reach. This Outlook is  guided by the UN's Agenda for Sustainable Development and the Paris Agreement on Climate Change. Several prerequisites underpin the theory of change behind IRENA's 1.5°C Pathway:

- ·   Pursuing the path that is most likely to drive down energy emissions in the coming decade and put the world on a 1.5°C trajectory.
- ·   Supporting emerging technologies most likely to become competitive in the short-term and most effective in achieving emissions reductions in the long-term.
- •   Limiting investments in oil and gas to facilitating a swift decline and a managed transition.
- ·   Reserving carbon capture and storage technologies for economies heavily dependent on oil and gas and as a transitional solution where no other options exist
- •   Phasing out coal and fossil fuel subsidies.
- •   Adapting market structures for the new energy era.
- ·   Investing in a set of policies to promote resilience, inclusion, and equity and protect workers and communities affected by the energy transition.
- ·   Ensuring  all  countries  and  regions  have  an  opportunity  to  participate  in  and  realise  the  benefits of the global energy transition.

## FIGURE S.3     Guiding framework of WETO theory of change

<!-- image -->

## Technological avenues to climate targets

IRENA's analysis shows that over 90% of the solutions shaping a successful outcome in 2050 involve  renewable  energy  through  direct  supply,  electrification,  energy  efficiency,  green hydrogen and bioenergy combined with carbon capture and storage (BECCS). The technological avenues leading to a decarbonised energy system have crystalised, dominated by solutions that can be deployed rapidly and at scale. Technologies, markets, and business models are continuously evolving, but there is no need to wait for new solutions. Considerable advancement can be achieved with  existing  options.  But  taking  the  energy  transition  technologies  to  the  necessary  levels,  and at a speed compatible with a 1.5°C goal, requires targeted policies and measures.

FIGURE S.4     Carbon emissions abatements under the 1.5°C Scenario (%)

<!-- image -->

<!-- image -->

By 2050, electricity will be the main energy carrier, increasing from a 21% share of total final energy  consumption  in  2018  to  over  50%  in  2050. Sectoral  boundaries  are  shifting,  with  the electrification of end-use applications in transport and heating. This increase is mostly driven by the use of renewable electricity in place of fossil fuels in end-use applications. As this shift occurs, the annual growth rate of renewable technologies will see an eightfold increase. Electrification of end-uses will also reshape several sectors, most notably transport, with electric vehicles coming to account for 80% of all road activity in 2050.

The annual energy intensity improvement rate needs to rise to 2.9%, nearly two and a half times the historical trend. With this rise, the energy intensity of the global economy will fall more than  60%  by  2050.  Energy  efficiency  technologies  and  measures  are  'ready-to-go"  solutions, available for significant scale-up now. Policies and measures to increase energy conservation and efficiency will be crucial to reduce total final energy consumption from 378 exajoule (EJ) in 2018 to  348  EJ  in  2050.  An  important  contribution  will  also  come  from  structural  and  behavioural changes, which will account for about a tenth of the improvement in efficiency.

Hydrogen and derivatives will account for 12% of final energy use by 2050. They will play an important  role  in  hard-to-decarbonise,  energy-intensive  sectors  like  steel,  chemicals,  long-haul transport, shipping and aviation. Hydrogen will also help balance renewable electricity supply and demand and serve as long-term seasonal storage. Some 5 000 GW of electrolyser capacity will be needed by 2050, up from 0.3 GW today. This scale of growth accentuates the importance of lowcarbon hydrogen from the outset. In 2050, two-thirds of the total hydrogen will be green - produced with  renewable  electricity  -  and  one-third  blue,  produced  by  natural  gas  coupled  with  carbon capture and storage (CCS).

Bioenergy will represent 18% of total final energy consumption in 2050. Increasing sustainable production  and  use  of  biomass  is  needed  across  the  energy  system.  In  some  sectors,  it  plays a  significant  role  -  particularly  as  feedstock  and  fuel  in  the  chemicals  sectors  and  as  fuel  in  the aviation  sector.  In  others,  it  helps  to  address  gaps  that  other  options  cannot  fully  resolve,  such as  replacing  natural  gas  with  biomethane  in  buildings  that  cannot  be  renovated.  Additionally, biomass coupled with CCS (BECCS) in the power sector and some industrial sectors will deliver the negative emissions needed to achieve the net zero goal.

In  residual  use  of  fossil  fuels  and  some  industrial  processes,  decarbonisation  efforts  may require CCS and CO  removal technologies and measures. 2 In the 1.5°C Scenario, some emissions persist  in  2050  from  residual  uses  of  fossil  fuels  and  some  industrial  processes.  Therefore,  the remaining CO  will have to be captured and sequestered. CCS is limited mainly to process-related 2 CO2  emissions  in  cement,  iron  and  steel,  and  blue  hydrogen  production.  CO   removal  includes 2 nature-based  measures  such  as  reforestation  and  BECCS,  direct  carbon  capture  and  storage, and other approaches that are still experimental.

## FIGURE S.5     Evolution of emissions with phaseouts of coal and oil, 2021-2050

<!-- image -->

Note: RE = renewable energy; VRE = variable renewable energy; CBAM = carbon border adjustment mechanism; ICE = internal combustion engine; GW = gigawatt; Gt = gigatonne; CCS = carbon capture and storage; BECCS = bioenergy combined with carbon capture and storage; CCU = carbon capture and utilisation.

<!-- image -->

By 2030, renewable power should reach 10 700 GW globally, almost quadrupling the current capacity. Rapid  scale-up  deployment  in  the  coming  decade  is  necessary  to  set  the  stage  for decarbonisation of the power system and electrification of end-use by 2050. This level of deployment is also a key recommendation of the Energy Transitions Theme Report, developed by IRENA, UNEP, and UN ESCAP for the United Nations High-Level Energy Dialogue. The abundance of cost-effective renewable potentials worldwide makes them a scalable option. For many countries, this translates a technical and economic challenge into a set of investment, regulatory and societal opportunities.

Infrastructure upgrade, modernisation and expansion is a high priority in the coming decade. Updating ailing infrastructure or investing in expansion is an integral part of the energy transition and an enabler of modern technologies. This will be particularly important in the coming decade as  the  share  of  renewables  grows,  requiring  system  flexibility  and  modern  grids.  Infrastructure developments must be aligned with long-term plans and reflective of broader strategies, including regional market integration.

The necessary deployment levels will be reached by 2030 only with policies to support these technological avenues. Deployment  policies  support  market  creation,  thus  facilitating  scale-up, reducing technology costs and increasing investment levels aligned with energy transition needs. Given the large amounts of public finance being injected into economies as part of the recovery measures, such policies will shape the direction of the energy transition and set the stage for the significant increase in the private sector investment required until 2050.

<!-- image -->

## TABLE S.1     Overview of policies to support energy transition solutions

TECHNO­

OBJECTIVE

## RECOMMENDATIONS

LOGICAL

AVENUE

|                                             | Deploy renewable energy                                                         |                                                                                                                                                                                                                                                                                                                                                                                  |
|---------------------------------------------|---------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Renewables (power and direct uses) Energy   | in end uses Deploy renewable in the power Increase energy                       | These policies include regulatory measures that create a market, as well as fiscal and financial incentives to make them more affordable and increase their cost competitiveness compared to fossil-fuel-based solutions. The choice of instrument consider the nature of scale, distributed, off-grid), development, the power structure and broader Energy efficiency policies |
| conservation and efficiency Electrification | conservation and efficiency in heating and cooling Increase energy conservation | codes, support for building retrofits and appliance standards are critical for the energy transition in buildings and industrial processes. Decarbonising the transport sector, among other measures, requires a shift from energy-intensive modes to low-carbon                                                                                                                 |
| of end uses                                 | Electrify heating and cooling Electrify transport                               | Targets for renewable power should consider the rising demand from the electrification of end uses, in line with long-term decarbonisation objectives. Moreover, policies and power system design are needed to support electrification in achieving its potential for providing system                                                                                          |
| Green hydrogen                              | Support the development of green hydrogen                                       | flexibility.                                                                                                                                                                                                                                                                                                                                                                     |
|                                             |                                                                                 | An enabling policy framework should consider four key pillars: a national green hydrogen strategy, priority setting, guarantees of origin and enabling policies.                                                                                                                                                                                                                 |
| Sustainable bioenergy                       | Ensure the sustainable use of bioenergy                                         | Renewable energy is not exempt from sustainability concerns. Some of these concerns include greenhouse gas emissions related to land-use change, and impacts on air and water quality and biodiversity.                                                                                                                                                                          |

<!-- image -->

## Financing the energy transition

USD 131 trillion will need to flow into an energy system over the period to 2050 that prioritises technology  avenues  compatible  with  a  1.5°C  Pathway. While  the  annual  funding  requirement averaging at USD 4.4 trillion is large, it represents 20% of the Gross Fixed Capital Formation in 2019, equivalent to about 5% of global Gross Domestic Product (GDP). Between now and 2050, over 80% of the USD 131 trillion total must be invested in energy-transition technologies, including efficiency, renewables, end-use electrification, power grids, flexibility, hydrogen, and innovations designed to help emerging and niche solutions become economically viable.

Current government strategies already envisage significant investment in energy amounting to USD 98 trillion by 2050. Collectively referred to in this Outlook as the Planned Energy Scenario (PES),  they  imply  a  near  doubling  of  annual  energy  investment,  which  in  2019  amounted  to USD  2.1  trillion.  Substantial  funds  will  flow  towards  modernisation  of  ailing  infrastructure  and meeting growing energy demand. But the breakdown of financing for technology under the 1.5°C Scenario differs greatly from current plans: USD 24 trillion of planned investments will have to be redirected from fossil fuels to energy transition technologies between now and 2050.

Funding  structures  in  the  1.5°C  Scenario  are  markedly  different  in  terms  of  capital  sources (public and private) and types of capital (equity and debt). In 2019, USD 1.6 trillion in energy assets were financed by private sources, accounting for 80% of total energy sector investment. That share would grow dramatically under the 1.5°C Scenario. The share of debt capital has to increase  from  44%  in  2019  to  57%  in  2050,  almost  20%  more  than  under  the  PES  (see  Figure S.6).  Energy  transition  technologies  should  find  it  increasingly  easy  to  obtain  affordable  longterm debt financing, while 'brown' assets will progressively be avoided by private financiers and therefore forced to rely on equity financing from retained earnings and new equity issues. Capitalintensive, more decentralised projects will influence investors' risk perception, which in turn may need targeted policy and capital market interventions.

Public funding will need to grow almost two-fold to catalyse private finance and ensure just and inclusive unfolding of the energy transition. Public financing plays a crucial role in facilitating the energy transition, as markets alone are not likely to move rapidly enough. In 2019, the public sector provided some USD 450 billion in the form of public equity and lending by development finance institutions. In the 1.5°C Scenario, these investments will grow to some USD 780 billion. Public debt financing will be an important facilitator for other lenders, especially in developing markets with high real or perceived risks. In some instances, this may include grants to reduce the cost of financing. Public funds are also needed to create an enabling environment for the transition and ensure that it occurs fast enough and with optimal socio-economic outcomes.

FIGURE S.6     Total average yearly investment by source and type of financing: 2019, PES and 1.5°C Scenario (2021-2030 and 2031-2050)

<!-- image -->

Sources: For 2019 investment: source and type of financing BNEF (2021a), IEA (2020a), IRENA and CPI (2020); for PES and 1.5°C Scenario: IRENA and BCG analysis.

Measures to eliminate market distortions that favour fossil fuels, coupled with incentives for energy  transition  solutions,  will  facilitate  the  necessary  changes  in  funding  structures. This will  involve  phasing  out  fossil  fuel  subsidies  and  changing  fiscal  systems  to  reflect  the  negative environmental, health and social costs of the fossil fuel-based energy system. Monetary and fiscal policies,  including  carbon  pricing  policies,  will  enhance  the  competitiveness  of  transition-related solutions. Such interventions should be accompanied by a careful assessment of the social and equity dimensions to ensure that the situation of low-income populations is not worsened but improved.

## Socio-economic footprint of the energy transition

## Investment  in  the  1.5°C  Scenario  will  yield  a  cumulative  payback  of  at  least  USD 61 trillion

by  2050. The  overall  balance  from  the  energy  transition  is  positive,  with  benefits  greatly exceeding  costs.  The  costs  for  reducing  emissions  vary  by  technology  and  sector,  but  the incremental  costs  are  significantly  lower  than  the  savings  achieved  by  cutting  external  costs. IRENA  estimates  that,  under  the  1.5°C  Scenario,  every  USD  1  spent  on  the  energy  transition should  yield benefits from  reduced  externalities  from  human  health  and  the  environment valued  at  between  USD  2  and  USD  5.5.  In  cumulative  terms,  the  additional  USD  30  trillion cost  implied  by  the  1.5°C  Scenario  over  the  period  to  2050  will  result  in  a  payback  of  between USD 61 and USD 164 trillion.

FIGURE S.7     Cumulative difference between costs and savings of 1.5°C Scenario compared to the PES, 2021-2050

<!-- image -->

The  energy  transition  goes  well  beyond  technology  and  brings  deep  structural  changes that  will  greatly  affect  economies  and  societies. IRENA  continues  to  capture  an  increasingly comprehensive picture of the socio-economic impacts of the energy transition. Results presented in this Outlook demonstrate that steps towards a decarbonised energy future will positively affect economic activity,  jobs  and  welfare,  provided  a  holistic  policy  framework  is  in  place.  Within  the analysis,  countries'  existing  policies  are  complemented  with  climate  policies  to  reach  energy transition targets while addressing distributional challenges for just and inclusive outcomes.

The 1.5°C Pathway provides a boost in GDP that is 2.4% greater (on average) than that of the PES over the next decade, aligned with the needs of a post-COVID recovery. Over the transition period to 2050, the average improvement of GDP is estimated at 1.2% over the PES. Additional GDP growth will be spurred by investment across the many dimensions of the energy transition, leading to multiple adjustments between interdependent economic sectors. The reduced demand for fossil fuels  leads  to  lower  revenues  for  mining  and  fuel  refining  industries,  as  well  as  for  governments (because of lower fossil fuel royalties), thus resulting in negative impacts on GDP in some countries. This reality highlights the need for a holistic policy framework that addresses structural changes caused by reduced fossil fuel dependency.

Throughout the transition period, economy-wide employment is 0.9% higher on average under the 1.5°C Scenario than under the PES. One of the main positive impacts on employment comes from investment in energy transition solutions, including renewables, grid enhancement and energy efficiency. Shifting investment from fossil fuels (extraction and power generation) and other sectors towards the energy transition decreases labour demand in fossil fuel and non-energy sectors and along their value chains.

<!-- image -->

## WORLD ENERGY TRANSITIONS OUTLOOK

A  transformed  energy  sector  will  have  122  million  jobs  in  2050. Qualifications,  skills  and occupations under the ambitious 1.5°C  Scenario  are  increasingly  concentrated  in  manufacturing, followed by fuel supply. Training for such occupations is relatively easy and offers opportunities for workers from the fossil-fuel industry. The educational requirements for the labour force evolve during the transition, with a continuous increase of the share and number of workers with primary education and a peak of workers with tertiary education by 2030.

FIGURE S.8     Energy sector jobs by technology under the PES and 1.5°C Scenario (million), global results

<!-- image -->

- Hydrogen
- Power grids and energy flexibility
- Energy efficiency and heat pumps
- Renewables
- Fossil fuels
- Nuclear

Based on IRENA's analysis.

FIGURE S.9     Energy sector jobs, by segment of

value chain, in the 1.5°C Scenario and PES (excluding vehicles)

<!-- image -->

<!-- image -->

- Fuel supply

Operation and maintenance

- Manufacturing
- Construction and installation

Based on IRENA's analysis.

Renewable energy jobs will increase to 43 million in 2050. In the PES, renewable energy jobs increase 9% from 2021 values to reach 18 million jobs by 2030 and 23 million by 2050. By contrast, the 1.5°C Scenario leads to a much larger gain by 2030, with renewables jobs more than tripling to 38 million over the coming decade. Solar photovoltaic (PV) accounts for the largest share, followed  by  bioenergy,  wind  and  hydropower.  Construction,  installation  and  manufacturing boost  renewable  jobs  during  the  following  decade,  with  operation  and  maintenance  gaining relative weight as the transition advances under the 1.5°C Scenario.

FIGURE S.10     Jobs in renewable energy, by technology, in the 1.5°C Scenario and PES (million)

FIGURE S.11     Structure of jobs in the 1.5°C Scenario by 2050 for a subset of renewable technologies by technology, segment of value chain and occupational requirements

<!-- image -->

<!-- image -->

IRENA's Energy Transition Welfare Index captures economic, social, environmental, distributional and energy access dimensions. For the first time, the Index reports distributional and energy access dimensions that are often overlooked in other analyses. Measuring the impact of  the  transition  across  these  dimensions  provides  a  quantitative  basis  for  roadmaps  designed to reap the transition's full socio-economic and environmental benefits.

FIGURE S.12     Structure of IRENA's Energy Transition Welfare Index

Dimensions

<!-- image -->

## The  1.5°C  Scenario  performs  better  than  the  PES  along  all  welfare  dimensions,  yielding  an 11% improvement over the PES by 2050.

- ·   The economic  dimension is  similar  for  both  scenarios  reflecting  the  energy  sector's  relatively small share in the overall global economy and labour force.
- ·   The environmental  dimension sees  a  30%  improvement  over  PES  with  significantly  lower emissions under the 1.5°C Scenario, although increased materials consumption poses sustainability challenges.
- ·   The social  dimension improves  23%  under  the  1.5°C  Scenario  largely  due  to  improved  health outcomes from lower  outdoor  and  indoor  air  pollution.  Social  expenditures  contribute  a  much smaller role.
- ·   The distributional dimension improves  37%  over  PES;  however,  the  index  remains  low  in  an absolute  sense,  indicating  potential  equity  barriers.  In  fact,  both  social  and  distributional dimensions bring down the overall Energy Transition Welfare Index - and these realities deserve more policy attention.
- ·   The energy access dimension grows 7% under the 1.5°C Scenario compared to PES as universal energy access and sufficiently levels are reached.

Socio-economic  impacts  vary  at  the  regional  and  country  level. Global  aggregates  mask important differences in how the energy transition affects regions and countries and how benefits are  distributed.  What  is  clear  is  that  the  energy  transition  roadmaps  and  their  resulting  socioeconomic  implications  are  closely  linked  with  the  policy  framework,  with  those  links  becoming stronger  as  ambitions  align  with  the  1.5°C  Pathway.  Governments'  involvement  in  the  transition should be accompanied by international co-operation to ensure that the benefits and burdens of the transition are equitably shared.

<!-- image -->

## TABLE S.2     Overview of structural change and just transition policies

## OBJECTIVE

## RECOMMENDATIONS

| Address potential misalignments in labour markets   | Ensuring a just and fair transition will require measures to overcome temporal, geographic and skills-related imbalances.                                                                                                                            |
|-----------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Develop local value chains                          | Enhancing and leveraging domestic capabilities requires carefully crafted incentives and rules, business incubation initiatives, supplier-development programmes, support for small and medium enterprises and promotion of key industrial clusters. |
| Provide education and build capacity                | Early exposure to renewable-energy-related topics and careers is vital for sparking young people's interests in pursuing a career in the sector, and also to increase social acceptance by a knowledgeable citizenry.                                |
| Support a circular economy                          | Policies and measures are needed to ensure the sustainability of energy transition-related solutions and their smooth integration in existing ecosystems in terms of sustainability, circular economy principles and reduced environmental impacts.  |
| Support community and citizen engagement            | Community energy can play an important role in accelerating renewables deployment while generating local socio-economic benefits and increasing public support for local energy transitions.                                                         |

## A comprehensive policy framework for the energy transition

Policy  measures  and  investments  in  energy  transitions  can  drive  a  wider  structural  shift towards resilient economies and societies. The  energy  sector  must  be  viewed  as  an  integral part of the broader economy to fully understand the impact of the transition and ensure that it is timely and just. Regions and countries have varied starting points, socio-economic priorities and resources, all  of  which  shape  the  scope  and  pace  of  their  energy  transition.  Energy  transitions trigger  structural  changes  that  bring  benefits  as  well  as  challenges,  with  those  challenges appearing in the form of misalignments in finance, labour markets, power systems and the energy sector itself. These misalignments, if not well managed, risk inequitable outcomes and a slowdown in the energy transition. Just and integrated policies - implemented by strong institutions - are imperative to realise the full potential of the energy transition.

International  co-operation  is  an  essential  piece  of  the  global  energy  transition. A  holistic global policy framework is needed to bring countries together to commit to a just transition that leaves no one behind and strengthens the international flow of finance, capacity and technologies. Climate policies represent a crucial element in such a framework. Other measures should include fiscal  policies  (such  as  adequate  carbon  pricing  covering  emissions  across  sectors)  and  public funding to implement policies to foster deployment, create enabling conditions and ensure a just and stable transition. Elements of the latter imperative include industrial development, education and training, and social protection. The necessary financial resources will not always be available domestically. International co-operation will be needed to provide such support, particularly to the least-developed countries and small island developing states.

## FIGURE S.13     Enabling policy framework for a just and inclusive energy transition

<!-- image -->

## 01 LEVERAGING THE COMPETITIVENESS OF RENEWABLES TO HASTEN THE ENERGY TRANSITION AND MINIMISE CLIMATE CHANGE

<!-- image -->

## The energy sector has experienced unprecedented dynamism in recent years largely due to the advent of renewables.

Traditionally  slow  to  change,  the  energy  sector  has  experienced  unprecedented  dynamism in  recent years, quite unlike any other time in history. This is in large part due to the advent of renewables. While the share of renewables in the overall energy mix remains limited at a global scale, technologies used to harness the sun and wind are reshaping the energy systems of the past, with wide-ranging and outsized implications. Meanwhile, policy priorities such as climate change, energy security, energy access and air pollution have placed a renewables-based energy transition at the forefront of the national, regional and global discourse.

In the turmoil caused by the COVID-19 pandemic, renewables showed remarkable resilience. This further  cemented  their  role  in  decarbonising  economies  worldwide  and,  through  their  potential to  create  jobs,  in  supporting  economic  recovery.  Combined,  these  developments  are  shifting renewables from niche to mainstream, as even the most traditional players come to embrace their immense promise. Importantly, renewables-based solutions are necessary to policy makers in their quest to limit the global temperature rise to 1.5°C by 2050, with net zero emissions. Such solutions increasing  adoption  sends  an  important  message  regarding  the  urgency  of  combating  climate change (Lederman and Chow, 2021). The strong financial performance of green investments has attracted the interest of the financial community in supporting the climate cause and is likely to encourage a new trend in investments.

This  chapter  presents  a  brief  overview  of  the  most  relevant  recent  developments  in  the  energy transition. It outlines key trends at a moment in time when over 100 nations are at different stages of operationalising their net zero carbon targets for 2050. Even as each country considers how to accomplish this in light of its own circumstances, endowments, abilities and needs, all countries are on the cusp of transforming their energy sectors. The chapter thus introduces a pathway towards maintaining the 1.5°C limit, here called the 1.5°C Scenario. As it clarifies key assumptions underlying the scenario, and outlines its parameters, the chapter sets the stage for a more detailed discussion of climate scenarios in the ensuing chapters.

## ENERGY TRANSITION TRENDS 1.1

## Renewables are increasingly the lowest-cost sources of electricity in many markets. It

has been a remarkable decade of change for renewable electricity generation, and solar photovoltaic (PV) and wind power technologies in particular. Among newly commissioned projects,  the  global  weighted  average  levelised  cost  of  energy  (LCOE)  of  utility-scale solar  PV  fell  by  85%  between  2010  and  2020,  from  USD  0.381/kilowatt  hour  (kWh)  to USD 0.057/kWh (Figure 1.1). This is a precipitous decline. At one time more than double the cost of the most expensive fossil-fuel-fired power generation option, utility-scale solar PV can now compete with the cheapest new fossil-fuel-fired capacity. 1  Between 2010 and 2020, the global weighted-average cost of electricity from onshore wind projects fell by 56%, from USD 0.089/kWh to USD 0.039/kWh. Over the same period, the global weighted average  cost  of  electricity  from  concentrating  solar  power  fell  from  USD  0.340/kWh to  USD  0.108/kWh.  This  68%  decline  in  the  cost  of  electricity  from  this  technology -  which  now  falls  in  the  middle  of  the  range  of  new  fossil-fuel  capacity  -  remains  a remarkable  achievement.  For  offshore  wind,  the  global  weighted  average  LCOE  of newly commissioned projects declined from USD 0.162/kWh in 2010 to USD 0.084/kWh in  2020,  a  reduction  of  42%  in  ten  years  (IRENA,  2021b).  Falling  technology  costs continue  to  affect  auctions,  where  new  record-low  prices  continued  to  emerge  even amid the global pandemic. For example, in 2020, Abu Dhabi saw a USc 1.35/kWh bid for  solar  PV  (Ombello,  2020),  followed  by  an  even  lower  bid  in  a  Portuguese  auction in July (Bellini, 2020).

- 1 The cost of fossil-fuel-fired power generation varies by country and fuel in an estimated range between USD 0.055/kWh and USD 0.148/kWh. The lower bound represents new, coal-fired plants in China.

The costs of renewable energy have continued to decline. Solar PV and wind are increasingly the cheapest sources of electricity in many markets.

FIGURE 1.1     Global LCOE of newly commissioned utility-scale renewable power generation technologies, 2010 and 2020

<!-- image -->

Source: (IRENA, 2021b)

Capacity (MW)

1

≤

100

200

300

≥

<!-- image -->

More renewable power capacity was added to the grid annually than all fossil fuels and nuclear combined in the seven years between 2013 and 2020. The share of renewable energy in electricity generation also increased steadily. Renewable power technologies now dominate the global market for new electricity generation capacity. Despite the pandemic's detrimental effects on most global supply chains, more than 260 gigawatts (GW) of renewable generation capacity - a record level - was added globally in 2020 (Figure 1.2). This is more than four times the capacity added from other sources and nearly 50% more than the 2019 addition (IRENA, 2021a). The upward trend in these shares reflects not only the rapid and increasing growth in the use of renewables but also a a decline in the growth of non-renewable capacity, following net decommissioning across many years in some regions. The impact of the pandemic on wind and solar PV has been much smaller than anticipated and both sources have continued dominating new capacity installations, showing the resilience and momentum of the renewables industry. A total of 111 GW of wind power were installed in 2020, compared to 60 GW in 2019; solar PV additions reached 127 GW in 2020 (IRENA, 2021a). As renewable electricity generation capacity increases so does the share of renewables in electricity generation, which increased from 20% to nearly 28% in the years 2010-2020 (IEA, 2020b). This capacity growth is concentrated in a limited number of countries and regions.

FIGURE 1.2     Share of new electricity capacity, 2001-2020

<!-- image -->

Based on IRENA's renewable energy statistics.

Note: GW = gigawatt.

A record level of more than 260 GW of renewable generation capacity was added globally in 2020. This is more than four times the capacity added from other sources and nearly 50% more than the 2019 addition.

Growing  shares  of  variable  renewable  energy  (VRE),  such  as  solar  and  wind  in  power  systems, complicate  the  balancing  of  supply  and  demand,  raising  system  requirements. To  effectively manage  large  VRE  shares,  a  wide  range  of  innovations  are  being  implemented  around  the world (IRENA, 2019a). Significant progress has been made in battery storage, digital technologies ( i.e. ,  Internet of Things, artificial intelligence, big data), as well as new and smart grids (mini-grids and super grids), contributing to better management of a power sector that is seeing the increasing integration  of  variable  renewables.  On  the  business  and  regulatory  side,  new  and  innovative models ( i.e. , aggregators, pay-as-you-go and community ownership), as well as market regulations are  empowering  consumers  while  also  helping  manage  the  greater  shares  of  VRE  generation. Aggregators' business models are picking up, as well. The global market for virtual power plants is projected to grow from less than USD 1 billion in 2019 to around USD 2.85 billion by 2027, with a compound annual growth rate of 27.2% (FBI, 2020).

Capital is increasingly moving to take advantage of the most attractive investment opportunities at this time of transition. Anticipating that demand for fossil fuels will soon peak as new energy technologies continue their rapid growth, financial markets are allocating capital in new ways. After the shock induced by the COVID-19 pandemic in March 2020, investors became enthusiastic about the opportunity presented by renewables, which resulted in a spike in the value of clean energy stocks (Figure 1.3). Although the S&amp;P Global Clean Energy Index followed a downward trend from the beginning of 2021, in the five years from May 2016 to May 2021, the index was up by 22%, while the  fossil-fuel-heavy  S&amp;P  500  Energy  Index  was  down  by  4%,  suggesting  an  emerging  trend  in financial markets towards cleaner energy assets.

<!-- image -->

<!-- image -->

## FIGURE 1.3     New energy vs. old energy: S&amp;P Global Clean Energy and Energy Indices, 24 May 2016 to 24 May 2021

<!-- image -->

Source: S&amp;P Dow Jones Indices LLC, 2021.

Investors and financial markets are anticipating the energy transition and already allocating capital away from fossil fuels and towards energy transition technologies, such as renewables.

In 2020, investment in the global energy transition hit a record high of USD 524 billion, having grown steadily for over 15 years (Figure 1.4) (BNEF, 2021a). 2  Renewable energy technologies dominated these investment flows, though their share decreased over time (from almost 90% in 2005-2009 to  70%  in  2016-2020)  as  other  energy  transition  technologies  attracted  increasing  volumes  of capital. In addition, investments in energy efficiency averaged just above USD 250 billion during 2014-2019 (IEA, 2020a).

Investments in electrified transport are also on the rise, as policies supporting the electrification of transport gain importance. In 2017, at least 60 countries and 40 jurisdictions at the sub-national level had set objectives for the deployment of electric vehicles (REN21, 2018). By the end of 2019, at least 13 jurisdictions had introduced financial incentives to support their deployment (REN21, 2020).  Policies  to  support  electric  vehicles  -  including  public  procurement,  public  support  for charging infrastructure, congestion charging, free parking and preferred access - have supported a surge in uptake. All of the top markets for electric vehicles to date ( e.g. , China, Norway and the United States) have introduced such policies.

Investments in electric heat have also increased in the past couple of years as more countries adopted financial incentives for their installation such as grants, rebates, tax incentives and loan programmes. In 2019, France, Germany and Lithuania implemented instruments to support the phase-out of inefficient fossil fuel boilers and the adoption of heat pumps.

- 2 This figure  measures  investments  in  renewables  (excluding  large  hydropower),  electrified  heat,  electrified transport,  energy  storage,  hydrogen  and  carbon  capture  and  storage  (CCS).  Including  investments  in  energy efficiency, the total rises to almost USD 800 billion.

<!-- image -->

T

R

A

N

Despite the COVID-19 pandemic, investment in energy transition technologies reached an all-time high of USD 524 billion in 2020 - up to almost USD 800 billion if energy efficiency measures are considered.

FIGURE 1.4     Global investment in energy transition technologies, 2005-2020

<!-- image -->

Source: BNEF 2021a.

Note: BNEF data exclude investments in large hydropower ( i.e. , greater than 50 MW), estimated at USD 28 billion on average per year between 2015 and 2019. CCS = carbon capture and storage.

## THE EVOLVING POLICY LANDSCAPE 1.2

The  number  of  countries  with  renewable  energy  policies  has  grown  significantly. In  2019, 143 countries had policies for renewables in the power sector compared with 117 in 2014 (REN21, 2020). As market conditions evolve alongside the maturity and competitiveness of technologies, the  preferred  policy  instruments  have  adapted  over  time.  For  instance,  competitively  set  pricing mechanisms for renewable power are replacing  administratively  determined  tariffs.  The  number of  countries  adopting renewable energy auction schemes have increased from 16 in 2010 to 109 in  2020.  During  this  period,  the  weighted  global  average  price  of  contracted  solar  energy  fell from USD 250/megawatt hours (MWh) to USD 56/MWh and that of onshore wind decreased from USD 75/MWh to USD 48/MWh (IRENA, 2019c). As the share of renewable electricity has grown, integration,  flexibility  and  power  market  design  have  also  come  to  the  fore  in  policy  design  and implementation.

Policies to promote the use of renewable energy in end-use sectors have received less attention. In 2019, 61 countries had introduced heating and cooling policies (IRENA, 2020c). Financial policies, such as investment subsidies, grants, rebates and tax credits are more common than regulatory policies  such  as  renewable  heating  mandates.  Given  the  context-specific  and  decentralised nature of heating and cooling needs, local governments also play a key role. At least 110 cities and municipalities are targeting 100% renewable heating and cooling. In the transport sector, 70 countries have introduced renewable energy policies largely focused on road transport and the use of liquid and gaseous biofuels.

It  is  abundantly clear that accelerating the pace and depth of the energy transition will require a continuing focus on the power sector, along with much greater policy efforts in electrification, as well as the heating and cooling and transport sectors.

Also,  countries  are  increasingly  adopting  policies  dedicated  to  off-grid  renewables.  Tailored regulations for mini-grids have been adopted in countries such as Nigeria, Tanzania, Uganda, Mali, Senegal,  India  and  Indonesia,  driving  investments  in  these  technologies.  The  regulations  usually address aspects related to licensing and legal provisions, tariff setting, the implications of main-grid arrival and public financing support.

## RENEWABLE ENERGY INVESTMENTS 1.3

With falling costs, renewable energy investments grew steadily over the past 15 years, from USD 70 billion in 2005 to just over USD 300 billion in 2019. In 2020, despite the dramatic impacts of the COVID-19 pandemic, investments in renewables reached over USD  320  billion  (BNEF,  2021a).  Solar  and  wind  technologies  have  consolidated  their dominance  over  time,  having  attracted  combined  shares  of  total  investments  above 90% since 2014 (Frankfurt School-UNEP Centre and BNEF, 2020; BNEF, 2021a; IRENA and CPI, 2020) (Figure 1.5).

Despite their steady growth overall, renewable energy investments remained concentrated  in  a  handful  of  regions  and  countries.  The  Asia-Oceania  region,  led by  China,  regularly  attracts  the  largest  share  of  renewable  energy  investments  (on average,  55%  during  2005-2019).  Europe  and  the  United  States  follow,  with  average shares of 20% and 16%, respectively, during 2005-2019. Regions dominated by developing and  emerging  economies  remained  consistently  under-represented,  attracting  only about  15%  of  global  investments  in  renewables  (Frankfurt  School-UNEP  Centre  and BNEF, 2020; IRENA and CPI, 2020) (Figure 1.6).

Global annual renewable energy investments increased almost five fold between 2005 and 2020, with solar and wind technologies recently accounting for about 90% annually.

FIGURE 1.5     Global annual renewable energy investments by technology, 2005-2019

<!-- image -->

Source: Frankfurt School-UNEP Centre and BNEF 2020.

Note: BNEF data excludes investments in large hydropower ( i.e. , greater than 50 MW), estimated at USD 28 billion on average per year between 2015 and 2019.

<!-- image -->

T

R

A

N

Annual investments in renewables remain concentrated in a handful of countries, with developing and emerging markets still attracting low levels of investments.

FIGURE 1.6     Global annual renewable energy investments by location, 2005-2019

<!-- image -->

Source: Frankfurt School-UNEP Centre and BNEF 2020.

Note: BNEF data excludes investments in large hydropower ( i.e. , greater than 50 MW), estimated at USD 28 billion on average per year between 2015 and 2019.

Annual  financial  commitments  to  off-grid  renewables  supporting  energy  access  in  emerging and developing countries reached USD 460 million in 2019, up from just USD 6 million in 2008. Investments remained very low until 2014 and have since grown at remarkable rates (Figure 1.7). Yet off-grid renewables still represent only 1% of the overall finance for projects to expand energy access in access-deficit countries. The majority of financing went to Sub-Saharan Africa, where 570 million people still lack access to electricity (IEA et  al. ,  2021).  The  region  attracted 65% of cumulative investments over 2008-2019 (or USD 1.3 billion). While over half of this was directed towards  East  African  countries,  West  Africa  has  picked  up  more  in  recent  years.  Solar  home systems for residential use attracted the majority of investments during this period, though there is recent growth in the share of capital going to renewable energy solutions for commercial and industrial purposes (mainly mini-grids). This focus on productive uses is essential to accelerate economic growth, especially in rural areas.

FIGURE 1.7     Annual commitments to off-grid renewable energy by region, 2008-2019

<!-- image -->

Source: IRENA analysis based on Wood Mackenzie (2020).

<!-- image -->

While providing, on average, only 14% of annual investments, the public sector remains key to lower risks, overcome initial barriers, attract private investors and bring new markets to maturity.

The lion's share of renewable energy financing is provided by the private sector, which accounted for 86% of investments in 2013-2018. Private capital came mainly from project developers (46%) and commercial financial institutions (22%). Institutional investors (including pension funds, insurance companies,  sovereign  wealth  funds,  and  endowments  and  foundations),  which  represent  a  key capital pool for accelerating the energy transition, provided only a small share of total investment 2% of total private capital in 2017-2018 (IRENA and CPI, 2020).

Globally, public finance accounts for only 14% of total direct investments in renewable energy assets. Most  of  this  flows  via  development  finance  institutions.  In  addition  to  direct  public  investment in  projects,  considerable  public  resources  are  spent  to  create  an  enabling  environment  for  the deployment  of  renewable  energy  through  the  promulgation  of  regulatory  instruments,  fiscal incentives, and other policies and measures. IRENA estimated that in Western Europe, government expenditure on measures to support renewables in 2015 was almost five times higher than direct investment  in  renewable  energy  projects  (USD  66  billion  as  compared  to  USD  14  billion).  When this additional expenditure is considered, the share of public financing spikes to over 55% of total renewable energy investment in 2015 in the region, compared to less than 20% if only direct public investment is considered (IRENA and CPI, 2018).

Public resources are crucial to lower risks, overcome initial barriers, attract private investors and bring new markets to maturity. As such, they play an especially vital role in emerging and developing countries where, aggravated by the COVID-19 crisis, investors' risk perception is comparatively high. As  shown  in  Figure  1.8,  public  financing  from  development  finance  institutions  and  government agencies in these countries jumped from around USD 3 billion in 2005-2008 to USD 18 billion in 2009,  and  has  since  fluctuated,  reaching  a  record-high  USD  25  billion  in  2017  before  dipping  in 2018 and 2019. Since 2010, public support for renewable energy in developing countries has been progressively directed away from hydropower towards less established technologies, such as solar and wind, as well as enabling infrastructure including grids and energy storage.

Beyond direct investments in projects, considerable public resources are employed for the implementation of regulatory instruments, fiscal incentives and other policies and measures in support of renewables.

FIGURE 1.8     Public annual renewable energy investments in emerging and developing countries by technology, 2005-2019

<!-- image -->

Source: IRENA, 2021c.

WORLD ENERGY TRANSITIONS OUTLOOK

## JOBS 1.4

According  to  the  most  recent  available  estimates  in  2019,  the  renewable  energy sector  worldwide  employed  at  least  11.5  million  people,  directly  and  indirectly.

The  progress  achieved  in  deploying  renewable  energy  has  yielded  impressive  socioeconomic benefits over the past several years, including employment along the value chain. Worldwide renewable energy employment has steadily grown since 2012, when IRENA first undertook its annual assessment. That year, an estimated 7.3 million persons were  employed  in  the  sector.  Figure  1.9  shows  the  evolution  of  IRENA's  employment estimates,  which  indicate  that  the  solar  PV  industry  is  the  single-largest  employer  in the sector, followed by bioenergy, hydropower and wind power.

Jobs  are  concentrated  in  a  number  of  countries  that  are  the  leading  markets  for  the installation  and  manufacture  of  renewables-related  equipment.  Beyond  this,  jobs  are being created in construction and in operations and maintenance across a wide range of countries. As countries work to leverage their domestic industries and capabilities, they  may  be  able  to  generate  additional  employment  in  value-added  activities  in manufacturing and services.

Women comprise only 32% of the renewable energy workforce. While this is significantly higher than the 22% seen in the energy sector overall, it is evident women represent a pool of talent yet to be fully utilised.

Renewable energy deployment has created growing employment along the value chain.

FIGURE 1.9     Global renewable energy employment by technology, 2012-2019

Total

<!-- image -->

Source: IRENA, 2020a.

<!-- image -->

Though renewables jobs were affected by COVID-19 as well, the sector fared better than conventional energy.

The full impact of the COVID-19 pandemic on employment in renewable energy is not yet known but jobs were affected by repeated lockdowns and other restrictions which put pressure on supply chains and constrained many economic activities. The ability of companies and industries to cope with lockdowns and supply chain disruptions differs enormously, as does their ability to switch to remote working arrangements. Renewable energy fared well compared with conventional energy, but  uncertainties  and  disruptions  dotted  the  way  and  employment  impacts  varied  by  country, renewable energy technology, segment of the renewables value chain and end-use sector. Broadly speaking, in many countries, a cycle of delays in spring 2020 was followed by great surges of activity later in the year.

Finally,  indications  are  that  employment  in  off-grid  renewables  suffered,  given  that  capacity additions during 2020 were at a considerably lower level than in 2019, and sales of solar home systems and other solar products were at the lowest level since 2015.

These impacts reinforce the importance of a comprehensive policy framework to align short-term recovery needs with long-term decarbonisation pathways, and to ensure steady socio-economic benefits and a just transition. Deployment policies, together with enabling and integrating policies, remain essential to provide an enabling environment in which the energy transition can unfold. Paired with such measures are a set of structural policies to address challenges like fossil fuel dependence and a variety of other commodity and technological dependencies. In addition, a just  transition  package  (including  education  and  skill  training,  labour  market  measures,  social protection, regional development efforts) can help overcome potential misalignments between job losses and gains, generate decent jobs and ensure that the energy industry workforce of the future is reflective of diversity in society offering opportunities for women, youth and minorities.

<!-- image -->

## OUTLOOK FOR ACHIEVING THE 1.5°C GOAL 1.5

While the energy transition has been remarkable to date, progress falls woefully short of what is needed to limit the global temperature rise to 1.5°C by 2050. Trends to date have shown the way towards a decarbonised sector in 2050 and offered some insight into potential socio-economic impacts. But they have had little or no effect on rising emissions. Despite clear evidence of humancaused  climate  change,  widespread  support  for  the  Paris  Agreement,  and  the  prevalence  of clean, economical and sustainable energy options, energy-related carbon dioxide (CO ) emissions 2 increased 1.3% annually, on average, over the period 2014 to 2019. While 2020 was an outlier due to the pandemic - energy-related CO  emissions declined by 5.8% - a rebound looks very likely, at least 2 in the short term (IEA, 2021a).

Holding the line at 1.5°C  means both reaching net zero emissions by 2050 and ensuring a rapid decline in emissions, beginning now (Figure 1.10).

Under IRENA's 1.5°C  Scenario,  process-  and  energy-related  cumulative  CO   emissions  from  2021 2 to  2050 would result in nearly 500 gigatonnes of carbon dioxide (GtCO ). In alignment with the 2 Intergovernmental Panel on Climate Change's report on limiting global warming to 1.5°C by 2050 (IPCC,  2018),  IRENA  plots  the  way  to  a  steep  and  continuous  downward  trajectory  towards  a 45% decline in carbon dioxide (CO ) emissions by 2030 and net zero by 2050. To get there, it is 2 imperative that land-use-related emissions decline and then go negative in the years leading up to 2050 so that the overall burden on the remaining carbon budget is at least neutral.

For the moment, however, the speed of the energy transition is far from what is needed to stay in line with the Paris Agreement. Policies presently in place 3  - referred to here as the Planned Energy Scenario  -  would  merely  stabilise  global  emissions,  with  a  slight  drop  towards  2050.  Overall, the pace of future projections indicated in the Planned Energy Scenario falls far short of what is needed for a 1.5°C limit. The time dimension is crucial, and a radical shift is required, starting today, based  largely  on  readily  available  renewable  energy  and  energy  efficiency  technologies  that can be scaled up now.

- 3 Based on governments' current energy plans and other planned targets and policies, including the first round of Nationally Determined Contributions under the Paris Agreement (as of 2019).

<!-- image -->

## FIGURE 1.10     Projected trends in global CO  emissions under three scenarios, 2020-2050 2

<!-- image -->

Based on IRENA's analysis.

Note: The blue shaded areas in the figure represent the remaining net CO  emissions in corresponding sectors in 2 the  1.5°C  Scenario  and  the  grey  area  represents  the  reductions  in  CO   emissions  in  the  1.5°C  Scenario  compared 2 to  the  PES.  Industry  includes  energy  and  process-related  CO   emissions.  International  bunkers  are  included  in 2 transport emissions. Others include emissions from non-energy uses and other sectors such as agriculture, forestry, etc. Emissions in industry and power and heat generation plants include CO  emissions captured by carbon removal 2 measures such as bioenergy with carbon capture and storage. As a result, towards 2050, these two sectors become net negative, i.e. , the CO  captured more than compensates remaining CO  emissions in those sectors. Overall, the net 2 2 CO2 emissions in the 1.5°C Scenario in 2050 would reach -0.4 Gt. GtCO /yr = gigatonnes of carbon dioxide per year; 2 PES = Planned Energy Scenario.

In the Planned Energy Scenario annual emissions reach 36.5 GtCO  in 2050. 2 For the 1.5°C Scenario, emissions need to drop to net zero by 2050.

Under the Planned Energy Scenario, annual emissions reach 36.5 GtCO  in 2050. To achieve the 2 1.5°C  Scenario,  emissions  would  have  to  drop  to  net  zero  in  all  sectors.  Additional  efforts  in sectors such as power, heat and industry would be needed, with negative emissions delivering the necessary additional carbon reductions.

Aligned with the IPCC's special report on limiting global warming to no more than 1.5°C by 2050 (IPCC,  2018),  IRENA's  1.5°C  Scenario  starts  with  the  goal  of  reducing  global  CO   emissions  by 2 following  a  steep  and  accelerated  downward  trajectory  from  now  to  2030  and  a  continuous downward trajectory thereafter, reaching net zero by 2050. Because the energy sector is currently responsible for around 80% of anthropogenic CO  emissions, it has a central role to play in delivering 2 the required decarbonisation.

This is achievable but extremely challenging, requiring urgent action on multiple fronts. Fossil fuel use would have to decline by more than 75% by 2050 (Figure 1.11). Fossil fuels would still have roles to play, mainly in power and to an extent in industry, providing 19% of the primary energy supply in 2050. Oil and coal would drop the fastest, while natural gas would peak around 2025 and decline thereafter. The global production of oil in 2050 is expected to be 85% lower than today. Most of it would be used in industry for petrochemicals (non-energy uses, close to 40%), and in aviation and shipping. Coal production would decline even more drastically, from around 5 750 million tonnes in  2018  (160  exajoules  [EJ])  to  240  million  tonnes  per  year  (7  EJ)  in  2050.  In  the  power  sector, coal generation would be cut in half by 2030, in half again by 2040 and phased out by 2050. The remaining coal demand would be largely restricted to industry, mostly for steel production (coupled with carbon capture and storage) and to a certain extent in chemicals production.

Natural gas would be the largest remaining source of fossil fuel in 2050, making up 70% of total fossil fuel supply and 13% of total primary energy supply (down from 26% in 2018). In 2050, natural gas  would  primarily  be  used  in  industrial  processes,  blue  hydrogen  production  (coupled  with carbon capture and storage) and power plants.

<!-- image -->

Fossil fuel companies could more speedily shift to investing in clean energy technologies as part of their business models. Staying under 1.5°C implies that current fossil fuel investment must be halved in the coming years and decades. Planning must begin now to minimise the impact of significantly lower fossil fuel demand on the sector and related services. Indicating the importance of urgent action, IRENA (2019d) estimates that, in a pathway towards a 2°C limit, the value of assets stranded in the upstream fossil fuel sector would total USD 3.3 trillion by 2050. Delaying action could cause this value to rise to an alarming USD 6.5 trillion by 2050 - almost double. Planning in advance also supports a just transition, assisting in the reallocation and creation of jobs and services.

With  accelerated  uptake  of  renewables,  fossil  fuel  use  would  drop  significantly  from  almost 487 EJ in 2018 to 112 EJ in 2050. This implies that only a quarter of today's fossil fuel demand would remain by 2050.

## FIGURE 1.11     Primary supply of fossil fuels (exajoules), 2018 to 2050, under the 1.5°C Scenario

## Fossil fuels primary supply (EJ)

<!-- image -->

Based on IRENA's analysis.

Fossil fuel use would have to decline by more than 75% by 2050.

## CONCLUSION 1.6

Climate  change,  energy  security,  energy  access  and  air  pollution  have  placed  a  renewablesbased energy transition at the forefront of the national, regional and global discourse. Addressing those  problems  using  renewables  will  be  indispensable  if  policy  makers  are  to  limit  the  global temperature  rise  to  1.5°C  by  2050,  with  net  zero  CO   emissions.  Fortunately,  renewables  are 2 increasingly the lowest-cost source of electricity in many  markets,  capping  a  remarkable decade  of  change  for  renewables-based  generation  of  electricity,  during  which  the  cost  of utility-scale  solar  PV,  for  example,  fell  by  85%.  The  momentum  of  renewable  energy  is  further demonstrated by its resilience in the face of the COVID-19 pandemic.

Falling costs  have  prompted  a  substantial  rise  in  capacity,  to  the  point  where  renewable power  technologies  now  dominate  the  global  market  for  new  generation  capacity.  To  meet  the challenges  posed  by  greater  shares  of  solar  and  wind  energy  in  the  power  mix,  rapid  advances have been made in digital technologies, battery storage, and new business models.

Policy instruments have evolved apace, with competitive pricing quickly overtaking administratively determined tariffs. The number of countries adopting renewable energy auction  schemes  increased  from  16  in  2010  to  109  in  2020,  driving  down  the  average  price  of solar  energy.  The  number  of  countries  with  renewable  energy  policies  has  grown  as  well. In 2019, 143 countries had policies for renewables in the power sector compared with 117 in 2014.

<!-- image -->

Climate change, energy security, energy access and air pollution have placed the energy transition at the forefront of the national, regional and global discourse.

In  2020,  investment  in  the  global  energy  transition  hit  a  record  high.  Investments  in  electrified transport are also on the rise, as policies supporting the electrification of transport gain traction. Policies for the use of renewables in heating and cooling have received less attention, though signs of progress are abundant.

Despite  their  growth  overall,  renewable  energy  investments  remained  concentrated  in  a  few regions and countries. The Asia-Oceania region, led by China, regularly attracts the largest share of renewable energy investment (on average, 55% during 2005-2019). Europe and the United States follow,  with  average  shares  of  20%  and  16%,  respectively,  during  2005-2019. Regions dominated by  developing  and  emerging  economies  remained  consistently  under-represented,  attracting only  about  15%  of  global  investments.  Yet,  annual  financial  commitments  to  off-grid  renewables supporting  energy  access  in  emerging  and  developing  countries  reached  USD  460  million  in 2019, up from only USD 6 million in 2008.

Overall,  most  renewable  energy  financing  is  provided  by  the  private  sector  -  86%  in  2013-2018. Private  capital  came  mainly  from  project  developers  (46%)  and  commercial  financial  institutions (22%). To date, conservative institutional investors have provided only a small share of financing, though this is expected to change as the perceived risks of investment in renewables fall.

Although public finance accounts for only 14% of total direct investments in renewable energy assets,  considerable  public  resources  are  spent  to  create  an  enabling  environment  for  the deployment  of  renewable  energy  through  the  promulgation  of  regulatory  instruments,  fiscal incentives, and other policies and measures. Public financing resources are crucial to lower risks, overcome initial barriers, attract private investors and bring new markets to maturity. As such, they play an especially vital role in emerging and developing countries where, aggravated by the COVID-19 crisis, investors' risk perception is comparatively high.

The time dimension is crucial and a radical shift is required based on readily available renewable energy and energy efficiency technologies that can be scaled up now.

The  progress  achieved  in  deploying  renewable  energy  has  yielded  impressive  socio-economic benefits over the past several years, notably job gains all along the value chain. Most of the new jobs are found in the countries that are the leading markets for the installation and manufacture of  renewables-related  equipment.  But  employment  is  also  being  created  in  construction  and  in operations and maintenance across a wide range of countries.

The full impact of the COVID-19 pandemic on employment in renewable energy is not yet known, but renewable energy fared well compared with conventional energy. In many countries, a cycle of delays in spring 2020 was followed by great surges of activity later in the year. These impacts reinforce the importance of a comprehensive policy framework to align short-term recovery needs with long-term decarbonisation pathways and to ensure steady socio-economic benefits and a just transition.

Trends to date have shown the way towards a decarbonised sector in 2050 but they have had little or no effect on rising emissions. Indeed, progress still falls woefully short of what is needed to hold the rise in global temperature to 1.5°C by 2050. The time dimension is crucial and a radical shift is  required  based  on  readily  available  renewable  energy  and  energy  efficiency  technologies  that can be scaled up now. IRENA's 1.5°C Scenario starts with the goal of reducing global CO  emissions 2 by  following  a  steep  and  accelerated  downward  trajectory  from  now  to  2030  and  a  continuous downward  trajectory  thereafter,  reaching  net  zero  by  2050.  This  is  achievable  but  extremely challenging, requiring urgent action on multiple fronts, as explored in detail in Chapter 2.

## 02 TECHNOLOGICAL AVENUES TO CLIMATE TARGETS

The Paris Agreement sets out a global framework to avoid dangerous climate change by keeping global warming below 2°C by 2050, while pursuing efforts to limit it to 1.5°C. Taking the agreement as a starting point, IRENA performed an in-depth analysis to identify six components of an energy transition robust enough to meet the 1.5°C climate goal, one that is in line with other energy scenarios and  studies.  These  components  form  the  heart  of  this  inaugural  edition  of  the  World  Energy Transitions Outlook.

Most of  the  technologies  needed  for  an  energy  system  producing  net  zero  emissions  of  carbon dioxide are already available. Although their costs must be further reduced, their deployment can be accelerated through innovations - and it is imperative to ramp up deployment now. Over 90% of the solutions required to meet the 2050 goal involve renewable energy through direct supply, electrification, energy efficiency, green hydrogen, and bioenergy combined with carbon capture and storage (BECCS).

Section 2.1 provides an overview of the 1.5°C Scenario, which represents IRENA's suggested pathway toward the Paris targets. Section 2.2 highlights solutions in key technological avenues to achieve the  1.5°C  climate  future.  Section  2.3  presents  a  comparison  of  energy  scenarios  from  several organisations that have put forward visions of a Paris-complaint energy future.

Most of the technologies needed to reach net zero carbon emissions globally by 2050 are available today. Renewable power, green hydrogen and modern bioenergy will dominate the world of energy in the future.

<!-- image -->

## CONTEXTUALISING THE 1.5°C CLIMATE PATHWAY 2.1

WETO outlines how carbon dioxide (CO ) emissions abatements would be allocated across 2 energy sources, practices, and uses (Figure 2.1) under the 1.5°C Scenario.

## FIGURE 2.1     Carbon emissions abatements under the 1.5°C Scenario (%)

<!-- image -->

| Abatements                                  | 2050   |
|---------------------------------------------|--------|
| Renewables (power and direct uses)          | 25 %   |
| Energy conservation and efficiency*         | 25 %   |
| Electrification in end use sectors (direct) | 20 %   |
| Hydrogen and its derivatives*               | 10 %   |
| CCS and CCU industry                        | 6%     |
| BECCS and other carbon removal measures     | 14 %   |

Note:  Abatement  estimates  include  energy  and  process-related  CO   emissions  along  with  emissions 2 from  non-energy  use.  Renewables  include  renewable  electricity  generation  sources  and  direct  use of  renewable heat and biomass. Energy efficiency includes measures related to reduced demand and efficiency improvements. Structural changes ( e.g. , relocation of steel production with direct reduced iron) and circular economy practices are part of energy efficiency. Electrification includes direct use of clean electricity  in  transport  and  heat  applications.  Hydrogen and its derivatives include synthetic fuels and feedstocks.  CCS  describes  carbon  capture  and  storage  from  point-source  fossil-fuel-based  and  other emitting  processes,  mainly  in  industry.  BECCS  and  other  carbon  removal  measures  include  bioenergy coupled with CCS in electricity, heat generation, and industry.

CCS = carbon capture and storage; BECCS = bioenergy with carbon capture and storage; CCU = carbon capture and utilisation; GtCO  = gigatonnes of carbon dioxide. 2

<!-- image -->

Renewable energy plays a key role in the decarbonisation effort. Over 90% of the solutions in 2050 involve renewable energy through direct supply, electrification, energy efficiency, green hydrogen and bioenergy with carbon capture and storage.

## Renewables, electrification and energy efficiency are the main pillars of the energy transition.

The global energy transition features the synergy of two important actions: (1) the increasing use of low-cost renewable power technologies and (2) the wider adoption of electricity to power end-use applications in transport and heat. Electrification allows for the use of carbon-free electricity in place of  fossil  fuels  in  end-use  applications,  and  significantly  improves  the  overall  efficiency  of  energy service supply. Electric vehicles, for instance, are more efficient than internal combustion engines. Hydropower generation, as well, is more efficient than natural gas generation. This is important as reductions in energy intensity need to be accelerated.

FIGURE 2.2     Renewable and non-renewable share of total primary energy supply in 2018 and 2050, PES and the 1.5°C Scenario (EJ/yr)

<!-- image -->

Renewable

Non-renewable

Note: Data include international bunkers and non-energy use of fuels for the production of chemicals and polymers. 1.5-S = 1.5°C Scenario; EJ/yr = exajoules per year; PES = Planned Energy Scenario; TPES = total primary energy supply.

<!-- image -->

Renewable energy's share of the world's total primary energy supply grows from 14% in 2018 to 74% in 2050 under the 1.5°C Scenario. This requires an eight fold increase in annual growth. Primary supply stabilises during this period due to increased energy efficiency and the growth of renewables.

## Energy efficiency must be scaled up rapidly and substantially to meet the 1.5°C target.

The historical energy intensity improvement rate 1  is far below what is needed. For most of the past decade, energy intensity decreased by about 1.2%/year. In the 1.5°C Scenario, the rate of energy intensity improvement needs to increase to 2.9% per year, nearly two and a half times the historical trend. The energy intensity of the global economy would decline by over 60% as a result.

Energy efficiency technologies and measures are 'ready-to-go' solutions, available for significant scale-up now. Energy intensity improvement can be driven by a wide range of technologies and approaches, including electrification, adoption of renewable energy generation such as solar and wind, technical efficiency improvements, and structural and behavioural changes.

A key step is the deployment of energy efficiency measures that improve technical efficiency, such as more efficient boilers, air conditions, motors and appliances. These would contribute about 38% of  the  reductions  needed  in  the  1.5°C  Scenario  to  meet  the  energy  intensity  improvement  goal (corresponding to 0.65 pp per year out of the 1.7 pp per year increase needed to bring the current 1.2%/year up to 2.9%/year).

Electrifying  end-use  sectors  using  renewable  power  leverages  synergies  with  energy  efficiency measures  and  brings  additional  energy  intensity  improvements.  One  reason  is  that  solar,  wind and hydropower plants produce electricity that has minimal energy conversion losses (and energy intensity is based on primary energy) compared to the use of fossil fuels for electricity generation.

- 1 For this indicator, energy efficiency is defined as the ratio between the primary consumption of energy and GDP. The indicator is expressed as a change in the ratio in the compound annual growth rate of energy intensity of GDP measured in purchasing power parity (PPP) terms.

Also, electric vehicles and heat pumps are much more efficient than comparable fossil-fuel-based systems.  Increased  electrification  reduces  growth  in  overall  primary  energy  use  if  supplied  by renewable power, and allows a given amount of renewable energy to yield a higher percentage share in the energy system at the same time. This important synergy between renewable energy and energy efficiency is often overlooked and can be leveraged to address dual mandates of increasing efficiency while increasing renewable shares (IRENA, 2017).

Thus, a combination of the large-scale adoption of renewable energy technologies outlined in the 1.5°C Scenario combined with high levels of electrification result in the largest increase in the rate of energy intensity improvement. Just under 18% of the improvement (0.3 pp per year) comes from the  use  of  renewable  energy  technologies  such  as  solar,  wind  and  hydro  to  supply energy for electricity and heat, as well as a shift from traditional uses of bioenergy to modern forms of renewable energy. The largest improvement, making up over 40% (0.7 pp per year), comes from electrification, such as electric vehicles in road transport and heat pumps for heating and cooling applications. In total, the combination of renewable energy and electrification makes up just under 60% of the improvement needed to achieve the scenario's energy intensity goal.

An important contribution will also come from structural and behavioural changes providing just under 10% of the needed efficiency improvement (0.15 pp per year). Circular economy principles will  play  an  increasingly  important  role  in  forthcoming  decades,  furthering  reductions  in  energy consumption and increases in the efficiency of resource use, as well as improvements in material efficiency in industry due to innovations. Advanced digital and communication technologies with enhanced connectivity make it possible to optimise the transport of heavy goods (e.g., as efficiency enhancements in traffic control reduce the overall energy consumed by freight). Technology shifts can also lead to the relocation of industrial processes, for instance, the shift from traditional carbon and  energy-intensive  steel  production  methods  to  green  steel  production  methods  with  green hydrogen. Electric arc furnaces could enable a wider relocation of the iron and steel sector to places where relatively low-cost and abundant renewable electricity sources are available. Such shifts could also have geopolitical and global economic implications.

Fossil fuels are still consumed in the 1.5°C Scenario, and the resulting CO  will need to be captured 2 and sequestered. This process is energy intensive, pushing up energy demand. This carbon capture and storage (CCS) 'penalty' reduces the energy intensity improvement by about 0.1 pp per year.

<!-- image -->

## FIGURE 2.3     Energy intensity improvement rate and contributions, by category, historical and under the 1.5°C Scenario, 2018 to 2050

<!-- image -->

1.5-S

Note: The categories listed represent aggregate sums of measures. 'Renewables induced efficiency gain' refers to energy intensity improvements achieved through the deployment of renewable technologies in the power sector (wind, solar PV, etc.) and in end-use direct applications (solar thermal, switching from traditional use of bioenergy to  modern  renewables,  etc.).  'Technical  efficiency  measures'  include  efficiency  measures  deployed  in  industry, buildings and transport sectors ( e.g. ,  improving insulation of buildings; more efficient appliances, motors, etc.). 'Electrification' denotes electrification of heat and transport applications such as through heat pumps and electric vehicles. 1.5-S = 1.5°C Scenario; CCS = carbon capture and storage; RE = renewable energy.

In the 1.5°C Scenario, the rate of energy intensity improvement needs to increase to 2.9% per year, nearly two and a half times the historical trend, causing the energy intensity of the global economy to fall over 60%.

<!-- image -->

## FIGURE 2.4     Breakdown of total final energy consumption (TFEC) by energy carrier in 2018 and 2050 (EJ) in the 1.5°C Scenario

<!-- image -->

<!-- image -->

Note: The figures above include only energy consumption, excluding non-energy uses. For electricity use, 25% in 2018 and 90% in 2050 are sourced from renewable sources; for district heating, these shares are 9% and 90%, respectively; for hydrogen (direct use and e-fuels), the renewable energy shares ( i.e. , green hydrogen) would reach 66% by 2050. The category 'Hydrogen (direct use and e-fuels)' accounts for total hydrogen consumption (green and blue) and other e-fuels (e-ammonia and e-methanol). Electricity (direct) includes all sources of generation: renewable, nuclear and fossil fuel based. 1.5-S = 1.5°C Scenario; EJ = exajoule.

By 2050, electricity would be the main energy carrier with more than a 50% direct share of total final energy consumption - up from 21% in 2018. By 2050, 90% of total electricity needs would be supplied by renewables followed by 6% from natural gas and the remainder from nuclear.

T

## ACHIEVING CLIMATE TARGETS UNDER THE 1.5°C SCENARIO 2.2

## 2.2.1 Renewable-powered electrification

Electricity  generation  must  expand  three  fold  by  2050,  with  renewables  providing 90% of the total electricity supply.

To  advance  the  energy  transition  at  the  pace  and  scale  needed  would  require  almost complete  decarbonisation  of  the  electricity  sector  by  2050.  The  transition  features  an important synergy between increasingly affordable renewable power technologies and the wider adoption of electric technologies for end-use applications, especially in transport and heat. Accelerated deployment of renewable power technologies driven by electrification of  end-use  application  alone  would  lead  to  almost  6  gigatonnes  (Gt)  of  CO   emissions 2 mitigated in the 1.5°C Scenario compared to the Planned Energy Scenario (PES) in 2050.

In the 1.5°C Scenario, rapid electrification of end-use applications along with the rise of green hydrogen production drive increased electricity demand. By 2050, electricity generation  triples  compared  to  the  2018  level,  and  renewables  supply  90%  of  total electricity by 2050, up from 25% in 2018. Natural gas 2  (around 6%) and nuclear (around 4%) provide the remainder. Wind and solar PV lead the transformation, supplying 63% of total electricity  needs  by  2050;  other  mature  renewable technologies ( e.g. ,  hydro,  bioenergy, geothermal) and emerging renewable technologies ( e.g. , concentrating solar power, ocean energy) also play important roles to decarbonise the world's electricity supply. This rise is accelerated by declining costs: during their lifetime, three-quarters of onshore wind and 40% of utility-scale solar PV commissioned in 2019 produced electricity cheaper than any fossil-fuel alternatives, while three-quarters to four-fifths of the onshore wind and utilityscale solar PV commissioned in 2020 from auctions or tenders had prices lower than the cheapest new fossil-fuel-fired option. 3

- 2 In  the  power  sector,  natural  gas  would  have  a  role  in  managing  demand  fluctuations  and  providing operational reserves.
- 3 Based on IRENA's renewables cost database: www.irena.org/costs.

The  installed  generation  capacity  of  renewable  power  will  need  to  expand  from  over 2 800 gigawatts (GW) in 2020  to over 27 700 GW in 2050, about a ten fold increase. 4 In annual terms, this requires more than 840 GW of new renewable capacity additions every year, up from around 264 GW added in 2020. Solar PV and wind (onshore and offshore) would lead the way; the installed capacity of solar PV power would reach over 14 000 GW and of wind (onshore and offshore) over 8 100 GW by 2050. Hydropower, biomass, geothermal, concentrating solar power and ocean technologies account for the remaining renewable energy expansion.

## FIGURE 2.5     Electricity generation and capacity by source, 2018 and 2050 (TWh/yr and GW) in the 1.5°C Scenario

<!-- image -->

Note: 1.5-S = 1.5°C Scenario; CSP = concentrating solar power; GW = gigawatts; PES = Planned Energy Scenario; PV = photovoltaic; RE = renewable energy; TWh/yr = terawatt hours per year; VRE = variable renewable energy.

- 4 Based on IRENA's Statistics:   www.irena.org/Statistics.

<!-- image -->

Electricity generation would grow three fold in 2050 and the share of renewables would rise to 90%. The remaining 10% of total electricity generation would be supplied by natural gas (6%) and nuclear (4%). Following a sharp decrease in coal generation over the current decade, by 2040 coal generation would be a quarter of today's level and eventually would be phased out by 2050.

To meet the 1.5°C target, no additional new coal units should be built, and the phase-out of existing ones must start now. Coal would have to be completely phased out by 2050. Nuclear power is expected to remain at an equivalent level as today. Natural gas, owing to its dispatchability, would retain a role in managing supply and demand fluctuations and in contributing to system adequacy, where  hydropower  and  hydrogen  for  electricity  generation  are  not  available.  Integrated  energy planning and governance are key, involving system operators, energy planners, regulators, market authorities and utilities. These stakeholders should adjust codes, regulations and strategies along with needed resources. Financial markets and funds must increase shares of renewable energy in their portfolios and divest from fossil fuel investments, since meeting a 1.5°C target will have drastic implications for the business cases of these old technologies. Tax regimes, trade agreements and financial regulation must be conducive to the rapid scale-up of investment in renewable energy and energy efficiency.

Electricity generation must expand three fold by 2050, with renewables providing 90% of the total electricity supply.

The flexibility of power systems is a key enabler for integrating very high shares of VRE - the backbone of the electricity system of the future. By 2030, the VRE share in total electricity generation would reach 42%. By 2050, 73% of the installed capacity and 63% of all electricity generation would come from variable resources (solar PV and wind), up from 15% of installed capacity and 7% of electricity generation in 2018. Such a level is manageable with current technologies leveraged by further innovations.

Several countries offer lessons in VRE integration. In 2019, VRE's share of the electricity generation mix in Denmark was over 50% (47% wind and 3% solar PV) (Business Day, 2020); it was over 40% in Lithuania and 34% in Germany (23% wind and 11% solar PV) (Renew Economy, 2019). Systemic innovations  are  needed  that  go  beyond  enabling  technologies  to  encompass  business  models, markets and regulations, and system operations.

IRENA has identified 30 flexibility options that may be combined into comprehensive solutions, taking into account the specifics of national and regional power systems. 5  Moreover, IRENA has been analysing how power systems' organisational structures (including markets) can be redesigned to foster and support renewable-based energy (IRENA, 2020d). As more countries adopt ambitious policy targets of very high or 100% renewables, adopting such a systemic approach to innovation will become more important. The future smart power system, largely based on variable renewables such as solar PV and wind, will require significant investments in power grids and flexibility measures ( e.g. , storage).

## FIGURE 2.6     Emerging innovations that support the integration of VRE

<!-- image -->

Based on IRENA (2019a).

- 5 The innovation toolbox was developed in IRENA's (2019a) study, Innovation Landscape for a Renewable-Powered Future: Solutions to Integrate Variable Renewables.

<!-- image -->

IRENA has identified 30 innovations that support the integration of wind and solar PV in power systems. Innovations need to be combined as there is no 'one-size-fits-all' solution and these need to be tailored to specific power systems.

On a technology level, both long- and short-term storage will be important for adding flexibility. The amount of stationary battery storage (which excludes electric vehicles) would need to expand from  around  5  gigawatt  hours  (GWh)  in  2018  to  over  16 000  GWh  by  2050.  When  the  battery storage  available  to  the  grid  from  electric  vehicle  fleets  is  included  (assuming  an  approximate availability factor for arbitrage), this value will increase by over 25 000 GWh to about 42 000 GWh. The  production  of  a  very  large  volume  of  hydrogen  from  renewable  power  in  combination  with hydrogen storage can help provide long-term seasonal flexibility starting from 2030 onwards and would provide an estimated storage capacity of 2 000 TWh by 2050). Flexibility will also be provided through  additional  measures,  including  grid  expansion  and  operational  measures,  demand-side flexibility,  power-to-heat  and  other  sector  coupling.  Smart  solutions,  such  as  smart  charging  of electric vehicles, can greatly facilitate the integration of VRE by leveraging storage capacity and the flexibility potential of the demand side. Such solutions may include the following.

- · Electricity storage technologies are a critical enabler for integrating large shares of VRE into power systems, facilitating the acceleration of the energy transition through rapid and scalable deployment and efficient provision of ancillary services, with the ability to be located virtually anywhere in the grid. Storage solutions include those offered by hydrogen, pumped hydro and batteries (including the use of electric vehicle batteries at the end of their useful lives) along with hydro,  biomass  and  concentrating  solar  power  thermal  storage.  These  may  be  supported  by digitalisation, smart communication and pricing solutions. Regulatory innovation is also essential to accommodate higher shares of VRE using storage, such as in the design and implementation of novel market mechanisms to appropriately value the essential services they provide to the system.

<!-- image -->

For  example,  as  an  alternative  to  physical  upgrades  to  the  infrastructure  needed  for  the  grid integration  of  VRE  sources  ( e.g. ,  solar  and  wind),  non-wire  alternatives,  such  as  utility-scale batteries connected at electricity transmission systems (also called virtual power lines) are being rolled out in several parts of the world. To make these economically attractive, market design should enable them to provide and be rewarded for a range of services including storage to reduce congestion, which would help to defer network investment, as well as ancillary and balancing services, such as frequency and voltage regulation that would support the reliable operation of the system (IRENA, 2020e).

- · Managing the loads from end-use sectors and promoting self-consumption, via distributed renewable energy sources, would help in enhancing demand-side flexibility and minimising the overall cost of system operation. Grid expansion and reinforcement would be needed; grid codes need to be updated, and security criteria reviewed and enhanced to secure the better use of the grid. One way to accomplish these tasks is through the more dynamic application of network studies especially contingency analysis that can guarantee network security. It is crucial to expand the application of solar PV distributed solutions, moving beyond rooftop solar to consider the options of floating solar PV, embedded batteries and solar cells in appliances, buildings, street lights and other innovative applications.

As  the  distinction  between  power-generating  and  power-consuming  grid  users  blurs,  it  is particularly important to specify technical requirements in grid codes (Inês et al. , 2020), as well as  for  battery  storage,  solar  PV  and  battery  combinations,  micro  combined  heat  and  power (CHP)  generators,  flywheels  and  any  other  combined  consumer-producer  connection.  For example, Germany's guidelines for the low-voltage connections of distributed energy resources distinguish among facilities for consumption, generation, storage and electric vehicle charging. At medium- and higher-voltage levels, there is an additional category for mixed facilities that combine assets of multiple types (VDE FNN, 2018). One type of storage and flexibility service that deserves special mention is electric vehicle charging, because the actual storage units are not permanently connected to the facility, and the implemented functionality does not necessarily include  discharging  and  exporting  active  power  into  the  power  system.  This  implies  that  grid operators need to have the technical capacity to monitor and manage so many distributed system elements.

- · Another priority is to develop innovative and alternative ways to reduce material use and reuse and recycle components such as PV panels, wind turbines, batteries and electrolysers at the end of their lifetime (IRENA and IEA-PVPS, 2016).
- · BECCS will also be necessary to offset the remaining emissions in power and other sectors , even as renewable capacity expansion occurs over time and coal generation is eventually phased out (by 2050).
- · Beyond technologies, innovation is needed in policies, regulations, trade agreements and business models. Attention needs to be focused on the creation of a new market niche - the management of information and its security via smart devices - that is likely to attract investors. An energy services approach would best support the scaling up of energy efficiency measures.

<!-- image -->

Electricity generation must expand three fold by 2050, with renewables providing 90% of the total electricity supply.

By  2050,  electricity  will  become  by  far  the  most  important  energy  carrier. Under  the  1.5°C Scenario, electricity consumption in end-use sectors would more than double compared to 2018, reaching 50 000 TWh by 2050. Transport and hydrogen production will emerge as significant new electricity markets. In addition, around 20 770 TWh would be needed to produce hydrogen by 2050. The direct electrification share of final energy consumption (which includes direct use of electricity but excludes indirect uses such as e-fuels) would reach 30% by 2030 and exceed 50% by 2050, up from just over 21% in 2018. The use of green hydrogen and green-hydrogen-based carriers (such as ammonia and methanol) as fuels, would reach almost 2% in 2030 and 7% in 2050 from negligible levels today. In total, direct and indirect electrification would reach 58% of final demand.

The buildings sector would see the highest direct electrification rates, reaching 73% compared to 32% in 2018. A rise would also be observed in the industry sector, where the direct electrification rate  would  be  35%  by  2050,  up  from  26%  in  2018  (including  indirect  electrification,  this  would approach  40%  by  2050).  For  decarbonising  some  heat  applications,  the  total  number  of  heat pumps would rise close to nine fold, exceeding 180 million by 2030 and close to 400 million by 2050 compared to around 20 million installed in 2018. More details on the technology components and pathway to decarbonise the buildings sector can be found in the annex of this report.

Electricity dominates final energy consumption either directly or indirectly, in the form of hydrogen and other e-fuels such as e-ammonia and e-methanol. Around 58% of final energy consumption in 2050 is electricity, green hydrogen and its derivatives. By 2050, electricity would be the main energy carrier with over 50% direct share in total final energy use, a rise from 21% today.

## FIGURE 2.7     TFEC split by direct electricity and the use of green hydrogen and its derivative fuels, 2018 and 2050, in PES and the 1.5°C Scenario (EJ/yr)

<!-- image -->

Note: '7%' in 2050 in the 1.5°C Scenario (1.5-S) corresponds to green hydrogen and its derivatives. In addition, around 11 EJ of green hydrogen would be needed for non-energy uses in 2050 (1.5-S), which is not represented in this figure. EJ = exajoules; PES = Planned Energy Scenario; TFEC = total final energy consumption.

Transport would see the most accelerated electrification in the coming decades with the share of electricity reaching 49% in 2050, up from just 1% in 2018. The stock of electric cars would rise from 10 million in 2018 to over 380 million by 2030 and 1 780 million by 2050; the stock of electric trucks would rise to 28 million by 2050. Electric vehicles would account for more than 80% of all road transport activity by 2050 (88% of the light-duty vehicles stock and 70% of heavy-duty vehicles). This  massive  electrification  in  transport  will  be  driven  by  technological  progress  -  markedly  the evolution of batteries and battery production processes - that has greatly improved the economic case  for  electric  vehicles  in  recent  years  and  is  quickly  expanding  the  scope  of  application  to  a broader set of road vehicle segments and types of services. If the ongoing cost reduction trends can be sustained, by 2050, the bulk of global road transport services could be delivered cost-effectively with electric technologies. More details on the technology components and pathway to decarbonise the transport sector can be found in the annex of this report.

<!-- image -->

## FIGURE 2.8     Electricity consumption by sector, 2018, 2030 and 2050 (TWh/yr) in the 1.5°C Scenario

## Electricity consumption (TWh)

<!-- image -->

Note: Electricity use for green hydrogen is not included in the figure. By 2050, close to 21 000 TWh of electricity would be needed for green hydrogen production. 1.5-S = 1.5°C Scenario; TWh = terawatt hours.

*Others includes electricity consumption via carbon capture and storage (CCS).

Electricity demand more than doubles in 2050 compared to 2018. The use of electricity in industry and buildings double to over 12 800 TWh and 21 300 TWh, respectively and in transport it grows from nearly zero to over 12 700 TWh.

## 2.2.2 Green hydrogen

## Hydrogen and its derivatives will account for 12% of final energy use by 2050.

As global economies aim to become carbon neutral, competitive hydrogen and synthetic fuels derived from hydrogen (such as ammonia, methanol and kerosene) emerge as key components of the energy mix. Hydrogen can help to achieve net zero CO  emissions in energy-intensive, hard2 to-decarbonise sectors like steel, chemicals, long-haul transport, shipping and aviation. It can also play fundamental roles in balancing renewable electricity supply and demand by absorbing shortterm  variations  as  well  as  acting  as  an  option  for  long-term  storage  to  help  balance  renewable variability  across seasons. In IRENA's 1.5°C Scenario, green and blue hydrogen production grows from negligible levels today to over 74 exajoules (EJ) (614 million tonnes) in 2050. In this context, hydrogen needs to be low carbon from the outset and ultimately green (produced by electrolysis of water using renewable electricity). But production costs must be cut to make it economical for countries world wide. Green hydrogen currently costs between two and three times more than blue hydrogen, which is produced using fossil fuels in combination with CCS. Falling renewable power costs and improving electrolyser technologies could make green hydrogen cost competitive by 2030.

By 2050, 30% of electricity use will be dedicated to green hydrogen production and hydrogen and its derivatives such as e-ammonia and e-methanol. Hydrogen and its derivatives together will account for about 12% of total final energy use. To produce this, almost 5 000 GW of hydrogen electrolyser capacity will be needed by 2050, up from just 0.3 GW today.

FIGURE 2.9     Hydrogen production costs resulting from low and high electricity cost   assumptions

<!-- image -->

Based on IRENA (2020f).

Note:  A  combination  of  cost  reductions  in  electricity  and  electrolysers,  combined  with  increased  efficiency  and operating lifetime, can deliver 80% reduction in green hydrogen cost. kg = kilogramme; MWh = megawatt hour.

C

H

<!-- image -->

Green hydrogen can be produced at costs competitive with blue hydrogen by 2030, using low-cost renewable electricity.

Hydrogen will offer a solution to industry and transport needs that are hard to meet through direct electrification, mitigating close to 12% and 26% of CO  emissions, respectively, in the 1.5°C Scenario 2 compared to  the  PES.  Today,  around  120  metric  tonnes  (Mt)  (14  EJ)  of  hydrogen  are  produced annually but almost all of this comes from fossil fuels or from electricity generated by fossil fuels, with a high carbon footprint - less than 1% is green hydrogen. As electrolyser costs fall, combined with further reductions in renewable electricity costs, green hydrogen will be less expensive than the estimated cost of blue hydrogen in many locations within the next 5 to 15 years (IRENA, 2020f). In the 1.5°C Scenario, by 2050, there will be a demand for 613 Mt (74 EJ) of hydrogen, two-thirds of  which  will  be  green  hydrogen.  The  electricity  demand  to  produce  hydrogen  will  reach  close to  21 000  town  by  2050,  almost  the  level  of  global  electricity  consumption  today.  This  requires significant scale-up of electrolysers' manufacturing and deployment. Around 160 GW of electrolysers need to be installed annually on average up to 2050. The installation rate will start growing from a few gigawatts added per annum in the coming years and eventually ramp up from 2030 onwards, exceeding 400 GW per annum by 2050.

## Priorities for technological innovation

At  present,  hydrogen is  used  at  scale  only  in  the  industrial  sector.  Unlocking  its  potential  across the entire energy system will require demonstration before scaling up. Some pathways, like steel production with pure hydrogen, require years of research before they reach the demonstration scale. Some parts of the hydrogen value chain are not yet cost competitive but are already deployed on a commercial scale. For instance, there are currently over 4 500 kilometres (km) of hydrogen pipelines, over 35 000 forklifts and over 25 000 passenger and commercial vehicles. Furthermore, hydrogen is already commonly used as industrial feedstock in chemical complexes and refineries. Some of the pathways and technologies that need further research are:

- · Electrolysis  integration  with  ammonia and liquid synthesis. These  processes  are  mature  but have been deployed separately so far; their integration remains to be demonstrated. Plant flexibility, design optimisation and operation need to be studied further. NEOM, a 2 GW electrolyser project in Saudi Arabia with a targeted start date in 2025, aims to demonstrate this concept.

- · Fuel  cells  for  trucks. 6 Trucks  have  higher  durability  requirements  (meaning  more  hours  of operation and cycles per year) than cars. This translates into more rare materials and a higher cost. Research is needed to achieve that high performance and durability, while still maintaining a low-cost premium for the fuel cell. This would require novel stack materials, such as catalysts, membranes and electrodes.
- · Direct reduction of steel. This pathway is at the pilot scale today; the most advanced project is HYBRIT in Sweden aiming to have a demo plant by 2025 (HYBRIT, 2021). The direct reduction of steel is already being accomplished today based on natural gas but further research is needed to  understand the operation of the shaft furnace with pure hydrogen (instead of syngas) and the  effect  on  physical  (hydrogen  embrittlement,  tumble,  fines)  and  metallurgical  (reducibility, metallisation, carbon) properties of the product (Ripke, 2017).
- · Ammonia-fuelled  ships. Ammonia  could  be  used  in  either  fuel  cells  or  internal  combustion engines.  MAN ES,  the  largest  marine  engine  manufacturer  in  the  world,  plans  to  develop  the first  ammonia-fuelled engine by 2024 (The Motorship, 2020). More than 50 research projects are  underway  looking  at  ammonia  use  in  reciprocating  engines.  Some  of  the  challenges  are ammonia's slow flame velocity, slow heat release and low flammability. Areas for innovation are the pilot fuel requirement, 7 the use of dual-fuel engines and the reduction of nitrogen oxide (NOx) emissions. Ammonia could also be used in fuel cells but these lack power density and load response capability, are expensive (&gt; EUR 1 500/kilowatt) and are at an early stage of development.
- · Hydrogen  ships. Hydrogen  has  been  used  in  the  fuel  cells  of  ships  in  only  a  couple  of demonstration projects to date, mostly in ferries with up to 600 kW capacity. The current limit for fuel cells is around 2 MW (Trellis et al. , n.d.) which would be enough for a small bulk carrier, but a large container ship can be up to 130 MW (IMO, 2015). Further innovation is needed to scale  fuel  cells  up  for  use  in  bunkering  infrastructure  ( e.g. ,  allowing  more  frequent  refuelling [Mao et al. , 2020]), and to reduce cargo displacement due to fuel storage.
- · High-temperature electrolysis. This  technology  promises  high  efficiency  levels  (&gt;  90%)  and heat integration with exothermic processes characterised by high costs and fast degradation ( i.e. , short lifetimes). Some of the areas where further innovation is needed are the improvement of electrolyte conductivity, optimisation of chemical and mechanical stability, matching the thermal expansion coefficient to both electrodes and ensuring minimal reactant crossover (IRENA, 2020f).
- · Direct air capture (DAC). CO2 is needed for methanol and synthetic fuels and DAC is one of two sustainable carbon sources (along with bioenergy). There are only 15 plants around the world with a cumulative capacity of 9 000 tonnes/year (IEA, 2020c). DAC's energy consumption and cost need to come down, as they are currently in the order of 6-8 gigajoules per tonne of carbon dioxide (GJ/tCO ) and several hundreds of US dollars per tCO . This could be achieved through 2 2 new sorbent materials, an all-electric concept, hybrid designs for heat integration and widening the operating window of the plant to encompass a flexible electricity input (ICEF, 2018)
- 6 Electrification is the main decarbonisation strategy for road freight (70% of activity), but fuel cell electric trucks are still needed to cover part of the balance (13%) by 2050.
- 7 Ammonia has low flammability which makes the use of another fuel necessary. This could be hydrogen obtained from the ammonia itself.

## WORLD ENERGY

## FIGURE 2.10     CO  emissions abatement options in the 1.5°C Scenario compared to PES 2 in the industry, transport and building sectors.

<!-- image -->

Note: Industry includes emissions from energy, process and non-energy uses. International bunkers are included in transport emissions. Renewables include direct use of renewables such as biomass, solar thermal and geothermal. Energy efficiency includes measures related to reduced demand and efficiency improvements. Structural changes ( e.g. , relocation of steel production with direct reduced iron) and circular economy practices are part of energy efficiency. Electrification includes direct use of clean electricity. Hydrogen includes indirect use of clean electricity via synthetic fuels and feedstocks ( e.g. , hydrogen and its derivates). CCS describes carbon capture and storage from point-source fossil-fuel-based  and  other  emitting  processes  mainly  in  industry  and  for  blue  hydrogen  production.  BECCS  and other carbon removal measures include bioenergy coupled with CCS and other measures such as reforestation and other measures in industry. CCS = carbon capture and storage; BECCS = bioenergy with carbon capture and storage; CCU = carbon capture and utilisation; GtCO  = gigatonnes of carbon dioxide; PES = Planned Energy Scenario. 2

In transport, 67% of emission reductions come from direct electrification and hydrogen. In industry, hydrogen and electrification combined contribute 27% of mitigation needs. In buildings, the key solutions are electrification, contributing close to half of the reduction needed, followed by energy efficiency.

Next  to  electricity,  the  direct  use  of  renewables  (bioenergy,  solar  thermal  and  geothermal) would occupy a major share (22%) of total final energy demand by 2050.

Solar  thermal,  geothermal and bioenergy will be needed to provide heat in industrial processes, cooking and space and water heating in buildings, and fuels for transport. In the 1.5°C Scenario the direct use of renewable energy would need to grow to 77 EJ in 2050 compared to 44 EJ in 2018. Bioenergy makes up a large share of renewable energy use today and will remain a significant source of  fuel,  both  in  industry  and  transport.  In  the  1.5°C  Scenario,  the  share  of  final  energy  met  using modern forms of bioenergy increases to 17% in 2050 from around 1.5% in 2018, requiring 153 EJ of primary biomass supply. Priorities for bioenergy include the production of advanced biofuels for aviation, road freight and shipping; the production and use of renewable fuels and feedstock for the chemical industry, and some use for heating in specific industry sub-sectors. In addition, BECCS will be used in power and heat production and some industrial processes ( e.g. ,  cement and chemical production). IRENA's analysis finds that, with care, the level of primary biomass can be harvested sustainably without causing deforestation or other negative land-use changes (IRENA, 2014).

## 2.2.3 Modern bioenergy

Bioenergy,  including  solid  biomass,  biogas  and  biomethane,  and  liquid  biofuels,  would represent 25% of total primary energy supply by 2050 in IRENA's 1.5°C Scenario. That means just over 150 EJ of biomass primary supply, a three fold increase compared to 2018 levels. Without increasing biomass production and use, the 1.5°C climate goal is not achievable.

Biomass  will  be  needed  across  the  energy  system.  In  some  sectors  it  would  play  a  major  role - particularly as feedstock and fuel in the chemicals sectors and as fuel in the aviation sector. In many others it would help address gaps that other options cannot fully resolve, such as the need for biomethane to replace natural gas in buildings that cannot be renovated. Additionally, the use of biomass coupled with CCS in the power sector and some industrial sectors will be critical in delivering much needed negative emissions to achieve the net zero goal.

## WORLD ENERGY

## Given  finite  biomass  resources,  prioritisation  and  cross-sectoral  planning  will  be  important

to  ensure  that  appropriate  biomass  feedstocks  are  available  for  the  appropriate  applications. Innovation  and  scale  are  needed  to  reduce  the  costs  and  diversify  the  sources  of  supply  and broaden production. For example, there is a need to further develop conversion technologies to use alternative feedstocks. However, the biggest challenges will be in scaling up production sustainably, without causing social, environmental or economic harm. The growing examples of good practice in biomass production suggest that this is possible, but regulating and managing its use such that that society can be confident in its sustainability will be challenging.

FIGURE 2.11     Primary bioenergy demand in 2018 and 1.5°C Scenario 2050 (EJ/yr)

<!-- image -->

Note: * The decline in bioenergy use in the buildings sector from 2018 to 2030 is due to the phase-out of traditional biomass uses in favour of modern bioenergy. EJ/yr = exajoules per year; NEU = Non-Energy Uses.

Primary bioenergy demand would grow from around 54 EJ in 2018 to over 150 EJ by 2050. Liquid biofuels consumption would reach 25% of total transport fuel demand by 2050 from 3%. Bioenergy would play an important role in electricity generation, providing thermal energy in industry and in aviation and marine energy supply by 2050.

Bioenergy makes up a large share of renewable energy use today and would remain a significant source  of  fuel  and  feedstock  in  IRENA's  1.5°C  Scenario. Achieving  the  net  zero  goal  will  not be  possible  with  renewable  electricity  and  energy  efficiency  alone;  bioenergy  will  be  needed  to provide heat in industrial processes, cooking and space and water heating in buildings and fuels for transport. Biomass will also be needed as feedstock in the petrochemical industry to produce chemicals and plastics.

In 2050 in the 1.5°C Scenario, the largest single use of biomass is in the power sector, but biomass contributes only a modest share of electricity production (around 13% of the total primary energy supply by 2050). The use of biomass in power is driven in part by the need for the negative emissions that BECCS can provide, and around 60% of the biomass power production will have CCS installed. BECCS will also be used in some heat plants and for some cement and chemical production.

Consistent with earlier IRENA analysis (IRENA, 2014), the required level of 153 EJ of primary biomass in 2050 can in principle be supplied sustainably without causing negative land-use changes. This is around three times the levels of supply in 2018 and at the higher end of the sustainable biomass supply potential estimated by IRENA and other institutions for 2050 (IRENA, 2014, 2016a, 2016b; Faaij, 2018). The challenge to scale up biomass production to those levels, while avoiding adverse environmental  or  social  consequences,  is  significant.  Robust  policy  frameworks  for  regulation, certification  and  monitoring,  and  responsible  sourcing  practices  by  industry  actors  need  to  be put in place globally to ensure that biomass supply is environmentally, socially and economically sustainable.

<!-- image -->

<!-- image -->

## Large untapped potential remains. Options include:

- · Greater use of food crop and forestry residues (while maintaining sufficient residues to enrich the soil and preserve biodiversity);
- · Wood harvesting through sustainable forest management;
- · The use of biogas from agricultural wastes such as manure and from municipal solid waste (which could also reduce emissions of methane); and
- · The use of marginal or contaminated lands on which food production is impractical.

These practices would also deliver economic and social benefits to other parts of the bio-economy. The risk of poor practices remains, but evidence suggests that with sound policies, careful monitoring and control, and further innovation in supply chains the levels of biomass needed can be feasibly and sustainably produced.

## Priorities for technological innovation include the following:

- · Substantial  scope  remains  to  broaden  the  supply  of  sustainable  feedstocks,  refine  conversion technologies,  decrease  production  costs  and  integrate  biomass  into  traditionally  fossil-fueldominated processes.
- · Sustainable  feedstocks  need  to  be  investigated  and  validated,  and  waste-based  feedstock collection  intensified.  Sustainable  options  for  growing  oil-based  energy  crops  as  well  as lignocellulosic conversion pathways for advanced fuels need to be pursued. These might include co-farming with other crops, seasonal (winter) farming, agro-forestry based on short-rotation woody  crops,  growing  on  degraded  lands,  using  land  made  available  by  more  intensified agriculture and using land freed up by reduced waste and losses in the food chain.
- · Drop-in  fuels  are  a  key  component  of  decarbonisation  strategies  for  the  transport  sector because ethanol and conventional biodiesel have limitations on the amount that can be mixed with petroleum fuels. Innovation is needed to reduce the cost of advanced biofuels production, especially for drop-in biofuels.
- · nnovation is also needed in how bioenergy and biofuels are used, in particular, the exploration of I how bioenergy in CCS can be cost-effectively integrated into power and production processes.
- · Beyond technological development, a systemic approach to innovation - one that pairs technology with innovations in regulatory frameworks, business models and systems operation - is critical to successfully scale up biomass use in the energy system.

C

H

## 2.2.4 Carbon capture and removal

Some emissions remain in 2050 from fossil fuel use and industrial processes. There will thus be a  need for both CCS technologies and also CO  removal (CDR) measures and technologies that, 2 combined  with  long-term  storage,  can  remove  CO   from  the  atmosphere,  resulting  in  negative 2 emissions. CDR measures and technologies include nature-based measures such as reforestation as well as BECCS, direct carbon capture and storage (DACCS) and some other approaches that are currently experimental.

## FIGURE 2.12     Amount of CO  (GtCO ) yet to be removed in the 1.5°C Scenario 2 2

## Total cumulative CO2 removals from 2021 to 2050

<!-- image -->

Note: BECCS = bioenergy with CCS; GtCO  = gigatonnes of carbon dioxide. 2

<!-- image -->

## In the 1.5°C Scenario, the role of CCS is limited, targeting process emissions from cement, iron

and steel, hydrogen and chemical production, with a limited deployment for waste incinerators. CCS is not deployed for fossil-fuel-based power production, which would have only a marginal role by 2050. CCU applied to fossil fuel or process emissions would have only a limited role, primarily in the chemical sector. Together the use of CCS and CCU in industry and CCS for fossil-fuel-based hydrogen production expand from 0.04 Gt/year of captured CO  in 2020 to 2.7 Gt/year in 2040 and 2 3.4 Gt/year of CO  in 2050. 2

CCS  &amp;  CCU  technologies  are  in  operational  use,  but,  despite  several  decades  of  development, deployment levels are still very low. As of early 2021, 24 commercial fossil-fuel-based CCS and CCU facilities were in operation globally with an installed capacity to capture around 0.04 Gtpa of energy and process-related CO  emissions. Focused effort will be needed to break from the lethargic pace 2 to date and rapidly ramp up deployments, particularly of BECCS. However CO  capture installations 2 are capital intensive and have long lead times to plan, finance and build and, away from the limited existing facilities,  securing  support  for  and  developing the necessary transportation and storage infrastructure can be complex and slow. Even with strengthened political and commercial support the cumulative impact of CCS &amp; CCU this decade will likely therefore be relatively small and there is a high risk CCS, CCU and BECCS deployments will fall significantly short of the levels needed by 2030.

CDR  technologies,  combined  with  long-term  storage,  can  in  principle  remove  CO   from  the 2 atmosphere, resulting in negative emissions. BECCS is the most established option. Biomass absorbs carbon from the atmosphere as it grows and the use of CCS prevents this carbon from being released back to the atmosphere during final use, usually by storing it below ground. Provided the biomass is sustainably sourced the net result is that CO  is removed from the atmosphere. 2

In  the  1.5°C  Scenario,  the  use  of  BECCS  in  power,  co-generation  plants  and  some  industrial processes (cement, chemicals, pulp mills and potentially others) would require rapid scaleup leading to 2.9 Gt/year of CO  captured and stored in 2040 and 4.7 GtCO  per annum in 2 2 2050, compared to less than 2 million tonnes CO  captured in 2020 from three operational 2 commercial plants. Beyond  BECCS,  other  potential  CDR  technologies  ( e.g. ,  DACCS)  are  mostly at  an  early  experimental  stage.  Since  their  future  potential  is  hard  to  quantify,  their  use  is  not included in the 1.5°C Scenario. As a result of the use of BECCS, in the latter part of the 2040s the power and industry sectors become net negative, i.e. ,  the  CO   captured more than compensates 2 the remaining CO  emissions in those sectors. Overall, the net CO  emissions in the 1.5°C Scenario 2 2 reach -0.4 Gt/year in 2050.

BECCS and CCS are now established but not widely deployed or accepted technologies and the pace  of  progress  in  their  development  and  deployment  in  the  past  decade  has  been  very  slow, much slower than many analysts predicted, with many plans falling by the wayside. If BECCS and CCS are to play an appreciable role in reaching net zero, technical, economic and social acceptance challenges will need to be addressed and the pace of development, validation and uptake will need to be greatly accelerated.

## COMPARISON OF ENERGY SCENARIOS 2.3

Apart from IRENA's energy scenarios various organisations have put forward visions for the future. All of these energy scenarios, including IRENA's, propose larger renewable energy shares in primary supply compared to 2018, with nearly half of them showing lower primary supply, which indicates greater energy efficiency. Also, all result in lower emissions (Box 2.1).

While IRENA's 1.5°C Scenario as presented in this chapter sets a trajectory for the world to reach 1.5°C climate targets by reaching net zero emissions by mid-century, IRENA's Transforming Energy Scenario presents a pathway to stay well below the 2°C Paris climate target. Their solutions are largely similar though with a variation in their rate of acceleration. That said, any reductions beyond the 2°C ambition would need to consider factors such as high abatement costs (e.g., green hydrogen, BECCS); the socio-economic impacts of industry relocation; the implementation of circular economy principles and behavioural change; the availability of certain technologies at commercial scale (e.g., cement CCS, smelt reduction CCS, waste CCS, high-temperature heat pumps for industry &gt;200°C); and the need for complex changes in existing buildings and infrastructure.

The rate of change proposed in this scenario is daunting - much of today's energy infrastructure and capital stock would need to be replaced in the next three decades to translate this vision into a reality. Ultimately, the speed and extent of the movement in this direction will determine the world's progress towards the goals of the Paris Agreement. The world needs to capitalise now on the renewed commitments made by countries and maintain the momentum, taking immediate, collaborative and concrete actions to meet the challenge of climate change (IRENA, 2021d).

<!-- image -->

## WORLD ENERGY

## BOX 2.1     Scenario comparison

Beyond IRENA's 1.5°C Scenario, several other scenarios have been published to explore pathways for  the  energy  transition  in  the  coming  decades.  Their  variation  reflects  the  complexity  and uncertainties  of  the  energy  transition  and  different  approaches  and  assumptions  regarding the  development  of  key  components  such  as  renewable  energy  and  electrification  as  well  as differences in overall carbon budgets.

Two below-2°C scenarios, DNV GL and Equinor, predict a fast transformation of the global energy sector. Though they reach similar electrification shares (35% for DNV GL and 37% for Equinor) by 2050, they have different global-energy-related CO  emissions, 17 gigatonnes (Gt)/year for DNV GL 2 and  10.6  Gt/year  for  Equinor  by  2050.  Among  those  scenarios  claiming  compatibility  with  the

## FIGURE 2.13     Shares of renewables in total primary energy in 2018 and 2050 in various energy scenarios

<!-- image -->

Sources: Shell's 2021 'Sky 1.5' scenario (Shell, 2021); BP's 'Rapid Scenario'(BP, 2020); the 'Below 1.5°C' and 'Above 1.5°C' scenario from the Intergovernmental Panel on Climate Change (IPCC, 2018); Greenpeace's 2015 'Advanced' scenario (Greenpeace, 2015); Teske's 'Achieving the Paris Climate Agreement Goals' (Teske, 2019); Equinor's 'Rebalance scenario' (Equinor, 2020); DNV GL's Energy Transition Outlook 2020 (DNV GL, 2020) and IEA's Net Zero by 2050 (IEA, 2021b).

Note: The figure includes 2018 and 2050 projections from various energy scenarios aligned with Paris climate targets from different institutions. IPCC's (2018) special report on global warming of 1.5°C assessed several energy scenarios from different institutions and aggregated them into two 2°C and three 1.5°C pathway classes. Of these, the assessed 'below 1.5°C' and '1.5°C-low-overshoot' pathways have a mean total primary energy supply equal to 553.23 EJ with a range between 289.02 EJ and 725.40 EJ (derived from the IPCC's SR15 2018 report, page 132, Table 2.6) in 2050. The mean share of renewables in total primary supply in those pathways is 60.24% with a range between 38.03% and 87.89%. For the '1.5°C-high-overshoot' pathway, the mean primary supply is 651.46 EJ (1012.50 EJ, 415.31 EJ) and the share of renewables in primary supply is 62.12% (86.26%, 28.47%). GtCO  = gigatonnes 2 of carbon dioxide; IPCC = Intergovernmental Panel on Climate Change; TPES = total primary energy supply.

Paris climate target of staying under a 2°C temperature rise, the electrification share in 2050 varies substantially as well, from 45% in BP's 'Rapid' scenario to 52% in the Greenpeace 'Advanced' scenario. There  is  however  a  broad  consensus  on  the  central  role  that  renewables  would  play  in  electricity generation with percentages ranging from 72% in Equinor's 'Rebalance' scenario to 90% in IRENA's '1.5-S' scenario. Despite the differences among the energy scenarios, there is a clear consensus on the important role that electrification powered by renewable energy sources has in the decarbonisation of the energy system. With a share of 51% of direct electrification and 58% if green hydrogen and its derivates are included, coupled with 90% of renewables in the power sector in 2050, IRENA's 1.5°C Scenario shows a higher electrification rate than the other scenarios.

FIGURE 2.14     CO  emissions versus electrification rates in various energy scenarios 2

<!-- image -->

Note: The size of the bubbles in the figure and the number indicated beside the scenario description reflect the share of renewables in the power sector in various scenarios. 1.5-S = 1.5°C Scenario; CO  = carbon dioxide; Gt = gigatonne. 2

<!-- image -->

## CONCLUSION 2.4

A net zero carbon future by 2050 may seem a daunting challenge. But IRENA's analysis indicates  that  it  is  feasible.  Achieving  it  will  require  a  massive  ramp-up  of  efforts  on seven fronts:

- 1. The rate of decline in energy intensity must move from the 1.2% recorded in recent years to 3%. Here, renewable power, electrification and circular economy principles have key roles to play, as do conventional energy efficiency technologies.
- 2. Annual growth in renewable energy's share in the globe's primary energy production needs to accelerate eight fold from its share in recent years.
- 3. Renewable  power  generation  capacity  must  grow  from  over  2 800  GW  today  to 27 500  GW  by  2050,  or  840  GW  per  year  and  a  four  fold  increase  in  the  annual capacity additions recorded in recent years.
- 4. Electric  vehicle  sales  must  grow  from  4%  of  all  vehicle  sales  today  to  100%,  with the stock of electric vehicles growing from 7 million in 2020 to 1.8 billion in 2050.

<!-- image -->

<!-- image -->

- 5. Hydrogen demand must increase from 120 Mt to 614 Mt in 2050, a five fold increase. The share of clean hydrogen in overall demand needs to grow from 2% to 100%. Two-thirds of demand would be met by green hydrogen; one-third by blue. Meeting that goal will require the addition of 160 GW of electrolysers each year between now and 2050, from the 2020 base of 0.3 GW of installed capacity.
- 6. The total primary supply of biomass needed to achieve net zero emissions by 2050 would be just over 150 EJ, a near tripling of primary biomass use in 2018. Based on a detailed assessment of the potential supply of sustainable biomass, this appears feasible.
- 7. Carbon capture and storage must grow from 0.04 Gt captured in 2020 to 7-8 Gt in 2050, with BECCS accounting for half for the total amount captured and stored.

All  of  these  challenging  steps  must  be  put  in  place  simultaneously  in  order  to  stay  within  the globe's  carbon  budget.  Such  a  profound  transition  entails  accelerating  the  scale  of  energy investments - starting today - and diverting investments away from fossil fuels towards energy transition technologies such as renewables, energy efficiency and electrification of end uses - plus associated infrastructure. These investment needs are analysed in Chapter 3.

## 03 INVESTMENT NEEDS AND FINANCING FOR THE ENERGY TRANSITION

Funding the energy transition at the pace required to keep the world on a climate-safe pathway will require a substantial increase in investments over their current level and over the level envisaged in governments' current plans. Fortunately, the necessary funding is available in today's capital pools.  The  climate-safe  pathway  will  also  require  a  reallocation  of  capital  towards  sustainable solutions, an even greater activation of the private sector and expanded use of debt financing. The required shifts are entirely achievable. However, policy support in the energy sector and beyond remains crucial to keep the pace of the energy transition on track with global climate goals.

Government plans in place today (outlined in the Planned Energy Scenario, or PES) call for investing almost USD 98 trillion in energy systems over the next three decades. IRENA's 1.5°C Scenario could be  achieved  by  adding  USD  33  trillion  to  the  amounts  already  planned,  for  a  total  investment of USD 131 trillion over the next 30 years. More than 80% of the total - USD 116 trillion through 2050 - needs to be invested in energy transition technologies (excluding fossil fuels and nuclear) such as renewables, energy efficiency, end-use electrification, power grids, flexibility innovation (hydrogen) and carbon removal measures. Cumulative investments of more than USD 24 trillion should  be  redirected  from  fossil  fuels  to  these  energy  transition  technologies  over  the  period to 2050.

On  average,  USD  4.4  trillion  would  be  needed  annually  over  the  period  2021-2050,  more  than double the level of investment in 2019 (USD 2.1 trillion) and a third more than the USD 3.3 trillion per year called for in the PES (BNEF, 2021a; IEA, 2020a; IRENA and CPI, 2020). While the amount of funding needed is large, it represents only about 5% of global gross domestic product (GDP) in 2019 and is well within the current capacity of global financial markets, which reached a volume of some USD 200 trillion in 2019 (World Bank, 2019a; SIFMA, 2020). Global institutional investors alone manage about USD 100 trillion in assets and have so far largely remained on the sidelines of the energy transition (IRENA, 2020g).

Section 3.1 of this chapter details the investment needs, by technology, for a 1.5°C climate pathway, comparing it with current plans (PES). Section 3.2 presents types of funding sources as the energy transition goes through stages of the technology revolution. It describes the key changes in funding structures to 2050 in terms of capital sources (public and private) and types of capital (equity and debt), demonstrating that the financial capital needed for the 1.5°C Scenario is available and the required shift in investments is achievable.

<!-- image -->

A climate-safe pathway requires a large scale up of energy system investments - which the world's current capital markets can provide.

Sections 3.1 and 3.2 suggest an important redistribution of investments by energy technology, as investments  pour  into  transition-related  technologies.  They  also  show  a  shift  in  funding  sources and financing structure, with private capital and debt financing playing an increasingly prominent role.  As  returns  from  fossil  fuel  assets  become  increasingly  uncertain  and  governments  around the  world  are  announcing  ambitious  climate  commitments  and  green  recovery  plans,  investors' appetite for fossil fuel assets is expected to continue to fall - and the cost of financing for these technologies to increase. Larger shares of private capital can be expected to flow towards energy transition technologies as they further grow and gain market shares with capital markets followed by institutional capital playing a growing role.

Such  changes  are  already  underway  as  part  of  an  ongoing  technological  revolution  -  but the  'natural'  pace  is  not  rapid  enough.  While  the  energy  transition  is  gaining  momentum,  the immediate climate emergency demands a faster pace of change. Past technology revolutions took about fifty years and the affected technology and the available financial stock were far smaller than today's. Markets alone are not likely to move rapidly enough to take transition technologies up  the  development  curve  at  the  pace  needed.  Moreover,  they  are  likely  to  continue  to  drive investment towards regions and countries where the transition has already taken off, while areas with high real and perceived risks could be left behind. In addition, as the transition progresses, new trends and challenges will arise. While these trends will vary significantly across countries and technologies, they are likely to shape risk perception, thus affecting the availability and cost of capital. These trends are discussed in Section 3.3.

To  speed  up  the  transition  to  the  pace  needed,  to  drive  investments  to  countries  and  regions where they would not typically flow or to overcome new challenges as the transition progresses, government intervention remains crucial to hasten the energy transition along the curve of technology development and to address the unique challenges the current transition brings. Chapter 4 describes in detail a comprehensive set of policy measures that governments can deploy to support the energy transition.

## NEW INVESTMENT PRIORITIES IN THE 1.5°C SCENARIO 3.1

Ensuring a sustainable, climate-safe future calls for the scale-up of investment from the currently planned USD 98 trillion between 2021 and 2050 (under PES) to USD 131 trillion (under the 1.5°C Scenario)  between  now  and  2050  -  an  incremental  increase  of  34%.  The  1.5°C  Scenario  would require  an  additional  USD  1.1  trillion  per  year  over  the  PES  (Figure  3.1),  plus  the  redirection  of investments from fossil fuels towards energy transition technologies (renewables, energy efficiency, and electrification  of  heat  and  transport).  High  upfront  investments  are  critical  mainly  to  enable the accelerated deployment of key renewable energy technologies in the power sector; a massive scaling up of electrification of transport modes and heating applications, along with an expansion of accommodative infrastructure; and large-scale green hydrogen projects.

<!-- image -->

For a climate-safe energy future, energy investments need to shift to low-carbon energy transition solutions and increase 34% overall compared to planned investments.

<!-- image -->

T

R

A

N

S

I

T

O

N

S

O

U

T

L

O

K

FIGURE 3.1     Total investment by technology: PES and 1.5°C Scenario (2021-2050)

<!-- image -->

Accelerating the pace of the energy transition and scaling up investments in energy transition technologies in all sectors hinges on what the world does between 2021 and 2030. Setting the right investment priorities is key.

In  the  1.5°C  Scenario,  markedly  more  funding  would  be  channelled  to  energy  transition technologies compared with PES. Under the 1.5°C Scenario, renewable energy investments in both power and end uses (such as transport and heating) would reach USD 1.3 trillion annually up to 2030, and USD 1 trillion in the 2031-2050 period - more than triple the investments in 2019 and under PES. At the same time, investment in fossil fuels and nuclear technologies would peak at USD 970 billion per year up to 2030 before falling to USD 290 billion thereafter, as the ability of these technologies to attract funding falls. Under PES, they continue to account for a large but shrinking share of annual energy sector investment (USD 1.7 trillion in 2021-2030; USD 1.3 trillion in 2030-2050, respectively).

In the power sector ,  accelerated investment of USD 1.7 billion per year would account for 44% of the  total  required  energy  transition  investment  over  the  period  to  2050.  Investments  would  be directed towards additional renewable power generation capacity, grid extension and resiliency, and other grid flexibility measures (from better renewable power generation forecasting to integrated demand-side flexibility and stationary battery storage). Key generation technologies, such as solar PV (rooftop and utility scale) would draw annual average investment of USD 237 billion per year; onshore wind, USD 212 billion per year; and power grids, including energy flexibility measures, close to USD 733 billion per year. Figure 3.2 shows the annual average investments in power and end uses, both between 2017 and 2019, and as needed to fulfill the 1.5°C Scenario between 2021 and 2050.

## FIGURE 3.2     Annual average investments in power and end uses, historical (2017-2019) and needed to meet 1.5°C Scenario (USD billion/year)

<!-- image -->

<!-- image -->

<!-- image -->

|                           |                                      | Annual average investments USD billion/yr   | Annual average investments USD billion/yr   |
|---------------------------|--------------------------------------|---------------------------------------------|---------------------------------------------|
| Power                     |                                      | Historical 2017-19                          | 1.5°C Scenario 2021-50                      |
| Power generation capacity | Hydro - all (excl. pumped)           | 22                                          |                                             |
|                           | Biomass (total)                      | 13                                          |                                             |
|                           | Solar PV (utility and rooftop)       | 115                                         |                                             |
|                           | CSP                                  | 3                                           |                                             |
|                           | Wind onshore                         | 80                                          |                                             |
|                           | Geothermal Wind offshore             | 3 18                                        |                                             |
|                           | Marine                               | 0                                           |                                             |
| Grids and                 | Electricity network                  |                                             |                                             |
| flexibility               | Flexibility measures ( e.g. storage) | 4 271                                       |                                             |

<!-- image -->

Continues next page

Note: Power generation capacity: Deployment of renewable technologies for power generation. Grids and flexibility: Transmission and distribution networks, smart meters, pumped hydropower, decentralised and utility-scale stationary battery storage (coupled mainly with decentralised PV systems) and hydrogen for seasonal storage. Renewables direct uses and district heat: Renewables in direct end-use and district heat applications ( e.g. , solar thermal, modern bioenergy). Energy  efficiency  in  industry: Improving  process  efficiency,  demand-side  management  solutions,  highly  efficient energy and motor systems, and improved waste processes. Energy efficiency in transport: All passenger and freight transport modes, notably road, rail, aviation and shipping. Key efficiency measures include light-weight materials, lowfriction designs, aerodynamic improvements, among others. Vehicle stock investments are excluded. Energy efficiency in buildings: Improving building thermal envelopes (insulation, windows, doors, etc.), deploying efficient lighting and appliances, equipping smart homes with advanced control equipment, replacing less efficient buildings with energyefficient  buildings. Hydrogen electrolyser and infrastructure: Electrolyser  capacity  (alkaline  and  polymer  electrolyte membrane) for the production of green hydrogen and infrastructure for the transport of hydrogen. Bio- and hydrogenbased ammonia and methanol: Production of ammonia and methanol from biomass and hydrogen feedstocks. Carbon removals: CCS deployment, mainly for process emissions in industry and blue hydrogen production. BECCS deployment in  cement  and  power  and  cogeneration  plants. Circular  economy: Material  and  chemicals  recycling  and  bio-based alternative products ( e.g. , bioplastics).

BECCS = bioenergy with CCS; CCS = carbon capture and storage; CSP = concentrated solar power.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| End uses and district heat   |                                               |   Historical USD billion/yr |   1.5-S |
|------------------------------|-----------------------------------------------|-----------------------------|---------|
| Renewables end uses and      | Biofuels - supply                             |                           2 |      87 |
| district heat                | Renewables direct uses and district heat      |                          31 |      84 |
| Energy efficiency            | Buildings                                     |                         139 |     963 |
|                              | Industry                                      |                          45 |     354 |
|                              | Transport                                     |                          65 |     157 |
| Electrification              | Charging infrastructure for electric vehicles |                           2 |     131 |
|                              | Heat pumps                                    |                          12 |     102 |
| Innovation                   | Hydrogen - electrolysers and infrastructure   |                           0 |     116 |
|                              | Hydrogen-based ammonia and methanol           |                           0 |      45 |
|                              | Bio-based ammonia                             |                           0 |      22 |
|                              | Bio-based methanol                            |                           0 |      12 |
| Carbon removals              | Carbon removals (CCS, BECCS)                  |                           0 |      65 |
| Circular economy             | Recycling and biobased products               |                           0 |      25 |

Total average investments (excluding fossil fuel and nuclear) 2017-2019

Total average investments (excluding fossil fuel and nuclear) 2021-2050

<!-- image -->

<!-- image -->

<!-- image -->

3843 USD billion/ year

Annual average investments

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Investment in energy transition technologies needs to more than quadruple in the 1.5°C Pathway compared to the current and business-as-usual levels.

Under the 1.5°C Scenario, the buildings sector would require investment in a wide range of renewable and energy efficiency technologies. The solutions are varied, including LED lamps, more efficient appliances, efficiency-oriented retrofits of building shells, heat pumps and smart home systems. The average annual investment needed in the buildings sector (USD 1.09 trillion) is dominated by energy efficiency investment (USD 0.96 trillion); the remainder going for heat pumps and uses of other renewables, largely solar thermal. Overall, the buildings sector represents almost 28% of the total energy transition investment over the period to 2050.

Transport investments  would  rise  to  USD  375  billion  per  year  (10%  of  total  transition-related investment), excluding the incremental costs of electric vehicles. Energy efficiency measures would account for almost 42% of the total. Charging infrastructure would represent 35%; biofuel supply, 23%. Vehicle charging stations, in particular, would enlarge their share of energy sector investments to 2% up to 2030 and 4% in the period 2031-2050.

To realise  the  1.5°C  Scenario,  it  will  be  necessary  to  expand  and  broaden  biomass  supply  chains while ensuring their sustainability, and to enhance and scale up conversion technologies. Bioenergy investments would rise to USD 226 billion per year (6% of total transition-related investment), most of it to increase the biofuels supply, while USD 69 billion per year would be needed for the bioenergybased  power  generation  capacity.  The  remaining  USD  72  billion  per  year  would  be  needed  for the direct use of bioenergy in end-use sectors (USD 21 billion), district heat generation, production of  ammonia and methanol from biomass (USD 36 billion), and deployment of bio-based plastics and organic materials (USD 13 billion) as part of circular economy practices.

Innovations will be needed in the end-use sectors and for sector coupling. Investments in electrolysers to  produce green  hydrogen, hydrogen  supply  infrastructure,  and  renewables-based  hydrogen feedstocks for chemical production would exceed USD 160 billion per year on average through 2050. Because of the early stage of development of green hydrogen, supply chain investments of around USD 5 billion per gigawatt of supply (representing around 15-20 petajoules/year, enough to make 2 million tons of iron and steel or to heat half a million energy-efficient homes) would be required. Today only 0.3 GW of hydrogen electrolyser capacity is in place; manufacturing capacity is below 2 GW per year.

In  the  1.5°C  Scenario,  thanks  to  a  supportive  regulatory  framework, new  energy  transition technologies become competitive and reach scale, drawing in an increasingly large amount of new investment. Heat pumps, smart meters, energy storage, hydrogen electrolyser and networks, carbon capture and storage, bioenergy with carbon capture and storage (BECCS), and others (materials recycling,  bioplastics,  etc.)  would  account  for  8%  of  total  energy  sector  investments  during 2021-2030 and grow to 14% in the period 2031-2050, compared with 2.2% and 1.9%, respectively, in the PES. Around USD 65 billion per year would be needed for the deployment of carbon capture and storage, mainly in industrial processes, blue hydrogen production, and BECCS for power, heat generation and industrial processes, along with infrastructure for transport and storage.

District  heating  and  cooling  systems offer  the  opportunity  to  integrate  bioenergy,  geothermal and  solar  heat.  This  field  of  investment  can  be  combined  with  building  renovation.  Investments for  deploying  renewable  technologies  to  produce  district  heat  could  be  increased  to  around USD 8 billion per year.

<!-- image -->

Supportive policies in the 1.5°C Scenario enable the development of new energy technologies which under Planned Energy Scenario remain relatively subdued.

## FUNDING STRUCTURES FOR A CLIMATE SAFE 1.5°C FUTURE 3.2

As  described  in  Section  3.1,  the  1.5°C  Scenario  requires  an  average  annual  investment of USD 4.4 trillion over the period 2021-2050. While the level of funding needed is large, it  represents  about  5%  of  the  global  2019  GDP  and  is  well  within  the  current  capacity of  global  financial  markets,  which  reached  around  USD  200  trillion  in  2019  (World Bank,  2019a;  SIFMA,  2020).  As  well,  global  institutional  investors  alone  manage  about USD 100 trilion of assets but have so far largely remained on the sidelines of the energy transition (IRENA, 2020g). This pool of assets needs to be mobilised.

The rest of this chapter illustrates how the energy transition can be funded in terms of capital sources (public and private) and types of capital (equity and debt). The model used  for  this  exercise  is  based  on  the  energy  industry's  current  funding  structure,  a deep  understanding  of  financial  markets,  a  set  of  assumptions  about  how  financial actors perceive the risks and returns, the evolution of their beliefs over time, and their subsequent  actions.  This  model  represents  one  of  many  possible  scenarios,  but  it  is evident  that the financial capital needed for the energy transition is available and the  required  shift  in  investments  is  achievable. Given  a  more  proactive  role  of  the public  sector  -  one  in  which  it  establishes  the  right  policy  framework,  emphasises and ensures long-term benefits from the energy transition, and supports and deploys innovative financing methods and instruments to lower the cost of financing - one may expect the speed of the transition and its associated costs to be even more beneficial.

C

H

The capital needed for the energy transition is available and the necessary shift in investments toward energy transition technologies is feasible.

## 3.2.1 Funding sources for the energy transition

To reach the investment levels required for the global energy transition, all sources of capital - private and public, equity and debt - will need to be mobilised. To date, most has come from private sources, a trend that is expected to intensify. Private sources include venture capital (typically investing in opportunities posing a higher risk and offering a commensurately high return) and industrial capital (project developers, corporations, and institutional investors). The latter are more likely to fund more established ventures. Public capital - from government entities ( e.g. , sovereign states, municipalities, state-owned  enterprises)  and  development  finance  institutions  (DFIs)  -  will  continue  to  play  an important role in the energy transition. Public finance can be used to support relatively new solutions and markets, to fund enabling infrastructure, to reduce risks and financing costs to attract private investments, and to support the development of a pipeline of bankable projects. The measures that DFIs in particular can take to increase the effectiveness of investment are described in Box 3.1.

As transition technologies mature, the capital structure of projects tends to move from early-stage equity-dominant forms of financing towards low-cost, long-term debt to finance expansion, a trend that is expected to intensify in the climate-safe scenario. It is also worth noting that the global debt market is larger than the equity market: in addition to companies, governments, too, raise funding via debt issuances. The global debt market was estimated at USD 106 trillion in 2019, exceeding equity market assets estimated at USD 95 trillion (SIFMA, 2020). Debt can also be raised directly from commercial banks and institutional investors, either as corporate-balance-sheet lending or project finance. Debt from capital markets can take a variety of forms, but is most often structured as bonds. 1 In the recent past, new types of bonds whose proceeds fund green assets in particular have been issued with great success, indicating that a change in global lending practices is already under way. These are explored in Box 3.5.

- 1 Bonds are tradable, fixed-income instruments with a defined maturity. They represent a loan made by an investor to a borrower (typically corporations or governments).

<!-- image -->

## BOX 3.1     De-risking investments in the energy transition

Policy makers and public capital providers (such as development finance institutions, DFIs) can help lower barriers to a greater scale up of investments in energy transition assets by taking actions to de-risk projects and mobilise private capital via blended-finance initiatives.

De-risking  energy  transition  projects is imperative  if  long-term  funding  is  to  be  made available at reasonable rates. High real or perceived risk is a frequent stumbling block for many energy  transition  projects,  especially  in  emerging  and  developing  markets.  Risks  that  need to  be  allocated,  mitigated  or  transferred  include  political  risks  in  the  host  country  ( e.g. ,  war, expropriation), policy or regulatory risks ( e.g. ,  changes in policies, introduction of new taxes), currency risks ( e.g. , volatile exchange rate), counterparty risks ( e.g. , default or non-payment by off-takers), grid and transmission risks, and liquidity risks. Risk-mitigation instruments such as guarantees, letters of comfort or intent, hedges against currency risks ( e.g. , forward contracts and swaps a ), letters of credit, and insurance products provide solutions for such risks but may not be easily accessible or affordable to market participants (IRENA, 2020h). Guarantees are the most effective leveraging instrument, being involved in 45% of all private capital mobilisation while representing only 5% of DFIs' commitments (OECD and Milken Institute, 2018). DFIs and other providers of public capital would do well to devote more of their efforts (and funding) to making such instruments widely accessible.

Table 3.1 summarises the types of risks encountered in many energy transition projects and the instruments available to public capital providers to address them.

Blended  finance  mechanisms such  as  co-financing  ( e.g. , public-private  partnerships),  onlending, subordinated debt, and convertible grants and loans encourage the pooling of capital and the sharing of financial know-how, risks and returns among participating parties (IRENA, 2020g). Notably, the participation of DFIs through blended finance structures typically reduces the perceived risk of third-party investors and lowers the overall cost of capital (CFLI, 2019). Blended finance is therefore an essential leveraging tool that DFIs can deploy to magnify the effect of their funding and crowd-in private sources of capital. Greater use of co-financing to raise capital for green technologies and project finance b  will encourage the sector's shift away from self-financing via balance sheets and towards greater access to global capital providers. Such mechanisms can also be coupled with risk-mitigation instruments provided by DFIs for an additional boost to risk-adjusted returns and bankability.

- a. A forward contract is an agreement between two parties to buy or sell an asset at a pre-determined price at a future date. It is used to hedge against price fluctuations. A currency swap is a transaction in which two parties exchange an equivalent amount of money in different currencies at a certain date and agree to swap the same amount of money in the future at the original exchange rate or another pre-agreed rate.

b. Project finance is a fairly complex financing mechanism whereby, instead of the project cost being met by the project owners using their balance sheets, a separate legal entity is formed to own, manage and operate the project ( e.g. , a power plant). Funding is typically provided by a group of financiers on a non-recourse basis in which case lenders have recourse only to the project's assets and not those of the sponsor. This structure is typically deployed for projects with a strong stand-alone business case (IRENA, 2020g).

TABLE 3.1     Key investment risks and financial risk-mitigation tools to address them

| RISK                                 | DEFINITION                                                                                                                                                                                                                              | RISK MITIGATION TOOLS                                                                                                                                                   |
|--------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Political risk                       | Risks associated with political events that adversely impact the value of investment ( e.g. , war, civil disturbance, currency inconvertibility, breach of contract, expropriation, non-honouring of government obligations).           | Government guarantee, political risk insurance, partial risk/ credit guarantee, export credit guarantee                                                                 |
| Policy or regulatory risk            | Risks associated with changes in legal or regulatory policies that have significant, adverse impacts on project development or implementation ( e.g. , incentive programmes, taxes, interconnection regulations, permitting processes). | Government guarantee, potentially backed by partial risk/credit guarantee, export credit guarantee                                                                      |
| Currency risk                        | Risks associated with changing or volatile foreign exchange rates that adversely impact the value of investments and arises when there is a mismatch between assets (revenues) and liabilities (debt financing).                        | Government guarantee, currency risk hedging (swap, forward), loans in local currency or covered in the power purchase agreement (PPA)                                   |
| Counterparty (power off- taker risk) | Credit and default risk by a counter-party in a financial transaction. For renewable energy investments, it is related to the risk of default or non-payment by the power off-taker, typically the electric utility.                    | Government guarantee, political risk insurance, partial risk/credit guarantee, export credit guaran- tee, liquidity facility, put option/ termination clause in the PPA |
| Grid and transmission risk           | Risks associated with limitations in interconnection, grid management and transmission infrastructure (including curtailment risk).                                                                                                     | Government guarantee, partial risk/credit guarantee                                                                                                                     |
| Resource risk                        | Risks associated with uncertainties around the availability, future price and/or supply of the renewable energy resource ( e.g. , resource risks related to geothermal projects).                                                       | Government guarantee/grant/ convertible grant, geothermal exploration insurance                                                                                         |
| Technology risk                      | Risks associated with use of nascent technology or unexperienced labour deploying it.                                                                                                                                                   | Specialised insurance products                                                                                                                                          |
| Liquidity risk                       | Possibility of operational liquidity issues arising from revenue shortfalls or mismatches between the timing of cash receipts and payments.                                                                                             | Government guarantee, letter of credit, escrow account, liquidity guarantee, put option                                                                                 |
| Re-financing risk                    | Risk that a borrower is unable to re-finance the outstanding loan during the life of the project due to inadequate loan terms (high cost of borrowing, the maturity of the loan is mismatched with the lifetime of the asset).          | Greater supply of capital market instruments used for re-financing ( e.g. , green bonds/ funds)                                                                         |
| Natural disasters                    | Risk that a natural disaster will impact the ability of a counter-party to fulfil its obligations ( e.g. , produce power, make payments).                                                                                               | Property and casualty insurance                                                                                                                                         |
| Source: Adapted from IRENA (2016a).  | Source: Adapted from IRENA (2016a).                                                                                                                                                                                                     | Source: Adapted from IRENA (2016a).                                                                                                                                     |

<!-- image -->

Capital flows to areas of opportunity and higher risk-adjusted returns. As a new technology establishes itself,  investors  put  capital  into  companies  leading  the  deployment  of  the  new  technology,  while pulling out of companies exploiting the old technology. This results in two feedback loops, further driving technological change and new capital flows. New technologies generally experience positive feedback loops. As capital flows into the new technology, the cost of capital falls, making it possible for companies to raise financing to expand production. As production expands and economies of scale are established, costs fall faster, and more capital is attracted into the new technology. At the same time, old technologies experience negative feedback loops. As investors lose faith in the old technology owing to its dimming prospects, capital exits rapidly, making it harder for incumbents to raise capital at affordable rates. The consequent reduction in production leads to higher unit costs, as total cost is spread over a smaller volume. This, in turn, forces incumbents to further curtail production, leading to lower investor confidence, write-downs, lower share prices and a reduced market share. Box 3.2 discusses how financing sources change at different stages of a technology revolution.

## BOX 3.2     Funding sources at each stage of a technology revolution

Looking at the ongoing global energy transition as the current technology revolution can provide a good indication of how capital is likely to flow to new technologies over time and help policy makers choose the policies and enabling frameworks required to meet investors' needs at each stage of technology development, thus accelerating the energy transition. a

In the very early stages of a technology revolution - the so called gestation phase (up to a market share of approximately 1%) - various ideas and new technologies are tested. As private investors do not know which technology will succeed, innovation is most often done by entrepreneurs. The public sector is also an important source of financing at this stage, often funding demonstration projects or research and development.

When a winning technology begins to emerge, the revolution enters an irruption phase (or spring phase), where market share moves up to around 5%. This is the period when the new technology becomes cost competitive and starts to grow rapidly and attract considerable capital. In financial markets, the first movers will typically be venture capital and hedge funds that have a high tolerance for risk and are willing to invest in equity shares of small-scale businesses with high growth potential.

In the frenzy (or summer) phase, more and more investors allocate their capital to the new technology, and  market  share  moves  from  5%  to  around  25%.  However,  because  capital  moves  faster  than  new options are created, this period tends to end in bubbles. As the new technology gains competitiveness, public sources of funding shrink as a share of total funding. Loans from commercial financial institutions are most prevalent as technology approaches competitiveness. However, commercial loans plateau and then begin to decrease once technology reaches competitiveness, as less costly ways to raise capital emerge. Industry equity grows, as the technology can now provide a viable business model. Corporations begin issuing bonds to raise capital earmarked for these technologies. Venture capital, on the other hand, may shrink in volume as the market becomes too competitive to yield the high margins they seek.

a. The five technology revolutions highlighted by Perez (2002) are the industrial revolution (after 1771); the age of steam and railways (after 1829); the age of steel, electricity and heavy engineering (from 1875); the age of oil, cars and mass production (after 1908); and the age of information and telecoms (after 1971).

At  the  end  of  the  period  of  frenzy,  an  event  occurs  to  trigger  a  collapse  of  the  financial  bubble.  This  is followed by a turning point, when regulatory changes are made to facilitate the further expansion of the new technology. This synergy (or autumn) phase marks the full flourishing of the technology, with market share moving from 25% to 75%. In this phase, investors understand the new technology and can make solid returns. As the technology begins replacing incumbents to become the dominant technology, the kickstarting role of public equity declines (though governments may choose for profit-making reasons to continue investing in the form of state ownership). At the same time, venture capital and loans from development finance institutions continue to decrease. In their place, industrial capital and financing raised through capital markets become the  main  funding  sources  for  dominant  technologies,  with  developers  and  corporations  owning  assets, and capital easily raised through bonds. Over time, however, bonds shrink slightly in volume as technology gains more dominance, and there is less need to go through capital markets. 75 100 Penetration level of new energy technology (%/2019)

Finally,  in  the  mature  (or  winter)  phase,  the  new  technology  progressively  loses  its  competitiveness as a result of lower demand and higher costs. Capital then shifts away from such technology and onto the new promising opportunities. 50

In the context of the global energy transition, the electricity sector has been leading the change, followed by the transport sector (Figure 3.3). At the end of 2019, solar PV and wind represented 8% of global electricity generation (growing at 24% and 13% per annum, respectively). Both were in the frenzy phase of their development (IRENA, 2020i). Electric vehicles have recently irrupted; their market share in 2020 was 4% of sales. Other energy transition technologies (notably green hydrogen) are still in the gestation phase. Harder-to-abate sectors of the economy such as industry are in the same phase, where it is not yet clear which new carbon-free technology will be most successful. Each technology's stage of technical development and market penetration varies by country, depending on specific conditions. 0 25 Time Gestation Phase 1 Spring Phase 2 Summer Phase 3 Autumn Phase 3 Winter

FIGURE 3.3     Energy transition technologies and their development stage

<!-- image -->

<!-- image -->

## 3.2.2 Key changes in funding structures to 2050

A  climate-safe  future  as  envisioned  in  the  1.5°C  Scenario  requires  funding  amounts,  patterns  of technological distribution and capital structures that are markedly different from those of the base year (2019) and the PES. Governments' ambitions and the speed of implementation of the required supportive measures will need to take hold decisively for the world to enact the 1.5°C Scenario.

In 2019, energy assets of all types were primarily financed by private sources, which contributed some USD 1.6 trillion, or about 80% of total investment in the energy sector. The majority of private funding came in the form of debt - either loans or bonds. The public sector, through DFI lending and public equity, provided about USD 450 billion. Broken down by technology, most capital was invested in fossil fuel supply (41%), followed by energy efficiency (22%), renewables (16%), power grids  and  other  energy  flexibility  measures  (13%),  and  power  generation  from  nuclear  and  fossil fuels  (8%).  Investment  in  battery  storage,  hydrogen,  and  other  technologies  remained  relatively small  (BNEF,  2021a;  IEA,  2020a;  IRENA  and  CPI,  2020).  On-balance-sheet  financing  by  utilities, energy companies and developers accounted for two-thirds of the financing raised in 2019 for new construction of utility-scale renewable energy projects (estimated at about USD 150 billion). The other third came in the form of project finance structures (estimated at about USD 80 billion) (Frankfurt School-UNEP Centre and BNEF, 2020).

Figure  3.4  tracks  sources  of  funding  from  2019  to  2030  and  2050  under  the  PES  and  the  1.5°C Scenario. The public sources are public equity and loans from DFIs. The private sources are private equity, lending from capital markets, and lending from commercial banks and institutional investors.

In the 1.5°C Scenario, the increase in aggregate funding needed (an increase that will be driven largely by green technologies) would be covered by the private sector , as investors take decisive action to limit their exposure to assets not aligned with global climate actions and channel funds to green assets. Institutional investors, in particular, can contribute considerably to closing the financing gap for the energy transition (Box 3.3). Public funding would continue to play a crucial role in lowering risks and barriers for private capital, supporting the policy environment, and enabling a just and inclusive energy transition (as described in Chapter 4 and Chapter 5). While direct public funding in absolute numbers will grow through 2050, its share of total investments in the energy transition will decline over time as green technologies continue to attract a growing share of private capital.

FIGURE 3.4     Total average yearly investment by source and type of financing: 2019, PES and 1.5°C Scenario (2021-2030 and 2031-2050)

<!-- image -->

Sources: For 2019 investment: source and type of financing BNEF (2021a), IEA (2020a), IRENA and CPI (2020); for PES and 1.5°C Scenario: IRENA and BCG analysis.

The additional capital needed for the 1.5°C Pathway would be largely covered by the private sector, while public resources would continue to be key to lower the risk perception for investors.

<!-- image -->

## BOX 3.3     Institutional investors and the energy transition

Institutional  investors  represent  one  of  the  largest  capital  pools  in  the  world,  yet  their potential role in financing the energy transition has so far remained largely untapped. This will have to change if the 1.5°C Scenario is to be realised.

IRENA investigated the investment behaviour of institutional investors in the renewable energy sector by analysing a sample of 5 800 pension plans, insurance companies, sovereign wealth funds, and endowments and foundations. By 2018-2019, this core group of institutional investors managed about USD 87 trillion in assets, yet IRENA's analysis shows that while their participation in  renewable  energy  transactions  has  increased  in  frequency  over  the  past  two  decades,  it remains subdued (IRENA, 2020g). By 2018, a fifth of such investors had invested in renewable energy  funds,  representing  about  USD  6  billion  per  year,  whereas  only  1%  of  such  investors had invested directly in renewable energy projects. While the number of direct investments in renewables has grown over time, institutional investors still provided, on average, only 2% of total renewable energy financing in 2018 (Figure 3.5) (IRENA and CPI, 2020).

## FIGURE 3.5     Number of renewable energy project transactions involving institutional investors, by technology, 2009 - Q2 2019

## Number of transactions

<!-- image -->

Source: IRENA analysis based on Preqin data (2019).

Note: "Mixed renewable technologies" include more than one type of renewable energy technologies.

Renewable energy represents only one of the energy transition solutions needed to achieve the 1.5°C Scenario. Institutional capital has the potential to bridge the investment gap in other areas of the energy sector as well. But to activate this important capital pool, a range of co-ordinated actions involving regulations, policy levers, capital market solutions and internal changes will be required. These include:

- · nternal  capacity  building I on  the  part  of  institutional  investors  will  be  needed  in  some markets to enhance skills in the financial, technical and legal structuring of energy transition deals. In addition, investors also need to hone their skills in climate risk and energy sector analysis and governance. The required skills transfers can be advanced by collaborating with other institutional investors and development finance institutions to co-finance trades, and by participating in institutional investors' groups.
- · Project  pipelines must  be  built  to  make  energy  transition  projects  more  bankable  and to  increase  their  ticket  size-  both  aimed  at  making  them  more  attractive  to  institutional investors.  Solutions  include  greater  provision  of  risk-mitigation  instruments  by  public financiers,  standardisation  of  contractual  agreements,  aggregation  of  projects  into  larger transaction blocks, and a wider deployment of blended finance initiatives between public capital providers and institutional investors.
- · Capital  market  solutions can  help  channel  institutional  capital  into  energy  transition technologies by enlarging the supply of green investment vehicles, created in accordance with a green taxonomy aligned with global climate targets (Box 3.4). Such vehicles include project bonds, project funds and green bonds; all can provide institutional investors with a desirable scale, credit assurance (when rated) and liquidity (when listed on an exchange).
- · Policy and regulatory actions can be a powerful lever to steer institutional capital towards green assets.  In  addition  to  policies  that  help  promote  overall  renewable  energy  deployment,  these include  1)  review  and  revision  of  investment  restrictions  that  may  limit  institutional  investors' investments in real assets like renewable projects; 2) adoption and development of sustainable finance principles, including frameworks for calculation and disclosure of climate-related risks; and 3) application of long-term sustainability mandates and green investment targets.

There are already signals in the market that institutional investors are re-evaluating their portfolios and  shifting  their  attention  to  sustainable  assets,  including  renewables.  Many  institutional investors - including Norway's Government Pension Plan Global, Sweden's Första AP-fonden, the United Kingdom's National Employment Savings Trust, and Dutch Robeco - have announced their intention to divest from fossil fuel assets to reduce their exposure to sustainability-related risks  (Ambrose 2019; IEEFA, 2020a; IEEFA, 2020b; Tuck, 2020). Others have begun to make net zero emissions pledges. These include the Ontario Teacher's Pension Plan, the New York State Common Retirement Fund, and a number of major British pension plans, to name a few (Ceres, 2020; Jolly, 2021; OTPP, 2021).

Keeping  the  world  on  a  climate-safe  pathway  will  hinge  on  the  participation  of  institutional investors in the energy transition. The pace of the shift of institutional capital from fossil fuel assets to green energy technologies, however, needs to quicken.

<!-- image -->

In  the  1.5°C  Scenario,  governments  increase  both  their  ambitions  and  their  speed  of implementation. While still providing a sizable amount of funding to finance energy assets (their financing  in  absolute  terms  increases  from  USD  460  billion  in  2019  to  USD  1.1  trillion  in  the  next decade  and  USD  630  billion  in  2031-2050),  direct  public  sector  funding  into  the  technological avenues of the transition decreases over time from 22% of total spending in 2019 to 19% in the period 2021-2030 and 17% in the following decades. In the meantime, considerable public funding will be needed for supportive policy measures and to create an enabling environment (Chapter 4). Private lenders, sitting on plenty of capital, are increasingly aligned with climate targets and more reluctant to  provide  loans  to  fossil  fuels.  They  are  expected  to  phase  out  fossil  fuel  investments  relatively quickly.  Governments,  too,  are  focusing  on  supporting  transition-related  technologies  and  will play a key role in areas related to supportive policies, stricter regulation, targeted financial support for new technologies, and infrastructure.

In the PES, there is an asymmetry of beliefs, whereby the private sector moves faster than the public sector to exit brown technologies. In the 1.5°C Scenario, this asymmetry remains in some countries; however, only a relatively minor shift occurs in the shares of private and public equity investment in  these  technologies.  Moreover, in the 1.5°C Scenario, this partial asymmetry would be resolved in the period 2021-2030 as public and private stakeholders unite in taking equally decisive action to shift assets towards technologies aligned with climate targets and actions. The share of public investments (debt and equity) in fossil fuel supply, for example, drops from 51% in 2019 to 15% in the 2031-2050 period in the 1.5°C Scenario as public investment in brown technologies falls. This analysis is based on the perception that regulators around the world will put growing pressure on financial actors to align their assets with climate targets. Box 3.4 provides an overview of recent developments in the green taxonomy and climate-related risk disclosures that will help drive the investment shift.

In absolute terms, as noted, the public sector is still projected to invest in the energy sector significantly more on average annually over the 30 years from 2021 to 2050 (USD 779 billion) than it did in 2019 (USD 461 billion). An increase in public debt financing - from 7% in 2019 to 14% in 2021-2030 and 11%  in  the  following  two  decades  -  will  be  an  important  facilitator  for  other  lenders,  especially  in developing markets. In energy efficiency for buildings, particularly, public debt plays an important role (it is expected to make up 20% of the overall funding need for the sector in 2021-2050), given that  the  business  case  for  these  measures  remains  difficult  and  requires  government  mandates and public financing.

<!-- image -->

In  2021-2030,  DFI  lending  is  projected  to  grow  from  around  USD  60  billion  in  2019  to  over USD 550 billion per year under the 1.5°C Scenario - compared with USD 200 billion in PES - before declining in the period between 2031 and 2050. The initial growth over the 2019 level represents about 55% of the balance sheet of multilateral and regional DFIs, but this may be achievable, since DFIs have a lending curve similar to governments and can increase their lending portfolio more easily than commercial banks. Hence, while such investments are challenging, they should also be feasible. In addition to direct lending, DFIs should boost the effectiveness of their interventions by focusing on activities that mobilise private sources of funding, such as blended finance transactions (including co-financing with private investors) and risk-mitigation instruments to make energy transactions more bankable for private investors (see Box 3.1).

In the 1.5°C Pathway, private sector rapidly redirects its capital towards transition technologies, while governments speed up implementation of supportive policies.

<!-- image -->

<!-- image -->

## BOX 3.4     Green taxonomy and climate-related risk disclosure

Policy  makers can help channel global capital towards sustainable assets by adopting green taxonomies aligned with climate targets and by requiring investors to disclose and reduce their climate-related risks. Significant developments on both fronts are already underway but need to be further strengthened and globally deployed.

The green  taxonomy is the  cornerstone  of  the  sustainable  finance  movements  that  are spreading rapidly in global capital markets. As investors increasingly seek green assets, and as financial markets in turn offer more green securities, the question arises as to what assets are to be considered green - with the risk of 'greenwashing' looming large. To date, many different definitions of green and sustainable have been used in the financial markets, with varying levels of alignment with science-based climate targets. This is why the market has so eagerly awaited the European Union's Sustainable Finance Taxonomy, released in April 2021. The EU taxonomy defines  what  constitutes  sustainable  activities  and  also  requires  providers  of  sustainable investment products in the Union to disclose how aligned they are with the taxonomy (European Commission, 2021a). Other states and regions are expected to take similar action, making it easier  for  the  growing  pool  of  investors  seeking  sustainable  assets  to  identify  qualifying opportunities. China, for example, has already announced changes in its green taxonomy that bring it closer to the EU standard (Li and Yu, 2021).

Climate-related  risk  disclosure is  another  recent  development  in  the  capital  markets  with potentially important effects on global investments. It would help move climate risk out of the 'non-traditional' financial risk category and well into the spotlight of global investors. Market participants are already making significant inroads in this domain. These include organisations that develop climate-risk calculation and reporting standards, such as the Task Force on ClimateRelated Financial Disclosures (TCFD); organisations that help align climate-risk disclosure with global accounting standards, such as the Sustainability Accounting Standards Board and the Climate Disclosure Standards Board; and a host of sustainable finance initiatives that promote stakeholder  co-operation  and  adoption  of  such  standards.  Table  3.2  for  example,  presents TCFD's recommendations regarding 'decision-useful' climate-related disclosure.

In  the  end,  it  will  be  up  to  regulators  to  mandate  climate-risk  reporting  and  enforce  such mandates. Several countries are already taking such measures. The French Energy Transition Law,  adopted  in  2015,  requires  French  institutional  investors  (including  asset  managers  and banks) to disclose their greenhouse gas emissions and how climate risks will affect their assets (Mazzacurati, 2017). More stringently, the British government announced that it would require all listed companies and large asset owners to disclose climate-related information in line with TCFD recommendations by 2022 (Government of the United Kingdom, 2019). Furthermore, in April 2021, New Zealand introduced legislation to require banks, insurers and investment managers to report their climate-related risks and how such risks will be managed. If adopted, New Zealand's measure would be a world first (Reuters, 2021).

## TABLE 3.2     TCFD recommendations regarding 'decision-useful' climate-related disclosure

| GOVERNANCE                                                                                       | STRATEGY                                                                                                                                                                                   | RISK MANAGEMENT                                                                                                                                         | METRICS AND TARGETS                                                                                                                                      |
|--------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------|
| Disclose the organisation's governance around climate-related risks and opportunities            | Disclose the actual and potential impacts of climate-related risks and opportunities on the organisation's businesses, strategy, and financial planning where such information is material | Disclose how the organisation identifies, assesses, and manages climate-related risks                                                                   | Disclose the metrics and targets used to assess and manage relevant climate-related risks and opportunities where such information is material           |
| a) Describe the board's oversight of climate-related risks and opportunities                     | a) Describe the climate-related risks and opportunities the organisation has identified over the short, medium, and long term                                                              | a) Describe the organisation's processes for identifying and assessing climate- related risks                                                           | a) Disclose the metrics used by the organisation to assess climate-related risks and opportunities in line with its strategy and risk management process |
| b) Describe management's role in assessing and managing climate- related risks and opportunities | b) Describe the impact of climate-related risks and opportunities on the organisation's businesses, strategy, and financial planning                                                       | b) Describe the organisation's processes for managing climaterelated risks                                                                              | b) Disclose Scope 1, Scope 2, and, if appropriate, Scope 3 greenhouse gas (GHG) emissions, and the related risks                                         |
|                                                                                                  | c) Describe the resilience of the organisation's strategy, taking into consideration different climate-related scenarios, including a 2°C or lower scenario                                | c) Describe how processes for identifying, assessing, and managing climate-related risks are integrated into the organisation's overall risk management | c) Describe the targets used by the organisation to manage climate-related risks and opportunities and performance against targets                       |

<!-- image -->

Far more debt is incurred to fund energy assets (particularly green assets) in the 1.5°C Scenario than in the PES, as greener assets are better able to attract low-cost long-term financing. Over time, brown technologies have growing difficulty finding debt financing at affordable costs and must rely on equity financing.

In the 1.5°C Scenario, debt would meet most of the increase in the funding needs driven by green technologies. Debt's share in the finance mix grows from 44% in 2019 to 66% in 2021-2030 and 57% in 2031-2050 (compared with 43% and 39%, respectively, in the PES). In absolute terms too, debt issuances grow, experiencing a fourfold increase - from USD 932 billion in 2019 to an average USD 3.7 trillion per year in 2021-2030, before declining to USD 2.2 trillion per year in the following two  decades.  Technologies  aligned  with  climate  targets  should  have  no  difficulties  in  attracting long-term debt financing under satisfactory terms, including in capital markets. Box 3.5 presents an overview of the green bonds market and the trend of record issuances since 2014, highlighting the massive potential for further growth in green debt. The shift toward higher shares of debt capital in the 1.5°C Scenario reflects a reduction in the perceived risk of energy transition technologies.

Going  forward,  long-term  climate  commitments  and  growing  pressure  on  financial  institutions to  align  their  investment  portfolios  with  the  targets  of  the  Paris  Agreement  are  likely  to  make  it increasingly  difficult  for  brown  technologies  to  obtain  commercial  loans  at  reasonable  rates.  As many lenders would be increasingly reluctant to back massive investments in fossil fuel assets, these technologies would need to meet their funding needs by retaining earnings (less dividends) and potentially issuing new stock. In the PES, where 44% of energy sector investments would still be directed to fossil fuel and nuclear assets, the share of equity would grow from 56% in 2019 to 57% up to 2030 and 64% in the period 2031-2050. Under the PES, equity would fund about 70% of the additional investments in fossil fuel technologies (or USD 814 billion per year), the majority of which (61%) would come from the public sector.

## BOX 3.5     Green bonds

The rise of green bond issuances in the recent past indicates that a shift in lending behaviour is already under way, as assets aligned with climate targets are attracting growing amounts of financial capital, especially long-term debt. However, the potential for further growth remains enormous and can benefit from active support from governments and market participants to help make the 1.5°C Scenario a reality.

Green bonds help issuers (governments, corporations) attract investors that have sustainability goals, providing  them  with  greater  transparency  over  the  use  of  proceeds  than  is  typically  the  case  with traditional  bonds.  Green  bond  proceeds  fund  green  projects  in  renewable  energy,  energy  efficiency, green  buildings,  clean  transport,  sustainable  water  management,  waste  and  pollution  control,  and nature-based  assets,  among  others  (CBI,  2019).  Most  green  bonds  fund  multiple  green  categories. IRENA's analysis of more than 4 300 green bonds issued over the past decade shows that about 50% (by volume, in USD) included renewable energy, while 16% were earmarked solely for renewable assets (IRENA, 2020j).

The green bond market started about a decade ago with initial issuances from development finance institutions such as the European Investment Bank in 2007 (for EUR 600 million) and the World Bank in 2008 (EIB, 2017; World Bank, 2019b). Since then the market has diversified away from DFIs to a variety of issuers including local, state and federal governments, and a variety of issuing companies (financial institutions, corporations). The green bond market has also grown rapidly, attracting about USD 271 billion in issuances in 2019 (Figure 3.6) (IRENA, 2020j). Further, in 2020, despite the COVID-19 pandemic, the market recorded record-high issuance of around USD 290 billion and reached the USD 1 trillion mark in cumulative issuances (CBI, 2020). However, given that the global bond market as a whole is worth about USD 100 trillion, the potential for further growth in the green bond market remains very large.

FIGURE 3.6     Annual global green bond issuance by region, 2014-2019

<!-- image -->

Source: IRENA, 2020g; based on data from the Environmental Finance (2020).

To realise this potential, several market barriers need to be lowered. These include lack of awareness of the benefits of green bonds (and hence lack of investor demand); lack of regulatory clarity and mandates surrounding  the  green  taxonomy  and  green  certification,  bond  issuance  and  reporting  on  use  of proceeds; and relatively high transaction costs. To lower these barriers, regulators can adopt issuance and certification standards aligned with climate targets such as those offered by the Climate Bonds Initiative. They can also provide economic incentives in co-operation with DFIs to fund demonstration issuances and offer grants to offset transaction costs. Policy makers can co-operate with green bond leaders in the financial industry to build financial skills needed to issue green bonds and other new instruments. Finally,  policy  makers  can  create  green  mandates  for  crucially  important  capital  holders  such  as institutional investors, thereby ensuring steady demand for green financial instruments (IRENA, 2020j).

## THE IMPACT OF THE ENERGY TRANSITION ON FINANCING RISKS AND CAPITAL POOLS 3.3

While  adequate  funding  for  the  energy  transition  is  achievable,  capital  availability  will depend largely on investors' assessment of risks and returns. Several trends are likely to influence this perception - positively or negatively. Dedicated policies and capital market interventions  may  be  needed  to  mitigate  risks  in  some  contexts  so  as  to  increase  the availability of affordable capital and increase the speed of the transition.

Observed trends related to the inherent nature of energy transition technologies include the broadening geographical distribution of investments (with more assets being built in developing countries); the shift in financing structures from operations-intensive to capitalintensive expenditures (resulting in a frontloading of investments); and fragmentation of markets and proliferation of smaller projects (reducing transaction size for investors); and the introduction of new technologies. Some of these trends may have a positive or mixed effect on capital pools. Others will need to be managed via dedicated policies and capital market interventions to mitigate risks and increase the availability of affordable capital.

Other trends in the enabling environment include those related to the shift of power systems towards liberalised  markets  in  some  countries  and  the  adoption  of  policies  to  keep  the world on a climate-safe pathway; the forced retirement of fossil fuel assets to accelerate the transition; the wider adoption of policies that eliminate distortions and incentivise energy transition  solutions;  larger  public  investments  in  supportive  infrastructure;  increased awareness among consumers and citizens about the potential and benefits of transitionrelated solutions; and support for innovation and the development of domestic value chains.

C

H

## 3.3.1 Observed trends related to the nature of the energy transition and their impact on investment risks

The  broader  geographical  distribution  of  investments. As  the  global  transition  unfolds,  the geographical distribution of investments in energy assets is broadening. With an increasing number of investments located in countries characterised by challenging political, technological and market conditions,  investors'  overall  perception  of  risks  is  expected  to  increase.  Public  finance  can  be particularly effective in supporting technologies and regions that private investors perceive as too risky. This can be done through blended finance and risk mitigation (Box 3.1). In addition, activating different types of investors with varying requirements in terms of size, location and risk-return profile could help attenuate the increased perception of risks related to this trend. Creating investment vehicles that open access to green projects in different countries can also help investors access new opportunities abroad.

The  shift  from  operations-intensive  technologies  to  capital-intensive  technologies. The energy  transition  will  entail  a  shift  from  financing  fossil  fuel  technologies,  which  rely  heavily  on operating  expenditures  (OPEX),  to  energy  transition  technologies,  which  generally  have  a  more capital-intensive profile (CAPEX). Depending on context, this trend affects the funding structure differently with respect to preexisting perceived risks. A rise in CAPEX makes an investment more sensitive to the reward that investors and lenders expect, which depends largely on the perceived risk  of  the  investment. Risk perception would thus have a much greater effect on the viability of the  investment. Therefore, it  is  easier  for  a  CAPEX-intensive  investment  ( e.g. ,  solar  and  wind)  to compete with an OPEX-intensive investment ( e.g. ,  fossil fuels) in a low-risk environment than in a high-risk  environment.  This  explains  why  renewable  energy  projects  have  a  much  harder  time reaching financial closure in developing countries. There is also a temporal difference. The viability of a CAPEX-intensive investment will depend on perceived risks over a short period - essentially around the time of the financial closure, when interest rates and the financial model that predicts a certain return on investment crystallise, on trade agreements, power systems structures, and contractual clauses, among other factors. An investment in OPEX-heavy technologies or assets by contrast, will be affected over its lifetime by fluctuations in the cost of the resource (coal, fuel or gas). DFIs can play a key role in this context, by facilitating access to risk-mitigation instruments needed to lower early-stage risks, both real and perceived.

<!-- image -->

<!-- image -->

Several observed trends related to the energy transition are likely to affect investors' risk perception and the availability and cost of capital for energy-transition technologies.

More fragmented markets and smaller projects. Several energy transition technologies (notably rooftop solar PV and other individually adopted technologies) are distributed, which affects their risk  profile  in  a  number  of  ways.  On  the  one  hand,  some decentralised installations such as heat pumps are only marginally affected by political risk, if at all, as the bulk of the support they receive is typically provided during their installation. Moreover, counterparty risk is also generally reduced as the investor and the off-taker are often the same entity, and revenues come mostly in the form of  reduced  electricity  costs  (for  power  assets)  or  overall  energy  expenses  (for  energy  efficiency projects). However, the smaller ticket sizes of decentralised projects may reduce their attractiveness in the eyes of traditional financiers ( e.g. ,  commercial banks) owing to the higher transaction costs involved  and  the  inability  of  some  installers  to  provide  guarantees  to  back  their  loans.  In  these instances,  contract  standardisation  and  bundling  of  projects  through  securitisation  can  help  to reduce transaction costs by increasing the overall ticket size (IRENA, 2020g; IRENA and CPI, 2020). Targeted regulations and public capital support are fundamental to help such projects become more widespread and gain commercial momentum.

Innovation and introduction of new technologies. While some renewable energy technologies such as solar PV and onshore wind have been widely deployed worldwide and are now relatively mature, other technologies, such as green hydrogen, are still at early stages of development and adoption. Those solutions still represent comparatively high-risk investments owing to uncertainties related to the technology itself as well as the ecosystem supporting it. For instance, the supporting infrastructure ( e.g. , distribution networks) may not be fully developed by the time green hydrogen is ready to be deployed, and available support schemes may be unsuitable or adjusting too slowly to the pace of innovation. While these conditions are attractive for some investors looking for higher returns from riskier investments (such as venture capital providers, for example), traditional investors may be reluctant to commit to these technologies and may want to wait until they reach a certain level of maturity. Public sector financing may therefore be needed to provide the initial investment injection.

C

H

## 3.3.2 Observed trends in power system structures and enabling environments and their impact on investment risks

Power structures transitioning to more liberalised systems. For power structures moving towards more  liberalised  systems,  power  generation  is  remunerated  in  the  wholesale  market  based  on clearing prices, which are typically determined according to the marginal cost of the most expensive active  generator  in  a  certain  time  slot.  As  the  share  of  renewables  increases  in  the  system,  this structure increases investors' exposure to price and off-take risks, thus increasing their reluctance to invest in variable renewable energy. Price risks arise from market price variations reflecting the fundamental demand-supply balance and the clearing price, which declines with rising penetration of  low-marginal-cost  renewable  energy.  Price  risks  can  be  mitigated  through  long-term  off-take agreements. But such agreements sometimes come with counterparty risks, including the risk of payment delays, as the off-taker may not always be creditworthy. Because merchant markets risk limiting  the  penetration  of  variable  renewable  energy  into  the  power  system,  it  remains  unclear whether this trend will continue in the future. A restructuring of power markets or a separation of generation risks and balancing risks through new auction structures will be needed to ensure higher penetration of renewables in the market (IRENA, 2020d) (see In Focus section in Chapter 4).

Increased  implementation  of  policies  to  accelerate  the  retirement  of  fossil  fuel  assets To accelerate the energy transition and achieve decarbonisation targets by 2050, many existing carbonintensive industries and assets will face early retirement and become stranded. 2  Implementing policies to retire fossil fuel assets would give a strong signal to investors about governments' commitment to the energy transition and would reduce risks related to the political environment and the stability of  transition-related  plans.  However,  the  way  early  retirement  is  managed  and  compensated  by governments could negatively affect the risk perception of energy sector investors. Abrupt change, in particular, before financial players have not had a chance to adjust their positions, could potentially have negative ripple effects in the overall financial market and the economy, given that a large share of pension funds' assets, for example, are currently invested in fossil fuels. To reduce uncertainties and  risks  for  energy  sector  investors,  the  phase-out  of  fossil  fuel  assets  should  be  carried  out with  transparent  and  strategic  planning,  a  clear  timeline,  and  clear  guidelines  and  mandates  for investors to redirect their assets towards industries aligned with climate targets. Governments could compensate for some of the losses incurred when these changes result in excessive social harm - for example, by developing programs for retraining and relocation of the workforce. This approach may be less disruptive and contribute to the promotion of a just transition (see Section 5.3).

- 2 Stranded assets are defined as the remaining book value of assets substituted before the end of their anticipated technical lifetime to achieve 2050 decarbonisation targets, without recovery of any remaining value (IRENA, 2017b).

<!-- image -->

Wider adoption of policies that eliminate market distortions and incentivise energy transition solutions. While many renewable energy technologies have achieved competitive cost structures, some transition technologies such as electric vehicles and heat pumps have not yet reached that point  against  fossil  fuel  alternatives  in  many  contexts.  As  governments  remove  existing  support schemes for fossil fuels (Congressional Research Service, 2019) and introduce fiscal policies such as carbon pricing (OECD, 2016), the ability of green solutions to compete against traditional solutions is  enhanced.  While  the  impacts  on  investment  risks  will  ultimately  depend  on  the  effectiveness, stability and long-term continuity of such policies, recent pledges of carbon neutrality and other ambitious climate goals made by governments around the world (see Chapter 4) suggest that the risk of unfavourable retroactive policies is relatively low.

Increased public investments in supporting infrastructure. Supporting infrastructure, such as grid enhancements and charging stations for electric vehicle, are a key enabler of the energy transition. Public commitments to enabling infrastructure have a knock-on effect on investment, since having the necessary infrastructure in place, coupled with supportive policies, can make it possible for new technological solutions to scale up, thus boosting investors' confidence in the viability of energy transition technologies. In addition, public participation in the provision of infrastructure can improve credit quality and the certainty of operational revenues, lowering investors' risks along this dimension.

Increased consumer awareness of the benefits and reliability of energy transition solutions. Energy  users,  from  corporations  to  households,  are  increasingly  demanding  cleaner  and  more efficient solutions for their energy needs. In some cases energy users have become 'prosumers', producing energy through rooftop solar PV in combination with energy-storage technologies and electric vehicles. In 2020, for example, non-energy corporations purchased a record-high level of clean energy through corporate power purchase agreements (BNEF, 2021b). By creating demand for  energy  transition  technologies,  this  shift  in  consumer  preferences  will  reduce  investors'  risk perception and push them to seek more such investment opportunities.

Increased adoption of policies and measures to support the development of domestic value chains. The  energy  transition  brings  immense  opportunity  for  the  development  of  local  supply chains, creating value and jobs locally (Chapter 5). As more countries plan to seize this opportunity, especially  in  the  process  of  recovery  from  the  COVID-19  crisis,  more  governments  are  weighing support for the development of domestic supply chains. For renewable energy power plants, this is  often  done  through  various  policy  mechanisms,  such  as  mandating  a  minimum  level  of  local content  in  supply  chains  ( e.g. ,  as  a  prerequisite  for  accessing  financing,  qualifying  for  a  feed-in tariff or participating in an auction), or incorporating them as evaluation criteria ( e.g. , in an auction). Instruments for the development of domestic value chains can lower risks related to supply chains, which  became  evident  during  the  COVID-19  crisis.  However,  localising  supply  chains  may  imply higher costs for investors in the short term if the technology employed is not the lowest-cost option available, and if local capabilities are not readily available.

## CONCLUSION 3.4

As renewables' costs continue to fall,  fossil  fuel  supply  and  fossil  and  nuclear  power  generation technologies  are  abruptly  losing  their  cost-competitiveness.  Due  to  their  superior  risk-adjusted returns,  investments in  renewables are increasingly outstripping those of brown technologies. In 2019, global investments in new renewable power exceeded investment in new fossil fuel power by more than three times (Frankfurt School-UNEP Centre and BNEF, 2020). In 2020, in the midst of  the  COVID-19  pandemic,  the  competitiveness  of  fossil  fuel  assets  was  further  jeopardised  as their returns became uncertain and governments around the world announced ambitious climate commitments and green recovery plans (IRENA, 2020b) (see Chapter 4). As these technologies are gradually identified for phase-outs, investors' appetite for them will drop, the cost of financing will increase, and private capital will move increasingly to new energy technologies. A larger share of private capital can be expected to flow towards energy transition technologies as the pressure to advance the transition grows. Capital markets and institutional capital can be expected to play an increasing role over the coming years as green technologies gain even more market share and provide stable returns.

Although the energy transition is gaining momentum, the immediate nature of the climate emergency and the global Sustainable Development Goals require a much faster pace of change. Markets alone are not likely to move quickly enough to take transition technologies up the development curve at the speed needed. Therefore, policy makers and public finance institutions remain key in ensuring that the energy transition occurs in time and with optimal socio-economic effects. The next chapter describes in detail a comprehensive set of policy measures that governments can use to support the energy transition.

<!-- image -->

Governments have a crucial role to play in advancing a just energy transition and placing the world on  a  trajectory  toward  limiting  the  global  temperature  rise  to  1.5°C.  The  surrounding  discourse often  defines  governments'  main  responsibility  as  creating  an  enabling  environment  for  private investments through predictable and stable policies and de-risking public financing tools. In fact, a much broader set of policy measures is required to facilitate the adoption of the entire spectrum of energy transition solutions needed to avoid a rise over 1.5°C and align short-term actions with longerterm climate and socio-economic development objectives.

This chapter discusses the components of a comprehensive policy framework necessary to advance an energy transition aligned with the 1.5°C Pathway, and focusing on accelerating the adoption of technology solutions and ensuring a just and inclusive transition which maximises socio-economic benefits for all. The broad policy framework for a just energy transition and its interaction with the main system layers of energy, society, economy and planet is shown in Figure 4.1.

A host of cross-cutting enabling policies ,  often involving institutions outside the energy sector, contribute  to  a  conducive  environment  for  the  energy  transition  covering  all  its  technological avenues. These include policies that set ambitions and issue clear signals to stakeholders, eliminate distortions, incentivise the uptake of solutions and facilitate access to affordable financing, among others. These policies are described in Section 4.1. Deployment policies to support all the essential technological avenues of the energy transition -  namely, renewable energy for power and end uses (heating and cooling and transport), energy efficiency, electrification, sustainable bioenergy and green hydrogen - play a fundamental role in accelerating the adoption of related technologies. Such policies support market creation, thus facilitating deployment, reducing technology costs and increasing adoption at levels aligned with energy transition needs. They are described in Section 4.2, along with some of the integrating policies enable the integration of energy transition related technologies into the energy system, the economy, society and planet.

It is essential to recognise that regions and countries face markedly different contexts with varied starting  points,  socio-economic  development  priorities  and  resources.  Regardless  of  starting point or context, however, any structural change in an economy (including an energy transition) will bring benefits, as well as challenges in the form of misalignments that may become evident in finance, labour markets, power systems and the energy sector itself. These misalignments, if not well managed, risk inequitable outcomes and a slower pace of the energy transition. Therefore, a set of structural and just transition policies , along with the creation of strong institutions to ensure policy co-ordination and cohesion, is required to manage potential misalignments. They are discussed in Section 4.3.

## FIGURE 4.1     Enabling policy framework for a just and inclusive energy transition

<!-- image -->

ECONOMY

<!-- image -->

PLANET

<!-- image -->

## SOCIETYLICIES DEPLOYMENT PO

## INTEGRATING POLICIES

## For example:

Renewable energy targets

Regulatory and pricing policies (e.g. feed-in tariffs and auctions)

Mandates and planned replacement

Tradable certificates

Fiscal and financial incentives

<!-- image -->

## STRUCTURAL CHANGE AND JUST AND INCLUSIVE TRANSITION POLICIES

## For example:

Measures to adapt socio-economic structure to the energy transition

Labour market policies and social protection (e.g training and retraining) Industrial policy

Trade policies (e.g. trade agreements)

Environmental and climate policies

## For example:

Measures to enhance system flexibility

Policies for the integration of off-grid systems with main grid

Policies for sector coupling, including infrastructure

Alignment of energy efficiency and renewable energy policies

<!-- image -->

## HOLISTIC GLOBAL POLICY FRAMEWORK

## For example:

Public investment for structural transition elements

International climate finance based on equity and fairness

Carbon pricing aligned with climate goals

Progressive government revenue recycling to address inequalities

<!-- image -->

## ENABLING POLICIES

## For example:

Ambitious energy plans

Policies to level the playing field (e.g. fossil fuel reforms)

Policies to ensure the reliability of technology (e.g.   quality and technical standards, certificates)

RD&amp;D and innovation policies

<!-- image -->

A broad set of policy measures is required to facilitate the adoption of energy transition solutions needed to align short-term actions with longer-term climate and socio-economic development objectives.

The policies needed to advance the energy transition reinforce one another and have implications for the energy system, economy, society and planet. An integrated policy approach is necessary to account for feedback among policies and across systems to ensure a timely, just and inclusive energy transition.

A holistic global policy framework would bring countries together to commit to a just transition that leaves no one behind and strengthens the international flow of finance, capacity and technologies in an equitable manner. Climate policies represent a crucial piece of such a framework. A portfolio of relevant measures would include fiscal policies such as adequate carbon pricing covering emissions across  sectors  and  meeting  public  funding  needs  for  the  implementation  of  policies  to  foster deployment and enabling conditions, and to address structural and just transition aspects including industry  creation,  education  and  training,  and  social  protection.  The  needed  financial  resources will not always be available domestically; international collaboration and co-operation are needed to channel them, particularly to least developed countries and small island developing states. The holistic global policy framework is discussed in Section 4.4.

<!-- image -->

WORLD ENERGY

TRANSITIONS OUTLOOK

## CROSS-CUTTING POLICIES ENABLING THE ENERGY TRANSITION 4.1

A range of cross-cutting policies is necessary to provide enabling conditions for the accelerated deployment of energy transition solutions in all technological avenues (summarised in Table 4.1). Governments need to raise their energy transition ambitions while considering locally available renewable  energy  resource  potential  and  multiple  socio-economic  and  climate  objectives. Ambitions should be accompanied by specific renewable energy targets and embedded within long-term plans that include phasing out fossil fuel assets. Among other measures, a fiscal system is  needed that facilitates the adoption of energy transition solutions while disincentivising new investments in fossil fuel technologies and supporting a phase-out aligned with the 1.5°C Pathway. Policies and measures are also needed to facilitate access to finance, foster innovation and raise awareness among consumers - and citizens in general - to support the uptake of transition-related technologies.

Governments need to raise their energy transition ambitions while considering locally available renewable energy resource potential and multiple socioeconomic and climate objectives.

<!-- image -->

## TABLE 4.1     Overview of cross-cutting policies to enable the energy transition

| OBJECTIVE                                                         | EXAMPLES OF MEASURES                                                                                                                                                             | COMMENTS                                                                                                                                                                                                                                    |
|-------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Raise ambition in commitments to the energy transition            | Net zero targets can be seen in legislation in Denmark, France, Hungary, New Zealand, Sweden and the United Kingdom.                                                             | Targets should go beyond the power sector to include the energy needed for heating and cooling and transport, and for specific solutions and technologies, such as green hydrogen.                                                          |
| Phase out fossil fuels                                            | Many European countries ( e.g. , Denmark, France, Finland, Hungary, Italy, Portugal, Slovenia, the United Kingdom) have announced a plan to phase out coal power plants by 2030. | A holistic policy framework is necessary to address the issue of fossil fuel as a stranded asset and its socio- economic implications.                                                                                                      |
| Eliminate distortions and incentivise energy transition solutions | Sweden's taxation of fossil fuels.                                                                                                                                               | Policies (that may include fiscal policies such as carbon pricing) should be implemented with careful consideration of broader social and equity issues, particularly for low- income populations.                                          |
| Facilitate access to finance                                      | The Brazilian Development Bank offers a loan supporting biomass co-generation projects.                                                                                          | Public financing can facilitate the adoption of energy transition solutions. Interventions range from the public ownership of transition-related assets, to unlocking private sector participation and supporting just transition measures. |
| Foster innovation                                                 | Direct funding to research and development in energy transition technologies ( e.g. , fast-charging infrastructure, green hydrogen linked with industrial use).                  | Enabling policies can further innovation across various dimensions of technology, infrastructure, financing, business models, market design and regulation, as well as governance and institutional frameworks.                             |
| Raise awareness among consumers and citizens in general           | The campaign HeatSmart Northampton raises public awareness and promotes the installation of heat pumps in a town in the state of Massachusetts (United States).                  | Consumers and citizens play a big role in the energy transition: they influence governments and corporations to move faster in their decarbonisation plans and make proactive choices regarding their energy consumption and sources.       |

## 4.1.1 Raise the ambition of commitments to the energy transition

The past two years have been significant for the energy transition with a number of countries raising net zero commitments. More than 12 countries and the European Union passed or proposed laws around net zero emissions and have earmarked significant financial resources for green recovery plans with renewables as a key pillar, and around 20 countries have placed net zero targets in policy documents (Table 4.2). In April 2021, the United States hosted a Leaders' Summit on Climate ahead of the 26 th UN Climate Change Conference of the Parties (COP26) and vowed to reduce emissions by  at  least  50%  by  2030,  more  than  doubling  its  prior  commitment  under  the  Paris  Agreement (The White House, 2021). Brazil, Canada and Japan followed with their own commitments.

TABLE 4.2   Jurisdictions with net zero targets as of the first quarter of 2021

Juristiction (by target year)

<!-- image -->

Source: ECIU, 2021.

## WORLD ENERGY

## TRANSITIONS OUTLOOK

Countries  around  the  world  need  to  be  increasingly  ambitious  in  their  pledges  to  scale  up renewables and cut energy-related carbon dioxide (CO ) emissions while also reaping significant 2 socio-economic benefits. But net zero and ambitious targets are not immediately feasible for all economies. Nationally Determined Contributions (NDCs) are being revised more than five years after the signing of the Paris Agreement. As of the first quarter of 2021, 75 parties to the Paris Agreement had already submitted their revised NDCs. Of the total 191 parties having submitted NDCs, 141 (or 74% of the total) included quantified renewable energy targets for the power sector, while only 63 parties (33%) included targets for direct heat and transport, thus leaving the potential of renewables in end uses largely untapped (Figure 4.2). The NDCs, while representing vital national focus on the energy transition and climate action, are collectively insufficient to achieve the 1.5°C Pathway.

Renewable energy targets are key drivers of policies, investment and development, as they provide clear indications of the intended deployment and timeline envisioned, which are important signals to investors. As  of  October  2020,  160  countries  had  national-level  targets  for  renewables  in  the  power  sector, compared to 49 countries with targets for heating and cooling and 46 for transport (REN 21, 2020).

FIGURE 4.2     Renewable energy components of NDCs, as of the first quarter of 2021

<!-- image -->

Over 60% of renewable energy targets for the power sector were already achieved at the end of 2019, leaving about 1 TW of renewables yet to be installed globally. As shown in Figure 4.3, existing renewable power targets fall short of actual deployment trends observed over the past decade. If renewable power installed capacity were to grow at the same pace as during 2010-2019, global renewable power capacity would reach 4 091 GW in 2030 - 13% higher than the level expected through  target  implementation  (IRENA,  forthcoming-a).  But  under  IRENA's  1.5°C  Pathway,  the installed capacity of renewable power would need to reach 10 771 GW by 2030 (see Chapter 2) more than double the amount installed to meet the targets noted.

FIGURE 4.3     Global installed capacity of renewable power: historical trends and future projections based on targets

<!-- image -->

<!-- image -->

As noted earlier, national renewable energy targets have so far focused mainly on the power sector. Policy makers need to define more holistic targets covering all end-use sectors, including heating and cooling and transport, as well as specific solutions such as green hydrogen (Section 4.2.4). These targets form the basis to establish long-term integrated energy planning strategies discussed in the following section.

## 4.1.2 Develop a long-term energy transition plan

Accelerating the energy transition and maximising its benefits require an integrated energy planning approach that combines targets and commitments with holistic and long-term plans including the deployment  of  energy  transition  technologies,  the  phasing  out  of  fossil  fuels  and  the  thorough consideration of their socio-economic impacts. An integrated long-term plan should be developed in coordination between different ministries ( e.g. , energy and environment or climate change).

For heating and cooling, for example, cross-sectoral planning should integrate the transition with plans  for  other  sectors  ( e.g. ,  power  and  industry).  The  energy  plan  must  consider  the  different transition  pathways  including  electrification,  the  deployment  of  green  gases,  sustainable biomass,  solar  thermal  and  geothermal  heat,  and  district  heating  and  cooling  among  key  enabling infrastructure (Figure 4.4). The plan must be based on specific needs, macroeconomic conditions, availability of resources, the infrastructure already in place, and the level of development, accessibility and  cost  of  technologies.  Developing  and  implementing  an  integrated  long-term  plan  require strong co-ordination and a robust institutional structure. This is especially the case when it comes to electrification with renewables, as it calls for the synchronisation of the deployment of renewable power  plants  with  measures  to  deploy  electricity-powered  technologies  in  the  transport  and heating sectors in a timely fashion (Section 4.2.3).

## FIGURE 4.4     Solutions and enabling infrastructure for the energy transition in heating and cooling

Renewablesbased electrification

<!-- image -->

Renewable gases

Sustainable biomass

Solar thermal heat

Geothermal heat

District heating and cooling

<!-- image -->

A long-term, integrated energy plan is also necessary to co-ordinate the deployment of renewablesbased solutions with measures to raise energy efficiency and develop the needed infrastructure, while minimising stranded assets. For example, district energy networks are long-term investments and they are affected by changes in heating and cooling demand resulting from efficiency gains. Therefore, to align the strategies of district heating infrastructure and buildings is a must (IRENA, IEA and REN21, 2020). This was underlined by the European Union's modification to the Energy Performance  of  Buildings  Directive,  requiring  synergies  between  renovation  of  buildings  and investments in district heating systems (European Commission, 2021b) (Box 4.1).

## BOX 4.1     Integrating innovation in buildings with district energy networks in the European Union

Buildings account for the largest share of energy consumption (40%) in the European Union (EU) and contribute to over a third of greenhouse gas emissions. The majority of buildings are over 50 years old and energy inefficient, and much of this stock will continue to exist in 2050 - the target year for the EU to become climate neutral. While the renovation of buildings has been a priority of EU climate actions, progress remains slow with only about 1% of the stock being renovated annually.

All  EU  member countries are required to publish a long-term building renovation strategy for 2050, as  part  of  the  'renovation  wave'  initiative  of  the  Green  New  Deal.  The  renovation  strategy  supports greater energy efficiency and the integration of renewables in the building stock. The long-term nature of the strategy provides signals regarding the potential for investments in district heating and cooling networks, by outlining the expected demand in buildings after renovation.

Source: European Commission, 2020a, 2021b.

Based on the long-term energy plans, investments are needed to upgrade existing and develop new infrastructure, often as a pre-requisite to attracting private investments in energy-transition-related solutions.  Those  are  discussed  in  this  chapter,  in  sections  dedicated  to  each  of  the  technological avenues of the energy transition. An integrated energy plan can help minimise stranded assets for a  given  climate  ambition  by  developing  national  strategies  that  leverage  existing  infrastructure. Examples include utilising existing district heating and cooling networks to deploy renewables-based solutions in cities, and repurposing parts of existing gas grids to transport green hydrogen. Synergies with the oil and gas industry can be leveraged. The offshore wind energy sector, for instance, can build on existing assets in the offshore oil and gas sector in different value chain segments, including foundations, array cables, substation structures, steelwork and cables (IRENA, 2018a).

<!-- image -->

T

Phasing out fossil fuels represents an important component of the energy transition.

## 4.1.3 Phase out fossil fuels

Phasing out fossil fuels represents an important component of the energy transition as discussed in Chapter 1. To reduce stranded assets, governments should halt the development of planned or new fossil fuel infrastructure. This can also send positive signals to other countries with similar contexts. The Government of Montenegro's announcement that it would stop the development of the second block of the coal power plant of Pljevlja, for example, drove the cancellation of a reconstruction plan for a coal power plant in North Macedonia and a new project in Kosovo* (CAN, 2020).

Some assets will need to be phased out, including fossil fuel upstream supply infrastructure, power plants, and fossil-based heating and cooling appliances or transport modes that need to be replaced. Many European Union countries (including Denmark, France, Finland, Hungary, Italy, Portugal and Slovenia) and the United Kingdom have announced a plan to phase out coal power plants by 2030; Austria  and  Sweden  successfully  phased  them  out  by  2020  (Beyond  Coal,  2021).  Some  Chinese cities including Suzhou city aim to replace all inefficient coal boilers with electric alternatives; and European cities including Athens and Madrid have announced plans to phase out petrol and diesel cars by 2025 (IRENA, 2021e, 2021f). As such plans are implemented, provisions should be made to ensure a just and fair transition and specifically to protect workers and communities. A dialogue involving all key stakeholders should be undertaken to decide how to address stranded assets.

A holistic policy framework is necessary to address the issue of fossil fuels as stranded assets and its socio-economic implications, requiring a series of measures further discussed in Sections 4.3 and 4.4. One among them is the compensation approach followed as countries seek to phase out fossil fuel assets earlier than foreseen, and to ascertain support needed for operators and communities, such as in Germany (Box 4.2).

- * This designation is without prejudice to positions on status and in line with the United Nations Security Council Resolution 1244 (1999).

## BOX 4.2     Germany's tender for coal being phased out by 2038 as part of its green recovery plan

In 2020, the Coal Phase-Out Act (the Act to Reduce and End Coal-Powered Energy and Amend Other Laws) entered into force as part of Germany's green recovery plan. The act aims to gradually reduce and eventually phase out the use of coal-based power generation by 2038. It stipulates that no new coal-based plants may begin operations after August 2020, apart from those that already hold licenses. The phase-out is expected to be carried out in three stages (Figure 4.5).

The act offers financial compensation to operators of coal-fired plants for early retirement. The reduction of  hard-coal power is to be achieved first by voluntary reductions offered by the plant operators and, after 2027, by legally mandating the reduction. To keep compensation to the minimum needed, the act set up competitive tenders where operators may offer capacity volume reductions and receive financial compensation in return. The plan was to auction 4 GW in 2020 and 1.5 GW in 2021 with non-awarded capacities in 2020 added to auctions in 2021. The auction is also designed to avoid the closure of power plants that are essential for network stability.

## FIGURE 4.5     Phase-out of coal in Germany by 2038

<!-- image -->

Source: Bundesnetzagentur, 2021.

Note: GW = gigawatt.

<!-- image -->

<!-- image -->

The first auction was held in September 2020 with a pre-determined cap on the compensation set at EUR 165 000/MW (about USD 194 000/MW) net nominal capacity. The available financial compensation decreases each year to offer an incentive to decommission a plant earlier. After 2027, no financial compensation will be paid to plant operators that will all be forced to shut down. The German Federal Network Agency determines a maximum tender volume for each auction  and  uses  a  procedure  set  out  in  the  act  in  case  there  are  too  many  bids.  Table  4.3 presents details of the first two rounds.

In  addition,  the  Structural  Support  for  Coal  Regions  Act  provides  lignite-coal  regions  with financial  aid  of  up  to  EUR  14  billion  (about  USD  11.86  billion)  and  hard-coal  regions  up  to EUR  1.09  billion  (about  USD  923  million)  to  deal  with  structural  changes  and  to  secure employment. The act also provides up to EUR 26 billion (about USD 22.02 billion) for highway and rail infrastructure improvement or expansion and creation of up to 5 000 additional jobs in federal agencies in the coal regions.

Sources: Gesley, 2020; European Commission, 2020b.

## TABLE 4.3     Results of auctions for coal plant phase-out in Germany

| ROUND     | CAPACITY AUCTIONED   | CAP ON PRICE                  | CAPACITY AWARDED   | WINNING BIDS                                                                                                                                                                                                                                         | REQUIREMENTS                                                                                                                                                                                                                                                                                |
|-----------|----------------------|-------------------------------|--------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| 2020 2021 | 4000 MW 1 500 MW     | 165 000 EUR/MW 155 000 EUR/MW | 4788 MW 1 514 MW   | 11 bids accepted (the largest for 875 MW) with a total of EUR 317 million (USD 385.6 million). Volume-weighted average award of EUR 66259/MW with bids ranging from 6047 to 150 000 EUR/MW Three bids for 757 MW, 690 MW and 67 MW. Bids ranged from | Plants retire from the wholesale market beginning 2021 and the units remain available only to transmission system operators for balancing until June-end. Operators cease coal-based power generation from July. Operators to cease coal-based generation by December 2021. Auction open to |

Sources: Shumkov, 2020; Petrova, 2021.

Note: MW = megawatt.

## 4.1.4 Eliminate distortions and incentivise energy transition solutions

Distortions that favour the uptake of fossil fuels by market structures need to be eliminated and a fiscal system established that actively supports the adoption of energy transition solutions, while disincentivising  new  and  existing  traditional  solutions  not  aligned  with  climate  ambitions.  This involves phasing out existing fossil fuel subsidies, and levying the environmental, health and social negative externalities of fossil fuels to remove market distortions as well as existing support for the fossil fuel industry (see Chapter 5).

Fiscal policies, including carbon pricing policies, should be implemented and adjusted to enhance the  competitiveness  of  renewables-based  solutions  against  fossil  fuels  (discussed  further  in Section 5.1). In Sweden, the taxation of fossil fuels has been a major driver for renewable heat, whereas low natural gas prices (reflecting subsidies to fossil fuel industries and unlevied negative externalities) hobble the competitiveness of renewable heat options in the United Kingdom and the United States (IEA, 2018).

However, as with the phasing out of fossil fuel subsidies, such interventions should be preceded by a careful assessment of their social and equity dimensions, particularly their effects on low-income populations, to ensure that they do not worsen energy poverty (Box 4.3) or have other socially regressive effects. Allaying these concerns by exempting certain household groups or energyintensive industries can compromise the viability of schemes. Instead, it may be more in line with long-term de-carbonisation objectives to provide dedicated support for low-income consumers or other highly affected parties to help them shift towards low-carbon solutions (see Section 4.5).

As with the phasing out of fossil fuel subsidies, carbon pricing policies should be preceded by a careful assessment of their social and equity dimensions.

<!-- image -->

## BOX 4.3     Addressing energy poverty

The term 'energy poverty' covers a broad spectrum of negative effects on well-being, due to affordability  challenges,  or  a  lack  of  or  insufficient  access  to  modern  energy  solutions.  In  a situation of energy poverty, a household is physically and/or financially unable to secure a level and quality of domestic energy services sufficient for its social and material needs. This situation is often accompanied by the use of dirty fuels (e.g., kerosene, traditional fuelwood), excessive time spent collecting them and low consumption of energy.

A definition of energy poverty accepted worldwide is still missing. Without a unified definition, the number of households living in this situation cannot be properly quantified. Yet, statistical data that describe some of the effects of energy poverty can help clarify the issue.

Energy poverty exists in every part of the world. In the Western Balkans, for instance, one out of three households is unable to keep adequately warm. Households with an income below 60% of the national median are particularly at risk (Figure 4.6). As a comparison, fewer than one out of ten households in the European Union faces the same challenge (but up to two out of ten among poor households).

Estimates indicate that 3 million households (out of 5 million) in the Western Balkans use outdated woodburning devices, a main indicator of energy poverty. The high dependence on biomass and poor regulatory mechanisms also endangers local forest resources, which are subject to illegal logging and black-market sales. The use of traditional biomass substantially increases indoor air pollution levels, which in Southeast Europe caused around 23 000 preventable deaths in 2016.

Governments in the region have taken steps to address energy vulnerability. They have adopted definitions  of  'vulnerable  customers',  and  many  provide  some  form  of  assistance  to  this population, mainly in the forms of cross-subsidisation, discounts on energy bills and protection from disconnection.

Source: Energy Poverty Observatory, 2020; IRENA, 2019e.

## Energy poverty exists in every part of the world.

FIGURE 4.6     Share of households unable to keep home adequately warm, by income level, in selected countries, 2019 (%)

<!-- image -->

Source: Energy Poverty Observatory, 2020.

- *  This designation is without prejudice to positions on status and in line with the United Nations Security Council Resolution 1244 (1999). Data for Kosovo are for 2018.

<!-- image -->

T

## 4.1.5 Facilitate access to finance

Public financing will play a crucial role in facilitating the adoption of energy transition technologies and solutions. Depending on local contexts, its role could vary from public ownership of transitionrelated  assets,  to  unlocking  private  sector  investments  in  energy  transition  technologies.  This  is especially needed in contexts with high risks where attracting private investments is challenging. Relevant  risks  include  country  risks  (related  to  politics,  policy  and  currency),  contractual  risks (liquidity,  counterparty  and  refinancing  risks)  and  technical  risks.  As  discussed  in  Chapter  3,  risk mitigation instruments can be an effective tool to improve the risk-return profile of projects and increase their attractiveness among private investors.

Public  funding  is  also  needed  to  reduce  technical  risks  associated  with  specific  technologies, project performance, resources and infrastructure. To reduce the risk of geothermal exploration, for example, government support measures include collecting and sharing geothermal data on public platforms, providing insurance against exploration risks and offering loan guarantees and grants to reduce the risk represented by the sunk cost of well drilling. The Government of the Netherlands, for instance, provides funds for geothermal heat projects set out by the Geothermal Heat Action Plan. Government funds are used to support risk insurance for the drilling of geothermal heat, to invest in software (ThermalGIS) for geothermal exploration, as well as grants and other financial schemes (Government of the Netherlands, 2021).

Bioenergy  projects  could  face  additional  difficulties  securing  financing  due  to  supply  chain risks  ( e.g. , unstable  feedstock  supply,  potential  negative  impacts  on  forestry  or  food  prices). Specific  public  funds  are  needed  to  facilitate  investment  from  commercial  entities.  For  example, the  Brazilian  Development  Bank  provides  loan  support  for  biomass  cogeneration  projects,  also allowing commercial banks and capital markets to step in (IRENA, forthcoming-b).

In  the  access  context,  significant  investments  are  needed  mainly  to  accelerate  the  adoption  of decentralised  renewable  energy  solutions  to  meet  electricity  and  clean  cooking  needs.  Tailored financing instruments are required to meet end-user and enterprise needs, along with investments (primarily public) in an enabling ecosystem featuring appropriate policies and regulations, capacity building and market linkages. IRENA analysis finds that investments in the off-grid sector, although growing,  are  heavily  concentrated  in  certain  regions,  countries  and  technologies  (IRENA  and CPI, 2020). Greater public and private financing needs to be mobilised and made more equitably accessible to end-users and enterprises through local financing institutions.

Greater public and private financing needs to be mobilised and made more equitably accessible to end-users and enterprises.

## 4.1.6 Foster innovation

As indicated in Chapter 2, systemic innovation will play a central role to drive down costs and ramp up the pace of the energy transition. A number of enabling policies can strengthen the innovation process  across  its  various  dimensions  of  technology,  infrastructure,  financing,  business  models, market design and regulation, as well as governance and institutional frameworks. The scope of innovation extends far beyond technology supply.

Research,  development  and  demonstration  policies relate  to  direct  funding  of  research  and development across a wide range of energy transition technologies ( e.g. ,  fast-charging infrastructure, green hydrogen linkages with industrial use) that are at different stages of market maturity, as well as support of demonstrations and piloting to create commercial-scale solutions.

A deployment-oriented innovation approach is needed for the success of the energy transition, particularly as the pathway from invention to mainstream technology may take long. The Innovation Toolbox  (www.irena.org/innovation/Toolbox)  developed  by  IRENA  shows  how  30  concrete innovations in technology, market design, business models and system operation can be used to transform  country  power  systems  by  increasing  flexibility.  Power  systems'  flexibility  is  a  priority for this decade, as an enabler of large shares of solar and wind. In terms of enabling technologies, battery storage is at the centre of present energy transition efforts.

Policies can also help to deploy enabling infrastructure ( e.g. ,  charging infrastructure for electric vehicles)  faster.  This  highlights  another  priority  for  this  decade  -  streamlining  infrastructure planning and permitting. New business models come into play, including aggregators and peerto-peer trading platforms supported by digital technologies that enable small players to reap the full benefits of their rooftop solar systems, while system operators can benefit from the services of  distributed  energy  resources  (IRENA,  2020k).  Such  new  business  models  are  now  widely deployed. In some jurisdictions, laws and regulatory regimes need to be adjusted to allow such innovations to be scaled.

Innovation in market design has proven critical to accelerate the transition (IRENA, 2017c). New technologies come with new types of services that can be provided to energy systems, but those services  need  to  be  properly  monetised  via  adjustments  to  market  design  ( e.g. ,  greater  time  or geographic resolution of energy prices).

For sectors that cannot be directly electrified, green hydrogen can play a key role, if electrolysers can be operated flexibly and their cost falls enough to warrant flexible operation. This is an example of an emerging technology option that can help to revolutionise the way we produce and consume energy. Meanwhile, innovations are required across the full production, shipment and deployment chain. Finally, policies can facilitate innovation through the deployment of new standards and certification processes, as well as through international collaboration by promoting sectoral agreements that accelerate deployment of new technologies.

<!-- image -->

T

## 4.1.7 Raise awareness among consumers and citizens

Consumers and citizens play a big role in the energy transition. On one hand, they can influence governments and corporations to move faster in their decarbonisation plans. For example, customer, shareholder and staff demand has been identified as one of the main drivers for corporate sourcing of renewable heat (IRENA Coalition for Action, 2020a). On the other hand, citizens make proactive choices regarding their energy consumption and sources.

Sharing information and raising awareness through public campaigns are vital for citizens to adopt clean solutions and behavioural changes in line with reducing energy consumption (Section 4.2.2). In heating and cooling, for example, government actions - at the national and city levels - to raise awareness regarding the potential and benefits of renewable solutions are essential to stimulate interest and strengthen confidence among potential consumers and relevant actors. South Africa launched the Solar Water Heater Campaign to increase public awareness while similar policies helped Barcelona (Spain), Rizhao (China) and Cape Town (South Africa), among other cities, to promote solar thermal solutions (IRENA, IEA and REN21, 2020).

Active  engagement  of  consumers  and  citizens  is  important  to  integrate  the  complex  dynamics of  social  systems  within  the  energy  transition.  Holistic  policies  that  address  social  feedback  and concerns  -  for  instance,  those  arising  from  the  implementation  of  regressive  policies  (discussed further in Section 4.4) - are better perceived by society at large and contribute to improved energy transition outcomes for the society, economy and planet.

Active engagement of consumers and citizens is important to integrate the complex dynamics of social systems within the energy transition.

<!-- image -->

## POLICIES TO SUPPORT THE TECHNOLOGICAL AVENUES OF THE ENERGY TRANSITION 4.2

While  cross-cutting  policies  provide  an  enabling  environment  for  the  energy  transition  to  move forward seamlessly, specific policies and measures are needed as well to increase the deployment of renewables, both in power and direct uses; promote energy conservation and efficiency; enable the electrification of end uses and support the development of green hydrogen and sustainable bioenergy. These are discussed further in this section and summarised in Table 4.4.

Specific policies and measures are needed to increase the deployment of renewables, promote energy conservation and efficiency, enable the electrification of end uses, and support the development of green hydrogen and the sustainable use of bioenergy.

<!-- image -->

## TABLE 4.4     Overview of policies to support energy transition solutions

TECHNO­

OBJECTIVE

EXAMPLES OF MEASURES

COMMENTS

LOGICAL

AVENUE

| Renewables (power and direct uses)   | Deploy renewable energy in end uses                                | Subsidies for solar water heaters in China, Tunisia and Lebanon.                                                                                | These policies include regulatory measures that create a market, as well as fiscal and financial incentives to make them more affordable and increase their cost competitiveness compared to fossil-fuel-based solutions.                        |
|--------------------------------------|--------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Renewables (power and direct uses)   | Deploy renewable energy in the power sector                        | Dedicated regulations for mini-grids in Nigeria, Kenya, Uganda, Zambia, Sierra Leone and Senegal.                                               | The choice of instrument and its design should consider the nature of the solution ( e.g. , utility scale, distributed, off-grid), the sector's level of development, the power system's organisational structure and broader policy objectives. |
| Energy conservation and efficiency   | Increase energy conservation and efficiency in heating and cooling | In the United States, China, Canada and Japan, almost all space cooling activities need to meet mandatory Minimum Energy Performance Standards. | Energy efficiency policies such as strict building codes, support for building retrofits and appliance standards are critical for the energy transition in buildings and industrial processes.                                                   |
| Energy conservation and efficiency   | Increase energy conservation in transport                          | Vancouver (Canada), launched a city campaign to encourage cycling and reduce private car use.                                                   | Decarbonising the transport sector, among other measures, requires a shift from energy-intensive modes to low- carbon modes.                                                                                                                     |
| Electrification of end uses          | Electrify heating and cooling                                      | Denmark reduced the tax paid on electricity-based heat as part of the country's plan to be fossil fuel free by 2050.                            | Targets for renewable power should consider the rising demand from the electrification of end uses, in line with long-term decarbonisation objectives.                                                                                           |
| Electrification of end uses          | Electrify transport                                                | Costa Rica set a target for 100% of vehicle sales to be zero emission by 2050, and Japan aims to have all cars be electric by 2050.             | Moreover, policies and power system design are needed to support electrification in achieving its potential for providing system flexibility.                                                                                                    |
| Green hydrogen                       | Support the development of green hydrogen                          | By 2020, 12 countries and the European Union had implemented green hydrogen policies.                                                           | An enabling policy framework should consider four key pillars: a national green hydrogen strategy, priority setting, guarantees of origin and enabling policies.                                                                                 |
| Sustainable bioenergy                | Ensure the sustainable use of bioenergy                            | The EU's revised Renewable Energy Directive (EU REDII) enhanced the sustainability criteria for bioenergy                                       | Renewable energy is not exempt from sustainability concerns. Some of these concerns include greenhouse gas emissions related to land-use change, and impacts on air and water quality and biodiversity.                                          |

## 4.2.1 Deploy renewables (for power and direct uses)

Policy  options  supporting  the  deployment  of  renewable  energy  technologies  and  solutions  vary according to the level of development of the sector. Instruments to deploy renewables have predominantly focused on the power sector since the early 2000s. With evolving market conditions and the changing maturity of technologies and markets, the instruments have adapted over time. For  instance,  the  developments  made  to  date  have  enabled  many  countries  to  transition  from administratively set to competitively set pricing mechanisms for renewable power. As the share of renewable electricity has grown, integration, flexibility and power market design aspects have also come to the fore in policy making.

Instruments to support the direct use of renewables in heating and cooling and transport have so far not received the same level of policy attention, as is evident in target setting and deployment trends. Accelerating the pace and depth of the energy transition will require a continuing focus on the power sector, along with much greater policy efforts in the heating and cooling, and transport sectors. This section discusses policies to accelerate renewables' adoption across end-use sectors. For both power and direct uses, deploying renewables at the scale needed for the 1.5°C Pathway will  require  policies  to  integrate  impacts  across  society  and  planet,  and  minimise  any  potential negative impacts. This issue is further discussed in Section 4.2.5 for bioenergy and Section 4.3.4 for solar photovoltaic (PV) and other transition technologies.

Accelerating the pace and depth of the energy transition will require a continuing focus on the power sector, along with much greater policy efforts in the heating and cooling, and transport sectors.

<!-- image -->

## Deploy renewable energy in end uses

Policies  supporting  the  deployment  of  renewable  energy  for  heating  and  cooling  and  transport include  regulatory  measures  that  create  a  market  for  these  technologies,  as  well  as  fiscal  and financial incentives, such as subsidies, grants and tax credits, to facilitate adoption and make them more equitably accessible for all types of users.

## Measures to create a market for renewable energy solutions

Policy makers need to establish dedicated, clear and long-term frameworks for the development of  solutions  such  as  solar  water  heaters  and  sustainable  biofuels.  Such  frameworks  can  include roadmaps, industrial strategies and specific targets. For  example, India is targeting 20 million square metres (m 2 ) of solar thermal collectors by 2022. Targets can also be set at the regional level. The Economic Community of West African States adopted the target to deploy solar thermal heating for around 50% of all health centres and schools, 25% of hotels and 25% of the agri-food industry by 2030 (ECREEE, 2015). The EU's revised Renewable Energy Directive to 2030 (RED II) aims for 14% of renewables in final energy demand of transport, including 3.5% from advanced biofuels produced from waste, residues and other cellulosic feedstocks (IRENA, forthcoming-b).

Targets for green gases are also emerging, especially with the increased interest in green hydrogen. France set a target to make 10% of the gas consumed in the country renewable by 2030; Denmark aims to make 100% of the gas injected into its grid renewable by 2035. Spain wants 25% of hydrogen consumed to be green by 2030. Section 4.2.4 presents a dedicated analysis of policies for green hydrogen.

Targets and roadmaps can be supported by mandates , such as for biofuel blending in Brazil, China, the European Union and the United States; or requiring the installation of solar thermal systems in new or existing buildings as in Kenya or Spain. Such mandates, like targets, can also be implemented at the city level (see Box 4.4).

City-level policies play a key role in creating a market for district heating and cooling and green gas services where guaranteed anchor loads are crucial for the development of the needed infrastructure. Mandating  connections  to  district  heating  and  cooling  networks  or  renewable  gas  grids  (where these exist) in new urban developments, public buildings and other opportune locations ensure a stable demand for the network and reduce investment risk. Such mandates have been introduced in Amsterdam (the Netherlands), Oslo (Norway), Belgrade (Serbia) and Abu Dhabi and Dubai (United Arab Emirates).

Policies to support renewables include regulatory measures that create a market for their adoption, and financial incentives to make them more equitably accessible for all users.

## BOX 4.4     The role of cities in the energy transition in end uses

Cities play a major role in advancing the global energy transition. They account for around three quarters of global primary energy and contribute to 70% of greenhouse gas emissions. At the same time, residents of urban areas face higher rates of air pollution, mainly resulting from the use of fossil fuels - a key and urgent driver of the energy transition.

The energy transition in cities is a story of urban transformation. Renewables have far-reaching effects that go beyond the energy sector; they influence transportation, buildings, land use and a slew of other vital city sectors. The energy transition presents an opportunity to reimagine cities in a number of ways that benefit both people and the environment.

There are several roles cities can play in accelerating the deployment of renewables in end uses (Figure 4.7). Actions focus mainly on measures to promote the electrification of public transit and to curb the use of internal combustion engine vehicles in urban areas, solar thermal ordinances, and renewable heating and cooling mandates.

## FIGURE 4.7     Roles of municipal governments in the energy transition

<!-- image -->

<!-- image -->

## Financial and fiscal incentives for the increased adoption of renewables in end uses

Financial incentives are still required to increase the adoption of renewables in many jurisdictions. For heating and cooling, centralised solutions such as renewables-based district heating and cooling and decentralised solutions such as domestic solar water heaters are not always cost competitive compared to fossil fuels. Financial incentives can be provided as single-payment subsidies, grants or loans. France's Fonds Chaleur (Heat Fund), for example, offers subsidies for residential, commercial and industrial  renewable  heat,  including  small-scale  biomass  applications  (EurObserv'ER,  2020). On a local level, Grenoble increased the Fonds Chaleur by adding local financial aid to small-scale projects (REN21, 2019). China, Tunisia and Lebanon provide subsidies for solar water heaters (IRENA, forthcoming-c). Germany's Market Incentive Programme provides low-interest loans for large-scale projects  for  district  heating  and  industries  and  grants  for  small-scale  renewable  heat  solutions (IRENA, IEA and REN21, 2020).

Fiscal  incentives such  as tax  credits,  reductions and accelerated depreciation are  commonly used to support the energy transition in end uses. For heating and cooling, residents in the United States could receive up to USD 500 in tax credits for the installation of geothermal heat pumps, solar water heaters and other energy efficiency technologies (United States DoE, 2021). In transport, such incentives are needed to promote biofuel production, distribution and consumption, as well as research and development. In 2016, Argentina put in place tax exemptions for biodiesel production and Sweden reintroduced tax cuts for ethanol and biodiesel (REN21, 2017).

Fiscal and financial incentives typically benefit individuals and corporations that have the financial capacity to invest in such solutions (with some financial support), with the risk of leaving behind low-income households locked in traditional and less efficient solutions ( e.g. ,  traditional  biomass for  heating  and  cooking  or  inefficient  combustion  engine  vehicles)  thus  contributing  to  further energy poverty (Box 4.3). It is crucial that a holistic policy approach be adopted that considers and addresses the aggregate socio-economic implications of various energy transition policy actions. Provisions should be made to ensure that direct support reaches the lowest-income households. For example, the Government of New Zealand provides grants to cover 90% of the cost of heat pumps or efficient pellet/wood burners and insulation improvement for low-income homeowners through the 'Warmer Wiki Homes' programme (EECA, 2021).

Regarding access, fiscal and financial incentives have played a crucial role in facilitating the adoption of renewables-based  clean  cooking  solutions.  Household  biogas  digestor  programmes  have benefited from an appropriate mix of grants, increasingly deployed as results-based financing and concessional loans. The Africa Biogas Partnership Programme, for instance, deployed over 70 000 biogas digestors across six countries in Sub-Saharan Africa through tailored financial incentives. Similarly,  Viet  Nam's  national  biogas  digestor  programme  facilitated  the  deployment  of  over 250 000 domestic systems initially through household subsidies followed by a transition to resultsbased financing for suppliers to support long-term market development (IRENA, 2018b). Other clean cooking solutions, including improved cookstoves, benefit from tax exemptions and rebates thus improving affordability for households (WHO, n.d.).

## Auction design should be tailored to country-specific conditions and broader policy objectives.

## Deploy renewable energy in the power sector

Regulations  and  pricing  instruments,  together  with  fiscal  and  financial  incentives,  support  the deployment of renewables-based power, while at the same time support measures are required to enable the electrification of end uses (see Section 4.2.3).

## Regulatory and pricing instruments to support renewable power generation

Scaling  up  renewable  energy  adoption  in  the  power  sector  requires  regulatory  and  pricing instruments, which adapt as renewables become cost competitive compared to fossil-fuel-based electricity  in many more jurisdictions. The choice of instrument and its design should consider the 2 nature of the solution ( e.g. , utility scale, distributed, off-grid), the sector's level of development and the power system's organisational structure and broader policy objectives. Each instrument should be adopted with specific considerations.

Pricing policies such as feed-in tariffs and premiums can be administratively set, in which case they need to continuously adapt to changing market conditions. Regular tariff-level adjustment, such as through degression mechanisms, can help reflect the falling costs of a technology and its growing deployment. Otherwise, prices can be set through competition.

Auctions are being increasingly adopted to keep pace with falling technology costs and to deliver renewable electricity at competitive prices globally. By 2020, around 209 countries had adopted auctions  (REN21,  2020),  and  by  2018,  the  global  average  prices  from  solar  PV  and  onshore wind  auctions  had  decreased  by  77%  and  36%,  respectively,  compared  to  2010  (IRENA,  2019c). In addition  to  procuring  renewable  electricity  cost-effectively,  auctions  can  be  designed  to pursue  broader  policy  objectives  (Box  4.5).  However,  if  not  designed  well,  auctions  can  lead to underbidding and projects not being completed on time or at all, and in some cases, they risk favouring large players, and leaving the small and new players behind. To take advantage of the strengths  of  auctions  and  minimise  the  risks  associated  with  their  weaknesses,  auction  design should be tailored to country-specific conditions and broader objectives. 3

- 2 IRENA (2021b) analysis presented in Renewable Power Generation Costs in 2020 finds that more than 60% of the renewable capacity added in 2020 achieved lower power costs than the cheapest new fossil-fuel plants.
- 3 IRENA  provides capacity building and policy advice to countries looking to design renewable energy auctions through the Policy Framework for the Energy Transition (PFET).

<!-- image -->

## BOX 4.5     Auction design to support policy objectives beyond price

Auctions are flexible in their design and they can serve objectives beyond price as trade-offs are studied and choices are made regarding the design elements (Figure 4.8). Auctions can be designed to maximise socio-economic benefits, through the inclusion of small and new players, job  creation,  regional  development  and  community  benefits,  and  the  development  of  local industries. South Africa was a pioneer in promoting economic development, especially in underserved regions, through qualification requirements and winner selection criteria that consider socio-economic development objectives.

Innovative  auction  design  can  also  help  address  some  of  the  challenges  related  to  system integration as shares of variable renewable energy generation increase. Mexico has considered geographical  allocation  signals  according  to  network  integration  feasibility  and  costs.  India and  South  Africa  have  sought  to  concentrate  renewable  project  developments  in  specific geographical areas, while hybrid technologies have been auctioned in Jordan (PV with storage), India (wind and PV) and Morocco (concentrating solar power and PV).

## FIGURE 4.8     Auction design for objectives beyond price discovery

<!-- image -->

Source: IRENA, 2019c.

Note: VRE = variable renewable energy.

Competitive procurement is also adopted in corporate purchase programmes for renewable power, enabling the buy-in of industry into renewables and accelerating investment in the energy transition. Next to supporting an effective system for the issuing and tracking of energy attribute certificates, energy  market  structures  that  allow  for  direct  contracting  between  companies  and  renewable energy suppliers support the further uptake of corporate sourcing of renewables.

For non-utility-scale projects, such as off-grid systems (Box 4.6) and grid-connected distributed solutions,  tailored  regulatory  and  pricing  instruments  are  needed.  Distributed  generation  can  be supported through net metering and net billing. However, careful consideration is needed to avoid jeopardising  the  system's  cost  recovery  and  prevent  cross-subsidisation  among  customers  who self-consume and those who do not. Indeed, these and other kinds of misalignments between the expected and the actual outcome of power system policies and regulation are bound to increase as  the  energy  transition  progresses,  if  no  measures  are  taken  to  redesign  the  power  system's organisational structure (see In focus section).

## BOX 4.6     Policies for off-grid renewable energy solutions

Facilitating the deployment of off-grid renewable energy solutions, such as mini-grids and stand-alone systems, to improve modern energy access requires dedicated policies and regulations.

In  the  specific  case  of  stand-alone  systems,  policies  can  strongly  influence  the  accessibility  and sustainability of such solutions for rural communities. Fiscal incentives, such as import duty and valueadded tax exemptions, are often introduced to incentivise market development; these directly improve the affordability of stand-alone systems (IRENA, 2019f). Other supportive measures include levelling the playing field, introducing quality standards and establishing dedicated consumer/enterprise financing channels as part of a broader programme.

Scaling up renewable energy mini-grids requires dedicated regulations to address key areas such as licensing and permitting requirements, tariff-setting frameworks and the implications of the arrival of the main grid (IRENA, 2018c). A growing number of countries have introduced dedicated regulations meant  to  scale  up  mini-grids,  including  Kenya,  Nigeria,  Senegal,  Sierra  Leone,  Uganda,  and  Zambia (UNIDO,  2020).  Moving  beyond  addressing  deployment  and  investment  risks,  policies  also  need  to address aspects related to capacity building and linkages between the sector and productive end uses (see Section 4.3). All of these have a strong bearing on the scalability of off-grid solutions and the socioeconomic outcomes of deployment policies.

<!-- image -->

## Fiscal and financial incentives for renewables-based solutions

Fiscal and financial incentives such as tax incentives, subsidies and grants complement regulatory and pricing mechanisms and are needed to improve access to capital, lower financing costs and make energy transition solutions more equitably accessible for all potential end users.

Reductions  in  sales,  energy,  value-added  or  other  taxes  on  renewable  electricity  technologies have been instrumental in kick-starting deployment in some countries in Southeast Asia and subSaharan Africa (IRENA, IEA and REN21, 2018), mainly in the access context (Box 4.6). Production and investment tax credits were instrumental in driving the development of solar and wind in the United States. But since their initial inception, federal renewable tax credits have expired, been extended, modified or renewed numerous times, creating uncertainty and multiple boom-and-bust cycles in the industry. When implemented, tax credits should be long term to reduce uncertainty and attract stable investments.

Capital subsidies for renewable electricity technologies are needed to reduce upfront capital costs in early stages of deployment (or when targeting low-income end-users), after which they may be replaced  by  other  forms  of  incentives,  including  performance-based  subsidies.  In  Nepal,  capital subsidies offered in 2013 covering 40% of project capital costs - along with a soft loan covering another 40% - were phased out to give way for generation-based support in 2016, thereby increasing the efficiency of systems (Climatescope, 2016). Grants are needed to fund research and development, demonstration projects and feasibility studies to support the wider deployment of technologies and the integration of variable renewable energy into the power system (see Section 4.1).

Fiscal and financial incentives complement regulatory and pricing mechanisms. They improve access to capital, lower financing costs and make energy transition solutions more equitably accessible for all potential end users.

## Public investments in enabling infrastructure and flexibility mechanisms

Depending  on  local  contexts,  public  investments  will  play  a  fundamental  role  in  upgrading  and expanding power grids and deploying power system flexibility to enable the integration of greater shares of variable renewable energy (VRE). 4  In liberalised power market settings, private investments particularly in flexibility options may still be attracted where appropriate organisational structures exist within the power sector (see In focus section). The flexibility options include the deployment of short- and long-term storage solutions (pumped hydropower, chemical batteries, hydrogen storage and thermal storage), demand-side resources (such as industrial loads, or residential ones, managed by aggregators), interconnections among different power pools and dispatchable renewable power plants. Electrification will require strategies for the adoption of digital solutions to unlock the hidden flexibility of electric loads, control the grids remotely and provide a more granular visibility over grid status  to  power  system  participants.  The  new,  flexible,  decentralised  power  system  will  need  an organisational structure fit for the renewable energy era.

The new, flexible, decentralised power system will need an organisational structure fit for the renewable energy era.

- 4 For  an  exhaustive discussion of flexibility and the role of governments in creating the enabling frameworks for power sector transformation, see IRENA (2019a) Innovation Landscape for a Renewable Powered Future: Solutions to Integrate Variable Renewables , and the related innovation toolbox: www.irena.org/innovation/Toolbox.

## In focus - the organisational structure of power systems for the renewable energy era

A  smooth  energy  transition  comprises  a  technological  transition,  systemic  changes  and  the reorganisation of the power system. While the technological transition and systemic changes are relatively well understood, the reorganisation of the power system lags behind (Figure 4.9), held back by implicit assumptions that current organisational structures are appropriate for the renewable energy era. Power system organisational structures were designed with the blueprint of fossil fuel technologies. But the energy transition is transforming how electricity is produced, transmitted and consumed.  Consequently,  the  interactions  between  the  different  elements  of  the  power  system (organisational structures, technologies and policies) and with the wider energy, socio-economic and planetary systems are also changing.

## FIGURE 4.9     Unequal advance in different transition layers, with organisational structures lagging behind

## Energy Transition

<!-- image -->

Both  regulated  and  liberalised  power  systems  face  similar  transition-related  challenges.  Merely adjusting and fixing, bit by bit, the organisational structures of current power systems will not suffice, and might in fact lead to additional misalignments producing unwanted effects able to derail the energy transition (see Box 4.7).

This is not new. Energy systems are set up to provide energy services to society, but in delivering those  services,  undesirable  impacts  on  societies  have  been  produced.  Important  misalignments have, for instance, led to climate change and air pollution. This results from organisational structures of the fossil fuel era not properly aligning the costs, price and value dimensions of energy. While the  energy  transition  itself  is  expected  to  mitigate  both  climate  change  and  air  pollution,  as  the transition  progresses,  new  fundamental  misalignments  arise  (IRENA,  2020d),  with  potentially severe consequences, if unaddressed.

Energy systems are set up to provide energy services to society, but in delivering those services, undesirable impacts on societies have been produced.

## BOX 4.7     Definitions of power system organisational structure and misalignments

## Power  system  organisational  structure

refers  to  the  structural  elements  of  both liberalised and centrally-planned power systems that guide the interactions between  all  agents  in  the  procurement and cost allocation of electricity and power services.  Structural  elements  encompass regulations, markets and ownership regimes.

Misalignment: represents  any  conflicting interaction of different components within  the  power  system  (be  they  related to technology, policies, organisational structures, or others) with each other or with elements  in the wider  energy, socioeconomic and planetary systems, producing undesired effects in the pursue of a just and ambitious energy transition.

Organisational structures should be properly  informed  and  guided  by  value, costs  and  prices  considerations.  The  term 'power  market'  is  equivalent  to  'power system organisational structure' for a liberalised power system.

<!-- image -->

## The misalignments

Understanding misalignments requires simultaneously considering the concepts of cost, price and value, as well as their alignments or lack thereof. The ultimate role of the organisational structure is  setting up pricing mechanisms that allow cost recovery while reflecting the value of the power system and fostering social value creation.

Pricing  mechanisms  deal  with  part  of  the  challenge  and  are  complemented  by  additional  pricing components such as subsidies and regulated payments. The cost and price dimensions often have hidden components (such as externalities) that may result in misalignments (IRENA, 2020d). The value dimension is the most often overlooked, while in fact it should be the powerhouse for socio-economic activity. It comprises both power system value and additional social value. Even for renewable energy technologies  the  contribution  to  the  value  dimension  differs  depending  on  how  and  where  these technologies are developed, deployed and operated. Price minimisation is often adopted as the main or sole goal. However, minimising price is likely to produce significant misalignments.

The most known and discussed misalignment (see Figure 4.10) is that related to incumbent marginal pricing and the deployment of renewable generation (also known as cannibalisation effects or the missing money problem), although its wider implications for the energy transition are still not being properly addressed. Indeed, today's prevalent marginal-price-based organisational structures are misaligned with the requirements of generation technologies with low operating expenditure and limited  dispatchability  (and  therefore  low  marginal  costs),  making  them  unfit  for  the  renewable energy era. The increasing penetration of renewable energy generation with low marginal costs, under marginal pricing mechanisms, results in a compression of clearing prices. This has often been celebrated as good news, with the promise of dramatically lowering electricity prices for everyone as  soon as support mechanisms for renewable energy are phased out. But this misses the point about the dynamics at play, since retiring support mechanisms would collapse the system operating under the current organisational structure. In life-cycle terms, the total costs of providing renewable

The ultimate role of the organisational structure is setting up pricing mechanisms that allow cost recovery while reflecting the value of the power system and fostering social value creation.

Dispatched capacity

Wholesale price

Capacity

(MW)

Low OPEX/Regulated

Hydro

Coal

Dispatched capacity

Wholesale price

Natural Gas renewable power

## FIGURE 4.10     Misalignments in marginal pricing allocation mechanisms: Missing money and cannibalisation effects

Note: OPEX = operating expenditure; MW = megawatt; MWh = megawatt hour.

<!-- image -->

electricity are lower than for fossil fuels, but in the absence of the right organisational structure these potential benefits cannot be materialised. Given the high ratio of capital expenditure to operating expenditure in the renewable energy generation cost structure, the almost unlimited compression of clearing  prices  brought  about  by  renewable  energy  deployment  under  marginal  pricing mechanisms is  a  recipe  for  failure.  The  more  renewable  energy  enters  the  system,  the  lower  its remuneration becomes, reducing prospects for cost recovery and paralysing new investments, even when renewable energy is completely cost competitive. Moreover, the deployment of renewable energy under this paradigm is unlikely to properly address the value dimension, with the deployed renewable energy capacity not contributing to social value creation as much as it could and not even adequately contributing to power system value. Effects from this misalignment ripple out beyond renewable energy generation to affect the needed flexibility mechanisms being procured under the same marginal pricing mechanism. Hence, an organisational structure based on marginal pricing cannot support a power system based on renewable energy generation.

Oil

Capacity

(MW)

<!-- image -->

## The way forward

The time has come for a new power system organisational structure that can support the energy transition and the power systems of the future. Until now, efforts to encourage this evolution have involved  adjustments  to  current  power  system  structures,  which  have  contributed  to  some  of the misalignments. Without a more comprehensive rethinking of power system structures, those misalignments will create barriers that could delay or even endanger the energy transition.

The good news is that instruments that have proved capable to support the energy transition, if properly  integrated,  are  already  available:  power  purchase  agreements  have  proven  suitable  for supporting  the  deployment  of  capital-intensive  renewable  power  plants,  minimising  the  cost  of procuring renewable power by keeping finance costs low. Wholesale markets featuring temporal and spatial granularity have proven able to elicit investments in flexible resources.

The 'dual procurement' approach takes into consideration these experiences and integrates them into a holistic vision of how a power system's structure could be made fit for the transition. In the dual  procurement  approach,  the  procurement  of  electricity  is  divided  into  two  complementary mechanisms,  each  one  fit  for  the  product  it  procures:  long-term  renewable  energy  (LT-RE) procurement  and  short-term  flexibility  (ST-flex)  procurement.  Auctions  or  public  ownership become the backbone of the LT-RE, through long-term procurement mechanisms that address the requirements of capital-intensive technologies. The ST-Flex addresses the procurement of flexible resources  needed  for  the  reliable  operation  of  a  renewable-energy-based  power  system,  and is  based  on  marginal prices, with a granular bidding format and without scarcity price caps that could limit the economic feasibility of investments in flexibility. Essential characteristics of the two procurement mechanisms are described in Table 4.5.

Without a rethinking of power system structures, misalignments will create barriers that could delay or even endanger the energy transition.

TABLE 4.5     Overview of policies to support energy transition solutions

## LT­RE PROCUREMENT

## ST­FLEX PROCUREMENT

| Based on periodic long-term product-based allocation mechanisms (auctions, direct                                                                                                                                                                                         | Based on the short-term dimension of current dispatch mechanisms (balancing markets,                                                                                                                                                                                                 |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Procures renewable electricity (VRE and dispatchable RE) and enables RE supply adequacy with the adequate anticipation                                                                                                                                                    | Procures flexibility (DSM, DER, storage, dispatchable RE, P2X, V2G, …) and enables flexibility supply adequacy                                                                                                                                                                       |
| Designed to match supply and demand as much as possible on the long-term (capturing temporal and locational value to the power system)                                                                                                                                    | Matching supply and demand on the short and very short term (capturing temporal and locational value to the power system)                                                                                                                                                            |
| Driven by long-term load forecast within integrated energy planning                                                                                                                                                                                                       | Driven by the short- and very short-term deviations between the scheduled load/REs production and real demand/production                                                                                                                                                             |
| Provides a safe investment environment that minimises finance costs for CAPEX-intensive technologies                                                                                                                                                                      | Liberalised systems: allowing prices to vary from very high to low and even negative. Additional regulated payments if needed (especially during the transition period: LT-Flex) Regulated systems: enabling framework for deploying and operating the required flexibility capacity |
| The dual procurement economic signals should reach the retail rates (or prices) of all users to promote their participation in system operation, while simultaneously addressing distributional issues so that collaborative engagement is achieved in a just transition. | The dual procurement economic signals should reach the retail rates (or prices) of all users to promote their participation in system operation, while simultaneously addressing distributional issues so that collaborative engagement is achieved in a just transition.            |
| Socially-wide collaborative governance (public or private): Enabling effective social and users participation in planning and operation, fostering the required collaborative framework for social value creation                                                         | Socially-wide collaborative governance (public or private): Enabling effective social and users participation in planning and operation, fostering the required collaborative framework for social value creation                                                                    |

Source: IRENA, forthcoming-d.

Note:  CAPEX  =  capital  expenditure;  DER  =  distributed  energy  resources;  DSM  =  demand-side  management; LT-Flex  =  long-term  flexibility;  LT-RE  =  long-term  renewable  energy;  P2X  =  Power-to-X;  RE  =  renewable  energy; ST-flex = short-term flexibility; V2G = vehicle to grid; VRE = variable renewable energy

<!-- image -->

T

## 4.2.2 Increase energy conservation and efficiency

As  noted  in  Chapter  2,  energy  conservation  and  efficiency  will  deliver  around  a  quarter  of  the emissions  reductions  needed  in  the  energy  sector  under  the  1.5°C  Pathway.  Energy  efficiency includes measures related to reducing demand and improving efficiency across industry, buildings and transport sectors.

## Increase energy conservation and efficiency in heating and cooling

Critical for the energy transition in buildings and industrial processes are energy efficiency policies such as building codes, support for building retrofits, labelling policies and appliance standards. Most are cost efficient in the medium term and can improve the cost competitiveness of renewable heating and cooling applications. It is, however, important to address prevailing challenges associated with ownership structures, equitable access and benefits sharing of energy efficiency investments and policies,  as  well  as  potentially  extended  payback  periods.  Campaigns  to  raise  the  awareness  of end users also play an important role in the adoption of energy efficiency measures. This section discusses a portfolio of policy measures to accelerate the adoption of energy efficiency measures across sectors.

## Minimum Energy Performance Standards

Minimum  Energy  Performance  Standards  (MEPS)  could  support  industrial,  commercial  and residential users to procure and switch to more energy-efficient appliances or equipment such as electric heating and cooling technologies. MEPS have been widely used by countries to regulate the cooling appliance market, covering more than 80% of space-cooling appliances in the commercial sector and 65% for residential uses. In the United States, China, Canada and Japan, almost all the space-cooling activities need to meet the mandatory MEPS (see Figure 4.11) (IRENA, IEA and REN21, 2020). However, the MEPS need to be adjusted according to technology and market conditions to ensure that mandates are optimally set.

Energy efficiency policies are critical for the energy transition.

<!-- image -->

## FIGURE 4.11     Global energy use for space cooling covered by MEPS in selected juristictions, 2018

## Mandatory policy coverage (%)

<!-- image -->

Source: IRENA, IEA and REN21, 2020.

In Australia and New Zealand, the Energy Label Policy (since 1987) and MEPS (since 2004), as the major pillars of the Equipment Energy Efficiency (E3) Programme, have significantly improved the efficiency performance of space-cooling equipment in the market. In 2018, Australia amended the energy labelling policy to cover more technologies and revised the efficiency metrics. New regulation also  requires  labelling  the  demand-response  capacity  which  could  be  aggregated  and  provide system flexibility. Japan's Top Runner Programme provides another successful example. It targets energy-intensive equipment, which is regulated by a set of energy efficiency standards and targets. The Top Runner Programme labels the most energy-efficient products on the market to encourage competition among manufacturers. This is complemented by disclosing and fining companies that are failing to achieve the energy efficiency targets (IRENA, IEA and REN21, 2020).

<!-- image -->

## Building codes

Building codes represent a set of regulations and requirements introduced by national or sub-national governments to guide buildings' construction, operation, renovation and repair activities. Building codes can be mandatory or voluntary and may cover only new buildings or also existing buildings and structures. The building codes can set requirements for the energy efficiency of buildings by specifying insulation standards and therefore reduce the heating and cooling needs. They can also set greenhouse gas emission targets and parameters for carbon footprints. In 2019, only 41 countries had building codes in place to mandate energy efficiency and renewable energy.

In France, the building codes include requirements for the carbon intensity of buildings' heat supply. In  Scandinavian countries, building codes are widely adopted to set energy efficiency standards and encourage renewable heat. In Finland, the carbon intensity of heating is required by building codes. Sub-national governments including municipalities could play pioneering roles by adopting ambitious targets and standards in local building codes and related policies. The member cities of the Global Covenant of Mayors for Climate &amp; Energy have committed to adopt and improve local building codes to be more ambitious than national standards. The European Union has required all new buildings to be nearly zero-energy by 2021. Singapore has also set zero-energy standards for new and existing buildings.

## Policies for building retrofitting and renovation

Building retrofitting and renovation could improve energy performance through improved insulation and structure, introducing more energy-efficient technologies (such as district heating and cooling) and  other  solutions.  Policies  to  support  retrofitting  and  renovation  for  reduced  emissions  and consumption could be included in the building codes, including financial incentives and standards for buildings' retrofitting, refurbishment and renovation.

## Policies and measures for district heating and cooling

Investments  are  also  needed  to  upgrade  ageing  district  heating  and  cooling  networks  with  low efficiency  and  high  operating  temperatures  (designed  initially  for  fossil-fuel-based  heat),  which are not compatible with many renewable technologies, and to develop new ones. In this context, financial incentives, fiscal measures and guarantees can offset the high capital costs and financial risks. Measures include subsidies, grants or energy-related tax incentives for private-sector utility providers  based  on  decarbonisation  impacts.  Debt  guarantees  to  minimise  risks  for  potential investors and concessional finance from multilateral development banks may be needed where it is difficult to secure financing locally or obtain interest-rate buydowns for more accessible finance (IRENA, 2017d). Kazakhstan is using development bank loans to refurbish its district heating systems and Denmark, Germany, Iceland, Norway and Sweden all offer financial incentives for investment in district heating and cooling infrastructure (IRENA, IEA and REN21, 2020). The Canton of Sarajevo (Bosnia and Herzegovina) developed a feasibility study for the improvement and decarbonisation of its urban district heating network, with the co-operation of the Italian Ministry of Environment, Land and Sea Protection and the United Nations Development Programme (IRENA, 2019e).

## Increase energy conservation in transport

## Policies for a modal shift in urban transport

Decarbonising the transport sector, among other measures, requires a shift from energy-intensive to low-carbon modes. A modal shift could significantly improve the energy efficiency of transport, especially in the urban context. This could be achieved by promoting energy-efficient mobility modes ( e.g. ,  public  transit,  rail-based  transit  systems,  car  sharing)  including  non-motorised  ones  such  as cycling  and  walking.  Public  transit  and  non-motorised  mobility  are  complementary  and  work  well together. A growing number of cities are introducing bus rapid transit (BRT) systems (Figure 4.12). Public campaigns are often undertaken by local governments to encourage green mobility modes. For example, Vancouver (Canada) launched a city campaign to encourage cycling and reduce private car use. Other polices, such as preferred parking fees, highway tolls and dedicated driving lanes for shared driving and public transit, could encourage the shift from private ownership to public transit.

Public transportation fleets also offer the opportunity to utilise renewable fuels. For instance, many cities in emerging countries, such as China and India, are promoting electric buses. Santiago (Chile) had 800 electric buses out of a total bus fleet of 6 700 buses by the end of 2020. In Europe, Oslo (Norway) and Gothenburg (Sweden) are operating fleets of electric buses.

FIGURE 4.12     Cities with bus rapid transit systems, per year and cumulative, 1968-2020

<!-- image -->

<!-- image -->

## Policies to avoid and reduce transport needs

Structural changes and behavioural policies in the transport sector can have a multi-faceted effect by promoting the use of public transportation and other mobility services, and also reducing avoidable travel through improved planning ( e.g. , transit-oriented development) and activity pattern changes ( e.g. , promotion of remote working). A reduction in traffic volume further reduces the demand for renewable fuels including biofuels and electricity for charging electric vehicles.

Well-designed land use policies can significantly reduce or even eliminate unnecessary transport needs, for instance, by improving access to the cities' commercial districts. Transit-oriented development in the urban context maximises the residential and business centres within range of public transport and walking distance. In this way, most commercial activities could rely on public transit and reduce the use of private cars. Policies to encourage mixed urban development, with housing, commercial outlets, institutions and entertainment activities together in a specific urban area, can make new developments more sustainable from a transport needs perspective. In dense cities with high numbers of residents and jobs per square kilometre, travel distances would be shortened.

Encouraging  new  activity  patterns  can  be  achieved  through,  for  instance,  telecommuting  and e-learning. While recognising that this may not be an option for a significant share of the workforce, telecommuting allows employees to work at home, or from a remote location for all or part of their workweek. In 2019, the city of San Antonio (United States) included telecommuting in its strategy to  reduce  car  trips  and  related  air  pollution.  Following  the  outbreak  of  the  COVID-19  pandemic  in early 2020, many employers permitted or even required office workers to work remotely, giving an unplanned and involuntary boost to forms of telecommuting enabled by video conferencing software. Although it is too early to judge how entrenched such forms of work will become in the long run, expectations are that the role of centralised offices has been altered fundamentally (IRENA, 2021e).

Structural changes and behavioural policies are needed to reduce avoidable travel through improved planning and activity pattern changes, while promoting the use of public transportation.

## 4.2.3 Electrify end-use sectors

Electrification  of  end  uses  represents  an  important  pillar  of  the  energy  transition.  Targets  for renewable power should consider the rising demand from the electrification of end uses, in line with  long-term  decarbonisation  objectives.  Policies  and  measures  are  needed  to  support  the electrification of heating and cooling and transport, and also to support electrification in achieving its potential for providing system flexibility.

## Electrification of heating and cooling

For heating and cooling, heat pumps are two to four times more efficient than conventional heating systems. Their uptake has been supported mostly through fiscal and financial incentives. Denmark, for  instance,  reduced  the  tax  paid  on  electricity-based  heat  as  part  of  the  country's  plan  to  be fossil fuel free by 2050 (McLaughlin, 2019). Germany's Market Incentive Programme has dedicated around USD 360 million per year in grants and loans for small-scale renewable heat systems like heat pumps. China provided government subsidies equal to around 10% of the retail price of heat pumps, depending on their rated heating capacity and efficiency.

## Electrification of transport

In the transport sector, the adoption of electric vehicles continues to grow aided by enabling policies. Targets for electric vehicles are increasingly being adopted at the national and sub-national levels. Costa Rica, for instance, is targeting 100% of vehicle sales to be zero emission by 2050 and Japan aims to have all cars be electric by 2050 (SLoCAT, 2020). On a sub-national level, Shenzhen (China) aims for 60% of new registered vehicles to be electric from 2021 to 2025 and to deploy 1 million electric vehicles by 2025 (Shenzhen DRC, 2021).

Financial incentives are often provided to support the uptake of electric vehicles. Germany has recently doubled the bonus provided to buyers of electric cars to EUR 3 000, and EUR 2 250 for hybrids costing less than EUR 40 000. The bonus for electric vehicles will be lowered in two steps until 2025 and that for hybrids could be removed altogether from 2022 (Reuters, 2020). In fact, support policies for transitionrelated  technologies  are  often  temporary,  ending  when  these  technologies  achieve  price  parity  and further evolve to ensure deployment at levels consistent with broader energy transition ambitions.

Norway, the world leader in electric vehicles, incentivises their deployment by offering exemptions from  registration  tax  and  value-added  tax  (EAFO,  2021),  among  other  policy  instruments.  An alternate approach also followed is to tax vehicles according to their emissions. In the United States, buyers of electric cars receive a federal tax credit of up to USD 7 500 for the first 200 000 units sold by each manufacturer (United States DoE, n.d.). As discussed further in Section 4.4, financial incentives, such as tax credits, to facilitate adoption must also consider aspects related to equity, i.e., support is accessible to, and benefits, all end users in a just manner.

The  electrification  of  transport  also  requires  significant  investments  in  enabling  infrastructure, particularly for charging. With electric vehicles accounting for more than 80% of all road transport activity by 2050, their market entry will be contingent upon co-ordinated investments in charging infrastructure and power grids. Smart charging solutions can significantly facilitate the integration of  variable  renewable  energy  by  leveraging  storage  capacity  and  the  flexibility  potential  of  the demand side (IRENA, 2019e).  Heavy  vehicles  such  as  long-haul  freight  trucks,  marine  ships  and airplanes that are unlikely to be fully electrified will require investments in infrastructure to deliver renewable solutions such as biofuels and green hydrogen-based fuels.

<!-- image -->

## Electrification as a source of flexibility

Heat  pumps  and  electric  vehicles  have  the  potential  to  become  sources  of  system  flexibility, facilitating the integration of larger shares of variable renewable energy. Exploiting the potential will require proactive policies for the upgrade of power networks, supported by digital technologies for monitoring and controlling the consumption profiles, as well as an increasing participation of new stakeholders such as aggregators of demand and distributed resources. As discussed in the In focus section, power systems' organisational structures need to be redesigned to support the integration of greater shares of variable renewable energy, for example, by removing barriers to the participation of renewables in ancillary services markets.

Moreover, electricity tariff structures need to be redesigned to meet the growing need for flexibility. Demand-side flexibility can be increased through time-of-use tariffs and other smart rate-setting options, thus facilitating the system-friendly integration of additional loads from heating and cooling and transport. Policies can also enable new actors and business models that bring flexibility services.

Finally, forward-looking plans should be developed to integrate the additional renewable electricity and  address  the  load  imposed  by  the  electrification  of  end  uses  through  grid  expansion  and strengthening. In fact, sector coupling with the direct and indirect electrification of end uses ( e.g. , through  green  hydrogen)  offers  opportunities  to  enhance  the  flexibility  of  the  energy  system facilitating integration of larger shares of renewables.

## 4.2.4 Support the development of green hydrogen

In  recognition of the important role green hydrogen will play in advancing the energy transition, several  countries  have  introduced  dedicated  policies  to  support  adoption.  By  2019,  15  countries and the European Union had implemented green hydrogen policies, about two-thirds focusing on the transport sector (IRENA, 2020l). Transport is, however, only one target end-use sector for the hydrogen value chain (Figure 4.13).

Demand-side flexibility can be increased through time-of-use tariffs and other smart rate-setting options, to accommodate for additional loads from heating and cooling and transport.

FIGURE 4.13     Green hydrogen value chain

<!-- image -->

Note: CO  = carbon dioxide; H  = molecular hydrogen; N  = dinitrogen; NH  = ammonia. 2 2 2 3

<!-- image -->

Each part of the hydrogen value chain - including electrolysis, transport, storage, conversion in other energy carriers and feedstocks (ammonia, methanol, synthetic fuels) and end uses - necessitates support to scale up to the level needed for the energy transition. The installed capacity of electrolysers needs to be raised from 200 MW today to 5 TW installed by 2050 in order to produce the 400 Mt.

This calls for policy action, with dedicated measures for each part of the value chain. Given the fact that green hydrogen touches many different parts of the energy sector, an enabling policy framework should consider the following four key pillars, as identified in IRENA (2020l).

- · National green hydrogen strategy: This defines the level of ambition for hydrogen across enduse  sectors  and  the  support  required  and  provisioned  for.  A  national  hydrogen  strategy  can serve as a reference point for attracting the private sector and investments. A growing number of countries are adopting national hydrogen strategies to position themselves in a sector that is gaining traction. Hydrogen strategies typically are preceded by vision documents and roadmaps. Figure 4.14 illustrates  government hydrogen-related initiatives announced between June 2018 and February 2021. The strategy development phase also offers the opportunity to engage civil society through open consultations and in setting priorities.

Each part of the green hydrogen value chain needs support to scale up to the level needed for the energy transition.

<!-- image -->

FIGURE 4.14     Government hydrogen-related initiatives announced between June 2018 and February 2021

<!-- image -->

<!-- image -->

- · Priority setting: Green hydrogen can be utilised in a wide range of end uses. In order to avoid diluting efforts, policy makers are encouraged to consider three key principles when selecting priority end uses to be developed:

First, despite the great promise of green hydrogen and its suitability to replace fossil gases, it is not a complete substitute for fossil fuels. Instead, it is just one of several possible decarbonisation alternatives that should be carefully weighed when setting priorities.

Second, policy decisions should include what applications should be prioritised and how quickly to make the shift from fossil fuels to green hydrogen. Policy makers should identify the highestvalue applications for a given amount of green hydrogen, in order to focus their efforts where they could provide the most immediate advantages and enable economies of scale.

Finally, the principle of additionality is crucial for the renewable energy used for green hydrogen production. In other words, if there are other productive uses for the electricity being generated from renewable sources, that electricity should not be diverted from those uses to produce green hydrogen. Instead, green hydrogen should be produced only from additional renewable energy capacity that would not otherwise be commissioned and electricity that would not otherwise be consumed.

- · Guarantees  of  origin: Since  the  molecules  of  green  hydrogen  are  identical  to  those  of  grey hydrogen, a certification system - referred to as 'guarantee of origin' (GO) - is needed to track the origin and to account for the life-cycle emissions of hydrogen (Figure 4.15). To be useful for producers, policy makers and end users, GO schemes should provide a label for the hydrogen product that clearly indicates its 'shade'. GO schemes will be a key element of a green hydrogen system, at least until carbon-intensive hydrogen is no longer produced.

Green hydrogen is just one of several possible decarbonisation alternatives that should be carefully weighed when setting priorities.

## FIGURE 4.15     Guarantees of origin and life-cycle emissions

<!-- image -->

Note: CO  = carbon dioxide. 2

- · Enabling policies: The final pillar is the adoption of enabling policies and measures to create the socio-economic space that would allow green hydrogen to become a part of the energy system (see also Section 4.1). Economywide policies that affect the sustainability and pace of the transition can create the ecosystem for green hydrogen to develop industrial, economic and social value, including jobs.  Examples of such measures are those that maintain industrial competitiveness and create export opportunities and the identification and leveraging of economic growth and job creation opportunities. Another important cross-cutting action is the collection of statistics. Hydrogen is not currently included in national energy balances, because it is considered a chemical product.  Including  hydrogen  supply  and  demand  as  a  separate  category  in  national  energy balances (similar  to  electricity,  fossil  fuels  or  bioenergy)  allows  better  identification  of  energy flows and provides a solid basis for further analysis. Maintaining a central repository of data on hydrogen deployment across different sectors (such as megawatts of electrolysis or number of fuel cell electric vehicles) can make market information (such as prices, traded volumes and share of green and low-carbon hydrogen) openly available to promote transparency. This action will require international co-operation to align methodologies and ensure mutual comprehension.

These  policy  pillars  represent  the  framework  necessary  for  green  hydrogen  policy  making.  In addition, some of the barriers faced by the green hydrogen sector must be tackled with dedicated measures, focused on specific parts of the value chain, for example, the supply side (see Box 4.7). Policies will also be needed to support adoption of hydrogen-based solutions on the demand side, in particular in the industrial and long-haul transport sectors.

<!-- image -->

## BOX 4.8     Policies supporting the supply of green hydrogen

In any energy system, policies can support the demand side, by supporting or mandating the adoption of renewable energy solutions by consumers, or the supply side, by supporting the production and transportation of clean energy or clean energy carriers. In the power sector, supply-side policies were generally preferred and policy support for green hydrogen could draw on the experiences from the power sector with appropriate adaptations.

Policy makers can set targets for the growth of electrolyser capacity and provide support for each stage of deployment, supporting electrolysers and electrolyser manufacturing capacity and ensuring a sufficient supply of renewable electricity. There are a wide range of possible support  schemes,  including  direct  grants,  feed-in  tariffs  and  premiums,  tax  incentives  and funding for research and development. Regulation and planning will also play an important role. A more detailed analysis is available in IRENA (2021i).

Regarding infrastructure, it is important to standardise the regulation of hydrogen infrastructure in  line  with  international  best  practice,  plan infrastructure step by step (prioritising industrial demand) and assist gas transmission system operators by financing the infrastructure to store and transport hydrogen.

Source: IRENA, 2021i.

## 4.2.5 Ensure the sustainable use of bioenergy

Sustainable  bioenergy  is  an  important  technology  for  the  energy  transition  and  its  greater  use will  play  a  significant  role  to  meet  decarbonisation  objectives  across  power,  heating/cooling  and transport end-use sectors. As noted in Chapter 2, in IRENA's 1.5°C Pathway, bioenergy will be needed to provide heat in industrial processes, cooking and space and water heating in buildings and fuels for transport. It will also be needed as feedstock in the petrochemical industry to produce chemicals and plastics. The energy transition will also involve phasing out the traditional use of bioenergy and replacing it with a combination of modern fuels, including biogas.

Policies  to  support  sustainable  bioenergy  adoption  across  the  power  and  end-use  sectors  were discussed in Section 4.2.1 along with other renewable energy technologies. Broadly, an enabling policy  framework  for  sustainable  bioenergy  must  consider  aspects  related  to  a  clear  long-term strategy, financing  support,  market  access,  support  for  innovation,  enabling  measures  and sustainability  governance.  This  section  will  specifically  discuss  the  sustainability  governance aspect  which  is  critical  to  ensure  the  strongest  compliance  to  standards  relating  to  social, economic  and  environmental  impacts.  Box  4.8  discusses  policies  and  measures  to  ensure  the sustainable use of bioenergy.

## BOX 4.9     Policies and measures for the sustainable use of bioenergy

The transition to renewables addresses many of the challenges posed by incumbent energy technologies at the intersection of society and the planet ( e.g. , climate change, local air pollution). However, even with a renewables-based energy system there is potential for negative environmental and social impacts if they are not adequately factored into the transition process and its policies.

Among the main sustainability concerns are those that relate to bioenergy production and consumption. Some of these concerns relate to environmental aspects, including greenhouse gas emissions related to direct or indirect land-use change, impacts on air and water quality and biodiversity, among others.

Comprehensive  guidelines  and  tools are  needed  to  support  policy  makers  in  defining  rules  for sustainable biomass. The Food and Agriculture Organization of the United Nations has developed such guidelines. Another international platform, the Global Bioenergy Partnership, has also produced a set of indicators, including those to assess environmental impacts, to help stakeholders better understand ways to ensure the sustainability of bioenergy.

Government legislation and independent voluntary certification schemes can also be introduced to demonstrate the sustainable practice of bioenergy industries. For example, the EU's Renewable Energy Directive  to  2030  introduces  enhanced  sustainability  criteria  for  bioenergy  production.  It  excludes biofuels based on raw materials produced on land with high carbon stocks or large effects on biodiversity, and requires minimum greenhouse gas savings for bioenergy production. Some independent certificate schemes  such  as  the  Forest  Stewardship  Council  and  Sustainable  Forestry  Initiative  are  also  widely recognised by related industry players to demonstrate sustainable bioenergy practices and reduce the negative impacts of bioenergy production on the planet (IRENA, forthcoming-b).

The  energy  transition's  planning  should  prioritise  the  use  of  bioenergy  for  those  applications  that do not have other renewable-based alternatives (this would rule out the use of bio energy for lowtemperature applications like heating buildings or producing domestic hot water, for example), and accelerate the development of alternatives for hard-to-abate sectors, like hydrogen and hydrogenbased synthetic fuels, so that the use of biomass is reduced as much as possible and can be secured from sustainable sources.

<!-- image -->

WORLD ENERGY TRANSITIONS OUTLOOK

## POLICIES FOR STRUCTURAL CHANGE AND A JUST TRANSITION 4.3

The transition under the 1.5°C Pathway will influence how we consume, produce, travel and commute, and thus transform global, regional and local economies. Chapter 5 goes deeper into  estimates of the impact of the transition on global economic growth, employment and welfare.  Even  as,  globally,  the  benefits  are  large,  impacts  vary  across  regions  and countries that feature markedly different contexts and challenges. If misalignments are not  well  managed  through  targeted  policies,  inequitable  outcomes  could  result.  This section discusses a portfolio of policies related to structural change and just transition (summarised in Table 4.6).

Even as globally the benefits of the energy transition are large, impacts vary across regions and countries that feature markedly different contexts and challenges. If misalignments are not well managed through targeted policies, inequitable outcomes could result.

<!-- image -->

TABLE 4.6     Overview of structural change and just transition policies

| OBJECTIVE                                         | EXAMPLES OF MEASURES                                                                                                                                                  | COMMENTS                                                                                                                                                                                                                                             |
|---------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Address potential misalignments in labour markets | Scotland's 'Transition Training Fund' offers grants for the retraining of oil and gas workers.                                                                        | Ensuring a just and fair transition will require an in-depth understanding of how structural changes will affect labour markets as well as measures to mitigate negative impacts and foster benefits.                                                |
| Develop local value chains                        | India has launched a Production Linked Incentive scheme to promote manufacturing of high- efficiency solar photovoltaic (PV) modules and to reduce import dependency. | Enhancing and leveraging domestic capabilities requires carefully crafted incentives and rules, business incubation initiatives, supplier-development programmes, support for small and medium enterprises and promotion of key industrial clusters. |
| Provide education and build capacity              | The Ethiopian Electric Utility plans to increase opportunities for women in the electricity sector.                                                                   | Early exposure to renewable-energy-related topics and careers is vital for sparking young people's interests in pursuing a career in the sector, and also to increase social acceptance by a knowledgeable citizenry.                                |
| Support a circular economy                        | The European Waste Electrical and Electronic Equipment Directive sets ambitious rules and regulations for recycling solar PV panels.                                  | Policies and measures are needed to ensure the sustainability of energy transition-related solutions and their smooth integration in existing ecosystems in terms of sustainability, circular economy principles and reduced environmental impacts.  |
| Support community and citizen engagement          | Countries such as Germany, Denmark and Japan encourage direct citizen participation in renewable energy projects.                                                     | Community energy can play an important role in accelerating renewables deployment while generating local socio-economic benefits and increasing public support for local energy transitions.                                                         |

<!-- image -->

T

Ensuring a just and fair transition will require an in-depth understanding of how structural changes will affect different areas and populations as well as measures to mitigate impacts and foster benefits.

## 4.3.1 Address potential misalignments in labour markets

Economic structures  and  labour  market  policies  are  intricately  intertwined.  The  challenges  lie  in reducing  the  dominance  of  fossil  fuels  (reflected  in  institutional  fabrics,  sectoral  structures  and investment  priorities);  altering  patterns  of  commodity,  technological  and  trade  dependence  and strengthening the supply chain structures necessary for supporting the energy transition. Ensuring a just and fair transition will require an in-depth understanding of how structural changes will affect different areas and populations as well as measures to mitigate impacts and foster benefits.

Labour  market  interventions could  encompass  adequate  employment  services  (matching  jobs with qualified applicants; promoting employee well-being; facilitating on- and off-job training and implementing job safety nets), along with measures to facilitate labour mobility , such as relocation grants. Facilitating collaboration between industry and educational institutions will also contribute to more co-ordinated skill-matching efforts. The future and the present labour force may not always be properly aligned (IRENA, 2019h), the main challenges being:

- · Temporal misalignments: Job losses and gains will likely take place at different points in time rather than in parallel.
- · Spatial misalignments: New jobs may be created in different communities, regions or countries than those where the principal job losses occur.
- · Educational  misalignments: Although  retraining  efforts  can  help  to  some  extent,  the  skills associated with vanishing jobs do not necessarily match the profiles and occupational patterns required in emerging and growing industries.
- · Sectoral  misalignments: The  relative  changes  in  employment  across  economic  sectors  may vary, hence requiring a migration of labour force from some economic sectors to others. Rising industries may draw more heavily on raw materials or intermediate inputs from sectors that are quite different from those that supply declining industries. The indirect effects will thus vary.

In parallel to targeting young people for new careers in the renewable energy sector, the existing workforce also presents a potential talent pool, besides the justice considerations of not leaving them behind. Reskilling and upskilling measures will be vital for extending the employment benefits of the transition along the value chain and in the wider economy to workers.

Skills synergies between the offshore wind and oil and gas industries can be utilised, such as expertise in  surveying  and offshore installation; design and manufacturing of support structures; large-scale installation  and  operation  and  maintenance  of  offshore  assets.  Similarly,  coal  sector  workers  can also find new opportunities in renewables, and recent years have seen many instances of targeted recruiting of coal miners for work in the solar and wind sectors (Marston, 2018). For example, a United States-based study of synergies between coal and solar PV skills found that 43% of coal-fired power plant workers could be transitioned to the PV sector without additional training while in the coal mining industry 30-35% of jobs are specific to the industry and would require reskilling (Louie and Pearce, 2016). It is  necessary to ensure that vulnerable workers and their communities do not shoulder an unfairly large burden due to the energy transition. Related efforts include measures to support income stability through unemployment insurance and other programmes, policy incentives for employers to retain (and retrain) workers where possible and flexible, longer-term employment contracts to promote job stability. Proactive strategies designed to minimise socio-economic disruption may also encompass public investments and economic diversification measures for affected regions and communities.

In addition to the identification of transferable skills, governments will also need to dedicate funds to the reorientation and reskilling of the workforce. An example of this is the Scottish government's Transition Training Fund which offers grants for the retraining of oil and gas workers who have lost their jobs or are at risk of redundancy (Skills Development Scotland, 2019). Partnerships between governments, industry and trade unions will play an important role in facilitating the shift for workers and securing safety standards and social benefits.

Reskilling and upskilling measures will be vital for extending the employment benefits of the transition along the value chain and in the wider economy to workers.

<!-- image -->

T

## 4.3.2 Develop local value chains

Bolstering  efforts  to  strengthen  local  value  chains  will  result  in  not  only  the  creation  of  new renewable energy jobs but also the generation of income by leveraging existing and new economic activities. The current momentum for a green recovery offers a historic opportunity to pursue the ambitious measures that would lead to this much-needed structural change. These measures must be targeted towards all sectors and inputs along the value chain. The energy transition provides many opportunities for localisation and structural reform. Stocktaking of regional and local strengths is  a  pre-requisite,  as  well  as  analysing  the  potential  of  creating  regional  hubs  for  the  manifold technologies necessary for the transition along a 1.5°C trajectory.

The  use  of  industrial  policy  can  support  the  development  of  internationally  competitive  local  or regional suppliers, particularly in developing economies. Thus far, barriers to entry lie in the capital intensity of starting new production lines, or exclusive consolidation of supply chains. In India, for instance, a key feature of the recovery plan has been to encourage manufacturing across sectors such as solar PV, automobiles, textile, medical devices and electronics. A Production Linked Incentive scheme  has  been  launched  to  promote  manufacturing  of  high-efficiency  solar  PV  modules  and reduce import dependency. The incentive offered is designed to increase as the value addition grows (MNRE, 2021).

The  availability  of  the  materials  and  equipment,  as  well  as  skills,  required  along  the  value  chain will also be an important factor in determining where local value creation can be maximised. For instance, as illustrated in Figure 4.16, a 50 MW wind farm would require 22 836 tonnes of concrete, 5 860 tonnes of steel and iron as well as other materials such as polymers, fibreglass and aluminium that  are  necessary  for  the  local  manufacture  of  components  (IRENA,  2018d).  This  in  turn  would create 144 420 person-days of employment, primarily in operation and maintenance (43%) followed by installation and grid connection (30%).

Bolstering efforts to strengthen local value chains will result in not only the creation of new renewable energy jobs but also the generation of income by leveraging existing and new economic activities.

## FIGURE 4.16     Distribution of material and human resource requirements for the development of a 50 MW wind farm

<!-- image -->

<!-- image -->

Quality assurance is key for a successful energy transition but should be turned into an entry point and not a barrier to the respective markets. Easy access to standardisation procedures, including training  and  skill  formation  (see  Section  4.3.3),  can  reduce  entry  barriers  for  local  firms  seeking access to value chains. Promoting the shift to regional value chains will also foster global resilience to exogenous shocks, such as the interruptions seen during the COVID-19 pandemic.

Enhancing  and  leveraging  domestic  capabilities  require  carefully  crafted  incentives  and  rules, business incubation initiatives, supplier-development programmes, support for small and medium enterprises and promotion of key industrial clusters.

A key objective is to harness, enhance and leverage the capabilities of domestic companies (either home-grown firms or local subsidiaries of international companies) so they can support the energy transition.  Suitable  policies  encompass  initiatives  and  programmes  to  incubate  new  businesses and develop the capabilities of existing firms in the supply chain, with the help of low-cost loans or access to land, dedicated supplier capacity-building programmes and regional industrial clusters. Governments can take a direct role by:

- ·   Designing renewable-energy-focused research and development strategies and ensuring uptake in the public and private sectors;
- ·   Facilitating  learning  effects,  spill-overs  and  technological  transfers  in  renewables  and  energy efficiency through carefully designed incentives;
- ·   Incentivising supply chain participation in renewable energy sectors by local firms, and actively supporting the creation of partnerships; and
- ·   Establishing  direct  links  to  labour  policy  to  translate  targets  and  support  measures  into employment creation.

Small and medium enterprises play an important role in any attempt to maximise local benefits and diversify economies. It is important to incentivise small and medium enterprises, ease access to information, support the digitalisation of small firms and open up access to finance to support start-ups and, in the long run, innovation and economic opportunity. Start-ups benefit from the promotion of key industrial clusters, as do firms of any size along the value chain of a technology. The  proximity  of  manufacturers,  services  and  designers  of  a  certain  technology  to  a  relevant market has additional benefits.

## 4.3.3 Provide education and build capacity

The renewable energy sector offers employment opportunities for people coming from a range of occupational profiles and backgrounds. Leveraging existing local capacities needs country-specific understanding of skill demand and supply, and of which relevant skills are readily available and which need to be developed or strengthened.

A thorough understanding of the jobs that will emerge domestically and the existing knowledge and skills that can be leveraged either from other industries or with skilling policies must go hand in hand with measures to increase renewable energy deployment.

The  renewable  energy  sector  offers  employment  prospects  for  people  with  a  wide  range  of experiences  and  backgrounds,  and  many  of  the  required  skills  are  typically  available  in  most countries.  While  there  is  a  demand  for  professionals  with  training  in  fields  such  as  science, technology, engineering and mathematics (STEM), as well as other highly qualified individuals (such as lawyers, logistics experts, marketing professionals, financial analysts and experts in regulation and standardisation), most jobs do not require a university degree, but high manual dexterity and on-the-job experience. The greatest demand from the renewable energy sector will be for factory workers, construction workers, technicians and tradespeople like plumbers and electricians. The low threshold of skills for many of these jobs opens doors to employment for many people, particularly where on-the-job training is available. Furthermore, some skill sets can be leveraged from other domestic industries, with some retraining.

Analysis of PV (IRENA, 2017e) and onshore wind industries (IRENA, 2018d) shows that a diverse set of jobs will be created, including jobs that require 'lower' or less formalised skills. In fact, over 60% of jobs can be filled by people without university degrees (see Figure 4.17). Individuals with advanced STEM degrees represent around 30% (PV) and 27% (onshore wind) of the workforce, non-STEM professionals  account  for  roughly  5%,  while  administrative  personnel  account  for  the smallest share (1.4%). A similar trend is seen in offshore wind where the largest share of employment (47%) is held by those with non-university skills and training.

A thorough understanding of the jobs that will emerge domestically and the existing knowledge and skills that can be leveraged either from other industries or with skilling policies must go hand in hand with measures to increase renewable energy deployment.

## WORLD ENERGY

FIGURE 4.17     Human resource requirements in the solar PV and wind industries

<!-- image -->

Source: IRENA, 2017e, 2018a, 2018d, 2020b.

Note: PV = photovoltaic; STEM = science, technology, engineering and mathematics.

When it  comes  to  the  manufacturing  of  solar  water  heaters,  as  shown  in  Figure  4.18,  67%  of  the human resources required are for factory workers and technicians, and their installation also draws on several trades (plumbers, electricians, bricklayers, mechanical technicians) (IRENA, forthcoming -c).

Measures to safeguard the quality of renewable energy jobs are as necessary as those undertaken to increase their quantity. The notion of decent work encompasses many dimensions including fair income, workplace  security,  social  protections,  personal  development  prospects,  freedom  of  organisation, equality of opportunities and equal treatment (ILO, n.d.-a). Given the diversity of the renewable energy sector in terms of industries, companies and supply chains, job quality and workplace practices can and do vary widely. National regulations, company policies and labour representation all play a vital role in areas such as wage levels and workplace protections. It is critical that workers and communities have a full voice in the decision making that drives the transition.

Realising the potential of the energy transition requires making use of all of the available talent pool as well as equitably distributing benefits. As such, targeted measures are required to train, recruit and retain women and other under-represented or marginalised groups (including older workers, ethnic and religious minorities, people with disabilities and those on a low income), and offer opportunities for career advancement.

Women,  for  instance,  account  for  only  32%  of  the  renewable  energy  workforce  which,  while higher than the 22% in the oil and gas industry, is still significantly less than their overall workforce participation (IRENA, 2019i). Also, parts of the renewable energy sector are far less open to women

## FIGURE 4.18     Human resource requirements for the manufacturing and installation of solar water heaters

## Manufacturing

<!-- image -->

Installation

Source: IRENA, forthcoming-c.

than the average would suggest. This is true of the wind sector, where women represent only 21% of the workforce. When it comes to STEM-related roles the disparity widens further with women holding only 28% of STEM jobs across all renewables (14% in wind), compared to 45% of administrative roles (35% in wind) (IRENA, 2020m).

Ensuring  the  inclusion  of  under-represented  groups  requires  a  range  of  both  educational  and workplace measures. Early exposure to renewable energy careers, targeted scholarships and funded training opportunities, mentorships and apprenticeship schemes can all play a role in building the talent pipeline. In the workplace, attracting and retaining talent will require policies and practices that address the challenges faced by under-represented groups. For example, many women would benefit from policies that allow for work-life balance as well as equal opportunities for professional development (as shown in Box 4.9). People with disabilities, who make up an estimated 15% of the world's population (ILO,  n.d.-b),  may  also  benefit  from  workplace  accommodations  and  adaptations.  Such  measures would often not only benefit the targeted group but also the workforce and society as a whole.

<!-- image -->

## BOX 4.10     Fostering women's employment at the Ethiopian Electric Utility

The  Ethiopian  Electric  Utility  (EEU)  is  working  towards  increasing  opportunities  for  women in  the  country's  male-dominated  electricity  sector.  As  of  late  2019,  women  represented  only 19.2%  of  the  EEU  workforce  and  just  9%  of  managerial  and  leadership  positions.  To  address this  imbalance the EEU has set a target to increase this share to 30% women employees by 2023. To achieve this goal the EEU has built partnerships with the Ministry of Science and Higher Education  and  12  universities  to  deliver  science,  technology,  engineering  and  mathematics (STEM) courses. They are also offering scholarships to female staff for graduate studies and technical training. To increase the number of women in managerial positions, leadership training is also being developed. Targeted internships to female STEM graduate students have also been used to provide practical experience, with the opportunity for a permanent job if requirements are met. These efforts are being funded by an earmarked allocation for gender equity and citizen engagement within the budget of the Ethiopia Electrification Program.

Source: WRI, 2021.

Building a skilled energy transition workforce requires measures to both increase the talent pipeline as well as enhance the quality of education and training provisions.

Early exposure to renewable-energy-related topics and careers is vital for sparking young people's interests in pursuing a career in the sector, but also to increase social acceptance by a knowledgeable citizenry. The curriculums at higher education and vocational training institutions need to reflect the skills and competences needed under the energy transition. Certifications and national standards can play an important role in ensuring quality and performance. Professional and supplementary education and training are also important for upskilling the current workforce, ensuring that workers' skills evolve along  with  the  demands  of  the  sector.  Targeted  skill  building  is  also  needed  in  the  energy  access context (as shown in Box 4.10). In addition to strengthening the content of education and training programmes, it is also important to enhance the instructional methods used. For example, experiential learning methods by which students are encouraged to develop problem-solving strategies can help to prepare learners for jobs in the constantly evolving renewable energy sector where independent knowledge seeking will often be necessary.

Public-private  partnerships  can  also  play  a  crucial  role  in  improving  overall  training  quality  while meeting sectoral labour requirements, promoting national skill standards and providing workplace training. In addition to training content, public-private partnerships can also play a role in the financing of training provisions through a shift from fees being the primary vehicle to a more integrated approach that incorporates multiple funding mechanisms including payroll-based training levies, tax incentives, scholarships and donations, vouchers and student loans (Dunbar, 2013).

## BOX 4.11     Energy access skills

Building the skills necessary for scaling up the use of renewable energy is especially crucial in the energy access context. Projects shortlisted for the Ashden Award for Energy Access Skills feature a range of innovative solutions for addressing skills shortages (Ashden, 2021).

Sendea  Academy  in  Uganda,  which  is  made  up  of  a  collective  of  locally  owned  small  and  medium enterprises, aims to address skills shortages in the solar industry by providing training for technicians, entrepreneurs and sales, management and finance professionals (Sendea, 2021).

Other  projects  selected  include  the  Bharatiya  Bikas  Trust  in  India  which  has  provided  professional development training  to  14  000  bank  workers  to  enable  them  to  offer  renewable  energy  loans;  the Strathmore Energy Research Centre in Kenya which has developed innovative solar curricula; and the African Management Institute's Off-Grid Talent Initiative which trains companies and middle managers working in the off-grid sector.

## 4.3.4 Support a circular economy

Policies  and  measures  are  also  needed  to  ensure  the  sustainability  of  energy  transition-related solutions and their smooth integration within the planet and existing ecosystems, featuring circular economy principles and reduced environmental impacts. Potential impacts to mitigate include, for example, those on land and biodiversity in the case of bioenergy and large hydro, and on migratory species in the case of wind. Social and environmental impacts of mining activities and the use of relatively  scarce  components  should  also  be  considered  and  mitigated  through  provision  for  a circular economy including end-of-life management.

Together with industry and other stakeholders, governments need to prepare for the anticipated waste volumes of equipment - such as solar PV panels and batteries - by adopting eco-design requirements  and sustainable  end-of-life  management  policies,  including  waste  legislation (Box 4.11). More data and analyses will be needed at the national level to support the establishment of  suitable  policy  and  regulatory  frameworks.  Information  should  be  gathered  through  regular monitoring of amounts of waste produced by country and technology, the composition of waste streams, installed system performance and the causes and frequency of system failures. To further stimulate  innovation  in  end-of-life  management,  research  and  development  programmes  across energy and waste sectors and industrial clusters can be effective. Tackling increasing waste streams will  also  lead  to  the  expansion  of  existing  waste  management  infrastructure,  including  regional markets in the absence of sufficient national waste volumes or country-specific technical know-how (IRENA and IEA-PVPS, 2016).

<!-- image -->

## BOX 4.12     European Waste Electrical and Electronic Equipment Directive (WEEE) for end-of-life management of PV

Established in 2003 and with its latest recast in 2012, the EU WEEE Directive sets ambitious rules and regulations for recycling solar PV panels. More specifically, the directive prescribes as of early 2014 minimum collection and recovery targets for electric and electronical equipment under a legislative framework for extended producer responsibility.

To  date,  the  European  Union  has  reached  average  PV  recycling  rates  of  over  70%,  with  an  objective  of achieving 85% recovery and 80% reuse and recycling. Between 2011 and 2020, almost 45 000 tonnes of waste  were  collected  and  treated  by  PV  CYCLE,  a  not-for-profit-association  created  by  the  European  PV industry to organise a collective take-back and recycling scheme for PV panels (Figure 4.19) (PV CYCLE, 2021).

However, some challenges remain in the end-of-life management of photovoltaics. These involve among other (1) collection (volumes need to reach certain levels to be profitable), (2) logistics (distance to recycling facilities, access to remote areas) and (3) financial costs (cost-benefit ratio of material value recovery vs. end-of-life management costs) (Deutsche Umwelthilfe, 2021; PV CYCLE, 2021; IRENA and IEA-PVPS, 2016).

End-of-life management offers significant employment opportunities, particularly in the waste industry. Currently,  the  European  waste  sector  accounts  for  less  than  1  million  employees  and  0.4%  of  the  EU's employment and GDP (European Commission, 2018). Labour market growth in this sector is expected to be boosted by additional circular economy policies under the EU's Green New Deal.

## FIGURE 4.19     Overview of EU PV recycling operations, by year and by country, 2019

<!-- image -->

Note: Other European countries include Austria, Bulgaria, Czechia, Denmark, Greece, Hungary, Luxembourg, Romania, Slovakia and Switzerland.

Source: PV CYCLE, 2021.

## 4.3.5 Support community and citizen engagement

Community  energy,  the  'economic  and  operational  participation  and  ownership  by  citizens  or members of a defined community in a renewable energy project', can play an important role in accelerating renewables deployment while generating local socio-economic benefits and increasing public support for local energy transitions (IRENA Coalition for Action, 2018). A diverse range of community energy ownership models can already be found throughout the world, such as in Europe, North America and increasingly in developing countries such as Costa Rica, Mali and the Philippines (IRENA Coalition for Action, 2020b).

Policy makers can stimulate community energy deployment by implementing enabling frameworks that help promote market entry for community energy projects and putting financial measures in place to de-risk early-stage activities, offset capital costs and provide communities with access to affordable and low-cost financing. Further, administrative measures like one-stop shops can support communities in navigating the complex process of developing a renewable energy project as well as help with skills development and capacity building (IRENA Coalition for Action, 2020b).

Governments  are  adopting  policies  that  value  direct  citizen  participation  in  renewable  energy projects. In countries such as Germany, Denmark and Japan, different forms of community energy have emerged that encourage citizen ownership of renewable energy projects next to accelerating local socio-economic  development  (IRENA  Coalition  for  Action,  2020b).  Renewable  Energy Communities are now enshrined in EU law, and need to be considered by Member States in support schemes.

Community energy can play an important role in accelerating renewables deployment while generating local socio-economic benefits and increasing public support for local energy transitions.

<!-- image -->

## HOLISTIC GLOBAL POLICY FRAMEWORK 4.4

Policies  to  advance  the  energy  transition  closely  interact  with  one  another  and  have implications  for  the  energy  system,  economy,  society  and  planet.  An  integrated  policy approach would account for feedback among the policies, and across systems, to ensure a timely, just and fair energy transition trajectory.

A  holistic  global  policy  framework  is,  necessary  to  guide  climate  action  under  the 1.5°C  Pathway  and  reinforce  the  energy  transition  at  a  national  level.  Climate  policies, including fiscal policy aligned with climate objectives, represent an important component of  such  a  framework.  A  diverse  portfolio  of  measures  and  instruments  focused  on enabling and supporting the transition must be integrated into a wider and transparent policy  strategy  that  accounts  for  the  fact  that  policies  introduce  strong  links  and feedback between energy, economic and social systems.

Policies,  such  as  carbon  pricing  and  taxes  on  transport  fuels,  that  intend  to  reduce consumption-related emissions could disproportionately affect low-income  groups (Andersson  and  Atkinson,  2020).  Government  revenues  from  the  implementation  of climate  policies  can  offset  the  regressive  effects  through  measures  such  as  targeted low-income household subsidies and lump sum payments. In the Canadian province of British Columbia, for instance, low-income households are provided with direct transfers to reduce the burden imposed by a carbon tax (Canada's Ecofiscal Commission, 2016; Beck et  al. ,  2015).  A  focused effort is needed to not just design policies with a view to scale up  deployment  of  energy  transition  solutions,  but  also  consider  their  feedback  across the energy sector, economy and society and introduce a holistic policy basket to address concerns.

To this end, the macroeconomic analysis presented in Chapter 5 incorporates a climate policy basket that accounts for the need for an integrated approach to address equity concerns  and  integrates  a  host  of  measures,  for  instance,  earmarking  part  of  the increased government revenue to transition-related investments (discussed further in Section 5.1).

Global policy frameworks are necessary to mobilise public financing to reinforce the energy transition across all regions of the world.

Public investment will play a crucial role in the energy transition, including in the implementation of policy portfolios. Beyond direct investments in technology deployment (where private capital is hard to  attract  or  requires  de-risking),  including  infrastructure  development  ( e.g. ,  networks,  charging infrastructure), public investments will be crucial to implement enabling and just transition policies ( e.g. , capacity building, social protection measures, education and retraining) as well as fossil fuels' phase-out. The American Jobs Plan aims to strengthen public investments to the tune of 1% of GDP annually over eight years focusing on key areas advancing the energy transition, including incentives for  the  roll-out  of  a  national  network  of  electric  vehicles  charging  infrastructure  and  policies  to promote equitable access (The White House, 2021). As discussed earlier, in Germany, a series of auctions have been conducted to seek bids from coal operators to prematurely close down power plants in exchange for awarded compensation (Appunn, 2021).

Public  financing  is  needed  to  shape  and  guide  the  energy  transition's  trajectory,  ensuring  positive impacts  across  key  socio-economic  indicators.  Public  funding  requirements  for  energy-transitionrelated policies are not always included in traditional assessments of energy transition pathways but must be accounted for and planned. While advanced economies are best positioned to mobilise public financing, global policy frameworks are necessary to mobilise such funding to reinforce the energy transition in the rest of the world. Emerging economies can benefit from international co-operation to support closure of plants, communities in transition, repurposing/rehabilitation, retraining and skilling, among  other  priorities.  Several  development  finance  institutions  have  introduced  programmes  to fund a just transition, such as the Energy Transition and Coal Phase-Out Programme in Asia and the Support to Energy Transition in Coal Regions in the Western Balkans, Ukraine, among other countries (Brookings, 2021).

<!-- image -->

<!-- image -->

Justice and equity are the pillars underpinning the global collaborative framework that an ambitious energy transition requires.

International climate finance has a key role to play in providing public financing necessary for a just and fair energy transition. Its function will vary from context to context - fossil-fuel-dependent communities and countries will require targeted efforts to unwind lock-ins to the fossil fuel economy and plan an alternative development trajectory based on new energy sources and economic activities (CPR, 2021). Countries where mitigation requirements consistent with climate targets go beyond their fair share of the global mitigation burden will require support to trigger the needed collaborative framework and leapfrog to climate-consistent energy systems and reap their share of the transition's benefits.

Now more than ever, public policies and investment decisions must align with the vision of a sustainable and just future. Making this happen requires a broad policy package - one that tackles energy and climate goals hand in hand with socio-economic challenges at every level. A just and fair transition leaves no one behind. Moreover, justice and equity are the pillars underpinning the global collaborative framework that an ambitious transition requires.

Ultimately,  the  success  of  the  energy  transition  in  mitigating  the  climate  crisis  will  depend  on  the policies  adopted,  the  speed  of  their  implementation  and  the  level  of  resources  committed.  In  our interconnected  world,  international  co-operation  and  solidarity  are  not  only  desirable,  they  are also  vital  for  addressing  climate  change,  economic  inequality  and  social  injustice.  Moving  forward, investment decisions should be evaluated on the extent to which they accelerate the shift towards an  inclusive  low-carbon  economy.  Anything  short  of  that  can  seriously  hamper  progress  towards a transformative decarbonisation of our societies (IRENA, 2020n).

## CONCLUSION 4.5

Delivering on ambitions aligned with a 1.5°C Pathway will require a comprehensive set of policies to  ensure  a  just,  smooth  and  timely  energy  transition.  As  outlined  in  this  chapter,  such  policies must  consider  deployment,  integration,  cross-cutting  enabling  conditions,  structural  and  just transition  aspects.  The  most  appropriate  mix  will  vary  from  country-to-country,  and  the  policy needs are likely to evolve as markets mature, the share of renewables in the energy mix grows, and energy transition advances.

The policies strongly interact with one another with far-reaching implications for the energy system, society, economy and planet. As governments embark on defining and implementing the optimum policy mix to advance the energy transition, the feedbacks and interactions between policies must be closely considered. A fundamental change in the energy system will require policy-making that effectively accounts for these interactions and addresses potential misalignments and regressive outcomes that are likely to disrupt the pace of the transition.

A  better  understanding  of  the  implications  of  energy  transition  ambitions  and  policies  across society, economy and environment systems offers valuable design feedback to maximise benefits and reduce risks of disruption. The next chapter presents insights into the impact of the energy transition  on  key  indicators  such  as  GDP,  employment  and  welfare,  and  highlights  key  climate policy conditions that can reduce potential regressive effects of energy transition policies.

## 05 SOCIO-ECONOMIC IMPACTS OF THE ENERGY TRANSITION

<!-- image -->

## Energy transition involves systemic changes affecting economies and societies.

The  energy  transition  goes  well  beyond  the  technological  solutions  required  and  involves  deep structural changes that will affect economies and societies at large. An improved understanding of these effects is crucial for policy making and for ensuring that the transition is just and inclusive. To this end, IRENA's socio-economic footprint analysis (IRENA, 2016b, 2019d, 2020o) continues to capture an increasingly comprehensive picture of the transition's socio-economic impacts.

IRENA adopts a comprehensive approach that links  the  world's  energy  systems  and  economies within one consistent quantitative framework, analysing impacts of the energy transition on variables such  as  gross  domestic  product  (GDP),  employment  and  welfare.  The  results  presented  in  this chapter demonstrate that steps towards the 1.5°C Scenario will positively affect economic activity, jobs  and  welfare  compared  to  the  Planned  Energy  Scenario  (PES),  so  long  as  an  appropriately holistic policy framework is in place. Box 5.1 provides an overview of the results.

Over the course of the entire transition period, the gains will vary. Over the next decade (20212030), overall GDP would be 2.4% higher on average on the 1.5°C Pathway compared to the PES. Economy wide, the 1.5°C Pathway yields an average of 1.4% more jobs in the first decade while jobs in the energy sector reach around 137 million by 2030, 78% of them related to the energy transition. Renewables account for 38 million. By 2050, the Energy Transition Welfare Index is 11% higher under the 1.5°C Scenario compared with the PES.

For energy and investment roadmaps to materialise, their links with society must be well understood, clear  and  transparent.  Effective  climate  policy  that  integrates  energy  and  investment  roadmaps with wider socio-economic policies and values is important for the energy transition. This includes measures to explicitly address the regressive effects of climate change itself, as well as the effects of other policies such as carbon pricing. Together with the comprehensive policy mix discussed in Chapter 4, this more holistic climate policy framework is imperative for a 1.5°C Pathway. Only if all stakeholders - citizens, politicians, institutions - are convinced of the need to transition the energy sector, can the collaborative effort needed to address the climate challenge arise. This is all the more important since, beyond what is being modelled, countries are moving along the pathway towards 1.5°C  at  various  speeds,  and  societies  and  economies  respond  in  complex  ways  to  transitions. Education, good governance and credible policy are key ingredients to an inclusive and just energy transition. When people and communities can see the benefits of the transition, political acceptance and support will be much stronger.

For IRENA's socio-economic footprint analysis, countries' existing policies are complemented with a climate policy basket to reach energy transition targets, while addressing distributional challenges with the aim to achieve just and inclusive outcomes. Government fiscal balances are the main link between policy (including climate policy) and social systems.

<!-- image -->

This chapter begins with an overview of the climate policy basket applied in IRENA's macroeconometric model  and  the  channels  through  which  climate  policy  affects  economic  and  social  systems (Section 5.1). It then discusses the impacts of the energy transition on GDP, jobs (economy wide and energy sector specific) and welfare (Section 5.2). The chapter concludes with a brief outlook on the way forward.

## BOX 5.1     Socio-economic footprint of the 1.5°C Scenario, 2030 and 2050: A snapshot

The 1.5°C Scenario is estimated to deliver positive outcomes across all socio-economic indicators analysed ( i.e. , GDP, jobs and welfare):

- · GDP: Additional  GDP  growth  is  spurred  by  investment  across  the  many  dimensions  of  the energy transition, leading to multiple adjustments between interdependent economic sectors. Prices respond to the different cost structures of the 1.5°C Scenario and the Planned Energy Scenario (PES), respectively, and react to investment and demand; more jobs translate into higher incomes and more consumption. The 1.5°C Scenario provides an initial boost to GDP of 2.4% on average over the next decade (over the PES) that is well aligned with the needs of a post-COVID recovery. Over the entire transition period to 2050, the average improvement of GDP is estimated at 1.2% over the PES. The reduced demand for fossil fuels leads to lower revenues for mining and fuel refining industries, as well as for governments through fossil fuel rents, thus resulting in negative GDP impacts in some countries. This highlights the need for a holistic policy framework that addresses structural changes reducing fossil fuel dependency.
- · Jobs: The global effect on jobs from the energy transition is positive. In the energy sector, jobs exceed the PES by 26 million in 2030 and are still 8 million higher in 2050 despite the decrease in fossil fuel jobs. Specifically, in the renewables sector, jobs could reach 43 million by 2050 under the 1.5°C Scenario - a 93% increase from the PES. Qualifications, skills and occupations under the more ambitious 1.5°C Scenario increasingly pertain to construction and operation and maintenance. Training for such occupations is relatively easier and offers more opportunities for fossil fuel workers. The educational requirements of the labour force evolve during the transition with a continuous increase in the share and number of workers with a primary education and a peak by 2030 of workers with a tertiary education.
- · Welfare: The  Energy  Transition  Welfare  Index  used  in  this  report  covers  five  dimensions (economic,  social,  environmental,  distributional  and  energy  access)  and  for  the  first  time reports the distributional and energy access dimensions which are often overlooked in other analyses.  The  1.5°C  Scenario  performs  better  than  the  PES  along  all  welfare  dimensions. By  2050,  the  1.5°C  Scenario  provides  a  11%  improvement  in  the  overall  Energy  Transition Welfare Index over the PES, with improvements of 30%, 23% and 7% in the environmental, social and energy access dimensions, respectively. On average from 2021 to 2050, the 1.5°C Scenario provides a 37% improvement in the distributional dimension over the PES.

## THE CLIMATE POLICY BASKET 5.1

Climate policy plays a pivotal role in the success of energy transitions. In IRENA's macroeconometric model, a diverse portfolio of measures addresses transition and social challenges. This approach adds  emphasis  on  how  the  energy  transition  benefits  people,  and  on  leaving  no  one  behind. In  addition  to  policies  focused  on  deployment,  integration  and  enabling  factors,  presented  in Chapter  4,  this  climate  policy  basket  includes  a  diverse  set  of  fiscal  policy  measures,  such  as adequate carbon pricing applied to emissions across sectors, subsidies and public investment in infrastructure and expenditure on efforts to ensure a just transition.

This climate policy basket includes the measures necessary to move towards the 1.5°C target. Yet it leaves ample room for countries to develop their own respective policy approaches, an aspect that increases trust and acceptance by building on established local policies. The climate policy basket also manages fiscal balances in a manner that addresses the potentially regressive impact of other climate policies. Fiscal surpluses are redistributed by recycling them into the economy through lump-sum payments in a progressive way. In case of fiscal deficits beyond historical trends, the additional deficit burden is shared between citizens (additional income taxes) and government deficit spending.

<!-- image -->

Climate policy plays a pivotal role in the success of energy transitions.

<!-- image -->

In its socio-economic footprint analysis, IRENA uses a macroeconometric modelling framework that captures the effects of the different climate policies and their feedback loops. This chapter discusses  the  resulting  structure  of  the  cumulative  global  government  balances  for  the  1.5°C Scenario,  both  in  terms  of  revenues  and  spending,  with  a  focus  on  the  main  elements  directly affected  by  the  transition. 1 Table  5.1  shows  the  revenue  and  spending  flows  included  in  the modeling of government fiscal balances, providing its shares in cumulative terms (2021-2050) at the global level.

Government revenue streams stand to change, through direct and induced macroeconomic effects on general taxation and declining fossil fuel export revenues, while carbon pricing will in turn provide additional resources. Revenues from public energy transition-related investment may also provide positive contributions, as does international climate finance. Carbon pricing plays a significant role, though still relatively  small  compared to the general revenue streams 2  (income, value added tax and social security contributions). The direct burden of carbon pricing on citizens is kept as low as possible by implementing a differentiated carbon pricing structure with lower prices for the use of fossil fuels in households and road transport (see Box 5.2). As fossil fuel use is phased out in the 1.5°C Scenario, the revenue stream for governments from fossil fuel exports (oil rent) declines, while revenues from public energy transition-related investment, such as renewable power generation, power grids and flexibility, electric vehicle (EV) charging and hydrogen infrastructure, grow. Financial flows from international climate co-operation also provide significant revenues.

Fiscal measures can address potentially regressive impacts of the energy transition.

- 1 The  main  standard  fiscal  balance  components  are  indirectly  affected  by  the  transition,  with  the  modelling framework used by IRENA also capturing these effects.
- 2 Note  that  general revenue streams are still higher than those presented, since the macroeconometric model captures only those revenue streams with macroeconomic implications.

TABLE 5.1     Elements included in the modeling for government fiscal balances, (% of global cumulative fiscal balances 2021-2050)

| GOVERNMENT REVENUE                              |   %SHARE | GOVERNMENT SPENDING                               |   %SHARE |
|-------------------------------------------------|----------|---------------------------------------------------|----------|
| Regular income tax                              |     84.6 | General government spending                       |     85.9 |
| Value added tax                                 |     84.6 | Benefit payments                                  |     85.9 |
| Social security contributions                   |     84.6 | Benefit payments                                  |     85.9 |
| Carbon tax                                      |      7.8 | Lump-sum subsidies for households                 |      7.6 |
| Household fuel tax                              |      0.4 | Cost of early power plant closures                |      0.1 |
| Transport fuel and vehicle registration tax     |      3   | Subsidies to support the transition               |      2.5 |
| Oil rents                                       |      1.3 | Fossil fuel subsidy payments                      |      0.2 |
| Additional income tax for revenue neutrality    |      0.2 | Contribution to international co-operation        |      0.9 |
| Receipts from international co- operation       |      1   | Energy-related investment by government and loans |      2.4 |
| Revenues from public-energy- related investment |      1.7 | Additional social spending                        |      0.4 |

Note: Since the model only tracks the fiscal flows that have a macroeconomic impact for the energy transition, the shares presented in the table do not reflect the shares corresponding to the full government revenues and spending. More specifically,  the  following  fiscal  flows  are  not  fully  represented:  regular  income  tax,  value  added  tax,  social security contributions, general government spending, and benefit payments.

<!-- image -->

## BOX 5.2     Carbon pricing in IRENA's modelling exercise

Carbon pricing aligned with climate goals helps level the playing field, as outlined in Chapter 4. More ambitious mitigation goals require higher carbon prices, while greater policy diversity can allow for lower prices. IRENA's modelling exercise uses carbon pricing at levels consistent with mitigation goals in combination with a diverse climate policy basket.

While  carbon  pricing  is  an  important  component  of  climate  policies,  its  potentially  negative impacts on consumers make it a complex policy tool. Social, and hence political, acceptance rests  on  clear  and  transparent  communication  of  potential  impacts,  real  and  perceived,  and on a convincing alignment with transition and social needs. Policy makers must devise ways to harmonise new fiscal instruments like a dedicated carbon tax with existing taxes on fuel use. More broadly, they also must manage and address the direct impact of such policy changes on citizens, including any regressive effects.

The policy basket for the 1.5°C Scenario, as outlined in this chapter, addresses these issues by:

- · Alleviating  direct  impacts  on  citizens  through  lower  carbon  prices  applied  to  household consumption and road transport, using already established fiscal policy instruments (fuel and registration taxes);
- · Distinguishing between current operating expenses and expenditure on new equipment ( e.g. , vehicles); and
- · Earmarking revenues from carbon pricing for transition-related public investment, as well as for subsidies to support lower-income groups.

Positive  government  fiscal  balances  are  re-circulated  to  citizens  in  the  form  of  lump-sum payments to mitigate negative socio-economic impacts. Where fiscal balances are negative, 3 the burden of addressing them is distributed between an increase of fiscal deficits and higher income taxation. Finding the right level of carbon pricing is difficult. Annex 5.1 discusses the implications  of  carbon  pricing  levels  set  lower  or  above  the  optimum.  Integrated  energyeconomy models can inform the balance between positive and negative impacts, but due to modelling limitations and the complexity of socio-economic systems, these estimates must be interpreted with caution and further refined through a holistic approach to policy making.

- 3 Always in accordance with econometrically estimated boundaries based on past data.

## Government intervention is required for an inclusive transition.

Government  spending plays  a  crucial  role  in  the  energy  transition,  including  in  addressing social challenges associated with a change from the status quo. General spending and benefits (such as for infrastructure, health, education, social security and subsidies for a wide variety of purposes) are  regularly  paid  out  by  governments.  The  energy  transition  will  involve  additional expenditure  with  long-term  socio-economic  dividends  as  presented  in  this  chapter.  Several government spending streams may significantly change: fossil fuel subsidies will be reduced while transition-related subsidies and public investment will need to increase; covering the losses from stranded assets may also increase government spending; and addressing the justice and fairness requirements of the transition and existing social challenges (including distributional aspects) will require additional expenditures. Last but not least, how fiscal balances are managed may also play a significant role during the transition, with important synergies with stimulus packages to address the COVID-19 crisis. The spending needs are likely to grow the longer action towards the energy transition is delayed.

Earmarking public funds for the transition is an important part of the fiscal policy implemented in the 1.5°C Scenario. Public expenditure is used for direct public investment and loans (for infrastructure, facilities  and  equipment)  in  support  of  energy  efficiency,  end-use  renewables,  heat  pumps  and electric or fuel cell vehicles, as well as for addressing stranded assets. Different purposes require public investment to different degrees, for instance, the building sector will require greater public participation  than  renewable  energy  for  power  generation,  while  the  electrification  of  public transport requires more than the electrification of private vehicles.

- 4    The  G7  environment  ministers  have  recently  agreed  to  stop  funding  coal-fired  power  stations  in  developing countries by the end of 2021, signalling increasing commitment to a 1.5°C Pathway.
- 5 T ransition-related subsidies include: energy efficiency, renewables in end-uses, green hydrogen, heat pumps, EV and EV charging infrastructure, and energy storage.
- 6 Such as the German Coal Phase-out Act, for example.

<!-- image -->

International co-operation is an essential piece of the global energy transition.

In  the  policy  basket  introduced  in  IRENA's  socio-economic  modelling  for  the  1.5°C  Scenario, public expenditures are also used to address the requirements of a just and fair energy transition, covering  both  domestic  and  international  needs,  based  on  international  co-operation.  Countries contribute to the joint effort according to their respective capability and responsibility. The financial flows from international co-operation are earmarked for three purposes in the IRENA analysis:

- · Enabling  the  energy  transition  and  addressing  social  challenges. This  includes  addressing potential misalignments from the energy transition, such as educational and skills requirements to accommodate the transition, retraining of workers from industries that are phased-out, social policies to address economic restructuration and legacy dependencies on the fossil fuel economy.
- · Ensuring a just transition across the globe. This includes providing support for countries with high socio-economic dependence on fossil fuel activity.
- · nternational fair transition elements. I Developing countries will need particular attention, based on the acknowledgement that fair emissions in many cases exceed necessary global emission reductions. Countries whose climate mitigation requirements surpass their fair share of the global mitigation  burden  require  support  to  leapfrog  to  climate-consistent  energy  systems  and  reap their share of the transition benefits.

Under the energy transition scenarios, the revenue components of government fiscal balances are responding to economic developments ( e.g. ,  changes in aggregated economic activity impacting taxes,  shifting  away  from  fossil  fuels  reducing  rents).  Investment  in  the  energy  transition  also creates flows and feedback loops in the real economy. Additional demand leads to additional output and employment, in those sectors critical to the energy transition and along the value chain. This manifests in additional GDP and differences in employment between the PES and the 1.5°C Scenario. IRENA's socio-economic modelling captures the implications of all these factors while envisioning an international collaborative framework to address climate change.

## SOCIO-ECONOMIC FOOTPRINT RESULTS 5.2

Renewable  energy  and  energy  efficiency  represent  key  technological  avenues  of  the  energy transition  with  significant  interactions  and  feedbacks  with  wider  economic,  social  and  planetary systems.  Underpinned  by  a  comprehensive  policy  framework  (as  elaborated  in  Chapter  4),  the energy transition can lay the foundations for building more resilient societies.

IRENA's cost-benefit analysis shows that when the reduced externalities from lower air pollution and avoided climate change are combined, the overall benefit of the energy transition is valued at  between  USD  2  and  USD  5.5  saved  for  every  additional  USD  1  spent  (see  Box  5.3).  The sub-sections that follow consider the socio-economic footprint of the energy transition analysed in terms of GDP, employment and welfare.

The energy transition can lay the foundations for building more resilient societies.

<!-- image -->

<!-- image -->

## BOX 5.3     Transition cost-benefit analyses

A broad view of the balance between the costs and benefits of the energy transition can be obtained  by  using  estimates  of  externalities  related  to  pollution  and  climate  change  and comparing  them  with  transition  costs,  including  investments,  operation  and  maintenance expenditures and subsidies.

The overall balance of the energy transition is positive, with benefits greatly exceeding costs. IRENA estimates that in the 1.5°C Scenario every USD 1 spent on the energy transition would yield benefits from reduced externalities valued at between USD 2 and USD 5.5. It should be noted that exogenous estimates of externality costs have a significant uncertainty, as reflected in the range of benefits expected from the transition (Figure 5.1). In cumulative terms, the 1.5°C Scenario would have an additional energy-system cost (net effect of increased investment and reduced operation and maintenance costs) of USD 30 trillion over the period to 2050 but would result  in  a  payback  through  reduced  externalities  from  human health and the environment of between USD 61 trillion and USD 164 trillion.

The savings from reduced externalities fall into three broad categories: outdoor air pollution, indoor  air  pollution  and  climate  change.  Two  externalities  are  included  in  this  cost-benefit analysis:

- · Air  pollution  externalities  are  the  largest  component,  making  up  roughly  two-thirds  of the  total.  (Indoor  pollution  largely  results  from  using  traditional  biomass.)  The  reduced externalities  from  lower  levels  of  air  pollution  alone  range  from  USD  37  trillion  to USD 106 trillion over the period. These savings are at minimum slightly above the additional cost required for the 1.5°C Scenario, but are potentially as high as three times that amount.
- · The  other  significant  source  of  reduced  externalities  is  related  to  climate  change.  These externalities are quantified using the social cost of carbon approach (Intergovernmental Panel on Climate Change estimates) to put a value on each tonne of CO  that is avoided through 2 the measures outlined in the 1.5°C Scenario. The reduced externalities from avoided climate change impacts account for savings ranging from USD 24 trillion to USD 58 trillion over the period.

In the 1.5°C Scenario, every USD 1 spent on the energy transition would yield benefits from reduced externalities valued at between USD 2 and USD 5.5.

<!-- image -->

<!-- image -->

T

## 5.2.1 Economic growth as measured by gross domestic product

Under  the  PES,  real  GDP  (following  a  short  period  of  recovery  from  the  impacts  of  COVID-19 in  2020) is expected to rise at a compound annual growth rate (CAGR) 7  of 2.9% between 2021 and 2050. While this may be interpreted as moderate growth, it should be noted that it implies significant stress on the planet's resources and ecosystems. In fact, in the PES the energy and carbon  intensity  of  the  economy  is  reduced  substantially  compared  to  today,  but  not  enough to address climate change. Table 5.2 summarises key trends under the PES over the next three decades. Global population is assumed to grow at a CAGR of 0.8% in the first decade and 0.3% in the second decade. Global labour force development reflects past and future population growth and a projection of participation rates.

## TABLE 5.2     Key economic and demographic trends of the PES (compound annual growth rates)

| VARIABLE              | 2021-2030   | 2030-2040   | 2040-2050     |
|-----------------------|-------------|-------------|---------------|
| 2.7%                  |             | 2.9%        | Real GDP 2.5% |
| Labour force 0.6%     |             | 0.4%        | 0.2%          |
| Total population 0.8% |             | 0.4%        | 0.3%          |

Source: The projections are constructed using a comprehensive set of international data sources. The main source for population data is the United Nations (World Population Prospects) and for GDP forecasts it is the World Bank's World Economic Outlook. These are supplemented with data from the International Labour Organization, Organisation for Economic Co-operation and Development (STAN), World Bank and Asian Development Bank databases and the European Commission (AMECO, Eurostat, EC Annual Ageing Report, EU Reference Scenario reports).

- 7 The CAGR is a measure of growth over a given period - in this instance 2021-2050. It can be thought of as the constant annual growth rate needed to move from an initial to a final value over a specified period.

## 1.5°C Scenario sees a boost in global GDP.

The  energy  roadmap  presented  in  this  report  includes  the  policies  outlined  in  Chapter  4  and leads  to  investments  in  the  energy  transition  substitute  by:  as  documented  in  Chapter  3.  All these  are  used  as  inputs  to  the  macro-econometric  model.  Changes  in  prices  (of  energy  and general  goods  and  services)  and  global  and  regional  trade  impacts  are  evaluated  in  a  macroeconometric  model  that  tracks  economy-wide  feedback  loops  and  dynamics  with  high  sectoral and geographical granularity.

Under  the  1.5°C  Scenario,  global  impacts 8   on  aggregated  economic  activity  are  positive. Compared with the PES, from 2021 to 2030, the level of GDP is on average 2.4% higher in the 1.5°C Scenario. Figure 5.2 offers a detailed view of the various drivers 9  that cause the difference between the two scenarios. Investment in the energy transition is the largest driver of the positive GDP effect over time.

With  a  growing  consensus  on  the  need  for  a  green  recovery  from  the  COVID-19  crisis,  muchneeded investments  to  boost  economies  must  be  in  sync  with  a  1.5°C  Pathway.  IRENA's  1.5°C Scenario reflects this by putting a large share of the necessary investment in the first decade of the  period  considered.  IRENA's  modelling  approach  allows  trends  in  GDP  and  other  economic or  welfare  indicators  to  be  traced  over  time,  and  is  thus  capable  of  showing  how  front-loaded investments in the first decade can yield the desired post-COVID stimulus effects and how these economic impacts evolve over the long term.

Given  front-loaded  investment  in  a  1.5°C  Scenario,  the  difference  to  the  PES  scenario  with its  delayed  plans  of  action  is  the  largest  at  the  beginning,  reaching  over  3%  (see  Figure  5.2). Infrastructure  investment  in  the  energy  transition  will  boost  domestic  economies  directly  and along the respective value chains. The overall economy picks up this positive impulse and spillover effects ( i.e. , indirect effects along the value chain) and induced effects contribute positively.

- 8 Country  and  regional  results  may  differ  significantly  from  global  aggregates,  with  some  countries/regions showing still more positive impacts of the energy transition on economic activity and vice versa.
- 9 IRENA's  analysis  uses  a  more  nuanced  description  of  drivers  and  their  effects,  but  here  drivers  have  been grouped for clarity.

<!-- image -->

## FIGURE 5.2     GDP difference between the 1.5°C Scenario and PES, with GDP drivers

<!-- image -->

Note: Transition-related investment includes the effects of changes in investments on transition-related categories such as renewables for power generation and end uses, energy efficiency, power grids and flexibility, electrification and hydrogen and electric vehicle infrastructure. Government transition-related spending is also included here.

Other investment includes fossil fuel supply, crowding out and any endogenous responses in investment (for example, to changes in prices of production). Trade includes net trade in fuels and any endogenous responses to other trade (for instance, as a response to price and wage changes). Induced and indirect effects include the effects of changes in taxes (income, value added tax) such as those due to oil rent losses, revenue recycling through lump-sum payments, aggregate prices and other changes in consumer expenditure (including reallocations and indirect effects).

## Investment impacts on GDP

The  investment  driver,  which  includes  both  transition-related  and  'other'  investments,  has  an overall positive effect on GDP during most of the transition, particularly during the ongoing decade.

Transition-related investment covers any investment in renewable energy in the power sector and in the end-use sectors, as well as investment in energy efficiency, in the grid and EV infrastructure, energy  flexibility  and  energy  system  integration  (including  hydrogen).  This  investment  leads  to additional demand across economic sectors, such as the manufacturing of equipment, construction and service sectors such as retail, business services or IT. The overall effect is positive and represents the largest contribution to GDP. It should be noted that government spending to support the energy transition significantly contributes to these improvements as it focuses on transition-related needs, facilitates  investments  by  the  private  sector  and  allocates  expenditure  to  support  a  just  and  fair transition. Governments' involvement in the transition is underpinned by international co-operation to ensure that the burdens and benefits of the transition can be more equitably shared.

Other investment includes that in fossil fuel supply, crowding out and any endogenous responses ( e.g. ,  to  changes  in  prices  of  output).  The  shift  away  from  a  fossil-fuel-based  energy  system  in the 1.5°C Scenario implies a sharp reduction of investment in fossil fuel supply compared with the PES. The additional energy sector investment needs of the energy transition (USD [2019] 33 trillion more in 1.5°C Scenario than in the PES in cumulative terms) will partially crowd out 10  investment from  other  economic  sectors  that  would  have  taken  place  under  the  PES,  thereby  contributing to the negative impact on GDP.

## Induced and indirect impacts on GDP

The overall impact of induced and indirect effects on GDP is positive. This impact includes: (1) the positive contribution of increased consumer expenditure due to changes in general taxation ( e.g. , income and VAT), revenue recycling though lump-sum payments, reallocations and other indirect effects; and (2) the negative impact of aggregate price effects and loss in government oil rents.

Revenue  recycling  through  lump-sum  payments  (besides  addressing  the  regressive  impacts of climate change and other transition policies) provides stimulus for consumption in the lower segment of the income distribution. Also, increased government revenues from higher GDP allows for reduced general taxation, thereby further inducing private consumption.

The resulting overall price levels put downward pressure on GDP throughout the period, especially in this decade. Carbon prices, technology costs, fossil fuel subsidies, wage responses (affecting labour costs) and the domestic response to changes in prices all play a role.

Losses  from  oil  rents  also  have  a  negative  impact  as  they  may  need  to  be  compensated  by governments to maintain budgets and governmental services. At the global level, the negative impact is relatively small but significant, 11 and higher between 2030 and 2050. The loss of value in the oil and gas sector is attributable to both lower global oil prices in the 1.5°C Scenario and lower extraction volumes.

- 10   Crowding out investment at the level of industries and governments reflects that investment in the energy transition is not fully additional. Some portion replaces investment that would have otherwise taken place under the PES scenario.
- 11 For countries with high dependence on fossil fuels the negative impact of lost oil rents is much higher, with a stronger influence on GDP.

<!-- image -->

## Trade impacts on GDP

Trade effects encompass changes in net trade in fuels and any endogenous responses to other trade (for instance, as a response to price and wage changes). At the global level such effects are relatively  small,  since  their  aggregate  represents  the  balance  between  some  countries/regions having positive effects and others negative effects. At the country or regional level, however, trade effects may have a significant impact.

Net fuel trade globally has a positive effect for much of the forecast period before nearing a zero balance by 2050. Consumption of manufactured fuels is much lower in the 1.5°C Scenario than in the PES throughout. Some countries lose revenues from fuel exports throughout the period to 2050, while others experience a strong reduction in fossil fuel imports, with its associated positive effect on GDP. By 2050, the net trade balance in fuels becomes a negligible proportion of the positive GDP impact. The impact of the 1.5°C Scenario on different countries' prices introduces changes both in the relative competitiveness and import/export dynamics of non-energy products, which alters the non-fuel trade balance. Net changes in other trade are negative at the global level throughout the considered time frame.

## Changes in economic structure

Figure 5.3 shows the difference in output between the 1.5°C Scenario and PES for different economic sectors, and thus gives an indication of how the overall economic structure is affected by the energy transition. Most impacts are amplified over time, independent of the direction ( i.e. , as negative effects become more negative and positive effects become more positive). The oil and gas and manufactured fuels sector experiences the most negative impacts, with a difference in output between the 1.5°C Scenario and PES that reaches USD (2019) -5.7 trillion by 2050. Manufacturing sectors gain over time, mainly providing the equipment and technologies for the energy transition. Between 2030 and 2050 the difference in output between the 1.5°C Scenario and PES is about USD (2019) 1.1 trillion per year. The agriculture sector (including forestry) benefits from the higher demand for biomass and biofuel inputs under the 1.5°C Scenario, reaching a difference in annual output between the 1.5°C Scenario and PES of USD (2019) 0.6 trillion by 2050. The largest benefits accrue in the three aggregated categories of services , where the total difference in output between the two scenarios is USD (2019) 3.3 trillion by 2050. Compared to PES, the 1.5°C Scenario features more demand for consulting, planning, financial, legal and administrative services, while higher consumption pathways lead to additional demand for leisure activities and respective services.

FIGURE 5.3     Differences in economic output between 1.5°C Scenario and PES, by sector

<!-- image -->

## WORLD ENERGY TRANSITIONS OUTLOOK

## Impact of climate change on GDP

The GDP results presented above do not include the effects of climate change for either the PES or the 1.5°C Scenario. However, climate change is already affecting economic activity, and will continue to do so to varying degrees depending on the region and emission pathway.

IRENA started exploring the implications of climate damages on overall economic activity in the Global  Energy  Transformation  report  (IRENA,  2019d),  using  a  recently  updated 12   methodology 13 that includes additional data on the impact of temperature changes on economic growth rates. The resulting estimate can still be considered conservative, since some climate change effects are not yet prominent or measurable, such as the intensification of extreme weather events ( i.e. , wildfires, flooding and tropical storms), sea level rise, the crossing of climate tipping points, and resulting trade disruptions, and the potential knock-on effects of complex political and social processes hastened by the stresses of climate change ( e.g. , mass migration; IRENA, 2019d).

Climate change damages aggregate economic activity in both the 1.5°C Scenario and PES, but to a differing degree according to cumulative CO  emissions during this century. Figure 5.4 outlines effects 2 on GDP in both scenarios, 14  compared with GDP results (presented above) under the assumption of no climate damage effects. While both scenarios entail negative impacts, the significantly lower cumulative emissions of the 1.5°C Scenario compared to the PES scenario imply less climate-related damages, supporting  the  benefits  of  transitioning  swiftly  to  a  clean  energy  future.  In  2050,  the difference in GDP between the two scenarios rises to 3.9% as compared with 0.3% when climate damages are not factored in (Figure 5.4).

The  results  presented  in  this  sub-section  show  how,  globally,  GDP  responds  positively  to  the energy transition, with better performance in the 1.5°C Scenario than in the PES. Moreover, GDP improvements are particularly high during the on-going decade as the global economy looks to recover from the COVID-19 crisis. The positive impacts on GDP of the 1.5°C Pathway are further amplified when climate damages are factored in due to lower cumulative emissions.

- 12    Based on work informed by an extended dataset at a sub-national level involving over 11 000 districts (Burke and Tanutama, 2019).
- 13    The methodology is based on a statistical analysis to derive a non-linear damage function that maps temperature changes to economic losses, as a function of the temperature level, providing geographical details of climate damages (Burke, Davis and Diffenbaugh, 2018; Burke, Hsiang and Miguel, 2015).
- 14   Climate damages unfold across different time scales. Some take decades to be felt but are already in the pipeline once greenhouse gas emissions have been released to the atmosphere. This report focuses on the transition period up to 2050, when the 1.5°C Scenario reaches net zero and hence has completed its cumulative emissions. However,  some  of  the  climate  damages  associated  to  these  cumulative  emissions  will  unfold  during  the 2050-2100 period. The goals for global warming (like the 1.5°C Scenario) make reference to the increase in global temperature by the end of the century.

## FIGURE 5.4     Effects of climate damages on global GDP under the 1.5°C Scenario and PES, for each scenario (left) and for the difference between both scenarios (right)

<!-- image -->

Based on IRENA's analysis

1.5°C Scenario implies lower impact of climate damages on GDP.

<!-- image -->

T

The energy transition has net positive effects on job creation.

## 5.2.2 Jobs in the energy transition

The employment dimension of the energy transition is particularly relevant as governments look to increase economy-wide job creation and manage misalignments in labour markets across sectors in transition. The analysis finds that the energy transition has net positive effects on job creation. The investment stimulus associated with the 1.5°C Scenario helps generate an economy-wide gain of jobs compared to the PES. The additional jobs peak around 2030 at 51 million, and by 2050 still run to 20 million. In the energy sector itself, the 1.5°C Scenario sees the number of jobs peaking by 2030 at 137 million jobs, or 26 million more than the PES. By 2050, the sector supports 122 million jobs  under  the  1.5°C  Scenario,  still  surpassing  the  PES  by  8  million  jobs.  The  43  million  jobs  in renewable energy by 2050 under the 1.5°C Scenario will be almost double the number in the PES.

This section first presents impacts on economy-wide jobs, followed by those in the energy sector as a whole and finally those most directly affected by the energy transition. The analysis provides insights on the evolution of conventional and energy-transition-related jobs as well as on the structure of renewable energy employment, its distribution across the value chain and the skills or occupational requirements needed to support this shift in the labour market.

## The impacts of the energy transition on economy-wide jobs

Additional  economic activity  leads  to  more  jobs  under  the  1.5°C  Scenario  compared  to  the  PES. Figure  5.5  presents  the  evolution  of  the  difference  in  economy-wide  employment  between  the scenarios over time, as well as its drivers. Jobs are not linearly related to increases in output, but are influenced by increases in productivity, regional shifts in manufacturing and services, and wage trends.  Moreover,  the  labour  market  does  not  respond  instantaneously  to  stimulus  in  economic activity but progresses with sluggish responses, while increases in aggregate economic activity do not all translate into additional jobs, since part of it is captured by increased wages. Employment benefits peak before 2030, with a difference of 1.44% (51.3 million jobs) over the PES. As the transition progresses  beyond  2030,  these  differences  in  employment  over  the  PES  gradually  reduce  until they reach 0.55% (20.2 million jobs) by 2050 (Table 5.3).

TABLE 5.3     Improvement in jobs in the 1.5°C Scenario over the PES, both in relative and absolute terms, global results

| IMPROVEMENT IN THE 1.5°C SCENARIO OVER PES   | 2021         |      |   2027 |   2030 2040 |   2050 |       |
|----------------------------------------------|--------------|------|--------|-------------|--------|-------|
| Relative                                     | %            |  0.8 |   1.44 |        1.09 |   0.73 |  0.55 |
| Absolute                                     | million jobs | 28.3 |  51.3  |       39.3  |  27    | 20.2  |

Based on IRENA's analysis.

Investment effects on economy-wide jobs. Throughout the transition period, overall employment is 0.9% higher on average in the 1.5°C Scenario than in the PES. One of the main positive impacts on employment comes from investment in the energy transition ('investment: transition related' in Figure 5.5), including grid enhancement, efficiency and, of course, renewable energy. Investment shifting from fossil fuels (extraction and power generation) and other sectors towards the energy transition ('investment: other' in Figure 5.5) leads to less labour demand in fossil fuel activities and in non-energy sectors and along their value chains. Overall, the net impact of investment on employment is positive during the first decade and becomes negative thereafter. This is a consequence of reduced investment in sectors with greater employment intensity.

Trade  effects on  economy-wide  jobs.  Trade  effects  on  employment  are  negative  during  the entire transition, being relatively small during the first two decades but increasing thereafter. This is  mainly  driven  by  the  change  in  trade  in  fossil  fuels,  but  non-energy  trade  also  contributes  to this negative result.

Induced and indirect effects on economy-wide jobs. Induced and indirect effects have a positive impact on employment throughout the transition. Wage effects, consumer expenditure and dynamic labour  market  responses  all  contribute  to  this  positive  impact  on  economy-wide  employment, which ultimately is the principal driver that tilts the balance towards positive employment impacts throughout the transition.

## WORLD ENERGY

R

T

A

N

S

I

T

O

N

S

O

U

T

L

O

K

FIGURE 5.5     Employment difference between the 1.5°C Scenario and PES, by driver

<!-- image -->

Note: Transition-related investment includes the effects of changes in investments on transition-related categories such as renewables for power generation and end uses, energy efficiency, power grids and flexibility, electrification and hydrogen and electric vehicle infrastructure. Government transition-related spending is also included here. Other investment includes fossil fuel supply, crowding out and any endogenous responses in investment (for example, to changes in prices of production). Trade includes net trade in fuels and any endogenous responses to other trade (for instance, as a response to price and wage changes). Induced and indirect effects include the effects of changes in taxes (income, value added tax) such as those due to oil rent losses, revenue recirculation through lump-sum payments, aggregate prices and other changes in consumer expenditure (including reallocations and indirect effects).

At  the  sectoral  level,  the  notable  shift  away  from  mining  and  manufactured  fuels  towards  services, manufacturing and agriculture is shown in Figure 5.6, which presents the difference in jobs between the 1.5°C Scenario and PES across different economic sectors for 2030, 2040 and 2050. Manufacturing sees a boost in jobs required to deploy the infrastructure and equipment for the transition. The differential is more than 13 million jobs by 2030, and by 2050 still runs to more than 9 million jobs. The agriculture sector (the classification includes forestry) fares well especially during the first decades of the transition (when more than 11 million jobs are created by 2030 than under the PES), benefitting in particular from the provision of biomass feedstock. Services are needed at each stage of renewable energy deployment, grid stabilisation or increase in energy efficiency. Planning projects, licensing and carrying out audits, issuing permits, supporting financing, conducting operation and maintenance (O&amp;M) and decommissioning are examples of these activities. Overall business services provide above 8 million jobs more than under the PES by 2050. The enhanced aggregated economic activity also contributes to the increase in service jobs, with public and personal services providing about 14 million jobs more than under the PES by 2050.

<!-- image -->

Based on IRENA's analysis.

<!-- image -->

The energy transition offers significant employment opportunities. Leveraging existing skills and qualifications helps to reap these benefits, and the scope for action is wide. The energy transition requires equipment, materials and services across all economic sectors, in particular when including the value chain in the analysis i.e. , those materials and activities required to produce wind turbines, photovoltaic (PV) modules, insulation or DC cables needed for the transition. The distribution of the potential positive effects differs between countries and regions depending on their economic structure. Each must identify areas with the greatest potential for local value creation, and carefully plan  alignment  with  the  energy  transition  requirements.  Planning  of  a  wind  farm,  for  instance, involves  legal,  energy  regulation,  real  estate  and  taxation  experts,  financial  analysts,  logistics experts,  environmental  experts,  health  and  safety  experts,  geotechnical  experts  and  engineers (IRENA, 2017f). The transport equipment sector benefits from the need for cranes, buses to bring workers or trucks to bring materials. Economy-wide jobs also include those in sectors not related to the energy transition value chain, but where additional economic activity from higher incomes triggers higher consumption.

However, if the success of the energy transition rides solely on the diverging capabilities of individual countries across the world, unequal outcomes will likely follow. For more equitable results, transition strategies could aim to support the evolution of countries' economic structures aided by international co-operation within a global collaborative framework.

## Jobs in the energy sector

The energy sector presently contributes just above 7% of global output and accounts for about 1% of all jobs. This includes, among others, all people working in coal mining, oil and gas extraction, processing of  fossil  fuels  as  well  as  electricity  generation,  be  it  fossil  or  renewable,  and  O&amp;M  of electricity grids. This sub-section first discusses jobs in the energy sector as a whole and then takes a detailed look at the picture in the renewable energy sector.

## Jobs in the overall energy sector

Fundamentally, the impact of the energy transition on energy employment is positive under both scenarios, but more so in the period to 2030 than in the later decades, reflecting the front-loading of  investment  and  changes  in  labour  intensity.  Figure  5.7  gives  an  overview  of  employment  in the  energy  sector  under  the  two  scenarios,  the  PES  and  1.5°C  Scenario,  in  absolute  values  over time. By 2030 the energy sector would have 137 million jobs under the 1.5°C Scenario, as compared with 111 million under the PES. By 2050 this difference shrinks from 26 million to 8 million. In both cases, the loss of fossil fuel jobs is lower than the increase in transition-related jobs.

Of the 137 million energy sector jobs in the 1.5°C Scenario by 2030, 107 million jobs (about 78%) are transition related. Energy efficiency is an important pillar of employment, particularly in the first decade, reaching above 45 million jobs by 2030. Renewables contribute about 39 million jobs. As the transition progresses beyond 2030, the further decrease of fossil fuel jobs in the 1.5°C Scenario is more than compensated by gains in renewables, power grids and flexibility, and hydrogen jobs.

FIGURE 5.7     Energy sector jobs by technology (left) and segment of value chain (right) under the PES and 1.5°C Scenario (million), global results Jobs (million) Jobs (million)

Jobs (million)

<!-- image -->

Jobs (million)

Nuclear

Note: 2021 estimates are obtained through a calibrated macroeconometric model based on investments associated with the PES. It should be noted that the jobs reported here for the energy sector go beyond the traditional categories (fossil fuels, electricity generation, bioenergy and nuclear) to include energy efficiency, energy flexibility, power grids, the hydrogen value chain and heat pumps.

Based on IRENA's analysis.

It  should  be  noted  that  following  a  2030  peak,  a  subsequent reduction in energy efficiency jobs brings  the  total  number  of  energy  sector  jobs  in  the  1.5°C  Scenario  to  122  million  by  2050.  The 2030 peak has two main reasons: first, given the urgency to get on a more sustainable pathway, the 1.5°C Scenario begins with high investment in the first decade; second, as costs come down and technologies mature, the labour intensity decreases ( i.e. , labour input requirements per unit of investment go down). 15  Qualifications, skills and occupations under the ambitious 1.5°C Scenario are increasingly concentrated in manufacturing, followed by fuel supply (Figure 5.7).

- 15    The expected improvements in labour productivity differ from technology to technology, depending on both the current degree of maturity and potential for benefiting from economies of scale.

<!-- image -->

The employment implications of the energy transition reach beyond its direct effects on the energy sector (presented in Figure 5.7). For instance, the road transport sector will also experience a shift from internal combustion engine vehicles to electric vehicles with important labour implications (Box 5.4).

## BOX 5.4   The energy transition's implications for jobs in road transport

The energy transition has impacts on employment far beyond the energy sector (as presented in Figure 5.7). A case in point is road transport vehicles and the associated infrastructure. The energy transition involves a shift from internal combustion engine vehicles to electric vehicles (EVs) and fuel cell vehicles. This has deep implications for employment along all segments of  the  value  chains  producing  and  maintaining  related  equipment,  given  that  mechanical components will be substituted by electrical ones and that the new vehicles have fewer parts. Labour intensity may be significantly lower, and there will be changes in needed skills and qualifications.

But this shift also has implications for infrastructure jobs, given the need to deploy, operate and maintain an extensive EV-charging infrastructure. The learning rates of the new vehicle technologies, the evolution of labour intensity and the room for behavioural change affecting the number of vehicles on the roads will all influence the labour market structure associated with this transition.

Figure 5.8 presents the evolution of overall energy sector jobs including vehicles and vehicle infrastructure requirements, complementing the values in Figure 5.7. By adding overall jobs across vehicle types (internal combustion engine, electric and fuel cell vehicles) and the jobs linked to EV-charging infrastructure, the total number of energy sector jobs increases from 137 to 177 million by 2030, an increase of 29%. From 2030 to 2050 the number of jobs in vehicles decreases due to the shift from internal combustion to electric vehicles and improvements in labour productivity.

The employment implications of the energy transition reach beyond its direct effects on the energy sector.

<!-- image -->

## FIGURE 5.8     Evolution of energy sector jobs by technology under the PES and 1.5°C Scenario, including vehicles and associated recharging infrastructure

<!-- image -->

Based on IRENA's analysis.

Hydrogen  jobs  presented  in  Figure  5.7  include  both  electrolysers  and  hydrogen  infrastructure. In the 1.5°C Scenario they remain stable at around 2 million jobs from 2030 to 2050, while in the PES they decline  because  of  decreasing  investment  after  2030.  In  relative  terms  they  represent a small share of all energy jobs, but the introduction of hydrogen in the energy system can have ripple effects throughout supply chains (see Box 5.5).

<!-- image -->

## BOX 5.5   The hydrogen supply chain

By 2050, as pointed out in chapter 2, 30% of electricity use will be dedicated to produce green hydrogen and its derivatives such as e-ammonia, e-methanol and synthetic kerosene, and almost 5 000 gigawatts of hydrogen electrolyser capacity will be needed, up from just 0.3 gigawatts today.  Such  upscaling  of  the  green  hydrogen  sector  will  lead  to  new  supply  chains,  as  seen before with other renewable energy technologies. For example, pipelines will need to connect hydrogen production points with the steel and chemical industry. Repurposing thousands of kilometres of fossil gas pipelines or building new hydrogen-ready ones will need trained piping system professionals. Hydrogen-related jobs linked to electrolysers and hydrogen infrastructure are included in Figure 5.7.

The employment impacts of the introduction of hydrogen as an important vector in the energy system has ripple effects  in  the  supply  chains  of  different  economic  sectors.  The  shipping industry will need professionals to repurpose ships able to consume ammonia and to build ships to transport liquid hydrogen (like the recently launched 'Suiso Frontier') or e-fuels worldwide (IRENA, 2021i). The air transport industry and its supply chains will also be affected as engines are required to work with increasing shares of hydrogen. Expected actions include introducing fuel-cell-based airplanes, producing synthetic hydrogen-derived airplane fuels and managing hydrogen-derived fuels in airports. Fuel cell vehicles and their supply chains will also provide new job opportunities, in the manufacturing of equipment and its maintenance, as well as in the supporting infrastructure. Hence, the total number of jobs linked to the introduction of hydrogen in the energy system goes beyond those displayed in Figure 5.7.

## Jobs in renewables

Looking specifically at the renewable energy segment of the energy sector, we find that the energy transition  leads  to  significant  jobs  growth  by  2030  and  2050,  with  the  1.5°C  Pathway  having  a significant advantage over the PES.

In the PES renewable energy jobs increase slightly (9%) from 2021 values to reach 18 million jobs by 2030. After 2030, under the PES the deployment of renewables intensifies with a delayed response to the climate change challenge, resulting in 23 million jobs by 2050. By contrast, the 1.5°C Scenario leads to a much bigger gain, with jobs in renewables reaching 38 million by 2030 (a 130% increase from  2021  values).  Thereafter,  a  reduced  rate  of  deployment  and  increasing  labour  productivity attenuate the growth of renewable energy jobs, which by 2050 reach 43 million (a 15% increase from  2030  values).  Comparing  the  two  pathways,  there  are  about  20  million  additional  jobs  in renewables under the 1.5°C Scenario by 2050 (see Table 5.4).

## TABLE 5.4     Overall renewable energy jobs in the 1.5°C Scenario and differences with the PES, global results

|                  |                 |              | 2021   | 2030   | 2050   |
|------------------|-----------------|--------------|--------|--------|--------|
| Renewable energy | Absolute        | million jobs | 16.5   | 37.8   | 43.3   |
| Renewable energy | Difference with | million jobs | -      | 19.8   | 20.8   |
| Renewable energy | the PES         | relative     | -      | 110%   | 92.6%  |

Note: IRENA has been monitoring renewable energy jobs annually since 2011, which are used to calibrate the macroeconometric model to the 2019 monitored jobs. Once calibrated, the model allows data gaps to be filled for places and technologies where no employment data are available, providing a full picture of renewable energy employment in the calibration year (2019). The calibrated model is used to provide a full picture of renewable energy jobs for the different scenarios over time. The job numbers for 2021 are those forecasted under the PES.

For  a  deeper  understanding  of  the  job  opportunities  under  both  scenarios,  detailed  results  for renewable energy jobs by technology are shown in Figure 5.9.

Of the 20 million solar jobs shown in the figure for the 1.5°C Scenario by 2050, 77% are PV, 15% solar water heaters (SWHs) 16  and 8% concentrating solar power. Solar PV is the single-largest source of jobs in renewables in both scenarios, but reaching a more significant number in the 1.5°C Scenario than under the PES. First, large investment sums go towards solar PV in that scenario, and second, it has a relatively high labour intensity. Labour intensity varies depending on the region where capacity is installed and the scale of the installation. Large-scale installations require less labour per megawatt than off-grid, rooftop or any other small-scale installation.

Bioenergy comprising all forms of biomass is the second-largest contributor given its high labour intensity for biofuels supply. It does not differ largely over time in the 1.5°C Scenario, due to the sustainability boundary for biomass use. By 2050 bioenergy employs 6 million people in the PES and 14 million people in the 1.5°C Scenario.

Wind turbine blades are labour intensive to manufacture, but other parts of turbines are less so. Installation resembles the labour intensity of other large construction heavy-infrastructure works. By  2030,  the  PES  creates  2.5  million  jobs  in  wind  energy  (a  27%  increase  from  2021),  while  the 1.5°C Scenario creates 5.6 million jobs (a 182% increase from 2021). Thereafter, the PES maintains similar  growth  rates  in  wind  energy  jobs  until  reaching  3.4  million  jobs  by  2050,  while  the  1.5°C Scenario maintains a rather stable workforce in wind energy through these two decades. By 2050 the 1.5°C Scenario has 2.1 million more wind energy jobs than the PES.

16   SWHs include applications in industry and buildings.

## WORLD ENERGY

## TRANSITIONS OUTLOOK

Under the 1.5°C  Scenario,  jobs  relating  to  SWHs  are  more  prominent  in  the  first  decade  than  in later  decades.  By  2030  the  1.5°C  Scenario  has  4.2  million  jobs  in  SWHs;  however,  by  2050  they decrease  to  2.9  million,  a  consequence  of  increased  electrification  of  end  uses  and  decreasing labour intensity in the SWH industry. On the other hand, the PES has a lower and stable number of SWH jobs throughout the scenario (around 0.9 million).

Hydropower is  one  of  the  oldest  renewable  energy  sources  and  has  grown  much  less  in  recent years than other renewables such as wind and solar. Also, new hydro installations increasingly have to be aligned with efforts to protect natural habitats and to minimise social impacts and conflicts surrounding  the  use  of  water  resources  among  different  communities  and  countries  that  share watersheds.  Altogether,  jobs  in  hydropower  are  expected  to  remain  stable  at  around  3.5  million across the transition.

FIGURE 5.9     Jobs in renewable energy, by technology, in the 1.5°C Scenario and PES (million)

<!-- image -->

Note: IRENA has been monitoring renewable energy jobs annually since 2011, and resulting data are used to calibrate the macroeconometric model. Once calibrated, the model allows gaps to be filled for places not covered in the annual reviews. This provides a full picture of initial renewable energy employment and its forecasted evolution.

Based on IRENA's analysis.

IRENA's analysis  of  the  different  segments  of  the  value  chain  of  renewable  energy  technologies provides further insights. Jobs in O&amp;M, for instance, are long term and often very stable, increasing in number gradually as capacities expand. Jobs in planning as well as in installation, however, require a consistent, long-term pipeline of projects.

Figure 5.10 presents the evolution of renewable energy jobs for both the PES and 1.5°C Scenario in terms of value chain segments. Construction, installation and manufacturing boost renewable jobs during the next decade in the 1.5°C Scenario, with O&amp;M gaining relative weight as the transition advances. Biofuel feedstock supply jobs also provide an important contribution to 1.5°C Scenario jobs.  By  2050,  the  43  million  jobs  in  renewable  energy  under  the  1.5°C  Scenario  are  distributed across the value chain with 33% in construction and installation, 26% in biofuel supply, 21% in O&amp;M and 20% in manufacturing.

FIGURE 5.10     Renewable energy jobs, by segment of value chain, in the 1.5°C Scenario and PES

<!-- image -->

Based on IRENA's analysis.

<!-- image -->

## Jobs by skill level and occupation

Skills matching is an important objective in leveraging the employment benefits from the energy transition.  The  transition  needs  skills  at  all  educational  levels  -  primary,  secondary  and  tertiary (Box  5.6).  The  1.5°C  Scenario  involves  the  following  trends:  a  steady  increase  of  jobs  requiring primary  education,  an  initial  contraction  and  later  recovery  of  the  number  of  jobs  requiring  a secondary education and a sharp peak by 2030 in jobs requiring a tertiary education, which by 2050 decrease to lower numbers than today. Due to inertia in the dynamics of the education system, insights into the future evolution of the labour force's occupational patterns need to be carefully considered to ensure that the appropriate skills are developed as discussed in Chapter 4.

## BOX 5.6   Evolution of education levels necessary to support energy transition

The  required  skills  by  economic  sector  are  presented  to  reflect  three  groups  based  on aggregations  of  the  ISCED  2011  classifications  per  education  level: 17 the  primary  education level  comprises  ISCED  levels  0-2  (childhood,  primary  and  lower  secondary  education);  the secondary education level includes ISCED levels 3-4 (upper secondary, post-secondary nontertiary  education),  such  as  vocational  qualifications  and  specialisations;  and  the  tertiary education  level  comprises  ISCED  levels  5-8  (short-cycle  tertiary  education,  bachelor's, master's and doctoral levels). It should be noted however that the level of education and skills are not necessarily correlated: high skills are required by some professional occupations linked to the primary education level, and low skills are sometimes linked to professional occupations associated to the tertiary education level.

Figure 5.11 shows the evolution of education levels necessary to support the energy sector in the PES and 1.5°C Scenario. From 2021, when jobs requiring secondary education dominate (42% of the 91 million energy sector jobs), the first decade sees an increase in the shares of jobs requiring tertiary and primary education. The increase in jobs requiring these education levels  is  significantly  higher  in  the  1.5°C  Scenario  than  in  the  PES.  In  the  1.5°C  Scenario,  of 137  million  energy  sector  jobs,  40%  require  tertiary  education  and  35%  primary  education by 2030. This shift is driven by the deployment of new energy infrastructure and systems, which mainly takes place in the first decade in the 1.5°C Scenario. On the other hand, by 2030 the number of jobs requiring secondary education declines from current values in both the PES and 1.5°C Scenario. Beyond 2030, there is another significant shift in the structure of the educational requirements needed to support the energy sector: a very sharp reduction in the number of jobs requiring tertiary education, an increase in jobs requiring secondary education and a continuing increase in jobs requiring primary education. In the 1.5°C Scenario, among 122 million energy sector jobs, 13% require tertiary education, 37% secondary education and 50% primary education by 2050.

17    International Standard Classification of Education (ISCED): https://ec.europa.eu/eurostat/statisticsexplained/index.php?title=International\_Standard\_Classification\_of\_Education\_(ISCED).

Education requirements will evolve through the energy transition.

FIGURE 5.11     Evolution of the distribution of jobs in the energy sector, by education level, in the PES and 1.5°C Scenario

<!-- image -->

Based on IRENA's analysis.

<!-- image -->

## Coordination between the energy and educations sector is required to fulfill future skills demand.

The  trends  in  the  educational  requirements  of  the  energy  sector  call  for  better  co-ordination between the sector and educational institutions. The 2030 boom in tertiary education requirements, as discussed above, is likely to encourage people to continue to seek such qualifications even though jobs requiring their educational profiles will materialise in lower numbers. An integrated approach to labour and educational policy and planning will be needed to address this challenge, and also to better integrate the educational requirements in the energy sector with those of other sectors. Part of the answer will lie with efforts to better anticipate emerging trends that influence education levels and specialisations. Another aspect concerns identifying transversal skills, i.e. ,  skills that are not exclusively related to a particular job or task but rather are applicable to a wide variety of work settings and roles. For example, organisational or inter-personal skills fall under this category. 18

In addition to future educational requirements of the workforce needed to support the transition, analysis  of  specific  occupations  is  essential.  To  illustrate  this  point,  Figure  5.12  provides  insights for  a  subset 19 of  renewable  technologies  by  2050,  showing  the  structure  of  the  required  jobs by technology, segment  of value chain and occupational requirements. Construction and installation  dominate  the  segments  of  the  value  chain  accounting  for  45%  of  the  jobs.  In  terms of  occupational  requirements,  workers  and  technicians  represent  the  largest  share  with  76% of the total.

The results presented in this section show that the energy transition offers significantly more job opportunities than those that are lost. Indeed, by 2030 when moving from the PES to the 1.5°C Scenario 14 million jobs are lost in fossil fuels, but 40 million jobs are gained in transition-related technologies. By 2050 the difference between the PES and 1.5°C Scenario is a loss of 20 million jobs in fossil fuels and a gain of 28 million jobs in transition-related technologies.

18    Ideally, this is done in such a way that people with different educational levels can more readily acquire the skills needed for the occupations that society requires, while finding satisfaction in their professional life. This requires increased flexibility in the way in which the links between education and work life are organised and understood by society.

- 19   These technologies are PV, SWH, onshore wind, offshore wind and geothermal. The analysis draws from IRENA's work on leveraging local capacities (IRENA, forthcoming-c, 2018d, 2017e, 2017f). The skill structure for additional technologies can be fleshed out as the leveraging analysis for those technologies becomes available.

FIGURE 5.12     Structure of jobs in the 1.5°C Scenario by 2050 for a subset of renewable technologies by technology, segment of value chain and occupational requirements

<!-- image -->

Note: O&amp;M = operation and maintenance; PV = photovoltaic; SWH = solar water heater.

Based on IRENA's analysis.

IRENA's analysis offers insights into the types of jobs needed to support the transition by technology, segment  of  the  value  chain  and  educational  and  occupational  requirements.  These  are  crucial elements  to  inform  the  transition's  policy  framework.  But  beyond  that,  policy  needs  to  address upfront  the  potential  job  misalignments  (temporal,  educational,  geographic)  that  may  arise.  Job opportunities due to the energy transition occur where installations of renewable energy systems are located, where relevant technologies (and their inputs along the supply chain) are produced and where related infrastructure is enhanced. Fossil fuel jobs are often located in other parts of a country and workers may be reluctant to move or face barriers to do so. Skills and qualifications needed for the energy transition are not readily available; even where they are, additional licensing is often required. These misalignments need to be addressed by a policy framework as outlined in Chapter 4.

<!-- image -->

T

## 5.2.3 Energy Transition Welfare Index

This sub-section first presents IRENA's Energy Transition Welfare Index and discusses the welfare results for both the PES and 1.5°C Scenario.

Prosperity and people's well-being have many aspects and dimensions. IRENA's Energy Transition Welfare Index captures five dimensions, namely, economic, social, environmental, distributional and energy access (see Figure 5.13). Measuring the energy transition's impact across these dimensions provides  a  quantitative  basis  to  inform  transition  roadmaps  to  reaping  all  the  potential  socioeconomic and environmental benefits. The Energy Transition Welfare Index allows a comparison between scenarios both in overall terms and along each of the five different dimensions.

The  Energy  Transition  Welfare  Index  and  its  dimensional  indexes  are  defined  in  absolute  and normalised terms for each scenario, which allows for direct comparison between scenarios. However, as for other socio-economic footprint results (GDP, employment), the relative performance of one scenario against another (1.5°C Scenario relative to the PES) may also be of interest. This section presents both absolute and relative welfare results.

FIGURE 5.13     Structure of IRENA's Energy Transition Welfare Index

Dimensions

<!-- image -->

- 20    IRENA's Energy Transition Welfare Index includes five dimensions which provide an adequate balance between the multi-dimensional  characteristics  of  prosperity/well-being  and  synthesise  requirements  for  useful  insights.  Each dimension of IRENA's Energy Transition Welfare Index includes two indicators. These indicators are combined into a dimension's index, and the different dimensional indexes are finally combined into the overall welfare index (see Figure 5.13 and Annex 5.2) that allows an overall welfare rating of each transition roadmap. All indexes are normalised so that they score between 0 and 1. The higher the value of an index, the greater its contribution to welfare. Indexes are combined by using a modified geometric mean (see Annex 5.2 for methodology).

## Welfare results for PES and 1.5°C Scenario: Global

There  are  two  ways  of  presenting  IRENA's  Energy  Transition  Welfare  Index:  a  multi-dimensional representation of welfare gains in its different dimensions, and a unidimensional representation that groups together the contributions from each of the dimensions. For all indexes, values range from zero (the worst possible outcome) to one (the best outcome).

Figures 5.14 and 5.15 present global results for the year 2050. Welfare improves over time in both scenarios but is higher under the 1.5°C Scenario than under the PES. By 2030, the Energy Transition Welfare  Index  value  is  0.25  for  the  PES  and  0.34  for  the  1.5°C  Scenario;  by  2050,  it  is  0.40  and 0.44,  respectively.  The  Difference  between  the  1.5°C  Scenario  and  PES  is  mostly  due  to  the environmental, access and social dimensions, in decreasing order. The dimensions with the highest index  values  are  access  (with  full  access  to  modern  energy  already  reached  by  2030  for  the 1.5°C Scenario), economic and environmental, while the social and distributional dimensions have low index values in both the PES and 1.5°C Scenario. See Annex 5.3 for data tables.

In both scenarios, the low values of the social and distributional dimensions drag the overall Energy Transition Welfare Index down. These two dimensions have not received much attention in policy circles to date, though awareness of the crucial role they can play as enablers or barriers is now increasing.

FIGURE 5.14     Overall welfare (centre) and dimensional (blades) indices for the PES and 1.5°C Scenario by 2050, global results, multi-dimensional representation

<!-- image -->

Note:  In  the  multi-dimensional  representation  of  the  Energy  Transition  Welfare  Index  that  resembles  a  wind  turbine  rotor (nacelle  and  blades),  the  nacelle  documents  the  overall  welfare  index  with  a  concentric  circle.  Each  of  the  five  rotor  blades represents one of the dimensional indices, indicating the respective index values.

<!-- image -->

## FIGURE 5.15     Overall Energy Transition Welfare Index and dimensional contributions of the PES and 1.5°C Scenario by 2050, global results, unidimensional representation

## Welfare Index

<!-- image -->

Note: In the unidimensional representation of the Energy Transition Welfare Index, the total height of the stacked bar represents the overall welfare index (the same value as shown in the nacelles of Figure 5.14), and each of the segments represents the contribution to the total value from the different welfare dimensions.

Based on IRENA's analysis.

## Relative welfare results of 1.5°C Scenario and the PES

As  was  done  for  the  other  socio-economic  indicators  (GDP,  employment),  the  relative  welfare index measures the difference between the 1.5°C Scenario and PES results. By 2050, the overall welfare index improves by 11% with the environmental, social and access dimensions being the main contributors to this improvement, as illustrated in Figure 16.

It  is  worth  noting  how  the  role  of  the  social  and  access  dimensions  is  reversed  compared to the absolute index values: The access dimension is the main contributor to the absolute welfare index because  it  reaches  very  high  dimensional  index  values  (1  for  1.5°C  Scenario).  However,  since  its improvement from the PES to 1.5°C Scenario is not very high 21  at the global level, in relative terms it makes a modest contribution. Conversely, the social dimension makes a modest contribution to the absolute welfare index, but in comparative terms between the two scenarios is the second-most important after the environmental dimension (Figure 5.16).

- 21 Under both the PES and 1.5°C Scenario, the energy sufficiency threshold is achieved at the global level.

## FIGURE 5.16     Relative improvement of the Energy Transition Welfare Index and its dimensional contributions by 2050, global results

## Difference in welfare index between 1.5-S and PES (%)

<!-- image -->

Based on IRENA's analysis.

## Welfare results: By dimension

As  explained  earlier,  each  dimension  of  the  Energy  Transition  Welfare  Index  is  informed  by  two indicators. 22 This  section discusses how the respective indicators influence the dimensional index during the transition.

## Economic dimension

The economic index is very similar for both the PES and 1.5°C Scenario (0.65 and 0.66, respectively, by 2050), reflecting the energy sector's relatively small share of the overall economy and labour force. Both indicators in this dimension contribute similarly to the dimension's index (Figure 5.17), with the energy transition leading to slight improvements in both consumption and investment and in non-employment.

- 22    The distributional dimension includes four indicators, combined into two sub-indexes by taking the average of the income and wealth components.

## WORLD ENERGY

## TRANSITIONS OUTLOOK

That  said,  the  improvement  between  the  PES  and  1.5°C  Scenario  is  more  pronounced  during the first decade (reaching a 1% difference around 2025), mainly due to front-loaded investments in the 1.5°C Scenario.

The economic index, for both the PES and 1.5°C Scenario, presents a minimum value shortly after 2030, resulting from the balance of two opposing trends: the consumption and investment index steadily  increases  with  aggregated  economic  activity  (GDP)  while  the  non-employment  index decreases with time, resulting from the balance of demographic and labour dynamics, including productivity improvements. 23

## FIGURE 5.17     Economic index under the 1.5°C Scenario and PES by 2050, by indicator, global results

<!-- image -->

Based on IRENA's analysis.

- 23    It should be noted here that although the socio-economic modelling captures econometric labour productivity improvements,  it  does  not  fully  address  current  megatrends  such  as  the  disruptive  impacts  of  artificial intelligence and automation. Hence, the decrease of the non-employment index (increase of non-employment) could be steeper than the analysis shows.

At the global level, per capita consumption and investment evolves from about USD (2019) 8 500 per annum by 2021 to around USD (2019) 17 000 per annum by 2050, still far from the sufficiency limit introduced in this indicator's index (USD [2019] 45 000 per annum). Of course, country and regional disparities in this indicator are substantial, as partly documented by the distributional dimension below.

Global non-employment 24  changes from around 17% by 2021 to 31% by 2050, for both the PES and 1.5°C  Scenario.  This  growing  non-employment,  due  to  the  demographic  and  labour  dynamics,  is not  a  consequence  of  the  transition,  but  of  the  context  within  which  the  transition  is  currently progressing. It highlights the need to holistically address contextual elements that go well beyond the technical aspects of the energy transition as noted in Chapter 4.

## Social dimension

The social index improves with time in both the PES and 1.5°C Scenario. By 2050 it reaches a value of  0.22  for  the  PES  and  0.27  for  the  1.5°C  Scenario  (a  23%  improvement  of  the  1.5°C  Scenario over the PES) (Figure 5.18). However, these values are low even to 2050, indicating that there is significant  room for improving welfare outcomes by addressing the social dimension. The health impact indicator dominates as outdoor and indoor air pollution improves, with the social expenditure indicator  providing  a  much  smaller  contribution.  Hence,  there  is  significant  room  to  improve  the Energy Transition Welfare Index by increasing social spending.

IRENA's 1.5°C Scenario leads to improvements in both social indicators. Health improvements are a  direct  consequence  of  phasing  out  the  combustion  of  fossil  fuels  and  transitioning  away  from traditional fuels for cooking. The policy basket implemented with the 1.5°C Scenario also addresses the improvement of the social spending indicator through different channels, including increased public participation by earmarking public fiscal resources to energy transition requirements through both direct investment and subsidies, public spending for a just and equitable transition (including international co-operation) and an increase in general social spending over the PES.

- 24    Share of working age population (age group from 15 to 64 years) without paid employment and not belonging to youth (14-24 age group) undertaking education.

## WORLD ENERGY

## FIGURE 5.18     Social index under the 1.5°C Scenario and PES by 2050, by indicator, global results

<!-- image -->

Based on IRENA's analysis.

## Environmental dimension

The  environmental  index  by  2050  is  0.47  for  the  PES  and  0.61  for  the  1.5°C  Scenario  (a  30% improvement of the 1.5°C Scenario over the PES).  Both  indicators  contribute  significantly  to  the environmental index in both the PES and 1.5°C Scenario, but the CO  emissions indicator is the one 2 that drives the improvement of the 1.5°C Scenario over the PES (Figure 5.19). The index deteriorates over time as a consequence of the increase in materials consumption.

Both  scenarios  have  similar  values  of  the  materials  consumption  indicator  (per  capita  materials consumption) 25  evolving from 5.7 tonnes/person-year by 2021 to 7.5 tonnes/person-year by 2050. This reflects that the energy transition alone cannot resolve significant, parallel challenges, such as bringing global material consumption down to sustainable levels - neither for materials used by the energy industry, nor for materials used for non-energy value chain production.

- 25    This  makes  reference  to  domestic  material  consumption  excluding  fossil  fuels,  and  hence  includes  the  aggregate consumption of non-metallic minerals, metal ores and biomass. It should be noted that this aggregate measure of materials  consumption,  although  an  adequate  proxy  for  the  sustainability  implications  of  materials  use,  does  not provide the resolution needed to track the consumption of potentially scarce materials in relation to available resources.

FIGURE 5.19     Environmental index under the 1.5°C Scenario and PES by 2050, by indicator, global results

<!-- image -->

Based on IRENA's analysis.

## Distributional dimension

The  distributional  dimension  is  increasingly  recognised  as  key  to  enabling  the  energy  transition. IRENA  has  for  the  first  time  introduced  this  dimension  in  its  welfare  indicator,  with  the  goal  of generating insights that contribute to fostering a just and inclusive energy transition. While GDP grows and the implemented policy basket leads to an improved distribution, the index itself remains low, indicating potential barriers to the energy transition from an equity point of view. The distribution of benefits is not uniform across countries and income groups, implying the transition does not by itself resolve income and wealth inequalities. Distributional results are presented here as a global aggregate.   IRENA's future work will further examine regional differences.

<!-- image -->

## Dedicated policies are needed to address distributional challenges.

The distributional impact of the energy transition depends on the energy transition roadmaps and the policy baskets used to implement them. Dedicated policies are, therefore, needed to address distributional challenges. The climate policy basket implemented under the 1.5°C Scenario includes progressive government revenue recycling through lump-sum payments, direct public involvement in more  equitable  distribution  of  benefits  from  the  transition,  increased  social  expenditure, differentiated carbon pricing that limits the direct burden on citizens and international collaboration with a focus on justice and equity.

FIGURE 5.20     Distributional index under the 1.5°C Scenario and PES Average 2021-2050, by indicator, global results

<!-- image -->

Based on IRENA's analysis.

## The 1.5°C Scenario has positive distributional impacts with targeted measures.

The  combination  of  the  1.5°C  Scenario  energy  transition  roadmap  and  the  accompanying  policy framework  brings  about  a  37%  improvement  in  the  average  distributional  index  over  the  PES during the transition period, with both the intra- and inter-distributional components contributing (Figure 5.20). The 1.5°C Scenario produces an average improvement of 44% in the intra-distributional sub-dimension 26  and 20% in the inter-distributional sub-dimension.

The  inter-distributional  indicator,  which  measures  changes  to  inequalities  between  countries, significantly  improves  over  time,  moving  from  an  almost  zero  index  by  2021  to  reach  about  0.16 by 2050, with both its wealth and income components improving over time (with wealth reaching an index of about 0.14 and income of about 0.20). However, these values indicate that inequality between countries is still very high by 2050. 27

There  are  many  dynamics  at  play  influencing  the  inter-distributional  indicator,  making  it  more complex  to  explore  than  the  aggregate  impacts  on  economic  activity  (GDP).  International co-operation as included in the 1.5°C Scenario climate policy basket 28  significantly reduces interinequality during the first years of the transition but its impact fades with time because of the underlying  aggregated  economic  growth. 29   Raising  the  sums  mobilised  through  international climate co-operation beyond the USD 300 billion/year assumed on average for the 1.5°C Scenario could achieve greater distributional benefits.

- 26    For the  global  results  herewith  presented,  the  intra-distributional  component  measures  inequality  in  the distribution of income and wealth across the global population (global citizens).
- 27    The  corresponding  indicator  values,  wealth  quintile  ratios  (WQR)  and  income  quintile  ratios  (IQR),  are  about WQR = 35 and IQR = 16 by 2050.
- 28    In  cumulative  terms,  the  assumed  international  co-operation  policies  amount  to  a  cumulative  spending  of USD 8.6 trillion, representing an average of just below USD 300 billion/year. All countries contribute to these funds  as  per  their  capabilities  and  responsibilities,  and  the  funds  are  distributed  as  per  the  country's  human development, fossil fuel vulnerability and equity in the distribution of the mitigation effort.
- 29    Note  that  the  underlying  aggregated economic activity (GDP) for the 1.5°C Scenario has a compound annual growth rate of 3% between 2021 and 2050. Hence, the weight of the international co-operation monetary flows relative to aggregated economic activity significantly reduces with time.

<!-- image -->

The transition process itself can, if not properly addressed with a focused policy framework, trigger inequality  increases  in  several  ways.  While  the  economic  benefits  of  the  transition  are  rather distributed, its negative impacts associated to fossil fuel dependence and vulnerability are far more concentrated.  Further,  a  front-loaded  transition  investment  meant  to  speed  up  mitigation  while addressing the recovery needs from the COVID-19 crisis may trigger inflationary and price effects 30 that could have a stronger impact in poor countries. Advanced economies, due to their structure, diversity and international positioning, are able to reap more benefits from the energy transition investment stimulus.  Properly  addressing  these  challenges  and  redirecting  the  transition  so  that it improves the distributional dimension requires a holistic policy framework with a clear focus on distributional issues.

The  intra-distributional  indicator  presented  here  makes  reference  to  the  global  population.  The intra-distribution index improves significantly over time, evolving from 0.01 in 2020 to 0.16 by 2050. The lump-sum payments to recirculate government revenue surplus play a significant role in the 1.5°C Scenario over the PES improvement for this index, with the difference between both scenarios reaching a maximum of about 100% around 2030. The two components from this index (income and wealth) have very different contributions: the income component for the 1.5°C Scenario reaches index values as high as 0.40 from 2030 onwards, while the PES barely reaches 0.30 towards the end of the transition. 31 But it is the wealth component that drags the intra-distributional indicator down, with extremely high wealth quintile ratios (WQRs) producing a zero value of the associated index.

## Access dimension

A discussion of welfare under the energy transition would be incomplete without addressing the energy access deficit faced by a significant proportion of the world's population. Over 755 million people lived without electricity access in 2019 (IEA et al. ,  2021), and 3.5 billion received unreliable supply (Ayaburi et al. ,  2020). Further, 2.6 billion relied on traditional fuels for cooking (IEA et al. , 2021).  The  lack  of  access  to  modern  energy  services  significantly  affects  households'  access  to resources  and  income-generating  opportunities  and  constrains  economic  and  industrial  activity. Access to modern energy services is closely linked to access to essential public services such as health care and education, and improves overall well-being and safety, particularly for women and children. Energy equity and distributive justice i.e. , the right to affordable and accessible energy is increasingly recognised as a critical pillar of a just energy transition (Sovacool and Dworkin, 2015; World Energy Council, 2020; Müller et al. , 2020).

- 30    Inflationary  effects  may  stem  from  the  investment  stimulus  triggering  an  increase  in  general  prices.  Interest rates could also increase if there is an increase in demand for loans to address the transition's investment needs. Energy prices could increase because of the costs of deploying the new generating and flexibility capacity and infrastructure, with direct and indirect effects on general prices. From 2030 onwards, the 1.5°C Scenario inflationary effects fade in many countries and there is a marked trend to reduce income inequality in both the PES and 1.5°C Scenario. However, the 1.5°C Scenario reduction is slower because rich countries keep on being able to reap more economic benefits from the transition than poor countries.
- 31 Income quintile ratios are still high at the end of the transition (IQR = 55), indicating room for further improvement in this indicator.

Estimates suggest that by 2030 - the target year to reach universal modern energy access under Sustainable  Development Goal 7 - 660 million people will still  be  without  electricity  access  and 2.3  billion  will  continue  to  rely  on  traditional  fuels  (Müller et  al. ,  2020).  Stepping  up  to  the  1.5°C Pathway must thus happen in tandem with efforts to scale up sustainable modern energy access. Tackling  inequalities  in  energy  access  and  consumption  also  provides  the  foundation  for  a  more resilient and inclusive society by catalysing economies, creating jobs, strengthening livelihoods and improving well-being for all.

The socio-economic impacts of gaining access to modern energy can be transformative in many respects for communities and enterprises. Energy access has cross-cutting impacts across several welfare  dimensions  discussed  earlier  in  this  chapter,  namely  economic  (through  higher  incomes, consumption  and  employment),  social  (through  lower  health  impacts  of  traditional  fuels)  and distributional.  However,  its  effects  across  other  dimensions  are  strongly  diluted  by  scale  effects. For instance, the increase of consumption and investment brought about by energy access affects the  lower  region  of  the  income  distribution,  and  hence  will  have  a  negligible  impact  on  average consumption and investment triggered by the energy transition.

Within the access dimension of the Energy Transition Welfare Index, the access itself counts ( i.e. ,  share of the population with access) as well as its sufficiency over time ( i.e. , progression along the energy ladder). The use of both indicators concurrently enables a discussion beyond the achievement of universal access by 2030 (defined usually in binary terms) and addresses inequalities in consumption across regions and accounts for opportunities to link energy access with income-generating services that generate strong socio-economic dividends over the long term (see Box 5.7).

Sufficiency is measured as per capita total final energy consumption to capture all energy needs holistically. A limit is set based on distributional and convergence considerations, energy sufficiency literature and energy efficiency (see Annex 5.2 for detailed methodology). Once universal access and sufficiency limits are reached, the dimension becomes neutral for the Energy Transition Welfare Index with impacts now fully captured within other dimensions.

At  the  global  level,  by  2050,  the  access  index  is  0.93  for  the  PES  and  1  for  the  1.5°C  Scenario (a 7% improvement of the 1.5°C Scenario over the PES) (Figure 5.21). This improvement is driven by the basic energy access indicator, whose index is 0.87 for the PES and 1 for the 1.5°C Scenario (a  14.6%  improvement  of  the  1.5°C  Scenario  over  the  PES). 32 The  energy  sufficiency  indicator  is, at a global level, 1 for both the 1.5°C Scenario and PES along the scenarios' time span.

## Tackling inequalities in energy access and consumption advances a more resilient society.

- 32    The 1.5°C Scenario reaches full basic energy access by 2030, in line with the Sustainable Development Goals. By 2030 the improvement of the 1.5°C Scenario over the PES in the basic energy access index is 36.1%, and in the overall access index 16.6%. From 2030 onwards the difference between the 1.5°C Scenario and PES diminishes with time since the 1.5°C Scenario has already reached full access and the PES is still progressing in the basic access dimension.

FIGURE 5.21     Contributions to two access index indicators under the 1.5°C Scenario and PES by 2050, global results

<!-- image -->

## Energy Access Index

<!-- image -->

Based on IRENA's analysis.

At a global level, both the 1.5°C Scenario and PES are above the sufficiency level of per capita total final  energy  consumption (20 kilowatt hour per day, kWh/p-d). Hence, both scenarios reach the highest  possible  value  for  the  sub-index  of  energy  access  sufficiency.  However,  global  averages hide large country and regional inequalities in terms of total final energy consumption, with some countries reaching per capita consumption levels nearly ten times higher than the sufficiency level.

C

H

A

P

T

E

R

5

## BOX 5.7   Linking energy supply with livelihood services

Traditional  approaches  to  energy  access  have  focused  on  achieving  a  certain  number  of  connections  or deploying a given number of systems. The need to encourage productive end uses and to link them with livelihoods is often an afterthought. An alternative approach is to identify energy needs that, if met, are likely to  transform  people's  livelihoods  across  sectors  by  increasing  productivity  and  incomes,  enhancing  value creation and access to markets, reducing drudgery and offering a pathway towards long-term social security.

Decentralised renewable energy solutions are particularly well equipped to provide tailored energy services for livelihood activities across sectors. There are critical differences between an approach that is technology centric  ( i.e. ,  it  aims  to  accelerate  the  deployment  of  specific  solutions  such  as  mini-grids  and  solar  home systems) and one that is end-user/livelihood centric (defines technology solutions based on identified energy needs across value chains). The ecosystem for livelihoods assumes additional dimensions (market linkages, sector-specific skills upgrades, couplings of energy technology with efficient livelihood equipment), which in turn maximise the value of improved energy access (Figure 5.22).

## FIGURE 5.22     Ecosystem needs for supporting livelihoods with distributed renewable energy solutions

<!-- image -->

## CONCLUSION 5.3

The analysis of global socio-economic impacts presented in this chapter indicates that the world will be better off - in multiple dimensions - if societies take the 1.5°C Scenario route. Spurred by investments across the many avenues of the energy transition, global GDP will receive a boost of an average of 1.2% to 2050 over PES. Even in the case of negative  impact  on  GDP  due  to  climate  damages,  the  1.5°C  Scenario  is  a  compelling option as the counterfactual would be much worse. Throughout the transition period, economy-wide employment is 0.9% higher on average in the 1.5°C Scenario compared to  PES.  The  energy  sector  will  have  at  least  122  million  jobs  in  2050,  with  renewable energy jobs rising from more than 11.5 million today to 43 million in 2050. Meanwhile, all  welfare  dimensions  analysed  -  economic,  social,  environmental,  distributional  and access - fare better under the 1.5°C Scenario, offering a 11% improvement in the overall Energy Transition Welfare Index over the PES.

Socio-economic  impacts  may  vary  at  the  regional  or  country  level  compared  to  the  global results  presented  here.  Future  IRENA  work  will  document  the  socio-economic  footprint  of  the 1.5°C Scenario at the regional and country level. The socio-economic footprint analysis highlights how energy transition roadmaps are closely linked with the holistic policy framework, with links becoming  stronger  as  ambitions  align  with  the  1.5°C  Pathway.  Still  navigating  the  COVID-19 pandemic  and  with  increasing  climate  change  impacts  already  being  felt  all  over  the  world, the  current  situation  calls  for  a  holistic  analysis  that  explores  transition  roadmaps  and  policy frameworks on an integrated and equal basis. In this report IRENA has advanced such analyses by closely integrating the policy dimension in the macroeconometric modelling with a focus on addressing social challenges.

<!-- image -->

## A WAY FORWARD

Less than a decade is left to achieve the 2030 Agenda for Sustainable Development and secure a fighting chance for a 1.5­degree world. The stakes cannot be higher, and how the energy system  evolves  in  the  coming  years  will  define  our  shared  future.  IRENA's  World  Energy Transitions  Outlook  provides  a  realistic  pathway  that  can  make  a  difference  in  the  limited time available. It draws on the existing technology solutions to rapidly progress and offers transparent choices for a different energy future.

<!-- image -->

The Outlook emphasises that investment in a comprehensive transformation involves not just a mix of technologies but also investment in the policy package to put them in place and optimise their economic and social impact. It clearly shows that a 1.5-degree world requires wide-reaching action across multiple dimensions to maximise benefits and carefully manage adverse effects. But it also indicates that a renewables-based energy transition can be a powerful equaliser in the world where disparities and gaps between communities, nations and regions continue to widen.

While ambitious climate and energy targets continue to be set, many are yet to be translated into effective policy and regulatory frameworks. Renewable technologies have yet to make sufficient inroads  into  the  end-use  sectors,  such  as  direct  heat,  buildings  and  transport.  And  countries are  grappling  with  multiple  priorities,  many  of  which  cannot  be  solved  in  isolation.  The  need  for international cooperation is evident as the world looks for solutions to meet energy and economic demands, rectify systemic inequalities, and reverse the climate change trends.

The technology avenues, investments and policies proposed in this Outlook can take us closer to where we need to be. There will be innovations, developments, and breakthroughs on the way, but we must not wait. Because we have no time to lose.

## WORLD ENERGY

## References

Ambrose, J. (2019), 'World's biggest sovereign wealth fund to ditch fossil fuels', 12 June, The Guardian, www.theguardian.com/business/2019/jun/12/worlds-biggest-sovereign-wealth-fundto-ditch-fossil-fuels.

Andersson, J. and G. Atkinson (2020), 'The distributional effects of a carbon tax: The role of income inequality', Centre for Climate Change Economics and Policy , Working Paper 378, and Grantham Research Institute on Climate Change and the Environment , Working Paper 349, London School of Economics and Political Science, London.

Appunn, K. (2021), 'Three more German coal power plants to go offline in December 2021', www. cleanenergywire.org/news/three-more-german-coal-power-plants-go-offline-december-2021# :~:text=Two%20German%20hard%20coal%20power,the%20second%20round%20of%20auctions.

Ashden (2021), 'Ashden awards longlist highlights global climate solutions', https://ashden.org/ news/ashden-awards-longlists-highlight-global-climate-solutions/.

Ayaburi, J., M. Bazilian, J. Kincer and T. Moss (2020), 'Measuring 'reasonably reliable' access to electricity services', The Electricity Journal , Vol. 33, no. 7, 106828, https://doi.org/10.1016/j. tej.2020.106828.

Beck, M.R., N. Rivers, R. Wigle, H. Yonezawa, (2015), 'Carbon tax and revenue recycling: Impacts on households in British Columbia', Resource and Energy Economics , Vol. 41, pp. 40-69.

Bellini, E. (2020), 'Portugal's second PV auction draws world record low bid of $0.0132/kWh', PV Magazine , 24 August, www.pv-magazine.com/2020/08/24/portugals-second-pv-auctiondraws-world-record-low-bid-of-0-0132-kwh/ (accessed 26 June 2021).

Beyond Coal (2021), 'Coal exit tracker', https://beyond-coal.eu/coal-exit-tracker/ (accessed 26 June 2021).

BNEF (2021a), Energy Transition Investment Trends , Bloomberg New Energy Finance, London.

BNEF (2021b), Corporate clean energy buying grew 18% in 2020 , despite mountain of adversity, https://about.bnef.com/blog/corporate-clean-energy-buying-grew-18-in-2020-despite-mountainof-adversity/ (accessed 26 June 2021).

BP (2018), 'Energy Outlook: 2020 edition', BP - British Petroleum , www.bp.com/content/dam/ bp/business-sites/en/global/corporate/pdfs/energy-economics/energy-outlook/bp-energyoutlook-2020.pdf.

Brookings (2021), 'The case for US cooperation with India on a just transition away from coal', www. brookings.edu/research/the-case-for-us-cooperation-with-india-on-a-just-transition-away-from-coal/.

Bundesnetzagentur (German Federal Network Agency) (2021), 'Power plant list of the Federal Network Agency - as of January 19, 2021', www.bundesnetzagentur. de/SharedDocs/Downloads/DE/Sachgebiete/Energie/Unternehmen\_Institutionen/ Versorgungssicherheit/Erzeugungskapazitaeten/Kraftwerksliste/Kraftwerksliste\_2021\_1. html;jsessionid=B825E015134CF318D6E1B2B956C7A9EF?nn=320094.

Burke, M. and V. Tanutama (2019), 'Climatic constraints on aggregate economic output', Working paper no. 25779, National Bureau of Economic Research , Cambridge, www.nber.org/papers/w25779.

Burke, M., S.M. Hsiang and E. Miguel (2015), 'Global non-linear effect of temperature on economic production', Nature , Vol. 527, pp. 235-239.

Burke M., W.M. Davis and N.S. Diffenbaugh (2018), 'Large potential reduction in economic damages under UN mitigation targets', Nature , Vol. 557, pp. 549-553.

Business Day (2020), 'Denmark gets nearly 50% of its electricity from wind power', Business Day , 2 January 2020, www.businesslive.co.za/bd/world/europe/2020-01-02-denmark-gets-nearly-50of-its-electricity-from-wind-power/ (accessed 26 June 2021).

CAN (2020), 'Energy transition in the Western Balkans: 2020 missed opportunities', Climate Action Network, https://caneurope.org/energy-transition-western-balkans-2020-missed-opportunities/.

Canada's Ecofiscal Commission (2016), Choose Wisely: Options and Trade-Offs in Recycling Carbon Pricing Revenues , Canada's Ecofiscal Commission, Montreal, https://ecofiscal.ca/wpcontent/uploads/2016/04/Ecofiscal-Commission-Choose-Wisely-Carbon-Pricing-RevenueRecycling-Report-April-2016.pdf.

CBI (2020), Sustainable debt: Global state of the market 2020 , Climate Bonds Initiative, London, www.climatebonds.net/resources/reports/sustainable-debt-global-state-market-2020.

CBI (2019), Green bonds: The state of the market 2018 , Climate Bonds Initiative, London, www.climatebonds.net/resources/reports/green-bonds-state-market-2018.

Ceres (2020), 'New York State Common Retirement Fund becomes first US pension fund to commit to net-zero by 2040', 9 December, Ceres, Boston, www.ceres.org/news-center/pressreleases/new-york-state-common-retirement-fund-becomes-first-us-pension-fund.

CFLI (2019), Financing the low-carbon future: A private-sector view on mobilizing climate finance , Climate Finance Leadership Initiative, www.assets.bbhub.io/company/sites/55/2019/09/Financingthe-Low-Carbon-Future\_CFLI-Full-Report\_September-2019.pdf.

Climatescope (2016), Nepal Renewable Energy Subsidy Policy , 2073 BS, Climatescope, https:// aepc.gov.np/uploads/docs/2018-06-19\_RE%20Subsidy%20Policy,%202073%20(English).pdf

CPR (2021), 'Managing a fair transition away from coal in India', Centre for Policy Research , New Delhi, www.cprindia.org/managing-fair-transition-away-coal-india.

Deutsche Umwelthilfe (2021), Strengthening circularity in photovoltaics: Challenges and opportunities along the lifecycle , www.duh.de/fileadmin/user\_upload/download/Pressemitteilungen/ Kreislaufwirtschaft/210310\_White\_Paper\_Strengthening\_Circularity\_in\_Photovoltaics\_ENG\_FINAL.pdf.

DNV GL (2020), 'Energy transition outlook 2020: A global and regional forecast to 2050', https://eto.dnv.com/2020#ETO2019-top (accessed 26 June 2021).

Dunbar, M. (2013), Engaging the Private Sector in Skills Development , Health &amp; Education Advice and Resource Team (HEART), Oxford Policy Management, Oxford, https://assets.publishing. service.gov.uk/government/uploads/system/uploads/attachment\_data/file/213937/engagingprivate-sector-skills-development.pdf.

EAFO (2021), 'Norway', European Alternative Fuels Observatory, www.eafo.eu/countries/ norway/1747/incentives.

ECIU (2021), 'Net zero tracker', Energy &amp; Climate Intelligence Unit , https://eciu.net/netzerotracker (accessed 26 June 2021).

ECREEE (2015), ECOWAS Renewable Energy Policy , ECOWAS (Economic Community of West African States) Centre for Renewable Energy and Energy Efficiency, Praia, www.ecreee.org/sites/ default/files/documents/ecowas\_renewable\_energy\_policy.pdf.

EECA (2021), 'Funding for heaters and insulation', Energy Efficiency &amp; Conservation Authority, www. eeca.govt.nz/our-work/programmes-and-funding/efficient-homes/funding-for-heaters-and-insulation/.

EIB (2017), CAB Newsletter 10th anniversary , European Investment Bank, Luxembourg, www.eib. org/en/investor\_relations/documents/eib-cab-10-years-newsletter.htm# (accessed 26 June 2021).

Energy Poverty Observatory (2020), 'Inability to keep home adequately warm', www.energypoverty.eu/indicator?primaryId=1461.

Environmental Finance (2020), 'Environmental finance bond database', www.bonddata.org/ (subscription required).

EurObserv'ER (2020), 'Policy and statistic reports: France', www.eurobserv-er.org/eurobserverpolicy-files-for-all-eu-28-member-states/.

European Commission (2021a), 'EU taxonomy for sustainable activities', European Commission, www.ec.europa.eu/info/business-economy-euro/banking-and-finance/sustainable-finance/eutaxonomy-sustainable-activities\_en.

European Commission (2021b), 'Renovation wave', https://ec.europa.eu/energy/topics/energyefficiency/energy-efficient-buildings/renovation-wave\_en.

## WORLD ENERGY

## TRANSITIONS OUTLOOK

European Commission (2020a), 'A renovation wave for Europe - Greening our buildings, creating jobs, improving lives', EUR-Lex, COM(2020) 662 final, https://eur-lex.europa.eu/legal-content/EN/ TXT/?qid=1603122220757&amp;uri=CELEX:52020DC0662.

European Commission (2020b), 'State aid: Commission approves competitive tender mechanism to compensate for early closure of hard coal-fired power plants in Germany', https://ec.europa.eu/ commission/presscorner/detail/en/IP\_20\_2208.

European Commission (2018), Impacts of circular economy policies on the labour market - Final report and Annexes , Cambridge Econometrics, Directorate-General for Environment, ICF and Trinomics, https://op.europa.eu/en/publication-detail/-/publication/fc373862-704d-11e8-948301aa75ed71a1/language-en.

Equinor (2020), Energy perspectives 2020: Long-term macro and market outlook, www.equinor.com/en/sustainability/energy-perspectives/EP-2020.html.

Faaij (2018), Securing sustainable resource availability of biomass for energy applications in Europe; review of recent literature , University of Groningen, Groningen.

FBI (2020), Virtual Power Plant Market Size , Fortune Business Insights, Pune.

Frankfurt School-UNEP Centre and BNEF (2020), Global trends in renewable energy investment 2020 , Frankfurt School-United Nations Environment Programme Centre and Bloomberg New Energy Finance BNEF.

Gesley, J. (2020), 'Germany: Law on phasing-out coal-powered energy by 2038 enters into force', www.loc.gov/law/foreign-news/article/germany-law-on-phasing-out-coal-powered-energy-by2038-enters-into-force/.

Greenpeace (2015), Energy [r]evolution: A Sustainable World Energy Outlook 2015 , Greenpeace international. www.duesseldorf.greenpeace.de/sites/www.duesseldorf.greenpeace.de/files/ greenpeace\_energy-revolution\_erneuerbare\_2050\_20150921.pdf.

Government of the Netherlands (2021), 'Government stimulates geothermal heat', www.government.nl/topics/renewable-energy/government-stimulates-geothermal-heat.

Government of United Kingdom (2019), 'Green Finance Strategy: Transforming Finance for a Greener Future', Crown Publishing, London, www.assets.publishing.service.gov.uk/government/ uploads/system/uploads/attachment\_data/file/820284/190716\_BEIS\_Green\_Finance\_Strategy\_ Accessible\_Final.pdf.

HYBRIT (2021), 'Research project 1', Hybrit, LKAB-SSAB-Vattenfall, www.hybritdevelopment.se/ en/research-project-1/.

ICEF (2018), 'Direct Air Capture of Carbon Dioxide - ICEF Roadmap 2018', ICEF - Innovation for Cool Earth Forum, Tokyo, December, www.icef-forum.org/pdf/2018/roadmap/ICEF2018\_DAC\_ Roadmap\_20181210.pdf.

IEA (2021a), 'Global energy review: CO  emissions in 2020: Understanding the impacts of Covid-19 2 on global CO  emissions', International Energy Agency, Paris, www.iea.org/articles/global-energy2 review-co2-emissions-in-2020.

IEA, (2021b), "Net Zero by 2050: A Roadmap for the Global Energy Sector", IEA, Paris.

IEA (2020a), World Energy Investment 2020 , IEA, Paris.

IEA (2020b), Global Energy Review 2020 , IEA, Paris.

IEA (2020c), 'Energy Technology Perspectives 2020 - Special Report on Carbon Capture, Utilisation and Storage', IEA, Paris, September, https://iea.blob.core.windows.net/ assets/181b48b4-323f-454d-96fb-0bb1889d96a9/CCUS\_in\_clean\_energy\_transitions.pdf.

IEA (2018), Renewable Heat Policies, IEA, Paris.

IEA, IRENA, UN, WBG and WHO (2021), Tracking SDG7: The Energy Progress Report 2021 , IEA, International Renewable Energy Agency, United Nations, World Bank Group, World Health Organisation, World Bank, Washington, D.C.

IEEFA (2020a), 'Dutch asset manager Robeco to divest thermal coal, oil sands holdings by year's end', 25 September, Institute for Energy Economics and Financial Analysis, www.ieefa.org/dutchasset-manager-robeco-to-divest-thermal-coal-oil-sands-holdings-by-years-end/.

IEEFA (2020b), 'U.K.'s biggest pension fund to divest from fossil fuels', 29 July, IEEFA, www.ieefa.org/u-k-s-biggest-pension-fund-to-divest-from-fossil-fuels/#:~:text=The%20 Guardian%3A,landmark%20move%20for%20the%20industry.

ILO (n.d.-a), 'Decent work', International Labour Organization, Genève www.ilo.org/global/topics/ decent-work/lang--en/index.htm.

ILO (n.d.-b), 'Disability and work', ILO, Genève, www.ilo.org/global/topics/disability-and-work/ lang--en/index.htm.

IMO (2015), Third IMO greenhouse gas study 2014 , International Maritime Organization, London,

Inês, C. et al. (2020), 'Regulatory challenges and opportunities for collective renewable energy prosumers in the EU', Energy Policy , Vol. 138, 111212, https://doi.org/10.1016/j.enpol.2019.111212.

IPCC (2018), Global Warming of 1.5°C: An IPCC Special Report on the Impacts of Global Warming of 1.5°C above Pre-Industrial Levels and Related Global Greenhouse Gas Emission Pathways, in the Context of Strengthening the Global Response to the Threat of Climate Change , Intergovernmental Panel on Climate Change, Geneva.

IRENA (forthcoming-a), Renewable Energy Targets: A Guide to Design , International Renewable Energy Agency, Abu Dhabi.

IRENA (forthcoming-b), Sustainable Bioenergy: A Guide to Policy Making , IRENA, Abu Dhabi.

IRENA (forthcoming-c), Renewable Energy Benefits: Leveraging Local Capacity for Solar Water Heaters , IRENA, Abu Dhabi.

IRENA (forthcoming-d), RE-organising power systems for the transition: The dual procurement of electricity for liberalized and public systems , IRENA, Abu Dhabi.

IRENA (2021a), Renewable Capacity Statistics 2021 , IRENA, Abu Dhabi.

IRENA (2021b), Renewable Power Generation Costs in 2020 , IRENA, Abu Dhabi.

IRENA (2021c), 'Renewable energy finance flows,' (database), www.irena.org/Statistics/View-Databy-Topic/Finance-and-Investment/Renewable-Energy-Finance-Flows, (accessed 25 May 2021).

IRENA (2021d), 'Leaders summit: The energy transition priorities needed for a 1.5°C future', IRENA, Abu Dhabi, 25 April, www.irena.org/newsroom/expertinsights/2021/April/Leaders-SummitThe-Energy-Transition-Priorities-Needed-for-a-1-5C-Future.

IRENA (2021e), Renewable energy policies for cities: Transport, IRENA, Abu Dhabi.

IRENA (2021f), Renewable Energy Policies for Cities: Experiences in China, Uganda and Costa Rica , IRENA, Abu Dhabi.

IRENA (2021g), Renewable energy policies for cities: Power sector , IRENA, Abu Dhabi.

IRENA (2021h), Renewable energy policies for cities: Buildings , IRENA, Abu Dhabi.

IRENA (2021i), Green Hydrogen Supply: A Guide to Policy Making , IRENA, Abu Dhabi.

IRENA (2020a), Renewable Energy and Jobs - Annual Review 2020 , IRENA , Abu Dhabi.

IRENA (2020b), The Post-COVID Recovery: An Agenda for Resilience, Development and Equality , IRENA, Abu Dhabi.

IRENA (2020c), Renewable Energy Policies in a Time of Transition: Heating and Cooling , IRENA, Abu Dhabi,

IRENA (2020d), Power System Organisational Structures for the Renewable Energy Era , IRENA, Abu Dhabi.

IRENA (2020e), Electricity Storage Valuation Framework: Assessing system value and ensuring project viability , IRENA, Abu Dhabi.

## WORLD ENERGY

## TRANSITIONS OUTLOOK

IRENA (2020f), Green Hydrogen Cost Reduction: Scaling up Electrolysers to Meet the 1.5°C Climate Goal , IRENA, Abu Dhabi.

IRENA (2020g), Mobilising institutional capital for renewable energy , IRENA, Abu Dhabi.

IRENA (2020h), Renewable energy finance: Sovereign guarantees , IRENA, Abu Dhabi

IRENA (2020i), Renewable energy statistics 2020 , IRENA, Abu Dhabi

IRENA (2020j), Renewable energy finance: Green bonds , IRENA, Abu Dhabi

IRENA (2020k), Business Models: Innovation Landscape Briefs , IRENA, Abu Dhabi.

IRENA (2020l), Green Hydrogen: A Guide to Policy Making , IRENA, Abu Dhabi.

IRENA (2020m), Wind Energy: A Gender Perspective , IRENA, Abu Dhabi.

IRENA (2020n), Measuring the Socio-Economics of Transition: Focus on Jobs , IRENA, Abu Dhabi.

IRENA (2020o), Global Renewables Outlook: Energy transformation 2050 , IRENA, Abu Dhabi.

IRENA (2019a), Innovation landscape for a renewable-powered future: Solutions to integrate variable renewables , IRENA, Abu Dhabi.

IRENA (2019b), A new world: The geopolitics of the energy transformation , IRENA, Abu Dhabi.

IRENA (2019c), Renewable energy auctions: Status and trends beyond price , IRENA, Abu Dhabi.

IRENA (2019d), Global energy transformation: A roadmap to 2050 , IRENA, Abu Dhabi.

IRENA (2019e), Renewable Energy Market Analysis: Southeast Europe , IRENA, Abu Dhabi.

IRENA (2019f), Off-grid renewable energy solutions to expand electricity access: An opportunity not to be missed , IRENA, Abu Dhabi.

IRENA (2019g), Innovation Outlook: Smart Charging for Electric Vehicles , IRENA, Abu Dhabi. IRENA (2019h), Transforming the Energy System - and Holding the Line on Rising Global Temperatures , IRENA, Abu Dhabi.

IRENA (2019i), Renewable Energy: A Gender Perspective , IRENA, Abu Dhabi.

IRENA (2018a), Renewable Energy Benefits: Leveraging Local Capacity for Offshore Wind , IRENA, Abu Dhabi.

IRENA (2018b), Southeast Asia case studies: Biogas programme in Viet Nam , IRENA, Abu Dhabi.

IRENA (2018c), Policies and Regulations for Renewable Energy Mini-Grids, IRENA, Abu Dhabi.

IRENA (2018d), Renewable Energy Benefits: Leveraging Local Capacity for Onshore Wind , IRENA, Abu Dhabi.

IRENA (2017a), Synergies between renewable energy and energy efficiency , IRENA, Abu Dhabi, Stranded assets and renewables: how the energy transition affects the value of

IRENA (2017b), energy reserves, buildings and capital stock , IRENA, Abu Dhabi.

IRENA (2017c), Adapting Market Design to High Shares of Variable Renewable Energy , IRENA, Abu Dhabi.

IRENA (2017d), Renewable Energy in District Heating and Cooling: A Sector Roadmap for REmap , IRENA, Abu Dhabi.

IRENA (2017e), Renewable Energy Benefits: Leveraging Local Capacity for Solar PV , IRENA, Abu Dhabi.

IRENA (2017f), Renewable Energy Benefits: Leveraging Local Capacity for Onshore Wind , IRENA, Abu Dhabi.

IRENA (2016a), Unlocking Renewable Energy Investment: The role of risk mitigation and structured finance , IRENA, Abu Dhabi.

IRENA (2016b), Renewable Energy Benefits: Measuring the Economics , IRENA, Abu Dhabi.

IRENA (2014), Global bioenergy supply and demand projections: A working paper for REmap 2030 , working paper, IRENA, Abu Dhabi.

IRENA Coalition for Action (2020a), Companies in transition towards 100% renewable energy: Focus on heating and cooling , white paper, IRENA, Abu Dhabi.

IRENA Coalition for Action (2020b), Stimulating investment in community energy: Broadening the ownership of renewables , white paper, IRENA, Abu Dhabi.

IRENA Coalition for Action (2018), Community Energy: Broadening the Ownership of Renewables , IRENA, Abu Dhabi.

IRENA and CPI (2020), Global Landscape of Renewable Energy Finance 2020 , IRENA, Climate Policy Initiative, Abu Dhabi and London.

IRENA and CPI (2018), Global Landscape of Renewable Energy Finance 2018 , IRENA, CPI, Abu Dhabi and London.

IRENA and IEA-PVPS (2016), End-of-Life Management: Solar Photovoltaic Panels , IRENA, International Energy Agency - Photovoltaic Power Systems, Abu Dhabi and Paris.

IRENA, IEA and REN21 (2020), Renewable Energy Policies in a Time of Transition: Heating and Cooling , IRENA, OECD/IEA and Renewable Energy Policy Network for the 21st Century, Abu Dhabi and Paris.

IRENA, IEA and REN21 (2018), Renewable Energy Policies in a Time of Transition , IRENA, OECD/ IEA and REN21, Abu Dhabi and Paris.

Jolly, J. (2021), 'Major UK pension funds worth nearly GBP 900 bn commit to net zero?', 10 March, The Guardian, www.theguardian.com/business/2021/mar/10/major-uk-pension-funds-worthnearly-900bn-commit-to-net-zero.

Lederman, J. and D. Chow. (2021), 'Biden commits to cutting U.S. emissions in half by 2030 as part of Paris climate pact', NBC news, 22 April, www.nbcnews.com/politics/white-house/bidenwill-commit-halving-u-s-emissions-2030-part-paris-n1264892.

Li S. and Yu R. (2021), 'China reveals co-operation with EU on green investment standards', 7 April, Financial Times, www.ft.com/content/cddd464f-9a37-41a0-8f35-62d98fa0cca0.

Louie, E. and Pearce, J. (2016), 'Retraining investment for U.S. transition from coal to solar photovoltaic employment', Energy Economics , Volume 57, Pages 295-302, ISSN 0140-9883, https://doi.org/10.1016/j.eneco.2016.05.016.

Mao, X. D. Rutherford, L. Osipova, and B. Comer (2020), 'Refueling assessment of a zeroemission container corridor between China and the United States: Could hydrogen replace fossil fuels?', International Council for Clean Transportation, Working Paper 2020-05, https://theicct.org/ sites/default/files/publications/Zero-emission-container-corridor-hydrogen-3.5.2020.pdf.

Marston J. (2018), 'Why these companies turn to coal country for skilled workers', www.edf.org/ blog/2018/05/08/why-these-companies-turn-coal-country-skilled-workers.

Mazzacurati, E. (2017), 'Art. 173: France's Groundbreaking Climate Risk Reporting Law', 16 January, Four Twenty Seven, www.427mt.com/2017/01/16/impact-french-law-article-173/ (accessed 26 June 2021).

McLaughlin, C. (2019), 'Denmark ends district heating heat pump grants', Ammonia21, 10 January, www.ammonia21.com/articles/8776/denmark\_ends\_district\_heating\_heat\_pump\_ grants#:~:text=Denmark%20has%20ended%20its%20support,for%20district%20heating%20 heat%20pumps.

MNRE (2021), 'Production linked incentive scheme 'National Programme on High Efficiency Solar PV Modules'', F. No. 283/62/2020-grid solar, Ministry of New &amp; Renewable Energy, Government of India, https://mnre.gov.in/img/documents/uploads/file\_f-1619672166750.pdf.

Müller, F., S. Claar, M. Neumann and C. Elsner (2020), 'Is green a Pan-African colour? Mapping African renewable energy policies and transitions in 34 countries', Energy Research &amp; Social Science , Vol. 68, 101551, https://doi.org/10.1016/j.erss.2020.101551.

## WORLD ENERGY

## TRANSITIONS OUTLOOK

OECD (2016), Effective Carbon Rates: Pricing CO  through Taxes and Emissions Trading Systems 2 , Organisation for Economic Co-operation and Development, Paris, www.oecd.org/tax/effectivecarbon-rates-9789264260115-en.htm.

OECD and Milken Institute (2018), Guaranteeing the Goals: Adapting public sector guarantees to unlock blended financing for the U.N. Sustainable Development Goals , OECD and Milken Institute, www.milkeninstitute.org/sites/default/files/reports-pdf/Guaranteeing-the-Goals-FINAL-4\_2.pdf.

OTPP (2021), 'Ontario Teachers' Pension Plan commits to net zero emissions by 2050', 21 January, Ontario Teachers' Pension Plan, www.otpp.com/news/article/a/ontario-teachers-pension-plancommits-to-net-zero-emissions-by-2050, (accessed 26 June 2021).

Ombello, C. (2020), '1.35 cents/KWh: Record Abu Dhabi solar bid is a sober reminder to upbeat fossil fuel pundits', Clean Technica, 8 June, https://cleantechnica.com/2020/06/08/1-35-centskwh-record-abu-dhabi-solar-bid-is-a-sober-reminder-to-upbeat-fossil-fuel-pundits/.

Perez, C. (2002), Technology revolutions and financial capital: The Dynamics of Bubbles and Golden Ages , Edward Elgar Publishing, ISBN: 978 1 84064 922 2.

Petrova, V. (2021), 'Germany's 2nd coal phase-out tender ends with 1,514 MW of successful bids', 5 April, https://renewablesnow.com/news/germanys-2nd-coal-phase-out-tender-ends-with-1514mw-of-successful-bids-736871/.

REN21 (2020), Renewables 2020 Global Status Report , Renewable Energy Policy Network for the 21st Century Secretariat, Paris.

REN21 (2019), Renewables in Cities 2019 Global Status Report , REN21 Secretariat, Paris.

REN21 (2018), Renewables 2018 Global Status Report , REN21 Secretariat, Paris.

REN21 (2017), Renewables 2017 Global Status Report , REN21 Secretariat, Paris.

Renew Economy (2019), 'Renewables deliver 47% of total generation in Germany so far in 2019', Renew Economy, 4 October, https://reneweconomy.com.au/renewables-deliver-47-of-totalgeneration-in-germany-so-far-in-2019/.

Reuters (2021), 'New Zealand introduces climate change law for financial firms in world first', 13 April, Reuters, www.reuters.com/business/sustainable-business/new-zealand-introduces-climatechange-law-financial-firms-world-first-2021-04-12/.

Reuters (2020), 'Germany to extend electric car subsidies to 2025', www.reuters.com/article/ukgermany-autos-subsidy-idUKKBN27W2FT.

Ripke, J. (2017), 'Innovative uses of Hydrogen in Steelmaking', U.S. Department of Energy, www. energy.gov/sites/prod/files/2017/05/f34/fcto\_may\_2017\_h2\_scale\_wkshp\_ripke.pdf.

S&amp;P Dow Jones Indices LLC (2021), 'S&amp;P 500', www.spglobal.com/spdji/en/indices/equity/sp500/#overview (accessed 25 May 2021).

Sendea (2021), Sendea Uganda: Solar Entrepreneuers Network for Decentralized Energy Access , www.sendea.org/.

Congressional Research Service (2019), The value of tax incentives for different types of energy resources , CRS Reports R44852, www.fas.org/sgp/crs/misc/R44852.pdf.

Shell (2021), 'The Energy Transformation Scenarios', www.shell.com/energy-and-innovation/theenergy-future/scenarios/the-energy-transformation-scenarios.html.

Shenzhen DRC (2021), Plan for Promoting New Energy Vehicles in Shenzhen City 2021-2025 ( 深圳市新能源汽车推广应用方案 2021-2025), Shenzhen Development and Reform Commission of Shenzhen Municipality, 31 March, http://fgw.sz.gov.cn/zwgk/zcfgjzcjd/zcfg/content/ post\_8667568.html.

Shumkov, I. (2020), 'Germany accepts bids for 4,788 MW in first coal phase-out tender', 4 Dec. https://renewablesnow.com/news/germany-accepts-bids-for-4788-mw-in-first-coal-phase-outtender-723394/ (accessed 27 June 2021).

SIFMA (2020), Capital Markets Fact Book 2020 , Securities Industry and Financial Markets Association, www.sifma.org/resources/research/fact-book/.

Skills Development Scotland (2019), 'Energy sector training fund helps 4272 people', Skills Development Scotland. www.skillsdevelopmentscotland.co.uk/news-events/2019/may/energysector-training-fund-helps-4272-people/.

SLoCAT (2020), 'E-mobility trends and targets', January 2020, Partnership on Sustainable Low Carbon Transport, https://slocat.net/wp-content/uploads/2020/02/SLOCAT\_2020\_e-mobility-overview.pdf.

Sovacool, B.K. and M.H. Dworkin (2015), 'Energy justice: conceptual insights and practical applications', Applied Energy , Vol. 142, pp.435-444.

TCFD (2019), Task Force on Climate-related Financial Disclosures: 2019 Status Report , Task Force on Climate-Related Financial Disclosures, www.fsb.org/2019/06/task-force-on-climate-relatedfinancial-disclosures-2019-status-report.

Teske S. (ed.) (2019), Achieving the Paris Climate Agreement Goals: Global and Regional 100% Renewable Energy Scenarios with Non-energy GHG Pathways for +1.5°C and +2°C , Springer International Publishing, www.springer.com/gp/book/9783030058425.

The White House (2021), 'Fact sheet: President Biden's leaders summit on climate', Briefing room, 23 April, www.whitehouse.gov/briefing-room/statements-releases/2021/04/23/fact-sheetpresident-bidens-leaders-summit-on-climate/.

The Motorship (2020), 'MAN ES targets 2024 for delivery of first ammonia engine', 2 June, www. motorship.com/news101/alternative-fuels/man-es-targets-2024-for-delivery-of-first-ammonia-engine.

Tuck, N. (2020), 'Sweden's AP1 to divest fully from fossil fuels', 16 March, European Pensions, www.europeanpensions.net/ep/Sweden-AP1-to-divest-fully-from-fossil-fuel.php.

UNIDO (2020), Clean Energy Mini-Grid Policy Development Guide , United Nations Industrial Development Organization, Vienna, www.unido.org/sites/default/files/files/2021-03/CEMG\_ Development\_Guide\_EN.pdf.

United States DoE (2021), 'Renewable energy tax credits', United States Department of Energy, www.energy.gov/articles/renewable-energy-tax-credits.

United States DoE (n.d.), 'Federal tax credits for new all-electric and plug-in hybrid vehicles', www.fueleconomy.gov/feg/taxevb.shtml.

VDE FNN (2018), 'Technical Connection Rules for Extra High-Voltage (VDE-AR-N 4130)', www.vde.com/en/fnn/topics/technical-connection-rules/tcr-extra-high-voltage

World Energy Council (2020), World Energy Trilemma Index 2020 , World Energy Council, London, https://trilemma.worldenergy.org/reports/main/2020/World%20Energy%20Trilemma%20 Index%202020.pdf.

WHO (World Health Organization) (n.d.), 'Policies enabling the adoption of clean household energy', www.who.int/airpollution/household/interventions/policy/en/.

Wood Mackenzie (2020), 'Off-grid renewable investment' (database), https://datahub.woodmac. com/app/main#/dashboards/5d3a1511d249d18c0f001758, (subscription required).

World Bank (2019a), 'GDP (current, US$)', World Bank, Washington D.C., www.data.worldbank. org/indicator/NY.GDP.MKTP.CD.

World Bank (2019b), '10 years of green bonds: Creating the blueprint for sustainability across capital markets', World Bank, Washington D.C., www.worldbank.org/en/news/immersivestory/2019/03/18/10-years-of-green-bonds-creating-the-blueprint-for-sustainability-acrosscapital-markets.

WRI (2021), 'Ethiopia: Expanding opportunities for women in the electricity sector', World Resources Institute, www.wri.org/just-transitions/ethiopia.

## ANNEXES

## ANNEX A SECTOR-SPECIFIC

## TRANSITION STRATEGIES

A1 Transport

A2 Industry

A3 Buildings

## ANNEX B SOCIO-ECONOMIC FOOTPRINT OF THE TRANSITION

<!-- image -->

## SECTOR SPECIFIC TRANSITION

The  energy  transition  requires  changes  on  the  supply  side  (discussed  in  Chapter  2)  and  on  the demand side (discussed here). This annex provides sector- and technology-specific details of the transition, looking ahead at the years until 2030 and 2050.

The analysis shows that a range of technologies and strategies need to be deployed. Renewables will play a dominant role in all end-use sectors such as electricity, green hydrogen or synthetic fuels produced from green hydrogen. Bioenergy and biomass feedstocks will also play an increasing role notably in industry and the transport sector.

In  industry,  renewable  electricity  and  bioenergy,  clean  hydrogen  and  carbon  dioxide  (CO ) 2 management  solutions  such  as  carbon  capture  and  storage  (CCS)  and  bioenergy  with  CCS (BECCS) play  an  important  role. Energy-intensive  industries  may  relocate  to  sites  with  access to  low-cost  renewable  energy.  The  total  share  of  renewables  in  industry  grows  to  66%  of  final consumption by 2050 (including non-energy uses).

In  the  transport  sector,  direct  electrification  dominates  cars  and  commercial  road  vehicles while ammonia from green hydrogen and renewable methanol dominate shipping. In aviation, a mix of synthetic fuels and biofuels will be needed. Whereas total electricity will account for 49% of the transport sector's final demand (90% of which is renewable) and biofuels for 24%, synthetic fuels raise renewables' share to 82% of final consumption in transport by 2050.

In the buildings sector, efficiency dominates. This encompasses a major retrofit of buildings as well as efficient space cooling devices and appliances. These must be combined with heat pumps for space and water heating. Traditional biomass cooking stoves are largely replaced with electricity, and to a lesser extent with green gas and modern biomass cooking stoves. The share of electricity in  buildings  grows  to  73%  and  the  total  share  of  renewables  in  buildings  grows  to  89%  of  final consumption by 2050.

The shift  from  fossil  fuels  to  electricity  and  other  forms  of  modern  renewable  energy  is  a  major efficiency driver, resulting in a significant drop in global energy use for transport and buildings while industrial final consumption increases slightly.

Investment opportunities for end-use sectors are detailed in this annex. These are dominated by building renovations and enabling infrastructure, such as for vehicle recharging. It should be noted that the substantial investment needed for renewable energy supply - including renewable power generation and electricity grids - are accounted for on the supply side. Also, electric cars and their related battery manufacturing plants, lithium mines and so on are not counted as energy transition investments. If such investments were included, they would raise the investment needs substantially. Meanwhile, investment needs for conventional internal combustion engines and related components will decline dramatically.

Table A.1 outlines key indicators for the changes needed to move the world from where it is today to where it needs to be in 2050 in the 1.5°C Scenario. The indicators show that significant acceleration is needed across a range of sectors and technologies, from deeper end-use electrification of transport and  heat  powered  by  renewables,  to  direct  renewable  use,  energy  efficiency  and  infrastructure needs. Such a substantial acceleration would be realised by increasing investment in the energy transition starting today.

<!-- image -->

## TABLE A.1     Energy Sector: Indicators of progress - status in 2018 and targets for 2030 and 2050

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Energy transition component   | Key Indicators                                 | Historical   | Where we need to be   | Where we need to be   | Implications/key actions                                                                                                                                                   |
|-------------------------------|------------------------------------------------|--------------|-----------------------|-----------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Energy transition component   | Unit                                           | 2018         | 2030                  | 2050                  |                                                                                                                                                                            |
| RENEWABLES                    | Renewable energy share of TPES (%)             | 14 %         | 38 %                  | 74 %                  | Stabilise primary energy demand with improved efficiency (including circular economy practices), accelerated deployment of renewables and other clean energy technologies. |
| RENEWABLES                    | Renewable energy share of power generation (%) | 25 %         | 65 %                  | 90 %                  | Emphasise solar and wind deployment, but also maximise solid biomass and biogas in the niche applications where they make sense.                                           |
| RENEWABLES                    | Renewable energy share of TFEC (%)             | 17 %         | 38 %                  | 79 %                  | Besides electrification, keep strong focus on solar thermal heating in buildings and liquid biofuels in transport.                                                         |
| RENEWABLES                    | Biomass - supply (EJ/yr)                       | 54 (EJ/yr)   | 99 (EJ/yr)            | 153 (EJ/yr)           | Bioenergy should be obtained in ways that are environmentally, socially and economically sustainable.                                                                      |
| ENERGY EFFICIENCY             | TPES (EJ/yr)                                   | 598 (EJ/yr)  | 590 (EJ/yr)           | 614 (EJ/yr)           |                                                                                                                                                                            |
| ENERGY EFFICIENCY             | Energy intensity improvement rate d (%)        | 1.2 %        | 2.6 %                 | 2.9 %                 | Promote efficiency standards and efficient appliances and create conditions for project developers that speed the deployment of energy efficiency technologies.            |
| ENERGY EFFICIENCY             | TFEC (EJ/yr)                                   | 378 (EJ/yr)  | 373 (EJ/yr)           | 348 (EJ/yr)           | Promote efficiency standards and efficient appliances and create conditions for project developers that speed the deployment of energy efficiency technologies.            |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

- a. Excludes electricity needs for green hydrogen.
- b. Includes battery and plug-in hybrid electric cars.
- c.   Includes energy, process, non-energy use emissions along with CO  captured by CCS, CCU, BECCS and other carbon 2 removal processes.
- d.   Energy efficiency intensity is measured in terms of primary energy use divided by gross domestic product (GDP). This shows the amount of energy required to generate one unit of GDP.

Note: TFEC = total final energy consumption; TPES = total primary energy supply.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Energy transition             | Key Indicators                                                                                                                                   | Historical               | Where we need to be    | Where we need to be    | Implications/key actions                                                                                                                                                                                                                         |
|-------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------|------------------------|------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| component                     | Unit                                                                                                                                             | 2018                     | 2030 (1.5°C Scenario)  | 2050                   |                                                                                                                                                                                                                                                  |
| ELECTRIFI- CATION OF END-USES | Electricity share in TFEC a (direct) (%)                                                                                                         | 21 %                     | 30 %                   | 51 %                   | Focus on electric mobility and electrifying heat in buildings and industry, and on synthetic fuels and feedstocks.                                                                                                                               |
| ELECTRIFI- CATION OF END-USES | Electricity consumption (direct) a (TWh/yr)                                                                                                      | 22315 TWh/yr             | 31070 TWh/yr           | 49275 TWh/yr           | Focus on electric mobility and electrifying heat in buildings and industry, and on synthetic fuels and feedstocks.                                                                                                                               |
| ELECTRIFI- CATION OF END-USES | Electric cars stock b (million)                                                                                                                  | >6 million               | 381 million            | 1780 million           | Create the conditions for the electric mobility market to develop. Deploy and incentivise charging infra- structure. Promote sector coupling and circular economy principles.                                                                    |
| ELECTRIFI- CATION OF END-USES | Heat pumps installations (million)                                                                                                               | 38 million               | 182 million            | 394 million            | Promote alternative heating technologies such as heat pumps. Heat pumps achieve energy efficiencies three to five times higher than fossil-fuelled boilers and can be powered by renewable electricity.                                          |
| HYDROGEN AND ITS DERIVATES    | Clean hydrogen production (EJ/yr)                                                                                                                | 0 EJ/yr                  | 18.5 EJ/yr             | 73.6 EJ/yr             | Set up a stable and supportive policy framework. Promote certification of hydrogen from renewable power.                                                                                                                                         |
| HYDROGEN AND ITS DERIVATES    | Clean hydrogen share in TFEC (%)                                                                                                                 | 0 %                      | 3 %                    | 12 %                   | Promote hydrogen-based direct reduced iron furnace for steel production and for chemical productions in industry.                                                                                                                                |
| CO 2 REMOVALS                 | Carbon capture and storage (CCS) and carbon capture and utilisation (CCU) for process and fossil fuel emissions in industry (GtCO 2 captured/yr) | 0.01 GtCO 2 captured/yr  | 1.3 GtCO 2 captured/yr | 3.4 GtCO 2 captured/yr | Apply CCS to abate remaining energy and process emissions in cement and steel sectors. Apply carbon capture (CCUS) in the production and waste management phases of chemicals and plastics and use the carbon for renewable hydrogen production. |
| CO 2 REMOVALS                 | Biomass with CCS (BECCS) (GtCO 2 captured/yr)                                                                                                    | 0.002 GtCO 2 captured/yr | 0.8 GtCO 2 captured/yr | 4.5 GtCO 2 captured/yr | Use biomass with CCS (BECCS) to produce negative emissions that can offset the remaining emissions of the power, cement and chemicals sector in the lifecycle.                                                                                   |
| CO 2 EMISSIONS                | CO 2 emissions (net) c (GtCO 2 /yr)                                                                                                              | 36 GtCO 2 /yr            | 22.9 GtCO 2 /yr        | -0.4 GtCO 2 /yr        | Renewables and energy efficiency measures, combined with deep electrification of end use applications can provide over 90% of the reductions required by 2050.                                                                                   |

<!-- image -->

The rate of change in the 1.5°C Scenario is daunting - much of today's energy infrastructure and capital stock will need to be replaced in the next three decades to translate this vision into a reality. Ultimately, the speed and extent of movement in this direction will determine the world's progress towards  the  goals  of  the  Paris  Agreement.  The  world  needs  to  capitalise  now  on  the  renewed commitments  by  countries  to  take  immediate,  collaborative  and  concrete  actions  to  meet  the challenge of climate change (IRENA, 2021a).

Chapter 2 summarises the technological avenues for the 1.5°C Scenario. The following discussion provides  further  details  on  the  end-use  sectors  of  transport,  industry  and  buildings.  IRENA  will conduct more studies on these topics and will further engage stakeholders and countries to discuss the actions needed in each of these sectors.

Total decarbonisation of all sectors is challenging but feasible under the 1.5°C Scenario. Proven technologies for a net zero energy system already exist.

## TRANSPORT A.1

The mobility of people and goods across the globe plays a vital role in today's economy and society. The transport sector is responsible for close to a quarter of global-energy-related CO  emissions 2 due to its heavy reliance on fossil fuels. With the global demand for transport services expected to increase in future years, it is crucial to sustainably transform the sector and advance towards a zerocarbon sector.

In  IRENA's  1.5°C  Scenario,  transport  would  see  a  faster  and  more  profound  transformation  with accelerated deployment of low-carbon solutions, as compared to current projections. Key shifts in this scenario include the following:

- · Transport  would  see  accelerated  electrification  and  an  associated  deployment  of  charging infrastructure in the coming decades. The share of electricity in final energy consumption would rise from 1% in 2018 to 49% by 2050. Electric vehicles would account for more than 80% of all road transport activity by 2050. Such a transition implies that close to a third of all light-duty vehicle sales and a fifth of truck sales over the current decade to 2030 should be electric.
- · Total liquid biofuel production would need to grow almost five fold by 2050, contributing 25% of the overall energy demand in the transport sector.
- · Hydrogen and its derivatives would offer a solution to transport needs that are hard to meet through direct electrification, mitigating close to 2.2 gigatonnes of CO  (GtCO ) emissions in the 2 2 1.5°C Scenario compared to the Planned Energy Scenario in 2050.
- · A combination of energy efficiency measures and low-carbon approaches would reduce transport consumption from 121 exajoules (EJ) in 2018 to close to 94 EJ by 2050. Adoption of stringent efficiency standards for new cars and trucks can reduce cumulative emissions in road transport by an estimated 15 GtCO  equivalent until 2050. 2
- · Beyond  technologies,  innovative  mobility  services  and  a  modal  shift  from  passenger  cars  to public transport (electric railways or trams), and from trucks to electric railways in the case of freight, would need to be promoted.

The combination of energy transition options adopted in IRENA's 1.5°C Scenario would lead to a drastic reduction in transport emissions from 8.2 GtCO  in 2018 to 0.4 GtCO  in 2050. Such a radical 2 2 transition  entails  scaling  up  energy  transition  investments  in  the  transport  sector  amounting  to USD 11.3 trillion in the period to 2050. In annual terms, USD 375 billion per year on average will be needed over the next three decades for measures including deploying charging infrastructure for electric vehicles, liquid biofuels production and greater energy efficiency.

<!-- image -->

## A.1.1 Overview and trends

The transport sector contributed total emissions of almost 8.2 GtCO  in 2018. The sector's energy 2 consumption was 118 EJ (or around 2 820 million tonnes of oil equivalent [Mtoe]), dominated by oil (92%) followed by small amounts of natural gas (4%), biofuels (3%) and electricity (1%). Threequarters of the sector's energy consumption occurred in road transport alone.

The electrification of transport is showing signs of disruptive change. Global sales of electric cars in 2020 grew 43% compared to 2019, to reach 3.2 million units, accounting for 4.2% of global new car sales (Irie, 2020). Meanwhile, global biofuels production and use in the transport sector continue to rise as more countries commit to higher blending targets, such as in Brazil, India and Indonesia (REN21, 2020). Recent innovations and pilot projects also point towards the potential to increase the use of alternative fuels in the form of hydrogen, ammonia, methanol and synthetic kerosene, in particular for use in aviation and shipping (IRENA, 2021b).

## FIGURE A.1     Total energy consumption and CO  emissions in transport 2

<!-- image -->

Under the 1.5°C Scenario, renewable electricity use could increase significantly, providing 44% of total transport energy consumption by 2050. A combination of low-carbon approaches would cut transport emissions to just 0.4 GtCO  annually 2 by 2050, a 97% reduction compared to 2018.

<!-- image -->

T

R

A

N

S

I

T

O

N

S

O

U

T

L

O

K

## TABLE A.2a     Transport: Indicators of progress - status in 2018 and targets for 2030 and 2050

<!-- image -->

| Energy transition                           | Indicators                                                     | Historical                                | Where we need to be                       | Where we need to be                       | Implications/Key actions                                                                                                                                                                            |                                           |
|---------------------------------------------|----------------------------------------------------------------|-------------------------------------------|-------------------------------------------|-------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------|
| component                                   |                                                                | 2018                                      | 2030 (1.5°C Scenario)                     | 2050                                      |                                                                                                                                                                                                     |                                           |
|                                             | Unit                                                           |                                           |                                           |                                           |                                                                                                                                                                                                     |                                           |
| Energy transition strategy and components   | Energy transition strategy and components                      | Energy transition strategy and components | Energy transition strategy and components | Energy transition strategy and components | Energy transition strategy and components                                                                                                                                                           | Energy transition strategy and components |
| ENERGY CONSERVATION AND EFFICIENCY          | Transport - TFEC (EJ)                                          | 121 EJ                                    | 122 EJ                                    | 93 EJ                                     | • Improve energy efficiency through novel technologies and operational measures. • Accelerate modal shift in transport from road and aviation to rail and public transport. • Reduce travel demand. |                                           |
| ELECTRIFICATION IN END-USE SECTORS (DIRECT) | Share of electricity in TFEC (%)                               | 1 %                                       | 9 %                                       | 49 %                                      | • Promote the rapid electrification of road transport. • Support battery and charging research and development (R&D), considering both mobility and grid needs.                                     |                                           |
| RENEWABLES (DIRECT USES)                    | Biofuels share in transport TFEC (%)                           | 3 %                                       | 13 %                                      | 24 %                                      | • Broaden and scale up the sustainable production and use of biofuels.                                                                                                                              |                                           |
| HYDROGEN AND ITS DERIVATIVES                | Clean hydrogen share in transport TFEC (%)                     | <0.1 %                                    | 0.7 %                                     | 12 %                                      | • Explore hydrogen as a potential transport fuel for road, aviation and shipping. • Introduce and scale up the use of alternative fuels though measures to support early demand.                    |                                           |
| HYDROGEN AND ITS DERIVATIVES                | Ammonia, methanol, synthetic fuels share in transport TFEC (%) | <0.1 %                                    | 0.4 %                                     | 8 %                                       | • Explore hydrogen as a potential transport fuel for road, aviation and shipping. • Introduce and scale up the use of alternative fuels though measures to support early demand.                    |                                           |
| CO 2 emissions                              | CO 2 emissions                                                 | CO 2 emissions                            | CO 2 emissions                            | CO 2 emissions                            | CO 2 emissions                                                                                                                                                                                      | CO 2 emissions                            |
| CO 2 EMISSIONS                              | Direct (GtCO 2 /yr)                                            | 8.2 GtCO 2 /yr                            | 6.7 GtCO 2 /yr                            | 0.4 GtCO 2 /yr                            | Encourage strong commitments from national, regional and regulatory bodies to reach net zero emissions in transport.                                                                                |                                           |

2017-2019 Note: TFEC = total final energy consumption.

2021-2050 (1.5°C Scenario)

Transport total

69 USD billion/year

(USD billion/

year)

375 USD billion/year

CO2 emissions

CO2 EMISSIONS

fuels share in transport

TFEC

(%)

Direct

(GtCO2/yr)

8.2

GtCO /yr

2

6.7

GtCO /yr

2

0.4

GtCO /yr

2

TABLE A.2b     Transport: Energy transition investments

<!-- image -->

|                                               | 2017-2019          | 2021-2050 (1.5°C Scenario)   |
|-----------------------------------------------|--------------------|------------------------------|
| Transport total (USD billion/ year)           | 69 USDbillion/year | 375 USDbillion/year          |
| ENERGY EFFICIENCY                             | 65 USDbillion/year | 157 USDbillion/year          |
| LIQUID BIOFUELS PRODUCTION                    | 2 USDbillion/year  | 87 USDbillion/year           |
| CHARGING INFRASTRUCTURE FOR ELECTRIC VEHICLES | 2 USDbillion/year  | 131 USDbillion/year          |

Note: Electric cars, the related battery manufacturing plant, lithium mines etc. are not counted as energy transition investments.

Encourage strong commitments from national, regional and regulatory

bodies to reach net zero emissions in transport.

<!-- image -->

T

## A.1.2 Transitioning towards decarbonisation

A combination of actions will be needed to achieve the massive reduction in emissions needed in the transport sector.

- · Accelerating the adoption of electric vehicles for road transport, in parallel with decarbonisation of the power supply, is the single-most important lever for the decarbonisation  of  the  transport  sector. Technological  progress  -  notably,  the  evolution  of batteries - has greatly improved the economic case for electric vehicles in recent years, and the scope of application is quickly expanding to a broader set of road vehicle segments and types of services. If ongoing cost reduction trends consolidate, by 2050 the bulk of global road transport services could be delivered cost-effectively with electric technology. In IRENA's 1.5°C Scenario, electric vehicles account for more than 80% of all road transport activity by 2050 (88% of the technology mix in light-duty vehicles and 70% in heavy-duty vehicles). To meet these targets, close to a third of all light-duty vehicle sales and a fifth of truck sales over the current decade to 2030 should be electric.
- · Electrification  also  has  a  role  to  play  in  the  deeper  decarbonisation  of  the  rail  sector. Electricity already plays an important role in this sector, accounting for 41% of the energy use in trains worldwide. Electric train technology is mature and has been applied for decades. Further electrification is technically possible and can be cost-effective in a broad set of circumstances.
- · n  addition  to  electrification,  a  decarbonisation  of  the  transport  sector  in  line  with  the  goals I of the Paris Agreement would require scaling up the adoption of renewable fuels including sustainable biofuels, hydrogen and synthetic fuels. In IRENA's 1.5°C Scenario, the production of sustainable liquid biofuels needs to be scaled up five fold compared to today's level. Biofuels, hydrogen and renewable-based synthetic fuels can be used in the remaining stock of combustion locomotives and for those routes where low-capacity factors make electric systems unattractive. Renewable power based fuels would account for around 11% of the final energy consumption of land-based transport by 2050. For the aviation sector, the use of biojet fuels would comprise 47% of the total fuel consumption, or around 204 billion litres of biofuels produced annually in the 1.5°C Scenario. The use of synthetic kerosene is also introduced in IRENA's 1.5°C Scenario, composing up to 23% of fuel use by 2050 with almost 100 billion litres of fuel required. Liquefied natural gas as a transition fuel in the international shipping sector would comprise 7% in 2030, but by 2050, investments in low-carbon fuel and ships would see ammonia, methanol and hydrogen composing almost 60% of the fuel mix.

- · The adoption of stringent efficiency standards for these new transport modes, along with behavioural changes, is crucial. In  addition to a drastic shift in the technology mix delivering energy  services,  structural  changes  in  how  mobility  services  are  delivered  in  the  first  place can  help  facilitate  decarbonisation.  Substantial  potential  exists  for  a  modal  shift  from  private passenger cars to collective transport (buses and trains), as well as from passenger aviation and road-based freight to rail.
- · The introduction of novel aircraft running on hydrogen and electricity (or hybrids) by 2035 for  regional short-haul flights will further increase the overall energy efficiency gains for aviation. Electric aircraft are powered by batteries and offer the advantages of more energyefficient motors and being fully carbon neutral if powered by 100% renewable electricity. Electricbattery-driven aircraft can be up to 1.8 times as energy efficient as conventional aircraft (Gnadt et al. , 2019; Schäfer et al. , 2019). Hydrogen aircraft technologies can either combust hydrogen in a jet engine or use it in fuel cells to produce electricity to drive propellors, with the latter approach currently favoured by developers. Both systems demand less energy and have greater emission reduction  potential  compared  to  conventional  aircraft  (Clean  Sky  2  JU  and  FCH  2  JU,  2020). Airbus's  recently  revealed  concepts  for  hydrogen-powered  zero-emissions  aircraft,  which  the company aims to be in service by 2035, is an encouraging sign. In IRENA's 1.5°C Scenario, electric and hydrogen aircraft together can replace 35% of short-haul flights of less than 1 100 kilometres. Together, hydrogen and electricity would comprise around 14% of the aviation sector's energy consumption by 2050.

IRENA's analysis of the 1.5°C Scenario shows that a combination of efficiency measures and lowcarbon approaches, as listed above based on transport mode, would reduce transport consumption to 93 EJ by 2050. In this scenario, electricity would account for 49% of consumption (90% of which is  supplied  by  renewables),  accompanied  by  a  significant  uptake  of  biofuels  (25%)  compared  to today's levels (3%), as well as a mixture of clean hydrogen and its derivatives providing around 21% of  the  fuel  mix;  fossil  fuels  would  provide  the  remaining  consumption  (around  5%).  At  the  same time, with increased environmental awareness and the long-term impacts of the pandemic, a smaller increase in transport demand is projected compared to the Planned Energy Scenario, especially in the aviation sector.

<!-- image -->

## BOX A.1     Status of battery technology

Battery storage is a key building block of the transformation towards net zero emission energy systems. Inexpensive, mass-produced batteries will enable cost-effective decarbonisation of the road transport sector - which today accounts for about a fifth of global energy-related CO 2 emissions. Furthermore, batteries can store cheap, carbon-neutral solar and wind generation, contributing to the safe, reliable operation of power systems with very high shares of renewables. Batteries can also support a wider range of services in the power sector, including frequency response, reserve capacity and black-start capability, among others (IRENA, 2017).

Battery  technology  has  experienced  impressive  progress  over  the  last  decade,  with  costs declining around 90%. The cost of lithium-ion battery packs, typically used in electric vehicles, exceeded USD 1 100/kilowatt hour (kWh) in 2010 but has fallen to USD 137/kWh in 2020 (BNEF, 2020). If current trends continue, average costs could soon break the USD 100/kWh mark, a figure often cited as the threshold for light-duty road vehicles to reach up-front cost parity with internal  combustion vehicles.  By  2030,  battery  pack  prices  could  reach  USD  61/kWh  (BNEF, 2021), further improving the cost competitiveness of electric vehicles.

At  the  same  time,  the  global  battery  production  capacity  is  growing  exponentially.  Battery production capacity for electric vehicles reached 180 gigawatt hours (GWh) per year in 2020, and the pipeline for large battery factories (&gt;1 GWh capacity) now includes 181 plants with a planned capacity of 3 terawatt hours per year by 2030 (Moores, 2021). Such capacity would enable the production of 48 million light-duty vehicles annually, more than half of the global market in recent years.*

Existing battery technology is quickly reaching commercial maturity to enable decarbonisation of some energy services, for example, road transport, short-term power storage and ancillary services.  Long-duration  power  storage  (tens  to  hundreds  of  hours),  aviation  and  maritime shipping are candidates to benefit from improved battery technology in the future. Each of these applications requires batteries that are optimised for their specific needs (Trahey et al. , 2019).

For example, regional commercial flights of up to 600 nautical miles could be enabled if batteries reached an energy density of 800 Wh/kg (Schäfer et al. , 2019) (about three to four times higher than today's technology). Batteries for aviation need to deliver large amounts of power output to  enable  safe  take-off  and  landing  operations;  they  also  need  to  charge  rapidly  to  enable short turn-around times for airlines and to operate under very stringent reliability and safety standards. Further research and development is needed to expand the scope of battery use in the energy transformation and to unleash their full decarbonisation potential.

- *   Assuming 80% of the production is dedicated to light-duty electric vehicles, and an average battery pack size of 50 kWh.

## A.1.3 Opportunities for investors

To achieve the transformation envisioned in the transport sector, at least USD 11 trillion will need to  be  invested  in  the  sector  by  2050.  The  bulk  of  investments  are  needed  in  energy  efficiency improvements for all transport modes (42% or USD 157 billion annually) and in charging infrastructure for electric vehicles (35% or USD 131 billion annually). Additional investments will be needed in supply chain expansion for electric vehicles and battery factories. The implications for mining and mineral supply  chains  require  attention  as  well.  Although  the  mining  investment  will  be  limited  to  those countries that have the natural resources, the need for these resources is global and growing. With the increasing use of biofuels, as well as hydrogen and its derivatives, additional investments will be needed for the expansion of production facilities, batteries, electrolysers and logistics. (For an indepth discussion of the investment required, see Section A.2.2.)

## A.1.4 Carbon dioxide emissions

As  a  result  of  a  massive  transition  in  the  transport  sector,  as  outlined  in  the  1.5°C  Scenario, the sector's annual emissions will be reduced from 8.2 GtCO  in 2018 to 6.5 GtCO  by 2030 and 2 2 0.4  GtCO   by  2050.  Electrification  measures  will  be  responsible  for  41%  of  total  CO   reductions 2 2 in  the  sector,  followed  by  energy  efficiency  improvements  contributing  27%,  hydrogen  and  its derivative fuels contributing 26%, and biofuels and biogas contributing the remainder.

## FIGURE A.2     Emission reductions in transport in 2050

<!-- image -->

<!-- image -->

## INDUSTRY A.2

The industrial production of key materials is an essential enabler of modern economies. As  countries  develop,  demand  for  such  material  continues  to  grow.  However,  many production processes are carbon intensive, making industry responsible for 12 GtCO 2 per year in 2018, around a third of human-induced CO  emissions (excluding land-use 2 emissions). Of this 12 Gt, energy use accounts for 10 Gt annually and the remaining 2 Gt is process-related emissions, which can be particularly difficult to address. In general, decarbonising industry is challenging due to the complexity of the processes involved, a relative lack of economically viable technical solutions for reducing CO  emissions and 2 the importance of competitive industries to national economies.

Among  industrial  sectors,  iron  and  steel,  cement,  chemicals  and  petrochemicals contribute the largest share of emissions (around 70%), and the major economic blocs of China, the United States and the European Union account for a large share of overall industrial production. The initial focus of efforts to reduce emissions in industry should therefore be concentrated on these sectors and countries.

Reaching zero emissions across the industrial sectors will require radical shifts in how materials are produced, consumed and disposed.

IRENA's  1.5°C  Scenario  proposes  a  portfolio  of  clean  energy  technologies  and  strategies  to decarbonise industry, built on five pillars:

- 1 Reduced demand and improved energy and materials efficiency. Along with circular economy practices and structural changes, this would lead to substantial reductions in industrial energy consumption by 2050.
- 2 Direct use of clean electricity produced predominantly from renewable sources. The direct electrification share in industry would rise from 28% in 2018 to 35% by 2050. For low-temperature industrial heat needs, heat pump installations would increase to 80 million by 2050.
- 3 Direct use of renewable heat and biomass - including solar thermal, geothermal, biofuels and bioenergy  feedstocks.  For  medium-  and  high-temperature  heat  requirements,  as  well  as  for chemical feedstocks, biomass will play a significant role, requiring over 36 EJ of biomass by 2050, up from 8 EJ in 2018.
- 4    Indirect  use  of  clean  electricity via  synthetic  fuels  and  feedstocks,  predominantly  using renewable electricity. The use of hydrogen and synthetic fuels and feedstocks in industry would climb to over 38 EJ by 2050.
- 5 Use of carbon dioxide removal and carbon capture and storage measures -  including  bioenergy with  carbon  capture,  utilisation  and/or  storage  (BECCS).  Some  emissions,  particularly process emissions, cannot be addressed by other means, and the combination of biomass with CCS could deliver some negative emissions. In 2050, around 4.5 GtCO  would be captured by 2 BECCS and CCS in industry.

To achieve the complete decarbonisation of industry proposed under the 1.5°C Scenario, investment in  energy  transition  technologies  in  industry  would  have  to  increase  significantly,  amounting  to USD 14.5 trillion over the period to 2050 or on average USD 486 billion per year. As a result, the industrial  sector  would  see  significant  reductions  in  CO   emissions,  from  5.4  GtCO   in  2018  to 2 2 -1  GtCO   in  2050  ( 2 i.e. ,  net  negative).  Renewables  and  energy  efficiency  contribute  close  to  40% of  the  mitigation needs between the Planned Energy Scenario and the 1.5°C Scenario. Hydrogen and  electricity  supplied  mostly  by  renewable  power  sources  would  together  contribute  27%  of mitigation. CCS would capture one-fifth of the emissions, and the remaining mitigation effort would be provided by BECCS and other carbon removal measures.

<!-- image -->

## FIGURE A.3     Total energy consumption and CO  emissions in industry 2

<!-- image -->

Note:  The  figure  includes  energy  demand  for  non-energy  uses,  coke  oven,  blast  furnace,  chemicals  fuels  and feedstocks along with industry co-generation.

By 2050 the share of renewables in the industrial sector needs to grow six fold, to 66% from 11% in 2018. Electricity would make up around 26% of the sector's energy demand, followed by hydrogen providing 22% and 20% from bioenergy.

## A.2.1 Overview and trends

Modern economies are highly dependent on large-scale production of key materials such as metals, minerals,  chemicals  and  finished  goods,  produced  by  industries  around  the  world.  As  countries develop  and  become  wealthier,  demand  for  such  materials  continues  to  grow.  However,  this production currently comes with high CO  emissions. Industry accounts for around 28% of human2 induced CO2 emissions (excluding land-use emissions), or around 12 GtCO  in 2018 (of which 2 Gt 2 are  process related and the rest energy related). Among the industry sub-sectors, the top three emitters are iron and steel (contributing 28% of industry-related emissions), cement and lime (25%) and the chemical and petrochemical industries (17%), together representing 70% of industry-related emissions (IRENA, 2020a).

The majority of energy used in industry is currently sourced from fossil fuels and is concentrated in key countries and regions. In 2018, China was responsible for more than 30% of global energy consumption  in  industry,  followed  by  the  United  States  with  11%,  the  European  Union  with  9% and India with 7%. Only around 11% of all energy consumed in industry was renewable (including electricity and district heat) in 2018. Energy use is not the only source of emissions in the industrial sector; CO  emissions also must be eliminated from production processes (mainly cement and iron 2 and steel) and from the life cycle of products. Reducing emissions and eventually reaching zero will therefore require radical shifts in how materials are produced, consumed and disposed of.

To date, however, the need to drive long-term emission reductions in industry has not received the required policy attention in most countries. The United Kingdom, being a pioneer in announcing a 2050 net zero energy target, recently launched a detailed industrial decarbonisation strategy aligned with the net zero goal (Government of the United Kingdom, 2019). A few other industrial economies are  exploring  options.  However,  on  a  global  scale,  relatively  less  attention  has  been  devoted  to decarbonising the industry sector. A number of reasons account for this lack of action, but two in particular are key. First, only a few economically viable CO  emission reduction technical solutions 2 are currently available for these industrial sectors, and until recently little consensus existed on which options are most suitable. Second, concerns about competitiveness and the risks of carbon leakage - that is, the transfer of production to other locations where emission reduction requirements are lower - is a deterrent in promoting national decarbonising efforts (IRENA, 2020a).

<!-- image -->

T

R

A

N

S

I

T

O

N

S

O

U

T

L

O

K

## TABLE A.3a     Industry: Indicators of progress - status in 2018 and targets for 2030 and 2050

| Energy transition strategy and components   | Energy transition strategy and components                                   | Energy transition strategy and components   | Energy transition strategy and components   | Energy transition strategy and components   | Energy transition strategy and components                                                                                                                                                                                                                                                                                                                                                                                                                                  | Energy transition strategy and components   |
|---------------------------------------------|-----------------------------------------------------------------------------|---------------------------------------------|---------------------------------------------|---------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------|
| ENERGY CONSERVATION AND EFFICIENCY          | Industry - TFEC (EJ)                                                        | 157 EJ                                      | 172 EJ                                      | 177 EJ                                      | • Keep a strong focus on energy efficiency by making processes ever more efficient and by setting or mandating minimum standards on energy efficiency and/or on the carbon intensity of fuels, processes and products. • Promote circular economy practices (material recycling, waste management, improvements in materials efficiency and structural changes such as reuse and recycling). • Incentivise and adopt best available technologies and efficiency standards. |                                             |
| ELECTRIFICATION IN END-USE SECTORS (DIRECT) | Share of electricity in TFEC (%)                                            | 21 %                                        | 22 %                                        | 26 %                                        | • Promote low-carbon electricity-based heating solutions such as heat pumps and electric boilers.                                                                                                                                                                                                                                                                                                                                                                          |                                             |
| ELECTRIFICATION IN END-USE SECTORS (DIRECT) | Heat pumps (million units)                                                  | 0 million                                   | 35 million                                  | 80 million                                  | • Promote low-carbon electricity-based heating solutions such as heat pumps and electric boilers.                                                                                                                                                                                                                                                                                                                                                                          |                                             |
| RENEWABLES (DIRECT USES)                    | Biomass heat (including combined heat and power (CHP) and feed- stocks (EJ) | 8.1 EJ                                      | 25 EJ                                       | 36 EJ                                       | • Develop sustainable bioenergy supply chains to meet the growing need for bioenergy in industry to supply heat demand, especially high-temperature heat. • Refine technologies and processes for the conversion of industrial plants to biomass-based heat.                                                                                                                                                                                                               |                                             |
| RENEWABLES (DIRECT USES)                    | Solar thermal consumption (GW th )                                          | 4 TWh/yr                                    | 890 TWh/yr                                  | 1291 TWh/yr                                 | • Promote awareness of the advantages of solar thermal and create incentives for project developers that can disseminate the technology, especially for low- and medium-temperature applications.                                                                                                                                                                                                                                                                          |                                             |
| RENEWABLES (DIRECT USES)                    | Solar thermal - flat plate, evacuated tube (million m 2 )                   | 5 million m 2                               | 1272 million m 2                            | 1844 million m 2                            | • Promote awareness of the advantages of solar thermal and create incentives for project developers that can disseminate the technology, especially for low- and medium-temperature applications.                                                                                                                                                                                                                                                                          |                                             |

<!-- image -->

- a.    The dataset in the table includes energy demand for non-energy uses , coke oven, blast furnace, chemicals fuels and feedstocks along with industry co-generation.

<!-- image -->

| Energy transition            | Indicators                                                                                                     | Historical               | Where we need to be    | Where we need to be     | Implications/Key actions                                                                                                                                                                                                                              |
|------------------------------|----------------------------------------------------------------------------------------------------------------|--------------------------|------------------------|-------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| component                    | Unit                                                                                                           | 2018                     | 2030 (1.5°C Scenario)  | 2050                    |                                                                                                                                                                                                                                                       |
| HYDROGEN AND ITS DERIVATIVES | Clean hydrogen consumption (EJ)                                                                                | 0 EJ                     | 16 EJ                  | 38 EJ                   | • Pilot at scale, and in multiple contexts, the use of renewably produced hydrogen to replace fossil fuel-based feedstocks and process heat (e.g., in iron and steel, methanol and ammonia production). • Incentivise demand for low-carbon products. |
| CCS                          | CCS - CO 2 captured (GtCO 2 /yr)                                                                               | 0.01 GtCO 2 captured/yr  | 1.1 GtCO 2 captured/yr | 2.3 GtCO 2 captured/yr  | • Pilot at scale the selective use of CCS, mainly to capture process emissions in energy-intensive industries.                                                                                                                                        |
| BECCS AND OTHERS             | BECCS - CO 2 captured (GtCO 2 /yr)                                                                             | 0.002 GtCO 2 captured/yr | 0.6 GtCO 2 captured/yr | 1.14 GtCO 2 captured/yr | • Pilot at scale the use of BECCS in key sub-sectors such as cement and chemicals in order to offset remaining uncaptured emissions (e.g., from clinker production).                                                                                  |
| Renewables share             | Renewables share                                                                                               | Renewables share         | Renewables share       | Renewables share        | Renewables share                                                                                                                                                                                                                                      |
| RENEWABLES a                 | Renewable energy share (including electricity and district heating) (%)                                        | 11 %                     | 40 %                   | 66 %                    | • Maintain a strong focus on strategies to accelerate energy efficiency improvements, clean hydrogen use and direct renewables use such as biomass and solar thermal.                                                                                 |
| CO 2 emissions               | CO 2 emissions                                                                                                 | CO 2 emissions           | CO 2 emissions         | CO 2 emissions          | CO 2 emissions                                                                                                                                                                                                                                        |
| CO 2 EMISSIONS               | CO 2 emissions with carbon capture and removal b (GtCO 2 /yr)                                                  | 6.1 GtCO 2 / yr          | 4.7 GtCO 2 / yr        | -1 GtCO 2 / yr          | Implement an appropriate carbon pricing mechanism in line with the real costs of the externalities and eliminate any remaining subsidies or incentives for the use of carbon-intensive fuels.                                                         |
| ENERGY- INTENSIVE INDUSTRIES | Iron and steel; cement; and chemical and petrochemical - share of industry gross emissions (excl. CCS/CDR) (%) | 70 %                     | 83 %                   | 98 %                    | • Develop a shared vision and strategy and co-develop practical roadmaps involving all major players. • Collaborate across borders to share knowledge and build capacity. Support research, development and deployment, and systemic innovation.      |

- b.    Emissions represent net CO  emissions including CO  removal using CCS, CCU and BECCS along with the life cycle 2 2 of petrochemicals.

Note: TFEC = total final energy consumption.

<!-- image -->

## TABLE A.3b     Industry: Energy transition investments

<!-- image -->

| Industry total billion/   | 2017-2019          | 2021-2050 (1.5°C Scenario)   |
|---------------------------|--------------------|------------------------------|
| ENERGY EFFICIENCY         | 45 USDbillion/year | 354 USDbillion/year          |
| RENEWABLES (DIRECT USES)  | 32 USDbillion/year | 45 USDbillion/year           |
| HEAT PUMPS                | 2 USDbillion/year  | 24 USDbillion/year           |
| CCS AND BECCS             |                    | 38 USDbillion/year           |
| CIRCULAR ECONOMY          |                    | 25 USDbillion/year           |

Note: Investments in hydrogen electrolysers, chemicals feedstocks and renewable power capacity are not included in this table.

## A.2.2 Transitioning towards decarbonisation

The majority of emission reductions will be achieved through a combination of six emission reduction measures, three of which rely primarily on renewable energy (IRENA, 2020a):

- · Reduced demand and improved energy and materials efficiency. This involves reducing energy and material demand and intensity of use through a range of actions, including energy efficiency, behavioural and process changes, relocation and the application of circular economy principles. For  instance,  greater  efficiency  in  materials  use  could  reduce  the  demand  for  new  materials production,  even  as  interesting  opportunities  exist  for  product  reuse  and  materials  recycling. Efforts to deploy low-carbon technologies need to be complemented with strategies and options to improve material efficiency and create a circular economy.

However, not all options are within the boundaries of the industry sector. An important effort will be required in the waste management sector, especially related to steel products and plastics. This is essential to increase recovery rates of materials from products that have reached their end  of  life,  to  ensure  cost-effective  and  efficient  logistics,  to  develop  cost-effective  recycling technologies  and  to  develop  the  global  infrastructure  to  circulate  these  materials.  Structural changes will have impacts throughout the product life cycle. The material flows across sectors will  be  affected by emission reduction efforts elsewhere in the economy, such as the reduced availability of blast furnace slag and fly ash for cement production, which will require new material solutions to be developed (Gielen and Saygin, 2018).

- · Direct  use  of  clean  electricity,  produced  predominantly  from  renewable  sources. Directly using  clean  electricity  (sourced  mainly  from  renewables)  to  provide  energy  requirements  can both replace existing fossil-fuel-based electricity use and replace other energy demand through 'electrification'.  Electricity  demand  is  expected  to  continue  to  grow  in  the  manufacturing industry, due in part to an electrification of production processes but also to production growth in electricity-intensive industries, such as the non-ferrous metals sector. As renewables' share in power generation grows, this increases their share in industry. Locating such industries close to renewable power plants is one option that would increase the share of renewable energy in the electricity sector.

Already  many  electricity-intensive  industries  such  as  aluminium  smelters  are  linked  with generation assets that offer cheap electricity from hydropower, and this is likely to increase in the coming years. Several large manufacturing companies are integrating renewable energy power generation into their existing manufacturing plants through either solar photovoltaic (PV) panels on  production  facilities,  wind  turbines  on  site  or  other  sources  of  renewable  energy.  Process technology  research  and  development  should  also  focus  on  electricity-based  alternatives, ensuring  that  the  electricity  sector  is  decarbonised.  An  interesting  trend  is  direct  corporate sourcing of renewable power. These and other trends are opening up possibilities for industry and transport that make zero emissions an achievable objective.

- · Direct use of renewable heat and biomass - including solar thermal, geothermal, biofuels and bioenergy feedstocks. This involves directly utilising renewables for energy and feedstocks, including the use of solar and geothermal for some heat requirements and the use of sustainable biomass (including  through  the  direct  use  of  bioenergy)  for  heat  and  for  the  production  and use of biofuels and bioenergy feedstocks. Industry's use of solar thermal heat will rise steeply and provide 5% of the sector's heat demand. Current direct renewable energy use in industry is predominantly in the form of biofuels and waste. This is mainly due to by-products and waste use, such as bagasse and rice husk in sugar production and other traditional industries; biogas from sewage and farms for food processing and black liquor in the pulp and paper sector.

The versatility of biomass also results in competitive uses within and between the industry sector and  other  sectors  of  the  economy.  Realising  cost-effective  and  sustainable  biomass  potential depends on a number of factors, including local feedstock cost and availability as well as biomass logistics. In addition to biomass, solar heating and geothermal could substitute fossil fuel use. Today only certain applications of renewable energy are cost-effective, such as low-temperature process heat generation with solar water heaters and steam production from low-cost biomass residues. Breweries, dairy industries and textile processing industries are typical settings where these technologies are applied.

mportant  economic,  technical  and  logistical  barriers  remain.  Yet  in  the  near  future  and  with I proper  policy  frameworks  in  place,  renewable  energy  technologies  can  provide  practical  and cost-effective alternatives for process heat generation and as a renewable carbon source for the production of chemicals and plastics (Saygin, D. and Gielen, D., 2021). Meanwhile, for mediumand  high-temperature  processes,  bioenergy  would  remain  critical.  As  such,  bioenergy  would constitute 20% of final energy consumption in 2050.

<!-- image -->

- · ndirect  use  of  clean  electricity  via  synthetic  fuels  and  feedstocks,  predominantly  using I renewable electricity. This involves sourcing energy and feedstocks from hydrogen or from fuels or feedstocks produced from hydrogen (synthetic fuels or feedstocks) using CO  captured from 2 non-fossil-fuel sources. The hydrogen should be 'clean' and preferably 'green' ( i.e. , sourced from renewables). Hydrogen would also play an important role in the sector: its use grows to over 38 EJ by 2050 (two-thirds derived from renewables) in IRENA's 1.5°C Scenario, driven by declining costs (IRENA, 2020b).
- · Carbon  capture,  utilisation  and/or  storage  (CCUS/CCS). This involves capturing most CO2  emissions  from  remaining  fossil-fuel-based  energy  production  that  cannot  be  credibly substituted with renewables or other processes and either storing the captured CO  permanently 2 or utilising the CO  in ways in which it will not be later released. Especially for industries with 2 high process emissions such as cement clinker production, this option could play an important role. While renewables and energy efficiency could make a significant contribution to industrial emission reductions, their joint potential is not enough to fully decarbonise the industry sector. CCS will need to be deployed for some manufacturing of iron, ammonia, cement clinker and some chemicals.
- · Biomass coupled with carbon capture and storage BECCS and other carbon removal measures. Additional effort will be needed to offset emissions using carbon dioxide removal technologies. These include the use of biomass in combination with CCS (BECCS), and other uses of biomass such as biomass carbon use (with proper accounting for its storage in synthetic organic materials), wood materials' use for construction (with accounting for its carbon storage effects), as well as carbonation of concrete and direct air carbon capture and storage (DACCS). These technologies are not currently deployed at any significant scale; if they are to have a meaningful impact, efforts must be ramped up quickly in the coming decades.

## A.2.3 Opportunities for investors

The  industrial  sector's  technology  portfolio,  as  outlined  in  IRENA's  1.5°C  Scenario,  requires increasing investments in the order of USD 14.6 trillion between 2021 and 2050 (or, on average, USD  486  billion  per  year  to  2050).  More  than  75%  of  this  total  investment  would  be  needed for  improving energy efficiency levels and circular economy practices. Around 14% of the total investments  would  be  needed  for  deploying  renewables  for  direct  use  and  heat  pumps.  The remaining 8% of the investments are attributed to coupling CCS and BECCS units.

A strategic move could be investing in energy-intensive industries in countries with good resources and large shares of renewables. For example, this could mean coupling iron ore mining and green ironmaking  in  places  with  abundant  and  low-cost  renewable  resources,  such  as  Australia,  to create  new  value  and  supply  chains  while  also  delivering  emission  reductions.  A  shift  from  the use of the blast furnace-basic oxygen furnace to the green hydrogen direct reduced iron-electric arc furnace could enable a wider relocation of the sector to places where relatively low-cost and abundant renewable electricity sources are available. The prospect of wider relocation could trigger the  creation  of  markets  for  greener  steel,  provided  there  is  adequate  infrastructure  in  place  for transporting hydrogen along with proper trade agreements and finance flows.

Decarbonising the industry sector requires concerted actions by all countries. Yet the actions of a few key countries and regions are particularly critical. Major economies such as China, the United States, India, the European Union and the United Kingdom currently account for two-thirds of global emissions and more than two-thirds of global industrial emissions. Actions and initiatives in these major economies and economic blocs will determine whether the world's industrial processes can get on a pathway consistent with 1.5°C climate targets.

For example, in China, the world's largest producer of a range of energy-intensive commodities, the energy consumption of the industry sector accounts for 60% of gross final energy use in industry (for both energy and non-energy use), with a proportional share of emissions. However, emission reduction in the industry sector has received relatively little policy attention to date. Decarbonising China's energy-intensive industries is important not just in a national context, but also as a key enabler of the decarbonisation of the global industrial sector. Strategies for decarbonising energy-intensive industries in China include exploring the targeted use of CCS for cement kilns and outsourcing some of the energy-intensive industry activities, for example, through imports of hydrogen direct reduced iron, green ammonia or renewable methanol (Gielen, Chen and Durrant, 2021).

After China, India is the world's second-largest producer of a range of energy-intensive commodities and uses coal as a dominant fuel. Industrial activities in the country are expected to surge in the coming decades driven  by  rapid  urbanisation,  economic  growth  and  ongoing  initiatives  such  as 'Make in India' and 'Atma Nirbhar Bharat'. Such advancements have significant implications for India's emission trajectory and provide a unique opportunity for the country to evolve sustainably and establish itself as a 'global green manufacturing hub'. Decarbonisation strategies for India's industrial sector could include: setting short- and long-term targets and goals as part of the country's updated Nationally Determined Contributions; planning and approving new greenfield projects with the  best  available  technologies  (supported  by  high  energy  efficiency  standards),  including  clean energy  fuels  (renewables,  clean  electricity);  promoting  circular  economy  practices;  deploying alternative fuels such as green hydrogen ( e.g. , for green steel and for chemical/fertiliser production) and scaling up energy transition investments (Deore, Kukreja and Koti, 2021).

## A.2.4 Carbon dioxide emissions

Industry is the second-largest emitter of energy-related CO , after the power sector, and is responsible 2 for  just  under  one-third  of  these  emissions  worldwide  (when  including  process  emissions).  The 1.5°C Scenario outlines a pathway to deliver more than 100% reductions of the sector's emissions by  2050.  Renewables,  energy  efficiency,  electrification  and  hydrogen  contribute  to  almost  twothirds of the mitigation needs between the Planned Energy Scenario and the 1.5°C Scenario. The remaining  emission  reductions  would  be  contributed  by  CCS  (20%)  and  BECCS  and  other  CO 2 removal measures.

<!-- image -->

## FIGURE A.4     Emission reductions in industry in 2050

<!-- image -->

Renewables and energy efficiency would contribute 39% of total mitigation needs in 2050, while hydrogen and electricity combined contribute 27%.

Relatively few of the technical options identified, however, are commercially mature or ready for wide adoption. Uncertainties remain about their potential and optimum use, and none will be easy to scale up. The reasons are varied and complex. They include: high costs for new technologies and processes;  the  need  for  enabling  infrastructure  ahead  of  demand;  highly  integrated  operations and  long-established  practices;  uneven,  large  and  long-term  investment  needs;  gaps  in  carbon accounting  and  business  risks  for  first-movers,  including  added  costs  and  consequent  'carbon leakage'  in  favour  of  competitors.  This  calls  for  inter-linked  sector-level  strategies  at  the  local, national and international levels, built on the five technology pillars of demand reduction and energy efficiency,  renewable  electricity,  renewable  heat  and  biofuels,  green  hydrogen  and  e-fuels,  and carbon-removal technologies.

## BUILDINGS A.3

The ways that we live and work in our built environment will be transformed over the next decades under the 1.5°C Scenario. Our buildings will increasingly be smart, inter-connected, highly energy efficient and powered and heated predominantly by renewable energy. This is not only necessary to meet global climate goals, but it also presents a strong business opportunity and could be a key driver in increasing employment and the quality of our air in urban areas.

An effective transition to reach zero emissions in the buildings sector entails multiple strategies:

- 1 Energy efficiency should take the top priority: all new buildings should be low-energy buildings starting in 2025 and zero-energy buildings beginning in 2030; meanwhile, for existing buildings the rate of renovation will need to triple. The buildings sector is a major user of manufactured products, and the nexus with efficient construction, alternative building materials, low-emission materials and better design - combined with circular economy principles in the construction and operation of buildings - will be key in helping to achieve emission reductions in other sectors, notably in industry.
- 2 Electricity will be the key energy carrier, with its share of final energy use in buildings increasing from 32% in 2018 to 56% by 2030 and 73% by 2050. Such a rise implies a doubling of electricity demand in the sector by 2050 compared to the 2018 level, driven by significant electrification of heat, growth in cooling demand and electric cooking. In addition, heat pumps are a key and efficient technology and will grow eight fold by 2050.
- 3 There remains an important role for direct use of renewables such as biofuels and biomethane and  solar  thermal  for  heating,  cooking  and,  along  with  clean  hydrogen,  for  greening  the  gas system. The number of solar thermal systems will grow more than four fold from 2018. Greening the gas grid will be important for areas that have existing gas supply infrastructure; a mix of clean hydrogen and biogas represent around 8% of heating demand by 2050. Finally, traditional uses of bioenergy (representing around one-quarter of energy demand in 2018, much of it unsustainably sourced  and  inefficiently  used)  will  be  replaced  with  a  combination  of  modern  biomass  cook stoves, biogas and electric stoves.

In total, this transformation will see the modern renewable energy share in the buildings sector rise from 15% in 2018 (or 40% if including traditional uses of bioenergy) to 78% in 2030 and 92% in 2050. To achieve this radical transition, USD 1.1 trillion per year will need to be invested in the sector in the period to 2050. Of this total, building retrofits, smart home and energy efficiency investments make up the bulk of the investment needs at over USD 960 billion per year. Reaching this level of

## WORLD ENERGY

## TRANSITIONS OUTLOOK

investment will be challenging, since most benefits are felt only in the long term. Thus, new financing schemes and tax regimes are required to incentivise investments.

Direct  CO   emissions  in  the  buildings  sector  accounted  for  9%  (3  Gt)  of  total  energy-related 2 CO2 emissions in 2018. The result of this energy transition in the sector is that by 2050, direct CO 2 emissions in the sector would reach zero. The key components that would mitigate almost 2.3 GtCO 2 when comparing the Planned Energy Scenario to the 1.5 °C Scenario are electrification (46%), energy efficiency improvements (38%), direct use of renewables (15%) and hydrogen for the remainder.

## FIGURE A.5     Total final energy consumption and CO  emissions in buildings 2

<!-- image -->

- Hydrogen
- Other (non-RE)
- District heat
- Electricity
- Geothermal
- Solar thermal
- Modern biomass (biogas/liquid)
- Modern biomass (solid)
- Traditional biomass
- Gas
- Oil
- Coal
- CO2 emissions (net)
- Renewable energy RE

By 2050 the share of renewables in buildings would ramp up to 89%, from 34% in 2018. Despite an additional 1 billion new households by 2050, overall energy consumption in buildings in 2050 would decline 14% compared to 2018.

## A.3.1 Overview and trends

The  buildings  sector  includes  residential,  commercial  and  public  buildings.  In  2018,  buildings consumed 122 EJ (around one-third of total final energy consumption), with 30% for heating, 24% for cooking, 20% for water heating, 18% for lighting and other appliances and 8% for cooling. An important caveat of the building sector's energy demand is that in some parts of the world ( e.g. , Africa) the sector is dominated by traditional uses of bioenergy, largely for cooking. This form of consumption makes up around one-quarter of energy demand in the sector globally. Direct use of fuels for heating is currently the largest consumer of energy in the sector, with more than two-thirds coming from fossil fuels, mainly natural gas.

Direct CO  emissions in the buildings sector account for 9% (3 Gt) of total energy-related CO 2 2 emissions. However, when including the emissions associated with electricity supply to the sector, the share of energy-related emissions applicable to building energy consumption rises to around 30%. Renewables make up a large share of energy demand in buildings, at around 40% in 2018. However, the largest component of that renewable energy consumption is met by traditional uses of bioenergy for cooking and heat. When traditional uses are excluded, the modern renewable energy share in buildings is much lower, around 15%. Modern forms of biomass still represent an important energy source in some countries, providing around 15% of heating demand (around 4 EJ). Overall, the sector has the largest share of electricity consumption at around one-third, with bioenergy (both traditional and modern) and natural gas each supplying around one-quarter of energy supply, and the remainder roughly half oil and half other sources.

Driven  by  population  growth  and  rising  gross  domestic  product,  the  total  floor  area  in  the sector is expected to increase 80% over the next 30 years. This is the equivalent of adding the entire residential building floor area of Germany every year (around 4 billion square metres [m 2 ]) for the next 30 years. Most of this growth will occur in developing and emerging economies. The sector is becoming more efficient with energy demand growing slower relative to new floor area added, compared to the past. This lower relative growth of energy demand is the result of a few key drivers: reduced traditional uses of bioenergy (which results in significant energy efficiency increases, and therefore energy savings); higher levels of building and appliance efficiency; a shift to electricity for energy services (which is more efficient) and greater adoption of other renewable sources.

<!-- image -->

T

R

A

N

S

I

T

O

N

S

O

U

T

L

O

K

## TABLE A.4a     Buildings: Indicators of progress - status in 2018 and targets for 2030 and 2050

<!-- image -->

<!-- image -->

| Energy transition            | Indicators                                              | Historical     | Where we need to be   | Where we need to be   | Implications/Key actions                                                                                                                                                  |                |
|------------------------------|---------------------------------------------------------|----------------|-----------------------|-----------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------|
| component                    | Unit                                                    | 2018           | 2030 (1.5°C Scenario) | 2050                  |                                                                                                                                                                           |                |
| RENEWABLES (DIRECT USES)     | Biomass (incl. traditional) (EJ)                        | 29 EJ          | 8.3 EJ                | 9.5 EJ                | • Phase out traditional uses of biomass and replace them with efficient and clean cook stoves.                                                                            |                |
|                              | Solar thermal and geothermal consumption - heating (EJ) | 1.8 EJ         | 2.3 EJ                | 6.2 EJ                | • Promote renewable-based heating solutions (e.g., solar thermal).                                                                                                        |                |
|                              | RE based district heat generation (EJ)                  | 0.4 EJ         | 4.2 EJ                | 7.3 EJ                | • Promote renewable-based heating solutions (e.g., modern biomass and heat pumps).                                                                                        |                |
| RENEWABLES (POWER)           | Distributed storage (batteries) (GJ)                    | 3.3 GW         | 99 GW                 | 2200 GW               | • Promote deployment of distributed energy resources and improve regulations for 'prosumers'. • Capitalise on smart homes and digitalisation to enable demand management. |                |
| HYDROGEN AND ITS DERIVATIVES | Clean hydrogen- consumption (EJ)                        | 0.0 EJ         | 2 EJ                  | 3.2 EJ                | • Do not expand gas infrastructure, but for some existing systems prepare them for green gas.                                                                             |                |
| CO 2 emissions               | CO 2 emissions                                          | CO 2 emissions | CO 2 emissions        | CO 2 emissions        | CO 2 emissions                                                                                                                                                            | CO 2 emissions |
| CO 2 EMISSIONS               | Direct (GtCO 2 /yr)                                     | 2.9 GtCO 2 /yr | 1.2 GtCO 2 /yr        | 0.0 GtCO 2 /yr        | • Mandate all new construction to be low-energy beginning by 2025 and zero-energy from 2030 onwards.                                                                      |                |

Note: *Estimated assuming unit capacity of 20 kW/unit.

<!-- image -->

TABLE A.4b     Buildings: Energy transition investments

<!-- image -->

|                                     | 2017-2019           | 2021-2050 (1.5°C Scenario)   |
|-------------------------------------|---------------------|------------------------------|
| Buildings total (USD billion/ year) | 151 USDbillion/year | 1089 USDbillion/year         |
| ENERGY EFFICIENCY                   | 139 USDbillion/year | 963 USDbillion/year          |
| RENEWABLES (DIRECT USES)            | 7 USDbillion/year   | 32 USDbillion/year           |
| SMART METERS                        |                     | 22 USDbillion/year           |
| HEAT PUMPS                          | 2 USDbillion/year   | 72 USDbillion/year           |

## A.3.2 Transitioning towards decarbonisation

Buildings  will  be  central  to  the  energy  transition  by  offering  opportunities  for  energy  efficiency improvements, being a site for energy production through distributed energy resources, providing energy storage to the power system (both with batteries and with electric vehicles) and by allowing better grid management through electricity demand response. To realise such a transition, several different energy transition strategies need to be pursued in parallel:

- · Energy efficiency is key to enable the 1.5°C Scenario. The energy intensity of the buildings sector, which measures the amount of energy consumed in the sector based on floor area, will decline  by  half  by  2050.  This  is  driven  by  the  requirement  that  all  new  building  construction will  need  to  be  low  energy  starting  in  2025  and  zero  energy  beginning  in  2030.  Meanwhile, for existing buildings the rate of renovation will need to triple, to 3% of the building stock per year - a significant increase over the historical average of just around 1% per year. Space heating energy demand decreases by about half in the 1.5°C Scenario, driven by improved efficiency and significant adoption of forms of electric heat such as heat pumps. In Europe, which has some of the world's most stringent building requirements and numerous renovation programmes, around 75% of the existing building stock is still not energy efficient. In this context, an initiative called the 'renovation wave' aimed at accelerating the rate of renovation as part of the European Green Deal was introduced in 2020 (EC, 2020).

- · Electrification will continue to play a critical role in the buildings sector. Electricity is already the single-largest energy carrier in the sector, making up 32% in 2018, and this share will rise to 73% in 2050 in the 1.5°C Scenario. This is equivalent to 21 300 terawatt hours by 2050, a doubling of electricity demand in the sector. Driving this increase is not just the wider adoption of electric appliances, but significant electrification of heat, growth in cooling demand and electric cooking.
- · n  a  future  renewable  energy  system,  power-to-heat  will  shape  a  significant  portion  of  the I heating sector. Heat pumps achieve rates of energy efficiency two to five times higher than fossilfuelled boilers and can be powered by renewable electricity. Under the 1.5°C Scenario, heat pumps will play a critical role, as their number increases from around 38 million in 2018 to around 290 million by 2050. This implies the need for 8.5 million new units to be installed every year for next three decades.
- · Electricity  demand  for  appliances  and  lighting  will  increase  40%  by  2050  in  the  1.5°C Scenario. Growth  is  slowed  due  to  higher  appliance  efficiency  and  includes  widespread  use of smart home systems with advanced controls for lighting and better appliance management (and separately for heating and cooling). Buildings would also be an important source of load management and flexibility to the grids, with load shifting enabled by widespread use of smart home appliances and smart meters (of which more than 2 billion are installed by 2050). Meanwhile, stationary storage will increase from just 3 GW today to over 2 200 GW by 2050, often built-in combination with distributed energy supply such as solar PV.
- · Heating water with electricity needs to become even more common. Electric water heating consumes around 3 EJ of electricity today and is a trend that is accelerating, in particular for systems  that  provide  instantaneous,  or  tankless,  hot  water  or  systems  that  use  heat  pump water heaters. Electric resistance water heating can play a limited yet important role in specific applications where alternatives, notably heat pump water heaters, are not available. In the 1.5°C Scenario electricity use for water heating is accelerated, rising 3.5 times. This shift is achieved by the ease of installation when switching from a fuel-based boiler to an electric boiler.

The direct use of renewables in buildings would grow substantially.

- · Solar  thermal  systems  would  see  significant  growth  and  play  an  important  role  in  some regions. Small-scale  solar  systems  are  in  wide  use  for  domestic  hot  water  and  for  heating buildings in temperate climates, and for some other limited applications requiring temperatures of less than 100°C 1  (Pauschinger, 2016). Large-scale systems are especially suited for integration with district heating networks due to economies of scale. For example, a centralised 15 megawatt solar district heating plant inaugurated in 2019 in Salaspils, Latvia, will meet about 20% of the annual heat demand from the system, with the rest being supplied by a 3 megawatt biomass boiler;  a  smaller-scale  example  consists  of  the  600  m   roof-mounted  solar  collectors  at  Wits 2 University  Junction  residence  in  Johannesburg,  South  Africa  (IRENA,  2020c).  In  2019,  around 690 million m 2 of solar thermal collector area was in place. In the 1.5°C Scenario solar thermal systems increase considerably, with collector area rising from 690 million m 2  to some 3 000 million m 2 . This is large growth, but solar thermal hot water systems are mature technologies that are reliable and cost-effective in places with higher solar irradiance. Even in areas with a less-than-ideal solar resource, these systems can be built and backed up by an electric boiler.
- 1 Solar thermal consists of capturing solar radiation to produce heat.

<!-- image -->

- · nefficient  heating  and  cooking  practices  must  be  replaced  with  clean,  efficient,  modern I systems. There are two primary ways of using modern biomass in the buildings sector: for space heating  and  for  cooking.  Buildings  can  be  heated  using  modern  biomass  through  town-scale district heating systems or building-scale furnaces, both of which use feedstocks such as wood chips and pellets very efficiently. Traditionally, biomass has been used for heating and cooking in  open fireplaces or stoves, and today modern biomass is being used in efficient boilers and furnaces and improved cook stoves. However, more than 2 billion people still rely on inefficient traditional  use  of  biomass,  such  as  fuelwood  and  charcoal,  for  cooking.  Inefficient  traditional cook stoves paired with solid fuels and kerosene emit indoor smoke that imperils the health of mainly women and children and causes nearly 4 million premature deaths every year. The largest share of biomass consumption in the buildings sector in 2017 was in Sub-Saharan Africa at 91% (entirely in the form of traditional uses).

These detrimental cooking practices must be replaced with clean, efficient, modern systems that use improved cook stoves fuelled with sustainably produced bioenergy such as wood, biogas or ethanol (IRENA, 2020d). Traditional uses of biomass in cooking must be phased out in the next decade and be replaced with modern fuels and improved and modern cook stoves. Cooking is significantly  transformed in the 1.5°C Energy Scenario, due in part to the complete phase-out of  traditional  uses  of  bioenergy.  Demand  is  further  reduced  to  10  EJ  by  2050,  a  result  of  this modern fuel switch but also significant and widespread electrification of cooking. Around 85% of cooking needs are met through electricity; the remainder is largely supplied via biomethane. The transformation will need to go hand in hand with enabling stable electricity access for the entire population.

- · Greening  the  gas  grid  will  be  necessary,  and  hydrogen  and  biomethane  will  play  the predominant role. The use of natural gas use for water and space heating in the buildings sector would decline to zero by 2050 due to widescale shift electrification, energy-saving renovations in old buildings and more energy-efficient new buildings, as well as hydrogen and biomethane taking over natural gas's role. For the latter, it is foreseen that this will be achieved by gradually increasing the levels of hydrogen and biomethane blended with natural gas and using the existing gas grid to deliver the green gases. Gas systems still remain and represent around 8% of sector energy and can be utilised if their gas is 'greened'.

For this, a combination of 70% biomethane and 30% zero-carbon hydrogen is deployed. Demand for district heat also rises 60%, as people become more urbanised. In Germany, the gas grid is undergoing a 10-year, EUR 7 billion (USD 7.8 billion) renovation to switch 30% of its customers from natural  gas  with  lower  methane  content  (L-gas)  to  gas  with  higher  methane  and  higher calorific  content  (H-gas).  This  is  due  to  the  decline  in  supplies  of  L-gas.  Although  this  seems like a minor shift compared to adding hydrogen into natural gas, it comes at a significant cost (IRENA, 2019).

Overall,  the  1.5°C  Scenario  sees  a  significant  change  in  the  buildings  sector.  Energy  demand  will decline around 14% to 105 EJ despite the growth in overall floor area. Several factors are attributed to this drop in demand: a large one is the phase-out of traditional uses of bioenergy, followed by significantly greater energy efficiency improvements reducing building sector energy intensity 50% from 2018 levels, and also electrification measures. The mix for energy services will also change, with 26% consumed for heating, 10% for cooking, 27% for lighting and other appliances, 21% for cooling and 17% for water heating - the largest increases are found in energy demand for cooling and appliances/lighting.

Space cooling demand increases the most of any energy service in buildings, with demand tripling. Due to increases in building envelope and cooling system efficiency, energy demand for cooling will still more than double by 2050, from 9 EJ to around 21 EJ by 2050. Overall, around 2.4 billion air conditioner units will be in operation by 2050, an increase from 0.9 billion today. District cooling grows to around 1 EJ by 2050, providing around 5% of cooling demand. Demand for district heat also rises 60%, as people become more urbanised. To supply this heat from carbon-free sources, several routes will need to be taken, from large electric boilers and electric heat pumps to municipal solid waste and bioenergy.

Coupling heating systems with thermal and seasonal storage offers important flexibility in demand in regions where winters are particularly harsh. For example, the Drake Landing Solar Community in Canada is using a long-term thermal energy storage system to store heat from solar collectors during summer to be used for space heating during winter. In coupling the power and thermal sector, Siemens-Gamesa is testing a thermal energy storage system that uses wind power to produce heat, which is stored in over 1 000 tonnes of rock. This system provides a thermal storage capacity of 130 megawatt hours of electric energy at rated charging temperatures of 750°C. IRENA estimates that around 234 gigawatt hours of thermal energy storage 2  is present across the globe, a crucial enabler of reliable, secure and flexible energy systems (IRENA, 2020c).

In the 1.5°C Scenario widespread innovation will be necessary. New technologies, materials, design and business models for net zero buildings' construction will be required. Smart energy management systems in buildings and digitalisation (the Internet of Things) will change how buildings consume energy and even allow them to start to provide grid services through enhanced demand flexibility. Increasingly,  the  sector  will  be  shifting  to  electric  vehicles,  meaning  that  charging  can  be  done at home. Decentralised energy supply will enable local generation of electricity through solar PV systems or other decentralised energy systems, and increasingly storage, both electric and thermal, will be found in buildings. To achieve this shift, enabling regulation and permitting will be required, as will reducing administrative and bureaucratic barriers. Utilities increasingly will need to reinvent themselves towards energy services and leverage the new markets related to the information from the grids.

- 2 The  IRENA  (2020c)  report  'Innovation  Outlook:  Thermal  Energy  Storage'  discusses  the  different  thermal energy storage technologies and user cases for heating and cooling systems, and projects the development and innovation needs for the next decades.

<!-- image -->

T

## A.3.2 Opportunities for investors

To achieve the transformation envisioned in the buildings sector, USD 34 trillion will need to be invested in the sector and related infrastructure and supply by 2050. The bulk of investments are needed in building retrofits, smart home and energy efficiency investments, amounting to just under USD 1 trillion on average invested per year, or USD 29 trillion over the period to 2050. Investments to  decarbonise  energy  supply  for  buildings  require  over  USD  100  billion  per  year,  or  around USD 4 trillion to 2050. Meanwhile, key enabling technologies such as storage and smart meters will require annual investments of around USD 40 billion per year, or USD 1.2 trillion in total to 2050.

## A.3.3 . Carbon dioxide emissions

As a result of massive transition in the buildings sector, as outlined in the 1.5°C Scenario, energyrelated CO  emissions decline 60% by 2030 and reach zero by 2050. 2 Direct CO  emissions in the 2 buildings sector account for 9% (3 Gt) of total energy-related CO  emissions in 2018. The result of 2 this energy transition is that by 2050, CO  emissions in the sector would reach zero. Electrification 2 measures would be responsible for 46% of total CO  reductions in the sector followed by energy 2 efficiency improvements contributing to 38%, direct use of renewables for 15% and hydrogen for the remainder.

## FIGURE A.6     Emission reductions in buildings in 2050

<!-- image -->

In buildings, the key solution is electrification contributing close to half of the CO  reduction 2 needed, followed by energy efficiency.

## References | Annex A

BNEF (2021), Electric Vehicle Outlook 2020 , BloombergNEF, London, https://about.bnef.com/ electric-vehicle-outlook.

BNEF (2020), 'Battery pack prices cited below $100/kWh for the first time in 2020, while market average sits at $137/kWh', BloombergNEF, https://about.bnef.com/blog/battery-pack-pricescited-below-100-kwh-for-the-first-time-in-2020-while-market-average-sits-at-137-kwh.

Clean Sky 2 JU and FCH 2 JU (2020), Hydrogen-powered aviation: A fact-based study of hydrogen technology, economics, and climate impact by 2050 , Clean Sky 2 Joint Undertaking and Fuel Cells and Hydrogen 2 JU, Brussels, www.fch.europa.eu/sites/default/files/FCH%20Docs/20200720\_ Hydrogen%20Powered%20Aviation%20report\_FINAL%20web.pdf.

Deore. M., R. Kukreja and PN. Koti (2021), 'OPINION: Why industrial decarbonization is an opportunity for India to fight climate change', Economic Times, https://energy.economictimes. indiatimes.com/news/power/opinion-why-industrial-decarbonization-is-an-opportunity-for-indiato-fight-climate-change/82052996.

EC (2020), 'Renovation wave', European Commission, https://ec.europa.eu/energy/topics/ energy-efficiency/energy-efficient-buildings/renovation-wave\_en.

Gielen D. and D. Saygin (2018), 'Global industrial carbon dioxide emissions mitigation: Investigation of the role of renewable energy and other technologies until 2060', Working paper, Payne Institute for Public Policy, Colorado School of Mines, https://ljp6c3tnea61xd0wz1l33nmfwpengine.netdna-ssl.com/wp-content/uploads/sites/149/2018/06/20180613\_Gielen\_ WorkingPaper\_web-1.pdf.

Gielen D., Y. Chen and P. Durrant (2021), 'Decarbonising Industry is key to China's net-zero strategy', Energy Post, https://energypost.eu/decarbonising-industry-is-key-to-chinas-net-zero-strategy.

Gnadt, A.R. et al. (2019), 'Technical and environmental assessment of all-electric 180-passenger commercial aircraft', Progress in Aerospace Sciences , Volume 105, pp. 1-30, https://doi. org/10.1016/j.paerosci.2018.11.002.

Government of the United Kingdom (2019), Industrial decarbonisation strategy , Crown Publishing, London, https://assets.publishing.service.gov.uk/government/uploads/system/ uploads/attachment\_data/file/970229/Industrial\_Decarbonisation\_Strategy\_March\_2021.pdf.

IRENA (2021a), 'Leaders summit: The energy transition priorities needed for a 1.5°C future', Expert Insights, 25 April 2021, International Renewable Energy Agency, Abu Dhabi, www.irena.org/ newsroom/expertinsights/2021/April/Leaders-Summit-The-Energy-Transition-Priorities-Neededfor-a-1-5C-Future.

IRENA (2021b), Innovation Outlook: Renewable Methanol , IRENA, Abu Dhabi.

IRENA (2020a), Reaching Zero with Renewables , IRENA, Abu Dhabi.

IRENA (2020b), Green Hydrogen Cost Reduction , IRENA, Abu Dhabi.

IRENA (2020c), Innovation Outlook: Thermal Energy Storage , IRENA, Abu Dhabi.

IRENA (2020d), Renewable Energy Policies in a Time of Transition: Heating and Cooling , IRENA, Abu Dhabi.

IRENA (2019), Hydrogen: A renewable energy perspective , IRENA, Abu Dhabi.

IRENA (2017), Electricity Storage and Renewables: Costs and Markets to 2030 , IRENA, Abu Dhabi.

<!-- image -->

Irie, R. (2020), 'Global plug-in vehicle sales reached over 3.2 million in 2020', EV-volumes, Trollhättan, www.ev-volumes.com.

Moores, S. (2021), The global battery arms race: Lithium-ion battery gigafactories and their supply chain , Oxford Institute of Energy Studies, Oxford, www.oxfordenergy.org/wpcms/ wp-content/uploads/2021/02/THE-GLOBAL-BATTERY-ARMS-RACE-LITHIUM-ION-BATTERYGIGAFACTORIES-AND-THEIR-SUPPLY-CHAIN.pdf.

Pauschinger, T. (2016), '5 - Solar thermal energy for district heating', in Advanced District Heating and Cooling (DHC) Systems, R. Wiltshire (ed.), pp. 99-120, Woodhead Publishing, Cambridge, https://doi.org/10.1016/B978-1-78242-374-4.00005-7.

REN21 (2020), Renewables 2020: Global Status Report , Renewable Energy Policy Network for the 21st Century Secretariat, Paris. www.ren21.net/wp-content/uploads/2019/05/gsr\_2020\_full\_ report\_en.pdf.

Saygin, D. and D. Gielen (2021), 'Zero-emission pathway for the global chemical and petrochemical sector', Energies , Vol. 14, No. 13, pp. 3772, https://doi.org/10.3390/en14133772.

Schäfer, A.W. et al. (2019), 'Technological, economic and environmental prospects of all-electric aircraft', Nature Energy , Vol. 4, pp. 160-166, www.nature.com/articles/s41560-018-0294-x.

Trahey, L. et al. (2019), 'Energy storage emerging: A perspective from the Joint Center for Energy Storage Research', Proceedings from the National Academy of Sciences , Vol. 117, No. 23, pp. 12550-57, www.pnas.org/content/117/23/12550.

<!-- image -->

## SOCIO-ECONOMIC FOOTPRINT

## Annex B.1 Socio-economic implications of varying carbon pricing from optimum levels

Modifying the level of carbon pricing from its optimal value- through its contribution to government fiscal  balances  -  for  a  given  climate  goal  and  climate  policy  basket  may  have  important  socioeconomic  implications.  Increasing  carbon  pricing  above  its  optimal  value  will  exacerbate  its regressive  effects,  triggering  negative  impacts  on  welfare  and  economic  activity,  potentially creating transition barriers.

Figure x illustrates the potential consequences of reducing carbon pricing from its optimal value. Not allowing deficit spending can have:

- 1. a negative impact on GDP, if governments decide to increase general taxation; and/or
- 2.    a negative impact on welfare and exacerbate inequality and/or create energy transition barriers, if governments decide to reduce social spending.

Alternatively, deficit spending could increase as has been the case historically in response to crises (most recently demonstrated by the COVID-19 pandemic). However, given fiscal constraints in the Global South to address social needs and the demands of the energy transition, it would require strong international collaboration to marshal the necessary resources. 1

## FIGURE B.1     Potential transition implications of sub-optimal carbon pricing

<!-- image -->

- 1 Specially those without monetary sovereignty or with high dependence on foreign exchange rates.

<!-- image -->

T

## Annex B.2 Welfare index methodology

IRENA's  Energy  Transition  Welfare  Index  captures  five  dimensions  namely,  economic,  social, environmental, distributional, and energy access. This section outlines the indicators comprising each dimension and discusses the methodology followed for the computation of the welfare index.

## Indictors of each welfare dimension

## Economic dimension

The  economic  dimension  addresses  the  contribution  form  sustainable  economic  activity  to welfare, and it is informed by two indicators: per capita consumption and investment, and nonemployment. 2

- 1. Consumption  reflects  disposable  income,  and  hence  can  be  used  as  a  proxy  for  increases in current well-being, whereas  investment supports future well-being. Acknowledging the  decreasing marginal returns of consumption to welfare, a logarithmic scale is used, and a  sufficiency  limit  has  been  introduced, 3   beyond  which  additional  consumption  does  not contribute  any  further.  Likewise,  an  aspirational  goal  of  minimum  consumption  has  been introduced to account for poverty lines.
- 2.    Employment, as means for income generation, contributes to the welfare of current and future generations.  The  economic  dimension  of  the  welfare  index  includes  the  non-employment indicator, which tracks the share of the working age population that is neither employed nor young and in education.

## Social dimension

The social dimension addresses the use of public resources to provide social value and address externalities  faced  by  society.  It  uses  two  indicators:  per  capita  public  expenditures  aimed  to increase social value; and per capita health impacts from pollution.

- 1. The per capita social  public  expenditure  includes  spending  on  education,  health,  and  social welfare,  together  with  transition-related  public  investment  and  budgets  related  to  climate policies.  The  associated index includes a minimum aspirational goal to acknowledge a basic contribution from public expenditure to welfare.
- 2.    The  health  impact  indicator  is  the  per  capita  health  costs  linked  to  energy  system-related air  pollution  (indoors  and  outdoors),  which  emphasises  the  relevance  of  living  in  a  healthy, unpolluted environment for people's well-being.
- 2 The state of not having paid work, excluding young people (age group from 15 to 24 years) getting an education. Non-employment is hence calculated as the share of the working age population (age group from 15 to 64 years) that is neither employed nor under education while belonging to the 14-24 age group. Non-employment is used instead of the unemployment or employment metrics because its more comprehensive gauging of the social implications of paid work, which is the main goal of a welfare index. Indeed, while unemployment and employment are evaluated as shares of the labour force, non-employment is defined on the basis of the whole working age population (not only the part of it belonging to the labour force), and hence beyond the short-term lack of paid work also captures the long-term lack of paid work (which is excluded from the labour force).
- 3 It  should  be  noted  that  countries/regions  exceeding  this  sufficiency  limit  are  not  penalised  in  terms  of  the welfare index. They just reach the maximum value (100%) of the corresponding indicator's index.

## Environmental dimension

The  environmental  dimension  addresses  the  sustainability  of  socio-economic  activity  within planetary  boundaries.  It  is  informed  by  two  indicators:  climate  change  and  the  use  of  natural resources.

- 1. The impacts from climate change on welfare are captured by vulnerability adjusted cumulative 4 CO2 emissions. 5  The vulnerability adjustment acknowledges that countries and regions differ both  by  multi-sectoral  propensity  to  be  negatively  impacted  by  climate  change  (exposure, sensitivity, adaptive  capacity)  and  their  readiness  for  adaptation  (across  all  economic, governance and social dimensions).
- 2.    The  resource  use  indicator  is  per  capita  materials  consumption   (excluding  fossil  fuels)  and 6 includes a developmental allowance 7  linked to the planetary sustainability boundary.

## Distributional dimension

Distributional  aspects,  receive  increasing  public  attention,  and  are  bound  to  play  an  important role in the transition, either as barriers or enablers. To gain insights into the transition dynamics affecting  inequality  and  how  policy  frameworks  can  address  these,  IRENA  has  included  a distributional dimension in its welfare index.

The distributional dimension has two indicators:

- 1. Within countries/regions (intra) inequality.
- 2.    Between countries/regions (inter) inequality.

Both  income  and  wealth  inequality  are  tracked.  Each  one  of  the  indexes  associated  to  these indicators is constructed as the arithmetic average of income and wealth inequality indexes. The indicator used is the quintile ratio: the ratio of income/wealth from the highest quintile (20% of population) to the income/wealth from the lowest quintile (20% of population) of the income/ wealth distributions.

The inter-distributional index (between countries) is common for all countries/regions, while the intra-distributional index (within countries/regions) is specific to each country/region. In the case of global results, the intra distributional indicator corresponds to the distribution of global citizens.

- 4  Cumulative emissions are evaluated from 2021 to 2050 (the scenarios time span)
- 5 Includes all CO  emissions (energy-related, industrial process and LULUCF) 2
- 6 Currently evaluated as Domestic Material Consumption (DMC).
- 7 Such that if the per capita materials consumption is lower than this allowance the Index is 100% and hence the materials consumption does not negatively impact the IRENA's Energy Transition Welfare Index.
- 8 Access to clean cooking is used here as a proxy to overall energy access.

<!-- image -->

## Access dimension

The access dimension addresses energy access and provides the visibility needed to track progress in this fundamental dimension, which if not specifically addressed is often overlooked.

The access dimension has two indicators: share of population without basic energy access; and progress along the energy access ladder.

- 1. The index associated to the share of population without energy access includes the aspirational goal of reaching full basic energy access.
- 2 The indicator used to measure progress along the energy access ladder 9  is per capita total final energy consumption. The index introduces a sufficiency limit, such that once per capita total final energy consumption reaches this sufficiency limit, the index achieves a maximal value of 1. In order to capture the effect of energy efficiency improvements over time, the sufficiency limit includes an efficiency modulation factor that adjusts it with time.

## Methodology for welfare index computation

Welfare  index  indicators  are  normalised  into  indicator  indexes  using  goalposts  and  include  a directional  parameter that aligns indicator index with welfare impact. Hence, indicator indexes are all bounded by zero and one, and increasing index values have positive impacts on welfare 10 . Sufficiency thresholds, thresholds on bad  performance,  minimum  aspirational goals and development allowances are included into the indicator indices' formulation.

The combination of indicators into dimensional indexes and that of dimensional indexes into the welfare index uses a modified geometric mean to limit substitutability while addressing zeroing and masking effects.

Several criteria have been applied for choosing goalposts:

- a)    Invariance  across  simulations/analyses:  In  this  case,  the  MAX  and  MIN  are  chosen  to  remain invariant across simulations, and hence results from different simulations can be compared. This could lead to the indexes series for a given analysis, while being within in the {0,1} range, not occupying this range completely.
- 8 Access to clean cooking is used here as a proxy to overall energy access.
- 9 Energy poverty is partly addressed by this indicator and complemented by the distributional dimension.
- 10 To illustrate, decreasing emissions would contribute positively to welfare as would increasing energy access.

- b)   Introducing sufficiency conditions . This applies to the MAX of an indicator that when increasing improves  welfare  and  acknowledges  the  fact  that  beyond  a  certain  value  further  increases from this indicator does not improve the considered welfare dimension. An example is in the energy access dimension for the indicator showing progress through the access ladder: beyond the sufficiency level, access has been achieved and the indicator does not improve further. 11 Application of the sufficiency criteria requires modifying the index formulation by capping the indicator at MAX. 12
- c)    Introducing  a threshold on bad performance .  This  applies  to  the  MAX  of  an  indicator  that when increasing reduces welfare and introduces a bad performance threshold from where a zero value for the index is obtained. In that way the index does not capture further welfare implications of bad performance beyond the threshold, but it better captures the differences between  countries  performing  below  the  threshold.  An  example  is  wealth  inequality  when measured  through  a  quintile  ratio,  where  in  some  regions  is  so  high  (infinity)  that  without introducing the threshold would completely dilute the index in all other countries/regions. This applies also to other indicators such as material consumption too high compared with planetary boundary and health impacts too high for social acceptability.
- d)   Introducing a minimum aspirational goal .  This  applies to the MIN of an indicator that when increasing improves welfare. When the indicator falls below the MIN, the index becomes zero (not achieving minimum aspirational goal in this dimension). An example is when consumption and  investment  falls  below  the  poverty  line.  Application  of  the  minimum  aspirational  goal requires modifying the index formulation by limiting the lower value of the indicator to MIN :
- e)    Introducing  a development  allowance .  This  applies  to  the  MIN  of  an  indicator  that  when increasing reduces welfare, but there is a threshold below which it could maintain sustainable economic activity. An example is materials consumption. If kept enough below a sustainable limit,  it  can  be  used  for  increasing  welfare  and  hence should not penalise the welfare index. Application of the development allowance requires modifying the index formulation by limiting the lower value of the indicator to MIN: 14
- 11 Countries are not penalised for going beyond this sufficiency limit, but no additional credit is provided in the concerned welfare dimension (index at its maximum value of I=1).
- 12    Note that for all indexes MAX acts as a cap for the Indicator (avoiding indexes outside the 0 - 1 range). The difference here is that MAX is intentionally set to a value lower than the expected maximum in the indicator's series range.
- 13    Note that for all indexes MIN acts as a lower limit for the indicator (avoiding indexes outside the 0 - 1 range). The difference here is that MIN is intentionally set to a value higher than the expected minimum in the indicator's series range.
- 14   Note that for all indexes MIN acts as a lower limit for the indicator (avoiding indexes outside the 0 - 1 range). The difference here is that MIN is intentionally set to a value higher than the expected minimum in the indicator's series range.

<!-- image -->

## Indicator's goalposts

Table B.1 presents the goalposts' used for each indicator. The table also indicates whether an upper or lower limit to the possible range has been imposed because of sufficiency, threshold on bad performance, aspirational goal or development allowance.

## TABLE B.1     Goalposts for the indicators in IRENA's Energy Transition Welfare Index

| DIMENSION         | INDICATOR                          | UNITS              |   MIN | MAX                | UPPER LIMIT   | LOWER LIMIT   |   DIR. |
|-------------------|------------------------------------|--------------------|-------|--------------------|---------------|---------------|--------|
| Economic          | Consumption and                    | USD/ person-year   | 700   | 45000              | Yes           | Yes           |      0 |
|                   | Non-Employment                     | %                  |   0   | 70                 | -             | -             |      1 |
| Social            | Social expenditure                 | USD/ person-year   | 150   | 30000              | -             | Yes           |      0 |
| Social            | Health Impact                      | USD/ person-year   |   0   | 1 000              | Yes           | -             |      1 |
| Environmental     | CO 2 emissions 15                  | GtCO 2             |   0   | 2361               | -             | -             |      1 |
| Environmental     | Materials consumption              | Tones/ person-year |   2.5 | 12.5               | Yes           | Yes           |      1 |
| Distributional 16 | Within country/ region             | -                  |   1   | 80 - IQR 160 - WQR | Yes           | -             |      1 |
| Distributional 16 | Between countries                  | -                  |   1   | 20 - IQR 40 - WQR  | Yes           | -             |      1 |
| Access            | Share of population without access | %                  |   0   | 100%               | -             | -             |      1 |
| Access            | Progress in access ladder 17       | kWh/p-d            |   0   | 20                 | Yes           | -             |      0 |

Based on IRENA's analysis

15  Cumulative until 2050.

16    The  quintile  ratio  (QR),  as  the  ratio  from  the  highet  quintile  to  that  of  the  lowest  quintile,  is  the  indicator  used  to  measure distributional aspects. The indicator is applied to income distribution (IQR) and to wealth distribution (WQR).

17    The MAX in this indicator is also affected by an efficiency modulation function which captures the effect of improving efficiency with time.

## Producing dimensional and overall welfare index

Combining indicator's indices to produce a dimensional index, or dimensional indices to produce the welfare index, requires a methodology to average the different indices.

IRENA's Energy Transition Welfare Index methodology uses arithmetic or geometric averaging depending  on  whether  full  substitutability  between  the  indices  being  averaged  is  considered appropriate or not for the purpose of measuring overall welfare. Except for the case of combining income and wealth inequality in the distributional dimension, all other averaging uses a geometric mean 18  to limit substitutability between different indices. 19

However, the geometric mean presents two inconvenient characteristics for the welfare index:

- · Zeroing effect: when one or more dimensional indexes are zero, the geometric mean becomes zero.
- · Masking effect: very low values in one or more dimensions produce a very low geometric mean, masking the evolution in the other dimensions.

IRENA's welfare index uses a modified geometric mean that addresses the zeroing and masking effects.

- 18    Besides the reduced substitutability, the geometric mean offers other advantages to the welfare index: Ensures that a 1% decline in the index in any dimension has the same impact on the IRENA's Energy Transition Welfare Index; Sufficiency components become neutral once the sufficiency threshold has been achieved; It is the only mean for which the mean of a quotient is the quotients of the means, and hence the ranking of the results is independent on what is used as a reference.
- 19   Low achievement in one index/dimension is not linearly compensated for by a higher achievement in another index/dimension.

<!-- image -->

T

## Annex B.3 Data tables

## Employment

## TABLE B.2     Energy sector jobs for the 1.5°C Scenario and differences with PES over time, global results.

|                     |                     |              | 2021/thinspace 20   | 2030   | 2050   |
|---------------------|---------------------|--------------|---------------------|--------|--------|
| Energy sector       | absolute            | million jobs | 91.0                | 136.5  | 121.8  |
|                     | difference with PES | million jobs | -                   | 25.8   | 8.0    |
|                     |                     | relative     | -                   | 23.3%  | 7.0%   |
| Transition- related | absolute            | million jobs | 52.5                | 106.5  | 95.8   |
|                     | difference with PES | million jobs | -                   | 39.8   | 28.3   |
|                     |                     | relative     | -                   | 59.6%  | 42.0%  |
| Fossil fuels        | absolute            | million jobs | 37.9                | 29.4   | 25.8   |
|                     | difference with PES | million jobs | -                   | -13.9  | -20.0  |
|                     |                     | relative     | -                   | -32.1% | -43.7% |

20    2021  estimates  are  obtained  through  a  calibrated  macroeconomic  model  based  on  investments  associated with the PES scenario. It should be noted that the jobs reported here for the energy sector go beyond the traditional categories for this sector (fossil fuels, electricity generation, bioenergy) and besides nuclear, also include energy efficiency, energy flexibility, power grids, hydrogen value-chain, and heat pumps-related jobs.

## Employment

TABLE B.3     Renewable energy jobs by technology in the 1.5°C Scenario and differences with the PES, global results.

|            |                     |              | 2021   | 2030   | 2050   |
|------------|---------------------|--------------|--------|--------|--------|
| Solar      | absolute            | million jobs | 5.52   | 17.32  | 19.90  |
|            | difference with PES | million jobs | -      | 10.01  | 9.64   |
|            |                     | relative     | -      | 137%   | 94%    |
| Bioenergy  | absolute            | million jobs | 5.34   | 11.11  | 13.67  |
|            | difference with PES | million jobs | -      | 6.02   | 7.72   |
|            |                     | relative     | -      | 118%   | 130%   |
| Wind       | absolute            | million jobs | 1.98   | 5.57   | 5.48   |
|            | difference with     | million jobs | -      | 3.05   | 2.11   |
|            | PES                 | relative     | -      | 121%   | 62%    |
| Hydro      | absolute            | jobs         |        |        | 3.70   |
|            |                     | million      | 3.52   | 3.32   |        |
|            | difference with     | million jobs | -      | 0.42   | 1.05   |
|            | PES                 | relative     | -      | 14%    | 40%    |
| Geothermal | absolute            | million jobs | 0.14   | 0.30   | 0.23   |
|            | difference with     | million jobs | -      | 0.12   | 0.02   |
|            | PES                 |              | -      | 72%    | 7%     |
|            |                     | relative     |        |        |        |
| Tidal/Wave | absolute            | million jobs | 0.002  | 0.18   | 0.37   |
|            | difference with     | million jobs | -      | 0.18   | 0.31   |
|            | PES                 | relative     | -      | 7 907% | 472%   |

<!-- image -->

## Employment

TABLE B.4     Renewable energy jobs by segment of value chain in the 1.5°C Scenario and differences with the PES, global results.

|                             |                     |              | 2021   | 2030   | 2050   |
|-----------------------------|---------------------|--------------|--------|--------|--------|
| Construction & Installation | absolute            | million jobs | 4.5    | 12.0   | 14.2   |
| Construction & Installation | difference with PES | million jobs | -      | 6.7    | 5.1    |
| Construction & Installation | difference with PES | relative     | -      | 126%   | 57%    |
| Manufacturing               | absolute            | million jobs | 4.3    | 11.0   | 8.7    |
| Manufacturing               | difference with PES | million jobs | -      | 6.2    | 5.6    |
| Manufacturing               | difference with PES | relative     | -      | 131%   | 178%   |
| O&M                         | absolute            | million jobs | 3.1    | 5.4    | 9.3    |
| O&M                         | difference with PES | million jobs | -      | 1.5    | 3.0    |
| O&M                         | difference with PES | relative     | -      | 38%    | 48%    |
| Biofuel supply              | absolute            | million jobs | 4.6    | 9.4    | 11.2   |
| Biofuel supply              | difference with PES | million jobs | -      | 5.4    | 7.1    |
| Biofuel supply              | difference with PES | relative     | -      | 135%   | 176%   |

## TABLE B.5     Energy sector jobs by educational requirement in the 1.5°C Scenario and differences with the PES, global results.

|           |                              |                                    | 2021   | 2030     | 2050     |
|-----------|------------------------------|------------------------------------|--------|----------|----------|
| Primary   | absolute                     | million jobs                       | 24.1   | 47.3     | 60.7     |
| Secondary | PES absolute                 | relative million jobs              | - 37.8 | 22% 34.8 | 2% 44.8  |
|           | difference with PES          | million jobs relative              | - -    | 8.6 33%  | 4.8 12%  |
| Tertiary  | absolute difference with PES | million jobs million jobs relative | 29.1 - | 54.5 8.8 | 16.2 2.2 |

## Welfare

TABLE B.6     Welfare and dimensional indexes for 1.5-S and PES, as well as the relative difference between both, for 2030 and 2050, global results.

| DIMENSION       | 2030      | 2030       | 2030          | 2050      | 2050       | 2050          | COMMENT                                                                                                                                                                                               |
|-----------------|-----------|------------|---------------|-----------|------------|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                 | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL |                                                                                                                                                                                                       |
| Economic        | 0.642     | 0.645      | +0.4%         | 0.655     | 0.656      | +0.2%         | Small improvement aligned with improvements of 1.5-S over PES in GDP and employment.                                                                                                                  |
| Social          | 0.153     | 0.187      | +23%          | 0.218     | 0.268      | +23%          | Through improved public health, makes a significant contribution to the increase from PES to 1.5-S, but remains low and hence provides significant potential for improving the overall welfare index. |
| Environ- mental | 0.547     | 0.711      | +30%          | 0.474     | 0.614      | +30%          | Mainly driven by the mitigation of CO 2 emissions.                                                                                                                                                    |
| Distribution    | 0.018     | 0.052      | +186%         | 0.157     | 0.154      | -2%           | Low index values in both PES and 1.5-S reflect the persistence of high inequalities irrespective of changes to the global energy landscape.                                                           |
| Access          | 0.857     | 1          | +17%          | 0.934     | 1          | +7%           | Both scenarios above sufficiency limit, but PES still without full basic energy access by 2050.                                                                                                       |
| Welfare         | 0.253     | 0.344      | +36%          | 0.399     | 0.442      | +11%          | Improvements in welfare index (1.5-S over PES) are higher than for GDP or employment. But low index values indicate room for improvement in welfare.                                                  |

<!-- image -->

## Welfare

## TABLE B.7     Economic index and its indicator's indexes for 1.5°C Scenario and PES, for 2030 and 2050, global results.

| INDICATOR                  | 2030      | 2030       | 2030          | 2050      | 2050       | 2050          | COMMENT                                                                                                                                                                                                                    |
|----------------------------|-----------|------------|---------------|-----------|------------|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                            | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL |                                                                                                                                                                                                                            |
| Consumption and Investment | 0.645     | 0.643      | -0.3%         | 0.767     | 0.767      | 0%            | Almost neutral role because of 1.5-S policy to earmark revenues for transition-related government spending. Per capita consumption and investment increases over time in both scenarios, almost doubling per-capita value. |
| Non- employment            | 0.639     | 0.647      | +1%           | 0.559     | 0.561      | +0.4%         | Positive impact of the transition on non-employment. Non-employment increases over time in both scenarios.                                                                                                                 |
| Economic Index             | 0.642     | 0.645      | +0.4%         | 0.655     | 0.656      | +0.2%         | Improvement of 1.5-S over PES mainly driven by non- employment improvements. Index reaches a minimum value around 2030, consequence of the balance in trends from its two indicators.                                      |

## Welfare

TABLE B.8     Social index and its indicators' indexes for 1.5°C Scenario and PES, for 2030 and 2050, global results.

| INDICATOR          | 2030      | 2030       | 2030          | 2050      | 2050       | 2050          | COMMENT                                                                                                                                                                                                                                                                                                                      |
|--------------------|-----------|------------|---------------|-----------|------------|---------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                    | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL |                                                                                                                                                                                                                                                                                                                              |
| Social expenditure | 0.047     | 0.051      | +9%           | 0.081     | 0.085      | 4%            | Social spending improves over time in both scenarios, almost doubling in per-capita terms. However, the social spending index value remains very low. Hence, there is significant room to improve the welfare index by increasing social spending.                                                                           |
| Health impact      | 0.483     | 0.669      | +39%          | 0.571     | 0.827      | +45%          | Health impacts reduce over time in both scenarios, but at a much higher rate in the 1.5-S reflecting the huge benefits that the energy transition brings about by eliminating outdoor and indoor air pollution. Under the PES, by 2050, global average health impacts still amount to a staggering 2019 USD 430/person-year. |
| Social Index       | 0.154     | 0.189      | +23%          | 0.218     | 0.268      | +23%          | Improves over time for both scenarios. The low index value is consequence of low social spending.                                                                                                                                                                                                                            |

<!-- image -->

## Welfare

## TABLE B.9   Environmental index and its indicators' indexes for 1.5°C Scenario and PES, for 2030 and 2050, global results.

| INDICATOR             | 2030      | 2030       | 2030          | 2050      | 2050       | 2050          | COMMENT                                                                                                                                                                                               |
|-----------------------|-----------|------------|---------------|-----------|------------|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                       | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL |                                                                                                                                                                                                       |
| CO 2 emissions        | 0.446     | 0.754      | +69%          | 0.446     | 0.754      | +69%          | Constant over time because the scenario's cumulative emissions is the indicator impacting climate change. Strong improvement of 1.5-S over PES because of ambitious mitigation effort.                |
| Materials consumption | 0.671     | 0.671      | 0%            | 0.504     | 0.501      | -0.6%         | Materials consumption increasing for both scenarios due to increasing aggregated economic activity. During the first decade, the GDP stimulus in 1.5-S leads to higher material consumption than PES. |
| Environmental Index   | 0.547     | 0.711      | +30%          | 0.474     | 0.614      | +30%          | The index deteriorates over time consequence of the increase in materials consumption. The positive improvement of 1.5-S over PES is dominated by the mitigation of CO 2 emissions.                   |

## Welfare

TABLE B.10     Distributional index and its indicators' indexes for 1.5°C Scenario and PES, average 2021-2050, global results.

| INDICATOR            | AVERAGE 2021 ­ 2050   | AVERAGE 2021 ­ 2050   | AVERAGE 2021 ­ 2050   | COMMENT                                                                                                                                                                                                                                                               |
|----------------------|----------------------|----------------------|----------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                      | PES INDEX            | 1.5­S INDEX           | DIFFER­ ENTIAL        |                                                                                                                                                                                                                                                                       |
| Intra-inequality     | 0.123                | 0.176                | +44%                 | The index improves over time. The wealth component drags the index down, attenuating the improvements in income. Lump-sum payments play a significant role in the 1.5-S over PES difference.                                                                          |
| Inter-inequality     | 0.076                | 0.091                | +20%                 | The index improves over time, with both its wealth and income components contributing to this. International cooperation plays a role in the improvement of 1.5-S over PES, more strongly felt during the first decade.                                               |
| Distributional Index | 0.088                | 0.121                | +37%                 | High improvement of 1.5-S over PES, consequence of the introduced policy elements addressing inequality. But index values are very low, indicating a huge room to improve welfare by strengthening policy action addressed at improving the distributional dimension. |

TABLE B.11     Access index indicator's contributions for 1.5S and PES by 2050, global results.

| INDICATOR          | 2030      | 2030       | 2030          | 2050      | 2050       | 2050          | COMMENT                                                                                                                |
|--------------------|-----------|------------|---------------|-----------|------------|---------------|------------------------------------------------------------------------------------------------------------------------|
|                    | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL | PES INDEX | 1.5­S INDEX | DIFFER­ ENTIAL |                                                                                                                        |
| Basic access       | 0.735     | 1          | +36%          | 0.873     | 1          | +15%          | The 1.5S reaches universal basic access by 2030, while the PES is not there even by 2050.                              |
| Energy sufficiency | 1         | 1          | 0%            | 1         | 1          | 0%            | Globally, both scenarios are above the sufficiency limit. But this average hide energy inequalities between countries. |
| Access index       | 0.857     | 1          | +17%          | 0.934     | 1          | +7%           | Index improves over time for both scenarios, driven by progress in universal basic access.                             |

ISBN 978-92-9260-334-2 Copyright © IRENA 2021

www.irena.org

<!-- image -->