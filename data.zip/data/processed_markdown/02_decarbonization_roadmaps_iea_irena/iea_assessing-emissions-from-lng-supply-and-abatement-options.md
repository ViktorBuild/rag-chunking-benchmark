---
document_id: iea_assessing-emissions-from-lng-supply-and-abatement-options
title: "Iea Assessing-Emissions-From-Lng-Supply-And-Abatement-Options"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_assessing-emissions-from-lng-supply-and-abatement-options.pdf"
tables_detected: 30
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Assessing Emissions from LNG Supply and Abatement Options

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 14 Association countries and beyond.

## IEA M ember countries:

This publication, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. International Energy Agency Website: www.iea.org

IEA Accession countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Chile Colombia Costa Rica Brazil Israel

Romania

## IEA A ssociation countries:

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Table of contents

| Introduction .............................................................................................................................    |   4 |
|-----------------------------------------------------------------------------------------------------------------------------------------------|-----|
| Chapter 1: Estimated emissions from liquefied natural gas...................................................                                  |   6 |
| Summary....................................................................................................................................   |   6 |
| Production and processing.......................................................................................................              |  10 |
| Transmission............................................................................................................................      |  16 |
| Liquefaction..............................................................................................................................    |  17 |
| Shipping ...................................................................................................................................  |  18 |
| Regasification...........................................................................................................................     |  20 |
| Chapter 2: Emissions reduction opportunities and costs .....................................................                                  |  22 |
| Summary..................................................................................................................................     |  22 |
| Reducing methane emissions..................................................................................................                  |  26 |
| Reducing flaring .......................................................................................................................      |  29 |
| Increasing process efficiency...................................................................................................              |  31 |
| Electrification............................................................................................................................   |  37 |
| Carbon capture, utilisation and storage ...................................................................................                   |  41 |
| Chapter 3: Policy and finance considerations ......................................................................                           |  43 |
| Summary..................................................................................................................................     |  43 |
| Policies..................................................................................................................................... |  45 |
| Voluntary initiatives ..................................................................................................................      |  49 |
| Finance.....................................................................................................................................  |  52 |
| Technical annex....................................................................................................................           |  56 |
| Data sources and limitations....................................................................................................              |  56 |
| Estimating emissions ...............................................................................................................          |  56 |
| Abatement and electrification cost estimates...........................................................................                       |  60 |
| Acknowledgements .......................................................................................................                      |  64 |

## Introduction

Global liquefied natural gas (LNG) supply has grown faster than overall natural gas demand in recent years. Around 580 billion cubic metres (bcm) of natural gas were exported as LNG in 2025, equivalent to about 13% of global natural gas consumption. LNG's share of the gas market is set to increase further, with a wave of new projects coming online over the next several years.

Previous International Energy Agency (IEA) analysis found that greenhouse gas (GHG) emissions from extracting, processing and transporting natural gas through pipelines, and as LNG, are globally on average around 11.5 grammes of carbon dioxide equivalent per megajoule (g CO2-eq/MJ). Given that about 55 g CO2/MJ are emitted when natural gas is combusted, extracting natural gas and bringing it to consumers represents nearly 17% of its life-cycle emissions.

There is a broad range of emissions from extracting, processing and transporting natural gas. Due to the high energy requirements to liquefy and transport gas over long distances, LNG tends to have higher emissions than natural gas produced close to where it is consumed. Emissions from gas transported by pipeline also vary widely, often in proportion to the distances involved.

Several importing countries are increasing their efforts to assess the emissions intensity  of  oil  and  gas  imports  through  different  approaches,  such  as  the  EU Methane Emissions Reduction Regulation (EU MER) and the Coalition for LNG Emissions Abatement toward Net-zero (CLEAN).

Producer-side measurement and reporting frameworks such as the Oil and Gas Methane Partnership (OGMP 2.0) are bringing greater visibility and structure to emissions tracking. Reporting and availability of natural gas value chain emissions data  have  increased  significantly  in  recent  years,  but  estimates  remain  highly uncertain.

Building  on  previous  IEA  work  looking  at  GHG  emissions  from  all  sources  of natural gas, at the LNG Producer Consumer Conference (LNGPCC) 2024, the Japanese Ministry of Economy, Trade and Industry (METI) and the IEA launched a two-year work programme to look in detail at emissions from LNG supply and abatement options. An interim report was published in 2025, with this final version prepared to inform dialogue at LNGPCC 2026.

This report provides estimates of emissions from LNG supply in 2025, based on the latest and best available production data and estimates from scientific studies and measurement campaigns.

Chapter  1  provides  estimates  of  emissions  from  natural  gas  production  and processing, pipeline transmission to export terminals, liquefaction, shipping and regasification  at  import  terminals.  It  considers  energy  consumption,  methane emissions, flaring and naturally occurring sources of CO2.

Chapter  2  explores  mitigation  options,  including  pathways  to  reduce  methane emissions and flaring, improve efficiency across the LNG value chain, electrify key processes and deploy carbon capture, utilisation and storage (CCUS).

Chapter  3  discusses  the  policy  and  finance  frameworks  that  can  support emissions reductions along the LNG supply chain.

This report does not assess emissions from gas distribution after regasification, end-use combustion, avoided or additional emissions from fuel switching to or from  LNG,  or  emissions  associated  with  other  potential  LNG  sources  (e.g. biomethane or e-methane).

## Box 1 What has changed since the interim report published in 2025?

In June 2025, the IEA released an interim report that provided estimates of emissions from  the  LNG  supply  chain  and  associated  abatement  options  for  2024.  Several changes since then are reflected in this report, including the addition of 2025 data and new scientific and measurement studies.

LNG exports in 2025 were around 30 bcm higher than in 2024, driven by capacity additions in the United States (Corpus Christi Stage 3 and Plaquemines LNG). New LNG producers also entered the market, including Canada (LNG Canada), Mexico (Fast LNG Altamira), Mauritania and Senegal (through the shared Greater Tortue Ahmeyim floating LNG facility).

Several new studies have been published since the interim report, including Pandey et al. (2026), Zhang et al. (2026), Zhu et al. (2025) and Ma et al. (2025). Updates from the IEA's Global Methane Tracker, the addition of real-world shipping emissions data  from  the  European  Union  Monitoring,  Reporting  and  Verification  (MRV) database, and an update to feed gas mapping to liquefaction terminals have also been incorporated.

In this report, we estimate that the global average emissions intensity of LNG from production to regasification is 18.6 g CO2 -eq/MJ of LNG delivered, slightly lower than the  value  published  in  the  interim  report  (19.4 g CO2 -eq/MJ  of  LNG  delivered). Further details of changes  to  the  underlying  data,  methodology  and  model assumptions are available in the Technical annex.

## Chapter 1: Estimated emissions from liquefied natural gas

## Summary

We provide emissions estimates along the LNG supply chain, covering upstream production, gas processing, transmission, liquefaction, shipping and regasification.  The  estimates  exclude  emissions  associated  with  exploration, onward transport after regasification and natural gas combustion.

We analyse feed gas flows from 51 upstream basins in 24 countries that connect to 52 liquefaction terminals in 24 countries and 181 regasification terminals in 50 countries.  We  track  the  voyages  of  800  LNG  carriers  making  around  7 000 round trip  journeys  per  year.  We  compile  public  and  proprietary  data  on  these -assets to develop a comprehensive estimate covering the entire supply chain for all  deliveries  of  LNG,  from  the  wellhead  through  production  and  processing, transmission  to  liquefaction  facilities,  shipping  and  regasification  (Figure 1). Further details of the underlying data, methodology and model assumptions are available in the Technical annex.

Figure 1 Global average emissions from LNG supply by supply chain segment, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: Intensities are reported as g CO2-eq per MJ of LNG delivered. GHG = greenhouse gas; CO2 = carbon dioxide; CH4 = methane; LDAR = leak detection and repair; CCUS = carbon capture, utilisation and storage; BOG = boil-off gas. Production and processing includes production, gathering and processing. Transmission includes compression and pipeline transport to liquefaction facilities. One tonne of methane is assumed to be equivalent to 30 t CO2 based on a 100 year global warming potential (IPCC, 2021). Emissions intensities are based on global average figures, but vary by -country, basin and supply chain segment. Percentages may not sum to 100% because of rounding.

We estimate total GHG emissions from the LNG supply chain up to and including regasification to be 390 million tonnes of carbon dioxide equivalent (Mt CO2-eq). Around 70% of these emissions are CO2, emitted through combustion or venting, while  the  remaining  30%  comes  from  methane  that  escapes  unburnt  into  the atmosphere. The main sources of methane emissions are flaring, venting  and leakages during upstream production and processing, while the main source of CO2  emissions  is  the  energy  required  to  compress  and  liquefy  natural  gas, followed by upstream production and processing.

Figure 2 LNG exports and estimated average GHG emissions intensity by exporting region, 2025

<!-- image -->

Pacific

IEA. CC BY 4.0.

Notes: bcm = billion cubic metres; g CO2-eq/MJ = grammes of carbon dioxide equivalent per megajoule; C &amp; S America = Central and South America. Emissions intensity includes all CO2 and methane emissions from production, processing, transmission, liquefaction, shipping and regasification, divided by total LNG exports from the region. One tonne of methane is assumed to be equivalent to 30 t CO2 based on a 100-year global warming potential (IPCC, 2021). Source: IEA estimates based on scientific literature and the latest available data, including measured, satellite and inferred data. Data availability and quality vary widely across basins, countries and regions. For methane emissions in countries with no data availability, emission intensities are estimated using data from the United States, scaled to account for country- and production-specific factors (see the Technical annex and Global Methane Tracker 2026 Documentation for further information).

Globally, we estimate that the average GHG emissions intensity of delivered LNG is 18.6 g CO2-eq/MJ, compared with an average of 11.5 g CO2/MJ for natural gas supply  overall.  This  average  masks  wide  variations  across  geographies  and supply  routes,  as  well  as  significant  differences  in  data  quality  and  availability across regions. Estimated LNG emissions intensities exceed 20 g CO2-eq/MJ for some exporters in Africa and Southeast Asia, range from 10 to 20 g CO2-eq/MJ in North America and the Middle East, and are around 5 g CO2-eq/MJ in Norway (Figure 2). The variation is explained primarily by the range of methane emissions associated with the natural gas supplied to LNG terminals, energy use during gas

transmission  and  liquefaction,  and  the  level  of  naturally  occurring 1 CO2 that  is vented where dedicated CCUS systems are not in place. In addition, differences in  shipping  distances  and  vessel  efficiency  can  lead  to  substantial  variation  in shipping emissions intensities across LNG supply routes (Figure 3).

<!-- image -->

IEA. CC BY 4.0.

Notes: Each data point represents the estimated weighted average emissions intensity of a single LNG supply route linking an LNG export terminal to a regasification terminal, taking into account round-trip voyages. One tonne of methane is assumed to be equivalent to 30 t CO2 based on a 100 year global warming potential (IPCC, 2021). -

Source: IEA estimates based on scientific literature and the latest available data, including measured, satellite and inferred data. Data availability and quality vary widely across basins, countries and regions. For methane emissions in countries with no data availability, emission intensities are estimated using data from the United States, scaled to account for country- and production-specific factors (see the Technical annex and Global Methane Tracker 2026 Documentation for further information).

## Box 2 How do IEA estimates of LNG emissions compare with others?

A  wide  range  of  LNG  emissions  intensities  have  been  reported  in  the  literature, largely driven by differences in process assumptions, system boundaries, allocation methods and emissions quantification approaches (i.e. inventory-based, measurement-based,  or  a  combination  of  the  two).  This  reflects  the  inherent complexity of the LNG supply chain, as well as the range of methods available to measure or estimate GHG emissions.

Allocation choices have  major implications for overall emissions intensities. Upstream methane emissions can be allocated between co-produced oil and natural gas on an energy or economic basis, or entirely to natural gas on a volumetric basis. Our estimates allocate upstream methane emissions between oil and natural gas on an energy basis.

1 CO2 that is extracted with produced natural gas.

There are also different ways to express a tonne (t) of methane in CO2-eq terms. The most  common  approach  is  to  use  global  warming  potential  (GWP).  However, different GWP values can be applied, which has a major impact on the assumed potency of methane. Some studies consider the impact of methane over a 20-year time frame, with 1 t of methane typically assumed to be equivalent to 82.5 t CO2-eq. Others consider its impact over a 100-year time frame, with 1 t of methane assumed to be equivalent to around 30 t CO2 -eq. 2

The choice of the most appropriate time frame depends on the emissions scenario in  question  (e.g. whether  or  when  global  temperature  rise  peaks)  and  can  be subjective. Our estimates assume that 1 t of methane is equivalent to 30 t CO2.

Figure 4 Emissions from producing and transporting LNG from the United States to Europe reported by different sources

<!-- image -->

₂

IEA. CC BY 4.0.

Notes: The basin providing feed gas or the specific US LNG terminal is shown in brackets where specified; otherwise, the estimate represents the average of all US LNG exports to Europe; S&amp;P (2025) does not specify the import location. CCL = Corpus Christi LNG terminal; SPL = Sabine Pass LNG terminal; RC = reference case; MC = measurementinformed case (see Roman-White et al. (2024) for further details). The horizontal axis shows emissions per unit of natural gas delivered to the regasification terminal. The IEA estimate is based on a net calorific value of 49.5 MJ/kg LNG. One tonne of methane is assumed to be equivalent to 30 t CO2 for all studies. Emissions from end-use combustion are excluded.

Sources: IEA analysis based on Roman-White et al. (2021), Roman-White et al. (2024), Zhu et al. (2024), BRG (2025), North Sea Transition Authority (NSTA) (2025), S&amp;P Global Commodity Insights (2025) © 2025 by S&amp;P Global Inc, and Wood Mackenzie (2025).

When comparing estimates for a specific trade route between the United States and Europe, published estimates for methane and CO2 emissions from production to regasification range from 14 g CO2-eq/MJ to 32 g CO2-eq/MJ (Figure 4). A much higher  emissions  intensity  for  LNG  trade  from  the  United  States  to  Europe  is reported in a debated study by Howarth et al. (2024), at around 56 g CO2-eq/MJ. When LNG GHG intensities are harmonised across studies using a Lower Heating

2

Some authors use conversion factors from earlier Intergovernmental Panel on Climate Change assessments. For example,

Roman-White et al. (2021), LNG Supply Chains, used a 100 year GWP value of 36 based on the IPCC (2014), AR5 Synthesis

-

Value basis and a 100-year GWP, the IEA estimates fall within the range of other available estimates.

Even  after  harmonisation,  methane  emissions  vary  more  than  tenfold  among different  sources, and CO2 emissions by a factor of nearly three, highlighting the importance of other methodological factors. For example, using measurement data instead of engineering estimates can change GHG intensity estimates by 41% to 52% (Roman-White et al. (2024)). 3  More work is needed to reconcile these methods. In our analysis, methane accounts for around 35% of the GHG emissions intensity associated with LNG trade between the United States and Europe.

## Production and processing

## Linking LNG terminals to upstream assets

About 580 bcm of LNG were exported globally in 2025 from 24 countries. 650 bcm of natural gas, usually referred to as feed gas, was produced for these exports, accounting for energy use and losses along the supply chain. Around 50 upstream basins supply feed gas for LNG exports. The gas flows through gathering stations, processing  plants,  boosting  facilities  and  pipelines  before  reaching  just  over 50 liquefaction terminals currently in service globally.

In some cases, it is straightforward to link individual upstream assets to a specific LNG export  terminal,  for  example  where  there  is  a  single  physical  connection between them. This is the case in Qatar, where feed gas is supplied from a single gas field, the North Field, and most production is exported as LNG (Figure 5). However, this calculation is  more  complicated for  LNG  terminals  in the  United States. Currently, eight LNG terminals receive natural gas from a pipeline network carrying co mingled natural gas from multiple upstream assets and processing -facilities.  In  some  cases,  commercial  information,  such  as  producer  supply agreements,  can  shed  light  on  the  feed  gas  that  is  produced,  treated  and transported  before  liquefaction,  as  can  company  reports  and  production  data. Nevertheless, different approaches can still be used to trace the origin of feed gas (Box 3). The approach adopted in this work is described in the Technical annex.

3 Integrating measurement data into supply chain emissions models remains challenging, and best practices for combining measurement and analysis methods are still evolving.

## Figure 5 Estimated feed gas volumes to LNG terminals by upstream basin in exporting regions, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: Volumes shown are feed gas and are therefore greater than LNG export volumes because of energy use during liquefaction and other losses along the supply chain. C &amp; S America = Central and South America; Other North America = Appalachian, Barnett, US federal offshore, Williston; Other Asia Pacific = Browse, Clarence-Moreton, Gascoyne, Papua New Guinea Fold belt; Other Southeast Asia = Baram, Balingian, Banggai, Kutai, North Sumatra, Outboard Belt; Other Africa = Berkine, Nile Delta, Reggane, Timimoun; Other C &amp; S America = Trinidad basin.

Sources: IEA estimates based on data from US Energy Information Administration (2025), Federal Energy Regulatory Commission (2025), IEA (2025) World Energy Outlook 2024, Rystad Energy (2025), S&amp;P Global Commodity Insights (2025), S&amp;P Capital IQ (accessed 1 April 2025), and company reporting.

## Box 3 Traceability in natural gas supply chains

There has been a surge of interest in understanding how to link specific sources of feed gas to LNG terminals since the introduction of the EU Methane Regulation in 2024. This regulation states that from 2027, importers of fossil fuels (including LNG) must demonstrate that imported fuels comply with EU-equivalent domestic standards for monitoring, reporting and verification of upstream methane emissions. Starting in 2028, importers will be required to report annually on the upstream methane intensity of imported fuels, and from 2030, fuels placed on the EU market are envisaged to be subject to a methane-intensity threshold.

So far, no sector wide traceability system has been implemented for LNG or natural -gas  markets.  Different  models  can  be  used  to  establish  that  imported  LNG  is associated with low or reduced upstream methane emissions. These approaches fall into two broad categories: bundled and unbundled.

In  a  bundled  model,  physical  supply  is  directly  linked  to  its  emissions  attributes. Importers  must  provide  evidence  that  the  specific  fuel  they  have  purchased  is associated  with  low  upstream  methane  emissions.  A  bundled  model  can  be implemented  in  different ways.  For  example,  operators  can  use  a  physical segregation approach, which relies on dedicated infrastructure to keep 'low methane

intensity'  gas  separate  from  higher-intensity  gas.  This  is  usually  the  costliest approach  (and  often  impractical)  except  where  dedicated  infrastructure  already exists. Alternatively, operators can use a mass balance approach, which allows for mixing  of  supplies  of  different intensity but  requires  that  compliance  claims correspond to the level of mixing (for example, if 30% of the feed gas is low intensity, the importer can only claim compliance for 30% of the imported supply). Bundled models usually require the implementation of a chain of custody system. Existing --resources  such  as  the  chain of custody  models  established  by  the  International --Sustainability  and  Carbon  Certification  and  the  International  Organization  for Standardization can be used to support bundled approaches. Bundled models can strengthen incentives for emissions reductions but are typically more complex and costly to implement.

In an unbundled model, physical supply is decoupled from its emissions attributes. The most prominent example of an unbundled approach is a book and claim system, --under  which  low-intensity  producers  'book'  performance  and  obtain  certificates. Producers then sell these certificates to importers, who can 'claim' low-intensity gas even if the physical supply they have purchased is not low intensity. Book and claim ---models tend to be relatively low-cost and simple for industry but may have lower emissions reduction potential than other models. They also do not allow imported LNG to be traced back to specific upstream assets.

## CO2 emissions from energy use

Extracting oil and gas from the subsurface requires large amounts of energy for a brief  period  to  power  drilling  rigs,  pumps  and  other  process  equipment, and to maintain the drilling fluids at the required temperature and pressure. A continuous fuel supply is essential for upstream oil and gas operations; typically diesel before production starts (i.e. during the drilling and development stage), and natural gas or electricity during the production phase, although drilling can also be electrified, for example in shale basins. After extraction, natural gas undergoes separation to remove  natural  gas  liquids,  dehydration  to  make  it  suitable  for  transport,  and treatment to remove impurities such as CO2, mercury and hydrogen sulphide.

We  estimate  that  the  global  average  emissions  intensity  of  energy  used  in production and processing is 1.8 g CO2/MJ of feed gas 4  (Figure 6), although this varies markedly across regions because of differences in the production type, the

4 In this chapter, emissions intensities are reported either as g CO2-eq per MJ of feed gas for an LNG terminal or g CO2-eq per MJ of LNG delivered to regasification terminals, as relevant to the part of the supply chain under study. The global average intensity of 18.6 g CO2-eq is standardised to MJ of LNG delivered to regasification terminals.

size and maturity of fields providing feed gas, the level of impurities in extracted gas, and the emissions intensity of electricity grids where processes are electrified.

Figure 6 Estimated CO2 emissions from energy use in feed gas production and processing by basin, and emissions intensity by exporting region, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: C &amp; S America = Central and South America. Other North America = Appalachian, Barnett, US federal offshore, Williston; Other Asia Pacific = Browse, Clarence-Moreton, Gascoyne, Papua New Guinea Fold belt; Other Southeast Asia = Baram, Balingian, Banggai, Kutai, North Sumatra, Outboard Belt; Other Africa = Berkine, Nile Delta, Reggane, Timimoun; Other C &amp; S America = Trinidad basin.

Source: IEA analysis based on the Oil Production Greenhouse Gas Emissions Estimator and annual revisions to energy use for oil and gas extraction (see Technical annex).

## Naturally occurring CO2 emissions

When  it  is  extracted,  natural  gas  often  contains  CO2,  hydrogen  sulphide  and heavier  hydrocarbon  molecules  (e.g. butane  and  pentane).  CO2,  hydrogen sulphide  and  other  components  are  treated  or  removed  (e.g. through  amine treatment) to reach specifications for transport; the CO2 may then be blended, reinjected or vented. Gas streams with higher CO2 or hydrogen sulphide content (i.e. sour gas) generally require more energy-intensive processing and treatment than sweeter gas compositions, increasing energy use and associated emissions.

Comprehensive  datasets  on  the  CO2  content  of  natural  gas  production  remain limited. Based on publicly available estimates, we estimate that around 30 Mt of naturally occurring CO2 is extracted from LNG feed gas each year, of which about 25 Mt CO2 is emitted to the atmosphere (Figure 7). This corresponds to a global average  CO2  emissions  intensity  of  about  1 g CO2/MJ  of  feed  gas.  However, emissions intensities vary widely across regions, ranging from around 2.5 g CO2/MJ to less than 0.2 g CO2/MJ. Around 7 Mt CO2 of annual capture capacity is currently available worldwide for naturally occurring CO2 emissions from three LNG plants. In all cases, the captured CO2 is transported and permanently stored.

Figure 7 CO2 vented from LNG feed gas by basin and average CO2 emissions intensity by exporting region, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: C &amp; S America = Central and South America. Other North America = Appalachian, Barnett, US federal offshore, Williston; Other Asia Pacific = Browse, Clarence-Moreton, Gascoyne, Papua New Guinea Fold belt; Other Southeast Asia = Baram, Balingian, Banggai, Kutai, North Sumatra, Outboard Belt; Other Africa = Berkine, Nile Delta, Reggane, Timimoun; Other C &amp; S America = Trinidad basin.

Source: IEA analysis based on field and country CO2 content (see Technical annex).

## Methane emissions

Sources  of  methane  emissions  before  liquefaction  include  emissions  from production,  gathering  and  processing;  transmission  emissions  are  covered separately. These emissions can result from intentional releases, often due to the design of the facility or equipment (e.g. compressors and valves that vent to the atmosphere), operational requirements (e.g. venting a pipeline for inspection and maintenance) or for safety reasons (e.g. pressure relief valves). They can also result from unintentional leaks, due to a faulty seal or leaking valve, for example, or from the incomplete combustion of natural gas during flaring.

In  total,  we  estimate  that  around  2.8 Mt  of  methane  was  emitted  during  the production and processing of natural gas that was used as LNG feed gas in 2025 (Figure 8). The global average upstream methane emissions intensity of feed gas was around 0.5% (which translates into average emissions of 3.5 g CO2 -eq/MJ of feed gas).  There is a wide variation in emissions levels and data quality between 5 countries, with the best performers estimated to have an emissions intensity that is almost two orders of magnitude lower than the worst performers.

5 The upstream methane emissions intensity is calculated here as methane emissions from natural gas operations divided by  feed  gas,  assuming  methane  has  an  energy  density  of  55 MJ/kg.  IEA  methane  emissions  estimates  are  based  on measured, satellite and inferred data (see Global Methane Tracker 2026 documentation for further information).

Figure 8 Upstream methane emissions from feed gas basin and upstream emissions intensities by exporting region, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: Mt = million tonnes. Upstream methane emissions intensity is calculated as methane emissions from natural gas operations divided by feed gas, assuming methane has an energy density of 55 MJ/kg. C &amp; S America = Central and South America. Other North America = Appalachian, Barnett, US federal offshore, Williston; Other Asia Pacific = Browse, Clarence-Moreton, Gascoyne, Papua New Guinea Fold belt; Other Southeast Asia = Baram, Balingian, Banggai, Kutai, North Sumatra, Outboard Belt; Other Africa = Berkine, Nile Delta, Reggane, Timimoun; Other C &amp; S America = Trinidad basin.

Source: IEA estimates based on measured, satellite and inferred data (see the Technical annex and Global Methane Tracker 2026 for further information), the Global Energy and Climate Model, and Rystad Energy (2025). For methane emissions in countries with no data availability, emission intensities are estimated using data from the United States, scaled to account for country- and production-specific factors (see the Technical annex and Global Methane Tracker 2026 Documentation for further information).

## Flaring

Around 170 bcm of natural gas was flared globally, mostly associated gas from oilfields. In general, natural gas fields and fields that produce large volumes of associated  natural  gas  flare  only  during  emergencies,  since  flaring  wastes  a marketable product. There are three main causes of flaring at LNG facilities: plant startups and shutdowns (e.g. during commissioning, testing, process stabilisation and  maintenance);  unplanned  events,  such  as  equipment  failure  or  process disturbances  (e.g. compressor  failure);  and  insufficient  boil-off  gas  recovery. 6 Analysis by Capterio based on data for all LNG plants globally shows that flaring intensities  can  vary  by  more  than  a  factor  of  100  between  the  best  and  worst performers, with some liquefaction plants flaring up to 4% of their output.

We estimate that upstream assets feeding liquefaction plants generated about 3.6 Mt CO2 in 2025, which translates into around 0.3 g CO2/MJ of feed gas.

6 During loading of LNG vessels, supercooled LNG often meets the 'warm' tanks of LNG vessels, evaporating as methane. While many facilities have recovery systems to collect and re-liquefy this 'boil-off' gas, their capacity is sometimes insufficient, with some of the gas volume being flared.

Flaring  also  causes  methane  emissions  due  to  the  incomplete  combustion  of natural gas at flares. We estimate that around 0.1 Mt methane was emitted from upstream facilities in 2025 (this amount is already included in Figure 8). Methane emissions from the incomplete combustion of natural gas flared at LNG facilities therefore add a further 0.2 g CO2 -eq/MJ of feed gas.

## Transmission

Transmission and distribution  networks  connect gas  processing  plants  to  LNG liquefaction  and  export  facilities.  CO2  emissions  depend  primarily  on  pipeline length and the distance over which gas is transported; compressor efficiency and the  type  of  compressor  driver  also  influence  emissions  levels.  Globally,  the average emissions intensity of energy used in transmission is 1.2 g CO2/MJ of feed gas (Figure 9), although this varies from 0.2 g CO2/MJ in Qatar to around 2 g CO2/MJ in North Africa and North America.

Transmission networks were responsible for nearly 0.5 Mt of methane emissions in 2025, which translates into an intensity of 0.6 g CO2 -eq/MJ. These emissions came mostly from compressor leakages (including reciprocating and centrifugal compressors), pipeline and transmission station venting (e.g. during maintenance), and methane slip from gas-fired generators. Infrastructure age is also a key determinant of methane emissions.

Figure 9 GHG emissions from feed gas transmission by basin and average transmission emissions intensities by exporting region, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: One tonne of methane is assumed to be equivalent to 30 tonnes of CO2. C &amp; S America = Central and South America. Other North America = Appalachian, Barnett, US federal offshore, Williston; Other Asia Pacific = Browse, Clarence-Moreton, Gascoyne, Papua New Guinea Fold belt; Other Southeast Asia = Baram, Balingian, Banggai, Kutai, North Sumatra, Outboard Belt; Other Africa = Berkine, Nile Delta, Reggane, Timimoun; Other C &amp; S America = Trinidad basin.

Source: IEA analysis based on data from Zhu et al. (2025), EERA (2024), and FENEX (2024).

The  values  reflect  two  broad  transmission  configurations  typically  observed  in LNG supply chains. In integrated LNG projects, gas is transported via dedicated pipelines directly from the field or treatment facility to the liquefaction plant. These systems are common in countries such as Qatar and Australia. The pipelines are generally  short  and  involve  fewer  compressor  stations,  which  results  in  lower transmission-related emissions. Open  transmission  networks  transport gas through  large,  shared  pipeline  systems  before  it  reaches  the  LNG  facility,  a configuration most commonly found in the United States. Gas may travel longer distances and  pass  through  multiple compressor  stations,  with emissions distributed across the broader network rather than linked to a single LNG project. Longer  transport  distances  generally  increase  emissions,  both  through  higher compression requirements and greater potential for methane leakage along the network.

## Liquefaction

Liquefying natural gas is the most energy-intensive process in the LNG supply chain and, on average, emits around 6.1 g CO2 eq/MJ of LNG delivered. Most -large-scale onshore LNG export terminals typically consume around 10% of the energy content of the feed gas to power their operations. Most of this energy is used  for cooling the natural gas  to -162 °C. Energy  consumption  varies significantly depending on the liquefaction process, natural gas feed composition and  the  type  of  main  refrigerant  compressor  driver  (e.g. electric  motor  or  gas turbine). For fully electrified facilities, such as Freeport LNG, energy consumption is significantly lower.

The different steps involved in the treatment and liquefaction of natural gas release CO2 and can result in methane vents and leaks into the atmosphere. We estimate that  CO2  emissions  account  for  around  95%  of  total  GHG  emissions  from liquefaction plants. A large fraction of CO2 emissions comes from mechanical drive turbines  that  drive  compressors  used  in  the  refrigeration  cycles  and  power generation turbines in other liquefaction processes. Smaller contributors include flaring and naturally occurring CO2 emissions, as well as natural gas combustion for pretreatment and liquids handling processes like dehydration, gas sweetening, mercury removal, condensate stabilisation and fractionation.

Methane  emissions  can  occur  during  gas  treatment,  liquefaction  and  storage. Sources include incomplete combustion during flaring, releases from compressor seal  vents  during  routine  operations,  and  equipment  degradation  over  time. Additional emissions may arise during maintenance activities, as well as from acid gas  recovery  units  and  nitrogen  rejection  units.  Small  quantities  can  also  be emitted as boil off gas (i.e. LNG that regasifies as it warms over time), particularly -when it is not fully recovered and used.

Emissions  vary  depending  on  the  technologies,  facility  type  (e.g. onshore  or floating facilities) and operational practices used. For example, mixed

refrigerant based processes such as single mixed refrigerant (SMR), dual mixed -refrigerant (DMR) or propane precooled mixed refrigerant (C3MR) have different energy intensities than cascade processes. Emissions intensities vary further due to  the  turbine  designs  and  models  used  in  the  liquefaction  process,  with  older technologies often being less efficient than the latest ones.

Floating LNG plants may face efficiency penalties compared to onshore facilities due to inherent space, weight and operational constraints. These constraints limit process  optimisation,  equipment  sizing  and  redundancy,  often  requiring  more compact  and  conservative  machinery  designs  that  operate  outside  optimal efficiency windows.

## Shipping

There are more than 800 LNG-carrying ships in operation, with around 200 under construction  for  delivery  by  2028.  Each  year,  these  ships  make  around  7 000 round trip voyages to deliver LNG from liquefaction to regasification terminals. The -main types of LNG carriers handle around 90% of annual LNG trade (Table 1).

Table 1 Summary of selected LNG carrier types and key characteristics, 2025

| Carrier type                     | Stroke type    |   CO 2 emissions intensity (g CO 2 /MJ of LNG per 1000 km) | Average methane slip range (%)   |   Share of market (%) |
|----------------------------------|----------------|------------------------------------------------------------|----------------------------------|-----------------------|
| Dual-fuel diesel electric (DFDE) | Four           |                                                       0.12 | 3-6                              |                    24 |
| Gas injection (ME - GI)          | Two            |                                                       0.12 | 0.1-1.6                          |                    11 |
| Gas admission (ME-GA)            | Two            |                                                       0.12 | 1-2                              |                    10 |
| Steam turbine                    | Not applicable |                                                       0.24 | 0                                |                    21 |
| Dual-fuel engine (X - DF)        | Two            |                                                       0.11 | 0.6-3.8                          |                    25 |

Notes: Share of the market refers to LNG carrying capacity of ships currently in service. Methane slip is expressed as a percentage of gas used in the main engines (excluding auxiliary generators). CO2 emissions intensity is expressed per MJ of LNG delivered at the regasification terminal. MAN's ME-GA engines have been discontinued. Source: IEA analysis based on data from Thinkstep (2019), FUMES (2024), Balcombe et al. (2022), ICIS LNG Edge (2026).

On average, around 2.7 g CO2 eq are emitted per MJ of LNG delivered by an -average-sized carrier. This varies significantly depending on voyage distance, fuel use, engine type and performance, engine load and other operational conditions. The  two  main  sources  of  emissions  during  shipping  are  fuel  combustion  and methane  slip.  Methane  slip  occurs  when  unburnt  methane  escapes  through engine exhaust into the atmosphere.

Methane slip is more prevalent in low-pressure four-stroke engines such as DFDE ships that use boil-off gas, especially when these ships operate at lower engine loads.  Steam  ships,  which  use  high pressure  steam  as  the  propulsion  source, -have negligible methane slip, but they have relatively high fuel consumption. In recent years, operators have moved towards more advanced designs - such as ME GI  and  X DF  ships  -  with  greater  efficiencies  and  lower  methane  slip. --Innovations that have had positive effects on emissions intensity include the use of two-stroke  instead  of  four stroke  engines,  alongside  the  transition  from -spherical Moss tanks to membrane-type containment systems.

In total, around 900 petajoules (PJ) of fuel - primarily boil off gas, but also heavy -fuel oil and marine gasoil - were used to power ships transporting LNG in 2025. This led to emissions of around 45 Mt CO2 and a further 12 Mt CO2 -eq of methane emissions,  equivalent  to a combined  GHG  emissions  intensity  of  around 2.7 g CO2-eq/MJ of LNG delivered. This represents about 5% of total international CO2 shipping emissions of around 1 000 Mt CO2 in 2025.

Emissions from the highest emitting 10% of journeys were more than ten times -greater than those from the lowest emitting 10%. Differences in fuel type, ship -speed and engine type play a role in this variation, but the primary factor explaining the wide range is the distance travelled. On average, a round-trip voyage for an LNG carrier was 14 000 km in 2025, but distances ranged from less than 500 km to over 50 000 km. On a regional basis, the emissions intensity of LNG carrying -ships varies significantly. For example, LNG shipped to the European Union has an  average  shipping  emissions  intensity  of  around  2.2 g CO2 -eq/MJ,  whereas LNG  shipped  to  the  People's  Republic  of  China  (hereafter,  'China')  has  an average  intensity  of  around  3.5 g CO2 -eq/MJ.  The  routes  with  the  highest emissions intensity were between Africa and Asia in 2025.

These estimates are broadly consistent with the range reported in recent literature. Thinkstep (2019) estimated LNG maritime transport emissions at approximately 2.5 g CO2 -eq/MJ of delivered LNG, while recent measurement- and simulationbased studies by Balcombe et al. (2022) and Rosselot et al. (2024) suggest a wider  range  of  roughly  2 to 8 g CO2 -eq/MJ,  reflecting  substantial  variability  in vessel design, operating conditions and methane slip. The CO2 estimates here are also broadly consistent with LNG ship GHG emissions reported through the EU  Monitoring  Reporting  and  Verification  and  FuelEU  Maritime  regulations, although the reported methane slip values show considerable variability. Primary measurement campaigns have also indicated that methane emissions from LNG carriers  can  exceed  earlier  default  assumptions,  particularly  from  engine  slip, highlighting the continuing uncertainty associated with these emissions.

## Regasification

LNG cargoes are offloaded and regasified at onshore or offshore facilities, or at specially  designed  floating  storage  and  regasification  units.  Depending  on  the geography,  scale  and  type  of  application  (e.g. for  peak-load  shaving  or  for baseload generation), operators choose from available technologies, with varying degrees of  efficiency,  operational  complexity,  capital  expenditure  requirements and emission characteristics. The main technologies used to regasify LNG are open-rack  vaporisers  (ORVs),  which  are  used  in  nearly  90%  of  the  world's regasification plants, submerged combustion vaporisers (SCVs), shell and tube vaporisers, intermediate fluid vaporisers and ambient air vaporisers.

The main sources of emissions at ORV regasification plants stem from the power consumption  of  pumps  circulating  the  heating  fluids  and  LNG,  boil-off  gas compressors, other utilities, and the flare pilot. For SCVs, the primary source of emissions is the combustion of natural gas to heat the LNG. Regasification energy demand  typically  consumes  0.3% to 0.5%  of  the  LNG  that  is  imported.  Other emissions  come  from  the  electricity  used  in  the  regasification  plant,  methane emissions from plant hardware (e.g. leaks from compressors, valves, flanges and fittings,  and  maintenance  activities),  and  emissions  related  to  LNG  loading, unloading and bunkering activities, where applicable.

Total GHG emissions intensity from regasification is around 0.3 g CO2 -eq/MJ of regasified LNG. Significant regional variations have not generally been observed. Estimates typically range from 0.2 to 0.4 g CO2 -eq/MJ using gate-to-gate and lifecycle assessment approaches that account for energy requirements, losses and full  supply  chain  emissions.  An  exception  is  China,  where  reported  emissions intensities are higher, at 0.5 to 0.6 g CO2 -eq/MJ.

## Box 4 Comparing the full life-cycle emissions intensities of LNG and coal

A common claim is that methane emissions along the gas supply chain result in LNG having a higher life cycle GHG emissions intensity than coal. IEA analysis does not -support this conclusion. While there is a wide variation in the emissions intensities of coal  and  LNG,  when  all  direct  and  indirect  GHG  emissions  are  considered  (from production to end use combustion, for power and heat generation), we estimate that -LNG results in about 25% fewer emissions than coal across energy use cases of these fuels (Figure 10).

Globally, on average, the life cycle GHG emissions intensity of electricity produced -from LNG is around 40% lower than electricity produced from coal. This is because gas fired -power  plants  are  generally  more  efficient  than  coal fired  plants  at -

generating electricity (the global average efficiency of gas-fired plants is 47%, while for coal fired plants, it is 37%). -

Around 99% of the LNG consumed in 2025 had fewer life cycle emissions than coal. -The choice of global warming potential (GWP) used to convert methane to CO2 -eq has some impact on this share, but it does not change the overall picture. When using a 20 year GWP rather than a 100 year GWP, we estimate that more than 90% --of the LNG consumed in 2025 still has lower life cycle emissions than coal. -

Nonetheless, comparing LNG only with coal sets the bar too low. Minimising the GHG emissions intensity of LNG remains essential; it is not enough simply to outperform the most carbon intensive fuel. -

Figure 10  Estimated life-cycle  GHG  emissions  intensities  of  LNG  and  coal, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: GWP20 = 20-year global warming potential; g CO2-eq/MJ = grammes of carbon dioxide equivalent per megajoule. Source: IEA estimates (see Technical annex and Global Methane Tracker 2026 Documentation).

## Chapter 2: Emissions reduction opportunities and costs

## Summary

Large  emissions  reductions  across  the  LNG  supply  chain  are  technically achievable today. Many measures can be implemented at low or moderate cost. Reducing  methane  emissions  is  the  single  most  important  and  cost effective -opportunity to lower overall emissions from LNG supply. Other options include electrification  using  low emissions  electricity,  energy  efficiency  improvements, -carbon  capture,  utilisation  and  storage  (CCUS),  and  the  elimination  of  routine flaring (Figure 11). This section focuses on the opportunities and costs of the direct emissions reduction measures in each area. We estimate that implementing all identified  measures  could  avoid  around  200 Mt CO2 -eq  of  GHG  emissions  per year, equivalent to about 50% of total emissions from the LNG supply chain.

Figure 11 Annual LNG emissions reduction potential and global average cost of abatement by selected measure, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: Cost of emissions reductions can vary widely between basins, LNG facilities and countries; CO2 abatement costs shown are global averages weighted by production. Electrification assumes either a grid connection supplied by lowemissions electricity or a dedicated renewable electricity installation. CCUS estimates are based on capturing pure streams of naturally occurring CO2 (rather than post-combustion emissions) and injecting them into a nearby basin. One tonne of methane is assumed to be equivalent to 30 t CO2 based on a 100-year global warming potential (IPCC, 2021). Source: IEA estimates based on scientific literature and the latest available data, including measured, satellite and inferred data. Data availability and quality vary widely across basins, countries and regions. For methane emissions in countries with no data availability, emission intensities are estimated using data from the United States, scaled to account for country- and production-specific factors (see the Technical annex and Global Methane Tracker 2026 Documentation for further information).

Abating methane emissions using processes such as leak, detection and repair (LDAR) programmes, installing vapour recovery units or using associated gas can cut emissions by about 80 Mt CO2 -eq annually across upstream and downstream natural gas operations. Reducing flaring at LNG facilities and fields supplying feed gas could lower annual emissions by a further 5 Mt CO2-eq. Upfront investment is needed  to  deploy  methane  abatement  measures,  but  many  of  these  provide sufficient gas savings over their lifetimes to cover the required outlays. As a result, around half of methane emissions from LNG supply could be abated at no net cost. However, the deployment of cost effective measures is often constrained by -practical  and  commercial  barriers,  including  limited  awareness  of  emissions sources, competing investment priorities, split incentives and contractual arrangements, upfront capital requirements, workforce constraints, and uncertainty over how to bring recovered gas to productive use.

The  electrification  of  upstream  facilities  and  LNG  terminals,  and  the  use  of low emissions electricity to power these, would significantly reduce the emissions -associated with liquefying and compressing natural gas. Several electrified LNG facilities have already been established, although electrifying some existing LNG facilities may be challenging, particularly those that are nearing the end of their technical lifetime. In total, we estimate that electrification of a selection of LNG liquefaction terminals, based on an assessment of the feasibility of connecting to grids or generating low-emissions electricity, could cut annual GHG emissions by around  40 Mt CO2 eq.  In  addition,  more  than  40%  of  upstream  natural  gas -production  sites  that  feed  LNG  terminals  are  near  an  electricity  grid,  and, depending  on  economic  and  technical  factors such  as grid access  and reinforcement  needs,  electrifying  these  facilities  is  also  an  option  to  reduce emissions. Doing so could cut another 50 Mt CO2 -eq. The savings calculated here account for cases where the average grid emissions intensity is significantly below that of the natural gas-based power generation technology currently used at LNG facilities and in upstream operations.

The use of CCUS is under way across parts of the LNG supply chain, as naturally occurring  CO2  is  already  separated  during  processing,  especially  at  integrated LNG project sites. In addition, regulatory frameworks in some producer countries are  beginning  to  incentivise  CCUS  deployment.  Our  analysis  indicates that  an additional 15 Mt CO2 could be captured annually from liquefaction plants in the form of naturally occurring CO2, in addition to the 15 Mt CO2 per annum of projects that  are  already  existing  or  under  development,  at  an  average  cost  of  around USD 50/t CO2 eq, assuming the availability of a nearby storage formation. Sharing -lessons learned and experiences from the establishment and operation of routine and at-capacity gas capture and injection systems will be key to maximise the benefits of this technology.

We estimate  that  the  upfront  capital  investment  required  to  electrify  upstream operations supplying a selection of LNG terminals would be around USD 70 billion,  while  electrifying  operations  at  a  selection  of  existing  LNG terminals  would  cost  around  USD 55 billion.  Around  USD 8 billion  of  additional investment would be required to deploy CCUS to capture naturally occurring CO2 from natural gas produced from fields with high CO2 concentrations, for projects which do not already have plans to do so, while deploying all methane abatement and flaring reduction measures would cost just over USD 5 billion.

Implementing all available measures could avoid a total of 200 Mt CO2 -eq/year and would have a weighted-average abatement cost of USD 60/t CO2. Globally, this  would  add  around  USD 0.2-1.50/MBtu  to  the  delivered  cost  of  LNG  from existing facilities, depending on the pathways chosen. Integrating such measures into  new  greenfield  LNG  projects  during  the  front end  engineering  and  design -(FEED)  phase  would  likely  be  less  costly  than  retrofitting  existing  facilities (Figure 12).

## Figure 12 Toolkit of opportunities and costs to reduce emissions from across the LNG supply chain, 2025

<!-- image -->

| Lever                               | Production and processing                                           | Transmission                                                            | Liquefaction                                                           | Shipping                                                                 | Regasification                                                         | Abatement potential   | Cost of implementation   |
|-------------------------------------|---------------------------------------------------------------------|-------------------------------------------------------------------------|------------------------------------------------------------------------|--------------------------------------------------------------------------|------------------------------------------------------------------------|-----------------------|--------------------------|
| Methane abatement                   | LDAR; VRU; blowdown capture; combustion optimisation                | LDAR; blowdown capture; predictive maintenance; compressor optimisation | BOG recovery; dry-seal compressors; operational optimisation           | Low methane-slip engines; methane oxidation catalysts; load optimisation | BOG recovery; VRUs; improved tank pressure management                  |                       |                          |
| Flare reduction                     | Gas re-utilisation; flare-tip upgrades; flare efficiency monitoring | Blowdown capture                                                        | Operational optimisation and start-up planning; flare monitoring       | Not applicable                                                           | Blowdown capture                                                       |                       |                          |
| Efficiency                          | Operational optimisation; turbine upgrades; autonomous control      | Compressor optimisation; pipeline flow optimisation; internal coatings  | Turbine upgrades; efficient refrigeration cycles; waste heat recovery  | Slow steaming; optimised ship design and operations; hull maintenance    | Efficient regasifiers; waste heat integration; cold energy utilisation | -                     | -                        |
| Electrification                     | Electrified field and processing equipment                          | Electric-drive compressors                                              | Electric-drive compressors; replacement of onsite gas-fired generation | Emerging technology: hybrid propulsion systems                           | Electric vaporisers; electrified pumps and terminal utilities          | -                     | -                        |
| CCUS                                | Capturing naturally occurring CO ₂ from gas processing              | Not applicable                                                          | Capturing naturally occurring CO ₂ ; post-combustion capture           | Emerging technology: onboard carbon capture systems                      | Not applicable                                                         | -                     | -                        |
| Share of LNG supply chain emissions | 40%                                                                 | 11%                                                                     | 33%                                                                    | 15%                                                                      | 1%                                                                     |                       |                          |

Widely applicable to existing facilities

Applicable to some existing facilities

Primarily suited to new facilities

Abatement potential ranges: = low (&lt; 10 Mt CO2-eq) Cost of implementation: = low (&lt; USD 10/t CO2-eq)

= moderate (10-50 Mt CO2-eq)

= high (&gt; 50 Mt CO2-eq)

= moderate (USD 10-100/t CO2-eq)

Notes: LDAR = leak detection and repair; VRU = vapour recovery units, BOG = boil off gas

= high (&gt; USD 100/t CO2-eq)

IEA. CC BY 4.0

## Reducing methane emissions

In total, we estimate that 4 Mt of methane was emitted across the LNG supply chain in 2025 (around 10% of total methane emissions from natural gas operations globally). Upstream operations accounted for around 70% of these emissions, with natural  gas  transmission,  LNG  liquefaction,  shipping  and  other  downstream operations responsible for the remaining 30% (Figure 13).

Figure 13 Share of methane emissions across the LNG supply chain, 2025

<!-- image -->

IEA. CC BY 4.0.

Source: IEA estimates based on measured, satellite and inferred data (see the Technical annex and Global Methane Tracker 2026 Documentation for further information).

Many  technologies  are  now  available  to  reduce  these  emissions  (Figure  14). Examples include standard leak detection and repair programmes, replacing gasdriven  controllers  and  other  methane emitting  equipment  with  electric  devices, -using vapour recovery units to capture low-pressure gas that would be vented, and  capturing  gas  during  blowdowns  when  equipment  is  depressurised  rather than venting it. Some measures require minimal investment and can be deployed quickly  by  operations  staff,  including improving  combustion  efficiency  through enhanced monitoring, maximising plant reliability through predictive maintenance, and optimising operations to minimise losses (Figure 15).

In  LNG  facilities,  boil off  gas  can  often  be  recovered  using  units  that  can  be -installed  relatively  easily,  even  at  existing  facilities.  Automated  air/fuel  ratio controls can improve the combustion efficiency of natural gas-powered engines and  turbines,  and  nitrogen  can  replace  natural  gas  where  flare  systems  are continuously  purged.  LDAR  programmes  can  reduce  unintentional  emissions, while measures such as using compressors with dry seals can reduce emissions during normal operations. Several additional measures are available to address

emissions  from  utilities,  storage,  pumps  and  other  equipment  present  at  LNG facilities. Minimising the number  of  start ups, -alongside other operational improvements, can also help reduce emissions.

Methane  emissions  from  shipping  can  also  be  minimised.  Measures  include avoiding low engine loads and implementing cylinder deactivation during low-load operation. Other options include improving operational controls, such as process control, variable valve timing, gas metering and optimal air/fuel ratios, or using engine designs that minimise methane slip. Efforts are also under way to deploy methane oxidation catalyst systems that can further reduce methane slip.

<!-- image -->

IEA. CC BY 4.0.

Notes: LDAR = leak detection and repair; VRU = vapour recovery units. 'New processes and equipment' includes blowdown capture, routing vents to recovery systems, measures to improve combustion efficiencies, and retrofitting ships to use engines with lower methane emissions.  Replace leaky equipment  includes instrument air " " systems, electric pumps, and other measures that involve replacing existing equipment. One tonne of methane is assumed to be equivalent to 30 t CO2 based on the 100-year global warming potential (IPCC, 2021).

Source: IEA estimates based on measured, satellite and inferred data (see the Technical annex and Global Methane Tracker 2026 Documentation for further information).

We  estimate  that  deploying  all  methane  abatement  technologies  currently available  across  the  LNG  supply  chain  would  reduce  methane  emissions  by around 70% from 2025 levels. Overall, we consider production and emissions from around  51  upstream  basins  supplying  feed  gas  for  LNG  exports.  Emissions intensity of delivered LNG would fall from around 0.7% to 0.2%, and the average downstream methane emissions intensity would fall from around 0.3% to 0.1%. 7

7 Downstream methane emissions intensity is calculated here as methane emissions from transmission, liquefaction, shipping and regasification divided by natural gas delivered to the regasification terminal, assuming methane has an energy density of 55 MJ/kg.

Figure 15 Marginal abatement cost curve for reducing methane emissions from the LNG supply chain by abatement measure, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: Other includes green completions, pipeline pump-down before maintenance, installing methane-reducing catalysts and retrofitting LNG carriers with engines that minimise methane slip. One tonne of methane is assumed to be equivalent to 30 t CO2 based on the 100-year global warming potential (IPCC, 2021).

Source: IEA estimates based on measured, satellite and inferred data (see the Technical annex and Global Methane Tracker 2026 Documentation for further information).

More than 80% of upstream LNG flows comes from companies that are members of  the  Oil  and  Gas  Methane  Partnership  2.0,  a  measurement-based  reporting framework  for  the  oil  and  gas  industry  (see  Chapter  3).  Several  member companies  of  the  partnership  already  report  upstream  methane  emissions intensities of much less than 0.1%.

## Box 5 Industry efforts to reduce methane emissions across the LNG supply chain

Several companies across the LNG supply chain are deploying measurement-based monitoring  and  targeted  operational  upgrades  to  reduce  methane  emissions.  For example,  Cheniere  Energy  conducted  detailed  measurement  campaigns  at  its liquefaction facilities and set an operational methane emissions intensity target of 0.03% per tonne of LNG produced across its two US Gulf Coast liquefaction facilities. At  the  transmission  and  regasification  stage,  Enagás  has  reduced  emissions intensity by eliminating gas-driven pneumatic  devices, installing boil-off gas compressors at regasification plants and deploying electric pumps.

Similar approaches  are  being  implemented  upstream  and  at  gas-processing facilities.  At  Shell,  methane  emissions  from  assets  under  its  operational  control declined by 78% between 2016 and 2025, supported by enhanced leak detection and repair programmes, improved flaring efficiency and operational improvements. At the company's Groundbirch natural gas operation in British Columbia, upgrades

such  as  electrifying  processing  equipment,  replacing  gas-driven  pneumatics  and deploying  continuous  leak  detection  systems  have  further  reduced  operational emissions. More broadly,  the  natural  gas  that  supplies  Canada's  LNG  exports  is produced under increasingly stringent methane regulations. With the deployment of technologies  such  as  multi-well  facilities  and  advanced  leak  detection  and  repair programmes,  these  measures  support  Canada's  ambition  to  reduce  methane emissions from the oil and gas sector by 75% below 2012 levels by 2030.

Likewise, Petronas has reported a reduction of around 60% in methane emissions across  its  natural  gas  value  chain  in  2024  relative  to  2019  levels,  supported  by measures  such  as  the  elimination  of  venting  through  vent-to-flare  projects  and upgrades to acid gas removal units. These reductions align with Malaysia's methane mitigation  efforts under  the  Global  Methane  Pledge  and  associated  national initiatives.

Together,  these  examples  show  how  combining  improved  measurement  with targeted  operational  improvements  can  deliver  substantial  methane  reductions across the LNG supply chain.

## Reducing flaring

There  are  many  options  to  use  natural  gas  that  would  otherwise  be  flared, including by transporting it to consumers through new or existing gas networks, reinjecting it to support reservoir pressure, or converting it to LNG (Figure 16). The gas can also be used to generate power, potentially in facilities equipped with CCUS to reduce emissions.

Methane  emissions  from  flares  should  be  minimal  when  they  are  properly designed, maintained and operated. However, this is not always the case, and higher  emissions  can  occur  due  to  factors  such  as  weather  and  changes  in production  rates.  Occasionally,  an  active  flare  may  be  extinguished  entirely, resulting  in  the  direct  venting  of  methane  gas  to  the  atmosphere  instead  of combustion.  This  also  poses  a  major  health  and  safety  risk.  We  estimate  that flares have a global average combustion efficiency of around 90%, significantly lower than the commonly assumed value of 98%.

Figure 16 Marginal abatement cost curve for reducing flaring emissions along the LNG supply chain by exporting country, 2025

<!-- image -->

Notes: Does not include avoided methane emissions. Abatement options include new gas pipelines or pipeline connections, mini-compressed natural gas and mini-LNG technologies, gas-to-power projects, and re-injection, as outlined in previous IEA analysis. Other includes Angola, Cameroon, Congo, Egypt, Equatorial Guinea, Mauritania, Mozambique, Norway, Peru, Rest of Asia, and Trinidad and Tobago.

Source: IEA analysis including data from the World Bank global gas flaring report.

Technologies and maintenance practices can improve the efficiency of existing flares. For example, modern flare tip designs improve fuel-air mixing and achieve higher  combustion  efficiencies,  significantly  reducing  emissions  resulting  from incomplete combustion.

Flaring reduction projects can face many barriers, including lack of infrastructure, contractual terms that prevent natural gas savings from affecting revenues, and information gaps regarding flared volumes and characteristics (for example, the share of flaring that is routine). In the LNG supply chain, most flaring reduction options would have a net positive cost in the absence of regulatory requirements. Small flared volumes can make it difficult to recover investment costs through new infrastructure development or gas transport. Reducing flaring at offshore facilities is often even more challenging because of space and weight constraints, as well as higher investment requirements.

Nevertheless,  several  measures  require  little  investment  and  are  often  costeffective.  These  include  better  planning  of  commissioning  and  maintenance activities  to  avoid  flaring  during  facility  start-ups,  as  well  as  operational  and equipment optimisation to reduce process upsets and flaring. Measuring actual flare destruction  efficiency  during  maintenance  activities  can  provide  more accurate data to evaluate the benefits of flaring reduction measures.

## Increasing process efficiency

## Production and processing

A  large  portion  of  the  energy  required  at  upstream  facilities  is  used  to  power electrical equipment.  This  electricity is often generated  using  small-scale, inefficient on-site diesel or natural gas generators. Electrifying field equipment and ensuring it is well maintained are often the most effective ways to improve the efficiency of field operations (discussed in detail in the next section).

Optimising  well  performance  can  reduce  energy  use  during  production  while increasing throughput by up to 25%. This can be achieved, for example, through autonomous well-control systems that respond dynamically to reservoir pressure. These systems are commercially available, but their use requires a high degree of digitalisation, including real-time sensors, data connectivity and skilled personnel.  Opportunities  are  typically  concentrated  at  larger  fields,  and  we estimate that the practical applicability of these tools is limited to about 30% of LNG-linked  upstream  assets  in  operation  today.  For  these  assets,  based  on information received from industry and service providers, upfront investment is around  USD 100-500 thousand  per  well  pad  and  USD 50-200 thousand  for subsequent deployments, with a payback period of a few months at a gas price of USD 3/MBtu.  In  less  digitally  mature  fields,  upfront  investment  can  rise  to USD 1-5 million, depending on operational complexity, while potentially delivering larger efficiency gains.

Using more efficient equipment, such as combined-cycle rather than open-cycle gas turbines at sufficiently large greenfield gas processing plants, and operating is closer to full load can reduce energy requirements by about 30%. Our analysis suggests that such upgrades typically have a payback period of five to eight years. However, deployment is often constrained by the availability of capital for the initial investment, as well as supply chain, site-specific and operational limitations.

## Transmission

Transmission includes pipelines, gathering and boosting stations, and compressors  stations.  Efficiency  improvements  can  be  achieved  by  optimising compressor performance and improving gas flow through pipelines.

Compressor stations typically consume 3 to 5% of the transmitted gas as fuel. Load optimisation and AI-based control tools can reduce consumption by over 5% by improving compressor operating profiles. Based on information provided by service  providers,  AI solutions  for  gas  turbines  can  achieve  payback  times  of about 2 years in medium-sized gas transmission systems (1 bcm/y) at negative abatement costs.

Transporting oil and gas from the point of extraction to processing facilities can consume up to 7% of the produced energy, depending on fluid characteristics, flow regime, pipeline diameter and transport distance. Internal pipeline coatings can cut energy consumption in gas transmission by up to 50% by improving flow efficiency,  as  well  as  reducing  maintenance  costs.  We  estimate  that  internal coatings in greenfield gas transmission pipelines can achieve payback times of around two to three years. However, costs and benefits vary over a wide range, depending on material  costs,  application  methods,  pipeline  size  and  operating conditions,  and  additional  services  like  inspection  and  testing.  Despite  limited deployment  data,  this  technology  is  considered  standard  practice  for  new pipelines in North America and Europe but is less common in regions with large legacy assets, where retrofits face economic and operational constraints.

Good  flow  assurance  practices  can  also  improve  performance.  Examples include preventing hydrate plugs that can lead to increased flaring or emergency venting, and keeping pipelines clean through regular pigging. These solutions are applicable across a range of pipeline operations and are particularly effective in long-distance transport and regions with a high risk of hydrate formation.

## Liquefaction

Liquefaction is the most energy-intensive process in the LNG supply chain, with energy use dominated by turbines driving refrigeration compressors and by power generation for plant operations. Fuel consumption can be reduced through several measures,  including  higher-efficiency  turbines,  mixed  refrigerant  or  multicycle refrigeration  processes, and improved heat integration through the use of heat pumps,  cold adsorption units and gas turbine air chilling systems. Full electrification of liquefaction facilities, which can deliver larger efficiency gains, is discussed in the following section.

Turbine choice for a new LNG facility is typically determined by a combination of factors, including the refrigeration process and train size, feed gas characteristics, site  conditions,  operational  considerations  (such  as  availability,  reliability  and maintenance philosophy), and project-specific factors such as experience, knowhow  and  available  equipment  inventories.  As  a  result,  feasibility  of  efficiency upgrades varies significantly across process configurations and between greenfield developments and brownfield retrofits.

The choice of refrigeration process strongly influences driver selection. Cascade processes are multi-cycle and can be applied across a range of plant scales. In current LNG developments, C3MR and other multi-cycle concepts are widely used in  mid-to-large  scale  trains  with  higher  power  requirements,  while  SMR  or expansion-based processes are more commonly used in smaller-scale applications. Smaller trains may often favour aeroderivative solutions (subject to

site conditions and maintenance constraints), while higher-demand configurations tend to favour heavy-duty industrial gas turbines, although aeroderivative turbines can also be applied in large-scale trains depending on project-specific conditions.

Heavy-duty simple-cycle industrial gas turbines typically operate at efficiencies of 30-48%  which  can  be  increased  to  above 60%  with  the  addition  of  combined cycles. Aeroderivative turbines offer simple-cycle efficiencies of up to around 45% and combined-cycle efficiencies of up to around 56%, alongside faster start-up times, improved turndown and smaller footprint. These advantages are offset by lower power output per unit, greater sensitivity to high ambient temperatures, and more frequent maintenance requirements.

For  new  LNG facilities,  installing  aeroderivative  turbines  instead  of  heavy-duty industrial  turbines  generally  requires  broader  changes  to  facility  and  system design,  increasing  capital  costs  beyond  the  turbine  equipment  itself.  Indicative estimates suggest that the incremental investment of around USD 40-70 million per train  can  often  be  recovered  within  a  few  years  through  reduced  fuel  use, resulting  in  slightly  negative  abatement  costs  under  favourable  fuel  prices  and operating conditions.

At  existing  facilities,  replacing  legacy  gas  turbines  with  aeroderivative  units  is typically  logistically  complex  and  capital  intensive.  Such  retrofits  require  civil works, new  infrastructure, system integration, and can involve extended shutdowns that affect revenues and contractual obligations. Indicative abatement costs are therefore higher, typically in the range of USD 65/t CO2 to USD 95/t CO2, depending on train size and plant complexity. Costs could increase substantially where the required shutdown period exceeds six to eight weeks.

Improved  heat  integration  provides  an  additional  efficiency  lever.  Gas  turbine exhausts  generate  waste  heat  streams  at  roughly  400-600 °C  that  can,  where layout and operating conditions permit, be recovered for process duties such as regeneration and reboiler services. While some LNG plants already incorporate heat recovery, others face design or operational constraints that limit integration potential. Under favourable conditions, experimental studies suggest that additional  heat  integration  could  reduce  fuel  use  by  around  17%  with  payback periods  of  just over  two  years  compared  with  conventional  systems  with compressor-based precooling systems. The actual benefits may vary depending on operational conditions, and  the available evidence  remains  limited to experimental and techno-economic studies.

For greenfield projects, mixed-refrigerant cycles (such as DMR or C3MR) can reduce energy use by roughly 5-15% relative to SMR processes, albeit at higher upfront cost and technical complexity. These configurations are most effective in baseload  plants  with  sufficient  scale,  flexible  refrigerant  requirements  and opportunities  for  waste  heat  recovery.  SMR  processes  are  often  selected  for

modularised LNG facilities because of their lower project execution risks in terms of cost, schedule and quality.

## Shipping

A wide range of technical and operational levers to improve the energy efficiency of LNG-carrying ships are in advanced stages of deployment today (IEA, 2024). These  range  from  optimised  ship  designs  to  operational  measures  related  to cruising speed and hull maintenance (Table 2). The measure with the greatest impact  is  slow  steaming  (reducing  a  vessel's  cruising  speed),  which  has accounted for around two-thirds of the efficiency improvements achieved by LNG carriers since 2008.

Table 2 Selected fuel-efficiency measures for LNG-carrying ships

| Efficiency measure         | Fuel savings potential                                                                                           | Capital expenditure                                                                     | Payback period                                                | Remarks                                                                                                                                                                                                                                     |
|----------------------------|------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------|---------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Slow steaming              | A 10% reduction in cruising speed can reduce fuel consumption by up to 20% (accounting for longer sailing times) | Near zero                                                                               | Immediate                                                     | Largest fuel-saving measure at minimal cost; no new technology deployment required, although reducing cruising speeds lower carrying capacity (which may be partly offset through just-in-time arrivals and reduced waiting times at ports) |
| Operational improvements   | Up to 6% per technology                                                                                          | USD 100-500 thousand per application for dynamic route optimisation                     | 1-2 weeks to months                                           | Includes trim and draft optimisation and autopilot upgrades                                                                                                                                                                                 |
| Hydrodynamics improvements | 3-10% per technology                                                                                             | USD 50-600 thousand for antifouling nano- coatings, USD 1-3 million for air lubrication | Less than 4 years for coatings, 3-7 years for air lubrication | Available technologies also include improved hull designs and pre- and post-swirl devices                                                                                                                                                   |
| Auxiliary systems          | Up to 2%                                                                                                         | USD 50-100 thousand for systems with low to moderate complexity                         | Less than 2 years                                             | Involves the optimisation of cooling water systems, heat exchangers, heating and ventilation systems                                                                                                                                        |
| Wind assistance            | Up to 10%                                                                                                        | USD 0.5-3 million per ship                                                              | 2-16 years depending on type                                  | Orders are increasing, although deployment in LNG shipping has been limited to date                                                                                                                                                         |

Source: IEA (2024), Energy Technology Perspectives 2024 (Annex C).

Several of these technologies make economic sense for shipowners and can be combined to deliver energy savings of more than 20% (Figure 17). This would lower per-ship costs by about USD 3 million per year, reduce the total cost of ship ownership by up to 10%, and achieve a payback period of less than five years, all assuming an LNG price of USD 10/MBtu.

The International Maritime Organization (IMO) has incentivised energy efficiency improvements  in  shipping  through  the  Energy  Efficiency  Existing  Ship  Index, which requires ships to meet minimum emissions intensity standards by adopting higher-efficiency  technologies.  It has  also  introduced  the  Carbon  Intensity Indicator  rating,  which  evaluates  operational  emissions  per  cargo  mile  and incentivises measures such as hull cleaning and speed optimisation to improve energy  efficiency.  The  IMO  has  proposed  a  framework  to  reduce  shipping emissions  to  net zero  by  around  2050,  although  detailed  implementation measures remain under negotiation. The proposal includes a goal-based marine fuel  standard  and  a  global  carbon  pricing  mechanism.  The  European  Union extended the EU Emissions Trading System to the maritime sector in 2024 and implemented  the  FuelEU  Maritime  regulation  in  2025,  increasing  emissionsrelated costs for EU-linked LNG shipping.

Figure 17   Marginal cost of efficiency improvements for a typical LNG-carrying ship

<!-- image -->

IEA. CC BY 4.0.

Notes: MBtu = million British thermal units. Assumes an LNG carrier of 160 000 cubic metres of capacity built in 2025. Energy savings are calculated over the 20-year lifetime of the ship. Operational improvements include trim and draft optimisation, autopilot upgrade; Hydrodynamics include hull shape optimisation, pre- and post-swirl devices, nano-coating, air lubrication; Auxiliary systems includes optimisation of cooling water systems, heat exchangers, heating and ventilation systems.

Source: IEA analysis based on data from IMO Global maritime energy efficiency partnership, US Department of Transportation, DNV.

## Regasification

The choice of regasification technology is highly dependent on geography and capacity  requirements,  but  it  also  carries  major  implications  for  operational emissions and efficiency. Most LNG terminals worldwide use ORVs, which rely on seawater or ambient air to warm LNG back to its gaseous state. These systems perform well in warmer climates and have inherently low emissions because they operate  without  fuel  combustion.  Their  main  drawback  is  environmental:  the discharge of cold seawater can be restricted in sensitive marine areas.

SCVs  are  the  leading  alternative.  They  offer  reliable performance  across geographies, particularly in cold regions. However, SCVs burn natural gas to heat LNG, consuming roughly 1.5% of the regasified stream and generating associated CO2 emissions.

Brownfield  projects  can  upgrade  vaporiser  technology  as  part  of  efficiency improvement programmes. One example is the Ulysse Project in France, where ageing SCVs are being refurbished and replaced by ORVs that use seawater and industrial waste heat. This transition is expected to reduce emissions by 25% per year, at a cost of approximately EUR 200 million over five years.

Beyond the choice of vaporiser, the main opportunities for improving regasification efficiency are waste heat integration and cold energy utilisation. Where terminals are located near low-grade heat sources - such as exhaust gases from floating storage and regasification units, steam from power plants, or residual heat from industrial processes  -  this  thermal  energy  can  be  reused  to  reduce  gas combustion in the vaporisation process. Integrating waste heat with SCVs could avoid  emissions  by  potentially  reducing  fuel  use  by  up  to  25%.  Cold  energy utilisation involves capturing the cryogenic energy of LNG during regasification for industrial use and power generation, and some onshore terminals already deploy such systems (see Box 6).

## Box 6 Cold Energy Recovery

LNG is stored and transported at approximately -162°C. Warming it up to a gaseous state  at  around  +5°C  creates  a  powerful  cooling  effect  that  can  be  captured  and reused. There are several technologies available that can make use of this cooling, which  can  help  reduce  energy  use  and  emissions  while  providing  an  additional source of revenue for LNG operators. Although the global potential is considerable, less than 1% is currently utilised. Examples of operating projects include:

-  The Senboku and Himeji regasification terminals in Japan, where Daigas has operated  cryogenic  cold  energy  recovery  systems  for  several  decades.  In

addition to cryogenic power generation at the terminals, Daigas supplies cooling to nearby factories and chemical plants, which return warmed fluid to the terminal, reducing Daigas' power demand for regasification.

-  The  Barcelona  and  Huelva  regasification  terminals  in  Spain,  where  Enagás operates cryogenic cold recovery units that deliver cooling services to customers up  to  around  six  kilometres  from  each  terminal.  In  Barcelona,  a  15 MW installation comprising five modular heat-exchanger loops supplies cooling to a nearby district cooling network. In Huelva, an initial 4 MW loop under construction will  serve  the  refrigeration  needs  of  food-processing  industries  within  the  port area.

The  commercial  viability  of  cold  energy  recovery  depends  on  several  structural factors. These include the terminal type, as cold energy recovery is generally better suited to onshore terminals because floating storage and regasification units face greater space constraints; the utilisation rate, as projects perform best at baseload terminals operating at consistently high throughput; and proximity to cooling demand, which provide an additional revenue stream and improve project economics.

## Electrification

Electrification offers a major opportunity to reduce the emissions from energy used in upstream and liquefaction facilities. In most cases, it would also improve energy efficiency.  If low-emissions  electricity  is  used,  it  would  significantly  reduce emissions.

## Production and processing

Around 40% of natural gas production sites that are mostly dedicated to feeding LNG terminals lie within 10 km of an electricity grid, and 75% are in areas with good wind or solar resources. Energy needs at upstream facilities could therefore be  met  through  grid  electricity  or  through  decentralised  renewable  energy systems.  Norway's  Equinor  has  led  efforts  to  electrify  upstream  oil  and  gas operations, with grid connections or dedicated offshore wind installations being integral parts of its plan to reduce emissions by 70% from Norway's Continental Shelf production by 2040 (although the company recently cancelled some plans for  electrifying  upstream  assets).  BP  has  electrified  a  substantial  portion  of  its assets in the Permian Basin in Texas. Shell is electrifying part of its gas processing assets feeding LNG Canada. Batteries have been deployed in Australia to reduce the need for back-up gas capacity. However, there are few examples of largescale actions being taken by other oil and gas producers, especially for existing assets.

Policy  or  regulatory  incentives  may  be  necessary  to  stimulate  the  required upfront investment. These could take the form of a CO2 price, which provided the  spur  for  development  in  Norway,  or  of  tax  breaks  and  exemptions  on  a portion of electricity tariffs. Costs could be reduced if operators collaborate to build  shared  clean  electricity  infrastructure  that  would  feed  wider  areas  of production (e.g. recent efforts by companies operating in the North Sea). Project economics could also be improved by crediting avoided CO2 or selling surplus renewable electricity back to the grid.

We estimate that around USD 70 billion of upfront investment would be required to electrify existing upstream assets that provide feed gas through dedicated grid connection or decentralised renewable system. This assessment excludes assets that are impractical to fully electrify, such as those requiring substantial amounts of heat and those located far from electricity grids or in areas with limited solar or wind resources. Doing so would avoid around 50 Mt CO2 per year at a weighted average abatement cost of around USD 130/t CO2 (adding around USD 0.8/MBtu to the delivered cost of LNG).

There are also electrification opportunities further downstream from the upstream assets feeding the LNG value chain, for example, by replacing gas turbine-driven compressors on large transmission pipelines with electric motors. Several projects have  already  been  implemented.  For  instance,  parts  of  the  United  Kingdom National Transmission System already use electrically driven compressors, while pipeline  operators  in  North  America  and  Europe,  including  TC  Energy  and Enbridge,  have  announced  or  implemented  electric-drive  compressor  projects where suitable grid connections are available. Costs are highly site-specific and depend particularly on compressor capacity and the extent of electrical and gridconnection  infrastructure  required.  As  an  indication  of  scale,  Northern  Border Pipeline's Chicago III project, which included installation of a new 12 MW electricdrive compressor and modifications at two existing compressor stations, cost USD 21  million. New-build  electric-drive  compressor  stations  are  generally  cost competitive with gas-turbine alternatives where high-voltage electricity is readily available.

## Liquefaction

The  main  options  for  electrifying  LNG  liquefaction  terminals  are  to  replace  or complement on-site gas turbines for power generation with renewable energy and battery storage systems, or with a grid connection where low-emissions electricity is available, and to replace mechanical gas turbines used for compression with electric motors. Emissions reductions arising from electrifying operations can vary depending on the solution chosen.

LNG  facilities  require  electricity  for  a  range  of  different  processes,  primarily compression (if not using mechanical gas turbines), as well as vapour and boil-off

handling systems, control systems, heating, ventilation and air conditioning, and loading  and  berthing  systems.  Replacing  on-site  gas  turbine  power  generation with renewables  and  battery  storage  systems,  or  with  low-emissions  grid electricity, could significantly reduce these emissions while also improving energy efficiency.

Hammerfest in Norway and Freeport LNG in the United States have, so far, been the major all-electric LNG plants. Hammerfest LNG has electrified its compressors but continues to use natural gas to power them. It is planning to develop a grid connection  to  draw  power  from  Norway's  hydro-dominated  electricity  mix. Freeport LNG, which was commissioned in 2019, secured a grid connection to supply  675 MW  of  power  capacity  to  drive  its  compressors.  This  enabled  a 90% reduction  in  site  combustion  CO2  emissions  and  a  net  LNG  production increase of 6.5% relative to a design based on traditional gas turbines.

Interest in all-electric LNG terminals has been growing. Woodfibre LNG, currently under construction, will be the first electrified facility  in  Canada.  In  2024, three sanctioned LNG export projects announced plans to be fully electrified: Ruwais LNG in the United Arab Emirates, which plans to run on renewable and nuclear grid power, Cedar LNG in Canada, which plans to use grid electricity, and Marsa LNG in Oman, which is constructing a dedicated 300 MW solar photovoltaic (PV) plant.

Electrifying  existing  LNG  terminals  can  involve  significant  costs  and  requires site-specific assessments of technical feasibility, as it may involve trade-offs. Initial capital expenditure can be high, and operators may be hesitant given the potential revenue loss and operational downtime associated with the conversion process. Electric  transmission upgrades are also often required as LNG export facilities typically require a high electrical load.

LNG  operators  face  several  choices  when  implementing  an  electrification programme, including selecting the technology and design for compression, and the appropriate strategy for procuring power supply. For projects pursuing a grid connection, costs vary depending on factors such as distance to the power grid, level  of  reinforcement  required  and  contractual  conditions,  including  the  power purchase price and grid stability. For projects building dedicated power generation capacity,  it  is  important  to  ensure  a  continuous,  reliable  source  of  energy  to maintain  operations  and  ensure  safety.  Options  include  complementing  gas turbines with variable renewable sources such as solar PV or wind and potentially adding  battery  capacity  in  a  hybrid  system  configuration.  Avoided  gas  use, emissions reductions and associated regulatory compliance benefits can then be factored into the economic assessment.

We  estimate  that  around  70%  of  LNG  liquefaction  terminals  worldwide  could potentially be electrified using low-emissions electricity. A geospatial assessment

of proximity to electricity infrastructure and solar and wind potential indicates that these facilities are either located within 10 kilometres of an electricity grid or in areas with favourable renewable energy resources. However, offshore terminals and facilities more than 15 years old are excluded from the assessment because of the higher costs and technical challenges associated with large-scale retrofits. This  leaves  around  400  bcm/year  of  LNG  liquefaction  capacity  that  could potentially be electrified. To calculate the marginal abatement cost of doing so, we consider the following:

On-site retrofit costs: We assume electricity demand of around 200-400 kWh/t LNG output,  and  that  a  conversion  would  require  new  electric motors  and  power  supply  infrastructure  (e.g. substations),  process  conversion (e.g. replacing  compressors,  re-engineering  shaft  lines,  optimising  refrigerant cycles),  and  additional  civil  works.  The  capital  costs  of  the  required  plant modifications  vary  according  to  the  LNG  technology  and  the  current  plant configurations; for brownfield conversions, incremental retrofit costs are assumed to be in the range of USD 20-60 per tonne per annum of LNG plant capacity.

Grid  connection  or  solar  plus  battery: A  least-cost  approach  is  used  to determine whether a grid connection or on-site power generation is the preferred option,  with  the  key  input  assumptions  for  grid  connection  being  power  prices (averaging USD 75/MWh), distance to existing grid (with an average investment cost of USD 1.4 million per km), and level of grid reinforcement required (calculated through a spatially-resolved grid density function, averaging around USD 80/kW). For on-site power generation, it is assumed that solar capacity is oversized by a factor of 3-4 relative to plant load to account for capacity factors, and  battery  storage  is  assumed  to  provide  8 hours  of  firming  to  maintain continuous plant operation; around 20% of gas capacity is retained for back-up purposes. There is likewise a very wide range in capital costs; off-grid solutions are  much  more  capital  intensive  whereas  grid  connections  have  high  ongoing operating costs.

In total,  the  upfront  capital  cost  of  fully  electrifying  these  plants  is  estimated  at around  USD 55 billion.  Doing  so  would  avoid  around  40 Mt CO2  per  year associated with the energy required for LNG liquefaction (Figure 18). Considering the discounted cash flows associated with the upfront investments, allowing for downtime, additional operating costs, and avoided feed gas costs, this investment has a weighted average CO2 abatement cost of around USD 100/t CO2 (with most projects  falling in the  range  of  USD 80-120/t CO2).  When  calculating  CO2 abatement  costs,  the  emissions  intensity  of  grid-based  electricity  is  taken  into account, as are the avoided emissions from lower use of feed gas to power the liquefaction process. On average, electrifying an existing plant would add around USD 0.6/MBtu  to  the  delivered  cost  of  LNG.  These  estimates  reflect  average conditions; actual costs can be higher for facilities requiring extended shutdowns

and contractual compensation, or where significant grid reinforcement is needed. Floating LNG facilities are also generally impractical to electrify through retrofit given space and weight constraints.

Figure 18 Marginal abatement cost of electrifying selected existing LNG export terminals using low-emissions electricity, 2025

<!-- image -->

IEA. CC BY 4.0.

Note: Other includes Algeria, Cameroon, Canada, Mauritania, Mexico, Nigeria, Norway, Oman, Papua New Guinea, Peru, the Russian Federation and the United Arab Emirates.

The

## Carbon capture, utilisation and storage

There are two main opportunities to deploy CCUS along the LNG supply chain: capturing  naturally  occurring  CO2  present  in  feed  gas  and  capturing  CO2 emissions from natural gas combustion at LNG liquefaction terminals.

Three  LNG  projects  are  currently  equipped  with  CCUS  to  capture  naturally occurring CO2. The Ras Laffan LNG plant in Qatar has been operating since 2019 with  a  capture  capacity  of  up  to  2.2 Mt CO2  per  year.  The  Snøhvit  project  in Norway  captures  up  to  0.75 Mt CO2  per  year  from  the  Hammerfest  LNG  gas stream and injects it into a saline aquifer. The Gorgon LNG project in Australia was  designed  to  capture  and  store  up  to  4 Mt CO2  per  year  over  its  40-year operating life, although it has operated well below full capacity since start-up.

Several new LNG projects are also planning CCUS deployment: Tangguh LNG in Indonesia reached a final investment decision in 2024 for CCUS infrastructure targeting  around  2.5 Mt CO2  per  year  and  Malaysia  LNG  is  planning  a  major CCUS facility. In addition, more than 5.5 Mt CO2 per year could be captured from Qatar's North Field LNG Expansion Project. Multiple LNG projects in the United States have announced CCUS plans and Australian regulations require all new gas field developments to avoid venting naturally occurring CO2 from the start of

production. All of Venture Global's LNG projects in the United States are likewise planning to use carbon capture technologies.

Naturally occurring CO2 streams at liquefaction plants typically have high purity, and capture costs are around USD 30-80/t CO2, including compression depending on scale. For high-CO2 feed gas, this can add USD 0.1-0.3/MBtu to delivered LNG costs. These figures apply only to naturally occurring CO2 separated from the feed gas stream and are not the cost of capturing combustion emissions at liquefaction plants. Further details are available in the IEA CCUS Projects Database.

CO2 emissions from combustion are much less concentrated, and no LNG projects currently use post-combustion CO2 capture. Capture costs are around USD 110-140/t CO2, increasing liquefaction costs by around USD 0.7-0.9/MBtu. Retrofitting  post-combustion  capture  at  existing  LNG  plants  is  technically  very complex  and  capital  intensive,  and  would  require  major  plant  modifications, additional  compression,  transport  and  storage  infrastructure  and  potentially prolonged  downtime  with  costs  reaching  several  hundred  million  US  dollars. Space constraints may further increase costs if capture units cannot be installed at optimal locations.

Following  capture,  CO2  must  be  transported  and  stored,  with  costs  strongly dependent on the proximity of suitable storage. Where storage is available near liquefaction plants, transport and storage costs are around USD 15-30/t CO2. For deep offshore storage requiring transport between mainland facilities and offshore sites, costs are expected to be higher, in the range of USD 75-150/t CO2.

## Chapter 3: Policy and finance considerations

## Summary

Realising the potential for emissions reductions across LNG supply chains will depend on a combination of regulatory, voluntary and financial levers (Table 3). In many jurisdictions, particularly in Australia, Europe and North America, methane regulations have emerged as the most immediate driver of emissions mitigation, with stricter requirements on MRV, LDAR, pneumatic equipment standards and venting restrictions. These measures can also help reduce flaring. Nevertheless, their effectiveness depends on the availability of enabling infrastructure. Access to carbon  capture  and  utilisation,  reinjection  options,  electrification  or  CO2 transport and storage can support more durable and scalable emission reductions than regulation alone.

Voluntary initiatives, including common MRV frameworks, buyer-led performance standards  and  third-party  assurance  and  certification  schemes,  can  reinforce regulatory expectations by improving transparency and comparability across LNG supply chains. Where these initiatives confer a commercial advantage, they can also strengthen the business case for emissions reductions. At the same time, financing from private capital, public programmes and multilateral institutions is important, particularly for capital intensive measures such as CCUS, electrification -and first of a kind low emissions projects. Revenue commitments, strategic equity ----stakes  and  public-private  financing  partnerships  can  further  de-risk  investment and support project deployment.

## Table 3 Overview of policy and financing instruments

|                       | Category                                      | Instrument                                                                 | Focus                                                                                                                                                                 |
|-----------------------|-----------------------------------------------|----------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Policies              | Exporting countries                           | National mandates and quantitative limits on GHG emissions                 | Sets enforceable limits on methane and CO 2 through banning routine flaring and venting, and enforcing mandatory technology standards and emissions caps              |
| Policies              | Exporting countries                           | Project permitting requirements                                            | Embeds emissions controls and compliance obligations into project approvals and contractual frameworks                                                                |
| Policies              | Exporting countries                           | Role of national oil companies                                             | Drives emissions outcomes through corporate operating standards and governance frameworks                                                                             |
| Policies              | Exporting countries                           | Multi-level governance systems                                             | Aligns federal rules with state and provincial implementation and enforcement                                                                                         |
| Policies              | Importing countries                           | Import standards                                                           | Imposes methane transparency and MRV requirements to imported gas and creates an intensity threshold for imported gas                                                 |
| Policies              | Importing countries                           | International commitments to reduce imported emissions                     | Signatory countries make methane reduction a central pillar of their fossil fuel policy                                                                               |
| Voluntary initiatives | Transparency and accountability mechanisms    | Monitoring, reporting and verification of emissions from LNG supply chains | Creates common MRV frameworks to improve comparability across LNG supply chains, reinforced by robust life-cycle assessment frameworks for product-focused accounting |
| Voluntary initiatives | Transparency and accountability mechanisms    | Buyer-led transparency and information exchange                            | Enables buyers to request and benchmark standardised supplier emissions data                                                                                          |
| Voluntary initiatives | Transparency and accountability mechanisms    | Third-party assurance and certification for LNG                            | Differentiates LNG supply based on independently verified emissions performance                                                                                       |
| Voluntary initiatives | Industry collaboration and commitments        | Other sector-led commitments                                               | Collective action on methane reductions and flare elimination across the industry                                                                                     |
| Finance               |                                               | Corporate finance                                                          | Company-level governance, MRV and abatement planning                                                                                                                  |
| Finance               | institutions                                  | Financing linked to specific uses or performance                           | Incentivises emissions reductions through targeted spending or key performance indicators                                                                             |
| Finance               | Government and multilateral financial support | Grants, below- market loans, or guarantees                                 | Addresses high upfront costs and infrastructure gaps (e.g. grid connections, CO 2 transport and storage) that hinder projects                                         |
| Finance               | Carbon markets                                | High-quality carbon dioxide removal credits                                | Channels funding towards verifiable emissions reductions and removals                                                                                                 |

Note: MRV = monitoring, reporting and verification.

## Policies

## Exporting countries

## National mandates and quantitative limits on GHG emissions

Some LNG-exporting countries  have  adopted  binding  national  regulations  that directly limit emissions from upstream and LNG operations. These include bans or  strict  limits  on  routine  flaring  and  venting,  quantitative  emissions  caps,  and performance-based standards for methane and CO2 emissions.

Norway combines CO2 taxation, methane-related operational requirements and permitting  conditions  that  strongly  incentivise  electrification  and  gas  utilisation. Algeria  and  Nigeria  have  national  regulations  that  restrict  routine  flaring  and require  operators  to  justify  flaring  volumes  under  defined  technical  or  safety exemptions.

Where such mandates are effectively enforced and supported by gas-gathering and utilisation infrastructure, they are associated with consistently lower emissions intensities.  Where  enforcement  capacity  or  infrastructure  is  limited,  however, regulatory requirements alone have often proved insufficient to deliver sustained emissions reductions.

## Project permitting requirements

A  complementary  policy  channel  operates  through  project-level  permitting  and contractual frameworks, including environmental permits, development approvals and  production-sharing  contracts.  These  instruments  often  specify  operational standards  rather  than  economy-wide  limits.  Common  requirements  include prohibitions on routine flaring outside commissioning or safety events; mandatory LDAR programmes and reporting obligations; limits on venting and requirements for  vapour  recovery;  equipment  standards  (such  as  restrictions  on  gas-driven pneumatics); and in some cases project-level emissions intensity thresholds.

Countries such as Oman and Qatar commonly embed these conditions directly in project approvals or operating licences. In the United States, several states also regulate emissions through air quality permits. These  measures  can  be particularly effective for new projects, although their impact ultimately depends on monitoring, enforcement and the availability of compliance options.

## Box 7 Flare reductions at QatarEnergy

Since 2012, QatarEnergy has implemented a series of measures to reduce routine gas  flaring,  beginning  with  the  launch  of  a  mitigation  programme  at  Ras  Laffan Industrial City. Initial efforts focused on monitoring and repairing valves, recycling fuel gas during shutdowns and start-ups, and reducing purge gas volumes. In 2014, the company commissioned the Jetty Boil-Off Gas Recovery Project, enabling more than 90% of boil-off gas generated during LNG loading to be recovered rather than flared.  The  initial  investment  was  around  USD 1 billion,  but  studies  estimate  a payback period of three years (assuming an LNG price of USD 10/MBtu).

Since  2014  a  further  USD 200 million  was  invested  in  flare-reduction  projects, including  facility  upgrades  and  enhanced  operational  controls.  Flaring  at  on-plot facilities was reduced by around 70%, while flaring associated with LNG loading fell by more than 90%, with a jetty boil-off gas recovery project alone avoiding 1.6 Mt CO2 emissions. QatarEnergy has set a target of achieving zero routine flaring by 2030, aligned with international efforts to eliminate routine gas flaring.

## Role of national oil companies

In countries where national oil companies (NOCs) dominate upstream production and  LNG  operations,  emissions  outcomes  are  often  shaped  less  by  formal regulation than by corporate operating standards and governance frameworks.

More than 30 NOCs have joined the Oil and Gas Decarbonization Charter (OGDC) and incorporated emissions reduction targets into internal standards, investment criteria and operating procedures. This can encourage joint-venture partners and contractors to meet defined emissions performance levels even in the absence of explicit legislation. Recent  IEA  analysis indicates that NOCs  with  strong governance  and  clear  operational  mandates  can  achieve  methane  emissions reductions  comparable  to  those  delivered  under  formal  regulatory  regimes, particularly  where  standards  are  applied  consistently  across  operated  assets. Rapid and cost-effective  methane  abatement  by  NOCs  could  reduce  methane emissions by up to around 30 Mt per year by 2030.

## Multi-level governance systems

In  some  federal  countries,  such  as  the  United  States,  methane  and  flaring outcomes are shaped by multi-level regulatory systems in which federal rules are complemented by subnational implementation and enforcement. These frameworks  combine  methane  standards  (including LDAR  and  equipment requirements),  waste-prevention  rules  and  reporting  obligations,  resulting  in substantial variation across jurisdictions, even within the same basin.

Australia and Canada also operate multi-level governance systems, but LNG-related emissions outcomes are often driven by federal levers. In Australia, a  large  share  of  LNG  feed  gas  production  is  offshore,  where  activities  in Commonwealth  waters  are  regulated under the Offshore Petroleum and Greenhouse  Gas  Storage  Act.  In  addition,  large  LNG  facilities  are  subject  to national,  federally  legislated  industrial  emissions  limits  under  the  Safeguard Mechanism.  State  and  territory  permitting  remains  important  in  some  onshore contexts,  but  federal  policy  signals  typically  dominate  for  LNG  supply  chains, especially for offshore developments.

In Canada,  the  federal  government  has  enacted  comprehensive  methane regulations  that  apply  to  all  upstream  activities  across  the  country.  Federal regulations  function  as  a  'backstop'  mechanism:  provincial  governments  can receive exemptions from the federal regulations and enforce their own, provided these are as stringent as the federal framework.

## Box 8 Policy frameworks for carbon capture utilisation and storage (CCUS) deployment

Some  exporting  countries  have  introduced  policy  frameworks  that  improve  the economics of CCUS and support its deployment alongside LNG production.

In the United States, federal tax credits for captured and securely stored CO2 (notably under Section 45Q) can materially improve CCUS project economics by creating a predictable  per tonne  revenue  stream,  particularly  for  projects  with  access  to -high purity CO2 sources and suitable storage. -

In Australia, CCUS  opportunities  are  supported  by  a  combination  of  large, well characterised storage resources located close to major LNG-producing regions -and  prospective  storage  basins  (notably  in  Western  Australia  and  the  Northern Territory) and established offshore regulatory frameworks for GHG storage.

These  advantages  can  reduce  development  risk  and  support  learning-by-doing, although project delivery still depends on permitting, infrastructure and commercial arrangements.

## Importing countries

Many  energy-importing  countries  recognise  that  fossil  fuel  consumption  within their borders contributes to GHG emissions globally. As such, several importers are  exploring  policy tools to improve  transparency  and  reduce  emissions associated with imported fuels.

## Import standards

Importing countries are expressing growing interest in measures that link market access to GHG emissions performance. The European Union, for example, has adopted a regulatory framework that extends methane transparency requirements to imported natural gas. From 2027, EU importers will be required to demonstrate that imported fuels are subject to MRV standards at the producer level that are equivalent to those applied within the European Union. From 2028, importers are required to report the methane intensity of imported gas, and from 2030, natural gas placed on the EU market is envisaged to be subject to a methane-intensity threshold. Secondary  legislation is currently under  development  to  define measurement and traceability methodologies required for implementation.

According to IEA analysis, if China, the European Union, Japan, Korea, and the United Kingdom were to implement a co-ordinated import standard with a methane intensity threshold of 0.2%, this could reduce global upstream oil and gas methane emissions  by  20%,  and  potentially  up  to  30%  if  a  spillover  effect  is  assumed. Several  approaches  could  be  used  to  establish  compliance  with  an  import standard. Some models decouple physical LNG cargoes from their environmental attributes, allowing lower-intensity gas to be traded through certificates or other accounting mechanisms. These approaches are generally simpler and less costly for industry to implement but may weaken the incentive to reduce emissions from specific supply chains. Other models require environmental attributes to remain linked  to  physical  gas  flows.  While  this  can  strengthen  incentives  for  emission reductions, it is typically more complex and costly to implement. Countries seeking to  introduce import standards need to decide which model will be accepted as proof of compliance.

## International commitments

Importing  countries  are  increasingly  signalling  a  willingness  to  tackle  energyrelated GHG emissions outside their borders, including through the adoption of international commitments aimed at reducing such emissions. One example of this is the Joint Statement on Drastically Reducing Methane Emissions in the Global Fossil Fuel Sector. Launched at the 30 th meeting of the Conference of the Parties (COP30) to the United Nations Framework Convention on Climate Change and backed by major producing and importing governments, this initiative  commits signatories to make methane reduction a central pillar of their fossil fuel policy. It supports mandatory MRV, the elimination of routine flaring and venting by 2030, and the integration of methane targets into nationally determined contributions. Signatories  will  also  work  towards  establishing  a  near-zero  methane  intensity marketplace and report progress in 2026, signalling greater policy co-ordination and alignment of trade measures to drive down methane emissions across global fossil fuel supply chains.

## Voluntary initiatives

Voluntary initiatives come in different forms, including MRV frameworks, buyer-led transparency  and  information  exchanges,  and  certification  schemes.  These initiatives  can  deliver  several  benefits  for  operators  active  across  LNG  supply chains. A credible voluntary scheme can provide evidence that delivered LNG is associated with minimal GHG emissions, enabling high-performing operators to differentiate their supply from higher-emissions alternatives. This can help attract customers  seeking  fuels  with  lower  emissions  intensities,  including  technology companies, data centres and industrial users with voluntary climate commitments. Over  time,  such  differentiation  could  also  support  price  premiums  for  loweremissions fuels, strengthening incentives for producers to curb emissions.

By enabling differentiation, voluntary schemes thus provide an avenue to reward first movers that choose to implement abatement measures where regulations do not  exist  yet.  They  can  also  help  gas-purchasing  companies  and  importing countries identify lower-emissions sources of supply and incorporate emissions performance into procurement decisions, supporting broader emissions reduction objectives.

While voluntary schemes have the potential to reward first movers, they are not a substitute  for  regulation.  Industry-led  efforts  can  play  an  important  role,  but government regulation remains critical to remove obstacles that prevent companies from getting started and ensure that emissions are reduced across the entire  sector.  Moreover,  the  current  landscape  is  fragmented,  with  schemes differing  in  scope,  methodology,  definitions  and  grading  systems.  This  can confuse buyers and weaken their ability to compare fuels on the basis of emissions performance. Voluntary schemes also remain constrained by partial coverage of LNG value chains, limited transparency, integrity concerns and uneven adoption across companies  and  countries. Among  voluntary initiatives, only some certification schemes require third-party verification of emissions, which may affect the  reliability  of  emissions  reported  under  other  approaches.  Ultimately,  the effectiveness of voluntary schemes depends on the use of measurement based -reporting and credible third party assurance. -

## Transparency and accountability mechanisms

## Monitoring, reporting and verification of emissions

Many initiatives have emerged in recent years that focus on establishing common frameworks for measuring and reporting emissions across the LNG value chain, forming the data backbone for transparency and comparability in the market.

The United Nations Environment Programme's Oil and Gas Methane Partnership (OGMP 2.0) is widely used as a reference framework for measurement based methane reporting and has become an important point of -alignment for credible MRV practices relevant to LNG supply chains. OGMP 2.0 provides guidance and tools that support a shift from generic emissions factors towards measurement-based reporting. As of August 2026, OGMP 2.0 has over 160 member companies, representing about 45% of global oil and gas production and over 80% of LNG flows. This indicates strong uptake of measurement-based reporting and significant volumes of production demonstrating higher data quality.

Members are expected to set near-term methane emissions reduction targets and report  methane emissions using increasingly measurement-based approaches. Members achieve 'Gold Standard Reporting' if they measure and report material methane emissions at the source and site level from operated assets within three years  of  joining  OGMP 2.0,  and  from  non-operated  assets  within  five  years. OGMP 2.0's  reporting  framework  has  been  incorporated  into  the  EU  MER, complemented by independent third-party assurance.

Other  frameworks  include  the  Natural  Gas  Sustainability  Initiative  Protocol,  a widely  used,  segment specific  methodology  for  calculating  methane  emissions -intensity across the United States natural gas value chain. GTI Energy's Veritas framework  harmonises  measurement based  methane  quantification  across  the -natural  gas  supply  chain.  The  International  Group  of  Liquefied  Natural  Gas Importers has also developed an MRV and GHG-Neutral Framework to establish consistent criteria for calculating the GHG footprint of delivered LNG cargoes.

While MRV initiatives are growing across LNG supply chains, coverage remains uneven,  with  liquefaction,  shipping  and  regasification  often  less  systematically monitored. Most MRV initiatives focus on methane, giving less attention to other GHGs. Existing MRV schemes also differ in scope and methodology, hindering the ability of buyers to compare supply according to performance.

## Buyer-led transparency and information exchange

Greater engagement from buyers has been instrumental in encouraging supplier disclosure and emissions reductions across LNG supply chains. These initiatives enable LNG buyers to request, share and compare emissions information from suppliers as part of procurement and due-diligence processes.

One  example  is  the  Coalition  for  LNG  Emissions  Abatement  toward  Net zero -(CLEAN), a public private initiative in which LNG buyers from Japan and Korea -send standardised questionnaires to LNG  producers regarding methane management and emissions reduction efforts at the project level. Information is aggregated by the Japan Organization for Metals and Energy Security, which acts as the secretariat for CLEAN, and disseminated alongside best practices, with the

aim of improving transparency and encouraging continued improvements across LNG  supply  chains.  CLEAN  is  designed  to  complement,  rather  than  replace, industry-led, measurement-based MRV frameworks and is currently one of the few initiatives to publish value chain emissions intensities at scale.

## Third-party assurance and certification for LNG

Several initiatives support independent assessment, assurance or certification of emissions performance associated with LNG production and supply. By improving transparency  and  credibility,  they  enable  differentiation  between  LNG  supplies based on emissions performance.

One example is Methane Intelligence Quotient (MiQ), an independent not-for-profit organisation that certifies roughly 7% of global gas production. MiQ offers an asset-level technical standard to assess emissions intensities across the natural  gas  supply  chain,  including  a  dedicated  standard  covering  liquefaction, shipping and regasification, supported by accredited independent auditors.

While  certification  schemes  can  allow  assets  with  low  GHG  emissions  to differentiate their supply, they still face numerous challenges. Measurement-based  quantification  is  not  always  required,  raising  the  risk  that methane emissions could be underestimated. Questions have also been raised about  the  integrity  and  transparency  of  some  schemes,  casting  doubt  on  the reliability  of  emissions  reported  under  them.  LNG  liquefaction,  shipping  and regasification facilities are rarely certified; Grain LNG in the United Kingdom is one notable  example.  Most  certification  initiatives  focus  on  methane,  with  less attention on CO2 and electricity related emissions (although some programmes, -like MiQ,  are  now  beginning  to  expand  into  comprehensive  GHG intensity -frameworks).  Certification  remains  concentrated  in  North  America,  with  limited uptake outside this region.

Certification schemes are most useful when anchored in robust MRV frameworks, combined with strong criteria regarding transparency and independence. Harmonising certification initiatives across countries, enhancing comparability and facilitating GHG-based purchasing would further enhance their effectiveness.

## Industry collaboration and commitments

## Other sector-led commitments

Industry coalitions have emerged across the oil and gas sector to drive collective voluntary action on reducing methane emissions and eliminating routine flaring.

The Oil and Gas Climate Initiative (OGCI) consists of 12 oil and gas companies and aims to advance voluntary action on methane through collective commitments,

leadership statements  and  shared  technical  resources.  OGCI  emphasises improved measurement, deployment of detection technologies and dissemination of practical guidance to support methane reduction across operations.

The Oil and Gas Decarbonization Charter (OGDC) was launched at COP28 in 2023  and  has  around  56  signatories.  The  OGDC  builds  on  the  goals  and approaches established under the OGCI. Its 56 companies have stated ambitions to dramatically reduce methane and flaring emissions by 2030, towards a goal of achieving net zero operational emissions by 2050.

The Zero Routine Flaring by 2030 initiative launched by the World Bank and the United Nations in 2015 aims to end routine gas flaring by 2030. Although voluntary and not legally binding, it establishes a public commitment by endorsers. Progress is  monitored  through  government  and  company  reporting,  as  well  as  satellite observations. Countries and companies that have endorsed the initiative account for around 60% of global gas flaring.

ONE Future, a coalition of about 40 natural gas companies in the United States, and the Environmental Partnership initiative bring together sector participants to reduce methane emissions through the sharing of best practices and improved emissions measurement and reporting.

These commitments rely primarily on voluntary targets and co-ordination rather than standardised measurement-based reporting frameworks. On the capacity-building  side,  notable  examples  include  the  Association  of  Southeast Asian  Nations'  Energy  Sector  Methane  Leadership  Program  and  the  African Energy Commission's project on Methane Emissions Management and Capacity Building in the African Oil and Gas Sector.

## Finance

Many  emissions  reduction  measures  in  the  LNG  supply  chain  do  not  require external financing, particularly for routine actions with a smaller capital footprint such as LDAR, operational improvements and small-scale equipment upgrades. Still, complementary external financing can play an important role for large capital programmes, first-of-a-kind projects, projects dependent on enabling infrastructure (e.g. gas utilisation, reinjection options, or power connections), or where access to capital remains a constraint. In these cases, financing may be available from private financial institutions, which may have their own emissions reduction goals, as well as from governments, multilateral institutions and carbon markets.

## Private financial institutions

Several financial institutions have their own emissions reduction or climate targets that influence how they assess financing for oil and gas companies, in addition to their core credit assessments. This often manifests when the lender undertakes due diligence, risk assessment or portfolio construction, and involves evaluating a borrower's emissions profile and transition strategy against the lender's portfolio preferences and transition objectives. Since bank loans typically have a shorter tenor than energy transition horizons, climate-related risk management frameworks, structured engagement processes and transition targets are used to inform  lending  decisions,  including  by  setting  expectations  on  governance, transparency, and the implementation of emissions reduction measures. These can  take  two  main  forms:  corporate-wide  expectations  or  financing  linked  to specific use or performance.

## Corporate financing expectations

Corporate-wide  expectations  typically  focus  on  borrowers  adopting  methane governance frameworks and MRV systems, identifying and implementing specific abatement measures, and improving disclosures to enhance comparability across suppliers and routes. Meeting these expectations can result in lower transition and reputational risks for lenders, potentially resulting in improved access to capital or more favourable financing terms for borrowers. In practice, these expectations are increasingly formalised through borrower due diligence requirements related to MRV readiness, credible abatement plans and governance. They can influence pricing  and  access to capital even when funding is not earmarked for a single emissions reduction project.

## Financing linked to specific uses or performance

Financing arrangements can also link funding conditions to the implementation of specific  abatement  measures  or  to  measurable  performance  outcomes. Unlike traditional  project  finance,  where  repayment  depends  on  the  cash  flows  of  a ring-fenced  project,  these  instruments  are  typically  structured  within  corporate finance frameworks but incorporate targeted incentives for emissions reductions. One  approach  is  to  link  financing  to  the  use  of  proceeds,  whereby  capital  is earmarked for defined activities such as methane abatement, flaring reduction or improvements to measurement and monitoring systems. These instruments are commonly issued at the corporate level but include restrictions on how funds are allocated.

A second approach is to link financing conditions to the achievement of predefined performance indicators. These may include reductions in methane intensity, lower flaring levels or improvements  in  measurement  quality.  Such  instruments

introduce performance-based incentives over time, as borrowing costs can vary depending on whether targets are met.

In 2025, the Methane Finance Working Group provided guidance on the design of these instruments. For use-of-proceeds structures, it outlines eligible methane and flaring abatement activities, as well as safeguards and disclosure requirements. For  performance-linked  instruments,  it  highlights  the  importance  of  robust, comparable metrics and transparent reporting frameworks to ensure environmental integrity.

## Government and multilateral financial support

Some  emissions  reduction  measures  are  technically  feasible  but  are  not implemented because of practical barriers such as high upfront costs, missing enabling infrastructure (e.g. available power connections) or institutional constraints  that  limit  implementation  capacity.  Government  support,  such  as grants, below-market loans and guarantees, can lower the cost of implementation and reduce risk for investors. Blended finance can further use this public support as an enabler to mobilise larger volumes of commercial finance. Public support can also help address early-stage development risks that can otherwise prevent projects from reaching bankability.

The World Bank's Global Flaring and Methane Reduction (GFMR) Partnership is one  example  of  this  approach.  GFMR  provides  catalytic  grants,  technical assistance,  and  policy  and  regulatory  support,  particularly  in  countries  and  for state-owned entities facing capacity constraints.

## Carbon markets

Carbon credits, which are tradable units representing 1 tonne of GHG emission reductions  or  removals,  are  often  used  at  the  corporate  level  to  help  achieve emissions reduction targets while generating revenue for emissions reduction and removal projects. Carbon credits have previously been used to label some LNG cargoes  as  'carbon  neutral',  with  credits  purchased  to  compensate  for  the estimated life-cycle emissions associated with a cargo. This practice has drawn growing scrutiny due to the widespread use of low-cost, nature-based credits with unclear permanence and verification standards. Questions have also been raised about the calculation of emissions reductions, including risks related to the lack of regulatory additionality in jurisdictions with existing climate policies.

Nonetheless, high-quality permanent carbon dioxide removal (CDR) credits could help channel funding towards genuine emissions removal projects. For all CDR solutions, robust accounting rules, independent international verification and clear definitions  are  essential  to  ensure  credibility.  Initiatives  such  as  the  Integrity Council for the Voluntary Carbon Market (ICVCM) Core Carbon Principles (CCP)

and the Paris Agreement Crediting Mechanism (PACM) can also help improve credit  quality  and  market  integrity.  In  particular,  the  PACM  Supervisory  Body adopted a new standard in late 2025 to address non-permanence and reversals in the mechanism's methodologies. The standard includes stringent requirements for long-term monitoring, liability provisions and mechanisms to address reversal risks. These developments aim to strengthen confidence that credited removals are durable over time and not subject to significant uncertainty. Around the same time, the ICVCM approved specific CDR methodologies eligible for high-integrity CCP-labelled credits, including methodologies for engineered CDR approaches.

## Box 9 The use of blended finance at Gorgon LNG, Australia

The CCUS system at the Gorgon LNG project cost around USD 2 billion within a much larger LNG megaproject with total capital costs of roughly USD 55 billion. The project  was  primarily  financed  through  joint-venture  equity  from  LNG  partners, including Chevron, ExxonMobil and Shell, with the core capital expenditure funded on the partners' balance sheets. Public support included a capital grant of around USD 40 million  from  Australia's  Low  Emissions  Technology  Demonstration  Fund. Additional financing was provided by export credit agencies and commercial banks, including the Japan Bank for International Cooperation and Mitsubishi UFJ Financial Group, to support participating companies' equity stakes. These loans applied to the overall LNG project, including the carbon capture facilities.

## Technical annex

## Data sources and limitations

This report provides a consistent set of estimates for CO2 and methane emissions from  LNG  supply  chains  based  on  the  latest  and  best  available  data.  These estimates reflect a detailed spatial representation linking upstream assets to LNG terminals, the latest scientific studies and measurement  campaigns,  and emissions  data  from  a  variety  of  sources  including  the  IEA  Global  Methane Tracker (2026) and Global Energy and Climate Model (2025); the World Bank for flaring; the Oil Climate Index plus Gas tool (OCI+) for energy use in production and  processing;  the  United  States  Energy  Information  Administration  (EIA), Federal Energy Regulatory Commission (FERC) and Environmental Protection Agency (EPA); the International Maritime Organization (IMO); Rystad Energy; and company and country reports.

LNG supply chains are complex and can evolve quickly, and literature reviews have identified large differences in emissions estimates over time, even for the same assets. Data on GHG emissions are often not available and, even when they are  available,  seldom  reflect  direct  measurements.  These  uncertainties  are compounded by challenges in apportioning emissions to LNG supply, rather than to  oil  and  other  co-products,  and  in  tracing  feed  gas  from  production  sites  to liquefaction  terminals.  Estimates  are  also  often  based  on  generic  information, such as reservoir CO2 content for naturally occurring CO2.

We  welcome  all  feedback,  including  measured,  robust  and  transparent  data sources that can help refine our estimates.

## Estimating emissions

## Production and processing

In this work, the mapping of upstream assets to LNG liquefaction facilities uses data from the EIA and FERC, as well as company reporting for the United States, and data from Rystad Energy for the rest of world, while recognising limitations in public disclosure and data transparency.

EIA data on LNG exports to domestic and international destinations are used to cross-check the volumes of natural gas used at each liquefaction site. We then link individual upstream gas assets known to produce LNG feed gas to each LNG terminal. Physical links and supply contracts often provide sufficient information to

estimate the share of feed gas flowing to a specific terminal from each upstream asset. Where no other information is available, we estimate the contribution of each upstream asset based on its total production, pipeline capacity and other operational details (e.g. reported outages). We estimate emissions intensities for the upstream assets and calculate a production-weighted average to derive the annual average emissions intensity of feed gas at each LNG terminal. Overall, we consider production and emissions from around 51 upstream basins supplying feed gas for LNG exports.

## CO2 emissions from energy use

Our estimates of CO2 emissions from energy use in production and processing are based on country- and production-specific data (e.g. conventional onshore, conventional offshore and shale gas) from the OCI+ tool. These estimates draw on  a  detailed  field-by-field  dataset  developed  by  the  Rocky  Mountain  Institute using the Oil  Production  Greenhouse Gas Emissions Estimator (version 3.0a), which considers the energy required for each stage of production (e.g. exploration, development, drilling, extraction, processing and maintenance).

## Naturally occurring CO2

Estimates of vented naturally occurring CO2  emissions  are based  on  a basin-by-basin assessment of natural gas CO2 concentrations using data from the scientific literature, as well as company and government reports (for example, for the  offshore  Ichthys  field  in  the  Browse  Basin,  which  supplies  feed  gas  to  the Ichthys  LNG  facility).  We  assume  that  all  extracted  CO2  is  emitted  to  the atmosphere,  except  for  volumes  already  captured  at  facilities  equipped  with CCUS, which are subtracted from the total.

## Methane emissions

The IEA estimates methane emissions from assets based on measured, satellite and inferred data following the methodology of the IEA's Global Methane Tracker 2026. These estimates are adjusted to account for asset-specific information, such as the type of production, the age of facilities and the type of operator (e.g. major, NOC). There is a high degree of uncertainty in estimating methane emissions, and estimates change as new measurement results emerge and as factors feeding into  the  estimation  process  change.  We  categorise  countries  according  to measured data availability as 'moderate', 'limited' or 'none'.

Countries with 'moderate' data availability are those whose methane emissions estimates are constrained by recent empirical datasets from airborne- and groundbased measurement campaigns that cover the majority of the country's oil and gas production and are documented in peer-reviewed studies.

Countries  with  'limited'  data  availability  are  those  whose  methane  emissions estimates are informed by a) MethaneSAT observations covering at least 25% of the country's total oil and gas production; b) other peer-reviewed measurement studies covering part of a country's oil and gas activity (e.g. offshore production); or c) observations from coarse resolution satellite inversions (such as TROPOMI) available for at least 50 days of the year.

For  countries  with  no  measured  data  or  relevant  scientific  study,  we  estimate emissions intensities by scaling production-specific emissions intensities from the United States using country- and production-specific scaling factors derived from a range of auxiliary sources.

See the Global Methane Tracker 2026 Documentation for further information.

Methane  emissions  also  occur  during  transmission,  liquefaction,  shipping  and regasification.  Our  estimates  of  emissions  from  transmission  are  based  on country-specific methane emissions intensities for downstream operations, scaled to each transmission segment and modelled LNG flows, taking into account the extent  of  operating  natural  gas  pipeline  networks.  The  methane  emissions intensity  of  liquefaction  is  assumed  to  be  0.05%  (based  on  satellite  data  from GHGSat) and that of regasification is assumed to be 0.02% (based on Innocenti et al., 2023). Emissions estimates for shipping employ Independent Commodity Intelligence Services (ICIS) ship-tracking data on LNG cargoes, IMO data on ship engine types, and a range of studies to define assumptions on fuel use, emissions and  operational  factors,  including  distance  travelled,  energy  use,  propulsion technology and average vessel capacity.

One tonne of methane is assumed to be equivalent to 30 tonnes of carbon dioxide based on a 100-year global warming potential (IPCC, 2021).

## Flaring

Estimates  of  CO2  emissions  from  flaring  are  based  on  a  detailed  review  of upstream  assets,  pipeline  connections  and  data  from  the  World  Bank,  which provides information on the volumes and locations of all flares in 2024, as well as country-level assumptions on the liquids content of extracted natural gas. Methane emissions from incomplete combustion at flares are based on IEA country-level estimates of combustion efficiency (see Global Methane Tracker 2026 Documentation for further details).

## Transmission

Estimates of energy use and CO2 emissions from feed gas transmission are based on life-cycle and global supply chain assessments, as well as regional reports,

including Zhu et al. (2025), the European Energy Research Alliance (EERA), and Future Energy Reports (FENEX).

## Shipping

Our  estimates  for  CO2  and  methane  emissions  from  shipping  are  based  on  a detailed bottom-up assessment of fuel use, taking into account the engine type, cargo size, voyages and fuel mix of all the ships that carried LNG in 2025. Methane slip  assumptions  are  in  line  with  the  range  reported  in  recent  studies  such  as Rosselot  et  al.  (2024),  Balcombe  et  al.  (2022)  and  Thinkstep  (2019).  Key assumptions are presented in Table 1. Our estimates align well with IMO-reported emissions  (e.g.  MEPC 82/6/38  reports  44 Mt CO2  from  LNG  carriers  in  2023, compared with our estimate of 45 Mt CO2).

## Comparisons with the interim report

The global average emissions intensity of LNG from production to regasification is  estimated  to  have  been  18.6 g CO2-eq/MJ  in  2025,  slightly  lower  than  the 19.4 g CO2-eq/MJ estimated for 2024 in the interim report. As detailed in Box 1, LNG exports in 2025 were around 30 bcm higher than in 2024, and several new LNG producers entered the market. The main changes by supply segment are:

-  Methane: There have been some methodological changes, as described in the Global Methane Tracker 2026 Documentation. These include revisions to the estimation of emissions intensities in countries with limited or moderate measured data, as well as updates to the underlying datasets (e.g. new data from  MethaneSAT).  The  global  average  upstream  methane  intensity  was 3.9 g CO2-eq/MJ in the interim report, compared with 4.0 g CO2-eq/MJ in this report.  The  largest  decrease  was  observed  in  Nigeria,  where  emissions intensity fell from 10 g CO2-eq/MJ to around 5 g CO2-eq/MJ. These reductions were partly offset by increases in the Asia Pacific region.
-  Shipping: The global average CO2 emissions intensity was 2.9 g CO2-eq/MJ in  the  interim  report,  compared  with  2.1 g CO2-eq/MJ  in  this  report.  This reflects incremental improvements in the LNG carrier fleet, as newer vessels have entered service and older steam-powered ships are used less frequently, as well as refined estimates of emissions from different LNG carrier types.
-  Transmission: The global average emissions intensity was 2.3 g CO2-eq/MJ in  the  interim  report,  compared  with  2 g CO2-eq/MJ  in  this  report.  This reduction  is  driven  mainly  by  additional  data  from  Zhu  et  al.  (2025),  which provide lower measurement-based emissions estimates from pipelines in the United States. A revised allocation of feed gas across producing basins also contributed to the lower transmission emissions intensity in the United States.

## Abatement and electrification cost estimates

Estimates of methane abatement costs are based on the IEA Methane Abatement Model, considering emissions sources across the LNG value chain. Details of the methodology are available in the Global Methane Tracker 2026 Documentation, including information on abatement options, potential savings, wellhead gas prices and discount rates.

Estimates  of  flare  reduction  costs  are  based  on  flare  size  and  distance  from existing infrastructure. Revenue from additional gas sales is based on 2024 gas prices. For further information on abatement options and costs, see Emissions from Oil and Gas Operations in Net Zero Transitions.

Estimates of electrification costs of liquefaction and upstream facilities are based on  a  detailed  geospatial  analysis  of  the  location  and  characteristics  of  these assets.  Fields  likely  to  cease  production  within  the  next  ten  years  are  not considered.  For  each  facility,  the  assessment  considers  current  and  future upstream energy use, distance to an existing electricity grid, grid connection costs, electricity prices, emissions intensity of electricity, wind and solar resources and costs, and battery costs. The choice between grid connection or decentralised renewables, as well as the optimal mix of wind and solar capacity, is based on the option with the lowest net present value in each year.

Table 4 Regional mapping used in the report

| Exporting region          | Country                                                                                                  |
|---------------------------|----------------------------------------------------------------------------------------------------------|
| North America             | Canada, Mexico, United States                                                                            |
| Central and South America | Peru, Trinidad and Tobago                                                                                |
| Europe                    | Norway                                                                                                   |
| Russia                    | Russian Federation                                                                                       |
| Africa                    | Algeria, Angola, Cameroon, Republic of the Congo, Egypt, Equatorial Guinea, Mozambique, Nigeria, Senegal |
| Middle East               | Oman, Qatar, United Arab Emirates                                                                        |
| Southeast Asia            | Brunei Darussalam, Indonesia, Malaysia                                                                   |
| Other Asia Pacific        | Australia, Papua New Guinea                                                                              |

Table 5 LNG electrification economics - key technical and economic assumptions

| Generic inputs                                     | Assumption         |
|----------------------------------------------------|--------------------|
| Electric load intensity                            | 350 kWh/t LNG      |
| Peak load contingency                              | 10%                |
| Backup gas capacity retained                       | 20%                |
| Grid power escalation                              | 2.00%              |
| Electric drive retrofit capex                      | USD 700/kW         |
| Fixed grid interconnect capex                      | USD 20 million     |
| Battery duration                                   | 8 hours            |
| Battery round-trip efficiency                      | 88%                |
| Retrofit fixed operations and maintenance          | 1.50%              |
| Solar and battery fixed operations and maintenance | 2.0%               |
| Interconnection fixed operations and maintenance   | 0.5%               |
| Owner's cost/contingency                           | 10%                |
| Operations and maintenance escalation              | 2.0%               |
| Construction period                                | 0.5 years          |
| Retrofit downtime                                  | 6 months           |
| Plant-specific inputs (average values)             | Assumption         |
| Grid CO 2 intensity                                | 425 kgCO 2 /MWh    |
| Grid power price in 2026                           | USD 72/MWh         |
| Average feed gas cost                              | USD 1/MBtu         |
| Lost LNG margin during downtime                    | USD 75/t           |
| Grid reinforcement capex                           | USD 1 000/kW       |
| Solar capex                                        | USD 673/kWdc       |
| Battery capex                                      | USD 250/kWh        |
| Distance to grid                                   | 32 km              |
| Transmission connection cost                       | USD 1.2 million/km |
| Renewable energy source potential (1-10)           | 7.4                |

## Abbreviations and acronyms

BOG

Boil Off Gas

C3MR

Propane pre-cooled mixed refrigerant

CCP

Core Carbon Principles

CCUS

Carbon capture, utilisation and storage

CDR

Carbon dioxide removal

CLEAN

Coalition for LNG Emissions Abatement toward Net Zero

COP

Conference of the Parties

CO2-eq

Carbon dioxide equivalent

DFDE

Dual fuel diesel electric

DMR

Dual mixed refrigerant

EERA

European Energy Research Alliance

EIA

United States Energy Information Administration

EPA

United States Environmental Protection Agency

EU MER

EU Methane Emissions Reduction Regulation

FENEX

Future Energy Reports

FERC

United States Federal Energy Regulatory Commission

FSRU

Floating storage and regasification unit

GFMR

World Bank Global Flaring and Methane Reduction Partnership

GHG

Greenhouse gas

GWP

Global warming potential

ICIS

Independent Commodity Intelligence Services

ICVCM

Integrity Council for the Voluntary Carbon Market

IEA

International Energy Agency

IMO

International Maritime Organization

LDAR

Leak detection and repair

LNG

Liquefied natural gas

ME-GA

Gas admission

ME-GI

Gas injection

MiQ

Methane Intelligence Quotient

MRV

Monitoring, reporting and verification

NOC

National Oil Company

OCI+

Oil Climate Index plus Gas

OGCI

Oil and Gas Climate Initiative

OGDC

Oil and Gas Decarbonization Charter

OGMP 2.0

Oil and Gas Methane Partnership

ORV

Open-rack vaporiser

PACM

Paris Agreement Crediting Mechanism

SCV

Submerged combustion vaporiser

SMR

Single mixed refrigerant

VRU

Vapour Recovery Unit

X-DF

Dual fuel engine

## Units

| bcm   | billion cubic metres          |
|-------|-------------------------------|
| km    | kilometre                     |
| °C    | degrees Celsius               |
| g     | gramme                        |
| kg    | kilogram                      |
| t     | tonne                         |
| Mt    | million tonnes                |
| MJ    | megajoule                     |
| PJ    | petajoule                     |
| kW    | kilowatt                      |
| MW    | megawatt                      |
| kWh   | kilowatt-hour                 |
| kWdc  | kilowatt (direct current)     |
| MWh   | megawatt-hour                 |
| MBtu  | million British thermal units |
| USD   | US dollars                    |
| EUR   | Euro                          |

## Acknowledgements

We would like to express our gratitude to Japan's Ministry of Economy, Trade and Industry for their support to this work.

The study benefitted from the outcomes of the discussions at the IEA Workshop 'Reducing Emissions from LNG Supply' held in March 2025.

The comments and suggestions of the following experts (in alphabetical order) who provided input and reviewed preliminary drafts of the report were of great value:

Andrea Intieri

Baker Hughes Carbon Limits Woodfibre LNG RMI TotalEnergies Woodside Energy Environmental Defense Fund Clean Air Task Force Equinor Carbon Limits Öko-Institut - Institute for Applied Ecology Cheniere Energy Methane Intelligence (MiQ) Institute of Energy Economics, Japan - IEEJ Oil and Gas Climate Initiative (OGCI) The Oxford Institute for Energy Studies TotalEnergies Tecnicas Reunidas Oil and Gas Climate Initiative (OGCI) Woodside Energy Tokyo Gas Organisation for Economic Co-operation and Development (OECD) International Group of LNG Importers Clean Air Task Force (CATF) Natural Resources Canada (NRCan) The Oxford Institute for Energy Studies

Benjamin Heras Cruz

Calvin Stuckert

Carmela Chaney

Claire Dauba

Craig Duarte

Daniel Zavala-Araiza

David McCabe

Dimitrios Pappas

Fanny Lagrange

Felix Christian Matthes

Fiji George

Georges Tijbosch

Hiroshi Hashimoto

Hugo Liabeuf

Jonathan Stern

Johann Thevenard

Juan Sánchez-Peñuela

Julien Perez

Justin Robertson

Kosho Tamura

Lahra Liberti

Laurent David

Lesley Feldman

Margaret Skwara

Maria Olczak

Maria Teresa Nonay

Enagas

Mark Davis

Capterio

Masataka Yarita

Japan Organization for Metals and Energy Security

Masuda Toshihiro

Ministry of Economy, Trade and Industry

Matt Watson

Watson Public Strategies

Peter Evans

BP

Rebeca Quintanilla

Context Labs

Rossella Palmieri

Baker Hughes

Ryota Kimura

Inpex

Selina Roman-White

SLR Consulting

Taiki Inoshita

INPEX

Vanessa Ryan

Chevron

Yusaku Akamatsu

Mizuho bank

Yvette Manolas

Independent consultant

Zitely Tzompa

Clean Air Task Force (CATF)

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual m ember countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject to the IEA's work is licenced under International Licence.

<!-- image -->

Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org

Contact information: www.iea.org/contact

Typeset in France by IEA - September 202 6 Cover design: IEA Photo credits: © Shutterstock