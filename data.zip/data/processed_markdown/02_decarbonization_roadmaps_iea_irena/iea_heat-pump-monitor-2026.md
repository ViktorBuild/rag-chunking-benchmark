---
document_id: iea_heat-pump-monitor-2026
title: "Iea Heat-Pump-Monitor-2026"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_heat-pump-monitor-2026.pdf"
tables_detected: 24
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Heat Pump Monitor 2026

Trends and market opportunities

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 14 Association countries and beyond.

## IEA M ember countries:

This publication, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. International Energy Agency Website: www.iea.org

IEA Accession countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Chile Colombia Costa Rica Brazil Israel

Romania

## IEA A ssociation countries:

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Table of contents

| Heat Pump Monitor 2026                                                                                                                     | Trends and market opportunities ............................................. 1   |
|--------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------|
| Table of contents.....................................................................................................................     | 3                                                                                 |
| Introduction ............................................................................................................................. | 4                                                                                 |
| Pillar A: Cross-sectoral deployment........................................................................................                | 7                                                                                 |
| Pillar B: Deep dive on heat pumps in buildings ....................................................................                        | 14                                                                                |
| Affordability ..............................................................................................................15             |                                                                                   |
| Energy security ........................................................................................................19                 |                                                                                   |
| Industrial competitiveness........................................................................................22                       |                                                                                   |
| Innovation and technology .......................................................................................26                        |                                                                                   |
| Pillar C: Regional insights.....................................................................................................           | 30                                                                                |
| Pillar D: Policies ....................................................................................................................    | 39                                                                                |
| Technical notes on the dashboards......................................................................................                    | 43                                                                                |
| Acknowledgements...............................................................................................................            | 47                                                                                |

## Introduction

Heating and cooling account for a significant share of global energy demand and CO2 emissions. As countries work to meet rising demand for secure, resilient, affordable and sustainable energy solutions, heat pumps can play a central role in heating and cooling systems. Despite strong growth in recent years, heat pumps meet less than 15% of heating demand in buildings worldwide and remain niche in industry and district heating applications. This highlights both the scale of the challenge and the significant opportunities for market expansion. Looking forward, deployment is expected to keep increasing across most major economies, driven by the increasing cost-competitiveness of heat pumps, stricter building standards, rising  cooling  demand,  increased  electrification  and  growing  interest  in  lowemissions district heating solutions. However, growth patterns vary widely across regions and sectors, reflecting differences in policy frameworks, energy prices, characteristics of the existing stock and user preferences.

Energy, climate, industrial and trade policies are increasingly interconnected, and measures affecting energy pricing, building regulations, manufacturing strategies, innovation support and trade all influence the deployment and competitiveness of heat pumps. Market conditions are also changing quickly, shaped by geopolitical developments and industrial and technological progress. In this rapidly evolving context, policy makers require timely, evidence-based and comparable information to guide decision-making.

For  many  years,  the  IEA  has  tracked  energy  technology  markets  and  related policies. Heat pumps have been a core element of this work, and as their strategic importance has grown, so too has the need for more comprehensive, granular, consistent  and  regularly  updated  monitoring.  Governments  increasingly  seek comparable indicators across countries, better visibility on manufacturing capacity and supply chain resilience, and clearer evidence on the effectiveness of policy instruments in different contexts.

The  IEA's  Heat  Pump  Monitor  responds  to  these  needs  by  providing  a comprehensive,  data-driven  assessment  of  global  and  regional  heat  pump markets, their enabling conditions and their future prospects. It centralises IEA analysis in one place, and consolidates national and international data within a consistent analytical framework aiming to support governments, researchers, and industry  stakeholders  in  identifying  priority  actions  to  scale  up  deployment, reinforce domestic manufacturing and maximise socio-economic benefits in line with broader objectives.

The analysis focuses on the buildings sector, where most heat pump deployment currently occurs, and also incorporates insights on industrial and district heating

applications.  It  assesses  the  current  status  and  outlook  of  global  and  regional markets,  examines  deployment  trends  and  market  penetration,  and  analyses manufacturing capacity, trade flows and supply chain dynamics. It also evaluates cost-competitiveness,  affordability, innovation  performance  and  employment impacts. Heat pumps are defined in line with the IEA's Heat Pump Taxonomy 1  to ensure consistency across regions and over time. The outlook presented in the Monitor is examined through scenario analysis, using the IEA's Current Policies Scenario (CPS), Stated Policies Scenario (STEPS) and Net Zero Emissions by 2050 Scenario (NZE Scenario), consistent with the World Energy Outlook 2025 (see below).

The IEA Heat Pump Monitor consists of a dedicated online tool that integrates analytical  insights  with  data  visualisation.  Its  central  output  consists  of  an analytical  summary  highlighting  the  main  messages  and  quantitative  insights, complemented by a compendium of 20 visual dashboards that enable users to explore trends across a wide range of indicators in greater depth and to conduct cross-country comparisons.

The  dashboards  are  organised  around  four  main  pillars:  a)  global  deployment trends by sector of application; b) in-depth analysis of buildings sector applications including aspects related to affordability, energy security, industrial competitiveness,  innovation  and  technology;  c)  regional  perspectives;  and  d) policies. Graphic visualisations are accompanied by analytical insights to support interpretation and application in a broader economic and regulatory context.

While the Monitor provides a global overview, it places particular emphasis on major heat pump markets that illustrate different development pathways and policy approaches.  These  are  Europe,  the  People's  Republic  of  China  (hereafter, 'China'), Japan and the United States, which reflect diverse regulatory environments, market structures and consumer preferences. Together, they offer valuable lessons for broader policy-learning internationally.

The analysis builds on the IEA's established market tracking systems, modelling tools and expert networks, including the IEA's Global Energy and Climate Model and  Manufacturing  and  Trade  Model.  It  draws  on  national  and  international statistical sources and benefits from stakeholder consultations and peer review.

1 The IEA definition of heat pumps includes heat pumps that are used as primary heating equipment, intended as the main equipment providing heat. The boundary includes reversible units (such as reversible air conditioners) when they serve as the main heating equipment. However, it excludes such units when used solely for cooling, or as a complement to other heating equipment, such as a boiler.

## Scenarios used in IEA's Heat Pump Monitor 2026

The  projections  for  technology  deployment,  employment,  manufacturing  and  trade presented in the Monitor are based on scenario analysis. The scenarios differ primarily in  their  assumptions  about  government  policies.  Three  scenarios  are  used  in  this report:

-  The Current Policies Scenario (CPS) sets  out  a  pathway  for  the  future  of  the energy system in which no change in energy-related policies is assumed beyond what is already in place. The CPS therefore builds on a narrow reading of today's policy settings, only considering those that are adopted in legislation and regulation, and assuming no changes will be made, even where governments have indicated their intention to do so. Where existing policies target a range of outcomes, it is assumed that the lower end of the range is achieved. In the CPS, policies that are time-bound  or  that  target  specific  years  are  not  strengthened  after  they  expire. Alongside  this  view  of  the  policy  landscape,  the  CPS  also  offers  a  generally cautious perspective on the speed at which new energy technologies are deployed and integrated into the energy system. It tends to project slower adoption of new technologies in the energy system than seen in recent years, or than projected in the STEPS.
-  The Stated Policies Scenario (STEPS) is designed to reflect the direction of travel of  the  global  energy  sector  based  on  current  energy-related  policies,  including those that have already been adopted, announced, or are in the advanced planning stage - even if they are not yet enshrined in law or regulations. Examples of the latter  include  energy  efficiency  targets  such  as  minimum  energy  performance standards for heat pumps. Policy targets are not assumed to be automatically met: in each case, their prospects are assessed taking account of market, infrastructure readiness and financial constraints. The STEPS assumes that time-bound policies continue beyond the currently-stated durations and retain a similar pace of change. However, it does not assume that aspirational goals, such as those included in the Paris Agreement, are achieved.
-  The Net Zero Emissions by 2050 (NZE) Scenario is a normative scenario that maps out a global pathway for the energy sector to achieve net zero carbon dioxide (CO2) emissions by 2050, alongside achieving goals on universal energy access and large reductions in air pollution. In contrast with previous editions, the NZE Scenario is no longer a low-overshoot scenario: it assumes that warming exceeds 1.5°C for several decades before returning below 1.5°C by 2100. This adjustment reflects  persistently  high  emissions  in  recent  years  and  the  slow  deployment  of some key technologies.

## Pillar A. Cross-sectoral deployment

Heat  pump  deployment  differs  markedly  across  buildings,  district  heating  and industry, as a reflection of the different stakeholders involved, as well as variations in policy support,  energy  prices,  infrastructure  and  technical  suitability by application.  Uptake  is  closely  linked  to  regulatory  stability,  competitiveness, system  integration,  access  to  finance  and  technology  maturity.  Systematic tracking of these developments helps governments design effective measures, strengthen  industrial  competitiveness  and  align  heating  strategies  with  energy security  and  wider  policy  objectives,  at  the  same  time  as  identifying  emerging market opportunities and anticipating barriers to investment.

Pillar A of the Heat Pump Monitor focuses on the current trends and future outlook for heat pump deployment across a range of application sectors. It analyses the underlying  drivers  shaping  future  market  developments,  including  regulatory frameworks, cost-competitiveness and infrastructure.

## Deployment in buildings

## Current status

## Heat pump adoption is growing in a vast market.

## What's next?

## Policy will be decisive for accelerating deployment.

Deployment has fluctuated in recent years, as steady growth prior to 2020 and record expansion in 2021 and 2022 - particularly in Europe - was followed by a slowdown in 2023. Since then, global sales have remained mostly stable, but with great regional variations. In some countries, sales of heat pumps have outpaced gas boilers and furnaces. The United States remains the largest market in terms of installed stock, followed by China, Europe and Japan, but China leads sales. Uptake is highest in areas with mild climates and is expanding in regions with rising demand for cooling, where heat pumps provide both heating and cooling, when backed by long-term policy frameworks and favourable electricity-to-gas price ratios.

The efficiency of heat pumps is widely recognised, but there are persistent barriers to deployment, notably high upfront costs, high electricity prices in some regions, and a shortage of skilled installers. A rebound in sales is expected in all IEA scenarios, as measures such as building codes, subsidies, heating plans and targets take effect in different countries. Deployment is also expanding in emerging markets, driven by dual-use heat pumps that provide cooling, and rising adoption of heat pump water heaters. In the CPS, sales are expected to increase by over 80% by 2035. In the STEPS, sales more than double, supplying around 20% of global heating demand. In the NZE Scenario, stronger policies mean global sales grow twice as fast as in the past decade.

## Global heat pump sales by region and share of space heating needs covered by heat pumps by scenario, 2019-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario.

Sustained policies will be critical to unlock potential for heat pump deployment.

## Regional patterns in heat pump deployment in buildings

## Current status

## What's next?

## Heat pump use differs markedly across different regions

Heat pump types and use patterns are shaped by differences in climate conditions, building design, heating systems, comfort preferences, standards and available financial support. Worldwide, the vast majority of heat pumps sold for buildings are air-source units. Of these, air-to-air systems are most common in China, the United States, the Nordic countries and Japan. In China, they are often used parttime or to heat only part of the space; in the United States, they are mostly centralised within ducted heating, ventilation and airconditioning (HVAC) systems; in the Nordics, they operate in well-insulated homes; and in Japan, they provide primary space heating alongside growing use of heat-pump water heaters. By contrast, Germany, the United Kingdom and northern Italy mainly rely on air-to-water (hydronic) systems with radiators or underfloor heating. Technology choice impacts unit size, which tends to be larger in the United States and Europe and smaller in China and Japan.

## While regional differences are expected to persist, harmonised market data across regions could inform better policies

Technology variety and differing consumer preferences are not expected to change in future years. However, these conditions have led to differences in reporting standards and classifications, which hinder like-for-like market comparison and tracking, as well as potential policy learnings across markets. A particular limitation concerns the need to distinguish heat pumps used primarily for heating from those serving the broader cooling market. To address this, the IEA has proposed a taxonomy to support collaboration towards harmonised global heat pump data monitoring. Harmonised data could provide policy makers with robust evidence to design, develop and monitor energy and industrial policies, while giving industry stakeholders a clearer understanding of market dynamics and investment opportunities across regions.

## Share of heat pump sales using air-distribution systems over water-distribution ones with respect to climate conditions for selected countries, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: Shares are in capacity terms based on 2024 sales. Water-distribution refers to hydronic systems, and air-distribution to ducted and unducted reversible air conditioners.

Air-to-air units that can provide both heating and cooling have high market shares in certain regions u

## Deployment in district heating

## Current status

## What's next?

## Heat pumps make up a small share of district heating

## Heat pumps will be part of rapidly expanding district heating systems

District heating supplies around 10% of global heat demand in buildings, mainly concentrated in Northern and Eastern Europe, Russia and China. It remains less widespread in North America, where systems are typically smaller in scale than those in China or Europe. While district heating is a resource-efficient method of heating, it still relies on fossil fuels for 90% of its supply globally, but a large and growing number of modern networks can integrate renewable and other low-emissions sources. Data on global heat pump deployment in district heating is scarce, but in Europe, large heat pumps and electric boilers supplied about 3% of district heating in 2023, and had the highest growth rate of all heat sources.

Policy interest in district heating is increasing, and heat pump deployment is expected to expand. In China, the floorspace covered by district heating tripled between 2002 and 2022, and there are policies in place to further develop and decarbonise those networks. In North America, the amount of floorspace connected to district energy networks increased by an average of 6% per year over the same period, indicating increasing momentum. In Europe, the European Union's Energy Efficiency Directive sets clear thresholds for district heating to rely less on fossil sources and to become more efficient. Heat pumps are expected to play an important role in meeting this growing heat demand and replacing fossil heat sources. For example, Germany alone has around 900 MW of district heating heat pump capacity under construction or in planning, positioning it among the leaders in this sector.

## District heating supply by source in China and Europe, 2022 and 2023

<!-- image -->

Sources: Danish Energy Agency (2024), Prospects for Clean and Renewable Heating in China - Insights from Denmark; China District Heating Association (2022); Euroheat &amp; Power (2025), DHC Market Outlook 2025.

Heat pumps have played only a marginal role in district heating supply to date.

## Opportunities for heat pumps in district heating

## Current status

## What's next?

## Heat pumps offer a compelling opportunity for district heating

Compared with other options for district heating supply, heat pumps provide distinct possibilities. They deliver significantly higher efficiency than other electrical heating options and can utilise a wide range of lowtemperature heat sources including waste heat from industrial processes, sewage treatment plants and data centres, and natural sources such as lakes, rivers and geothermal. Through flexible operation, heat pumps can provide grid-supporting services, and absorb intermittent excess electricity supply from solar and wind to produce heat that is stored with thermal storage and dispatched later, for example when energy prices and demand are higher.

## The possibilities of heat pumps in district heating are already being seen in deployments across all regions

A growing number of case studies showcase the future possibilities for heat pumps in district heating. One of the single largest deployments of heat pumps in district heating globally is in Stockholm, where a combined capacity of 500 MW of heat pumps supplies about 10-20% of heat demand to the network. In China, with its vast industrial base, a 200 MW absorption heat pump in the city of Qianxi utilises waste heat from a nearby steel mill. In the United States, another example comes from the fast-growing data centre industry: Amazon's headquarters in Seattle has been heated by waste heat from a nearby data centre since 2017, enabled by heat pumps and district heating.

## Temperature ranges of heat sources suitable for heat pumps in district heating

<!-- image -->

IEA. CC BY 4.0.

Note: Geothermal temperatures are for average geological conditions without any increased geothermal activity. Sources: Figure adapted from IEA (2025), Opportunities for district heating in the changing energy landscape, with additional analysis based on ThinkGeoEnergy and Marina, A. et al. (2021), An estimation of the European industrial heat pump market potential.

A wide range of heat sources can be integrated with heat pumps in district heating.

## Deployment in industry

## Current status

## Heat pumps are starting to be adopted in industry

paper and chemical sectors have the highest deployment potential, as a large portion of their processes are at suitable temperatures.

Use of heat pumps in industrial environments is not new but remained very low until a recent acceleration in deployment. High capital cost, technological complexity, grid connection delays and limited awareness have all constrained uptake. Today, however, companies are looking for ways to improve energy efficiency, recover waste heat and diversify their energy mixes. In this context, heat pumps are becoming an increasingly attractive option. Deployment statistics are scarce, but more and more examples are now emerging, driven by policy support. In Japan, industrial heat pump capacity reached almost 650 MW in 2024 according to the JEHC, up from 290 MW a decade prior. Heat pumps are most well-suited to applications like drying, pasteurisation or supplying steam. Light industry (which includes food and drink, textiles and machine manufacturing), and the

## What's next?

## Technological innovation opens the door to new industrial applications

Industrial heat pump deployment accelerates in all IEA scenarios, thanks to greater awareness, policy support and resilience benefits. Additionally, technological innovation keeps increasing the potential for heat pumps at higher temperatures. Industrial heat pumps able to reach 120°C were first demonstrated around 2022, and commercial roll-out of machines reaching over 160°C is expected by 2027. In the STEPS, heat pumps supply 8% of heat demand in light industry in 2035. In the NZE Scenario, a stronger policy push results in faster deployment to supply 20% of demand in 2035.

Estimated share of heat pumps in heat supply to light industry by scenario (left), 2024-2035, and deployment potential as a share of heat demand per sector (right), 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario. * 2024 values are estimates.

Industrial heat pumps have the potential to supply up to 20% of industrial heat, mainly in light industry and the paper and chemical sectors.

## Cost-competitiveness of industrial heat pumps

## Current status

## What's next?

## Industrial heat pumps can compete with alternatives on cost

Industrial heat pumps are costly, with a capital cost about ten times greater than a gas boiler and three times that of a coal boiler. In addition, electricity prices are generally higher than for fossil fuels. However, heat pumps can compete with these alternatives over their lifecycle thanks to their efficiency, and the greater their Coefficient of Performance (COP), the lower their operating cost. For instance, in China, a heat pump with a COP under 2 would not be competitive against a gas boiler considering current prices, but if the COP is above 3, the balance would shift in favour of the heat pump.

## The COP of an industrial heat pump is mainly affected by one factor: the temperature lift

The temperature lift is the delta between the temperature of the heat source and the heat sink. A greater lift generally results in a lower COP, meaning that heat pumps using ambient air or water as a heat source have a limited temperature range in which they can be costcompetitive. The use of higher-temperature heat sources, such as industrial waste heat, provides a stepping-stone to reach much higher output temperatures while remaining competitive. The other main factor impacting competitiveness is the electricity-to-gas price ratio. In regions like the Middle East or the United States, where gas is relatively cheap compared to electricity, industrial heat pumps are less likely to compete with gas boilers on cost.

## Levelised cost of industrial heat pumps and gas boilers in China and the European Union (left) and industrial electricity and gas price in selected countries (right), 2025

<!-- image -->

Note: CAPEX = capital expenditure; OPEX = operating expenditure; COP = Coefficient of Performance.

The cost-competitiveness of industrial heat pumps depends on two key factors: their Coefficient of Performance and the electricity-to-gas price ratio.

## Pillar B. Deep dive on heat pumps in buildings

The most immediate opportunity for scaling up heat pump deployment is in the buildings  sector,  as  technology  is  mature  and  widely  applicable.  Uptake  in buildings is shaped by multiple factors, including climate, consumer preferences and cost-competitiveness, which vary across countries. Monitoring these factors is  critical  to  identify  opportunities,  as  well  as  any  barriers,  and  to  guide  policy interventions.

Pillar B of the Heat Pump Monitor examines current trends and future opportunities for heat pump deployment in buildings. It is structured around four sub-pillars affordability,  industrial  competitiveness,  energy  security,  and  innovation  and technology - to provide a comprehensive, policy-relevant overview of the market and its enabling conditions.

## Affordability

Affordability is widely recognised as a key challenge to heat pump deployment. While the lifetime costs of heat pumps are mostly favourable, especially in climates with both heating and cooling needs, upfront costs are typically higher than for conventional technologies, creating a potential burden for consumers. The ratio of electricity  to  natural  gas  prices  is  a  critical  factor  in  determining  whether  the additional upfront investment can be recovered over the system's lifetime.

The affordability sub-pillar of the Heat Pump Monitor explores regional variations in upfront, operational and lifetime costs, highlighting the opportunities that exist to  enhance the cost-competitiveness of deploying heat pumps across different markets.

## Upfront costs

## Current status

## Heat pump prices vary widely and are generally higher than alternatives

Retail prices of equipment differ within and across regions, depending on factors including heat pump type, building design and the existing heating infrastructure. China stands out as the most cost-competitive region across all product categories, thanks to its large manufacturing base with strong government support. However, even within comparable regions and product segments, heat pump prices differ as much as 60% between lowerand higher-cost products. Despite this, heat pumps remain more expensive on average than competing heating technologies, which continues to be a major barrier to deployment. In addition, in Europe and the United States, installation costs are often high, sometimes even higher than equipment costs, further increasing the overall investment required. As a result, many markets still rely on public subsidies to make heat pumps attainable for most consumers.

## What's next?

## Reducing costs requires sustained industrial investment, policy support and workforce development

As heat pumps have become more efficient, and gained additional features, their prices have remained largely stable over time. Following this trend, no drastic price drops are expected in the short term. However, China's experience has demonstrated that lowering equipment costs is possible, and other regions could further reduce upfront costs through sustained investment in manufacturing and supply chains. Structural changes like this would take time, meaning that targeted financial incentives for consumers, such as subsidies on investment, would remain necessary to sustain market growth in the interim. In parallel, in regions with high installation costs, expanding skills training, improving market and price transparency and standardising installations will be critical to lowering overall installation costs.

## Equipment cost distributions of bestselling heat pumps by product category and region, 2025

<!-- image -->

IEA. CC BY 4.0.

Note: A2W = air-to-water (monoblock); DHW = Domestic Hot Water heater including water tank.

Sources: IEA analysis based on data from JD.com, Kakaku, Klimatime, Climamarket, Klimango, Klima-sklep, Airecomfort,

HVACDirect

Heat pump prices and capacities vary widely across regions and products, although China has the lowest-cost options in all categories.

## Operational costs

## Current status

## Affordable electricity is key to heat pump cost-competitiveness

## What's next?

## Price ratios are unlikely to change without targeted efforts

Heat pumps are 3-5 times more efficient than natural gas boiler alternatives but usually have higher upfront costs. For heat pumps to be cost-competitive, the ratio of electricity price to natural gas price must be sufficiently low for the additional upfront investment to be recovered over the equipment lifetime. Data show that the countries with the lowest price ratios also tend to have the highest market shares of heat pumps. In addition, several countries with favourable price ratios have also historically had long-term policy support for heat pump uptake. There are also some exceptions to the price ratio trend, most notably China and the Netherlands, where the heat pump markets have started to grow more recently.

The annual average electricity to natural gas price ratio has remained relatively stable over time in most regions, and any big changes have been largely due to sudden price shocks, such as the 2022 energy crisis. However, energy markets remain dynamic and rapidly evolving, which is likely to affect electricity-togas price ratios over time. Governments do have tools at their disposal to alter this trend, for example by adjusting energy taxes and levies as well as electricity tariffs. One option could be to reduce tax on electricity used for heating, as has previously been done in Denmark and Finland, for example. Heat pumps with intelligent operation are also becoming more common and when combined with hot water storage tanks and time-of-use electricity pricing, can reduce operational costs by using electricity when it is cheapest.

## Heat pump market shares with respect to gas boilers and relative to the electricity to natural gas price ratio (annual averages) in selected countries, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: Market share is based on unit sales of heat pumps and gas boilers. The electricity price for Denmark includes the reduced tax. Energy prices for EU member states as per Eurostat, others by the IEA Energy Prices Database Sources: IEA analysis based on data from EHPA, METI, JRAIA, AHRI, ChinaIOL (2025).

Electricity to natural gas price ratio is the most influential factor in determining heat pump cost-competitiveness compared to natural gas boilers.

## Lifetime cost

## Current status

## Heat pumps are often cost-competitive over their lifetime, but costs vary widely

In many cases, heat pumps are already costcompetitive with conventional alternatives over their lifetime. The lifetime cost of owning (also known as Total Cost of Ownership) a heat pump (based on the levelised cost of heating and cooling) depends on multiple factors, including equipment cost, installation cost, equipment lifetime and energy price. This means that the lifetime cost can vary widely between households, even within the same region and with identical use. Typically, while heat pumps have a higher upfront cost than conventional alternatives, they have lower operational costs thanks to their higher efficiency, despite high electricity-to-gas price ratios in some countries.

## What's next?

## There are several policy options available to address the lifetime cost of heat pumps

Depending on the region and use case, upfront investment costs and operational costs contribute differently towards the lifetime cost. Electricity cost is among the most important factors to address to reduce lifetime cost, especially in countries with a high electricityto-gas price ratio. An example of a policy measure suitable for these cases is to adjust energy taxes and levies as well as electricity tariffs (e.g. time-of-use pricing) and support flexible demand. Upfront costs - such as for equipment and installation - also affect consumer decisions. Direct subsidies towards the equipment cost are a common approach used to drive uptake, but other options such as low-interest loans, 'Heating as a Service' or leasing business models can also be used.

## Levelised cost of heating and cooling for selected cities and use cases (unsubsidised), 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: AC = Air conditioner; HP = Heat pump; DHW = Domestic Hot Water; NG = Natural gas condensing boiler; Dir.El = Direct electric heating. In regions with both heating and cooling needs, reversible air/air heat pumps are assumed to be used for both purposes. Assumes a 3% discount rate and 15-year lifetime for ACs, gas and air/air HPs, and an 18-year lifetime for air/water HPs.

Heat pumps are used in a variety of ways based on heating and cooling needs; in many cases they are cost-competitive over their lifetime, but costs vary widely.

## Energy security

Heat pumps can play a strategic role in enhancing energy security by reducing reliance  on  fossil  fuels,  especially  natural  gas  for  building  heating,  helping countries  manage  imports  and  diversify  energy  sources.  However,  this  shift increases reliance on the electricity grid for security of heating and increases total and peak electricity demand during cold periods. At the same time, switching to heat  pumps  also  creates  opportunities  to  provide  flexibility  and  support  grid management.

The  energy  security  sub-pillar  of  the  Heat  Pump  Monitor  examines  how  heat pumps  both  reduce  natural  gas  demand  and  influence  peak  electricity  loads, offering insights to inform system planning and policy design.

## Peak electricity demand and flexibility

## Current status

## What's next?

## Increased heat pump adoption in buildings is raising electricity demand, but heat pumps remain a manageable share of total peak electricity load

## Heat pump peak demand grows rapidly to 2035 and offers opportunities for power systems flexibility

Electrifying heating through heat pumps adds a new thermosensitive load to power systems, increasing electricity demand during cold periods. This requires consideration of electricity security and resource adequacy, particularly during extreme weather events such as cold spells. Today, peak heat pump electricity demand ranges from around 2% to 16% of the overall peak - and sometimes higher shares locally - amounting to about 10 GW in Japan and 130 GW in the United States. The pace of heat pump electricity demand growth will be further shaped by income growth (which affects living standards and floorspace per household), building insulation levels and improvements in heat pump efficiency.

In absolute terms, peak heat pump demand rises rapidly to 2035 in all scenarios. However, their contribution to system-level peak demand remains limited, as overall peak growth is also driven by other rising loads, notably electric vehicles and air conditioning. In Japan, China and the United States, summer peaks continue to exceed winter peaks, meaning system sizing is more influenced by cooling demand, including from reversible heat pumps. In addition, heat pumps are set to become an important source of system flexibility. By leveraging buildings' thermal inertia, water storage, coupling with other heating equipment and recent manufacturer advances in controllability, heat pumps can shift electricity consumption in response to grid or price signals, thereby lowering pressure on electricity grids and enabling renewables integration.

## Heat pump peak electricity demand and share of heating demand covered by heat pumps in the Current Policies Scenario and Stated Policies Scenario, 2024-2035

Note: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario.

<!-- image -->

Higher heat pump deployment adds new loads to electricity systems, but their high efficiency mitigates peak demand impacts.

## Natural gas security

## Current status

## Heat pumps contribute to reducing demand for natural gas

## What's next?

## Heat pumps will remain important to reducing reliance on energy imports

In Europe and Japan, heating in buildings represents around 50% of total natural gas demand. In China, this share is around 20%, as use in industry plays a larger role. Without heat pumps, reliance on natural gas would likely be even higher: In 2024, if all alreadyinstalled heat pumps had instead been replaced with natural gas boilers, annual natural gas demand for heating buildings in Europe would have been an estimated 12% higher (20 billion cubic meters (bcm)). In Japan and China, it would have been around 35% higher (6 bcm and 25 bcm, respectively). Data for 2025 shows that gas savings from heat pumps has continued to increase, reaching a combined 53 bcm for the three regions.

As countries seek to enhance energy security and resilience at the national level, many are now aiming to reduce and diversify energy imports. For example, Japan aims to increase the share of oil and gas demand that is domestically controlled to 50% by 2030, and the European Union aims to phase out Russian gas imports by the end of 2027. In 2024, Europe relied on net imports to cover about half of its total natural gas demand. In China, around 40% of demand was met by imports, and in Japan, almost 100%. Further deployment of heat pumps has significant potential to reduce natural gas demand and reliance on imports, contributing to policy objectives on energy security. In 2024, there were a total of over 200 million natural gas boilers used for space heating in the latter three markets, with heat pumps still only covering a small share of heating needs.

## Natural gas demand for heating in buildings, additional demand potentially avoided by heat pumps, and share of space heating met by heat pumps, 2024

<!-- image -->

Notes: Accounts for natural gas demand used for electricity generation for heat pumps. The 2024 natural gas intensity for heating and electricity generation is assumed to be the same as the 2020-24 average. Share of space heating needs is by equipment stock.

Heat pumps are already curbing natural gas demand in Europe, China and Japan, with room to further support energy security and reduce reliance on imports as uptake grows.

## Industrial competitiveness

Manufacturing and trade are central to the competitiveness and availability of heat pumps. Production is geographically diverse, with most major markets sourcing the majority of heat pumps domestically, although the production of components such  as  compressors  remains  concentrated  in  a  few  regions.  Growing  global demand presents opportunities  to  expand  manufacturing,  but  scale-up  can  be constrained by short-term shifts in policy signals, supply chain bottlenecks, and shortages of skilled workers.

The  industrial  competitiveness  sub-pillar  of  the  Heat  Pump  Monitor  examines manufacturing  and  trade  patterns,  regional  variations  in  production  costs,  and workforce and skills  gaps  that  can  affect  capacity  to  meet  growing  heat  pump demand.

## Employment

## Current status

## The global heat pump workforce has grown 50% since 2015, but mass rollout places strains on supply of workers

installers must supplement their plumbing training with courses on the mechanics of heat pumps, electrical installation, safety standards and handling of F-gases.

Nearly 800 000 workers globally currently work principally on heat pumps, or 1% of the total energy workforce. Manufacturing, installation and repair together account for nearly three-quarters of jobs, which are concentrated in three major regions - China, Europe and the United States. As with many other parts of the energy sector, the mass rollout of heat pumps faces bottlenecks due to shortages of vocationally trained workers, namely HVAC installers and plumbers. In addition, inadequate training and experience have sometimes resulted in poor-quality installations and negative public perceptions. The skills gap is especially pronounced in Europe, where water-based heating systems are more common, meaning existing boiler

## What's next?

## Heat pump jobs are projected to grow by 2035 in all scenarios

Demand for heat pump workers is expected to continue to grow over the next decade in all scenarios, though at varying rates. In the CPS, in which heat pump sales remain lower than in other scenarios, the pace of employment growth slows relative to recent years, with a 30% increase by 2035. This rises to 60% in the STEPS, on par with recent trends, and up to 140% in the NZE Scenario. Meeting future demand for labour to deliver on heat pump installations would require an immediate ramping-up of vocational education, given existing shortages and the time required for training and gaining practical experience.

## Heat pump employment by region, scenario and economic activity, 2015-2035

<!-- image -->

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario. The number of jobs per economic activity corresponds to the number of workers in each activity who work principally on heat pumps, and is based on data from 2024.

Demand for heat pump workers is set to continue growing rapidly over the coming decade, adding to existing strains on the supply of skilled workers.

## Manufacturing and trade

## Current status

## Differing local preferences and standards mean that heat pump manufacturing is geographically diverse, and trade is limited

## What's next?

## Growing demand opens up new avenues for manufacturing and trade globally

Unlike other key clean energy technologies, the supply chain for heat pumps is relatively diverse, although upstream steps such as rotary compressor manufacturing are more regionally concentrated, notably in China. In 2024, only around 15% of heat pumps installed in buildings worldwide (by capacity) were traded across borders, with most demand met by domestic production. In all major markets - China, the United States, Europe and Japan - over 70% of heat pumps sales in 2024 were sourced locally. Global manufacturing capacity in 2024 stood at around 145 GW/yr, led by China (35%), followed by the United States (25%) and the European Union (20%).

Both current policies and stated policy intentions point towards a global increase in demand to 2035, and, therefore, to manufacturing capacity, although the role of trade is less certain. Heat pump manufacturing is relatively localised and can scale quickly in response to predictable demand (the typical lead time for a new factory is 1-3 years), but this does not always happen smoothly. Shortterm policy signals, sudden demand surges, or shortages of skilled labour and components can all delay capacity expansion. As a result, domestic production may lag behind demand growth, increasing reliance on imports. Countries with strong air-conditioner manufacturing industries, especially China, are well positioned to quickly expand heat pump and component production by repurposing existing production lines for air conditioners, and would require only limited investments to adapt to requirements in other regions.

## Global heat pump manufacturing and demand by region in the Current Policies Scenario and Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario. The left-hand side figure is based on data for 2024.

China's dominance in air-conditioner manufacturing positions it to rapidly scale up exports in response to growing heating and cooling demand globally.

## Levelised cost of production

## Current status

## Economies of scale have made China the lowest-cost heat pump producer

Heat pump production costs vary widely by region, shaped by manufacturing conditions (skills, infrastructure, energy and labour) and market factors such as product type, size, compressor choice and standards. Given that final assembly is not an energy-intensive process, components and materials dominate production costs (60-85%), favouring countries with competitive and well-integrated heat pump component manufacturing and access to materials. China has a major advantage, especially for air-to-air units, which share supply chains and manufacturing processes with air conditioners. Air-to-air heat pumps cost about 40% less to produce in China than in Japan, while air-to-water units remain around 60% more expensive to produce in Europe than in China. Most of the production cost gap is due to economies of scale, vertical integration and lower labour cost.

## What's next?

## Competitiveness requires stable demand at scale - not just lower production costs

Several levers could help narrow the production cost gap with China, including automation, industrial clustering and deeper collaboration through joint ventures and technology partnerships. However, closing the cost gap will be challenging. In addition, production cost has a limited effect on final retail prices, particularly for air-to-water heat pumps. Stable, predictable demand is critical to ensuring economies of scale that can support the competitiveness of local manufacturing. Demand is highly sensitive to electricity-to-gas price ratios, as well as to the final end-user costs, for which installation and distribution costs also play an important role, especially in Europe.

## Levelised cost of production by main cost components, 2024

Notes: OPEX = operational expenditure; CAPEX = capital expenditure. Retail cost includes only the outdoor unit for the United States, and only the equipment cost for all other regions.

<!-- image -->

The competitiveness of heat pump manufacturing depends on supply chain integration and scale, which ultimately hinges on market design, demand stability and energy price signals.

## Innovation and technology

Technological development remains key to enhancing the performance, sustainability and cost of heat pumps and, as a result, their adoption in the market. Although heat pump technology is already mature, continuing innovation enables new applications across different climates and building types, lowers operating costs,  improves  integration  with  buildings  and  power  systems,  and  supports higher-temperature or industrial uses. Innovation is also crucial in the context of refrigerant  transitions,  which  present  both  opportunities  and  challenges  for manufacturers.

The  innovation  and  technology  sub-pillar  of  the  Heat  Pump  Monitor  highlights emerging technological  developments,  examines  trends  in  heat  pump patents, and explores the opportunities and implications arising from shifts in refrigerants.

## Technology development

## Current status

## Heat pumps are a mature technology

The global market for heat pumps in buildings is mature and experiencing strong growth, as the technology has now been in commercial use for more than 100 years. Virtually all heat pumps commonly found in buildings use the vapour-compression cycle, mostly operating with hydrofluorocarbon refrigerants.

## What's next?

## Innovations are expanding in the heat pump market

Deployment of alternative heat pump designs to date (such as absorption and adsorption) is limited to niche markets, while some new designs (such as thermo-acoustic and membrane heat pumps) are still under development and have not yet reached commercialisation. R&amp;D in heat pump technology is being undertaken worldwide, led by multinational companies such as Daikin, Midea, Nibe and Carrier, as well as by international collaborations such as the IEA Technology Collaboration Programme on Heat Pumping Technologies.

Much of the ongoing innovation in heat pump technology concentrates on expanding use cases and improving the efficiency, connectivity and flexibility of vapour compressor units. Another area of innovation relates to the thermodynamic cycle - either the application of new types of refrigerants or use of other novel thermal cycles that do not require any refrigerants at all. In the short term, heat pumps with innovations such as natural and hydrocarbon refrigerants and flexible operation will become more common on the market. In the longer term, novel technologies such as thermo-acoustic and solid-state heat pumps might start to appear on commercial markets.

## Heat pump technology development milestones and current state, 1748-2026

<!-- image -->

IEA. CC BY 4.0.

Note: IoT = Internet of Things, heat pumps with network connectivity for data exchange with other devices. Sources: IEA analysis and Zogg, M. (2008), History of heat pumps: Swiss contributions and international milestones.

Innovation can increase the added value and efficiency of heat pumps in all applications.

## Patents

## Current status

## Heat pump patenting has surged since 2010

Heat pump patenting activity around the world has increased nearly fivefold since the 2000s - twice the average increase seen in other technologies - as R&amp;D and innovation in heat pumps have expanded. Japan saw a sharp increase in patents in the late 2000s, encouraged by government-backed innovation programmes. In addition, Japan and Korea host the headquarters of many leading airconditioning manufacturers, making them hubs for patent filings and intellectual property (IP) ownership. Patenting in China has grown steadily since 2000, positioning the country as an industry leader, with about one-third of all heat pump patents in 2022. Patenting efforts in Europe and the United States have also continued, although growth has been slower. The increase in patenting activity in the late 2000s was largely driven by applications for the buildings sector, but patents for industrial applications have also risen steadily over the past two decades.

## What's next?

## Patenting activity is expected to remain high, driven by innovations in electrification, system integration and refrigerants

China has recorded the highest patenting activity in nearly all categories in the past few years and is expected to retain this lead in the years to come. Since the 2010s, patenting in the transport sector has accelerated as electric vehicle sales have grown. This trend responds to the absence of combustion engine waste heat in electric -vehicles, which instead incentivises integrated thermal management solutions using heat -pumps. Korea and China have led patenting efforts in this sector in recent years. While most heat pump innovations are likely to remain at the component level (e.g. compressors, heat exchangers), advances in software, system integration and low-global warming potential (GWP) refrigerants are also expanding.

## Heat pump patenting activity, 2000-2022

<!-- image -->

Notes: Shows a count of International Patent Families (IPFs), each of which represents a unique invention and includes patent applications filed in at least two countries. Country contributions on the left are exclusive; patents may appear in multiple categories on the right.

Source: IEA analysis based on European Patent Office PATSTAT patents database accessed through the OECD Micro-data Lab.

Patenting in heat pump technologies has risen sharply and is expected to remain high, driven both by continued innovation in long-established firms and China emerging as a new player.

## Refrigerants

## Current status

## A refrigerant shift is underway

Historically, most heat pumps have relied on hydrofluorocarbons (HFCs) as refrigerants, many of which have very high global warming potentials (GWPs), more than 2 000 times that of CO  (e.g. R-410A). Emissions can occur ₂ through leakage during heat pump operation, servicing and improper handling at end of life. Today, heat pumps in buildings use a broad range of refrigerants. R32, with a GWP of 675 (significantly lower than old HFC), is widely deployed as a mid-transition option, alongside emerging lower-GWP alternatives such as Hydrofluoroolefin (HFO)/HFC blends (e.g. R-454B in the United States) and natural refrigerants, notably CO2 in Japan and propane in Europe. In China, R32 is the predominant refrigerant and the share of R410A is declining.

## What's next?

## International action paves the way for a major cut in HFC emissions

The Kigali Amendment to the Montreal Protocol, in force since 2019 and ratified by 172 countries as of June 2026, aims to cut HFC use by over 80% globally by 2050 through country-specific phase-down schedules. In parallel, the European Union has adopted a stricter F-gas Regulation. Heat pumps account for as much as 15% of HFC use in countries with higher uptake, such as the United States or parts of Northern Europe. To meet these targets, it is expected that refrigerants used in heat pumps will shift to low GWP refrigerants (GWP &lt;150) in Europe -and Japan by the end of the 2020s, and in China and the United States by the early 2030s. This is forcing manufacturers to redesign equipment and address safety challenges linked to low-GWP refrigerants (such as high pressures or flammability), while maintaining high efficiency and similar unit sizes, and adapting to regional regulations.

## Hydrofluorocarbon consumption phase-down under the Kigali Amendment in key heat pump markets, 2020-2050

<!-- image -->

Notes: Values to 2024 are actual; later values are projected under full Kigali and F-gas compliance. While heat pumps can transition to low-GWP or natural refrigerants, other applications, such as aerosols and foams, still require HFCs, so overall limits do not reach zero.

Sources: IEA analysis based on UNEP, EEA, US EPA, and JRAIA.

The ongoing shift to low-GWP refrigerant alternatives is creating regulatory pressure for manufacturers but opens new opportunities for innovation.

## Pillar C. Regional insights

Heat pump markets vary widely across regions, and their differing characteristics influence both rates of heat pump adoption and the policy measures that are most effective.

Pillar C of the Heat Pump Monitor examines key markets, including China, Europe, Japan and the United States, assessing market trends, policy frameworks, cost structures  and  technical  potential  from  each  region.  This  analysis  highlights lessons learned, transferable practices and opportunities for tailored interventions to support wider deployment.

## China

## Current status

## China has become the world's largest heat pump market, shaped by distinct regional heating practices

Deployment has grown at the buildings level and in centralised district heating, including with geothermal systems. Growth in distributed units has been driven by air pollution control and economic incentives such as the coal-toelectricity and 'trade-in' programmes, stricter building energy codes and uptake in regions with heating and cooling demand. In northern urban China, district heating dominates, but distributed systems are emerging, including heat pumps. In the urban hot summer and cold winter zone, central heating is largely absent, and rising incomes have led to rapid growth in residential distributed solutions, such as heat pumps that provide flexible, part-time heating and cooling. These are already common in the services sector. In rural areas, space heating has historically relied on coal and traditional biomass stoves, but targeted policies are accelerating a shift towards heat pumps and other electric technologies. Hot water production is typically separate from space heating; heat pump water heaters are gaining ground, but conventional technologies remain dominant.

## What's next?

## Rapid growth in deployment is expected

Air-to-air heat pumps are often the most costcompetitive decentralised solution in China, but air-to-water systems compete with electric and gas heating in colder climates, and ground-source heat pumps can be costeffective for large buildings, despite higher upfront costs. These favourable economics and policy support - are expected to drive a strong increase in installed capacity in buildings by 2035, especially in rural areas across the whole country, cities in central parts of China, and new urban developments in northern China.

## Decentralised heat pump stock in Chinese buildings in the Current Policies Scenario and Stated Policies Scenario, 2022-2035

<!-- image -->

Note: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario. Source: Updated from IEA (2024), The Future of Heat Pumps in China.

Heat pump deployment in China is set to accelerate through 2035, with growth expected both in air- and water-distribution systems.

## What is China's role in the heat pump supply chain?

## Current status

## What's next?

## China is a world-leader on heat pump production, with a domestic supply chain that is often vertically integrated

China's role in the global supply chain is concentrated in specific segments; for assembly of heat pumps, manufacturing outside China is sufficient to meet demand in most heating regions. However, manufacturing capacity for small air conditioners - which share components with heat pumps - is heavily concentrated in China. Notably, about 90% of rotary compressor manufacturing capacity is located in China, which creates an acute vulnerability in the supply chain. By contrast, scroll compressor manufacturing and refrigerant feedstock (fluorspar) production are more geographically diversified, reducing exposure to disruptions.

## Rising heat pump demand globally might increase reliance on Chinese manufacturing, but policy stability can increase supply chain diversity

Increasing electrification of heating - mostly driven by stricter building energy codes, heating policies and efficiency incentives - is expected to accelerate heat pump adoption. China has shown it can rapidly increase exports, and by doing so could meet strong demand growth in countries where local manufacturers typically need more stable demand signals to scale production. Diversifying the supply chains for rotary compressors and small air conditioners is expected to remain challenging, but domestic heat pump assembly can help reduce deployment delays and limit price volatility - if stable policies are implemented in key markets. Further opportunities to diversify the supply chain arise from differing efficiency standards and shifts to low-GWP refrigerants.

## Share of manufacturing capacity for heat pumps, air conditioners and principal components in China and the rest of the world, 2024

<!-- image -->

IEA. CC BY 4.0.

Note: AC = Air conditioners.

Source: IEA (2026), Energy Technology Perspectives 2026.

China dominates manufacturing of small air conditioners and rotary compressors, but heat pump assembly, scroll compressors and fluorspar have more diverse supply chains.

## Europe

## Current status

## Europe's market has strong structural drivers, but recent sales volatility highlights continued dependence on stable policy support

## What's next?

2025 data show Europe's heat pump market recovering, and further growth is supported by the region's industrial base and policy frameworks

Europe accounts for more than 20% of global sales by capacity. Within the European buildings sector, air-to-water (hydronic) systems account for the largest share of sales, but some countries such as the Nordics tend to prefer air-to-air units. In 2025, France, Italy and Germany led in terms of total units sold, while Norway, Finland and Sweden had the highest share of installations by household, reflecting early adoption. After double-digit growth in 2022, driven by energy security concerns and the announcement of more than USD 2 billion in manufacturing investment, market conditions weakened in 2023, and total sales declined in 2024, apart from in the United Kingdom and Ireland, where sales continued to grow. Europe also has a strong presence within the industrial and district heating heat pumping sectors, showcasing a wide array of demonstration cases within the two sectors.

Data for 2025 shows a return to growth for the European heat pump market, with particularly strong annual growth for some countries, including Germany and Sweden. Europe benefits from a strong industrial base, technological leadership and an evolving policy framework. In the European Union, REPowerEU, the revised Energy Efficiency, Energy Performance of Buildings and Renewable Energy Directives, together with the Net-Zero Industry Act and Clean Industrial Deal, can support deployment across all sectors. Electrification remains central: the European Commission's Electrification Action Plan aims to electrify 32% of final energy use by 2030, and then increasing to 46% by 2040. By 2035, heat pump stock is projected to nearly double in the CPS and to reach twoand-a-half times today's level in the STEPS.

## Heat pump sales in Europe's ten largest sales markets and sales in Europe by type in the Current Policies Scenario and Stated Policies Scenario, 2019-2035

<!-- image -->

Note: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario.

Heat pump sales in Europe have fluctuated, with diverging trends indicating solid markets in some countries while others remain reliant on policy support.

## How much natural gas could an accelerated heat pump roll-out save?

## Current status

## What's next?

## Current policies are supporting heat pump scale-up

## Heat pumps can drive immediate reductions in natural gas demand

Europe remains highly dependent on imported natural gas; about half of total natural gas supply was imported in 2024. However, diversification and demand reduction have become central aims of European policy since the energy crisis of 2022. From 2019-24, gas demand in buildings fell by 12%, driven by the combined effect of efficiency gains, milder temperatures and the energy crisis. In the absence of heat pumps, this decline would have been only 3%, leading to 20 bcm/year of additional gas

Several policies could further amplify a fall in natural gas consumption. In particular, REPowerEU prioritises cutting fossil fuel imports and calls for rapid heat pump deployment, backed by targets for national deployment and manufacturing in Germany and France. Europe's heat pump stock is projected to continue growing over the coming decade in the CPS and STEPS, avoiding an additional 14 and 27 bcm/year of gas use by 2035, respectively. By contrast, full alignment with European heat pump targets - including REPowerEU and the UK target - could drive a more than threefold expansion, and raise gas savings up to 39 bcm/year - about 16% of today's net imports. While heating in buildings is the largest end-use of natural gas in Europe (accounting for around 50%), further savings could be made by expanding heat pump deployment in industry and district heating.

## Heat pump stock in Europe's buildings and avoided natural gas consumption in the Current Policies Scenario, Stated Policies Scenario and in an accelerated deployment case, 2019-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario. 'Targets' is based on the assumption that the targets of the RePowerEU and the UK target to 2030 are achieved and that these trends continue to 2035. Natural gas consumption includes all buildings end uses. Accounts for natural gas demand used for electricity generation for heat pumps.

Scaling up heat pump deployment could cut European natural gas consumption by 14-39 bcm/year by 2035, reducing dependency on imports.

## Japan

## Current status

## Japan is experiencing a structural shift in heat pump manufacturing, technology, and market competition

## What's next?

## Japan's heat pump leadership faces new challenges

Japan accounts for around 7% of global heat pump sales and hosts the headquarters of several major manufacturers. The Japanese market is mature and has largely remained flat for several years. It is dominated by reversible air conditioners, which are the most popular type of space heating equipment, even surpassing the combined share of oil and natural gas boilers. Air conditioner ownership (including air-to-air heat pumps) has reached an average of 2.8 units per household - more than anywhere else in the world. These smaller standardised units are increasingly imported, particularly from China, whereas larger systems and heat pump water heaters, as well as their components, are predominantly manufactured domestically. Japan has the highest energy efficiency standards across global markets, but progress on improvements has slowed in recent years.

In the CPS, there is no growth in the heat pump market by 2035, whereas in the STEPS there is modest growth in space heating, and sales in water heater units double. Japanese manufacturers' strengths in compressors, refrigerants and system integration provide a solid base to strengthen competitiveness in global heat pump markets, particularly in highefficiency, high-reliability segments that are subject to increasingly stringent refrigerant regulations. Sustained policy signals will be crucial for Japan to maintain its technological edge as global heat pump markets continue to expand. Mechanisms such as the forthcoming implementation of the Top Runner programme 2027 aim to support further R&amp;D-led improvements, combined with a strategic focus on component leadership and advanced refrigerant solutions.

## Share of domestic heat pump production by segment in Japan, 2000-2024, and energy performance of small air-to-air heat pumps under the Top Runner programme, 2007-2030

<!-- image -->

Notes: HPWH = heat pump water heater. Domestic production excludes firms receiving products from overseas. Energy performance data since 2022 is based on the forthcoming Top Runner programme (TR2027). Small air-to-air heat pumps refer to 2.8 kW units. Japan APF (Annual Performance Factor) is a seasonal efficiency metric combining annual heating and cooling performance.

Source: IEA analysis based on data from METI.

<!-- image -->

Domestic production has slowed in recent years, while energy efficiency gains have plateaued as technologies mature.

## What is driving adoption of heat pump water heaters?

## Current status

## Japan's Eco-cute heat pump water heater is a global benchmark for innovation and efficiency

efficiency and lower lifetime cost than alternatives. However, deployment varies significantly by region, driven by lifetime cost and dwelling types.

Since 2000, water heating has accounted for around 20% of final energy consumption in buildings, with about 80% of such demand supplied by fossil fuels. In residential buildings, water heating demand exceeds that of space heating, reflecting cultural preferences for baths. To reduce the associated energy consumption and CO2 emissions, the 'Eco-cute' - the market nickname for a CO2 refrigerant-based heat pump water heater - was developed and introduced in 2001. Deployment has since expanded rapidly, capturing around 10% of the water heating market within a decade, although natural gas units remain dominant. Early uptake was backed by policies such as financial incentives and, more recently, policies encouraging participation in demand response have started to be planned. In most cases, the Eco-cute offers substantially higher

## What's next?

## Harmonised standards and targeted incentives could expand Eco-cute adoption

Current Eco-cute standards are mainly designed for detached housing and focus on system resilience, setting requirements for water tank size. Aligning such standards more closely with those applied to gas and other types of water heaters could unlock greater deployment, particularly in areas with lower adoption. At the same time, subsidies for a wide range of equipment - including hybrid water heaters, fuel cells and high-efficiency gas and oil systems - shape the relative economic attractiveness of heat pump water heaters. More targeted incentives for Ecocutes and the harmonisation of technical standards could strengthen their value proposition.

## Water heater sales, 2000-2025, and Eco-cute deployment by dwelling type and by region, 2023

<!-- image -->

IEA. CC BY 4.0.

<!-- image -->

Notes: WH = water heater; HP= heat pump; HDD = heating degree days. HPWH (heat pump water heater) refers to Ecocute. Oil-WH refers to kerosene, Gas-WH refers to natural gas and liquefied petroleum gas, Elec-WH refers to electric resistance.

Sources: IEA analysis based on data from METI and MoE.

The market share of heat pump water heaters has rapidly expanded, but further growth will depend on harmonised standards, targeted subsidies and overall lifetime cost.

## United States

## Current status

## Heat pumps now lead sales of new heating equipment in the United States

Heat pumps have been a mainstream technology in the United States for decades. As early as 1990, roughly 6.4 million homes (around 7% of households), and 450 000 commercial buildings (around 10% of the total), used a heat pump for space heating. Their footprint has continued to expand steadily: over the past decade, heat pump sales have almost doubled, and in recent years they have consistently outpaced natural gas furnace sales. In 2025, heat pump sales were around 12% higher than those of fossil fuel heating systems, and over 20% US households now rely on a heat pump as their primary heating equipment.

## What's next?

## Favourable economics, air conditioning replacement cycles and incentives underpin demand

The US heat pump market benefits from four structural tailwinds: firstly, generally favourable lifecycle economics in many regions, particularly where electricity prices are low or winters are mild; secondly, policy and market support at federal, state and utility level, including incentives and financing programmes that reduce upfront costs and encourage contractor uptake; thirdly, a large air-conditioning replacement pipeline that can 'upgrade' to heat pumps using established installers and supply chains; and fourthly, growing momentum in heat pump water heaters, which remain a small share of today's market but offer significant expansion potential. Together, these factors underpin continued market growth: under both current and stated policies, US heat pump sales are projected to double by 2035, translating into a substantial expansion of installed heat pump capacity in buildings.

## Market share of heat pumps versus natural gas furnaces (left), and market share of heat pumps versus air conditioners (right) in the United States, 2010-2025

<!-- image -->

IEA. CC BY 4.0.

Notes: Market shares based on unit sales. Air conditioners include systems used only for cooling, while heat pumps include reversible systems that can be used for heating and/or cooling.

Heat pump sales have more than doubled since 2010 and now outsell gas furnaces, in part driven by systems that can be used for both heating and cooling.

## Can the existing air-conditioning stock offer a rapid entry point for heat pumps?

## Current status

## What's next?

## AC systems are already widespread

More than 90% of US households use air conditioning (AC). Of these, around 75% rely on central AC systems with ducts and distribution infrastructure already in place. A large share of these central AC systems are designed for cooling only, even though upgrading to a reversible system typically costs just USD 200-500 more than purchasing a non-reversible unit. In colder regions, systems sized for cooling may need to be upsized to cover peak heating loads, increasing installed costs. Even so, heat pumps can still meet most annual heating demand or operate alongside existing systems during peak periods.

## End-of-life replacement of AC systems could provide an opportunity to scale heat pumps

If, at end of life, every cooling-only air conditioner was replaced by a reversible system that could also be used for space heating, heat pumps could supply heating in roughly 60% of US households by 2035. This shift would be gradual, in step with predictable replacement cycles, but the physical prerequisites for warm-air heat delivery are often already in place. Over time, the normal replacement of older AC units could translate into a large expansion of heating-capable heat pumps, even without a one-off retrofit push. Under both current and stated policies, the share of households using heat pumps reaches more than 35% by 2035. Exploiting the synergies between air conditioners and heat pumps can be a transformational lever for more rapid scale-up.

## Share of households using air-conditioning systems and heat pumps in the United States, 1980-2050

<!-- image -->

IEA. CC BY 4.0.

Note: Projections beyond 2025 assume that all central air conditioners are replaced by heat pumps at end of life. Source: IEA analysis based on data from EIA.

Upgrading existing central air conditioners to reversible heat pump systems at end of life could provide heating in 60% of households by 2035 at low additional cost.

## Pillar D. Policies

A range of policy measures exist to support heat pump adoption, either directly or indirectly,  and  these  vary  across  regions  and  sectors  depending  on  national priorities and institutional capacities.

Pillar D of the Heat Pump Monitor provides an overview of existing policies in key markets  and  highlights  notable  international  examples  across  different  policy types that may offer insights and inspiration for other countries.

## Policy mapping

Heat pump-relevant policies in selected countries

|                 |                  |             |                                      | CA    | CN    | FR    | DE    | IT    | JP    | KR    | UK   | US    |
|-----------------|------------------|-------------|--------------------------------------|-------|-------|-------|-------|-------|-------|-------|------|-------|
| Deployment      | Buildings        | Incentives  | Grants                               | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓    | ( ✓ ) |
|                 |                  |             | Loans                                |       |       |       |       | ✓     |       |       | ✓    |       |
|                 |                  |             | Tax credits and deductions           |       |       |       | ✓     | ✓     |       |       |      |       |
|                 |                  |             | Reduced VAT rate                     |       |       | ✓     |       | ✓     |       |       | ✓    |       |
|                 |                  | Regulations | Limits FFB use in new buildings      | ✓     | ( ✓ ) | ✓     | ✓     | ✓     |       |       | ✓    | ( ✓ ) |
|                 |                  |             | Limits FFB use in existing buildings |       | ( ✓ ) | ( ✓ ) | ✓     |       |       |       |      |       |
|                 |                  |             | MEPS                                 | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓    | ✓     |
|                 |                  |             | Labelling system                     |       | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓    |       |
|                 |                  | Energy &    | Carbon tax                           |       |       | ✓     |       |       | ✓     |       |      |       |
|                 |                  | Emission    | Emissions trading system             |       |       | ✓     | ✓     | ✓     | ✓     | ✓     |      |       |
|                 | Industry         | Incentives  | Grant, loans and tax credits         | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓    |       |
|                 |                  | Regulations | Heating electrification plan         |       |       | ✓     | ✓     | ✓     |       |       |      |       |
|                 |                  |             | Renewable energy targets             |       | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     |      |       |
|                 |                  | Energy &    | Carbon tax                           | ✓     |       | ✓     |       |       | ✓     |       | ✓    |       |
|                 |                  | Emission    | Emissions trading system             | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓    | ( ✓ ) |
|                 | District heating | Incentives  | Grant, loans and tax credits         | ✓     |       | ✓     | ✓     |       |       |       | ✓    |       |
|                 |                  | Regulations | Mandatory heat mapping               |       |       | ✓     | ✓     |       |       |       | ✓    |       |
|                 |                  |             | Renewable energy targets             |       |       | ✓     | ✓     | ✓     |       |       |      |       |
| Industrial      | Manufacturing    | Investment  | Incentives to manufacturer           | ( ✓ ) | ✓     | ( ✓ ) | ( ✓ ) | ( ✓ ) | ( ✓ ) | ( ✓ ) | ✓    | ✓     |
| competitiveness |                  | Employment  | Skills training                      | ✓     |       | ✓     | ✓     | ✓     |       |       | ✓    | ✓     |
|                 |                  | Refrigerant | F-gas regulation                     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓    | ✓     |
|                 | Trade            | Tariffs     | Equal or lower tariff than average   | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓     | ✓    | ( ✓ ) |

Notes: Policy status ✓ = applied nationally, ( ✓ ) = partially (e.g. by fuel as coal or oil only) or regionally applied. CA = Canada, CN = China, FR = France, DE = Germany, IT = Italy, JP = Japan, KR = Korea, UK = United Kingdom, US = United States. FFB = fossil fuel boilers; MEPS = minimum energy performance standards. Limits on FFB use in new/existing buildings include bans, clean heat standards (renewable quotas, restrictions on fossil fuel subsidies) and building energy codes. 'Tariffs' compares any heat pump tariffs to tariffs on similar goods between key trade partners. Does not include non-tariff measures.

Sources: IEA analysis based on IEA (2025) Global Energy Policies Hub; IEA (2025) World Energy Employment.

## International examples

## Current status

## Multiple policies support heat pump deployment, primarily in buildings.

For heat pumps in buildings, governments mainly use financial incentives, while long-term frameworks, regulatory and pricing reforms are less common. In district heating and industry, dedicated targets and regulations are limited, with progress driven by innovation funds, planning, pricing mechanisms  and  renewable requirements within broader heat or sectoral transition strategies.

| Policy measures and aims                               | Sector        | Selected international examples                                                                                                                             |
|--------------------------------------------------------|---------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                        | Buildings     | • Canada's Green Buildings Strategy provides a guide for building codes and regulatory actions to improve building performance.                             |
| Sustaining market signals Long-term strategic          | District heat | • Austria's national commitments to fully decarbonise district heating networks.                                                                            |
| frameworks                                             | Cross- sector | • China's Heat Pump Action Plan sets goals, targets and actions to accelerate the development, deployment and industrial competitiveness of heat pumps.     |
|                                                        | Buildings     | • Belgium (Flanders)'s ban on natural gas connections and fossil heating systems in new buildings.                                                          |
| Strengthening deployment Deployment targets, bans      | District heat | • Moldova's national energy & climate plan details planned measures to integrate about 7 MWof heat pump capacity into the two main district heat utilities. |
| Strengthening deployment Deployment targets, bans      | Industry      | • New Zealand's ban on new industrial coal boilers, and phase-out of existing ones by 2037.                                                                 |
| Strengthening deployment Deployment targets, bans      | Cross- sector | • Korea's Heat Pump Deployment Activation Plan targets 3.5 million heat pumps by 2035.                                                                      |
| Improving affordability -                              | Buildings     | • Canada's Oil to Heat Pump Affordability Program provides upfront grants to low - to median - income households switching from oil heating to heat pumps.  |
| upfront cost Grant, subsidies and financial incentives | District heat | • France's Fonds Chaleur subsidises renewable and recovered heat infrastructure.                                                                            |
| upfront cost Grant, subsidies and financial incentives | Industry      | • The Netherlands' SDE++ grant programme is directed at low-carbon heat solutions.                                                                          |
| Improving affordability - operational cost             | Buildings     | • Ireland's Renewable Heat and taxation support includes lower taxes on electricity and heat pump installations (e.g. reduced VAT).                         |

| Policy measures and aims                                         | Sector        | Selected international examples                                                                                                                                                                                                                                                  |
|------------------------------------------------------------------|---------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Tax reallocation, time-of-use rates, Carbon Pricing, Obligations | District heat | • The United Kingdom's Green Heat Network Fund for the development, commercialisation and expansion of low- and zero-carbon heat networks.                                                                                                                                       |
| Tax reallocation, time-of-use rates, Carbon Pricing, Obligations | Industry      | • Spain's Electro-Intensive Facilities Statute: A new Reserve Fund for energy (FERGEI) state-backed power purchase agreement (PPA) risk- sharing/guarantee mechanism for long-term renewable power purchase agreements.                                                          |
| Tax reallocation, time-of-use rates, Carbon Pricing, Obligations | Cross- sector | • The Netherlands' Energy Savings Obligation for large electricity and gas users to implement energy-saving measures with a payback period of 5 years.                                                                                                                           |
| Tax reallocation, time-of-use rates, Carbon Pricing, Obligations |               | • The Netherlands' reduced electricity taxes (2024-34).                                                                                                                                                                                                                          |
| Strengthening competitiveness                                    | Buildings     | • Canada's heat pump training for skilled workers. • Poland's restrictions ensuring only lab-tested units with heat pump quality certifications are eligible for its subsidy programme.                                                                                          |
| Skills training, and industrial policies                         | Cross- sector | • The EU Net-Zero Industry Act (NZIA) targets manufacturing and supply chains, with heat pumps listed as a strategic net zero technology.                                                                                                                                        |
| Supporting innovation Innovation funds,                          | Industry      | • The US Industrial Heat Shot Initiative targets R&D and demonstration of technologies that can cut industrial heat emissions by 85 %by 2035. • Japan's Green Innovation Fund supports long - term R&D, demonstration and industrial scale - up of decarbonisation technologies. |
| auctions                                                         | Cross- sector | • Canada's Strategic Innovation Fund provides financial support for large, transformative projects across sectors (including in manufacturing).                                                                                                                                  |

## Technical notes on the dashboards

## Common abbreviations

AC

Air conditioning

CPS

Current Policies Scenario

COP

Coefficient of Performance

GWP

Global warming potential

HFC

Hydrofluorocarbons

HP

Heat pump

HPWH

Heat pump water heater

HVAC

Heating, ventilation and air conditioning

IPF

International Patent Family

NZE

Net Zero Emissions by 2050 Scenario

STEPS

Stated Policies Scenario

TRL

Technology readiness level

## Heat pump definition

The  definition  of  heat  pumps  used  in  the  Heat  Pump  Monitor  for  buildings  is consistent with the definition used in the IEA Heat Pump Taxonomy: ' heat pumps used as primary heating equipment, intended as the main equipment providing heat and covering the majority of heating needs. The boundary includes reversible units (such as reversible air conditioners) when they serve as the primary heating equipment.  However,  units  used  solely  for  cooling,  or  as  a  minor  short-term complement to other heating equipment, are excluded .'

For industry, Mechanical Vapour Recompression (MVR) devices are considered as industrial heat pumps. Devices providing heating and cooling at the same time are also considered.

For  district  heating,  both  MVR  and  thermally  driven  heat  pumps  such  as absorption heat pumps are considered as district heating heat pumps. Devices providing heating and cooling at the same time are also considered.

Coefficient of Performance (COP) represents the ratio between thermal energy provided by the heat pump and the energy supplied to make it work.

## Deployment in buildings

Share of space heating needs refers to the share of useful energy demand for space heating covered by heat pumps.

Share of heat pumps using air-distribution systems over water-distribution ones is assessed  based  on  2024  sales  capacity.  Water-distribution  refers  to  hydronic systems,  while  air-distribution  refers  to  ducted  and  unducted  reversible  air conditioners.

Sources  of  historical  heat  pump  data  for  buildings:  European  Heat  Pump Association  (EHPA);  the  Air-Conditioning,  Heating  and  Refrigeration  Institute (AHRI);  the  Japan  Refrigeration  and  Air  Conditioning  Industry  (JRAIA),  and ChinaIOL.

## Deployment in district heating

Produced heat from absorption heat pumps utilised for flue  gas  heat  recovery inside combined heat and power (CHP) plants is reported based on the fuel the heat was derived from and is therefore not included in the metrics presented on heat supplied from heat pumps in district heating.

In  the  China  Building  Energy  and  Emission  Yearbook  2024  district  heating  is referred to as 'Northern Urban Heating (NUH)'.

In the figure 'District heating supply by source in China and Europe, 2022 and 2023',  heat  supply  sources  are  counted  as  follows,  based  on  the  categories presented in the original sources:

| Figure categories             | Original categories (Europe)                         | Original categories (China)                                                                  |
|-------------------------------|------------------------------------------------------|----------------------------------------------------------------------------------------------|
| Coal, oil, peat               | • Coal, oil & Peat                                   | • Coal-fired CHP for DH • Coal-fired heat-only boilers for DH                                |
| Bioenergy                     | • Bioenergy                                          |                                                                                              |
| Natural gas                   | • Natural gas                                        | • Gas-fired CHP • Gas-fired heat-only boilers for DH • Gas-fired individual household boiler |
| Other renewable               | • Geothermal • Solar Thermal                         | • Renewable energy heating                                                                   |
| Electricity (inc. heat pumps) | • Heat pumps & boilers                               | • Electrification                                                                            |
| Waste heat                    | • WH (flue gas) • WH (industry) • WH (non-bio waste) | • Industrial waste heating                                                                   |
| Other                         | • Other                                              |                                                                                              |

## Deployment in industry

Heat pump potential  per  industry  considers  the  heat  output  potential  for  those sectors.  For  the  food  and  tobacco,  chemical  and  paper  sectors,  the  same assumptions as in the article by Marina et al. (2021) are used. Other sectors either use a sector-specific assumption or an assumed deployment potential of 95% of temperatures below 60°C, 50% between 60°C and 100°C, 30% between 100°C and 150°C, 3% between 150°C and 200°C and no deployment potential above 200°C. The total amount of industrial heat demand is estimated using internal IEA data.

In  the  electricity-to-gas price ratio figure, average industrial end-user prices for 2024 are used. Those prices include specific taxes and network cost for industrial users associated with those fuels.

For levelised cost calculations, a discount rate of 8% is assumed. CAPEX includes equipment and installation cost but not grid connection cost.

2024 values are estimated using values from JEHC, IEA HPT TCP Annex 48, Annex 68, and ACEEE.

## Operational cost

In  the  electricity-to-gas  price  ratio  figure,  annual  average  residential  end-user prices for 2024 are used. Those prices include specific taxes and network cost for industrial users associated with those fuels. Prices for EU member states as per Eurostat; others as per the IEA Energy Prices Database.

## Patents

The number of International Patent Families (IPFs) is used as a proxy for unique inventions. An IPF is defined as a group of patent applications relating to the same invention that are filed in at least two national or regional patent offices.

Heat  pump-related  patents  are  identified  using  a  combination  of  relevant Cooperative Patent Classification (CPC) codes and a keyword search for 'heat pump'  and  related  terms  in  the  title  and  abstract  of  each  patent  document. Sectoral classification is based on the primary CPC codes assigned to each patent family.

In  cases  where  an  IPF  includes  multiple  inventors  from  different  countries, fractional counting is applied where each country is assigned a proportional share of the patent family.

It should  be  noted  that  this  approach  aims  to  capture  heat  pump-related technologies as comprehensively as possible. However, some patents relevant to heat  pump  technologies  may  not  explicitly  mention  'heat  pump'  in  the  title  or abstract,  and  in  certain  cases  abstracts  may  be  incomplete  or  unavailable.

Consequently,  the  results  should  be  interpreted  as  an  indicative  measure  of innovative activity in the heat pump sector based on the information available in the PATSTAT database, rather than as an exhaustive count that could only be obtained through a detailed manual assessment of individual patent documents.

## Refrigerants

The projections assume full compliance with the Kigali Amendment and the EU Fgas Regulation. In China's case, current HFC consumption remains well below the Kigali baseline limits, and prevailing market trends indicate a continued decline. As a result, the near term projections are set below the Kigali threshold levels. -

To estimate the share of HFC use attributed to heat pumps in the United States, 50% of HFC consumption in reversible air-conditioning systems is allocated to heat pump applications.

## Geographical scope

China: Includes (The People's Republic of) China and Hong Kong, China.

Europe: European Union  regional  grouping  and  Albania,  Belarus,  Bosnia  and Herzegovina, Gibraltar, Iceland, Israel, Kosovo, Montenegro, North Macedonia, Norway,  Republic of Moldova, Serbia, Switzerland, Türkiye, Ukraine and United Kingdom.

Caspian: Armenia,  Azerbaijan,  Georgia,  Kazakhstan,  Kyrgyzstan,  Tajikistan, Turkmenistan and Uzbekistan.

## Acknowledgements

This study was prepared by the Energy Technology Policy (ETP) Division of the Directorate of Sustainability, Technology and Outlooks (STO), with contributions and input from other divisions of the International Energy Agency (IEA). The study was led and co-ordinated by Chiara Delmastro, Energy Analyst - Buildings.

The  main  authors  of  this  study  are  (in  alphabetical  order):  Chiara  Delmastro, Jianlan  Dou,  Alexandre  Gouy,  Sangitha  Harmsen,  Rafael  Martinez  Gordon, Michael  McGovern,  Mazyar  Moghaddam,  Axel  Nordin  Fürdös  and  Anthony Vautrin. Konstantina Kalogianni and Gael Salinas also made key contributions.

Araceli  Fernandez  Pales,  Head  of  the  Technology  Innovation  Unit,  provided valuable feedback and overall guidance. Valuable comments and feedback were provided  by  other  senior  management  within  the  IEA,  in  particular,  Timur  Gül, Stephanie Bouckaert, Roberta Quadrelli and Daniel Wetzel.

Per-Anders  Widell,  Charlotte  Bracke  and  Bérengère  Merlo  provided  essential support throughout the process. Lizzie Sayer edited the manuscript.

Thanks  go  to  the  IEA's  Communications  and  Digital  Office  for  their  help  in producing the report and website materials, particularly to Andrea Pronzati, and Curtis Brainard, Astrid Dumond, Lucile Wall and Jethro Mullen.

Peer reviewers provided essential feedback to improve the quality of the work. They include:

Martin Andersen

Danish Technological Institute

Takahiro Asahi

Daikin

Johan Carlsson

European Commission, Joint Research Centre

Greta Corsale

European Heating Industry

Ezilda Costanzo

ENEA

Marco Dall'Ombra

Assoclima - ANIMA Confindustria

Fernando Diaz Alonso

Eurostat

Martin Forsen

NIBE

Duncan Gibb

RAP

Caroline Haglund Stignor

IEA Heat Pumping Technologies TCP

Andrej Jentsch

IEA District Heating and Cooling TCP

Masaru Matsui

Panasonic

Maurizio Pieve

ENEA

Stephan Renz

IEA Heat Pumping Technologies TCP

Silvia Rezessy

European Commission, DG ENER

Philippe Riviere

European Commission, DG ENER

Federica Sabbati

European Heating Industry

Guillaume Uguen

European Heat Pump Association

Hiromi Yamamoto

Tohoku University

Jie Yang

ChinaIOL

Metkel Yebiyo

IEA Heat Pumping Technologies TCP

Hengyi Zhao

China Heat Pump Alliance

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual Member countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

For further information, please contact: ETP (etp@iea.org).

<!-- image -->

Subject  to  the  IEA's  Notice  for  CC-licenced  Content,  this  work is licenced under  a  Creative  Commons  Attribution  4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area. Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA - July 2026 Cover design: IEA Photo credits: © ShutterStock

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those  of  the  IEA's  individual  Member  countries  or  of  any  particular  funder  or collaborator.  The  work  does  not  constitute  professional  advice  on  any  specific issue  or  situation.  The  IEA  makes  no  representation  or  warranty,  express  or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

For further information, please contact: ETP (etp@iea.org).

<!-- image -->

Subject to the IEA's Notice for CC-licenced Content, this work is licenced under a Creative Commons Attribution 4.0 International Licence.

This document and any map included herein are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications

International Energy Agency

Website: www.iea.org