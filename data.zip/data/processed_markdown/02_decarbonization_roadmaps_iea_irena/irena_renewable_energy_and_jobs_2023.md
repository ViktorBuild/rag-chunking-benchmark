---
document_id: irena_re_jobs_2023
title: "Renewable Energy and Jobs: Annual Review 2023"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IRENA"
year: 2023
original_file: "irena_renewable_energy_and_jobs_2023.pdf"
tables_detected: 39
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Renewable Energy and Jobs Annual Review 2023

E

D

E

D

<!-- image -->

In Collaboration with

<!-- image -->

H2

## © IRENA 2023

Unless otherwise stated, material in this publication may be freely used, shared, copied, reproduced, printed and/or stored, provided that appropriate acknowledgement is given of IRENA as the source and copyright holder. Material in this publication that is attributed to third parties may be subject to separate terms of use and restrictions, and appropriate permissions from these third parties may need to be secured before any use of such material.

ISBN: 978-92-9260-552-0

Citation: IRENA and ILO (2023), Renewable energy and jobs: Annual review 2023 , International Renewable Energy Agency, Abu Dhabi and International Labour Organization, Geneva.

## ABOUT IRENA

## ABOUT ILO

The International Renewable Energy Agency (IRENA) is an intergovernmental organisation that supports countries in their transition to a sustainable energy future and serves as the principal platform for international co-operation, a centre  of  excellence,  and  a  repository  of  policy,  technology,  resource  and financial knowledge on renewable energy. IRENA promotes the widespread adoption  and  sustainable  use  of  all  forms  of  renewable  energy,  including bioenergy,  geothermal,  hydropower,  ocean,  solar  and  wind  energy,  in  the pursuit of sustainable development, energy access, energy security and lowcarbon economic growth and prosperity.

www.irena.org

## ACKNOWLEDGEMENTS

Under the guidance of Rabia Ferroukhi, this report was authored by Michael Renner, Celia García-Baños and Arslan Khalid (IRENA). Hydropower jobs estimates are based on statistics provided by Dennis Akande (IRENA) and modelling contributed by Maximilian Banning (GWS). IRENA expresses gratitude for valuable contributions (Chapter 4) made by colleagues at the ILO, including Camila Pereira Rego Meireles, Casper Edmonds, Jose Luis Viveros Añorve and Moustapha Kamal Gueye, as well as Diana Junquera Curiel (IndustriALL). The authors also thank Divyam Nagpal (IRENA), IRENA national focal points for country data and Renata Grisoli (UNDP) for data on Brazil's bioethanol workforce.

For further information or to provide feedback, go to publications@irena.org

Download from www.irena.org/publications

## DISCLAIMER

This publication and the material herein are provided 'as is'. All reasonable precautions have been taken by IRENA to verify the reliability of the material. However, neither IRENA nor any of its officials, agents, data providers or other third-party content providers provide a warranty of any kind, either expressed or implied, and they accept no responsibility or liability for any consequence of use of the publication.

The information  contained  herein  does  not  necessarily  represent  the  views  of  the  Members  of  IRENA.  The  mention  of specific companies or certain projects or products does not imply that they are endorsed or recommended by IRENA in preference to others of a similar nature that are not mentioned. The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area, or the authorities thereof, or concerning the delimitation of frontiers or boundaries.

The International Labour Organization is  the  United  Nations  agency  for  the world  of  work.  We  bring  together governments, employers and workers to drive a human-centred approach to the future of work through employment creation, rights at work, social protection and social dialogue.

www.ilo.org

<!-- image -->

## FOREWORD

We are pleased to present this edition of IRENA's Renewable energy and jobs: Annual review ,  the tenth in the series and the third produced in collaboration with  the  International  Labour  Organization  (ILO).  The  report  embodies  the intersection of our agencies' respective mandates - namely the energy transition and decent work for social justice - and discusses key opportunities and challenges for workers, employers, communities and public policy makers.

This  year's  report  finds  that  renewable  energy  employment  worldwide  has  continued  to  expand  -  to  an  estimated 13.7 million direct and indirect jobs in 2022. We can expect the creation of many millions of additional jobs in the coming years and decades, provided that education and skills development programmes are appropriately expanded, workforce development programmes are put in place, and labour markets respond to evolving needs.

Nevertheless,  challenges  abound.  Today's  renewable  energy  jobs  are  concentrated  in  a  relatively  small  number  of countries, reflecting the uneven geographic footprint of equipment manufacturing and capacity installations. The detail and quality of available data varies among countries and between the different renewable energy technologies, and information on job quality and workforce diversity remains sparse. Yet, with each edition of this series, we shed more light on these aspects.

Renewable energy and other energy transition technologies are attracting growing investment; but even as spending rises and installations expand, new challenges emerge.  Climate change, technological advances, shifts in demographics and the global economic outlook, as well as other key developments may bring about adverse effects for employment. While each country rightfully aspires to derive socio-economic benefits from the energy transition, global solidarity is vital, as humanity confronts not only rising dangers from climate change but also deep social and economic divides.

The energy transition requires urgent collective action to reduce reliance on fossil fuels and towards clean energy; but it also must ensure that all persons have access  to basic human needs  and security of modern energy. We call upon policy makers to ensure that the uncertainties and disruptions inherent in the transition are minimised, and that efforts are made to close social protection gaps in the transformation process.

This year, in June, the International Labour Conference reaffirmed the urgency of action to advance a just transition to achieve social justice, decent work and poverty eradication, and to tackle environmental and climate change. During discussions, representatives of governments, workers and employers endorsed the 2015 Guidelines for a Just Transition as the central reference for policy making and basis for action.

It is critical that new jobs provide adequate wages and high standards of occupational safety and health. Fundamental principles  and  rights  at  work  must  be  upheld  and  workers'  voices  heard.  It  is  essential  that  communities  whose livelihoods now depend on fossil fuels be offered a stake in the new energy system through retraining and economic revitalisation strategies, wherever feasible. It is also vital that women have equal access to training and career paths in an industry that historically has been heavily male-dominated; that  jobs  be  created  for  youth  in  the  renewable  energy sector;  and  that  ethnic  minorities  and  other  vulnerable communities  be welcomed into a workforce that reflects the diverse spectrum of modern societies.

This will not only enable the renewable energy industry to tap a much wider pool of human talent, thus minimising or avoiding future skill gaps; it will also advance the goal of creating a more fair, equitable and truly sustainable world. There is much to do, but we are enthusiastic and confident that we can achieve these aspirations.

Francesco La Camera

<!-- image -->

<!-- image -->

Director-General International Renewable Energy Agency

Gilbert F .  Houngbo

Director-General International Labour Organization

<!-- image -->

## TABLE OF CONTENTS

| Foreword . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .   | 03   |
|------------------------------------------------------------------------|------|
| Abbreviations . . . .                                                  | 07   |
| Message from the Director of the                                       |      |
| Knowledge, Policy and Finance Centre . . . .                           | 08   |
| About the series . . . . . . . . . . . . . . . . . . . . . . . .       | 09   |
| KEY MESSAGES . . . . . . . . . . . . . . . . . . . . . .               | 10   |
| INTRODUCTION                                                           | 12   |

<!-- image -->

<!-- image -->

<!-- image -->

## CHAPTER 1

|   BY | RENEWABLE ENERGY EMPLOYMENT TECHNOLOGY . . . . . . . . . . . . . . . . . . .   |   16 |
|------|--------------------------------------------------------------------------------|------|
|  1.1 | Solar photovoltaic . . . . . . . . . . . . . . . .                             |   18 |
|  1.2 | Wind . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                 |   22 |
|  1.3 | Hydropower . . . . . . . . . . . . . . . . . . . . . . . .                     |   24 |
|  1.4 | Liquid biofuels . . . . . . . . . . . . . . . . . . . .                        |   26 |
|  1.5 | Other technologies . . . . . . . . . . . . . . . . . .                         |   27 |
|  1.6 | Decentralised renewables                                                       |   30 |
|  1.7 | The future of energy transition jobs . . .                                     |   35 |

## CHAPTER 2

| RENEWABLE ENERGY EMPLOYMENT                                      |
|------------------------------------------------------------------|
| IN SELECTED COUNTRIES . . . . . . . . . . . . . . . . . 37       |
| 2.1 Leading countries . . . . . . . . . . . . . . . . . . . 40   |
| 2.2 Other countries . . . . . . . . . . . . . . . . . . . . . 55 |

<!-- image -->

## CHAPTER 3

| INDUSTRIAL                                                                                               |   61 |
|----------------------------------------------------------------------------------------------------------|------|
| 3.1 The geography of solar PV and wind equipment manufacturing . . . . . . . . . . .                     |   62 |
| 3.2 Industrial policy initiatives amid a new geopolitics . . . . . . . . . . . . . . . . . . . . . . . . |   65 |
| 3.3 Critical materials, economic development and community rights . . . . . . . . . . . . . . . .        |   70 |

## CHAPTER 4

PERSPECTIVES AND ACTIONS FOR

A JUST TRANSITION

.

.

.

.

.

.

.

.

.

.

.

.

.

.

.

.

.

.

.

.

.

.

72

4.1  Governments' perspectives and actions . . .  73

4.2 Employer perspectives and actions   . . . . .  76

4.3 Labour union perspectives and actions   . . .  77

## CHAPTER 5

THE WAY FORWARD: MULTIPLYING

CHALLENGES DEMAND NEW THINKING

.

.

.

.

79

## Figures

| Figure 1   | Evolution of global renewable energy employment by technology, 2012-2022 . . . . . . . . . . . . . . . . . . . . . . . .   |   13 |
|------------|----------------------------------------------------------------------------------------------------------------------------|------|
| Figure 2   | Global renewable energy employment, by technology, 2022 . . . . . . . . . . . . . . .                                      |   17 |
| Figure 3   | Solar photovoltaic employment in 2022: Top ten countries . . . . . . . . . .                                               |   19 |
| Figure 4   | Women in the solar photovoltaic sector compared with other sectors . . .                                                   |   21 |
| Figure 5   | Wind employment in 2022: Top ten countries . . . . . . . . . . . . . . . . . .                                             |   23 |
| Figure 6   | Hydropower capacity in the top ten countries, 2022 . . . . . . . . . . . . . . . . . . .                                   |   24 |
| Figure 7   | Hydropower employment (direct jobs), by country, 2022 . . . . . .                                                          |   25 |
| Figure 8   | Liquid biofuels employment in 2022: Top ten countries . . . . . . . . . .                                                  |   26 |
| Figure 9   | Employment in the European heat pump sector, 2022 . . . . . . . . . . . .                                                  |   29 |
| Figure 10  | Distribution of labour required along the value chain for pico, micro and mini hydro plants . . . . . . . .                |   32 |
| Figure 11  | Distribution of skills required for pico, micro and mini hydro plants . . . .                                              |   33 |
| Figure 12  | Renewable energy employment in selected countries and regions . . . . .                                                    |   38 |
| Figure 13  | Solar photovoltaic module production by country/region, 2008-2022 . . . . . . .                                            |   62 |
| Figure 14  | ILO guidelines for a just transition: A framework for action . . . . . . . . . . . .                                       |   73 |
| Figure 15  | Holistic policy framework for a just and inclusive energy transition . . . . .                                             |   83 |

<!-- image -->

## Tables

| Table 1   | Direct jobs in Kenyan mini-grid development . . . . . . . . . . . . . . . . . . . . . . . . .                                          |   31 |
|-----------|----------------------------------------------------------------------------------------------------------------------------------------|------|
| Table 2   | Estimated direct and indirect jobs in renewable energy worldwide, by industry, 2021-2022 (in thousands) .                              |   39 |
| Table 3   | Employed persons by selected occupations in the United States economy, 2022 . . . . . . . . . . . . . . . . . . . . . .                |   47 |
| Table 4   | Solar photovoltaic generating and manufacturing capacities in Southeast Asia, 2022 . . . . . . . . . . . . . . . . . . . . . . . . . . |   56 |

## Boxes

| Box 1   | Solar PV: A gender perspective . . . . . . .                                                        |   20 |
|---------|-----------------------------------------------------------------------------------------------------|------|
| Box 2   | Employment in heat pumps . . . . . . . . . . .                                                      |   28 |
| Box 3   | Women - Key to skilling the energy transition . . . . . . . . . . . . . . . . . . . . . . . . . . . |   46 |
| Box 4   | Gender gaps in Spain's energy transition industries . . . . . . . . . . . . . . . . . .             |   53 |
| Box 5   | Policy elements to ensure plentiful, decent jobs . . . . . . . . . . . . . . . . . . . . . . .      |   74 |

<!-- image -->

## Abbreviations

| ALMM                                                               | Approved List of Models and Manufacturers [India]                  |
|--------------------------------------------------------------------|--------------------------------------------------------------------|
| APPA                                                               | Asociación de Productores de Energía Renovables [Spain]            |
| BCD                                                                | basic customs duty [India]                                         |
| BUSA                                                               | Business Unity South Africa                                        |
| CCS                                                                | carbon capture and storage                                         |
| CDI                                                                | Confederation of Danish Industry                                   |
| CRES                                                               | China Renewable Energy Society US Department of Energy             |
| EU                                                                 | European Union                                                     |
| EU-27                                                              | 27 Member States of the European Union                             |
| FTE                                                                | full-time equivalent                                               |
| GDP                                                                | gross domestic product                                             |
| GMG                                                                | Green Mini-Grid Facility Programme [Kenya] gigawatt                |
| GW th                                                              | gigawatt thermal                                                   |
| GWEC                                                               | Global Wind Energy Council                                         |
| ILO                                                                | International Labour Organization                                  |
| IRA                                                                | Inflation Reduction Act [United States]                            |
| IREC                                                               | Interstate Renewable Energy Council [United States]                |
| ITJ                                                                | Instituto para la Transición Justa [Spain]                         |
| JET IP                                                             | Just Energy Transition Investment Plan                             |
| kW                                                                 | kilowatt                                                           |
| MW                                                                 | megawatt                                                           |
| O&M                                                                | operations and maintenance                                         |
| PLI                                                                | production-linked incentive [India]                                |
| PV                                                                 | photovoltaic                                                       |
| SAREM South African Renewable Energy Masterplan                    | SAREM South African Renewable Energy Masterplan                    |
| SDG                                                                | Sustainable Development Goal                                       |
| STEM                                                               | science, technology, engineering and mathematics                   |
| USDA-FAS US Department of Agriculture Foreign Agricultural Service | USDA-FAS US Department of Agriculture Foreign Agricultural Service |

<!-- image -->

<!-- image -->

## MESSAGE FROM THE DIRECTOR OF THE KNOWLEDGE, POLICY AND FINANCE CENTRE

This edition of Renewable Energy and Jobs marks the 10th anniversary of the series.  It is also the  final  one  produced  under my  guidance,  with  a  dedicated and  talented team. The  idea for this series dates  back  to the early years of IRENA. From the very beginning, we insisted that  the  energy  transition  is  a  complex  undertaking  that  needs  to  be  approached  not  only from a technological angle, but from a holistic perspective that examines the socioeconomic dimension and analyses the array of policies needed for generating value along the supply chain and creating a skilled workforce.

When the agency was founded in 2009, information on the employment impacts of renewable energy was extremely scarce and mostly of an anecdotal nature. The jobs dimension was hardly in  the  public  eye.  Accordingly,  the  initial  editions  of  our  report  were  focused  on  identifying and marshaling existing data sources and supplementing them with our own calculations and estimates. Over time, we were able to close many gaps, and provide greater breadth and depth of coverage. We are proud that our work has brought greater visibility to this dimension of the energy transition - and stirred growing interest, which has led to more and better data becoming available.

Exciting  work  remains  to  be  done.  Over  the  years  our  focus  has  broadened  to  encompass qualitative employment aspects, workforce diversity, and the requirements of a just transition. The jobs review series  is  now  part  of  a  staple  of  IRENA  reports  on  the  socioeconomics  of renewables and the energy transition. They include analyses of the gender perspective and assessments of opportunities for countries to leverage and enhance their local capacities. And in  addition  to  our  work  on  current  renewable  energy  jobs,  our  socioeconomic  modeling  of energy transition pathways to 2030 and 2050 sketches how employment could expand in the future, with the right level of policy ambition in place.

I  forge  ahead  in  my  career  with  the  firm  belief  that  IRENA  has  significantly  broadened  the horizon of many in the energy world. As I bid farewell to the Agency, I am confident that both my current team and those joining in the future will persistently prioritise placing people at the heart of the ongoing energy transition - and that the world will follow suit.

th

EDITION

Rabia Ferroukhi

Director Knowledge Policy and

Finance Centre

<!-- image -->

<!-- image -->

## ABOUT THE IRENA RENEWABLE ENERGY AND JOBS SERIES

Renewable energy development not only changes the mix of energy sources powering the world's economies, but also creates jobs, builds economic value and enhances human wellbeing. The IRENA Renewable energy and jobs series quantifies  current  employment  in  the  sector,  examining  different  renewable  energy  technologies  worldwide  and  in selected individual countries. The analysis considers a variety of public and private sector policy contexts, including those related to deployment, industrial policy, skill building, labour market measures and others. While available qualitative information about renewable energy jobs, such as education, skill requirements or workforce attributes, remains limited, the series asserts that decent jobs are a must for the energy transition.

This is the tenth edition of the series, and the third produced in collaboration with the International Labour Organization. Following an initial standalone report in 2013, IRENA launched this series to provide regular updates to its assessment of renewable energy employment worldwide. Each edition discusses the latest available data and highlights specific aspects, such as employment in the energy access context, the gender equity dimension or the requirements of a just transition.

The series is part of IRENA's extensive analytical work, ongoing since 2011, on the socioeconomic impacts of a renewablesbased energy transition, including employment creation; leveraging of domestic capacities along the renewable energy value chain; women's participation in the renewable energy sector within the context of creating a diverse workforce; education and training opportunities; and the modelling of energy transition pathways to 2050 with regard to jobs, gross domestic product and a broad measure of welfare. This work is highlighted on the back cover of this report.

## Annual reviews of employment in renewables

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

2011

<!-- image -->

<!-- image -->

2015

<!-- image -->

2013

<!-- image -->

2012

2014

<!-- image -->

2017

<!-- image -->

2022

2020

2018

2021

2019

These  publications  and  IRENA's  comprehensive  research  on  socio-economic  impacts  -  all  of  which  is showcased on the back cover - can be accessed by visiting www.irena.org/Publications.

2016

<!-- image -->

2023

<!-- image -->

<!-- image -->

## KEY NUMBERS

13.7 million

## Global renewable energy jobs

in 2022, up from 12.7 million in 2021. Close to two-thirds of all jobs are in Asia, where China alone accounts for 41% of the global total.

4.9 million

## Solar photovoltaic (PV) jobs

in 2022; among renewable energy technologies, solar PV is the fastest-growing sector, accounting for more than one- third of the total renewable energy workforce. Women hold 40% of these jobs.

2.5 million

Direct jobs in hydropower in 2022, 2.3% more than in 2021. Operation and maintenance represent almost two-thirds of the direct jobs, 30% of the jobs are related to construction and installation, and about 6% are in component manufacturing.

2.5 million

Jobs in biofuels in 2022, mostly in the agricultural supply chain.

1.4 million

Wind power jobs in 2022. China and Europe lead, although the geography of component production is becoming increasingly diverse.

<!-- image -->

## KEY MESSAGES

## DECENTRALISED RENEWABLES: Decentralised solutions provide

reliable power and employment in remote areas. Small-scale hydropower, for instance, requires anywhere from 17 000 person-days (for a pico plant, which averages 5 kilowatts [kW]), to about 64 000 person-days (for a 50 kW micro plant), to over 160/thinspace000 person-days (for a 500 kW mini plant) for initial planning and equipment procurement and manufacturing, installation, connection, ongoing operation and maintenance, all the way to eventual decommissioning.

MILLIONS OF ADDITIONAL JOBS: Employment can be expanded substantially in coming years and decades with a comprehensive and ambitious policy mix.

INDUSTRIAL POLICY: Vulnerability to global supply chain disruptions, along with geopolitical rivalries, is driving a new interest in industrial policy measures to build and strengthen local capacities and secure related job creation benefits.

## WORKFORCE DEVELOPMENT AND DIVERSITY:

Education and training must be expanded to prevent the widening of skill gaps. They must be paired with efforts to tap talent among under-represented groups, including women, youth and minorities.

A JUST TRANSITION: Labour rights and social dialogue are indispensable for an energy transition that produces just outcomes and secures workers' prospects.

SYSTEMIC CHANGE: Achieving the energy transition in a manner consistent with climate stability requires much faster renewables deployment, in turn creating more jobs. It also demands broader, systemic change - moving beyond the pursuit of endless economic growth incompatible with planetary limits.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## RENEWABLE ENERGY JOBS

## Introduction

This tenth edition of Renewable energy and jobs: Annual review offers the latest set of global renewable energy employment estimates, which are based on IRENA's own methodologies and calculations, as well as a large array of reports published by government agencies, industry associations, non-governmental organisations and academic experts.

The report examines the renewable energy employment landscape as of 2022 globally as  well  as  for  selected  countries.  Against  the  backdrop  of  investment  and  deployment trends and a variety of policy contexts, it discusses job numbers as well as job quality and workforce diversity in the core segments of the renewable energy supply chain.

The  key  finding  of  this  edition  is  that  the  global  renewable  energy  sector  employed 13.7 million people directly 1 as well as indirectly  in 2022.  The number has been growing 2 3 over  the  past  decade,  from  7.3  million  in  2012  (see  Figure  1),  thanks  mainly  to  solar photovoltaic  (PV),  bioenergy,  hydropower  and  wind  power. 4   The  socio-economic modelling undertaken for IRENA's World Energy Transitions Outlook series indicates that the large-scale investment required to put the world on a climate-safe pathway would create many millions of additional jobs in the next decades.

<!-- image -->

- 1 Direct employment refers to employment generated directly by core activities, without taking into account the intermediate inputs necessary to manufacture renewable energy equipment, or construct and operate facilities. These directly involved industries are also called renewable energy industries (sectors).
- 2 Indirect employment includes employment in the upstream industries that supply and support the core activities of renewable energy deployment. Workers in such positions may produce steel, plastics or other materials, or provide financial and other services. These industries are not directly involved in renewable energy activities but produce intermediate inputs along the value chain of each renewable energy technology.
- 3 Data are principally for 2022, with some data for 2021 and some instances where only information from earlier years is available. The data for hydropower include direct employment only, whereas data for other technologies include both direct and indirect employment wherever possible.
- 4 The jobs numbers shown in Figure 1 for the period 2012-2021 reflect the figures reported in earlier editions of this series. IRENA does not revise previous years' estimates in light of information that may later become available.

Figure 1 Evolution of global renewable energy employment by technology, 2012-2022

<!-- image -->

- a Includes liquid biofuels, solid biomass and biogas./emspace
- b Direct jobs only.
- c   'Others' includes geothermal energy, concentrated solar power, heat pumps (ground based), municipal and industrial waste, and ocean energy.

The continued development of renewable energy - and thus employment in the sector -  is  influenced  by  a  multitude  of  factors:  notably,  cost-competitiveness  vis-à-vis  other energy technologies; the ebb and flow of investments; the resulting size of national and regional  markets;  the  availability  of  required  inputs  (components  and  raw  materials) and the existence of a skilled workforce. These are shaped by corporate strategies and an array of public policy measures (incentives and regulations) intended to facilitate the scale-up of deployment, build viable supply chains and train workers. Policy changes could trigger a surge in activity or could lead to decisions to defer investments, in turn causing employment to fluctuate.

<!-- image -->

Following largely stagnant spending levels in the years between 2015 and 2020, annual renewable energy investments (including private capital and public spending) rose from USD 348 billion in 2020 to USD 499 billion in 2022 - a gain of 43%. The bulk of funds went to the solar and wind industries, whose combined share of overall renewable energy investments  rose  from  82%  in  2013  to  a  stunning  97%  in  2022.  The  majority  of  funds are directed to the power sector, with end-use sectors accounting for only 10% (IRENA, 2023a). It is little surprise, then, that solar PV and wind power have been the most dynamic renewable energy technologies, showing strong growth in both capacity and jobs.

Where jobs are created depends on the geographic footprint of equipment manufacturing and  capacity  installations,  as  well  as  the  inputs  of  raw  materials,  semi-manufactured components  and  services  along  the  value  chain.  Labour  requirements  depend  on  the scale  of  projects.  Labour  intensity  tends  to  decline  as  technologies  mature,  learning curves  are  mastered,  automation  rises,  and  the  use  of  new  technologies  like  artificial intelligence (AI) advances.

Worldwide, some 295 gigawatts (GW) of renewable electricity were installed in 2022, with cumulative capacity reaching 3/thinspace372 GW. Renewable hydro remains the largest contributor with  1/thinspace256  GW,  although  only  20  GW  were  added  in  2022.  Solar  PV  and  wind  added 191.5 GW and 74.7 GW, respectively, with cumulative total installed capacities of 1/thinspace047 GW and 899 GW. Cumulative bioenergy power capacity is at 149 GW, with about 7.6 GW added in 2022 (IRENA, 2023b).

The  cumulative  solar  thermal  capacity  at  the  end  of  2022  was  542  gigawatts  thermal (GWth), corresponding to 774 million square metres of collector area. The net increase of 19 GWth (27 million square metres) was a smaller addition than in the previous year; stronger contributions from European markets could not counteract a decline in the Chinese and Indian markets (Weiss and Spörk-Dür, 2023). Global liquid biofuel production appeared to be up slightly in 2022, at 6%, compared with 162 billion litres in 2021 (REN21, 2023).

<!-- image -->

<!-- image -->

<!-- image -->

© photoschmidt / shutterstock.com

Half of the world's new wind power capacity and 45% of solar PV capacity were installed in China (IRENA, 2023b). China was followed by the United States, Brazil, the United Kingdom, Germany, Sweden and France in wind capacity installation, and the United States, India, Brazil, the Netherlands and Germany in solar PV capacity installation (IRENA, 2023b).

Annual  capacity  deployment  does  not  necessarily  correlate  closely  with  equipment manufacturing or shipments. Employment dynamics in these different value chain segments can  thus  diverge  substantially.  For  example,  there  were  far  more  PV  module  shipments globally in 2022, 272 GW, than reported installations (Wood Mackenzie, 2023a). As of mid2023, European PV panel inventories amounted to about 40 GW of capacity, roughly equal to the amount newly installed in Europe in 2022. This could rise to 100 GW by year end, given labour shortages and other installation bottlenecks (Rystad Energy, 2023).

<!-- image -->

This  report  is  organised  as  follows: Section  1 presents  employment  trends  by  major technology. Section 2 discusses job findings in several leading countries and for several additional countries in different regions of the world. Section 3 highlights the changing policy  landscape  regarding  equipment  manufacturing,  which  over  time  will  affect  the geography of job creation in renewable energy. Section 4 revisits a topic that has been explored by previous editions of this report: the need for a just transition, with a focus on the perspectives and actions of governments, businesses and labour unions. Section 5 emphasises that a faster energy transition will lead to greater job creation, but underscores the need for new thinking against the backdrop of multiplying global challenges.

<!-- image -->

<!-- image -->

## CHAPTER 1

## RENEWABLE ENERGY

## EMPLOYMENT BY TECHNOLOGY

This section presents employment  estimates  for solar photovoltaic (PV), wind, hydropower  and  liquid  biofuels.  Other  renewable  energy  technologies,  included  in Figure 2 employ fewer people, and the information available on them is typically less detailed. For any  given  technology,  equipment  manufacturing,  construction  and installation, and operation and maintenance (O&amp;M) are the main value chain segments, besides a range of support services.

<!-- image -->

Figure 2 Global renewable energy employment, by technology, 2022

<!-- image -->

<!-- image -->

Note: CSP = concentrated solar power; "Others" include jobs not broken down by individual renewable energy technologies.

<!-- image -->

<!-- image -->

<!-- image -->

## 1.1 SOLAR PHOTOVOLTAIC

Yet another record was set in 2022 - with the addition of 191.4 GW of solar PV capacity worldwide, up from 141.2 GW in 2021. China accounted for 45% of these installations, or 86 GW, and was followed by the United States, India and Brazil. The Netherlands, Germany, Japan, Spain, Australia and the Republic of Korea rounded out the top ten (IRENA, 2023b).

China  is  home  to  the  vast  majority  of  global  solar  PV  manufacturing,  supported  by comprehensive industrial policies. The country retains a commanding position across the supply chain, from ingots and wafers to cells and modules. Southeast Asia has become an important, but much smaller, production and export hub, whereas the rest of the world has a marginal share in the supply chain.

Europe's  PV  imports  surged  during  the  first  half  of  2022  due  to  the  Ukraine  crisis  and subsequent efforts to reduce reliance on oil and gas imports. However, installation rates trailed due to shortages of inverters and skilled labour, which subsequently slowed imports during the second half of the year. India's module imports declined significantly after the first quarter of 2022 once its basic customs duty took effect. In Brazil, a rush of installations was triggered by an impending law imposing a grid fee on small-scale distributed projects (Chen, 2023).

According  to  the  United  States  (US)  Department  of  Energy  (US  DOE,  2022),  1  GW  of production capacity (for crystalline silicon [c-Si] modules, which account for about 90% of all  manufactured modules) could generate anywhere from 1/thinspace085 jobs to 2/thinspace020 direct jobs across the full value chain.

IRENA estimates global solar PV employment at 4.9 million in 2022, up from about 4.3 million in  2021.  Of  the  ten  leading  countries  shown  in  Figure  3,  four  are  in Asia ,  two  are  in the Americas and three are in Europe .  Together, the top ten accounted for almost 4.1 million jobs, or 85% of the global total. Asian countries host 73% of the world's PV jobs, reflecting the region's continued dominance of manufacturing and strong presence in installations. The remaining jobs were in the Americas (11.5% of all jobs), Europe (11%; with European Union [EU] member states accounting for 10.6%) and the rest of the world (4.8%).

<!-- image -->

Figure 3 Solar photovoltaic employment in 2022: Top ten countries

<!-- image -->

China accounted for about 56% of PV employment worldwide, or some 2.76 million jobs. Employment in PV in the United States reached 264/thinspace000 jobs in 2022. PV employment in Europe was estimated at 540/thinspace000 in 2022 of which 517/thinspace000 jobs were in EU Member States. India's total solar jobs are estimated to be at 281/thinspace400. On-grid solar is estimated to have generated 201 400 jobs, with another 80/thinspace600 in off-grid settings. Increasing solar PV installations in Brazil boosted employment in this industry to 241/thinspace000 jobs. Japan added less capacity in 2021 than the previous year. IRENA estimates its workforce at 127/thinspace000.

Women's representation is higher in the workforce for solar PV than for other renewable energy technologies (see Box 1).

<!-- image -->

## Box 1

## Solar PV: A gender perspective

IRENA's socio-economic work seeks to close the information gap regarding gender in the renewable energy industry. In the most recent report in the series A Gender Perspective ,  IRENA assessed the challenges faced by women working in the solar photovoltaic  (PV)  sector.  The  assessment  considered  both  modern  markets  and energy access scenarios. The study, the third in the series, obtained primary data from individuals and organisations in the solar PV sector by means of a global online survey (IRENA, 2022a).

The analysis  showed  that  women  represent  40%  of  the  full-time  positions  in  the solar PV sector, almost twice as much as in the wind or the oil and gas sectors (21% and 22%, respectively). The solar PV sector exceeds women's average 32% share across the broader renewable energy sector but falls somewhat short of the share of women employed in the overall economy (see Figure 4).

<!-- image -->

Women's representation across solar PV job roles is uneven. They are most frequently hired for administrative positions,  where  their  share  reaches  58%.  Meanwhile,  women  represented  comparatively  small  shares, 32% of STEM (science, technology, engineering and mathematics) positions and 35% of non-STEM technical positions (such as lawyers or procurement experts). Further, women hold 38% of other non-technical positions ( e.g. marketing, sales, distribution, product assembly or installation). The better performance in this category is largely due to off-grid solar, which has multiple positions and initiatives targeting women. This may also influence leadership composition, with women accounting for 30% of managerial jobs. However, women represent 17% of the total senior management roles in the solar PV industry.

Effective actions are needed to ease women's entry into the industry and improve their career prospects and progression. Creating gender awareness is essential to fully understand the complexity of the barriers faced by

<!-- image -->

<!-- image -->

women. Further, national policies are needed to create safer spaces and better workplace practices, policies and regulations. Also, women need networks and systems to support training and mentorship to enable full utilisation of their talents.

IRENA will  continue  to  work  for  reducing  barriers,  fostering  inclusivity  and  empowering  women  to  actively participate and excel in the sector. Furthermore, IRENA is fully committed to mainstreaming gender considerations, integrating gender equality and equity into its policies, programmes and initiatives. Prioritising gender equality and promoting diversity in the renewable energy sector fosters a more equitable and sustainable future for all.

Figure 4 Women in the solar photovoltaic sector compared with other sectors

<!-- image -->

Source: IRENA, 2022a.

Note: PV = photovoltaic; STEM = science, technology, engineering and mathematics.

<!-- image -->

<!-- image -->

## 1.2 WIND

In  2022, the wind energy sector installed 74.6 GW of capacity, 19% below the previous year's and 33% slower than the record pace in 2020. Except for Sweden and France, new capacity additions in all leading countries were below that in the peak year. China retained the lead with close to half of global additions, far ahead of the United States, Brazil, the United Kingdom, Sweden, Türkiye, Germany, India, France and Spain (IRENA, 2023b).

Global employment in onshore and offshore wind remained steady at 1.4 million jobs in 2022. Wind employment was concentrated in a relatively small number of countries. China alone accounted for 48% of the global total, followed by Asia (representing 55%), Europe (representing 29%), the Americas (representing 16%) and Africa and Oceania (representing 0.7%). The top ten countries shown in Figure 5 together employed 1.23 million people. Four of  these  are  in  Europe,  four  in  Asia  and  two  in  the  Americas.  The  recent  phenomenon of rising costs of inputs has led original equipment manufacturers to reinforce efforts to outsource  some  component  production  to  low-wage  countries.  This  will  contribute  to changing the industry's geographic make-up.

On  average,  installation  of  1  GW  of  onshore  wind  capacity  could  create  130/thinspace000  jobs in  development,  construction  and  installation  over  a  five-year  period  and  12/thinspace000  jobs annually during the 25-year O&amp;M phase (GWEC, 2022). Meanwhile, the greater complexity of components like foundations, substations, cables and installation vessels creates higher labour requirements for offshore wind farms than onshore installations.

<!-- image -->

<!-- image -->

Figure 5 Wind employment in 2022: Top ten countries

<!-- image -->

<!-- image -->

R

E

N

E

W

A

B

L

E

E

N

E

R

G

Y

A

N

D

J

O

B

S

:

<!-- image -->

<!-- image -->

## 1.3  HYDROPOWER

Hydropower remains at the forefront of the renewable energy landscape, boasting a global capacity surpassing 1/thinspace255 GW as of 2022. This figure translates to an impressive 37% of the global total renewable energy capacity. Total installed hydropower capacity exceeds that of wind and solar PV, although annual additions are much smaller now - some 20.5 GW in 2022. As shown in Figure 6, China, Brazil, Canada and the United States are among the key actors in this sector (IRENA, 2023b).

To assess job numbers in hydropower, IRENA uses an employment-factor approach coupled with national-level data for select countries. Considering data revisions since the  previous  edition  of  the  Annual  Review,  the  latest  report  estimates  that  about 2.49 million individuals were directly employed in the sector in 2022, 2.3% more than in the previous year. Consistent with earlier findings, O&amp;M represent two-thirds of the direct jobs, 30% of the jobs are related to construction and installation activities, and about 6% are in component manufacturing. The remaining fraction pertains to O&amp;M services, which represent the smallest proportion of the workforce. China continues to  dominate  in  hydropower  employment with a 35% share of the global total. India (second to  China  with  a  19%  share),  followed  by  Brazil,  Viet  Nam  and  Pakistan,  are among the top five (see Figure 7).

Figure 6 Hydropower capacity in the top ten countries, 2022

Source: IRENA, 2023b.

<!-- image -->

Figure 7 Hydropower employment (direct jobs), by country, 2022

<!-- image -->

<!-- image -->

<!-- image -->

R

E

N

E

W

A

B

L

E

E

N

E

R

G

Y

A

N

D

J

O

B

S

:

<!-- image -->

A

N

N

U

A

L

V

I

E

W

## 1.4 LIQUID BIOFUELS

A total of 162 billion litres of liquid biofuels were produced globally in 2021 (returning to 2019 levels after a decline in 2020, with bioethanol contributing 106 billion litres, biodiesel about 46 billion litres and hydrotreated vegetable oil [renewable diesel] adding close to 10 billion litres) (REN21, 2023).

According  to  preliminary  estimates  by  the  US  Department  of  Agriculture's  Foreign Agricultural Service (USDA-FAS), output among the world's leading biofuel producers was up slightly in 2022. As in earlier years, the United States, Brazil and the European Union were the dominant ethanol producers. EU members led in biodiesel production, followed by Indonesia, Brazil and the United States.

IRENA  estimates  worldwide  biofuel  employment  in  2022  at  2.5  million,  mostly  in feedstock operations. Latin America accounts for 42% of all biofuel jobs worldwide, while Asia (principally  Southeast  Asia)  accounts  for  37%.  The  more  mechanised agricultural  sectors  of North  America and Europe represent  smaller  employment shares (15% and 6%, respectively). The top ten countries together account for about 94% of global estimated employment (Figure 8).

Figure 8 Liquid biofuels employment in 2022: Top ten countries

Million jobs

<!-- image -->

<!-- image -->

<!-- image -->

In  the  United  States,  360/thinspace000  people  were  required  for  direct  and  indirect  labour in  biofuel  feedstock and processing operations in 2022. In the 27 EU Member States, biofuel  created  an  estimated  148/thinspace300  jobs  in  2021  (up  from  141/thinspace600  jobs  in  2020) (EurObserv'ER, 2023). Total biofuels production in the European Union was relatively unchanged in 2022 (USDA-FAS, 2022e). Employment, therefore, may also be assumed to have remained at the 2021 level.

Many countries have labour-intensive feedstock operations, with informal and seasonal employment in the agricultural supply chain. Brazil remains the world's largest employer in  liquid-biofuel-related  operations  (about  856/thinspace000  jobs),  and  is  second  only  to the  United  States  in  biofuel  production.  Other  countries  estimated  to  have  sizeable biofuel workforces include Indonesia (619/thinspace000), Colombia (186/thinspace700), Thailand (97/thinspace100), Malaysia (66/thinspace600) and the Philippines (44/thinspace900).

## 1.5 OTHER TECHNOLOGIES

As Figure 2 indicates, other renewable energy technologies employ far fewer people than solar PV, wind, hydropower and biofuels. The industries that manufacture and install these technologies are far less dynamic. For most of them the available information about their employment impacts is relatively scarce. Assessments for employment impacts of heat pumps, for example, are available only for some countries. Box 2 provides a summary of available information.

<!-- image -->

## Box 2 Employment in heat pumps

China, Japan, the United States and Europe are the major markets for heat pumps. Global heat pump sales grew 11% in 2022, driven by developments in Europe, where rising energy prices and supportive installation policies are driving up sales (REN21, 2023). Three million units were sold in Europe in 2022. This is 38% more than in 2021, double the sales volume in 2019 and three times as many sales as in 2016 (Rosenow and Gibb, 2023).

Based on a survey of its members, the European Heat Pump Association estimates that in 2022, about 116/thinspace000 people were employed in this growing sector in European countries  (see  Figure  9).  About  66/thinspace000  people  were  employed  in  manufacturing, 36/thinspace000 in  installations  and  15/thinspace000  in  maintenance  services  (EurObserv'ER  [2023] provides a much higher job number [some 377/thinspace300 in 2021], although this includes employment in air-source pumps and air-conditioning equipment).

The largest number of European heat pump jobs are found in France, Italy and Germany, which together represent just over half of the European total (Nowak and Westring, 2023). A large portion of installations centres on European-made heat pumps. This creates local jobs, although recent demand growth has surpassed local manufacturing capacities and raised reliance on imports (EurObserv'ER, 2023). Companies announced plans for investments of more than EUR 5.5 billion in new European manufacturing factories (REN21, 2023).

In  China,  the  heat  pump  industry  provided  employment  opportunities  for  a  similar number of people as in Europe, some 118/thinspace000 in 2022 (CHPA, 2023). Based on a survey,

<!-- image -->

<!-- image -->

this  figure  includes  production,  sales  distribution,  installation,  and  after-sales  service.  The  numbers  cover air-to-water  heaters  and  water/ground-to-water  heat  pumps,  but  exclude  air-to-air  heat  pumps, i.e. air conditioning. Some 28/thinspace000 people produced equipment and 20/thinspace000 people produced components. Sales and installation services, including sales, logistics, installation, and after-sales, provided employment opportunities for 71/thinspace000 people, about 60% of the total. The China Heat Pump Alliance forecasts that the heat pump industry could provide employment opportunities for 400/thinspace000 people by 2030 in China.

In  the  United  States,  the Energy and Employment Report estimates  6/thinspace465  jobs  related  to  ground-source  or geothermal heat pumps in 2022. The figure for air-source heat pumps is much higher, at 64/thinspace641 (US DOE, 2023).

Figure 9 Employment in the European heat pump sector, 2022

<!-- image -->

Source: Nowak and Westring, 2023.

<!-- image -->

## 1.6 DECENTRALISED RENEWABLES

Following  the  COVID-19-induced  activity  slump  in  2020  (when  just  340  megawatts [MW] were installed), the off-grid sector rebounded, adding 690 MW of new capacity in 2021 and 1/thinspace400 MW in 2022 (IRENA, 2023b). Among various emerging technologies, decentralised renewable energy has emerged as a viable solution to provide reliable and clean power to communities, especially in remote areas. Beyond the environmental benefits, this decentralised approach creates local jobs and excellent opportunities for promoting diversity. This section discusses job and livelihood implications for mini-grids (often based on solar PV), small-scale hydropower and clean cooking solutions.

## 1.6.1 Mini-grids

Mini-grids  will  play  an  increasingly  important  role  in  closing  existing  gaps  in  energy access,  especially  in  remote  rural  areas.  In  2010,  there  were  about  500  mini-grid installations  in  Sub-Saharan  Africa.  While  the  number  has  risen  significantly,  to  over 3/thinspace000 installations at present, further acceleration is needed. According to one estimate, more than 160/thinspace000 mini-grids are required to address access needs (World Bank, 2023).

Kenya features prominently in the region, having deployed a significant share of Africa's mini-grids. The International Labour Organization has undertaken an assessment of the employment impacts of the EU-funded Green Mini-Grid (GMG) Facility Programme in Kenya,  which  consists  of  33  sites,  principally  solar  PV  based.  For  a  typical  mini-grid, the  study  (Oyuma,  Game  and  Lieuw-Kie-Song,  2023)  assumes  that  the  design  and feasibility  phase  takes  one  month  of  work  and  the  construction  phase  takes  another month, engaging, respectively, 7 and 104 workers. This translates into 0.7 and 8.8 fulltime equivalent (FTE) jobs, respectively, for a total of 9.5 FTE jobs, nearly all held by men. Most of the jobs are unskilled; almost half of the construction phase jobs pay an average daily wage of KES/thinspace500 (USD/thinspace4.69), 5 compared with KES 1/thinspace600 (USD 15.025) for wiring work, and KES 2/thinspace700 (USD 25.355) for field engineers and household mappers, for example. For O&amp;M, the study estimates an additional 2.8 FTE jobs. For the 33 sites under GMG, the study also estimated indirect and induced employment at 652 jobs (these are not necessarily FTE jobs) in agriculture, manufacturing and services. Women account for about 20% of the total.

Based on average investment costs of EUR/thinspace195/thinspace275 per site and costs per connection of EUR/thinspace688, the study estimated that for every EUR/thinspace1/thinspacemillion invested, 58/thinspaceFTE jobs could be created annually. Table/thinspace1 summarises key findings pertaining to direct jobs at present and direct jobs if future mini-grid targets are realised.

5 Average exchange rate of USD 1 = KES 106.488 in 2020, when the study was conducted. It should be noted that the exchange value of the Kenyan shilling has declined significantly since then. By September 2023, 1 USD equalled 146 KES.

<!-- image -->

<!-- image -->

Table 1 Direct jobs in Kenyan mini-grid development

<!-- image -->

| Parameters                | Parameters                                                    | FTE Jobs   |
|---------------------------|---------------------------------------------------------------|------------|
| Average mini-grid site    | Jobs in design and feasibility phase (temporary)              | 0.7        |
| Average mini-grid site    | Jobs in construction and commissioning phase (temporary)      | 8.8        |
| Average mini-grid site    | Jobs in operations and maintenance phase (permanent)          | 2.8        |
| Average mini-grid site    | Total direct jobs (temporary plus permanent)                  | 12.3       |
| For 33 GMGsites a         | Permanent jobs                                                | 92         |
| For 33 GMGsites a         | Temporary Jobs                                                | 314        |
| For 33 GMGsites a         | Total jobs (temporary plus permanent)                         | 406        |
| Future connection targets | Estimated jobs created if 35000 households served/thinspace b | 1 439      |
| Future connection targets | Estimated jobs created if 1.1 million households served       | 45100      |

Source: Oyuma, Game and Lieuw-Kie-Song, 2023.

Notes:

- The number of sites that were developed under Phase 2 of the GMG programme. a
- b It is estimated that 117 mini-grid sites are needed to meet this goal.
- FTE = full-time equivalent; GMG = Green Mini-Grid.

<!-- image -->

## 1.6.2 Small-scale hydropower

Small-scale hydropower systems offer numerous benefits for local communities and the environment. They not only provide electricity but could also support irrigation services and connect communities to the central grid. They also make it possible to sell excess power, creating opportunities for additional income generation. In this way, they help transform local economies and generate inclusive growth by empowering rural women to participate in these activities. Further, community-based hydro mini-grids incentivise local communities to restore and maintain surrounding watersheds, contributing to environmental sustainability.

The implementation value chain of small-scale hydropower offers plenty of local job opportunities. Jobs can be created due to feasibility studies, planning and procurement, and equipment manufacturing, to installation and connection, O&amp;M, and eventually, decommissioning.

analysis  (IRENA, 2023c), a small-scale hydropower plant

According to IRENA's latest Leveraging local capacity requires substantial labour to implement. For instance, a pico hydro plant (averaging 5 kW) requires  over  17/thinspace000  person-days,  a  micro  hydro  facility  (50  kW)  requires  approximately 64/thinspace000 person-days and a mini hydro system (500 kW) requires more than 160/thinspace000 persondays. 6 Among all value chain segments for a system, the majority of labour is needed for O&amp;M work over the system's lifetime. This O&amp;M work accounts for 94%, 87% and 78% of total person-days for pico, micro and mini hydro, respectively (see Figure 10).

- 6 Person-days reflect the amount of work done by one person working full-time for one day.

<!-- image -->

Figure 10 Distribution of labour required along the value chain for pico, micro and mini hydro plants

<!-- image -->

Source: IRENA, 2023d.

Note: kW = kilowatt.

The above work mostly requires low to moderate technical skills (see Figure 11), which are typically readily available in  a  country's workforce or can be developed through certification programmes or vocational training centres. By employing local talent,  small-scale  hydropower  projects  contribute  to  local  capacity  development  and  skill enhancement.

Connecting  renewable  energy  supply  with  income-generating  activities,  known  as  productive  end  uses,  has the  potential  to  boost  productivity,  increase  incomes,  create  local  employment  and  catalyse  rural  economies. However, translating energy access into livelihood improvements requires investing in a social ecosystem that fosters technology solutions tailored to the specific needs of local communities. This investment should include financing, capacity and skill training, market access and cross-sector policy support to fully realise the benefits of decentralised renewable energy solutions.

The hardware required for small-scale hydropower can be manufactured locally. This creates opportunities for local skill building and fostering enterprise development. However, costly international standards often hinder local developers from competing for projects. Donor-funded international programmes must encourage the involvement of local experts instead of relying solely on foreign service providers. Full realisation of small-scale hydropower's benefits and maximum domestic value creation require policies and measures to prioritise community capacity enhancement along the value chain and the promotion of social acceptance.

As the sector continues to grow, the demand for skilled workers in installation, maintenance, entrepreneurship and community engagement will increase. The expansion of the decentralised renewable energy job market has a positive multiplier effect, benefiting local economies, reducing poverty and fostering social development.

Figure 11 Distribution of skills required for pico, micro and mini hydro plants

<!-- image -->

Source: IRENA, 2023c.

Note: kW = kilowatt; STEM = science, technology, engineering and mathematics.

<!-- image -->

<!-- image -->

## 1.6.3 Renewables-based cooking solutions

Achieving  universal  access  to  clean  cooking  solutions  is  a  pressing  global  challenge. Traditional cooking methods, such as open fires and inefficient stoves, not only contribute to indoor air pollution but also have severe health, environmental and socio-economic implications.  Renewables-based  clean  cooking  solutions,  including  bioethanol-based, biogas-based,  electricity-driven and  modern  biomass-based  solutions,  present  a significant opportunity to accelerate progress towards Sustainable Development Goal 7 and offer substantial job opportunities.

Studies  show  that  countries  such  as  Kenya  had  about  700  FTE  jobs  in  the  bioethanol sector  in  2019,  while  the  biogas  sector  employed  800  people  and  the  electric  cooking sector employed 200 (Lee et al. ,  2021). The potential for an increase in jobs numbers in the clean cooking sector is substantial if renewable-based solutions were to replace liquid petroleum gas. Currently, the sector, including liquid petroleum gas, is estimated to provide approximately 19/thinspace000 direct, formal jobs. There is also potential for 15/thinspace000-35/thinspace000 direct but  informal  jobs.  Viet  Nam's  biogas  programme  deployed  over  180/thinspace000  biodigesters between 2003 and 2020, creating 2/thinspace500 jobs in the construction and services sectors (SNV and EnDev, 2021). Training and skill development is a critical element of local job creation in the clean cooking sector, which involves manufacturers, installers and O&amp;M providers, as well as smallholder farmers where feedstock is needed ( e.g. bioethanol supply chains) (IRENA, 2023d).

Lee et al. (2021) also showed that women's involvement in the sector is limited, representing only about 20% of the non-managerial workforce, due to the physically demanding nature of these jobs. However, there are more women managers in the clean cooking sector. For biogas-based solutions, about one-third of managers are women, a share that rises to one-half for bioethanol-based and electricity-powered cooking solutions. According to the study, companies typically express a strong desire to involve women in managerial roles and in the research and development of products. The clean cooking sector thus presents a unique opportunity to bridge both the skill and gender gap (Lee et al. , 2021).

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## 1.7 THE FUTURE OF ENERGY TRANSITION JOBS

While this annual review primarily focuses on the renewable energy sector itself, several closely  intertwined  solutions  of  escalating  significance  significantly  contribute  to  the emergence  of  job  opportunities  or  the  dynamics  of  the  employment  market  and  its requirements. Among them, energy efficiency measures represent a pivotal facet. Further, the development of grid transmission and distribution networks will be crucial in unfolding the energy transition, as is true for flexibility innovations, energy storage and hydrogen technologies, among others.

The shift towards sustainable energy sources fosters increased economic engagement and redirects financial endeavours from fossil fuels towards sectors involved in the energy transition.  IRENA's World  Energy  Transitions  Outlook presents  a  1.5°C-compatible trajectory  that  is consistent  with  the  Paris  Agreement  on  Climate  Change.  The macroeconometric  modelling  framework  underlying  IRENA's  1.5°C  pathway  captures the effects of and feedback loops for different climate and energy transition policies, including their  impacts on government revenue streams, spending, and distributional and social impacts. The 2022 edition of the Outlook indicated that if the world follows IRENA's  1.5°C  pathway,  employment  in  the  energy  sector  could  grow  to  139  million jobs by 2030, with renewables accounting for 38.2 million and other energy transition technologies for 74.2 million (IRENA, 2022b).

These  numbers  are  derived  from  socio-economic  modelling  of  IRENA's  1.5°C  scenario, which represents a complex set of investments and policies that can drive the needed change in the energy sector. However, IRENA's work has consistently emphasised that the transition has socio-economic effects (GDP, employment, and social welfare) far beyond the energy sector, across the economy at large. These impacts are shaped by an array of policies, and it is critical that outcomes maximise benefits for people while minimising uncertainties and adjustment burdens. Some of the key policies include carbon pricing, fossil fuel subsidy reduction, higher government spending on social infrastructures, and international collaboration. The forthcoming volume 2 of World Energy Transitions Outlook 2023 , also explores the impacts of channeling revenues from wealth taxes towards social investments, and presents the impact of fair wages to workers in mineral mining industries in developing or emerging economies (IRENA 2023a, forthcoming).

<!-- image -->

<!-- image -->

As the global transition gains momentum,  it  becomes  increasingly evident that governments  need  to  proactively  establish  robust  policies  to  foster  the  widespread implementation  and  seamless  integration  of  renewable  technologies.  Prioritising  the cultivation of a skilled workforce remains imperative, alongside a growing emphasis on the calibre of these employment positions. Further, it is critical that policy makers conceive an overarching framework that encompasses a spectrum of measures, including industrial strategies, labour market policies, social safety nets and initiates for promoting diversity and inclusivity (see Section 4).

Moreover, the landscape of labour is undergoing a paradigm shift as automation increases in the manufacturing sector. This transformation is recalibrating employment dynamics, reducing traditional workforce dependencies while simultaneously generating demand for the skill sets required to program and operate automated systems. While this transition might entail job displacements, the positions that emerge from it are anticipated to be of higher quality, demanding advanced skills. Ensuring low-income individuals' access to these roles should be a top priority.

Meeting  the  human  resource  capacity  challenge  to  fill  these  energy-transition-related roles requires a robust scaling up of education and training programmes. It also calls for strategic measures to cultivate an inclusive and gender-balanced transition workforce. By embracing these multi-faceted approaches, the energy transition can accelerate the move to a more equitable and empowered workforce.

## RENEWABLE ENERGY EMPLOYMENT IN SELECTED COUNTRIES

This section discusses employment estimates across several countries. As in previous editions,  the  principal  focus  is  on  countries  leading  in  equipment  manufacturing  and installation - China, Brazil, India, the United States and the EU members. These countries are  highlighted  in  Figure  12,  with  more  detailed  data  in  Table  2.  Later,  the  section discusses a few other countries. Overall, the bulk of renewable energy employment is in Asian countries, which accounted for 62% of all jobs in 2022. While geopolitics and restrictive trade policies are increasingly influencing policy making on the production and deployment of renewable energy equipment, the jobs landscape is also affected by corporate decision making on production hubs and outsourcing.

<!-- image -->

<!-- image -->

CHAPTER 2

<!-- image -->

<!-- image -->

<!-- image -->

Figure 12 Renewable energy employment in selected countries and regions

<!-- image -->

Disclaimer: This map is provided for illustration purposes only. Any boundaries and names shown do not imply any endorsement or acceptance by IRENA.

## Table 2 Estimated direct and indirect jobs in renewable energy worldwide, by industry, 2021-2022 (in thousands)

|                           | World    |   China | Brazil   | United States   | India   | European Union (EU27) n   |
|---------------------------|----------|---------|----------|-----------------|---------|---------------------------|
| Solar PV                  | 4902     |  2760   | 241      | 264 f           | 282 l   | 517                       |
| Liquid biofuels           | 2490     |    55   | 856 e    | 360 g           | 35      | 148                       |
| Hydropower a              | 2485     |   876   | 194      | 66 h            | 466     | 83                        |
| Wind power                | 1 400    |   681   | 68       | 126             | 40      | 319                       |
| Solid biomass b, c        | 779      |   195   |          | 47 i            | 58      | 354                       |
| Solar heating and cooling | 712      |   557   | 41       | n.a.            | 19      | 38                        |
| Biogas                    | 309      |   160   |          | n.a.            | 85      | 47                        |
| Geothermal energy b       | 152      |    87   |          | 8.6 j           |         | 7                         |
| Concentrated solar power  | 80       |    59.4 |          | n.a.            |         | 5                         |
| Total                     | 13 720 d |  5548   | 1 400    | 994 k           | 988     | 1 534 e                   |

Note:    The figures presented in the table are the result of a comprehensive review of primary national entities such as ministries and statistical agencies, and secondary data sources such as regional and global studies. Empty cells indicate that no estimate is available. 'n.a.' indicates not applicable. The column values may not add up precisely to totals due to rounding off.

- a. Direct jobs only.
- b. Power and heating applications.
- c. Traditional biomass not included.
- d. ncludes 27/thinspace000 jobs in waste to energy and about 240/thinspace500 jobs in heat pumps (118/thinspace000 jobs in China, 116/thinspace000 in EU-27 countries, I and about 6/thinspace500 in the United States).
- e. Includes a rough estimate of 200/thinspace000 indirect jobs in equipment manufacturing.
- f. Includes jobs in all solar technologies, but principally PV.
- g. Includes 296/thinspace529 jobs in ethanol and 63/thinspace180 jobs in biodiesel.
- h. US DOE (2023) estimate, including 54/thinspace595 jobs in traditional hydro and 11/thinspace677 jobs in low-impact hydro. The United States total does not include an estimated 8/thinspace333 jobs in pumped hydro (energy storage).
- i. Includes woody biomass fuels (34/thinspace164 jobs) and biomass power (12/thinspace850 jobs).
- j. Figure is for direct employment in geothermal power.
- k. ncludes 122/thinspace481 jobs in technologies not individually separated in the table, such as solar heating and cooling, geothermal heat, heat I pumps and others. Solar heating and cooling are also included (but not reported separately) in the Solar Foundation's estimate for all solar technologies; there is thus slight double counting.
- l. Includes 201/thinspace400 jobs in grid-connected solar photovoltaic (PV) and 80/thinspace600 in off-grid solar PV.
- m. Solar PV, wind and hydropower jobs are for 2022. Jobs for other technologies are for 2021.

<!-- image -->

<!-- image -->

## 2.1 LEADING COUNTRIES

CHINA's renewable energy employment grew from 5.37 million in 2021 to 5.55 million in 2022.

<!-- image -->

The  country's  pre-eminence  in solar  photovoltaic  (PV) employment  reflects  its strong position as the dominant equipment manufacturer as well as its commanding position in capacity installation. Although low labour costs are a factor in China's success, it  is  largely  due  to  infrastructure  provision  and  industrial  policies,  which  supported  the development of an integrated supply chain of unrivalled proportions.

According  to the China Photovoltaic Industry Association, the country produced 827/thinspace000 tonnes of polysilicon, 357 GW of silicon wafers, 318 GW of cells and 289 GW of solar modules in 2022. Its exports rose by 80% to USD 51 billion when compared year over year, reflecting strong global demand (Joshi, 2023). Europe received the bulk of module exports (86.6 GW), with smaller volumes going to Asia Pacific (28.5 GW), the Americas (24.8 GW), the Middle East (11.4 GW) and Africa (3.4 GW) (Chen, 2023).

Regarding deployment, China added 86 GW of solar PV capacity in 2022, another record and equivalent to 45% of worldwide additions. Meanwhile, in wind, additions of 37 GW fell significantly short of the record capacity addition in 2020 and even of the smaller additions in 2021. These installations nonetheless represented half of the global total (IRENA, 2023b).

According to estimates by the China Renewable Energy Society (CRES, 2023), the country employed 2.76 million people in solar PV in 2022, about 80/thinspace000 more jobs than in 2021. The  employment  impacts  of  growing  manufacturing  and  deployment  are  somewhat counterbalanced  by  rising  automation,  which  diminishes  the  industry's  labour  needs. Manufacturing activities accounted for an estimated 1.8 million jobs, and construction and installation together with operation and maintenance (O&amp;M) accounted for 918/thinspace000 jobs.

<!-- image -->

In  the wind sector,  China  added  32.9  GW  of  onshore  capacity  in  2022  -  slightly more than in the year before (when the expiration of a subsidy slowed construction activity), but still less than half of the record capacity added in 2020. Offshore capacity addition progressed significantly slower in 2022 than the year before, with new installations of 4.1 GW compared with 17.4 GW (IRENA, 2023b). Although grid limits will continue to constrain  developments,  China's  2060  carbon  neutrality  target  will  push  further  wind growth (Li, 2022).

Since 2008-2010, Chinese wind companies have established a large supply chain primarily for serving the domestic market. Due to substantial investments and strategic industrial policy making, China can benefit from unmatched economies of scale and has become the world's largest hub for the production of key components and raw material processing. This  translates  into  substantial  cost  advantages.  For  example,  reports  indicate  that Chinese wind firms could manufacture turbines at approximately 60% of the cost of their competitors (Barnard, 2023).

'Completed  and  firm'  wind  turbine  orders  filled  by  Chinese  manufacturers  doubled between 2020 and 2021 to 50.7 GW, and further grew by 18%, to 59.8 GW, in 2022 (Wood Mackenzie, 2023b). The bulk of production is for the large domestic market. Meanwhile, the market dynamics are changing, and favourable cost and profit margins over Western competitors are leading Chinese manufacturers to look more towards export markets. Both competition and co-operation with European manufacturers are expected to grow. Besides export sales, Chinese companies are building or planning to build manufacturing plants in India, Brazil, Spain and the United Kingdom (Ren and Diao, 2022; Diao, Li and Wang, 2022).

According to Wood Mackenzie's estimates, China is planning to add 17 GW of new blade capacity  in  2023-2024  to  serve  both  domestic  and  foreign  demand.  This  is  in  sharp contrast to Western markets, where manufacturers struggling with low demand, rising costs and low profitability are outsourcing component production (Lico, 2022b).

According to CRES (2023), the Chinese wind industry employed an estimated 681/thinspace000 people in  2022,  up  from  654/thinspace000  in  2021.  Manufacturing  accounted  for  234/thinspace000  of  these  jobs, construction and installation represented 276/thinspace000 and O&amp;M accounted for 171/thinspace000.

<!-- image -->

In hydropower ,  global capacity additions in 2022 were predominantly in China, whose hydropower sector employed about 927/thinspace200 people directly, as per IRENA's estimates. Solar heating and cooling were estimated to have had 557/thinspace000 direct jobs, down  from  636/thinspace000  jobs  in  2021. Concentrated  solar  power represented  another 59/thinspace400 jobs, roughly the same as in 2021. Geothermal heat and power had 87/thinspace000 jobs, also  up  slightly  from  2021. Bioenergy technologies  accounted  for  410/thinspace000  jobs,  up from 386/thinspace000 in 2021. Of this total, 240/thinspace000 jobs were in equipment manufacturing and 170/thinspace000 in O&amp;M (CRES, 2023). China's fuel ethanol production remained below the 2019 peak value, but biodiesel output reached another record (USDA-FAS, 2022f). China's biofuels  sector  is  estimated  to  have  employed  55/thinspace000  people  in  2022,  up  marginally (CRES, 2023).

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

BRAZIL had an estimated 1.4 million renewable energy jobs in 2022. Biofuels , with an estimated 856/thinspace200 jobs in 2022, remained the single-largest employer in renewable energy, although job numbers declined slightly from the previous year.

<!-- image -->

Biodiesel production was estimated at 6.37 billion litres in 2022, down about 6% from 2021. In November 2021, the mandatory biodiesel blend in vehicle fuels had been reduced from 13%  to  10%  given  the  increased  cost  of  soybeans  (the  primary  feedstock)  (USDA-FAS, 2022a).  IRENA  estimates  282/thinspace400  biodiesel-related  jobs  in  Brazil  in  2022,  down  from 343/thinspace500 the year before.  The most recent available employment estimate for bioethanol is 7 for 2021, at 344/thinspace500 jobs (MTE/RAIS, 2023),  along with an approximate 200/thinspace000 indirect 8 jobs in equipment manufacturing. Brazil's estimated sugarcane-based ethanol output rose by about 8.5% in 2022. Applying this percentage change to employment would suggest some 573/thinspace800 ethanol-related jobs in 2022. Most ethanol is produced from sugarcane, but corn ethanol production is expanding, rising 37% in 2022 (USDA-FAS, 2022a).

<!-- image -->

Brazil  ranked  fourth  in  new solar PV capacity  installation  in  2022,  after  China,  the United States and India. It added 9.9 GW, to bring the cumulative installed capacity to 24 GW (IRENA, 2023b). ABSOLAR (2023) reported even higher figures and found that 29% of cumulative PV capacity as of 2022 was in centralised generation facilities, down from 76% in 2018. The bulk of PV expansion over the past few years has been in distributed generation.

The Brazilian development banks BNB and BNDES are the principal sources of finance for large-scale PV. Altogether, some 42.4 GW of new solar PV projects were authorised between March 2022 and February 2023, of which 4.9 GW were under construction by mid-2023 and 7.5 GW were already in operation (Greener, 2023a).

Brazil  remains  heavily  dependent  on  imports  of  (predominantly  Chinese-made)  PV modules. Imports for both large-scale and distributed projects rose from 4.8 GW in 2020 to  10.4  GW  in  2021  and  soared  to  17.8  GW  in  2022  (Greener,  2023b).  Employment  is thus created principally in sales, installations and O&amp;M, which are typically handled by small enterprises. IRENA estimates about 241/thinspace100 jobs in Brazil's solar PV sector in 2022. This is a dramatic increase from 131/thinspace000 jobs in 2021, reflecting the fact that cumulative deployment in the labour-intensive distributed segment almost doubled.

<!-- image -->

Brazil added 1.78 million square metres of solar water heating capacity in 2022, just 2% below the impressive record set in 2021 (ABRASOL, 2023). IRENA estimates 41/thinspace100 jobs in solar water heating. 9

<!-- image -->

In  the wind industry,  4  GW  of  capacity  were  added in 2023, up somewhat from 3.8 GW in 2021 (ABEEÓLICA, 2023). Brazil ranked third in wind capacity addition in the world, after China and the United States (IRENA, 2023b). IRENA estimates the country's wind workforce at about 67/thinspace700 people, primarily in construction, followed by O&amp;M. 10

- 7   The calculation is based on employment factors for different feedstocks (Da Cunha, Guilhoto and Da Silva Walter, 2014). The 2022 shares of feedstock raw materials, principally soybean oil and animal fat (beef tallow), are derived from USDA-FAS (2022a).
- 8 In 2021, about 167 900 workers were engaged in sugarcane cultivation in Brazil, and 176/thinspace700 worked in alcohol and ethanol processing.
- 9 This estimate is based on the assumption that employment changes mirrored the change in installations, thus applying a 2% decline to ABRASOL's 2021 estimate of 42/thinspace000 jobs (Johann, 2022). Mercantil Environmental (2023) mentions a figure of 50/thinspace000 jobs but does not explain how it was calculated.
- 10 This calculation is based on employment factors published by Simas and Pacca (2014).

The UNITED STATES had  close  to  1  million  renewable  energy  jobs  in  2022,  including about 406/thinspace700 jobs in biofuels, biomass power and woody biomass fuels; about 263/thinspace900 in solar PV; almost 122/thinspace500 in various renewable heating and cooling technologies;  about 11 66/thinspace300  in  hydropower 12 and  8/thinspace600  in  geothermal  power.  In  addition,  but  not  included in  this  report,  about  251/thinspace500  jobs  were  created  for  various  energy-transition-related technologies. 13 US DOE (2023) further estimates that energy efficiency employed about 2.2 million people in 2022, up by 50/thinspace500 over the previous year. 14

The passage of the Inflation Reduction Act (IRA) in August 2022 triggered announcements of new clean energy investments. Between August 2022 and the end of July 2023, over USD 270  billion  in  utility-scale  investments  and  investments  in  83  new  or  expanded utility-scale  manufacturing  facilities  were  announced,  with  a  potential  of  29/thinspace780  new jobs.  They  include  52  solar  PV  factories;  17  wind  facilities;  and  14  utility-scale  battery storage sites (American Clean Power, 2023).

<!-- image -->

In  2022,  the  United  States  installed  an  estimated 17.6  GW of solar PV capacity, its second-highest capacity addition after the 19.2 GW installed in 2021 (IRENA, 2023b). The industry faced supply chain disruptions due to an anti-circumvention probe announced in March 2022 (affecting PV cells and modules imported from Cambodia, Malaysia,  Thailand  and  Viet  Nam)  and  the  enforcement  of  the  'Uyghur  Forced  Labor Prevention Act',  which  led  to  the  months-long  detention  of  many  module  shipments from the Xinjiang Uyghur Autonomous Region (Groom, 2022).

<!-- image -->

<!-- image -->

- 11 This figure includes solar thermal, geothermal, biomass, heat pumps and other technologies.
- 12 This figure includes 11/thinspace677 jobs in low-impact hydro and 54/thinspace595 jobs in traditional hydro. There are also 8/thinspace333 jobs in pumped hydro, which are, however, not included here (US DOE, 2023).
- 13 This figure includes jobs in battery storage (72/thinspace923 jobs, of which 13/thinspace600 in battery manufacturing), smart grids (24/thinspace916 jobs), micro grids (19/thinspace845 jobs), other grid modernisation (20/thinspace794 jobs) and electrical vehicle charging (113/thinspace001 jobs) (US DOE, 2023).
- 14 The energy efficiency category includes appliances; heating, ventilation and air-conditioning; water heaters; electronic goods; windows, roofing and insulation; commercial equipment; and lighting.

<!-- image -->

<!-- image -->

According to the National Solar Jobs Census 2022 ,  US solar employment rose to almost 264/thinspace000 jobs in 2022, 3.6% more than in 2021. 15  Developments were mixed in different market segments. For utility-scale projects, the pace of installations slowed, with the loss of an estimated 6 000 jobs. However, employment in residential solar, which relies more on domestic modules, soared by 40%, with 9/thinspace500 jobs added. In 2022, two out of three solar jobs (or about 171/thinspace600 jobs) were in the installation and project development segments, with another 33/thinspace400 jobs in manufacturing, 30/thinspace600 jobs in sales and distribution, and 28/thinspace200 jobs in O&amp;M and 'other' activities (IREC, 2023).

Job creation has not kept pace with installations in recent years. This reflects growing labour productivity and installations with a focus on the utility-scale segment. The more labour-intensive residential solar segment accounts for 55% of jobs but just 28% of total capacity (IREC, 2023).

In 2022, only about 10% of US solar workers belonged to a union - no improvement over earlier years. Women accounted for 31% of all US solar jobs in 2022 (up from 29% the previous year and 27% in 2017). With a share of 9% of solar jobs, African Americans are less represented in the workforce than their share of jobs across the entire US economy would suggest. By contrast, Latinos and Latinas, at 22% of jobs, and Asians, at 9%, are above their respective national shares. A little over a quarter (27%) of the surveyed solar firms had strategies for hiring more women (compared with 31% in the previous year), and just 12% (up from 8%) took steps to increase LGBTIQ+ 16  hires (IREC, 2023).

In the wind industry, US blade manufacturing capacity dropped by 63% between 2021 and 2022, from 8.3 GW to just 3.1 GW. Over 2/thinspace000 workers were laid off as a result (Lico, 2022b). In October 2022, General Electric Co. announced that it would lay off 20% of its onshore wind workforce in the United States, along with other workers in Latin America, the Middle East and Africa (Singh and Hampton, 2022). US domestic production was replaced with growing imports from Mexico and India, with smaller volumes coming from Spain and Brazil, and much reduced volumes from China. Corporate outsourcing strategies seek to leverage the lower wage levels in many of these countries in an environment where labour and material costs have increased. Manufacturing and assembly labour accounts for 35% of the cost of fibreglass blades, 17 a typical blade requires more than 2/thinspace000 hours of labour inputs (Lico, 2022b).

<!-- image -->

<!-- image -->

- 15 The Interstate Renewable Energy Council (IREC) includes only solar workers who spend at least half of their working hours on solar goods and services. By contrast, the United States Energy &amp; Employment Report (US DOE, 2023) pegs solar PV employment at 346 143 in 2022, up from 333 887 in 2021. This includes all employees engaged with solar technologies, regardless of the share of time they spent on solarrelated work.
- 16 LGBTIQ+ stands for lesbian, gay, bisexual, transgender, intersex, queer/questioning, asexual and many other terms (such as non-binary and pansexual) (ILO, 2022).
- 17 However, fibreglass is expected to be increasingly replaced by carbon fibre, given the latter's advantages in weight, strength and flexibility. Labour represents merely 11% of carbon fibre costs, compared with 52% for material and energy, and 37% for capital costs (Lico, 2022b).

But the local content bonus included as part of the IRA may encourage a reopening of some factories. Also, subject to order confirmations and public funding, Vestas, Siemens and General Electric Co. intend to build new turbine component factories in Colorado, New York and New Jersey (Kessler, 2023; Woods, 2023).

In 2022, only 7.8 GW of wind capacity was installed in the United States, a little more than half of the over 14 GW added each in 2020 and 2021 (IRENA, 2023b). Still, the number of wind power jobs in 2022 was estimated at 125/thinspace580, up from 120/thinspace164 in 2021, given growing O&amp;M needs. For onshore wind employment, the largest segment was construction, with a 36% share, followed by professional and business services, with a 26% share. For offshore wind, such services accounted for 48%, followed by construction, with a 32% employment share (US DOE, 2023).

<!-- image -->

Biofuels is  estimated  to  have  359/thinspace700  jobs  in  the  United  States.  Total  biofuel production in 2022 remained below the 2018 peak level of 68 billion litres. Ethanol output rose slightly from 2021, but biodiesel volumes continued to decline. Input-output modelling suggests that bioethanol may have employed 296/thinspace500 persons in 2022 in the United States, including 78/thinspace800 directly and 217/thinspace700  indirectly  in  the  agricultural  supply chain (ethanol represents almost 40% of the entire country's corn crop; a large share of  the  industrial agriculture system is thus involved in producing this output). The total number  of  jobs  includes  close  to  30/thinspace000  export-related  positions  (Urbanchuk,  2023). Biodiesel output fell to 6.14 billion litres in 2022, down 5% from 6.5 billion litres in 2021 (US EIA, 2023). IRENA estimates the number of biodiesel-related jobs at about 63/thinspace200 in 2022, down from 66/thinspace650 in 2021.

Across the US energy sector, 11% of workers were either represented by a union or covered under a project labour agreement or collective bargaining arrangement. While quite low, it was higher than the 7% across the private sector economywide (US DOE, 2023).

Unionisation offers a range of benefits, including higher wages and benefits. Some 46% of unionised employers offered or required workplace diversity and/or inclusion training, more than double the 22% share among non-unionised employers. They were also more likely  to  have  specific  strategies,  policies  or  programmes  for  increasing  the  number  of female, minority and LGBTIQ+ hires. Far fewer (29%) of the unionised employers found it 'very difficult' to attract workers than non-union companies (48%) (US DOE, 2023).

Rewiring America  (Griffith, Calisch and Laskey, 2020), a non-profit organisation, estimated  that  the  United  States  will  need  an  additional  1  million  electricians  to  help install solar panels, heat pumps, electric vehicle charging stations and other technologies to  meet  the  climate  goals  established  under  the  IRA.  Reaching  that  goal  requires tapping into a broader pool of people, and, in particular, overcoming the barriers faced by women in the industry (see Box 3).

<!-- image -->

<!-- image -->

<!-- image -->

## Box 3

## Women - key to skilling the energy transition

As the world embraces renewable technologies and more sustainable practices, job opportunities in the electrical industry will multiply, especially for skilled electricians. Data  from  the  US  Bureau  of  Labor  Statistics  (BLS,  2023a)  show  that  about  21%  of currently active electricians will reach retirement age in the next ten years, whereas the demand for electricians could grow by 7%, resulting in nearly 80 000 job openings per year. That estimate does not even yet account for all the new incentives included as part of the Inflation Reduction Act - rebates for solar panels, electrical panels, heat pumps, stoves, cars, etc. - nor does it consider the possibility that demand might soar if local governments keep pushing to electrify buildings (Pontecorvo, 2023).

The evolving landscape in the electrical industry calls for urgent measures to attract fresh talent and invest in comprehensive training programmes to meet future demand. Women, largely underrepresented, at only 2% (see Table 3), can play a pivotal role in  this  transformation,  bringing  much-needed  diversity  and  innovation  to  a  maledominated field.

<!-- image -->

However, achieving gender equality and empowering women in the electrical sector require addressing critical issues like harassment and abuse, which are rife in the field (Preston, 2021). Cultivating a safe and respectful workplace is essential to attract and retain women in the industry. Further, increasing visibility of women's contributions and combating exclusionary practices in unions will help remove barriers and provide more opportunities for women to advance in their careers.

Actively  promoting  an  inclusive  and  supportive  working  environment  -  that  fights against  harassment,  advocates  for  visibility,  dismantles  exclusionary  practices  and supports  caregivers  -  can  help  the  women  in  the  electrical  sector  unlock  their  full potential, enabling the sector to secure a prosperous future (Renwick, 2023).

Table 3 Employed persons by selected occupations in the United States economy, 2022

|                                                  |                                                | Total jobs (thousands)   |   Share of women(%) |
|--------------------------------------------------|------------------------------------------------|--------------------------|---------------------|
| All employment                                   | All employment                                 | 158 291                  |                46.8 |
| Professional and related                         |                                                | 38749                    |                56.5 |
|                                                  | Electrical and electronics engineers           | 296                      |                 8.1 |
| Natural resources, construction, and maintenance |                                                | 14 260                   |                 5.7 |
| of which:                                        | Construction and extraction                    | 8427                     |                 4.2 |
| of which:                                        | Roofers                                        | 208                      |                 5   |
| of which:                                        | Carpenters                                     | 1 282                    |                 3.5 |
| of which:                                        | Electricians                                   | 918                      |                 2.2 |
| of which:                                        | Plumbers, pipefitters, steamfitters            | 610                      |                 1.1 |
| of which:                                        | Installation, maintenance, and repair          | 4853                     |                 4.2 |
| of which:                                        | Electrical power-line installers and repairers | 119                      |                 1.5 |

Source: BLS, 2023b.

<!-- image -->

<!-- image -->

India

0.99 million jobs

INDIA had an estimated 988/thinspace000 renewable energy jobs in 2022. Hydropower, with some 466/thinspace000  jobs,  was  the  largest  renewables  employer,  followed  by  solar  PV,  which  had 282/thinspace000 people involved with on-grid and off-grid systems. Other renewables represented far smaller numbers.

<!-- image -->

India added 13.5 GW of solar PV capacity in 2022, up from 10.3 GW in 2021. Both values  were  new  records  set  by  the  country  (IRENA,  2023b).  India's  domestic module production capacity grew from 10.4 GW in 2021 to 24.7 GW in 2022, although actual production did not keep pace and capacity utilisation declined from 36% to 28% (Wood Mackenzie, 2023a). While India remains heavily reliant on imports, its own solar module exports in 2022 more than quintupled, benefitting from US import restrictions imposed on Chinese products (Gulia et al. , 2023).

Based on an employment factor analysis, IRENA estimates that India had 201/thinspace400 jobs in grid-connected solar PV in 2022, up 47% from 2021. Roughly 80/thinspace000 people work in off-grid solar.

In  fiscal  year 18 2022,  India's  solar  industry  added  52/thinspace100  jobs  in  project  development (predominantly in construction and installation). Utility-scale solar accounted for 83% of added solar PV capacity, with a total of 72/thinspace700 jobs (up from 42/thinspace900 in 2021). Rooftop solar employment increased to 65/thinspace400 jobs from 43/thinspace000 jobs, while wind employment grew, at a slow pace, to 26/thinspace100 jobs (from 25/thinspace500) (CEEW, NRDC India and SCGJ, 2023; Tyagi et al. , 2022). These figures are lower than IRENA's estimates since they exclude indirect jobs, jobs in off-grid solar applications and jobs in equipment manufacturing.

<!-- image -->

India  ranks  fourth  in  the  world  in  cumulative wind power  generating  capacity, although 2022 was another slow year, with just 1.9 GW added, compared with the peak installation of 4.1 GW in 2017 (IRENA, 2023b). The wind energy sector added only 600 new jobs in construction and installation. India has 10-12 GW of domestic annual wind turbine  generator  manufacturing  capacity  (GWEC,  2023),  indicating  the  potential  for  a growth in domestic installations and exports. IRENA estimates that the Indian wind sector had 40/thinspace000 jobs in 2022, of which O&amp;M represented almost half.

<!-- image -->

18 India's fiscal year runs from 1 April to 31 March.

<!-- image -->

Countries  in EUROPE had  a  total  of  1.8  million  renewable  energy  jobs,  of  which  about 1.6 million were in the 27 EU Member States (EU-27).

<!-- image -->

IRENA estimates European wind power to have had 402/thinspace000 jobs in 2022, of which 319/thinspace000  were  in  EU-27.  The  continent's  total  wind-generating  capacity  reached 240 GW in 2022, with a record 18.6 GW newly added. The EU-27 installed the bulk of this new capacity, (15.7 GW) for a total of 204.1 GW (IRENA, 2023b).

Meanwhile, the picture was less encouraging for manufacturing. According to the Global Wind Energy Council (GWEC, 2023), new wind turbine orders declined by 47%, reflecting growing competition from non-European suppliers and high levels of uncertainty. Although European manufacturers remain industry technology leaders, operating losses led to job cuts. For example, in the fall of 2022, Siemens Gamesa announced that it would cut 2 900 jobs, including 800 in Denmark, 475 in Spain and 300 in Germany. The company employs about 27/thinspace000 people worldwide (Lee, 2022).

Losses  resulted  from  the  combined  effects  of  supply  chain  delays,  rising  costs  for  key materials and other inputs, and lengthy wind farm permitting processes (Hodgson, 2023, 2022). Turbine prices are typically set long before their actual delivery. In 2020 and 2021, costs were declining, but subsequently rose sharply; manufacturers have been unable to pass the rising costs on to project developers (Woods, 2023). Further, there is growing competition  from  Chinese  manufacturers,  which  have  benefited  from  a  stable  policy framework  at  home  and  are  now  increasingly  turning  their  focus  to  exports.  Chinese companies  already  have  a  strong  presence  in  supplying  turbine  components  used  by Western firms (Reed, 2022).

<!-- image -->

In the solar PV sector, Europe as a whole added about 37.7 GW in 2022, a significant gain over the 27.3 GW added in 2021 - which in itself was a new record (IRENA, 2023b). The EU-27 members represented 36 GW and 25.7 GW, respectively, of the total.

The 2022 EU Solar Jobs Report (SolarPower Europe, 2022) estimates 465/thinspace600 full-time employees in 2021, up from about 357/thinspace000 in 2020. This includes about 205/thinspace000 direct jobs and 261/thinspace000 indirect jobs, in material processing and logistics. Close to 80% of the total,  or  367/thinspace000  jobs,  were  in  the  deployment  segment.  By  contrast,  manufacturing employed only about 44/thinspace200 people, with another 40/thinspace000 employed in O&amp;M, and 14/thinspace000 were  employed  in  decommissioning  and  recycling.  Within  manufacturing,  the  bulk  of employment relates to inverter production (about 31/thinspace000 jobs), whereas employment for modules and polysilicon is much smaller, and employment for the production of cells and ingots/wafers is marginal (SolarPower Europe, 2022).

Given  Poland's  strong  focus  on  labour-intensive  residential  rooftop  systems  -  which require  three  times  as  much  labour  as  utility-scale  deployments  -  SolarPower  Europe believes that the country's solar PV sector had 113/thinspace000 jobs in 2021, up from 90/thinspace000 in 2020. Other leading countries include Germany (about 86/thinspace900 jobs), Spain (65/thinspace600), the Netherlands (36/thinspace400),  Greece  (33/thinspace700),  France  (33/thinspace200)  and  Italy  (24/thinspace300).  All  of  them have gained significantly in employment over the previous year, reflecting the growth of new deployments (SolarPower Europe, 2022).

<!-- image -->

<!-- image -->

<!-- image -->

Under  changed  economic  and  political  conditions,  companies  and  governments  are rediscovering industrial policy as a prime area for action to advance critical societal objectives. In late 2022, the European Commission - in a bid for greater EU self-reliance and in support of accelerated solar deployment - launched a Solar Photovoltaic Industry Alliance to achieve 30 GW of annual solar manufacturing capacity across the value chain by 2025. The alliance is intended to develop an action plan on issues including, among others, innovation, industrial supply chain, raw materials, finance access, circularity and sustainability, and skills, and will see participation from industry, research centres, consumer associations and non-government organisations. The approach is patterned on initiatives such as the Battery Alliance and the European Clean Hydrogen Alliance (European Commission, 2022a, 2022b), and comes in the context of growing efforts in the United States and India to attract corporate investment in local manufacturing (Taiyang News, 2022).

As is the case in other parts of the world, building or reconstituting a domestic solar PV manufacturing industry, including in particular ingot and wafer capacities, is a steep challenge for Europe. As global leaders, Chinese companies derive strong competitive advantage from their much greater scales of production (Fuhs and Enkhardt, 2023).

SolarPower Europe projects that under a 'medium scenario', EU solar PV jobs could grow to about 530/thinspace000 by 2026, 19 and double that figure under a more ambitious pathway to 2030. But as the organisation points out, this will depend not only on a concerted industrial strategy but also on boosting skilling and workforce development efforts, including efforts to better connect job seekers with companies' requirements.

<!-- image -->

According to EurObserv'ER (2023), the European bioenergy sector has the largest employment share, with a total of 549/thinspace200 people. Solid biomass (for heating and electricity)  had  a  workforce  of  approximately  353/thinspace800  in  2021.  Another  148/thinspace300  were employed for biofuels and 47/thinspace100 for biogas.

The use of solid biomass in the EU-27 rose substantially, reaching peak levels in 2021. Over 95% of EU's solid biomass supply need is met domestically, translating into significant local employment in feedstock operations. The largest employers in this regard were Poland and Germany, with over 40/thinspace000 jobs each, followed by France, the Netherlands, Sweden and Italy (each with over 20/thinspace000 jobs) (EurObserv'ER, 2023).

Ethanol fuel  production in EU-27 rose to new peaks of 5.2 billion litres and 5.35 billion litres in 2021 and 2022, respectively. Meanwhile, biodiesel output in both years remained slightly  below that in the 2020 peak year, at about 19 billion litres (USDA-FAS, 2022e). However, substantial biofuel production capacities still remain idle. EurObserv'ER (2023) estimated about 148/thinspace300  biofuel-related  jobs  in  EU-27  in  2021,  up  from  141/thinspace600  jobs  in 2020. Given that overall biofuel production was slightly higher in 2022, it stands to reason that employment that year aligned closely with the 2021 value.

EU  biofuel-related  jobs  in  2021  were  predominantly  in  countries  with  vast  agricultural  areas (Poland with 21/thinspace400 jobs, Romania with 17/thinspace800 jobs, Hungary with 17/thinspace000 jobs and Spain with 13/thinspace 500  jobs )  and  among the biggest consumers - France (18/thinspace800 jobs) and Germany (12/thinspace400 jobs).

19 This scenario expects 34 GW in annual capacity additions. For a comparison, the European Union installed 36 GW in 2022.

Among the EU-27 members, new solar PV installations in GERMANY rose to 7.3 GW in 2022, continuing a steady upward trend after multiple years of much slower capacity growth. The picture is quite different for wind. Following record installations in 2017, of 6.1 GW, the pace has slowed, with 2.5 GW added in 2022, even though it represented an uptick from just  1.6  GW  in  2021  (IRENA,  2023b).  Wind  additions  are  affected  by  a  time-consuming permitting process and restrictive siting rules in some of Germany's federal states.

The 2022 EU Solar Jobs Report (SolarPower Europe, 2022) estimated Germany's direct and  indirect solar  PV employment  in  2021  at  about  86/thinspace900  FTEs.  Bundesverband Solarwirtschaft (BSW, 2023) provides a figure of 55/thinspace000 direct jobs in 2023, reflecting growing installation activity. IRENA's estimates suggest that the industry supported close to 94/thinspace000 jobs in 2022. German wind energy employment declined from 167/thinspace600 jobs in 2016 to 122/thinspace100 jobs in 2019, followed by a modest recovery to approximately 139/thinspace000 jobs in  2022.  The  slow  pace  of  new  capacity  installations  also  makes  it  harder  to  sustain  a sizable  domestic  manufacturing  industry. Bioenergy -  biofuels,  biomass  power  and biogas - remains a key employer in Germany, with 78/thinspace000 jobs in 2022. The jobs number has, nevertheless, declined over the past couple of years. Geothermal energy (13/thinspace200 jobs) and hydropower (4/thinspace700 jobs) are much smaller employers.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The required solar and wind energy expansion in Germany in the coming years will need some 216/thinspace000 additional skilled workers in renewables supplies and support functions. Skill shortages  specifically  encompass  electricians,  heating  and  air-conditioning  technicians, and  information  technology  specialists.  Greater  recruitment  of  women  and  retraining workers  from  other  fields  could  help  address  the  challenge  (Institut  der  deutschen Wirtschaft,  2022).  Germany's  metalworkers'  union,  IG  Metall,  in  concert  with  heating, electrical,  carpentry  and  other  trade  associations,  points  to  a  lack  of  190/thinspace000  skilled workers in energy transition fields and an energy renovation backlog for over 19 million residential buildings. Policy makers will have to boost the capacities of vocational schools and  other  educational  institutions  and  ensure  that  vocational  and  academic  education paths hold equal value. In October 2022, the German government approved a new skilled labour strategy, which includes measures to help companies and businesses attract and retain skilled workers (Meza, 2022).

<!-- image -->

<!-- image -->

<!-- image -->

In 2021, renewable energy made remarkable strides in SPAIN , significantly contributing to the national economy and job market. According to a study by the Asociación de Productores de Energía Renovables (APPA, 2022), the renewable energy sector contributed 1.6% of gross domestic product (GDP). The sector provided employment to an estimated 111/thinspace409 workers. Solar PV installations witnessed a 59% increase in employment opportunities, especially those focused on self-consumption. Further, other renewable technologies such as wind, solar thermal and marine, also made positive contributions to job creation. All of this resulted in an overall impressive net gain in employment opportunities of almost 20% compared with the previous year (APPA, 2022).

Meanwhile, in a new study conducted in collaboration with the Naturgy Foundation, the Spanish Just Transition Institute (ITJ) estimates that the energy transition has created over 152/thinspace000  jobs  over  the  past  seven  years  (2015-2022).  But  importantly,  the  study  points out  that  women  represented  just  18.2%  of  the  sector's  workforce  in  2021,  a  marginal increase  of  1.2%  over  2012,  almost  a  decade  earlier.  Also,  the  sector  share  remains significantly  below  women's  representation  across  the  entire  economy  in  2012,  when women constituted 47% of the overall workforce (Martínez et al. , 2023). The study also identifies gender gaps in technical occupations (see Box 4).

<!-- image -->

<!-- image -->

## Box 4

## Gender gaps in Spain's energy transition industries

<!-- image -->

According to a first full assessment of the Spanish labour market, women had four out of 10 of the new jobs linked to the energy transition in the period 2015-2021. From a low starting point, female employment grew much faster than male employment in the various subsectors of the energy transition. While positive, the evolution over the last decade is still very slow.

Women continue to be under-represented in essential technical fields related to the energy transition, both in terms of university programmes and vocational training. Of all university graduates in 2020, only 11% were women majoring in science, technology, engineering and mathematics (STEM) fields, compared with 36% of men graduating in these fields.

The gap is more pronounced in vocational training, where 7.9% of women are engaged. Women working in clean  energy  primarily  hold  administrative  positions,  whereas  technical  positions  remain  male  dominated. Gender parity in energy transition employment, whose current lack indicates a deep and persistent gap, would require 265 years to achieve at the current pace of progress.

Additional  analysis  shows  that  the  gender  wage  gap  in  the  energy  transition  sector  is  comparatively  less pronounced than in the overall economy, with women earning 6% less than men, as opposed to a 14% national wage gap. According to the study,  women in  the  Spanish  energy  transition  sector  are  often  found  to  be overqualified for their positions.

Further, the study shows that women occupied less than 20% of the jobs created in the renewable market across the European Union in 2020. Sadly, no country in the region managed to surpass the 30% threshold. Overall,  these  findings  highlight  the  pressing  need  to  address  gender  disparities  in  the  energy  transition industry by promoting women's participation in technical fields, fostering gender balance in various roles and ensuring equal pay for equal work. Only through concerted efforts can these gaps be bridged to create a more equitable and inclusive energy transition workforce.

Source: Martínez et al., 2023.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

According to modelling estimates by EurObserv'ER (2023), in 2021, FRANCE had about 24/thinspace900  people engaged in solid-biomass-related jobs, 18/thinspace800 in biofuel-related jobs and 14/thinspace500 in wind-power-related jobs. This was a change by small margins over 2020. But the number of jobs rose dramatically in solar PV, from 3/thinspace600 to 23/thinspace300, reflecting a faster pace of installations, which also continued into 2022. The pace of wind capacity additions has been relatively slow, due in part to slow permitting processes. France added just 1.3 GW of capacity in 2021 but gathered speed thereafter, installing a record 2.4 GW in 2022, for a cumulative total of 21.1 GW (IRENA, 2023b).

A detailed assessment by France Énergie Éolienne and Capgemini (2022) suggests that the EurObserv'ER wind jobs estimate is rather conservative. According to this study, there were 25/thinspace460  direct and indirect wind-related jobs at the end of 2021, up 12.8% over the 22/thinspace600 jobs in 2020. Of the total jobs, 33% were in planning and development, followed by 28% in engineering and construction, 22% in component manufacturing and the remaining 17% in O&amp;M. Close to 30% of all wind jobs are in the capital region around Paris, the Île-deFrance, where much of the design and planning work takes place. Five other regions have an at least 10% jobs share each (together accounting for 56% of all jobs). Offshore wind accounts for 6/thinspace200 jobs, a quarter of all wind jobs, and these are primarily in Normandy and Pays de la Loire. In March 2022, the government and industry made an offshore wind pact (Pacte éolien en mer) to create 20/thinspace000 offshore jobs by 2035, with a view to achieving at least 50% local content.

Regarding regions outside the European Union, the Offshore Wind Industry Council (OWIC, 2023) reports that the UNITED KINGDOM's wind power workforce grew to 32/thinspace257 in 2022, up 4% from the previous year. This number includes about 17/thinspace400 direct jobs and 14/thinspace900 indirect jobs. OWIC forecasts that jobs could grow to 88/thinspace500 in 2026, as several projects are installed. By 2030, the workforce could grow to 104/thinspace400 if the current deployment target of 50 GW (almost double the 2022 capacity) is fulfilled. Some 56/thinspace300 jobs would be direct and 48/thinspace100 indirect. However, this projected growth needs to be supported by a skill strategy to bridge shortages of planners, technicians for high-voltage electrical works, engineers, turbine technicians and other skilled personnel. Women represent 20.6% of the current workforce, inching up from 16% in 2019, 18% in 2020 and 19.3% in 2021. Regionally, 29% of the UK's offshore wind workforce is in Scotland, followed by Yorkshire and Humber (16.4%), London (15.2%) and the North East and North West regions of England (about 11% each). The remaining parts of the country have much smaller shares.

<!-- image -->

<!-- image -->

A  study  by  Robert  Gordon  University  (2022)  argues  that  significant  investments  are needed to secure and expand renewable energy jobs. The most ambitious of four scenarios to 2030 entails GBP 17 billion in investments in manufacturing and deployment of wind, hydrogen, and carbon capture and storage. With skill transferability relatively high, close to 14/thinspace000 oil and gas workers may need assistance with reskilling and skill certification in transitioning to renewables.

Another study (Platform, 2022) examines the clean job creation potential (in offshore wind, hydrogen electrolysers and energy efficiency retrofitting) in four areas in eastern Scotland  and  England  that  now  have  significant  oil-and-gas-related  employment: Aberdeen and Aberdeenshire, Fife and Tayside, Tyneside and Teesside. It finds that by 2032, these areas could have between 97/thinspace800 and 138/thinspace900 jobs, of which 30/thinspace500-38/thinspace300 would be in offshore wind.

The report notes that the United Kingdom has so far created fewer offshore wind jobs than expected, mostly because components like foundations, 20  towers, nacelles and others are largely imported. Newly opening factories signal the beginnings of a bigger domestic supply chain, and public investment could reinforce this as the pipeline of projects exceeds operational capacities eightfold.

## 2.2 OTHER COUNTRIES

In  West  Asia, TÜRKIYE's new  solar  PV  capacity  installations  reached  a  new  record  of 1.6 GW in 2022, but wind additions were at less than half the pace in 2021 (IRENA, 2023b). A key objective has been to boost the share of renewable energy equipment produced domestically. Türkiye has adopted tariffs and anti-dumping rules to limit imports, and it offers tax incentives for domestic module production. The country now has more than 60 module companies. Further, a number of large companies in industries such as textiles are setting up module production lines to supply their own needs (Gifford, 2023). IRENA estimates 26/thinspace000 solar PV jobs and 13/thinspace000 wind energy jobs in Türkiye.

In East Asia, JAPAN's cumulative solar PV capacity reached 78.8 GW in 2022. This is the third-largest capacity of any country worldwide, but new additions (4.6 GW) continue to be substantially below the record of 7 GW achieved in 2019 (IRENA, 2023b). IRENA estimates some 127/thinspace000 solar PV jobs in 2022, 21 when foreign-produced modules accounted for 90% of total shipments (JPEA, 2023).

Japan has about 4.4 GW of wind capacity. Almost all of it is onshore and is growing slowly. The country recently established its offshore wind presence in December 2022 (IRENA, 2023b). Japan adopted a goal of 10 GW of wind capacity by 2030 and 30-45 GW by 2040, with  a  60%  local  content  share  by  2040.  Input-output  analysis  suggests  that  reaching 7 GW by 2030 could create 54/thinspace000 jobs (of which 20 000 are direct and 34/thinspace000 indirect) in the construction of wind farms, and reaching 36 GW by 2040 could create 69/thinspace000 jobs. O&amp;M could have about 4/thinspace560 jobs by 2030 and close to 18/thinspace000 jobs by 2040. However, appropriate  measures  will  be  required  to  train  an  adequate  number  of  people  in  the required skills (Renewable Energy Institute, 2022).

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Among Southeast Asian countries, Viet Nam, Malaysia and Thailand are leading solar PV cell  and  module  manufacturers  and  exporters.  They  have  also  installed  the  largest PV generating capacities in the region, together with the Philippines. The PV footprint remains much smaller in the rest of the region (see Table 4). Malaysia, as a key module manufacturing hub, is home to nearly 45/thinspace000 solar PV jobs, whereas domestic installations have  remained  limited.  For  Thailand's  solar  PV  manufacturing  sector,  IRENA  estimates employment opportunities at over 29/thinspace000 people.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 4 Solar photovoltaic generating and manufacturing capacities in Southeast Asia, 2022

|             | PV generation   | PV manufacturing capacity (GW)   | PV manufacturing capacity (GW)   | PV manufacturing capacity (GW)   | PV manufacturing capacity (GW)   |
|-------------|-----------------|----------------------------------|----------------------------------|----------------------------------|----------------------------------|
|             | capacity (MW)   | Polysilicon                      | Wafer                            | Cell                             | Module                           |
| Viet Nam    | 18 474          | -                                | 12.5                             | 14                               | 29.65                            |
| Thailand    | 3060            | -                                | -                                | 9.35                             | 6.2                              |
| Malaysia    | 1 933           | 11                               | 1.2                              | 23.6                             | 13.9                             |
| Philippines | 1 625           | -                                | -                                | 0.4                              | 0.8                              |
| Singapore   | 572             | -                                | 1.8                              | 2.9                              | 3.7                              |
| Cambodia    | 456             | -                                | -                                | 1                                | 2.2                              |
| Indonesia   | 291             | 12                               | -                                | 1                                | 2.05                             |
| Myanmar     | 103             | -                                | -                                | -                                | -                                |
| Lao PDR     | 34              | -                                | -                                | -                                | -                                |

Sources: IRENA, 2023b (generating capacities); Yu and Dong, 2023 (polysilicon); Wood Mackenzie, 2023a (other manufacturing capacities). Note: GW = gigawatt; Lao PDR = Lao People's Democratic Republic; MW = megawatt; PV = photovoltaic.

<!-- image -->

VIET NAM is a major manufacturer and exporter of PV cells and modules. Its cell production capacity  rose  from  just  50  MW  in  2013  to  12.5  GW  in  2021,  while  module  production capacity  increased  from  110  MW  to  29.65  GW  over  the  same  period.  Module  output, meanwhile, soared from 22 MW to 11.4 GW (Wood Mackenzie, 2023a). However, domestic deployments have fluctuated dramatically. Following a massive surge in PV installations, new additions in 2021 came to a standstill due to power transmission bottlenecks, and in 2022, at 1.8 GW, were still much smaller than in 2019 and 2020 (IRENA, 2023b). The government now eyes adding only 4 GW by 2030, although distributed solar PV could grow significantly since it is not subject to grid connection limitations (Wood Mackenzie, 2023c). With a decrease in installations, Viet Nam's solar PV workforce declined to about 115/thinspace000 jobs in 2022, according to IRENA estimates. The jobs were predominantly (69%) in module, cell, inverter and wafer manufacturing. Viet Nam's wind additions were still strong in 2021, at 3.6 GW, but slowed considerably in 2022, to 0.5 GW (IRENA, 2023b). IRENA estimates that Viet Nam may have 9/thinspace000 wind jobs.

Indonesia, Malaysia, Thailand and the Philippines are large biofuel producers. Despite rising palm oil prices in 2022, INDONESIA maintained its 30% biodiesel blending mandate. Continued subsidies and tax incentives for flexible-fuel vehicles were expected to boost domestic consumption by 10% over that in 2021. Exports remain limited due to export levies and EU import policies imposing sustainability criteria. Production  was estimated to rise to a record 10.3 billion litres in 2022, up 8% over 2021 (USDA-FAS, 2022c). Based on an employment factor calculation, IRENA estimates biodiesel employment to have risen to 619/thinspace000 jobs in 2022, up from 574/thinspace000 in 2021. This figure may not necessarily represent full-time and formal employment, however.

MALAYSIA's biodiesel production in 2022 was projected at 1.15 billion litres, the third straight year of decline and 35% below the 2019 peak. Less than half of the country's production capacity is utilised. The government had intended to introduce a biodiesel blending  mandate  (B20)  in  2020  to  counter  high  gasoline  and  diesel  prices,  but implementation  had  to  be  postponed  repeatedly  due  to  COVID-19  impacts,  volatility in crude  palm  oil  prices,  political  uncertainty  and  fiscal  constraints  affecting  the government's  ability  to  provide  biodiesel  subsidies.  Exports  rose,  but  prospects  in the primary market in Europe are dim, given the EU's decision to limit the use of palm biodiesel (USDA-FAS, 2022d). IRENA estimates that the biodiesel sector accounted for about 66/thinspace600 jobs in 2022, down from 106 200 in 2019.

In  the PHILIPPINES ,  ethanol  and  biodiesel  production  both  grew  somewhat  in  2022. However,  there  has  been  no  move  to  require  higher  blend  rates  (USDA-FAS,  2023a). An estimate by IRENA suggests biofuels may employ close to 45/thinspace000 people.

THAILAND's ethanol production remains below the 2019 peak, and biodiesel output has declined for the past three years. Total biofuel consumption fell by 7.8% primarily due to reductions  in  biodiesel  use,  which  more  than  offset  the  growing  ethanol  demand.  The government reduced the mandatory biodiesel blend rate from 10% to 7% at the beginning of  2022  (USDA-FAS,  2023b).  IRENA  estimates  97/thinspace100  biofuel  jobs  in  Thailand  in  2022, down from a revised figure of 115/thinspace400 in 2021.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In  the  Pacific, AUSTRALIA's government  launched  the  Australian  Energy  Employment Report in January 2023, the country's first national energy workforce survey to improve understanding of the needed policies for job and skill development, provide support for energy  transition  pathways,  generate  a  snapshot  of  workforce  diversity,  and  improve workforce planning and industry investment (Department of Climate Change, Energy, the Environment and Water, 2023).

Researchers  at  the  Institute  for  Sustainable  Future  estimate  Australia's  transition  to 82% renewable energy in power generation - the government's aim - will require up to 30/thinspace000 workers to build solar and wind farms, rooftop solar and associated infrastructure like  transmission  lines.  These  jobs  will  predominantly  be  in  project  development  and construction  and,  increasingly,  in  O&amp;M.  A  dedicated  skill  strategy  is  required  to  build this  workforce,  although  there  already  are  shortages  of  engineers,  electricians  and transmission line workers today (Briggs and Langdon, 2022).

Another  study,  commissioned  by  the  Future  Battery  Industries  Cooperative  Research Centre (FBICRC, 2021), finds that the battery industry currently employs  about 6/thinspace000  people,  although  mostly  in  the  mining  of  the  needed raw materials. A continued focus  on  the  mining  segment  of  the  value  chain  could  expand  the  number  of  jobs  to 18/thinspace700 by 2030. However, a greater focus on material processing, battery manufacturing and  assembly,  associated  services,  and  end-of-life  reuse  and  recycling  could  support 34/thinspace700 jobs in Australia.

The Australian government is actively building a renewable energy workforce. This includes the convening of a Jobs and Skills Summit, and commissioning Jobs and Skills Australia to conduct a capacity study for the workforce needed for a clean energy transition. The Clean Energy Council, meanwhile, released a report titled Skilling the Energy Transition with key recommendations such as anticipating workforce needs, better calibration between the higher education and vocational training sectors and the industry, increasing the visibility of clean energy jobs and establishing a Transition Authority (Clean Energy Council, 2023).

<!-- image -->

In the Western Hemisphere, hydropower asserts its dominance as the foremost employer within CANADA's renewable sector, sustaining a substantial workforce of 28 800 in direct roles  and  bolstering  an  additional  15/thinspace500  jobs  indirectly  in  2020.  IRENA's  hydropower estimates  (see  Section  1.3)  suggests  over  35/thinspace000  direct  jobs  in  2022.  Solar  PV  ranked next with 13/thinspace000  individuals  in  direct  positions  throughout  2022.  The  bioenergy  sector was pivotal in employment, encompassing approximately 4/thinspace700 direct jobs, of which 1/thinspace300 were specifically attributed to liquid biofuels. Trailing behind, the wind sector contributed 3/thinspace600 direct jobs (Energy and Natural Resources Canada, 2023).

MEXICO added close to 1.2 GW of solar PV capacity in 2022, resulting in approximately 19/thinspace000 jobs in the sector. The wind market was relatively stagnant, with only about 160 MW added (IRENA, 2023b). The country, however, has become the primary wind blade supplier in the Western  Hemisphere,  with  manufacturing  capacity  growing  from  2.1  GW  to  2.6  GW  over 2021-2022. The United States' manufacturing capacity, by contrast, declined from 8.3 GW to 3.1 GW, while capacities in Brazil and Canada stagnated at a combined 3.9 GW over the same period (Lico, 2022b). The Mexican Wind Energy Association estimated 6/thinspace933 wind jobs in 2021 (the most recent year for which data were available), of which manufacturing accounted for almost two-thirds (AMDEE, 2022). A more vibrant domestic market could create some 29/thinspace000 jobs between 2022 and 2026, according to the Global Wind Energy Council (GWEC, 2022).

NICARAGUA's power  generation  sector  has  grown  remarkably  in  recent  years  due  to substantial  public  and  private  investments  at  the  national  level.  The  country  has  been able to meet its power demand through a substantial improvement in electricity coverage due  to  expanded  installed  capacity.  There  has  been  a  significant  push  for  renewable sources in the national energy mix. In the past decade, the country's installed renewable capacity increased from 550 MW to 743 MW (IRENA, 2023b). Nicaragua's progress can be attributed to its abundant natural resources and strategic geographical location, but also to the established legal framework to further encourage investments. This resulted in 8/thinspace400 direct jobs in 2022 across biomass, geothermal, solar PV, wind and hydropower.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In COLOMBIA , ethanol and biodiesel production in 2022 were estimated to have decreased to 360 million litres and 700 million litres, respectively, despite rising transportation fuel demand.  This  was  due  to  adverse  weather  conditions  and  a  decision  to  reduce  blend mandates. Ethanol production fell for a fourth consecutive year and was estimated at 24% below the 2018 peak. Meanwhile, biodiesel production had risen year after year, but fell slightly in 2022 (USDA-FAS, 2022b). A rough employment factor calculation suggests that among those deriving a livelihood from biofuels (not necessarily  full-time  equivalents), about  82/thinspace000 are  in  ethanol-related  jobs  and  104/thinspace700  in  biodiesel-related  jobs.  The combined total of 186/thinspace700 jobs is about 6% less than a revised estimate of 198/thinspace150 for the year 2021.

<!-- image -->

In SOUTH  AFRICA , cumulative  direct  employment  through  the  Renewable  Energy Independent Power Producer Procurement Programme is estimated at 69/thinspace554 job-years. Of that, some 49/thinspace422 job-years, close to three-quarters, are in construction, a sector that offers employment only for a limited period, often low-skilled jobs, with limited cross-links to  other  sectors  of  the  economy.  The  remainder,  some  20/thinspace132  job-years,  were  in  O&amp;M roles. Women have a mere 16% share in all jobs, though up from a 10% share a year earlier. More than 60% of employment is in the Northern Cape region. The Eastern Cape and Western Cape together have close to a quarter share, whereas numbers are much smaller elsewhere (IPPPP, 2023). Aside from deployment-related jobs, South Africa has some solar and wind manufacturing capacity (which is although hampered by weak competitiveness with  foreign  producers  and  insufficient  and  variable  local  demand)  (USAID  and  Power Africa, 2022).

<!-- image -->

<!-- image -->

## INDUSTRIAL POLICY INITIATIVES

Equipment manufacturing for the solar photovoltaic (PV) and wind energy industries is highly concentrated in a few countries, as is much of the associated employment. However, these structures are in a state of flux due to corporate policies seeking locations with low labour costs for factories and government policies trying to localise or re-localise manufacturing operations. This section discusses the current geography of solar PV and wind equipment manufacturing and sketches recent industrial policy initiatives in several countries, which may change the geography of renewable energy employment.

<!-- image -->

## CHAPTER 3

<!-- image -->

## 3.1   THE GEOGRAPHY OF SOLAR PV AND WIND EQUIPMENT MANUFACTURING

Global annual solar PV module production has multiplied 38-fold over the past 15 years, growing from 7.2 GW in 2008 to 271 GW in 2022. Production jumped from 193 GW to 271 GW in 2022 alone. Meanwhile, it is worth noting that a large portion of capacity sits idle; less than half has been utilised in recent years, down from as much as 83% in 2017 (Wood Mackenzie, 2023a).

Even more than is the case for installations, the centre of gravity in manufacturing shifted from Europe to China, with obvious implications for where jobs are created. In solar PV manufacturing, China's share of global module production doubled from 39% in 2008 to 78% in 2022. While China continues to expand its own manufacturing capacity, trade restrictions adopted in past years have led Chinese manufacturers to invest in module factories in Southeast Asia that essentially assemble Chinese-made PV cells for export (Yu and Dong, 2023). Southeast Asia's share of global module production rose from 2% to 11% in 2020 (but fell to 8% in 2022).

Only minimal manufacturing is taking place in other regions of the world. Europe's share plunged from 30% to 0.5% over 2008-2022, Japan's dropped from 11% to 0.2% and that of the United States dropped from 6.8% to 1.7% (see Figure 13) (Wood Mackenzie, 2023a). China holds an even more dominant position in wafer, cell and polysilicon production, with 97%, 84% and 83%, respectively, of the global production in 2022 (Yu and Dong, 2023).

Figure 13 Solar photovoltaic module production by country/region, 2008-2022

<!-- image -->

Gigawatt of annual module production

Source: Wood Mackenzie, 2023a.

<!-- image -->

Notwithstanding  rising  trade  tensions,  the  value  of  China's  solar  PV  exports  (mostly modules, with Europe as the principal buyer) grew 64% in 2022, from USD 32 billion to USD 52 billion. This reflects the country's dominant position and the fact that its modules are up to 57% more affordable than those produced in the United States or Europe. China's principal cost advantage lies in its lower material costs; while labour costs are also lower in China, they contribute only about 10% or so to overall costs (Yu and Dong, 2023).

Regarding wind equipment manufacturing ,  Chinese firms have primarily produced for their own sizable domestic market, whereas European companies have dominated markets outside of China. Global competition is, however, set to grow, and this will strongly affect the geography of job creation in the industry. Cost pressures will likely lead to increased automation in blade manufacturing, affecting labour requirements (Lico, 2022b).

Global orders for 'completed and firm' wind turbines grew from about 64.4 GW in 2020 to  104.8  GW  in  2021,  declining  slightly  to  100.9  GW  in  2022.  Chinese  manufacturers managed to increase their share of global orders from 39% in 2020 to 59% in 2022. All other companies saw a reduction in 2022, from 54.1 GW to 41.1 GW (Wood Mackenzie, 2023b). Chinese firms benefit from stable long-term policies and demand certainty at home, and they have significant economies of scale along the supply chain segments (Lico, 2022a).

Meanwhile,  European  firms,  which  have  long  been  the  technology  front  runners,  are facing several pressures, including, among others, rising raw material costs, skyrocketing logistics  costs  and  port  congestion,  higher-than-expected  costs  of  developing  new turbines  and  lingering  COVID-19  impacts  (Lico,  2022a).  In  recent  years,  European equipment manufacturers have closed less profitable plants and outsourced production, especially of blades, 22 to low-wage countries (such as Brazil, India, Mexico and Türkiye) (Lico, 2022a, 2022b).

22   Only a third of onshore blades and half of offshore blades worldwide were produced in-house by original equipment manufacturers in 2021, down from 50% and 80%, respectively, a decade earlier (see Lico, 2022b).

<!-- image -->

At  the  same  time,  an  increasing  number  of  countries  have  adopted  domestic  content requirements  to  incentivise  or  mandate  the  establishment  of  factories  on  their  own territories,  serving  domestic,  regional  or  global  markets  (David,  2021).  For  gearboxes and generators, India and Eastern Europe are positioning themselves as alternatives to dominant Chinese suppliers. All European suppliers of drivetrains have set up factories in low-wage Asian countries and invested in automation to reduce labour costs (Lico, 2022d).

China leads the world in terms of overall wind manufacturing capacity. According to the Global Wind Energy Council (GWEC, 2023), China had 60% of total 163 GW nacelle capacity in 2022, followed by Europe (19%), the United States (9%), India (7%) and Latin America (4%).  China  is  adding  over  60  nacelle  assemblies  to  about  a  100  already  in  operation (White, 2023).

China commands a 60% share also in blade manufacturing, followed by Europe (14%), India (11%), and the United States and Latin America (7% each). The distribution of other component manufacturing follows a similar pattern, except generators, where Europe still retains a 22% share. Three-quarters of gearbox manufacturing takes place in China, with the rest divided between Europe and India (GWEC, 2023).

Meanwhile, supply chains for towers are fragmented, with over 240 factories in 30 countries owned by 100 different suppliers (Lico, 2022c). However, growing regionalisation reflects high  logistics  costs  for  ever  taller  towers  and  is  reinforced  by  tariffs  and  local  content rules. Corporate outsourcing strategies are driven by cost control objectives amid rising competition  and  ongoing  global  oversupply.  Chinese  manufacturers  (which  supplied 87% of offshore towers in 2021) benefit from lower steel costs besides significant scale advantages to gain an edge over US and European suppliers. Between 2017 and 2020, EU tower production dropped 10%, while imports from China increased by 54% (Lico, 2022c). This prompted governments to impose tariffs 23  and domestic content requirements. For onshore towers, tariffs led to a shift in supply chains towards Indonesia, the Philippines, the Republic of Korea and Viet Nam.

<!-- image -->

<!-- image -->

- 23   The United States imposed high tariffs on towers imported from Spain and Viet Nam but much lower tariffs on towers imported from Canada, Indonesia, Malaysia, the Republic of Korea and India (see Lico, 2022c).

<!-- image -->

<!-- image -->

## 3.2   INDUSTRIAL POLICY INITIATIVES AMID A NEW GEOPOLITICS

Policy making regarding the global renewable energy supply chain landscape is shifting due to a growing concern that reliance on distant supply chains - which involve a handful of  dominant players - entails vulnerability to disruptions such as pandemics and other disasters.  Diverging  national  strategies  and  corporate  objectives,  trade  disputes  and geopolitical rivalries have added to a sense of upheaval.

Indeed, the narrative has changed dramatically. Just a few short years ago, the dominant view was that solar PV panel and component manufacturing was essentially a commodity business that was best offshored to countries with low wages and other cost advantages.

While  outsourcing  to  low-wage  locations  continues,  the  rising  geopolitics  of  the  energy transition has generated a new determination to 're-shore', 'near-shore' or 'friend-shore' a greater share of manufacturing capacities, as well as critical material supplies (IRENA, 2023e).

In a bid to build and strengthen local capacities, governments are re-embracing previously disavowed industrial policy measures (besides tariffs and non-tariff import restrictions, which  have  already  increasingly  been  adopted  in  recent  years).  Such  policies,  which entail both incentives and mandates, may include, among other measures, local content requirements; manufacturing clusters; tax credits, subsidies, grants and loan guarantees for  manufacturing;  public  research  and  development  funds,  and  technology  transfer policies; inexpensive electricity and land; and the creation of market demand.

Writing in a broad, economy-wide  context,  Mazzucato  (2022)  has  argued  that governments should 'raise the bar' on expectations from the private sector in return for  public  funding.  She  suggests  four  types  of  conditions  for  public  procurement, grants,  loans  and  tax  incentives:  broad  affordability  and  equitable  access;  social  and environmental standards; adequate sharing of royalties, equity or intellectual property with the government; and a prohibition of the use of public funds for share buybacks.

<!-- image -->

China has successfully pursued a broad array of industrial policies for several years, building a fully integrated wind and solar manufacturing industry. More recently, other countries are also  prioritising  efforts  to  localise  or  regionalise  portions  of  the  supply  chain  to  reduce energy security vulnerabilities and also capture a greater portion of the socio-economic benefits  of  the  energy  transition.  Japan,  the  United  States,  the  European  Union,  India and South Africa, among others, have announced industrial policy initiatives to stimulate domestic manufacturing and become more competitive vis-à-vis Chinese suppliers.

Meanwhile, it is worth noting that current industrial policy initiatives will not fundamentally change the renewable energy manufacturing landscape for some years, since that requires substantial time and resources to establish the needed capabilities at the necessary scale. China will thus continue to host most renewable energy jobs for the foreseeable future. Further,  in  solar  PV,  China  hinted  in  January  2023  at  its  possibility  of  imposing  export restrictions on wafer, silicon and ingot casting technologies, complicating other countries' plans to expand their solar manufacturing capabilities (Martinez and Pierce, 2023).

Among  the  countries  that  have  announced  industrial  policy  initiatives, Japan seeks to  establish  its  own  manufacturing base for offshore wind through its 'Programme for Promoting Investment in Japan to Strengthen Supply Chains' (GWEC, 2023), which will mandate developers to work with local companies and demonstrate local and national economic benefits. These two dimensions will account for one-fifth of the combined bid scores under the country's first offshore tender (Diao, Li and Wang, 2022).

India's industrial  policy  efforts  have  focused  on  solar  PV.  As  shown  by  Garg  and  Jain (2022), Indian solar PV developers have preferred low-cost imports to domestic products, and solar manufacturers pay higher interest rates than project developers. India's solar manufacturing thus lags global technology development by three to five years. The cost of capital and electricity renders domestic production uncompetitive with China. The country continues to rely heavily on not only cell and module imports, but also imports of materials like glass, encapsulant film, backsheets and aluminium framing, as well as the machinery needed for cell  and  module  production.  This  renders  the  country  vulnerable  to  supply chain disruptions and price fluctuations, as experienced in 2020-2021 (Gulia et al. , 2023).

The Indian government has taken several actions to address this situation. Besides tariffs (a basic customs duty, BCD), non-tariff import restrictions (the Approved List of Models and

<!-- image -->

<!-- image -->

Manufacturers, ALMM) and domestic content requirements, it implemented a productionlinked incentive (PLI) scheme for solar PV manufacturing in April 2021 (Gulia et al. , 2023).

The BCD is imposed on module imports (40%) and cell imports (25%). Meanwhile, Indian module manufacturers rely heavily on imported cells, eventually paying hefty BCD fees. The ALMM lists over 70 approved domestic manufacturers. However, in March 2023, the government decided to defer its implementation until 2024 when the limited availability of high-quality, high-wattage modules from domestic firms added substantial delays in the completion of solar projects. The PLI provides some USD 2.26 billion in funds to stimulate domestic manufacturing. It triggered a doubling in nameplate capacity for PV modules in 2022-2023, to 38 GW. While only 50-60% of this is presently operational, capacity is expected to expand further to 110 GW by 2026. Cell, ingot/wafer and polysilicon production capacity, however, remains marginal or non-existent (Gulia et al. , 2023), with module and cell production being the focus of PLI funding (Yu and Dong, 2023).

An estimated 41/thinspace200 jobs in plant operation - on average, some 1/thinspace050 jobs per gigawatt - could be created if the government's plan to expand solar PV manufacturing capacity succeeds. 24  However, there has to be a skill-building strategy to address the lack of people with know-how of installing, commissioning and operating such plants (Gulia et al. , 2023).

In  June 2023, news media reported on a draft proposal for a new PLI incentive, which will offer INR 216 billion (USD 2.63 billion) 25 in subsidies over 2023-2030. The scheme will target companies establishing manufacturing capacity of 50 gigawatt hours of battery energy storage systems for the power grid, and it is hoped that the subsidies will reduce import dependence. The proposed plan mandates the domestic generation of at least 90% of the value (Parkin, 2023).

In the United States , the August 2022 Inflation Reduction Act (IRA) provides significant incentives for renewables, including domestic manufacturing. Existing tax credits for solar and wind were extended to 2024 (GWEC, 2023), after which they will be replaced with a Clean Electricity Investment Credit (funded to the tune of USD 50.9 billion until 2031) and a Clean Electricity Production Credit (USD 11.2 billion) for specified renewable energy and storage technologies. The objective will be to reduce annual greenhouse gas emissions from power generation to 75% of 2022 levels. An Advanced Manufacturing Production Credit (USD 30.6 billion) is available for the domestic production of solar and wind energy components, inverters, battery components and critical minerals (Bhutada, 2023).

To qualify for a 'domestic content bonus' payment, at least 40% of the overall mining, production or manufacturing cost of all products in land-based clean energy projects or facilities as well as their components must originate in the United States (a lower threshold of  20%  applies  to  offshore  wind  projects).  This  threshold  would  increase  to  55%  after 2025. Iron and steel used in projects must be manufactured entirely in the United States. Importantly, the IRA also imposes wage and apprenticeship requirements as conditions

24   This entails 3/thinspace200 polysilicon-related jobs (16 GW), 10/thinspace875 ingot/wafer-related jobs (29 GW), 6/thinspace825 jobs in cell production (55 GW) and 20/thinspace300 jobs in module assembly (58 GW) (Garg and Jain, 2022).

25 Average exchange rate of USD 1 = INR 82.18 in June 2023.

<!-- image -->

<!-- image -->

<!-- image -->

for  some of the incentives (White House, 2023). For a company undertaking a project larger than 1 MW to receive the full 30% investment or production tax credit, it must pay construction labourers either at or above the local prevailing wage. And with a view to promote workforce development, it mandates qualified apprentices to account for 12.5% of work hours in 2023 (increasing to 15% from 2024) (IREC, 2023).

The  IRA  triggered  announcements  of  16  new  or  expanded  wind  power  manufacturing facilities,  18  new  solar  manufacturing  facilities  and  8  new  grid-scale  battery  storage manufacturing  facilities,  with  a  potential  of  nearly  14/thinspace000  manufacturing  jobs  (GWEC, 2023).  In  solar  PV,  52  GW  of  new  module  manufacturing  capacity  (9  GW  currently  in place) and 20 GW of cell capacity (none existing at present) have been announced since the passage of the IRA but will not be fully operational until 2025 or 2026 (Martinez and Chopra, 2023).

While Europe has  a  strong  industrial  base  for  wind,  the  continent  has  very  limited  PV manufacturing capacity, which is falling far short of the annual demand. The European Union had 19 GW of polysilicon manufacturing capacity, 5 GW of module manufacturing capacity and 1-2 GW of wafer and cell manufacturing capacity in 2022 (Yu and Dong, 2023).

In March 2023, the European Commission proposed a Green Deal Industrial Plan. This was motivated by China's dominant position in solar PV manufacturing and in minerals critical to the energy transition, as well as by initial concerns that subsidies offered by the US IRA may discriminate against foreign companies and would draw renewable energy and electric vehicle manufacturers across the Atlantic (Chazan, 2023). The Commission's objective is to scale up clean technology manufacturing in the European Union, so that the related 26 manufacturing capacity approaches or is able to fulfil 40% of the deployment needs by 2030. One key measure is a streamlining of regulations to speed up project permitting. Another measure is a relaxation of strict rules governing state aid for capital investments in low-carbon projects (Carbon Brief, 2023).

- 26   The Commission's list of eight 'strategic net-zero technologies' includes solar power and solar thermal, onshore and offshore wind power, batteries and energy storage, heat pumps and geothermal energy, electrolysers and fuel cells, sustainable biogas/biomethane, carbon capture and storage, and grid technologies.

A proposed Net-Zero Industry Act sets non-binding manufacturing capacity targets and requires member states to apply non-price criteria (environmental sustainability, energy system integration and supply chain resilience) to auction procurement mechanisms. 27 The Net-Zero Industry Act also includes measures to build a skilled workforce (European Commission, 2023a). A Critical  Raw  Materials  Act  aims  to  increase  the  EU's  capacity for domestic sourcing and refinement of such materials, diversify imports and increase the 'circularity and sustainability' of raw material use. It aims to speed up permitting processes  and  meet  a  quarter  of  the  European  demand  for  strategic  raw  materials through domestic mining (10%, up from 3% at present) and recycling (15%) (BourgeryGonse, 2023). Meeting these targets will not be easy and may clash with environmental protection objectives (Noyan, 2023). A European Critical Raw Materials Board would be established as a new central purchasing agency (European Commission, 2023b).

In September 2022, Germany's Ministry for Economic Affairs and Climate Action (BMWK, 2022)  proposed  creating  a  European  Platform  for  Transformational  Technologies  'to develop  and  promote  the  EU's  industrial  production  capacities  in  five  strategically important technologies - wind energy, solar PV, electrolysers, electricity grids and cables, and heat pumps - large and small' (Taiyang News, 2022). Further, the ministry decided to fund a study on the feasibility of restoring a complete solar PV supply chain in Europe, including materials, manufacturing, research and development, and a workforce with the requisite skill sets (Hutchins, 2023).

In South Africa , the government responded to the high import reliance by releasing a draft South African Renewable Energy Masterplan (SAREM) for public comment in mid-2023. The Masterplan, which is based on a collaboration among government, industry and labour, seeks to foster industrial development and job creation through value chain localisation for solar, wind and battery storage technologies. SAREM acknowledges that prior efforts to build industrial capabilities for renewable energy have so far yielded mixed results due to stop-start procurement cycles, local content rules that were not well aligned with realities, and inconsistent policies.

Industrial  policy  measures  proposed  under  SAREM  include  financial  and  non-financial interventions to support the growth of black-owned and black-managed businesses (Black Industrialist  Programme);  preferential-rate  loans  to  support  domestic  manufacturers (Manufacturing  Competitiveness  Enhancement  Programme);  and  local  development finance  institutions' support  in  enhancing  industrial  capabilities  and  stimulation  of investment through efforts to reduce infrastructure costs (Critical Infrastructure Programme) (DTIC, 2023).

27 In January 2022, new 'State Aid Guidelines for Climate, Energy and Environment' had already allowed governments to include up to 30% non-price criteria in selecting winning auction bids. The proposed act now defines these criteria (GWEC, 2023).

<!-- image -->

<!-- image -->

<!-- image -->

## 3.3   CRITICAL MATERIALS, ECONOMIC DEVELOPMENT AND COMMUNITY RIGHTS

Besides building or strengthening industrial capacity, policies also highlight the 'critical materials'  needed  to  produce  solar  panels,  wind  turbines  and  other  energy  transition technologies. Countries strive to secure access to supplies as they increasingly compete to gain an advantage in the race towards building cleaner energy economies (IRENA, 2023e). As highlighted by a recent Financial Times report, this represents a sharp turnaround: 'For decades,  developed  economies  shunned  these  sorts  of  industrial  activities,  content  to offshore the environmental damage to the developing world where costs would also be lower' (White, 2023).

However,  this  new  race  for  resources  may  not  offer  much  in  the  way  of  lasting socioeconomic benefits for resource-rich countries in Africa, Asia and Latin America. At present, many do not possess the capacity to refine raw materials into processed inputs. The risk is  that  they  will  once  more  be  relegated  to  the  role  of  commodity  suppliers, dependent on unpredictable commodity markets for price setting and unable to create jobs and value further downstream. There also need to be safeguards to ensure that the race for materials does not translate into a race to the bottom, in terms of environmental degradation and burdens imposed on workers and local communities.

In  January  2023,  several  organisations  jointly  launched  an  Africa  Renewable  Energy Manufacturing  Initiative  to  scale  up  manufacturing  capabilities  on  the  continent  and create substantial employment. Doing so would require sustained efforts in skill training and  career  development  for  engineers,  technicians  and  others,  besides  measures to  attract  manufacturers  and  incubate  African  manufacturing  projects  (Bloomberg Philanthropies, 2023).

A related report by Sustainable Energy for All (SEforALL, 2023) identifies countries with the highest feasibility for such an approach. The report suggests that among the key success factors are sufficient demand, manufacturing scale, political stability, appropriate policies and regulations, trade relations with China (as the leading force in the sector and with strong foreign direct investment in the region), supporting infrastructure and the ability to

export. The African Development Bank has launched an 'Industrialise Africa' initiative to support such efforts, providing USD 300 million in financing (SEforALL, 2023).

A  number  of  resource-rich  countries  are  seeking  to  exert  greater  control  over minerals  critical  to  the  energy  transition.  The  objective  is  to  retain  a  higher  share  of the  socioeconomic  benefits  and  avoid  becoming  locked  into  the  role  of  raw  material suppliers. According to an analysis of the Organisation for Economic Co-operation and Development (OECD, 2023), the number of export restrictions on critical raw materials worldwide grew fivefold since 2009.

The Plurinational State of Bolivia and Mexico have nationalised their lithium industries, while Zimbabwe introduced  a  ban  on  raw  lithium  exports  (Stott  and  Bryan,  2023). Indonesia has  since  2014  banned  exports  of  unprocessed nickel ore and succeeded in attracting foreign direct investment for building a domestic smelting industry. The country also restricted exports of bauxite, an aluminium precursor, and a ban on copper concentrate exports is to take effect in 2024 (Hook, Dempsey and Nugent, 2023). Indonesia and the Democratic Republic of Congo have also adopted export restrictions on materials used in  lithium-ion  batteries  (Crooks,  2023).  In  the  Democratic  Republic of Congo, a second copper smelter is under construction (Hook, Dempsey and Nugent, 2023).

In early 2023, Chile's government announced plans - subject to Congressional approval -  to  negotiate  a  majority  stake  in  the  country's  two  existing  lithium  projects.  The negotiation is to be through the state-owned companies Codelco and Enami initially and later through a proposed national lithium company. Policy objectives include developing local value chains, increasing wealth retained within the country and establishing stricter environmental  rules  concerning  the  water-intensive  process  needed  to  extract  lithium from salt flats.  The  environmental rules are to be established in consultation with local communities (Government of Chile, 2023). Chile is offering preferential prices for lithium carbonate to firms investing in domestic value-added projects. Examples of such firms include China's BYD, which plans to build a lithium cathode factory that could employ 500 people (Hook, Dempsey and Nugent, 2023).

In  June  2023, Namibia decided  to  ban  the  export  of  unprocessed  materials  including lithium, cobalt, manganese, graphite and rare earths such as dysprosium and terbium in order to retain a greater share of the wealth generated from their use (Reuters, 2023).

While  stepping  out  of  a  raw  material  supplier  role  can  support  a  country's  national economic  development,  it  requires  more  than  industrial  policy  to  ensure  equitable outcomes from this role transition. For example, as noted by the Business &amp; Human Rights Resource Centre (Pouhe and Gwanyanya, 2023), violations of communities' land rights and livelihoods (including lack of consultation, evictions, unjust resettlements and inadequate compensation), as well as abuses of labour rights and human rights violations, have been recorded  around  several  transition  mineral  mining  projects  as  well  as  some  renewable energy installations. Further, local protests and lawsuits have led to some planned projects being  suspended.  Meanwhile,  better  approaches  and  business  models  are  beginning to  emerge.  Pouhe and Gwanyanya (2023) argue in favour of three core principles: coownership models that generate buy-in from workers and communities; human rights due diligence and social protection, with an emphasis on worker (re-)training and decent work; and  free,  prior  and  informed  consent  in  negotiations  with  local  populations,  especially indigenous communities.

<!-- image -->

## CHAPTER 4

## PERSPECTIVES AND ACTIONS FOR A JUST TRANSITION

Previous editions of this report have emphasised that job quality matters just as much as  job  quantity,  and  that  the  transition  from  a  fossil-fuel-dominated  energy  sector to  a  cleaner  energy  future  needs  to  be  just  and  inclusive  in  relation  to  workers  and communities. This outcome requires not only foresight and comprehensive policies, but also meaningful social dialogue involving governments, private companies and business associations, labour unions and other stakeholders.

Based on its tripartite structure involving governments, businesses and organised labour, in 2015 the International Labour Organization developed guidelines for a just transition (ILO, 2015). At the June 2023 International Labour Conference, tripartite representatives reaffirmed the urgency of action to advance a just transition to achieve social justice, decent  work  and  poverty  eradication,  and  tackle  environmental  and  climate  change. The conference declared that 'A just transition promotes environmentally sustainable economies in a way that is inclusive, by creating decent work opportunities, reducing inequality and by leaving no one behind' (ILO, 2023).

To accelerate and scale up the implementation of the 2015 guidelines, the International Labour Conference elaborated a coherent and practical framework for action based on four  building  blocks:  (1)  promoting  inclusive,  sustainable  and  job-rich  economies;  (2) advancing social justice; (3) managing the just transition process and (4) financing a just transition (see Figure 14).

This section discusses perspectives and actions by the tripartite stakeholders.

Figure 14 ILO guidelines for a just transition: A framework for action

<!-- image -->

Source: ILO, 2023.

## 4.1 GOVERNMENTS' PERSPECTIVES AND ACTIONS

Several countries have recognised the need for a just energy transition and are leveraging this unique opportunity to rebuild economic structures by generating jobs and income, promoting social justice,  restoring  natural  capital  and  reducing  environmental  impacts. Renewable  energy  investments  create  jobs  in  equipment  manufacturing,  installations, and  operation  and  maintenance,  while  energy  efficiency  programmes  for  buildings, transportation and industries create jobs in areas such as energy auditing, retrofitting and the manufacturing of energy-efficient technologies. A number of actions can ensure that the transition to a clean energy future is jobs rich and just (see Box 5).

<!-- image -->

## Box 5

## Policy elements to ensure plentiful, decent jobs

1 2

3

5 4

6

Workforce training and education initiatives to equip workers with the skills needed for renewable energy jobs.

Just transition policies to support workers and communities affected by the clean energy transition through retraining assistance, income support and job placement assistance, as well as assistance with infrastructure development, community projects and economic diversification efforts.

Engagement  with  labour  unions,  industry  stakeholders  and  community organisations  to  develop  collaborative  strategies  to  ensure  that  workers' concerns and interests are accounted for while planning and implementing clean energy initiatives.

Green job creation targets for a clear focus on employment generation and drive policy efforts to achieve those targets.

Local and  regional economic  development  initiatives  to promote  the establishment of renewable energy industries, attract clean energy investment and foster innovation in clean technologies.

Inclusive decision-making processes with inputs from diverse stakeholders to address the needs and perspectives of different communities and promote social equity.

7

Support for small and medium enterprises as job creators through financial incentives, capacity-building programmes and procurement policies.

<!-- image -->

<!-- image -->

<!-- image -->

For example, the governments of South Africa and Spain have adopted several policies in this vein. The South African government, after submitting its Nationally Determined Contribution  towards  achieving  the  Paris  Agreement's  goals  in  2021,  launched  the Just Energy Transition Investment Plan (JET IP), which is to be implemented between 2023  and  2027.  This  plan  outlines  a  USD  98  billion  investment  in  renewable  energy, electric vehicles and green hydrogen, and includes provisions for social and economic development  such  as  job  creation,  skill  development  and  community  empowerment. While the government's policy on just energy transition is still evolving, it nevertheless reflects the government's determination to diversify its energy mix and ensure that the transition to a low-carbon economy contributes to its efforts to tackle inequality, poverty and unemployment (ITJ, 2022).

It  is  crucial  to  recognise, however, that relying exclusively on funding from the JET IP will fall short of fulfilling the investment needs for a fair transition towards sustainable energy for each recipient. South Africa's JET IP agreement will contribute less than 10%, totalling USD 8.5 billion, in funding. Further, a mere 0.4% of the overall planned amount under South Africa's JET IP will be allocated to boost economic diversification, innovation and skill development. Grants constitute just 4% of the total JET IP funding package, exposing South Africa to risks related to privatisation, which could also be applicable to other beneficiary nations (Gunfaus et al. , 2022; IRENA and CPI, 2023).

The Spanish government has introduced a set of policies to optimise economic activity and  employment  prospects  in  the  transition  to  a  green,  low-carbon  economy,  while minimising potential negative social and economic impacts. Known as the Spanish Just Transition Strategy, these policies encompass core objectives, which include boosting competitiveness and addressing social cohesion challenges arising from the economic transition towards ecological sustainability. Opportunities are intended to be accessible and equitable for women, vulnerable populations and rural residents, and labour market status and trends with respect to the green transition are closely monitored. Further, the strategy promotes the establishment of sectoral forums to facilitate collaboration and knowledge sharing. Specific plans for key economic sectors entail thorough analyses of challenges, opportunities and threats, and the formulation of necessary measures for a successful transformation.

The  strategy  also  entails  an  evaluation  and  enhancement  of  the  current  tools  and instruments  provided  by  the  General  State  Administration  to  support  businesses. This support includes, among other factors, provisions for research and development, financing, loans, guarantees and training. Further, the Spanish Just Transition Strategy proposes  suitable  policies  to  support  co-ordinated  efforts  among  various  entities, including the General State Administration, autonomous communities, local authorities and  social  stakeholders.  These  policies  encompass  industrial  support,  research  and development,  promotion  of  economic  activity,  employment  and  vocational  training. Lastly, the strategy focuses on minimising adverse impacts in vulnerable regions through the implementation of Just Transition Agreements. It provides technical and financial support for the execution of these agreements, as demonstrated by the Urgent Action Plan, which targets regions that confront closure of coal mining and coal-fired power plants (ITJ, 2022).

<!-- image -->

To be effectively implemented, policies will have to be well co-ordinated, include all relevant stakeholders  and  be  adequately  financed.  Managing  the  transition  process  will  require coherence across policy areas and effective institutional co-ordination to plan and implement changes in accordance with evidence-based monitoring and evaluation frameworks.

Achieving a just transition requires determined policy action that puts a human face on policies and integrates climate and employment targets into a coherent policy framework. A well-designed and progressive climate environmental policy could be beneficial for employment and equity targets. A transition towards climate neutrality can generate net employment, although this varies significantly across sectors.

## 4.2 EMPLOYER PERSPECTIVES AND ACTIONS

Employer  and  business  membership  organisations  play  a  crucial  role  in  driving the  renewable  energy  transition  by  advocating  for  supportive  policies,  promoting investment in clean technologies, and facilitating partnerships between businesses and governments. These organisations understand that a renewable energy transition can create new business opportunities, drive innovation and support economic growth.

For example, the United States Council for International Business participates in international forums such as the United Nations Framework Convention on Climate Change and represents business interests in global climate discussions. The Council launched the initiative Business for  2030  (n.d.)  in  2015  to  support  the  2030  Development  Agenda  and  the  Sustainable Development  Goals  (SDGs).  Business  for  2030  is  a  platform  to  showcase  private  sector efforts aligned with the SDGs, and features over 200 projects of over 50 companies in more than 150 countries. These projects contribute to 89 of the 169 SDG targets.

In  the  United  Kingdom,  the  Confederation  of  British  Industry  has  published  reports and policy recommendations highlighting renewable energy's economic benefits. The Confederation  also  engages  with  the  government  and  stakeholders  to  advocate  for supportive policies and regulatory frameworks. It has created several toolkits including best practices and practical information for its member companies. The toolkits cover topics like 'how to create a culture of sustainability in your business' (CBI, 2023) and 'how your business can take action and seize net zero opportunities' (CBI, 2022).

The  National  Business  Association  of  Colombia  (Asociación  Nacional  de  Empresarios  de Colombia, ANDI) collaborates with government agencies, industry stakeholders and civil society to develop strategies that support renewable energy adoption and provides businesses with guidance and resources related to sustainable practices and clean energy adoption. In 2014, it launched the Biodiversity and Development Initiative, which aims for greater comprehensive biodiversity management in the country through fostering collaboration among businesses, institutions and local groups as well as investment (ANDI, 2023).

In  South  Africa,  the  Business  Unity  South  Africa  (BUSA)  advocates  for  policies  and regulations supporting the growth of renewable energy sectors. BUSA also collaborates with industry stakeholders to develop skill training programmes and promote job creation in  renewable  energy.  In  the  domain  of  sustainable  energy  and  infrastructure,  BUSA's

specific objectives include, among others, public consultations for a co-ordinated highlevel road map of all pending energy legislation and policies; finalisation of the Integrated Energy Plan  and  the  Integrated  Resource  Plan  with  planning  transparency;  and  continuing  the Renewable Energy Independent Power Producer Procurement Programme (BUSA, 2023).

The Confederation of Danish Industry (CDI 2016) supports knowledge-sharing platforms and provides resources to help businesses make a renewable energy transition that is fair and inclusive for workers. The CDI actively participated in the negotiations and discussions that led to the 2018 Danish Energy Agreement, which outlines the country's energy and climate  goals,  including  a  commitment  to  transitioning  to  renewable  energy  sources and mitigating greenhouse gas emissions. The CDI was crucial in advocating for policies and incentives that support and encourage clean energy investments and facilitate the transition for businesses and workers.

## 4.3 LABOUR UNION PERSPECTIVES AND ACTIONS

Labour  unions  contend  that  investing  in  clean  energy  transition  technologies  will  not inherently  guarantee  the  creation  and  sustainability  of  good  jobs.  Unions  have  concerns about the progress on a just transition in different countries and the lack of union involvement in the process (IndustriALL Global Union, 2021). While social dialogue experiences vary from country to country, fundamentally, a just transition is possible only with social dialogue and a well-organised workforce. Transitions will be challenging but not impossible, and workers must be assured of a just transition for them, their families and communities.

To gain insights on the future prospects of energy sector workers and address unions' concerns, the IndustriALL Global Union, the International Trade Union Confederation and LO Norway launched the Initiative for a Just Transition in  the  energy  sector  in  2022. The Initiative had 121 participants from unions in 32 countries and involved information exchange regarding the future of work in the energy sector and on ways in which workers could transfer jobs in the oil and gas supply chain to the renewables sector.

<!-- image -->

<!-- image -->

<!-- image -->

Unions and experts shared information on jobs, skills, markets, investments and emissions for technologies such as hydrogen, carbon capture and storage, offshore wind and other renewables, alternative fuels and energy services. A subsequent report (IndustriALL Global Union, International Trade Union Confederation and LO Norway, 2022) offered conclusions and recommendations. A series of ten workshops 28  with experts from the International Renewable Energy Agency and the International Energy Agency, energy sector unions and national labour confederations was held between April and October 2022. The workshops focused on the implications of net zero for energy sector jobs. Participants exchanged information on emerging technologies, what the transition looks like in different parts of the world, as well as union strategies for ensuring good jobs and a just transition.

The US Project Labor Agreement - signed between North America's Building Trades Unions and the Danish offshore wind company Ørsted - is a good example of possibilities for renewables sector workers. The Project Labor Agreement was for Ørsted to construct its  US  offshore  wind  farms  using  a  unionised  workforce.  The  National  Offshore  Wind Agreement covers all Ørsted contractors and subcontractors that will construct offshore windfarms along the Atlantic coast.

The agreement is a commitment to build infrastructure that will reduce carbon emissions and create high-wage union jobs. It can be a model for the entire renewable industry as well as for other emerging technologies, where labour standards and environmental performance go hand in hand and where the goal of green jobs being union jobs becomes real.

According to Ørsted, US offshore wind projects could create some 80/thinspace000 direct jobs plus  many  thousands  of  indirect  jobs  in  manufacturing,  maritime  work,  logistics  and clean energy technology (Ørsted, 2022). The training and other provisions of the Project Labor Agreement will help generate a workforce capable of building complex offshore wind energy infrastructure. Ørsted itself has committed USD 23 million to bolster existing efforts or establish new programmes for preparing US workers for offshore wind.

<!-- image -->

- 28   The workshops covered the following topics and geographies: hydrogen, onshore and offshore wind, battery and solar photovoltaic, carbon capture and storage; Europe and the Americas; and Australia, Indonesia, Iraq, Japan, New Zealand, Nigeria, South Africa and Spain.

## MULTIPLYING CHALLENGES DEMAND NEW

## THE WAY FORWARD: THINKING

This  tenth  edition  of Renewable  energy  and  jobs documents  the  continued  growth of  renewable  energy  employment,  with  job  numbers  estimated  to  have  grown  from 7.3 million in 2012 to 13.7 million in 2022 worldwide. The jobs are predominantly in a few countries - China in particular, but also Brazil, India and the members of the European Union  -  which  represent  the  majority  of  capacity  installations  and  play  key  roles  in equipment manufacturing, as well as engineering and various services. At present, jobs are  unevenly  distributed  between  men  and  women,  and,  as  pointed  out  in  previous editions, the qualitative aspects of renewable energy jobs, including wages, occupational safety and health, job security and rights at work, demand greater attention.

Renewable  energy  investments  have  noticeably  increased  in  volume  in  recent  years. Further accelerating the pace implies that in the coming years and decades, millions of additional jobs will be created. However, this requires a range of accompanying measures, for  example,  increased  efforts  to  expand  education  and  skill-building  programmes; retraining of workers from fossil fuel industries; and greater opportunities for women, youth and minorities to join the renewable energy workforce.

CHAPTER 5

U

<!-- image -->

A

L

V

I

E

UN Secretary-General António Guterres COP 27, 7 November 2022

<!-- image -->

Achieving  the  energy  transition  in  a  manner  that  allows  humanity  to  meet  urgent climate  and  environmental  priorities  will  require  significantly  accelerated  investments and installations. Progress remains highly inadequate. In fact, it is not an exaggeration to  say  that,  for  now,  the  world  is  experiencing  an  energy addition -  with  renewables forming another layer on top of the existing, fossil-fuel-dominated system - rather than the needed energy transition (Hickel, 2022).

A steady stream of fresh scientific  assessments and more frequent extreme weather events  lend  ever-greater  urgency  to  a  fundamental  transformation.  Yet,  geopolitical tensions,  trade  rows  and  supply  chain  disruptions  have  led  governments  to  become increasingly preoccupied with shoring up energy supplies, including the very fossil fuel sources that humanity has pledged to wean itself off.

Corporations and governments continue to look to economic growth as the remedy to many challenges. Yet an ever-expanding economy requires ever greater energy supply, making the transition even more challenging. And there can no longer be any doubt that endless growth is not possible on a planet with finite resources and capacity to absorb carbon and pollutants. The Earth is already sending unmistakable signals of increasing distress.  The  latest  scientific  assessment  of  nine  planetary  boundaries  (Richardson et  al. ,  2023)  finds  that  six  of  them  have  already  been  crossed. 29 Persisting  with  the current approach will worsen the situation, threatening a cascade of rising calamities. A destabilised climate system, widespread biodiversity loss and overburdened terrestrial and marine ecosystems form the greatest threats to humanity's well-being and indeed its long-term survival (Hickel, 2022).

29   In addition to climate change, they concern biosphere integrity, land systems, freshwater, biogeochemical flows, and novel entities. The remaining three boundaries our ocean acidification, atmospheric aerosol loading, and stratospheric ozone depletion. Richardson et al. (2023).

UN Secretary-General

António Guterres

27 July 2023

<!-- image -->

Also, given the wide - and growing - disparities in wealth and human development between and within countries, it is clear that the current economic approach has failed to bring about universal well-being. Studies show that even for those who are materially well off, growth in material consumption past a certain point does not lead to greater happiness and offers diminishing  returns.  But  maintaining  the  current  economic  model  under  conditions  of growing climate and environmental constraints exposes the poorer portions of humanity - principally people in the Global South - to the effects of accelerating resource depletion and renders them increasingly vulnerable to climate shocks.

IRENA's work has long emphasised the importance of ensuring the energy transition delivers  broad  socio-economic  benefits,  so  that  people  can  have  a  tangible  stake  in it,  in  turn  securing  popular  and  political  acceptance.  The  energy  transition  needs  to be  embedded within  broader  systemic  changes  that  aim  to  ensure  a  level  of  human well-being at lower levels of energy and material throughput, advance equity among countries and communities (overcoming historical disparities), and align economies with climate and resource constraints.

Socially,  economically  and  politically,  this  transformation  is  an  unavoidable  yet  most complex  task.  The  increasingly  evident  limits  and  contradictions  of  conventional economics  and  growth-based  paradigms  have  given  rise  to  an  increasingly  vibrant discussion of workable concepts and approaches for a more just and inclusive transition and to allow humanity to live within planetary boundaries. For close to a century, GDP has been the accepted yardstick to measure progress, but it suffers from well-documented shortcomings and pitfalls - for example, the inclusion of activities that do not contribute to well-being while excluding others (such as unpaid work, most often carried out by women) that do. Modifications of the GDP, or full-blown alternatives such as Bhutan's gross national happiness index, may measure the economy and human well-being more accurately and could facilitate a different set of socio-economic policies (Hickel, 2022).

<!-- image -->

<!-- image -->

## We need a renewables revolution, not a self-destructive fossil fuel resurgence.

<!-- image -->

UN Secretary-General António Guterres

06 February 2023

© Loredana Sanguiliano / shutterstock.com

<!-- image -->

Wealthy countries that have consumed the bulk of the world's energy and materials will have to reduce their claim. Greater efficiency can help, but experience shows that the 'rebound effect' - cost reductions from improvements in efficiency allow consumers to buy more of the improved product or increase demand for other products - prevents any lasting reduction of overall consumption volumes.

There is thus a need to scrutinise fundamental production and consumption patterns and make an even stronger distinction between human needs and wants. Doing so could create the space needed by people who currently consume less than what is needed for  sustaining  a  decent  life.  A  less  consumption-intensive  economy  would  imply  a shift in employment away from the extractive sector and manufacturing of disposable goods  towards  recycling,  refurbishing  and  remanufacturing  activities.  Energy  sector employment would be less extensive than under a conventional trajectory. Societies may thus need to explore new approaches - such as the concept of a universal basic income - to make people's incomes less dependent on unsustainable practices.

Humanity faces a broad, and potentially conflicting, set of objectives. For one, there is a clear need for a significantly rapid transition away from fossil fuels, in light of the growing climate crisis. However, renewed concern about energy supply security runs high and, to some extent, may reinforce fossil fuel reliance. Further, hundreds of millions of people need  to  be  provided  improved  energy  access,  to  fulfil  the  promise  of  Sustainable Development Goal 7. This concerns not just a need for more ample supplies but also for  cleaner  energy.  Narrowing the vast chasm in energy consumption levels between rich and poor countries also requires re-thinking the excessive energy use in consumer societies. Yet socio-economic inequalities and pockets of energy poverty are growing even within richer societies.

Uncertain  socio-economic  prospects  may  strengthen  the  appeal  of  political  forces that favour parochial approaches, in turn weakening global solidarity and diminishing prospects for cooperation in pursuit of shared goals. It is critical to ensure not only that fossil fuel-reliant workers and communities have a viable perspective in a new energy system, but also that women, youth, minorities and marginalised groups are given equal

<!-- image -->

opportunities. Last but not least, the energy transition itself must proceed in a manner that safeguards ecosystems, a concern that ranges from the mining and processing of critical raw materials all the way to how renewable energy equipment is handled at the end of its useful life. Yet, the growing urgency of the energy transition could translate into  tremendous pressure to extract energy transition minerals as quickly as possible while sidelining environmental concerns and local community interests.

This panoply of goals and interests may be difficult to reconcile, especially in a context of growing geopolitical rivalry that renders global co-operation more difficult. It is a task that cannot be left to markets if just, inclusive and sustainable outcomes are to be more than a slogan. Priorities must be determined in open debate and policy decisions must be  guided  by  social  dialogue.  Governments  and  other  stakeholders  will  have  to  play a  proactive  role  in  transforming  economic  systems,  reinforcing  an  argument  that  has underpinned IRENA's staple of socio-economic reports: policy making must be inspired by a holistic framework that considers technological aspects in conjunction with social, economic and environmental priorities (see Figure 15).

Figure 15 Holistic policy framework for a just and inclusive energy transition

Source: IRENA, 2022b.

<!-- image -->

<!-- image -->

## References

ABEEÓLICA (2023), 'InfoWind Brazil', InfoWind no. 30, Associação Brasileira de Energia Eólica, 23 February, https:// abeeolica.org.br/energia-eolica/dados-abeeolica/.

ABRASOL (2023), 'Produção e Vendas de Sistemas de Aquecimento Solar: Base 2022' [Production and Sales of Solar Heating Systems: Base year 2022], Associação Brasileira de Energia Solar Térmica, https://abrasol.org.br/wpcontent/uploads/2023/04/ Pesquisa-de-Producao-e-Vendas-de-2023-ano-base-2022.pdf.

ABSOLAR (2023), 'Solar PV energy benefits to Brazil', infographic, Associação Brasileira de Energia Solar Fotovoltaica, 2 May, www.absolar.org.br/en/market/infographic/.

AMDEE (2022), 'Wind development in Mexico has an important local and regional economic footprint', Asociación Mexicana de Energía Eólica, May, https://amdee.org/el-viento-ennumeros.html.

American Clean Power (2023), Clean Energy Investing in America , American Clean Power Association, Washington, DC, August 2023, https://cleanpower.org/wpcontent/uploads/2023/08/CleanEnergy InvestingReport\_digital.pdf.

ANDI (2023), 'Temas Ambientales 2023' [Environmental Issues 2023], Asociación Nacional de Empresarios de Colombia, www.andi.com.co/Home/Pagina/1053-temas-ambientales-2023# biodiversidadydesarrollo.

APPA (2022), 'Avance del estudio del impacto macroeconómico de las energías renovables en España 2021' [Progress of the study of the macroeconomic impact of renewable energies in Spain 2021], Asociación de Empresas de Energías Renovables, Madrid, www. appa.es/wpcontent/uploads/2022/11/Avance\_Estudio\_Impacto\_ Macroeconomico\_Renovable\_2021.pdf.

Barnard, M. (2023), 'China's purchasing power advantage &amp; Wright's Law mean its green investments go a lot further,' Clean Technica , 30 January, https://cleantechnicacom.cdn.ampproject.org/c/s/ cleantechnica.com/2023/01/30/chinas-purchasing-power-advantage wrights-law-mean-its-green-investments-go-a-lot-further/amp/.

Bhutada, G. (2023), 'Breaking down clean energy funding in the Inflation Reduction Act', Decarbonization Channel, 21 February, https://decarbonization.visualcapitalist.com/breakingdown-cleanenergy-funding-in-the-inflation-reduction-act/.

Bloomberg Philanthropies (2023), 'New Africa Renewable Energy Manufacturing Initiative will help unleash 1.2 terawatts of renewable energy, create up to 14 million jobs, and increase GDP by over six percent by 2050', press release, 17 January, www.bloomberg.org/ press/new-africarenewable-energy-manufacturing-initiative-willhelp-unleash-1-2-terawatts-of-renewableenergy-create-up-to-14million-jobs-and-increase-gdp-by-over-six-percent-by-2050/.

BLS (2023a), 'Occupational outlook handbook: Electricians', Bureau of Labor Statistics, www.bls.gov/ooh/construction-andextraction/electricians.htm.

BLS (2023b), 'Labor force statistics from the current population survey', Bureau of Labor Statistics, www.bls.gov/cps/cpsaat11.htm.

BMWK (2022), 'Initiative zur Einrichtung einer 'Europäischen Plattform für Transformationstechnologien'' [Initiative to establish a European Platform for transition technologies],, Bundesministerium für Wirtschaft und Klimaschutz, www. bmwk.de/Redaktion/DE/Downloads/B/backgroundpapereuropean-plattfom-fortransformation-technologies. pdf?\_\_blob=publicationFile&amp;v=8.

Bourgery-Gonse, T. (2023), 'EU unveils Critical Raw Materials Act, aiming to lessen dependence on China', Euractiv , 16 March, www. euractiv.com/section/economy-jobs/news/euunveils-critical-rawmaterials-act-aiming-to-lessen-dependence-on-china/.

Briggs, C. and R. Langdon (2022), 'To hit 82% renewables in 8 years, we need skilled workers - and labour markets are already overstretched', The Conversation , 17 August, https:// theconversation.com/to-hit-82-renewables-in-8-yearswe-need-skilled-workers-andlabour-markets-are-alreadyoverstretched-188811.

BSW (2023), 'Statistische Zahlen der deutschen Solarstrom  branche (Photovoltaik)' [Statistical figures from the German solar power industry (photovoltaics)], Bundesverband Solarwirtschaft, Berlin, May, www.solarwirtschaft.de/datawall/uploads/2022/02/ bsw\_faktenblatt\_photovoltaik.pdf.

BUSA (2023), 'Affordable, reliable and sustainable energy and infrastructure (technology, water and road transportation) to meet current and future needs', Business Unity South Africa, www. busa.org.za/4-affordable-reliable-and-sustainable-energy-andinfrastructure-technologywater-and-road-transportation-to-meetcurrent-and-future-needs/.

Business for 2030 (n.d.), 'Our impact', www.businessfor2030. org/progress.

Carbon Brief (2023), 'Q&amp;A: How the EU wants to race to net-zero with 'Green Deal Industrial Plan'', 17 March, www.carbonbrief. org/qa-how-the-eu-wants-to-race-to-net-zero-with-greendealindustrial-plan/.

CBI (2023), 'Toolkit: How to create a culture of sustainability in your business', Confederation of British Industry, 20 March, www.cbi.org.uk/articles/toolkit-how-to-create-a-culture-ofsustainability-in-your-business/.

CBI (2022), 'Toolkit: How your business can take action and seize net zero opportunities', Confederation of British Industry, 22 June, www.cbi.org.uk/articles/toolkit-how-your-businesscan-takeaction-and-seize-net-zero-opportunities/.

CDI (2016), The Global Goals and Opportunities for Business , Confederation of Danish Industry, Copenhagen, Denmark, www. danskindustri.dk/DownloadDocument?id=90486&amp;docid=90565.

CEEW, NRDC India and SCGJ (2023), 'India's expanding clean energy workforce: 2022 update', Council on Energy, Environment and Water; Natural Resources Defense Council India and Skill Council for Green Jobs, February, www.indiaenvironmentportal. org.in/files/file/renewable%20energy%20employment%20 jobs%202023.pdf.

Chazan, G. (2023), 'France and Germany claim assurances from US over green subsidies', Financial Times , 8 February (requires subscription).

Chen, R. (2023), 'China's module exports hit high in 2022', InfoLink Consulting, 3 February, https://infolink-group.com/energy-article/ solar-topic-Chinas-module-exports-hit-high-in-2022.

CHPA (2023), 中国热泵产业发展报告 2023 [China heat pump industry report], China Heat Pump Alliance, Beijing.

Clean Energy Council (2023), Clean Energy Australia Report 2023 , Clean Energy Council, Melbourne, Australia, https://assets. cleanenergycouncil.org.au/documents/Clean-Energy-AustraliaReport-2023.pdf.

CRES (2023), 'Communication with experts', China Renewable Energy Society, Beijing, May.

Crooks, E. (2023), 'The limits to resource nationalism for lithium', Wood Mackenzie blog, 12 May, www.woodmac.com/news/opinion/ limits-to-resource-nationalism-lithium/.

Da Cunha, M. P., J.J.M. Guilhoto and A.C. Da Silva Walter (2014), 'Socioeconomic and environmental assessment of biodiesel production in Brazil', 22nd International Input-Output Conference, Lisbon , Portugal, 14-18 July, www.iioa.org/conferences/22nd/ papers/files/1771\_20140512071\_Paper\_Cunha\_Guilhoto\_Walter.pdf.

David, A. (2021), 'The evolution of global onshore wind turbine blade production and trade', US International Trade Commission, Executive Briefings on Trade, May, www.usitc.gov/ publications/332/executive\_briefings/ebotthe\_evolution\_of\_ global\_onshore\_wind\_turbine\_blade\_production\_and\_trade.pdf.

Department of Climate Change, Energy, the Environment and Water (2023), The Australian Energy Employment Report , Department of Climate Change, Energy, the Environment and Water, Canberra, www.energy.gov.au/government-priorities/ energy-workforce/australian-energyemployment-report.

Diao, C., X. Li and Y. Wang (2022), 'A window of opportunity for the Chinese offshore wind supply chain', Wood Mackenzie, November (requires subscription).

DTIC (2023), 'South African Renewable Energy Masterplan (SAREM): An industrial and inclusive development plan for the renewable energy and storage value chains by 2030', draft version for public consultation, Department of Trade, Industry and Competition, Republic of South Africa, 7 July, www.dmr.gov.za/ Portals/0/Resources/Renewable%20Energy%20Masterplan%20 (SAREM)/South%20African%20Renewable%20Energy%20 Masterplan%20(SAREM)%20Draft%20III.pdf.

Energy and Natural Resources Canada (2023), 'Communication with experts', 26 August.

EurObserv'ER (2023), The State of Renewable Energies in Europe: 2022 Edition , EurObserv'ER, Paris.

European Commission (2023a), 'Net-Zero Industry Act: Making the EU the home of clean technologies manufacturing and green jobs', press release, 16 March, https://ec.europa.eu/commission/ presscorner/detail/en/ip\_23\_1665.

European Commission (2023b), 'Critical raw materials: Ensuring secure and sustainable supply chains for EU's green and digital future', press release, 16 March, https://ec.europa.eu/commission/ presscorner/detail/en/ip\_23\_1661.

European Commission (2022a), 'Commission kicks off work on a European Solar Photovoltaic Industry Alliance', news article, 11 October, https://ec.europa.eu/info/news/commission-kicksworkeuropean-solar-photovoltaic-industry-alliance-2022-oct-11\_en.

European Commission (2022b), 'Launch of the European Solar PV Industry Alliance', news article, 16 November, https://single-market-economy.ec.europa.eu/news/ launch-european-solarpv-industry-alliance-2022-11-16\_en.

FBICRC (2021), Future Charge: Building Australia's Battery Industries: Final Report , Future Battery Industries Cooperative Research Centre, Bentley, Australia, https://fbicrc.com.au/ wpcontent/uploads/2021/06/Future-Charge-Report-Final.pdf.

FEE and Capgemini Invent (2022), 2022 Wind Observatory , France Énergie Éolienne and Capgemini Invent, Paris, September, https://fee.asso.fr/wpcontent/uploads/2023/01/ Observatoiredelolien2022-VENG23.pdf.

Fuhs, M. and S. Enkhardt (2023), '11 bis 15 Milliarden Euro Unterstützung für Ausbau europäischer Photovoltaik- Industrie nötig' [11 to 15 billion euros in support needed for the expansion of the European photovoltaic industry], PV Magazine Deutschland , 3 March, www.pvmagazine.de/2023/03/03/11-bis-15-milliardeneuro-unterstuetzung-fuer-ausbau-europaeischer-photovoltaikindustrie-noetig/.

Garg, S. and R. Jain (2022), Making India a Leader in Solar Manufacturing: Ways to Achieve Technology Leadership and Global Competitiveness , Council on Energy, Environment and Water, New Delhi, www.ceew.in/cef/solutions-factory/publications/CEEWMaking-India-a-Leader-in-Solar-Manufacturing.pdf.

Gifford, J. (2023), 'Weekend read: A manufacturing bridge between Europe and Asia', PV Magazine , 13 May, www. pv-magazine.com/2023/05/13/weekend-read-a-manufacturingbridge-between-europe-and-asia/.

Government of Chile (2023), 'Estrategia Nacional del Litio', www.gob.cl/litioporchile/.

Gunfaus, M.T. et al. (2022), 'Just Energy Transition Partnerships: Can they really make a difference, and how?', IDDRI blog, 3 November, www.iddri.org/en/publications-and-events/blog-post/ justenergy-transition-partnerships-can-they-really-make.

Greener (2023a), Strategic Market Report: Large-Scale PV Power Plants , Greener, São Paulo, Brazil, www.greener.com.br/estudo/ strategic-report-utility-scale-pv-market-brazil-2023/.

Greener (2023b), Strategic Report: Distributed Generation Brazil , Greener, São Paulo, Brazil, www.greener.com.br/estudo/ strategic-report-distributed-generation-2023/.

Griffith, S., S. Calisch and A. Laskey (2020), Mobilizing for a Zero Carbon America: Jobs, Jobs, Jobs, and More Jobs , Rewiring America, Washington, DC, July, www.rewiringamerica.org/policy/jobs-report.

Groom, N. (2022), 'Exclusive: U.S. blocks more than 1,000 solar shipments over Chinese slave labor concerns', Reuters, 11 November, www.reuters.com/world/china/exclusive-us-blocksmore-than1000-solar-shipments-over-chinese-slave-labor-2022-11-11/.

Gulia, J. et al. (2023), India's Photovoltaic Manufacturing Capacity Set to Surge , Institute for Energy Economics and Financial Analysis and JMK Research and Analytics, April, https://ieefa.org/resources/indias-photovoltaic-manufacturingcapacity-setsurge.

GWEC (2023), Global Wind Report 2023 , Global Wind Energy Council, Brussels, Belgium, https://gwec.net/globalwindreport2023/.

GWEC (2022), Capturing Green Recovery Opportunities from Wind Power in Developing Economies , Global Wind Energy Council, Brussels, Belgium, https://gwec.net/wpcontent/uploads/2022/02/ REPORT\_Capturing-Green-Recovery-Opportunities-from-WindPower-in-Developing-Economies.pdf.

Hickel, J. (2022), Less Is More: How Degrowth Will Save the World , Penguin Books, London.

Hodgson, C. (2023), 'Europe's wind industry flags further weakness in 2023 despite energy demand', Financial Times , 29 January (requires subscription).

Hodgson, C. (2022), 'European wind industry 'struggling' with rising costs', Financial Times , 11 October (requires subscription).

Hook, L., H. Dempsey and C. Nugent (2023), 'The new commodity superpowers', Financial Times , 8 August (requires subscription).

Hutchins, M. (2023), 'Germany launches feasibility study on PV manufacturing', PV Magazine , 28 March, www.pv-magazine.com/ 2023/03/28/germany-launches-feasibility-study-on-pvmanufacturing/.

ILO (2023), Achieving a Just Transition Towards Environmentally Sustainable Economies and Societies for All , Report ILC.111/VI, presented at the International Labour Conference, 111th Session, 2023, International Labour Organization, Geneva, www.ilo.org/ wcmsp5/groups/public/---ed\_norm/---relconf/documents/ meetingdocument/wcms\_876568.pdf.

ILO (2022), Inclusion of lesbian, gay, bisexual, transgender, intersex and queer (LGBTIQ+) persons in the world of work: A learning guide . International Labour Organization, Geneva. www.ilo.org/ wcmsp5/groups/public/---dgreports/- --gender/documents/ publication/wcms\_846108.pdf.

ILO (2015), 'Guidelines for a just transition towards environmentally sustainable economies and societies for all', International Labour Organization, Geneva, www.ilo.org/wcmsp5/ groups/public/@ed\_emp/@emp\_ent/documents/publication/ wcms\_432859.pdf.

IndustriALL Global Union (2021), 'Building union power in the renewables supply chain', Webinar, 9 December, www.industriallunion.org/building-union-power-in-the-renewablessupply-chain.

IndustriALL Global Union, International Trade Union Confederation and LO Norway (2022), 'Just transition and the energy sector: 2022 roundup', https://admin.industriallunion.org/sites/default/files/ uploads/images/FutureOfWork/JustTransition/v7\_final\_report.pdf.

Institut der deutschen Wirtschaft (2022), Energie aus Wind und Sonne Welche Fachkräfte brauchen wir? , Kompetenzzentrum Fachkräftesicherung, Cologne, Germany, November, www.kofa.de.

IPPPP (2023), Independent Power Producers Procurement Programme: An Overview as at 31 March 2023 , Independent Power Producers Office, Centurion, South Africa, www.ippprojects.co.za/ Publications.

IREC (2023), 13th Annual National Solar Jobs Census 2022 , Interstate Renewable Energy Council, Albany, NY, July, https:// irecusa.org/census-executive-summary/.

IRENA (2023a - forthcoming), World Energy Transitions Outlook 2023: 1.5°C Pathway , Volume 2, International Renewable Energy Agency, Abu Dhabi.

IRENA (2023b), Renewable Capacity Statistics 2023 , International Renewable Energy Agency, Abu Dhabi, www.irena.org/ Publications/2023/Mar/Renewable-capacity-statistics-2023.

IRENA (2023c), Leveraging Local Capacity for Small Scale Hydropower , International Renewable Energy Agency, Abu Dhabi.

IRENA (2023d), 'Advancing renewables-based clean cooking solutions', www.irena.org/Events/2023/Apr/Advancing-renewablesbased-clean-cooking-solutions.

IRENA (2023e), Geopolitics of the Energy Transition: Critical Materials , International Renewable Energy Agency, Abu Dhabi, www.irena.org/ Publications/2023/Jul/Geopolitics-of-the-Energy-Transition-CriticalMaterials.

IRENA (2022a), Solar PV: A Gender Perspective , International Renewable Energy Agency, Abu Dhabi, www.irena.org/ publications/2022/Sep/Solar-PV-Gender-Perspective.

<!-- image -->

IRENA (2022b), World Energy Transitions Outlook 2022: 1.5°C Pathway , International Renewable Energy Agency, Abu Dhabi, www.irena.org/ publications/2022/Mar/World-Energy-Transitions-Outlook-2022.

IRENA and CPI (2023), Global Landscape of Renewable Energy Finance 2023 , International Renewable Energy Agency, Abu Dhabi, www.irena.org/Publications/2023/Feb/ Global-landscapeof-renewable-energy-finance-2023.

ITJ (2022), Spain, towards a Just Energy Transition , Instituto para la Transición Justa, Madrid, July, www.transicionjusta.gob.es/ Documents/Noticias/common/220707\_Spain\_JustTransition.pdf.

Johann, D. (2022), 'Communication with Associação Brasileira de Energia Solar Térmica (ABRASOL)', 23 and 27 June.

Joshi, A. (2023), 'China's solar exports jump 80% in 2022 despite new trade barriers', Mercom, 21 February, https://mercomindia. com/chinas-solar-exports-jump-80-2022/.

JPEA (2023), 'Statistics', Japan Photovoltaic Energy Association, www.jpea.gr.jp/enprofile/statistics/.

Kessler, R. (2023), 'Vestas invests $40m in Colorado factories as US onshore wind market poised for 2024 rebound', Recharge , 18 July, www. rechargenews.com/wind/vestas-invests-40m-incolorado-factories-asus-onshore-wind-market-poised-for-2024-rebound/2-1-1488349.

Lamprell (2023), 'Renewables', www.lamprell.com/our-business/ renewables.aspx.

Lee, A. (2022), 'Wind power giant Siemens Gamesa to axe almost 3,000 jobs in turnaround bid', Recharge , 29 September, www. rechargenews.com/wind/wind-power-giant-siemens-gamesatoaxe-almost-3-000-jobs-in-turnaround- bid/2-1-1323294.

Lee, C-J. et al. (2021), 'Powering jobs: The employment footprint of clean cooking solutions in Kenya', Energy, Sustainability and Society , Vol. 11, article 27, https://doi.org/10.1186/ s13705-021-00299-0.

Li, X. (2022), 'China wind power outlook, 2022', Wood Mackenzie, October (requires subscription).

Lico, E. (2022a), Global Wind Supply Chain Trends Series - Article 1: Wind Energy Supply Chain Financial Analysis , Wood Mackenzie, August (requires subscription).

Lico, E. (2022b), Global Wind Supply Chain Trends Series - Article 2: Wind Turbine Blades Supply Chain Trends , Wood Mackenzie, September (requires subscription).

Lico, E. (2022c), Global Wind Supply Chain Trends Series - Article 3: Wind Turbine Tower Supply Chain Trends 2022 , Wood Mackenzie, November (requires subscription).

Lico, E. (2022d), Global Wind Supply Chain Trends Series - Article 4: Wind Turbine Drivetrains and Nacelle Components Supply Chain Trends 2022 , Wood Mackenzie, December (requires subscription).

Martínez, M.I. et al. (2023), El empleo de las mujeres en la transición energética justa en España. Análisis cuantitativo y cualitativo , Fundación Naturgy e Instituto para la Transición Justa [Jobs for women in the just energy transition in Spain: Quantitative and qualitative analyses], Madrid, www.fundacionnaturgy.org/publicacion/ el-empleo-delas-mujeres-en-la-transicion-energetica-justa-enespana/.

Martinez, S.L. and E. Pierce (2023), 'Global solar PV supply chain quarterly briefing: Q1 2023', Wood Mackenzie (requires subscription).

Martinez, S.L. and S. Chopra (2023), 'The long and winding road to US-made solar module procurement', Wood Mackenzie, May (requires subscription).

Mazzucato, M. (2022), 'Industrial strategy demands a new deal with the private sector', Financial Times , 27 November (requires subscription).

Mercantil Environmental (2023), 'Pesquisa de Energia solar térmica explica como a produção de aquecedores solares somou 1,78 milhão de m2 em 2022' [Energy research on solar thermal explains how solar heater production totaled 1.78 million m2 in 2022], 14 April, https://noticias.ambientalmercantil.com/ 2023/04/energia-solar-termica-producao-deaquecedores-solaressomou-178-milhao-de-m2-em-2022/.

Meza, E. (2022), 'Germany's new labour strategy sees skilled workers as crucial for energy transition', Clean Energy Wire , 13 October, www. cleanenergywire.org/news/germanys-new-labour-strategy-seesskilled-workers-crucial-energy-transition.

MTE/RAIS (2023), 'Annual list of social information: Database including active and inactive employments for sugarcane cultivation and alcohol manufacture', in Relação Anual de Informações Sociais (Annual Report of Social Information) , Ministério do Trabalho Emprego, (Ministry of Labour and Employment), Brazil, accessed June 2023.

Nowak, T. and P. Westring (2023), European Heat Pump Market and Statistics Report 2022 , European Heat Pump Association, Brussels.

Noyan, O. (2023), 'Critical Raw Materials Act: Can Europe achieve its ambitious goals?', Euractiv, 17 March, www.euractiv.com/section/ economy-jobs/news/critical-raw-materials-act-can-europe-achieveits-ambitious-goals/.

OECD (2023), 'Supply of critical raw materials risks jeopardising the green transition', Organisation for Economic Co-operation and Development, 11 April, www.oecd.org/newsroom/supply-ofcritical-raw-materials-risks-jeopardising-the-green-transition.htm.

Ørsted (2022), 'North America's building trades unions and Ørsted agree to build an American offshore wind energy industry with American labor', 5 May, www.us.orsted.com/ newsarchive/2022/05/national-offshore-wind-agreement.

OWIC (2023), Offshore Wind Skills Intelligence Report , Offshore Wind Industry Council, June, www.owic.org.uk/\_files/ ugd/1c0521\_94c1d5e74ec14b59afc44cebe2960f62.pdf.

Oyuma, C., A. Game and M. Lieuw-Kie-Song (2023), Employment Impact Assessment of the Green Mini Grid (GMG) Facility, Kenya , International Labour Office, Geneva, www.ilo.org/wcmsp5/groups/ public/---ed\_emp/documents/publication/wcms\_884868.pdf.

Parkin, B. (2023), 'India gears up for multibillion-dollar battery subsidies', Financial Times , 28 June (requires subscription).

Penman, H. (2022), 'Unions left livid after Moray West fabrication work disappears 'into the desert wind'', Energy Voice , 22 March, www.energyvoice.com/renewables-energytransition/wind/ uk-wind/397274/uae-based-lamprell-agrees-major-fabricationcontract-with-moray-west-offshore-wind-farm/.

Platform (2022), 'Potential clean job creation in regions with high oil &amp; gas employment', November, https://platformlondon.org/wpcontent/uploads/2022/10/Regional-Green-Job-Creation-copy.pdf.

Pontecorvo, E. (2023), 'To get off fossil fuels, America is going to need a lot more electricians', Grist , 11 January, https://grist.org/energy/ electrician-shortage-electrify-everything-climate-infrastructure-labor/.

Pouhe, S. and M. Gwanyanya (2023), 'Fast and fair: Achieving a just energy transition in Africa', Business &amp; Human Rights Resource Centre, June, www.businesshumanrights.org/en/from-us/briefings/ fast-and-fair-achieving-a-just-energy-transition-in-africa/.

Preston, C. (2021), 'The jobs where sexual harassment and discrimination never stopped', The Hechinger Report , 31 January, https://hechingerreport.org/the-jobs-where-harassment-anddiscrimination-never-stopped/.

Reed, S. (2022), 'Europe's wind industry is stumbling when it's needed most', New York Times , 22 November, www.nytimes. com/2022/11/22/business/wind-power-europe.html.

Ren, Y. and C. Diao (2022), 'Looking west: Overseas expansion of Chinese wind companies', Wood Mackenzie, November (requires subscription).

REN21 (2023), Renewables 2023: Global Status Report , REN21 Secretariat, Paris, www.ren21.net/wp-content/uploads/2019/05/ GSR-2023\_Energy-Supply-Module.pdf.

Renewable Energy Institute (2022), Socioeconomic Analysis of Offshore Wind Power Development in Japan , Renewable Energy Institute, Tokyo, Japan, December, www.renewableei.org/ pdfdownload/activities/REI\_SocioEconomicAnalysis\_EN.pdf.

Renwick, D. (2023), 'The US needs 1m more electricians to hit climate goals. Can it recruit more women?', The Guardian , 20 April, www.theguardian.com/environment/2023/apr/20/ uselectricians-shortage-recruit-women.

Richardson, K. et al. (2023), 'Earth beyond six of nine planetary boundaries', Science Advances , 13 September, Vol 9, Issue 37, DOI: 10.1126/sciadv.adh2458.

Robert Gordon University (2022), Making the Switch , May, www. rgueti.com/wpcontent/uploads/2022/06/Making-the-switchimages.pdf.

Reuters (2023), 'Namibia bans export of unprocessed critical minerals', 8 June, www.reuters.com/markets/commodities/ namibia-bans-export-unprocessed-critical-minerals-2023-06-08/.

Rosenow J. and D. Gibb (2023), 'Guest post: How the energy crisis is boosting heat pumps in Europe', Carbon Brief , 21 March, www.carbonbrief.org/guest-post-how-the-energy-crisisisboosting-heat-pumps-in-europe/.

Rystad Energy (2023), 'Europe hoarding Chinese solar panels as imports outpace installations; €7 billion sitting in warehouses', 20 July, www.rystadenergy.com/news/ europe-chinese-solarpanels-imports-installations-storage.

Simas, M. and S. Pacca (2014), 'Assessing employment in renewable energy technologies: A case study for wind power in Brazil', Renewable and Sustainable Energy Reviews , Vol. 31/March, pp. 83-90, www.sciencedirect.com/science/article/abs/pii/S1364032113007958.

Singh, R.K. and L. Hampton (2022), 'Exclusive: GE lays off workers at onshore wind unit as part of turnaround strategy', Reuters , 6 October, www.reuters.com/business/energy/exclusivege-lays-off-workersonshore-wind-unit-part-turnaround-strategy-sources-2022-10-06/.

## SNV and EnDev (Energising Development) (2021),

'Household biodigesters in Viet Nam building a sector for 20 years', SNV, Viet Nam, http://vepg.vn/wp-content/ uploads/2021/05/4.-SNV\_VietNam-Biogas-Program\_EN.pdf.

SolarPower Europe (2022), EU Solar Jobs Report 2022: Addressing the Solar Skills Challenge , SolarPower Europe, Brussels, Belgium, www.solarpowereurope.org/insights/thematic-reports/ eusolar-jobs-report-2.

Stott, M. and K. Bryan (2023), 'Chile's president moves to bring lithium under state control', Financial Times , 21 April (requires subscription).

SEforALL (2023), Africa Renewable Energy Manufacturing: Opportunity and Advancement , Sustainable Energy for All, www.seforall.org/system/files/2023-01/%5BFINAL%5D%20 20220115\_ZOD\_SEForAll\_AfricanManufacturingReport.pdf.

Taiyang News (2022), 'European Commission's backing to boost industry efforts targeting 30 GW/year solar PV manufacturing for EU by 2025', Taiyang News , 13 October, https://taiyangnews.info/ markets/kick-off-for-eu-solar-photovoltaic-industry-alliance/.

Tyagi, A. et al. (2022), India's Expanding Clean Energy Workforce: Opportunities in the Solar and Wind Energy Sectors , Council on Energy, Environment and Water, Natural Resources Defense Council and Skill Council for Green Jobs, Delhi, www.nrdc.org/ sites/default/files/indias-clean-energy-workforce-450-gw-targetreport.pdf.

Urbanchuk, J.M. (2023), 'Contribution of the ethanol industry to the economy of the United States in 2022', prepared for the Renewable Fuels Association by ABF Economics, Doylestown, PA, 14 February, https://ethanolrfa.org/.

US DOE (2023), United States Energy &amp; Employment Report 2023 , US Department of Energy, Washington, DC, June, www.energy. gov/policy/us-energy-employment-jobs-report-useer.

US DOE (2022), Solar Photovoltaics: Supply Chain Deep Dive Assessment , US Department of Energy, Washington, DC, 24 February, www.energy.gov/sites/default/files/2022-02/Solar%20 Energy%20Supply%20Chain%20Report%20-%20Final.pdf.

US EIA (2023), 'Table 10.4a: Biodiesel overview', in Monthly Energy Review: August 2023 , US Energy Information Administration, Washington, DC, www.eia.gov/totalenergy/data/monthly/pdf/mer.pdf.

USAID and Power Africa (2022), South African Solar PV Value Chain , United States Agency for International Development and Power Africa, 9 February, https://pdf.usaid.gov/pdf\_docs/ PA00ZHT4.pdf.

USDA-FAS (2023a), Philippines: Biofuels Annual , US Department of Agriculture-Foreign Agricultural Service, Manila, 9 June, www. fas.usda.gov/data/philippines-biofuels-annual-8.

USDA-FAS (2023b), Thailand: Biofuels Annual , US Department of Agriculture-Foreign Agricultural Service, Bangkok, 6 June, www. fas.usda.gov/data/thailand-biofuels-annual-7.

USDA-FAS (2022a), Brazil: Biofuels Annual , US Department of Agriculture-Foreign Agricultural Service, Sao Paulo, 7 September, www.fas.usda.gov/data/brazil-biofuels-annual-9.

USDA-FAS (2022b), Colombia: Biofuels Annual , US Department of Agriculture-Foreign Agricultural Service, Bogota, 1 August, www. fas.usda.gov/data/colombia-biofuels-annual-8.

USDA-FAS (2022c), Indonesia: Biofuels Annual , US Department of Agriculture-Foreign Agricultural Service, Jakarta, 28 July, www.fas. usda.gov/data/indonesia-biofuels-annual-6.

USDA-FAS (2022d), Malaysia: Biofuels Annual , US Department of Agriculture-Foreign Agricultural Service, Kuala Lumpur, 10 November, www.fas.usda.gov/data/malaysia-biofuels-annual-5.

USDA-FAS (2022e), European Union: Biofuels Annual , US Department of Agriculture-Foreign Agricultural Service, The Hague, 13 July, www.fas.usda.gov/data/european-union-biofuels-annual-2.

USDA-FAS (2022f), China: Biofuels Annual , US Department of Agriculture-Foreign Agricultural Service, Beijing, 6 September, www.fas.usda.gov/data/china-biofuels-annual-8.

Weiss, W. and M. Spörk-Dür, (2023), Solar Heat Worldwide: Edition 2023: Global Market Development and Trends 2022 , Detailed Market Figures 2021, AEE - Institute for Sustainable Technologies, Gleisdorf, Austria, and Solar Heating and Cooling Programme, International Energy Agency, Paris, www.iea-shc.org/ Data/Sites/1/publications/Solar-Heat-Worldwide-2023.pdf.

White, E. (2023), 'How China cornered the market for clean tech', Financial Times , 9 August (requires subscription).

White House (2023), 'Treasury releases new guidance, strengthening incentives for domestic clean energy manufacturing', 12 May, www.whitehouse.gov/cleanenergy/ clean-energyupdates/2023/05/12/treasury-releases-newguidance-strengthening-incentives-for-domesticclean-energymanufacturing/.

Wood Mackenzie (2023a), 'Global PV supply chain pulse: February 2023' (requires subscription).

Wood Mackenzie (2023b), 'Global wind turbine order tracking, March 2022', 5 April (requires subscription).

Wood Mackenzie (2023c), 'Finally! Vietnam's 2030 power plan: targeting more gas and onshore wind', June (requires subscription).

Woods, B. (2023), 'From GE to Siemens, the wind energy industry hopes billions in losses are about to end', CNBC, 17 April, www. cnbc.com/2023/04/17/from-ge-to-siemens-wind-energy-hopesits-crisis-is-about-to-end.html.

World Bank (2023), 'Solar mini grids could sustainably power 380 million people in Africa by 2030 - if action is taken now', press release, 26 February, www.worldbank.org/en/news/ pressrelease/2023/02/26/solar-mini-grids-could-sustainably-power380-million-people-in-afe-africa-by-2030-if-action-is-taken-now.

Yu, T. and C. Dong (2023), 'Is China's domination of PV exports coming to an end?', May (requires subscription).

<!-- image -->

## Publications

## Jobs assessments

<!-- image -->

You can explore IRENA's comprehensive research on socio-economic impacts, by visiting www.irena.org/Publications

## IRENA HEADQUARTERS

P.O. Box 236, Abu Dhabi United Arab Emirates www.irena.org