---
document_id: iea_turkiye-2026
title: "Iea Turkiye-2026"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_turkiye-2026.pdf"
tables_detected: 11
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 3 2 M ember countries, 1 4 A ssociation countries and beyond.

This publication , as well as any data and map included herein  are without prejudice , to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

## IEA M ember

countries:

IEA Accession countries:

Australia

Austria

Belgium

Canada

Czech Republic

Denmark

Estonia

Finland

France

Germany

Greece

Hungary

Ireland

Italy

Japan

Korea

Latvia

Lithuania

Luxembourg

Mexico

Netherlands

New Zealand

Norway

Poland

Portugal

Slovak Republic

Spain

Sweden

Switzerland

Republic of Türkiye

United Kingdom

United States

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

Brazil Chile Colombia Costa Rica Israel Romania

## IEA Association countries:

The European Commission also participates in the work of the IEA

<!-- image -->

## Table of contents

| Executive summary............................................................................................4         |                                                                                                                   |
|------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Energy policy landscape .................................................................................11            |                                                                                                                   |
| Climate and energy strategy...........................................................................11               |                                                                                                                   |
| Energy efficiency.............................................................................................17       |                                                                                                                   |
| End-use sectors ..............................................................................................20       |                                                                                                                   |
| Electricity.........................................................................................................31 |                                                                                                                   |
| Fuels                                                                                                                  | ...............................................................................................................44 |
| Affordability                                                                                                          | .....................................................................................................53           |
| Energy investment and financing....................................................................54                  |                                                                                                                   |
| Recommendations..........................................................................................56            |                                                                                                                   |
| Focus areas.......................................................................................................60   |                                                                                                                   |
| Expansion and integration of variable renewables                                                                       | .........................................60                                                                       |
| Recommendations..........................................................................................73            |                                                                                                                   |
| Energy performance and competitiveness of industry....................................74                               |                                                                                                                   |
| Recommendations..........................................................................................81            |                                                                                                                   |

Annexes  .............................................................................................................83

## Executive summary

Türkiye's energy sector is at a pivotal juncture, shaped by domestic energy and climate ambitions, strong demand growth, structural import dependence and its strategic role as a regional energy corridor. As a major link between Europe, the Middle East and the Caspian region, Türkiye plays an important role in regional energy markets, while managing internal energy system pressures. Strong economic and population growth are driving sustained increases in energy demand, impacting security  of  supply,  affordability  and  emissions.  Türkiye  has  made  progress  in modernising  its  energy  infrastructure,  strengthening  its  integration  with  regional markets  and  expanding  cleaner  energy  sources  such  as  renewables  and  nuclear power. However, high reliance on imported fuels and exposure to global energy price volatility  remain  persistent  challenges  along  with  a  need  for  coherent  regulatory frameworks.

Türkiye established a comprehensive energy and climate policy framework that aligns a long-term strategic vision with shorter-term implementation instruments. The first National Energy Plan (TNEP), developed by the Ministry of Energy  and  Natural  Resources  (MENR)  and  adopted  in  2022,  set  targets  for 2020-2035, incorporating sectoral, demographic and economic projections from other state  bodies.  The  12th  Development  Plan  (2024-2028),  was  prepared  within  the framework of the government's 2053 vision, and established targets for a five-year implementation period. MENR's Strategic Plan (2024-2028), and the Second National Energy Efficiency Action Plan (2024-2030), provide nearer-term targets, performance measures and delivery mechanisms.

Türkiye's adoption of its first-ever Climate Law in July 2025 marked a major milestone that strengthens climate governance and creates a framework for carbon pricing. This  broad-reaching law translates Türkiye's international climate commitments  and  2053  net  zero  emissions  target  into  domestic  legislation  and

establishes the legal framework of a national emissions trading system. This new framework and the opportunities for complementary measures elevate the importance of  a  more  integrated  approach  to  industrial  competitiveness  that  promotes  policy coherence across Türkiye's energy security, climate and economic objectives.

Managing rapid demand growth while ensuring affordability and energy system resilience  is  a  central  challenge  for  Türkiye's  energy  policy. Energy  demand increased steadily over the past decade and is expected to continue rising under the TNEP,  requiring  sustained  investment  across  the  system.  For  example,  a  fastgrowing economy and population have steadily increased electricity demand at an average annual rate of almost 5% from 2005 to 2024 - the fastest rate of growth in IEA's membership - and the TNEP forecasts this growth to continue until 2035, albeit at  a  slower  pace,  driven  primarily  by  industry  and  household  consumption.  Such demand  growth  amplifies  vulnerabilities  to  external  shocks,  particularly  given Türkiye's  reliance  on  imported  fossil  fuels.  Continuing  existing  efforts  to  ensure transparent,  market based  end user  pricing,  paired  with  targeted  measures  for --vulnerable  consumers,  would  strengthen  incentives  for  efficiency  and  investment without undermining social objectives.

The power sector will help determine the pace and scale of Türkiye's transition and  must  balance  rapid  renewables  growth  with  reliable  system  operation. Ambitious plans to expand wind and solar capacity are central to the TNEP, with renewables expected to supply a growing share of electricity demand. Renewables supplied 43% of electricity generation in 2025, and the TNEP foresees renewable generation rising to 55% of electricity supply by 2035. Nuclear energy is expected to contribute  around  10%  of  capacity  once  Akkuyu  nuclear  power  plant  is  fully operational in the coming years, further diversifying the energy mix. Delivering this transformation  requires  not  only  adding  capacity,  but  also  improving  system operations, ensuring reliability and keeping total system costs manageable.

Scaling up variable renewables places growing demands on grid infrastructure, system operations and flexibility. While Türkiye has made significant investments in transmission  and  distribution  networks,  its  plans  for  a  major  expansion  of transmission, substations and battery storage capacity by 2035 underscore the scale of the challenge. System flexibility is currently provided mainly by hydropower and thermal  generation  but  rising  shares  of  wind  and  solar  will  increase  the  need  for storage, demand-side response, digital solutions and regional grid interconnections. Clear locational signals, market rules and regulatory frameworks will be essential to mobilise  investment  in  flexibility  and  grids,  encourage  consumer  engagement  in demand-side response and ensure secure system operation.

Nuclear power is intended to be a cornerstone of Türkiye's future decarbonised electricity  system,  but  delivery  depends  on  robust  financing  and  a  credible approach to emerging technologies. Beyond the Akkuyu nuclear power plant, the government is planning to build additional large-scale nuclear power plants, which will require viable financing frameworks and co-ordinated policy action. In parallel, small modular  reactors  (SMRs)  could  offer  a  potential  flexible  and  modular  solution  for decarbonising  hard-to-abate  industrial  sectors,  but  clear  strategic  and  regulatory frameworks are needed to enable credible, private-sector-led applications.

Coal  remains  prominent  in  the  energy  mix,  raising  long-term  economic  and environmental challenges that point to the need for a just and orderly transition. In 2024, coal supplied one-quarter of total energy supply and generated more than one-third of electricity. Türkiye consumed around 120 million tonnes (Mt) of coal in 2025, making it the largest coal consumer in Europe. Although it has declined over the past decade, Türkiye's carbon intensity of power generation remains among the highest  in  IEA's  membership.  While  coal  plants  contribute  to  adequacy  and  price stability, continued reliance on coal risks higher emissions, exposure to future carbon pricing  and  growing  fiscal  costs  through  support  mechanisms  such  as  capacity payments. Establishing a policy framework to ensure an orderly, well planned coal transition would help manage these risks, support affected communities and redirect resources toward cleaner alternatives.

Energy  efficiency  is  one  of  Türkiye's  most  cost-effective  levers  to  reduce import  dependence,  improve  affordability  and  strengthen  competitiveness. Türkiye's  policy  push  began  with  the  Energy  Efficiency  Law  in  2007  and  has expanded  through  successive  strategies,  including  the  Energy  Efficiency  2030 Strategy and the second action plan for 2024-2030, which is supported by substantial investment intentions. A range of initiatives has been introduced, such as measures to promote building retrofits, industrial process optimisation and efficient appliances. Nevertheless,  Türkiye's  full  energy  efficiency  potential  remains  untapped.  Barriers such  as  limited  access  to  finance,  the  need  for  improved  implementation,  and insufficient public awareness persist. Strengthening monitoring mechanisms, enhancing  capacity-building  efforts,  and  fostering  public-private  partnerships  are critical next steps to accelerate progress and maximise impact.

Buildings policy sits at the intersection of affordability,  energy  security  and resilience, and requires a step change in renovation delivery and finance. The expansion of the building stock is a key driver of rising energy demand and emissions in  the  sector.  Moreover,  Türkiye  is  highly  prone  to  earthquakes,  and  although resilience efforts have accelerated, the building stock needs further strengthening. Energy  efficiency  upgrades  can  offer  financial  returns  that  help  improve  the

bankability of retrofit projects. Combining energy efficiency with seismic upgrades can reduce costs. Prioritising residential renovations through scalable financing solutions, while  integrating  seismic  resilience  upgrades,  can  lower  household  bills,  manage system  demand  growth  and  strengthen  resilience,  provided  that  programmes  are designed to reach vulnerable households effectively.

Decarbonising heat requires a clearer 'heat market' pathway that leverages Türkiye's geothermal strengths and enables investable local delivery models. Türkiye is assessing the role of district heating as a solution for decarbonising space heating, the largest energy end use in residential buildings, and existing geothermalbased systems, which are presently concentrated in resource rich regions, suggest scope  to  expand  low-emissions  heat  where  it  is  cost  effective.  Moreover,  the requirement  for  buildings  above  a  certain  size  to  source  10%  of  their  energy consumption  from  renewable  energy  could  be  fulfilled  through  the  direct  use  of geothermal heat. Nonetheless, Türkiye is still at the early stages of legislation and policies dedicated to district heating.

The transport sector accounts for a significant and growing share of energy demand and emissions in Türkiye, requiring stronger policy action to diversify fuels, improve efficiency and shift towards lower-emission modes of transport. In  2023,  the  transport  sector  accounted  for  around  30%  of  total  final  energy consumption  and  one-quarter  of  energy-related  emissions,  with  road  transport overwhelmingly  dominant  and  almost  entirely  dependent  on  oil  products.  Despite relatively low car ownership compared with European peers, rapid growth in vehicle stock and travel demand is driving increased fuel consumption and emissions. Under the Energy Efficiency Strategy 2024-2030 and other policies, Türkiye introduced a range of measures to address this challenge, including support for electric vehicles, expansion  of  charging  infrastructure  and  policies  to  promote  public  transport  and modal shift towards rail and maritime transport.

Ensuring Türkiye's industrial competitiveness in a carbon-constrained global economy  will  depend  on  combining  efficiency  delivery,  carbon  pricing  and integrated infrastructure planning. Organised industrial zones can act as practical 'one-stop shops' to scale energy efficiency in less energy intensive industries that often lack capacity to participate in programmes independently, while strengthening access  to  finance  and  implementation  support.  At  the  same  time,  an  emissions trading system focused on large energy consumers - complemented by a carbon tax or  charge  for  firms  outside  the  Emissions  Trading  System  (ETS)  -  can  support emissions  reductions  and  alignment  with  external  market  pressures,  especially  if revenue  recycling and  infrastructure planning (electricity, gas, hydrogen  and CO2 networks) are integrated into a coherent competitiveness strategy.

Türkiye's efforts to modernise its energy sector, meet climate commitments, and improve  efficiency  are  commendable,  yet  require  sustained  momentum  and coherent action. The recommendations in this report offer a roadmap for policy makers and stakeholders to navigate the complexities of the transition, capitalise on emerging opportunities, and deliver a secure, sustainable and inclusive energy future for Türkiye. Looking ahead, success will depend on the alignment of strategic objectives, robust governance, and active engagement across all segments of society. By embracing innovation,  fostering  collaboration,  and  prioritising  long-term  resilience,  Türkiye  can position itself as a regional leader in a secure global energy transition.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

<!-- image -->

Sources and notes for this infographic can be found in the annexes.

## Policy recommendations for Türkiye

## Energy policy landscape

- 1 Prioritise the renovation of residential buildings to improve energy efficiency, thermal performance and seismic resilience by scaling up financial solutions.
- 2 Accelerate the deployment of a heat market, leveraging domestic geothermal resources, to decarbonise heating systems and strengthen energy security.
- 3 Complete energy market reform by carefully transitioning end-user prices to a transparent, market-based pricing mechanism.
- 4 Ensure a viable financing framework for large nuclear power plants while establishing a clear strategic framework for small modular reactors.
- 5 Establish a policy framework to initiate a just and orderly transition for local communities relying on the coal industry.

## Expansion and integration of variable renewables

Focus area

- 6 Ensure market rules provide clearer locational signals to improve system operation and ensure grid stability during the transition.
- 7 Expand participation in the electricity spot market and encourage investment in system flexibility.

## Energy performance and competitiveness of industry

## Focus area

- 8 Leverage organised industrial zones to drive energy efficiency actions in less energy-intensive industries.
- 9 Introduce an emissions trading system for large energy consumers to encourage efficiency and emissions reductions while introducing a carbon tax for companies falling outside the ETS.
- 10 Adopt a more integrated approach to industrial competitiveness and support energy security and climate goals.

IEA. CC BY 4.0.

## Energy policy landscape

## Climate and energy strategy

## Energy targets

Türkiye outlined its long-term energy targets in its first National Energy Plan (TNEP) in  2022.  The  TNEP,  developed  by  the  Ministry  of  Energy  and  Natural  Resources (MENR),  includes  targets  for  the  period  2020-2035  and  incorporates  sectoral, demographic and economic projections from the Presidency of Strategy and Budget and  TurkStat.  To  support  Türkiye's  energy  transition,  the  12th  Development  Plan (2024-2028), the MENR's 2024-2028 Strategic Plan and the Second National Energy Efficiency Action Plan (2024-2030) provide short-term targets, performance measures  and  strategies  for  increasing  domestic  energy  production,  improving energy efficiency and achieving green transformation of the economy.

The MENR's 2024-2028 Strategic Plan defines goals for meeting Türkiye's energy needs  based  on  reducing  import  dependency  and  enhancing  energy  security. Expanding renewable energy is a central pillar: Türkiye aims to more than double its renewable  capacity,  from  70 gigawatts  (GW)  in  2024  to  nearly  160 GW  by  2035. By 2030, renewable installed  capacity is  projected  to  reach  91 GW.  In  addition  to increasing the renewable energy supply, exploration and production of domestic fossil fuels  is  set  to  enhance  the  self-sufficiency  of  the  energy  supply.  Oil  production  is expected to almost double, rising from 125 thousand barrels per day (kb/d) in 2025 to  210 kb/d  in  2028,  equivalent  to  a  fifth  of  oil  demand  (over  1 000 kb/d)  in  2024. Natural gas production will also expand, increasing almost fivefold from 3.1 billion cubic  metres  (bcm)  in  2025  to  15.5 bcm  in  2028,  or  around  29%  of  gas  demand (53 bcm) in  2024.  Underground  gas  storage  capacity  will  more  than  double,  from

5.8 bcm in 2024 to 12 bcm by 2028, further enhancing security of supply. In addition, Türkiye  plans  to  expand  coal  production,  increasing  by  almost  50%,  from  around 662 petajoules (PJ) in 2024 to 965 PJ in 2028. This increase is driven primarily by increased lignite production, from almost 600 PJ to 906 PJ, while hard coal production is projected to rise from 56 PJ to 59 PJ. While greater levels of energy production align with Türkiye's goal of reducing external energy dependency, the increase will also contribute to rising domestic emissions.

The  Energy  Efficiency  Strategy  and  2nd  National  Energy  Efficiency  Action  Plan (2024-2030) highlight the importance of energy efficiency. Between 2011 and 2022, Türkiye surpassed its 2023 energy intensity improvements target of 20% ahead of schedule.  The  government  aims  to  reduce  energy  intensity  by  15%  in  the  period 2024-2030,  at  an  annual  average  rate  of  2.3%.  While  Türkiye's  energy  intensity improvements averaged 1.4% per year between 2014 and 2024, it demonstrated a 3.1%  improvement  between  2020  and  2024,  suggesting  potential  to  accelerate progress.

## Climate targets

Türkiye ratified the Paris Agreement in 2021 and submitted a first updated Nationally Determined  Contribution  (NDC)  to  the  United  Nations  Framework  Convention  on Climate Change (UNFCCC) in 2023, committing to achieve net zero greenhouse gas (GHG)  emissions  by  2053.  Türkiye's  2030  GHG  emissions  reduction  targets  are measured against the business-as-usual scenario (BAU) projection to 2030. The first NDC raises the target to 41% economy-wide reduction, compared to 2030 BAU levels, using 2012 as the base year for the BAU projection. This marks a more ambitious goal compared to the target from the intended NDC (2015), which vowed to reduce emissions by 21% from the BAU scenario. Under the BAU scenario, emissions increase by 101% from 2024 to 2030, reaching 1 175 million tonnes carbon dioxide equivalent (Mt CO2-eq), while under Türkiye's first updated NDC, they only increase  by  20%,  to  almost  700 Mt CO2  in 2030.  The  first  updated  NDC  also highlights  Türkiye's  pledge  to  a  peak  in  emissions  by 2038.  In  November  2025, Türkiye  submitted  its  second  NDC,  introducing  a  new  emissions  target  for  2035 aiming to limit emissions to 643 Mt CO2-eq.

The continued rise in emissions through 2038 is a result of increased energy demand, driven  by  economic  growth.  According  to  the  12th  Development  Plan  2024-2028, gross domestic product (GDP) will grow by almost 50% between 2023 and 2028 and GDP per capita by 41% (in current prices, USD). GHG emissions (excluding LULUCF)

in  2024  were  585 Mt CO2-eq,  covering  around  1.1%  of  global  GHG  emissions. Türkiye's per capita CO2 emissions are considerably lower than the OECD average: in  2023,  they  were  4.6 tonnes  of  carbon  dioxide  (t CO2),  compared  to  the  OECD average of 7.5 t CO2 per capita. They have been increasing, however, growing by 38% from 2005 to 2023.

## Select indicators in Türkiye, 2010-2024

Note: TES = total energy supply; TFEC = total final energy consumption.

<!-- image -->

Source: IEA (2026), World Energy Balances.

Despite the absolute increase in energy-related emissions, a relative decoupling of emissions from GDP  growth  has  taken  place  over the past two decades. From 2010 to 2024,  GDP  increased  by  roughly  110%  while  total  energy-related emissions increased by 50%. Further, Türkiye recorded energy efficiency improvements with primary energy intensity reducing by 26% between 2010 and 2024.

Within the energy sector, electricity and heat generation accounted for 35% of GHG emissions in 2024. The next-largest emitting sector was industry (25%) - including manufacturing, construction, agriculture and fishing - followed by transport (24%) and buildings (15%). From 2010 to 2024, the largest increase in emissions in absolute terms has come from transport, more than doubling, as car ownership rates have risen. Both emissions from electricity and heat generation and industry increased by around 45%, and emissions from buildings increased by 22%.

## Energy-related emissions by sector in Türkiye (2024) and relative change, 2010-2024

<!-- image -->

IEA. CC BY 4.0.

Source: IEA (2026), Greenhouse Gas Emissions from Energy.

## Climate resilience

Türkiye's average temperature has been climbing since 1994 and is likely to continue to do so, boosting energy demand for cooling in the upcoming decades. This will put additional pressures on the energy system, which has already seen rapid increases in electricity demand.  Türkiye's  observed  average  annual  mean  temperature increased by more than 2°C from 1901 to 2020, a rate of warming in the past two decades that is significantly higher than the world average.

More  severe  weather  events are also likely to affect the country's energy infrastructure. The frequency of extreme climate events has increased over the past two decades, setting a new record every year since 2018, according to Turkish State Meteorological  Services.  Furthermore,  climate  projections  indicate  an  increase  in drought  frequency,  duration  and  severity  by  the  end  of  the  century.  In  2020,  for example, droughts caused electricity generation from hydropower plants to fall by 12% while heavy rainfalls  with  flash  floods  in  the  Black  Sea  region  led  to  power outages in the same year. Furthermore, Türkiye is in an active volcanic zone and exhibits an overall high exposure to natural disasters.

These factors underscore the necessity for an appropriately designed and protected energy infrastructure. Türkiye formulated its Climate Change  Mitigation and Adaptation  Strategy  and  Action  Plans  2024-2030  in  March  2024  to  strengthen

economy-wide resilience to climate change. It sets out sector-specific targets and mitigation/adaptation activities aligned with the country's NDC. Notably, the Strategy introduced  the  Climate  Portal,  an  online  monitoring  system  managed  by  the Directorate of Climate Change (DoCC). By 30 June each year, the DoCC compiles a progress-evaluation  report  for  the  Climate  Change  and  Adaptation  Co-ordination Board (CCACB) working groups, ensuring accountability. The 12th Development Plan (2024-2028) stipulates the preparation of a Disaster Management Strategy to better respond  to  natural  disasters,  including  the  heightened  risks  resulting  from  global warming. This Plan envisions Türkiye as an environmentally friendly, disaster-resilient, high value-added economy.

## Climate policy framework

Following Türkiye's ratification of the Paris Agreement in October 2021, Presidential Decree No. 85 established the DoCC to lead and co-ordinate national climate policies, strategies and actions. To facilitate stakeholder representation and ensure inclusive and  participatory  climate  governance,  the  government  established  the  CCACB, comprising representatives from ministries, the private sector and civil society. First and  foremost,  the  CCACB  approves  climate  planning  documents  and  reviews progress to maintain transparency and accountability in achieving Türkiye's climate goals. Furthermore, CCACB working groups provide input to sectoral strategies.

In  February  2022,  Türkiye  convened  its  first  Climate  Council,  bringing  together participants  from  government,  industry,  academia  and  civil  society.  The  Council presented  217 recommendations  and  76 priority  actions,  which  directly  inform Türkiye's  long-term  climate  strategies.  The  2053  Long-term  Climate  Strategy, submitted  to  the  UNFCCC  in  November  2024,  serves  as  the  overarching  climate roadmap towards net zero emissions. These actions are complemented by several recent planning documents with short-term energy targets and green transformation measures, of which the most relevant are the TNEP, the 12th Development Plan (2024-2028),  the  2024-2028  Strategic  Plan  and  the  Second  National  Energy Efficiency Action Plan (2024-2030).

The  Climate  Law,  adopted  on  2 July 2025,  marks  a  major  milestone  in  Türkiye's environmental policy and its commitment to achieving net zero emissions by 2053. It represents  the  country's  efforts  to  align  its  climate  governance  with  the  Paris Agreement and establish a legally binding framework for reducing GHG emissions. The  Climate  Law  also  provides  for  a  domestic  Emissions  Trading  System  (ETS) modelled on the European Union's (EU) ETS, expected to cover installations in the

major industrial  sectors  such  as  energy,  cement  and  steel  with  annual  emissions above thresholds to be defined in secondary legislation, potentially 50 000 t CO -eq. ₂ The  new  law  aims  to  prevent  carbon  leakage  and  protect  domestic  industry  and establishes a governance structure led by the Climate Change Directorate and the National Advisory Committee.

## Taxation and carbon pricing

The new Climate Law provides the legal framework for combating climate change, establishing  a  national  ETS  and  reinforcing  the  authority  of  the  DoCC.  Türkiye's ETS design aligns closely with that of the European Union, in anticipation of impacts from the EU Carbon Border Adjustment Mechanism (CBAM). The implementation of the CBAM is set to significantly affect Türkiye's major carbon-intensive export sectors, notably iron and steel. In response to this challenge, a 2023 study commissioned by the  Ministry  of  Environment,  Urbanization  and  Climate Change found that Türkiye could counteract the impact of the CBAM by introducing a domestic ETS. The newly adopted Climate Law establishes the legal foundation for the country's climate action, providing for the creation of a national ETS and strengthening the DoCC's authority.

Currently  under  development,  Türkiye's  ETS  is  designed  in  alignment  with  the EU ETS,  while  taking  into  account  Türkiye's  circumstances,  and  is  intended  to support Türkiye's goal of achieving net zero emissions by 2053. Under the Climate Law, installations covered by the ETS have been granted a transitional exemption period,  allowing  them  until 2028  to  obtain  their  greenhouse  gas  (GHG)  emissions permits. As planned by the Directorate of Climate Change (DoCC), the TR ETS will be launched with a two-year pilot phase, a decision that was formally endorsed at the first  meeting  of  the  Carbon  Market  Board.  Following  its  publication  in  the  Official Gazette in December 2023, a grant agreement with the World Bank's Partnership for Market  Implementation  programme  came  into  effect.  The  Partnership  supports Türkiye  in  modelling  different  ETS  design  options,  assessing  the  potential  socioeconomic impacts of the ETS, preparing for the pilot phase and assisting with the initial implementation stages. The pilot ETS is expected to cover a limited number of installations  in  the  energy  and  industrial  sectors,  on  the  order  of  180  facilities. Modelled  on  the  EU  ETS,  Türkiye's  pilot  ETS  will  use  data  from  its  monitoring, reporting  and  verification  system,  in  place  since  2015.  Monitoring,  reporting  and verification legislation established an installation-level system for CO2 emissions for approximately  800 entities,  covering  the  energy  sector  (total  rated  thermal  input &gt;20 megawatts [MW]) and several industry sectors. Regulated entities submitted their first  monitoring  plans  by  October  2014  and  have  been  submitting  verified  annual

emissions reports to the Directorate of Climate Change every year since 2015. The Climate Law also provides a framework for the free allocation of allowances in the ETS;  however,  the  Climate  Law  does  not  yet  specify  the  timeline  for  introducing auctions. Detailed regulation and technicalities will be developed through secondary legislation. Complementing the ETS, the Climate Law also establishes a framework for the generation and trading of carbon credits through voluntary offsetting projects, to be registered in a national offset registry.

## Energy research and development

The government aims to expand research and development (R&amp;D) activities for both energy and critical minerals, a recurring objective in the 2024-2028 Strategic Plan, the 12th Development Plan and the Medium-Term Program (2025-2027). Priorities focus on clean energy technologies to strengthen energy security, economic growth and environmental sustainability, with renewables and energy efficiency receiving the largest support. While energy efficiency spending rose between 2014 and 2019, it declined sharply in 2020 and remained well below pre-pandemic levels in 2024.

The  Turkish  Energy,  Nuclear  and  Mineral  Research  Agency  (TENMAK)  leads innovation by funding R&amp;D in clean energy, advanced systems and critical materials, supporting  collaboration,  commercialisation  and  technology  roadmaps.  TENMAK prepared the Hydrogen Technologies Strategy (2023) and is developing plans for CCUS, critical materials, digitalisation, solar, wind and energy storage.

Hydrogen  is  a  growing  focus,  with  ambitions  to  become  a  technology  provider leveraging renewable potential for domestic use and export. R&amp;D also targets cleaner use of  domestic  coal,  alongside  CCUS,  to  decarbonise heavy industry.  The  2030 Industry  and  Technology  Strategy  supports  domestic  manufacturing  in  solar  and wind, as well as deployment of electrolysers, fuel cells and storage, while promoting digitalisation, smart grids and green transformation of industrial zones.

## Energy efficiency

Türkiye began strengthening energy efficiency policy in 2007 with the implementation of an Energy Efficiency Law. Since then, it has introduced comprehensive efficiency policies  covering  energy  production  through  to  final  consumption  across  all  major

sectors. These measures have delivered strong results, as evidenced by improvements in energy intensity - a key metric for measuring the energy efficiency of the overall economy.

Like many countries, Türkiye was heavily impacted by recent geopolitical turmoil. The 2022  energy  crisis  saw  energy  demand  decline  that  year  by  1.5%  even  as  the economy  expanded  by  5.4%,  yielding  an  exceptional  year  of  energy  intensity improvement  of  7%.  This  energy  shock  contributed  to  the  first  National  Energy Efficiency  Plan  (NEEAP) slightly overachieving on its initial targets, delivering just over  1 000 PJ  of  cumulative  energy  savings  as  a  direct  result  of  the  additional USD 8.5 billion in investments over the period. This investment also helped generate almost 45 000 new jobs and reduced emissions by almost 70 Mt CO2-eq between 2017 and 2023. As a result of these programmes, the government estimates each dollar of investment yielded a four-dollar return.

## Targets from Türkiye's energy efficiency strategies

|                                | 2017-2023   | 2017-2023   | 2024-2030   |
|--------------------------------|-------------|-------------|-------------|
|                                | Target      | Actual      | Target      |
| Energy savings (PJ)            | 1 001       | 1 030       | 1 553       |
| Emissions reduction (Mt CO 2 ) | 66.6        | 68.6        | 100         |
| Investment (USD billion)       | 10.9        | 8.5         | 20.2        |
| Jobs created                   |             | 44 880      |             |

Sources: IEA analysis based on MENR (2024), Energy Efficiency 2030 Strategy and 2nd National Energy Efficiency Action Plan (2024-2030), (accessed October 2025).

The boost in investment combined with policy actions initiated during the first NEEAP period contributed to more than a doubling of the rate of energy intensity progress, from 1.2% per year in the period 2011-2017 to 3% per year from 2017 to 2023. To put this in perspective, had energy intensity progress remained steady at 2017 levels averaging 1.2% per year through to 2023, an extra 870 PJ of energy would have been needed in 2023 to produce the same GDP, equivalent to 13% more energy each year.

In 2024, Türkiye launched its Energy Efficiency 2030 Strategy and second NEEAP for  the  period  2024-2030  with  61 actions  identified  across  7  sectors  involving 266 activities. This  includes  a  plan  to boost  energy  efficiency  investment  to USD 20.2 billion  between  2024  and  2030,  USD 5 billion  of  which  will  be  publicly sourced through taxes and incentives; the remainder will be financed by the private sector. These investments are expected to yield a cumulative reduction in energy consumption of over 1 500 PJ by 2030, lower emissions by around 100 Mt CO2 and generate even more employment than the first phase of the NEEAP.

## Annual improvements in primary energy intensity in Türkiye (2000-2023) and 2030 targets

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on IEA (2026), World Energy Balances; IEA (2025), Energy Efficiency Progress Tracker; MENR (2024), Energy Efficiency 2030 Strategy and 2nd National Energy Efficiency Action Plan (2024-2030), (accessed October 2025).

The  targeted  15%  reduction  in  energy  intensity  in  the  period  2024-2030  implies annual improvements of around 2.3%. This would represent a substantial increase compared with the 2011-2017 baseline (almost tripling), but a slowdown relative to the faster progress achieved in recent years (around 3% annually in 2017-2023).

## End-use sectors

## Industry

The industrial sector, including manufacturing, refining and mining, plays a central role in Türkiye's economy, contributing around one-quarter of GDP and accounting for  roughly  35%  of  total  final  energy  consumption  in  2024.  It  is  also  responsible for  22%  of  energy-related  GHG  emissions. The  sector more than doubled in size since 2010, up almost 120%, with industrial value added growing at an average of 5.4% per year between 2010 and 2025. According to the IEA's Energy Efficiency Progress Tracker, Türkiye improved its industrial energy efficiency faster than global benchmarks and comparable countries. Türkiye's industrial energy intensity improved at a rate of 2.6% per year from 2010 to 2019 compared to an annual improvement rate of 1.8% globally.

Manufacturing  dominates  industrial  energy  use,  representing  around  80%  of  total consumption, ranging from energy-intensive industries such as steel, cement and petrochemicals  to  less  energy-intensive  sectors  including  automotive,  textiles  and food production. Their differing economic structures shape their energy-use patterns and decarbonisation challenges. Energy-intensive industries correspond to the majority of  consumption  (67%  of  energy  consumption  in  2024),  while  less  energy-intensive industries play a larger role in employment, value added and exports (Focus Area 2).

Energy-intensive manufacturing is particularly dependent on direct use of fossil fuels (74% in  2024),  especially  for  high-temperature  processes.  Coal  made  up  35%  of energy use in energy-intensive sectors. Natural gas accounted for 23%, oil for 15% and  electricity  use  for  21%,  the  largest  share  of  which  is  used  in  ferrous  metals. Energy consumption in less-intensive manufacturing sectors more than doubled to 460 PJ in 2024 from 181 PJ in 2010. Among less energy-intensive industries, coal consumption  grew  the  most  in  percentage  terms,  almost  tripling  over  the  period, followed by electricity and natural gas.

Industrial growth and  decarbonisation of industry are both priorities for the government. The 12th Development  Plan targets to increase the share of manufacturing in GDP from 22% in 2022 to 27% by 2028, positioning Türkiye among the top 10 global manufacturing economies, while the Long-Term Climate Strategy sets out plans for the manufacturing industry sector to reach Türkiye's net zero by 2053 goals. Existing policies, including energy efficiency obligations, financial support programmes and planned carbon pricing, provide a framework to improve industrial efficiency and reduce emissions (see Focus Area 2).

## Buildings

The expansion of the buildings stock is a key driver of rising energy demand in the buildings sector. In 2022, the buildings stock reached approximately 9.5 million units (an 8% increase in five years), around 90% of which are residential buildings. The World Bank projects this number to reach 17 million units in 2050. Meanwhile, the number of households rose from 20 million to 27 million between 2012 and 2025. As the floor area increases, more energy is required to heat and cool these spaces.

In 2024, buildings accounted for 36% of Türkiye's total final energy consumption and 15% of energy-related GHG emissions. Since 2010, energy demand grew by 2.7% annually, resulting in a 45% increase. Energy use reached over 1 750 PJ in 2024, driven primarily by residential demand. Fossil fuels continue to dominate, with natural gas covering half of the sector's total energy consumption in 2024, up from 22% in 2010, having displaced coal (-18% from 2010) and bioenergy (-11%). Electrification stood at 33% in 2024, well below the IEA average (47%), as the penetration of electric systems,  especially  in  heating,  is  lower.  Direct  renewable  energy  use  remained limited,  with  bioenergy  at  3.9%  in  2024,  solar  at  2.3%  and  geothermal  at  4.2%. Türkiye,  however,  ranks  among  the  top  IEA  Member  countries  for  geothermal consumption in buildings.

## Energy use by fuel in residential buildings in Türkiye, 2010 and 2024

<!-- image -->

IEA. CC BY 4.0.

Note: The change in energy use from geothermal and solar between 2010 and 2024 is not included in the figure due to its small amount (an increase of 23 PJ).

Source: IEA (2026), World Energy Balances.

Many existing buildings were constructed before the introduction of more stringent building energy performance and seismic requirements. Consequently, a significant share of the existing building stock may not reflect current standards, highlighting the importance of renovation and urban transformation programmes.

Türkiye  has  strengthened  minimum  energy  performance  requirements  for  new buildings through  amendments  to  the  Regulation  on  Energy  Performance  in Buildings. Since 2025, buildings larger than 2 000 m² are required to achieve at least energy performance class B and meet 10% of their energy needs from renewable energy  sources.  The  regulation  introduced  the  concept  of  nearly  zero-energy buildings and applies these requirements in a phased manner. Amendments adopted in 2026 also introduced mandatory life-cycle assessment and a low-carbon building certificate for buildings above a construction area of 10 000 m², taking effect in 2027.

The Air Quality Improvement Programme is a Ministry of Environment, Urbanization and Climate Change scheme that provides grants to local governments to reduce air pollution  from  residential  heating  and  improve  overall  air  quality.  Since  2021, approximately 20 000 residences received grants to convert from coal-fired heating to natural  gas-fired  heating  systems  or  geothermal  systems.  The  Air  Quality Improvement  Programme  will  continue  by  increasing  the  number  of  residences receiving grants.

## Main features of the most recent building codes in Türkiye

<!-- image -->

| Year         | 2000 (general code)                             | 2007 (general and earthquake codes)                                        | 2018 (earthquake code)                                             | 2023 (general code)                                                       |
|--------------|-------------------------------------------------|----------------------------------------------------------------------------|--------------------------------------------------------------------|---------------------------------------------------------------------------|
| Key features | First modern building code                      | Stricter seismic rules, structural requirements, updated zoning regulation | Introduced performance- based design, seismic- resilience elements | Focused on zoning, inspections, structural safety, permits and incentives |
| Enforcement  | Limited, at the local level; frequent amnesties | Earthquake code mandatory for new buildings                                | All new buildings nationwide; all existing non-compliant buildings | Centralised. Improved inspections                                         |
| Compliance   | Limited. First buildings to be covered          | Mainly in public buildings, frequent amnesties                             | Limited despite a strong code                                      | Tightened                                                                 |

IEA. CC BY 4.0.

Sources: IEA analysis based on Turkish Earthquake Regulation (2007), Turkish Building Earthquake Code (2018), Law on the Transformation of Areas Under Disaster Risk (Law No. 6306).

There  is  a  financing  gap  for  programmes  targeting  the  renovation  of  residential buildings as much of the current focus is on public buildings. In 2023, the government increased the 2019 energy-savings target for public buildings from 15% to 30%. The World Bank and International Bank for Reconstruction and Development invested USD 200 million in the project. The government implemented incentives and support mechanisms for energy efficiency improvements in existing buildings, such as lowinterest  loans  for  thermal  insulation  of  residential  buildings.  Energy  performance certificates  became  compulsory  for  buying  and  selling  property  in  2020,  but  no minimum rating is required. Over two-thirds of households live in buildings constructed before the introduction of the 2011 regulation on the energy performance of buildings.

Furthermore, the Savings Target and Implementation Guide (2024-2030) for Public Buildings explains possible energy efficiency measures and presents three different approaches for investments.  Public  institutions  may  undertake  energy  efficiency investments using their own funds, through energy performance contracts, or by seeking  support  from  national  or  international  projects.  With  the  enactment  of energy performance contract legislation, public institutions and organisations are permitted  to  enter  such  contracts  for  energy-saving  projects  for  up  to  15 years. Furthermore,  MENR  in  2022  launched  a  residential  thermal  insulation  financing scheme  to  support  energy  efficiency  improvements  in  homes.  The  programme offers loans of up to TRY 50 000 ( Turkish liras) per dwelling unit with a 60-month repayment period and a fixed interest rate of 0.99%, helping households invest in energy-saving building upgrades.

The  Ministry  of  Energy  and  Natural  Resources  and  the  Ministry  of  Environment, Urbanization  and  Climate  Change,  with  support  from  the  World  Bank,  jointly developed  the  KABEV  Project  for  renovating  public  buildings  with  a  budget  of USD 200 million. Alongside the KABEV Project, the government also established the KADEV project (addressing earthquake resilience and efficiency) with a budget of USD 250 million, and the KAYEP project (for Solar Energy Power Plant installation) with a budget of USD 450 million. The second phase of the KABEV Project, with a budget of USD 300 million, was initiated by the Ministry of Environment, Urbanization and Climate Change.

New  buildings  must  comply  with  2023  Nearly-Zero  Energy  Buildings  guidelines, focusing  on  energy  efficiency,  thermal  performance,  and  renewable  energy  use. Following a two-year transition period with relaxed rules from 2023 to 2025, from 1 January 2025 a minimum energy performance rating of B is mandatory for all new buildings exceeding 2 000 m 2  of floor area, as well as a minimum share of 10% of renewable energy consumption.

Seismic  and  energy  efficiency  retrofits  should  be  addressed  together.  Türkiye  is highly  prone  to  earthquakes,  and  a  significant  share  of  the  building  stock  is  not earthquake resistant. The February 2023 earthquake struck the southeast regions of the country, resulting in over 53 000 deaths and displacing millions. Another 200 000 buildings  were  heavily  damaged.  The  Turkish  Building  Seismic Code of 2018 updated previous codes and promoted earthquake-resilient construction practices and an earthquake-resistant design. The World Bank found that integrating seismic and efficiency renovations is not only beneficial but often essential.

In  countries with strong regulatory frameworks for buildings renovation, combining energy-efficiency  and  seismic  upgrades  within  the  same  renovation  project  can reduce transaction costs, facilitate co-ordinated investment and extend the useful life of the building. Meaningful energy savings will only be made if the structural integrity is  strengthened.  Additional  benefits  included  shared  labour  and  resources  across both renovation streams, co-ordinated investment planning and an improved payback period  due  to  the  extended  lifetime.  Furthermore,  incorporating  rooftop  solar installations  enhances  energy  security  by  ensuring  continued  power  supply  even when energy systems are disrupted following an earthquake.

Energy  efficiency  upgrades  can  offer  financial  returns  that  help  improve  the bankability of retrofit projects. Combining energy efficiency with seismic upgrades can reduce  transaction  costs.  Seismic  and  energy  efficiency  interventions  are  often implemented separately, however, unless buildings are fully demolished and rebuilt.

## District heating

Türkiye is assessing the role of district heating as a solution for decarbonising space heating, the largest energy  end  use  in  residential buildings. Space  heating represented 60% of residential buildings' demand in 2024, dominated by natural gas (71%), followed by coal (15%) and bioenergy (8%). The latest governmental data available report that district heating capacity stands at 3 500 MW, serving approximately  336 000  housing  equivalents,  primarily  relying  on  geothermal  and waste heat sources. The 2021 buildings and dwelling census found that almost 50% of households used household-level central heating as their primary heating method, and only around 11% used district heating or centralised heating systems for one or more buildings.

While the government aims to establish a functioning heat market to promote the expansion of district heating and cooling systems, Türkiye is still at the early stages when it comes to legislation and policies dedicated to district heating. A draft heating law is being considered, generically targeting the expansion of district heating and the

identification of new settlements, but no further information is available. A 2022 project estimated Türkiye's waste heat assessment potential, which derives from industry (42% of  the  potential),  thermal  power  plants  (40%)  and  commercial  buildings  (18%).  The calculated potential from industry is estimated at 160 000 terajoules/year, enough to heat 3.8 million homes. It would generate USD 735 million savings per year and require an upfront investment of USD 16 billion.

Thermal power plants over 20 MW  must  complete  a waste heat audit by September 2026 to assess potential for district heating and efficiency improvements. Co-generation  plants  are  exempt  from  licensing  if  they  meet  specific  efficiency standards and use energy for self-consumption. To date, 231 certificates have been issued, covering about 703 megawatts electrical (Mwe) and almost 740 megawatts thermal  for  industry  and  buildings,  including  co-generation,  waste  heat  and  micro co-generation projects.

There are 19 geothermal-based district heating systems in Türkiye: the government should look for ways to leverage this renewable source to expand district heating. The district heating network is mostly developed in the western part of the country, where geothermal activity is more abundant, particularly in the Izmir region. Around 90% of Türkiye's geothermal resources are classified as low- to medium-temperature, which is ideal for direct heat applications. The requirements for public buildings, mandating that 10% of energy use of buildings that exceed a specified floorspace footprint should be renewable, could be satisfied by the direct use of geothermal-based heat.

## Energy use in residential space heating by fuel (2024) and share of households by heating system type (2021) in Türkiye

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on IEA (2026), Energy End-uses and Efficiency Indicators; TurkStat (2022), Survey on Building and Dwelling Characteristics, 2021, (accessed in July 2025).

## Transport

In 2024, transport accounted for 29% of total final energy consumption and 24% of energy-related emissions, mainly from road transport. Oil fuels provided 98% of the energy use in transport in 2024, a share which has not changed in the past decade. Of  this,  diesel  fuels  take  up  69%  of  the  consumption.  Energy  use  in  transport  is expected to grow by 17% from 2024 to 2035.

## Energy use by fuel (2024) and growth in the transport sector (20102030 projection) in Türkiye

<!-- image -->

IEA. CC BY 4.0.

Note: On the left-side chart, unmarked fuels include natural gas, electricity and biofuels, respectively 0.8%, 0.5% and 0.5%.

Sources: IEA analysis based on IEA (2025), World Energy Balances; MENR (2022), Türkiye National Energy Plan, (accessed January 2026).

The  Energy  Efficiency  Strategy  2024-2030  outlines  several  key  policies  for  the transport  sector  in  the  medium  term.  The  government  aims  to  shift  towards energy-efficient  modes  of  transport,  notably  by  increasing  the  share  of  rail  and maritime transport, while reducing dependence on road transport. Furthermore, the government is promoting public transport solutions, particularly in urban areas, by developing  multimodal  transportation  options  and  expanding  bicycle  lanes  and pedestrian-friendly pathways.

Türkiye 2026

Türkiye  introduced  special  incentives,  including  tax  reductions,  for  electric  and alternative fuel vehicles to curb fossil fuel consumption. It also signed a Memorandum of Understanding on Zero-Emission Medium- and Heavy-Duty Vehicles, which aims to achieve 100% zero-emission new truck and bus sales by 2040 with an interim goal of  30%  by  2030.  While  electrification  will  be  the  main  decarbonisation  option  for light-duty vehicles and parts of heavy road transport, biofuels produced in Türkiye from waste have the potential to decarbonise various parts of the transport sector, including  heavy  road  transport.  In  2024,  Türkiye  was  amongst  the  four-lowest IEA members  in  terms  of  biofuels'  share  of  energy  consumption  in  the  transport sector,  with  just  0.5%. Given  Türkiye's  abundant  bioenergy  resources,  such  as biogas, this presents a significant opportunity to advance its decarbonisation goals.

## Road transport

In April 2026, there were 17.7 million registered cars in Türkiye, corresponding to a car ownership rate of around 200 cars per 1 000 people. While this figure is lower than any EU country, it is increasing at a fast rate. In 2025, the number of new road vehicles registrations decreased by 8.9% compared to the previous year. With an average age of 14.2 years, the stock of road vehicles is relatively old and inefficient (higher than most EU countries), contributing to higher emissions and air pollution. The share of motorcycles among newly registered vehicles is significant in Türkiye, representing more than one-fifth of new vehicles in December 2025, with the stock of motorcycles growing at a faster rate than passenger cars since 2010. In 2024, Turkish drivers covered 383 billion kilometres, an increase of 43% compared to 2016. Over half of these kilometres were made in passenger cars. Given the demand for shortdistance travel, there is significant potential to reduce reliance on private automobiles by improving urban and suburban public transport systems, such as buses, light rail and metro networks.

## Electric vehicles

Türkiye's electric vehicles (EV) market is nascent and has only begun to expand very recently,  thanks  to  the  creation  of  a  legal  and  policy  framework  for  EV  use  and EV manufacturing and charging infrastructure. The EV sales share grew from 1.3% in 2022 to 7.2% in 2023 and 22% in 2025. From 2024 to 2025, EV sales more than doubled.  The  government's  target  is  for  EVs  to  make  up  35%  of  the  automobile market by 2030 , with a total of 2.5 million EVs on the road, up from 420 000 cars and two/three wheelers in 2025.

Türkiye's  ambitious  goals  in  terms  of  EV  deployment  are  supported  by  the establishment  of  favourable  incentives  for  EVs.  Car  purchases  in  Türkiye  are impacted by the Special Consumption Tax, a one-off tax applied to new vehicles only, ranging from 70% to 220% of the price and based on the engine size. In 2025, Türkiye supported  EVs  with  special  consumption  tax  rates  ranging  from  25%  to  75%, depending on engine power and the vehicle's tax category. In terms of value-added tax (VAT), battery electric vehicles are generally subject to the standard 20% rate. Furthermore,  vehicle  credit  limits  have  been  increased  for  EVs.  Customers  can access a loan of up to TRY 1.75 million (USD 38 400) to finance EV purchases, which is four times the regulated limit for non-EV vehicles. Cities such as Istanbul and Izmir offer parking privileges and licence plate benefits for battery electric vehicles.

## Passenger car registrations by powertrain (2022-2025) and EV stock share, charging points (2025) and targets in Türkiye

<!-- image -->

IEA. CC BY 4.0.

Note: LPG = liquefied petroleum gas. EV charging points for 2025 refer to publicly available chargers; for 2030, the value refers to the sum of AD and DC charging points in the medium scenario.

Sources: IEA analysis based on TurkStat (2025), Motor land vehicles, December 2025, (accessed May 2026); MENR (2024), 2024-2028 Strategic Plan, (accessed in September 2025); IEA (2026), Global EV Data Explorer; EMRA (2026), Charging Network Infrastructure Projection, (accessed August 2026).

Since 2023, the new Türkiye-based EV car manufactured by the automotive company Togg has been driving EV car sales. Established in 2018, Togg began selling its first model,  a  battery  electric  vehicle,  in  March  2023.  It  sold  20 000 units  in  2023, 50 000 in 2024 and 40 000 in 2025, surpassing domestic sales by Tesla and BYD,

with plans to expand production further to one million cars by 2030. Togg created a joint venture with Farasis Energy, a Chinese battery company, in April 2023, securing close collaboration to support beneficial supply chain integration.

To  incentivise  domestic  EV  production,  in  2024  the  government  launched  the High Technology Investment Programme, to which it allocated USD 5 billion, as well as USD 4.5 billion for battery production. The government also aims to attract foreign investment to the EV sector and continues to work with Chinese EV manufacturer BYD on a USD 1 billion investment in a production plant in Türkiye. However, in September 2024,  Türkiye  announced strict conditions on the import  of plug-in  hybrid  EVs from certain countries, including the People's Republic of China (hereafter, 'China').

A key strategy to increase the roll-out of EVs is the installation of public EV charging points  around  the  country.  Türkiye's  Medium-Term  Program  (2025-2027)  and 2024-2028  Strategic  Plan  emphasise  strengthening  EV  charging  infrastructure, integrating smart grids and ensuring widespread access to public charging stations. The country implemented the Charging Service Regulation (2022), which introduced licensing  procedures  and  operational  rules  for  charging  networks.  Following  this Regulation, the number of licensed charging operators rose from 5 in 2021 to around 170 in 2024. By March 2026, Türkiye had installed almost 42 000 charging points. The goal is to install 100 000 EV charging points by 2028 by adding 20 000 units per year from 2024.

## Rail, air and maritime transport

Transport  planning,  involving  railway  and  maritime  transport,  can  contribute  to enabling modal shift from road transport to less energy-intensive modes of transport. The  2053  Türkiye  National  Transportation  and  Logistics  Master  Plan  identifies alternatives  to  road  and  air  transport,  such  as  rail  transport.  Türkiye  has  heavily invested in rapid and high-speed railway lines, increasing the railway network from almost 12 000 kilometres (km) in 2010 to 14 000 km in 2024, 16% of which is highspeed lines. The government plans to expand the high-speed network further.

Air  transport,  notably  domestic  transport,  has  increased  rapidly  over  the  past  two decades, partly driven by deregulation and lower taxes. Continuous policy support for air transport development boosted passenger and freight air travel, mainly domestic. Türkiye is a major hub for international aviation: it aims to reduce the carbon footprint

of its airports by introducing various criteria on energy management, energy efficiency and sustainability to accelerate investments in sustainable energy resources and to create the appropriate infrastructure for the supply of green energy to the terminal facilities and apron areas.

Sustainable aviation fuels (SAFs) are essential for Türkiye's 2053 net zero emission target and aviation sector decarbonisation. Legislation regulating SAF production and supply  was  introduced  in  2025,  aligning  Türkiye  with  International  Civil  Aviation Organization  and  European  Commission  goals.  By  2030,  all  airlines  must  cut emissions by 5% using SAFs. Fuel producers and suppliers are investing, securing international agreements and developing materials to meet mandatory usage rates effective from 2026. Efforts also continue to expand domestic Carbon Offsetting and Reduction Scheme  for  International Aviation-compliant materials and  explore alternative feedstocks.

The maritime sector, which accounts for 0.8% of transport sector energy demand, offers potential for improved energy efficiency and emissions reductions. The 2023 IMO Strategy on Reduction of GHG Emissions from Ships targets a 40% carbon intensity reduction by 2030 (compared to 2008) and net zero emissions 'by or around  2050'.  Maritime  passenger  transport  is  mostly  used  for  urban  passenger transport in Istanbul, Izmir and Çanakkale provinces. The government's Transport and  Logistic  Master  Plan  foresees  the  construction  of  38 new  ports  for  freight transport by 2053. Alternative fuels are one of the key measures to ensure that the GHG emissions reduction targets are achieved.

By  the  end  of  2025,  Türkiye's  fleet  of  vessels  over  1 000 gross  tonnage  reached 51.8 million  deadweight  tonnage,  ranking  it  11th  globally,  with  an  average  age  of 26 years. To improve energy efficiency, the Ministry of Transport and Infrastructure's Directorate General for Maritime Affairs provides incentives to build newer and more efficient  ships  by  scrapping  older  vessels.  The  financial  support  for  constructing fossil-fuel powered ships to replace scrapped vessels is set at 1.5 times the scrap cost per tonne. If the newly built ship uses an alternative environmentally friendly energy source, liquefied natural gas (LNG) or a hybrid system, however, the support increases to 2.5 times the scrap cost per tonne. Additionally, shipowners who convert the main engines of an existing vessel from fossil fuels to an alternative eco-friendly energy source will receive a grant covering 25% of the transformation cost.

Under the Regulation on Issuance of Green Port Certificates for Port Facilities (Official Gazette, 18 November 2023, No. 32373), new port facilities must meet green port standards, while existing facilities can choose to comply. Applicants for a Green Port Certificate must meet energy-efficient requirements, including operating at least 50% of  main  cargo  handling  equipment  on  electricity  and  providing  shore-side  power infrastructure at a minimum of one terminal, quay or pier.

## Electricity

Türkiye's electricity demand is the fastest growing among IEA countries. It grew at an average annual rate of 4.5% from 2005 to 2024, driven by a fast-growing economy and population. Electricity demand grew by 3% from 2024 to 2025, largely driven by a  surge  in  cooling  needs  during  an  intense  heatwave.  Türkiye's  power  and  heat generation  sector  is among  the  most  carbon-intensive  among  IEA  countries (the sixth-highest in 2024) measured in grammes of carbon dioxide per unit of kilowatt hour (g CO2/kWh) generated. Although Türkiye has improved the carbon intensity of power generation over the past decade (-7.3% from 2015 to 2025), it continues to trail behind several IEA Member countries: as of 2025, Türkiye had reached the average carbon  intensity  observed  by  IEA  countries  in  2015,  around  420 g CO2/kWh. Nevertheless, Türkiye's CO2 intensity of electricity generation remains lower than that of other countries with significant coal-fired power, such as Poland, while exceeding the level in Czechia.

## Carbon intensity of electricity generation and projections in selected countries and IEA average, 2015-2030

<!-- image -->

IEA. CC BY 4.0.

Source: IEA (2025), Electricity 2026.

In 2025, coal accounted for 33% of electricity generation and natural gas for 23%. In  the  same year, coal recorded a decline (-0.9% y-o-y) and natural gas a strong increase  (+24%  y-o-y).  Variable  renewable  energies  such  as  wind  and  solar photovoltaics (PV) are increasing: solar generation grew at a record speed (+24% from 2024 to 2025), supported by the Renewable Energy Resource Areas tender mechanism. Among other renewable energies, hydro, in 2025, declined by 23% yo-y  because  of low  rainfall  and  subsequent  droughts, while  geothermal  reached almost 12 TWh.

Türkiye's  National  Energy  Plan  foresees  electricity  generation  increasing  25%  by 2030 and by 40% by 2035, compared to 2025 levels. As for solar PV, Türkiye already surpassed the level of electricity generation expected by 2025 in the TNEP, reaching 38 TWh. Under the TNEP, this will grow to 52 TWh by 2030. Wind is in line with the projections, reaching over 39 TWh in 2025, and the plan projects a growth to 53 TWh in 2030. Nuclear will enter the market over the next years, later than initially planned.

## Electricity demand and generation growth

The TNEP forecasts electricity demand to grow until 2035 but at a slower pace than in the preceding decades, driven by demand from industry and services. In residential buildings,  for  example,  demand  increased  by  14%  from  2023  to  2024  driven  by greater use of air conditioning and electric appliances and electrification of heating and  cooking  in  some  regions.  The  TNEP  projects  electricity  demand  to  reach 510 TWh in 2035. End-use sector electrification is expected to reach 25% in 2035, from 22% in 2024. Installed generation capacity is expected to increase by around 60%  from  2024  to  2035.  The  TNEP  outlines  at  what  stage  capacity  from  each technology will be introduced, as well as shares and capacities by technology over time. Türkiye's peak electricity load has been rising steadily in recent years, driven primarily by increased summer cooling demand and economic and population growth, with peak demand reaching a new high of 59.5 GW during a summer heatwave in July 2025.

The TNEP foresees strong growth in renewable energy generation, which is crucial to  achieving  Türkiye's  climate  targets,  as  it  is  expected  to  contribute  to  55%  of electricity generation in 2035 (up from 43% in 2025). Renewable energy capacity is expected to grow to 65% (up from 59% in 2024). Nuclear power will provide over 10% of  total  electricity  supply  by  2035  once  the  Akkuyu  nuclear  power  plant  is  fully operational, according to the TNEP.

## Electricity market operation

Türkiye  is  one  of  the  largest  electricity  markets  in  Europe  and  is  poised  to  keep growing. The sector's key challenges are boosting domestic production to cut reliance on imported fossil fuels, meeting rising energy demand, keeping prices stable and affordable, and supporting renewable integration (Focus Area 1).

Liberalisation of the electricity market began in 2001 with the Electricity Market Law, which was updated in 2013. Initially, the Electricity Market Law introduced elements of competition  and  unbundling  of  the  vertically  integrated  market  structure,  and  the generation, distribution and retail markets were opened to private sector investment. The Electricity  Market  Law  is  broadly  consistent  with  EU  regulations,  notably  in areas  such  as  market  liberalisation,  aggregator  participation  and  balancing. However, regulatory harmonisation is still underway, particularly on topics such as cross-border integration and consumer rights. EÜAŞ, the state -owned Electricity Generation Corporation, operated 50% of capacity in 2010: by late 2024 its share had dropped to 19%, as independent power producers accounted for more than 80% of installed capacity.

Prosumers,  known  in  Türkiye  as  unlicensed  producers,  are  consumers  producing electricity to satisfy their own needs. They do not require a licence from the Energy Market  Regulatory  Authority  (EMRA)  and  provide  a  growing  share  of  electricity generation.  This  framework  is  designed  to  encourage  small-scale,  decentralised energy production, especially from renewable sources such as solar PV and wind. Unlicensed producers are exempt from obtaining a generation licence, simplifying the process for households, co-operatives and  small businesses. The  electricity generated can be used for self-consumption and the surplus energy can be fed into the  grid  subject  to  a  maximum  limit.  Unlicensed  producers  are  compensated  by means of net metering or offsetting mechanisms.

The process is governed by the Unlicensed Electricity Generation Regulation issued by  EMRA.  Producers  are  obliged  to  comply  with  technical  standards  and  safety regulations.  Installed  capacity  is  typically  limited  to  25 kilowatts  for  residential systems, though higher capacities are allowed for commercial and industrial users operating  under  specific  conditions.  Solar  PV  has  benefited  the  most  from  the unlicensed generation regime. It led to a boom in rooftop solar PV installations in the residential and agricultural sectors. Solar PV accounted for 97% (or almost 23 GW) of unlicensed capacity at the end of 2025.

## Unlicensed installed capacity by technology (2025) and solar capacity by licence (2022-2025) in Türkiye

<!-- image -->

IEA. CC BY 4.0.

<!-- image -->

Sources: IEA analysis based on EMRA (2025), Annual Report 2024, (accessed in January 2026);

Note: Unlicensed capacity refers to the capacity produced by prosumers. EMRA (2026), Monthly Report January 2026, (accessed in May 2026).

As  of  mid-2025,  Türkiye  had  15  electricity  interconnections  with  neighbouring countries. Interconnections are managed by the transmission system operator, the Turkish  Electricity  Transmission  Company  (TEİAŞ), and  the  amount  of  electricity trade  fluctuates  from  year  to  year  depending  on  hydro  seasonality  variations. Volumes are small compared to overall generation.

TEİAŞ oversees transmission activities and operates the real-time management and the  balancing  and  ancillary  services. In  2013,  TEDAŞ ,  the  state-owned  electricity distribution company, was unbundled into 21 regional electricity distribution companies, all of which were privatised by the end of that year. The retail market, with 21 privately owned  retail companies, reflects this regional structure. Energy Exchange Istanbul operates the wholesale electricity market, including the day-ahead, the intraday and the futures market.

Türkiye  introduced  an  electricity  capacity  mechanism  in  2018,  primarily  to  ensure system  reliability  and  resource  adequacy  in  the  electricity  market.  The  capacity mechanism was designed to guarantee payments to power plants that meet certain criteria,  ensuring  they  remain  available  to  generate  electricity  when  needed.  The mechanism rewards eligible power plants with monthly capacity payments. In 2024, TEİAŞ allocated TRY 13 billion (approximately USD 285 million) through the capacity mechanism,  up  from  USD 92 million  in  2023.  Natural  gas  has  received  the  most support  since  2022,  accounting  for  64%  of  capacity  payments  in  2024,  with  coal accounting for the remainder.

## Grid reliability and resilience

Grid-related outages impose costs on the economy and are generally the result of technical  failures,  for  example  those  associated  with  ageing  equipment.  Only  a relatively  small  but  consistent  share  (~10%)  can  be  attributed  to  uncontrollable nature-related factors, such as extreme weather events and earthquakes.

Türkiye's average temperature is rising and is likely to continue to do so, boosting energy  demand  for  cooling  in  the  upcoming  decades.  Although  total  annual precipitation  across  the  country  has  neither increased  nor  decreased  significantly, greater regional and seasonal disparities are projected. The incidence of extreme precipitation  patterns  involving  droughts  and  heavy  rainfall  with  flash  floods  is expected to increase. Overhead transmission and distribution lines are vulnerable to climate  hazards,  such  as  wildfires  and  floods.  Underground  transmission  and distribution cables represent an alternative but require higher upfront costs and are exposed to other risks, such as heatwaves. The National Climate Change Action Plan proposes  incorporating  climate  change  impacts  into  plans  for  planning  renewable energy resources. Updates to the Action Plan could highlight energy sector resilience and help raise the climate resilience profile in the TNEPs, which currently focus on climate change mitigation.

## Electricity tariffs

A large share of consumers, under a certain consumption threshold, are subjected to regulated electricity tariffs. Tariff regulation depends on annual consumption, which determines the eligibility  threshold.  Consumers whose electricity use exceeds this threshold  are  classified  as  eligible  consumers  and  may  negotiate  bilateral  supply contracts.  The  others  remain  on  regulated  tariffs  (on  retail  tariffs  or  on  last-resort supply tariffs) determined by the regulator, EMRA. Given the volume of residential consumers' consumption, they generally qualify for regulated tariffs, while industrial users generally exceed the threshold and qualify as eligible consumers, allowing them to choose their electricity supplier and negotiate a contract.

Based on voltage levels and usage types, there are five different levels of regulated tariffs, distinguishing between residential and industrial consumers, agriculture and public/private or commercial  use.  EMRA  is  progressively  moving  towards  a cost-based tariff system, pushing smaller consumers to enter the liberalised market.

In 2025, EMRA determined the limit at 750 kWh annually. In 2018 and 2021, rising electricity  prices  led  several  suppliers  to  terminate  bilateral  contracts  with  eligible consumers  as  they  were  unable  to  meet  their  obligations.  As  a  result,  many consumers gave up their eligible status and returned to regulated pricing.

Measured at constant prices and purchasing power parity (PPP), residential electricity tariffs  in  Türkiye  have  been  lower  than  the  OECD  average  since  2023.  Türkiye introduced  measures  in  2022  to  protect  consumers  from  energy  price  inflation. Policies included VAT reductions and direct payments to consumers with a focus on the less well-off. Direct payments to consumers cost around TRY 10 billion a year, with  vulnerable  households  receiving  extra  compensation.  Subsidies  were  mostly lifted in February  2025  for  large  residential  consumers,  including  EV  owners, consuming over 417 kWh per month (equivalent to a large household or a household with several air conditioners).

## Industry and residential electricity prices in Türkiye and the OECD, 2021-2024

<!-- image -->

IEA. CC BY 4.0.

Notes: The residential price components refer to a low-tier residential consumer. The 2024 industry price is not yet available.

Sources: IEA analysis based on IEA (2025), Energy Prices; EMRA, Electricity Market Annual Sector Report, (accessed in July 2025).

Until 2023, the largest price component for residential consumers was the energy cost or  generation  fee,  which  mainly  reflects  the  cost  of  energy,  includes  a  renewable support component and others. The generation fee declined between 2022 and 2024, when it was lower than the network fee. The network fee includes distribution and

Türkiye 2026

transmission fees. EMRA operates a price equalisation mechanism, which enables cross-subsidisation between the 21 Turkish regions, to ensure a unitary nationwide distribution tariff. The taxes and levies paid by residential consumers in Türkiye are among the lowest in Europe, to reduce the burden on consumers. Given that industrial consumption  is  generally  above  the  eligibility  threshold,  industry  prices  are  not regulated and are, on average, higher. The largest component in the industry price is the energy cost (75% in 2024). EMRA announced tariff increases in April 2025.

## Renewables

In  2024,  the  2035  Renewables  Roadmap  announced  more  ambitious  targets  for renewable energy, setting a goal of 120 GW for installed solar PV and wind capacity combined by 2035. According to data from TEİAŞ , there were 32.7 GW of installed solar  PV  and  wind  by  the  end  of  2024,  suggesting  an  almost  fourfold  increase by 2035. By 2035, generation from solar and wind is expected to exceed hydropower output, although this remains highly sensitive to drought conditions.

Introduced in 2005, the Renewable Energy Support Mechanism or YEKDEM provides financial support to licensed renewable energy projects by means of feed-in tariffs and local content premiums. Producers receive extra incentives for using locally made equipment and the rate depends on the energy source. Between 2011 and 2023, around  TRY 65 billion  (USD 1.5 billion)  was  allocated,  supporting  nearly  half  of Türkiye's installed renewable capacity. To complement YEKDEM, the government introduced the Renewable Energy Resources Areas (YEKA) tender programme in 2016 to develop large renewable energy projects via a competitive bidding process open to privately owned companies. YEKA tenders will switch to a competition-based model to accommodate the new, ambitious target for renewable capacity, including a super permission mechanism to cut permitting times to less than two years. Beyond domestic support schemes and competitive tenders, Türkiye is also pursuing largescale  renewable  energy  projects  through  international  partnerships,  including  an agreement with ACWA Power to develop 5 GW of solar and wind capacity.

## Solar PV

Türkiye has experienced considerable growth in solar energy over the last two years and  has  surpassed  its  target  for  2025.  In  2025,  solar  contributed  to  38 TWh  of electricity generation,  reaching  over  10%  of  the  total.  This  increase  in  solar development  has  led  to  higher  renewable  energy  installed  capacity  and  record expansion in 2024 when solar energy accounted for 90% of the total new capacity,

with  more  than  two-thirds  represented  by  unlicensed  facilities  serving  industrial needs. According to the Long-Term Climate Strategy, the largest capacity additions will come from solar PV, with installed capacity increasing from 20 GW in 2024 to 77 GW by 2035. According to IEA projections, Türkiye is among the seven countries that will contribute the most to Europe's cumulative installed capacity of solar PV up to 2030. Türkiye enjoys around 110 days of sunlight per year which, combined with its large surface area, gives it a higher solar energy potential than most of Europe. Most existing solar farms are in the southern regions owing to the higher irradiation levels. Türkiye is already home to one of the world's largest solar farms, the 1 350 MW Kalyon  Karapinar  Solar  Park,  located  in  the  central  Konya  region,  which  began operations in 2023.

Türkiye  is  the  largest  solar  panel  manufacturer  in  Europe,  well  positioning  it  to accelerate  deployment  of  both  utility-scale  and  distributed  solar  PV  to  reach  its targets.  Türkiye  is  one  of  the  countries  which  has  introduced  high  import  taxes (25 USD/kg)  and  antidumping  duties  (25  USD/m 2 )  on  solar  modules  from  China, starting in 2017. In 2023, Türkiye set a minimum import price per kilogramme for solar cells  and  for  blue  wafer  to  support  domestic  cell  manufacturers.  The  price  was updated yearly and raised to 170 USD/kg in July 2025.

In 2024, the Ministry of Industry and Technology launched the HIT-30 programme. This investment initiative provides comprehensive support and incentives for projects focused  on  high-priority  technology  areas,  with  customised  solutions  designed  to address  specific  requirements.  Solar,  wind  and  battery  storage  technologies  are designated as priority  areas  in  green  energy,  and  qualifying  investments  in  these sectors will be eligible for support under HIT-30. The HIT-Solar call aims to develop cell production capabilities within Türkiye's panel production industry. Total support budget amounts to USD 2.5 billion, with the objective of establishing an annual cell production capacity of 15 GW, which includes investments in high local content and R&amp;D centres. The programme supports five investments in cell production beginning at the ingot stage, each with a minimum annual capacity of 5 GW.

Coastal Law No. 3621 was amended in May 2024 to enable the establishment of renewable power plants on reservoirs, dams, and both artificial and natural lakes, subject to conditions defined in the law. Several small-capacity floating solar power plants have been constructed and are expected to become more common.

Expanding  rooftop  solar  PV  while  decentralising  energy  production  and  reducing reliance  on  subsidies  offers  a  means  to  increase  solar  penetration.  Based  on estimations, rooftops in Türkiye hold the potential to install 120 GW of solar PV, which

would allow the country to meet 45% of electricity demand from rooftop solar alone. The three provinces with the largest solar rooftop potential are home to the most populous Turkish cities of Izmir, Istanbul and Ankara.

Despite  the  potential  benefits  from  rooftop  solar  over  large-scale  solar  parks, deployment  faces  regulatory  and  practical  hurdles.  In  2019,  Türkiye  introduced monthly  net  metering,  allowing  residential  solar  users  to  sell  excess  power  at consumer rates. Adoption remains slow, however, owing to lengthy processes, which require approval from multiple authorities and a 27-week timeline from application to installation. Türkiye is launching reforms and investments to meet its 2035 wind and solar PV goals. With the legal changes on 24 July 2025, regulations are now finalised, reducing the permitting process for wind and solar plants from about 48 months to 18 months. Improving application processes and mandating rooftop solar for new and public buildings could help Türkiye meet its energy and self-sufficiency targets while allowing consumers to generate affordable electricity.

## Wind

Wind accounted for 11% (39 TWh) of total electricity generation in 2025, making it the second-largest source of renewables after hydro power. Wind capacity is projected to increase  from  13 GW  in  2024,  to  43.1 GW  in  2035.  All  currently  installed  wind  is onshore,  with  the  highest  wind  generation  output  found  in  the  western  regions, including Izmir, Balikesir, Istanbul and  Çanakkale.  Promoted  by  government incentives, Türkiye developed a strong supply chain with more than 70 companies involved  in the manufacturing  of  wind  turbine  generators  and  onshore  wind components. It is Europe's fifth-largest manufacturer of wind technology and exports 75% of its production.

In 2024, an Offshore Wind Roadmap for Türkiye published estimates of the technical capacity of offshore wind at 75 GW. Potential is the highest along the west coast where wind speeds exceed 9.5 m/s. This region is also home to the country's most populous areas and demand centres, making offshore wind a strategic solution for meeting energy needs without extensive new transmission infrastructure. The most promising  areas  are the  Aegean  Sea  near  Çanakkale  and  Ayvalık,  the  Sea  of Marmara, and parts of the Black Sea, where floating wind technology is suited for deeper  waters.  Türkiye's  robust  supply  chain,  competitive  ports  and  proven shipbuilding  capabilities  position  it  well  to  develop  domestic  offshore  wind  and supply regional projects. Measures to lower market and project risks would help the offshore sector grow.

In 2018, Türkiye announced plans for an offshore wind farm with a capacity of up to 1.2 GW. The tender was not completed owing to a combination of tender-specific and macroeconomic  conditions  which  reduced  investor  interest.  The  Offshore  Wind Roadmap recommends developing derisking mechanisms, such as guarantees and hedging,  to  help  access  lower  cost  international  finance.  Furthermore,  improving permitting  procedures  and  site-specific  data  on  wind  and  undersea  conditions  is essential. The government has invested in preliminary site surveys, inspired by the Danish model, which will reduce risks for the first offshore projects.

## Geothermal

Türkiye is one of the world's ten largest consumers of geothermal energy. In 2024, geothermal accounted for 2.4% (119 PJ) of total final energy consumption. It is mainly used for heating (directly and through district heating networks) in the tourism/wellness  and  agriculture  sectors,  as  well  as  in  electricity  generation. Geothermal accounted for 4.2% (74 PJ) of energy consumption in buildings in 2024, mainly applied as direct heating for residential and commercial use.

## Geothermal capacity additions across leading countries (2013-2023) and geothermal share in electricity generation in Türkiye (2010-2024)

<!-- image -->

Sources: IEA (2025), Electricity Information; IEA (2024), The Future of Geothermal Energy; IEA (2025), World Energy Balances.

Of  the  25 district  heating  systems  installed  in  Türkiye,  19  are  geothermal  based. These are in the west of the country,  which  has  the  greatest  geothermal  activity. Globally, Türkiye added the most geothermal power capacity between 2013 and 2023. Over the same period, electricity generation from geothermal grew

more than eightfold, from 1.4 TWh to 11 TWh, and reached 3.1% of total electricity generation  in  2024.  Türkiye,  which  views  geothermal  as  a  high-potential  energy resource to reduce import dependency, plans to increase the capacity of geothermal and biomass to 5.1 GW by 2030, from 3.9 GW in 2024.

Geothermal energy offers significant potential as a dispatchable and flexible source of clean electricity. It can replace fossil-fuel based heat generation in co-generation plants or  boilers.  Expanding  and  leveraging  domestic  geothermal  resources  could  reduce Türkiye's reliance on coal for industrial processes as well as in electricity generation. Minimising  drilling  costs,  which  constitute  60-80%  of  total  construction  costs,  could increase private investment appetite and tap into Türkiye's geothermal resources. In addition, the 12th Development Plan intends to increase geothermal R&amp;D activities.

Several schemes are in place to derisk investment costs for geothermal exploration and  drilling.  A  Risk-Sharing  Mechanism  provides  partial  coverage  of  exploration drilling costs in case of unsuccessful wells. A total of USD 37 million is available under the mechanism, funded by a grant from the World Bank's Clean Technology Fund. Second, exploration studies led by the General Directorate of Mineral Research and Exploration have been ongoing since 2005. The state-led discoveries, in combination with  private  sector  activities,  increased  Türkiye's  apparent  heat  capacity  from 3 000 megawatt  hours  (MWh)  to  40 000  MWh  in  2023.  Since  2008,  a  total  of 103 fields, 16 of which are suitable for electricity generation, have been transferred to private investors through tenders which came into effect with Law No. 5686.

According to government sources, 78% of geothermal potential sits in the western part of the country, close to industrial and consumer demand centres. About 90% of resources are low and medium temperature, suitable for direct applications (heating, thermal tourism and industrial applications); the remaining 10% is suitable for indirect applications (electricity generation). Areas with high geothermal resources are linked to volcanic activities, which makes this energy infrastructure vulnerable to earthquakes, and should be considered in the government's expansion plans.

## Nuclear power

Nuclear  power,  part  of  Türkiye's  national  energy  discussion  for  more  than  half  a century,  is  now  becoming  a  reality.  At  the  2024  United  Nations  Climate  Change Conference (COP29), Türkiye joined more than 30 countries as a signatory to the Declaration  to  Triple  Nuclear  Energy  Capacity.  The  TNEP  envisages  7.2 GW  of nuclear power capacity by 2035. Türkiye developed the full scope of the institutional, regulatory and legal infrastructure to support and oversee its nuclear programme and sees the development of its ambitious nuclear power programme as a low-carbon tool

to: increase energy independence by reducing fossil fuel imports while strengthening energy security; support grid stability and provide part of the flexibility required by the rise of the share of variable wind and solar that supports the country's decarbonisation and  electrification goals;  and  develop  a  local  nuclear  industry  and  expertise supporting potential future participation in international nuclear supply chains.

The Akkuyu project is based on a unique structure to support the launch of the nuclear programme. In 2010, Türkiye and the Russian Federation (hereafter, 'Russia') entered into an intergovernmental agreement to construct the Akkuyu nuclear power plant with four units of 1 200 MWe each and utilising the VVER-1 200 pressurised water reactor design. Situated on the south-eastern coast of Türkiye along the Mediterranean Sea, first nuclear concrete was poured in 2018. The initial plan projected commissioning of the first unit in 2025, with a total estimated cost of USD 20 billion. Due to project delays, however, the first unit is now expected to be commissioned in 2026, with subsequent units  following  annually.  The  expected  service  life  of  the  reactors  is  60 years, extendable up to 80 years.

## Under development and targeted nuclear capacity and share in electricity generation in Türkiye, 2026-2053

Source: IEA analysis based on MENR (2023), TNEP, (accessed January 2026).

<!-- image -->

This project, which is led and financed by Rosatom, is based on a 'build-own-operate' model. The owner and operator is Akkuyu Nuclear Joint Stock Company (Akkuyu Nuclear JSC), currently fully owned by Rosatom. Rosatom will remain the majority owner of Akkuyu Nuclear JSC and will provide the fuel during the entire lifetime of the

plant. The spent fuel will be stored on site during the operation of the plant, and the operator will contribute to a secured fund to finance radioactive waste management and decommissioning.

The Turkish Electricity Trade and Contracting Corporation ( TETAŞ ) secured a power purchase agreement that would allow it to purchase a guaranteed 70% of the power generated by the first two units, and 30% of the other two units, over a 15-year period. According to Decree Law No. 703, published in Official Gazette No. 30473 (bis) on 9 July 2018, TETAŞ and EÜAŞ were merged under EÜAŞ. The duties, authorities and  responsibilities  previously  held  by  TETAŞ  are  now  carried  out  by  EÜAŞ. Electricity  is  to  be  purchased  at  a  weighted  average  price  of  0.1235 USD/kWh, exclusive of VAT. During this period, excess electricity will be sold by Akkuyu Nuclear JSC to the market and after this 15-year period all the output will be sold on the electricity market.

The  unique  project  structure  allowed  Türkiye  to  secure  financing  for  the  project without requiring Turkish state funds or debt, while offering a risk-sharing mechanism approved by the parties involved. Construction and operational risks are entirely with Rosatom  and  its  subsidiaries.  With  the  power  purchase  agreement  covering approximately half of the electricity produced during the first 15 years of operation, both sides are partially exposed to electricity market risk. As the power purchase agreement  was  negotiated  in  US dollars,  this  exposes EÜAŞ to a  significant exchange rate risk, especially considering the depreciation of the Turkish lira since the signature of the intergovernmental agreement underlying this project.

Efforts were made to ensure a degree of localisation and the development of a local workforce  and  expertise.  According  to  the  agreement,  Turkish  engineers  are expected to account for 20% of the technical staff at the start-up of the plant. This is made  possible  by  an  ambitious  training  programme  supported  by  both  sides. A minimum of 40% of the construction work is expected to be carried out by Turkish companies. It is estimated that, so far, 57% of the project budget has been spent in Türkiye (e.g. for material, equipment, services, salaries, etc.).

Two other large-scale nuclear power plant projects are under discussion, mainly in a government-to-government format. The Turkish government aims for these subsequent projects to be structured in a way that increases localisation and Turkish industry involvement and control over the plant compared to the Akkuyu project. Yet it is also a priority to have a viable financing scheme that does not place an excessive burden on the public budget or create debt.

Türkiye's second nuclear power plant, planned to be built in the Sinop province, would allow it to meet the goal of 7.2 gigawatts electrical (GWe) of nuclear power by 2035 and, depending on the type of reactors chosen and the number of units, to further  add  nuclear  capacity  to  the  electricity  mix.  The  environmental  impact assessment decision and site approval for a nuclear power plant at Sinop site was granted  and  Türkiye  is  currently  in  discussions  with  potential  vendors  for  this project. A third nuclear power plant is expected to be located on the Black Sea coast in  the  Thrace  region,  north-west  of  Istanbul.  Intergovernmental  discussions  with vendors and investors are ongoing.

Small modular reactors (SMRs) offer potential for greater involvement of the private sector and to decarbonise hard-to-abate sectors. SMRs are gaining global interest for their  potential  for  flexibility,  lower  upfront  costs,  shorter  deployment  times,  and suitability for industrial applications and hydrogen production. Across the globe, more than 70 SMR concepts are under active development in more than 30 countries, with a variety of maturity levels and deployment plans. Türkiye plans to build 5 GW of SMR capacity as part of its mid-century target for nuclear power. Discussions with several SMR vendors  have  been  initiated  and  the  government  is  preparing  an  incentive mechanism for the deployment of SMRs. These projects are likely to be driven by the private industrial sector in line with recent developments in other OECD countries where industry is financing SMR projects to secure a supply of power and/or heat.

## Fuels

Fossil fuels provide over 80% of Türkiye's primary energy: much of this energy is imported and energy imports were equivalent to 11% of Türkiye's GDP in 2022. Even with  projected  increases in domestic coal and natural gas production, Türkiye will continue efforts to decrease its dependence on imports and vulnerability to market volatility and price fluctuations in the future. Türkiye plans further investments in fossil fuel exploration and production activities, including non-conventional resources such as shale oil and methane gas. Oil and gas exploration and production account for over 54% of the TRY 260 billion (USD 5.7 billion) investment in the energy and mining sector announced in the 2025 investment programme.

## Total energy supply and share of production by fuel in Türkiye, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: EJ = exajoule; TES = total energy supply.

Source: IEA (2026), World Energy Balances.

## Oil

Türkiye is a net importer of both crude oil and oil products. While it is increasing its efforts to expand oil production in the Gabar Mountain region, dependence on crude oil imports remained constant at almost 90% of total energy supply (TES) in 2024. Its main trading partners in 2024 were Iraq and Russia, together accounting for 72% of its imports.

## Türkiye's crude oil and oil products import by country, 2021-2024

<!-- image -->

IEA. CC BY 4.0.

Source: IEA (2026), Oil Information.

The opening of the STAR refinery in late 2018 added 214 kb/d to Türkiye's crude processing capacity but also contributed to an increase in crude oil imports. While the commissioning of the refinery significantly reduced oil products import dependency between  2019  and  2020,  gross  imports  are  increasing,  reaching  approximately 580 kb/d in 2024, or the equivalent of 2018 levels. Oil remains the largest energy source, accounting for 35% in total final energy consumption in 2024, and was the largest  source  in  TES,  at  29%.  Oil  product  demand  and  final  consumption  have remained relatively constant over the years, with mainly consumption from transport showing an upward trend.

The transport sector is the main consumer of oil products, followed by industry and buildings. Türkiye is one the world's largest markets for LPG in transport, with 30% of registered cars fuelled by LPG. This is reflected in the high share of LPG in the total oil product demand of 15%, or 131 kb/d in 2024, with domestic demand largely met through imports.

## Natural gas

Natural gas plays a major role in the Turkish energy system: it accounted for over one-quarter of TES in 2024, with demand amounting to 53 bcm. Natural gas, largely imported  from  Russia,  is  used  mainly  in  the  buildings  (65%  of  TFEC  in  2024)  and industry (34%) end-use sectors, with buildings' use predominantly for heating. Natural gas also fuelled 23% of electricity generation in 2025, although the 12th Development Plan projects a drop in natural gas-fired electricity generation to 15% of output in 2028.

## Natural gas production

Recent investments in offshore exploration have resulted in several discoveries. The Sakarya gas field in the Black Sea, which was discovered in 2020, is owned and operated by Turkish Petroleum Corporation, the state-owned oil and gas company. The  gas  field  will  deliver  16.5 bcm  per  year  at  full  capacity,  fulfilling  more  than  a quarter of domestic consumption (at 2024 levels). The government provides support for  the  development through tax benefits and exemptions. The field began its first phase of operations in 2023, gradually ramping up production for Phase 2 to start in 2026.  Expected  daily  production  in  2026  is  20 million  cubic  metres  (mcm)  and Phase 3 is expected to bring total production to 45 mcm/d by 2028. As of mid-2025, Türkiye's  Black  Sea  proven  natural  gas  reserves  amounted  to  785 bcm,  primarily attributable to discoveries in the Goktepe-3 and Sakarya gas fields.

## Natural gas production in Türkiye, 2018-2025

<!-- image -->

Source: IEA (2026), Monthly Gas Data Service.

## Natural gas infrastructure

Türkiye produces natural gas and imports from abroad via long-term purchase contracts with Algeria, Azerbaijan, the Islamic Republic of Iran and Russia, as well as spot and long-term LNG imports. The country is crossed from east to west by the Trans-Anatolian Natural Gas Pipeline (TANAP), part of the Southern Gas Corridor delivering gas from Azerbaijan to Europe. TANAP's import capacity is 16 bcm and there are plans to double it  by  2028. The Blue Stream Gas Trans-Black Sea pipeline from Russia also crosses Türkiye,  with  an  annual  import  capacity  of  16 bcm.  By  December 2024,  Russia  was Türkiye's largest source of natural gas imports. The Trans-Adriatic Pipeline connects to TANAP and enables export to Europe of about 10 bcm annually.

In  May 2024, Türkiye and Azerbaijan signed a co-operation agreement to expand pipeline capacity, including the South Caucasus Pipeline and potentially TANAP, to enhance  exports  to  Europe.  Türkiye  is  also  connected  to  regional  gas  networks through several interconnections, including links with Greece, Bulgaria and the South Caucasus, as well as planned projects to expand supply routes. The TurkStream pipeline  system  has  a  total  capacity  of  31.5 bcm,  supplying  both  Türkiye  and European markets.

Türkiye 2026

Türkiye operates five LNG terminals, including three floating storage regasification units. LNG accounted for 24% of imports in 2024, declining due to increased domestic production.  Türkiye's  natural  gas  storage  capacity  reached  5.8 bcm  in  2024, equivalent to 11% of demand in 2024. Capacity is expected to increase to 13 bcm by 2028, driven mainly by the expansion of the Tuz Gölü facility, providing high injection and withdrawal rates.

## Market structure

BOTA  is the main importer  and  retailer  of  natural  gas.  It  also  operates  the  gas Ş transmission system. An amendment to the Law on Organized Industrial Zones from April  2023  re-emphasised  the  need  for  legal  unbundling,  by  separating  BOTA Ş ' responsibilities  for  import,  transmission  and  distribution activities  into  distinct  legal entities. In 2024, BOTA Ş provided almost all the country's total natural gas supply. Distribution system operators carry out their activities under licences conferred by EMRA,  maintaining  regional  monopolies  for  distribution  and  retail.  There  are 73 distribution system operators and 120 000 km of pipelines covering all 81 provinces. At the retail level, BOTA Ş remains the largest supplier to end users.

The natural gas spot market operated by Energy Exchange Istanbul was established in 2018 and a continuous Trade Platform enables day-ahead and intraday operations. The Platform enables shorter term transactions with daily spot prices and the physical delivery of the traded volumes. As of August 2024, the volume of traded gas in the organised  market  was  almost  9 bcm  and  46 companies  held  wholesale  trading licences. In October 2021, a Natural Gas Futures Market was established, enabling trading of natural gas futures, to enhance transparency, predictability and hedging of natural  gas  contracts.  Energy  Exchange  Istanbul  acts  as  the  sole  counterpart  to minimise the counterparty risk for participants.

Like the electricity market, consumers are divided into eligible and non-eligible, based on annual consumption. Since 2015, the eligibility threshold was &gt;75 000 m 3 /year for residential consumers. Customers above this threshold - eligible consumers - are allowed  to  purchase  natural  gas  from  any  company:  they  negotiate  unregulated bilateral contracts  in the wholesale  market.  In  2024,  there  were  more  than 800 000 eligible customers.

## Coal

In 2024, coal accounted for 26% (1 769 petajoules) of Türkiye's total energy supply and  was  the  largest  energy  source  in  electricity  generation  (34%).  Although  total

energy supplied from coal increased by 89% from 2005 to 2024, its share of TES decreased. In 2025, Türkiye consumed almost 120 Mt of coal, surpassing Germany and  Poland  to  become  the  largest  consumer  of  coal  in  Europe.  Coal  demand  in Türkiye is expected to remain around 90 Mt by 2030. Türkiye reached a record level of coal-fired electricity output of 120 TWh in 2024, slightly surpassing Germany.

Coal in electricity generation and its share in electricity generation among European countries, 2020-2024

<!-- image -->

## Production and imports

The 12th Development Plan expects the 2053 net zero target to impact coal policy in the future. Around 90% of Turkish coal reserves consist of lignite, and the government promotes the exploration, mining and development of existing mines. Domestic lignite has low calorific value and requires large volumes to satisfy demand. Imports of hard coal have almost doubled in the past 15 years. Since 2022, Türkiye's largest trade partner has been Russia, overtaking Colombia, as imports from Russia increased by 24% from 2022 to 2024, reaching 25 Mt, after peaking at 29 Mt in 2023.

## Coal production and import by type (2010-2024) and projections (20252028) in Türkiye

<!-- image -->

IEA. CC BY 4.0.

Note: Projections are not available for imports.

Sources: IEA (2026), World Energy Balances; MENR (2024), 2024-2028 Strategic Plan, (accessed in October 2025).

The  expansion  of  coal-fired  power  capacity  over  the  past  decade  was  part  of  a strategy to exploit domestic lignite resources and reduce reliance on imported natural gas for power generation.

## Average emission factors of selected fuels in Türkiye, 2014-2024

<!-- image -->

Source: IEA (2025), Emission Factors 2025; IEA (2026), World Energy Balances.

As of 2026, Türkiye hosts 69 coal-fired power plants, including unlicensed plants and auto-producers. In 2024, coal-fired plants provided 21 GW of capacity. According to Global Energy Monitor, the average age of coal-fired units is 24 years, with 29% older than 30 years and another 27% built in the last decade. Some plants hold licences extending beyond Türkiye's 2053 net zero target. Additionally, 96 GW of proposed coal plant capacity between 2010 and January 2026 was cancelled, while less than 11 GW of capacity was added over the same period. No coal-fired capacity is planned for retirement between 2026 and 2040.

## The case for the coal transition

Despite the government's plan to operate the coal power plants to the end of their technical  lives,  economic  factors  and  climate  goals  build  the  case  for  an  orderly transition of the coal industry. This transition includes plant repurposing and early retirement of unabated coal-fired power plants. Postponing a technically feasible coal transition can result in higher costs while an orderly transition helps minimise social disruptions, which could arise from unplanned closures, in coal-dependent regions.

Türkiye is hesitant to move away from coal-powered electricity generation owing to concerns about security of supply and energy costs. Coal plants currently generate electricity, contribute to the adequacy of power systems and participate in capacity markets. Rather than relying on coal for continuous generation, shifting the focus to flexibility services and keeping coal capacity available for periods of system needs, would reduce electricity generation from unabated coal power plants over the year. This  approach  would  also  preserve  some  employment  and  mitigate  the  loss  of revenue associated with a full closure.

Plans  to  expand  wind  and  solar  offer  clean,  low-cost  alternatives  to  meet  rising electricity demand: the generation costs of new solar PV and onshore wind power plants  is  lower  today  than  new  and  existing  fossil  fuel  plants  in  almost  all  cases. Nonetheless, the introduction of an ETS could raise the price of coal-fired electricity.

Lignite-fired generation and domestic coal production depend significantly on state support mechanisms, placing a burden on the national budget, that could instead be redirected to finance the energy transition. A key support instrument is the capacity mechanism introduced in 2018. It provides monthly payments to reward available capacity. The mining sector also receives financial support to pay miners' wages to compensate for the hardship of the profession, as well as support in the form of a tax expenditure for lignite exploration.

Türkiye plans to develop a CCUS roadmap, which will include proposals to retrofit newer coal plants. This could preserve existing assets and jobs and ensure more time to  absorb  the  transition  costs.  Türkiye  is  also  advancing  efforts  to  improve  the environmental performance and value-added utilisation of domestic coal resources. Current  projects  include  the  development  of  advanced  carbon  materials,  such  as graphene, carbon nanotubes and carbon fibre, as well as the recovery of rare earth elements and other critical minerals from coal-processing wastes. These initiatives aim to support innovation, enhance resource efficiency and contribute to domestic critical mineral supply chains.

Türkiye's 12th Development Plan focuses on upskilling and preparing the workforce for the digital and green transitions. The number of employees in the coal and lignite mining sector has fluctuated in recent years but is generally declining compared to 2015 (-20%), resulting in a total of around 32 000 employees in 2024. This is partially because of productivity gains - and employment reductions differed among regions, highlighting the importance of targeted regional policies while progressing towards the net zero target. An effective people-centred transition focuses on workers, offering direct  payments  and  compensation,  mindful  of  the  wage  premium  coal  workers receive to work in this sector.

A  workers'  transition  needs  to  consider  different  retirement  ages;  workers  farther away from retirement should benefit first from reskilling and education programmes. In terms of upskilling, Türkiye offers vocational training, with a focus on renewable energy and on providing equal opportunities within the energy sector. Establishing a regional  skills-mapping  exercise  would  help  identify  the  transferable  skills  of  coal workers and specific  training  required  for  new  emerging  employment  sectors  and enable the implementation of targeted reskilling initiatives while mitigating employment disruptions.

## Hydrogen

Türkiye released its first hydrogen strategy in January 2023. The aim of the Hydrogen Technologies  Strategy  and  Roadmap  is  to  establish  a  domestic  low-emission hydrogen supply chain, targeting 2 GW of electrolysers by 2030, 5 GW by 2035 and 70 GW by 2053. It also seeks to reduce the low-emissions hydrogen production costs to  below  2.4 USD/kg by 2035 and to 1.2 USD/kg by 2053. Türkiye is preparing a Hydrogen  Action  Plan  in  co-operation  with  the  World  Bank  to  operationalise  the National Hydrogen Technologies Strategy and Roadmap. The Plan is expected to define priority actions, investment needs and implementation arrangements across

the hydrogen value chain. Achieving the Strategy's hydrogen cost-reduction targets will be important for strengthening the competitiveness of domestic production and supporting wider adoption in key sectors.

For comparison, the global hydrogen costs were 4.5-6.5 USD/kg in 2023, and the IEA estimates production costs from renewable-based electrolysis could fall to 2-9 USD/kg H2 by 2030 under the net zero emissions scenario. The strategy includes support for demonstration projects using natural gas as a transition pathway. It also foresees blending hydrogen into the gas system, with a target share of 12% in the gas mix by 2053. Industry is expected to be the main sector for hydrogen deployment.

To date, there is no legal provision for hydrogen use in the energy sector and in 2022 the Change and Adaptation Co-ordination Board recommended either establishing  a  stand-alone  hydrogen  market  law  or  including  provisions  for  a hydrogen regulatory framework in existing laws such as the Natural Gas or Electricity Market Laws. According to the IEA Global Hydrogen Review 2024, Türkiye received over  USD 400 million  in  funding  from  multilateral  development  banks  for  the development of hydrogen projects in the period 2022-2024.

## Affordability

Following  the  global  energy  crisis  in  2022,  government  support  measures  helped shield households in Türkiye from rising energy costs. These measures, including subsidies  and  tariff  regulation,  contributed  to  relatively  stable  natural  gas  and electricity prices compared with many other countries.

As a result, the share of household income spent on energy appears relatively low on average (3% in 2025). However, this masks significant disparities across regions and income groups. Low-income households spent almost twice as much on energy as in 2021 and a notable share of households continues to struggle to adequately heat their  homes  (20%  in  2025,  compared  to  the  European  Union  average  of  9%), particularly in lower-income regions in eastern Türkiye.

## Households' inability to keep their home adequately warm in selected countries, 2020-2025

Source: IEA analysis based on Eurostat (2026), Data Browser Inability to Keep Home Adequately Warm, (accessed in May 2026).

<!-- image -->

Türkiye remains highly dependent on imported natural gas, exposing consumers to future price volatility. While regulated tariffs have helped limit short-term impacts on households, they may also weaken incentives for energy efficiency and investment.

Transport  costs  also  weigh  significantly  on  household  budgets  in  Türkiye.  While nominal  diesel  prices  are  below  the  OECD  average,  they  are  high  in  purchasing power  terms,  contributing  to  affordability  pressures,  particularly  for  lower-income households. Improving vehicle efficiency is therefore key to limiting transport-related fuel poverty. At the same time, electric vehicles remain concentrated among higherincome households, and with the vehicle fleet ageing (around 14 years on average), reducing upfront costs will be important to support a more equitable transition.

## Energy investment and financing

The transition to a low-carbon economy in Türkiye requires significant investment in renewable energy, grids and energy efficiency. In 2025, around 7.6% of the public investment  budget  was  allocated  to  energy  projects.  The  government  estimates investment needs of USD 80 billion for renewable capacity, USD 28 billion for grid infrastructure  and  USD  20  billion  to  meet  energy  efficiency  targets  by  2030, highlighting the importance of mobilising private capital.

Financial flows are gradually shifting towards renewables. Turkish banks increasingly view coal investments as unattractive due to long investment horizons and growing transition  risks,  while  loan  performance  in  renewable  energy  projects  remains stronger than in fossil fuel assets.

However, several structural barriers constrain the scale-up of energy finance. Limited availability of long-term financing, low domestic savings and the absence of a fully developed  green  finance  framework,  including  a  national  taxonomy  and  carbon market, hinder investment. These challenges are compounded by macroeconomic factors  such  as  inflation,  exchange  rate  volatility  and  high  interest  rates,  which increase the cost of capital and deter investment in capital-intensive projects such as renewable energy and grid infrastructure.

The government has introduced policy frameworks to support sustainable finance, including the development of a national green taxonomy aligned with the European Union,  and  initiatives  to  integrate  sustainability  considerations  into  the  financial sector.  This  initiative  is  particularly  relevant  as  Turkish  energy-intensive  industry exports will be impacted by the European Union's CBAM. Türkiye also benefits from international climate  finance,  particularly from  multilateral development  banks, supporting renewable energy deployment, energy efficiency and grid integration.

In May 2024, Türkiye signed a new USD 1 billion programme with the World Bank and Turkish development banks to support the installation of 53 GW of solar and 7.5 GW of battery storage by 2035. Furthermore, in 2024 Türkiye, the World Bank (International  Bank  for  Reconstruction  and  Development  and  the  International Finance Corporation), and the European Bank for Reconstruction and Development developed  a  Renewable  Energy  Integration  Investment  Plan.  The  Plan  aims  to facilitate the  transformation  of  the  country's  transmission  system  to  allow  for additional  renewables  capacity  by  2035  and  to  deploy  flexibility  and  stability mechanisms.

## Recommendations

<!-- image -->

Prioritise the renovation of residential buildings to improve energy efficiency, thermal performance and seismic resilience by scaling up financial solutions

Türkiye aims to renovate 40% of existing residential buildings by 2033. More than 31%  of  households  reside  in  residential  buildings  built  before  2000  and  over three-quarters were built before the adoption of building codes. Large areas of Türkiye are earthquake-prone, including Istanbul, which accounts for the largest number of buildings. A significant share of buildings in the country is not earthquake-proof, and the  latest  major  earthquake  (2023),  in  addition  to  its  devastating  human  impact, damaged almost 40 000 buildings.

To  achieve  the  ambitious  urban  renovation  and  transformation,  the  government should  include  residential  buildings  in  efficiency  programmes.  Country-specific circumstances  such  as  the  age  structure  of  the  building  stock,  the  high  share  of multi-family dwellings and the shared ownership of these buildings should be taken into  account  in  the  design  of  target-oriented  schemes  to  enhance  the  building renovation rate. Furthermore, the current decision-making requirements in multi-apartment  buildings  present  a  barrier  to  energy  efficiency  renovations.  It  is important to ensure that vulnerable and less well-off householders are part of the energy transition. Incentive schemes should help low-income families reduce energy consumption,  improve  comfort,  and  lower  heating  and  cooling  costs  while  also contributing to energy efficiency and reducing carbon emissions. In high-risk seismic zones,  Türkiye  should  fast-track  the  renovation  of  buildings  at  risk  and  provide incentives for owners to demolish and rebuild unsafe structures under safer, modern standards. Where possible, earthquake proofing should accompany building retrofits.

<!-- image -->

## Accelerate the deployment of a heat market, leveraging domestic geothermal resources to decarbonise heating systems and strengthen energy security

Türkiye  should  address  a  policy  gap  by  providing  a  coherent  set  of  incentives  to promote renewable heating, cooling and co-generated power, adding dispatchable capacity  to  the  grid  in  the  most  resource-efficient  way.  It  should  build  on  existing efforts to map out geothermal resources and heating and cooling needs; engage with municipalities, promoters and the banking sector to identify and promote adequate business  and  financing  models;  and  promote  innovation  to  sustain  Türkiye's technological leadership. The IEA estimates that geothermal energy could provide up to 15% of global electricity demand growth to 2050. Boosting this sector in Türkiye could spur economic growth and reduce dependencies through the creation of new jobs  in  the  manufacturing,  installation  and  maintenance  of  geothermal  energy systems for the domestic market and potentially for export markets over time.

<!-- image -->

## Complete energy market reform by carefully transitioning end-user prices to a transparent, market-based pricing mechanism

Retail gas and electricity prices in Türkiye are protected by regulatory measures to prevent  significant  tariff  increases  owing  to  fluctuations  in  international  energy markets and exchange rate variations. In early 2022, EMRA introduced tiered tariffs for residential and commercial consumers with the upper limit for low-tier residential consumers increased to benefit a greater number of consumers. While wholesale power prices returned to near normal after the crisis, retail tariffs remained at a lower level. These low tariffs, while beneficial to Turkish consumers in the short term, pose longer  term  challenges  to  the  energy  sector  and  hinder  efforts  to  reduce  energy consumption and energy imports.

Artificially low gas and electricity prices offer consumers little financial motivation to reduce their consumption. As a result, energy efficiency measures, such as investing in energy-efficient appliances or retrofitting homes, become less attractive. Artificially low  energy  prices  drive  up  energy  demand  and  place  a  further  strain  on  scarce resources and domestic energy security. To achieve its energy efficiency and climate goals, a balanced approach to tariff setting is essential, where prices reflect the cost

Türkiye 2026

of energy and encourage responsible energy use. The gradual implementation of a tariff reform will need to be carefully communicated and managed to support public acceptance and must be accompanied by complementary measures to protect less well-off and vulnerable households from energy poverty.

<!-- image -->

## Ensure a viable financing framework for large nuclear power plants while establishing a clear strategic framework for small modular reactors

Nuclear power is seen as a cornerstone of Türkiye's future decarbonised electricity system: it will provide dispatchable, carbon-free power and enhance system stability and  flexibility,  thereby  supporting  and  complementing  the  expected  large-scale deployment of wind and solar. In addition to the Akkuyu nuclear power plant, the government is planning to build two more nuclear power plants. Security of supply, reducing  dependencies,  localising  technology  transfer  and  a  viable  financing framework should be a central focus for Türkiye in negotiations to build and finance these plants.

Small  modular  reactors  (SMRs)  offer  a  potential  flexible  and  modular  solution  for decarbonising  hard-to-abate  industrial  sectors.  These  reactors  could  provide  both low-carbon  electricity  and  potentially  high-temperature  heat  to  energy-intensive industries such as steel, cement, chemicals and fertilisers. This would help achieve national decarbonisation goals for these key economic sectors while ensuring they remain competitive on export markets where carbon content is increasingly factored in. While several SMR concepts are moving toward demonstration, Türkiye should finalise  its  legal  and  administrative  framework  for  SMRs  to  include  a  transparent, time-bound process for technology selection and project development.

To  enable  private  sector-led  deployment,  the  government  should  work  with  key industrial  stakeholders  to  assess  demand,  define  viable  project  structures  and develop  an  appropriate  risk-sharing  mechanism  that  provides  predictability  to investors without relying on direct public financing. Early engagement with potential end users, long-term visibility (on energy strategy and the regulatory environment), and  a  co-ordinated  policy  framework  can  help  make  SMRs  a  strong  element  of Türkiye's industrial decarbonisation and clean growth strategy.

<!-- image -->

## Establish a policy framework to initiate a just and orderly transition for local communities relying on the coal industry

The coal industry brought considerable benefits to Türkiye's economic development, but its influence is likely to decline in the coming years owing to sustainability and competitiveness pressures. Türkiye's speed in securing its energy supply will depend on how well it integrates variable renewable energy and nuclear power. While the energy transition will benefit the economy, the process needs to be carefully steered to ensure that local communities that rely on coal industries are not left behind.

The policy framework should include indicative time frames for the decommissioning of  a  first  set  of  older  coal-fired  power  plants  and  local  governance  mechanisms involving  relevant  stakeholder  groups.  It  should  ensure  that  communities  are adequately  prepared,  promote  innovation  and  offer  reskilling  opportunities  to  the workforce according to the potential of new economic activities in each region, in the energy sector and beyond. The framework should incorporate mechanisms for direct participation  of  workers,  youth,  women  and  local  communities  in  policy  design, drawing  on  local  knowledge  to  tailor  solutions  for  each  region.  The  expected implementation of a domestic emissions trading system, paired with electricity market reforms, is likely to push out older inefficient power plants.

Evidence from other countries' transitions demonstrates that coal-producing regions can  suffer  long-term  effects  if  the  transition  is  not  anticipated.  Measures  to  help manage the transition include support for workers and companies; the development of alternative industries; and investment in local infrastructure and public services, including  digital  connectivity,  healthcare  and  education.  Early  engagement  with private  sector  partners  and  local  entrepreneurs  is  essential  for  accelerating  new business  opportunities  and  broadening  the  range  of  quality  employment  options beyond the energy sector.

## Focus areas

## Expansion and integration of variable renewables

Realising the full potential of Türkiye's solar PV and wind power will require proactive integration  strategies.  Between  2019  and  2025,  the  shares  of  solar  PV  and  wind power in electricity generation doubled. The government identified these sources as key pillars for decarbonising the energy sector, and capacity is expected to continue expanding rapidly towards 2035, supported by cost reductions in solar PV and wind power technologies and backed by an emerging and supportive policy environment.

Maximising the benefits from increased solar PV and wind capacity requires effective integration  into  the  power  system.  While  power  systems  have  always  managed demand  variability,  variable  renewable  energy  (VRE)  sources  introduce  supply variability  depending  on  the  weather.  This  variability  will  require  increasing  the flexibility  of  the  entire  power  system,  by  leveraging  dispatchable  generation,  grid enhancements,  increased  storage  and  demand  response.  Successful  integration maximises  the  amount  of  energy  that  can  be  sourced  securely  and  affordably, minimises costly system stability measures, and reduces dependency on fossil fuels.

VRE sources are not only crucial  for  power  sector  decarbonisation  but  also  offer benefits that extend far beyond the environment. By reducing fossil fuel consumption, renewables enhance energy security and improve affordability, providing a hedge against  volatile  fuel  markets.  Nonetheless,  realising  these  multifaceted  benefits requires  more  than  simply  installing  renewable  capacity:  it  needs  VRE  to  be effectively integrated into existing power systems. Effective integration ensures that renewable  electricity  can  be  reliably  delivered  when  and  where  it  is  needed, maximising its value to the grid and consumers alike. System integration of solar PV and wind power involves the technical, institutional, policy and market adjustments

necessary to ensure their secure and cost-effective incorporation into the power grid. To  do  so,  Türkiye  must  enhance  system  flexibility  and  strengthen  the  supporting infrastructure. Successful integration will maximise the benefits of renewable energy, minimise the need for costly interventions to maintain system stability and reduce reliance on fossil fuels.

## Understanding variable renewable electricity integration

The IEA developed its VRE integration framework to understand the challenges grid operators face as they expand their networks to accommodate increasing volumes of VRE. The IEA analysis outlines six phases of impacts on the power system resulting from increasing loads of solar PV and wind. Each phase presents new challenges requiring targeted measures to enable the secure and cost-effective uptake of VRE. Phases  1  to  3,  which  are  considered  low  phases  of  VRE  integration,  experience relatively  low  impacts,  with  most  challenges  addressable  through  straightforward modifications  to  existing  assets  or  operational  improvements.  Phases  4  to  6  are considered high phases requiring a fundamental transformation of the power system.

Türkiye is currently in Phase 2 and is expected to reach Phase 3 by 2030 should it meet its targets. Phase 2 is when VRE has a minor to moderate impact on the system. As more VRE capacity is added, changes between load and net load become more noticeable with a minor to moderate impact on the system, such as faster and more frequent ramping of generators. Upgrades to operating practices, such as integrating forecasting into dispatch and making better use of existing system resources, are usually  sufficient  to  achieve  system  integration.  In  Phase  3,  VRE  determines  the operation pattern of the power system. Greater swings in the supply-demand balance prompt the need for a systematic increase in flexible operation of the power system that  often  goes  beyond  what  can  be  readily  supplied  by  existing  assets  and operational practice.

Conventional  power  plants,  networks  and  pumped  storage  hydropower  have historically been the primary sources of flexibility. Operational improvements in VRE power plants and networks and the advent of affordable distributed energy resources and battery energy storage systems are enabling a wider set of flexibility options. As power systems transition towards higher phases of system integration, these flexibility resources can work together to enhance system flexibility in a cost-effective, reliable and  environmentally  sound  manner.  A  combination  of  technical  enhancements, institutional reforms, market design updates and policymaking will be necessary in

Türkiye if the system is to accommodate the projected volumes of solar PV and wind. All  these  requirements  contribute  to  a  secure  and  cost-effective  electricity  system while maximising the use of renewable energy.

## Policy framework

Türkiye set out its ambitious policy goals for the renewable energy sector in its 2053 Long-Term Climate Strategy, published in November 2024. The Strategy sets out a comprehensive  approach  to  achieving  the  country's  net  zero  emissions  target by 2053.  The  provision  of  a  sustainable,  high-quality,  secure,  uninterrupted  and affordable energy supply is to be achieved by maximising the use of domestic and renewable energy sources and improving energy efficiency. The government aims to transform electricity generation by means of renewable energy, electrification, energy efficiency, low-carbon hydrogen, energy storage, and the establishment of nuclear power plants and SMRs.

Key  incentives  to  support  this  transition  include  YEKDEM,  which  promotes  local production by offering long-term purchase guarantees to effectively use renewable energy resources and increase investments, and the YEKA model, which facilitates large-scale projects and supports domestic energy production.

More than TRY 65 billion (USD 1.5 billion) was allocated to renewable energy projects between 2011 and 2023 under YEKDEM. As a result, renewable electricity capacity more than tripled, meeting growing energy demand while curbing emissions growth. Türkiye  aims  to  more  than  double  its  existing  renewable  energy  capacity  (2024), reduce energy intensity by 35%, and integrate clean energy technologies into the energy system as part of its short- and medium-term targets for 2030 and 2035.

The  share  of  renewable  energy  sources  in  electricity  generation,  43%  in  2025,  is expected to rise to nearly 70% in 2053. Solar PV and wind power along with geothermal energy are expected to play a crucial role in transitioning to a low-carbon electricity generation  system.  The  aim  of  increasing  renewable  electricity  capacity  is  twofold: enhance energy supply security and reduce external dependency. Existing renewable energy potential will be maximised, and new innovative technologies such as hybrid power plants and floating solar and offshore wind energy systems will be expanded, even if  they  are  not  yet  fully  commercialised  today.  The  use  of  Renewable  Energy Guarantee of Origin (YEK-G) certificates is encouraged. Efforts to reduce dependency on imported renewable energy technologies and increase global competitiveness will require investments in R&amp;D to strengthen local production capacity.

## Türkiye's renewable electricity targets

Hydropower accounted for 16% of Türkiye's electricity generation in 2025 and the share of VRE in electricity generation increased to 21% with projections of reaching 34% by 2030 (see next section).

## Solar PV, wind and total variable renewable energy share in electricity generation, historical (2018 and 2025) and 2030 projections in Türkiye

<!-- image -->

Sources: IEA (2025), World Energy Balances; IEA (2025), Electricity 2025; IEA (2025), Renewable Energy Progress Tracker, Türkiye, Ministry of Environment, Urbanization and Climate Change (2024), Türkiye, Ministry of Environment, Urbanization and Climate Change (2024), 2053 Long Term Climate Strategy.

## Wind and solar capacity and targets in Türkiye, 2020-2035

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on IEA (2025), Electricity Information; EMRA (2025), 2024 Electricity Market Development Report (accessed January 2026); Türkiye, Ministry of Environment, Urbanization and Climate Change (2024), 2053 Long-Term Climate Strategy, (accessed October 2025).

In November 2024, the new Long-Term Climate Strategy updated Türkiye's targets for  wind  and  solar  PV  capacity. While  the  2030  targets  remained  unchanged,  the target for 2035 greatly increased. Solar capacity is expected to almost quadruple from 2024 to 2035 and wind capacity is expected to triple.

## Cumulative distribution of hourly solar PV and wind generation shares in Türkiye and Germany, 2018 and 2025

<!-- image -->

Source: IEA analysis based on EPIAS (2026), collected through the IEA Real-time Electricity Tracker, (accessed July 2026).

For around 97% of 2018, the electricity system operated with a VRE share below 15%: in 2025, it was above 15% for over half of the time. From 2018 to 2025, the average hourly generation from wind and solar combined increased from 6.8% to 15%, rising to above 30% in 2025 for part of the year. By way of comparison, in a more mature and developed market such as Germany, VRE generation in 2024 was above 30% for over 70% of the time.

## Grid expansion

Electricity  grid  expansion,  modernisation  and  upgrades  allow  solar  PV  and  wind energy to serve growing demand. Grids need to grow and be strengthened to connect the  new  solar  PV  and  wind  power  plants,  transport  the  generated  electricity  to consumers, and balance electricity supply and demand securely. Furthermore, grids support  solar  and  wind  integration  by  facilitating  geographical  smoothing  of  their

generation profiles, improving the power system's flexibility. Türkiye's 2025 Investment  Programme  allocated  TRY 42 billion  (USD 970 million)  to  electricity transmission infrastructure and TRY 9.5 billion (USD 220 million) to support capacity increases and repurposing of power generation infrastructure.

Between 2014 and 2024, Türkiye's electricity transmission and distribution networks underwent significant  expansion  and  modernisation.  Total  investment  in  electricity networks in that period is estimated to be USD 350-375 million. These expansions and investments have aimed to improve network reliability, operational efficiency and quality of service, supporting Türkiye's growing electricity demand and its transition towards more sustainable energy sources.

As of the end of December 2025, Türkiye's electricity transmission system included more than 76 000 km of transmission lines, almost 800 high-voltage substations and 15 interconnections  with  neighbouring  countries.  Transmission  system  planning considers current consumption patterns, industrial zone development, large user and distribution company demands, and supply security when determining new substations  and  transmission  corridors.  The  Electricity  Strategic  Plan  2024-2028, published  by  the  Ministry  of  Energy  and  Natural  Resources,  outlines  several  key network development targets aimed at enhancing energy security, sustainability and efficiency.  The  Plan's  key  elements  include  expansion  and  modernisation  of  the electricity transmission and distribution infrastructure to meet growing demand and improve reliability, the development of energy storage technologies to support grid stability and renewables integration, and the expansion of EV charging infrastructure and cross-border interconnections. The Plan also contains proposals to roll-out smart meters  and  digital  platforms  and  increase  the  use  of  data  analytics  and  artificial intelligence to optimise grid operations and demand-side management.

By  2035,  Türkiye  plans  to  install  around  14 700 km  of  high-voltage  direct  current (HVDC) lines to strengthen cross-border electricity links and improve system stability along with around 90 500 km of new  alternating current lines and around 950 substations. This expansion is crucial for integrating the increasing capacity of VRE sources into the grid. The country also plans a significant increase in battery energy capacity, with a target of adding 7.5 GW of battery storage by 2035. This will help balance supply and demand and ensure a stable electricity supply.

## System flexibility

System flexibility can be understood as the ability of a power system to manage the variability and uncertainty of supply and demand reliably and cost-effectively across all  relevant  timescales.  Maintaining  the  supply-demand  balance  is  achieved  by adjusting generation and demand. Flexibility can extend across several timescales, for example managing hourly changes in the supply-demand balance or dealing with extended periods of lower resource availability, such as droughts affecting hydropower.  High  shares  of  VRE  can  create  operational  challenges,  particularly short-term flexibility related to power system stability on the sub-second timescale. System inertia, a property derived from synchronous generators, acts to mitigate the rate of change of frequency following a contingency event in the power system. VRE generators do not have a direct, electromechanical coupling to the grid, which makes them different to traditional, synchronous generators.

Most of the flexibility required to maintain power system reliability in Türkiye today is provided by hydropower and dispatchable thermal power plants. Rising flexibility needs and changes in the composition of the power plant fleet, such as the addition of nuclear power and retirement of coal-fired plants, increase the need for alternative sources of flexibility to maintain grid stability and security of supply. Reinforced power grids and additional  interconnections  can  help  even  out  fluctuations  in  the  supply  of  weatherdependent variable renewables, within and between countries and regions; they can also connect additional providers of flexibility to the system. Grid assets, such as HVDC interconnections, can also provide flexibility services such as voltage control directly.

The  12th  Development  Plan  identifies  an  energy  storage  system  as  a  possible solution to Türkiye's flexibility needs,  along with the installation of pumped hydropower plants, the expansion of the interconnection capacity with neighbouring countries, the roll-out of smart meters and the development of supervisory control and data acquisition systems. The flexibility and storage capabilities of reservoir plants and pumped storage hydropower facilities are unmatched by any other technology. With low operational costs and large storage capacities, existing reservoir hydropower plants are the most affordable source of flexibility today. The increasing need in many markets for system flexibility and storage to facilitate the integration of higher shares of VRE is expected to drive record growth of pumped storage projects worldwide between 2021 and 2030.

## Battery storage technologies

Türkiye plans to meet part of its flexibility needs with battery storage technologies. As of 2024, the country did not have any battery storage capacity, but it plans to increase battery  storage  capacity  to 2.1 GW by 2030 and to 7.5 GW by 2035, assuming a two-hour charging time. Domestic regulations define three types of storage systems: independent storage systems, united storage systems and power generators with storage systems. Batteries are the preferred option for daily storage, owing to their capital cost, which Türkiye expects to decrease consistently. Batteries are charged at noon, absorbing excess electricity from solar PV.

The  regulatory  framework  to  integrate  storage  facilities  into  the  system  was strengthened in 2022 (Law No. 7417). With the update, EMRA will grant a pre-licence for  the  establishment of a solar or wind facility to entities committing to set up an electricity storage facility up to the capacity of the planned battery. In turn, entities holding  licences  for  the  generation  of  such  renewable  energy  and  applying  to establish a storage facility will have the right to expand it up to the capacity of their generation facility. The Law introduced new types of facilities, such as storage facilities integrating generation and vice versa. By June 2023, EMRA received applications for 275 GW of storage capacity but halted the amendment in October 2023.

Sector coupling has the potential to play a key future role in long-duration flexibility and  making  the  best  use  of  VRE.  Hydrogen  production  is  an  alternative  that contributes to that regard. Electrolysers, which are expected to function in times of high VRE generation, add additional system flexibility. While the flexible operation of electrolysers as part of integrated energy systems does not yet present a fully viable business  case,  their  proven  ability  to  operate  with  varying  loads  highlights  their potential  to  provide  long-duration  flexibility.  Owing  to  their  fast  response  time, electrolysers  can  provide  increased  short-term  flexibility  to  the  grid,  enabling  the integration  of  renewables  and  seasonal  flexibility  when  coupled  with  large-scale storage. A hybrid configuration could potentially combine the best of both, using a small share of electricity from the grid (with GHG emissions tracking) to provide firm capacity and  increase  the  use  of  the  assets  while  limiting  the  increase  in  GHG  emissions. Electrolyser capacities are projected to reach 5 GW in 2035 and 70 GW in 2053.

## Demand-side flexibility

In  2024,  Türkiye  accounted  for  a  quarter  of  Europe's  electricity  demand  growth, pushed by cooling needs in the country's hottest summer in 54 years. Demand-side

participation  is  one  of  the  main  options  to  provide  flexibility  to  the  power  system. Demand-side participation is mostly achieved by the transport sector, by means of smart charging of EVs at times when electricity supply is high in the system. The residential sector also holds significant potential for system flexibility through demandside participation.

## Daily peak load (7-day moving average) in Türkiye, 2018 and 2025

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on ENTSO-E (2026), Transparency platform, collected through the IEA Real-time Electricity Tracker, (accessed June 2026)

Most EV charging is expected around noon, taking advantage of high solar energy production.  Demand for  charging  is  minimised  during  the  peak  hours  of  transport activity. As a result, the electricity load is expected to decrease in the afternoon. Since charging is also performed partly at night, load stays at higher levels compared to the actual profile. In households, demand-side participation will be enabled, notably by load shifting (e.g. by changing the operating hours of electrical appliances such as dishwashers  and  washing  machines).  However,  there  is  no  contribution  to  grid flexibility via space heating in the residential sector.

Türkiye  also  established  a  regulatory  framework  for  electricity  aggregation  and demand-side flexibility as part of broader efforts to enhance power system flexibility and integrate higher shares of variable renewable energy. Aggregation activities were incorporated into the Electricity Market Law, and implementing regulations entered into force in December  2024, with aggregator licences being issued from February 2025  onwards.  In  parallel,  new  regulations  enable  TEİAŞ  to  procure

demand-side flexibility through competitive tenders, allowing eligible consumers to participate  through  aggregators that manage and adjust electricity consumption in response to system needs. During the first procurement period (December 2025 to February 2 026), TEİAŞ secured 200 MW of flexible demand capacity, increasing to 873 MW for the second procurement period covering July to September 2026.

## Distribution system flexibility

As they are mainly connected to distribution grids, the increasing volume of distributed energy resources is pushing distribution system operators to explore the flexibility services these resources can provide rather than only seeing them as an additional complexity to manage. Rather than exacerbating problems such as grid congestion, outages and voltage violation, distributed energy resources can be adopted to provide crucial support to address these network issues.

To access the value of distributed energy resources, incentives for their uptake must be assessed in the context of broader system objectives to ensure they respond to actual  system  needs  and  do  not  internalise  the  benefits  solely  to  the  end  user. Distributed  energy  resources  can  provide  services  to  the  system  by  voluntarily adjusting generation and/or consumption in response to an external signal, which can be a price signal or direct activation, e.g. by an aggregator. They can be targeted at a defined time and duration at a specific location within a specific portion of the grid to enhance security of supply and service quality in the most efficient way, thereby reducing costs for consumers.

Türkiye's Smart Grid 2023 Vision and Strategy Roadmap Summary Report outlines Türkiye's  objectives  and  strategic  plan  for  developing  a  smart  grid  infrastructure by 2035. It assesses the current state of Türkiye's electricity distribution network and proposes a detailed roadmap with short- and medium-term milestones across various technical components, such as grid management, IT infrastructure, renewable energy integration and cybersecurity. The Report also addresses the regulatory framework, budget and financing to achieve this vision, seeking a more efficient, sustainable and secure energy system.

Overall, smart meters are envisioned as a key enabler for a more informed, engaged and potentially cost-effective electricity experience for Turkish consumers. They will provide greater control over energy consumption, facilitate participation in emerging

energy  markets  and  support  the  integration  of  renewable  energy  sources  at  the household  level. The  successful  deployment  and  integration  of smart  meter infrastructure are critical to realising these benefits.

The Smart Grid Roadmap sets several targets, which are aimed to align with national energy policies and enable the transition to a smarter and more sustainable electricity grid.  The  Principles  and  Procedures  on  the  Widespread  Deployment  and  Use  of Smart  Meter  Systems,  which  regulate  the  use  of  smart  meters  in  the  electricity distribution  system  and  the  replacement  of  existing  electricity  meters  with  smart meters, entered into force following their publication in the Official Gazette No. 33098, 5  December  2025.  Türkiye  introduced  a  regulatory  framework  to  support  the deployment of smart electricity metering as part of efforts to modernise the power system and strengthen demand-side participation. The Principles and Procedures on the Widespread Deployment and Use of Smart Meter Systems entered into force in December 2025, establishing the framework for the installation of smart meters in the electricity distribution network and the replacement of conventional meters. The rollout of smart metering is expected to improve system monitoring, facilitate consumer participation  in  electricity  markets  and  support  the  development  of  demand-side flexibility services.

Smart meters will promote the development of small-scale distributed and renewable grid infrastructure, with a specific focus on establishing the infrastructure to support rooftop solar power plants. The overall aim is to introduce 35 GW of flexible sources into the system, comprising 10 GW rooftop solar plus storage, 10 GW of large-scale storage, 5 GW of grid management and 10 GW of demand-side management. The Roadmap also targets:

- · a 20% improvement in the capacity utilisation rates of current grid assets
- · reducing power system losses to 8% (including transmission and generation)
- · providing resilience against attacks or natural disasters that can be carried out on the electric infrastructures of smart grids
- · encouraging  the  use  of  advanced  grid  equipment  and  technologies  such  as superconductors, amorphous transformers and power electronic-based switching equipment
- · creating a market structure and regulatory framework that triggers and supports the transformation of the sector and new business models

- · providing  support  for  target  areas  for  technology  development  and  export, including  storage,  the  Internet  of  Things,  data  analysis,  grid  management software, smart meters and solar panels
- · ensuring  that  smart  meter  and  communication  units  are  supplied  from  local resources.

## Interconnections

Türkiye's electricity strategy focuses on expanding regional co-operation, increasing renewable energy capacity and enhancing grid resilience to meet growing demand, reduce  import  dependency  and  achieve  carbon  neutrality.  Türkiye  plans  to  triple interconnection  capacity  with  neighbouring  markets  by  2035,  which  will  increase export capacity threefold to 6.75 GW and import capacity fivefold to 6.6 GW. HVDC lines spanning 14 700 km will be installed to strengthen cross-border electricity links. Türkiye currently supplies electricity to Iraq and plans to expand supply to the Syrian Arab Republic, aiming to contribute to regional stability and mutual development.

Türkiye's  interconnection  strategy  aligns  with  its  broader  energy  policy  goals  of diversifying  routes  and  resources  for  energy  security  while  reducing  reliance  on hydrocarbons.  Regional  interconnections  are  seen  as  vital  for  promoting  stability, mutual growth and resilience against disruptions such as the nationwide blackout in 2015.  Türkiye's  interconnection  strategy  is  a  multifaceted  approach  combining renewable energy expansion, infrastructure modernisation and regional co-operation to achieve sustainable growth and energy security.

## Transmission network technologies are evolving

Digital technologies play a significant role in modern transmission grids. They can increase  capacity  and  enhance  the  efficiency,  reliability  and  flexibility  of  the  grid, allowing it to handle higher loads and transmit electricity more effectively. This can help  avoid  the  construction  of  new  lines  or  assist  in  cases  where  line  extension deployment is not fast enough. Dynamic line rating involves real-time monitoring of weather conditions and line temperatures to adjust the current carrying capacity of transmission lines accordingly. This technology allows lines to operate closer to their thermal  limits  safely  instead  of  using  fixed  values,  optimising  and  increasing transmission capacity.

Flexible alternating current transmission systems such as fast-acting reactive power support or static synchronous compensators enable real-time control of power flows, voltage  levels  and  other  stability  characteristics.  They  modulate  the  generation  of reactive power depending on need, further enhancing power transmission capacity and grid stability. In 2025, these power electronics devices are relatively uncommon. Nonetheless,  they  will  become  increasingly  prevalent  as  the  share  of  renewable energy sources increases and demand grows for load flow control and grid quality assurance. Combined  with energy storage systems, such as batteries and supercapacitors, these systems can provide rapid response capabilities to support grid  frequency  as  they  can  quickly  inject  or  absorb  power  to  balance  supply  and demand variations and act as virtual inertia to stabilise the grid.

HVDC is another significant technology that supports system operations by efficiently transporting large amounts of electricity and can provide functionalities for bidirectional load flow control and reactive power control. It can also assist with black start processes. The ability to control the power flow on the HVDC line provides a significant benefit in optimising the power flow distribution across the overall grid.

Even if monitoring systems such as a wide-area management system are already in place in transmission grids, they are becoming larger and more integrated than in the past, expanding to incorporate the monitoring of connected distribution grids whose complexity is increasing with the growing renewables penetration. In these systems, embedded advanced analytics and artificial intelligence algorithms can process vast amounts of data to predict electricity demand patterns and potential grid issues. By anticipating demand  peaks  and  identifying  potential  transmission  bottlenecks, operators can take proactive measures to reinforce the grid and enhance its capacity. By attaching sensors to critical but also expensive assets such as transformers and circuit breakers, valuable feedback can be obtained about their health status. This enables  proactive  and  preventive  maintenance,  as  issues  can  be  identified  and addressed before they lead to costly failures.

The  use  of  new  technologies  such  as  drones  and  satellite-based  technology  has revolutionised  the  inspection  of  power  lines,  both  in  transmission  and  distribution grids. Instead of relying on expensive helicopter rides, drones and satellite imaging can  be  deployed  for  line  inspections.  They  capture  pictures,  videos  and  thermal images that can be automatically evaluated. This enhances the safety of operational staff by minimising their exposure to hazardous conditions during inspections.

## Recommendations

<!-- image -->

## Ensure market rules provide clearer locational signals to improve system operation and ensure grid stability during the transition

To manage the energy transition with rapid growth in variable renewable generation, distributed renewable resources and significant electrification of end-use sectors, the existing grid infrastructure needs to be used as efficiently as possible. Concerns over integration challenges, such as grid connection queues and congestion management, can deter investment in solar PV and wind capacity. These factors cause delays and uncertainty, making it difficult for projects to connect, and negatively impacting their business case. Regulations that outline the technical and operational requirements of all stakeholders involved in the transmission system, including generators, distributors and consumers, should ensure that new grid connections are in places that support efficient grid operation now and, in the future, and avoid unnecessary delays. Other measures such as the introduction of efficient seasonal and locational tariffs and flexible grid connection agreements that reflect the cost of connection and latest  grid  stability  procedures  would  facilitate  the  integration  of  new  sources  of variable renewable energy.

Future scenarios in Türkiye will involve periods when renewables satisfy most system demand.  To  maintain  system  stability  during  these  times,  inverter-connected generation such as wind and solar PV must also contribute. Allowing wind and solar PV  to  actively  participate  in  balancing  and  ancillary  services  markets  could  be beneficial.  These  markets  may  require  adjustments,  such  as  lower  minimum  bid volumes, to accommodate these resources. Furthermore, developing requirements for adding converter-based power sources could be advantageous. Extending current requirements to include  unlicensed  production  is  one  way  to  do  so.  The  updated EU Requirements  for  Generation  Regulation  which  will  be  decided  in  2025  could provide  a  point  of  reference.  As  the  Regulation  will  apply  in  many  IEA  European Member countries, manufacturers are expected to adapt their products, resulting in equipment compliant with the Regulation becoming available on the market.

<!-- image -->

## Expand participation in the electricity spot market and encourage investment in system flexibility

Türkiye should streamline its different support mechanisms and reform the existing market design to meet the needs of its energy transition (e.g. rather than starting a new market/tender for demand-side response, allow these resources to participate in the existing balancing market). A system with a large share of renewables also needs system flexibility. It is not necessarily the flexibility of individual installations that is important but rather the collective flexibility of the system. One means to integrate large amounts of renewables is to ensure that other resources that offer flexibility services  have  the  correct  incentive  to  do  so.  Türkiye  will  need  to  find  a  way  to encourage new sources of flexibility (both on the generation and the demand side) and  meet  its  targets  for  battery  storage  installations.  Producers  should  react  to transparent price signals but at the same time have a 'firm' income stream to be able to finance investment. Consumers should be able to adjust load according to available power (react to price signals) but without worrying too much about electricity bills.

## Energy performance and competitiveness of industry

Over the past 15 years, Türkiye has emerged as one of the world's fastest-growing industrial economies, with industrial manufacturing value added more than doubling since 2010. The industrial sector refers to manufacturing, refining and mining; unless otherwise  specified,  the  analysis  in  this  section  focuses  on  manufacturing,  which accounts for around 80% of industrial energy consumption. This rapid growth creates increasing  pressure  to  sustain  competitiveness,  in  light  of  the  effects  of  carbon taxation  on  certain  industrial  sectors.  Policy  will  need  to  address  two  challenges: improving access to energy efficiency measures in less energy-intensive industries and managing the exposure of key sectors to carbon pricing and external market measures.

In 2023, Türkiye's manufacturing energy intensity (2.7 MJ/USD), measured in terms of energy consumption per unit of value added, was higher than other G20 economies such as Germany (2.3 MJ/USD) and Italy (2.2 MJ/USD). However, energy intensity remains higher than in many G20 economies, despite relatively fast improvements.

Türkiye has also made progress in electrifying its manufacturing industry sector. The share of electricity in manufacturing processes increased from 25% in 2010 to 28% in  2024,  alongside  a  73%  rise  in  absolute  electricity  consumption  in  the  sector. Despite  these  gains,  Türkiye's  industrial  growth  drove  a  notable  rise  in  fossil  fuel consumption, raising critical energy security and environmental risks. Between 2010 and 2024, oil product use increased by almost four times (from a low base), natural gas consumption rose by 62% and coal by 12%. As a result, manufacturing accounted for  29%  of  the  increase  in  total  final  energy  demand  and  30%  of  the  increase  in emissions from fuel combustion in the period 2010-2024.

## The expansion of less energy-intensive industries provides opportunities for energy savings

Energy represents a significant share of costs in energy-intensive industries such as metals,  cement  and  chemicals,  making  efficiency  a  key  priority.  In  2024,  these subsectors accounted for 57% of industry sector energy use and the same portion of the  sector's  CO2  emissions  from  fuel  combustion.  By  contrast,  less  intensive industries such as textiles, automotive, machinery, and food and beverage processing, consumed 23% of industrial energy in 2024, but contributed around 44% of value added, 66% of manufacturing employment, and nearly 55% of exports. The analysis in this section focuses on manufacturing, as this subsector accounted for 80% of all industrial energy use in 2024 in Türkiye.

While heavy industry drives energy demand, less energy-intensive industries account for a larger share of value added, jobs and exports. For energy efficiency policy to best  support  industrial  strategy,  competitiveness  and  sustainability,  distinguishing between energy-intensive and less energy-intensive industries is therefore important.

Value  added  in  both  less  energy-intensive  and  energy-intensive  industry  roughly doubled between 2010 and 2024. However, energy demand in less energy-intensive industries  increased by more than 150%, compared with 82% in energy-intensive industry.

Given their economic and social impact, less energy-intensive industries should be a priority  for  policy makers.  They  show  relatively  high  short-term  energy  efficiency potential  and  are  highly  cost  effective.  Measures  such  as  the  electrification  of low-temperature  process  heat  and  electric  motor  upgrades,  in  particular,  offer

attractive  paybacks.  IEA  analysis  of  survey  data  from  the  Energy  Efficiency  and Management Association of Türkiye shows that sectors such as wood, as well as food and  beverages,  present  high  energy-saving  potential  should  energy  efficiency measures be applied.

## Manufacturing value added and energy consumption in Türkiye, 2010 and 2024

<!-- image -->

IEA. CC BY 4.0.

Note: Other manufacturing and non-specified industrial energy consumption are not included. Sources: IEA analysis based on IEA (2026), Energy End-uses and Efficiency Indicators; UNIDO (2026), INDSTAT Revision 4, Value Added, (accessed in May 2026).

While opportunities exist across all industrial segments, the cost of energy savings varies by sector. Less energy-intensive industries generally offer more cost-effective options, whereas some energy-intensive sectors, such as cement, face higher costs per unit of energy saved. Overall, the largest total savings potential remains in energyintensive industries, albeit at higher average costs. Among them, paper stands out, as  it  offers  short  payback  periods  and  the  lowest  cost  per  unit  of  energy  saved (28 USD/TJ). Energy savings from cement are twice as expensive as those from less energy-intensive industries and the paper sector.

## Industrial energy efficiency savings potential and cost in Türkiye, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: Paper includes printing. Energy savings costs reflect sectoral averages based on a survey of individual industrial sites which have a variety of cost profiles.

Sources: IEA analysis based on IEA (2026), Energy End-uses and Efficiency Indicators; Energy Efficiency and Management Association (2025), Energy Efficiency &amp; ESCO Market in Türkiye, (accessed in September 2025); Energy Efficiency and Environment Directorate (2025), 2024 Cement Industry Benchmarking Report, (accessed May 2026).

The  combination  of  exceptionally  fast  energy  demand  growth  and  considerable efficiency,  electrification  and  savings  potential in  lighter  industries suggests  that  a strong  policy  focus  in  this  area  could  have  a  substantial  impact.  However,  these sectors  face  difficulties  in  accessing  energy  efficiency  programmes,  as  they  are typically  composed  of  smaller  and  more  fragmented  firms.  By  contrast,  energyintensive industries are typically dominated by relatively large enterprises with greater capacity to implement efficiency measures. At the same time, they are highly capitalintensive,  meaning  that  efficiency  improvements  often  require  substantial  upfront investment and can be more complex to implement.

This  focus  on  larger  energy  consumers  is  reflected  in  Türkiye's  existing  Energy Efficiency Obligation Scheme (Law No. 5627). The Scheme requires enterprises with annual energy consumption greater than 1 000 toe per year (tonnes of oil equivalent; about  12 million kWh/year),  Organised  Industrial  Zones  (OIZs)  with  more  than 50 active  enterprises,  and  power  plants  with  installed  capacity  of  greater  than 100 MW to conduct energy audits and develop efficiency action plans.

OIZs  can  help  address  these  barriers  by  providing  co-ordination  and  support  to smaller firms and facilitating access to efficiency programmes. In Türkiye, OIZs are

government-backed areas offering investors ready infrastructure, social amenities, and regulatory incentives. Each OIZ is equipped with essential utilities such as roads, water, electricity, and natural gas. As of 2024, 392 OIZs were in place, hosting over 67 000 companies and employing more than 2 million people. Businesses in OIZs enjoy  tax  benefits  and  expedited  permits,  underpinning  industrial  growth,  regional development and account for about a third of exports and industrial employment.

## Carbon pricing to mitigate pressures on competitiveness in key export sectors

Türkiye's impressive industrial growth was fuelled largely by exports, with the value of goods exports more than doubling from 2010 to 2024. A key factor underpinning this  performance  has  been  the  comparatively  low  industrial  energy  costs,  which provide a competitive advantage relative to many other countries. At the same time, Türkiye's strong trade relationship with the European Union, which accounts for 40% of its total exports, exposes its industry to evolving carbon-related trade measures.

Key export sectors such as steel, cement and aluminium are exposed to EU markets and are therefore directly affected by carbon pricing mechanisms such as the CBAM. Türkiye is the world's seventh-largest steel producer and steel is one of Türkiye's key export  sectors.  In  2025,  a  significant  share  of  exports  (41%)  was  destined  for EU markets. The sector benefits from relatively low energy intensity (measured in energy consumed per production output) compared with many other G20 producers, at 7.1 PJ/Mt, below Brazil, Germany, Japan and the United States. Türkiye is also the world's largest cement and clinker exporter by value and the fourth-largest cement producer by volume. Energy intensity of non-metallic minerals, which include cement, is lower in Türkiye than in many other G20 producers. Despite Türkiye's advantages, even  relatively  efficient  producers  remain  exposed  to  carbon  pricing  through  the EU's CBAM, reinforcing the importance of reducing carbon intensity and introducing domestic carbon pricing mechanisms.

## Energy intensity of steel production across selected G20 producers, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: Energy intensity is represented by the slope: the line shows Türkiye's energy intensity, with all the countries above having a higher energy intensity. Selected countries include top 10 G20 producers excluding outliers such as China, India and Russia.

Sources: IEA analysis based on IEA (2026), Energy End-uses and Efficiency Indicators; World Steel Association (2025), (accessed: May 2026).

Reflecting  relatively  strong  performance,  energy  intensity  in  non-metallic  minerals industries  declined  by  around  18%  between  2010  and  2024,  reflecting  efficiency improvements. Further progress will nonetheless be needed to maintain competitiveness under tightening carbon constraints. Among the measures to reduce carbon  intensity  further,  the  Turkish  government  published  the  2024  Low  Carbon Pathway for the cement sector and integrated 'green cement' in public procurement construction projects. A Communiqué on the Promotion of the Use of Green Cement with Low Carbon Emissions in Public Procurement Contracts was published in the Official Gazette on 16 March 2024 and officially entered into force on 1 January 2025.

Increased  efforts  and  closer  integration  of  efficiency,  electrification  and  climate policies will remain key to secure future industrial growth. To deliver Türkiye's 2053 net zero target and  ensure  economic  resilience,  the government  developed decarbonisation  roadmaps  for  cement,  steel  and  aluminium.  These  ambitious roadmaps identify pathways to achieve a 93% emissions reduction for cement, a 99% reduction for steel and a 75% reduction for aluminium by 2053. The pathways rely on the  introduction  of  all  feasible  low-carbon  technologies  as  well  as  the  necessary

financial and regulatory policies. Their implementation can leverage the government's experience gathered by conducting the mandatory energy and CO2 audits under the Energy Efficiency Obligation Scheme.

As the European Union's CBAM entered into force in January 2026, reducing the carbon intensity of industrial production will become even more critical for Türkiye to sustain  its  export  competitiveness  and  overall  industrial  performance.  Under  the CBAM, EU importers  are  required  to  pay  for  the  carbon  emissions  embedded  in imported goods, unless an equivalent carbon price has already been applied in the country of origin. In its initial phase, the CBAM targets carbon-intensive products most vulnerable to carbon leakage, including iron and steel, cement, aluminium, fertilisers, electricity, and hydrogen.

A  study  commissioned  in  2023  by  the  Ministry  of  Environment,  Urbanization  and Climate Change concludes that Türkiye could mitigate the effects of the CBAM with the  introduction  of  a  domestic  ETS.  Following  this,  the  Grand  National  Assembly enacted  the  country's  first  Climate  Law  in  July  2025,  which  is  now  in  force.  The Climate  Law  mandates  participation  in  the  new  ETS  for  power  plants,  petroleum refineries, iron and steel producers, cement and lime manufacturers, and selected waste management operators and other enterprises emitting more than 50 000 t CO2-eq  annually.  To  enhance  the  effectiveness  of  emissions  reductions, within and outside the ETS, the government also aims to transform the current indirect pricing methodology into a direct carbon tax, potentially establishing a national carbon price where needed.

Türkiye is also aligning its industrial regulatory framework with EU standards, such as the  EU  Industrial  Emissions  Directive  (as  amended  by  Directive  2024/1785/EU). A regulation on the management of industrial emissions came into effect in December 2025 and aims to minimise or prevent industrial emissions and waste generation as well as sources of air, water, soil, noise and odour pollution, in accordance with zero pollution  objectives.  The  Regulation  adopts  an  integrated  pollution  prevention  and control approach to ensure comprehensive protection of the environment and public health. Additionally,  it establishes  the  administrative  and  technical  framework necessary for advancing green transformation within industry, promoting the circular economy and supporting decarbonisation efforts.

Further alignment with EU policy frameworks, in areas such as electrification and renewable energy development, are under consideration. Importantly, under CBAM rules, only electricity with a demonstrable link to a specific low-carbon generator, via

on-site or PPAs, qualifies as low-emissions electricity, providing an incentive for onpremises solar production. Developing a national green taxonomy harmonised with the EU Taxonomy is particularly relevant in this context to guide capital towards lowcarbon  investments  and  support  industrial  transformation,  particularly  in  hard-toabate sectors.

## Recommendations

<!-- image -->

## Leverage organised industrial zones to drive energy efficiency actions in less energy-intensive industries

Lighter  industries  such  as  textiles  and  food  and  beverages  are  seeing  rapidly increasing energy use but may not have access to efficiency programmes because they  consist  of  smaller  energy  users  who  typically  lack  the  capacity  to  take  part independently. Smaller industrial consumers may moreover not fall under the scope of  the  existing  Energy Efficiency Obligation Scheme, which has an annual energy consumption threshold of 1 000 toe per year (about 12 million kWh/year). This is a large  amount  of  energy:  a  regular  small-  to  medium-sized  textile  manufacturer consumes  typically  around  1-5 million  kWh/year;  a  large  producer  with  dyeing operations would likely use over 12 million kWh/year. Some energy efficiency support mechanisms  are  already  available  to  smaller  businesses  with  annual  energy consumption  below  1 000 toe.  For  example,  industrial  enterprises  with  an  annual energy consumption of 500 toe or more are eligible to apply for support from the Efficiency  Increasing  Projects.  In  addition,  the  SME  Energy  Efficiency  Support Program,  administered  by  the  Small  and  Medium  Enterprises  Development  and Support  Administration,  is  a  support  mechanism  specifically  aimed  at  small  and medium-sized enterprises.

Nonetheless, many smaller enterprises may not be able to measure and manage energy  consumption  and  access  the  government  incentive  schemes  which  are focused on larger energy consumers. Organised industrial zones are highly effective at providing co-ordination between enterprises in the zone and can act as one-stop shops for implementing energy efficiency measures and opening the available offer of energy efficiency support schemes to a wider group of enterprises. They would thereby  leverage  the  extensive  energy  improvement  potential  of  the  less  energyintensive sector.

<!-- image -->

## Introduce an emissions trading system for large energy consumers to encourage efficiency and emissions reductions while introducing a carbon tax for companies falling outside the ETS

This  approach  can  complement  Türkiye's  existing  Energy  Efficiency  Obligation Scheme, which has already established a regulatory framework for monitoring and managing  energy  consumption  and  carbon  emissions.  By  targeting  large  energy consumers  in  sectors  such  as  iron  and  steel,  cement,  aluminium,  and  hydrogen, compliance  costs  can  be  reduced  while  aligning  with  the  requirements  of  the European  Union's  Carbon  Border  Adjustment  Mechanism,  which  also  prioritises power generation. Focusing the emissions trading system (ETS) on a smaller number of the largest energy users, who account for most of the energy consumption and CO2 emissions, can further minimise the administrative and compliance burden while still achieving significant impact. A low-level carbon tax or charge on fuel consumption could  be  an  important  element  to  complement  the  scheme  as  the  threshold  for inclusion in the ETS is high and will only apply to a small group of consumers. This will also generate a revenue stream that can be reinvested to support efficiency or other measures to support the energy transition.

<!-- image -->

## Adopt a more integrated approach to industrial competitiveness and support energy security and climate goals

As Türkiye moves forward with its new Climate Law, it should develop an integrated energy and climate governance system and a strategy grounded in analysis of future energy  demand,  including  planned  industrial  zones,  and  aligned  with  designated priority  areas  for  renewables,  electricity,  gas,  hydrogen  and  CO2  infrastructure. Building on its existing gas and electricity networks, such a strategy would enhance efficiency,  resilience  and  sustainability  by  enabling  co-ordinated  planning  at  the national and local levels for both current and future needs. This approach should be supported  by  institutional  arrangements  that  promote  policy  coherence  across energy,  climate  and  economic  objectives.  Organised  industrial  zones  can  play  a central role in this framework by facilitating energy efficiency investments, electrification,  and  the  use  of  renewable  and  recovered  energy,  leveraging  their advantages of shared infrastructure and industrial clustering.

## Annexes

## Acknowledgements

The IEA review team visited Ankara on 7-11 April 2025 and met with government officials and public and private sector stakeholders across the energy sector. This report is based on information from these meetings, the review team's assessment of Türkiye's energy policy and detailed research by the IEA. The review team members were  Anna  Guldbrand  (Sweden,  team  leader);  Frédéric  Maurer  (Switzerland); Michaela Titz (Austria); Cyril Loisel (European Commission); Alexiei Ozeretzkovsky (Nuclear Energy Agency); and Kieran McNamara, Nicholas Howarth and Anders Caratozzolo from the IEA Secretariat.

Kieran McNamara managed the review and is the main author of the report, supported by Anders Caratozzolo. Nicholas Howarth wrote the focus area on energy efficiency in industry and Alexiei Ozeretzkovsky wrote the nuclear section. Anders Caratozzolo and Fabian Burkard designed and prepared the energy data sections of the report, dedicated analysis, figures and tables, supported by Christina Hounisen, Anita Finco, Emma Mares, Samuel Talbot and George Vamos. The report benefited from reviews and insights from IEA staff, including Heymi Bahar, Esra Bozkir Broekman, Eren Çam, Leonardo  Collina,  Russell  Conklin,  Giulia D'Angiolini,  Esin  Emer,  Musa  Erdogan, Carlos  Fernández  Alvarez,  Martin Küppers,  Dennis  Hesseling,  Mine  Isik,  Gergely Molnár,  Šimon  Olmer,  Matthieu Prin,  Alessio  Scanziani,  Richard  Simon,  Arda Topalakci,  Taube  Van  Melkebeke,  Fabian  Voswinkel,  Jacques  Warichet,  Kerem Yilmaz and Oya Zaimoglu. Roberta Quadrelli, Luca Lorenzoni, Taylor Morrison and Thomas Elghozi provided support on statistics and data. Isabelle Nonain-Semelin and Astrid  Dumond  managed  the  editing  and  production  processes.  Clara  Vallois managed the translation process. The graphic design of the report was done by Poeli Bojorquez. Jennifer Allain edited the report. Nicolette Groot supported the organisation of the review team's visit.

The IEA is especially  grateful  to  its  counterparts  in  Türkiye  for  their  excellent  cooperation throughout the review process. In particular, the IEA would like to thank Ahmet Berat Çonkar, Öztürk Selvitop, Rahmi Kopar, Halime Semerci Kuşçu, Emir Aldan, Mustafa Nuri Erdem and Elif Atalay, for their support in co-ordinating the review and facilitating the work of the review team.

The IEA also thanks the numerous individuals from the following organisations who provided  valuable  insights  for  the  report:  the  Ministry  of  Energy  and  Natural Resources,  the  General  Directorate  of  Energy  Affairs;  the  General  Directorate  of Nuclear Energy, Department of Energy Efficiency and Environment; the Directorate of Strategy Development; the Electricity Generation Corporation; the Energy Market Regulatory Authority; the General Directorate of Mining and Petroleum Affairs; the Ministry of Agriculture and Forestry; the Ministry of Environment, Urbanization and Climate  Change;  the  Directorate  of  Climate  Change;  the  Ministry  of  Industry  and Technology; the Ministry of Transport and Infrastructure; the Ministry of Treasury and Finance; the Nuclear Regulatory Authority; the Petroleum Pipeline Corporation; the Presidency  of  Strategy  and  Budget;  Türkiye  Electromechanical  Industry  Inc.;  the Turkish  Electricity  Distribution  Corporation;  the  Turkish  Electricity  Transmission Corporation; the Turkish Energy, Nuclear and Mining Research Council; the Turkish Energy, Nuclear and Mineral Research Agency; the Turkish Petroleum Corporation; the Centre for Solar Energy Research and Applications; the Centre for Wind Energy Technologies  Applications  and Research;  the Electricity Distribution Services Association; the Electricity Producers Association; the Energy Efficiency Association; the  Energy  Investors  Association;  the  Energy  Markets  Operation  Inc.;  the  Energy Traders Association; the Geothermal Power Plant Investors Association; the Istanbul International  Centre  for  Energy  and  Climate;  the  Turkish  Aluminium  Industrialists Association; the Turkish Cement Manufacturers' Association; the Turkish Society of HVAC and Sanitary Engineers; and the Turkish Wind Energy Association.

## Abbreviations and acronyms

BAT

best available technique

BAU

business-as-usual

CBAM

Carbon Border Adjustment Mechanism

CCACB

Climate Change and Adaptation Co-ordination Board

CCUS

carbon capture, utilisation and storage

DoCC

Directorate of Climate Change

EMRA

Energy Market Regulatory Authority

ETS EU

Emissions Trading System

European Union

EÜAŞ

Electricity Generation Corporation

EV

GDP

GHG

HVDC

IEA

JSC

LNG

LPG

MENR

NDC

NEEAP

OIZ

PPP

PV

R&amp;D

SAF

SMR

TANAP

TEİAŞ

TENMAK

TES

TETAŞ

TNEP

TRY

UNFCCC

USD

VAT

VRE

YEKDEM

electric vehicle

gross domestic product

greenhouse gas

high-voltage direct current

International Energy Agency

joint stock company

liquefied natural gas

liquefied petroleum gas

Ministry of Energy and Natural Resources

Nationally Determined Contribution

National Energy Efficiency Action Plan

organised industrial zone

purchasing power parity

photovoltaic

research and development

sustainable aviation fuel

small modular reactor

Trans-Anatolian Natural Gas Pipeline

Turkish Electricity Transmission Company

Turkish Energy, Nuclear and Mineral Research Agency

total energy supply

Turkish Electricity Trade and Contracting Corporation

National Energy Plan

Turkish lira (currency)

United Nations Framework Convention on Climate Change

United States dollar (currency)

value-added tax

variable renewable energy

Yenilenebilir Enerji Kaynaklari Destekleme Mekanizmasi (Renewable Energy Resources Support Mechanism)

## Units of measurement

bcm

billions of cubic metres

GJ

gigajoule

GW

gigawatt

GWh

gigawatt hour

GWe

gigawatt electrical

kb/d

thousand barrels per day

km

kilometre

kWh

kilowatt hour

mcm

millions of cubic metres

Mt

million tonnes

Mt CO2-eq

million tonnes carbon dioxide equivalent

MW

megawatt

MWe

megawatt electrical

MWh

megawatt hour

PJ

petajoule

t CO2

tonne carbon dioxide

TJ

terajoule

toe

tonne of oil equivalent

TWh

terawatt hour

See the IEA glossary for a further explanation of many of the terms used in this report.

## Infographic note

The GHG emissions chart is illustrative, showing the expected direction of emissions beyond 2035 rather than precise projected levels.

## Infographic sources

GHG  emissions : IEA analysis based on Turkish Statistical Institute (2025), Greenhouse Gas Emissions Statistics 1990-2023, (accessed January 2026).

Wind and solar capacity : IEA (2026), Electricity Information; UNFCCC (2024), 2053 Long Term Climate Strategy, (accessed January 2026).

Industry : IEA analysis based on UNIDO (2025), INDSTAT Revision 4, Value added, (accessed January 2026); IEA (2026), Energy End-uses and Efficiency Indicators.

Natural gas production : IEA (2026), Monthly Gas Data Service.

Power system transformation : IEA (2025), World Energy Balances.

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual M ember countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject to the IEA's Notice for CC-licenced Content, this work is licenced under a Creative Commons Attribution 4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA September 202 6 Cover design: IEA

<!-- image -->

## Türkiye 2026

## Energy Policy Review

Government action plays a pivotal role in ensuring secure and sustainable  energy  transitions.  Energy  policy  is  critical  not just for the energy sector but also for meeting environmental, economic  and  social  goals.  Governments  need  to  respond to  their  country's  specific  needs,  adapt  to  regional  contexts and  help  address  global  challenges. In this context, the International Energy  Agency  (IEA)  conducts  Energy  Policy Reviews to support governments in developing more impactful energy and climate policies.

This Energy Policy Review was prepared in partnership between the Government of Türkiye and the IEA. It draws on the IEA's extensive knowledge and the inputs of expert peers from IEA Member  countries  to  assess  Türkiye's  most  pressing  energy sector  challenges  and  provide  recommendations  on  how  to address them, backed by international best practices. The report also highlights areas where Türkiye's leadership can serve as an example in promoting secure and clean energy transitions. It also promotes the exchange of best practices among countries to foster learning, build consensus and strengthen political will for a sustainable and affordable energy future.

<!-- image -->