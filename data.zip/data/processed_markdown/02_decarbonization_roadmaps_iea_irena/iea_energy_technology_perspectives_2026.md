---
document_id: iea_energy_technology_perspectives_2026
title: "Energy Technology Perspectives 2026"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IEA"
year: 2026
original_file: "iea_energy_technology_perspectives_2026.pdf"
tables_detected: 60
converted_with: "Docling v2.32 (TableFormer)"
---

## Energy Technology Perspectives 2026

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 13 Association countries and beyond.

## IEA M ember countries:

This publication and any map included herein are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Revised versions: April and July 2026 Information notice found at: www.iea.org/corrections

Source: IEA. International Energy Agency Website: www.iea.org

IEA A ssociation countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Abstract

The  2026  edition  of Energy Technology Perspectives is published  against the backdrop of a fast-changing policy and technology landscape. Governments are working to establish secure and resilient supply chains for clean energy technologies  while  advancing  key  energy  policy  goals  such as  energy  security, affordability and  economic  competitiveness,  as  well as climate and other environmental  goals.  In  a  landscape  that  is  constantly evolving, this report aims to deliver  timely  insights  into  the  status  and  outlook of technology deployment, manufacturing, project pipelines, investments, and trade of different energy technologies  and  materials.  The  aim  is  to provide  useful  analysis  that  can  inform  the  considerations  of  policy  makers around the world.

Energy Technology Perspectives 2026 examines demand-side dynamics for energy technologies -such as deployment trends and policy developments -  as  well as supply-side factors, including manufacturing capacity  and  trade  flows,  underpinned  by  robust  modelling  and  quantitative analysis.  This  year's  edition  puts  a  special  focus  on  vulnerabilities  in  energy technology supply chains and industrial competitiveness, analysing manufacturing cost structures and industrial policy impacts.

The IEA's Energy  Technology  Perspectives ( ETP )  series serves as the world's guidebook for clean energy technologies. As the IEA's flagship technology publication, ETP has been a key source of insights on all matters relating  to  energy  technology  since  2006.  Over  the  past  20  years, ETP has expanded  to  encompass  more  data  and  analysis on different aspects of energy  technologies,  including infrastructure,  supply  chains  and  beyond.  The 2026 edition aims to provide a comprehensive  update  on  today's  most pressing energy technology issues.

## Foreword

As governments seek for new ways to drive economic growth and support national prosperity, many are looking at the potential opportunities from the emerging Age of Electricity that the International Energy Agency (IEA) has repeatedly highlighted in our recent analysis.

The data shows why. Today, a group of key technologies contributing to the Age of  Electricity  -  including  solar  panels,  wind  turbines,  batteries,  electric  cars, electrolysers and more - already represents a USD 1 trillion market. And in all of the IEA's scenarios about the future of energy, this valuation is set to rise sharply over the next decade, driven in part by booming demand for electricity.

Most of this value comes from more established technologies such as electric cars and  renewables.  They  have  all  benefited  from  mass  manufacturing  and  cost reductions and are an important reason why the Age of Electricity has emerged so rapidly.

At the same time, many emerging technologies are moving faster than you might think. Take electrolysers for low-emissions hydrogen production: despite a recent wave of project delays and cancellations, the anticipated surge in deployment by the end of this decade mirrors the pace of expansion seen when growth in solar PV  first started  to climb.  Meanwhile,  technologies  still  in  early  stages  of development  -  such  as  nuclear  fusion  -  are  capturing  widespread  attention, although their real-world viability and impact still need to be proven.

Given the scale of the opportunity, countries and companies have been racing to secure their place in this fast-growing segment of the energy economy. Yet in the 17 months since we published our last Energy Technology Perspectives report, the backdrop has undoubtedly become more complex. Shifting policies, economic conditions and technological progress are creating uncertainty about the prospects and economic potential of these technologies.

This edition of Energy Technology Perspectives , the latest instalment of the IEA's flagship technology publication, provides fresh data and analysis to help make sense of this landscape, enabling decision makers to separate signal from noise. Its  analysis  of  the  factors  that  shape  competitiveness  in  energy  technology manufacturing - which highlights potential supply chain vulnerabilities and their implications for economic security - makes it a must-read for anyone developing industrial strategies and partnerships.

Several  high-level  takeaways  stand  out.  First,  the  size  of  this  opportunity  will ultimately rely on the combination of energy, industrial and trade policies, all of which are closely intertwined. Countries will need to chart their own courses based on their resources and priorities. But even as many increasingly adopt defensive positions with the goal of protecting domestic industries, our analysis shows that the  energy  technologies  examined  in  this  publication  will  remain  an  important feature  of  global  trade.  While  tariff  increases  are  expected  to  put  pressure  on average  costs  for  consumers,  the  impact  will  differ  by  technology  -  and  the economics, in many cases, are still set to favour strong growth.

Second, international collaboration remains highly valuable, allowing countries to play to their strengths. Securing a competitive edge in technology supply chains will rely not only on support for domestic manufacturing, but also on establishing strategic partnerships with countries and companies around the world. This can reduce costs and increase diversification, which is crucial for energy security.

I would like to thank the dedicated members of the ETP team who produced this timely  and  insightful  report  under  the  leadership  of  the  IEA's  Chief  Energy Technology Officer, Timur Gül. I hope decision makers around the world will find this data-driven analysis instructive as they look towards the future.

Dr Fatih Birol Executive Director International Energy Agency

## Acknowledgements

This study was prepared by the Energy Technology Policy (ETP) Division of the Directorate  of  Sustainability,  Technology  and  Outlooks  (STO),  with  input  from other divisions of the International Energy Agency (IEA). The study was designed and directed by Timur Gül , IEA Chief Energy Technology Officer.

The  modelling  and  analytical  teams  of  Energy  Technology  Perspectives  2026 ( ETP-2026 ) were co-ordinated and supervised by Araceli Fernandez (Head of the Technology Innovation Unit), Peter Levi (Head of Technology Supply Chain Unit) and Uwe Remme (Head of the Hydrogen and Alternative Fuels Unit). Other principal  authors  were Simon  Bennett (ten  key  questions  related  to  energy technologies and their supply chains) and Leonardo Paoli (industrial competitiveness and supply chain risks).

The main authors and contributors from the ETP division were (in alphabetical order):

Giovanni Andrean (trade routes, shipping, grid technologies), Matthildi Apostolou (energy-intensive industries competitiveness), Jose Miguel Bermudez Menendez (hydrogen), Herib Blanco (technology trends, geothermal, industrial competitiveness), Leonardo Collina (energy-intensive industries competitiveness), Elizabeth  Connelly (road,  deployment  outlook), Laurence Cret (shipping), Chiara Delmastro (buildings,  heat  pumps), Mathilde Fajardy (carbon capture, utilisation and storage, deployment drivers, nuclear, renewables), Hannes Gauch (technology dashboards, sustainable aviation fuels), Alexandre Gouy (industrial  heat,  recycling), Carl  Greenfield (carbon  capture, utilisation and storage), Mathilde Huismans (wind, renewables, data management), Jack  Jaensch (manufacturing  and  trade,  economic  analysis), Clara  Klint (manufacturing  and  trade  support), Teo  Lombardo (batteries, recycling), Rafael Martínez Gordón (heat pumps), Quentin Minier (sustainable aviation fuels), Axel Nordin Fürdös (heat pumps), Faidon Papadimoulis (solar PV, data management), Amalia Pizarro Alonso (hydrogen,  storage,  industrial and  trade  policy), Thibault  Rey (heat  pump  manufacturing), Caroline  Robert (economic analysis), Andrew Ruttinger (near-zero emissions materials, energyintensive  industries  competitiveness), Martin  Scheubrein (data  management), Jules Sery (electric cars), Richard Simon (industry, energy-intensive industries competitiveness)  and Agrata  Verma (industrial  and  trade  policy,  economic analysis).

Other key contributors from across the IEA were Heymi Bahar, Piotr Bojek, Jianlan Dou , Michael Drtil, Martin Kueppers, Luis Munuera (external), Nikolaos

Papastefanakis, Jules Parfouru, Apostolos Petropoulos, Tiffany Vass, Prokopios Vlachogiannis, Fabian Voswinkel, Stéphanie Bouckaert, Brent Wanner and Daniel Wetzel.

Special thanks to Frank van Tongeren (former Head of OECD's SMART Data and Modelling  Unit  within  the  Directorate  on  Trade  and  Agriculture),  who  provided strategic advice on economic analysis.

Valuable  comments  and  feedback  were  provided  by  senior  management  and other colleagues within the IEA, in particular, Laura Cozzi, Dan Dorner, Tim Gould, Brian Motherway, Dennis Hesseling and Alessandro Blasi.

Trevor Morgan provided writing support and holds editorial responsibility; Lizzie Sayer supported the editing of the manuscript. Charlotte Bracke, Anna Kalista, Mao Takeuchi and Per-Anders Widell provided essential support throughout the process.

Thanks  also  to  the  IEA  Communications  and  Digital  Office  for  their  help  in producing the report, particularly to Jethro Mullen, Lee Bailey, Curtis Brainard, Poeli Bojorquez, Gaelle Bruneau, Jon Custer, Astrid Dumond, Merve Erdil, Grace Gordon, Julia Horowitz, Isabelle Nonain-Semelin, Andrea Pronzati, Lucile Wall, Wonjik Yang.

The work could not have been achieved without the financial support provided by the Governments of Canada, Germany and Japan.

Several senior government officials and experts provided essential input and feedback to improve the quality of the report. They include:

Sam Adham

CRU

Putra Adhiguna

Energy Shift Institute

Bentley Allan

Johns Hopkins University

Takahiro Asahi

Daikin

Florian Ausfelder

Dechema

Divya Balakrishnan

GIZ

Ben Backwell

Global Wind Energy Council

Harmeet Bawa

Hitachi Energy

Chris Bayliss

Aluminium Stewardship Initiative

Georg Bieker

International Council on Clean Transportation

Teymour Bourial

ExoPeak

David Caranci

Stellantis

Jean Château

OECD

Ilka von Dalwigk

Recharge

Greg De Temmerman

Independent

Rebecca Dell

ClimateWorks Foundation

Raoul Doerr

European Commission, DG ENER

Luca Dona

Ionate Energy

Caroline Haglund Stignor

TCP on Heat Pumping Technologies

Ohira Eiji

Kawasaki Heavy Industries

Capella Festa

SLB

Martin Forsen

NIBE

Jason Gadoury

Natural Resources Canada

Lambert Guilbault

Alcoa

Tyler Hamilton

MaRS Discovery District

Noé van Hulst

Gasunie

Robert Höglund

CDR.fyi

Ashish Khanna

International Solar Alliance

Martin Knops

RWTH Aachen University

Torgeir Knutsen

Ministry of Energy, Norway

Hideyuki Koga

Toyota Motor Corporation

Gerrit Koll

The German Aerospace Center

Leif Christian Kröger

Thyssenkrupp Nucera

Verene Kuhn

World Economic Forum

Sarah Ladislaw

RMI

Barry Lavery

ReNew

Benjamin Lechaptois

Bureau Veritas Marine &amp; Offshore

Jon Lezamiz Cortazar

Siemens Gamesa

Toby Lockwood

Clean Air Task Force

Sam Lowe

Australian delegation to the OECD

Silvia Madeddu

Schneider Electric

Masaru Matsui

Panasonic

Milo McBride

Carnegie Endowment for International Peace

Tim McCaffery

Siam Cement Group

Dennis Mesina

Department of Energy, United States

Andrew Minson

Global Cement and Concrete Association

Nobuto Nakanishi

Panasonic Energy

Tasuku Nakanishi

Ministry of Economy, Trade and Industry, Japan

Torben Norgaard

Mærsk Mc-Kinney Møller Center

Thomas Nowak

Qvantum International

Peta Olesen

Department of Climate Change, Energy, the Environment and Water, Australia

Diederik Peereboom

T&amp;D Europe

Stephanie Pfeifer

The Institutional Investors Group on Climate Change

Andrew Purvis

WorldSteel Association

Sandiswa Qayi

AET Africa

Lizet Ramirez

WindEurope

Thorsten Reichartz

RWTH Aachen University

Olga Rataj

UNIDO

Joonas Rauramo

Coolbrook

David Reiner

University of Cambridge

Frédérique Rigal

Airbus

Mats Rinaldo

DNV Group

Agustín Rodriguez

Topsoe

Diana Rodriguez Barrera

Heidelberg Materials

Malcolm Ross

Eavor

Nicola Rossi

Enel

Toshiyuki Sakamoto

The Institute of Energy Economics, Japan

Gerhard Salge

Hitachi Energy

Javier Sanz

European Solar Alliance

Jehan Sauvage

OECD

Hannah Schindler

Ministry of Economic Affairs and Energy, Germany

Madhavi Srinivasan

Nanyang Technological University, Singapore

Sandro Starita

European Aluminium Association

## Anna Stephenson

Emily Stumpf

Ulrik Stridbæk

Bert Stuij

Simona Sulikova

Elena Talalasova

Jacopo Tattini

Peter Taylor

Pradeep Tharakan

Stephane Tondo

Jessika Trancik

Philipp Trompetter

Drew Turner

Ulderico Ulissi

Fridtjof Unander

David Victor

Nick Wagner

Daniel Weaver

Rebecca Williams

Veronika Wilk

Markus Wråke

Feng Zhao

Liu Ziyu

Department of Energy Security and Net Zero, United Kingdom

Panasonic Europe

Ørsted

Netherlands Enterprise Agency

World Bank

Global Maritime Forum

European Commission, DG GROW

University of Leeds

Asian Development Bank

ArcelorMittal

MIT

The German Aerospace Center

Danfoss Climate Solutions

CATL

Aker Solutions

University of California San Diego

World Economic Forum

Department of Energy Security and Net Zero, United Kingdom

Global Wind Energy Council

DryFiciency

Calentix Energy

Global Wind Energy Council

CATL

## Table of contents

| Executive summary................................................................................................................   | Executive summary................................................................................................................                                                                                     | 15                                                                                                                                |
|-------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|
|                                                                                                                                     | Introduction.............................................................................................................................                                                                             | 23                                                                                                                                |
| Report                                                                                                                              | scope and structure...................................................................................................                                                                                                | 23                                                                                                                                |
|                                                                                                                                     | Scenarios                                                                                                                                                                                                             | .............................................................................................................................. 24 |
|                                                                                                                                     | References............................................................................................................................                                                                                | 25                                                                                                                                |
| Chapter 1. Ten key questions about energy technologies and their supply chains......                                                | Chapter 1. Ten key questions about energy technologies and their supply chains......                                                                                                                                  | 27                                                                                                                                |
|                                                                                                                                     | Introduction ...........................................................................................................................                                                                              | 27                                                                                                                                |
| 1.                                                                                                                                  | How are recent shifts in trade policy affecting clean energy technology supply chains?.                                                                                                                               | 28                                                                                                                                |
| 2.                                                                                                                                  | How will today's low profits in clean energy technology manufacturing affect innovation and investment? ............................................................................................................. | 33                                                                                                                                |
| 3.                                                                                                                                  | How can policy help close the cost gap with China in energy technology supply chains?................................................................................................................                 | 38                                                                                                                                |
| 4.                                                                                                                                  | Is the current electricity transformer shortage a cause for concern?.............................                                                                                                                     | 42                                                                                                                                |
| 5.                                                                                                                                  | Is there a case for investing in a domestic battery sector when China holds such a cost advantage? .............................................................................................................      | large 47                                                                                                                          |
| 6.                                                                                                                                  | Has the hydrogen bubble burst? ....................................................................................                                                                                                   | 52                                                                                                                                |
| 7.                                                                                                                                  | Is carbon capture, utilisation and storage finally taking off? ..........................................                                                                                                             | 57                                                                                                                                |
| 8.                                                                                                                                  | Large, modular and fusion reactors all have renewed momentum: how quickly can nuclear be brought online?.............................................................................................                 | 63                                                                                                                                |
| 9.                                                                                                                                  | Can strategic industries in advanced economies restore their competitive edge?........                                                                                                                                | 68                                                                                                                                |
| 10.                                                                                                                                 | Is there a technology on the horizon that can replicate the explosive growth of solar PV and batteries? ..................................................................................................            | 74                                                                                                                                |
|                                                                                                                                     | References............................................................................................................................                                                                                | 79                                                                                                                                |
| Part A. Deployment of clean energy technologies, materials and fuels………………….83                                                      | Part A. Deployment of clean energy technologies, materials and fuels………………….83                                                                                                                                        |                                                                                                                                   |
| Chapter 2. Outlook for deployment of clean energy technologies...................................                                   | Chapter 2. Outlook for deployment of clean energy technologies...................................                                                                                                                     | 85                                                                                                                                |
|                                                                                                                                     | Highlights...............................................................................................................................                                                                             | 85                                                                                                                                |
| Recent                                                                                                                              | market trends............................................................................................................                                                                                             | 86                                                                                                                                |
| Global                                                                                                                              | outlook .......................................................................................................................                                                                                       | 95                                                                                                                                |
|                                                                                                                                     | Drivers of deployment.........................................................................................................                                                                                        | 109                                                                                                                               |
|                                                                                                                                     | References..........................................................................................................................                                                                                  | 120                                                                                                                               |
| Chapter 3. T echnology deployment dashboards .......... ..........                                                                  | Chapter 3. T echnology deployment dashboards .......... ..........                                                                                                                                                    | ......................................... 123                                                                                     |
|                                                                                                                                     | Highlights.............................................................................................................................                                                                               | 123                                                                                                                               |
|                                                                                                                                     | Electric cars.........................................................................................................................                                                                                | 124                                                                                                                               |
|                                                                                                                                     | Zero-emissions trucks.........................................................................................................                                                                                        | 126                                                                                                                               |
|                                                                                                                                     | Ammonia and methanol propulsion ships...........................................................................                                                                                                      | 128                                                                                                                               |
|                                                                                                                                     | Buildings heat pumps..........................................................................................................                                                                                        | 130                                                                                                                               |
| Air                                                                                                                                 | conditioning systems.....................................................................................................                                                                                             | 132                                                                                                                               |
|                                                                                                                                     | Zero-carbon-ready building envelopes...............................................................................                                                                                                   | 134                                                                                                                               |
| Industrial                                                                                                                          | heat pumps..........................................................................................................                                                                                                  | 136                                                                                                                               |
|                                                                                                                                     | Near-zero emissions steel ..................................................................................................                                                                                          | 138                                                                                                                               |
| Near-zero                                                                                                                           | emissions cement..............................................................................................                                                                                                        | 140                                                                                                                               |
|                                                                                                                                     | Recycling.............................................................................................................................                                                                                | 142                                                                                                                               |
| Solar                                                                                                                               | PV and wind power....................................................................................................                                                                                                 | 144                                                                                                                               |
|                                                                                                                                     | Nuclear................................................................................................................................                                                                               | 146                                                                                                                               |
|                                                                                                                                     | Geothermal                                                                                                                                                                                                            | ......................................................................................................................... 148     |

| Stationary energy storage technologies .............................................................................                                                                                                                                               | 150                                                                                                                                      |
|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------|
| Low-emissions hydrogen, ammonia and methanol............................................................                                                                                                                                                           | 152                                                                                                                                      |
| Sustainable aviation fuels production.................................................................................                                                                                                                                             | 154                                                                                                                                      |
| Carbon dioxide removal......................................................................................................                                                                                                                                       | 156                                                                                                                                      |
| Technical notes on the dashboards....................................................................................                                                                                                                                              | 158                                                                                                                                      |
| References..........................................................................................................................                                                                                                                               | 170                                                                                                                                      |
| Part B. Clean energy technology manufacturing and trade……………………………….175                                                                                                                                                                                            |                                                                                                                                          |
| Chapter 4. Recent trends.....................................................................................................                                                                                                                                      | 177                                                                                                                                      |
| Highlights.............................................................................................................................                                                                                                                            | 177                                                                                                                                      |
| Global investment and trade...............................................................................................                                                                                                                                         | 178                                                                                                                                      |
| The policy landscape                                                                                                                                                                                                                                               | .......................................................................................................... 185                           |
| Manufacturing project pipelines..........................................................................................                                                                                                                                          | 194                                                                                                                                      |
| Prices and profitability.........................................................................................................                                                                                                                                  | 200                                                                                                                                      |
|                                                                                                                                                                                                                                                                    | 209                                                                                                                                      |
| References..........................................................................................................................                                                                                                                               |                                                                                                                                          |
| Chapter 5. Outlook for manufacturing and trade..............................................................                                                                                                                                                       | 217                                                                                                                                      |
| Highlights.............................................................................................................................                                                                                                                            | 217                                                                                                                                      |
| Solar PV..............................................................................................................................                                                                                                                             | 226                                                                                                                                      |
| Wind.................................................................................................................................... Electric cars                                                                                                             | 235                                                                                                                                      |
| and Electrolysers........................................................................................................................                                                                                                                          | batteries................................................................................................... 244 256                     |
| Heat pumps.........................................................................................................................                                                                                                                                | 259                                                                                                                                      |
| References..........................................................................................................................                                                                                                                               | 263                                                                                                                                      |
| Part C. Supply chain risks and industrial competitiveness………………………………..267                                                                                                                                                                                         |                                                                                                                                          |
| Chapter 6. Supply chain risks............................................................................................. Highlights............................................................................................................................. | 269 269                                                                                                                                  |
| Supply chain security..........................................................................................................                                                                                                                                    | 270                                                                                                                                      |
| Concentration of supply ......................................................................................................                                                                                                                                     | 271                                                                                                                                      |
| Implications for security and resilience...............................................................................                                                                                                                                            | 274                                                                                                                                      |
| Technology-specific security considerations ......................................................................                                                                                                                                                 | 283                                                                                                                                      |
| Maritime chokepoints..........................................................................................................                                                                                                                                     | 286                                                                                                                                      |
| References.......................................................................................................................... Chapter 7. Industrial competitiveness...............................................................................          | 293                                                                                                                                      |
| Highlights.............................................................................................................................                                                                                                                            | 297                                                                                                                                      |
| Drivers of competitiveness..................................................................................................                                                                                                                                       | 298                                                                                                                                      |
| Regional trends in the manufacturing industry ...................................................................                                                                                                                                                  | 304                                                                                                                                      |
| Competitiveness of established industries .........................................................................                                                                                                                                                | 308                                                                                                                                      |
| Competitiveness of clean energy technologies                                                                                                                                                                                                                       | .................................................................. 323                                                                   |
| References..........................................................................................................................                                                                                                                               |                                                                                                                                          |
| Chapter chains........                                                                                                                                                                                                                                             | 347 353                                                                                                                                  |
| 8. Strategic considerations for clean energy technology supply                                                                                                                                                                                                     | Highlights.......................................................................................................................... 353 |
| Competitiveness and security objectives are intertwined...................................................                                                                                                                                                         | 354                                                                                                                                      |
| Mapping the supply chain ...................................................................................................                                                                                                                                       | 358                                                                                                                                      |
| Key considerations on security of supply                                                                                                                                                                                                                           | ........................................................................... 359                                                          |
| Prioritising competitiveness actions....................................................................................                                                                                                                                           | 364                                                                                                                                      |
| References..........................................................................................................................                                                                                                                               | 371                                                                                                                                      |
| Annexes. Definitions, Glossary, Regional groupings, References .......................................                                                                                                                                                             | 373                                                                                                                                      |

## Executive summary

Deployment of many clean  energy technologies,  fuels  and  materials  has been growing fast, but shifting policies, economic conditions and technological progress are creating uncertainty about their prospects and economic  potential. Against  this  backdrop,  the  IEA's  flagship  technology publication Energy Technology Perspectives (ETP) aims to separate the signal from  the noise, by providing timely data, scenarios and  analysis across deployment, manufacturing, trade, competitiveness and security. At a time when misjudging the moment risks wasting capital or stalling momentum, this report has been designed to help decision makers navigate uncertainties.

## Despite headwinds, the markets for clean energy technologies and fuels are expanding rapidly

Deployment of clean energy technologies rises in all IEA scenarios,  but the 1 extent to which the market value grows will depend on policy direction. The combined global market value for clean energy technologies has grown 20% on average per year over the past decade, to reach nearly USD 1.2 trillion in 2025. In  the  Current  Policies  Scenario  (CPS),  their  global  market  value  grows  most slowly, but it still doubles to around USD 2 trillion in 2035, about the size of the global  crude  oil  market  in  2025.  At  almost  USD 3 trillion  by  2035,  their  market value is higher in the Stated Policies Scenario (STEPS), with greater deployment offsetting the additional decline in costs. Electric cars are by far the largest clean energy technology market in 2035, accounting for around three-quarters of the total market value in all scenarios.

There  are  many  growth  opportunities  for  low-emissions  fuels,  especially those that can be directly used in existing infrastructure . In several segments - notably cars - low-emissions fuels are not only competing with fossil fuels, but increasingly with the rising use of electricity. However, the medium-term growth prospects remain bright: their market value grows significantly in both the CPS and the STEPS, from around USD 215 billion in 2025 to about USD 390 billion in 2035, equivalent to about 20% of the combined market for diesel and gasoline used  in  transport.  Around  60%  of  this  growth  comes  from  the  expansion  of relatively mature biofuels such as biomethane, bioethanol and biodiesel.

1 ETP-2026 uses three main scenarios, consistent with those presented in the World Energy Outlook 2025 . The CPS and the STEPS are exploratory and based on a set of starting conditions. The NZE Scenario is normative and describes a pathway to reduce global energy sector CO2 emissions to net zero by 2050, while recognising that each country will follow its own route.

Increased  use  of  fuels  that  are  more  costly  and  still  at  low  levels  of  market penetration, such as sustainable aviation fuels and other hydrogen-based fuels, would require stronger policy support.

The  market  outlook  for  low-  and  near-zero  emissions  materials  is  very uncertain  as  production  cost  premiums  remain  high. Technologies  like cement  kilns  fitted  with  carbon  capture,  and  steel  furnaces  using  electrolytic hydrogen,  are  expected  to  cost  significantly  more  than  their  conventional counterparts  over  the  next  decade  in  most  regions.  The  outlook  for  near-zero emissions materials is therefore highly dependent on policy support: the market value for near-zero emissions steel, cement, aluminium and ammonia reaches USD 5 billion in the CPS and USD 20 billion in the STEPS in 2035.

## There is measurable progress across energy technologies that are at different stages of development today

The positive market outlook for clean energy technologies that underpin the age of electricity has been led by policy but is increasingly driven by costcompetitiveness. Cost reductions for many technologies like solar PV, batteries, electric  cars  or  heat  pumps  have  been  enabled  by  their  modularity  and  massmanufacturing, while for others, like nuclear or geothermal, technology innovation has been a key driver. Around 80% of global solar PV and wind generation now occurs at lower levelised costs than for coal or gas, supporting a surge in global capacity  additions.  Battery  prices  have  fallen  by  75%  over  the  past  decade, boosting  electric  car  sales  and  enabling  a  larger  share  of  variable  renewable energy in electricity supply. In some emerging markets, battery electric cars are becoming cheaper to buy than comparable internal combustion engine cars. The future pace of deployment of these technologies hinges on policy support to foster markets and overcome infrastructure bottlenecks.

There is evidence of progress - albeit less steady - for technologies at an early stage of deployment, and this is moving faster than many people think. Low-emissions  hydrogen  production;  carbon  capture,  utilisation  and  storage (CCUS);  and  near-zero  emissions  material  production  typically  involve  large engineering  projects  that  rely  on  policy  support  to  scale  up  and  reduce  costs. Earlier high investor confidence and policy ambition has weakened recently, but growth opportunities exist. Global investment in low-emissions hydrogen production climbed to nearly USD 8 billion in 2025 - year-on-year growth of 80% -  and  expected  growth  in  electrolyser  deployment  to  2030  is  similar  to  the expansion  seen  as  solar  PV  began  to  ramp  up.  For  CCUS,  average  annual investment has grown more than 15-fold since 2020 to over USD 5 billion in 2025, with several landmark projects reaching final investment decisions (FIDs), though

almost 90% of announced projects have not yet reached that milestone. Since 2020, new  capacity for near-zero emissions steel production announced (105 Mt, around 5%  of today's production) has been  roughly double the conventional capacity added, but only 5% has reached FID.

Technologies at early stages of development, or with applications beyond energy, are capturing widespread attention, but their real-world viability and impact is yet to be proven. Start-ups developing technologies such as nuclear fusion, solid-state cooling, iron ore electrolysis, production of conventional cement without limestone or direct electrochemical ammonia production are now attracting increased investments. But they are still at early stages of technology readiness and face substantial technical and cost barriers. It is unlikely that they will reach significant  market  shares  within  a  decade;  if  successful,  however,  they  could trigger profound transformations, and these market shares could be worth trillions of dollars by mid-century. Several technical records for nuclear fusion were broken in  2025,  and  venture  capital  has  flowed  into  the  sector,  but  the  timeline  for commercialisation and technology costs remain deeply uncertain. Falling computation costs, more data and technical breakthroughs have driven AI capabilities  to  accelerate  energy  innovation,  but  the  extent  of  its  real-world impact remains to be seen.

## Energy technology manufacturing and trade are showing signs of resilience to changes in industrial and trade policy

Many governments are adopting an increasingly defensive posture on clean energy technology trade, seeking to shield domestic industries from foreign competition and alleged unfair practices . Early evidence of the impact of tariff hikes  in  2025  points  to  a  flurry  of  short-term  adjustments  by  manufacturers, including front-loaded shipments, deferred investments, precautionary stockpiles and a slowdown in some trade flows. However, of all global gross imports of clean energy technologies in 2025, only about 15% was accounted for by countries that now  impose  substantially  higher  tariffs.  While  tariff  and  duty  increases  are expected to put upwards pressure on average production and import costs, the impact  in  2025  was,  in  many  cases,  partly  balanced  out  by  falling  commodity prices, the substitution of imports with financially supported domestic production, and other alterations to trade patterns. Moreover, the impact of tariffs and duties on final consumer costs depends on the product: the same tariff levied on a final product like an electric vehicle has a greater impact than the same tariff applied to a system component, like solar PV modules, which typically account for around 10-15% of the  consumer  cost  of  a  domestic  rooftop  solar  installation  in  many advanced economies.

Trade continues to play a central role in the outlook for manufacturing key clean energy technologies, despite recent increases in tariffs . In the STEPS, the  global  value  of  net  trade  in  these  technologies  more  than  doubles  from USD 290 billion  in  2025  to  reach  USD 620 billion  by  2035.  China  remains  the largest exporter by a wide margin, with the value of its net exports growing to USD 375 billion  in  2035  -  the  latter  figure  is  equivalent  to  around  10%  of  the country's total goods exports today. The projected rate of increase in the value of global  trade  is  broadly  in  line  with  what  was  projected  in ETP-2024 ,  as  trade policies  are  only  one  of  many  forces  shaping  clean  energy  technology  supply chains; industrial and energy policies also play a role.

Continued  industrial  and  trade  policy  responses  to  China's  growing EV exports - worth an estimated USD 50 billion in 2025 - have increasingly re-routed them to new markets. While emerging economies accounted for less than 5% of China's EV exports in 2020, they now represent nearly 40%. In Central and South American countries, Chinese EVs are projected to make up around half of  total  EV  sales  on  average  in  the  STEPS  by  2035.  In  the  European Union, maintaining  existing  countervailing  duties  helps  prevent  the  share  of  Chinese imports in the region's EV sales from increasing significantly above today's level of around 20% through to 2035. Nevertheless, given the size of the market, the region becomes the largest source of growth for China's EV exports in absolute terms. China remains the world's largest EV exporter in the STEPS to 2035, as exports grow almost sixfold. The North American market remains virtually closed to Chinese EV imports in this scenario.

Industrial and trade policies introduced in the United States and India are boosting  downstream  stages  of  solar  PV  manufacturing  domestically, though China remains the largest producer across all supply chain steps. India experiences the largest increase in share of global production in the STEPS, rising from 3% in 2024 to more than 10% by 2035, and becomes a net exporter of modules by 2030. Existing policies and a decline in demand in the United States lead to near self-sufficiency by 2030 in the STEPS. In the European Union, the Net-Zero Industry Act has moved to the implementation phase, but the targets it sets are not accompanied by systematic financial support for domestic investment. This is reflected in the limited announcements for new solar PV manufacturing facilities and the targets not being met in the STEPS.

## Concentration in clean energy technology supply chains remains a source of vulnerability

New analysis shows that production outside the largest exporter of clean energy  technologies  could,  in  principle,  meet  most  demand  in  those countries on aggregate, but there are weak links within each supply chain. Each of the key supply chains analysed contains at least one step where less than

one-quarter of demand outside of China could be met with supply outside of China, posing risks to the resilience of the entire supply chain. China's manufacturing strengths mean the country accounts for 60-85% of production capacity for key supply chains, and over 95% for some production steps. The economic impact of a disruption would differ for each supply chain and technology. For example, each month  of  a  halt  in  battery  supply  chain  exports  from  China  would  lead  to  an estimated loss in output of USD 17 billion from electric car factories elsewhere, with facilities in the European Union accounting for over half of the losses. Each month of disruption of Chinese exports of solar supply chain components would mean that solar PV module production plants outside China lose output worth around  USD 1 billion,  with  more  than  40%  of  the  affected  output  located  in Southeast Asia and India.

Supply  chain  concentration  is  especially  acute  for  metal  and  mineral processing, and midstream production steps . Metals and mineral processing capacity outside China is adequate for materials like steel and copper, but far from sufficient for most critical minerals. Magnet rare earth elements - used in wind turbines and electric cars as well as multiple other technologies from drones to data centres - are particularly affected, as refining is dominated by China; the vulnerabilities associated with such dependencies were brought into sharp focus when China recently announced export restrictions on these elements. On the basis  of  committed  manufacturing  and  mining  projects,  and  projected  market trends in the STEPS, no major change in the diversity of clean energy technology supply chains is likely to occur before 2030.

The impact of Chinese clean energy technology manufacturing companies extends  beyond  the  country's  borders .  Chinese  firms  account  for  a  large portion of production capacity located outside China in the solar PV industry. In contrast,  Chinese  ownership  of  battery  manufacturing  capacity  outside  China remains limited (5%) but is expected to rise to around one-quarter by 2030 based on projects in construction or at FID. Dependencies in the supply chain extend to IT systems; increased digitalisation brings exposure to new, evolving cybersecurity risks that can affect energy technologies' control systems, and with them entire distribution grids.

The present wave of clean energy technology manufacturing investment is waning - the future trajectory  of  investment  will  be  shaped  by  efforts  to diversify supply chains. Global manufacturing investment for key clean energy technologies fell back slightly to just under USD 200 billion in 2024 from a high of USD 220 billion in 2023, and it is expected to have continued to decline gently through to year-end 2025. Manufacturing investment for most technologies does not return to the levels reached over the past 2 years in the STEPS and CPS through to 2035. This is largely due to a surplus of existing manufacturing capacity relative  to  current  demand  for  solar  PV  and  batteries,  and  because  increased

investment to meet future demand for EVs is offset by reduced investment for other technologies. Continued manufacturing investment in the STEPS is, in large part, driven by efforts to diversify supply chains: for example, the combined share of the European Union  and  the  United States  in global clean technology manufacturing investment increases from less than 25% in 2024 to more than 35% on average during 2031-2035.

## If not addressed, industrial competitiveness could become a stumbling block for energy and economic policy goals

In  clean  energy  technology manufacturing, the factors shaping industrial competitiveness differ across supply chains. China's competitive edge and low costs reflect decades of accumulated advantages, including innovation, largescale production, manufacturing efficiency, a skilled workforce, integrated supply chains and access to cheap resources and labour - all reinforced by consistent policy  and  financial  support   Across  all  supply  chains  considered,  there  are . opportunities to reduce the cost gap with China as experience ramps up in other countries, and through continued innovation. For batteries, higher manufacturing efficiency accounts for over 40% of the cost difference between China and Europe. Energy and labour cost differences account for a large share of the cost gap with Europe  in  energy  and  labour-intensive  steps,  such  as  upstream  solar  PV manufacturing (65% of the gap) and in wind blade production (75%). Electrolyser manufacturing is not yet established at scale anywhere, and there is a trade-off between low-cost production, efficiency and durability, meaning that production in advanced economies can still be competitive.

In  upstream industries like steel, aluminium and chemicals, energy costs remain critical to competitiveness in near-zero emissions material production. Energy costs can account for over two-thirds of total production costs in  upstream  industries;  for  near-zero  emissions  technologies,  energy  spending could be several times higher. The impacts are profound: During the 2022 global energy crisis, for example, output from upstream industries in the European Union fell sharply. In contrast, since the early 2020s, access to cheap shale gas in the United States  has  significantly  increased  its  share  of  global  petrochemical feedstock and product exports. Low-cost renewables could make hydrogen-based steelmaking cost-competitive with conventional technologies in the future under specific conditions in some major steel-producing countries like the United States, China and India. In others, like Europe and Japan, higher prices mean production costs would remain 50-80%  higher than elsewhere, surpassing regional differences for conventional steel production. Yet offshoring ironmaking to regions with  competitive  renewables  could  cut  these  cost  differences  to  30-40%,  with limited effects on jobs.

To  rise  to  the  moment,  countries  will  need  to  identify  and  play  to  their strengths and look to strategic partnerships to increase industrial competitiveness. While  downstream  industries  typically  generate  more  direct value added to the economy, strategic upstream industries are a source of indirect value  creation,  and  are  crucial  to  multiple  sectors  beyond  energy,  including defence. There is a balance to be struck between domestic production and imports of  technologies  and  materials;  the  way  this  balance  plays  out  depends  on  the relative  strategic  importance  of  these  industries.  Some  emerging  markets  with particularly low energy costs - such as in the Middle East or North Africa - could achieve production costs even lower than China's for energy-intensive processes. Producing solar PV modules made in the European Union with imported wafers from North Africa could cost almost 20% less than producing a fully EU-made module. India, Southeast Asia and the Middle East could, in principle, produce polysilicon and wafers at comparable costs to China, and Southeast Asia already has  production  capacity  in  place  for  these  commodities.  For  wind  turbines, producing in Europe while importing components from India could cost only 15% more than producing turbines in China, cutting 75% of the production cost gap between Europe and China. Strategic co-operation between countries for specific supply chain steps can reduce costs and increase diversification.

## Introduction

## Report scope and structure

The International Energy Agency's (IEA) Energy Technology Perspectives (ETP ) flagship series of reports has been providing critical insights into the technological dimensions of the energy sector since 2006. Revamped in 2020, it now serves as a guidebook for clean energy technologies globally, focusing on themes that are particularly  pertinent  for  policy  makers.  This  reflects  the  pivotal  role  of  those technologies  and  innovation  in  meeting  the  policy  goals  of  energy  security, economic development and environmental sustainability. This new edition of ETP aims  to  provide  a  comprehensive  update  on  developments  related  to  energy technologies, with a special focus on  security of supplies and  industrial competitiveness.

In  the  context  of  a  fast-changing  geopolitical  landscape,  this  new ETP edition provides  insights into the status of and  outlook  for the deployment  and manufacturing  of  clean  energy  technologies  and  related  materials,  including production  costs,  affordability,  project  pipelines,  investments  and  international trade. It also examines the drivers of market dynamics, including both demand and supply-side factors, with a particular focus on policy developments. The quantitative analysis draws on the IEA's Global and Energy Climate model (IEA, 2025a) and Manufacturing and Trade model (IEA, 2026).

The  analytical  scope  of  the  report  differs  for  technology  deployment  and manufacturing. The analysis of technology deployment covers a very wide range of  technologies  and  materials;  some,  such  as  carbon  capture  utilisation  and storage, sustainable aviation fuels, alternative propulsion systems for ships and near-zero  emissions  cement,  are  at  an  early  stage  of  deployment  today.  The analytical  scope  for  manufacturing  is  narrower and  limited  to  technologies  and components that have complex supply chains and that are mass-manufactured and traded today, such as batteries, solar PV or wind.

Chapter  1  of  this  year's Energy  Technology  Perspectives is  overarching  and addresses  ten  key  questions  related  to  energy  technologies  and  their  supply chains, each of which is inherently complex and for which the IEA has observed over the past year a need for analytical insights among high-level decision makers in government and the private sector. The remainder of the report is presented in three parts: Part A explores the outlook for the deployment of energy technologies, materials and fuels on the basis of IEA scenarios. It features visual dashboards with key metrics for each  major  technology, including market  size, cost

competitiveness,  technical  performance,  infrastructure  needs  and  innovation. Part B examines the current state and the outlook for manufacturing and trade. Part  C  assesses  the  risks  posed  by  high  levels  of  concentration  in  the  supply chains of selected clean energy technologies, examines the drivers and trends in industrial competitiveness across regions, and explores strategies for narrowing competitiveness  gaps  in  selected  clean  energy  technologies  as  a  means  of promoting diversification and reducing the concentration of supply. It ends with an overview  of  strategic  considerations  for  navigating  tensions  and  trade-offs between  different  policy  goals  in  view  of  security  risks  and  competitiveness challenges.

## Scenarios

As  in  previous  editions  of ETP , the  projections  for  technology  deployment, manufacturing  and  trade  presented  here  are  based  on  scenarios  analysis. The scenarios  differ  primarily  in  their  assumptions  about  government  policies. Three scenarios are used in this report:

-  The Stated Policies Scenario (STEPS) is  designed  to  reflect  the  direction  of travel  of  the  global  energy  sector  based  on  current  energy-related  policies, including  those  that  have  already  been  adopted,  announced,  or  are  in  the advanced planning stage - even if they are not yet enshrined in law or regulations. Examples of the latter include power sector development plans aimed at achieving a certain mix of generation assets by a specific date, regulatory reforms in the transport sector and energy efficiency targets for appliances. Policy targets are not assumed to be automatically met: in each case, their prospects are assessed taking account of market, infrastructure readiness and financial constraints. The STEPS assumes that time-bound policies continue beyond the currently-stated durations and retain a similar pace of change. However, it does not assume that aspirational goals, such as those included in the Paris Agreement, are achieved.
-  The Current Policies Scenario (CPS) sets out a pathway for the future of the energy system in which no change in energy-related policies is assumed beyond what is already in place. The CPS therefore builds on a narrow reading of today's policy  settings,  only  considering  those  that  are  adopted  in  legislation  and regulation,  and  assuming  no  changes will  be  made,  even  where  governments have indicated their intention to do so. Where existing policies target a range of outcomes, it is assumed that the lower end of the range is achieved. In the CPS, policies that are time-bound or that target specific years are not strengthened after they expire. Alongside this view of the policy landscape, the CPS also offers a generally cautious perspective on the speed at which new energy technologies are deployed and integrated into the energy system. It tends to project slower adoption of new technologies in the energy system than seen in recent years, or than projected in the STEPS.

-  The Net Zero Emissions by 2050 (NZE) Scenario is a normative scenario that maps out  a  global  pathway  for  the  energy  sector  to  achieve  net  zero  carbon dioxide (CO2) emissions by 2050, consistent with the long-term goal of limiting the rise in global average temperatures to 1.5°C (with a 50% probability). In contrast with previous editions, the NZE Scenario is no longer a low-overshoot scenario: it assumes  that  warming  exceeds  1.5°C  degrees  for  several  decades  before returning  below  1.5°C  by  2100.  This  adjustment  reflects  persistently  high emissions in recent years and the slow deployment of some key technologies. Achieving this pathway requires not only a very rapid transformation of the energy sector  but  also  large-scale  deployment  of  CO2  removal  technologies,  which remain unproven at large scale.

All scenarios use 2024 as the base year and extend annually to 2050, although the analytical focus is on the next 10 years. In some instances, historical data on energy  technology  supply  and  demand,  markets  and  technology  costs  are provisional or estimated. Population and economic growth rates are assumed to be similar in all scenarios.

As the IEA's guidebook on clean energy technologies, the primary focus of the ETP scenario  analysis  is  on  the  STEPS  to  assess  the  implications  of  current government energy-policy intentions for the future deployment, manufacturing and trade of clean energy technologies and materials. The CPS and NZE Scenario are used  mostly  for  the  purpose  of  benchmarking  to  reflect  on  lower  and  higher outlooks for deployment.

It is important to note that none of the scenarios is a prediction or forecast. Rather, they serve as analytical tools to explore the implications of different policy and technology choices. They provide a quantitative framework to support decisionmaking in the energy sector and offer strategic guidance on technology choices for governments and other stakeholders. The scenarios are consistent with those presented in the World Energy Outlook 2025 (IEA, 2025b).

## References

IEA (2025a). Global Energy and Climate Model documentation . Retrieved from:

https://www.iea.org/reports/global-energy-and-climate-model

IEA (2025b). World Energy Outlook 2025 . Retrieved from: https://www.iea.org/reports/world- energy-outlook-2025

IEA (2026). Manufacturing and Trade Model documentation . Retrieved from:

https://www.iea.org/reports/manufacturing-and-trade-model

## Chapter 1. Ten key questions about energy technologies and their supply chains

## Introduction

The global  energy  system  is  in  flux,  providing  the  backdrop  to  the  analysis  of energy technologies and their supply chains set out in this edition of the ETP . Decision-makers are confronted by a constant stream of energy-related headlines, often  stripped  of  context.  A  development  that  might  transform  investment decisions in one region may barely register elsewhere or even have the opposite effect.

Over the past year, the uncertainties clouding the outlook for energy technologies have intensified. Governments and companies are pushing ahead with plans to expand manufacturing capacity for technologies such as solar photovoltaic (PV), batteries  and  lower-emissions  steel  plants,  despite  sizeable  global  surplus capacity. Long-standing assumptions about steady cost declines are being tested, in part by the imposition of import tariffs whose implications are not always clear. As the energy system electrifies, optimistic expectations about demand growth spurring  investment  sit  uneasily  alongside  reports  of  shortages  in  critical  grid components. In areas such as carbon capture, utilisation and storage (CCUS) and hydrogen, announcements of record investment coincide with what appear to be contradictory claims of sluggish deployment and rising costs.

This chapter draws together the latest IEA analysis of these issues and highlights insights from the chapters that follow, organised around ten questions on energy technologies  and  supply  chains.  The  questions  and  answers  are  intended  to engage senior decision-makers by providing a clear, factual and neutral guide to today's most pressing developments - not an exhaustive account, but a concise guide to what matters now. Those questions are:

- 1. How are recent shifts in trade policy affecting clean energy technology supply chains?
- 2. How will today's low profits in clean energy technology manufacturing affect innovation and investment?
- 3. How can policy help close the cost gap with the People's Republic of China (hereafter, 'China') in energy technology supply chains?

- 4. Is the current electricity transformer shortage a cause for concern?
- 5. Is there a case for investing in a domestic battery sector when China holds such a large cost advantage?
- 6. Has the hydrogen bubble burst?
- 7. Is carbon capture, utilisation and storage finally taking off?
- 8. Large, modular and fusion reactors all have renewed momentum: how quickly can nuclear be brought online?
- 9. Can heavy industries in advanced economies restore their competitive edge?
- 10.  Is there a technology on the horizon that can replicate the explosive growth of solar PV and batteries?

Some  of  these  questions  concern  technologies  such  as  transformers,  CCUS, hydrogen  and  nuclear  energy  that  fall  outside  the  scope  of ETP-2026 ,  which focuses on clean energy technology supply chains. The answers to the others draw directly on data and assessments presented elsewhere in the report; these are  summarised  here,  with  references  in  the  text  to  guide  readers  to  the  full analysis.

## 1. How are recent shifts in trade policy affecting clean energy technology supply chains?

## Why it matters

Trade policy has rarely been so prominent in global headlines as in recent months. The total number of restrictive measures in place worldwide rose sixfold in less than a decade, from just over 600 in 2015 to nearly 3 300 in 2024 (Global Trade Alert, 2025). The first half of 2025 brought another wave of announcements, with tariffs being the predominant tool. Discriminatory trade measures can take several forms, but the result in most cases is to raise the relative price of imports. Tariffs are intended to shield domestic producers from foreign competition, but some of the increased costs of doing so will fall on consumers. Other measures such as quotas, export controls, border adjustments and standardisation rules, add further restrictions to cross-border trade.

The  manufacturers  of  clean  energy  technologies  are  not  immune  to  these developments.  The  rapid  global  rollout  of  many  clean  energy  technologies  in recent  years  has  been  underpinned  by  international  trade,  which  has  enabled economies of scale, specialisation and vigorous competition. Solar photovoltaic (PV) module prices have tumbled by around 85% over the past 8 years, driving a

near-sevenfold increase in global deployment. Theoretically, mounting tariffs and other trade measures that push up prices risk stalling - or even reversing - these gains  in  the  countries  that  impose  them.  Yet  trade  policy  does  not  operate  in isolation. Its effects on costs, prices and deployment depend on how it intersects with wider energy, climate and industrial policies, which can blunt or amplify its influence.

## What is happening

Many governments are adopting a more defensive posture on trade, aiming to shield domestic industries from foreign competition and alleged unfair practices. Low-cost Chinese exports of clean energy technologies are accelerating deployment in several markets - especially in emerging economies - but growing unease over China's surplus industrial capacity and surging export volumes has prompted  trade  policy  action  from  the  United States,  European Union  and Canada. This is exemplified by these countries' deployment of duties to target imports of Chinese solar PV panels, wind turbines and electric vehicles (EVs) and 'level the playing field' for domestic producers. More sweeping tariffs have also emerged:  recently  in  the  United States,  and  for  a  longer  period  in  India,  the government has imposed broad tariffs covering a wide range of goods.

Table 1.1 Announced trade-weighted average import tariff and duty rate on selected clean energy technologies, 2023 and 2025e

| Product              | United States   | United States   | United States   | China   | China   | China   | European Union   | European Union   | European Union   | India   | India   | India   |
|----------------------|-----------------|-----------------|-----------------|---------|---------|---------|------------------|------------------|------------------|---------|---------|---------|
| Product              | 2023            | 2024            | 2025e           | 2023    | 2024    | 2025e   | 2023             | 2024             | 2025e            | 2023    | 2024    | 2025e   |
| Solar PV modules     | 16%             | 246%            | 191%            | 0%      | 0%      | 0%      | 0%               | 0%               | 0%               | 38%     | 21%     | 21%     |
| Wind nacelles        | 1%              | 1%              | 23%             | 8%      | 8%      | 18%     | 3%               | 3%               | 3%               | 10%     | 8%      | 8%      |
| Battery cells        | 2%              | 19%             | 56%             | 9%      | 9%      | 9%      | 2%               | 2%               | 3%               | 20%     | 15%     | 16%     |
| Electric vehicles    | 2%              | 2%              | 23%             | 15%     | 15%     | 16%     | 6%               | 16%              | 13%              | 125%    | 56%     | 56%     |
| Average on all goods | 2%              | 2%              | 18%             | 3%      | 3%      | 13%     | 3%               | 3%               | 3%               | 12%     | 12%     | 12%     |

Notes: e = estimated. The rates are calculated by combining all applicable duties, including base tariffs or preferential reductions, anti-dumping and countervailing duties and other surcharges, and weighting them by each partner country's share in total imports. Values for all goods are taken directly from The Budget Lab analysis and refer to the weighted average tariff rate across all imported goods.

Sources: IEA analysis based on World Trade Organization (2025); The White House (2025); US National Archives (2025); International Trade Administration (2025); Office of the United States Trade Representatives (2025); China, Ministry of Finance (2025); European Commission (2025); Diário Oficial da União [Official Diary of the Union] (2025); Sitharaman (2025); Brown (2025); Financial Times (2025); World Bank (2025); and The Budget Lab (2025).

For clean energy technologies, the steepest tariff increases have occurred in the United States, though they did not start from a blank slate. Several technologies or components, including solar PV modules, already faced substantial duties in 2024  (Table  1.1).  China  first  responded  with  broad  tariffs  on  a  wide  range  of US goods and export  controls  on  a  set  of  materials  and  components  that  are critical to clean technology supply chains, from rare earth elements and magnets to  high-energy-density  battery  materials  and  parts.  Yet,  as  part  of  the  October 2025  trade  agreement,  China  agreed  to  suspend  many  of  these  retaliatory measures  (see  Chapters  4  and  5).  Other  US  trading  partners,  notably  the European Union, have launched public consultations, but have yet to take formal action. Elsewhere, tariff levels have remained broadly unchanged, though they remain high in India.

## What it means

While tariffs are changing frequently at the moment, and the full impacts of the uncertainty this generates will take time to register, it is instructive to examine the potential impact on production costs. Early evidence of the impact of the recent tariff  hikes  in  2025  points  to  a  flurry  of  short-term  adjustments,  including  frontloaded shipments, deferred investments, precautionary stockpiles and a slowdown  in  trade  flows.  Disregarding  these  short-term  impacts,  our  analysis shows that, where they are increased, tariffs put upwards pressure on average delivered costs (i.e. the average cost to customers considering both imported and domestically produced units).

In  the  United States,  we  estimate  that  average  delivered  costs  increased  by around  100%  for  solar  PV  modules  during  2023-2025  and  by  around  8%  for battery  cells  during  2024-2025  (periods  of  sharp  tariff  increases  for  each technology). However, the upwards pressure on average costs due to tariffs is substantially offset by changes in material and component prices, and changes to trade patterns, including changes in the share of domestic production. Other key importing countries and regions like India and the European Union saw overall decreases in average delivered costs over the same periods, with the exception of solar PV modules in the European Union (Figure 1.1).

Two main factors blunt the impact of recent tariff hikes globally: the United States - where the sharpest tariff increases have taken place - accounts for about 15% of global gross imports (including intra-EU trade); and higher domestic production and shifting trade flows dilute the effect of pricier imports within the US market. The  rise  in  costs  may  therefore  remain  modest  relative  to  the  headline  tariff increases, even though the measures clearly run against the long-standing trend of declining costs driven by innovation and economies of scale. For end users, the

impact  is weaker  still. In markets  such  as  the  European Union  and  the United States, for example, PV modules typically represent only 10-15% of the cost of a residential rooftop solar installation.

## Figure 1.1 Changes in average delivered costs for solar PV modules and battery cells in key importing regions, 2023-2025e

<!-- image -->

- Material price changes (incl. tariffs and duties on materials)
- Tariffs and duties changes (directly imposed on product)
- Changes in trade patterns (incl. domestic production)
- Net change

IEA. CC BY 4.0.

Notes: e = estimated. The average cost in 2025e reflects the impact of tariffs announced as of 1 November 2025 on new imports, without accounting for use of stockpiles of earlier imports. Delivered costs refer to the weighted average unit cost of supply, including both domestic production and imports, with the latter including tariff and transport costs. Costs presented are inclusive of explicit financial support mechanisms in industrial strategies, such as the production tax credits in the US Inflation Reduction Act. The increase in component costs due to tariffs is included in 'Material price changes'. Sources: IEA analysis based on a range of data sources; see IEA (2026), for details.

The impact of tariff increases in 2025 on the average delivered cost of key technologies has often been outweighed by declining costs for key inputs and shifting trade patterns.

There are, however, early signs that firms are already adjusting their investment and  trade  strategies.  Some  Chinese  EV  manufacturers  have  shifted  planned investments towards the European Union following the introduction of countervailing duties in 2024. In solar PV, steep anti-dumping and countervailing duties on cells and modules from Southeast Asia have contributed to the scalingback of planned capacity in parts of Southeast Asia.

Over the medium-term, other forces will come into play. Despite the recent tariff increases,  international  trade  remains  central  to  the  outlook  for  clean  energy technology  manufacturing.  In  the  Stated  Policies  Scenario  (STEPS),  in  which global tariffs are assumed to remain at their 1 November 2025 levels, the value of global trade in the leading technologies more than doubles over the next decade, broadly in line with the increase projected in ETP-2024 . This is because tariffs are just one part of a wider policy landscape: industrial and energy policies continue to exert significant influence on the development of supply chains.

- Other

Industrial policies remain powerful drivers of domestic manufacturing, notably for solar  PV.  India's  Production  Linked  Incentive  scheme  and  US  production  tax credits under the Inflation Reduction Act continue to provide strong incentives. In the STEPS, India and the United States meet virtually all of their demand by 2030, though both remain dependant on imports of wafers and polysilicon, respectively (Figure  1.2).  Tariffs  are  already  visible  in  market  prices:  higher  import  costs contribute to a gap of about 150% between US domestic prices and those in other major markets. The gap is large enough to sustain domestic output with limited effect on deployment, given the small share of modules in the total cost of solar PV installations.

Energy policies that shape domestic demand also strongly impact the viability of domestic manufacturing. The outlook for US battery demand - both for EVs and stationary  storage  applications  -  has  shifted  markedly  since ETP-2024 .  The repeal of the Clean Vehicle Tax Credit 2025 and ongoing revisions to California's Advanced Clean Cars II regulation and national fuel economy standards lead to a projected 60% reduction in US battery demand in 2030 in the STEPS compared to the earlier projection. This lowers import needs and results in significant surplus domestic manufacturing capacity based on today's project pipeline (see Chapter 5).  By  contrast,  other  major  importing  regions  have  seen  little change in demand-side policies and have not raised tariffs to the same extent, leaving their outlooks broadly unchanged.

Continuing industrial and trade policy responses to China's growing EV exports worth around USD 35 billion 1 in gross terms in 2024 - are already reshaping trade patterns. Emerging economies accounted for just over 5% of China's EV exports in  2020; they now take one-third. In major emerging markets without plans for large-scale manufacturing, particularly in Latin America, imports from China are projected to make up around half of total EV sales in the STEPS by 2030. The European Union  remains  the  largest  single  market  for  Chinese  EV  exports  in 2030, though China's current near 20% share of EU EV demand does not rise further.  In  Southeast  Asia,  where  low-cost  Chinese  EVs  and  favourable  trade policies are boosting sales today, industrial strategies continue to drive investment in domestic manufacturing capacity, which expands eightfold between 2024 and 2030 in the STEPS. By 2030, less than 5% of EVs sold in the region are projected to come from China, down from more than half.

1 Unless stated otherwise, USD figures are real 2024 dollars in market exchange rate terms throughout this report.

Figure 1.2 Key indicators for manufacturing and trade of selected clean energy technologies by selected countries and regions in the Stated Policies Scenario, 2023-2030

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario; EVs = electric vehicles; EMDE = emerging markets and developing economies; AE = advanced economies. Battery demand refers to EVs and battery energy storage system deployment.

Tariffs  are  just  one  part  of  a  wider  policy  landscape,  with  industrial  and  energy  policies continuing to exert significant influence on the development of supply chains.

## 2. How will today's low profits in clean energy technology manufacturing affect innovation and investment ?

## Why it matters

Governments around the world are doubling down on industrial strategies and policies  to  support  clean  energy  technology  manufacturing.  Yet  the  context  is evolving  rapidly:  razor-thin  margins  and  oversupplied  markets  that  started  to emerge before 2025 have only intensified, while tighter public finances are making it harder to lure investment through targeted subsidies. Policy makers now face a delicate balance between the longer-term economic and environmental benefits of faster deployment and expanded production of equipment that will power future energy systems, and more immediate economic priorities. What the right balance will look like will vary by country and technology, depending on energy security concerns, comparative advantages, existing skills and how far the equipment has become commoditised. As global supply chains grow more complex, understanding how they generate skilled jobs in industrial hubs and how energy systems can be shielded from equipment shortages during trade disruptions is becoming ever more important.

The past year has seen a steady flow of headlines on plummeting margins across the clean technology manufacturing sector. Meanwhile, many firms, eyeing public support, are eager to launch demonstration and commercial projects to produce emerging technologies, with construction already underway in some cases. The weak finances of many producers raise difficult questions. What happens when new capacity is added to well-supplied markets? Are some of these technologies structurally destined to be low-margin businesses? And if so, what does that mean for public budgets and for the ability of firms to fund innovation? A common critique is that governments expect companies to both operate in a low-profit environment and  simultaneously  invest  in  more  diversified  supply  chains  and  technology innovation. Does that place a bigger burden on governments to undertake R&amp;D?

## What is happening

Profit margins for energy technology manufacturers have been generally low and volatile in recent years, though the degree of volatility varies by technology and region. Global excess capacity and fierce competition, particularly in China, have driven steep price cuts; solar PV modules have at times been sold below cost. The Chinese government has signalled a willingness to  curb the  intense  local competition  that  has  resulted  partly  from  public  support  to  manufacturers,  but meaningful consolidation is likely to take time.

The  prices  of  solar  PV  modules,  wind  turbines  and  batteries  have  fallen dramatically over the past decade. Gains in manufacturing efficiency, technological innovation and economies of scale have been major drivers. The globalisation of supply chains - and the ability to trade components - have also helped push down prices, as detailed in Chapter 4. Part of the decline reflects companies accepting margins far below those typical of 'blue-chip' firms. This is most  pronounced  in  China,  where  manufacturers  have  expanded  capacity aggressively to win market share. Extensive vertical integration has helped those firms withstand intense price pressure, enabling them to absorb thinner margins and push prices down across international markets (Figure 1.3):

-  The solar PV industry has become highly commoditised, dominated by large Chinese producers - seven of the world's ten largest manufacturers are based in  China  -  and  characterised  by  fierce  price  competition  that  has  eroded profitability. The average profit margin (based on earnings before interest and tax, or EBIT) of the world's largest publicly listed firms hovered around 10% from 2015 to 2023, but turned negative in 2024 despite record global sales, driven by a sharp drop in margins among Chinese manufacturers. The top seven Chinese producers collectively posted losses of close to USD 4 billion. By  contrast,  average  profit  margins  for  the  world's  top  500  manufacturing companies did not experience a similar decline, remaining close to 10% in 2024.

-  Wind manufacturers face a different mix of pressures. Policy changes have made future demand less predictable, and the expected benefits of industrywide standardisation have yet to materialise. Instead, supply chain disruptions, delivery delays, forward-pricing practices and rising input costs have battered profits,  especially  in  the  European Union.  Adjustments  to  pricing  strategies and contracts have lifted margins for most firms in advanced economies since profits bottomed out in 2022, but global average margins have continued to fall  as  the  performance  of  a  few  large  manufacturers  has  deteriorated.  In China, the phase-out of central government subsidies for wind farms in 2022 pushed margins towards zero in 2024.
-  Battery-makers have  fared slightly better. The  industry remains  more concentrated than solar PV and wind, with scale and technology advantages still concentrated among a small group of leading firms, including one major Chinese producer - CATL - that significantly boosts the global average (see Chapter 4).  This  more  consolidated  industry  structure  has  helped  maintain relatively  stable  margins  in  China.  In  Europe,  however,  production  costs remain  roughly  50%  higher  than  in  China,  denting  profitability  and  eroding market share.

Figure 1.3 Profit margins for manufacturers of selected clean energy technologies by region, 2015-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: Profits are calculated on earnings before interest and tax basis. Regions are weighted by revenue. Companies are categorised by their headquarters. Covers publicly listed companies only. Includes companies representing 65% of the global market for solar PV, 80% for wind and 65% for batteries. Data for 2025 is up to June 2025.

Source: IEA analysis based on S&amp;P Global (2025).

Intense competition in China's solar PV sector has depressed profits worldwide, but the more consolidated structure of the battery sector has maintained comparatively stable margins.

## What it means

Industrial strategies to build new supply chains must strike a fine balance: keeping prices high enough  for producers  outside China  to reinvest and  remain competitive, without eroding affordability or access and without insulating firms from competitive discipline. Designing effective policies to achieve these goals is no small feat.

Profitability is not merely a cyclical concern or a matter for shareholders. Energy technologies  are  strategic  assets,  which  justifies  government  intervention  to ensure  the  long-term  durability  of  both  established  and  emerging  industries. Persistently low margins weaken firms' ability to invest in new capacity and R&amp;D, slowing innovation and eroding competitiveness.

Because companies often target a relatively stable ratio of R&amp;D to revenue, falling revenues  have  immediate  consequences.  Between  2022  and  2024,  R&amp;D spending by solar PV manufacturers fell by around 25%, driven largely by Chinese firms (Figure 1.4), while R&amp;D spending in the wind sector declined by around 15%. Capital investment followed a similar pattern, falling 10% in solar PV and 20% in wind. Battery producers are an exception: total R&amp;D spending continued to rise in 2024, led by companies in China, Korea and Japan, despite lower revenues. Yet even here, the share of revenues devoted to R&amp;D has slipped from 8% in 2015 to 5% in 2024 - closer to the levels seen in the more mature solar PV and wind sectors.

Within  each  industry,  more  profitable  firms  typically  invest  a  larger  share  of revenue  in  R&amp;D.  Among  battery  manufacturers,  the  top  two-thirds  ranked  by profitability spent a proportion of revenue on R&amp;D that was five times higher than the bottom third over 2015-24. This pattern is particularly pronounced for batteries and, to a lesser extent, wind - sectors where ongoing innovation is essential to further  cost  reductions.  The  link  is  weaker  for  solar  PV,  where  technological leadership  matters  less  than  economies  of  scale  and  the  ability  to  operate efficiently.

The main aims of industrial policy - encouraging domestic production to guard against import disruption, ensure supply chain security, support economic growth and achieve technological leadership - are in jeopardy if margins stay low and depress investment in new capacity and innovation. In this case, policy makers need to devise strategies that target risks with specific tools. Import tariffs and other forms of government aid can, in some cases, be appropriate provisional tools to  help  domestic  producers  compete.  For  example,  new  tariffs  have  helped  to shield US solar PV companies and EU EV manufacturers from excess capacity in China. However, they should be linked to global price benchmarks to maintain downward price pressure over time and prevent domestic firms from becoming 'flabby' and inefficient.

Figure 1.4 R&amp;D and overall capital expenditure, and average R&amp;D intensity according to profitability for selected clean energy technologies, 2015-2024

<!-- image -->

IEA. CC BY 4.0.

Notes: CAPEX = capital expenditure. Profits are calculated based on earnings before interest and tax. R&amp;D expenditure is calculated as a share of total revenues. Lines represent revenue-weighted average of R&amp;D intensity (expenditure over revenues) by percentile of profit margins (0-33%, 33-66%, 66-100%). Covers publicly listed companies only. Includes companies representing 65% of the global market for solar PV and wind, and 60% for batteries. Source: IEA analysis based on S&amp;P Global (2025).

Battery  manufacturers  have  sustained  rising  R&amp;D  and  capital  spending  despite  lower revenues, with the most profitable companies investing far more than their weaker rivals.

Other measures may be needed to keep innovation on track. Ensuring innovators have access to capital and credible growth prospects can accelerate progress in manufacturing  efficiency,  smarter  material  use  or  advances  in  chemistry  and design.  Governments  have  a  range  of  tools  at  their  disposal,  including  tax incentives,  concessional  finance  for  scale-up  and  dedicated  R&amp;D  grants  (IEA, 2025e).  Additionally,  regional  manufacturing  hubs  might  be  encouraged  to develop more integrated supply chains. In the solar PV sector, vertically integrated producers (IEA, 2022b) have generally achieved bigger and more stable profits than  those  confined  to  manufacturing  individual  components  or  assembly  of finished modules. However, intervention in this area demands careful planning and  a  realistic  assessment  of  the  scale  and  scope  required  to  capture  these advantages.

## 3. How can policy help close the cost gap with China in energy technology supply chains?

## Why it matters

China  is  the  undisputed  giant  of  clean  energy  technology  manufacturing.  It produced around 80% of solar PV modules and batteries globally, as well as over 70% of nacelles for wind turbines - more than any other country and at prices other regions struggle to match. While the vast majority of that production serves the domestic market, the country is also a major exporter. Governments in Europe, North  America  and  elsewhere  are  understandably  keen  to  build  up  their  own industries, both to reduce dependence on imports and to capture the economic dividends of industrial growth.

One obstacle is cost. Two decades of large-scale investment, industrial integration and  policy  support  to  scale  up  domestic  demand  and  manufacturing  have  left Chinese firms highly competitive. For now, substituting Chinese imports with local output means higher costs for producers and consumers alike, unless governments step in with subsidies.

However, this does not mean the production cost gap is unbridgeable. Careful policy design - grounded in a realistic understanding of where cost reductions are achievable - can narrow, and in some cases close, the gap. That entails targeted investments  in  manufacturing  and  automation,  demand  policies  that  support economies of scale and reforms to electricity markets aimed at lowering prices. Without  such  focus,  there  is  a  risk  that  these  industries  can  survive  only  with constant injections of public financial support or measures to restrict trade.

## What is happening

Production costs in China can be less than half those in advanced economies, such  as  the  European Union,  specifically  in  some  production  steps.  But  the reasons differ markedly across technologies (Figure 1.5):

-  Solar PV: One-third of the gap in cell and module manufacturing costs stems from higher energy prices; for example, European firms pay two to three times more, on average, for electricity than their Chinese rivals. Scale also matters: larger Chinese plants explain up to 20% of the cost differential. Lower labour costs contribute much less than energy in polysilicon and wafer production.
-  Wind power: For turbine blades, labour accounts for around 75% of the gap, with cheaper energy playing a negligible role. For nacelles, the labour share is far smaller, at about 10%, with components accounting for almost the entire cost gap, though lower component costs can themselves be a function of lower labour costs and economies of scale.

-  Batteries:  China's  edge  is  strongly  supported  by  manufacturing  efficiency, thanks to integrated supply chains, advanced manufacturing processes and production scale. Access to cheap components also contributes.
-  Heat pumps: The gap relates primarily to cheaper labour, components and production scale rather to energy costs. Around half of the total cost difference stems  from  China's  huge  component  manufacturing  base,  especially  for compressors, and the scale of heat pump manufacturing. It supplies about 90% of global demand for rotary compressors and roughly one-third for scroll compressors.  Vertically  integrated  supply  chains  and  China's  dominant position in global air-conditioner production also contribute to lower costs.
-  Electrolysers:  Cheaper  components  -  in  some  cases  linked  to  different technology choices such as alkaline rather than proton exchange membrane electrolysers  -  explain  most  of  today's  cost  gap.  Production  scale  could become a more important factor if manufacturing capacity expands much more rapidly  than  in  Europe  over  the  next  few  years.  Several  of  China's  major electrolyser manufacturers have also entered the sector from the solar PV and wind  industries,  drawing  on  their  established  manufacturing  know-how  and well-developed component supply chains.

## Figure 1.5 Difference in manufacturing costs in China compared with the European Union for selected clean energy technologies by cost factor, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: CAPEX = capital expenditure. The analysis is based on the levelised cost of production, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. Downstream solar PV refers to cell and module production; upstream solar PV refers to polysilicon and wafer production. Batteries refer to lithium-ion battery cells using lithium nickel cobalt manganese oxide as cathode active material and graphite as anode active material. Labour cost for battery production in the European Union is calculated as the productionweighted average of labour costs in 2024. Components refers to the cost of component and material inputs. Efficiency refers to production efficiency and is inversely proportional to scrap rates and manufacturing line downtime, and directly proportional to automation of production processes.

The reasons for China's lower manufacturing costs vary widely by technology, requiring different policy mechanisms to help close the gap.

The often-cited story of cheap Chinese labour is insufficient as an explanation for China's cost advantage; outside labour-intensive products like turbine blades, it explains  little.  As  manufacturing  becomes  more  automated,  the  importance  of labour costs will diminish further. In some instances, China's faster adoption of automation means that labour intensity is already lower there than in high-income regions, even though Chinese labour remains cheaper.

Energy costs are also not the primary source of China's competitiveness, except in  solar  PV  manufacturing  -  specifically  for  polysilicon  and  wafer  production. China's real strengths lie in scale, tightly integrated supply chains and process efficiency. Some of these advantages have been shaped by financial and other forms  of  government  support,  especially  during  the  early  stages  of  industry development (see Chapter 4).

## What it means

Closing the gap is possible. Policies will be most effective if they concentrate on areas  where  manufacturing  efficiency  gains,  scale  effects  and  innovation  can make a difference - rather than, for example, trying to compete on the basis of low-cost  energy  or  labour.  Every  country  should  take  into  consideration  their domestic  strengths  and  comparative  advantages,  as  well  as  tolerance  for geographically  concentrated  supply  chains,  when  identifying  priority  areas  for onshoring manufacturing. Lithium-ion batteries show the way: in the European Union,  their  production  cost   could  be  cut  by  one-third  -  closing  a 2 staggering  80%  of  the  gap  with  China  -  through  measures  that  enhance manufacturing efficiency and  secure  access  to cheaper  components  and materials. Continuous improvements in manufacturing processes, supported by learning-by-doing, innovation and automation, can deliver substantial efficiency gains. At the same time, partnerships with countries that supply key materials and components can secure access to competitively priced inputs.

Economies of scale are indispensable for all types of technology. However, no manufacturer will invest without confidence in future demand. Governments can play a role in providing it. Fuel economy and emissions standards for vehicles, for example, give clarity to investors and guarantee markets for EVs and batteries, which  in  turn  can  support  the  development  of  enabling  infrastructure  such  as charging  stations.  Targets  for  clean  energy  deployment  and  long-term  public procurement  programmes  can  also  help.  Larger,  more  predictable  markets encourage standardisation, learning-by-doing and lower unit costs - a key driver

2 Production costs refer to the estimated average direct manufacturing cost in the European Union if key battery components (cathode and anode active materials) were produced domestically.

behind wind turbine price reductions in recent years. Tax credits, concessional loans and investment guarantees can help attract capital to larger plants to reach competitive scale, but not to keep sub-scale facilities afloat.

Governments can also encourage domestic manufacturers to seek partnerships with leading equipment makers and support training programmes. New entrants in complex industries such as batteries and solar PV often struggle with low yields, due to lack of experience related to the complicated manufacturing processes for these  products.  Partnerships  with  established  manufacturers  can  raise  quality faster, transfer know-how and strengthen local supply chains. High-yield factories, with  less  waste  and  fewer  defects,  mean  lower costs.  Close  relationships  with nearby customers, a traditional strength in sectors like cars and chemicals, can also  provide  an  edge.  In  addition,  policy  makers  can  support  firms  seeking  to compete  on  quality  as  well  as  cost;  for  example,  by  focusing  on  higher-value products in key niches that are less common in Chinese portfolios. Some nonChinese electrolyser producers are adopting such an approach, by focusing on the development of non-alkaline electrolysers, such as proton exchange membrane or solid oxide electrolysers.

Figure 1.6 Current and future committed battery cell and electrolyser manufacturing capacity by technology in China and the rest of the world, 2030

<!-- image -->

IEA. CC BY 4.0.

Notes: NMC = lithium nickel manganese cobalt oxide; NCA = lithium nickel cobalt aluminium oxide; LFP = lithium iron phosphate; PEM = proton exchange membrane. Committed manufacturing capacity in 2030 is based on current manufacturing capacity, committed expansions and additional committed capacity. Committed refers to projects that are either under construction or have reached a final investment decision. Solid state refers to semi-, quasi- and all-solid-state batteries. Due to limited data availability on the status of sodium-ion battery projects, the same committed-to-announced capacity ratio as for new lithium-ion battery plants is assumed for sodium-ion capacity.

Sources: IEA analysis based on data from BMI (2024); and BNEF (2025) as well as announcements by manufacturers and personal communications, gathered by the IEA.

Battery and electrolyser producers outside China are focusing on different technologies other than LFP batteries and alkaline electrolysers - in order to compete.

Innovation - a necessary condition for success, though insufficient on its own - is another obvious area where governments can make a difference. This can take the form of direct involvement in R&amp;D and demonstration projects, measures to help  technologies  cross  the  so-called  'valley  of  death'  between  early-stage development  and  commercialisation,  or  incentives  that  mobilise  private  sector investment.  Breakthroughs  will  certainly  play  a  role,  but  only  if  they  deliver significant  cost  or  performance  improvements  over  market-leading  products, which are increasingly 'good enough' for most applications (IEA, 2025a). Chinese manufacturers  are  also  continually  innovating  and  optimising,  making  this  a moving target. Prioritising innovation funding in areas with the greatest potential upside will be key to effective strategies.

Energy costs are not a critical factor for all technologies, but high electricity prices can  be  a  major  handicap  for  the  solar  PV  sector  and  a  drag  on  certain  other electrified  manufacturing  processes  -  especially  in  Europe.  Policies  to  reform wholesale  power  markets  in  order  to  expand  the  role  of  low-cost  and  lowemissions electricity and provide competitive tariffs for electricity-intensive energy technology manufacturing can therefore help to close the cost gap.

Ultimately, governments are faced with tough strategic choices. Each country will define its industrial strategy according to its strengths and weaknesses. For most countries, it is not realistic or necessary to try to compete effectively across all parts  of  the  relevant  clean  energy  technology  supply  chains.  Smart  industrial strategy means focusing efforts where scale and efficiency can deliver results, by stimulating demand, cutting input costs and accelerating learning. Every tool to boost  competitiveness  -  whether  it  takes  the  form  of  subsidies,  standards  or funding for innovation - comes with a price tag. The priority should be to identify technologies where cost parity is genuinely within reach, or that serve to meet a particular strategic interest, and avoid propping up those where it is not. Evidencebased choices will determine whether new supply chains are competitive, resilient and built to last.

## 4. Is the current electricity transformer shortage a cause for concern?

## Why it matters

A transformer is a passive device that transfers electrical energy between circuits and alters voltage levels, stepping up voltage for efficient long-distance transmission and stepping down voltage for safe local distribution. It is a critical link in electricity grids, connecting generation, transmission, distribution and end users. In the United States alone there are between 60 and 80 million distribution

transformers,  while  in  the  European Union  there  are  roughly  4.4 million  power transformers.  Reports  of  shortages  in  this  essential  equipment  have  therefore caused concerns among grid operators and policy makers.

A lack of transformers, or a sharp rise in their cost, could stall electricity projects of all kinds. In an era of rapid electrification, such bottlenecks could derail policy goals, from leadership in artificial intelligence (AI) to the rollout of EVs. Uneven impacts across regions could undermine the competitiveness of key industries. In several large economies, ageing infrastructure poses a further risk: without timely replacement of transformers and other critical assets, grid failures could become more frequent.

## What is happening

There is clear evidence of rising lead times and prices in the transformer market over the past few years. In the United States, lead times for deliveries of some transformer classes have tripled to around 150 weeks since 2021, while prices have risen nearly 70% since 2020. These trends are the result of demand growth outpacing investment in new manufacturing capacity. Unexpectedly rapid growth in global demand is being driven by four main factors:

-  Replacement of ageing infrastructure in advanced economies.
-  Deployment of distributed electricity generation, which requires transformers at each network connection.
-  Construction of large new electricity-consuming facilities, such as data centres and EV charging networks.
-  Rapid  expansion  of  power  grids  in  emerging  markets  and  developing economies (EMDEs).

Global demand growth is being led by fast-growing economies such as China and India, which are expanding grids to connect more distributed power sources and supply new customers. In Europe, electrification and higher renewables penetration are also pushing up demand, resulting in similar lead times as in the United States. In America, grid upgrades (70% of transformers are over 25 years old), renewable energy projects, EV charging and the fast-expanding data centre sector are the main drivers. By 2030, US electricity demand from data processing is expected  to  exceed  that  of  all  domestic  energy-intensive  manufacturing combined. Because these applications require similar transformer types, and data centre developers often pay more, they are pulling ahead in procurement.

The transformer supply-demand gap varies by region. The tightest market is in the United States, where past boom-bust cycles have made manufacturers reluctant to expand capacity until demand is certain, and where data centres and liquefied

natural gas projects have added strong, sustained demand. While China appears to be well supplied thanks to its large export volumes, the situation in Europe is more  complex:  the  region  can  export  significant  quantities  of  oil-based  highvoltage transformers yet still needs to import large volumes of transformers of all types, suggesting a tight market.

Market tightness is most severe for large power transformers. The largest ones step  up  or  step  down  high  voltages  used  for  long-distance  transmission,  with capacities of up to 1 000 megavolt amperes (MVA) and weights of 400 tonnes enough to handle the output of a nuclear plant. A 12-turbine wind farm typically needs  40-60 MVA,  similar  to  the  requirement  for  stepping  down  high-voltage supply to a large data centre. These units are custom-built to fit specific projects and space constraints, requiring high-tech equipment and a skilled workforce. This complexity limits  new  entrants  and  has  led  to  a  concentrated  global  market  in which  manufacturers  avoid  maintaining  large  surpluses.  Added  to  their  sheer weight, oil-filled transformers contain chemicals that are awkward and expensive to  transport  over  long  distances.  This  means  spare  manufacturing  capacity  in other parts of the world cannot easily fill any gap in local supply. Alternative oils such  as  esters  are  becoming  more  common,  but  do  not  eliminate  logistical constraints.

Smaller distribution transformers, which step down voltages for use in homes and factories,  are far more compact - an EV fast-charging station rated at 350 kW typically  needs  a  2-3 MVA  unit  -  and  more  standardised,  making  them  much easier to ship and  trade internationally. In the United States, distribution transformers typically fall in the 2-5 MVA range, whereas, in Europe, capacities below 1 MWA are more common. Despite these regional differences, their relative uniformity and manageable size mean they are less affected by regional market imbalances.

Inflation has added further upward pressure to transformer prices. Raw materials - especially copper for windings and grain-oriented electrical steel for cores - can account for up to half of total costs; both have seen significant price increases since 2021 (Figure 1.7).

## Figure 1.7 Global average prices of imported transformers, 2017-2024

<!-- image -->

IEA. CC BY 4.0.

Notes: Based on total import values and mass reported in customs data. Values are inflation-adjusted. Dry refers to drytype transformers; low voltage refers to power capacity rated below 650 kVA, medium voltage to 650-10 000 kVA and high voltage to above 10 000 kVA.

Source: IEA analysis based on Sinoimex (2025).

Transformer prices have risen steeply since 2021 as manufacturing has struggled to keep pace with rising demand, with oil-based transformer prices rising the most.

## What it means

Manufacturing  capacity  for  transformers  is  expanding,  but  any  fundamental rebalancing  of  supply  and  demand  will  take  years.  At  first  glance,  trade  flows suggest  that  global  markets  are  adapting.  The  combined  value  of  transformer exports  and  imports  more  than  doubled  between  2020  and  2024,  with  China, Mexico, Europe 3 and Korea emerging as the main exporters, and the United States and the Middle East as the main importers (Figure 1.8). Yet the headline figures are misleading. Much of the increase reflects cost inflation rather than rising volumes: there is little evidence that more transformers are actually being shipped across borders.

Limited  flexibility  to  address  local  market  imbalances  through  trade  has  left suppliers  in  advanced  economies  relatively  well-insulated.  Despite  rising  input costs, manufacturers have generally preserved healthy margins, often reaching 20%  of  end-customer  prices.  While  international  trade  continues  to  play  an important  role  in  alleviating  cost  pressures,  resolving  structural  bottlenecks ultimately hinges on sustained investment.

3 Europe refers here to the European Economic Area, made up of 27 EU countries, Norway, Iceland, Liechtenstein and the United Kingdom.

Several manufacturers have already announced capacity expansions on the back of firm demand from grid and generation projects. For example, Hitachi Global has committed  more  than  USD 100 million  to  upgrade  and  modernise  its  power transformer  factories  in  Canada  to  meet  the  rapid  growth  in  North  American demand. The company is also investing USD 30 million to expand its manufacturing  facility  in  Germany.  These  projects  form  part  of  a  broader USD 1.5 billion investment programme  aimed at gradually expanding the company's  global  transformer  capacity  through  to  2027. Other  suppliers  are following suit. Hyundai Power Transformers is investing USD 33 million to expand production in Alabama by around 60%, while Siemens Energy has announced a USD 150 million investment to establish its first US power transformer factory in North Carolina, with manufacturing scheduled to begin in 2027.

The most effective action governments can take to rectify bottlenecks is to provide visibility, through clear long-term investment plans for the grid, stable policies for generator  connections  and  stronger  co-ordination  with  equipment  suppliers  on standards and certifications. These measures are essential to give manufacturers and  project  developers  the  confidence  to  commit.  Clear  rules  could  also  help developers secure firm transformer contracts, reducing uncertainty around project timelines.  Improving  the  efficiency  of  today's  grid infrastructure is equally important. However, many regulatory frameworks still favour hardware investments over operational upgrades, including digitalisation, that could raise system efficiency and reliability. Aligning regulations to support both modernisation  and  smarter  system  operation  would  ease  pressure  on  supply chains while improving overall grid performance.

Beyond shoring up today's supply, governments can also encourage innovation to  reshape  tomorrow's  demand  through  support  for  technologies  that  reduce transformer  size,  material  requirements  and  losses  in  operation.  Improved lifecycle efficiency standards could both encourage innovation and enhance grid reliability, considering the specific challenges of rapid technological change in a highly regulated industry such as electricity networks. For instance, amorphous core transformers can substantially cut standby losses, but require modifications in  manufacturing  and  present  challenges  for  grid  integration  due  to  increased dimensions and weight. Promising areas include additive manufacturing, solidstate and smart transformers, as well as technologies to increase the capacity of current grids, such  as  dynamic  line rating and  high-temperature  low-sag conductors. Targeted support - whether through direct R&amp;D funding, incentives for adoption or regulatory 'sandboxes' that allow new approaches to be tested in real  systems - can speed the transition to a leaner, more resilient transformer market (IEA, 2025e).

Figure 1.8 Major exporters and importers by transformer type and value, 2024

<!-- image -->

Notes: ASEAN = Association of Southeast Asian Nations; CSAM = Central and South America; Europe = European Economic Area, made up of 27 EU countries, Norway, Iceland, Liechtenstein and the United Kingdom. Dry refers to drytype transformers; low voltage refers to power capacity rated below 650 kVA, medium voltage to 650-10 000 kVA and high voltage to above 10 000 kVA.

Source: IEA analysis based on Sinoimex (2025).

China, Mexico, Europe and Korea are the biggest transformer exporters, with global trade more than doubling since 2020.

## 5. Is there a case for investing in a domestic battery sector when China holds such a large cost advantage?

## Why it matters

This question is hotly debated, and with good reason. Batteries are no longer just a component industry: they are a strategic technology. They underpin the shift to EVs, bolster the resilience and flexibility of power grids, are vital to the functioning of several rapidly expanding applications, including data centres and humanoid robots, and are increasingly central to defence applications, with drones being a prominent example. Their deployment also strengthens energy security, reducing reliance on oil in road transport while enabling greater use of domestic intermittent renewables.

However, strategic importance comes with strategic risk. Today, between 60% and nearly 100% of each step of the battery manufacturing supply chain sits in

just  one  country:  China.  This  outsized  role  is  the  result  of  years  of  sustained investment,  public  support,  technology  innovation,  integration  along  the  supply chain and the development of world-class expertise.

Japan and Korea have also built strong battery industries with global reach, though they  are  less  integrated  than  China's  when  it  comes  to  battery  component manufacturing  and  mineral  processing.  By  contrast,  producers  operating  in Europe and North America face higher costs and often struggle to match the prices or quality of Chinese products.

The dilemma facing policy makers outside China is how far to push for homegrown  capacity,  if  at  all.  New  production  locations  may  take  years  to  achieve competitiveness,  raising  questions  about  the  value  of  subsidising  investment today.  Yet  for  countries  and  regions  with  major  automotive  sectors,  such  as Europe, Japan, Korea and North America, the battery industry is more than a cost equation:  it  is  a  critical  link  between  vehicle  manufacturing  and  control  over mineral  supply  chains.  The  automotive  sector  remains  a  pillar  of  industrial strength,  but  its  future  increasingly  hinges  on  secure,  affordable  access  to batteries.

This explains the divergence of views. Some argue for aggressive subsidies to scale  domestic  production  quickly.  Others  see  greater  promise  in  funding innovation to leapfrog to next-generation technologies, where cost gaps may be smaller.  A  third camp  stresses  the  importance  of  forging  resilient  supply relationships with established producers abroad or encouraging them to invest in manufacturing capacity close to domestic markets.

## What is happening

Chinese, Korean and Japanese companies dominate global lithium-ion battery cell production, accounting for 99% of output. In 2024, roughly 80% of all batteries were  produced  in  China.  The  European Union  and  the  United States  together contributed  around  15%,  mostly  from  factories  built  by  Korean  and  Japanese firms.  Chinese  producers  are  also  extending  their  reach  abroad  through  local manufacturing investments or technology licensing agreements.

Building a competitive domestic industry is neither quick nor cheap. When a new producer begins operations, the share of output that is unfit for sale is often much higher than that needed to achieve profitability. It can take more than 5 years from the  start  of  production  for  a  new  facility  to  reach  close  to  its  nominal  capacity (Fraunhofer,  2024).  For  regions  without  a  strong  industrial  base  in  batteries, mastering  the  process  demands  patient  capital  and  long-term  commitment. Governments, for strategic reasons, may choose to share some of the investment

risk  with  private  players  through  direct  financial  support  or  by  encouraging investments or joint ventures that bring in established producers with expertise and privileged access to supply chains.

Lack of investment in the midstream battery supply chain poses a growing risk to global supply security. Production capacity and technical expertise for essential components  such  as  active  materials  and  their  precursors  remain  heavily concentrated in China. Korea and Japan are the only other countries with notable midstream  industries,  offering opportunities  to diversify sourcing  for some components while leaving many others reliant on Chinese supply (Figure 1.9).

This structural imbalance is unlikely to ease without a ramp-up in investment and stronger international co-operation. China continues to wield substantial influence: export  controls  on  key  battery  components  introduced  since  late  2023  target precisely the most vulnerable links in the battery supply chain. If the most recent restrictions - announced in October 2025 and later paused for one year following the latest trade agreement with the United States - were to be enforced, battery production outside of China could face serious disruption.

Figure 1.9 Share of battery demand outside China that could be met without supply from China, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: NCX includes lithium nickel manganese cobalt oxide (NMC) and lithium nickel cobalt aluminium oxide (NCA); LFP = lithium iron phosphate; CAM = cathode active material. 100% refers to global demand excluding China. The export controls announced in October 2025 are temporarily suspended at the time of writing. Lithium, nickel, and cobalt refer to total production capacity and demand across all sectors. Bars refer to production outside of China if the utilisation rate were to be increased to 85% of nameplate capacity. Some export controls on lithium processing apply, but since they refer specifically to lithium processing technologies, they are not considered in the figure. Batteries with an energy density greater than 300 Wh/kg and lithium-rich manganese-based chemistry are also subject to export controls. The NCX cells affected by export control are those with an energy density greater than 300 Wh/kg. All facilities able to produce graphite anode suitable for battery applications are included within the scope of anode manufacturing capacity. LFP is deployed in over 90% of battery energy storage systems, while electric vehicles rely on a combination of NCX and LFP.

Sources: IEA analysis based on data from EV Volumes (2025); BMI (2024); and BNEF (2025).

Nearly all battery energy storage systems and over 70% of EV batteries used outside China could not be produced without Chinese-made batteries or components.

Efforts to diversify the battery supply chain will only succeed if they are grounded in sound economic fundamentals. Europe and the United States have attracted substantial investment in battery cell manufacturing, driven by robust automotive industries that offer large and expanding sources of demand. The same principle applies  further  upstream:  scaling  up  midstream  production  capacity  requires predictable, large-scale demand to justify investment. A competitive and stable manufacturing base can provide this anchor. However, production costs in Europe and the United States remain up to 50% higher than in China, if excluding tax credits  or  other  support  measures,  complicating  efforts  to  establish  a  selfsustaining midstream industry.

Partnerships  with  incumbent  manufacturers  can  help  bridge  the  gap,  as  they accelerate  production  cost  reduction  and  can  influence  suppliers  to  relocate production.  But  building  a  midstream  industry  through  purely  market-driven dynamics takes time, which may not align with supply security concerns. Targeted strategic  midstream  investments  in  regions  scaling  up  battery  production  may therefore be justified as a form of insurance against short-term supply shocks.

Innovation is sometimes seen as a shortcut - a way for latecomers to leapfrog incumbents by betting  on  new technologies, such  as sodium-ion  or  solid-state batteries (IEA, 2025a). Sodium-ion batteries are already commercial in China, but their limited energy density makes them competitive only during periods of high lithium prices or for targeted applications, such as in cold climates. In addition, they are unlikely to offer a competitive opening for new entrants - China accounts for  over  95%  of  the  announced  manufacturing  capacity.  Solid-state  batteries remain at the prototype stage and are expected to begin entering markets between 2027 and 2030. However, high initial costs and nascent supply chains will likely restrict their initial use to premium segments and emerging applications such as humanoid robotics.

However, potential disruptive breakthroughs are a risky foundation for industrial strategy.  The  battery  industry  continues  to  optimise  established  technologies, breaking  records  on  energy  density,  ultrafast  charging,  safety,  and  longevity. Without  an  efficient  and  competitive  battery  ecosystem  already  in  place,  even promising advances may struggle to reach commercial scale quickly enough to deliver real benefits and compete with increasingly optimised lithium-ion technologies.

## What it means

Building and maintaining a domestic battery production base, even at a modest scale,  is  less  about  competing  with  China  today  than  about  securing  strategic resilience for tomorrow. The benefits of doing so are reinforced by the need to supply applications that are less sensitive to cost, notably in defence. Yet battery

manufacturing  is  a  complex  business:  developing  experience,  building  supply chains  and  achieving  cost  reductions  will  take  time.  Relying  solely  on  market forces  to  nurture  a  midstream  industry  may  not  bring  results  fast  enough  to address pressing supply security concerns.

That  makes  the  case  for  targeted  and  timely  government  support  to  scale  up production  a  strong  one,  both  in  advanced  economies  looking  to  safeguard competitiveness and in countries rich in critical minerals that could emerge as lowcost producers in the longer term. Strategic partnerships with established Asian manufacturers could also help by accelerating technology transfer, driving down costs  and  encouraging  suppliers  to  localise  production.  The  stakes  are  high: modern batteries  are  becoming  one  of  the  most  important  technologies  of  the 21st  century, so secure and affordable access is becoming a matter of economic and national security (Birol, 2025).

Strategic planning, however, must be grounded in reality. Established producers will continue to dominate global supply in the near term, including by operating or supplying much of the capacity located in Europe and the United States. In this context, partnerships with incumbent manufacturers - particularly when ensuring knowledge transfer - can be valuable, aligning strategic goals around investment, learning and innovation.

Innovation offers  potential  entry  points  for  new  players,  but  it  is  no  shortcut  to success.  Tomorrow's  leaders  in  next-generation  batteries,  including  solid-state designs,  will  be  those  that  pair  technical  breakthroughs  with  manufacturing efficiency, supply chain strength and a skilled workforce, much as today's lithiumion industry has done. Skills, suppliers and operational know-how must transfer smoothly across technologies if innovation is to translate into competitiveness.

The size of the overall lithium-ion battery market - about USD 130 billion in 2024 -  does  create  opportunities  for  newcomers to  scale  up  by  first  targeting  niche segments,  such  as  premium  applications  where  performance  outweighs  cost. These  markets  can  be  large  enough  to  build  experience,  generate  profit  and eventually move towards mass adoption. Still, competition will be fierce. The same incumbents  that  dominate  lithium-ion  production  are  also  among  the  most advanced  developers  of  new  battery  technologies,  making  it  difficult  for  new entrants to carve out lasting advantages.

## 6. Has the hydrogen bubble burst?

## Why it matters

Hydrogen has been widely hailed as a potential solution to some of the hardestto-decarbonise parts of the global economy. Hydrogen emits no carbon at the point  of  use  and  can  be  produced  from  renewables-based  electricity  through electrolysis of water, with fossil fuels combined with CCUS or using sustainable biomass,  offering  a  pathway  for  reducing  emissions  in  sectors  such  as  heavy industry, refining, aviation, shipping and long-haul road freight.

Between 2019 and 2023, investor sentiment and policy ambition were buoyant. Hydrogen was seen as a versatile fuel that could help meet net zero commitments, while falling costs for solar PV and wind reinforced the idea that production could quickly shift toward regions with abundant renewable energy. Countries responsible for over 85% of global CO  emissions had pledged net zero targets, ₂ generating strong expectations of a surge in demand for low-emissions hydrogen.

That perception has since changed significantly. Over the past year, headlines have  been  dominated  by  project  delays  and  cancellations,  bankruptcies  and weakened  policy  ambitions.  Investor  sentiment  has  cooled  sharply,  prompting questions about whether earlier enthusiasm represented a bubble. This is casting doubts about the long-term roles of hydrogen in the future energy system.

The IEA's annual Global Hydrogen Review (IEA, 2025b) offers a reality check. Policy  makers,  in  particular,  need  clear  signals:  will  hydrogen  provide  an opportunity  to  bolster  industrial  competitiveness  or  will  it  undermine  energy affordability?  Misjudging  the  moment  risks  either  wasting  capital  or  stalling momentum.

## What is happening

Momentum in the sector remains strong, despite the recent uncertainty. Global investment in low-emissions hydrogen production 4  climbed to almost USD 8 billion in 2025, an 80% jump from the year before. Output is expected to have reached about 1 Mt in 2025 - about twice the level in 2020 and accounting for around 1% of total hydrogen supply, which still relies predominantly on natural gas reforming. By 2030, total production is expected to reach more than 4 Mt based on committed projects.

4 See IEA (2025b) for a definition of low-emissions hydrogen.

The bulk of low-emissions hydrogen (more than 80%) in 2024 came from gasbased plants equipped with CCUS and around 15% from water electrolysis based on  renewables,  with  the  rest  having  been  derived  from  biomass.  Electrolysers have  grown  larger:  the  capacity  of  recently  commissioned  plants  has  reached 500 MW, with some under construction set to surpass 1 GW (IEA, 2025b).

However,  this  expansion  has  gone  hand  in  hand  with  a  turbulent  period  for hydrogen company finances. Between 2019 and 2021, over USD 70 billion was added  to  the  total  value  of  listed  hydrogen  firms  specialised  in  low-emissions production technology, about half of which only went public after 2019. Since then, their combined market capitalisation has collapsed by more than 80%, though the decline now appears to have levelled off. Still, the sector's financial strains remain evident: in early 2025, HydrogenOne  Capital Growth, a GBP 105 million (~USD 135 million) fund launched in 2020 to back hydrogen ventures, announced it would wind down after persistent underperformance (H2View, 2025).

Since  2020,  around  three-quarters  of  project  investment  has  been  directed towards producing hydrogen for industrial use or for fuels such as ammonia and synthetic hydrocarbons. These areas also account for practically all firm offtake agreements signed over the past 5 years, reflecting lower complexity and existing expertise among hydrogen users. They are likely to remain the backbone of future demand for low-emissions hydrogen. Low-emissions hydrogen and its derivative fuels are particularly well-suited to large-scale applications where hydrogen from unabated fossil fuels is already in use today and alternatives to cutting emissions are absent, such as in refining and chemicals, or to applications where alternative technologies are constrained, as in steelmaking, aviation and shipping.

Investment  in  low-emissions  hydrogen  production  has  been  unevenly  spread across regions and technologies. Spending on electrolysis is highest in China, where low equipment costs and the ability of state-owned enterprises to implement government plans have driven rapid deployment - from just a few megawatts in 2020 to around 2 GW in 2025. In Europe, the push to cut reliance on Russian natural  gas  has  provided  an  extra  spur  for  electrolyser  installations,  unlocking capital for large-scale projects. By contrast, most investment in Canada and the United States has gone to steam reforming plants equipped with carbon capture, driven by access to cheap natural gas, abundant underground CO  storage and ₂ generous tax incentives.

Most of the recent setbacks for developers and equipment suppliers stem from three sources: the slow conversion of policy targets into workable frameworks; recognition that the slow ramp-up of deployment is preventing the fast reductions on production costs to enable wider adoption; and the sheer complexity of building industrial supply chains and customer confidence from scratch. Unlike solar, wind

or batteries, the financial viability of hydrogen projects is tied up with uncertain fuel prices and multiple end-uses, making it a far more complicated business - a factor that investors may have underestimated.

For all the sector's recent troubles, the scale-up of electrolyser manufacturing and deployment over the past 5 years has been closer to the early trajectory of solar PV than to a stalled technology. This growth is mostly a consequence of the push that  China  has  given  to  electrolysis  technology,  aiming  to  replicate  previous success in technology manufacturing, as well as the willingness of some investors to  gain  experience and market position in a sector that is expected to play an important role in meeting climate, energy security and industrial competitiveness goals. Global installed electrolyser capacity reached 100 MW in 2009, but it took another 14 years to clear the 1 GW mark in 2023 (Figure 1.10). Since then, growth has accelerated: in the first seven months of 2025 alone, more than 1 GW was added, and total installed capacity is expected to have reached near 5 GW by the end of the year. Projects already at the stage of a final investment decision (FID) point to 26 GW of total capacity by 2030. If projects with strong potential to be in operation by 2030 are also considered, the potential capacity rises to 65 GW. That pace is similar to the breakneck expansion seen as solar PV and offshore wind started to take off.

Figure 1.10 Global installed capacity of solar PV, offshore wind and water electrolysis at the early stage of adoption

<!-- image -->

Notes: Year 0 is the year at which global installed capacity of each technology reached 100 MW: 1991 for solar PV, 2002 for offshore wind and 2009 for water electrolysis. The dotted line in water electrolysis shows the installed capacity that could be achieved with projects that are almost certain or have a strong potential to start operating by 2030 according to the analysis presented in our Global Hydrogen Review 2025 (IEA, 2025b).

Source: IEA (2025c).

The expected pace of deployment of water electrolysis is not far off the breakneck expansion seen when solar PV and offshore wind first began to scale up.

## What it means

Hydrogen is no passing fad. While financial corrections, project delays and cost gaps  have  cooled  investor  interest,  deployment  is  accelerating,  technology  is scaling rapidly, and industrial demand is growing. While stark, the recent market corrections are typical in emerging sectors: technologies often experience cycles of exuberance followed by consolidation before stabilising around the most viable opportunities. In other words, the 'bubble' may be weakening, but it is far from bursting - the sector is simply entering a more disciplined and sustainable phase. In this new phase stakeholders will focus efforts on those applications with more solid business cases and higher probability of succeeding, rather than diversifying exploratory effort across a large variety of uses, some of which are more prone to fail.

Nonetheless, the long-term prospects for low-emissions hydrogen and hydrogenbased fuels hinge critically on policy support and technology innovation due to their higher cost relative to conventional hydrogen and other energy sources. If that  support  falters,  the  sector  could  prove  more  vulnerable  than  other  clean energy technologies. The contrast is clear in the assessment of the likelihood of announced projects in our Global Hydrogen Review 2025 (IEA, 2025b).

Based solely on projects that are almost certain to proceed under today's policy settings,  global  low-emissions  hydrogen  production  is  set  to  increase  sixfold between 2024 and 2030. Including projects with a strong potential to come online by 2030, output could rise almost fifteen-fold. However, realising these projects would require targeted policy intervention through support schemes that narrow the  cost  gap  with  unabated  fossil  fuel-based  hydrogen,  stimulate  demand  in existing industrial applications and scale up enabling infrastructure such as CO ₂ transport and storage networks and hydrogen pipelines.

Bringing the full pipeline of announced projects into operation would result in a staggering fifty-fold rise in output, but that appears highly challenging as the end of the decade draws closer. Many proposed projects will also compete with other rapidly  growing  energy-intensive  sectors,  such  as  data  centres,  for  electricity supplies  and  capital  for  enabling  infrastructure.  As  a  result,  a  large  share  of announced projects are more likely to materialise after 2030.

Unlike  renewables  in  the  power  sector,  low-emissions  hydrogen  still  cannot compete on price with unabated fossil fuels without targeted incentives. Producing low-emissions hydrogen requires an additional energy-intensive step -electrolysis  or  CO   capture.  Fossil  fuels,  when  used  directly  in  industry  or ₂ transport,  avoid  this  extra  layer  of  conversion  losses.  These  unfavourable thermodynamics are unavoidable, though they can be overcome when fossil fuel prices are high or when policy support narrows the cost gap.

Another reason to be cautious about the longer-term prospects for hydrogen is that the cost gap has not closed as quickly as many had hoped. Electrolyser costs have  risen  in  recent  years  due  to  inflation,  supply  chain  tensions  and  cost estimates  becoming  more  realistic  as  projects  progress,  though  this  trend  is expected  to  reverse  as  manufacturing  scales  and  construction  experience accumulates.  Industrial  sectors  such  as  refining  and  chemicals,  along  with hydrogen-based  fuels,  represent  a  demand  base  large  enough  to  unlock  the economies of scale needed for steep cost reductions. For instance, replacing just one-quarter  of  today's  hydrogen  use  in  refining,  ammonia  and  methanol  with electrolytic hydrogen would require about 240 GW of capacity - enough to cut the current capital costs of installing an electrolyser by more than 40%.

At present, producing hydrogen from fossil fuels with CCUS carries a cost gap of USD 0.4-1.2 per kg relative to unabated fossil-based hydrogen, implying a carbon price  of  USD 30-100  per  tonne  of  CO2  to  level  the  playing  field  (Figure  1.11). Electrolytic  hydrogen  shows  wider  variation.  In  regions  with  good  renewable resources and expensive natural gas for industrial end users, the cost gap can be as  low  as  USD 0.5-4.5/kg  H2  (equivalent  to  CO   prices  of  USD 40-350/t).  By ₂ contrast, regions  with  cheap  natural  gas  face  a  cost gap  of  more  than USD 6/kg H2, requiring CO  prices in excess of USD 550/t to close it. ₂

Figure 1.11 Hydrogen production cost by pathway and region in the Stated Policies Scenario, 2024-2030

<!-- image -->

IEA. CC BY 4.0.

Notes: NG = natural gas; CCUS = carbon capture, utilisation and storage. Assumes a capture rate of 95% for technologies using CCUS. The grey shading represents the range of production costs from unabated fossil fuels. The ranges of the fossil-based routes for China include both natural gas reforming and coal gasification. Hydrogen costs are capped at USD 12/kg, although some production routes cost more. Water costs are not included. See the technical annex of the IEA's Global Hydrogen Review 2025 for further details on technoeconomic assumptions. Source: IEA (2025b).

Renewable hydrogen production remains far more expensive than unabated fossil-based production, but the cost gap is set to close as early as 2030 in locations such as China.

Some regions are on track to eliminate the cost gap for low emissions hydrogen -entirely by 2030. In markets such as China, where technology and capital costs are  relatively  low,  the  economics  are  particularly  favourable.  In  other  regions, notably parts of Europe and Latin America, persistently high natural gas prices, supportive  carbon  pricing  mechanisms  and  strong  renewables  potential  are expected to bring the cost differential down to less than USD 1/kg.

Low-emissions hydrogen production is not a standardised plug-and-play technology. Whether based on electrolysis or CCUS-equipped steam reforming of fossil  fuels,  it  requires  the  development  of  entire  supply  chains  from  scratch. Establishing appropriate regulatory frameworks, including standards and certification schemes, is therefore critical to ensure transparency, comparability and investor confidence. Progress in this respect varies widely across regions. Large  energy-importing  economies  such  as  Europe,  Japan  and  Korea  have already  devised  comprehensive  frameworks  to  mitigate  investment  risks  and facilitate  market  development.  In  contrast,  progress  remains  limited  in  many EMDEs, where institutional capacity and policy alignment are still evolving.

The International Organization for Standardization (ISO) is playing a central role in harmonising approaches. The first part of its lifecycle GHG emissions standard for  hydrogen  production  is  expected  in  early  2026,  while  additional  standards covering conversion into carriers - including liquid hydrogen, ammonia and liquid organic hydrogen carriers - reconversion to hydrogen and transport are scheduled for release later in the year. These efforts will be pivotal in enabling cross-border trade and ensuring that hydrogen contributes effectively to policy goals.

## 7. Is carbon capture, utilisation and storage finally taking off?

## Why it matters

Carbon  capture,  utilisation and  storage  (CCUS)  is  an  important  suite  of technologies needed to complement other means of reducing CO2 emissions. It captures CO  from power plants, industrial facilities or directly from the air, either ₂ reusing it or storing it safely underground so that it does not contribute to climate change.  As  well  as  cutting  hard-to-abate  emissions  at  source,  CCUS  enables permanent CO  removals to balance emissions that cannot be eliminated  and ₂ lower CO2 concentrations in the atmosphere. Without it, reaching net zero globally by mid-century is virtually impossible.

Interest in CCUS has surged in recent years, with a wave of projects announced and installed capacity expected to double in the years ahead. Yet past project cancellations,  cost  overruns  and technical  challenges  are  breeding  scepticism.

The 2010s saw a similar burst of optimism (IEA, 2021): more than USD 8.5 billion of  public  funding  was  pledged  globally  to  projects  that,  in  many  cases,  never moved far beyond the drawing board. Perceptions of poor operational performance and uncertainty about the financial viability of CCUS investments persist, raising concerns among investors over long-term revenues and returns.

In this context, it is reasonable to ask whether the current momentum will prove any different this time and translate into sustained deployment, or whether we are witnessing  another  false  dawn.  At  stake  are  major  policy  choices  in  several countries, where governments must decide whether to anchor CCUS as part of their long-term climate strategies. For that debate to be constructive, it is essential to understand if and how today's conditions differ from past episodes - both in the scale of private sector commitment and in the changing role of CCUS within the wider energy transition.

## What is happening

There is strong evidence that today's wave is different, but several factors need to align for CCUS to really take off. Global investment in CCUS has grown sharply, from around USD 0.3 billion in 2020 to over USD 5 billion in 2025, far exceeding that  in  the  previous  wave  of  the  early  2010s  (Figure  1.12).  In  2023-24  alone, governments  earmarked  around  USD 50 billion  in  support.  Notably,  after  two decades  of  deliberation,  the  United Kingdom  has  taken  FIDs  on  several  large projects.

The current wave is also broader than before, with projects now spanning multiple sectors,  including  those  that  typically  involve  more  dilute  CO2  streams  and therefore  higher  capture  costs.  The  past  year  has  seen  several  milestones, including FIDs on the first natural gas power plant with carbon capture and storage in  the  United Kingdom and the world's largest CO2 removal facility in Sweden. CCUS deployment in  the  cement  sector  is  also  accelerating,  with  the  biggest capture facility ever applied to a cement plant starting operation in Norway and an even larger capture facility reaching FID in the United Kingdom. In addition, two large CO2 storage projects in Norway and Australia began operations.

Deployment is also widening geographically. In 2020, close to 60% of all projects in operation and under construction were located in North America, but today that share has fallen to around 40%, reflecting the sector's growing international reach. Europe has emerged as a key hub, with major developments underway in the United Kingdom, Denmark and the Netherlands. Indonesia has reached its first FID for a large-scale project, while both the Middle East and China now have as much or more CO  capture capacity under construction as Europe. ₂

Figure 1.12 Global investment in carbon capture, utilisation and storage and average capture rates in operating facilities, 2010-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: NGP = natural gas processing; CCUS = carbon capture, utilisation and storage. CO2 capture rates are estimated by dividing the mass of CO2 separated in the capture plant (and therefore not emitted) by the total mass of CO2 contained in the gas stream to which capture plant is fitted. Estimated average corresponds to the entire operational period to date. Estimated max corresponds to the highest rate achieved so far in a single a year of operation.

Sources: IEA analysis based on IEAGHG TCP (2019); Alberta Department of Energy (2024); Enhance Energy (2024); US Environmental Protection Agency (2023); IEA Bioenergy TCP (2023); Red Trail Energy (2022); Giannaris, S. et al. (2021); Chevron (2024); Petra Nova Parish Holdings (2020).

The  current  wave  of  CCUS  investment  is  bigger  than  any  before  it,  while  operational performance has mostly achieved targeted levels.

More than  50  countries  are  now  represented  among  the  hundreds  of  projects announced  worldwide.  If  all  proceed  as  planned,  global  CO   capture  capacity ₂ would increase eightfold, while storage capacity would expand more than thirteenfold by 2030. As these new projects move from design to operation, gaining realworld experience across different sectors and regions will be essential - not only for  improving  performance  and  reliability,  but  also  for  driving  down  costs  and accelerating the next wave of deployment.

Operational  data  suggest  that  projects  are  performing  better  than  is  often assumed, with most plants operating in line with their original design expectations. It is important to note that few projects were designed to capture the majority of a facility's total emissions. Instead, they were typically configured to target specific,

concentrated CO  streams, reflecting the limited economic incentive to capture ₂ from more dilute sources. Judged against these design parameters, most projects have achieved their planned capture rates. 5

Notably,  several  biofuel  and  hydrogen  plants  -  where  CO2  concentrations  in exhaust gases are high - have achieved capture rates above 90% of their targeted streams during  full  operation,  with  some  reporting  annual  averages  exceeding 95% (Figure 1.12). While some projects have fallen short of overall CO  capture ₂ volume targets, this often reflects reduced utilisation of the host facility, such as a power plant or industrial unit, rather than any technical shortcoming of the capture system itself (Clean Air Task Force, 2024). Even so, unplanned downtime at the base plant can undermine project economics by reducing the overall volume of CO2 captured and raising the levelised cost of capture.

Some projects have nonetheless faced technical hurdles. The Gorgon project in Australia has encountered difficulties in managing reservoir pressure (Chevron, 2024); ADM Decatur in the United States has experienced problems related to CO2  purity,  well  clogging  and,  more  recently,  corrosion  (Reuters,  2024);  and Canada's Boundary Dam facility has undergone multiple system modifications to enhance the availability of its capture plant (Giannaris, S. et al., 2021). Importantly, the lessons from these early difficulties have contributed to more robust legal and regulatory frameworks, improving reliability and safety across the industry.

Today's momentum differs markedly from that of a decade ago in both scale and sectoral  diversity,  but  project  economics  remain  a  central  obstacle  to  wider deployment. In many industries, the levelised cost of CO  avoided for ₂ nth-of-akind projects still exceeds prevailing carbon prices in most jurisdictions (Figure 1.13).  Recent  inflationary  pressures,  the  first-of-a-kind  cost  premiums associated with new applications targeting dilute CO  streams and high transport ₂ and storage fees - particularly for initial emitters connecting to offshore hubs in Europe - are compounding the problem.

Business  models  are  evolving,  enabling  projects  to  'stack'  multiple  revenue streams. By combining policy supports, such as tax credits or carbon contracts for difference (CCfDs), which are designed to bridge the gap between the prevailing carbon price and an agreed strike price with income from the sale of low- or nearzero-emission  products  or  high-quality  carbon  removal  credits,  developers  are diversifying their sources of revenue. Some removal credits in voluntary markets are fetching over USD 2 000 per tonne, providing a powerful incentive for early

5 CO2 capture rates are estimated by dividing the mass of CO2 separated in the capture plant (and therefore not emitted) by the total mass of CO2 contained in the gas stream to which capture plant is fitted (i.e. the CO2 treated by the capture plant).

movers. In Sweden, a mix of government grants and CCfDs cover over half of the cost  of Stockholm  Exergi's  bioenergy-based  district  heating  project.  When combined with credit sales, this support package is sufficient to make the project commercially viable (Figure 1.13).

This 'revenue stacking' approach has found favour among financers. Banks are now  co-funding  CCUS  projects  in  both  the  United Kingdom  and  Sweden, signalling greater confidence in the sector's financial maturity in some markets. It marks  a  clear  departure  from  earlier  business  models  that  relied  on  a  single revenue stream from selling captured CO  for enhanced oil recovery - a model ₂ that faltered during periods of low oil prices and led to the temporary shutdown of the Petra Nova project in the United States. It also contrasts with past approaches built  solely  on  expectations  of  higher  future  carbon  prices,  which  provides  an uncertain foundation for investment.

Figure 1.13 Levelised cost of carbon avoided or removed for selected carbon capture, utilisation and storage applications, and costs and revenues of a first-of-akind project, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: CCfD = carbon contract for difference; CCGT = combined cycle gas turbine; CDR = carbon dioxide removal; ETS = Emissions Trading Scheme; FCC = fluid catalytic cracker; PC = pulverised combustion; T&amp;S= transport and storage. Left: levelised cost of carbon avoided and removed from previous IEA analysis (see notes on page 63 of (IEA, 2023)), inflated to 2024, and CO2 transport and storage fee updated to USD 50/t CO2. Potential reflects levelised costs that could be reached without the cost premiums that are typically associated with first-of-a-kind plants. The first-of-a-kind assessment is based on Stockholm Exergi plant. Model assumptions include 8% weighted average cost of capital, fixed operating expenses at 4% of capital expenses, and an economic lifetime of 15 years.

Revenue stacking is proving crucial to the financial viability of CCUS projects in Europe, such as Stockholm Exergi, for which grants and CCfDs provide over half of its revenue.

## What it means

Recent  momentum  in  CCUS  reflects  growing  confidence  in  the  technology's potential,  but  interest  alone  does  not  equal  impact.  The  surge  in  announced projects  is  impressive,  yet  only  facilities  that  reach  operation  can  deliver  real emissions  reductions.  So  far,  only  around  a  quarter  of  the  capture  capacity announced for 2030 has reached FID and even that milestone does not guarantee delivery: projects can still be delayed, scaled back or cancelled post-FID.

For now, CCUS remains a niche solution, concentrated in North America, China, the Middle  East  and  a  handful  of  Northern  European  countries.  Broader deployment will depend on greater confidence that project risks are both modest and manageable - a conviction that will strengthen only as more facilities move from  paper  to  operation.  Beyond  high-concentration  CO   streams,  deployment ₂ remains limited. Achieving cost reductions in these areas will require scale and accumulated operational experience - progress that can only come with more projects coming into operation.

Attracting  larger  volumes  of  private  capital  would  mark  a  turning  point  for  the industry. Most recent FIDs have relied heavily on public backing, reflecting the early-stage nature of the market. For the market to mature, projects must secure predictable revenue streams that make investment attractive beyond government support. To date, this has been the case for only a few projects. A forthcoming IEA report  on  leveraging  private  capital  for  CCUS  will  explore  how  policy frameworks, market design and risk-sharing models can help achieve this.

Whether  the  current  wave  of  activity  becomes  a  large-scale,  durable  global industry will depend on turning project announcements into steel on the ground, embedding private finance and extending deployment far beyond today's early movers.

## 8. Large, modular and fusion reactors all have renewed momentum: how quickly can nuclear be brought online?

## Why it matters

After years of drift, a new era of nuclear energy beckons. More than 70 GW 6  of capacity, equal to 17% of the existing fleet, is now under construction worldwide - one of the fastest build-out rates in the last 35 years. More than 40 countries are planning further expansion. The first small modular reactors (SMRs) are finally moving from blueprint to building site. Energy security, reliability and the need for low-carbon power are all sharpening policy makers' interest, with geopolitics and the global race for leadership in AI adding further urgency.

Nuclear fusion - a very different and as-yet-unproven energy technology - is also generating  fresh  excitement.  The  last  few  years  have  seen  some  important advances in fusion technology, while venture capital funding has surged, with tech companies investing in anticipation of long-term offtake contracts, given fusion's promise of constant, emissions-free power.

Yet some of the old obstacles remain. Conventional reactors have a history of delays  and  cost  overruns,  while  SMRs  have  been  in  the  works  for  decades. Fusion,  despite  the  buzz,  is  still  unproven  and  the  old  adage  about  it  being '30 years away, and always will be' still resonates with many observers. Whatever the technology, nuclear reactors will always take years to plan and build. Still, many expect timelines to shorten as construction experience accumulates. For governments banking on nuclear, the task now is to separate real progress from hype and to judge when new reactors will actually start delivering electricity to the grid.

## What is happening

For conventional nuclear fission, new reactors still take about a decade to build, even before accounting for permitting, which can add another 3-8 years. Despite efforts for streamlining, there is little sign that these timelines are shrinking. In fact, global average construction times for large reactors have roughly doubled since the 1970s, and in Europe and North America, projects launched this century have taken more than 20 years on average to complete (Figure 1.14). Korea used to be

6 Data on nuclear capacity in this report refer to gross capacity.

able to build a reactor in about 5 years, but that has stretched to 8-10 years over the last decade. The stand-out exception is China, which has managed to hold average construction times below 6 years over the past quarter-century.

Figure 1.14 Construction times for large nuclear reactors and number of reactors connected to the grid by country or region, 1951-2025

<!-- image -->

IEA. CC BY 4.0.

Notes: In the upper figure, the construction time of 43 years for Unit 2 of the Watts Bar nuclear power plant is not shown (construction started in 1973 but was halted in 1985 due to decreased power demand before being recontinued in 2007, with the unit being connected to the grid in 2016). Construction time refers to the period from the first pouring of the concrete for the reactor building to the grid connection.

Source: IEA analysis based on International Atomic Energy Agency (2025).

Global construction times for large reactors have doubled since the 1970s, with European and North America projects launched this century taking more than 20 years to complete.

One reason nuclear projects outside China take so long to complete is the collapse in construction that began in the early 1990s: with new orders drying up, much of the industrial base and workforce expertise withered away, and has since had to be rebuilt. Increasing regulatory stringency and rule changes have also made new designs  more  complex  and  costly,  dragged  out  permitting  procedures  and

prolonged construction times. As a result, final capital costs and lead times have, in many cases, ended up at least double the original estimates.

China's  experience  shows  how  standardisation  makes  a  difference.  There, 1 single reactor design accounts for 22 of the 58 units built since 2000, while just 2  designs  make  up  88%  of  the  33  currently  under  construction.  China's  State Council  has  also  approved  a  further  21  reactors,  out  of  which  20  rely  on  just 2 designs (World Nuclear News, 2024), (World Nuclear News, 2025a). Along with a steady stream of orders, this repetition has kept build times under control. The first  four  Westinghouse AP1000 units installed in China took nearly 9 years on average to complete - only slightly faster than the 10 years required for the first two in the United States. The next wave of eight AP1000s now under construction is  moving  more  quickly,  reflecting  lessons  learned  from  earlier  projects.   The 7 installation of the reactor pressure vessel - an important construction milestone was achieved, on average, after just 21 months from the start of work, compared with 42 months for the initial series (Spangler et al., 2025).

Domestic  industrial  capacity  has  expanded  in  parallel.  Whereas  China's  first generation of nuclear plants in the 1990s depended to a large extent on imported equipment, around 90% of the components used in recent projects are sourced from  domestic  suppliers  (China  Atomic  Energy  Authority,  2018;  Nengyuanjie, 2020). These newer reactors also meet international safety standards (International Atomic Energy Agency, 2025), underscoring how localisation has gone hand in hand with technical maturity.

SMRs, typically defined as reactors producing less than 300 MW of electricity, are often seen as the nuclear industry's best bet for faster deployment. Their appeal lies in designs  that  promise  more  standardisation,  heavier  use  of  off-site manufacturing and serial production. In theory, this should trim construction times, as well as make them easier to integrate into less centralised power systems by slotting into regional grids or industrial hubs where a gigawatt-scale reactor would never fit.

Momentum  is  building,  with  more  than  90 SMR  designs  at  varying  stages  of development across more than 30 countries. They make use of a wide range of nuclear technologies, from established light-water reactor technologies to novel approaches, with around 12 designs at advanced development stages. In Canada, an FID was taken in 2025 to build four units, with the first slated for grid connection by 2030 (World Nuclear News, 2025b). The UK government also pledged in 2025 GBP 2.5 billion (around USD 3.2 billion) of public funding, and picked a preferred design,  with  commissioning  due  in  the  mid-2030s  (Vallance,  2025).  In  the United States,  data  centre  operators,  hungry  for  reliable,  uninterrupted  power

7 The localised, Chinese version of the AP1000 is typically named CAP1000.

supplies  to  support  AI,  have  begun  partnering  with  SMR  developers,  with  one design having already cleared regulatory approval for construction.

Fusion  is  another  story  altogether.  No  power  plant  yet  exists,  but  interest  and money are pouring in. The number of firms researching fusion has multiplied in recent years and global venture capital flows into the sector have risen sharply, led  above  all  by  the  United States,  but  followed  by  China  with  a  surge  of investments in the last three years (Figure 1.15). For the first time in 2022, an inertial fusion device in the United States produced more energy than was put into a fusion reaction. The ratio of the energy produced by this device to the energy put into it has since been increased, from 1.5 to 4.1 in April 2025 (National Ignition Facility,  2025). In early 2025, scientists in China and France broke records for sustaining high-confinement plasma, keeping it stable for 17 minutes (Chinese Academy of Sciences, 2025) and then 22 minutes (CEA, 2025) - an important milestone on the path to designing a working reactor. Another fusion device, a stellarator, set a new record for its combination of temperature, plasma density and  confinement  time  (known  as  the  'triple  product'),  which  is  needed  for  the technology to be viable, over long plasma durations in 2025 (EUROfusion, 2025). The  focus  of  both  public  and  private  initiatives  is  shifting  from  study  of  the fundamental physics towards the engineering of first-of-a-kind facilities.

The world's largest fusion experiment is under construction in France. Known as ITER,  the  intergovernmental  project  aims  to  prove  that  a  fusion  reactor  can produce  more  energy  than  it  consumes,  targeting  a  net  energy  gain  of  ten. However,  the  effort  has  been  beset  by  technical  setbacks,  cost  overruns  and schedule  delays,  pushing  that  milestone  back  to  2039.  If  successful,  ITER  is expected to pave the way for a 500 MW demonstration plant connected to the grid around 2050 at the earliest (EUROfusion, 2018).

Alongside this publicly funded effort, a wave of private companies has entered the fusion race, promising to deliver working reactors far sooner. Dozens of start-ups, many  spun  out  of  leading  research  institutions,  are  developing  alternative technologies that aim to compress timelines and costs, with the majority targeting the  commissioning  of  a  first  demonstration  power  plant  by  the  mid-2030s. Commonwealth  Fusion  Systems,  a  US-based  firm  and  the  sector's  largest fundraiser, is pursuing a high-temperature superconducting magnet design and targets achieving a net energy gain of ten as early as 2027. 8 If that target is met, a grid-connected plant could follow in the 2030s.

8 In addition, other companies working on magnetic fusion are developing high-temperature superconducting magnets, which are operating at temperatures of -253°C, such as Helical Fusion in Japan, Tokamak Energy in the United Kingdom or Energy Singularity in China. Low-temperature superconducting magnets, as used in the ITER project, operate at temperatures of -269°C. High-temperature superconducting magnets allow for a more compact fusion reactor design, reducing capital costs and construction time.

Private sector momentum - built on decades of public research - has undoubtedly injected new credibility into fusion's long-promised potential. Whether optimism turns into operating power plants remains to be seen, but the combination of public research  and  infrastructure  and  private  innovation  has  given  fusion  its  most realistic path yet toward commercial heat and electricity production within the next two decades.

Figure 1.15 Global venture capital funding for fusion companies, 2010-2025e, and announced start years for electricity-generating fusion plants, 2025-2055

<!-- image -->

IEA. CC BY 4.0.

Note: Venture capital investment in 2025 only covers the period until August 2025.

Sources: IEA analysis based on Cleantech Group (2025); Crunchbase (2025); Fusion Energy Base (2025); and surveys from Fusion Industry Association (2025).

Cumulative venture capital investment in fusion energy has reached almost USD 11 billion, with the majority of companies aiming to commission power plants in the 2030s.

## What it means

The  evidence  that  SMRs  will  cut  lead  times  for  new  nuclear  power  capacity remains mixed. The four demonstration plants in China, Japan and the Russian Federation (hereafter, 'Russia') each took 7-9 years to build - hardly a dramatic improvement  on  conventional  projects.  China's  second  SMR,  which  started construction in 2021, is aiming for grid connection in 2026, but even that would not be a rapid turnaround by industry standards. These first-of-a-kind SMR plants are not yet benefiting from reductions in construction times and costs that their smaller sizes - typically four times smaller than a large reactor - and standardised designs  could  bring.  It  is  the  manufacturing  of  multiple  standardised  SMRs  in parallel,  largely  assembled  off-site  in  factories,  that  is  expected  to  bring  down costs and avoid cost overruns.

With  first-of-a-kind  projects  still  under  construction,  the  future  cost  of  SMRs remains uncertain. Given their limited economies of scale, it is no surprise that

first-of-a-kind SMRs are expected to cost twice as much as conventional largescale reactors - around USD 10 000/kW in advanced economies (World Nuclear News, 2025b) and less than USD 6 000/kW in China and India (Global Times, 2025).  Assuming  global  deployment  reaches  120 GW  by  2050,  average  SMR costs could reach cost parity with large-scale reactors in the 2040s (IEA, 2025d). Developers themselves are more optimistic, targeting a cost range of USD 2 000-3 400/kW.

Fusion raises multiple different questions: the issue is not construction timelines, but how quickly technology developers can shift from experiments in laboratories to  the  first  grid-connected  demonstration  plant.  If  realised,  the  prize  will  be extraordinary: reactors that generate more energy than they consume require, in principle, no imported fuel (with most reactor designs needing only lithium and water),  emit no CO  and leave behind no highly radioactive waste. Such attributes 9 ₂ would surely attract investors willing to shoulder high upfront costs - provided the plants prove they can run safely, continuously and for decades at a stretch.

Nevertheless, the timeline  remains  deeply  uncertain,  given  uncertainties  about technological  progress  and  costs.  There  has  been  steady  progress:  improved performance in plasma confinement, growing attention to engineering challenges and a surge of private investment supporting competing designs. Even so, the leap from one grid-connected demonstration to a fleet of reliable, commercially operating reactors is likely to remain a long-term endeavour.

## 9. Can strategic industries in advanced economies restore their competitive edge?

## Why it matters

Excess  global  industrial  capacity  -  especially  in  steel  and  chemicals  -  has depressed prices and squeezed producers in some advanced economies out of export markets. Trade restrictions are compounding the strain, disrupting supply chains and reshaping the competitive landscape. In Europe, the energy crisis has added  to  these  problems,  with  high  and  volatile  fossil  fuel  prices  arising  from imported energy leaving swathes of industry uncompetitive. Yet governments are

9 Most proposed reactor designs rely on a combination of deuterium and tritium as fuels. While the production of deuterium from sea water is well established, tritium is extremely rare, with estimated global stocks of 25-30 kg being mostly a byproduct of CANDU nuclear reactors in Canada. A single fusion power plant alone may require 10 kg of tritium for commissioning and start-up (Science Business, 2024). Concepts for the production of tritium from lithium using breeding blankets, mostly for use in tokamak reactors, are still at early development stages in terms of materials, coolants and tritium extraction methods (technology readiness levels 2-5).

understandably reluctant to let strategic sectors collapse: industry is too closely tied to skilled jobs, downstream manufacturing and other supply chains, including defence. For instance, in 2025, the UK government stepped in to rescue a lossmaking blast furnace - the country's last - rather than see it shut (UK Government, 2025). The US government also stepped in to veto plant closures or relocations the  same  year,  when  a  US  steel  company  was  privately  sold  to  a  Japanese investor (Alper, Yamazaki, &amp; Uranaka, 2025).

The longer-term dilemma is harder still. Many advanced economies have pledged to decarbonise industry to reduce environmental impacts, while also seeking to strengthen  energy  security  and  industrial  competitiveness,  and  to  capture opportunities in growing markets for low-emissions products. Yet the price tag for scaling low-emissions technologies can be daunting, particularly for firms already struggling  to  compete.  Several  companies  have  delayed  or  reconsidered  the investment timeline for building new, low-emissions plants.

That leaves policy makers and industry searching for a two-track solution: shoring up  the  competitiveness  of  today's  facilities  while  finding  ways  to  invest  in  the technologies that could deliver an edge tomorrow. Innovation can accelerate the development of technologies to boost efficiencies and lower costs in the coming decades. In the meantime, the balance between short-term survival and long-term transformation  will define whether  energy-intensive  industries  in advanced economies can reclaim their footing in global markets.

## What is happening

For decades, advanced  economies  dominated  energy-intensive industries, supplying local markets with steel, cement and chemicals. Their industrial clusters, located  close  to  centres  of  demand,  were  built  on  formidable  comparative advantages:  sophisticated  technologies,  dense  capital  stock,  strong  logistics, integration with customers and highly skilled workforces.

However, these advantages are being eroded. Myriad structural pressures - high energy  and  labour  costs,  ageing  assets,  reliance  on  imported  fuels  and  raw materials,  shrinking  domestic  demand  and  complex  regulation  -  have  steadily undercut  competitiveness.  Europe  has  been  hit  especially  hard:  the  drive  to eliminate imports of Russian gas has kept energy prices high. Industrial producers in Europe have faced energy costs about twice as high as in North America and China over the past 5 years (Figure 1.16). They also face carbon prices that add costs  not  borne  by  their  main  competitors  overseas.  Japan  faces  intense competition with the burgeoning fleet of new plants elsewhere in Asia, while North America faces new vulnerabilities as shifts in trade policy expose its reliance on cross-border supply chains, especially in steel and aluminium.

Figure 1.16 Industrial sector indicators by country or region, 2000-2025

<!-- image -->

IEA. CC BY 4.0.

Notes: EMDEs = emerging markets and developing economies. (Left): Share of global demand is based on value of demand for crude steel, aluminium, ammonia, and cement. Assumed material prices are taken as average global prices from 2000-25. When not available, assumed material prices are derived using the evolution of historical levelised cost of production and demand. (Middle): The energy price for each country/region is the average weighted by demand for each type of energy input. (Right): Share of global exports is based on value of selected traded high-value industrial products (machinery, transport equipment and fertilisers) using bulk material inputs that provide a representative sample across subsectors.

Source: IEA analysis based on CEPII (2025).

The competitiveness of materials producers in advanced economies, particularly Europe, has steadily declined in the past 25 years, while Chinese firms have increased their presence.

China and other EMDEs now account for roughly half of gross exports of key bulk industrial materials (steel, aluminium and ammonia) and also meet most of their own  development  needs.  Roughly  three-quarters  of  global  demand  for  bulk industrial materials comes from these countries. Material quality is no longer the competitive differentiator it used to be for advanced economies, with EMDEs especially  China  -  producing  and  exporting  larger  shares  of  high-value,  highquality  goods.  Low  energy  costs  remain  a  key  advantage  in  many  EMDEs. Advanced  economies  therefore  face  a  double  squeeze:  losing  ground  abroad while confronting fierce competition at home.

Trade frictions have heightened awareness of the longer-term dilemma: how to balance  short-term competitiveness  with  the transition to innovative, lowemissions  production  based  more  on  domestic  resources  in  the  2030s.  Early movers face daunting economics: new technologies could raise production costs significantly, while markets for more expensive products are still emerging. In the steel sector, for example, initial cost premiums of 20-145% 10 are enough to deter

10 Based on comparison of hydrogen direct reduced iron electric arc furnace production compared to conventional ironbased production.

investment, even where public support is strong. ArcelorMittal's decision to shelve its  plans  for  near-zero  emissions  steel  production  in  Germany  (ArcelorMittal, 2025), despite the offer of a EUR 1.3 billion (approximately USD 1.5 billion) public grant  (Germany,  Federal  Ministry  for  Economic  Affairs  and  Energy,  2024), illustrates  these  pressures.  As  energy-intensive  sectors  are  largely  driven  by operating expenses, capital subsidies alone might not be enough to guarantee long-term competitiveness.

EMDEs may be able to capture emerging opportunities thanks to their growing access to cheap clean energy, abundant raw materials and other enabling factors (IEA,  2024).  Realising  this  potential,  however,  will  depend  on  progress  in financing, infrastructure and regulatory frameworks.

Rapid  shifts  are  difficult,  but  they  can  happen  when  conditions  align.  In  the United States,  steelmaking  has  moved  sharply  away  from  coal-based  basic oxygen furnaces towards electric arc furnaces. By 2025, output from the latter reached  just  over  55 Mt  (about  70%  of  total  production),  driven  by  federal government  stimulus  spending  in  the  wake  of  the  2008  financial  crisis,  cheap natural  gas  and  rising  availability  of  scrap.  This  shift  has  lowered  costs  and emissions  while  boosting  flexibility,  competitiveness  and  energy  security.  The United States now has the world's second-largest fleet of electric arc furnaces.

## What it means

Advanced  economies  can  no  longer  count  on  their  traditional  strengths  to guarantee competitiveness. Those advantages remain important in many cases, but  are  no  longer  sufficient  to  offset  structural  weaknesses  that  have  been amplified  by  global  market  pressures  and  excess  capacity.  A  carbon  border adjustment mechanism, which aims to confirm that a price has been paid for the embedded  carbon  emissions  generated  in  the  production  of  certain  imported goods, may address one source of higher costs but it cannot resolve these deeper issues. Implementing such a mechanism brings its own problems (see Chapter 7). Even if strong markets for near-zero and low-emissions products emerge, some EMDEs  are  likely  to  retain  their  competitive  edge  over  advanced  economies. Addressing the underlying problems could take decades.

Maintaining  the  status  quo  is  a  high-risk  strategy  for  the  least  competitive advanced economies, requiring heavy subsidies with no assurance of restoring competitiveness. An alternative path may lie in strategic partnerships that divide supply  chains  to  maximise  each  region's  strengths.  EMDEs  with  low-cost renewable  energy  resources  could  take  on  the  energy-intensive  steps  of production, while advanced economies retain higher-value activities where they still  hold  an  edge,  such  as  in  specialised  manufacturing  and  integration  with downstream industries.

Advanced economies could continue to participate in technology development and benefit from their large-scale deployment, while working with EMDEs to establish secure and efficient supply chains. Supply chain security remains a policy priority, meaning that partial relocation of certain domestic production steps - combined with  other  measures  to  enhance  competitiveness  -  may  be  preferable  to abandoning  them  altogether.  Shared  investment  could  create  more  resilient supply chains, lower overall transition costs and capture rising demand for cleaner materials, complementing domestic production that is retained to support security. Experience also suggests that investing in upstream materials production, even when uncompetitive on a cost basis alone, can strengthen downstream industries and domestic supply chains, including for strategic sectors like defence (see Chapter 7).

The potential prize is sizeable, though the opportunities and constraints vary by sector and region, and on how trade policies evolve in the coming years. In the Stated  Policies  Scenario  (STEPS),  which  takes  account  of  policies  that  have already been adopted or announced, or are at the advanced planning stage, global markets for low-emissions iron and ammonia for industrial use reach USD 8 billion by 2035. Already, publicly announced agreements for export of these materials, some of which are firm offtakes, have an estimated value exceeding USD 2 billion.

Many of Europe's industrial sites are ill-suited  to  low-cost  near-zero  emissions production. Importing intermediate low-emissions inputs and focusing on downstream manufacturing could safeguard the majority of their industry sector jobs (Agora Industry, 2025). For instance, Brazil already has competitive energy resources and existing iron and steel infrastructure, and so if Western European steel producers imported iron from Brazil produced with low-emissions hydrogen rather  than  producing  it  domestically,  the  average  steel  cost  premium  over conventional steel would fall from roughly 20% to near cost parity in that scenario (Figure 1.17). 11

Similarly,  Japan faces rising costs in adopting near-zero emissions production, primarily  as  a  result  of  high  energy  costs  due  to  geographical  constraints.  Its competitive advantage, however, lies in value-added industries further down the supply chain. The Middle East, by contrast, benefits from abundant renewable energy  resources,  making  low-emissions  ammonia  imports  from  this  region  a

11 An additional strategy could be to import iron produced with natural gas. Rather than reduce emissions intensity in steel production by roughly 85% compared to today's global average coal-based production, this would lead to a reduction of about 50% (IEA, 2022a), but for a potentially lower premium. Whether it could be attractive depends on there being a differentiated market for low-emissions steel with only partially reduced upstream emissions, among other policy objectives.

more  cost-effective  option  for  Japan;  urea  cost  premiums  would  fall  from approximately 80% to 55%. In both cases, importing hydrogen is also feasible, but tends to be more expensive. Its competitiveness will depend on the structure of specific  supply  chains  and  the  development  of  international  hydrogen  markets over the next decade.

Even  then,  some  policy  support  remains  necessary:  for  example,  the  cost  of producing near-zero emissions steel in Europe from imported iron is still projected to be about 30% higher than the cost of imports from China in 2035. However, these  trade-offs  may  prove  acceptable  if  they  preserve  jobs,  protect  domestic capacity and allow advanced economies to specialise in higher-value products. The  lesson  is  clear:  by  capturing  the  strategic  opportunities  provided  by  lowemissions technologies, advanced economies could proactively shape competitive, cleaner industries for the future.

Figure 1.17 Production costs of steel and urea using conventional and innovative technologies in the Stated Policies Scenario, 2035

## Steel, Western Europe (imports from Brazil)

<!-- image -->

<!-- image -->

Domestic value chain

- Imported low-emissions inputs

IEA. CC BY 4.0.

Notes: LCOP = levelised cost of production, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment; Conv. = conventional; H2 = hydrogen; NH3 = ammonia. LCOPs are indicative average costs for the selected technology pathways in each region. Indicated percentages show the relative cost premium for the relevant technology and trade scenario (columns) beyond the cost premium of the domestic case for low-emissions technologies (dashed line). All cost premiums are measured relative to the domestic conventional case. For steel production, hydrogen direct reduced iron using an electric arc furnace compared with a conventional blast furnace-basic oxygen furnace is assumed; for the ammonia step of urea production, electrolysis compared with conventional steam methane reforming is assumed. For urea production, biogenic CO2 is sourced for the low-emissions case and fossil CO2 is sourced from a co-located steam methane reforming process for the conventional case. Domestic value chain costs are those resulting from the production occurring in the importing region. Imported lowemissions inputs costs are those resulting from production of low-emissions H2, NH3, and iron occurring in the exporting region and the transportation of those inputs to the importing country. The cost of carbon pricing is included in the LCOP.

Strategic partnerships that maximise each region's strengths in low-emissions technology supply chains could boost resilience, lower transition costs and capture rising demand.

## 10. Is there a technology on the horizon that can replicate the explosive growth of solar PV and batteries?

## Why it matters

Energy rarely evolves in straight lines. Instead, it lurches forward when a new technology rewrites the rules: coal fuelled the industrial age, while oil reshaped the global economy. More recently, solar panels have revolutionised the way we generate  power  and  lithium-ion  batteries  have  made  it  attractive  to  store  that energy or use it to power a car. Like the fossil fuels that came before them, they are transforming the global energy landscape, creating entirely new markets for decentralised  electricity,  backup  power  and  EVs  -  riding  the  wider  wave  of electrification.  These  are  not  incremental  gains  but  decisive  shifts  that  are reordering markets, politics, energy security and daily life.

Governments and companies alike are asking whether another breakthrough is waiting in the wings - a technology capable of reshaping markets on the scale of solar  and  batteries,  and  unlocking  similar  wealth  for  those  who  design  it  and master its supply chain. No one wants to miss the 'next big thing'. The trouble is, in  today's  crowded  field  of  contenders,  it  is  far  from  clear  which  -  if  any  technology that will be.

## What is happening

The boom in solar and batteries over the past two decades is hard to overstate. At the turn of the century, global installed capacity of solar PV was negligible; in 2025,  it  accounted  for  more  than  half  of  new  capacity  additions.  Since  2015, installed capacity has multiplied eleven-fold. The use of batteries has risen even faster.  In  2015,  global  storage  was  almost  entirely  pumped  hydro;  in  2025, batteries are thought to have overtaken it. Their spread has been turbocharged by the rapid growth of EVs, which rely on the same technologies. Annual investments in solar PV and batteries combined have reached more than USD 500 billion similar to those in oil supply. Over the past 10 years, the former have more than tripled  while  the  latter  have  dropped  by  30%.  In  addition,  both  solar  PV  and batteries  still  have  a  long  way  to  run:  competitiveness  is  improving,  costs  are falling and their environmental advantages remain compelling.

Yet their success was far from assured two decades ago. Both were considered costly  options.  Early  progress  rested  on years  of research,  bolstered  by  public procurement, feed-in tariffs (for solar PV) and investment support in the first stages of market development, and later by advances in manufacturing. Public backing

helped drive down costs, and as innovation, economies of scale and learning-bydoing took hold, the technologies became competitive in their own right.

China emerged in the 2010s as the dominant market and manufacturer for both technologies, drawing on low labour and energy costs, a strong industrial base and sustained policy support - leaving the western countries that had pioneered them far behind. Today, China accounts for nearly two-thirds of both global solar PV module and battery sales. The United States, Japan and the European Union together represent  less than  6%  of  global  manufacturing  capacity  for  solar  PV panels and components, and less than 13% for batteries.

## What it means

One  way  to  think  about  which  emerging  clean  energy  technologies  might  be poised for explosive growth is to examine what made solar PV and batteries so successful in the first place. Six features stand out:

-  Modularity and manufacturability: Both can be mass-produced by competing firms  with  variations  on  a  standardised  design.  This  competition  has  been central to driving down costs: solar PV prices have fallen by more than 85% since 2010.
-  Standardisation with flexibility: They slot easily into different end-use products without changing their basic architecture, which in turn enables scale.
-  Multiple uses: They serve a range of applications in and beyond the energy sector,  allowing  early  uptake  in  premium  markets  before  breaking  into  the mainstream.
-  Technological maturity: By the time international policy and economic drivers aligned  -  demand  growth  in  emerging  economies,  concerns  about  climate change and local air pollution, and oil security risks in China - the technologies had already been tested for decades.
-  Tradability and ease of deployment: Both can be shipped globally and installed without specialised equipment or highly trained staff. In 2024, almost 20% of PV modules were traded across borders.
-  Existing  infrastructure:  Both  can  be  plugged  straight  into  existing  electricity grids.

Some technologies under active research do share several of these traits and promise to address certain problems that solar and batteries cannot, ranging from food security to clean heating and health. Investors are already casting their votes: the past couple of years have seen a steep increase of venture capital flows into six sectors: electrolysers for hydrogen production, geothermal, advanced heating and  cooling,  small  modular  nuclear  reactors,  hydrogen-based  fuels  and  grid technologies. The pattern is strikingly familiar: the same ramp-up in venture capital preceded the solar and battery booms (Figure 1.18).

But  no  technology  in  development  today  ticks  all  six  boxes.  Hydrogen  lacks transport infrastructure, geothermal is not modular, SMRs still need specialised staff  for  manufacturing  and  plant  construction.  However,  this  does  not  mean deployment will not take off. Historical examples show that deployment can take place  without  some  of  these  conditions.  For  example,  industrial  ammonia synthesis started in 1913 and took off in the 1960s driven by population growth and  fertiliser  demand  (Rouwenhorst,  Travis,  &amp;  Lefferts,  2022)  -  despite  the technology not being modular or flexible, and being limited to a single use.

Figure 1.18 Global venture capital flows to selected technologies, 2005-2025e

<!-- image -->

IEA. CC BY 4.0.

<!-- image -->

Notes: SMR = small modular reactor; EV = electric vehicle; VC = venture capital; H2 = hydrogen. Values are indexed to 2005 for solar PV and 2015 for EV and batteries. Values are 3-year moving averages. 2025 estimated based on data until mid-November. Heating/cooling includes mechanical or active systems (e.g. evaporative cooling), solid-state, passive and renewable thermal management systems. Investment refers to ongoing capital spending on assets.

Sources: IEA analysis based on IEA (2025f); Cleantech Group (2025) and Crunchbase (2025).

Recent years have seen a jump in venture capital flows into electrolysis, geothermal, heating and cooling technologies, small modular reactors and hydrogen-based fuels.

Another way to gauge potential is to map emerging clean energy technologies against  a  few  key  characteristics.  Three  quantifiable  traits  were  central  to  the success  of  solar  PV  and  batteries:  unit  size  (smaller  units  facilitate  rapid  cost reduction); reliance on climate policy (diverse market drivers reduce investment risk); and the size of the known addressable market (larger deployment can deliver greater  economic  impact).  Using  these  criteria,  we  identify  three  groups  of technologies with the greatest global potential - provided they become proven products and deployment conditions are favourable (Figure 1.19). All are mature enough  to  scale  up  and  would  be  deployed  rapidly  in  the  context  of  a  faster transition away from unabated fossil fuels, such as in the Net Zero Emissions by 2050 Scenario (NZE Scenario):

-  Scalable solutions are deployed in small units, can reduce emissions and have low  dependence  on  climate  policies.  They  could  break  into  mass-market

applications if costs fall and attractive consumer products emerge. Examples include heat pumps, energy storage using phase-change materials, advanced batteries, electric trucks and energy management systems for grid flexibility. These technologies see large investments in the NZE Scenario (Figure 1.19).

-  Mega-solutions have low reliance on climate policy or new infrastructure and could benefit from the electrification of end-uses, including AI applications. But their  large  scale  limits  the  speed  of  cost  reduction  and  installation  typically requires site-specific solutions. Examples  include long-duration energy storage,  industrial electrification, electricity grid infrastructure and  nextgeneration geothermal systems.
-  Major emissions displacers are highly dependent on the growth of markets for low-emissions alternatives or complements to today's conventional industrial technologies.  Rapid  expansion  of  these  markets  is  needed  to  sustain  high investment  over  a  decade,  generating  innovation  and  economic  returns. Examples  include  the  production  of  sustainable  aviation  fuels  and  lowemissions shipping fuels, ammonia and primary steel, as well as CO2 removal.

Figure 1.19 Selected clean energy technologies by asset or project size and dependence on climate policy, 2025-2050

<!-- image -->

IEA. CC BY 4.0.

Notes: CCUS = carbon capture, utilisation and storage; DAC = direct air capture; EV = electric vehicle; FCEV = fuel cell electric vehicle; HP = heat pumps; SAF = sustainable aviation fuels; ZEV = zero-emission vehicle. Dependence on climate policy is calculated based on the deployment ratio between the Stated Policies Scenario (STEPS) and Net Zero Emissions by 2050 Scenario (NZE Scenario).

Clean energy technologies with strong potential for scale-up can be classified into three archetypes based on typical average size and deployment dependence on climate policy.

In short, solar PV and batteries possess a unique combination of traits - rapid demand growth,  investment  surges  and  cost  reductions  -  that  will  be  hard  to match, apart from further advances in PV cell and battery design. In addition, to identify the next major opportunities, attention may need to shift towards crosscutting  components  used  across  multiple  types  of  energy  equipment.  These technologies tend to evolve more incrementally and attract less public attention, yet their leading suppliers stand to capture substantial value as demand expands across  several  sectors  simultaneously.  High-performance  motors,  industrial robots,  compressors,  heat  exchangers,  electrodes,  membranes,  cutting  tools, inverters and power-quality controllers are becoming crucial determinants of the competitiveness  of  a  range  of  products,  from  next-generation  batteries  and industrial electrolysers to geothermal energy and high-efficiency air conditioning. Together, these components already represent a global market of over USD 1 trillion.

In  addition,  a  handful  of  long-term  bets  could,  if  successful,  tap  into  markets potentially worth trillions of dollars by mid-century. These include nuclear fusion, solid-state cooling, iron ore electrolysis, limestone-free conventional cement and direct electrochemical ammonia production. Each faces substantial technical and cost barriers and none are expected to have a significant market share within a decade. Their deployment at large scale would require public support in the form of innovation, demand creation and economic incentives. However, history offers a cautionary note: few predicted that solar PV and batteries would take off as fast as they did.

## References

Agora Industry. (2025). The role of green iron trade in accelerating competitive steel transformation. Berlin: Agora Think Tanks GmbH. Retrieved from https://www.agoraindustry.org/publications/the-role-of-green-iron-trade-in-accelerating-steeltransformation

Alberta Department of Energy. (2024). Quest Carbon Capture and Storage Project Annual Summary Report. Retrieved from https://open.alberta.ca/dataset/e90a4e6e-2c11-44eeb198-de244261c585/resource/20fd42f8-6627-44af-82cad4af052a040b/download/quest-annual-summary-report-2023-alberta-department-ofenergy-and-minerals.pdf

- Alper, A., Yamazaki, M., &amp; Uranaka, M. (2025). US will have golden share in Nippon Steel's takeover of US Steel, lawmaker says. Retrieved from https://www.reuters.com/business/us-government-may-hold-some-us-steel-sharesnippon-steel-deal-kyodo-says-2025-05-27/
- ArcelorMittal. (2025). ArcelorMittal Europe urges faster implementation of Steel and Metals Action Plan. Retrieved from https://corporate.arcelormittal.com/media/newsarticles/arcelormittal-europe-urges-faster-implementation-of-steel-and-metals-actionplan
- Birol, F. (2025). Batteries are crucial technology for the 21st century . Retrieved from Financial Times: https://www.ft.com/content/874fb936-86de-4fa5-95a1-92afb46e2538
- BMI. (2024). Benchmark Minerals Lithium Ion Battery Gigafactory Assessment . Retrieved from https://www.benchmarkminerals.com/

BNEF. (2025). Data service . Retrieved from https://about.bnef.com/

Brown, C. P. (2025). Trump's trade war timeline 2.0: An up-to-date guide. PIIE . Retrieved from https://www.piie.com/blogs/realtime-economics/2025/trumps-trade-war-timeline20-date-guide

CEA. (2025, February 18). Nuclear fusion: WEST beats the world record for plasma duration! Retrieved from https://www.cea.fr/english/Pages/News/nuclear-fusion-west-beats-theworld-record-for-plasma-duration.aspx

CEPII. (2025). BACI . Retrieved from https://www.cepii.fr/CEPII/en/bdd\_modele/bdd\_modele\_item.asp?id=37

Chevron. (2024). Gorgon Gas Development and Jansz Feed Gas Pipeline Environmental Performance Report 2024. Retrieved from https://australia.chevron.com//media/australia/our-businesses/documents/2024-Gorgon-Gas-Development-andJansz-Feed-Gas-Pipeline-EPR.pdf

China, Ministry of Finance. (2025). The State Council Tariff Commission announced adjustments to tariffs on imported goods originating from the United States . Retrieved from https://gss.mof.gov.cn/gzdt/zhengcejiedu/202505/t20250513\_3963685.htm

Chinese Academy of Sciences. (2025). Chinese "Artificial Sun" Sets Milestone Record towards Fusion Power Generation . Retrieved from https://english.cas.cn/head/202501/t20250121\_899060.shtml#:~:text=The%20duration %20of%201%2C066%20seconds,set%20by%20EAST%20in%202023

Clean Air Task Force. (2024). Carbon capture and storage: What can we learn from the project track record? Retrieved from https://www.catf.us/resource/carbon-capturestorage-what-can-learn-from-project-track-record/

Cleantech Group. (2025). Retrieved from https://i3connect.com/front\_page

Crunchbase. (2025). Retrieved from https://data.crunchbase.com/reference/getting-started

Diário Oficial da União [Official Diary of the Union]. (2025). Imprensa Nacional [National Press] . Retrieved from https://www.in.gov.br/leiturajornal

Enhance Energy. (2024). Alberta Carbon Trunk Line project : knowledge sharing report. Retrieved from https://open.alberta.ca/publications/alberta-carbon-trunk-line-projectknowledge-sharing-report-2023

EUROfusion. (2018). European Research Roadmap to the Realisation of Fusion Energy . Retrieved from https://euro-fusion.org/wp- content/uploads/2022/10/2018\_Research\_roadmap\_long\_version\_01.pdf

EUROfusion. (2025). Wendelstein 7-X sets World record for long plasma triple product . Retrieved from https://euro-fusion.org/eurofusion-news/wendelstein-7-x-sets-worldrecord-for-long-plasma-triple-product/

European Commission. (2025). Publications Office of the European Union . Retrieved from https://op.europa.eu/en/

EV Volumes. (2025). Global Electric Vehicle Sales Data, Market Trends &amp; Forecasts You Can Trust . Retrieved from https://ev-volumes.com/

Financial Times. (2025). Russia imposes fees to stem flood of low-cost Chinese cars . Retrieved from https://www.ft.com/content/48cb143e-03ce-4e23-bc6a-7e47d673f1d8

Fraunhofer. (2024). Whitepaper "Mastering Ramp-up of Battery Production" . Retrieved from https://www.ffb.fraunhofer.de/en/publications/White\_papers\_environment\_reports\_studi es/Mastering\_Ramp-up\_of\_Battery\_Production.html

Fusion Energy Base. (2025). Retrieved from https://www.fusionenergybase.com/about

Fusion Industry Association. (2025). The global fusion industry in 2025. Retrieved from https://www.fusionindustryassociation.org/fusion-industry-reports/

Germany, Federal Ministry for Economic Affairs and Energy. (2024). Habeck übergibt Förderbescheid über rund 1,3 Milliarden Euro an ArcelorMittal [Habeck hands over funding notice for around 1.3 billion euros to ArcelorMittal] . Retrieved from https://www.bundeswirtschaftsministerium.de/Redaktion/DE/Pressemitteilungen/2024/0 5/20240530-foerderbescheid-1.3-mrd-euro-arcelormittal.html

Giannaris, S. et al. (2021). SaskPower's Boundary Dam Unit 3 Carbon Capture Facility - The Journey to Achieving Reliability. Proceedings of the 15th Greenhouse Gas Control Technologies Conference 15-18 March 2021 , 15. Retrieved from https://papers.ssrn.com/sol3/papers.cfm?abstract\_id=3820191

Global Times. (2025). New nuclear technology sees vast export potential . Retrieved from https://www.globaltimes.cn/page/202307/1295190.shtml

Global Trade Alert. (2025). Retrieved from https://globaltradealert.org/

H2View. (2025). HydrogenOne fund to return cash to shareholders in managed realisation. Retrieved September 15, 2025, from https://www.h2-view.com/story/hydrogenone-fundto-return-cash-to-shareholders-in-managed-realisation/2130274.article/

IEA. (2021). Carbon capture in 2021: Off and running or another false start? Retrieved from https://www.iea.org/commentaries/carbon-capture-in-2021-off-and-running-or-anotherfalse-start

- IEA. (2022a). Achieving Net Zero Heavy Industry Sectors in G7 Members . Retrieved from https://www.iea.org/reports/achieving-net-zero-heavy-industry-sectors-in-g7-members

- IEA. (2022b). Special Report on Solar PV Global Supply Chains. Retrieved from https://www.iea.org/reports/solar-pv-global-supply-chains
- IEA. (2023). CCUS policies and business models. Retrieved from https://www.iea.org/reports/ccus-policies-and-business-models-building-a-commercialmarket
- IEA. (2024). Energy Technology Perspectives 2024 . Retrieved from https://www.iea.org/reports/energy-technology-perspectives-2024
- IEA. (2025a). How can innovation help secure future battery markets and mineral supplies? Retrieved from https://www.iea.org/commentaries/how-can-innovation-help-securefuture-battery-markets-and-mineral-supplies
- IEA. (2025b). Global Hydrogen Review 2025. Paris: IEA. Retrieved from https://www.iea.org/reports/global-hydrogen-review-2025
- IEA. (2025c). Hydrogen Production and Infrastructure Projects Database. Paris: IEA. Retrieved from https://www.iea.org/data-and-statistics/data-product/hydrogenproduction-and-infrastructure-projects-database
- IEA. (2025d). The Path to a New Era for Nuclear Energy. Retrieved from https://www.iea.org/reports/the-path-to-a-new-era-for-nuclear-energy
- IEA. (2025e). The State of Energy Innovation. Retrieved from https://www.iea.org/reports/thestate-of-energy-innovation

IEA. (2025f).

World Energy Investment 2025

. Retrieved from https://www.iea.org/reports/world-energy-investment-2025

- IEA. (2026). Manufacturing and Trade Model Documentation. Retrieved from https://www.iea.org/reports/manufacturing-and-trade-model
- IEA Bioenergy TCP. (2023). Deployment of BECCUS value chains in the United States. Retrieved from https://www.ieabioenergy.com/wp-content/uploads/2023/03/BECCUS1.0\_US-Case-Study\_final\_update.pdf
- IEAGHG TCP. (2019). Retrieved from https://publications.ieaghg.org/technicalreports/201904%20The%20Shell%20Quest%20Carbon%20Capture%20and%20Storage%20Project .pdf

International Atomic Energy Agency. (2025). PRIS - Power Reactor Information System . Retrieved from https://pris.iaea.org/PRIS/home.aspx

International Trade Administration. (2025). International Trade Administration . Retrieved from https://www.trade.gov/

National Ignition Facility. (2025). Retrieved from https://lasers.llnl.gov/science/achievingfusion-ignition

Office of the United States Trade Representatives. (2025). Office of the United States Trade Representatives . Retrieved from https://ustr.gov/

Petra Nova Parish Holdings. (2020). Petra Nova Final Scientific/Technical Report. Retrieved from https://www.osti.gov/servlets/purl/1608572

Red Trail Energy. (2022). Red Trail Energy Subpart RR Monitoring, reporting, and verification (MRV) plan. Retrieved from https://www.epa.gov/system/files/documents/202204/rtemrvplan.pdf

Reuters. (2024). ADM pauses CO2 injection at carbon capture storage site after finding potential leak . Retrieved from https://www.reuters.com/sustainability/climateenergy/adm-pauses-co2-injection-carbon-capture-storage-site-after-finding-potential2024-10-02/

Rouwenhorst, K. H., Travis, A. S., &amp; Lefferts, L. (2022). 1921-2021: A Century of Renewable Ammonia Synthesis. Sustainable Chemistry . Retrieved from https://www.mdpi.com/2673-4079/3/2/11/review\_report

S&amp;P Global. (2025). Commodity Insights . Retrieved from https://www.spglobal.com/commodity-insights/en

Science Business. (2024). UK and Canada team up to solve nuclear fusion fuel shortage. Retrieved from https://sciencebusiness.net/news/uk-and-canada-team-solve-nuclearfusion-fuel-shortage

Sinoimex. (2025).

Global Trade &amp; Industry Growth Lab

. Retrieved from https://www.sinoimex.com/en/index

Sitharaman, N. (2025). Budget 2025-2026 . Retrieved from https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/feb/doc20252149 3201.pdf

Spangler, R., Qin, S., Larsen, L. M., Bolisetti, C., Abou-Jaoude, A., Asgari, M. and G. Wilkinson. (2025). Potential Cost Reduction in New Nuclear Deployments Based on Recent AP1000 Experience. INL. Retrieved from https://inldigitallibrary.inl.gov/sites/STI/STI/Sort\_173162.pdf

The Budget Lab. (2025). The Fiscal and Economic Effects of the Revised April 9 Tariffs . Retrieved from https://budgetlab.yale.edu/research/fiscal-and-economic-effects-revisedapril-9-tariffs

The White House. (2025). Briefings &amp; Statements . Retrieved from https://www.whitehouse.gov/briefings-statements/

UK Government. (2025). Government acts to save British steel production. Retrieved from https://www.gov.uk/government/news/government-acts-to-save-british-steel-production

US Environmental Protection Agency. (2023). Greenhouse Gas Reporting Program (GHGRP) . Retrieved from https://www.epa.gov/ghgreporting

US National Archives. (2025). Federal Register . Retrieved from https://www.federalregister.gov/

Vallance, P. (2025). Small Modular Reactor Programme and Site Allocation, Statement made on 13 November 2025 . Retrieved from https://questionsstatements.parliament.uk/written-statements/detail/2025-11-

13/hlws1050#:~:text=At%20the%20Spending%20Review%20the,government%20appro vals%20and%20contract%20signature

World Bank. (2025). Indicators . Retrieved from https://data.worldbank.org/indicator

World Nuclear News. (2024). China approves 11 new reactors . Retrieved from https://www.world-nuclear-news.org/articles/china-approves-11-new-reactors

World Nuclear News. (2025a). Ten new reactors approved in China . Retrieved from https://www.world-nuclear-news.org/articles/ten-new-reactors-approved-in-china

World Nuclear News. (2025b). Canada's first SMR project: How is CAD20.9 billion costcalculated? Retrieved from https://www.world-nuclear-news.org/articles/what-is-thebudget-for-canadas-first-smr-project

World Trade Organization. (2025). WTO Tariffs &amp; Trade Data . Retrieved from https://ttd.wto.org/en

## Part A

## Deployment of clean energy technologies, materials and fuels

Technology innovation and commercialisation are behind many new developments in energy markets. Today, the areas of clean energy technologies, near-zero emissions materials and low-emissions fuels are particularly dynamic, albeit to varying degrees. They have become a focus of attention in recent years as the market opportunities are linked to technological leadership and industrial expertise, and not solely to resource endowment. Companies and countries can therefore gain a foothold in these markets by being at the forefront of innovation and commercialisation pathways.

Part  A  of  this  report  explores  the  outlook  for  the  deployment  of  clean  energy technologies, near-zero emissions materials and low-emissions fuels on the basis of IEA scenarios. It consists of a discussion of the major trends and factors that explain them in the outlook (Chapter 2) followed by a series of visual dashboards (Chapter 3) with key metrics for each major technology, including market size, cost-competitiveness, technical performance, infrastructure needs and innovation.

## Chapter 2. Outlook for deployment of clean energy technologies

## Highlights

-  Many clean energy technologies are increasingly cost-competitive and growing strongly. Their aggregate market value has grown 20% on average per year since 2015 to reach nearly USD 1.2 trillion.  Some  80%  of  global  solar  PV  and  wind generation now occurs at lower levelised costs than for coal or gas. Battery prices have dropped 75% since 2015, pushing electric car sales to around 25% share in  2025.  Deployment  increases  in  all  IEA  scenarios:  in  the  Current  Policies Scenario (CPS), their global market value nearly doubles to around USD 2 trillion in 2035, greater than the oil market in 2025 . In the Stated Policies Scenario (STEPS), their  market  value  approaches  USD 3 trillion,  and  in  the  Net  Zero  Emissions  by 2050 Scenario (NZE Scenario), more than USD 5 trillion.
-  The market for near-zero emissions materials remains almost non-existent, due to  the  limited  availability  of  cost-competitive  technologies  at  scale,  insufficient policy  support  and  low  consumer  willingness  to  absorb  cost  premiums.  Yet momentum is building: 105 Mt of near-zero emissions steel production capacity has been announced since 2020 (equal to around 5% of global production today), roughly double the conventional capacity additions, though only 5% has taken final investment decision (FID). A strong policy push is needed for a large market for near-zero emissions materials: in the NZE Scenario, it reaches USD 500 billion in 2035, far higher than in the STEPS (USD 20 billion) and CPS (USD 5 billion).
-  The market for low-emissions fuels grew by an average of 7% annually in the past decade, reaching around USD 215 billion in 2025, but remains small, equal to  less  than  10%  of the market  for  oil-based  transport  fuels in 2025 . Growth opportunities exist: the market value for low-emissions fuels increases significantly in the STEPS and the CPS to around USD 390 billion in 2035. Higher deployment  requires  stronger  policy  support  to  overcome  cost  premiums;  the market for low-emissions fuels grows fivefold by 2035 in the NZE Scenario.
-  The deployment outlook hinges on manufacturing and enabling infrastructure. Investment  in  production  assets  for  clean  energy  technologies,  near-zero emissions materials  and low-emissions fuels is around  USD 245 billion  today, about three times more than 5 years ago. Investments in infrastructure, primarily electricity  grids,  total  around  USD 430 billion,  about  40%  more  than  in  2020. While average annual investment in production assets in 2031-35 falls by 60% in the STEPS compared to today, average annual investment in grids is about 60% higher.

## Recent market trends

Technology  innovation  and  commercialisation  form  the  basis  of  any  new development in energy markets. Today, the areas of clean energy technologies, near-zero emissions materials and low-emissions fuels are particularly dynamic, even if to varying degrees. They have become a focus of attention in recent years as the market opportunities are linked to technological leadership and industrial expertise, not solely to resource endowment - companies and countries can gain a foothold in these  markets  by  being  at  the  forefront  of innovation  and commercialisation pathways.

## Clean energy technology markets keep expanding

The global market for clean energy technologies has grown rapidly in recent years and continues to develop at pace. The combined market for key technologies 1 expanded at an average rate of close to 20% per year between 2015 and 2024. The  market  for  2025  is  projected  to have grow n by  nearly  25%,  pushing  the value  to nearly USD 1.2 trillion  - overtaking the coal market and approaching 2 the scale of the natural gas market (Figure 2.1).

Electric cars have been the main driver of this expansion. The global market for electric cars grew by more than 40% per year on average between 2015 and 2024, accounting for around 90% of total clean energy technology market growth. This surge has been powered by rising sales, which more than offset a 30% decline in average electric car prices - a drop supported by a 75% fall in battery costs - over the same period. Nonetheless, despite this growth, in 2024, the global market for electric cars (around USD 690 billion) was just 30% of the size of the conventional car market. Electric car markets have grown at different speeds across different regions, and for different reasons. In China, electric cars became an industrial policy  priority  in  2001,  and  in  2024,  they  represented  close  to  50%  of  its  car market,  with  sales  reaching  USD 330 billion  -  the  world's  largest  electric  car market. The second-largest market for electric cars is the European Union, where sales have been driven mainly by energy security and climate change priorities, and totalled close to USD 150 billion in 2024. The market for other road vehicles, in particular zero-emission trucks that are powered by batteries or fuel cells, has also grown steadily - by around 25% per year - largely in line with rising sales. However, it remains considerably smaller than the market for electric cars, and

1 Electric cars, zero-emission trucks, other electric vehicle batteries and stationary batteries, solar PV modules, wind turbines, heat pumps, electrolysers and alternative propulsion ships.

2 Unless stated otherwise, USD figures are real 2024 dollars in market exchange rate terms throughout this report.

zero-emission truck sales represented less than 2% of all truck sales globally in 2024.  To  an  even  greater  extent  than  for  electric  cars,  the  market  for  zeroemission trucks is largest in China, accounting for around USD 13 billion of the approximately USD 16 billion market globally in 2024.

Figure 2.1  Global market for selected clean energy technologies, 2015-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: Heat pumps are residential only (the industrial heat pump market remains negligible). Wind turbines include towers, nacelles and blades. Electrolysers refer to the stack. Other batteries include electric vehicle batteries for vehicles other than cars  and  trucks,  as  well  as  stationary  storage  batteries.  Sales  of  wind  turbines,  solar  PV  modules,  heat  pumps  and electrolysers are measured in terms of GW; sales of electric cars, zero-emission trucks, and alternative population ships are measured in terms of number of vehicles or vessels; sales of other batteries are measured in terms of GWh. Source: IEA analysis based on BNEF (2025).

The  global  market  for  key  clean  energy  technologies  has  grown  strongly  over  the  past decade, at an average of almost 20% per year, driven primarily by electric cars.

In the power sector, the market value for solar PV and wind turbines has grown much more slowly, as plunging costs have offset much of the growth in demand. Solar  capacity  additions  grew  tenfold  between  2015  and  2024,  yet  the  overall market value rose by only 4%, or less than 1% per year, due to an 85% drop in the  cost  of  PV  modules  (Figure  2.2).  Similarly, while  wind  turbine  costs  fell  by around 55% over the same period, market growth was more modest. Despite a 75% increase in capacity additions since 2015, the market value in 2024 remained broadly similar over the same period, reflecting the impact of significantly lower prices. In 2024, around 650 GW of solar and wind electricity generation capacity was added, more than eight times the fossil fuel-based capacity additions.

Figure 2.2  Global average clean energy technology price trends, 2015-2025e

<!-- image -->

IEA. CC BY 4.0.

Note: Heat pumps are residential only.

Sources: IEA analysis based on BNEF (2025); InfoLink (2025); and S&amp;P Global Mobility (2025).

The prices of most clean energy technologies have fallen sharply since 2015, especially solar PV modules, lithium-ion batteries and wind turbines.

The  market  for heat  pumps  for  heating  purposes  reached  approximately USD 50 billion in 2024, having grown at an average annual rate of more than 5% since 2015. The heat pump market reached about half the size of the gas boiler market in 2024 and is now almost as big as the solar PV market. Market growth has continued despite prices remaining relatively constant since 2015, due to heat pumps increasingly coming with additional features (e.g. quieter operation). While China deployed the most heat pumps (by capacity) in 2024, the United States was home to the largest heat pump market, valued at over USD 17 billion, representing about one-third of the global market that year.

Markets for technologies such as electrolysers for dedicated hydrogen production and  low-  or  zero-emission-capable  ships  are  still  in  their  early  stages,  and  so recent growth patterns are uneven. Electrolyser deployment began to accelerate in the early 2020s, and global installed capacity doubled in 2023 with the addition of nearly 700 MW. Growth then slowed in 2024 but picked up again in 2025. The market for methanol- and ammonia-fuelled ships has also been volatile, due to the wide variation in vessel size and type. In 2024, for instance, the delivery of seven large methanol-fuelled containerships and one large chemical tanker expanded the value of the market to more than USD 1 billion - 13 times larger than in 2023, when  only  two  methanol-powered  chemical  tankers  were  delivered.  However, methanol-  and  ammonia-fuelled  ships  continue  to  represent  a  relatively  small share  of  expected  new  ships  (around  6%  of  gross  tonnage  to  be  delivered  in 2025);  orders  for  liquefied  natural  gas  ships  that  could  eventually  be  run  on biomethane make up a greater share of planned deliveries.

China has consistently been the largest market for clean energy technologies over the past decade, increasing from slightly less than 40% of the global clean energy technology market in 2015 to close to 45% in 2025. A decade ago, wind turbine components accounted for the largest share - about 35% - of the USD 80 billion clean energy technology market in the country. The market for solar PV modules was slightly smaller, representing almost one-third. Electric cars represented only 10% of the market in 2015, but in 2018 they took the lead, and have remained the largest clean energy technology market in China ever since. In 2025, the electric car market in China is expected to have reached USD 390 billion, accounting for more than 80% of the total clean energy technology market in China.

Figure 2.3  Market value for selected clean energy technologies by region, 2015-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes:  AEs  =  advanced  economies;  EMDEs  =  emerging  markets  and  developing  economies.  Selected  clean  energy technologies include electric cars, zero-emission trucks, other electric vehicle batteries and stationary batteries, solar PV modules, wind turbines, heat pumps, electrolysers and alternative propulsion ships.

Source: IEA analysis based on BNEF (2025).

China  has  remained  the  largest  market  for  key  clean  energy  technologies  over  the  past decade, though Europe has experienced a similar annual growth rate of over 20% since 2015.

Europe is the second-largest clean energy technology market today, with market growth averaging more than 20% per year from 2015 to 2025, a rate similar to China. Electric cars were responsible for 85% of the growth in the European clean energy technology market over this period and have represented the majority of the market in Europe since 2017.

In 2015, the North American clean energy technology market was just 1% smaller than  the  European  market  but  has  grown  at  a  slower  annual  rate  since  then, increasing on average 15% per year to 2025. In 2025, the North American market

for  clean  energy  technologies  is  expected  to  have  increased  by  less  than  3% compared to 2024, reaching around USD 165 billion, representing less than 15% of the global market.

In India, the market for clean energy technologies is estimated to have grown by around 40% in 2025, compared to 2024. However, this is a recent trend: growth in  the  Indian market has averaged only 10% per year since 2015, to reach an estimated  USD 18 billion  in  2025.  The  total  clean  energy  technology  market in emerging  economies  excluding  China is  estimated  to have reach ed USD 75 billion  in  2025,  less  than  15%  the  size  of  the  market  for  clean energy  technologies  in  advanced economies.

## Near-zero emissions materials: a market opportunity or a challenging market?

Near-zero  emissions  materials  are  materials  produced  using  processes  and technologies that generate very low emissions 3  (IEA, 2024a). The global market for  key  bulk  materials  -  including  steel,  cement,  aluminium  and  ammonia  produced through conventional emissions-intensive routes has grown steadily by around 5% annually since 2015, to reach an estimated USD 1.8 trillion in 2025. In contrast,  the  market  for  near-zero  emissions  alternatives  remains  almost  nonexistent  today.  This  is  primarily  due  to  the  limited  availability  of  commercially available or cost-competitive technologies and insufficient consumer appetite to absorb cost premiums in the absence of sufficiently strong policy support.

However, momentum is starting to build around these markets, with demand from end-users  playing  a  key  role  in  helping  to  accelerate  deployment.  Some  early buyers, including those participating in the First Movers Coalition, have expressed a  willingness  to  pay  a  higher  price  -  sometimes  referred  to  as  the  'green premium'. In some cases, this premium could be substantial. In the steel sector, for example, Stegra has reported a price premium of 25-35% (Johnson, 2025) for its low-emissions steel, while SSAB expects to charge a premium of EUR 200-300 (USD 235-350)  per  tonne  for  its  product  (SSAB,  2025).  Together,  these  two companies represent 60% of all announced offtake agreements for iron-based near-zero emissions steel.

In parallel, voluntary labels and certifications have emerged in recent years as a way  to  enable  demand  for  near-zero  and  low-emissions  materials.  Existing labelling schemes - which have mainly been developed by the private sector -

3 The definition of near-zero emissions materials used is materials that are compatible with the endpoint of a net zero emissions pathway such as the IEA's NZE Scenario.

help to communicate emissions performance, justify price premiums, and create differentiated markets for these  materials.  While  announced  certifications  for materials on the market remain limited, their potential coverage is significant: the share  of  total  global  materials  production from companies that are  members  of the organisations developing these standards is almost 70% for steel and nearly 50% for cement.

Demand for near-zero emissions materials is growing, driven by such voluntary commitments.  In  the  case  of  steel,  demand has  more  than  doubled  each  year since 2021, on the back of individual buyer agreements and industry-led demand aggregation initiatives. This has helped advance several first-of-a-kind near-zero emissions projects and demand could continue to grow, especially if pioneering buyers begin to reap reputational or  marketing  benefits  that  incentivise  broader industry participation. Nevertheless, demand from voluntary commitments makes up  only  a  very  small  share  of  the  total  market:  announced  offtake  agreements (both firm and preliminary) and aggregated demand from both public and private international  initiatives  currently  account for just 0.4%  of total global steel demand.  For  ammonia, the  story  is  similar, although it has been able to attain a larger  market  share:  low-emissions  offtakes  from  industrial  users  could  fulfil almost 4% of global ammonia demand for industrial applications.

In addition, the project pipeline for near-zero emissions materials production has expanded significantly in recent years. Announced steel capacity has grown at an average annual rate of 55% since 2020 (Figure 2.4) and cement projects at 50%. The  first  small-scale  aluminium  project  has  also been  launched.  Production capacity for  conventional  materials  has  grown  much more slowly (&lt;1% for steel and  cement,  3%  for aluminium), albeit from a larger base. Since 2020, announcements  of  new  capacity  for  near-zero emissions  steel  have  reached around 105 Mt - roughly double  the growth  in  conventional  capacity (of around 50 Mt). For cement, growth in announced near-zero emissions capacity (around 55 Mt) contrasts  with a  decline  of  nearly  300 Mt  in  conventional  production. Regional  growth  trends  vary:  Europe  and  the  Middle  East  lead  on near-zero emissions  steel  projects  (Figure  2.4),  North  America  and  Africa on ammonia, Europe and North America on cement, and Canada on aluminium. However, many of these projects remain at early stages of development, with only a small share having reached FID, equivalent to 5% of announced capacity for steel and 10% for cement.

In the steel sector, near-zero emissions steel production capacity announced to date is sufficient to produce just over 5% of the world's overall steel demand. More than 90% of this capacity is considered 'near-zero emissions capable', meaning that  it would  operate  using  the  same  core  process  equipment  as  near-zero emissions capacity - achieving a substantial reduction in emissions intensity from the start, compared to current conventional technologies - but it would initially fall short of the emissions intensity required for near-zero emissions. However, these

projects  have  plans  to  reduce  emissions  to  a  level  consistent  with  near-zero emissions at a later date, and would be designed with technical capabilities that enable near-zero emissions production in the future without substantial additional capital investments in core process equipment.

Much of the project pipeline for near-zero emissions steel is in Europe, where recent  growth  has  been  driven  by  government  emissions  targets  and  broader market  signals  that  are  building  momentum  for  the  transformation  of  heavy industry despite higher costs (see below). Projects that have reached FID status have typically benefited from significant public subsidies to help bridge the cost gap.  Nevertheless,  despite  some  progress,  there  has  been  a  wave  of  project delays and cancellations over the past year, due to difficult market conditions and withdrawal of government support.

Figure 2.4  Near-zero emissions steel demand and production project pipeline by region, 2020-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: Announced and committed demand refers to estimated offtake for near-zero emissions steel based on preliminary and firm announcements from individual companies and private sector demand aggregation initiatives. Compliant refers to projects that operate as near-zero emissions from the start; have achieved a final investment decision (FID) or provided strong certainty that FID will be achieved; and include clear information confirming near-zero emissions production. Capable refers to 'near-zero emissions capable' projects; projects that have not achieved an FID, or are not near achieving one, are also included in this category due to greater uncertainty. For further information, see the definitions of these terms in Chapter 3. Production from announced projects shown here excludes near-zero emissions steel from 100% scrap. Source: IEA analysis based on publicly available announcements.

While  significant  capacity  capable  of  producing  near-zero  emissions  steel  has  been announced, much of it is not expected to operate as fully near-zero emissions at the outset.

## Box 2.1 Major steel  producing markets are approaching the new market opportunity differently

China  (52%  of  global  steel  production  today): Announcements  of  near-zero emissions projects have been slower than in other major steel producing countries but co-ordinated action through the China Iron and Steel Association has led to a draft standard for near-zero emissions steel with a threshold that is aligned with the IEA's  proposed  definition  from  the  report Achieving  Net  Zero  Heavy  Industry Sectors in G7 Members (IEA, 2022). This aims to build market foundations and support premium pricing and export access. Several hydrogen-ready projects have been announced and successfully brought into operation, with the aim of switching to hydrogen later.

European Union (7%): Following  a  wave  of  early  announcements, few projects have reached FID, with some delayed, postponed or cancelled. Producing nearzero emissions steel from hydrogen in the European Union is projected to be 2570%  more  expensive  than  in regions with cheaper  energy, such as the United States or the Middle East, by 2035. Despite available subsidies and other mechanisms helping to narrow this cost gap, the resulting price premiums remain too  high  for  most  buyers.  Mechanisms  to  address  this  include  the  Emissions Trading Scheme, the Carbon Border Adjustment Mechanism, proposed contracts for difference, and a new low-emissions product label under the Clean Industrial Deal.

North  America  (6%): Demand  is  emerging:  RMI's  Sustainable  Steel  Buyers Platform identifies 1 Mt of demand from North American firms (RMI, 2024). Early projects continue to need subsidies, and some US projects have been cancelled or defunded. Canada  is supporting deployment through several mechanisms, including  Clean  Economy  Investment  Tax  Credits  targeting  carbon  capture, utilisation  and  storage  (CCUS)  and  low-emissions  hydrogen  production  facilities that reduce emissions from conventional steel plants.

Japan (4%): Few near-zero emissions steel projects have been announced, as efforts focus more on incremental emissions reductions than full decarbonisation. Companies are adopting the 'Green Steel for GX' label, which uses a mass balance approach to allocate emissions reductions to select steel products, allowing them to be marketed as 'green steel.' The government offers subsidies to support this strategy  and  incentivises  low-emissions  steel  procurement,  including  through subsidies for carmakers producing electric vehicles (EVs) and public procurement rules.

Middle East (3%): Several projects plan to begin using natural gas and switch to hydrogen  as  it  becomes  available.  While  this  approach  means  the  emissions reductions are lower initially, it can stimulate market development. However, without clear  hydrogen transition  timelines, there  is  a  risk  of  carbon  lock-in  and  missed opportunities to expand the market for near-zero emissions steel.

## The  small  low-emissions  fuels  market  is  dominated  by established biofuels

The market for low-emissions fuels 4 remains relatively small today. Between 2015 and  2024,  the  combined  market  for  selected  biofuels  and  low-emissions hydrogen-based  fuels  -  including biodiesel, bioethanol, biogas, hydrogen, ammonia, methanol and synthetic fuels - grew at an average rate of about 7%. It is expected to have continued to expand in 2025, reaching roughly USD 215 billion. Despite this growth, the sector represents less than 10% of the market value of fossil diesel and gasoline used in transport today, as sustainable fuels continue to account for only a limited share of global energy consumption. In 2024, liquid  biofuels  made  up  around  5%  of  energy  use  in road transport  and around 0.1% of jet fuel demand. Low-emissions hydrogen supplied less than 1% of total hydrogen use, while demand for low-emissions ammonia and methanol in shipping remains limited, awaiting the delivery of additional new vessels.

Conventional biofuels such as biodiesel, bioethanol, and biogas make up the bulk of the market for low-emissions fuels today. The value of the market for biodiesel and bioethanol has grown relatively steadily over the past decade, at an 8-10% annual average growth rate, supported by blending mandates, while growth for biogas has been more marginal, at 2% per year.

Overall growth in hydrogen and hydrogen-based fuels has not met the ambitious goals set  by  project  announcements  in  recent  years,  hampered  by  high  costs, uncertain demand and regulatory environments, and slow infrastructure deployment.  It  is  nonetheless  considerable:  the  value  of  the  low-emissions hydrogen market for fuel applications has grown at an average of 7% per year since 2020, albeit from a low base. In the short term, demand for low-emissions hydrogen for fuel applications is being driven mainly by its use in refining. New applications still represent a small share of demand, but demand for hydrogenbased fuels (ammonia and methanol) for shipping (and to a lesser extent for power generation and aviation) stands out. These applications account for around 40% of  the volume included in firm offtake agreements for low-emissions hydrogen. Despite these signs of early progress in the market, current offtakes remain too limited in volumes to secure large investments, which is compounded by them often being non-binding. Some firm offtakes in these applications have, however, led to investment decisions for production, such as at a synthetic methanol plant in  Denmark.  In  2025,  production  of  low-emissions  hydrogen-related  fuels  is

4 Low-emissions fuels designate fuels and chemical feedstocks that can be produced from plants, which absorb CO2 from the atmosphere as they grow, or through industrial processes that generate very low emissions, for example renewablepowered and/or using CO2 captured from the air or biogenic sources. These can include both gaseous - biogas, hydrogen, synthetic methane - and liquid - biofuels, ammonia, synthetic hydrocarbon fuels - products.

expected to have risen by 30%, with around 60% of the increase from electrolytic hydrogen, driven by China, which benefits from low-cost renewables and domestic equipment, and 40% from CCUS projects in the United States, spurred by the 45Q tax credit on CO2 storage.

Sustainable aviation fuels (SAFs) make up a very low share of the low-emissions fuels market but are growing faster than all other low-emissions fuels. The value of  the  market  for  biokerosene  -  mostly  produced  from  waste  and  residue  oils feedstocks today - grew at an average annual rate of 150% between 2021 and 2024. This uptick was primarily driven by blending mandates, for example in the European Union,  United Kingdom  and  Brazil,  as  well  as  by  regulatory  targets, despite significantly higher costs (see Chapter 3).

Figure 2.5  Low-emissions fuels market size trends, 2015-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: Market size is calculated based on fuel production volumes and prices, allocated to the point of demand. Market size excludes  the  use  of  hydrogen,  hydrogen-based  fuels,  and  biofuels  as  feedstock  in  industry.  The  market  for  hydrogen, ammonia  and  methanol  used  as  fuels  and  feedstock  in  industry  was  around  USD 1 billion  in  2024.  For  hydrogen  and hydrogen-based  fuel  production,  fuel  production  costs  are  used  as  proxies  for  prices.  Biogases  include  biogas  and biomethane. Synthetic fuels include synthetic methane and kerosene. Hydrogen and hydrogen-based fuels are only included from 2018 onward. While small volumes of synthetic kerosene are produced, the market pre-2025 is negligible and has been removed from the indexed chart (right).

Low-emissions fuels markets remain dominated by conventional biofuels, while emerging fuels like biokerosene and low-emissions hydrogen are growing from a small base.

## Global outlook

Growth in the development and deployment of clean energy technologies, nearzero emissions materials and low-emissions fuels has been strong over the past decade. The extent and pace at which these developments continue, however, is in no small part linked to government policy and the extent to which it enables deployment hurdles linked to infrastructure, cost premiums and regulatory barriers

to  be  overcome. This section explores the outlook for the deployment of clean energy  technologies,  near-zero  emission  materials  and  low-emission  fuels through the lens of IEA scenarios. The analysis begins with an overview of energy trends under different scenarios before examining the market prospects for each of the three areas in turn, as well as providing an overview of the investments required.

## The use of clean energy grows across all scenarios

Today, clean energy represents 18% of the global energy mix, up from less than 15% in 2015. This share is set to continue growing in all the outlooks discussed in this report, reaching 27% in 2035 in the STEPS, 25% in the CPS and 52% in the NZE Scenario. Clean energy demand increases more than 60% from now to 2035 in the STEPS, reaching around 195 EJ - a level similar to today's oil demand. The increase  is  not  much  lower  in  the  CPS,  at  55%,  whereas  the  trajectory  of  the NZE Scenario  requires  an  increase  of  145%.  The  use  of  solar  PV  grows particularly strongly, almost quadrupling over the next decade in the STEPS, while use of wind energy grows by 150%. As a result, the use of unabated fossil fuels falls by 7% to 2035 (mostly at the expense of coal) in the STEPS, even as total energy demand increases. By contrast, unabated fossil fuel use grows slightly to 2035 in the CPS, by around 1%. In the NZE Scenario, total energy use declines by 14%, with unabated fossil fuel demand almost halving.

Figure 2.6  Global energy mix by scenario, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario. Oil, coal and natural gas refer to unabated uses as well as non-energy use. Clean energy includes renewables, modern bioenergy, nuclear, abated fossil fuels, low-emissions hydrogen and hydrogen-based fuels. Other includes traditional use of biomass and non-renewable waste.

Clean energy demand grows in all scenarios; in the STEPS, it increases over 60% by 2035, reaching a level similar to today's oil demand.

The extent of clean energy growth has direct implications for emission trajectories. In the NZE Scenario, energy sector emissions in 2035 are around half the level projected in the STEPS and 45% of the level in the CPS in the same year. More than  a  quarter  of  the  increase  in  clean  energy  over  the  next  decade  in  the NZE Scenario comes from growing demand for solar PV. This has a significant impact on the emissions trajectory: about one-fifth of the cumulative emissions savings to 2035 in the NZE Scenario relative to the STEPS are associated with solar PV. Growth in modern bioenergy and wind each represent close to 20% of the growth in clean energy over the next decade in the NZE Scenario, and abated fossil fuels almost 10%.

The  growing  electrification  of  end-use  sectors  is  a  common  feature  across  all scenarios. The share of electricity in final energy demand increases from about 20% today to around 25% in 2035 in the STEPS and the CPS, and above 30% in the  NZE  Scenario.  Thanks  in  part  to  the  efficiency  gains  brought  about  by electrification,  total  electricity  demand  in  the  NZE  Scenario  in  2035  is  just  2% higher than in the STEPS and the CPS, meaning electricity demand grows by more than  30%  over  the  next  decade  in  all  scenarios.  Uptake  of  heat  pumps contributes to electricity reaching almost 50% in the final energy demand mix of buildings  in  2035  in  the  STEPS  and  in  the  CPS,  and  over  55%  in  the NZE Scenario, from close to 40% today. Electricity consumption for transport also grows,  albeit  from  a  lower  base.  Electricity  represents  6%  of  transport  energy consumption in the STEPS in 2035, 5% in the CPS and more than double that in the  NZE  Scenario,  up  from  less  than  2%  today.  The  electrification  of  industry grows from 24% today to 26% in 2035 in the STEPS, remains at 24% in the CPS, and increases to 32% in the NZE Scenario. Electrification in industry over the next decade  is  mainly  driven  by  the  electrification  of  low-temperature  heat  in  nonenergy intensive industries and growth of electricity-intensive scrap-based steel production.

From 2025 to 2035, the demand for liquid biofuels grows by about 30% in both the STEPS and CPS, but their share of total energy demand grows only slightly to reach around 1% in 2035. Biofuels, including biomethane, play a larger role in the transport sector, increasing from around 4% of transport energy demand in 2025 to over 5% in 2035 in the STEPS. A third of the increase in the demand for biofuels from 2025 to 2035 in the STEPS comes from increased demand for road transport; just under 20% is for aviation. In the NZE Scenario, demand for liquid biofuels more than doubles from 2025 to 2035, reaching 3% of total energy demand and 10% of transport energy demand.

Figure 2.7  Total energy consumption per fuel and electricity demand per end-use sector and by scenario, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario. Renewables include modern bioenergy and renewable waste.

Demand for electricity is set to grow more than 30% over the next decade based on the stated policy direction; at the same time, renewable energy supply grows 70%.

Demand for low-emissions hydrogen and hydrogen-based fuels in 2035 in the STEPS is more than 20 times the demand estimated for today. Nevertheless, hydrogen and hydrogen-based fuels represent just 0.1% of global energy demand in 2035 in the STEPS, a marginally higher share than in the CPS. Demand in 2035 in  the  NZE  Scenario is more than ten times higher than in the STEPS, driven mostly by increased consumption for transport, especially for the shipping sector. Still,  hydrogen  and  hydrogen-based  fuels  represent  less  than  1.5%  of  energy consumption in the NZE Scenario in 2035.

## Box 2.2 Enabling infrastructure: electric grids in the spotlight

As  the  world  moves  into  the  age  of  electricity,  with  an  increasing  reliance  on distributed energy sources and growing electricity demand from various dispersed end-uses, grids are becoming ever more critical to the functioning of the energy system.  Electricity  demand  grows  sharply  over  the  next  decade  in  all  outlooks discussed in this report: by more than 30% in both STEPS and CPS and by 35% in the NZE Scenario. The upgrades and expansion of electricity grids required to meet and  maintain  the  growing  demand  for  electricity  will,  in  turn,  require  more  grid components, such as cables, inverters and transformers. Beyond sheer expansion, grids will also face increased capacity constraints and growing system complexity as variable renewables, distributed resources and increased electrification reshape

power flows and operational requirements. To tackle these challenges, grids will need enhanced dynamic control capabilities to manage rapid voltage fluctuations and dynamic line rating to unlock additional capacity and reduce the need for costly new infrastructure.

Global demand for cables grew by 6% in 2024, mainly driven by growing demand in  China  and  other  emerging  markets  and  developing  economies  (EMDEs).  In advanced  economies,  more  than  80%  of  new  cable  line  length  was  used  for replacements, while growing electricity demand was responsible for 40% of total new cable length  in  China,  and  60%  in  other  EMDEs. The  overall  length  of  the cables in the grid is set to grow by roughly 3.9 million kilometres per year on average from 2025 to 2035 in the STEPS, by 3.8 million kilometres in the CPS and by roughly 4.3 million kilometres per year in the NZE Scenario. The larger needs in the NZE Scenario stem from higher deployment of renewables and increased electrification compared to other scenarios.

Figure 2.8 Cable additions by region, purpose and scenario, 2023-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: EMDEs = emerging markets and developing economies; CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario. ' Increased demand' refers to additions due to an increase in demand, 'Renewables' refers to additions due to an increase in renewables and 'Replacements' refers to additions due to replacements of existing lines.

Inverters, which are necessary to convert the direct current generated by solar PV into  alternating  current  that  is  compatible  with  the  existing  grid,  are  another important  component  in  the  context  of  grid  upgrades  and  expansion.  In  2024, demand for PV inverters grew by over 20%, reaching more than 400 GW.

Transformer demand has also surged in the past 5 years, outpacing supply and resulting in increased prices and lead times. Average annual transformer capacity additions  and  replacements  reached  3 GW  between  2015  and  2024,  driven  by increased  electrification,  large  new  electricity-consuming  facilities  (such  as  data centres  and  EV  charging  networks),  rapid  expansion  of  distributed  electricity generation and ageing infrastructure. As these trends accelerate between 2025 and

2030,  annual  average  transformer  capacity  is  set  to  reach  around  6  GW  in  the STEPS and CPS, with China alone representing roughly 70% of total additions in both scenarios. It reaches more than 7 GW in the NZE Scenario.

Manufacturing is critical to meet this increasing demand for grid technologies and to  counter  any  possible  bottlenecks  or  supply  chain  risks.  Clear  visibility  on investments, long-term procurement signals and harmonised technical standards are important to enabling manufacturing expansions at a pace that encompasses demand growth. See Chapter 6 for further investigation of these risks.

## Market opportunities are not evenly distributed

Over the next decade, the value of the global market for clean energy technologies is  set  to  grow  in  all  IEA  scenarios. In the  STEPS, the market for clean energy technologies grows almost two-and-a-half times to approach USD 3 trillion (in real 2024 dollars) by 2035, while it almost doubles to reach around USD 2 trillion in the CPS.  The  value  of  the  market  for  clean  energy  technologies  reached  in 2035 across all scenarios is greater than the value of the global oil market in 2025 .

Figure 2.9  Global and regional market size of selected clean energy technologies by scenario, 2015-2035

<!-- image -->

2015

Europe

China

AEs

CPS

STEPS

2035

North America

Other AEs

India

EMDEs

IEA. CC BY 4.0.

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario. AEs = advanced economies; EMDEs = emerging markets and developing economies. Wind turbines include towers, nacelles and blades. Electrolysers refer to the stack. Heat pumps include residential and industrial. Alternative propulsion ships refer to methanol- and ammonia-fuelled ships. Other batteries include electric vehicle batteries for vehicles other than cars and trucks, as well as stationary storage batteries.

The value of the market for clean energy technologies grows two-and-a-half times over the next decade in the STEPS.

Other EMDEs

By region

6 000

5 000

4 000

3 000

2 000

1 000

0

2025e

NZE

Electric cars remain by far the largest clean energy technology market in 2035 in all scenarios; as such, they are also the main driver of the differences in market value growth across the scenarios. In the STEPS and the CPS, they account for 75-80% of total growth of the value of the market between 2025 and 2035. Zeroemission  trucks  contribute  close  to  10%  of  total  growth  in  both  scenarios, becoming the second-largest clean energy market by the end of the decade, with sales increasing almost sixfold. Batteries for other EVs and for stationary storage also represent close to 5% of the increase in the market size for clean energy technologies in the STEPS.

While installed solar PV capacity more than triples over the period in the STEPS, its  market  size  in  2035  is  about  25%  lower  than  in  2025,  reflecting  declining technology costs. Global installed solar PV capacity also triples in the CPS from 2025 to 2035, yet annual additions in 2035 are about 10% lower than in 2025, and therefore the market for solar PV is about 40% lower in 2035 in the CPS. In both the CPS and STEPS, wind capacity more than doubles over the same timeframe. As a result, its market grows over 2% per year in the STEPS, and by roughly 1.5% in the CPS. The value of the market for heat pumps grows at around 2.5% annually to 2035 in the CPS and 6.5% annually in the STEPS. The growth in the market for electrolysers is higher, but starts from a lower base. Over the next 10 years, the value of the market for electrolysers grows 10% annually in the CPS and slightly faster in the STEPS.

Sales of methanol- and ammonia-fuelled ships in 2035 in the STEPS are 12 times higher than in 2025, with vessel types diversifying beyond chemical tankers and containerships to include cargo ships and bulk carriers. In the CPS, sales in 2035 are  just  10%  lower  than  in  the  STEPS,  marking  an  11-fold  increase  in  sales compared  to  2025.  As  a  result,  the  market  size  for  alternatively  fuelled  ships increases  at  least ninefold by  2035  in  the  two  scenarios,  reaching  over USD 60 billion in the CPS and about USD 70 billion in the STEPS - greater than today's solar PV market.

The value of the global market for clean energy technologies grows two-and-ahalf times more to 2035 in the NZE Scenario compared with the STEPS. As in the STEPS and in the CPS, electric cars and zero-emission trucks remain the two largest markets. The electric car market grows at an average annual rate of around 15% in the NZE Scenario. By 2035, the market reaches nearly USD 4 trillion in the NZE Scenario, more than four times its size in 2025. The market for zeroemission trucks expands even more rapidly, growing nearly 13-fold between 2025 and  2035,  with  an  average  annual  growth  rate  close  to  30%.  Sales  increase slightly faster - by around 15 times - supported by falling production costs and vehicle prices.

Other clean energy technologies also grow more rapidly in the NZE Scenario than in the STEPS and the CPS. In particular, the market size for electrolysers in the NZE Scenario in 2035 is about six times the size of the electrolyser market in the STEPS in that year.

The geographic distribution of clean energy technology deployment to 2035 varies between scenarios. Currently, the market size for clean energy technologies is roughly equal between advanced economies and EMDEs, largely due to China's dominant role  in  EV  sales  and  solar  PV  installations.  In  2025,  China's  market alone, valued at approximately USD 510 billion, is estimated to account for nearly half  of  the  global  clean  energy  technology  market.  In  the  STEPS,  stronger regulations in some of the largest advanced economies drive faster market growth (more  than  10%  per  year  to  2035)  compared  with  EMDEs.  For  example,  the market for clean energy technologies reaches USD 950 billion in Europe in 2035 in the STEPS. In the CPS, the market value for clean energy technologies in 2035 in  advanced  economies  is  30%  lower  than  in  the  STEPS,  and  65%  lower  in emerging economies other than China. For example, the market for clean energy technologies in India grows by 7% from 2025 to 2035 in the CPS, while it grows 18% over the same period in the STEPS. In both the STEPS and CPS, China's market continues to expand at around 5% per year, surpassing USD 800 billion by 2035. In the NZE Scenario, the value of the clean energy technology market grows by over 15% annually in both advanced and emerging economies.

## Box 2.3 China's expanded Renewable Electricity Mandates are driving new markets for clean energy technologies in heavy industries

In July 2025, China's National Development and Reform Commission expanded its Renewable  Electricity  Mandates  to  cover  steel,  cement,  polysilicon  and  certain types of data centres, alongside the aluminium industry, which has been covered since  2024  (Howe,  2025).  The  mandates  stipulate  province-level  shares  of renewable electricity in the total electricity consumption by these sectors, alongside a further stipulation for renewables excluding hydropower generation (i.e. mainly solar PV and wind) (National Development and Reform Commission, 2025).

China's solar and wind electricity generation has grown rapidly, from 10% of final electricity demand in 2020 to nearly 20% in 2024. As China phases out its feed-in tariffs, the Renewable Electricity Mandates reflect a broader shift towards a more market-oriented  support  framework  for  renewables.  To  date,  China's  heavy industries  have  played  a  limited  role  in  driving  renewable  electricity  demand. However, coupled with China's ambitious industrial decarbonisation and electrification  targets,  the  extended  mandates  have  the  potential  to  significantly increase renewable electricity demand across these sectors.

Province-level thresholds for renewables excluding hydropower for 2025 range from 10.7-30%. In 2026, this range is elevated to 12.4-30%. In hydro-rich Sichuan, where the overall share of renewables in electricity generation is already high, the 2026 mandate  will  require  heavy  industry  to  increase  its  non-hydropower  renewables share  from  11.9%  to  13.6%.  Some  provinces  that  have  rapidly  increased  their electricity generation from solar and wind in recent years - including Hebei, Jilin and Liaoning - will see their targets remain largely stable at around 30% through 2026 (Myllyvirta, 2025).

Figure 2.10 Mandated shares of solar and wind generation in Chinese heavy industry, 2025-2026

<!-- image -->

IEA. CC BY 4.0.

Notes: In the left-hand graph, the China average is weighted by consumption. In the right-hand graph, electricity consumption estimates for the steel and aluminium industries exclude any consumption downstream of casting.

In 2024, the aluminium, steel, cement and polysilicon industries together accounted for more than 1 600 TWh of electricity consumption, which is about 15% of China's total. Just the incremental tightening of the Renewable Electricity Mandates in 2026 relative to 2025 would see the weighted national average share for solar PV and wind in heavy industry consumption increase from 24.3% to 26.1%. This increase would  lead  to  an  estimated  22  TWh  of  additional  renewable  electricity  demand nationally  -  more  than  the  total  electricity  demand  of  Croatia.  If  all  of  this  was generated from solar PV, it would require installation of 26 GW, which corresponds to 8% of China's total annual installations in 2024. Wind turbines could be used in combination with - or instead of - solar PV, and demand for electrolysers is likely to be stimulated in instances where electrolytic hydrogen is a useful intermediate (e.g.  chemically  reducing  iron  in  the  steel  industry,  or  for  long-duration  energy storage).

Power  purchase  agreements  and  other  instruments  can  be  used  to  alleviate difficulties with building-out solar PV and wind generation in certain provinces (e.g. densely populated Beijing). At the same time, province-level mandates can help target industrial decarbonisation efforts in coal-rich provinces that account for the majority  of  production  in  these  industries,  which  often  make  extensive  use  of emissions-intensive  captive  coal  power  plants.  Under  the  current  targets,  Inner Mongolia would see the most rapid increase in its mandated renewable electricity consumption, with its target rising by five percentage points (Figure 2.10). Achieving this will require more than 8 TWh of additional renewable electricity by 2026.

The  size  of  the  global  market  for  bulk  materials  produced  using  near-zero emissions technologies grows only modestly in the STEPS and the CPS, reflecting limited announced  projects  and  the  strong  policies  needed  to  drive  rapid deployment of those technologies. It grows far more quickly in the NZE Scenario, reaching USD 500 billion in 2035 (20% of total market for conventional routes), compared with just  USD 20 billion  in  the  STEPS  (1%  of  the  total  market)  and USD 5 billion in the CPS (0.3%).

Steel  contributes  more  than  three-quarters  to  the  total  near-zero  emissions materials market in 2035 in the NZE Scenario, cement 15%, aluminium 5% and ammonia for non-fuel uses 3%, roughly in proportion to their current market sizes. Compared to the overall market for materials, the market opportunity for near-zero emissions materials in the NZE Scenario is slightly skewed towards advanced economies. This reflects the design of the scenario, which assumes a faster pace of  decarbonisation  in  these  regions.  However,  many  EMDEs  have  potential  to produce  near-zero  emissions  materials at lower cost, thanks to low-cost renewable energy resources.

Under  advantageous  circumstances,  projects  producing  near-zero  emissions materials might already be able to compete with conventional alternatives in the near-term (see Chapter 7), although this has not yet been the case. Achieving the market scale of the NZE Scenario would require a far larger number of projects to be launched than have been announced to date. Project deployment at this scale would only  happen  with  strong  policy  support,  in  areas  such  as  internationally interoperable emissions standards, action on demand creation and transparency and certainty on related cost premiums. Availability of low-emissions electricity at low cost, and enabling infrastructure such as low-emissions hydrogen transport and storage, electricity grids and CCUS would also be necessary, requiring multiyear planning and co-ordinated investments.

## Figure 2.11 Global market size of conventional and near-zero emissions bulk materials by scenario, 2025e-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario. Represents the market size for steel, cement, aluminium, and ammonia for non-fuel applications. Assumed materials prices are derived using the evolution of levelised cost of production and demand in each scenario. Near-zero emissions steel includes both iron-based and scrap-based production.

The  near-zero  emissions  materials  market  is  worth  USD 500 billion  in  2035  in  the  NZE Scenario, but to reach this size, far more projects would need to be announced - and soon.

The global market for low-emissions fuels roughly doubles in size by 2035 in both the  STEPS  and  the  CPS,  expanding  from  around  USD 215 billion  in  2025,  to around  USD 390 billion,  or  about  15-20%  the  current  size  of  the  diesel  and gasoline markets in transport.

In the STEPS and CPS, 60% of this growth comes from the continued expansion of  relatively  mature  biofuels  such  as  biomethane,  bioethanol  and  biodiesel  in transport, particularly road. Biodiesel and bioethanol are expected to grow at an average annual rate of 2-3%, while biomethane could grow at an average 7-8%, with  the  three  biofuels  accounting  for  an  80%  share  of  the  low-emission  fuels market in 2035. Another 20% of market growth comes from hydrogen, ammonia and methanol, driven primarily by increasing use of low-emissions hydrogen as a fuel in industry, road transport and shipping. Growth in these sectors reflects early corporate offtake commitments and targeted tax incentives.

The remainder of the increase is driven by sustainable aviation fuels (SAFs), which stand out for their high relative growth, albeit from a small base. In both the STEPS and CPS, SAFs are projected to grow by about 30% per year, boosted by blending mandate requirements, with biokerosene making up two-thirds of the growth. By 2035, SAFs are expected to meet about 4% of total jet fuel demand, while some regions have set substantially higher mandates - such as the European Union's target of 20% by 2035.

In the NZE Scenario, low-emissions fuels play a far greater role, with the market expanding fivefold between 2025 and 2035, approaching half of the current size of diesel and gasoline markets in the transport sector. Emerging low-emissions fuels - hydrogen, ammonia, methanol and SAFs - account for over half of the total low-emissions  market  by  2035,  reflecting  a  structural  shift  away  from  existing biofuels, which are increasingly constrained by sustainable feedstock availability. The low-emissions hydrogen, ammonia and methanol markets grow more than twice as fast as in the STEPS, underpinned by rising demand for low-emissions fuels in industry and shipping.

Achieving this faster scale-up will require significant cost reductions, robust policy support and strong demand signals. SAFs produced using the prevailing route today - hydroprocessed esters and fatty acids (HEFA) - currently cost some two to  three  times  more  than  fossil  jet  fuels,  and  face  limitations  on  sustainable feedstock. Synthetic kerosene, which is still at demonstration phase, can cost over nine times more. While investment in these emerging pathways will be needed to reduce  costs,  including  in  other  biomass-based  SAFs,  the  resulting  impact  on average  flight  ticket  prices  could  be  relatively  limited  (see  Chapter  3).  As  of September 2025, only 15% of hydrogen and hydrogen-based fuel production that could be operational by 2030 had offtake agreements, and just one-quarter of those contracts are on firm, long-term terms.

Regionally,  the  market  for  low-emissions  fuels  is  currently  slightly  larger  in advanced  economies,  which  account  for  about  60%  of  global  demand.  This reflects  early  adoption  of  climate  policies  such  as  blending  mandates.  In  all scenarios,  the  regional  distribution  becomes  more  balanced  over  time,  as emerging economies scale up low-emissions fuels use.

Figure 2.12 Low-emissions fuels market size by fuel, region and scenario, 2015-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: AEs = advanced economies; EMDEs = emerging markets and developing economies. CSAM = Central and South America; CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario. Market size is calculated based on fuel production volumes and prices, allocated to the point of demand. Biogases include biogas and biomethane. Hydrogen refers to low-emissions hydrogen. For hydrogen and hydrogen-based fuel production, fuel production is used as a proxy for price. Market size excludes the use of hydrogen, hydrogen-based fuels, and biofuels as fuel or feedstock in industry. The market for low-emissions hydrogen and hydrogen-based fuels, as well as low-emissions hydrogen, ammonia and methanol used as feedstocks in industry and biorefineries, is around USD 55 billion in 2035 in the STEPS, USD 45 billion in the CPS, and USD 550 billion in the NZE Scenario.

The  market  for  low-emissions  fuels  doubles  and  diversifies  by  2035  in  the  STEPS,  with hydrogen-based fuels and biokerosene making up almost 20% of the value of the market.

## Investment needs

Developing and maintaining markets for clean energy technologies, materials and fuels requires investments in production assets and infrastructure. For example, a growing market for electric cars triggers investment in new or retooled assembly plants,  EV  charging  infrastructure,  and  eventually  electricity  grid  upgrades  or expansions to power the growing stock. In particular, investment in electric grids can  help  avoid  delays  in  grid  reinforcement  and  interconnection,  which  could otherwise limit the speed at which new electricity-related clean energy technology projects can be deployed and connected to the grid, notably for solar, wind and battery storage.

Investment  in production assets  for clean energy  technologies,  near-zero emissions materials and low-emissions fuels is estimated to have reached around USD 245 billion in 2025, about three times the investment 5 years earlier. To put this in perspective, global investment in low-emissions fuels production facilities alone  in  2025  is  estimated  to  be  the  same  as  that  expected  in  oil  refineries (USD 30 billion) (IEA, 2025a).

Investment  in  enabling  infrastructure,  primarily  electricity  grids,  is  estimated  to have approached around USD 430 billion in 2025, about 40% more than in 2020. The level of investment in production assets and enabling infrastructure combined in 2025 is estimated to be around half of the size of the market for these clean energy technologies, near-zero emissions materials and low-emissions fuels.

Figure 2.13 Average annual investments in production assets and enabling infrastructure by technology category in the Stated Policies Scenario and Net Zero Emissions by 2050 Scenario, 2020-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario; EV = electric vehicle. Investments in  production  assets  refers  to  manufacturing  or  production  equipment.  Clean  energy  technologies  include  battery  cells, anodes and cathodes; electric cars; solar PV modules, cells, polysilicon and wafers; wind towers, blades and nacelles; heat pumps; and electrolysers. Alternative fuels include advanced biofuels, low-emissions hydrogen and hydrogen-based fuels.

Investment in production assets for clean energy technologies and low-emissions fuels falls to 2035 in the STEPS, but grows for near-zero emission s materials and enabling infrastructure.

Average annual investment in production assets for clean energy technologies, materials and fuels combined falls by 60% in the STEPS from 2031-35, compared to  2025  levels.  This  is  mainly  driven  by  a  drop  in  investment  needed  for manufacturing capacity for clean energy technologies to cope with demand, given the big expansion observed in recent years. For example, manufacturing capacity for battery cells expanded more than fivefold from 2020 to 2025. In the STEPS, however,  battery  manufacturing  capacity  only  doubles  to  2035.  For  solar  PV module manufacturing, capacity has increased more than fourfold over the last 5 years, yet it increases only 5%  over  the next decade  in the STEPS (see Chapter 5 for more details).

In  the  CPS,  investments  to  enable  markets  for  clean  energy  technologies, materials and fuels are lower than in the STEPS, but are still needed to bring both production capacity and enabling infrastructure above 2025 levels. The annual investments in the production of near-zero emissions materials are about 60%

lower  on  average  from  2031-35  than  in  the  STEPS.  By  contrast,  annual investments in alternative fuel production assets in the CPS are only around 15% lower than in the STEPS on average over the same period. In the NZE Scenario, average investment in clean energy technology production assets between 20312035  is  similar  to  2025  levels,  though  investments  for  near-zero  emissions materials  are  more  than  15  times  2025  levels,  and  those  for  alternative,  lowemissions fuels production assets are five times 2025 levels.

Average annual investment in electricity grids between 2031-35 in the STEPS is about 60% higher than in 2025. Investment in public EV charging infrastructure increases  by  a  greater  percentage  (80%)  but  reaches  just  USD 20 billion  in average annual investment from 2031-35, compared to around USD 660 billion for electricity grids. In the CPS, the average annual investment from 2031-35 for electricity  grids  is  only  2%  lower  than  in  the  STEPS;  for  EV  chargers,  the investment level is about one-third of that in the STEPS. Investment in electricity grids  and  EV  charging  infrastructure  during  this  timeframe  are  much  higher (25-100%)  in  the  NZE  Scenario.  The  NZE  Scenario  also  sees  higher  annual investments in carbon removal plants (USD 55 billion), CO2 transport and storage infrastructure (USD 30 billion), and hydrogen infrastructure (USD 35 billion) from 2031-35.

## Drivers of deployment

The  adoption  of  new  technologies  and  fuels  in  the  energy  sector  is  driven  by multiple factors including cost-competitiveness, direct or indirect policy support, affordability,  energy  and  environmental  performance  and  consumer  appeal, among others. However, technologies vary widely in terms of their target users, which affects both the expected value of the service provided to the consumer and how production costs are ultimately passed on to end-users.

Some clean energy technologies, such as EVs and heat pumps, are consumer goods and compete directly with conventional alternatives, such as oil-fuelled cars and gas-fired boilers. Others, like solar PV plants, heavy-duty trucks, near-zero emissions materials manufacturing, or low-emissions ships, are typically deployed by businesses or public entities to support the delivery of other goods or services. These distinctions influence how sensitive adoption is to cost, which economic or financial indicators - e.g. upfront equipment or installation costs, running costs, total cost of ownership (TCO) - matter most in decision-making, and which policy instruments are likely to be most effective in supporting deployment.

## Cost-competitiveness

Utility-scale solar PV and wind are among today's most cost-competitive clean energy  technologies.  Since  2010,  the  levelised  cost  of  electricity  (LCOE)  has declined by 90% for solar PV and 70% for wind generation. In 2024, approximately 80% of all wind and solar electricity generation took place in countries where these

technologies offered a lower LCOE than coal- or gas-fired plants. Climate and energy  security  policies  have  played  a  critical  role  in  helping  solar  and  wind compete with fossil  fuels  in  those  countries.  China,  in  particular,  has  provided extensive support for both large-scale and distributed solar and wind systems. Combined with its ability to manufacture components cheaply, this has enabled renewable generation  costs  that  are  competitive  with  coal.  In  the  wind  sector, ongoing reforms in auction design (e.g. through two-sided contracts for difference and the inclusion of qualitative criteria), permitting processes, and grid access notably in Europe, India and several emerging and developing economies - are improving the bankability of new projects. This is helping the industry bounce back from recent supply chain disruptions and macroeconomic headwinds.

Costs are projected to decline further through to 2035 - by about 40% for solar PV, and about 10% for onshore wind. In the STEPS, projected LCOEs show that new  solar  PV  and  onshore  and  offshore  wind  have  similar  or  lower  average generation costs than new  coal, gas and nuclear in the United States, European Union and China. Even when accounting for technology dispatchability, analysis shows that the value-adjusted levelised cost of electricity (VALCOE)  of 5 a solar or wind plant operating at a 95% capacity factor could be comparable to dispatchable sources in major markets in 2035 (IEA, 2025g).

The economics of mass market technologies, such as EVs and heat pumps, are also improving in some markets. In China, battery manufacturing cost reductions, a high degree of vertical integration in supply chains, and intense competition have driven down electric car prices to match - or even undercut - those of conventional cars in most market segments. In 2024, two-thirds of electric cars sold in China were  priced  lower  than  their  internal  combustion  engine  (ICE)  counterparts, compared to half in 2021. These cost advantages have had global ripple effects, with the affordability of Chinese EVs contributing to their rising adoption in other regions. In 2024, the share of electric cars in total car sales in other emerging markets  and  developing  economies  in  Asia,  Latin  America  and  Africa  nearly doubled, reaching 4%, largely due to the availability of competitively priced imports from China. However, this trajectory could shift amid uncertainty over future import tariff policies.

In the world's second and third leading electric car markets - the European Union and United States - progress on making EVs more affordable is, however, lagging behind  China.  In  Germany,  for  example,  the  average  price  premium  for  small battery  electric  cars  remained  almost  unchanged  between  2021  and  2023, reaching just over 40% higher than equivalent small ICE models in 2024. In the

5 The VALCOE, developed for the IEA Global Energy and Climate Model, accounts for a technology's intermittency, its contribution to a system's adequacy and stability, and its ability to provide flexibility.

United States,  the  price  premium  has  fluctuated,  reaching  just  over  40%  for medium battery EVs in the same year, and just over 25% for electric SUVs.

Figure 2.14 Evolution of cost-competitiveness for electric cars and heat pumps, 20212024

<!-- image -->

IEA. CC BY 4.0.

Notes: ICE = internal combustion engine; BEV = battery electric vehicle; PHEV = plug-in hybrid electric vehicle. Electric car price premium is calculated for sport utility vehicles (SUVs) relative to ICE equivalents. Operational cost premium is calculated based on annual spending on heat pump operation relative to gas-fired boilers.

The competitiveness of mass market technologies such as electric cars and heat pumps is improving in some markets, although barriers to adoption remain.

In an increasing number of countries, space-heating heat pumps are becoming the most economical choice compared with fossil fuel-based systems, especially when  accounting  for  their  higher  energy  efficiency  and  ability  to  provide  both heating  and  cooling.  In  regions  with  milder  winters  and  a  strong  demand  for cooling, such as the southern United States, southern Europe, central China, and Japan, air-to-air heat pumps offer a clear economic advantage, thanks to their dual (heating and cooling) functionality and lower operating costs. In colder regions like central and northern Europe, Canada, and the northern United States, the costcompetitiveness  of  heat  pumps  is  more  dependent  on  the  relative  prices  of electricity and natural gas, highlighting the need for balanced energy pricing and targeted  policy  support  to  level  the  playing  field.  In  some  northern  European countries, annual operating costs are lower than for gas-fired boilers due to longstanding cheap electricity prices relative to natural gas and have been steadily decreasing  in  the  past  10  years  thanks  to  efficiency  improvements.  This  has boosted heat pump adoption, especially when accompanied by long-term policies that  removed  much  of  the  uncertainty  for  households  and  installers.  However, higher upfront costs relative to gas-fired boilers may still prove to be a barrier to adoption in many regions without a similar level of long-term confidence.

The situation is quite different for industrial heat pumps, a market still in its early stages but with significant untapped potential. Today, electricity supplies less than

5% of total industrial heat demand globally. Installed industrial heat pump capacity is expected to grow in the coming years, making up 2% of industrial heat in light industries in 2035 in the STEPS. However, higher electricity to gas price ratios could increase the cost premium, pointing to the need for policy to support cost reductions.

## Figure 2.15 Relative cost and market share for selected clean energy technologies and low-emissions products by market in the Stated Policies Scenario, 2024-2035

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

Notes: SAFs = synthetic sustainable aviation fuels based on electrolytic hydrogen; VALCOE = value-adjusted levelised cost of electricity; TCO = total cost of ownership; Near-zero emissions cement: production weighted average cost of production of low-emissions pathways indexed on unabated cement production.

While clean energy technologies are becoming increasingly affordable, in many instances policies are required to address cost and non-cost barriers.

Electric trucks have also become more affordable, thanks to falling battery prices and improvements in energy density, particularly in China, where the price gap between diesel and electricity (on an energy-equivalent basis) is relatively wide. In certain applications in China, battery electric trucks already offer a lower TCO due to the higher energy efficiency of electric  powertrains  compared with  ICE. While  TCO  remains  higher  than  for  fossil-fuelled  alternatives  in  many  other regions,  cost  parity  is  expected  to  be  reached  across  a  growing  number  of applications over this decade.

By contrast, emerging  low-emissions fuels still face a considerable cost disadvantage compared with unabated fossil-based alternatives, which continues to  be  a  barrier  to  widespread  adoption.  Electrolytic  hydrogen,  for  instance,  is currently 1.2 to 7.5 times more expensive to produce than fossil-derived hydrogen even in locations with low-cost renewables. Similarly, SAFs remain uncompetitive because of high production costs (see above) and limited feedstock availability. Methanol- and ammonia-powered ships cost about twice as much to own and operate as conventional vessels, though this gap should narrow as fuel production expands and ships become more efficient.

Near-zero  emissions  materials  also  continue  to  struggle  to compete  with conventional alternatives (see Chapter 7). Although the materials themselves are often  identical  in  quality,  the  deployment  of  near-zero  emissions  production technologies depends heavily on cost-competitiveness, as well as the willingness of buyers to pay a price premium and policy drivers such as public procurement of near-zero and low-emissions materials.

Nevertheless, a subset of buyers are willing to pay a price premium for near-zero emissions materials and fuels. For instance, a recent survey of buyers indicated that around half of respondents might accept a 25% price premium for near-zero emissions steel and concrete (Climate Group, 2024) (IEA, 2025b). However, most near-zero  emissions  production  cannot  currently  meet  that  price  point  without substantial subsidies. For instance, in the STEPS, the cost of producing near-zero emissions  hydrogen-based  steel  is  estimated  to  remain  20-145%  higher  than conventional steel even by 2035, in the absence of policy support. This translates to an additional cost of USD 125-600 per tonne of crude steel in this scenario, depending on the region. As the price premium increases, the share of willing buyers declines significantly, limiting the size of the market and slowing broader commercial adoption.

Low-emissions fuels and materials are typically inputs further up in the value chain than many clean technologies destined for mass market consumers. This creates an opportunity for their cost premiums (including profit margins) to be absorbed along  the  supply  chain,  resulting  in  only  modest  price  increases  for  end consumers. For example:

- · Low-emissions  fuels:  switching  to  fertilisers  based  on  low-emissions hydrogen in wheat production would lead to only a minimal impact on final retail prices. Similarly, the use of SAFs would have a relatively small impact on airfares: in Europe, for instance, under the European Union's 20% SAF blending  mandate  by  2035,  average  ticket  prices  would  rise  by  around 10%, since fuel accounts for around 30% of airline costs on average. In shipping, fuel costs represent only a small share of overall freight rates, with the latter typically being a minor component of final consumer prices. Nonetheless, even marginal increases can be significant, given the strong competition in the shipping industry.
- · Materials: use of near-zero emissions materials would lead to only a minor impact  on  final  price  in  a  variety  of  key  applications.  In  the  automotive sector, full substitution of conventional steel with near-zero emissions steel would increase car prices by just 1-2%. In the construction sector, the price of a typical house would rise by a similar amount - roughly 1-3% - if nearzero  emissions  steel  and  cement  were  to  be  used.  In  both  examples, partial substitution of these materials in the final product would have an even smaller impact on the price.

Nevertheless, the current production cost premiums for low-emissions fuels and materials remain a major barrier for project developers. Without stronger policy intervention, these premiums are unlikely to fall significantly.

## Policy drivers

Policy support remains essential to the cost-competitiveness and market potential of  new  energy  technologies  and  fuels.  This  is  especially  true  for  those  that continue to face significant cost gaps compared with conventional alternatives or are  hampered  by  non-cost  barriers  such  as  social  acceptability  or  regulatory hurdles.

In  transport,  targeted  measures  such  as  purchase  subsidies,  tax  credits,  fuel economy standards and EV mandates have significantly boosted EV adoption, even  in  regions  where  affordability  of  EVs  remains  a  challenge.  For  example, despite electric cars being on average 20-25% more expensive (from a purchase price) than their ICE equivalents in the European Union and North America, EV market shares in those regions  rose from  under  1%  in  2015 to  12%  and  8%, respectively,  in  2024.  This  trend  has  been  reinforced  by  large-scale  legislative packages, like the EU Fit for 55 package, which combine consumer incentives with industrial policy to strengthen domestic supply chains (see Chapter 7).

Similar dynamics are visible in the buildings sector. Heat pump deployment has increased in all major heating markets, supported by building codes requiring or encouraging their installation in new buildings, subsidy schemes, and other policy

measures that steadily raise the bar for heating systems. Over the last decade, sales have increased 80% globally (in capacity terms), with stronger growth in Europe and the United States. Recent efforts such as the REPowerEU plan in the European Union  and  US  state-level  electrification  mandates  have  helped  to accelerate heat pumps adoption. Meanwhile, countries including Japan and Korea are  expanding  subsidy  programmes  to  overcome  upfront  costs.  Despite  these advances,  heat  pumps  still  only  cover  about  15%  of  global  heating  needs  in buildings.

Policy remains particularly critical for earlier-stage technologies that struggle to scale. Low-emissions fuels and materials, and alternative propulsion vessels, for example, require robust demand-side incentives to complement supply-focused policies (see Box 2.4). For example, international frameworks like the International Civil  Aviation  Organization  scheme  have  so  far  had  limited  impact  in  driving adoption of SAFs, prompting several governments to introduce national blending mandates (e.g. in the European Union (European Commission, 2025), United Kingdom (UK Department for Transport, 2025), Brazil (Argus, 2025), and Japan (Argus, 2024)).

## Box 2.4 Designing  an  effective  policy  framework  for  near-zero  emissions materials

A  strong  and  well-designed  policy  framework  can  transform  a  difficult  market environment for near-zero emissions materials into a viable commercial opportunity. Governments  have  a  wide  range  of  policy  tools  at  their  disposal  to  support  the development and scale-up of markets. For a detailed overview of policies for materials, see the IEA's Demand and Supply Measures for the Steel and Cement Transition (IEA, 2025b) paper and the Policy Toolbox for Industrial Decarbonisation (IEA, 2025c). Key policy levers include:

-  Bridging the price gap for  near-zero  emissions  products through supply-side support to make early-stage investments financially viable.
-  Stimulating demand by helping to secure buyers or creating markets for nearzero emissions products, even when they come at a premium, both through public procurement and other instruments that create private sector demand.
-  Shifting the competitive landscape through broader market signals - such as carbon pricing or regulatory standards - that reward lower-emission production pathways.
-  Establishing enabling conditions , including clear definitions, certifications, and standards, to underpin market confidence and support other policy measures.

-  Co-ordination of enabling infrastructure that near-zero emissions technologies depend on - namely, low-emissions hydrogen, low-emissions electricity, biofuels and CCUS - to avoid delays in deployment.

There  is  no  single  'correct'  policy  formula;  what  matters  most  is  that  policies  are sufficiently strong to make a tangible impact. Governments can and should tailor their policy mix to reflect domestic circumstances, market maturity and industrial structure. In many cases, a comprehensive framework combining supply-side support, demand stimulation and enabling measures will be most effective. However, one well-designed and robust policy can sometimes outperform several weaker ones, especially when administrative simplicity and regulatory clarity are critical to success.

At the same time, technologies that are already cost-competitive with fossil-based alternatives continue to face systemic barriers that hinder their market penetration. For  example,  solar  PV  is,  on  average,  cheaper  than  fossil  generation  in  the European Union  and  the  United States,  but  remains  constrained  by  permitting hurdles, grid bottlenecks and public acceptance, making up 11% and 6% of the regions' electricity mixes in 2024, respectively. The same is true to a lesser extent for  onshore  wind,  with  generation  reaching  15%  and  10%  the  same  year, respectively. In China, the adoption of medium- and heavy-duty electric trucks is similarly  limited  -  not  by  cost,  but  by  infrastructure  readiness.  While  charging networks for passenger EVs and electric buses are well established, public and depot charging stations, especially for long-haul freight, are still in the process of being scaled up.

Regulatory reforms to address legal or regulatory barriers in some sectors are also increasingly being put in place. For example, the use of low-emissions ammonia in ship engines is currently prohibited in many jurisdictions, requiring changes in safety regimes before deployment can begin at scale. The recent introduction of pilot  safety  frameworks  for  ammonia  vessels  illustrates  how  governments  are beginning  to  adapt  legal  systems  to  enable  their  wider  deployment.  Similarly, current building codes can include prescriptive rules on cement composition and building  design,  in  some  cases  precluding  the  use  of  lower-emissions  clinker substitutes or innovative building designs that could reduce the use of emissionsintensive clinker. Revision of these building codes could facilitate greater uptake of near-zero and low-emissions cement. The European Union's revised Construction Products Regulation is an example of supportive regulatory reform.

## Innovation

Innovation is central to improving competitiveness across the board and boosting technology  adoption  by  lifting  technical  barriers  to  adoption  and  bringing  new

solutions to market. It can also contribute to improving the operational performance of existing technologies, alleviating non-cost factors, and facilitating the recuperation of valuable materials. Innovation in manufacturing techniques is a crucial strategy for countries aiming to become or to remain major players in an increasingly competitive global clean technology  market  (see  Chapter  7). Governments have a critical role to play in supporting energy innovation, a sector marked by high barriers to entry such as capital intensity, long lead times, safety standards, and the need for extensive physical infrastructure (IEA, 2025d).

Recent years have seen strong momentum in bringing entirely new solutions to market.  The  development  of  alternative  energy  conversion  methods  (such  as thermochemical,  biological,  or  electrochemical  processes),  the  design  of  new equipment  and  systems  to  accommodate  alternative  fuels  or  low-emissions production pathways, and the use of emerging materials like nanomaterials or solid-state  electrolytes  has  allowed  for  the  achievement  of  performance  levels beyond those possible with conventional technologies. In shipping, ammonia as a marine fuel  shows  strong  potential  to  support  deep  decarbonisation  due  to  its scalability  and  competitive  TCO  compared  with  other  low-emissions  options. However, engines capable of running on low-emissions ammonia are still at the prototype stage, with commercial deployment expected in the coming years. In a milestone  for  the  sector,  in  2024,  a  ship  belonging  to  Australian  mining  firm Fortescue became the first to use ammonia for marine propulsion at the Port of Singapore.  It  had  been  retrofitted  with  two  dual-fuel  engines  to  run  on  both ammonia and diesel (Maritime and Port Authority of Singapore, 2024). Engine manufacturers such as Everllence (formerly MAN), Wärtsilä, J-Eng, WinGD, and Hyundai have also begun offering ammonia-capable engines, contributing to a noticeable increase in ammonia-fuelled vessels on shipyard order books.

Another area in which innovation has played a significant role in bringing new technologies to market is carbon dioxide removal (CDR), a sector that is important to meeting net zero goals, particularly in direct air capture (DAC) (IEA, 2025d). Currently, DAC faces high energy requirements and steep first-of-a-kind costs, estimated  at  between  USD 500  and  USD 1 900  per  tonne  of  CO   captured. ₂ Around USD 1 billion of RD&amp;D funding has been made available to fund DAC first-ofakind  and  pilot  projects,  in the  hope  that  advanced  capture  materials and improvements in process efficiency, along with economies of scale, could bring these costs down to around USD 300/t CO  by mid-century. ₂

In parallel, innovation continues to play an important part in enabling performance gains in existing clean energy technologies. Lithium-ion batteries have doubled in average  energy  density  since  2010,  enabling  lighter  battery  packs  and  longer ranges  for  EVs,  while  more  affordable  chemistries  -  such  as  lithium  iron phosphate (LFP) and sodium-ion - are broadening market options. Heat pumps have  achieved  significant improvements  in  seasonal  performance  factors,

expanding  their  competitiveness  in  colder  climates,  while  record  solar  cell efficiencies have been demonstrated through tandem perovskite-silicon designs, now being piloted at industrial scale in China and Europe.

Figure 2.16 Evolution of technology readiness levels, 2021-2025, and performance for selected clean energy technologies, 2010-2024

<!-- image -->

IEA. CC BY 4.0.

Notes: COP = coefficient of performance. Technology performance is based on sales-weighted average. Sources: IEA (2025e) and IEA (2023).

Continued innovation is bringing emerging clean energy technologies closer to market and improving their performance, helping to support market uptake.

System  integration  is  another  frontier  that  innovation  efforts  are  tackling.  This includes  grid-responsive  solutions  such  as  virtual  power  plants  (a  network  of decentralised, medium-scale power generating units combined with flexible power options for consumers and storage systems) and vehicle-to-grid interfaces, as well as  digital  tools  that  co-ordinate  decentralised  assets  and  manage  variability. Infrastructure upgrades like hydrogen-ready pipelines and fast-charging networks for  EVs  also  enable  the  broader  deployment  of  clean  technologies  such  as variable renewables. The rollout of smart grids, first commercialised in the late 2000s, has played a central role in managing variable renewable energy inputs. These  technologies  are  becoming  increasingly  important  as  the  share  of renewable electricity  in  total  generation  grows  and  as  more  end-uses  become electrified. Efficient EV charging is another key enabler of adoption. For example, cars  equipped  with  bidirectional  chargers,  first  brought  to  market  in  the  early 2020s, now account for more than one in eight new electric cars sold, offering both greater grid flexibility and enhanced user value (IEA, 2025f).

Finally, materials innovation is increasingly focused on sustainability and recyclability.  As  demand  for  critical  minerals  and  materials  grows  alongside accelerating clean energy technology deployment, innovation could also play a

central  role  in  enabling  the  recovery  of  valuable  resources  from  end-of-life equipment and industrial  waste.  This  includes  more  efficient  material  recovery methods,  such  as  hydrometallurgy  or  electrochemical  separation,  AI-powered sorting systems for complex waste streams like electronic waste and composites, and product designs that incorporate disassembly and recycling considerations from  the  outset  (closed-loop  approaches).  For  example,  improved  recycling processes for lithium and nickel could reduce global demand by around 25% by 2025 and, similarly, could reduce demand for cobalt by 40% by the same year (IEA, 2024b). However, significant technological advances are needed across all stages  of  the  recycling  chain  for  recycled  materials  to  compete  with  mined equivalents and to comply with emerging regulatory frameworks. Based on current trends,  recycled  lithium  and  nickel  are  projected  to  meet  only  around  5%  of demand by 2035, with the primary constraint being that the increase in demand far outpaces the number of batteries reaching end-of-life (see Recycling section in Chapter 3).

## References

| Argus. (2024). Japan aims to tighten SAF supply regulations . Retrieved from https://www.argusmedia.com/en/news-and-insights/latest-market-news/2582074-japan- aims-to-tighten-saf-supply-regulations                                                                 |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Argus. (2025). Brazil SAF industry set to take off in 2027 . Retrieved from https://www.argusmedia.com/en/news-and-insights/latest-market-news/2674362-brazil- saf-industry-set-to-take-off-in-2027                                                                   |
| BNEF. (2025). Data service . Retrieved from https://about.bnef.com/ Climate Group. (2024). Report: Nearly half of global companies are ready to pay a for lower emission steel and concrete . Retrieved from                                                          |
| premium https://www.theclimategroup.org/our-work/news/report-nearly-half-global-companies- are-ready-pay-premium-lower-emission-steel-and                                                                                                                             |
| European Commission. (2025). ReFuelEU Aviation . Retrieved from https://transport.ec.europa.eu/transport-modes/air/environment/refueleu-aviation_en                                                                                                                   |
| Howe, C. (2025). China sets its first renewable standards for steel, cement and polysilicon. Reuters . Retrieved from https://www.reuters.com/sustainability/boards-policy- regulation/china-sets-its-first-renewable-standards-steel-cement-polysilicon-2025-07- 11/ |
| IEA. (2022). Achieving Net Zero Heavy Industry Sectors in G7 Members. Retrieved from https://www.iea.org/reports/achieving-net-zero-heavy-industry-sectors-in-g7-members                                                                                              |
| IEA. (2023). Net Zero Roadmap: A Global Pathway to Keep the 1.5 °C Goal in Reach . Retrieved from https://www.iea.org/reports/net-zero-roadmap-a-global-pathway-to- keep-the-15-c-goal-in-reach                                                                       |
| IEA. (2024a). Definitions for Near-Zero and Low-Emissions Steel and Cement, and Underlying Emissions Measurement Methodologies . Retrieved from https://www.iea.org/reports/definitions-for-near-zero-and-low-emissions-steel-and-                                    |
| cement-and-underlying-emissions-measurement-methodologies IEA. (2024b). Recycling of Critical Minerals . Retrieved from https://www.iea.org/reports/recycling-of-critical-minerals                                                                                    |
| IEA. (2025a). World Energy Investment 2025. Retrieved from https://www.iea.org/reports/world-energy-investment-2025                                                                                                                                                   |
| IEA. (2025b). Demand and Supply Measures for the Steel and Cement Transition . Retrieved from https://www.iea.org/reports/demand-and-supply-measures-for-the-steel-and- cement-transition                                                                             |
| IEA. (2025c). Policy Toolbox for Industrial Decarbonisation . Retrieved from                                                                                                                                                                                          |
| https://www.iea.org/reports/policy-toolbox-for-industrial-decarbonisation                                                                                                                                                                                             |
| (2025e). ETP Clean Energy Technology Guide . Retrieved from https://www.iea.org/data- and-statistics/data-tools/etp-clean-energy-technology-guide                                                                                                                     |
| IEA.                                                                                                                                                                                                                                                                  |
| IEA. (2025f). Global EV Outlook 2025 . Retrieved from https://www.iea.org/reports/global-ev- outlook-2025                                                                                                                                                             |

IEA. (2025g). World Energy Outlook 2025 . Retrieved from https://www.iea.org/reports/worldenergy-outlook-2025

InfoLink. (2025). InfoLink Consulting . Retrieved from https://www.infolink-group.com/

- Johnson, S. a. (2025). Green steel firm Stegra secures half of $1.1bn funding. BusinessDay . Retrieved from https://www.businessday.co.za/world/2025-11-06-green-steel-firmstegra-secures-half-of-11bn-funding/

Maritime and Port Authority of Singapore. (2024). World's First Use of Ammonia as a Marine Fuel in a Dual-Fuelled Ammonia-Powered Vessel in the Port of Singapore . Retrieved from https://www.mpa.gov.sg/media-centre/details/world-s-first-use-of-ammonia-as-amarine-fuel-in-a-dual-fuelled-ammonia-powered-vessel-in-the-port-of-singapore

Myllyvirta, L. (2025). China's north cleans up its power mix as the south lags. Retrieved from CREA: https://energyandcleanair.org/chinas-north-cleans-up-its-power-mix-as-thesouth-lags/

National Development and Reform Commission. (2025). Notice on Renewable Energy Power Consumption Responsibility Weights and Related Matters in 2025 (NDRC Energy Office [2025] No. 669). Retrieved from NDRC:

- https://www.ndrc.gov.cn/xxgk/zcfb/tz/202507/t20250711\_1399141.html
- RMI. (2024). Amazon and Johnson Controls Join Major Corporations in Launching Tender to Accelerate Deployment of Near-Zero Emissions Steel . Retrieved from https://rmi.org/press-release/amazon-and-johnson-controls-join-major-corporations-inlaunching-tender-to-accelerate-deployment-of-near-zero-emissions-steel/
- S&amp;P Global Mobility. (2025). Global New Vehicle Registrations . Retrieved from https://www.marketplace.spglobal.com/en/datasets/global-new-vehicle-registrations(248)
- SSAB. (2025). SSAB Capital Markets Day 2025 - Accelerating premium leadership . Retrieved from https://www.ssab.com/en/news/2025/11/ssab-capital-markets-day-2025-accelerating-premium-leadership
- UK Department for Transport. (2025). Sustainable Aviation Fuel (SAF) Mandate . Retrieved from https://www.gov.uk/government/collections/sustainable-aviation-fuel-saf-mandate

## Chapter 3. T echnology deployment dashboards

## Highlights

-  Clean energy technology deployment advances in all IEA scenarios. How fast it will advance is linked to the capacity of individual technologies and technology groups to support the achievement of multiple policy objectives, the extent to which they benefit from effective policy support, and their relative abilities to reach technology maturity and cost-competitiveness.
-  For example, clean energy technologies that underpin the age of electricity, like batteries or solar PV, are increasingly cost-competitive and expanding rapidly, supported by their modularity and mass manufacturing. While there is evidence of progress for energy technologies still under development or entering markets, it has been less steady. This is the case for low-emissions hydrogen production; carbon capture, utilisation and storage (CCUS); and near-zero emissions material production, all of which tend to involve large-scale engineering projects and rely on policy support to scale up and lower costs. Other technologies at earlier stages of development, such as nuclear fusion, solid-state cooling, iron ore electrolysis or conventional cement made without limestone could be transformative, but their viability remains unproven.
-  This chapter analyses trends on deployment, cost-competitiveness and enabling factors for clean energy technologies across different sectors, including technologies that both produce and consume energy directly, as well as those used to produce low-emissions fuels and materials:
-  Transport: electric cars, zero-emissions  trucks  and  ships  powered  by ammonia or methanol.
-  Buildings: heat pumps for space heating, air conditioning systems and zerocarbon ready building envelopes.
-  Industry: industrial heat pumps, near-zero emissions steel and cement, and recycling technologies.
-  Power generation: solar PV, wind power, nuclear, geothermal and stationary energy storage.
-  Other energy  transformation: production of low-emissions hydrogen, ammonia and methanol, and sustainable aviation fuels.
-  Carbon dioxide removal: bioenergy  with  carbon  capture  and  storage  and direct air capture.

<!-- image -->

## Energy Technology Perspectives 2026

<!-- image -->

<!-- image -->

PAGE | 124

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

## Electric cars

## Lower electric car prices mean less policy support is needed

Global sales of electric cars have grown every year over the past decade, largely driven  by  supportive  policies  such  as  financial  incentives  and  fuel  economy standards. In 2024, global sales of electric cars rose by more than 25% and they are  estimated  to  have  risen  by  around  20%  in  2025.  Battery  technology improvements, notably higher energy density, better manufacturing efficiency and a shift  toward  chemistries with lower critical mineral content, have also helped reduce production costs, increased driving range and made electric cars more attractive  to  consumers.  The  average  range  of  new  battery  electric  cars  has increased by more than 75% since 2015.

Government subsidies have recently been scaled back in several countries due to budget constraints. For instance, in Germany, where battery electric cars are still around 20% more expensive on average than internal combustion engine (ICE) cars, sales declined by more than one-quarter in 2024 when subsidies were no longer  available.  In  some  cases,  subsidies  were  phased  out  because  of  the increasing  affordability  of  electric  cars.  In  the  People's  Republic  of  China (hereafter, 'China'), the phase-out of national purchase subsidies at the end of 2022 had little impact on sales in 2023, partly because more than 60% of electric cars  sold  in  China  that  year  were  cost-competitive  with  equivalently  sized  ICE cars.

Imports  of  affordable  Chinese-made  electric  cars  have  boosted  sales  in  some emerging markets, including Brazil, Indonesia, Mexico and Thailand. In Brazil, for example, the price gap between battery electric and ICE cars dropped from over 100% in 2023 to just 25% in 2024, as the share of Chinese imports in electric car sales rose from 60% in 2023 to more than 80% in 2024. Despite continued growth in sales, total government spending on electric cars worldwide accounted for only around 7% of total electric vehicle (EV)-related spending in 2024, down from 20% in 2017.

Industry plans, such as announcements of more affordable models, combined with continued  battery  cost  declines  and  policy  support  in  many  countries,  point  to growing electric car sales in the coming years, which is reflected in IEA scenarios.

## Priority policy actions

-  Adapt support for electric cars as prices become more competitive.
-  Expand  publicly  accessible  EV  charging  infrastructure  and  support  the installation of home chargers.
-  Ensure secure, resilient and sustainable EV supply chains.

<!-- image -->

## Chapter 3. Technology deployment dashboards

<!-- image -->

PAGE | 126

<!-- image -->

<!-- image -->

## Zero-emissions trucks

## Cheaper batteries have reduced electric truck ownership costs

Interest  in  zero-emission  trucks,  including  battery  electric  and  fuel  cell  electric trucks,  has  been  rising  in  recent  years,  though  deployment  remains  limited.  In 2024,  battery  electric  truck  sales  surpassed  90 000  units  globally,  with  over 4 000 fuel  cell  electric  trucks  also  being  sold.  Government-funded  pilot  and demonstration projects have shown that zero-emissions trucks can fulfil driving requirements for logistics operations, but their uptake is being driven primarily by emissions  regulations.  Declining  battery  prices  and  improvements  in  energy density have made electric trucks more cost-competitive.

China currently accounts for around 80% of global zero-emissions truck sales. Domestic efforts to cut emissions from heavy industry have spurred investment in heavy-duty  electric  trucks,  and  battery  swapping,  which  allows  for  quicker turnaround  times,  has  also  boosted  adoption,  with  around  one-third  of  electric trucks sold in the country in 2024 being battery swap capable. In China, a relatively wide gap between diesel and electricity prices (per unit of energy), combined with the  higher  energy  efficiency  of  electric  powertrains  compared  with  internal combustion engines, means that battery electric trucks already offer a lower total cost  of  ownership  (TCO)  for  some  applications.  TCO  parity  is  expected  to  be achieved in more regions and applications later this decade.

The deployment of high-power chargers for heavy-duty vehicles has so far been limited, including in China. While several major markets have installed thousands of charging points in the 300-350 kW range, the world's first megawatt-scale (MW) chargers for trucks were only deployed in 2024, in the United States and Europe. In addition,  although  some  governments  have  been  investing  in  hydrogen refuelling infrastructure for over a decade, most existing stations were designed for cars and buses. As a result, many may not be suitable for refuelling fuel cell trucks, either due to insufficient hydrogen dispensing pressure or physical space constraints. However, in recent years, stations designed to serve trucks have been built in regions such as Europe and the United States.

In 2035, zero-emission truck sales reach over 20% of total global truck sales in the STEPS, around 15% in the CPS, and close to 60% in the NZE Scenario.

## Priority policy actions

-  Implement targeted fiscal policies and innovative financing models.
-  Leverage national and regional air quality regulations.
-  Support co-ordinated public-private deployment of high-power electric charging with grid upgrades, and roll-out of hydrogen refuelling infrastructure.

<!-- image -->

## Energy Technology Perspectives 2026

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

<!-- image -->

PAGE | 128

<!-- image -->

<!-- image -->

## Ammonia and methanol propulsion ships

## Policy support is needed  to level the playing field with conventional fuels

Large ocean-going  vessels often travel for several weeks,  which  makes electrification difficult. Drop-in biofuels can be used in existing ships without major modifications,  but  their  long-term  potential  is  constrained  by  the  availability  of sustainable biomass. Synthetic fuels derived from low-emissions hydrogen are alternatives  that  can  be  further  scaled  up;  synthetic  methanol  and  ammonia appear the most cost-competitive on a TCO basis, but they require new propulsion systems and enhanced safety measures.

As a result of the expansion of Emission Control Areas (IMO, 2025a) and GHG emissions limits from the European Union (European Commission, 2025a) and International Maritime Organization (IMO, 2025b), conventional ships represent only around a third of planned deliveries for 2028 (by gross tonnage); liquefied natural gas-propulsion ships make up more than half. Methanol propulsion ships make up some 10% of orders, but these have levelled off for deliveries for 2026 and  2028,  with  shipowners  noting  difficulties  in  securing  long-term  offtake agreements with fuel suppliers (WSJ, 2024). Development of ammonia engines for  large  vessels  has  accelerated,  with  leading engine  manufacturers reporting successful  pre-commercial  trials,  some  at  full  load.  At  least  30  ammoniapropulsion  medium  to  large  vessels  are  expected  to  be  delivered  from  2026 (United Nations Statistics Division, 2025). The TCO of methanol- or ammoniapowered ships is today up to twice as high as that of oil-fuelled vessels, but this cost gap is expected to narrow as fuel production scales up and energy efficiency improves. Fuel costs per unit of cargo are typically small compared to freight rates, and freight  itself  is  often  just  a  minor  component  of  end-consumer  prices,  but competition in the shipping industry is intense. Some cargo owners are willing to pay a green premium, but not yet at the levels required for alternative fuels (Boston Consulting Group, 2025).

In 2035, alternative propulsion ships reach more than one-third of total sales gross tonnage in the STEPS and CPS, and 80% in the NZE Scenario.

## Priority policy actions

-  Continue to foster international collaboration and ensure timely implementation of internationally agreed pathways.
-  Provide financial support to shipyards producing alternative propulsion ships and encourage knowledge-sharing on design and manufacturing.
-  Accelerate development of international green shipping corridors and investment in alternative fuel production and bunkering at key ports.

<!-- image -->

<!-- image -->

## Chapter 3. Technology deployment dashboards

<!-- image -->

<!-- image -->

<!-- image -->

## Buildings heat pumps

## Heat pumps return to growth as sales increase in all scenarios

Global sales of heat pumps for heating slowed in 2023 and 2024, after a record surge in 2022. This dip came against the backdrop of high interest rates, inflation, higher energy prices, policy uncertainty and a weaker construction sector. China remains the  world's  largest  market,  accounting  for  one  in  three  installations  in 2024, followed by the United States and the European Union.

Despite this recent slowdown, the longer-term view is more encouraging: global sales have more than doubled over the past decade. Heat pumps are increasingly cost-competitive in countries where the ratio of electricity to fossil fuel prices is favourable, or where milder winters and high cooling needs make air-to-air models appealing thanks to their potential for year-round operation.

However, cost remains an important barrier. In many regions, electricity prices remain higher than natural gas, weakening  incentives to switch. In the United Kingdom, electricity prices are roughly four times higher than natural gas prices; in Germany, they are about three times higher. Even in Canada and the United States, where electricity is relatively cheap, low gas prices mean that the cost gap remains wide. This is often due to taxes and levies that disproportionately affect electricity. In addition, while lifetime costs are often lower, upfront costs can be two to three times higher than for fossil fuel alternatives, which acts as a barrier to uptake, especially for low-income households. Sudden changes to subsidies or regulations can disrupt supply chains and erode consumer confidence, as seen recently in Italy, Germany and parts of the United States.

In the STEPS, annual heat pump sales double by 2035 compared to today. In the CPS,  sales  increase  by  85%,  driven  by  improvements  in  affordability.  In  the NZE Scenario, sales are almost double those in the STEPS by 2035, unlocking the full potential for heat pump adoption across all markets.

## Priority policy actions

-  Adjust energy taxes and levies while encouraging flexible demand, including via targeted R&amp;D support.
-  Avoid abrupt changes to incentives or regulations.
-  Expand fast-track reskilling programmes and integrate heat pump training into vocational education.
-  Establish  one-stop-shops  for  advice  and  installation,  streamline  permitting processes and encourage innovative business models (e.g. leasing).

<!-- image -->

## Energy Technology Perspectives 2026

<!-- image -->

<!-- image -->

<!-- image -->

PAGE | 132

<!-- image -->

<!-- image -->

## Chapter 3. The outlook for deployment by technology

## Air conditioning systems

## Policy is key to enable access to affordable, high-performance units

Rising temperatures and improving living standards are driving a surge in global demand  for  air  conditioning  (AC)  -  now  one  of  the  fastest-growing  uses  of electricity in buildings and the dominant means of indoor cooling. Since 2000, the number of households owning AC has nearly tripled worldwide, rising from less than 15% to about 40%, pushing up electricity use for space cooling by more than two-and-a-half  times.  Penetration  is  highest  in  wealthier,  temperate  regions  reaching around 90% in the United States and Japan, and over 70% in China. Uptake remains lower in hotter, more humid regions, largely due to affordability constraints - reaching more than 30% in Brazil, about 20% in India and less than 10% across much of Africa.

Improving  AC  efficiency  is  critical  to  limiting  the  impact  of  rising  demand  on electricity use, peak loads and refrigerant-related emissions - a major contributor to global warming.  More  than  100  countries  now  have  minimum  energy performance standards (MEPS) in place for AC, covering around 90% of global cooling  energy  demand,  up  from  about  75%  in  2015.  These  standards  have steadily  raised  average  efficiency,  but  major  gaps  persist.  The  most  efficient models sold today are up to four times more efficient than the least efficient, and about three times as efficient as the global average. However, high-efficiency units frequently carry a capital cost premium due to added features such as quieter operation, improved design and smart functionality.

In the STEPS, AC efficiency improves gradually, with around 2 billion units sold between 2025 and 2035. In the CPS, efficiency improvements are more muted. In the  NZE  Scenario,  all  units  sold  by  2035  are  assumed  to  match  today's  best available models.

## Priority policy actions

-  Expand  and  tighten  MEPS  to  improve  access  to  high-efficiency  units  and accelerate the phase-out of inefficient models, such as fixed-speed models.
-  Encourage innovative business models (e.g. cooling-as-a-service) and support R&amp;D (e.g. on solid-state cooling or desiccant-based systems).
-  Prioritise passive cooling solutions and introduce targeted financial incentives for high-efficiency units, especially for low-income households in humid and temperate climates.
-  Align national and local cooling strategies with building energy codes, design regulations and broader urban and energy planning frameworks.

<!-- image -->

## Energy Technology Perspectives 2026

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

PAGE | 134

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

<!-- image -->

<!-- image -->

## Zero-carbon-ready building envelopes

## Zero-carbon-ready buildings are still rare, remaining costly and undervalued

Driven  primarily  by  energy  efficiency  regulations  focused  on  reducing  heating demand, several countries and regions - including Canada, the European Union, the  United Kingdom  and  parts  of  the  United States  -  have  made  progress  in aligning building codes with principles for zero-carbon-ready buildings (ZCRBs) (IEA, 2022a). However, less than 10% of the existing building stock worldwide meets these standards; about 100 countries - down from more than 130 in 2016 - still  lack mandatory building energy codes altogether. As a result, many new buildings are still constructed with poor performance envelopes that lock in high energy use, reduced occupant comfort and limited climate resilience for decades to come.

Around half of the global floor area that will be in place in 2050 has yet to be built, with a large share expected in regions with high cooling demand. At the same time, approximately 75% of today's building stock will still be in use, meaning that renovation would be required to reach ZCRB status. The construction sector is one  of  the  world's  largest  employers.  Currently,  ZCRB  envelopes  cost  about 15-20% more than non-code compliant building envelopes in cold climates such as North America, and up to 35% more in mixed and warm climates like India and Brazil. While  investment  decisions  often  focus  on  payback  periods,  these calculations typically span the long lifetime of buildings and do not fully reflect the benefits  of  high-performance  envelopes,  including  improved  indoor  air  quality, greater  resilience  to  extreme  temperatures  and  enhanced  property  value.  The limited availability of transparent cost and performance data for ZCRB projects remains a major barrier to wider uptake.

## Priority policy actions

-  Incorporate principles of energy efficiency, climate resilience, and whole-life carbon performance in buildings regulation, especially in emerging markets and developing economies (EMDEs).
-  Reinforce financial support and simplify building energy renovation procedures,  focusing  on  improving  access  for  low-income  households  and less-performing buildings.
-  Support  training  of  regulators,  architects,  equipment  manufacturers  and construction workers.
-  Promote  robust  techno-economic  assessments  of  ZCRB  envelopes  and ensure clear communication of results to decision-makers and the public.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

## Industrial heat pumps

## Efficiency advantages enable electrification of industrial heat

Heat  pumps  are  emerging  as  an  effective  solution  to  improve  resilience  and reduce  emissions  from  low-temperature  industrial  heat.  Electricity  currently provides  less  than  5%  of  global  industrial  heat  demand,  although  electricity consumption grew by around 2% per year between 2010 and 2020 and is now accelerating, growing 4% since 2020. A major contributor to this increase is the growing  deployment  of  high-efficiency  heat  pumps.  Their  efficiency  is  highest when providing heat below 100ºC, though systems that integrate waste heat can achieve  temperatures  above  200°C  while  maintaining  strong  performance (HPT TCP, 2023). Heat pumps could now meet a substantial share of industry heating needs cost-effectively: up to 45% in light industry, and around 20% across all industrial sectors, depending on the availability of waste heat.

On average, industrial heat pumps cost around three times more than coal boilers, and up to ten times more than natural gas-fired alternatives. The potential need to expand electricity grid connections can add to upfront costs. This remains a major hurdle to wider adoption, particularly for smaller firms and those in EMDEs. When running costs are also considered, industrial heat pumps can be competitive with natural  gas  boilers  under  certain  circumstances;  the  breakeven  point  is  highly dependent on the electricity to gas price ratio.

Higher-efficiency  applications  can  have  a  narrower  cost  gap,  as  can  hybrid approaches, such as heat pumps with gas backup or thermal energy storage. These combinations can reduce average electricity costs, lower utility bills and improve energy security, strengthening the overall business case for heat pumps.

Installed heating capacity of industrial heat pumps rises in the STEPS to 80 GWth by 2035 (around 8% of thermal needs in light industries). It sees a more muted trend in the CPS and reaches nearly triple this level in the NZE Scenario.

## Priority policy actions

-  Adjust energy taxes and levies as well as electricity tariffs (e.g. time-of-use pricing) and support flexible demand.
-  Reinforce electricity grids, reduce grid fees, and prioritise grid connections for industrial loads that can provide flexible demand to stabilise power systems.
-  Scale  up  financial  support  for  first  adopters  of  electrified  industrial  heat, particularly if paired with optimised process integration.
-  Promote standardised system designs (including effective communication of best practices across sectors) and expand training to build a skilled workforce.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

PAGE | 138

<!-- image -->

<!-- image -->

## Near-zero emissions steel

## Overcoming cost premiums has been harder than anticipated

Commercial-scale  technologies  for  near-zero  emissions  steel  are  starting  to emerge, as well as earlier-stage technologies like iron ore electrolysis. The global project pipeline grew rapidly from 2020 to 2023, led mainly by iron-based projects using hydrogen. Despite this, by end-2025, planned capacity was just 115 Mt/year - around 5% of today's steel production and 20% of the deployment needs by 2035  in  the  NZE  Scenario.  Much  of  the  planned  capacity  is  still  in  early development,  or  is  intended  to  start  with  natural  gas  and  lacks  firm  plans  to transition to low-emissions hydrogen - less than 10% is fully near-zero emissions. Only 6 Mt (5%) of fully near-zero emissions capacity has reached final investment decision (FID), while over 15 Mt of total planned capacity has been postponed or cancelled since 2024, cutting expected capacity in 2027 by almost one-fifth.

Near-zero emissions steel is more expensive than conventional. This is especially true for iron-based steel, where levelised costs of production in 2035 are expected to be about 20-145% higher (USD 125-600 per tonne of crude steel) in the STEPS, in the absence of targeted policy support or significant scale-up. Rising energy prices, especially in the European Union (30% higher since 2020), have increased costs. Together with tighter fiscal conditions, global excess capacity and lowerthan-hoped buyer willingness to pay a premium, this has stalled global progress.

Yet the race continues to launch the first commercial-scale plant, with projects in China, Finland, Namibia, Spain and Sweden at or near FID (IEA, 2025d). These are backed by subsidies and early offtake agreements from buyers willing to pay a premium. So far, offtakes total over 5 Mt, worth almost USD 5 billion, but the potential market is larger; in the NZE Scenario, it reaches USD 380 billion by 2035, 30%  of  the  total  steel  market.  Consumer-facing  markets  are  key  for  demand creation,  making  up  almost  half  of  publicly  announced  offtakes  for  near-zero emissions steel, despite accounting for less than one-quarter of all steel demand.

## Priority policy actions

-  Adopt interoperable standards for near-zero and low-emissions steel.
-  Reinforce  and  expand  near-term  supply-side  support  policies  (e.g.  direct subsidies, contracts for difference) (IEA, 2025a).
-  Stimulate private and public demand for near-zero emissions steel (e.g. public procurement, buyer subsidies/incentives, embodied carbon limits, labelling).
-  Consider strategic partnerships with iron ore-rich regions that have access to low-cost renewable energy (see Chapter 7).
-  Invest in infrastructure for electricity grids and low-emissions hydrogen.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

<!-- image -->

PAGE | 140

<!-- image -->

<!-- image -->

## Near-zero emissions cement

## Willingness to pay cost premiums remains limited

While technologies to reduce emissions from cement production are advancing, progress has been slow. The most advanced near-zero emissions options involve CO  capture, while conventional cement made without limestone is a promising ₂ earlier-stage option. Since 2020, project announcements have increased sevenfold, but few have reached FID. All announced projects are in advanced economies, though the bulk of projected demand is in EMDEs - posing a major hurdle. Many announcements also plan for only partial CO  capture or lack defined ₂ storage solutions. Total announced capacity stands at about 55 Mt (with just 20 Mt at an advanced stage) - equivalent to 1% of today's conventional capacity.

A milestone was reached in 2025 when the first large-scale cement plant with carbon capture began operating in Norway, capturing around half of its emissions and  with  its  cement  already  sold  for  the  year  (Buli,  2025).  Limited  near-zero emissions cement has been sold, but advanced purchase agreements secured 0.1 Mt of silicate-based cement in 2025, at around USD 10 million in value.

Near-zero emissions cement remains significantly more expensive, and in 2035 is still 75-150% more costly (USD 50-175 per tonne) in the STEPS, in the absence of policy support and significant scale-up. Low- or no-clinker alternatives that can reduce emissions with little or no cost premium are emerging, such as those using calcined clay. Of the 15 full-scale calcined clay plants in operation today, eight are in EMDEs. Limestone filler or activated slag can also play a role, though some of these  pathways  may  be  constrained  by  raw  material  availability  and  technical limitations to the extent of clinker substitution.

Announced near-zero emissions capacity today is only 10% of the level required in the NZE Scenario in 2035, a gap of roughly 640 Mt. In this scenario, the market value  reaches  USD 70 billion  in  2035,  around  20% of the  total  cement market. Deployment is much lower in the STEPS and CPS, given limited policy support.

## Priority policy actions

-  Adopt interoperable standards for near-zero and low-emissions cement.
-  Reinforce  and  expand  near-term  supply-side  support  policies  (e.g.  direct subsidies, retrofit-ready requirements, contracts for difference) (IEA, 2025a).
-  Boost public and private demand for near-zero emissions cement (e.g. through public procurement, embodied carbon limits, novel cement in building codes).
-  Accelerate the development of CO2 transport and storage infrastructure.
-  Increase funding for low- and no-clinker cements, as well as recycling and material efficiency innovations.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

PAGE | 142

IEA. CC BY 4.0.

## Recycling

## Progress on recycling is uneven across materials and regions

Recycling trends vary widely, depending on the material. For bulk materials such as aluminium and paper, global average recycling rates have remained stable at high levels or seen modest gains recently. By contrast, the recycling of critical minerals is accelerating quickly. Lithium recycling from batteries, for example, has jumped from just 4% in 2015 to around 20% today. Even so, recycling rates for battery minerals remain well below those for metals produced at higher volumes: between 40% and 80% globally for key metals like steel, aluminium and copper.

There is a wide geographic divide. In Asia and Latin America, electronic waste collection rates remain below 5% and in Africa they are barely at 1%, with little improvement since 2010. In contrast, rates reach 30% in Japan and Korea, and 40-50% across Europe and North America.

The pace of recycling growth hinges on how quickly materials reach end-of-life. For bulk materials like steel and aluminium, ageing infrastructure is expected to boost  scrap  availability,  potentially  easing  demand  for  primary  production  especially in China - or increasing exports. By contrast, battery mineral recycling remains limited in the short term, mostly due to limitations on available feedstock. By  2035,  recycled  lithium  and  nickel  are  expected  to  meet  only  about  5%  of demand, as usage far outpaces available end-of-life feedstock. Innovation and shifting  technology  choices  can  also  limit  recycling  potential  for  certain  critical minerals. For example, the increasing uptake of lower-cost battery chemistries like lithium iron phosphate (LFP) in mass-market EVs is reducing demand for cobalt and nickel in battery production.

Recycling of all types of material is projected to grow in the STEPS, the CPS and the  NZE  Scenario,  particularly  in  China  and  other  EMDEs,  where  decades  of accumulated stock are now reaching end-of-life, boosting scrap availability.

## Priority policy actions

-  Develop  clear  long-term  policy  roadmaps  with  targets  and  intermediate milestones to guide industry efforts and boost investor confidence.
-  Promote traceability, standards and certification schemes.
-  Set up tolling models to maintain the economic viability of recycling low-value materials or chemistries such as LFP batteries.
-  Align and harmonise waste and recycling regulations to facilitate trade.
-  Introduce targeted policies to improve material recovery, spur innovation and tap into new sources of recyclable content, including mining waste and tailings.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

PAGE | 144

<!-- image -->

<!-- image -->

## Solar PV and wind power

## Manufacturing  gains  and  policy  support  are  driving  record capacity additions

The year 2024 was another record-breaker for solar PV and wind deployment. Global solar PV capacity additions surged by nearly 30%, and wind installations slightly outpaced 2023, itself a record year. Together, solar and wind accounted for  nearly  80%  of  total  electricity  capacity  additions  and  over  95%  of  new renewables capacity. China led the way with 60% of global additions, driven by strong  policy  support  for  utility-scale  and  distributed  systems,  and  low-cost domestic manufacturing that has made solar and wind generation competitive with coal in many provinces. Capacity additions are estimated to have grown around 10%  for both technologies combined in 2025. Rooftop and small-scale installations, while more costly than utility-scale systems in many markets, also saw rapid growth, particularly in China and India (albeit from a lower base in the latter), backed by local incentives and rising demand for self-generation. Offshore wind is gaining momentum too, especially in Europe.

Solar  PV  continues  to  dominate  renewables  deployment  globally  in  all  IEA scenarios, accounting for 75% of renewable capacity additions and over 50% of total electricity capacity additions by 2035 in both the STEPS and CPS, of which two-thirds are in China. Installed wind capacity doubles by 2035 in the STEPS and CPS, supported by improvements in auction design, permitting and grid access particularly  in  Europe,  China  and  India.  In  the  NZE  Scenario,  solar  and  wind capacity grow nearly sixfold and fourfold, respectively, by 2035. However, growing difficulties in integrating new capacity into power systems could impact the viability of solar and wind projects, with curtailment already reaching 16% in some regions (IEA, 2025e). China offers a strong example of progress: average wind curtailment fell  from  its  peak  at  over  15%  in  2016  to  less  than  5%  in  2024,  and  solar  PV curtailment declined to similarly low levels, thanks to grid upgrades, power market reforms and demand-side measures.

## Priority policy actions

-  Support  investment  in  transmission  capacity,  deploy  energy  storage  and modernise grid operations to reduce curtailment and improve reliability.
-  Streamline permitting to facilitate faster deployment and predictable demand.
-  Strengthen  support  for  distributed  solar  PV  (e.g.  via  feed-in  tariffs,  tax incentives and smart meter rollouts), especially in EMDEs.
-  Train workforce for installation, maintenance and offshore operations, including port infrastructure and vessels.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

PAGE | 146

<!-- image -->

<!-- image -->

## Nuclear

## Investment is growing as new technologies develop

Nuclear  power's  share  of  global  electricity  was  at  9%  in  2024,  making  it  the second-largest  source  of  low-emissions  electricity  after  hydropower.  Growth  is being  driven  by  rising  electricity  demand  and  the  ability  of  nuclear  to  provide dispatchable  low-emissions  electricity  and  heat.  Over  40  countries  now  have policies in place to expand its use. Capacity that had been suspended or was in maintenance is set to restart production in France and Japan, and new reactors are due to begin commercial operations in markets including China, India, Korea and Europe.

Innovation  in  small  modular  reactors  (SMRs)  is  also  reshaping  the  technology landscape, with a view to diversify providers, reduce costs, and cut lead times. As of November 2025, there were agreements and expressions of interest for 30 GW of SMR capacity, the majority of which is in the United States, in large part to meet growing  demand  from  data  centres.  Government  support  and  new  business models  will  be  critical  in  ensuring  these  reactors  become  cost-competitive, unlocking a path to wider adoption. However, the market for nuclear technologies remains highly concentrated, with Chinese and Russian technologies being used in 57 of the 61 reactors that have started construction since 2017. A new wave of projects - both SMRs and large-scale reactors - creates the possibility for Europe, Japan  and  the  United States  to  regain  technology  leadership.  Fusion  is  still  a longer-term prospect although investments are growing (see Chapter 1).

Momentum  should  be  maintained  over  the  longer-term:  annual  investment  in nuclear has increased by 50% since 2020, exceeding USD 70 billion in 2024. Over 70 GW of nuclear capacity is under construction, one of the highest levels since 1990. Almost half of these projects are located in China, where installed capacity is expected to surpass the European Union and the United States by around 2030. Global nuclear capacity grows by around 35% by 2035 in the STEPS and CPS, and 70% in the NZE Scenario. But tripling installed capacity by 2050 would require around 50% higher annual investment in the 2040s than in the NZE Scenario.

## Priority policy actions

-  Build  robust,  diverse  supply  chains  including  for  technology  design  and nuclear supply and enrichment.
-  Invest in a skilled workforce and support innovation.
-  Support business models through de-risking mechanisms for investment as well as direct financial support.
-  Implement effective, transparent nuclear safety regulations, alongside provisions for decommissioning and waste management.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

PAGE | 148

<!-- image -->

<!-- image -->

## Geothermal

## Next-generation geothermal remains expensive and cost reduction is essential

In 2024, electricity generation from geothermal was about 100 TWh (0.3% of the global  total)  with  total  installed  capacity  at  over  15 GW  across  more  than  30 countries.  In  Costa  Rica,  El  Salvador,  Iceland,  Kenya,  New  Zealand  and Nicaragua, geothermal contributed more than 10% to the annual electricity supply. Net additions in 2025 are estimated to have reached almost 0.5 GW, mostly from conventional projects, and multiple large-scale enhanced geothermal projects will start  operations  in  2026-27.  About  30  countries  have  supportive  policies  (IEA, 2025e).

Conventional geothermal (i.e. all capacity deployed today) relies on the location of  naturally  formed  hydrothermal  reservoirs.  Next-generation  geothermal  uses directional drilling and hydraulic fracturing to access heat at much larger depth, meaning  that  generation  is  not  location  dependent.  Generation  cost  from conventional geothermal is on average USD 60-80/MWh today (IEA, 2024b). This jumps  to  around  USD 230/MWh  for  next-generation  geothermal  but  could  be reduced by 80% by 2035 through innovation, scale and learnings from the oil and gas industry. Such a cost reduction would make geothermal competitive with other low-emissions alternatives, and would enable tapping into 600 TW of technical potential (almost 2 000 times larger than conventional geothermal) at a depth of less than 8 km, and 42 TW at less than 5 km. As reference, the global power generation capacity was over 11 TW in 2025.

By  2030,  42  countries  are  expected  to  have  some  geothermal  capacity,  with annual  capacity  additions  tripling  2024  levels,  driven  by  growth  in  Indonesia, Japan, Kenya, the Philippines, Türkiye and the United States (IEA, 2025e). By 2035,  global  geothermal  capacity  more  than  doubles  in  the  STEPS  (32  GW), doubles in the CPS (30 GW) and reaches more than 55 GW in the NZE Scenario.

## Priority policy actions

-  Improve subsurface data quality and create open data repositories to facilitate geothermal resource assessments.
-  Broaden risk mitigation schemes for early-stage projects, including demonstration  and  testing  of  emerging  technologies,  and  remuneration schemes that ensure long-term revenue certainty and that value flexibility.
-  Consolidate administrative steps involved in permitting for geothermal energy and consider dedicated regimes separate from minerals mining.

<!-- image -->

## Chapter 3. Technology deployment dashboards

<!-- image -->

## Stationary energy storage technologies

## Surging battery storage is complementing pumped hydro

Until  the  early  2020s,  nearly  all  grid-scale  storage  came from  pumped-storage hydropower, with under 200 GW of installed capacity globally (about 8 500 GWh of storage), though it is limited to geologically suitable locations. Over the past 5 years,  electrochemical  battery  storage  capacity  has  surged,  growing  at  an average annual rate of 70%, nearly three times that of solar PV today and faster than solar PV's peak growth in the early 2010s. Global stationary battery capacity is estimated to have surpassed pumped hydro in power terms by the end of 2025, reaching  around  270 GW,  though  energy  storage  capacity  will  still  lag  at approximately 625 GWh.

This rapid growth has been driven by battery cost reductions of over 75% since 2015, which are largely due to the rise in electric car sales. Falling solar PV costs have also boosted demand for storage to integrate higher shares of renewables, especially in areas with weak transmission networks, as batteries can be deployed more quickly than grid upgrades. Globally, around 4 GW of other long-duration storage technologies are now in operation, including 1 GW of mechanical systems (e.g. compressed air, liquid CO  and liquid air energy storage). ₂

Battery storage is set to continue expanding rapidly, though the pace will depend on several factors. In the STEPS, it reaches 1.7 TW/4.9 TWh by 2035, compared with 1.4 TW/4.2 TWh in the CPS and 2.9 TW/8.5 TWh in the NZE Scenario. This gap reflects three drivers in the NZE Scenario: faster electrification of end-uses (electricity accounts for more than 40% of final consumption compared to 30% in the STEPS), a higher share of generation from variable renewables (60% versus 40%),  and  a  sharper  decline  in  fossil-based  dispatchable  capacity.  By  2035, storage provides 30% of dispatchable capacity in the NZE Scenario, almost twice the  share  in  STEPS  or  more  than  double  that  in  the  CPS.  Scale-up  will  also depend on how much flexibility can be delivered via demand-side response, and how competitive storage technologies - especially long-duration - can become.

## Priority policy actions

-  Support  demonstration  and  scale-up  of  emerging  long-duration  storage technologies, while maintaining efforts to lower battery costs.
-  Provide  long-term  revenue  predictability,  including  via  capacity  payments, availability-based remuneration or government-backed guarantees.
-  Grant  storage  providers  access  to  electricity  markets,  covering  energy, capacity and ancillary services, to enable stacking of revenue streams.
-  Streamline grid connection procedures through one-stop-shop permitting and efficient pricing mechanisms.

<!-- image -->

## Energy Technology Perspectives 2026

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Low-emissions hydrogen, ammonia and methanol

## Public support and off-takers drive initial growth

Global low-emissions hydrogen production is rising briskly, but at an estimated 1 Mt  in  2025,  still  accounts  for  less  than  1%  of  total  hydrogen  production. Production grew by more than 70% since 2020, albeit from a low base. In 2024, almost 85% of supply came from fossil fuels with CCUS; the rest was mainly from electrolysis, with electrolytic production having nearly quintupled since 2020. In 2025, low-emissions hydrogen is estimated have risen by 30%, with 60% of the increase  from  electrolytic  hydrogen,  driven  by  China,  and  40%  from  CCUS. Around 30% of it is used for ammonia and methanol production.

China has commissioned the world's largest electrolytic ammonia plant, supported by low-cost renewables and domestic equipment, and an offtake agreement with Marubeni, a Japanese conglomerate. In Denmark, the largest CO -to-methanol ₂ plant  using  electrolytic  hydrogen  started  operating  in  2025,  backed  by  public funding and offtake agreements with Lego, Mærsk and Novo Nordisk, and using biogenic CO  from biogas. In the United States, CCUS-based hydrogen projects ₂ are advancing, spurred by the 45Q tax credit for CO  storage. ₂

Projects  that  are  operational  or  have  committed  investments  in  low-emissions hydrogen stand at 4.2 Mt per year, more than four times the estimated production in 2025. If all announced projects go ahead, production could reach 37 Mt by 2030. In the STEPS, low-emissions hydrogen grows to 13 Mt by 2035, compared with 11 Mt in the CPS and more than 120 Mt in the NZE Scenario. In the latter scenario, ammonia and methanol production - used as both chemicals and fuels - consume 32 Mt  and  14 Mt  of  low-emissions  hydrogen,  over  35%  of  global  demand. Achieving the much faster scale-up envisioned in the NZE Scenario would call for lower  production  costs  and  stronger  demand  signals,  including  for  existing hydrogen uses. The volume of hydrogen covered by offtake agreements is just 7 Mt today, and only a quarter of those are on firm contractual terms.

## Priority policy actions

-  Develop lead markets through the introduction of quotas, mandates and public procurement to create early demand.
-  Close the cost gap with fossil hydrogen with investment incentives, revenuestabilising tools  such as contracts for difference  and access to cheap finance. , ,
-  Support  investment  in  power  grids,  and  hydrogen  and  CO   transport  and ₂ storage, to avoid infrastructure bottlenecks.
-  Adopt  clear,  pragmatic  regulation  and  certification schemes  that  ensure environmental integrity and enable cross-border interoperability.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

<!-- image -->

PAGE | 154

<!-- image -->

<!-- image -->

## Sustainable aviation fuels production

## SAF output is rising on the back of blending mandates

Global production of sustainable aviation fuel (SAF), derived from biofuels and low-emissions hydrogen, is estimated to double in 2025, but still meet only around 0.5% of total jet fuel demand. Growth is being primarily driven by policy measures, such as the European Union's ReFuelEU Aviation regulation, which requires a 2% SAF blend from 2025, rising to 20% by 2035. The United Kingdom has set a 10% blending  mandate  by  2030,  and  in  Brazil,  airlines  are  obliged  to  reduce  their emissions by 1% through SAF in 2027, and by 10% by 2037.

The  high  production  costs  of  SAF  remain  an  immediate  obstacle  to  wider deployment. SAF produced via the prevailing technology today - hydroprocessed esters and fatty acids (HEFA) - costs two to three times more than fossil jet fuel. Producing synthetic kerosene (still at the demonstration phase) costs over nine times more. But the impact on the consumer is likely to be lower. For example, under the ReFuelEU 20% SAF mandate by 2035 (5% synthetic), average ticket prices would rise by around 10%, as costs decrease for emerging SAF pathways. Waste and residue  oils  are  important  bio-SAF  feedstocks,  and  likely  the  main avenue to 2030, intensifying pressure on their already limited supply (IEA, 2022b). Crop-based feedstocks may compete with food production, whereas for e-SAF, the availability of CO2 feedstocks is a key constraint. Biogenic CO2 sources are limited  and  require  nearby  facilities  such  as  biorefineries  or  CO2  transport infrastructure; capturing CO2 directly from the air is prohibitively expensive for now.

In the STEPS and the CPS, global SAF output grows tenfold by 2035, reaching 4% of projected jet fuel demand, mainly driven by current mandates. Projected needs in the NZE Scenario are four times higher.

## Priority policy actions

-  Accelerate SAF uptake by confirming existing mandates and tax incentives, and creating demand signals in new markets.
-  Promote  financing  mechanisms  based  on  GHG  performance  to  support emerging production routes (e.g. contracts for difference, flexible loans). --
-  Establish clearly defined minimum performance thresholds that are compatible across borders and sectors, ideally under the Carbon Offsetting and Reduction Scheme for International Aviation (CORSIA) framework.
-  Encourage strategies to expand production of sustainable biomass feedstocks (e.g. sequential cropping, cultivation on degraded lands).
-  Update the ASTM D7566 standard specification and accelerate testing and certification by aircraft manufacturers for full approval of SAF as a drop-in fuel.

<!-- image -->

## Chapter 3. The outlook for deployment by technology

<!-- image -->

PAGE | 156

<!-- image -->

<!-- image -->

## Carbon dioxide removal

## Public funding and voluntary markets are driving first-of-a-kind projects

Bioenergy with carbon capture and storage (BECCS) and direct air capture (DAC) are among the leading carbon dioxide removal (CDR) technologies today in terms of capacity. Their deployment is set for a step change, with several first-of-a-kind projects expected to be commissioned soon in Denmark, Iceland, Sweden and the  United States.  Projects  already  under  construction  alone  could  more  than double  current  BECCS  capacity  and  expand  DAC  capacity  by  a  factor  of  50 worldwide,  albeit  from  a  low  base.  These  efforts  are  largely  backed  by  public funding, with around USD 5 billion committed over the past 5 years.

Voluntary carbon markets have been critical in enabling projects to reach FID by providing  stronger  demand signals and revenue certainty. In 2024, developers signed advanced offtake agreements covering nearly 6 Mt of CO  removals using ₂ these two technologies - almost double the volume seen in 2023. These markets, however, remain highly concentrated: about 65% of purchases of carbon credits from CDR projects in 2024 came from a single buyer, Microsoft (CDR.fyi, 2025a). They cannot provide the long-term, stable demand needed to scale investment.

Stronger policy support is essential to foster innovation, lower costs and ensure removals are durable, measurable and verifiable. DAC, in particular, faces high energy needs and steep first-of-a-kind costs, currently estimated at USD 500-1 900 per tonne of CO . However, advances in capture materials and ₂ scale effects could bring costs down to around USD 300/t CO  in the longer-term. ₂

If all announced projects proceed, CO  removal capacity could grow around 80₂ fold by 2035 from today's level of around 1 Mt CO  per year, surpassing by a wide ₂ margin the 7 Mt projected in the STEPS or the 5 Mt in the CPS, though far short of the 660 Mt in the NZE Scenario.

## Priority policy actions

-  Create demand  including through the introduction of legally binding targets, , public procurement, integrating CDR in compliance and international carbon markets  and policies such as carbon contracts for difference. ,
-  Increase public RD&amp;D funding, focusing on material performance, energy use and climate adaptability, supported by open-access testbeds.
-  Facilitate data sharing -and establish robust, consistent standards for monitoring, reporting and verification across CDR methods.
-  Promote early investment in scalable CO2 transport and storage infrastructure to enable cost-effective deployment of CDR technologies.

## Technical notes on the dashboards

## General notes

## Common abbreviations

STEPS

CPS

NZE

TRL

Stated Policies Scenario

Current Policies Scenario

Net Zero Emissions by 2050 Scenario

Technology readiness level

## Definition of market status categories

-  Pre-commercial: has not yet reached TRL 9. Includes technologies which can be ordered but are not yet in commercial operation.
-  Awaiting adoption: has reached TRL 9 but struggling to be deployed in the market.
-  Building  momentum:  has  entered  certain  markets  but  not  being  widely adopted, global impact limited.
-  Strong growth: widely adopted, market size/share growing substantially.
-  Consolidation: widely adopted, market size/share stabilising or declining.

## Qualitative cost advantage indicator

<!-- image -->

-  Costs are assessed on a like-for-like basis (e.g. production costs for similar products, value-adjusted levelised cost of electricity).
-  For some technologies, both purchase cost and whole-life costs, i.e. total cost of ownership, are assessed separately.
-  Policies influence the competitiveness of technologies; they define the playing field.
-  This assessment is for 2025.

## Electric cars

-  Chargers less than or equal to 22 kW are classified as slow, chargers greater than 22 kW and up to 150 kW as fast, chargers 150 kW and up to 1 MW as ultra-fast, and chargers 1 MW or above as MW-scale.
-  Sources:  IEA  analysis  based  on  country  data  submissions  and  data  from European Automobile Manufacturers' Association (2025); European Commission  (2025b);  EV  Volumes  (2025);  Marklines  (2025);  S&amp;P  Global Mobility (2025); and US Department of Energy (2025).

## Zero-emissions trucks

-  HD = heavy-duty; MD = medium-duty; BEV = battery electric vehicle; TCO = total cost of ownership.
-  Medium-duty trucks have a gross vehicle weight of greater than 3.5 tonnes and up to 15 tonnes; heavy-duty trucks have a gross vehicle weight greater than 15 tonnes.
-  Assumptions used for the total cost of ownership analysis are described in Annex A of the Global EV Outlook 2025 (IEA, 2025c).
-  Sources: IEA analysis based on data from EV Volumes (2025); China EV100 (2025); China Commercial Vehicles Dealers Association (2025); and CALSTART (2025).

## Ammonia and methanol propulsion ships

-  The total cost of ownership is calculated for a representative containership of capacity  9 400 Twenty-foot  Equivalent  Units  (TEUs),  fitted  with  the  energy efficiency  technologies  expected  to  be  deployed  at  the  time  of  investment (2035). Fuel costs as per IEA's Global Energy and Climate model results (IEA, 2025f). Operating costs exclude fuel costs.
-  Alternative fuel readiness of ports is based on the score defined in the IEA's Global  Hydrogen  Review  2025  (IEA,  2025g).  The  score  is  calculated  as follows: Score = 3 × ammonia (NH ₃) + 3 × liquefied petroleum gas (LPG) + 3 × methanol (MeOH) + 1 × liquefied natural gas (LNG), where each variable is binary:  1  if  the  port  has  storage  infrastructure  for  that  carrier  (NH3,  LPG, MeOH, or LNG), and 0 otherwise. 'High' means a score of 8 to 10, 'Medium' means a score of 5 to 7, 'Low' means a score of 1 to 4, 'Nil' means a score of 0.
-  Alternative propulsion ship construction means construction of ships equipped with  a  methanol  or  ammonia  dual-fuel  engine  (it  does  not  include  LNGpowered ships). Constructed gross tonnage values for 2035 in the different scenarios are averaged over a period of 5 years (2031-2035).

## Buildings heat pumps

-  In calculating the levelised cost of heat, heat pumps are assumed to have a lifetime of 15-20 years, compared with 17 years for gas boilers. Annualisation of operating expenditures is performed using a 3% discount rate. Annualised CAPEX and operational cost assumptions rely on the IEA Global Energy and Climate Model (IEA, 2025f).
-  2025e data are based on data available as of February 2026, while 2019 2024  data  are  based  on  data  available  in  2025  from  EHPA  (2025);  AHRI (2025); JRAIA (2025); and ChinaIOL (2025).

## Air conditioning systems

-  Efficiency is reported in CSPF = Cooling Seasonal Performance Factor.
-  CSPF values have been standardised based on ISO group 1, applying distinct harmonisation models for fixed-speed versus inverter technologies.
-  Annualised capital and operational cost parameters follow the assumptions of the IEA Global Energy and Climate Model (IEA, 2025f).
-  Shipments from China are categorised under the GB 21455-2019 classification, wherein Class 2 and above represent high efficiency, Classes 3 -4 represent medium efficiency, Class 5 medium to low, and below Class 5 represent the lowest efficiency.

## Zero-carbon-ready building envelopes

-  A  zero carbon ready  building  is  highly  energy-efficient  and  either  uses --renewable  energy  directly  or  an  energy  supply  (e.g.  electricity  or  district heating) that will be fully decarbonised by 2050.
-  Building construction costs are evaluated over a 50-year horizon with a 3% discount rate. Assumptions  for heating and  cooling expenditures and construction costs are aligned with those used in the IEA Global Energy and Climate Model (IEA, 2025f).
-  Buildings designated as compliant are those governed by applicable energy efficiency  standards  or  regulations;  those  lacking  such  requirements  are classified as non-compliant.
-  Technology readiness levels follow the framework provided in the ETP Clean Energy Technology Guide (IEA, 2025b).

## Industrial heat pumps

-  HP = Heat pump; COP = Coefficient of Performance; this represents the ratio between thermal energy provided by the heat pump and the energy supplied to make it work.

-  Due to uncertainty in current stock and sales of industrial heat pumps, data focuses on potential future growth in industrial heat pump installations.
-  The temperature lift is the delta between the average temperature of the heat source, and the average temperature of the heat sink.
-  In the electricity to gas price ratio figure, average industrial end-user prices for 2024  are  used.  Those  prices  include  specific  taxes  and  network  cost  for industrial users associated with those fuels.
-  CAPEX includes equipment and installation cost but not grid connection cost. The error bar represents the range of capital costs in between the 20% and 80% percentile, as listed by HPT TCP (2023).
-  Heat pump potential per industry considers the heat output potential for those sectors.  For  the  food  and  tobacco,  chemical  and  paper  sectors,  the  same assumptions as in the article by Marina et al. (2021) are used. Other sectors either use a sector-specific assumption or an assumed deployment potential of  95%  of  temperatures  below  60°C,  50%  between  60°C  and  100°C,  30% between 100°C and 150°C, 3% between 150°C and 200°C and no deployment potential  above  200°C.  The  total  amount  of  industrial  heat  demand  is estimated using internal IEA data.
-  In the levelised cost calculation, a COP of 5 is assumed for the temperature lift of 50°C, and a COP of 2 for the 120°C lift. This is based on the average COP of real heat pumps as listed by HPT TCP (2023).
-  The theoretical maximum COP is the Lorenz COP. It is calculated using the ratio between the entropic mean temperature of the sink and the temperature lift.
-  Sources:  IEA  analysis  based  on  Marina,  Spoelstra,  Zondag,  &amp;  Wemmers (2021); Taibi, Gielen, &amp; Bazilian (2010); ITP Thermal (2019); Madeddu et al. (2020); HPT TCP (2023); US Energy Information Administration (2021).

## Near-zero emissions steel

-  'Near-zero emissions' refers to projects that, once operational, will operate at an emissions intensity consistent with near-zero emissions from the start, as defined in the IEA report Achieving Net Zero Heavy Industry Sectors in G7 Members (IEA, 2022c).
-  'Near-zero emissions capable' refers to capacity that operates using the same core process equipment as near-zero emissions capacity and will achieve a substantial reduction in emissions intensity (compared to current conventional technologies) from the start - but initially fall short of the emissions intensity for  near-zero  emissions - with plans to reduce emissions further to a level consistent  with  near-zero  emissions  at  a  later  date  and  with  technical capabilities such that it could achieve near-zero emissions production without substantial additional capital investments in core process equipment.

-  'Announced'  is  the  estimated  capacity  based  on  publicly  available  project announcements for iron-based steel and includes both near-zero emissions and  near-zero  emissions  capable  capacity.  Based  on  publicly  available information as of November 2025.
-  Assumed materials prices for market size estimation are derived using the evolution of levelised cost of production and demand in each scenario.
-  Near-zero  emissions  steel  includes  both  iron-based  and  scrap-based  steel production.
-  Levelised  cost  of  production  (LCOP)  estimates  are  based  on  regional averages in 2035 in the STEPS and are reported per tonne of crude steel. Conventional production is represented by production from blast furnace basic oxygen  furnace  and  natural  gas  direct  reduced  iron  electric  arc  furnace pathways  and  near-zero  emissions  production  is  represented  by  hydrogen direct reduced iron electric arc furnace pathways. Costs do not include any explicit policy supports, e.g. carbon pricing or subsidies. The box represents the range of expected typical LCOP values, while the whiskers include the average LCOP in higher- or lower-cost regions. Cost premiums are calculated based  on  the  difference  between  LCOP  for  conventional  and  near-zero emissions  production  in  each  region.  The  global  average  production  cost premium is based on the difference between the median LCOP across regions for conventional and near-zero emissions.
-  Cost pass-through of cost premiums to final products are estimated as follows: Prices for technologies are based on 2024 capital costs (including installation costs) of typical products, which  are  USD 40 000  for  an  electric  car, USD 1 030 per kilowatt (kW) of onshore wind power, and USD 700 per kW of utility solar PV power. The assumed material intensities are global averages and  constant  over  time.  Cost  increases  are  derived  from  the  difference  in production cost between near-zero emissions and conventional steel, following  the  methodology  described  in the  previous  paragraph.  Two  value chain  stages  with  a  10%  profit  margin  have  been  assumed,  used  as  an illustrative average to account for the escalation of initial material costs across the value chain.
-  The share of historical conventional steel by final use is calculated using the IEA's model of steel consumption by end use sector (IEA, 2025f) including sources  such  as  (Cullen,  Allwood,  &amp;  Bambach,  2012).  Share  of  near-zero commitments  is  based  on  sectoral  representation  of  members  within  key private  sector  demand  aggregation  initiatives  for  near-zero  emissions  steel and  of  companies  that  have  publicly  announced  commitments,  including letters of intent, memoranda of understanding, and offtake agreements. Share of near-zero offtakes is based on estimated quantities of near-zero emissions steel  purchases  from  publicly  announced  commitments.  Based  on  publicly

available information as of November 2025. Demand growth to 2030 is based on the STEPS and represents the global total.

-  Potential coverage of voluntary labels for near-zero and low-emissions steel is based on production volumes based on membership under private organisations or based on jurisdiction of governments that have released or are developing voluntary labels.

## Near-zero emissions cement

-  'Near-zero emissions' refers to capacity that, once operational, will operate at an emissions intensity consistent with near-zero emissions from the start, as defined in the IEA report Achieving Net Zero Heavy Industry Sectors in G7 Members (IEA, 2022c).
-  'Near-zero emissions capable' refers to capacity that operates using the same core process equipment as near-zero emissions capacity and will achieve a substantial reduction in emissions intensity (compared to current conventional technologies) from the start - but initially fall short of the emissions intensity for  near-zero  emissions - with plans to reduce emissions further to a level consistent  with  near-zero  emissions  at  a  later  date  and  with  technical capabilities such that it could achieve near-zero emissions production without substantial additional capital investments in core process equipment.
-  'Announced'  is  the  estimated  capacity  based  on  publicly  available  project announcements for cement production and includes both near-zero emissions and  near-zero  emissions  capable  capacity.  Based  on  publicly  available information as of November 2025.
-  Assumed materials prices for market size estimation are derived using the evolution of LCOP and demand in each scenario.
-  LCOP  estimates  are  based  on  regional  averages  in  2035  in  the  STEPS. Conventional production is represented by production from dry kiln pathways and near-zero  emissions  production  is  represented  by  dry  kiln  with  carbon capture  and  storage  pathways.  Costs  do  not  include  any  explicit  policy supports, e.g. carbon pricing or subsidies. The box represents the range of expected typical LCOP values, while the whiskers include the average LCOP in higher- or lower-cost regions. Cost premiums are calculated based on the difference between LCOP  for conventional and near-zero emissions production  in  each  region.  The  global  average  production  cost  premium  is based  on  the  difference  between  the  median  LCOP  across  regions  for conventional and near-zero emissions.
-  Cost pass-through of cost premiums to end products are estimated as follows: Prices for infrastructure are based  on  2024  capital costs, which  are USD 420 000 for the construction of a single-family home, USD 950 000 for construction of a kilometre of paved lane, and USD 2 550 000 for construction

of a kilometre of track. The assumed material intensities are global averages and  constant  over  time.  Cost  increases  are  derived  from  the  difference  in production cost between near-zero emissions and conventional steel, following  the  methodology  described  in the  previous  paragraph.  Two  value chain  stages  with  a  10%  profit  margin  have  been  assumed,  used  as  an illustrative average to account for the escalation of initial material costs across the value chain.

-  Green public procurement coalition refers to the Industrial Deep Decarbonisation Initiative (IDDI); membership of IDDI as of November 2025. Current IDDI members are Australia, Brazil, Canada, Germany, India, Japan, Saudi  Arabia,  the  United  Arab  Emirates,  the  United Kingdom,  and  the United States.  Share  of  public  procurement  is  taken  as  a  constant  global average for the purposes of the analysis. IEA analysis is based on publicly available estimates  on  share  of public procurement  (Global  Efficiency Intelligence, 2024a) and (Global Efficiency Intelligence, 2024b).
-  Potential coverage of voluntary labels for near-zero and low-emissions cement is based  on  production  volumes  based  on  membership  under  private organisations or based on jurisdiction of governments that have released or are developing voluntary labels.

## Recycling technologies

-  EVs = Electric vehicles.
-  When not stated otherwise, projected data refers to the STEPS.
-  'Recycling rate' is defined as the efficiency of the entire recycling supply chain (collection, separation, metallurgy), while 'share of demand met by recycling' is defined as the share of total material demand met by recycled inputs.
-  Other  critical  minerals  include  nickel,  manganese,  cobalt,  graphite,  lithium, neodymium, praseodymium, terbium and dysprosium.
-  Global available feedstock shows maximum possible feedstock volumes for recycling  before  any  collection  rates  or  recycling  process  yield  losses. Projected capacity is based on announced projects. 85% maximum utilisation rate for production capacity is assumed. Recycling capacity refers to material recovery  capacity.  Available  feedstock  excludes  batteries  from  portable electronics and e-bikes.
-  Sources: IEA (2024a); Bloomberg (2025); Food and Agriculture Organization of the United Nations (2025); US Geological Survey (2025); IEA (2021); World Gold Council (2024); and Silver Institute (2025).

## Solar PV and wind

-  Detailed  levelised  cost  of  electricity  and  value-adjusted  levelised  cost  of electricity are available from (IEA, 2025h) (annex B).

## Nuclear

-  CAPEX = capital expenditure; SMR = small modular reactor.
-  Annual investment spending is presented as a 5-year average.
-  2024  Value-adjusted  levelised  cost  of  electricity  (VALCOE)  represents  an average for coal, gas, and nuclear power generation, and is available from (IEA, 2025h) (annex B). Potential reflects potential cost reductions associated with a deployment trajectory consistent with the Announced Pledges Scenario by 2040 (see analysis in IEA [2025i]).

## Geothermal

-  Market sizing is based on the share of the annual investment that is associated with equipment manufacturing (i.e. excluding items such as permitting costs, exploration, drilling). See page 26 of (IEA, 2024b).
-  Potential cost reduction is based on a high level of transfer and productivity gains  from  the  oil  and  gas  industry  and  correspond  to  next-generation geothermal. See pages 68 and 69 of (IEA, 2024b).
-  VALCOE is based on the STEPS from IEA (2025h). In case full cost reduction potential is reaped, next-generation geothermal could reach parity with fossilbased generation (IEA, 2024b).
-  Technical potential for next-generation geothermal from IEA (2024b).
-  Venture capital data from Group,C. (2025), Crunchbase (2025).

## Stationary energy storage technologies

-  In  IEA's Global  Energy  and  Climate (GEC) Model (IEA,  2025f),  lithium-ion batteries  serve  as  a  proxy  for  stationary  energy  storage  technologies.  This reflects  their  commercial  maturity  and  modelling  constraints.  Consequently, the model represents stationary storage using utility-scale lithium-ion battery systems with different storage duration ranges, and the corresponding global market size is estimated based on their costs. These results should not imply that all future deployment of stationary storage would be met exclusively by lithium-ion  batteries.  Instead,  they  serve  as  an  economically  representative benchmark  for  current  technologies.  Other  storage  technologies,  such  as redox-flow  batteries,  compressed  air,  or  thermal  storage,  may  ultimately deliver the required flexibility and duration ranges, particularly as their costs decline or they become better suited to specific system needs. For example,

batteries  are  less  suited  for  long-duration  storage  (&gt;10 hours),  creating opportunities for alternative technologies to meet this need.

-  Short-term flexibility addresses hour-to-hour variations in demand and supply. Today, typical requirements for short-term flexibility are equivalent to around 10% of average demand. In the GEC model, by 2035, short-term flexibility needs  are  handled  by  a  combination  of  batteries, demand  response, hydropower, thermal power and curtailment (IEA, 2025h).
-  The levelised cost of electricity delivered from each energy storage technology includes CAPEX, fixed and variable operating costs (OPEX), and the cost of input  energy,  namely  electricity  for  charging,  or  hydrogen  production  for hydrogen turbines or natural gas for single-cycle gas turbines, which serve as a benchmark  for  today's  dispatchable  generation  technologies.  Typical conversion  efficiencies  and  energy  losses  are  considered.  The  uncertainty range reflects different annual full-load hours, with the lower bound corresponding to 2 000 hours and the upper bound to 250 hours. For hydrogen and natural gas peaker plants, the uncertainty range also reflects variability in fuel prices. For hydrogen, the assumed range of low-emissions prices is from USD 3.4/kg H ,  corresponding  to  the  minimum  levelised  cost  of  renewable ₂ hydrogen  production  achievable  with  current  technologies  in  China,  to USD 8.0/kg H . Higher low-emissions hydrogen prices are possible but would ₂ make the technology uncompetitive for providing dispatchable capacity. For natural  gas,  prices  are  assumed  to  range  from  USD 3 per  million  British thermal  units  (MMBtu)  to  USD 15/MMBtu.  A  constant  electricity  price  of USD 40/MWh is assumed in all cases.
-  The maximum storage duration range presented reflects economically feasible potential rather than technical limits. While it is technically possible to extend the storage duration of certain technologies, such as using electrochemical batteries for longer discharge periods, doing so would generally result in lower capacity  factors  and  substantially  higher  levelised  costs  of  energy  storage. Therefore, the storage duration ranges are based on economic considerations and current and near-term prospects rather than on technological capabilities.

## Low-emissions H2, ammonia and methanol

-  Low-emissions hydrogen includes hydrogen which is produced through water electrolysis  with  electricity  generated  from  low-emissions  sources,  such  as renewables like solar and wind turbines, and nuclear. Hydrogen produced from biomass or from fossil fuels with CCUS technology is also counted as lowemissions hydrogen. However, production from fossil fuels with CCUS is only included if upstream emissions are sufficiently low, capture is applied at high rates to all CO2 streams associated with the production route, and all CO2 is permanently  stored  to  prevent  its  release  into  the  atmosphere.  The  same principles apply to low-emissions feedstocks and hydrogen-based fuels, such

as  methanol,  produced  using  low-emissions  hydrogen  and  a  sustainable carbon source, i.e. this must be of biogenic origin or directly captured from the atmosphere, but not from fossil fuels or fossil-derived process emissions.

-  The market size is  estimated  based  on  the  weighted  average  cost  of  lowemissions hydrogen and its main derivatives in the region of consumption, including  low-emissions ammonia, low-emissions synthetic methanol (using CO  as a feedstock, not syngas), synthetic methane, and synthetic kerosene. ₂ In the dashboard, ammonia's market size includes its use both as a fuel and as  a  feedstock  for  fertilisers,  explosives,  and  other  industrial  applications. Similarly, the market size of methanol covers both fuel and feedstock uses. The market size under 'Other H2 uses' includes pure hydrogen applications (such as direct combustion, iron ore reduction and inputs to biorefineries), as well as synthetic methane and synthetic kerosene. It also includes hydrogen used as a feedstock to produce high value-added chemicals, accounted for based on the value of the hydrogen input, rather than that of the final chemical product.
-  The map of hydrogen production from electrolysis reflects the production from the  least-cost  configuration  of  renewable  energy  supply  and  storage.  It considers an optimised combination of solar PV, onshore and offshore wind and battery storage, operating off-grid with the electrolyser, to minimise the levelised  cost  of  electrolytic  hydrogen.  The  electrolyser  capacity  factor  is optimised accordingly. Water costs are not included. A larger version of the map can be consulted at IEA's Hydrogen Tracker (IEA, 2025j).
-  The  range  in  the  levelised  cost  of  hydrogen  production  reflects  regional differences  in  fossil  fuel  prices,  renewable  costs,  technology  CAPEX  and OPEX as well as cost of capital. Electrolyser CAPEX includes the electrolyser system,  balance  of  plant,  engineering,  procurement  and  construction,  and contingencies; electrolyser capacity factor is assumed to be the same as the renewable  power  plant.  Figure  is  capped  at  USD 12/kg H2,  although  some production routes reach higher values. Water cost is not included. Detailed techno-economic data can be found in the Annex of IEA's Global Hydrogen Review 2025 (IEA, 2025g).
-  Hydrogen pipeline capacity is represented as a weighted average of 6.9 GW, reflecting  a  typical  mix  of  pipeline  diameters  rather  than  a  single  one.  The assumed  mix  includes  48-inch  (~1 200 mm,  12.7 GW),  36-inch  (~900 mm, 3.6 GW) and 20-inch (~500 mm, 0.9 GW) pipelines operating at 75% of their design  capacity  for  5 000 full-load  hours  (IEA,  2023).  Seaborne  trade  of ammonia includes shipping of both fossil-based ammonia and low-emissions ammonia.

## Sustainable aviation fuels production

-  Sustainable aviation fuels include biojet kerosene and synthetic kerosene.
-  Prices for HEFA biojet and fossil kerosene are taken as January-September 2025  averages  across  major  regions (Europe, North America, China, Singapore) and IEA analysis based on Argus (2025). Ranges for HEFA biojet prices are given as error bars. For emerging pathways, no market prices exist yet  and  thus  average  estimated  production  costs  are  provided  based  on IEA analysis with error bars giving the range of estimated costs for e-SAF, based on the cost of renewable electricity supply and regional differences.
-  The ticket price increase under ReFuelEU was calculated as the extra airline cost due to the mandated use of SAF compared to using 100% fossil kerosene in 2035. It was assumed that fuel accounts for 26% of total airline operating cost  and  that  airlines  have  a  profit  margin  of  4%  (IATA,  2025).  ReFuelEU mandates the use of 20% SAF with a sub-mandate of 5% for e-SAF. Following IEA cost projections, bio-SAF was assumed to be 2.2 times more expensive as fossil kerosene in 2035, and e-SAF 6.2 times.
-  The pipeline of SAF production projects using emerging pathways is based on IEA analysis based on IEA (2025e).
-  GHG intensities for the bio-SAF pathways are taken from R&amp;D GREET 2024 Rev1,  where  direct  land  use  change  is  included,  but  indirect  is  excluded. Carbon  capture  and  storage  (CCS)  assumptions  and  e-SAF  pathways  are based on IEA analysis.

## Carbon dioxide removal: BECCS and DAC

-  BECCS  =  bioenergy  with  carbon  capture  and  storage;  DAC  =  direct  air capture.
-  Historical  deployment  of  BECCS,  DAC  and  CO2  storage  is  based  on  the IEA CCUS Projects Database (IEA, 2025k).
-  2024 market size was based on volumes of BECCS and DAC credits and average  credit  prices  in  2024  (CDR.fyi,  2025b;  S&amp;P,  2025).  2035-2050 markets are based on volumes of CO2 removed via BECCS and DAC in each scenario multiplied by assumed carbon price (see Annex B of IEA (2025h) for selected carbon prices in the CPS, STEPS, and NZE Scenario).
-  2024  cost  was  estimated  based  on  available  capital  and  operating  cost information from existing projects:
-  Bioethanol plants: CAPEX: USD 58-285 million; fixed OPEX: 5%; electricity input:  0.66  GJ  per  tonne  CO2;  CO2  captured:  0.16-0.50  Mt  CO2  per  year; electricity price: USD 80/MWh; CO2 transport and storage fee: USD 0 per tonne CO2 (integrated); carbon removal efficiency: 87%; WACC: 8%; project lifetime: 25 years.

-  Combined heat and power: CAPEX: USD 1 230 million; fixed OPEX: 4%; heat input: -2.4 GJ/tonne CO2 (recovery); electricity input: 2 GJ per tonne CO2; CO2 captured: 0.87 Mt CO2 per year; heat price: USD 121/MWh; electricity price: USD 36/MWh; CO2 transport and storage fee: USD 70-105 per tonne CO2; carbon removal efficiency: 90%; WACC: 8%; project lifetime: 15 years.
-  Solid-DAC: CAPEX:  USD 11-17 million; fixed OPEX:  18%;  heat  input: 7.2 GJ/tonne  CO2;  electricity  input:  2.3  GJ  per  tonne  CO2;  CO2  captured: 0.0036 Mt CO2 per year; heat price: USD  5/MWh;  electricity price: USD 57/MWh; CO2 transport and storage fee: USD 30 per tonne CO2; carbon removal efficiency: 90%; WACC: 8%; project lifetime: 10 years.
-  Liquid-DAC: CAPEX:  USD 2 600 million; fixed OPEX: 5%; gas input: 5.3 GJ/tonne  CO2;  electricity  input:  1.3  GJ  per  tonne  CO2;  CO2  captured: 0.98 tonnes CO2  per year; gas price: USD  8/MWh;  electricity price: USD 64/MWh; CO2 transport and storage fee: USD 30 per tonne CO2; carbon removal efficiency: 90%; WACC: 8%; project lifetime: 25 years.
-  Potential  reflects  levelised  costs  that  could  be  reached  without  the  cost premiums  that  are  typically  associated  with  first-of-a-kind  plants:  BECCS based on IEAGHG (2021a); Schmitt, et al. (2022); and NETL (2022); DAC based on IEAGHG (2021b); McQueen, et al. (2021); and Keith, et al. (2018).
-  Historical average  prices  on  voluntary  carbon  markets  estimated  from disclosed deals between 2021 and 2025 (CDR.fyi, 2025b; S&amp;P, 2025).

## References

AHRI. (2025). the Air-Conditioning, Heating and Refrigeration Institute . Retrieved from https://www.ahrinet.org/

HPT TCP. (2023). High-Temperature Heat Pumps - Task 1 - Technologies . Retrieved from https://heatpumpingtechnologies.org/annex58/wpcontent/uploads/sites/70/2023/09/annex-58-task-1-technologies-task-report.pdf

Argus. (2025). Argus Direct . Retrieved from https://www.argusmedia.com/en/solutions/howwe-deliver/client-portal/argus-direct-workspaces

Bloomberg. (2025). Precious and Industrial Metals . Retrieved from https://www.bloomberg.com/markets/commodities/futures/metals

Boston Consulting Group. (2025). The $10 Billion Opportunity in Green Shipping. Boston Consulting Group . Retrieved from https://www.bcg.com/publications/2025/the-10-billionopportunity-in-green-shipping

Buli, N. (2025). Heidelberg sells out of net-zero cement from Norway plant, CEO says. Reuters . Retrieved from https://www.reuters.com/sustainability/climateenergy/heidelberg-sells-out-net-zero-cement-norway-plant-ceo-says-2025-06-18/

CALSTART. (2025). Drive to Zero's Zero-emission Technology Inventory (ZETI) Tool Version 9.0 . Retrieved from https://globaldrivetozero.org/tools/zeti/

CDR.fyi. (2025a). 2024 Year in Review . Retrieved from CDR.fyi: https://www.cdr.fyi/blog/2024-year-in-review

CDR.fyi. (2025b). Key Metrics . Retrieved from https://www.cdr.fyi/

China Commercial Vehicles Dealers Association. (2025). Retrieved from https://www.ccvda.cn/

China EV100. (2025). Retrieved from https://www.chinaev100.com/

ChinaIOL. (2025). ChinaIOL . Retrieved from http://www.chinaiol.com/

Crunchbase. (2025). Retrieved from https://data.crunchbase.com/docs/using-the-api

Cullen, J., Allwood, J., &amp; Bambach, M. (2012). Mapping the global flow of steel: from steelmaking to end-use goods. Environ. Sci. Technol. Retrieved from https://doi.org/10.1021/es302433p

EHPA. (2025). European Heat Pump Association . Retrieved from https://ehpa.org/

European Automobile Manufacturers' Association. (2025). ACEA . Retrieved from ACEA: https://www.acea.auto/

European Commission. (2025a). Decarbonising maritime transport - FuelEU Maritime. Retrieved from https://transport.ec.europa.eu/transport-modes/maritime/decarbonisingmaritime-transport-fueleu-maritime\_en

European Commission. (2025b). Retrieved from European Alternative Fuels Observatory: https://alternative-fuels-observatory.ec.europa.eu/

EV Volumes. (2025). Retrieved from EV Volumes: https://ev-volumes.com/

Food and Agriculture Organization of the United Nations. (2025). FAO Stat . Retrieved from https://www.fao.org/faostat/en/#home

| Global Efficiency Intelligence. (2024a). The Scale and Impact of Green Public Procurement of Steel and Cement in Canada, Germany, the UK, and the US . Retrieved from https://www.globalefficiencyintel.com/scale-and-impact-of-green-public-procurement-of- steel-and-cement-in-canada-germany-uk-us   |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Global Efficiency Intelligence. (2024b). Advancing Green Public Procurement of Steel and Cement in China . Retrieved from https://www.globalefficiencyintel.com/green-public- procurement-of-steel-and-cement-in-china                                                                                  |
| Group, C. (2025). Retrieved from https://i3connect.com/                                                                                                                                                                                                                                                 |
| IATA. (2025). Airline Profitability to Strengthen Slightly in 2025 Despite Headwinds . Retrieved from https://www.iata.org/en/pressroom/2025-releases/2025-06-02-01                                                                                                                                     |
| IEA. (2021). The Role of Critical Minerals in Clean Energy Transitions . Retrieved from https://www.iea.org/reports/the-role-of-critical-minerals-in-clean-energy-transitions                                                                                                                           |
| IEA. (2022a). Technology and Innovation Pathways for Zero-carbon-ready Buildings by 2030 Retrieved from https://www.iea.org/reports/technology-and-innovation-pathways-for- zero-carbon-ready-buildings-by-2030/introduction                                                                            |
| IEA. (2022b). Is the biofuel industry approaching a feedstock crunch? Retrieved from https://www.iea.org/reports/is-the-biofuel-industry-approaching-a-feedstock-crunch                                                                                                                                 |
| IEA. (2022c). Achieving Net Zero Heavy Industry Sectors in G7 Members . Retrieved from https://www.iea.org/reports/achieving-net-zero-heavy-industry-sectors-in-g7-members                                                                                                                              |
| IEA. (2023). Energy Technology Perspectives 2023 . Retrieved from https://www.iea.org/reports/energy-technology-perspectives-2023                                                                                                                                                                       |
| IEA. (2024a). Recycling of Critical Minerals . Retrieved from https://www.iea.org/reports/recycling-of-critical-minerals                                                                                                                                                                                |
| IEA. (2024b). The Future of Geothermal Energy . Retrieved from https://www.iea.org/reports/the-future-of-geothermal-energy                                                                                                                                                                              |
| IEA. (2025a). Demand and Supply Measures for the Steel and Cement Transition . Retrieved from https://www.iea.org/reports/demand-and-supply-measures-for-the-steel-and- cement-transition                                                                                                               |
| IEA. (2025b). ETP Clean Energy Technology Guide . Retrieved from https://www.iea.org/data- and-statistics/data-tools/etp-clean-energy-technology-guide                                                                                                                                                  |
| IEA. (2025c). Global EV Outlook 2025 . Retrieved from https://www.iea.org/reports/global-ev- outlook-2025                                                                                                                                                                                               |
| IEA. (2025d). Races to First in Energy Innovation . Retrieved from https://www.iea.org/data- and-statistics/data-tools/races-to-first-in-energy-innovation                                                                                                                                              |
| IEA. (2025e). Renewables 2025 . Retrieved from https://www.iea.org/reports/renewables-2025                                                                                                                                                                                                              |
| IEA. (2025f). Global Energy and Climate Model . Retrieved from https://www.iea.org/reports/global-energy-and-climate-model                                                                                                                                                                              |
| IEA. (2025g). Global Hydrogen Review 2025. Retrieved from https://www.iea.org/reports/global-hydrogen-review-2025                                                                                                                                                                                       |
| IEA. (2025h). World Energy Outlook 2025 . Retrieved from https://www.iea.org/reports/world- energy-outlook-2025                                                                                                                                                                                         |
| IEA. (2025i). The path to a new era for nuclear energy. Retrieved from https://www.iea.org/reports/the-path-to-a-new-era-for-nuclear-energy                                                                                                                                                             |

- IEA. (2025j). Hydrogen Tracker . Retrieved from https://www.iea.org/data-and-statistics/datatools/hydrogen-tracker
- IEA. (2025k). CCUS Projects Database . Retrieved from https://www.iea.org/data-andstatistics/data-product/ccus-projects-database

IEAGHG. (2021a).

Biorefineries with CCS

. Retrieved from https://ieaghg.org/publications/biorefineries-with-ccs/

- IEAGHG. (2021b). IEAGHG Technical Report 2021-05 . Retrieved from https://publications.ieaghg.org/technicalreports/2021-

05%20Global%20Assessment%20of%20Direct%20Air%20Capture%20Costs.pdf

- IMO. (2025a). New sulphur emission limits enter into effect in the Mediterranean. Retrieved from International Maritime Organization:

https://www.imo.org/en/mediacentre/pages/whatsnew-2254.aspx

- IMO. (2025b). IMO approves net-zero regulations for global shipping. Retrieved from International Maritime Organization: https://www.imo.org/en/mediacentre/pressbriefings/pages/imo-approves-netzeroregulations.aspx
- ITP Thermal. (2019). Renewable Energy Options for Industrial Process Heat . Retrieved from https://arena.gov.au/assets/2019/11/renewable-energy-options-for-industrial-processheat.pdf
- JRAIA. (2025). Japan Refrigeration and Air Conditioning Industry Association . Retrieved from https://www.jraia.or.jp/
- Keith, et al. (2018). A Process for Capturing CO2 from the Atmosphere. Retrieved from https://www.sciencedirect.com/science/article/pii/S2542435118302253
- Madeddu et al. (2020). The CO2 reduction potential for the European industry via direct electrification of heat supply (power-to-heat). Environmental Research . Retrieved from https://iopscience.iop.org/article/10.1088/1748-9326/abbd02/pdf
- Marina, A., Spoelstra, S., Zondag, H., &amp; Wemmers, A. (2021). An estimation of the European industrial heat pump market potential. Renewable and Sustainable Energy Reviews . Retrieved from https://www.sciencedirect.com/science/article/pii/S1364032120308297

Marklines. (2025). Information Platform . Retrieved from https://www.marklines.com/en/

- McQueen, N., Gomes, K. V., McCormick, C., Blumanthal, K., Pisciotta, M., &amp; Wilcox, J. (2021). A review of direct air capture (DAC): scaling up commercial technologies and innovating for the future. Retrieved from https://iopscience.iop.org/article/10.1088/25161083/abf1ce
- NETL. (2022). Cost of Capturing CO2 from Industrial Sources . Retrieved from https://www.netl.doe.gov/energy-analysis/details?id=865aaad2-9252-44d9-a48a95599b3072b4
- S&amp;P. (2025). Engineered carbon dioxide removal purchases tracker .
- S&amp;P Global Mobility. (2025). Global New Vehicle Registrations . Retrieved from https://www.marketplace.spglobal.com/en/datasets/global-new-vehicle-registrations(248)
- Schmitt, T., Leptinsky, S., Turner, M., Zoelle, A., White, C. W., Hughes, S., James III, R. E. (2022). Cost and Performance Baseline for Fossil Energy Plants Volume 1: Bituminous Coal and Natural Gas to Electricity. Retrieved from https://www.osti.gov/biblio/1893822

Silver Institute. (2025). Silver Supply and Demand . Retrieved from https://silverinstitute.org/silver-supply-demand/

Taibi, E., Gielen, D., &amp; Bazilian, M. (2010). Renewable Energy in Industrial Applications - An assessment of the 2050 potential. United Nations Industrial Development Organization . Retrieved from https://www.researchgate.net/publication/339948715\_Renewable\_Energy\_in\_Industrial \_Applications\_-\_An\_assessment\_of\_the\_2050\_potential

United Nations Statistics Division. (2025). UN Global Platform - Ship Register . Retrieved from https://unstats.un.org/bigdata/task-teams/ais/index.cshtml

US Department of Energy. (2025). Alternative Fuels Data Center . Retrieved from https://afdc.energy.gov/

US Energy Information Administration. (2021). Manufacturing Energy Consumption Survey . Retrieved from https://www.eia.gov/consumption/manufacturing/data/2018/

US Geological Survey. (2025). Commodity Statistics and Information . Retrieved from https://www.usgs.gov/centers/national-minerals-information-center/commoditystatistics-and-information

World Gold Council. (2024). Gold Demand Trends Q1 2024 . Retrieved from https://www.gold.org/goldhub/research/gold-demand-trends/gold-demand-trends-q12024/supply

WSJ. (2024). Maersk Orders LNG Ships and Takes a Detour on Its Green Goals. Wall Street Journal . Retrieved from https://www.wsj.com/business/earnings/maersk-reports-lowernet-profit-despite-strong-container-shipping-demand-b88540a8

## Part B

## Clean energy technology manufacturing and trade

While the present wave of investment in clean energy technology manufacturing is now falling back, the future trajectory of investment will, in large part, be shaped by  efforts  to  diversify  supply  chains.  Several  governments  are  adopting  an increasingly  defensive  posture  on  clean  energy  technology  trade,  seeking  to shield domestic industries from foreign competition and alleged unfair practices. Nevertheless, trade continues to play a central role in the outlook for manufacturing key clean energy technologies.

Part B of this publication includes an in-depth examination of recent developments in clean energy technology manufacturing and trade (Chapter 4), focusing on the policy changes, project announcements and other developments related to key mass-manufactured  clean  energy  technologies  that  have  taken  place  since ETP-2024 . This forms the foundation for an updated scenario outlook (Chapter 5) for these mass-manufactured technologies, including manufacturing investment, production, capacity and trade flows.

## Chapter 4. Recent trends

## Highlights

-  Global investment in manufacturing capacity for six clean energy technologies solar photovoltaic (PV), wind, batteries, electric vehicles (EVs), electrolysers and heat  pumps  -  dropped  below  USD 200 billion  in  2024,  down  from  nearly USD 220 billion in 2023. This downwards trend is estimated to have continued in 2025, mainly due to weaker solar PV and wind manufacturing investment in China. The United States and the European Union are estimated to have accounted for around 30% of global manufacturing investment combined in 2025, up from 15% in 2023, marginally increasing global supply chain diversification.
-  After dipping in 2024, global trade in clean energy technologies recovered in 2025, with gross imports for relevant product categories reaching an all-time high in the second quarter. This is despite prices for several technologies falling; solar PV module prices have fallen around 50% since 2023 with those for battery packs falling by 30%. China maintains an out-sized role in global trade in clean energy technologies, with its gross exports exceeding USD 165 billion in 2025 (50% of the global total excluding intra-EU trade). This is equivalent to around 15% of its trade surplus across all goods, which was approaching USD 1.2 trillion in 2025.
-  Higher tariffs and duties on clean energy technologies in the United States have contributed to significant increases in domestic production as a share of demand: 40 and 25 percentage points during 2023-2025 for solar PV modules and battery cells respectively. Production tax credits still in place in 2025 and shifting trade patterns  offset  around  half  of  the  estimated  increase  in  average  costs  across imports and domestic production. In other major importing regions, average costs of batteries are estimated to have fallen due to lower global commodity prices.
-  The  manufacturing  project  pipeline  has  contracted  across  most  clean  energy technologies  since  2024.  The  capacity  of  announced  projects  that  have  been completed or cancelled since the last review exceeds that of newly announced projects. This reflects well-supplied markets for several clean energy technologies, notably  for  solar  PV  and  batteries,  and  uncertainty  about  the  pace  of  future deployment.
-  Industry margins have tightened across the board. Solar PV manufacturers have seen margins collapse under intense price competition, notably in China, with the top ten firms posting USD 4.5 billion in losses in 2024. Western wind producers, which  incurred  losses  in  2022-23,  are  beginning  to  recover,  while  profits  at Chinese wind firms are being squeezed by falling prices. Chinese battery makers remain profitable on average thanks to a small number of high performers, but those outside China are struggling to maintain positive margins.

## Global investment and trade

## Overall manufacturing investment and trade

Global investment in manufacturing has experienced substantial growth in recent years and is estimated to have stood at around USD 7.5 trillion per year in 2025. 1 It has more than doubled over the past two decades and, by 2024, was 20% higher than  in  2019  and  4%  up  on  2023.  This  growth  has  been  led  primarily  by  the People's Republic of China (hereafter, 'China'), driven by investment in electrical machinery,  electronic  engineering and  high-tech  goods,  and  India, where investment in consumer durables has almost doubled. Between 2019 and 2024, manufacturing investment increased by 50% in China. The United States also saw strong growth, with investment rising by around 15% over the same period, led by electronics  (including  investment  in  chip  manufacturing  facilities,  but  not  data centres, as these are not manufacturing investments) and agricultural machinery. In contrast, Japan recorded a modest contraction while the European Union saw a 30% decrease.

Following  a  sharp  contraction  in  2020,  the  value  of  global  trade  in  goods  and services rebounded strongly, reaching nearly 7% above pre-pandemic levels by 2024. The recovery was more pronounced in services trade, which stood at more than 8% above 2019 levels in 2024, while goods trade was closer to 6% higher. While the physical volumes of goods trade increased between 2023 and 2024, falling prices in some categories such as fuel reduced the value of trade. Goods trade volume growth has been stronger than expected in 2025, due to surges in imports  ahead  of  the  imposition  of  new  tariffs  and  duties  in  some  advanced economies, supportive fiscal policies and strong growth in emerging markets.

In 2025, a series of new tariffs has raised the cost of imported goods for several countries,  particularly  the  United States.  Accounting  for  tariff  announcements across all goods imports, the volume-weighted announced tariff rate in the United States rose to around 18% - up from around 3% at the end of 2024. Tariffs  on  imports  from  certain  trading  partners,  notably  China  and  India,  are considerably higher.

1 Unless stated otherwise, USD figures are real 2024 dollars in market exchange rate terms throughout this report.

Figure 4.1  Global manufacturing investment, trade and tariffs, 2019-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: e = estimated. Manufacturing investment refers to manufacturing industries within ISIC Rev. 4 Divisions 10-33. T ariff rate values are averages across all goods and trading partners; values for 2025 shown as dashed lines are monthly estimates of the long-run effective rate based on announced policies up to 1 November 2025 for the United States, the European Union and China, not accounting for consumption shifts; data prior to 2025 are annual averages.

Sources: IEA analysis based on UN Trade &amp; Development (2025); Oxford Economics Limited (2025); World Bank (2025); and The Budget Lab (2025).

Global goods trade and manufacturing investment rebounded strongly after the Covid-19 pandemic, but growth has since slowed due to geopolitical and trade policy uncertainties.

Based on announcements as of 1 November 2025, goods imported from China faced  an  average  tariff of around  48%,  down  from  a  mid-April  peak  of approximately 135% (which was threatened but never fully imposed). This was based  on  a  bilateral  agreement  between  the  United States  and  China,  which removed broader tariffs while leaving targeted tariffs, such as Section 232 and 301 tariffs, in place. China responded throughout 2025 with reciprocal tariff increases on  US  imports.  However,  because  US  goods  account  for  a  smaller  share  of Chinese  imports  than  vice  versa,  the  average  rate  across  all  Chinese  imports remained much lower, at around 8% in November 2025. Other major US trading partners  have  launched  public  consultations  on  possible  countermeasures  but have not yet announced formal actions.

## Clean energy technology manufacturing investment

Global investment in facilities to manufacture clean energy technologies has fallen back  recently,  following  several  years  of  rapid  growth  in  response  to  surging deployment. In 2023, investment in plants making six mass-manufactured clean energy technologies - solar PV, wind turbines, EVs and batteries, heat pumps and

electrolysers  (the  focus  of  Part  B)   -  reached  nearly  USD 220 billion,  before 2 declining by 6% to less than USD 200 billion in 2024 (Figure 4.2). For comparison, global investment in oil production the same year was around USD 450 billion. An assessment  of  plants  built  and  under  construction  in  2025  points  to  clean energy technology manufacturing investment continuing a gentle downward trend.

These investments in  manufacturing capacity  are  being  made  in  order  to  gain access to the market for key clean energy technologies, which continues to grow strongly. The size of this market increased by almost 15% globally in 2024, and is expected to have surpassed USD 1.1 trillion in value in 2025, which is roughly equivalent in size to the global market for coal. EVs make up over 75% of the market by value. China remains the largest market globally and has seen average annual  growth  of  around  40%  since  2020,  owing  to  consistently  strong  clean energy  technology  deployment.  Outside  of  China,  developing  economies  are expected to have seen some of the strongest growth rates in 2025, at around 35% on average, in part owing to low-cost imports from China.

Figure 4.2  Global investment in selected clean energy technology manufacturing and global market size by technology and country/region, 2020-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: EVs = electric vehicles; RoW = Rest of World. Batteries and EVs includes anode and cathode active materials, battery cells and electric cars. Solar PV includes polysilicon, wafers, cells and modules. 'Other' includes electrolysers, heat pumps and wind turbines, blades and nacelles.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

The first wave of clean energy technology manufacturing spending has faded; the combined market for these technologies is estimated to have surpassed USD 1.1 trillion in 2025.

2 This  group  of  technologies  and  subsets  thereof  are  referred  to  as  'key  clean  energy  technologies'  throughout  Part  B (Chapters 4 and 5).

In 2024, factories producing batteries and electric cars accounted for more than 75%  of  total  clean  energy  manufacturing  investment,  with  an  increase  by approximately  USD 20 billion  and  USD 10 billion  that  year,  respectively.  This reflects  sustained  demand:  Global  sales  of  electric  cars  continued  to  grow strongly,  exceeding  17 million  in  2024,  and  are  estimated  to  have  reached 21 million in 2025. In contrast, investment in the solar PV supply chain fell by 50% in 2024. This decline was driven by intense price competition and a large overhang of manufacturing capacity, which for modules had increased by 70% in 2023. Wind energy manufacturing investment also saw a downturn, falling from USD 12 billion in 2023 to less than USD 10 billion in 2024. This was largely the result of a difficult market  environment  in  recent  years,  marked  by  supply  chain  disruptions, profitability  pressures  and  auction  rounds for  offshore  wind  farms that  in  some cases failed to attract any bids.

China continues  to  attract  the  majority  of  global  investment  in  clean  energy manufacturing, accounting for around 70% of cumulative spending since 2020. It is  also  associated  with  a  significant  share  of  the  manufacturing  investment occurring in other countries. While a full asset-level dataset for these investments is  not available to this study, the scale of these outward financial flows can be inferred from studies tracking foreign direct investment (FDI). One recent analysis highlights a sharp increase in outbound investment across a range of clean energy technologies, materials and infrastructure (Xue &amp; Larsen, 2025).  It estimates that 3 China's cumulative outbound FDI in these areas reached nearly USD 200 billion between 2022 and the first  half  of  2025  -  roughly  six  times  the  total  over  the preceding 9 years.

Despite China's outsized role in these areas of investment, recent shifts in regional dynamics  indicate  that  the  manufacturing  base  may  be  broadening.  In  the European Union , investment  almost  doubled  from  2023  to  2024,  driven  by industrial policy initiatives such as the Net-Zero Industry Act (NZIA) and the Clean Industrial Deal. These and other measures have boosted domestic demand and expanded  the size of the internal market. Despite this momentum,  EU manufacturers are struggling to compete - particularly for batteries and EVs - with Asian firms, which benefit from lower production costs and greater economies of scale  (see  Chapter  7).  These  pressures,  along  with  difficulties  in  scaling  up production, have led to the cancellation or failure of several EU battery projects (see  below).  Nonetheless,  battery  production  in  the  European Union,  which  is currently  dominated  by  Korean  and  Chinese  companies  operating  within  the region, is expected to have grown in 2025, supported by committed projects and rising EV demand (IEA, 2025c).

3 This estimate does not fully align with the scope of the technologies in this chapter.

A recent slump in EU heat pump demand has led at least one EU manufacturer to postpone  or  cancel  manufacturing  capacity  expansions  that  were  announced during the post-2022 market boom (CoolingPost, 2025). However, others have continued to invest. Panasonic, for example, is expanding its European manufacturing  activities (Panasonic  Group,  2025),  while  Midea  -  another overseas  company  -  is  pursuing  acquisition  and  integration  initiatives  (Midea, 2025).

In the United States , the One Big Beautiful Bill Act was passed into law in July 2025, eliminating several tax credits that support the deployment of clean energy technologies, including the 30D and 45W EV tax credits. The 45X manufacturing tax credits remain largely in place, with the exception of those for wind, which are scheduled  to  expire  after  2027.  However,  uncertainty  persists  around  how strengthened local content requirements and rules around foreign influence will be administered. These uncertainties, together with expectations of weaker domestic demand  for  EVs  following  the  withdrawal  of  the  45W  credits,  have  led  some manufacturers to cancel projects and others to pause investment plans (Clean Investment Monitor, 2025). As a result, US manufacturing investments, which rose from  over  USD 19 billion  in  2023  to  more  than  USD 25 billion  in  2024,  are estimated to have declined by around 15% in 2025. Investment in the EV and battery supply chain - which accounts for the vast majority of total clean energy manufacturing  investment  in  the  United States  -  is  expected  to  have  declined even more sharply.

Several other regions have also seen strong growth in clean energy manufacturing investment.  In Korea ,  investment  in  battery  and  EV  manufacturing  (including upstream  components)  grew  by  25%  in  2024,  reflecting  a  renewed  focus  on industry.  Meanwhile, India 's  total  clean  energy  investment,  spanning  all  major technologies, increased by more than 65% in 2024.

## Clean energy technology trade

International trade statistics for product categories that broadly align with the six technologies covered in this chapter indicate a modest decline of around 6% in the global value of trade in 2024 (Figure 4.3).  Estimates for 2025 based on data 4 for the first three quarters of the year point to a rebound of around 10%. Physical volumes  are  continuing  to  rise  with  falling  unit  prices  (see  below)  and  rapidly growing deployment. In 2024, demand increased by 30% for batteries and 15% for both solar PV and wind turbines (see Chapter 2).

International  trade  remains  vital  to  meeting  global  demand  for  clean  energy technologies. With the exception of China, most countries rely heavily on imports

4 Gross values of trade in monetary units in this publication broadly correspond to those reported in trade statistics.

of technologies, components and materials to meet their rising demand. In 2025, the United States is estimated to have accounted for 15% of global gross imports (20% excluding intra-EU trade), the European Union for 45% (60% excluding intraEU trade),  and  India  for  2%  (also  around  2%  excluding  intra-EU  trade).  Many countries  that  are  net  importers  of  a  given  technology  also  export  significant volumes of another, or of their components. The United States and European Union were the largest gross importers across these product categories,  though  the  United States'  exports  amounted  to  roughly  25%  of  its imports in value terms, while they were closer to 70% for the European Union (excluding intra-EU trade).

Figure 4.3  Gross trade for key clean energy technology product categories, 2017-2025, and imports and exports by region, 2023-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: HS = Harmonised System; EVs = electric vehicles. Values are compiled based on statistical data on the value of trade collected by customs authorities for product categories that best correspond to the six key clean energy technologies examined in Part B of this publication. No data are available for electrolyser trade. Values are stated in gross terms, with no aggregation of individual country data. See IEA (2026) for details of the HS codes used.

Source: IEA analysis based on Sinoimex (2025).

The value of trade in  clean  energy  technologies  fell  by  6%  in  2024,  with  dependence  on imports from China remaining high in all major regions.

EVs saw the second-largest fall in traded value among clean energy technologies in 2024. Nonetheless, taking into account recent US market and policy shifts, they are  estimated  to  have  accounted  for  more  than  50%  of  total  clean  energy technology trade in 2025. Meanwhile, the traded value of solar PV modules saw the largest decline, despite trade volumes remaining stable at around 145 GW in 2023 and 2024. This divergence is largely due to a steep drop in prices, which fell by around 40% over the same period. This trend is expected to continue through 2025, with further price reductions contributing to a decline in the value of trade.

By virtue of its position as the dominant manufacturer, China is by far the largest single exporter of clean energy technologies. Its gross exports were worth about USD 150 billion  in  2024  (around  40%  of  the  global  total;  50%  excluding  intraEU trade), though this was the lowest level since 2022. In 2025, China's exports are estimated to have increased to more than USD 160 billion. This is equivalent to  around  15%  of  its  trade  surplus  across  all  goods,  which  reached  almost USD 1.2 trillion  in  2025.  China's  reliance  on  imports  is  negligible,  as  domestic manufacturing capacity is more than sufficient to meet internal demand. Indeed, domestic capacity far outstrips internal demand, by roughly four times for cathodes and cells, and three times for solar PV modules.

Most other regions are large net importers of clean energy technologies. In the European Union, a strategic push to expand domestic manufacturing has recently reduced reliance on imports. Excluding intra-EU trade, the import-to-export ratio fell  from  1.6  in  2023  to  an  estimated  1.4  in  2025,  driven  largely  by  a  surge  in EV exports to other European countries (including the United Kingdom, Norway, Switzerland  and  Türkiye)  and  the  United States.  Over  the  same  period,  the EU solar  industry  shifted  from  heavy  import  dependence  to  becoming  a  net exporter  in  some  countries  and  parts  of  the  value  chain.  In  the  United States, import and export values are estimated to have decreased by 15-20% in 2025. Although domestic manufacturing capacity is expanding for key components such as cathodes, solar cells, and wafers, it has not kept pace with growing demand. Lower prices have also partially offset rising import volumes.

Low  prices,  a  rapidly  evolving  trade  policy  landscape  and  significant  excess capacity relative to demand globally for some technologies, are among the factors contributing  to  growing  inventories.  Consistent  data  on  inventories  are  not available to this study, but estimates can be made for some technologies:

-  Global production of solar PV modules was around 40% higher than demand in 2023 and around 30% higher in 2024. This has resulted in inventory buildup, especially in Europe and North America, to levels roughly double those of annual installations. This is around eightfold the typical levels that might be expected.  The  gap  between  demand  and  production  appears  to  have narrowed in 2025, due to low prices and mounting financial losses for many producers, which has led to lower shipments. However, given their starting point, inventory levels are expected to have remained elevated in 2025 and continue to remain so thereafter.
-  In  2023,  global  sales  of  Chinese-made electric  cars outside  China  were around 275 000 cars lower than the exports reported by Chinese customs. This led to clogged ports, particularly in Europe and Brazil, and limited the capacity for additional imports in 2024 until excess inventory was cleared. In the first three quarters of 2025, exports outstripped overseas sales by around 350 000  units,  which  is  roughly  two  months'  worth  of  China's  average EV exports. Some Chinese EV manufacturers are reporting inventory levels

exceeding 3 months' worth of sales, compared with a typical industry average of less than 6 weeks (Reuters, 2025a). Global inventories of batteries have also built up to an estimated 20-30% of annual demand during 2024.

## The policy landscape

Government industrial and trade policies play a critical role in driving manufacturing  investment,  with  far-reaching  implications  for  export  potential, import dependence, trade balances and surplus manufacturing capacity. They can shape cost structures  and  help  improve  overall  competitiveness.  While  factors intrinsic to a location, such as access to affordable energy, specialised workforce and finance, remain important, industrial and trade policies, along with broader deployment-oriented measures, can significantly influence costs and capital flows, both directly and indirectly. For instance, policies that promote harmonisation of technical standards, streamline permitting processes and strengthen R&amp;D are vital to the long-term competitiveness and resilience of supply chains.

## Trade policy measures

Since the release of ETP-2024 , there has been a marked increase in the use of trade policy measures  across a broad range of goods, notably by the United States  and  China.  This  follows  decades  of  tariff  liberalisation  under multilateral  and  bilateral  agreements,  and  is  closely  tied  to  wider  policy  goals, including national security, industrial competitiveness and climate objectives. This recent increase in the use of trade policy measures has resulted in a higher tradeweighted average tariff and duty rates on clean energy technologies (Figure 4.4).

While rising tariffs and duties can reduce overall trade flows, the trade-weighted approach reflects the rates actually applied to products that enter the country. This indicates that, despite some degree of trade diversion to avoid higher tariffs and duties,  imported  clean  energy  technologies  are  now  facing  higher  rates  on average.  Tariff  escalation  is  more  pronounced  in  the  United States,  where average  rates  surged  across  all technologies. Solar PV  faced  the  steepest increase, with the announced ad valorem 5 trade-weighted  tariff and  duty rate averaging 169% in 2025 across  all  US  trade  partners  and  peaking  at  315%  for imports from China. EVs also became a major target: US tariffs climbed from zero in  2023  to  an  average  of  34%  across  all  trading  partners,  and  up  to  148%  for China,  the  highest  levied  partner.  Following  the  US-China  trade  and  economic agreement of October 2025, China retained a broad 10% tariff on US goods while suspending its earlier retaliatory duties of 34% (Financial Times, 2025b). Tariff

5 Ad valorem tariffs are duties charged as a percentage of the value of imported goods.

adjustments  elsewhere  were  narrower  in  scope  and  mainly  concentrated  on specific components rather than broad, sector-wide measures.

Figure 4.4 Announced estimated trade-weighted average tariffs and duties on selected clean energy technology imports in key countries and regions, 2023-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: EVs = electric vehicles. 2025e = estimated based on trade data for the first three quarters and the tariffs and duties announced as of 1 November 2025. The bold lines show the trade-weighted average tariff and duty rate applied across all trading partners and all components of a product category (e.g. solar PV includes a trade-weighted average of polysilicon, wafers, cells and modules). The shaded area refers to the range of rates applied across trading partners. See (IEA, 2026) for details of the HS codes used.

Sources: IEA analysis based on World Trade Organization (2025); US National Archives (2025); International Trade Administration (2025b); Office of the United States Trade Representatives (2025); China, Ministry of Finance (2025); European Commission (2025b); Diário Oficial da União [Official Diary of the Union] (2025); Sitharaman (2025); Brown, (2025); Financial Times (2025a); and The White House (2025c).

The weighted-average rate of tariffs and duties applied to clean energy technologies surged in the United States during 2023-2025; rates in other major regions remained relatively flat.

The  United States,  the  European Union  and  Canada  have  introduced  antidumping  duties  (ADDs)  and  countervailing  duties  (CVDs)  on  imports  of  solar panels, wind turbines and EVs. These measures, sometimes directed at specific companies, aim at addressing alleged distortions in trade competition, such as foreign production subsidies and selling below cost. China is the principal target of these actions. These duties, which can be very high, generally function in the same way as regular tariffs, and can significantly impact trade patterns.

A  notable  example  is  the  United States,  which  in  April  2025  concluded  an investigation into alleged non-market practices in the PV cells and module supply chain from Cambodia, Malaysia, Thailand and Viet Nam, and has imposed CVDs exceeding 3 000% on certain firms and countries. These duties are expected to effectively halt imports from the targeted entities altogether. The European Union has also imposed firm-specific CVDs on battery electric car imports from China (excluding  plug-in  hybrids),  ranging  from  17%  to  35%,  coming  into  effect  on 30 October 2024 for a period of 5 years (European Commission, 2024).

## Industrial strategies

As in ETP-2024 , this report's analysis of manufacturing and trade in clean energy technologies incorporates the latest developments in national industrial strategies and  trade  policies.  Key  policies,  including  the  production  tax  credits  for  clean energy  technology  manufacturing  under  the  US  Inflation  Reduction  Act  (IRA), domestic production targets outlined in the European Union's Net-Zero Industry Act  (NZIA)  and  India's  Production  Linked  Incentives  scheme,  remain  in  place. However, some of these measures have been significantly modified, and others have been complemented by new policy initiatives.

For  example,  NITI  Aayog,  a  policy  think  tank  of  the  Government  of  India, recommended  moving  toward  60%  local  sourcing  in  the  wind  sector  in  2024 (Sharma, 2024), a move later reinforced by the Minister of New &amp; Renewable Energy in October 2025, urging the raising of local content levels from around 64% to 85% by 2030, aligning with the government's broader strategy for clean energy self-reliance (Energy World, 2025). Additionally, Japan aims to achieve a domestic procurement ratio of 65% or more by 2040, based on its Offshore Wind Industry Vision 2.0 formulated in August 2025 (Japan, Ministry of Economy, Trade and Industry, 2025). These developments are part of a wider trend towards reinforcing domestic supply chains in the clean energy sector. Meanwhile, the United States has reallocated subsidies under the IRA, notably through the One Big Beautiful Bill, which amends the Advanced Manufacturing Production Tax Credit (45X). The provision immediately terminates 45X credits for wind energy components sold after 31 December 2027, while maintaining a phased reduction for solar, batteries, inverters, and critical minerals through 2032-2033 (US Congress, 2025).

## Table 4.1 Selected industrial and trade policy developments since ETP-2024

| Category            | Policies                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                            |
|---------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Industrial policies | India , wind: >60% local sourcing requirements for key components (JMK, 2025) + reduction of Goods and Services Tax (GST) on renewable energy equipment from 12% to 5% (Government of India, 2025). United States , solar, wind and batteries: One Big Beautiful Bill Act including early rollback of the 45X advanced production manufacturing credits under the IRA (US Congress, 2025). Japan , wind: The Japanese offshore wind industry has set a voluntary target to achieve a 65% domestic procurement ratio by 2040 (Chiba, 2025). European Union 's NZIA has moved to the implementation phase, with secondary legislation being adopted for 'net-zero strategic project' status and mandatory public procurement rules (European Commission, 2025c) . Korea 's Industrial Supply Chain 3050 Strategy (Herh, 2023). Australia 's Battery Strategy (Australian Renewable Energy Agency, 2025) and the Solar |

Note: *The Section 232 car tariffs apply to USMCA non-compliant and non-US value of the content only. **IEEPA tariffs only apply to USMCA non-compliant products from Canada and Mexico.

## Export controls

In  addition  to  the  increase  in  tariff  and  non-tariff  measures,  there  is  a  growing number  of  export  restrictions, particularly on  critical minerals  essential  to manufacturing  clean  energy  technologies.  Within  the  battery  supply  chain,  for example, China accounts for upwards of 60% - and in some cases more than 95% - of manufacturing capacity at each step, from mineral refining to battery production.  Several  energy-related  minerals  face  some  form  of  export  control today, and the restrictions are expanding, not just to raw and refined materials but also to processing technologies, such as those used for lithium and rare earth refining (IEA, 2025b). China also accounts for about 90% of rare earth element refining, and nearly 95% of global permanent magnet production.

Outside of China, in 2025 the Democratic Republic of Congo introduced export restrictions on cobalt, shifting from a ban to quota-controlled exports. In China, the expansion of export controls in 2025 created uncertainty about supply chains for critical materials and clean energy technologies, notably lithium-ion batteries and permanent magnets used in electric motors for EVs and wind turbine generators. A series of policy changes has increased the country's leverage over these highly concentrated supply chains:

-  Graphite: In  October  2023,  China  imposed  export  controls  on  high-purity synthetic  and  natural  graphite,  tightening  them  further  in  December  2024, particularly  for  exports  to  the  United States  (China,  Ministry  of  Commerce, 2023) (China, Ministry of Commerce, 2024). With China producing over 90% of anode active material, these measures pose an acute threat to the stability of  other  countries'  supply.  Graphite-based  anodes  are  indispensable  to lithium-ion batteries, with limited technological alternative today; a shortage of graphite anodes would effectively halt battery production.
-  Rare  earth  elements: In  April  2025,  China  announced  export  controls  on seven  key  rare  earth  elements  and  all  related  compounds,  metals  and magnets (China, Ministry of Commerce, 2025a). This led to a sharp decline in export volumes in April and May, with many carmakers in the United States, Europe and elsewhere reporting difficulties in sourcing permanent magnets, forcing some to cut production or suspend operations (Reuters, 2025b). Trade volumes began to recover from June, soon reaching pre-export control levels.
-  Advanced  lithium  iron phosphate  (LFP)  technologies  and  lithium processing: In  July  2025,  China  updated  its  'Catalogue  of  Technologies Prohibited or Restricted from Export', adding fourth-generation LFP battery and  lithium  processing  technologies  (China,  Ministry  of  Commerce  and Ministry of Science and Technology, 2025). Virtually all LFP battery production is located in China and only a handful of Chinese companies can produce the latest  generation  of  LFP  materials  that  deliver  lower  costs,  longer  driving ranges  and  support  ultra-fast  charging.  As  interest  in  LFP  batteries  grows among automakers  outside  China  seeking  to  reduce  EV  production  costs, several  battery  manufacturers,  led  by  Korean  companies,  are  investing  to

develop LFP production outside of China. However, export restrictions on LFPrelated materials, manufacturing equipment and expertise may hinder or delay these efforts.

-  Broader battery and rare earth element controls: In October 2025, China announced new export controls on rare earth elements and a wide range of battery materials, technologies and equipment (China, Ministry of Commerce, 2025b). They include cathode precursors, broader coverage of LFP materials, nickel-based  cathode  active  materials  and  advanced  technologies  under development, such as batteries exceeding  300 Wh/kg  and  lithium-rich manganese-based cathode materials. These controls also apply to several categories  of  manufacturing  equipment,  including  technologies  previously subject to export restrictions. These measures have been suspended for one year following recent negotiations between China and the United States (The White House, 2025b).

How strictly the latter controls could be enforced remains uncertain. For example, following the announcement of graphite export restrictions in late 2023, exports surged in November ahead of their implementation in December and then fell back to  pre-2022 levels as companies obtained export licences (Figure 4.5). Recent export  restrictions  can  create  uncertainty,  particularly  where  licensing  requires firms to disclose commercially sensitive information and navigate lengthy approval processes. However, negotiation processes and the granting of export licences or case-by-case exemptions enable trade resumption after initial hurdles. As such, these measures tend to reshape trade flows and incur compliance costs rather than resulting in a complete or sustained interruption of supply, although the risk of such disruptions in the future cannot be ruled out.

## Figure 4.5  Monthly gross graphite exports from China, 2022-2025

<!-- image -->

Notes: Graphite includes natural, spherical, and artificial graphite. See (IEA, 2026) for details of the HS codes used. Not all of the exports of these products are destined for lithium-ion battery applications, but batteries account for a significant share of their use. 2025 data is for January to September.

Source: IEA analysis based on data from Sinoimex (2025).

The announcement of graphite export restrictions in late 2023 led to a surge in exports ahead of their implementation and then fell back to pre-2022 levels.

## Impact of higher tariffs on costs and trade patterns

Increases  in  tariffs  generally  raise  the  final  cost  of  clean  energy  technologies, either  directly,  through  duties  on  importing  the  technologies,  or  indirectly,  by increasing the cost of intermediate inputs to domestic production, such as raw materials  and  components.  Assessing  these  effects  is  difficult  because,  unlike market prices, data on manufacturing costs are rarely disclosed for commercial reasons.  Moreover,  many  other  factors  besides  tariff  changes  can  influence manufacturing costs, especially in the short term when inventories of imported technologies and components can offset the impact of tariff increases. The longerterm impact of tariff increases on costs, disregarding the impact of inventories, is estimated using a decomposition analysis (see Figure 4.6). 6

In the United States , rising import costs coincided with increases in the share of domestic production for both solar PV modules and batteries. IRA production tax credits for manufacturing initiated in 2023 - and maintained through 2025 - have been crucial to closing cost gaps between domestic production and imports, and dampening the cost increases that may otherwise be passed onto consumers:

-  US  tariffs  and  duties  on solar  PV  modules increased  over  the  period 2023-2025 for all the major exporters to the United States, during which time the share of supply met by domestic production increased from around 15% to around half. Tariffs and duties would have increased the average delivered costs (i.e. the weighted average cost across domestic production and imports after tariffs  have been imposed) by nearly 200%, around half of which was offset by shifts in trade patterns. The most important shift was the increase in domestic  production, where  the  IRA  production tax credits make  the US production cost among the lowest in the world). A shift in the role played by different trading partners also dampened the impact of the tariff increases on delivered costs. Countries in Southeast Asia that were subject to CVDs and ADDs are estimated to have seen a reduction in their combined share in total US imports from more than four-fifths in 2023 to about half in 2025. The main sources of supply to fill the gap were Indonesia, primarily, and then India.

6 A decomposition analysis was performed using the IEA MaT model to illustrate the contribution and interaction of three key categories of cost factors: First, changes in the prices of input materials and components (including the indirect impact of tariffs on imports thereof) that impact the cost of both imports and domestic production. Second, changes in trade patterns, including substitution between imports and domestic production, which impact the average delivered cost by changing the source of imports (i.e. changes in trading partners) and the share of imports vs. domestic production. Third, changes in tariffs and duties (including ADDs and CVDs) that impact the cost of importing the technology. Tariffs are imposed on costs as opposed  to  prices,  which  is  an  approximation.  Two  selected  periods  that  saw  rapid  tariff  increases  across  two  key technologies are used - 2023-25 for solar PV modules and 2024-25 for lithium-ion batteries - to examine the impact across three key importing countries/regions: the United States, the European Union and India. The analysis disregards inventories of technologies and components that were imported before tariffs came into effect, which would likely dampen the immediate impact on cost increases.

-  The  average  delivered  cost  of battery  cells in  the  United States  during 2024-25 was also subject to counteracting forces: on the one hand, tariffs and duties pushed up producer costs, and on the other, an increase in the share of  demand being met by domestic production that was eligible for financial support  (increasing  from  almost  60%  to  70%)  pushed  them  down.  The additional factor that had a non-negligible impact for battery cells was changes in material  and  component  prices:  whereas  prices  for  critical  minerals, cathodes and anodes declined globally during this period, increases in tariffs and duties on these inputs in the United States raised their costs. The increase in the average rate of tariffs and duties on lithium-ion batteries - from nearly 25% in 2024 to almost 70% for imports from China in 2025 - has the larger impact,  contributing to  an  estimated rise  of  more  than  15%  in  the  average delivered  cost.  The  net  impact  of  the  input  price  changes,  shifts  in  trade patterns  and  tariff  and  duty  increases  was  an  almost  10%  increase  in  the delivered cost.

Figure 4.6  Estimated changes in average delivered costs and domestic production as a share of demand for solar PV modules in selected importing countries and regions, 2023-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: 2025e = estimated based on trade data for the first three quarters. The average cost in 2025 reflects the full impact of tariffs and duties announced as of 1 November 2025, without accounting for use of stockpiles of earlier imports. Delivered costs refer to the weighted average unit cost of supply, including both domestic production and imports, with the latter including tariff and transport costs. Costs presented are inclusive of explicit financial support mechanisms in industrial strategies, such as the production tax credits in the US Inflation Reduction Act. The increase in component costs due to tariffs and duties is included in 'Material price changes'.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

The impact of US tariffs and duties on costs for imported solar PV module and components has contributed to driving up domestic production and average delivered costs.

The European Union maintains relatively low levels of tariffs and duties on most goods,  including  clean  energy  technologies,  of  which  it  is  the  largest  importer globally. The region has benefited from falling global prices for most technologies, materials and components in recent years. Domestic demand for clean energy technologies remains strong, drawing on some domestic production. However, a lack of any systematic financial support mechanisms, together with high energy and labour costs, mean that the region remains among the most expensive for manufacturing most clean energy technologies:

-  Average  delivered  costs  of solar  PV  modules in  the  European Union  are estimated to have increased by around 20% during the period 2023-25. This is partly due to slight increases in global prices for key input materials (e.g. aluminium, silver), but mostly because of a slight increase in the share of its domestic production, of around 4 percentage points between 2023 and 2025. There is not an obvious cost incentive underpinning this small increase, but consumer preferences and project-level domestic procurement requirements are thought to explain the shift.
-  Global prices for input materials and components for battery cell production have fallen sharply during the period 2023-25, after reaching historic highs in 2022. For example, lithium prices at the start of 2024 were about 80% lower than at the beginning of 2023. In early 2025, prices declined by a further 35% compared with early 2024, reaching similar prices to those at the end of 2015, despite global demand having expanded six-fold between 2015 and 2024 and seeing continued growth in 2025. Material price declines contribute nearly half of the nearly 10% decline in average delivered cost of battery cells estimated for  the  European Union  during  2025.  The  remaining  cost  decline  is  mostly attributable to minor shifts in sourcing across trading partners, with a slight increase  in  the  proportion  sourced  from  China  (the  lowest-cost  producer globally). The European Union's domestic production is also becoming more cost-effective over  time  as  its manufacturing  efficiency  increases  (see Chapter 7).

India 's  average  delivered  costs  for  solar  PV  modules  and  battery  cells  have followed  a  similar  trajectory  to  those  of  the  European Union  during  the  recent period of global tariff and duty increases: the cost of the former is estimated to have  decreased  by  10%  during  2023-25  and  the  latter  by  almost  6%  during 2024-25e. India's goods imports were already subject to relatively high tariffs and duties before 2023, and various rates (e.g. including the most favoured nation or 'MFN'  rate)  for certain groups  of products  have  continued  their gradual downwards trajectory  in  recent  years.  Tariffs  and  duties  on  solar  PV  modules decreased  on  average  by  17  percentage  points,  which  is  estimated  to  have contributed a nearly 4% decline in average delivered costs, whereas the rest of the decrease stems from increased domestic production, which is cheaper when tariffs and duties are taken into account.

Figure 4.7  Estimated changes in average delivered costs and domestic production as a share of demand for battery cells in selected importing countries and regions, 2023-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: 2025e = estimated based on trade data for the first three quarters. The average cost in 2025 reflects the full impact of tariffs and duties announced as of 1 November 2025, without accounting for use of stockpiles of earlier imports. Delivered costs refer to the weighted average unit cost of supply, including both domestic production and imports, with the latter including tariff and transport costs. Costs presented are inclusive of explicit financial support mechanisms in industrial strategies, such as the production tax credits in the US Inflation Reduction Act. The increase in component costs due to tariffs and duties is included in 'Material price changes'.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Lower prices for battery materials and components globally and production efficiency gains drove costs down, except in the United States, where tariffs and duties increased costs.

## Manufacturing project pipelines

The global pipeline of  announced projects for manufacturing key clean energy technologies  provides  a  useful  indicator  of  shifts  in  investor  sentiment  and progress in expanding manufacturing capacity. The latest data compiled for ETP2026 show  that  the  project  pipeline  has  contracted  since  the  assessment conducted  for ETP-2024 (Figure  4.8).  For  most  technologies,  the  capacity  of previously announced projects that have either been completed or cancelled since the last review exceeds that of newly announced projects (Table 4.2). This trend reflects  a  comfortable  level  of  capacity  relative  to  current  demand,  as  well  as uncertainty about the pace of future technology deployment (see Chapter 5).

Figure 4.8  Global manufacturing project pipelines in 2030 for selected clean energy technologies by edition of Energy Technology Perspectives

<!-- image -->

IEA. CC BY 4.0.

Notes: ETP = Energy Technology Perspectives. Capacities are annual. Announced capacity to 2030 refers to all announcements, both committed and preliminary. ETP-2023 was published in January 2023 featuring assessed announced projects as of November 2022. The cutoff point for ETP-2024 was June 2024 and, for ETP-2026 , it is November 2025. Battery deployment includes all EV types and stationary storage. The results for wind manufacturing are not directly comparable across editions due to methodological changes in underlying data sources.

Sources: IEA analysis based on data from Benchmark Mineral Intelligence (2024); BNEF (2025); EV Volumes (2025); InfoLink (2025); S&amp;P Global (2025); UN Comtrade (2025) and announcements by manufacturers and personal communications.

Existing manufacturing capacity remains comfortably above current demand for all key clean energy technologies but planned capacity expansions are slowing.

## Solar PV

Planned additions to solar PV module manufacturing capacity declined sharply in 2025 . Many  planned  projects  have  already  come  online,  while manufacturers scaled back expansion plans slightly in response to low utilisation rates at existing plants and weaker earnings prospects. The capacity additions that remain  in  the  pipeline  mostly  relate  to  the  replacement  of Passivated  Emitter  Rear Contact (PERC) module production with more efficient Tunnel Oxide Passivated  Contact  (TOPCon)  modules.  Planned capacity  for  other  designs,  such  as  Heterojunction  Technology  (HJT)  or  Back Contact (BC) cells, has held steady or increased marginally.

Figure 4.9  Clean energy manufacturing installed capacity and project pipelines to 2030 by technology, stage and country and region

## Solar PV modules

## Wind nacelles

IEA. CC BY 4.0.

<!-- image -->

Notes: Committed = projects that have reached a final investment decision (FID) or are under construction. Preliminary =

projects that have not yet reached an FID. The areas of the pie charts are proportional to the capacity level. Sources: IEA analysis based on data from UN Comtrade (2025): S&amp;P Global (2025); BNEF (2025); Wood Mackenzie (2025); InfoLink (2025); Benchmark Mineral Intelligence (2024); EV Volumes (2025) as well as announcements by manufacturers and personal communications, gathered by the IEA.

China dominates the clean technology manufacturing project pipelines for 2030 across all technologies apart from heat pumps.

Rapid capacity growth in recent years has contributed to steep declines in module prices, intensifying financial pressure on manufacturers. Current utilisation rates at module factories stand at 57%; they could produce up to 1.1 TW per year if utilisation  increased  to  85%  -  about  double  the  540 GW  of  solar  PV  capacity additions  in  2024.  In  parallel,  the  scale  of  individual  projects  has  increased enormously: Jinko Solar's new PV module plant in Shanxi, with a planned capacity of  56 GW could alone almost meet the annual demand of the European Union (Shaw &amp; Thompson, 2024).

In China,  which  accounts  for  80%  of  global  solar  PV  module  production, intensifying price competition is further dampening industry expectations. In July 2025,  for  instance,  Zhejiang  Bangjie  Holding  Group  Co.  cancelled  its  planned 16 GW cell factory in the Jiangshan Economic Development Zone, citing changing market conditions. LONGi has also suspended plans for a 15 GW module plant in

Wuhu for 18 months due to income uncertainty. As a result, around half of planned capacity additions to 2030 are now located outside of China, mainly in India and the United States, though they are small relative to current capacity in China.

Across the sector, firms are under growing pressure to scale up or innovate in order  to  remain  competitive  in  a  well-supplied  market.  Governments  are  also increasingly  aware  of  the  global  capacity  overhang.  In  July  2025,  Chinese authorities  announced  plans  to  address  overcapacity  in  the  solar  PV  sector, aiming to curb price wars and rebalance the market. This mirrors announcements made by the Chinese authorities during the same month, cautioning the Chinese EV industry against unsustainably low pricing strategies and inventory-clearing practices, which are seen as contributing to unhealthy levels of competition within the sector and raising concerns about long-term market stability (China, Ministry of Industry and Information Technology, 2025).

Table 4.2 Notable  clean  energy  technology  manufacturing  project  cancellations, delays and shutdowns since June 2024

| Company                            | Location                | Description                                                                                                                                                                 |
|------------------------------------|-------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Solar PV                           | Solar PV                | Solar PV                                                                                                                                                                    |
| Zhejiang Bangjie Holding Group Co. | Zhejiang, China         | Plans announced in July 2025 to scrap a 16 GWn-type cell factory and subsequent 16 GWwafer factory, due to changing market conditions (Shaw & Thompson, 2024) (Shaw, 2025). |
| LONGi                              | Wuhu, China             | 18-month delay to LONGi's 15 GWPV module factory reported in December 2024, citing income uncertainty (Bloomberg, 2024).                                                    |
| 3Sun                               | Inola, United States    | 3 GWPV modules plant placed on hold in October 2024 due to financial uncertainties regarding the IRA (Alliance News, 2024).                                                 |
| Risen                              | China                   | Decision to delay a 10 GWmodule factory announced in August 2024, citing supply chain disruption (Bhambhani, 2024).                                                         |
| Risen                              | China                   | Decision to delay 5 GWHJT PV cells factory in August 2024, citing supply chain disruption (Bhambhani, 2024).                                                                |
| Meyer Burger                       | Goodyear, United States | Closure of solar cell plant with 1.4 GWcapacity in May 2025 due to financing problems (Meyer Burger, 2025).                                                                 |
| Wind                               | Wind                    | Wind                                                                                                                                                                        |
| LM Wind Power, (GE Vernova)        | Suape, Brazil           | Closure of a blade factory in Suape (employing 1 000 people) announced in February 2025, due to weak demand in the Latin American market (Chetwynd, 2025).                  |
| Siemens Gamesa                     | Esbjerg, Denmark        | Plans for new offshore nacelle factory put on hold in October 2025, citing market conditions (Ivanova, 2025).                                                               |
| Vestas                             | Szczecin, Poland        | Plans for a new blade factory suspended in October 2025 due to weaker than expected demand in Europe (Vachkova, 2025).                                                      |

| Company                | Location                 | Description                                                                                                                                                           |
|------------------------|--------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Batteries              | Batteries                | Batteries                                                                                                                                                             |
| Northvolt              | Skellefteå, Sweden       | In November 2024 and March 2025, Northvolt filed for restructuring in the United States (Northvolt, 2024) and Sweden (Northvolt, 2025).                               |
| Svolt                  | Überherrn, Germany       | Factory with 24 GWh capacity cancelled in October 2024 due to weak EV demand in Europe (Randall, 2024).                                                               |
| Freyr                  | Georgia, United States   | 34 GWh factory cancelled in February 2025 due to unfavourable market conditions and strategic realignment (Maisch, 2025).                                             |
| Kore Power             | Buckeye, United States   | 12 GWh battery manufacturing plant cancelled in February 2025 (Colthorpe, 2025).                                                                                      |
| Stellantis             | Belvidere, United States | Plan for 34 GWh battery plant cancelled in June 2025 (Avila, 2025).                                                                                                   |
| Electrolysers          | Electrolysers            | Electrolysers                                                                                                                                                         |
| Green Hydrogen Systems | Skive, Denmark           | Key assets being acquired by Nucera as of June 2025, following failure to restructure or find a buyer (Markosyan, 2025).                                              |
| Nel                    | Herøya, Norway           | Production at 1 GWalkaline electrolyser plant suspended in January 2025 due to sluggish market (Collins, 2025).                                                       |
| Heat Pumps             | Heat Pumps               | Heat Pumps                                                                                                                                                            |
| Bosch                  | Dobromierz, Poland       | Planned EUR 280 million facility that would have created 500 jobs by 2027 suspended in September 2025 due to weak sales and policy uncertainties (CoolingPost, 2025). |

## Wind turbines

The  already  modest  project  pipeline  for  wind  component  manufacturing  has contracted  in  several  producing  regions.  Investments  for  new  wind  turbine factories are typically announced only when a final investment decision (FID) is very close, so the pipeline is much smaller than for solar PV, though it tends to be more stable. Global installed manufacturing capacity stood at around 285 GW at end-2024, compared with 130 GW of deployment during that year.

In several regions, political and policy-related uncertainty is also weighing on the outlook  for  demand.  For  example,  LM,  part  of  GE  Vernova,  closed  its  blade manufacturing plant in Suape, Brazil, in early 2025, citing weak regional demand. In the United States, political opposition to wind power, along with a prolonged pause in offshore wind permitting, has added to market uncertainty (see Chapter 2).  However,  given  the  limited  number  of  wind  manufacturing investment announcements in the United States in recent years, changes to the manufacturing pipeline are expected to be more modest than changes in demand. The  European Union  saw  two  cancellations  related  due  to  lower-than-expected demand for offshore wind energy.

## Batteries

The battery manufacturing project pipeline has contracted slightly since the last assessment in ETP-2024 due to uncertain demand prospects and low utilisation of installed capacity. Yet the combined total of existing and announced capacity is almost 20% higher than the levels assessed in ETP-2023 , with installed capacity more than tripling over that period. Over 800 GWh of manufacturing capacity was commissioned in 2024, and about 1.3 TWh is estimated to have been added in 2025.  If  all  announced  projects  were  to  proceed,  total  global  capacity  would increase more than 2.5 times, reaching over 9.5 TWh. For comparison, battery deployment in 2024 - including for EV sales and stationary storage installations was about 1.1 TWh.

How much of this announced capacity will materialise is uncertain, as projects may be  shelved  amid  intensifying  competition.  In  China,  battery  demand  remains strong,  but  fierce  domestic  competition,  significant  surplus  capacity  and  the increasing  use  of  international  trade  restrictions  are  compressing  margins  and putting pressure on smaller, less efficient producers (Reid, 2025).

In the European Union, battery manufacturing is going through a defining moment (IEA, 2025d). While the pipeline of battery manufacturing projects remains robust, albeit mostly led by Asian companies, cost pressures and a rising preference for LFP batteries, which are currently produced solely by Chinese firms, is putting increasing  pressure  on  domestic  and  Korean-owned  facilities  operating  in  the region. The bankruptcy of Sweden's Northvolt - Europe's largest investment in a domestic  battery  manufacturer  -  underscores  the  difficulties  faced  by  new entrants (Northvolt, 2025).

In the United States, declining battery demand linked to reduced EV sales - driven in part by the phase-out of the USD 7 500 consumer 30D tax credit available under the IRA - raises the risk that factories may operate below the levels required for profitability. Quarterly data on US investments shows a marked decline of battery manufacturing investment in the first three quarters of 2025 (Clean Investment Monitor, 2025).

## Electrolysers

Electrolyser  project  announcements  remain  substantial,  but  their  viability  is increasingly uncertain. If all projects were realised, global manufacturing capacity would total nearly 190 GW in 2030. However, most of these projects have not reached  FID.  For  around  65 GW  of  planned  capacity,  the  target  date  for completion  has  not  been  confirmed  and  could  be  pushed  back  as  market conditions evolve.

Existing  manufacturers  are  already  encountering  difficulties,  as  demand  for electrolytic  hydrogen  remains  weaker  than  anticipated  at  the  beginning  of  this

decade  (IEA,  2025e).  In  early  2025,  for  instance,  Norwegian  electrolyser manufacturer  Nel  suspended  production  of  alkaline  electrolysers  at  its  facility, citing unfavourable market conditions (Collins, 2025). As of June 2025, the Danish electrolyser manufacturer Green Hydrogen Systems had filed for bankruptcy, and its  intellectual  property  and  test  site  were  acquired  by  Thyssenkrupp  Nucera (Markosyan, 2025). Persistently low utilisation rates across existing electrolyser manufacturing facilities - averaging around 10% globally - risk pushing up capital costs. At such low utilisation rates, CAPEX costs could be six to eight times higher than if capacity were utilised at 80%, which is thought to be close to the upper end of what is feasible (see Chapter 7).

## Heat pumps

The  project  pipeline  for  heat  pumps  has  declined  since  2024.  Most  of  the previously  announced  expansion  plans  focused  on  increasing  manufacturing capacity in Europe, where demand saw an unprecedented surge from 21 GW in 2021 to 32 GW in 2022. However, following a sharp downturn in 2023 and 2024 during which European heat pump sales fell by 25% - many manufacturers chose to pause or postpone their expansion plans.

This trend should be interpreted with caution. Outside Europe, most manufacturers  do  not  typically  announce  capacity  increases.  This  is  partly because expanding heat pump manufacturing is generally less complex than for many other clean energy technologies. As a result, such projects are often not announced  far  ahead  of  time,  especially  by  original  equipment  manufacturers (OEMs) for whom heat pumps constitute only a small part of a broader product portfolio. In most cases, manufacturers can adjust and scale up their production lines  in  response  to  rising  demand  without  the  need  for  extensive  forward planning.

## Prices and profitability

Profitability  is  critical  to  sustaining  investment  in  new  manufacturing  capacity. Beyond enabling capital returns to shareholders, healthy profit margins are vital for funding ongoing R&amp;D, process innovation and capacity expansion - activities that  drive  efficiency  improvements  and  reduce  system  costs.  They  are  also important for downstream industries, such as grid equipment manufacturers, who must balance investment in long-lived, capital-intensive assets with shorter-term market  fluctuations,  and  can  bolster  the  resilience  of  supply  chains  against geopolitical risks and price shocks.

In recent years, profitability in clean energy technology manufacturing has been volatile,  largely  due  to  sharp  fluctuations  in  both  market  prices  and  the  costs associated with building, operating and maintaining production facilities. Over the past 10 years, global average prices for solar PV modules, battery packs and wind

turbines have  declined  steeply  -  by  approximately  90%,  80%  and  50%, respectively (Figure 4.10). Prices for these technologies are heavily influenced by three key factors: supply-demand dynamics (including the impact of overcapacity), trade policy measures such as tariffs (which contribute to regional price variations) and  production  cost  reductions  driven  by  technological  innovation,  process improvements, economies of scale and changes in input costs, particularly for critical minerals.

Figure 4.10 Average prices for solar PV modules, onshore wind turbines and battery packs in selected countries and regions, 2015-2025e

<!-- image -->

Note: Data for 2025 is estimated.

Source: IEA analysis based on data from BNEF (2025).

Solar PV and battery costs have dropped sharply due to innovation, scale and competition, while onshore wind costs have fallen in China but stagnated elsewhere, widening price gaps.

## Solar PV

Solar PV has experienced the most dramatic price declines among clean energy technologies in recent years. In China, the European Union and Japan, the current price of a solar PV module is now around one-tenth of what it was in 2015. US prices remain higher than in other major markets, largely due to trade measures, including tariffs  on  imported  solar modules and cells, and ADDs and CVDs on imports  from  China  and  Southeast  Asia.  Economies  of  scale,  innovation  and commoditisation  have  significantly  reduced  manufacturing  costs.  One  clear example is the sharp drop in material intensity: the amount of polysilicon required per watt of module capacity has fallen by 87% since 2004. However, falling prices resulting  from  excess  capacity  have  reduced  profitability,  triggering  cyclical investment behaviour, with periods of over-expansion being followed by market consolidation.

Solar PV manufacturers have historically maintained profitability, as evidenced by EBIT margins, which measure operating profit as a share of revenue. From 2015 to 2023, the largest publicly listed solar companies maintained an average EBIT margin of around 10% - a similar margin to those recorded by the world's top 500 publicly traded manufacturing companies over the same period. 7  However, solar margins took a sharp downward turn in 2024. Sectoral performance is heavily influenced by Chinese firms, which account for seven of the ten largest companies by revenue. In response to oversupply, many of these firms adopted aggressive pricing  strategies,  contributing  to  a  steep  decline  in  market  prices.  In  contrast, North American firms, which make up a much smaller share of global production, were somewhat shielded from these pressures due to a more protected domestic market.

Figure 4.11 Profit margins of companies producing selected clean energy technologies by country of company headquarters, 2015-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: Based on earnings before interest and tax (EBIT) margins, which measure operating profit as a share of revenue. Margins are weighted by revenue in each region to calculate the average for the rest of the world. Companies are categorised according to their regional headquarters. Solar PV includes polysilicon, wafer, cell and module production. Covers publicly listed companies only. Includes companies representing 65% of the global market for solar PV, 80% for wind and 65% for batteries. Data for 2025 is up to June 2025.

Source: IEA analysis based on S&amp;P Global (2025).

Historically, Chinese clean energy technology manufacturers have been the most profitable, owing to low-cost inputs, economies of scale and public financial support.

Historically, vertically integrated companies have generally outperformed component-specific firms, as their ability to offset losses in one segment of the value chain with profits in another has supported more stable margins (IEA, 2022).

7 Defined as companies falling under the Nomenclature of Economic Activities (NACE) code C - Manufacturing, with revenue and EBIT data available.

This model helped some Chinese manufacturers weather earlier price declines. However, by 2024, even this approach was not enough to combat falling prices, with the top ten Chinese solar PV manufacturers collectively reporting more than USD 4.5 billion in EBIT losses.

## Wind turbines

Wind turbine prices show the widest regional variation among the leading clean energy technologies, reflecting a mix of structural and market factors. Chinese manufacturers  benefit  from  a  mature  domestic  supply  chain,  a  large  and expanding home market with many competing firms, and substantial economies of scale. Low-cost upstream inputs such as steel and magnets based on rare earth elements are available domestically, thanks to large government subsidies and persistent excess manufacturing capacity. By contrast, the European Union and the United States face higher costs, with inflationary pressures and a smaller pool of manufacturers contributing to higher prices and less competition. In addition, the size and weight of wind turbine components, particularly blades and towers, means  that  shipping  accounts  for  a  large  share  of  delivered  costs,  further increasing the price of imported equipment.

The wind industry has experienced significant volatility in recent years, particularly in North America and the European Union. Supply chain disruptions and delivery delays have created major operational difficulties in those regions, undermining profitability. The rising cost of components and raw materials, exacerbated by high inflation, has further eroded profitability. While 2022 was the worst year in recent history for most western companies, the poor performance of other manufacturers in 2023  further  reduced  the  global  weighted  average  margin.  Collectively, companies  outside  of  China  for  which  data  is  available  recorded  EBIT  losses totalling over USD 5 billion in 2023.

In Europe, persistent inflation in the wake of the Covid-19 pandemic has pushed up material costs and caused delays in both manufacturing and installation. The failure to index turbine prices to inflation has further compressed margins, resulting in  operating  losses  in  both  2022  and  2023.  However,  manufacturers  in  the European Union have shown signs of recovery over the past 2 years, with 2024 marking a turning point, driven by higher selling prices and improved margins. At the same time, companies in North America are struggling to turn a profit, most recently due to delays in completing offshore wind projects.

In contrast, Chinese manufacturers secured their largest set of orders in 2023, totalling  more  than  100 GW  (WoodMackenzie,  2024),  yet  the  top  five  Chinese manufacturers by revenue reported EBIT profits of only USD 200 million. Margins were squeezed as domestic turbine prices fell more rapidly than production costs amid intense competition and provincial efforts to meet their renewable energy

targets by end-2025 (Climate Cooperation China, 2022). Following this period of rapid price declines, Chinese manufacturers agreed to halt further price cuts, a move that appears to have supported a modest recovery in profitability (Energy Watch, 2024).

## Batteries

Prices of battery packs continue to decline. Lithium-ion (Li-ion) batteries remain the dominant technology, thanks to consistent cost reductions along the supply chain  and  steady  performance  improvements.  Within  the  Li-ion  category,  LFP batteries  have  gained  significant  market  share  in  both  mobility  and  stationary storage applications, largely due to their lower costs and rapid adoption in China. LFP batteries now power half of all global EV sales and account for over 90% of new stationary storage installations, driven primarily by rapid deployment in China, but with increasing uptake in advanced economies and other emerging markets and developing economies (IEA, 2025c).

Technological  advancements  have  also  shifted  the  cost  structure  of  batteries, increasing the proportion of raw material costs in the total cost. As a result, battery prices have become more sensitive to fluctuations in the prices of critical minerals. Since  2023,  expansions  in  supply,  particularly  from  China,  Indonesia  and  the Democratic Republic of the  Congo,  have  helped  bring  down the  prices of  key battery metals, easing some of the pressure on overall battery costs (IEA, 2025a).

Battery companies have faced intense competition over the past decade, but the largest players have managed to maintain profitability. In 2024, China's largest battery producer,  CATL,  reported  its  highest-ever  EBIT  profits, exceeding USD 8.5 billion - over ten times the combined profits of the next three Chinese battery  firms.  Other  Asian  battery  producers  remain  profitable,  though  at  a considerably lower level than China's CATL. The largest firms based in Japan and Korea  posted  a  combined  EBIT  profit  of  just  over  USD 1 billion  in  2024,  with margins similar to most Chinese manufacturers.

Non-Chinese manufacturers - particularly those in Europe and the United States, where many Korean and Japanese firms operate - typically have lower economies of scale and higher production costs. In Europe, costs are estimated to be around 50% higher than in  China,  significantly  hampering  their  competitiveness,  while manufacturers in the United States can compete only thanks to IRA tax credits. Upstream in the battery supply chain, margins for battery component producers primarily  Chinese  and  Korean  -  are  also  under  considerable  pressure.  The revenue-weighted average EBIT margins for the largest anode and cathode active material producers have fallen from their respective peaks - from over 15% in 2021 to 7% in 2024 for anodes and from over 15% in 2017 to less than 3% in 2025 for cathodes.

## Research and development

As the market for clean energy technologies continues to expand rapidly and price competition  becomes  more  intense,  manufacturers  and  governments  have  a bigger incentive to innovate to improve their competitiveness. R&amp;D is a critical driver of innovation, with the potential to generate returns many times greater than the initial investment. Sustained investment in R&amp;D today is essential to driving productivity  gains  in  the  future.  Such  innovation  can  take  many  forms,  from improving  manufacturing  efficiency  and  optimising  material  use,  to  developing new technologies or chemistries that lead to better-performing products. However, R&amp;D spending must be carefully balanced against a company's cash flow, as the returns often take years to materialise. Both public and corporate energy R&amp;D spending has risen in recent years, by around 6% per year in real terms over 2015-23 (IEA, 2025f).

Manufacturers often prioritise two broad categories of innovation: cost leadership and  product  differentiation.  Focusing  on  product  differentiation  often  involves greater risk and higher costs than achieving gains through incremental improvements  in  manufacturing  processes.  For  example,  in  2024  the  largest pharmaceutical firms by revenue had R&amp;D-to-revenue ratios of around 20%, while in the automotive industry this was closer to 4%. This reflects the pharmaceutical sector's reliance on a steady pipeline of new products to replace expiring patents, in  contrast  to  automotive  firms,  which  primarily  compete  through  incremental efficiency and production improvements.

Across clean energy technologies, batteries exhibit the highest weighted average R&amp;D-to-revenue  ratio,  at  around  6%  between  2015  and  2025,  compared  with roughly 3% for both solar PV and wind. This likely stems from different innovation strategies, with battery firms pursuing product differentiation by investing in LFP and nickel manganese cobalt (NMC) cathodes, as well as the development of new battery designs, such as solid-state and sodium-ion batteries. Over the past five years, Chinese firms have maintained consistently higher R&amp;D ratios than their Korean peers.

By  contrast,  solar  PV  manufacturers  have  primarily  focused  on  incremental improvements to existing silicon-based cell technologies - such as shifting from PERC to TOPCon and HJT - rather than a fundamental shift in cell chemistry, though development of perovskite, thin-film and other emerging technologies is continuing.  In  the  wind  industry,  turbine  sizes  have  increased  steadily,  with average  onshore  wind  turbine  rotor  diameters  growing  by  around  70%  and average power capacity almost tripling over the last decade. Yet the underlying components  remain  broadly  similar,  with  innovation  being  driven  more  by advances in materials and manufacturing logistics than by radical technological breakthroughs.

Figure 4.12 R&amp;D spending to revenue ratio for selected clean energy technologies, 2015-2025e

<!-- image -->

Notes: Covers publicly listed companies only. Average line is weighted by revenue. Solar PV includes polysilicon, wafer, cell and module production. The companies included in this analysis represent 65% of the global market for solar PV, 65% for wind and 60% for batteries. 2025 values are estimates based on data up to June 2025.

Source: IEA analysis based on S&amp;P Global (2025).

Battery manufacturers spend proportionately more on R&amp;D than solar PV and wind firms.

## Government financial incentives

Government subsidies can play an important role in reducing production costs and improving profitability, but measuring their impact is inherently complex, largely due  to  the  difficulty  of  quantifying  the  benefits  associated  with  different  policy instruments. Grants are relatively straightforward to assess when disclosed, but tax incentives and below-market financing require building counterfactual scenarios to estimate the actual cost differential. The OECD undertakes this work: its  Manufacturing  Groups  and  Industrial  Corporation  (MAGIC)  (OECD,  2025) database provides key inputs to the IEA's MaT model used for the supply chains analysis in this and previous editions of the ETP.

Assessing support is further complicated by the diversity of support mechanisms used  across  regions  and  technologies.  China  employs  a  combination  of  tax concessions, grants and concessional financing across the solar PV, wind and automotive sectors, with concessional finance particularly prevalent in wind, and grants more prominent in automobiles. By contrast, the United States has leaned heavily on tax incentives, especially for solar PV and wind manufacturing, primarily under the 2022 IRA. Although the IRA was revised in 2025 under the One Big Beautiful Bill Act, the overall scale and distribution of support for the manufacturing of many clean energy technologies has remained largely unchanged. However, tax credits for EVs ended in September 2025 and wind and solar manufacturing incentives are due to expire after 2027. This change is already having tangible effects,  with  several  polysilicon,  wafer  and  cell projects  cancelled  following  the introduction  of  the  bill.  In  comparison,  the  European Union  has  provided  less

support for wind and automotive, while support for solar PV - particularly through grants - has fallen since the early 2010s, in line with the decline of its domestic industry.

Figure 4.13 Average rate of financial support as a share of corporate revenue for selected clean energy technology manufacturing industries by country or region, 2005-2024

<!-- image -->

IEA. CC BY 4.0.

Notes: In the United States, high levels of below-market loans to the automotive sector are a result of lending during and following the 2008-09 financial crisis. Tax concessions received under the US Inflation Reduction Act are recorded as financial grants by some companies in their financial statements and are categorised as such for all companies here. Source: OECD (2025).

China provides the most financial support in absolute terms, but US and EU support for solar PV manufacturers is at a similar level to China's in proportion to revenue.

In aggregate across all three sectors, China has consistently provided the highest levels of government support to clean energy technologies (Figure 4.13). At times, support relative to revenue from the United States and European Union has been even higher than China's for some clean technologies, albeit for much shorter durations and for much smaller manufacturing bases. Recent policy measures in the United States, notably the IRA, have significantly increased its support levels for solar PV, while the European Union had the highest relative levels of support at the beginning of the 2010s. In the last decade, the absolute scale of support has been much higher in China, as the industries have much higher revenues. Financial support has generally been larger for solar PV module producers than for wind turbine manufacturers, with the notable exception of China, where the wind sector has benefited from substantial below-market loans. In the automotive

sector,  encompassing  both  EV  and  internal  combustion  engine  manufacturing, support in China is more evenly distributed across different policy instruments.

The  MAGIC  database  represents  a  major  step  forward  in  tracking  industrial subsidies,  but  it  does  not  capture  all  forms  of  government  support.  Some channels,  such  as  preferential  regulatory  treatment  or  export  restrictions  on upstream  inputs  that  can  lower  financial  and  input  costs,  are  only  partially reflected. Others, such as the provision of energy or land at below-market prices, are  inherently  difficult  to  quantify,  despite  offering  potentially  significant  cost advantages  to  firms.  This  inevitably  incomplete  picture  makes  it  harder  to distinguish genuine productivity-driven advantages from those arising from policyinduced  distortions,  both  domestically  and  internationally.  The  estimates  of financial support presented here should therefore be considered as a lower-bound indication.

## References

Alliance News. (2024). Enel keeps 3Sun USA on hold and waits for elections . Retrieved from Market Screener: https://www.marketscreener.com/quote/stock/ENEL-S-P-A70935/news/Enel-keeps-3Sun-USA-on-hold-and-waits-for-elections-48149269/

Australian Government. (2025). Pioneering Aussie solar tech to kickstart $1bn Solar Sunshot program . Retrieved from https://www.dcceew.gov.au/about/news/pioneering-aussiesolar-tech-kickstart-1bn-solar-sunshot-program

Australian Renewable Energy Agency. (2025). Battery Breakthrough Initiative . Retrieved from https://arena.gov.au/funding/battery-breakthrough-initiative/

Avila, L. (2025). Stellantis scraps plans for Illinois battery plant, parts hub: UAW. Automotive Dive . Retrieved from https://www.automotivedive.com/news/stellantis-uaw-belvidereassembly-battery-plant/749830/

Benchmark Mineral Intelligence. (2024). Benchmark Minerals Lithium Ion Battery Gigafactory Assessment . Retrieved from https://www.benchmarkminerals.com/

Bhambhani, A. (2024). Risen Energy Delays Manufacturing Projects; Posts Net Loss in H1 2024. Taiyang News . Retrieved from https://taiyangnews.info/business/risen-energydelays-manufacturing-projects-posts-net-loss-in-h1-2024

Bloomberg. (2024). Longi Delays Solar Module Plant in China as Sector Struggles . Retrieved from Energy Connects: https://www.energyconnects.com/news/renewables/2024/dece mber/longi-delays-solar-module-plant-in-china-as-sector-struggles/

BNEF. (2025). Data service . Retrieved from https://about.bnef.com/

Brown, C. P. (2025). Trump's trade war timeline 2.0: An up-to-date guide. PIIE . Retrieved from https://www.piie.com/blogs/realtime-economics/2025/trumps-trade-war-timeline20-date-guide

Chetwynd, G. (2025). GE Vernova closing wind blade factory with 1,000 jobs to go. ReCharge . Retrieved from https://www.rechargenews.com/wind/ge-vernova-closingwind-blade-factory-with-1-000-jobs-to-go/2-1-1777552

Chiba, D. (2025). Japan to raise local content target for offshore wind farms to 70%. Nikkei Asia . Retrieved from https://asia.nikkei.com/business/energy/japan-to-raise-localcontent-target-for-offshore-wind-farms-to-70

China, Ministry of Commerce. (2023). Announcement No. 39 of 2023 of the General Administration of Customs of the Ministry of Commerce on Optimizing and Adjusting Temporary Export Control Measures for Graphite Items . Retrieved from https://www.mofcom.gov.cn/zcfb/blgg/art/2023/art\_f6b1bc49e2c8482f8eb749012bc66d ec.html

China, Ministry of Commerce. (2024). Announcement No. 46 of 2024 Announcement on Strengthening Export Controls on Relevant Dual-Use Items to the United States . Retrieved from https://www.mofcom.gov.cn/zwgk/zcfb/art/2024/art\_3d5e990b43424e60 828030f58a547b60.html

China, Ministry of Commerce. (2025a). Announcement No.18 of 2025 of The Ministry of Commerce and The General Administration of Customs of The People's Republic of China Announcing the decision to implement export control on some medium and heavy rare earth related items . Retrieved from https://english.mofcom.gov.cn/Policies/AnnouncementsOrders/art/2025/art\_0dd87cbee 7b045bf93fabe6ab2faceee.html

China, Ministry of Commerce. (2025b). Announcement No. 58 of 2025 announced the decision to implement export controls on items related to lithium batteries and artificial graphite anode materials . Retrieved from https://www.mofcom.gov.cn/zwgk/zcfb/art/2025/art\_79646f0161564975a938fe00fee158 d5.html

- China, Ministry of Commerce and Ministry of Science and Technology. (2025). Announcement No. 28 of 2025 Announcement on the adjustment and issuance of the "Catalogue of China's Prohibited and Restricted Export Technologies" . Retrieved from https://fms.mofcom.gov.cn/zcfg/jsjckzcfg/art/2025/art\_ba35a101c22c4f6e844f749cb0a9 8552.html

China, Ministry of Finance. (2025). The State Council Tariff Commission announced adjustments to tariffs on imported goods originating from the United States . Retrieved from https://gss.mof.gov.cn/gzdt/zhengcejiedu/202505/t20250513\_3963685.htm

China, Ministry of Industry and Information Technology. (2025). The Ministry of Industry and Information Technology and other departments held a symposium on the new energy vehicle industry to deploy work to further standardize the competitive order of the new energy vehicle industry . Retrieved from https://www.miit.gov.cn/xwfb/bldhd/art/2025/art\_3d4d963739924503872222a3a2a54c7 7.html

Clean Investment Monitor. (2025). The State of US Clean Energy Supply Chains in 2025 . Retrieved from https://www.cleaninvestmentmonitor.org/

Climate Cooperation China. (2022). China released its 14th Five-Year Plan for Renewable Energy with quantitative targets for 2025 . Retrieved from https://climatecooperation.cn/climate/china-released-its-14th-five-year-plan-forrenewable-energy-with-quantitative-targets-for-2025/

Collins, L. (2025). Nel temporarily halts hydrogen electrolyser manufacturing at flagship 1 GW

factory in Norway.

Hydrogen Insight

. Retrieved from https://www.hydrogeninsight.com/electrolysers/nel-temporarily-halts-hydrogen-

electrolyser-manufacturing-at-flagship-1gw-factory-in-norway/2-1-1763764

Colthorpe, A. (2025). US BESS startup KORE Power no longer building Arizona cell gigafactory. Energy Storage News . Retrieved from https://www.energystorage.news/us-bess-startup-kore-power-no-longer-building-arizona-cell-gigafactory/

CoolingPost. (2025). Bosch halts Polish heat pump factory plans . Retrieved from https://www.coolingpost.com/world-news/bosch-halts-polish-heat-pump-factory-plans/

Diário Oficial da União [Official Diary of the Union]. (2025). Imprensa Nacional [National Press] . Retrieved from https://www.in.gov.br/leiturajornal

Electrive. (2025a). Turkey introduces new car tariffs. Retrieved from https://www.electrive.com/2025/09/22/turkey-introduces-new-car-tariffs/

Electrive. (2025b). Brazil's import tariffs on EVs moved forward . Retrieved from https://www.electrive.com/2025/08/01/brazil-accelerates-tariff-hike-on-disassembled-evimports/#:~:text=Brazil%E2%80%99s%20foreign%20trade%20committee%2C%20Gec ex-

Camex%2C%20has%20announced%20an,the%2035%25%20import%20tax%20forwar d%20by%2018%20months

Energy Watch. (2024). Chinese wind OEMs sign pact to end price war . Retrieved from https://energywatch.com/EnergyNews/Renewables/article17545173.ece

| Energy World. (2025). Joshi urges wind industry to raise local content to 85% from 64% by 2030. 1. Retrieved from https://energy.economictimes.indiatimes.com/news/renewable/indias-wind-energy- industry-urged-to-boost-local-content-to-85-by-2030/124979542                                                             |
|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| European Commission. (2024). EU Commission imposes countervailing duties on imports of battery electric vehicles (BEVs) from China. Retrieved from https://trade.ec.europa.eu/access-to-markets/en/news/eu-commission-imposes- countervailing-duties-imports-battery-electric-vehicles-bevs-china                          |
| European Commission. (2025a). Joint Statement on a United States-European Union framework on an agreement on reciprocal, fair and balanced trade. Retrieved from https://policy.trade.ec.europa.eu/news/joint-statement-united-states-european-union- framework-agreement-reciprocal-fair-and-balanced-trade-2025-08-21_en |
| European Commission. (2025b). Publications Office of the European Union . Retrieved from https://op.europa.eu/en/                                                                                                                                                                                                          |
| European Commission. (2025c). The Net-Zero Industry Act . Retrieved from https://single- market-economy.ec.europa.eu/industry/sustainability/net-zero-industry-act_en#net- zero-strategic-project-status                                                                                                                   |
| EV Volumes. (2025). Global Electric Vehicle Sales Data, Market Trends & Forecasts You Can Trust . Retrieved from https://ev-volumes.com/                                                                                                                                                                                   |
| Financial Times. (2025a). Russia imposes fees to stem flood of low-cost Chinese cars . Retrieved from https://www.ft.com/content/48cb143e-03ce-4e23-bc6a-7e47d673f1d8                                                                                                                                                      |
| Financial Times. (2025b). Markets tumble as China announces 34% retaliatory tariffs on US import. Retrieved from https://www.ft.com/content/84fe4e66-74ef-4517-8733- 2c84f77ea3b7                                                                                                                                          |
| Government of Canada. (2025). Canada's response to U.S. tariffs on Canadian goods . Retrieved from https://www.canada.ca/en/department-finance/programs/international- trade-finance-policy/canadas-response-us-tariffs.html Government of India. (2025). GST Reforms Power India's Green Transition. Press                |
| Information Bureau , https://www.pib.gov.in/PressReleasePage.aspx?PRID=2167486&reg=3&lang=2#:~:text =The%20rationalization%20of%20GST%20rates,farmers%2C%20industries%2C%20a nd%20developers                                                                                                                               |
| Herh, M. (2023). Korean Gov't to Lower Dependence on Specific Countries for Advanced Materials, Components. Business Korea . Retrieved from https://www.businesskorea.co.kr/news/articleView.html?idxno=207805                                                                                                             |
| IEA. (2022). Special Report on Solar PV Global Supply Chains. Retrieved from https://www.iea.org/reports/solar-pv-global-supply-chains                                                                                                                                                                                     |
| https://www.iea.org/reports/global-critical-minerals-outlook-2025 IEA. (2025b). With new export controls on critical minerals, supply concentration risks                                                                                                                                                                  |
| IEA. (2025a). Global Critical Minerals Outlook 2025 . Retrieved from                                                                                                                                                                                                                                                       |
| become reality . Retrieved from https://www.iea.org/commentaries/with-new-export- controls-on-critical-minerals-supply-concentration-risks-become-reality                                                                                                                                                                  |
| IEA. (2025c). Global EV Outlook 2025 . Retrieved from https://www.iea.org/reports/global-ev- outlook-2025                                                                                                                                                                                                                  |

- IEA. (2025d). The battery industry has entered a new phase . Retrieved from https://www.iea.org/commentaries/the-battery-industry-has-entered-a-new-phase

IEA. (2025e).

Global Hydrogen Review 2025

. Retrieved from https://www.iea.org/reports/global-hydrogen-review-2025

IEA. (2025f). The State of Energy Innovation . Retrieved from https://www.iea.org/reports/thestate-of-energy-innovation

- IEA. (2026). Manufacturing and Trade Model Documentation. Retrieved from https://www.iea.org/reports/manufacturing-and-trade-model

InfoLink. (2025). InfoLink Consulting . Retrieved from https://www.infolink-group.com/

International Trade Administration. (2025b). International Trade Administration . Retrieved from https://www.trade.gov/

- Ivanova, T. (2025, 10 24). Siemens Gamesa halts nacelle factory project in Denmark . Retrieved from Renewables Now: https://renewablesnow.com/news/siemens-gamesahalts-nacelle-factory-project-in-denmark-1283852/
- Japan, Ministry of Economy, Trade and Industry. (2025). Retrieved from https://www.meti.go.jp/shingikai/enecho/denryoku\_gas/saisei\_kano/yojo\_furyoku/pdf/03 7\_03\_00.pdf
- JMK. (2025). India Pushing for Wind Turbine Manufacturing Indigenization . Retrieved from https://jmkresearch.com/indias-latest-push-for-a-holistic-domestic-wind-turbinemanufacturing-market/
- Maisch, M. (2025). Freyr cancels $2.6 billion gigafactory in Georgia, sells site . Retrieved from https://www.ess-news.com/2025/02/10/freyr-cancels-2-6-billion-gigafactory-in-georgiasells-site/
- Markosyan, M. (2025, 09 02). Nucera closes buy of bankrupt Danish electrolyser maker GHS assets . Retrieved from Renewables Now: https://renewablesnow.com/news/nuceracloses-buy-of-bankrupt-danish-electrolyser-maker-ghs-assets-1281040/

Meyer Burger. (2025).

- Meyer Burger shuts down solar module production and lays off 282 employees in the U.S. Retrieved from https://www.meyerburger.com/cs/newsroom/artikel/meyer-burger-shuts-down-solarmodule-production-and-lays-off-282-employees-in-the-us

Midea. (2025, February). Midea Completes Acquisition of ARBONIA climate . Retrieved from https://mbt.midea.com/global/news/midea-completes-acquisition-of-arboniaclimate.mobile.mobile

Northvolt. (2024). Northvolt takes major actions to support and enhance homegrown battery production platform . Retrieved from https://northvolt.com/articles/chapter11/

Northvolt. (2025). Northvolt files for bankruptcy in Sweden . Retrieved from https://northvolt.com/articles/northvolt-files-for-bankruptcy-in-sweden/

OECD. (2025). How governments back the largest manufacturing firms . Retrieved from https://www.oecd.org/en/publications/how-governments-back-the-largestmanufacturing-firms\_d93ed7db-en.html

Office of the United States Trade Representatives. (2025). Office of the United States Trade Representatives . Retrieved from https://ustr.gov/

Oxford Economics Limited. (2025). Global Industry Service . Retrieved from https://www.oxfordeconomics.com/service/subscription-services/industries/globalindustry-service/

Panasonic Group. (2025, August). Panasonic officially started operations at the new building in its Czech factory, a production site for Air-to-water heat pumps . Retrieved from https://news.panasonic.com/global/press/en250829-4

Randall, C. (2024). SVOLT confirms cancellation of its Saarland plans . Retrieved from https://www.electrive.com/2024/10/28/svolt-confirms-cancellation-of-its-saarland-plans/

Reid, M. (2025). China's overcapacity: Will its battery industry consolidate? CRU . Retrieved from https://www.crugroup.com/en/communities/thought-leadership/2025/chinasovercapacity-will-its-battery-industry-consolidate/

Reuters. (2025a). Exclusive: BYD slows production, delays capacity expansion at China factories, sources say . Retrieved from https://www.reuters.com/business/autostransportation/byd-slows-production-delays-capacity-expansion-china-factoriessources-say-2025-06-25/

Reuters. (2025b). China's rare earth export curbs hit the auto industry worldwide . Retrieved from https://www.reuters.com/business/autos-transportation/some-european-autosupplier-plants-shut-down-after-chinas-rare-earth-curbs-2025-06-04/

- S&amp;P Global. (2025). Commodity Insights . Retrieved from https://www.spglobal.com/commodity-insights/en

Sharma, Y. S. (2024). NITI Aayog proposes a minimum 60% local sourcing requirement by value for wind energy plants. The Economic Times . Retrieved from https://economictimes.indiatimes.com/industry/renewables/niti-aayog-proposes-aminimum-60-local-sourcing-requirement-by-value-for-wind-energyplants/articleshow/111754690.cms

Shaw, V. (2025). Chinese PV industry Brief: Zhejiang Bangjie drops 18 GW factory plan. Retrieved from https://www.pv-magazine.com/2025/07/18/chinese-pv-industry-briefzhejiang-bangjie-scraps-plans-to-build-18-gw-solar-factory/

Shaw, V., &amp; Thompson, V. (2024). Chinese PV Industry Brief: JinkoSolar breaks ground on 56 GW solar factory . Retrieved from https://www.pvmagazine.com/2024/03/29/chinese-pv-industry-brief-jinkosolar-breaks-ground-on-56gw-pv-panel-factory-in-shanxi/

Sinoimex. (2025). Global Trade &amp; Industry Growth Lab . Retrieved from https://www.sinoimex.com/en/index

Sitharaman, N. (2025). Budget 2025-2026 . Retrieved from https://static.pib.gov.in/WriteReadData/specificdocs/documents/2025/feb/doc20252149 3201.pdf

The Budget Lab. (2025). The Fiscal and Economic Effects of the Revised April 9 Tariffs . Retrieved from https://budgetlab.yale.edu/research/fiscal-and-economic-effects-revisedapril-9-tariffs

The White House. (2025a). Amendments to adjusting imports of automobiles and automobile parts into the United States . Retrieved from https://www.whitehouse.gov/presidentialactions/2025/04/amendments-to-adjusting-imports-of-automobiles-and-automobileparts-into-the-united-states/

The White House. (2025b). Fact Sheet: President Donald J. Trump Strikes Deal on Economic and Trade Relations with China . Retrieved from https://www.whitehouse.gov/factsheets/2025/11/fact-sheet-president-donald-j-trump-strikes-deal-on-economic-andtrade-relations-with-china/

The White House. (2025c). Briefings &amp; Statements. Retrieved from https://www.whitehouse.gov/briefings-statements/

The White House. (2025d). Fact Sheet: President Donald J. Trump Imposes Tariffs on Imports from Canada, Mexico and China . Retrieved from https://www.whitehouse.gov/fact-sheets/2025/02/fact-sheet-president-donald-j-trumpimposes-tariffs-on-imports-from-canada-mexico-and-china/

The White House. (2025e). Fact Sheet: President Donald J. Trump Increases Section 232 Tariffs on Steel and Aluminum . Retrieved from https://www.whitehouse.gov/factsheets/2025/06/fact-sheet-president-donald-j-trump-increases-section-232-tariffs-onsteel-and-aluminum/

The White House. (2025f). Adjusting Imports of Medium- and Heavy-Duty Vehicles, Medium and Heavy-Duty Vehicle Parts, and Buses into the United States. Retrieved from https://www.whitehouse.gov/presidential-actions/2025/10/adjusting-imports-of-mediumand-heavy-duty-vehicles-medium-and-heavy-duty-vehicle-parts-and-buses-into-theunited-states

The White House. (2025g). Further Modifying the Reciprocal Tariff Rates . Retrieved from https://www.whitehouse.gov/presidential-actions/2025/07/further-modifying-thereciprocal-tariff-rates/

The White House. (2025h). Fact Sheet: President Donald J. Trump Implements A Historic U.S.-Japan Framework Agreement. Retrieved from https://www.whitehouse.gov/factsheets/2025/09/fact-sheet-president-donald-j-trump-implements-a-historic-u-s-japanframework-agreement/

The White House. (2025i). Joint Fact Sheet on President Donald J. Trump's Meeting. Retrieved from https://www.whitehouse.gov/fact-sheets/2025/11/joint-fact-sheet-onpresident-donald-j-trumps-meeting-with-president-lee-jae-myung/

UN Comtrade. (2025). UN Comtrade Database . Retrieved from https://comtradeplus.un.org/

UN Trade &amp; Development. (2025). Merchandise: Total trade and share . Retrieved from https://unctadstat.unctad.org/datacentre/dataviewer/US.TradeMerchTotal

United Kingdom, Department for Business and Trade. (2025). General terms for the United States of America and the United Kingdom of Great Britain and Northern Ireland Economic Prosperity Deal . Retrieved from https://assets.publishing.service.gov.uk/media/681d327d43d6699b3c1d2a9d/US\_UK\_E PD\_050825\_FINAL\_rev\_v2.pdf

US Congress. (2025).

H.R.1 - One Big Beautiful Bill Act

. Retrieved from https://www.congress.gov/bill/119th-congress/house-bill/1

US National Archives. (2025). Federal Register . Retrieved from https://www.federalregister.gov/

Vachkova, R. (2025, 10 22). Vestas halts project for Polish wind blade factory - report . Retrieved from Renewables now: https://renewablesnow.com/news/vestas-haltsproject-for-polish-wind-blade-factory-report-1283652/

Wood Mackenzie. (2025). Wind Supply Chain Service . Retrieved from https://www.woodmac.com/lens/lens-wind/

WoodMackenzie. (2024). Record highs for global wind turbine order intake in 2023 . Retrieved from https://www.woodmac.com/press-releases/2024-press-releases/record-highs-forglobal-wind-turbine-order-intake-in-2023

World Bank. (2025). Indicators . Retrieved from https://data.worldbank.org/indicator

World Trade Organization. (2025). WTO Tariffs &amp; Trade Data https://ttd.wto.org/en

. Retrieved from

Xue, X., &amp; Larsen, M. (2025). China's Green Leap Outward: The rapid scale-up of overseas Chinese clean-tech manufacturing investments. Net Zero Industrial Policy Lab . Retrieved from https://static1.squarespace.com/static/64ca7e081e376c26a5319f0b/t/68c09417468c29 75452a39d1/1757451287251/PB+-11+China+Low+Carbon+FDI-vf.pdf

## Chapter 5. Outlook for manufacturing and trade

## Highlights

-  Due  to  a  large  overhang  of  manufacturing  capacity  for  several  clean  energy technologies - notably solar PV and batteries - the investment in manufacturing capacity needed to keep pace with global demand in the Stated Policies Scenario (STEPS) over the next decade is just 40% of the historic peak in 2023. Despite recent increases in tariffs and duties in some countries, trade remains central to meeting rising demand, with the value of global net trade over the next decade rising to more than double that of 2024.
-  China's net exports of clean energy technologies more than double to 2035 in the STEPS, at which point they are around four-fifths of the combined value of crude oil export revenues across OPEC countries in 2025. Despite this, several countries reduce their dependence on Chinese imports in relative terms at certain steps in the value chain - particularly downstream. EU net imports of battery cells from China drop from around half of domestic demand levels in 2025 to around a quarter by 2035. Dependency on Chinese cathode imports jumps from around 15% to 45% over the same period; for anodes it remains at today's elevated levels of around 75%.
-  China remains by far the largest producer of solar PV modules and components in the STEPS, though its market share declines somewhat. It supplies over 70% of projected global module demand in 2030 (compared with 80% in 2024) and more than 80% of upstream wafer and polysilicon (90% in 2024). India sees the biggest increase in global market share, rising from 3% in 2024 to 10% in 2030 and 12% in  2035,  and  becomes  a  net  exporter  by  2030.  The  policies  in  place  in  the United States lead to near-self-sufficiency for modules by 2030.
-  Several emerging economies are playing a growing role in the global wind supply chain. Nacelle and blade exports account for about 20% of India's production in 2035, mainly serving Asia Pacific and European markets. Brazil is projected to export 10% of its nacelle production and 30% of blade production to other Latin American countries. North Africa, particularly  Morocco,  is  emerging  as  a  blade manufacturing hub, supplying around 5% of EU wind imports by 2035.
-  The  share  of  domestic  electric  vehicle  (EV)  demand  met  by  imports  in  the European  Union  remains  below  one-third  in  the  STEPS,  with  China  supplying around 70% of these imports in 2035, up from 60% in 2024, despite countervailing duties (or equivalent measures) being maintained. The North American car market remains virtually closed to Chinese imports due to even higher tariff and duty rates. The US project pipeline for battery cell manufacturing is sufficient to supply local demand through to 2030 in view of weaker projected demand.

## Global trends

This chapter sets out projections of manufacturing activity and inter-regional trade for clean energy technologies to 2035 under two scenarios: the Stated Policies  Scenario  (STEPS)  and  the  Net  Zero  Emissions  by  2050  Scenario (NZE Scenario). 1 These projections are derived from the IEA's Manufacturing and Trade (MaT) model, which simulates investment, production and trade by technology through global optimisation of production and trade costs [see IEA (2026) for more information].

The analysis  in  this  chapter  focuses  primarily  on  the  STEPS,  reflecting  the substantial changes to industrial and trade policy since ETP-2024 . Two major sources  of  uncertainty  shape  the  outlook:  potential  future  shifts  in  policy  including  tariffs  and  other  trade  measures  -  and  the  trajectory  of  demand. These are explored through sensitivity analysis of alternative policy assumptions and modelling of a range of deployment levels (see Box 5.1).

## Box 5.1 Deployment uncertainty in context

While deployment for clean energy technologies grows in all IEA scenarios, a key source of uncertainty in this outlook for manufacturing and trade stems from the extent to which it does so. IEA modelling scenarios embody a wide range of future deployment levels for the key clean energy technologies in focus in Part B of this ETP (Figure 5.1).

The Current Policies Scenario (CPS), which sets out a pathway for the future of the  energy  system  in  which  no  change  in  energy-related  policies  is  assumed beyond what is already in place, constitutes the lower bound of deployment in all cases for these technologies. Deployment levels in the STEPS, which also takes account of those policies that have been formally tabled but not yet adopted, are 25% higher for solar PV than in the CPS by 2035; 15% higher for wind; 20% higher for EVs and over 20% higher for batteries. In the NZE Scenario, deployment levels are substantially higher for these four technologies: 120-170% higher than in the CPS and 80-135% higher than in the STEPS by 2035.

Existing and announced manufacturing capacity levels help put this deployment uncertainty in context. For solar PV modules, for example, there is enough existing and committed announced (i.e. those facilities that have reached a final investment

1 See the Introduction for a detailed description of the scenarios.

decision  (FID)  or  are  under  construction)  capacity  to  supply  deployment  levels across all IEA scenarios, even when considering a maximum practical utilisation rate of 85%  of nameplate capacity and 2035  deployment  levels in the NZE Scenario.  While  that  is  not  the  case  for  other  key  technologies  like  EVs, battery cells and wind nacelles (nor it is true for several of these technologies' components), there is ample existing and committed announced capacity to meet the deployment levels in both the CPS and the STEPS to 2030.

Figure 5.1 Global demand by scenario and capacity of existing and announced projects for key clean energy technologies, 2024-2035

<!-- image -->

Notes: CPS = Current Policies Scenario; STEPS = Stated Policies Scenario; NZE Scenario = Net Zero Emissions by 2050 Scenario.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

## Manufacturing investment

In  the  STEPS,  which  reflects  government  policies  and  measures  already  in place  or  under  active  development,  global  investment  in  clean  technology manufacturing is projected to continue to decline through to 2035. After peaking at nearly USD 220 billion  in 2023, investment in manufacturing capacity for the 2 six key clean energy technologies - solar PV, wind turbines, EVs and batteries, electrolysers and heat pumps - dropped to just under USD 200 billion in 2024. It  then  averages  around  USD 145 billion  per  year  over  2026-30  and  drops below USD 50 billion per year over 2031-35 (Figure 5.2). EVs and batteries see the  largest  decline  in  absolute  terms,  though  solar  PV  sees  the  steepest percentage drop. This downturn reflects exceptionally high recent investment, especially  in  solar  PV,  which  has  resulted  in  global  manufacturing  capacity being more than sufficient to meet projected demand to 2035, reducing the need for new plants. Between 2026 and 2035, nearly all investment goes to EVs and batteries.

<!-- image -->

Figure 5.2 Global annual average investment in clean energy technology manufacturing in the Stated Policies Scenario and Net Zero Emissions by 2050 Scenario, 2024-2035

<!-- image -->

Notes: STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario; RoW = Rest of World. Investment for 2026-30 and 2031-35 refers to annual averages. Batteries and EVs includes anode and cathode active materials, battery cells and electric cars. Solar PV includes polysilicon, wafers, cells and modules. Other includes electrolysers, heat pumps, and wind turbine blades, towers and nacelles.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Manufacturing investment diversifies geographically over time, with emerging economies making in-roads after 2030 in the STEPS and even more so in the NZE Scenario.

2 Unless stated otherwise, USD figures are real 2024 dollars in market exchange rate terms throughout this report.

The faster clean energy technology deployment projected in the NZE Scenario requires a very different investment trajectory. Near-term investment remains close to peak levels, reflecting the stronger policy support and higher demand required to align with a 2050 net zero pathway. Over 2026-30, average annual spending remains just under USD 200 billion - close to the 2023 high - before declining in 2031-35. It nonetheless remains far above the levels in the STEPS across  all  major  technologies.  Compared  with  the  STEPS,  investment  in 2031-35 is over four times higher for EVs and batteries, three times higher for heat pumps and more than ten times higher for wind. For instance, EV sales in 2035 in the NZE Scenario are nearly double those in the STEPS, sustaining elevated battery demand and driving higher investment along the EV supply chain.

Investment in clean energy technology manufacturing shifts decisively away from the People's Republic of China (hereafter, 'China') in both scenarios. In the STEPS, China's share of global investment in new and refurbished factories for producing the six technologies drops from 65% in 2024 to around 45% in 2030 and little less than 30% in 2035, largely reflecting energy, industrial and trade policies in other regions. The European Union sees the biggest increase, with its share rising from over 10% in 2024 to nearly 30% by 2035. This growth is driven by long-term demand certainty underpinned by ambitious EV targets, and  industrial  policies  such  as  the  Net-Zero  Industry  Act  (NZIA),  which  is considered in the STEPS. This outlook depends on the timely completion of committed projects, which generally face higher production costs than in other regions, and on maintaining ambitious deployment policies and targets. China continues  to  leverage  its  ample  existing  capacity  and  remains  the  largest producer in the STEPS, with its share of global output of these technologies declining only slightly, from around 60% in 2024 to 45% in 2035.

In the NZE Scenario, an even bigger share of investment flows to emerging markets  and  developing  economies  (EMDEs)  other  than  China  -  20%  in 2026-35, compared with close to 10% in the STEPS. This scenario assumes these  economies  can  overcome  investment  barriers,  implement  effective policies,  build  industrial  capacity  and  develop  the  necessary  skills.  Many EMDEs  also  benefit  from  improved  access  to  raw  materials,  affordable renewable energy and large workforces, creating strong potential to develop clean technology manufacturing (IEA, 2024b) (IEA, 2024a).

## Production and trade

Building  on  this  foundation,  EMDEs  scale  up  production  of  clean  energy technologies across nearly all segments by 2035 in both scenarios, with a much faster expansion projected in the NZE Scenario. In the STEPS, countries with an  established  industrial  base,  such  as  an  automotive  sector,  see  clean technology manufacturing beginning on a significant scale only in the 2030s;

for those with minimal industrial capacity today, it starts after 2040. EVs remain the  leading  technology  by  production  value  in  both  scenarios,  with  EMDEs increasing their share of global production of all technologies, particularly EVs and wind. In the NZE Scenario, EMDEs excluding China increase their share of  production  of  EVs  from  1%  in  2024  to  nearly  25%  in  2035,  while  they increase their wind manufacturing share from less than 20% to over 50%.

Figure 5.3 Estimated output value from clean technology manufacturing by technology in the Stated Policies Scenario and Net Zero Emissions by 2050 Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario; EMDE = emerging markets and developing economies.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

EMDEs other than China scale up production of clean energy technologies rapidly to 2035 in both scenarios, with a much faster expansion projected in the NZE Scenario.

International trade remains a central component in meeting rising demand for clean  energy  technologies  in  both  scenarios,  as  manufacturing  capacity continues to be concentrated in China and a small number of other countries and demand is much more dispersed. In the STEPS, average annual global trade in 2035 is more than double that of 2024, while in the NZE Scenario it is more than six times higher (Figure 5.4).  China's position as a net exporter of 3 clean energy technologies strengthens in absolute terms in the STEPS, thanks

3 Unless specified otherwise, all traded value and volume figures in Chapter 5 are stated on a net, inter-regional basis. This is contrast to Chapter 4, where statistical data on gross international trade are used.

to its large amount of existing manufacturing capacity and - in almost all cases - having  the  lowest  production  costs.  China's  net  exports  of  clean  energy technologies increase from around USD 145 billion in 2024 to USD 375 billion in 2035. To put this latter figure in context, it represents around 10% of China's total  goods  exports  in  2024  (around  USD 3.6 trillion)  (State  Council,  2025), which is around four-fifths of the combined value of crude oil export revenues across OPEC countries in 2025 (USD 4 55 billion) (EIA, 2025).

Despite this rapid growth, several countries lower their dependency on Chinese imports in relative terms at certain steps in the value chain - particularly those downstream. For example, the European Union's net imports of battery cells from China drop from around half of domestic demand levels in 2025 to around a quarter by 2035. At the same time, the dependency on Chinese cathodes imports jumps from around 15% to 45% over the same period; for anodes it remains at today's elevated levels of around 75%. A similar pattern can be seen in the profile of Chinese import dependence across the solar PV supply chain; several  countries  reduce  their  dependence  on  Chinese  module  and  cell imports, but to a lesser extent - or not at all - for wafers and polysilicon.

Figure 5.4 Inter-regional net trade in clean energy technologies in the Stated Policies Scenario and Net Zero Emissions by 2050 Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario; NZE = Net Zero Emissions by 2050 Scenario; EVs = electric vehicles; EMDEs = emerging markets and developing economies; AEs = advanced economies. Trade is in net terms by technology, based on the regional groupings used in the Manufacturing and Trade model, which align with those used in the Global Energy and Climate model. Intra-regional trade is not included.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Clean energy technology trade over the next decade reaches more than double that of 2024 in the STEPS and more than six times higher in the NZE Scenario.

Trade remains a key enabler of clean energy technology deployment, which has  far-reaching  effects  on  the  need  to  trade  fossil  fuels.  Between  2024 and 2035 in the STEPS, changes in total energy supply are relatively small in the United States (0%), European Union (-8%) and China (4%), while India sees  a  larger increase (32%). Across  all countries, electricity plays a growing  role, increasingly  generated  and  transformed  using  clean  energy technologies, which  must  be  imported  where  domestic  manufacturing  falls short, as in most countries other than China.

The  European Union  sees  its  net  imports  of  fossil  fuels  drop  from  around USD 410 billion in 2024 to USD 275 billion in 2035 in the STEPS. Fossil fuel imports drop by more than 30% over that period, pushing down their share in total energy consumption from 55% in 2024 to around 40% in 2035. Over the same  period, net imports of clean energy  technologies increase from around USD 65 billion to USD 165 billion, resulting in a broadly flat import bill for fossil fuels and clean energy technologies combined. Similarly, China cuts net fossil fuel  imports  to  USD 460 billion,  while  substantially  increasing  net exports  of  clean  energy  technologies,  leading  almost  to  a  balancing  of the  value  of  imports and exports across these two categories of goods.

The  United  States  and  India  follow  different  paths.  The  United  States reduces  fossil energy use but increases net exports, with shortfall replaced by renewables-based electricity, driving growth in clean energy technology imports.  India,  on  the  other  hand,  sees  an  increase  in fossil fuel demand, but expanding  domestic  manufacturing  allows  it  to  meet nearly all EV, solar PV module and wind demand by 2035, limiting imports.

Figure 5.5 Net trade in clean energy technologies and fossil fuels in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Note: Positive values are net exports; negative values are net imports. Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Fossil fuel imports fall sharply in the European Union and China over the next decade in the STEPS, owing to widespread deployment of clean energy technologies.

For several technologies, the global manufacturing capacity needed to meet projected  2030  production  levels  in  both  the  STEPS  and  NZE  Scenario  is already  in place, under  construction  or  planned.  Battery  manufacturing capacity, including committed projects with an FID, is sufficient even in the NZE Scenario (Figure 5.6). For solar PV, existing capacity alone exceeds projected demand. Wind nacelles  fall  short  when  considering  existing  and  committed capacity  at  full  utilisation.  Electrolysers  require  a  large  share  of  announced projects, including those not yet at the FID stage, to meet demand. Heat pumps face the biggest gap, needing more than a doubling of capacity by 2030 to meet NZE Scenario requirements.

Figure 5.6 Projected output from existing and announced manufacturing capacity relative to deployment in the Stated Policies Scenario and Net Zero Emissions by 2050 Scenario, 2030

<!-- image -->

IEA. CC BY 4.0.

Note : STEPS = Stated Policies Scenario; NZE Scenario = Net Zero Emissions by 2050 Scenario. Committed capacity s refers to projects that have reached a final investment decision or are under construction. Increased utilisation refers to the gap between 2024 production levels and existing capacity being utilised at 85%. That rate is assumed for both existing and announced manufacturing capacity in 2030. For heat pumps, the project pipeline is concentrated in Europe, where manufacturers announced new plans after the 2022 surge in sales, though this reflects the fact that new manufacturing projects are commonly not announced publicly by heat pump manufacturers in other regions.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Manufacturing project pipelines for solar PV modules, battery cells and electrolysers are sufficient to achieve the production levels projected for 2030, even in the NZE Scenario.

## Solar PV

## Global trends

Solar  PV  deployment  maintained  strong  momentum  in  2024,  with  installed generating  capacity  increasing  by  540 GW  (around  25%  higher  than  the capacity additions in 2023). Almost 60% of this growth came from China, with most of the remainder from the European Union, the United States and India (see Chapter 2). China continued to dominate the global solar PV manufacturing  supply  chain,  adding  substantial  capacity  across  all  major production stages: polysilicon, wafers, cells, and modules. Yet the manufacturing  capacity  growth  in  China  was  lower  than  in  2023  in  most segments, except for polysilicon manufacturing - the bottleneck at the end of 2023 - which expanded by more than 50% and accounted for virtually all global capacity additions in 2024.

In  recent  years,  rapid  capacity  growth  has  created  a  substantial  overhang, driving  down  prices  and  profits.  As  a  result,  several  previously  announced projects have been cancelled or delayed over the past year (see Table 4.2). Part of this overcapacity stems from internal competition between provinces in China and from investments in more advanced cell technologies, which have made much of the existing capacity obsolete (though it remains operational). Most  new  manufacturing  facilities  are  designed  to  produce  Tunnel  Oxide Passivated Contact (TOPCon) cells, while many existing Passivated Emitter Rear Contact (PERC) plants have been retrofitted to produce this technology. The increased conversion efficiency of TOPCon may translate to multiple GWh of additional solar power generated in the coming years.

Lower  prices  have  given  installers  and  utilities  in  China  and  elsewhere  an opportunity to purchase PV  modules at reduced cost, boosting both deployment and stockpiles in Europe and North America. Concerns over the possible  introduction  of  high  tariffs  and  duties  have  also  fuelled  inventory building in importing countries, particularly in the United States. Trade volumes and patterns remained largely unchanged in 2024, with over one-quarter of modules being traded between regions (excluding changes to inventories). Our estimates for 2025 show a slight fall in trade volumes because of the build-up of domestic capacity in the United States and India, and a slowdown in US solar PV deployment. Modules remain by far the most traded component both in terms of value (four times that of cells) and capacity (two times more). In fact, the trade of modules roughly matches the traded capacity of cells and wafers combined.

Figure 5.7 Global manufacturing and inter-regional net trade flows in the solar PV supply chain in the Stated Policies Scenario, 2024-2035

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

Notes: AEs = advanced economies; EMDEs excl. China = emerging markets and developing countries excluding China. Flows have been normalised to global demand and excludes inventory changes.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

China  continues  to  dominate  the  solar  PV  supply  chain  and  deployment  of  generating capacity, though the market share of other EMDEs is set to grow rapidly.

Medium-term prospects for manufacturing and trade in solar PV modules and components  are  shaped  by  the  current  supply  overhang,  which  is  slowing capacity  additions,  and  influencing  trade  policies.  China  remains  by  far  the largest  producer  across  all  components  and  final  modules  in  the  STEPS (Figure 5.7). Though its market share declines by 6%, it still supplies nearly 75% of the projected 660 GW of global module demand in 2030 (compared with 80%

of 560 GW in 2024) and about the same share of the 650 GW of demand in 2035. Its share of supply of components falls more, but remains at around 80% given that it starts from a higher base (Figure 5.8).

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

China's share of solar PV production globally is set to fall as new facilities come online in other EMDEs and advanced economies.

India experiences the largest increase in global share of production, rising from 3% in 2024 to 10% in 2030 and reaching about 12% by 2035. Association of Southeast  Asian  Nations  (ASEAN)  countries  see  a  regional  reshuffling  of capacity and production as a result of US trade policies, but maintain a share of around 5% of global production through 2030 and beyond. Other EMDEs are entering the supply chain as well; for example, the Middle East is establishing new  capacity,  with  a  polysilicon  production  facility  coming  online  in  Oman, leveraging its competitive energy costs.

In the NZE Scenario, global demand for solar PV is more than 50% higher than in the STEPS in 2030 and almost 90% higher in 2035, reaching almost 1.2 TW. This stronger outlook allows more room for new entrants, especially in EMDEs other than China. By 2030, these economies widen their lead over advanced economies in module production, and by 2035 they account for 35% of global output, with similarly increasing shares along the supply chain.

In  addition  to  the  main  four  components,  inverters  -  an  essential  piece  of equipment for connecting PV modules to the grid - also have ample supply, with around 1 200 GW of annual output in 2024. Manufacturing capacity for inverters is relatively well distributed at present compared with other components, with the European Union and India able to meet their own demand, and the United States capable of covering the majority of its requirements domestically. Rising global

requirements to 2035 are expected to be met comfortably in both scenarios, although a modest expansion of around 10% will be needed under the  NZE Scenario.

## Impact of US and Indian industrial and trade policies

Alongside China's extensive use of tax concessions, grants and below-market loans (see Chapter 4), the United States and India are the only major economies offering explicit financial support for solar PV manufacturing as part of their clean energy  industrial  policies.  The  US  Inflation  Reduction  Act  (IRA)  continues  to lower  the  levelised  cost  of  production  (LCOP)  for  modules  from  around USD 0.21/W to USD 0.14/W, while India's Production Linked Incentive scheme provides  substantial  capital  expenditure  support.  Both  countries  complement these incentives  with  trade  measures  that  increase  import  costs  and  enforce local  content  requirements;  for  example,  India  mandates  the  use  of  locally sourced cells as per its Approved List of Models and Manufacturers.

The impact of these policies is already evident. Between 2022 and 2024, module and cell manufacturing capacity expanded threefold in India and fivefold in the United States. This growth is projected to continue under the STEPS, with an additional 30 GW of module capacity projected in the United States (Figure 5.9) and 70 GW in India by 2030 (Figure 5.10). Upstream capacities also continue to expand rapidly:  wafer  manufacturing,  which  was  previously  negligible  in  both countries, is projected to reach 5 GW in the United States and over 65 GW in India by 2030, while India's polysilicon capacity is projected to rise to 25 GW, from zero in 2024.

Figure 5.9 Solar PV module and cell production, demand and net trade in the United States in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Financial support under the IRA and protective trade policies are set to continue to drive up solar PV module and cell production - and reduce imports - in the United States.

Higher  domestic  production  costs  combined  with  substantial  import  duties mean  that solar PV  module and component  prices in India (around USD 0.15/W) and the United States (close to USD 0.30/W) are far higher than the USD 0.09/W price of Chinese modules - the global price benchmark. Part of the reason for this price gap is that Chinese modules are currently estimated to  sell  at  a  small  loss.  Under  the  STEPS,  the  gap  narrows,  reflecting  both current policies and structural cost factors. In the United States, an additional driver  of  higher  prices  is  the  significant  share  (around  20%)  of  thin-film manufacturing,  which  is  more  expensive  per  unit  of  power  output  than crystalline silicon-based production.

Despite higher prices, solar PV deployment in both countries in the STEPS is not significantly affected, as module costs represent only a small share of total PV  installation/plant  costs.  Most  of  the  projected  slowdown vis-à-vis the projections  for  the  United States  in ETP-2024 stems  instead  from  policy changes  and  resulting  uncertainty,  which  dampen  investor  confidence.  In contrast, India continues rapid capacity additions in that scenario. Strong policy support and aggressive manufacturing expansion are enabling newer, more advanced facilities  to  replace  outdated,  uncompetitive  plants  -  previously  a cause of very low utilisation rates. As a result, India is expected to achieve its first  module  trade  surplus  as  early  as  2026  and  is  projected  to  be  able  to produce sufficient  modules and cells before the end of the decade to meet domestic demand entirely, with surplus capacity maintained beyond 2030.

Figure 5.10 Solar PV module and cell production, demand and net trade in India in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

India's  solar  PV  manufacturing  capacity  is  set  to  outstrip  deployment,  with  the  country reaching self-sufficiency in both module and cell production before 2030 in the STEPS.

## Box 5.2 The impact of new US import duties on Southeast Asian solar PV manufacturing

The  solar  PV  manufacturing  capacity  of  Southeast  Asian  countries  increased steadily  until  2023,  making  the  region  as  a  whole  the  second-largest  holder  of manufacturing  capacity  outside  China.  Southeast  Asia  has  highly  competitive production costs and benefits from a strong manufacturing base, favourable policy frameworks and a skilled workforce. These factors have supported the expansion of an export-oriented industry, with an LCOP for modules about 10% above China's - well below the global median, which is around 30% higher.

Most of this capacity is in downstream components, with Chinese-based companies accounting  for  more  than  60%  of  total  production  capacity.  Given  the  highly standardised nature of solar PV products and manufacturing processes, the move into Southeast Asia has led to a significant transfer of know-how. Proximity to China has facilitated smooth integration into Chinese supply chains, particularly through the import of upstream  components  from  the  same  companies'  integrated infrastructure in China.

Recent shifts in US trade policy threaten to severely disrupt solar PV manufacturing in Southeast Asia. Following an investigation by the Department of Commerce, the US International Trade Commission determined that imports of modules and cells were damaging the US industry, prompting the government to impose countervailing duties (CVD) and antidumping duties (ADD) in June 2025 (Table 5.1) (International Trade Administration, 2025a).

Table 5.1 US duties on solar PV imports from Southeast Asia, from June 2025

| Country   | ADD rates   | CVD rates   |
|-----------|-------------|-------------|
| Cambodia  | 125%        | 535-3 404%  |
| Malaysia  | 0-81%       | 15-171%     |
| Thailand  | 111-203%    | 255-775%    |
| Viet Nam  | 62-271%     | 68-543%     |

Note: Numbers are rounded to the nearest percentage point.

Historically, the United States has been the main importer of solar PV modules and cells from Southeast Asia, as US imports from China have been heavily restricted in  recent  years.  With  the  new  tariff  and  duty  rates  in  place,  import  prices  of Southeast Asian products now  exceed  the  breakeven level for US-based production. This appears to be triggering a slump in exports to the United States and a sharp contraction in ASEAN manufacturing, with 2025 output projected to fall by around 50% compared with the previous year based on data covering the first half  of  2025.  This  has  led  to  a  drop  in  new  project  announcements  and  the decommissioning of some existing plants.

## Impact of EU targets for solar PV manufacturing

Even  though  the  European Union  recorded  the  second-highest  solar  PV capacity  additions  as  a  region  in  2024,  domestic  production  remains  very limited along the entire supply chain and is virtually non-existent for wafers. As a result, the European Union imports over 85% of its requirements, with more than three-quarters coming from China.

The NZIA designates solar PV as a 'net-zero technology of interest', making it eligible for support to speed up permitting for manufacturing facilities. However, among all the technologies covered by the NZIA, the solar PV supply chain appears the most difficult to develop, given the region's high production costs, the absence of systematic financial support schemes (such as those in place in  the  China,  United States  and  India)  and  the  European Union's  continued openness to solar PV imports.

## Figure 5.11 Solar PV module and component production and demand and announced projects in the European Union in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario; NZIA = Net-Zero Industry Act. The NZIA target is defined as 40% of total demand for a clean technology being accommodated with domestic production at all steps in the supply chain. The '2024 existing' and '2030 existing &amp; announced' values on the right-hand graph show the projected output from existing capacity and announced projects assumed a utilisation rate of 85%.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

The NZIA target calls for a rapid ramp-up of EU solar PV module and component production to 2030 and beyond, but capacity in the pipeline is insufficient to meet this goal.

The  absence  of  specific  support  mechanisms  to  make  the  NZIA  target achievable is  reflected  in  the  modest  growth  of  manufacturing  capacity  and related announcements in 2024 and 2025. Announcements have not increased significantly  since the  policy  was  adopted. Given the lead times for building capacity in Europe and the lack of incentives, especially compared with the United States, neither the 2030 nor 2035 targets are assumed to be met in the STEPS.  Moreover,  the  prospect  of  a  significant  increase  in  production incentives  is  looking  less  likely  in  view  of  the  gradual  shift  in  EU  spending priorities,  notably  towards  defence.  In  addition,  the  prospects  for  achieving competitiveness appear more promising for some  other clean energy technologies, including wind and batteries.

Among components, only polysilicon production is relatively well-positioned, supported by the region's strong chemical industry, notably Germany's Wacker Chemie.  However,  high  energy  costs  limit  expansion  in  the  STEPS,  while exports to China are falling as Chinese producers increase both output and product purity. For modules, the target is more attainable - though likely only after 2030, by when demand will have peaked - as announced capacity would need to increase by three-quarters by then. By contrast, cells and wafers must climb from a much lower base, making progress considerably harder.

## Solar PV supply chain concentration in China

The concentration of solar PV manufacturing in China has continued to rise across all parts of the supply chain over the past 5 years, with the greatest clustering upstream  in polysilicon and  wafer production. Its polysilicon production  capacity  has  expanded  particularly  quickly:  in  2024  alone,  it increased by more than 50% compared with end-2023. This rapid expansion has  closed  the  gap  between  domestic  supply  and  demand  for  solar-grade polysilicon, enabling China to achieve near self-sufficiency. Its share of global polysilicon  production  has  risen  to  almost  95%  -  higher  than  its  share  for modules and cells, and more than 25 percentage points above the level of 5 years ago.

Wafers  are  the  only  PV  supply  chain  segment  for  which  new  project announcements  have  outstripped  project  cancellations since ETP-2024 ; project pipelines for modules and cells have been revised downward or remain stagnant, as is the case for polysilicon. Almost all cancellations and downscaling for modules and cells have come from China, where companies have entered a phase of consolidation. Although these changes have not yet led to a dramatic drop in China's share of global capacity, the impact will be more evident in production output in the near future. In the STEPS, China's production share is projected to decline by 6-13 percentage points by 2030, remaining above 70% for downstream components - which are more directly

targeted by US and Indian policies - and above 80% for upstream components, which benefit from vertical integration and economies of scale. Despite this fall, China remains the leading exporter of PV components due to the scale of its capacity and cost-competitiveness.

Historically,  polysilicon  and  wafer  supply  has  been  more  concentrated  than modules, both in terms of the number of countries hosting production and the number and size of facilities. In 2024, modules were produced in 40 countries and wafers in 15, but only six countries manufactured polysilicon. Energy costs play a critical role in determining cost-competitiveness, favouring regions with abundant  low-cost  energy,  such  as  certain  provinces  of  China,  emerging producers  in  the  Middle  East,  some  parts  of  Southeast  Asia  and  India. Moreover,  upstream  segments  attract  fewer  financial  incentives,  as  they account for a relatively small share of total value added in the solar PV supply chain.  However,  building  a  more  resilient  supply  chain  would  require  less concentrated manufacturing across all steps. Given that these upstream stages are not substitutable, expanding wafer and polysilicon capacity represents a logical upstream extension for countries that have already established robust module and cell manufacturing.

Figure 5.12 Global solar PV manufacturing capacity announcements and China's share of global production and demand in the Stated Policies Scenario, 2024-2030

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Chinese companies have slashed their plans to add manufacturing capacity for solar PV modules and cells, which is set to moderate their combined global market share in 2030.

## Wind

## Global trends

Wind turbine deployment reached 115 GW in 2024 and is projected to have risen  by  over  25%  to  145 GW  in  2025.  Global wind  manufacturing  capacity reached over 280 GW in 2024. This surge is driven mainly by China's rapid expansion of wind installations, which are expected to have reached 90 GW in 2025 - about 60% of global added capacity that year. The acceleration reflects upcoming  changes  to  China's  electricity  pricing  system,  which  is  moving towards  a  more  market-based  approach.  However,  the  global  speed  of deployment  and  manufacturing  to  meet  the  sector's  needs  are  set  to  slow significantly after 2025. In the STEPS, global wind additions grow by a little over 2% per year on average to 2035, with strong growth in Europe offset by a marked slowdown in China. In advanced economies, most of the growth comes from  Europe,  while  additions  in  the  United States  fall  due  to  recent  policy changes.

As components are costly to transport over long distances, production tends to be  located  close  to  markets.  Among  the  three  main  components  analysed, blades and nacelles have the highest trade volumes, while towers are traded the  least,  with  only  about  10%  of  production  currently  exported.  Nacelle assembly is more geographically concentrated than blade or tower assembly, mainly due to higher labour costs and the complexity of subcomponents, which benefit from proximity to established industrial clusters. In 2024, inter-regional trade in nacelles was equivalent to around 12% of global production. Blade manufacturing  is  more  geographically  dispersed.  While  many  plants  are located in major deployment markets, significant production hubs also operate just across borders from these markets. For example, Mexico supplies about 40%  of  US  blade  demand,  while  Türkiye  supplies  around  10%  of  the European Union's.

The geographic distribution of wind turbine manufacturing is poised to shift over the coming decade, largely reflecting differences in deployment prospects. In the STEPS, China's share of global production of the three main components drops  from  65-75%  in  2024  to  45-65%  in  2030  and  40-60%  in  2035,  as domestic production stagnates and production in other EMDEs and advanced economies continues to expand. Inter-regional trade  in  wind components  is also projected to increase as regional demand shifts, although manufacturing capacity centres remain largely unchanged. By 2030, global exports of nacelles, blades and towers rise by 240%, 190% and 85%, respectively. In the case of nacelles, the share of trade in global production rises to nearly 30%, mainly due to weak demand in China, which frees up capacity for export (Figure 5.13).

In the same scenario, the United States substantially reduces its reliance on imports. All nacelles deployed domestically are expected to be assembled in the country, while the domestic share of blade production increases from 35% to 80% by 2030. This shift sharply reduces projected imports from Europe, India and Mexico: nacelle imports fall from 6 GW to near zero, while blade imports are  six  times  lower.  Smaller  emerging  suppliers  such  as  Brazil  and  other Central  and  South  American  countries  are  also  affected,  having  previously been identified as potential sources under the IRA renewable energy targets.

Figure 5.13 Global manufacturing and inter-regional net trade flows of wind turbine nacelles in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: AEs= advanced economies, EMDEs = emerging markets and developing economies excluding China. Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

China's share of global nacelle production drops sharply to 2035, with a bigger share of its output going to exports, reflecting weaker domestic deployment.

Global wind manufacturing expands much faster in the NZE Scenario than in the STEPS to meet stronger demand. Wind capacity additions reach close to 390 GW by 2035,  before  easing  to  about  315 GW  in  the  early  2040s.  The difference is largest in EMDEs other than China, which in aggregate see their additions increase more than double - twice the rate of the increase advanced economies observe in the NZE Scenario. By 2040, these countries supply over 45%  of  global  wind  turbine  components,  compared  with  about  30%  in  the STEPS.

## Prospects for China's exports

China is set to retain its position as the world's largest manufacturer of wind turbines and components in the medium term. In 2024, it accounted for about 70% of global manufacturing capacity for nacelles and blades, and around 45% for towers. With few new capacity announcements elsewhere, this dominance - particularly in nacelle and blade production - is expected to persist. In the STEPS, the surplus of domestic manufacturing capacity relative  to  demand shrinks  and  even  turns  into  a  gap  in  several  regions  (Figure  5.14).  The European Union  shifts  from  being  a  net  exporter  in  2024,  exporting  around 2 GW of nacelles (over 10% of domestic demand) to becoming a net importer of nearly 15% of its demand by 2030.

Figure 5.14 Difference between projected output from existing and announced projects and local demand by country/region and Chinese exports by destination for wind turbine blades and nacelles in the Stated Policies Scenario, 2024-2030

<!-- image -->

IEA. CC BY 4.0.

Notes: CSAM = Central and South America. The difference in the left-hand graph is calculated based on existing and committed announced projects, assuming a utilisation rate of 85%.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

In  many  regions,  growth  in  domestic  demand  is  set  to  outpace  growth  in  manufacturing capacity, resulting in large increases in exports from China, where deployment is slowing.

A similar trend emerges in the Asia Pacific region excluding China, where several countries are currently net exporters. In the STEPS, imports meet around 35% of that region's demand  for nacelles and 50%  of demand  for blades by  2030.  Because  many  nacelle  facilities  in  these  countries  primarily  serve overseas markets, they need to rely on net imports to meet growing domestic demand for these components in this scenario.

This growing global reliance on imports in the STEPS is met largely by Chinese exports. This is due to lower-priced Chinese turbines on overseas markets, which today are on average about 40% cheaper than those from other manufacturers (BNEF, 2025a). The price gap is not uniform: in EMDEs in Africa and parts of Asia Pacific, Chinese turbines can be 10-45% less expensive, while in European and North American markets, the difference narrows to 10-25%, reflecting stricter quality requirements, trade measures and the high cost of shipping from China to those markets (see also Chapter 4).

However, the potential for further growth in Chinese exports is constrained by three main factors:

-  Turbine design differences: There are significant differences in the design of turbines across regions. For instance, the average rotor diameter of onshore turbines  in  the  European Union  is  around  160  metres,  compared  with  over 200 metres  in  China  (Figure  5.15).  This  makes  some  Chinese-designed turbines less compatible with project specifications in many overseas markets.
-  Legacy of excess capacity: Much of China's current excess capacity stems from factories built between 2020 and 2023, primarily serving low wind-speed Chinese  regions.  More  recently,  new  facilities  in  northern  China  have  been developed for high wind-speed and offshore projects. It is uncertain whether the older production lines can be adapted or maintained as demand shifts toward different turbine types and performance requirements.
-  Industrial  policies: Many  governments  are  strengthening  domestic  wind supply chains through a mix of trade measures and targeted industrial policies:
-  In  the European Union ,  the  NZIA  does  not  impose  local  content  quotas. Instead, it introduces non-price criteria, such as those relating to sustainability, innovation and resilience, that can be used as pre-qualification or award criteria in  public  procurement  and  renewable  energy  tenders.  These  measures  can encourage  local  component  manufacturing.  In  May  2025,  the  European Commission issued new secondary legislation clarifying that the definition of covered components includes permanent magnets, gearboxes, drivetrains and bearings. It also specified that, from 30 December 2025, 30% of new auction volumes must apply the rules on the inclusion of non-price criteria (European Commission, 2025b).
-  In India ,  a  draft  regulation  proposes  geographic  sourcing  requirements  for turbine  components,  aiming  to  localise  a  greater  share  of  the  value  chain (see Box 5.4) (India, Ministry of New and Renewable Energy, 2025).
-  In Japan , the government has set a target of 60% domestic content in offshore wind projects by 2040, with a likely revision to 70%, as part of its offshore wind deal. This target is backed by subsidies for local production facilities (Japan, Ministry  of  Economy,  Trade  and  Industry,  2020);  by  the  end  of  2024,  five Japanese companies had been around USD 85 million (GX, 2025).

## Box 5.3 Differences  in  regional  configurations  and  the  complexity  of onshore and offshore wind technologies

In  many  respects,  the  onshore  and  offshore  wind  sectors  operate  as  distinct manufacturing industries, each with its own complexities and at a different stage of maturity.  Onshore  wind  technology  has  reached  a  relatively  mature  phase,  with rotor  diameters  increasing  only  slightly  in  all  regions  except  China.  Current manufacturing  innovation  is  focused  less  on  size  and  more  on  materials  and processes.  For  example,  hybrid  towers  are  becoming  more  common  in  China, though adoption is slower in other markets. In blade manufacturing, research is increasingly directed toward recyclability and the transition from thermosetting to thermoplastic materials. In recent years, the share of direct drive turbines has fallen sharply, from over 20% in 2022, to just below 9% in 2024, and medium-speed gear drive models are emerging as the preferred option. This shift has further increased standardisation in the onshore sector.

Figure 5.15 Regional differences in onshore wind turbine configurations, 20142024

<!-- image -->

IEA. CC BY 4.0.

Notes: Weighted averages for rotor diameter, capacity and specific capacity are calculated based on the number of turbines per firm project order. The analysis covers future wind projects on order.

Source: IEA analysis based on S&amp;P Global (2025).

By  contrast,  offshore  wind  remains  at  the  stage  of  scaling  and  technological diversification. Rotor sizes and turbine capacities (MW per unit) continue to grow, and floating wind is still at an early commercial stage - the first large-scale projects of  over  50  MW  were  completed  only  in  2021.  This  ongoing  evolution  adds complexity to both component standardisation and logistics.

Several emerging economies are also playing a growing role in the global wind supply chain:

-  India remains a major global supplier and is reinforcing its industrial base. Under a revised certification policy introduced in April 2025 (India, Ministry of New  and  Renewable  Energy,  2025),  local  sourcing  of  blades,  towers, gearboxes and generators is mandatory for all new wind projects, with limited initial exemptions.  Under  the  STEPS,  both  nacelles  and  blades  exports account for about 20% of production in 2035, mainly serving Asia Pacific and European markets.
-  Brazil has shifted from solely meeting domestic demand to serving regional markets too, with production facilities for all major components. It is projected to export 10% of nacelle production and 30% of blade production to other Latin American countries in 2035 in the STEPS.
-  North Africa , particularly Morocco, is emerging as a blade manufacturing hub. By 2035, around 5% of EU wind imports are expected to come from the region, benefiting from proximity and shorter logistics chains.
-  Southeast  Asia is  expanding  its  role  as  local  deployment  grows.  Existing facilities include GE's onshore wind generator production in Viet Nam and CS Wind's tower manufacturing. Indonesia and the Philippines have potential to expand further,  leveraging  their  steel,  shipbuilding  and  automotive  sectors. Tower production offers an accessible entry point for countries with limited turbine manufacturing experience.

Figure 5.16 Wind blade demand, production and inter-regional trade in selected emerging economies in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Emerging economies with established wind component industries are set to expand exports to advanced economies as well as meet growing domestic and regional demand.

## Box 5.4 Local content requirements in India's wind energy industry

India's  wind  deployment  is  set  to  accelerate,  supported  by  a  10 GW  per  year tendering  trajectory  to  help  double  onshore  wind  capacity  by  2030.  Under  the Atmanirbhar Bharat (Self-Reliant India) agenda, the government is strengthening domestic  manufacturing  through  measures  such  as  Concessional  Custom  Duty Certificates (CCDCs) for import of critical components. It is also aiming to improve quality  by  requiring  original  equipment  manufacturers  (OEMs)  to  source  towers, blades, gearbox, generators and special bearings from facilities inspected under a standard operating procedure.

A baseline assessment of India's wind manufacturing industry by MEC+, supported by  the  Asian  Development  Bank,  analysed  12  turbine  models  covering  80%  of installations in financial year (FY) 2024 (MEC+, 2025). India now has over 15 GW of nacelle  manufacturing  capacity  serving  domestic  and  export  markets,  alongside sizeable  capacity  for  blades,  towers,  gearboxes  and  generators,  ranging  from 10-29 GW (Figure 5.17). However, manufacturing of more upstream components remains limited in scale and capability.

Figure 5.17 Manufacturing capacity and costs of wind turbine components in India, 2024

<!-- image -->

Notes: In the graph on the right, the lower end of turbine costs reflects larger 5 MW platforms, while the higher end reflects the costs of 3 MW turbines. 'Limited domestic manufacturing' assumes manufacturing in India is limited to towers and blades, with the subcomponents of the nacelle imported. 'High domestic' assumes high reliance on domestic manufacturing of those same components.

Source: IEA analysis based on MEC+ (2025)

The assessment found that India's wind sector witnessed a steady rise in local content between FY2022 and FY2024. Local content in the assembly of nacelles, towers and rotors  grew  from  40% to over 70%, while growth at the system-level, such as the

production of gearboxes, control systems and generators, was more modest, rising from about 30% to 50%. At an end-to-end level, which includes sub-systems and raw materials,  local  content  remained  much  lower,  reflecting  continued  reliance  on imported systems or sub-systems and the limited scale of upstream production.

Bottlenecks were assessed across supplier availability, manufacturing capacity and capability,  quality  and  pricing.  Pricing  is  the  most  significant  barrier:  domestic component costs remain 20-25% higher than imports, mainly due to raw material costs and higher cost of financing. Import duties and logistics reduce but do not eliminate the  gap.  Capability  and  scale  for  newer  turbine  models  also  lags,  especially  for upstream components, creating continued dependence on imports.

Strengthening India's wind manufacturing ecosystem will require clear enforceable policies  that  provide  long-term  procurement  visibility  and  export  facilitation. Regulatory  measures,  including  domestic  content  requirements,  targeted  fiscal incentives and concessional finance, could support this transition. Enhanced quality assurance  frameworks,  securing  raw  material  supply,  R&amp;D  for  next-generation turbines and skilled workforce development will be important to build a competitive and resilient industry.

## Supply chain bottlenecks

Complex installation processes and lengthy permitting procedures can create bottlenecks  in  the  wind  power  supply  chain  for  both  onshore  and  offshore projects, though the underlying causes differ (Box 5.3). In the case of offshore wind, the scale and technical complexity of projects have prompted governments to play a more active role in auction design. Measures include centralised tenders, government-led zoning and pre-surveyed sites, all aimed at reducing risk and uncertainty for developers. For example, the Netherlands holds  annual  tenders  with  clear  multi-GW  targets  and  pre-developed  sites. Japan is moving towards a similar co-ordinated approach by publishing preauction site surveys and establishing centralised zoning. In the European Union, the updated Renewable Energy Directive, known as RED III, adopted  in  2023,  introduced  binding  deadlines  for  permitting  and  required member states to digitalise their permitting procedures. In addition, in 2024, the European Union  adopted  a  series  of  recommendations  and  guidance  to streamline permitting procedures (European Commission, 2025a).

Port  capacity  and  the  availability  of  installation  vessels  could  also  become bottlenecks for turbine deliveries and installations, particularly in the offshore sector.  Outside  China,  sufficient  port  space  hinges  on  new  or  announced expansions of  ports.  But  even  when  all  plans  materialise,  half  of  all  basins analysed would face shortages to meet capacity additions projected for 2030 under the STEPS. In absolute terms, the largest shortfall is in the East Sea/ Sea of Japan  basin  (Figure  5.18).  In  the  Asia  Pacific  region,  port  capacity

constraints are likely to be more persistent as offshore projects accelerate in Japan,  Korea,  the  Philippines  and  Viet Nam.  Other  areas,  such  as  the Mediterranean  and  offshore  United States  and  Mexico,  are  expected  to experience less severe capacity pressures, reflecting lower projected additions from Southern European countries and the United States.

The availability of wind turbine installation vessels (WTIVs) is another potential bottleneck  for  offshore  wind.  Globally,  excluding  China,  the  current  fleet  of WTIVs is insufficient to meet the deployment needs projected for 2030 in the STEPS. Even accounting for vessels that are due to be commissioned by 2026 and others that are planned, the fleet would still reach only 14 vessels - 6 short of  the  estimated  20  vessels  required  worldwide  in  2030.  Beyond  global availability of vessels, local factors also play a role: cabotage rules in countries such as Brazil and Japan limit the use of foreign vessels, which can delay the completion  of  offshore projects and  significantly increase  costs. These constraints highlight that, alongside scaling manufacturing, timely investment in  specialised  installation  vessels  and  clearer  regulatory  frameworks  will  be critical to meeting offshore wind targets.

## Figure 5.18 Port and vessel capacity for handling offshore wind installations outside mainland China in the Stated Policies Scenario, 2030

<!-- image -->

Existing ports Existing vessels Upgraded or planned ports or vessels Gap with STEPS demand

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario. Assumes an average turbine size of 15 MW and that each turbine requires 1.3 hectares in a port. Peak demand is scaled by a factor of 1.5, reflecting the assumption that each offshore wind project occupies the port for 2 years during installation; thus, in a 3-year window, a given berth can service 1.5 projects. Each port is assumed to operate at 60% utilisation. Demand allocated to different basins based on current port capacity. Only wind turbine installation vessels with a main-crane capacity over 1 500 tonnes and a minimum lifting height of 150 metres are considered here.

Sources: IEA analysis based on S&amp;P Global (2025); UN Trade &amp; Development (2025); Rystad Energy (2023); and WindEurope (2023).

The projected expansion in wind turbine trade hinges on large additional investments in expanding port capacity and vessels beyond current plans, especially in Asia Pacific.

## Electric cars and batteries

## Global trends

Electric  car  and  battery markets remain highly concentrated, shaped by the industry's  history  and  economics.  Commercial  lithium-ion  battery  production began in Japan in 1991, proving a platform for electric car production, and has since been dominated by Asian firms, headquartered mostly in China, Japan and Korea. A major turning point came in the early 2010s, when strong Chinese government  support  boosted  EV  demand  and  offered  the  opportunity  for today's  leading  EV  manufacturers,  such  as  BYD  and  Tesla,  to  scale  up production. Growing demand, combined with the requirement to use Chinese-made  batteries  to  access  EV  subsidies  between  2015  and  2019, enabled companies like CATL and BYD, which now account for over half the global EV battery market, to build manufacturing expertise, workforce capacity and scale, underpinning lower costs and faster innovation cycles.

The concentration of demand and production in China has created a tightly clustered supply chain -from  critical mineral refining and  component production to battery and EV manufacturing. In 2024, China accounted for over 90% of anode active material (AAM), almost 85% of cathode active material (CAM), 80% of battery cell and 70% of electric car production. Outside China, virtually only Korea and Japan have sizeable CAM and AAM output, while most other  battery  cell  manufacturing  occurs  in  Europe  and  the  United States  nearly  all  by  companies  headquartered  in  Asia  (IEA,  2025a).  Electric  car manufacturing is somewhat less concentrated due to the strong automotive industry presence in Europe, North America and Japan.

In the STEPS, the electric car and battery supply chain diversifies as demand grows, investment rises and specialised workforces expand outside China. Yet diversification remains limited, with China still the largest source of demand and production in 2035 (Figure 5.19). By then, it supplies nearly 90% of AAM, about three-quarters of CAM and two-thirds of batteries. The advanced economies drive most diversification, accounting for almost 10% of AAM, 20% of CAM and about  25%  of  battery  output,  with  the  European Union  and  United States together providing close to 10% of CAM and 20% of battery production. EMDEs other than China produce nearly 5% of AAM and CAM but increase their battery and electric car output share to about 6% and 10% respectively - five and ten times their 2024 shares. Electric car production in advanced economies also rises, reducing China's share to just below 55%.

Figure 5.19 Global manufacturing and inter-regional net trade flows of electric cars, lithium-ion batteries and key components in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: AE = advanced economies; EMDEs = emerging markets and developing economies. 'Car-equivalent' is a combined unit of measure for electric cars, batteries and battery components, with the latter two expressed as the number of cars that could be produced with a given quantity thereof.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

China is set to continue to dominate the electric car and battery supply chain, though its market share declines to 2035 with rapid growth taking place in other EMDEs.

While  EV  production  expands  in  the  advanced  economies,  the  share  of demand met by domestic manufacturing does not increase. Despite increased trade restrictions, such as EU countervailing duties on Chinese-made battery

electric  cars,  tariff  reinstatements  in  Brazil  and  Mexico  and  new  levies  in Türkiye, Chinese exports continue to dominate global trade. With unmatched capacity and low costs across the EV supply chain, China's exports are set to grow, with over one in four electric cars sold in advanced economies made in China by 2035 (6 million vehicles) - up from 800 000 in 2024 (15% of sales).

EMDEs other than China gain ground as domestic manufacturers grow and Chinese firms open new assembly plants in South America (e.g. BYD's facility in  Brazil)  and  Southeast  Asia  (projected  to  host  over  a  quarter  of  China's overseas EV capacity by 2030). Asian, western and domestic carmakers are also retooling assembly lines and setting up new production facilities in India, increasing the country's capacity more than tenfold to 1.8 million electric cars by 2030. In the STEPS, electric car production in EMDEs other than China reaches over 5 million by 2035 - about 10% of global output and up from just 1% in 2024.

In the NZE Scenario, electric car production volumes are significantly higher than in the STEPS across all regions, driven by much stronger demand. This growth  supports  greater  diversification  in  manufacturing,  particularly  among EMDEs.  Advanced  economies  increase  their  production  by  about  60% compared  with  STEPS  by  2035;  however,  their  share  of  the  global  market declines as EMDE production ramps up to supply close to 30% of the global electric car market, tripling relative to STEPS over the same period. This shift reflects expanding industrial capacity and rising domestic demand in EMDEs, reshaping the global EV landscape.

## Impact of weaker US demand-side policy support

Several recent policy shifts are dampening the outlook for electric car demand and  production  in  the  United States.  They  include  the  repeal  of  the  Clean Vehicle Tax Credit (US Congress, 2024), ongoing efforts to revise the National Highway Traffic Safety Administration fuel economy standards (US Department of  Transportation, 2025) and to eliminate GHG regulations for road vehicles (US Environmental Protection Agency, 2025), and the revocation of California's waiver to  adopt stricter emission  standards than  federal  law  (US  Congress, 2025a). In 2024, US electric car sales totalled 1.6 million and are expected to have remain ed somewhat  unchanged in 2025 , despite weaker policy incentives,  as  consumers take advantage of the tax credits before they end. Although demand is still projected to double by 2030 in the STEPS, this would represent just 20% of  total  new  car  sales  -  down  from  the  over  50%  that would previously have been needed to comply with fuel economy standards.

These demand-side revisions have three main implications for the supply side:

-  Sufficient  domestic  capacity: Despite  several  US  carmakers  pivoting focus back to internal combustion engine (ICE) cars and delaying their pure EV strategies following recent policy shifts (ICCT, 2025), US pure electric car manufacturing capacity is still expected to exceed 3.5 million units by 2030,  complemented  by  nearly  8 million  units  of  flexible  ICE/EV  car manufacturing capacity (BNEF, 2025b). This project pipeline enables US plants to meet domestic demand through 2035 in the STEPS without the need for additional investment.
-  Reduced import needs: A greater share of demand served by domestic production sharply cuts import dependency. Remaining imports are costly due  to  a  25%  tariff  on  all  electric  cars.  While  US  tariff  and  duty  hikes increase import costs from all countries, they do so to a lesser extent for imports from Canada or Mexico that meet United States-Mexico-Canada Agreement (USMCA) trade agreement content rules, giving North American producers  a  competitive  edge  over  other  importing  regions  (The  White House, 2025). By 2035, imports reach 1.5 million units - almost entirely from Mexico - covering roughly one-third of domestic demand, compared with 4.5 million (40% of demand) in ETP-2024 .
-  Weaker battery demand: Lower EV sales also reduce domestic battery needs,  weighing  heavily  on  the  US  battery  industry.  Committed  battery capacity  by  2030  could  produce  nearly  double  projected  US  demand  in 2035 in the STEPS.

The recent increases in tariffs and duties are expected to have a significant impact on US battery supply chains in the short term, accelerating the shift toward domestic production, but have limited effects over the medium term. By 2030 and 2035, projections remain broadly consistent with those outlined in the ETP-2024 . Battery production - supported by IRA tax credits and the resulting wave of investment - is expected to be able to satisfy most domestic demand, while the supply of cathode and anode active materials remains constrained by available  manufacturing  capacity.  The  main  change  is  a  markedly  lower projection for battery demand.

Momentum in battery and battery component manufacturing investment in the United States has nonetheless slowed, with some projects cancelled or paused (Clean Investment Monitor, 2025). In the STEPS, US battery cell production reaches less than 350 GWh in 2030 and just over 400 GWh in 2035, primarily serving domestic needs with the remainder exported to Mexico - equivalent to less  than  40%  and  50%  of  the  nameplate  capacity  of  currently  committed projects, respectively.

This shift  reflects  weak domestic demand rather than insufficient production incentives.  Recent  legislative  updates  preserve  IRA  tax  credits  for  battery production while tightening long-term rules on prohibited foreign entities (PFEs) (US Congress, 2025b), but also introduce greater short-term flexibility (Zhang, 2025). As a result, investment continues to focus on the development of nonPFE supply chains for the US market. However, scaling these supply chains will  require  additional  overseas  production  capacity,  as  domestic  CAM  and AAM  committed  capacity  remains  insufficient.  Domestic  production  meets about half of CAM demand and about one-quarter of AAM demand by 2035 in the  STEPS,  leaving  the  United States  reliant  on  imports.  The  shortfall  is projected to be largely met by imports from Korea for CAM, while AAM supply is projected to depend on imports from China, Southeast Asia and Korea.

## Box 5.5 The impact of weaker EV demand for the battery industry in the United States

As in the European Union, battery production costs in the United States remain well  above  those  in  China.  However,  the  US  investment  environment  is  more favourable, largely due to the 45X manufacturing tax credit, which provides up to USD 35/kWh for battery cell production - roughly half the cost of producing lithium nickel manganese cobalt oxide (NMC) batteries in China and enough to bridge the underlying cost gap between the two countries in 2024. In 2025, rising costs of imported  materials  and  components  are  expected  to  have  left  US  production almost  10% more expensive than Chinese production, even after IRA support. While counter to global trends, this differential remains relatively modest, helping to sustain the economic case for US-based battery manufacturing.

Incentives  alone,  however,  cannot  guarantee  competitiveness.  Achieving  lower unit  costs  depends on economies of scale, which require strong and sustained demand. Recent policy developments have softened the outlook for EV sales in the United States, dampening battery demand projections. This creates problems for  battery  manufacturers  that  have  committed  substantial  investments  in  US facilities.  In  addition,  these  firms  may  face  increasingly  stringent  conditions  to access tax credits. As a result, more than half of committed manufacturing capacity in the United States is projected to be unutilised in 2030 in the STEPS.

## EU trade policies

The  European Union's  automotive  industry  -  one  of  its  most  important industrial sectors - stands at a crossroads, as high EV and battery production costs continue to weigh on the world's second-largest car producer. Recent

policy measures, including the EU  Automotive Action Plan (European Commission,  2025c)  and  the  NZIA  (European  Commission,  2025d),  aim  to strengthen competitiveness while re-affirming the overall impetus towards the 100% CO2 emission reduction target for new car sales by 2035. In the STEPS, the  European Union  remains  the  world's  second-largest  electric  car  market after China, with around 11 million units sold in 2035 - accounting for one in five sales worldwide.

Figure 5.20 EU electric car and battery supply by origin in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: Utilisation rate refers to production for both domestic use and exports divided by installed manufacturing capacity. Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

EU output of electric cars grows almost fourfold and EU battery output eightfold by 2035, assuming duties on Chinese car imports are extended beyond their current end-date of 2029.

Price-competitiveness  remains  a  key  barrier  to  mass-market  adoption  of electric cars in the European Union (IEA, 2025a). Waning purchase subsidies in major markets such as Germany (Reuters, 2023) and France (Légifrance, 2024) contributed to the first-ever drop in EU sales in 2024, with the share of electric cars in total car sales decreasing from nearly 22% in 2023 to 20% in 2024. Output also stalled at 2.4 million units, exceeding EU demand by more than 5%. High labour costs, elevated battery prices (making up around 25% of the price of an average battery electric car) and lesser economies of scale and supply chain integration than China continue to hinder affordable EV offerings (IEA, 2025c). In 2024, nearly a quarter of available ICE models were priced below EUR 30 000, compared with only around 5% of electric models.

The EU electric car market has since shown signs of recovery. Despite the recent  increase  in  flexibility  for  carmakers  to  comply  with  their  2025  CO2 emissions targets, electric car sales reached a record high in the first half of 2025 with around 25% of new cars sold being electric (ACEA, 2025). Current emission  standards  give  a  clear  and  robust  signal  for  EV  demand  and production scale-up, but the availability of affordable models remains essential to  ensure  emission  targets  are  met.  More,  lower-cost  models  are  expected soon (IEA, 2025a), but achieving scale and cutting production costs will be critical. This may require deeper collaboration in battery manufacturing - such as through joint ventures - with established Asian battery manufacturers, some of which are already present in Europe, including LG Energy Solution, CATL, SK On and Samsung.

Current trade policies partly shield the EU automotive industry from lower-cost Chinese car imports, though the risk of retaliation remains significant given the European Union's  strong  position  as  an  exporter.  The  OEM-specific  CVDs implemented in July 2024, following an anti-subsidy investigation initiated in October  2023,  have  helped  to  keep  the  share  of  Chinese  imports  in  total EU electric  car  sales  below  20%.  EU  manufacturing  capacity  is  unlikely  to constrain supply, as many existing ICE assembly lines can be quickly retooled: of 13 EV manufacturing projects announced in 2025, only five are greenfield investments, with the remainder involving conversions (T&amp;E, 2025).

Based on current project pipelines, EU EV manufacturing capacity could reach 9 million  units  by  2030,  exceeding  domestic  demand  standing  at  just  under 7 million in the STEPS. Under this scenario, the share of domestic demand met by imports remains below one-quarter through 2035 - with a growing number of cost-competitive imports from Korea, the rest of Europe and Japan, reducing China's share of EU imports to around 30% in 2030. From 2030 onward, limited manufacturing capacity among other exporters makes China's unused capacity increasingly relevant to meeting the European Union's growing demand. While imports from other regions remain unchanged in absolute terms, China's share rises again, capturing more than two-thirds of EU imports by 2035, close to the 60% share observed in 2024.

Current EU trade policy maintains CVDs on imports of Chinese battery electric cars through the end of 2029. Discussions in Beijing at the end of 2024 between the European Union and Chinese officials explored a potential agreement to set floor prices for Chinese EV exports to the region (European Commission, 2024a). This 'price undertaking' was presented as an alternative to CVDs and, notably, was not proposed with a specific expiry date. At the 25th EU-China Summit  in  2025,  the  European Union  re-iterated  its  commitment  to  take

proportionate, legally compliant action to counter trade-distorting practices by China, stressing that its protective trade policy instruments would remain in place (European Council, 2025).

The STEPS assumes these CVDs continue beyond 2029, thereby constraining the  market  share  of  lower-priced  Chinese  models.  Nonetheless,  given  the uncertainty over future EU trade measures, we have devised a sensitivity case, which explores the impact of lifting CVDs as scheduled in 2029. In this case, the strong price-competitiveness of Chinese-made battery electric cars spurs much higher exports to the European Union, lowering the average retail prices of battery electric cars in the region (if tariff and duty savings are fully passed through) but at the expense of EU-based production (Figure 5.21). Chinese imports could exceed 10% of EU battery electric car demand by 2030 and rise to close to 50%  by  2035,  cutting  the domestic  share  by more  than 15 percentage  points  down  to  50%.  This  higher  penetration  of  low-priced Chinese models would reduce the average delivered unit costs in the region by around 1% in 2030 and 4% in 2035.

Figure 5.21 China's share of the EU battery electric car market in the Stated Policies Scenario and in a sensitivity case with import duties ending in 2029, 2030-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario; CVDs = countervailing duties. Plug-in hybrid electric vehicles are excluded from this analysis. In the STEPS, CVDs already in place at the end of 2024 - or equivalent measures - are assumed to remain in perpetuity, whereas in the 'CVDs discontinued' sensitivity case they are discontinued at the end of that year. No explicit interactions between car prices and demand levels are considered in this analysis.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Lifting duties on Chinese EV imports would cut the share of domestic carmakers in meeting EU demand from 70% to 50% by 2035, while average delivered costs fall 4%.

## Box 5.6 Current EU trade policy design opens the door to Chinese hybrid car imports

In 2023, the European Union launched an investigation into Chinese government subsidies  to  battery  electric  car  manufacturers.  In  response  to  the  findings, provisional CVDs were imposed in July 2024, and the final measures took effect on 30 October 2024 (European Commission, 2024b). In October 2024 - the last month before the CVDs took effect - EU imports of Chinese battery electric cars leapt up, more than doubling month-on-month, as Chinese OEMs accelerated shipments to avoid the additional costs.

The CVDs explicitly exclude plug-in hybrid electric cars (while including extendedrange electric cars) from their scope. As a result, immediately after the duties came into force, imports of both plug-in and non-plug-in hybrids from China rose sharply, accounting for more than one in four EU car imports from China in the first three quarters of 2025, compared with about 10% in the same period the previous year. While imports of Chinese hybrids are likely to grow further if current EU trade policy remains unchanged, this trend is expected to be short-lived. Indeed, if the upcoming formal review of EU CO  standards for cars confirms the 100% fleet-wide tailpipe ₂ emission reduction target by 2035, no hybrids would qualify as compliant powertrain technologies and would, therefore, lose significant market share.

Figure 5.22   Monthly gross EU car imports from China by powertrain, 2022-2025

<!-- image -->

IEA. CC BY 4.0.

Notes: ICEV = internal combustion engine vehicle; HEV = hybrid electric vehicle; PHEV = plug-in hybrid electric vehicle; BEV = battery electric vehicle. 2025 data is up to September. Please see IEA (2026) for details of the harmonized system (HS) code and powertrain mapping used in this analysis.

Source: IEA analysis based on Sinoimex (2025).

## Chinese EV exports to emerging economies

Chinese electric car exports diversified significantly in 2024, spurred by rising trade restrictions in traditional markets and growing demand in other EMDEs. Europe,  still  the  largest  overseas  destination,  accounted  for  nearly  40%  of export value, but that was down from 70% three years earlier. Southeast Asia, Mexico,  Brazil,  Russian  Federation  and  Caspian  Sea  countries  now  take  a growing  share.  In  2024,  Chinese-made  EV  sales  outside  of  Europe  nearly doubled to over 550 000 units, making up close to half of overseas sales.

Low-cost  Chinese  imports  have  pushed  down  electric  car  prices  in  EMDEs (IEA, 2025a). In Brazil, their share in electric car imports climbed from 60% in 2023 to 85% in 2024, narrowing the electric-ICE car price gap from over 100% to 25%. In Indonesia, import duty waivers tied to local EV investment boosted the share of Chinese EV sales from 10% to 66%, cutting the price premium from over 100% to 50%. The first three quarters of 2025 saw Chinese electric car imports in Indonesia and Southeast Asia more broadly continue to grow already exceeding full-year sales of Chinese imports in 2024.

To sustain growth, Chinese OEMs are expanding shipping capacity. In 2025, BYD  commissioned  the  world's  largest  roll-on/roll-off  vessel,  bringing  its capacity to nearly 50 000 electric cars across six ships (Ren, 2025). SAIC's fleet reached 37 vessels with capacity for roughly 300 000 cars (Kang, 2025). Shipping firms such as COSCO Shipping Car Carriers (Finn, 2025) and China Merchants (The Maritime Executive, 2025) are also playing an important role in serving fast-growing overseas markets.

Chinese exports to other EMDEs are set to rise, underpinned by competitive pricing  and  expanding  shipping  capacity.  Yet  local  production  will  intensify competition. Chinese OEMs, domestic brands such as Viet Nam's VinFast and India's  Tata  and  Mahindra,  as  well  as  established  western  automakers  are building or repurposing plants in EMDEs to serve local and export markets, benefiting from lower labour and energy costs. Policy support, such as duty waivers for EV makers investing in India, Indonesia, Thailand and Viet Nam, is fuelling this trend. Chinese OEM capacity in Southeast Asia could almost triple between 2024 and 2026 to 1.2 million  cars  based  on  current  projects  (IEA, 2025a). Japanese and Korean incumbents in India and Southeast Asia, and European brands in South America, are also retooling lines. In India, capacity could hit 1.8 million units by 2030, more than double the projected domestic demand in the STEPS.

Trade restrictions are, nonetheless, set to rise as investment-linked waivers expire:  Indonesia  (Medina,  2024),  Thailand  (Baker  McKenzie,  2024)  and Malaysia  (Yusry,  2024)  end  theirs  in  2025;  India's  Scheme  to  Promote Manufacturing of Electric Passenger Cars in India limits exemptions to 5 years

(India, Ministry of Heavy Industries, 2024); and Brazil has already reinstated tariffs on hybrids and electric cars (Brazil, Ministry of Development, 2023). In 2024, nearly two-thirds of electric car sales in EMDEs other than China were Chinese imports, a share that is expected to have remained roughly unchanged through  2025.  By  2030,  in  the  STEPS,  although  Chinese  exports  to  other EMDEs  triple  from  2024  levels  to  exceed  1.2 million  units,  their  share  in domestic sales in these markets falls below 40% as local output grows. By 2035, exports could reach around 1.6 million units - one-fifth of China's total but make up only 25% of other EMDE sales.

Figure 5.23 Electric car supply by origin in emerging markets other than China and India in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: EMDEs = emerging markets and developing economies. Electric cars refer specifically to passenger cars and pickup trucks, and include battery electric and plug-in hybrids. Domestic refers to vehicles produced and sold in the focus region. Electric car stockpiling is excluded from the analysis.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Chinese electric car exports to other EMDEs triple from 2024 to over 1.2 million units by 2030, but China's share of that market falls below 40% as local output grows.

## Battery supply chain dependence on China

Without  stronger  efforts  to  diversify  battery  supply  chains,  Chinese  export controls - if fully enforced - could severely disrupt battery production outside China (see Chapters 1 and 4). Despite substantial recent investment in cell manufacturing in the United States and Europe, midstream segments remain a major vulnerability. Production of cathode precursors and cathode and anode active materials is still heavily concentrated in China.

Korea currently leads diversification efforts for battery components, but these have  focused  mainly  on  NMC  cathode  materials.  Capacity  for  lithium  iron

phosphate (LFP) materials, NMC and LFP cathode precursors, and graphite anodes remains limited. Much of the  technical expertise  and  manufacturing know-how for these critical steps is still held by Chinese companies.

Project pipelines indicate that this imbalance will persist through 2030, leaving China with considerable leverage. If exports of these components were fully restricted in 2030, up to two-thirds of battery cell production outside China could be  curtailed.  Meeting  demand  would  require  higher  imports  of  completed batteries from China, potentially more than doubling Chinese exports in 2030 an additional 400-650 GWh. This would be equivalent to roughly USD 30-50 billion in additional imports on a net basis. 4

## Figure 5.24 Chinese battery exports in the Stated Policies Scenario and additional export requirements if key component precursor exports were halted, 2030

<!-- image -->

Additional export requirements

IEA. CC BY 4.0.

Notes: Additional export requirements reflect the reliance on imports of battery to meet demand outside China, where battery demand is assumed to be inflexible. Export bans are assumed to take effect in 2030, at a point in time that is here assumed would hinder new manufacturing investments from becoming operational in order to ease supply constraints during that year. The analysis assumes a complete halt in Chinese exports of all cathode precursors or anode active materials. Precursors refer to intermediate compounds used in the production of cathode active materials, accounting for differences in cathode chemistry.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Were  Chinese  battery  precursor  exports  to  be  fully  restricted  in  2030,  two-thirds  of  cell production outside China could be curtailed, potentially doubling Chinese battery exports.

4 This includes both additional battery imports and reduced battery component imports. The analysis assumes an average battery price across all applications of USD 85/kWh, an average precursor materials price of USD 10/kWh and an average anode active materials price of USD 5/kWh.

## Electrolysers

## Global trends

Electrolysers, which use electricity to split water into hydrogen and oxygen, are a  key  technology  for  producing  low-emissions  hydrogen  from  renewable  or nuclear power. Global installed electrolyser capacity is rising rapidly, driving most of the growth in low-emissions hydrogen supply in 2024 (with most of the remainder  from  natural-gas-based  hydrogen  facilities  equipped  with  carbon capture and storage). In 2024, electrolytic hydrogen accounted for around 20% of total low-emissions hydrogen output, up from just 4% in 2020, and is set to reach 50% within 2 years based on committed capacity additions.

Medium-term  demand  prospects  remain  strong.  In the STEPS,  global electrolyser demand grows from about 3 GW 5  in 2024 to 9 GW in 2030 and 17 GW in 2035. This is driven by policy measures to support hydrogen demand and  lower  the  cost  of  electrolytic  hydrogen  to  end  users,  as  the  cost  of production remains far higher than that of hydrogen produced conventionally (see Chapter 2). China remains the largest market, representing over 30% of demand in 2030, while other EMDEs emerge as notable buyers, accounting for 20% of sales. In 2024, two-thirds of deployment was concentrated in China and most of the rest in advanced economies (Figure 5.25). In the NZE Scenario, demand for  electrolysers  grows  much  faster,  reaching  80 GW  in  2030  and 150 GW in 2035.

At present, almost all electrolyser demand is met by domestic manufacturing, with little trade across major regions. This reflects the market's early stage, the localised nature of production and the high cost of shipping bulky equipment. For  large-scale  projects,  building  near  the  end-use  site  or  shipping  semiassembled components is typically cheaper, especially when plants are tailored to local conditions. However, rising global demand is set to change this. In the STEPS, the share of exports in China's electrolyser output climbs from almost zero in 2024 to more than 40% by 2030, with EMDEs emerging as the primary destinations over this period. India is building manufacturing capacity under its National  Green  Hydrogen  Mission,  which  is  sufficient  to  meet  all  domestic needs in the STEPS by 2030.

5 This only includes manufacturing for water electrolysis. Taking into account manufacturing for chlor-alkali, global electrolyser demand reached around 4 GW in 2024 (IEA, 2025b).

Figure 5.25 Global manufacturing and inter-regional net trade flows of electrolysers in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: AEs = advanced economies; EMDEs = emerging markets and developing economies. Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Inter-regional trade in electrolysers is set to take off in the next 5 years as demand surges worldwide, with China emerging as a major exporter to advanced and emerging economies.

Alkaline  electrolysers  -  a  more  mature  technology  with  a  long  history  of deployment in the chlor-alkali industry - are expected to remain the leading technology in the medium term, accounting for almost 60% of manufacturing capacity  by  2030  based  on  project  announcements.  The  technology  is particularly  dominant  in  China,  accounting  for  more  than  90%  of  existing manufacturing  capacity.  As  with  other  mass-manufactured  clean  energy technologies,  Chinese  plants  are  generally  very  large,  their  size  averaging three times those in Europe. This allows Chinese companies to take advantage of economies of scale to lower the costs.

## Manufacturing capacity overhang

Electrolyser manufacturing capacity reached 38 GW by the end of 2024, based on nominal facility sizes from company announcements - an increase of more than 11 GW from 2023. However, utilisation rates remain at around 10%, as demand  has  grown  more  slowly  than  was  anticipated  when  much  of  this capacity  was  planned.  Several  installation  projects  have  been  delayed  or

cancelled  as  developers  struggle  with  high  costs,  uncertain  demand  and regulatory environments, and slow infrastructure development (IEA, 2025b). As a result, many manufacturers have faced mounting losses; in some cases this has led to bankruptcy, as with French producer McPhy, which entered judicial liquidation in July 2025, with part of its assets being acquired by John Cockerill (McPhy,  2025).  Others  have  paused  factory  operations  and  announced  job cuts.

The imbalance between capacity and demand is set to worsen through the late 2020s, with announced manufacturing additions continuing to outpace growth in  installations  -  despite  a  sharp  slowdown  in  new  manufacturing  project announcements and project cancellations over the  past year,  particularly  in advanced  economies.  If  all  planned  projects  proceed,  global  electrolyser manufacturing  capacity  would  approach  190  GW  by  2030  -  far  above  the projected demand of around 9 GW in the STEPS but broadly aligned with the requirements of the NZE Scenario. However, less than 15% of these planned additions have reached FID to date.

Figure 5.26 Average electrolyser plant size by region, and projected output from existing and committed manufacturing capacity in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario. The projections assume an 85% utilisation rate for the announced committed capacity in 2030, which is the sum of the announced committed capacity and the existing capacity at the end of 2024.

Sources: IEA analysis based on a range of data sources; see IEA (2026) for details.

Announced  electrolyser  manufacturing  capacity  additions  continue  to  outstrip  projected demand growth in the STEPS, aggravating the already existing large capacity overhang.

## Heat pumps

## Global trends

The manufacturing of heat pumps for building applications remains geographically  diverse,  though  upstream  segments  such  as  component production are more concentrated. In 2024, only around 15% of heat pumps installed worldwide by capacity were traded across borders, with most demand met  by  domestic  production.  All  major  markets  -  China,  the  United States, Europe and Japan - sourced over 70% of their heat pump supply locally. Global manufacturing capacity is around 145 GW led by China (35%), followed by the United States (25%) and the European Union (20%).

Global demand remained sluggish in 2023 and 2024, prompting little change in manufacturing capacity. The surge of factory expansion plans announced in 2022 - mainly in Europe, where sales had doubled in 2 years - has stalled after two consecutive annual declines: falling 10% in 2023 and more than 20% in 2024, in capacity terms. This downturn has weighed on international trade. The largest  recent  trade  flow  -  Chinese  exports  to  Europe  -  peaked  in  2022 alongside record regional sales but has since fallen 40%, in line with installation declines.

Product types vary by region: central ducted air distribution systems dominate in the United States, hydronic units are common in parts of Europe, while in Japan and central-southern China, multiple reversible air conditioners are often used for space heating. Local manufacturers benefit from tailoring products to national  standards  and  consumer  preferences,  with  after-sales  service  and brand familiarity reinforcing domestic sourcing. Industrial policies, such as the EU  NZIA,  which  supports  manufacturing  ecosystems  including through streamlined permitting, further support local production. Ongoing discussions in France on linking heat pump subsidies to products 'made in Europe', and in Poland  on  regulatory  changes  that  could  disadvantage  imported  certified models, also reflect this broader push toward local manufacturing.

Heat pump manufacturing is projected to grow sharply over the next decade on the back of a sales rebound. Key policy drivers include heat pump subsidies, building  energy  codes,  carbon  pricing,  national  heat  plans  and  heat  pump targets,  as  well  as  policies  aimed  at  training  and  skills  development.  In  the STEPS, capacity rises 80% in China, more than doubles in the United States and rises by about 40% in the European Union by 2035. By then, these three markets account for 85% of global manufacturing capacity and 80% of demand, cementing their central role in shaping the industry's future. Trade follows a similar path, with inter-regional heat pump flows more than doubling by 2035,

though the share of traded equipment in global sales remains at 20%, as today, reflecting the dominance of domestic production (Figure 5.27). Modest demand growth in other EMDEs (excluding China) - mostly in smaller Asian economies, as well as in Eastern Europe and Latin America - is met largely by Chinese exports, reinforcing China's position as the leading supplier.

Figure 5.27 Global manufacturing and inter-regional net trade flows of heat pumps in the Stated Policies Scenario, 2024-2035

<!-- image -->

IEA. CC BY 4.0.

Notes: AEs = advanced economies; EMDEs = emerging markets and developing economies.

Source: IEA analysis based on a range of data sources; see IEA (2026) for details.

Global  heat  pump  trade  is  set  to  more  than  double  by  2035,  though  the  major  markets continue to source most of their heat pumps domestically.

The heat pump market grows even faster in the NZE Scenario, with global sales more than quadrupling to 2035 on the back of far stronger policy measures than those currently in place. Global manufacturing capacity grows at a similar pace to domestic demand, but at a slightly faster pace in China than in advanced economies. Some other EMDEs, especially those with strong air conditioner industries, expand production of reversible heat pumps, though their share in global  output  remains  modest  at  around  5%.  International  trade  grows  in parallel  with  rising  demand,  increasing  fivefold  between  2024  and  2035. However, most installations rely on domestic supply: by 2035 only one in four heat pumps is traded inter-regionally, while three-quarters are produced and installed locally.

The Kigali Amendment to the Montreal Protocol - an international agreement to phase down the consumption and production of hydrofluorocarbons (HFCs) - is prompting heat pump manufacturers, which use these gases, to adapt their product  offerings,  with  potentially  significant  effects  on  global  trade  flows. HFCs,  which  replaced  ozone-depleting  refrigerants,  are  potent  GHGs.  The pace of their phase-down under the agreement varies by country, with the most developed economies required to act fastest. In response, manufacturers are redesigning products and adjusting supply chains. This shift creates strategic opportunities for  first  movers  -  particularly  those  investing  early  in  potential technologies with low global warming potential - to secure a competitive edge in future export markets.

## Role of air conditioning component manufacturers

Many components used in heat  pumps  are  similar  to  those  used  in  the  air conditioning industry; a reversible air conditioner is essentially a heat pump. Consequently, countries and companies with strengths in cooling equipment manufacturing - such as for compressors, heat exchangers and inverters - are often well-positioned to lead on component supply for heat pump manufacturers.

Although  the  market  for  heat  pumps  used  as  primary  heat  equipment  is expanding quickly, it remains far smaller than the global cooling market, which is an order of magnitude larger. For example, around 2.5 million heat pumps were  sold  in  Europe  in  2024  -  the  same  number  of  air  conditioners  (ACs) produced in China in only around four days. This disparity reflects the maturity and scale  of  air  conditioning  demand,  and  points  to  significant  potential  for technology transfer, supply chain synergies and economies of scale as heat pump adoption accelerates.

Unlike heat pump assembly, which is relatively geographically diverse, some upstream components common to both technologies, such as compressors, remain heavily concentrated in China. In 2024, manufacturers based in China represented  90%  of  global  air  conditioner  manufacturing  capacity.  This concentration  extends  upstream:  China  is  the  largest  global  producer  and exporter of rotary compressors, used in most small-capacity residential cooling and heat pump systems, with 90% of global rotary compressor manufacturing capacity  in  2024.  Scroll  compressor  production  -  more  common  in  larger residential and light commercial systems - is somewhat more geographically distributed, but China remains a key player in this segment as well.

Figure 5.28 Global manufacturing of heat pumps and components (compressor units), 2024, and sales of air conditioners in the Stated Policies Scenario, 2024-2035

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

Notes: STEPS = Stated Policies Scenario. Manufacturing capacity in this figure refers to number of units. For heat pumps, rotary compressors are mostly used in small size units, especially air-to-air units.

Sources: IEA analysis based on ChinaOL (2025) and Sinoimex (2025).

China's  90%  share  of  rotary  compressor  manufacturing  is  advantageous  for  its  AC producers, with sales projected to remain ten times higher than heat pumps through 2035.

Compressor  supply  chains  also  underline  the  scale  gap  between  the  two markets. Roughly 75% of rotary compressor output is used in air conditioners, while only 5% goes into heat pumps. In addition, most major heat pump and air conditioning manufacturers are vertically integrated with compressor production, either through in-house facilities or joint ventures. Companies such as Panasonic, Daikin, Midea, Gree and Carrier produce compressors directly, giving them greater control over cost, performance and supply chain resilience. This integration allows them to tailor compressor designs to specific product lines, secure critical components during supply disruptions and strengthen their competitive position across both heating and cooling markets.

These synergies between air conditioners and heat pump supply chains, along with the competitive advantage of air conditioner manufacturers, are expected to persist in the future. In the STEPS, air conditioner sales increase by 20% to 2035.  While  heat  pumps  sales  grow  more  rapidly,  doubling  over  the  same period, the total number of air conditioners sold remains far more than five times higher than that of heat pumps.

## References

ACEA. (2025, July 24). New car registrations . Retrieved from https://www.acea.auto/pcregistrations/new-car-registrations-1-9-in-h1-2025-battery-electric-15-6-market-share/

Baker McKenzie. (2024). Thailand: Extension of the customs duty incentives for completely built-up BEVs imported from 1 January 2024 to 31 December 2025 . Retrieved from https://insightplus.bakermckenzie.com/bm/tax/thailand-extension-of-the-customs-dutyincentives-for-completely-built-up-bevs-imported-from-1-january-2024-to-31-december2025

BNEF. (2025a). China Wind Turbine Export Update: Momentum Builds. BNEF.

BNEF. (2025b). Tariffs lift output at US car plants, shift focus from EVs. BNEF.

Brazil, Ministry of Development. (2023). Minutes of the 209th regular meeting of the executive management committee (GECEX) of the chamber of foreign trade (CAMEX) . Retrieved from https://www.gov.br/mdic/pt-br/assuntos/camex/atas/gecex/2023/ata-da-209areuniao-ordinaria-do-gecex.pdf

ChinaOL. (2025). Monthly China's Household EC Production . Retrieved from https://data.chinaiol.com/ecdata/index

Clean Investment Monitor. (2025). The State of US Clean Energy Supply Chains in 2025 . Retrieved from https://www.cleaninvestmentmonitor.org/reports/q3-2025-update

EIA. (2025). OPEC Revenues Fact Sheet . Retrieved from https://www.eia.gov/international/analysis/special-topics/OPEC\_Revenues\_Fact\_Sheet

European Commission. (2024a). Discussions on undertakings for electric vehicles in Beijing . Retrieved from https://policy.trade.ec.europa.eu/news/discussions-undertakingselectric-vehicles-beijing-2024-11-08\_en

European Commission. (2024b). EU Commission imposes countervailing duties on imports of battery electric vehicles (BEVs) from China . Retrieved from https://trade.ec.europa.eu/access-to-markets/en/news/eu-commission-imposescountervailing-duties-imports-battery-electric-vehicles-bevs-china

European Commission. (2025a). Enabling framework for renewables . Retrieved from https://energy.ec.europa.eu/topics/renewable-energy/enabling-framework-renewables\_en

European Commission. (2025b). Net-Zero Industry Act to further accelerate decarbonisation technologies manufacturing in the EU . Retrieved from https://ec.europa.eu/commission/presscorner/detail/en/ip\_25\_1324

European Commission. (2025c). Communication from the commission to the european parliament, the council, the european economic and social committee and the committee of the regions . Retrieved from https://transport.ec.europa.eu/document/download/89b3143e-09b6-4ae6-a826-932b90ed0816\_en?filename=Communication%20-%20Action%20Plan.pdf

European Commission. (2025d). The Net-Zero Industry Act . Retrieved from https://singlemarket-economy.ec.europa.eu/industry/sustainability/net-zero-industry-act\_en

European Council. (2025). EU-China summit, 24 July 2025 . Retrieved from https://www.consilium.europa.eu/en/meetings/international-summit/2025/07/24/

Finn, R. (2025). COSCO SHIPPING Launches New Vehicle Carrier Service at Port of Piraeus, Bolstering Transshipment Hub Status. Logistic Manager . Retrieved from https://logistics-manager.com/cosco-shipping-launches-new-vehicle-carrier-service-atport-of-piraeus-bolstering-transshipment-hub-status/

- GX. (2025). 第二回公募 [2nd Round Public Offering] . Retrieved from https://gxsupplychain.jp/assets/pdf/gx\_list\_saitaku20250124.pdf
- ICCT. (2025). Record electric vehicle sales show American demand - Will U.S. automakers deliver or retreat? Retrieved from https://theicct.org/record-electric-vehicle-sales-showamerican-demand-will-us-automakers-deliver-or-retreat-nov25/
- IEA. (2024a). Advancing Clean Technology Manufacturing. Retrieved from https://www.iea.org/reports/advancing-clean-technology-manufacturing

IEA. (2024b).

Energy Technology Perspectives 2024.

Retrieved from https://www.iea.org/reports/energy-technology-perspectives-2024

- IEA. (2025a). Global EV Outlook 2025 . Retrieved from https://www.iea.org/reports/global-evoutlook-2025
- IEA. (2025b). Global Hydrogen Review 2025 . Retrieved from https://www.iea.org/reports/global-hydrogen-review-2025
- IEA. (2025c). The battery industry has entered a new phase . Retrieved from https://www.iea.org/commentaries/the-battery-industry-has-entered-a-new-phase
- IEA. (2026). Manufacturing and Trade Model Documentation. Retrieved from https://www.iea.org/reports/manufacturing-and-trade-model

India, Ministry of Heavy Industries. (2024). Scheme to Promote Manufacturing of Electric Passenger Cars in India . Retrieved from https://heavyindustries.gov.in/schemepromote-manufacturing-electric-passenger-cars-india-0

India, Ministry of New and Renewable Energy. (2025). No. 293/8/2017-Wind . Retrieved from https://cdnbbsr.s3waas.gov.in/s3716e1b8c6cd17b771da77391355749f3/uploads/2025/ 04/20250417480611676.pdf

International Trade Administration. (2025a). Crystalline Silicon Photovoltaic Cells, Whether or Not Assembled Into Modules From the Socialist Republic of Vietnam: Amended Final Antidumping Duty Determination; Crystalline Silicon Photovoltaic Cells, Whether or Not Assembled Into Modules From Cambodia . Retrieved from https://www.federalregister.gov/documents/2025/06/24/2025-11588/crystalline-siliconphotovoltaic-cells-whether-or-not-assembled-into-modules-from-the-socialist

Japan, Ministry of Economy, Trade and Industry. (2020). Overview of the Vision for Offshore Wind Power Industry . Retrieved from https://www.enecho.meti.go.jp/category/saving\_and\_new/saiene/yojo\_furyoku/dl/vision/ vision\_first\_overview\_en.pdf

Kang, L. (2025). SAIC adds new 9,500-car cargo ship, bringing its fleet to 36 car carriers. CnEVPost . Retrieved from https://cnevpost.com/2025/06/13/saic-adds-new-9500-carcargo-ship/

Légifrance. (2024). Décret n° 2024-102 du 12 février 2024 relatif aux aides à l'achat ou à la location de véhicules peu polluants [Decree No. 2024-102 of 12 February 2024 on aid for the purchase or rental of low-emission vehicles] . Retrieved from https://www.legifrance.gouv.fr/jorf/id/JORFTEXT000049130533

McPhy. (2025). John Cockerill Hydrogen appointed as the buyer of the majority of McPhy's activities, including the Belfort Gigafactory . Retrieved from https://www.mcphyfinance.com/images/PDF/cp/gb/2025/McPhy\_PR\_LJ\_Opening\_EN\_97f7c.pdf

MEC+. (2025). Ramping up Local Manufacturing for Wind Turbines in India. MEC+. Retrieved from https://mecintelligence.com/mec-perspectives/adb-mec-report/adb-windmanufacturing

Medina, A. F. (2024). Indonesia Issues New Tax Incentives to Spur EV Production and Sales. ASEAN Briefing . Retrieved from https://www.aseanbriefing.com/news/indonesia-issuesnew-tax-incentives-to-spur-ev-production-and-sales/

- Ren, D. (2025). China's BYD expands car-carrier fleet to bolster EV exports amid furious domestic competition. South China Morning Post . Retrieved from https://www.scmp.com/business/china-business/article/3315626/chinas-byd-expandscar-carrier-fleet-bolster-ev-exports-amid-furious-domestic-competition
- Reuters. (2023). Germany to end e-vehicle subsidy programme . Retrieved from https://www.reuters.com/business/autos-transportation/germany-end-e-vehicle-subsidyprogramme-2023-12-16/

Rystad Energy. (2023). The State of the European Wind Energy Supply Chain . Retrieved from https://windeurope.org/intelligence-platform/product/the-state-of-the-europeanwind-energy-supply-chain/

S&amp;P Global. (2025).

Commodity Insights

. Retrieved from https://www.spglobal.com/commodity-insights/en

Sinoimex. (2025). Global Trade &amp; Industry Growth Lab . Retrieved from https://www.sinoimex.com/en/index

State Council. (2025). China's foreign trade hits new high in 2024 . Retrieved from https://english.www.gov.cn/archive/statistics/202501/13/content\_WS6784a546c6d0868f 4e8eec59.html?

- T&amp;E. (2025). Europe's automotive industry at a crossroads . Retrieved from https://www.transportenvironment.org/articles/europes-automotive-industry-at-acrossroads

The Maritime Executive. (2025). China Puts Largest Car Carrier into Service, Launches First Methanol PCTC. Retrieved from https://maritime-executive.com/article/china-putslargest-car-carrier-into-service-launches-first-methanol-pctc

The White House. (2025). Fact Sheet: President Donald J. Trump Adjusts Imports of Automobiles and Automobile Parts into the United States . Retrieved from https://www.whitehouse.gov/fact-sheets/2025/03/fact-sheet-president-donald-j-trumpadjusts-imports-of-automobiles-and-automobile-parts-into-the-united-states/

UN Trade &amp; Development. (2025). Merchandise: Total trade and share . Retrieved from https://unctadstat.unctad.org/datacentre/dataviewer/US.TradeMerchTotal

US Congress. (2024). S.4237 - ELITE Vehicles Act . Retrieved from https://www.congress.gov/bill/118th-congress/senate-bill/4237/text

US Congress. (2025a). H.J.Res.88 - 119th Congress (2025-2026) . Retrieved from https://www.congress.gov/bill/119th-congress/house-joint-resolution/88/text

- US Congress. (2025b). H.R.1 - One Big Beautiful Bill Act . Retrieved from https://www.congress.gov/bill/119th-congress/house-bill/1

US Department of Transportation. (2025). Resetting the Corporate Average Fuel Economy Program . Retrieved from https://www.federalregister.gov/documents/2025/06/11/202510586/resetting-the-corporate-average-fuel-economy-program

- US Environmental Protection Agency. (2025). Proposed Rule: Reconsideration of 2009 Endangerment Finding and Greenhouse Gas Vehicle Standards . Retrieved from https://www.epa.gov/regulations-emissions-vehicles-and-engines/proposed-rulereconsideration-2009-endangerment-finding

WindEurope. (2023). The State of the European Wind Energy Supply Chain . Retrieved from https://windeurope.org/data/products/the-state-of-the-european-wind-energy-supplychain/

- Yusry, M. (2024). Going EV: What the Malaysian government is doing to charge up the transition. Malay Mail . Retrieved from https://www.malaymail.com/news/malaysia/2024/07/09/going-ev-what-the-malaysiangovernment-is-doing-to-charge-up-the-transition/141965?

Zhang, L. (2025). The One Big Beautiful Bill Act that redefines the US clean energy initiatives . Retrieved from https://www.crugroup.com/en/communities/thought-leadership/2025/theone-big-beautiful-bill-act-that-redefines-the-us-clean-energy-initiatives/

## Part C

## Supply  chain  risks  and  industrial competitiveness

Enhancing  supply  chain  security  and  industrial  competitiveness  are  important policy objectives that, if not addressed, could form stumbling blocks for energy and climate policy goals. Clean energy technology supply chains encompass a broad set of components and materials: for most countries, it is not possible to compete in all steps of a technology supply chain, let alone in all supply chains. Measures  to  enhance  security  of  supply  or  boost  competitiveness  can  entail significant costs. Governments can therefore benefit from data-driven insights into their countries' relative strengths and weaknesses in different supply chains when designing industrial strategies and prioritising action.

Part C of this report assesses the risks posed by high levels of concentration in the supply chains of selected clean energy technologies (Chapter 6), examines the drivers and trends in industrial competitiveness across regions, and explores strategies for narrowing competitiveness gaps in selected clean energy technologies as a means  of promoting diversification and reducing the concentration  of  supply  (Chapter  7).  It  ends  with  an  overview  of  strategic considerations  for  navigating  tensions  and  trade-offs  between  different  policy goals in view of security risks and competitiveness challenges (Chapter 8).

## Chapter 6. Supply chain risks

## Highlights

-  Supply chain security remains a challenge: Clean energy technology manufacturing  is  highly  geographically  concentrated,  with  China  as  the  main supplier in most supply chain stages. China accounts for around 85% of solar and 80%  of  lithium-ion  battery  supply  chain  production  capacity,  and  even  higher shares for PV wafers (95%) and anode materials (97%). Cybersecurity considerations further enhance the importance of addressing security of supply.
-  An 'N-1' assessment, which models the impact of losing the largest exporter in each supply chain, shows that for the final downstream stages of most of the four technologies  examined  -  solar  PV,  wind,  batteries  and  heat  pumps  -  capacity outside China could, in theory, have met most non-Chinese demand in 2024. Yet each of these supply chains contains several steps where production outside the largest exporter is not sufficient to meet demand, and at least one step where it covers less than one-quarter. A supply chain is only as secure as its weakest link.
-  No major change in the security of global clean energy technology supply chains is likely before the end of the current decade, based on committed manufacturing and mining projects and projected market trends based on today's stated policy settings.
-  The impact of Chinese clean energy technology manufacturing companies extends beyond the  country's  borders.  Chinese  firms  account  for  a  large  portion  of  the production  capacity  located  outside  China  in  the  solar  PV  industry.  Such  high market concentration can create risks, particularly in the event of major firms facing financial  difficulties,  labour  disputes  or  being  targeted  by  sanctions.  For  most technologies, the largest company holds between 5% and 20% of global production capacity.
-  Applying the 'N-1' analysis to the facility level for each of supply chains reviewed above reveals that, in each segment, the largest facility had the capacity to supply between 2% and 17% of global demand in 2024. Solar PV wafer manufacturing sits towards the top of this range, with one facility in the Inner Mongolia province, China, capable of producing the equivalent of the entire solar PV demand of the European Union and India combined. Fires at Chinese polysilicon plants in 2020 and 2022 caused major global price spikes and supply bottlenecks.
-  Concentration is also high in metal and mineral refining. China processes over 70% of lithium, cobalt, graphite and rare earths. Similarly, in mining, two-thirds of cobalt comes from the Democratic Republic of the Congo, and 85% of natural graphite from China. This heightens exposure to risks of disruption.
-  Around half of global clean energy technology trade passes through the Strait of Malacca,  the  sector's  most  critical  shipping  chokepoint.  Blockages  at  Malacca, Suez, or other major routes could increase transit times, fuel use and freight costs, underscoring the importance of diversified transport networks for supply security.

## Supply chain security

The supply chains for clean energy technologies differ markedly from those for fossil  fuels,  with  far-reaching  implications  for  energy  security  and  resilience  to supply  disruptions.  The  transition  to  clean  energy  puts  the  spotlight  on  critical minerals and other inputs needed to manufacture clean technologies. The supply of both the material inputs and final technologies is often far more geographically concentrated than for fossil fuels. Global market concentration - measured as the share of a given market held by a small number of businesses - is also very high for several technologies.

While global supply chains are not inherently more vulnerable than domestic ones, dependence on imports can pose risks, particularly when a large share of supply comes  from  countries  facing  acute  geopolitical  threats  such  as  conflict,  social instability, unfair trade practices or human rights concerns. Concentrated supply chains  are  also  more  exposed  to  natural  disasters,  industrial  accidents  and deliberate efforts to manipulate supply or prices. The concentration of production in a single or small number of countries also heightens dependence on specific maritime trade routes, which can be vulnerable to disruption - especially where they pass through critical chokepoints. Trade-related policy changes can further disrupt markets when exporters or importers rely too heavily on a single trading partner.

The energy security paradigm is evolving with the growing use of clean energy technologies. Disruptions to their supply chains typically have less immediate and severe economic effects than disruptions to fossil fuel supplies. This is because fossil fuels are primary energy sources, whereas clean energy technologies are assets that generate electricity or deliver energy services. For example, a shortage of new solar PV panels does not affect electricity output from existing installations, but  it  does  limit future capacity.  Nonetheless,  over  time,  prolonged  supply constraints  could  slow  the  deployment  of  clean  energy  technologies  and  raise costs.  Meanwhile,  the  growing  reliance  on  electricity  underscores  the  need  to strengthen power system security and reliability.

Geographical diversification of supply chains - including greater use of domestic resources  and  manufacturing,  and  reduced  reliance  on  imports  from  a  small number  of  countries  -  can  be  an  effective  means  of  improving  security  and resilience. However, for certain stages of production, this is not always feasible due  to  limited  or  uneconomic  production  capacity.  At  present,  clean  energy technology  manufacturing  and  trade  are  highly  concentrated,  with  People's Republic of China (hereafter, 'China') commanding global output. This reflects a combination  of  relatively  low  production  costs,  government  policy  and  traderelated measures.

This chapter assesses the risks posed by high levels of regional concentration in the supply of final clean energy technology products and key components.

## Concentration of supply

Clean  energy  technology  supply  chains  are  significantly  more  concentrated geographically  than  those  of  fossil  fuels.  Each  step  of  the  supply  chain  has different levels of concentration; by weighting the concentration of each step by their  respective  contribution  to  the  value  of  final  technologies,  it  is  possible  to obtain a single concentration metric. On this measure, a single producer - China -  provides  over  85%  and  80%  of  the  global  supply  capacity  of  solar  PV  and batteries, respectively (Figure 6.1). Of the five main technologies, China's supply chain dominance is the lowest for heat pumps, for which it has just under a 60% share  of  global  capacity.  By  contrast,  the  members  of  the  Organization  of  the Petroleum Exporting Countries (OPEC) together account for only around one-third of global oil supply and 15% of gas supply.

Figure 6.1 Geographic concentration of supply chains for selected industrial products, fossil fuels and clean energy technologies by region, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: OPEC = Organization of the Petroleum Exporting Countries; Li-ion = lithium-ion; REE = rare earth elements Bars show  the  value-weighted  average  geographical  concentration  of  the  leading  producer  across  the  entire  supply  chain, excluding resource extraction (mining). The whiskers represent the least and most concentrated step within the industrial process stages of the supply chain for each technology. For fossil fuels and selected products, geographical concentration refers to production. For semiconductors and clean energy technologies, it refers to manufacturing capacity. Heat pumps include both assembly and compressors manufacturing. Battery refers to battery cells and anodes to anode active materials. Nickel refining for li-ion batteries refers to nickel sulphate.

Sources: IEA analysis based on BCG-SIA (2024), Meier (2025), IFR (2024).

China controls 60-85% of the five key clean energy technology supply chains - a far higher level of concentration than for oil and gas and most other strategic products.

The degree of concentration in clean energy technology manufacturing in China surpasses  the  levels  of  industrial  specialisation  observed  in  other  leading economies. By comparison, Japan accounted for around 38% of global industrial robotics  output  in  2024,  while  Europe  supplied  just  under  60%  of  worldwide commercial aircraft deliveries. China's position reflects the sustained effectiveness of its manufacturing-oriented policies, underpinned by cost competitiveness,  innovation,  extensive  materials  production  capabilities  and consistent policy support, which together have enabled the country to achieve a high degree of industrial self-reliance across a wide range of sectors, extending well beyond clean energy technologies.

China's strength in the clean energy technology sector is especially pronounced for mass-produced technologies and components. Elsewhere in the Asia Pacific region, manufacturing remains concentrated in technologies where countries hold strong intellectual property and manufacturing advantages, such as batteries and solar PV. By contrast, production of large, site-specific technologies, such as lowemissions fuel facilities and wind turbine towers, is less concentrated, reflecting the  high  cost  of  shipping  bulky  equipment  and  the  need  for  substantial  local infrastructure.

Concentration levels vary along clean energy technology supply chains, with final products generally displaying lower geographic concentration than intermediate components. In the solar PV supply chain, for example, China accounts for around 80% of global module production capacity, compared with about 95% for wafers. A similar pattern is observed in batteries: China holds roughly 85% of global cell assembly capacity but as much as 97% for anode active material.

Intermediate  products  are  typically  more  energy-intensive,  require  specialised technical capabilities while offering lower profit margins. As a result, diversifying production outside China tends to be harder for these stages than for final product manufacturing. In addition, producers of manufacturing equipment for goods that are almost exclusively made in China are themselves predominantly Chinese, as demand for their machine tools constitutes nearly their entire market.

Further upstream, mineral refining also shows very high geographical concentration. China processes more than 70% of global lithium, cobalt, graphite and  rare  earth  supplies.  In  contrast,  raw  material  extraction  is  generally  more geographically diverse, reflecting the distribution of natural resource endowments. China is therefore not the leading producer for all raw materials required in these supply chains. Nonetheless, mining activities for some key minerals remain highly concentrated: around two-thirds of global cobalt output originates in the Democratic  Republic  of  the  Congo  (DRC),  while  85%  of  natural  graphite production takes place in China (IEA, 2025c).

Market concentration in clean energy technology supply chains is also pronounced. Whereas traditional energy technologies are produced by companies

based  in  multiple  countries,  clean  energy  manufacturing  is  disproportionately controlled by firms headquartered in a single country - predominantly China. For most of the key clean energy technologies and their components, Chinese firms collectively hold the majority of global manufacturing capacity; in the case of solar PV  cells  and  battery  anodes,  the  share  exceeds  85%  (Figure  6.2).  Such concentrated ownership heightens the risk of supply disruptions, whether from a major producer halting operations due to financial difficulties or from sanctions targeting specific companies. An example of the latter is China's Huawei, whose operations  in  the  United States  have  been  restricted  due  to  concerns  about surveillance and espionage.

Figure 6.2 Production capacity of selected clean energy technologies and components by region of company headquarters, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: The name and market share of the largest manufacturer is shown on the right side of each bar. Batteries refers to lithium-ion battery cells. HYNEBM refers to Hunan Yuneng New Energy Battery Material Co Ltd.,

Sources: IEA analysis based on BNEF (2025a), Benchmark Minerals Intelligence (2024), WindEurope (2023), GWEC (2024), GWEC (2022), InfoLink (2025), S&amp;P Global (2025) and ChinaIOL (2025).

Almost all the leading clean energy technology manufacturing companies are headquartered in China, often holding a global market share exceeding that of entire regions.

## Implications for security and resilience

Secure  and  resilient supply chains  are needed  to  ensure  adequate  and uninterrupted  supplies  of  raw  and  intermediate  materials,  components  and equipment at every stage of production, as well as the timely delivery of finished products to end users (IEA, 2024a). In IEA parlance, energy security refers to adequate and timely investments to ensure supply stays in line with demand, while resilience refers to the ability of energy systems to handle physical disruptions along  supply  chains.  A  high  degree  of  geographic  and  market  concentration threatens both the security and resilience of supply chains.

Secure supply chains are supported by diversity in both suppliers and technologies, which fosters competition, provides flexibility and maintains efficient spare capacity. Such diversity helps stabilise prices and ensures price formation is transparent, providing clear investment signals and effective hedging opportunities for market participants. Threats to security often arise from underinvestment in specific supply chain segments, leading to global supply-demand imbalances.  Resilient  systems  must  be  able  to  respond  and  adapt  rapidly  to sudden market shocks - whether related to supply, demand or price - by coordinating with alternative supply chains capable of delivering equivalent technologies or services. Diversity of supply can also help mitigate the impact of such shocks.

In  practice,  there  are  significant  risks  to  the  security  and  resilience  of  energy supply  chains,  mainly  due  to  a  lack  of  supply  diversity,  with  the  potential  to severely disrupt energy markets. For example, the surge in critical mineral prices in 2022, driven by rapidly rising demand and pandemic-related supply disruptions, triggered the first-ever increase in electric vehicle (EV) battery prices. Likewise, China's  introduction  of  export  restrictions  on  magnets  containing  rare  earth elements  in  early  2025  forced  several  non-Chinese  manufacturers  of  electric motors and other machinery to halt production (Reuters, 2025). China announced additional export controls on supply chain components used to make EVs in the second half of 2025 (see Chapters 4 and 5). In both cases, the high degree of geographic and market concentration of certain supply chain segments exacerbated the impact of these market shocks. Energy supply chains - both for fossil fuels and clean energy technologies - must be robust enough to withstand such disruptions.

## Box 6.1 The increasing importance of cyber security

Energy security considerations related to clean energy technologies go beyond the risks to supply of physical assets. Increased electrification brings with it new security challenges related to the IT systems required to manage  the generation, transmission, distribution and use of electricity.

Electricity networks are the backbone of clean energy transitions. As digital controls, sensors  and  connected  devices  proliferate  in  order  to  integrate  renewables  and operate systems closer to their limits, exposure to cyber risk is growing in scale and complexity. The true picture is likely under-reported, yet available evidence shows a sharp increase: estimated attacks on critical infrastructure jumped 30% in 2023 to 420 million  worldwide,  and  the  average  number  of  attacks  on  energy  utilities  has quadrupled since 2020 (IEA, 2023; Checkpoint, 2026). In the United States, the grid's 'vulnerable points' are estimated to be increasing by 60 per day, from 21 000 in 2022 to  24 000  today  (knowbe4,  2024).  The  economic  toll  is  also  rising,  with  average breach costs at USD 4.83 million in 2025 (IBM, 2025).

In power  generation,  landmark  incidents  include  the  sabotage  of  enrichment centrifuges in Iran in 2010; the Aurora generator test, a live demonstration carried out in 2007 by the US government of a destructive, cyber-induced operation against a power plant; and a 2022 outage of satellite modems that cut remote monitoring and control for around 5 800 wind turbines in Germany (PV Magazine, 2022). Though less visible to the public, 22 Danish energy companies were breached over a few days in May 2023, prompting targeted disconnections and islanding to limit spread and avert wider consequences (cybernews, 2023).

At transmission level, a notable increase in the number and variety of attacks has been  seen  globally  since  Russia's  full-scale  invasion  of  Ukraine.  Nevertheless, Ukraine's experience shows defence is improving: while malware-driven operations cut power in 2015-16, attempts against nine high-voltage substations in 2022 were ultimately  contained  (US  Congress,  2024).  Campaigns  against  North American utilities  in  2017-18 demonstrated how stolen credentials and compromised vendor access can reach the transmission grid control-room (AP News, 2018) (CSIS, 2025).

## Risks are broadening with digitalisation and decentralisation

Distribution  networks  now  rely  on  advanced  distribution  management  systems, automated switches and millions of smart meters. Even when power flows remain stable, ransomware can disrupt customer-facing services: in Johannesburg (2019) (Help Net Security, 2019), billing systems and the pre-paid vending platform were knocked  offline;  in  Colombia  (2022)  (Finance  Colombia,  2022),  ransomware crippled customer systems, affecting over 300 000 customers.

As connected devices spread 'behind the meter,' small vulnerabilities can add up to system effects. Research indicates that hijacking less than 2% of system load (American Public Power Association, 2023), for example via compromised smart meters, can destabilise frequency if they are then switched in unison.

## Supply-chain cyber risk is now an evolving system issue

Global  supply  chains  introduce  dependencies  in  hardware,  firmware  and  cloud services,  as  well  as  pathways  to  access  critical  functions  through  compromised vendor  equipment.  This  risk  is  no  longer  theoretical.  In  2025,  authorities  in  the United States and European Union examined communications modules in imported inverters and  batteries, warning  about  the  potential for large-scale remote manipulation (Engineering, 2025) (MAYA, 2025). In 2024, Lithuania blocked remote access  by  Chinese  suppliers  to  solar,  wind  and  storage  control  systems,  citing national security concerns (PV Magazine, 2024).

In Europe, some  200 GW  of  installed PV  capacity is linked to Chinesemanufactured  inverters,  and  about  75%  of  new  inverters  originate  from  China, making firmware assurance and authenticated updates a priority. In the United States,  a  2019  seizure  and  inspection  of  a  Chinese-made  large  power transformer shipment, whose findings were not disclosed, reflected concerns about the  approximately  500  large  power  transformers  from  China  operating  in  the United States (knowbe4, 2025) (SecuretheGrid, 2023).

## Raising the floor on cyber risk in modern power systems

As grids digitalise and decentralise, exposure grows in ways that are often invisible to consumers: attacks may not always cut power, but they can degrade operations, disrupt  services  and  undermine  confidence.  Evidence  from  multiple  jurisdictions shows that despite adversaries becoming more capable and opportunistic, day-today operational discipline can stop most incidents from cascading. Sustaining trust therefore  means  treating  cybersecurity  as  integral  to  reliability,  adequacy  and flexibility, on par with physical assets and markets.

Policy is catching up: new  US  regulation now  requires supply-chain risk management  and  patch  authenticity  verification  as  part  of  energy-sector  cyber measures. Australia now empowers authorities to set conditions, mandate incident reporting and block high-risk equipment in critical systems. India issued guidelines in 2025 requiring that rooftop solar PV inverters only transmit data to servers hosted in India. Japan's 2024 regime allows authorities to intervene when 'specified critical facilities' rely on high-risk technologies or service arrangements. In parallel, utilities are embedding these expectations in procurement, so that supply-chain governance becomes part of day-to-day operations.

Investing in people and TSO-DSO co-ordination matters as much as technology, and international alignment can improve performance faster given shared suppliers and cross-border power flows (IEA, 2023). Progress can be tracked with a small set of  indicators,  such  as  the  share  of  critical  assets  meeting  operational  security baselines, the proportion of distributed energy resources connected under assured firmware,  time  to  detect  and  recover,  and  the  coverage  of  enhanced  supplier assurance. This can help to ensure that grids remain secure, reliable and affordable as digitalisation expands.

## Assessing dependencies in the supply chain

As  noted,  the  degree  of  geographic  concentration  of  production  differs  widely across  clean  energy  technology  supply  chains  and  among  different  stages  of those chains. However, concentration alone does not determine vulnerability: in some segments, substantial spare production capacity exists. This means that, in some cases, even the loss of a major supplier could be offset quickly by ramping up output in other countries with unused capacity.

To assess overall supply security and resilience, we conducted an 'N-1 analysis' of the leading clean energy technology supply chains. Commonly used in power system studies, this  method  evaluates  the  consequences  of  losing  the  largest asset - in this case, the largest exporter of a given technology or component regardless  of  the  cause.  Using  2024  data  and  assuming  that  all  other  plants produce  at  85%  of  their  nameplate  capacity,  we  estimate  the  share  of  global demand that could still be met without the largest exporter.  In 2024, China was 1 both  the  largest  producer  and  exporter  for  most  manufacturing  steps  of  clean energy technologies except for the mining of certain critical minerals, therefore in this analysis Chinese supply is excluded from all steps of the supply chain. The resulting share of global demand - excluding China - that could have been met provides an indication of the security and resilience of each supply chain. This exercise is not intended as a full simulation of the impact of potential disruptions, but rather as a way of highlighting where global supply chains are most dependent on a single source.

Results from this analysis vary sharply across and along supply chains. For the final downstream stages of most of the four technologies examined - solar PV, wind, batteries and heat pumps - capacity outside China could, in theory, have met  most  non-Chinese  demand  in  2024  (Figure  6.3).  However,  each  of  these supply  chains  contains  several  steps  where  production  outside  the  largest exporter is insufficient to meet demand, and at least one step where it covers less than one-quarter of demand. The lack of availability of supply of a single step could affect the entire supply chain, making it less secure.

In  metals  and  minerals  processing,  capacity  outside  the  leading  producer  is generally adequate for bulk materials such as steel and copper, but falls well short for  most  critical  minerals.  This  is  particularly  the  case  for  magnet  rare  earth elements  and  graphite,  as  refining  capacity  is  overwhelmingly  concentrated  in China. At the extraction stage, the leading producer for each mineral often differs from that for clean energy technologies, and mined ores serve a wide range of industries  beyond  clean  energy  applications.  As  a  result,  global  mining  output excluding  China  would  still  exceed  non-Chinese  demand  for  most  minerals, except for rare earths and to a larger extent graphite.

1 In this analysis, the global demand without the largest exporter is considered to be the demand for the final technology and all the intermediate steps that would be needed to satisfy it.

## Figure 6.3 Share of global demand  excluding  China  for  selected  clean energy technologies and components that could have been met without China, 2024

<!-- image -->

Electric cars

<!-- image -->

<!-- image -->

Heat pumps

<!-- image -->

## Supplier region

- Share of demand in STEPS in 2030 that could be met by expected capacity

IEA. CC BY 4.0.

Notes: MREE = Magnet rare earth elements (neodymium, dysprosium, terbium and praseodymium); CSAM = Central and South America; STEPS = Stated Policies Scenario; AC = air conditioner; RoW = Rest of World. Aluminium, cobalt, copper, fluorspar,  graphite,  lithium,  MREE  and  steel  refer  to  total  production  capacity  and  demand  across  all  sectors,  and  not specifically to demand from any single supply chain. Cathode and anode refer to active materials. All facilities able to produce graphite  anodes  suitable  for  battery  applications  are  included  in  global  anode  manufacturing  capacity.  Battery  refers  to lithium-ion battery cells. For the midstream and downstream, manufacturing capacities are used, while for critical minerals and materials, production is used. Assumes production outside of China is set to 85% of nameplate capacity. For inverters and solar glass, production from Asian countries outside of China is classified as RoW.

Sources: IEA analysis based on IEA (2025b), IEA (2025c), Benchmark Minerals Intelligence (2024), BNEF (2025a), EV Volumes (2025), WindEurope (2023), InfoLink (2025), S&amp;P Global (2025) and ChinaIOL (2025).

All clean energy technology supply chains have at least one step where only one-quarter of global demand could be met by suppliers outside China.

The results of this analysis can be interpreted as an upper bound on the production capacity  available  outside  China  for  two  main  reasons.  First,  a  portion  of intermediate  production  located  outside  China  currently  supplies  downstream manufacturers  within  China.  For example,  an  estimated  USD 28 million  equivalent to around 12% of European polysilicon output - is exported to China for  wafer  production.  In  the  event  of  a  supply  disruption,  new  logistical  and commercial linkages would need to be established, a process that could take time. Second, manufacturing facilities outside China are currently operating at relatively low  utilisation  rates.  Increasing  output  to  85%  of  nameplate  capacity  would therefore require both time and additional investment.

No major change in the security of clean energy technology supply chains is likely before the end of the current decade, taking account of committed  manufacturing 2 and mining projects and projected market trends based on today's stated policy settings. In the Stated Policies Scenario (STEPS), the share of demand that could be  met  with  production  outside  China  in  2030  increases  slightly  for  rare  earth element refining but falls for cathodes and wind turbine components. It remains largely unchanged for the other components and final technologies. In the longer term,  more  investment  outside  China,  particularly  in  upstream  segments  and component  manufacturing,  would  be  needed  in  order  to  have  any  significant impact on the overall security of those supply chains.

The  influence  of  Chinese  clean  energy  technology  manufacturing  companies extends beyond China's borders. The 'extraterritorial' elements of China's export controls  on  certain  battery  and  permanent  magnet  supply  chains  highlight  the importance  of  understanding  Chinese  ownership  of  productive  assets  located abroad (China, Ministry of Commerce, 2025). This is particularly evident in the refining of critical minerals and in the solar PV industry.

For nickel, while only about 30% of global supply is refined in China, Chinese companies  control  almost  half  of  supply  outside  of  China  -  primarily  through operations  in  Indonesia.  For  graphite,  Chinese  companies  hold  nearly  30%  of production  capacity  outside  of  China.  For  other  critical  minerals,  Chinese ownership  of  overseas  assets  remains  more  limited,  though  new  investments, especially  in  lithium,  could  significantly  expand  China's  global  footprint  in  the coming years.

In the solar PV sector, around 85% of wafer production capacity outside China is controlled by Chinese firms. By contrast, Chinese ownership of battery manufacturing capacity abroad (apart from for anode active materials) remains

2 'Committed' refers to plants that have reached a final investment decision or are under construction.

modest,  though  it  is  expected  to  grow  rapidly.  Based  on  currently  committed projects, by 2030, the share of battery production capacity outside China owned by Chinese firms could rise from around 6% in 2024 to around one-quarter by 2030.  This  expansion  reflects  growing  outward  foreign  direct  investment,  as Chinese  companies  seek  access  to  international  markets  while  mitigating  the impact of trade restrictions.

As a result, in many clean energy technologies supply chain steps, operational know-how and technical expertise are increasingly concentrated within Chinese firms.  This  concentration  adds  a  further  layer  of  complexity  to  diversification efforts, even when production assets are geographically distributed.

Figure 6.4 Share of committed global production capacity located outside China owned by China-headquartered companies for selected technologies and minerals, 2024 and 2030

<!-- image -->

IEA. CC BY 4.0.

Notes: REE = rare earth elements. No projections are available for wind turbines, critical minerals and electric cars. For polysilicon, no production capacity outside of China is owned by Chinese companies.

Sources:  IEA  analysis  based  on  BNEF  (2025a),  Benchmark  Minerals  Intelligence  (2024),  WindEurope  (2023),  InfoLink (2025), S&amp;P Global (2025) and ChinaIOL (2025).

Chinese firms account for large shares of solar PV production and minerals refining capacity located outside China, and their share of the battery supply chain is set to jump by 2030.

Accidents  or  natural  hazards  can  pose  significant  risks  to  the  security  and resilience of supply chains, potentially taking facilities offline for extended periods. Supply chains that depend heavily on a small number of production facilities are particularly vulnerable. For example, fires at Chinese polysilicon plants in 2020 and 2022 had major repercussions for the global solar PV supply chain, sharply

pushing up prices. When disruption persists for more than a few days or weeks, its effects can extend beyond prices, resulting in reduced demand and delays in technology deployment.

We have applied the N-1 analysis to the largest facility for each of the clean energy technology  supply  chains  reviewed  above.  The  results  show  that  in  2024,  the single  largest  operating  factory  in  each  segment  had  the  capacity  to  supply between 2% and 17% of global demand (Table 6.1). Solar PV wafer manufacturing sits  towards  the  top  of  this  range,  with  one  facility  in  China's  Inner  Mongolia province  capable  of  producing  the  equivalent  of  the  solar  PV  demand  of  the European Union and India combined, or twice that of the United States. However, the loss of output from this plant could be offset relatively easily, as total wafer manufacturing capacity at the end of 2024 was more than one and a half times global demand due to underutilised capacity both in China and elsewhere.

The least concentrated segment in this analysis is module assembly, where the largest facility - the Jinko Solar plant in Zhejiang, China - accounted for around 2% of  global  production.  Here  too,  spare  capacity  was  substantial,  exceeding actual production by around 75% in 2024.

While individual factories generally represent only a small share of global output, any  disruption  to  them  could  have  significant  regional  impacts.  For  instance, Europe's biggest battery factory - LGES's 86 GWh plant near Wroclaw, Poland accounts for around half of the continent's battery manufacturing capacity. In the case of wind turbine manufacturing, the biggest factories in the United States and Korea  account  for  half  of  total  manufacturing  capacity  for  nacelles  in  those countries. In China, the large number of individual factories means that no single factory has capacity exceeding 5% of the total for the country.

Very high market concentration can also create significant risks, particularly in the event of major firms facing financial difficulties, labour disputes or being targeted by sanctions. For most technologies, the largest company holds between 10% and 20%  of  global production capacity. There are some  notable exceptions: compressors for heat pumps, polysilicon manufacturing and wind turbine gearbox production, where the largest company - in the latter two cases headquartered in China  -  accounts  for  around  30%  of  total  capacity.  Even  a  temporary  halt  to production by these companies could create major bottlenecks in the global solar PV and wind turbine supply chains.

## Table 6.1 Largest individual company and production facility for selected clean energy technology supply chain by segment, 2024

| Technology    | Step               | Largest company   | Largest company                                       | Largest factory   | Largest factory                   |
|---------------|--------------------|-------------------|-------------------------------------------------------|-------------------|-----------------------------------|
| Technology    | Step               | Share             | Name                                                  | Share             | Location                          |
|               | Cells              | 19%               | CATL                                                  | 4%                | Yibin (China)                     |
| Batteries     | Cathodes           | 16%               | Hunan Yuneng New Energy Battery Material              | 2%                | Yulin (China)                     |
|               | Anodes             | 8%                | Shanghai Shanshan Lithium Battery Material Technology | 5%                | Jilin (China)                     |
| Solar PV      | Modules            | 9%                | Jinko Solar                                           | 2%                | Haining (China)                   |
|               | Cells              | 12%               | Tongwei                                               | 3%                | Yiwu (China)                      |
|               | Wafer              | 17%               | LONGi                                                 | 9%                | Baotou (China)                    |
|               | Polysilicon        | 27%               | Tongwei                                               | 6%                | Baotou (China)                    |
|               | Nacelles assembly  | 14%               | Envision Energy                                       | 3%                | Pensacola (United States)         |
|               | Blades             | 17%               | China National Building Material                      | 5%                | Sheyang (China)                   |
| Wind turbines | Towers             | 19%               | CS Wind Corp.                                         | 12%               | Tan Thanh (Viet Nam)              |
|               | Generators         | 22%               | CRRC Zhuzhou                                          | 5%                | Dafeng (China)                    |
|               | Gearboxes          | 31%               | NGC                                                   | 17%               | Jinhu (China)                     |
|               | Assembly           | 15%               | Daikin                                                | 4%                | Foshan (China)                    |
| Heat pumps    | Rotary compressors | 35%               | GMCC                                                  | 12%               | Hefei (China)                     |
| Heat pumps    | Scroll compressors | 51%               | Copeland                                              | 10%               | Lebanon, Missouri (United States) |
| Electrolysers | Assembly           | 9%                | Sungrow                                               | 5%                | Shenzhen (China)                  |

Notes: Batteries refers to lithium-ion batteries. Cathodes and anodes refer to cathode and anode active materials. All facilities able to produce graphite suitable for battery applications are included in global anode manufacturing capacity. The largest factory does not always belong to the largest producing company. In this table, heat pumps refer to reversible units without distinction as to their application.

Sources:  IEA  analysis  based  on  BNEF  (2025a),  Benchmark  Minerals  Intelligence  (2024),  WindEurope  (2023),  InfoLink (2025), S&amp;P Global (2025) GWEC (2025) and ChinaIOL (2025).

## Technology-specific security considerations

## Solar PV

China is the largest producer across all major segments of the solar PV supply chain, but significant capacity also exists in other regions - much of it currently underutilised. At present, production outside of China could mostly meet the rest of the world's needs for solar PV modules and inverters. For modules, much of this capacity stems from recent investments in Southeast Asia (with almost 60% owned by Chinese companies), India and North America, while for inverters legacy facilities in Europe account for a large share. However, a significant share of this non-Chinese capacity is less competitive, as it is geared towards manufacturing older,  less-efficient  modules,  which  is  one  reason  for  low  utilisation  rates.  This mostly concerns facilities that have existed for several years, whereas more recent capacity expansion is oriented to produce modern, high-efficiency models.

Further upstream in the supply chain, the picture is very different. Only just over half  of  global  cell  demand  (excluding  China)  could  be  met  by  factories outside China, and just one-quarter for wafer manufacturing. In these segments, most non-Chinese production capacity is located in Southeast Asia, with 70% or more owned  by  companies  headquartered  in  China  and  primarily  serving  export markets. For solar glass and polysilicon, less than half of demand outside China (excluding China) could be met without Chinese production.

In the STEPS, supply diversity improves somewhat in the downstream solar PV sector  to  2030,  on  the  assumption  that  committed  manufacturing  projects  go ahead.  Upstream,  however,  change  is  limited,  except  for  cell  manufacturing, where new capacity in India and the United States increases diversity. Achieving a meaningful improvement in the security and resilience of the solar PV supply chain would require major new investments in upstream segments outside China.

## Wind

China  is  the  largest  producer  of  all  major  wind  power  components  (nacelles, blades, towers, gearboxes and generators), as well as the refined metals used to manufacture them. In 2024, global production capacity for the main downstream turbine components - nacelles, blades and towers - exceeded demand outside China, largely thanks to substantial capacity in Europe. However, most of the key components  for  nacelles  are  produced  in  China,  with  limited  manufacturing capabilities  elsewhere.  Capacity  for  the  assembly  of  gearboxes  outside  China could meet all demand beyond China's borders, thanks to Indian and European production capacity.

Further upstream, supply chain vulnerabilities are more pronounced. Copper essential for generators and cabling (and used in several industrial applications outside the energy sector) - is mainly mined in Chile and refined in China. The most critical  potential  bottleneck  lies  in  permanent magnets and the rare earth elements  required  to  produce  them.  Permanent  magnets  are  used  almost exclusively  for  offshore  wind  turbines,  which  accounted  for  8%  of  global  wind capacity additions in 2024 and are projected to make up 20% of capacity additions to 2030 in the STEPS. Less than 10% of rare earth refining capacity is located outside China, though mining and magnet manufacturing shares are somewhat higher thanks to recent investments in Europe and the United States. Given the recent Chinese export control announcements on these minerals, this remains the most acute supply security risk for the wind turbine industry.

These vulnerabilities are set to worsen under today's stated policy settings. In the STEPS,  demand  outside  China  is  projected  to  rise,  yet  planned  capacity expansions are minimal, held back by the perception of uncertain demand among manufacturers  headquartered  outside  China.  Most  new  turbine  manufacturing capacity is expected to be built in China. As a result, dependency on China currently concentrated in midstream and upstream components - will extend to downstream segments in the future as well.

## Electric vehicles and batteries

China is the largest producer and exporter across most of the EV supply chain stages, with the exception of lithium mining (led by Australia), cobalt mining (led by the DRC) and nickel mining and refining (led by Indonesia). In downstream segments,  including  EV  assembly  and  battery  cell  manufacturing,  production capacity  outside  China  is  sufficient  to  meet  all  non-Chinese  demand,  as  cell factories are often located in the same regions as vehicle assembly.

Electric motor manufacturing appears to be in a similar position, though precise data are unavailable, as most motors are produced in-house by car manufacturers. However, nearly all EV motors contain permanent magnets, which require rare earth elements. For both rare earth refining and permanent magnet manufacturing, less than 25% of non-Chinese global demand could be met with capacity  outside  China,  leaving  motor  supply  chains  as  exposed  as  those  for batteries.

With regards to battery components, capacity outside China is sufficient to meet demand for nickel manganese cobalt (NMC) battery active materials, supported by facilities in Korea and Japan, but largely insufficient for lithium iron phosphate (LFP)  battery  active  materials,  NMC  and  LFP  precursors,  and  anode  active material. Production capacity for electrolyte salts and solvents outside China could

cover about two-thirds of demand. While electrolyte solvent production could, in principle, be expanded in regions with a developed chemicals industry, capacity remains limited today.

For  critical  minerals,  the  picture  is  mixed.  In  the  case  of  lithium  -  the  most important mineral for lithium-ion batteries - around 65% of mining and nearly 95% of processing demand could be met without relying on the largest producer. By contrast, cobalt remains heavily dependent on the largest producer for mining and, albeit to a lesser extent, for refining. Graphite refining for lithium-ion batteries today mostly focused on synthetic graphite - is even more concentrated, with only minimal  capacity  outside  China,  as  few  countries  have  been  willing  or  able  to develop this highly energy-intensive industry.

There is little prospect of any significant change in the security and resilience of EV supply chains over the rest of this decade, given current investment plans. In the STEPS, committed investments in cell and graphite production outside China improve diversity slightly, but in most other stages the situation either worsens or remains stable. As a result, the risk profile for EV supply chains is likely to remain high, with upstream stages remaining highly exposed.

## Heat pumps

China is the largest producer and exporter of assembled heat pumps. 3  However, international trade in heat pumps is limited because units are often tailored to local market requirements, meaning reliance on Chinese imports is currently modest in most heating regions. Overall, for heat pumps used as primary heating equipment, manufacturing capacity outside China is more than sufficient to meet demand, moderating concerns about supply security.

The situation is very different for small air conditioning (AC) units, which - in the case  of  reversible  models  -  can  also  be  used  for  heating  (i.e.  functioning  as conventional  space-heating  heat  pumps).  Reversible  units  are  common  in countries with a temperate climate, where both heating and cooling are needed seasonally. These units are estimated to account for around 30% of heat pump capacity sold as primary heating equipment. Small AC units are more easily traded internationally,  and  their  production  is  far  more  concentrated  in  China,  which dominates manufacturing and exports. Outside China, production capacity could only meet over half of global demand.

3 In this report, 'heat pumps' refers to units that deliver heat directly to households and residential or commercial buildings for space heating and/or domestic hot water provision. It includes natural source heat pumps, including reversible air conditioners used as primary heating equipment. It excludes reversible air conditioners used only for cooling, or used as a complement to other heating equipment, such as a boiler.

Across  the  heat  pump  sector,  the  main  supply  security  risk  lies  in  rotary compressor manufacturing. Such compressors - used in both small heat pumps and  AC  units  -  are  also  produced  predominantly  in  China,  where  many manufacturers either make their own or source them from a well-developed local supply chain. Chinese producers benefit from economies of scale, and compressors  are  easy  to  transport  and  trade.  At  present,  rotary  compressor production capacity outside China can cover about one-quarter of global demand for  use  in  heat  pumps.  The  production  of  scroll  compressors,  used  in  larger residential and commercial units, is less concentrated geographically. Fluorspar, the key feedstock for current F-gas refrigerants, is produced mainly in China, but non-Chinese  production  is  thought  to  be  sufficient  to  meet  remaining  global demand.

New project  announcements for heat pump manufacturing are not common in most parts of the world, so it is hard to assess the medium-term prospects for supply diversity. In Europe, where announcements are more commonplace, new project plans since 2022 point to rising domestic production capacity through to 2030. In all regions, without fresh investment, production capacity for heat pump assembly could begin to lag behind demand in the coming years. In the STEPS, production outside China would not be enough to cover global demand in 2030 a reversal of the current situation.

## Maritime chokepoints

The  supply  chains  for  most  clean  energy  technologies  -  along  with  their components and material inputs - rely heavily on maritime shipping. As global trade  volumes  continue  to  grow,  the  risk  of  severe  congestion  or  physical disruption  at  key  maritime  chokepoints  could  rise.  Such  disruptions  may  be triggered by geopolitical tensions, extreme weather events, piracy or accidents.

In  2023,  60%  of  global  trade  by  value  passed  through  at  least  one  maritime chokepoint;  the  share  was  70%  for  fossil  fuels  and  65%  for  clean  energy technologies. For fossil fuels, the most critical passages are the Strait of Hormuz and the  Strait  of  Malacca:  typically,  around  one-fifth  of  global  oil  and  liquefied natural gas (LNG) trade flows through the Strait of Hormuz (Figure 6.5). For clean energy technologies, Malacca and the Suez Canal are the most important routes, with the Panama Canal playing a key role in trade between the United States and South America or Asia, though its overall volumes are smaller.

Figure 6.5 Global clean energy technologies and fossil fuels passing through selected chokepoints by share of value, 2023-2024

<!-- image -->

IEA. CC BY 4.0.

Notes: Trade passing through each chokepoint is calculated by combining global trade data with shortest shipping routes between ports. 2023 values are estimated by the IEA based on modelled shipping routes and trade values, while 2024 values are adjusted based on data for tankers and container carriers.

Sources: IEA analysis adapted from IEA (2024b) and International Monetary Fund (2024).

Recent disruptions at the Bab el Mandeb Strait and the Suez Canal have had a significant impact on maritime energy trade routes.

Since  November 2023, Houthi attacks  on  shipping  have  significantly  disrupted shipping through the Bab el Mandeb Strait and the Suez Canal, driving up freight and insurance costs and forcing the re-routing of traffic  via  the  Cape  of  Good Hope. Shipping along that route has fallen by about 90% for container carriers and 50%  for  oil  tankers,  with  the  containerised  freight  index  more  than  doubling between 2023 and 2024.

Around  half  of  all  clean  energy  technology  trade  today  transits  the  Strait  of Malacca,  making  it  the  single  most  important  chokepoint  for  the  sector.  This reflects the gap between European demand for clean energy technologies and its domestic manufacturing capacity. Across the leading clean energy technologies, at least half of global supply is located in Asia, east of Malacca.

A blockage at any of these chokepoints - whatever the cause - could disrupt both clean energy and fossil fuel supply chains, posing a threat to energy security. The scale of the impact would vary by commodity and by country, depending on the location of supply and demand. Disruptions would generally be far more severe for fossil fuels, as they are primary energy sources: the loss of a significant share of  global  oil  supply,  for  example,  has  historically  triggered  rapid  spikes  in international  prices  and  far-reaching  economic  consequences  worldwide.  By contrast, delays in the delivery of clean energy technologies could severely disrupt

supply chains but are unlikely to cause such acute economic shocks, as these technologies are assets used to produce, transform or consume energy, rather than being energy sources themselves.

## Box 6.2 Low-emissions fuel bunkering: an opportunity for diversification or further concentration of supply?

Fuel is a significant and volatile cost component in maritime shipping, making the distribution and concentration of bunkering supply key determinants of freight costs. Bunkering today is highly concentrated: the Port of Singapore alone meets around one-fifth  of  global  demand  -  with  nearly  55 Mt  delivered  in  2024  -  and  the  top 17 ports account for more than 60%. Located along main trade routes, these hubs benefit  from  economies  of  scale  and  proximity  to  refineries,  reducing  costs. However,  maritime  instability  from  conflict,  piracy  or  environmental  hazards  can cause delays and re-routing, raising freight costs and emissions. With demand for low-emissions marine fuel set to grow, an important question is whether today's bunkering hubs will retain their dominance or give way to a more diversified supply landscape.

Alternative  marine  fuels  include  biofuels,  hydrogen  and  hydrogen-based  fuels. Certain biofuels, such as biodiesel and biomethane, can be used as 'drop-in' fuels with limited modification to existing vessels, but their scalability is constrained by the availability of sustainable biomass and competing demand from other sectors, particularly  aviation.  Hydrogen-based  fuels,  while  currently  more  costly,  offer greater long-term potential. In 2025, over 100 methanol-powered vessels were in service and around 360 were on order, while over 40 ammonia-powered vessels were on order books. Most are equipped with a dual-fuel engine that can operate on both the alternative fuel and conventional oil, improving operational flexibility, compliance with regional fuel standards and resilience to oil price spikes.

Low-emissions fuels are not yet traded as readily as conventional heavy fuel oil. The scale and geography of their supply will strongly influence future freight costs and resilience. If bunkering remains concentrated in a few ports, ships may face longer  diversions  and  higher  prices  when  alternative  fuels  are  unavailable. However, if supply expands along main routes and re-routing corridors, bunkering would become more diversified and less vulnerable to disruption.

Announced  projects  suggest  about  10 Mt  per  annum  (Mtpa)  of  low-emissions hydrogen has strong potential to be operational* by 2030, covering roughly 10% of 2024's  marine  fuel  demand  with  hydrogen-based  fuels.  This  is  contingent  on demand-side policies, including for shipping, and measures to narrow the cost gap with fossil-based pathways. About three-quarters of this capacity lies within 500 km of a major port (falling to 60% within 250 km) giving more than 70 of the world's 242 main  cargo  and  bunkering  ports  access  to  at  least  0.1 Mtpa  of  hydrogen

(44 ports are within 250 km). Supply would remain uneven, concentrated in Europe, the US East Coast, the Middle East and northern China, though this aligns with today's major bunkering hubs, giving them an early-mover advantage.

Figure 6.6  Major current shipping routes and ports, and low-emissions hydrogen supply from announced projects, 2030

<!-- image -->

IEA. CC BY 4.0

Notes: H2 = hydrogen. Hydrogen supply is based on announced projects with a strong potential to be operational by 2030 within a 500 km radius of each port, regardless of announced end-use. The methodology used to assess the likelihood of hydrogen projects with an announced operational date between 2026 and 2030 becoming operational by 2030 is described in the IEA´s Global Hydrogen Review 2025 . The map shows the potential hydrogen supply available to each port individually, but does not account for competition, so the actual volumes available may be lower if multiple ports draw from the same project.

Sources: Adapted from IEA (2024b) and IEA (2025e).

Only about 2.4 Mtpa - less than one-quarter of the total - is within 500 km of major maritime chokepoints. Several major ports in the Asia Pacific, sub-Saharan Africa and Latin America may therefore need to import hydrogen-based fuels from distant sources, even where local production costs are relatively low. An additional 27 Mtpa of projects have been announced for 2030 or earlier but remain uncertain. If they are realised later in the 2030s, these projects could transform prospects, enabling new hubs to emerge near major dry-bulk ports in Australia and along alternative routes such as in Namibia (via the Cape of Good Hope) and the Strait of Magellan.

* Calculated based on a methodology developed to assess the likelihood of hydrogen projects with an announced operational date between 2026 and 2030 becoming operational by 2030, described at IEA´s Global Hydrogen Review 2025 (IEA, 2025d).

We  have  analysed  the  potential  impact  of  a  blockage  at  the  main  maritime chokepoints by estimating deviations in route distance and time, and the resulting changes  in  energy  consumption,  using  the  shipping  route  modelling  tool developed for ETP-2024 (IEA, 2024b). This analysis focused on two major origindestination pairs: Shanghai (China) - Rotterdam (Netherlands), for clean energy technology trade, and Corpus Christi (United States) - Chiba (Japan), for oil and gas.  For  each  pair,  alternative  routes  were  considered  depending  on  which chokepoints were affected. The results are summarised in Table 6.2. In the case of Shanghai (China) - Rotterdam (the Netherlands), the shortest, most convenient route is eastbound via the Suez Canal, transiting other chokepoints such as the Taiwan Strait, the Strait of Malacca and the Bab el Mandeb Strait.

In the event of a blockage at the Strait of Malacca , ships would be forced to divert via  the  Sunda  or  Lombok  Straits,  adding  roughly  2 000 km  to  the  route  from Shanghai to reach Colombo (Table 6.2), assuming navigation through Sunda is not possible. Although Malacca handles very high traffic volumes, a closure would be disruptive but not crippling. On the Shanghai - Rotterdam route via the Suez Canal, such a diversion would add about 74 hours of sailing time and require 10% more fuel, though delays could be longer due to limited capacity and congestion in the alternative straits. Fuel can account for roughly 30% of operational shipping costs,  but  transport  generally  represents  a  small  share  of  total  clean  energy technology costs, ranging from 1% for solar PV polysilicon to 15% for wind blades (IEA, 2024b). Longer voyages would therefore have only a minor impact on the final  price  of  the  technology.  However,  extended  transit  times  could  create temporary shortages in shipping capacity, pushing freight rates sharply higher,

A blockage at the Suez Canal or Bab el Mandeb Strait would be more disruptive, as demonstrated by recent disruptions. Ships leaving from Shanghai can reroute either around the Cape of Good Hope, increasing distance by 35%, or across the Pacific  and  through  the  Panama  Canal  to  Europe,  adding  27%.  Despite  being shorter,  the  Panama  route  is  less  favoured  due  to  congestion,  vessel  size limitations and high tolls. Since early 2024, geopolitical instability in the Red Sea has reduced Suez traffic by roughly 60%, with a comparable rise in traffic via the Cape of Good Hope but little change through the Panama Canal. The Red Sea remains  a  critical  corridor  for  both  clean  energy  and  fossil  fuel  shipments;  its complete  closure  would  cause  severe  disruption,  even  though  the  shipping industry can adapt at the cost of longer transit times and higher freight rates.

For the Corpus Christi (United States) - Chiba (Japan) route, the shortest passage is via the Panama Canal , which is also vulnerable to weather-related constraints. Severe drought in late 2023 and early 2024 reduced traffic by almost 50% yearon-year. A closure would leave three options: east via the Suez Canal (increasing distance  by  60%),  east  via  the  Cape  of  Good  Hope  (75%)  or  around  South America via the Strait of Magellan. The latter is rarely used and traffic data from

2023-24 show no notable increase consistent with diversions from the Panama Canal. Although the Panama Canal is less relevant for clean energy technology trade, it plays a major role in other energy commodity transport, meaning closures would significantly affect transit times and costs.

Beyond these two cases, the Strait of Hormuz remains the most critical chokepoint for fossil fuels: r oughly  25%  of  the  world's  seaborne  oil  trade and  almost  one-fifth  of  global  LNG  trade  passed  through  it  in  2025. Unlik e other  passages,  there  is  no  alternative  route  for  ships  entering  or  leaving the Persian  Gulf,  so any  disruption  would  halt  maritime  trade  entirely. This makes Hormuz's risk profile fundamentally different - and potentially far more severe than for all other chokepoints.

In  addition  to  the  direct  rise  in  fuel  consumption  and  operational  expenses, such  as additional staffing costs from longer distances and increased insurance premium,  chokepoint  blockages  would  also  have  wider  indirect impacts.  Longer  voyage  durations  reduce  effective  global  shipping  capacity, pushing  up  freight rates  and  heightening  inflationary  pressures.  They  also increase emissions from the shipping sector and force customers to hold more working capital to absorb potential delivery delays.

Table 6.2 Potential impact of a blockage of maritime shipping at selected chokepoints

|                                     |                          |                             | Share of global trade (%), 2023   | Share of global trade (%), 2023   | Impact              | Impact                    | Impact                  |                                                                                         |
|-------------------------------------|--------------------------|-----------------------------|-----------------------------------|-----------------------------------|---------------------|---------------------------|-------------------------|-----------------------------------------------------------------------------------------|
| Origin-destination pair             | Blocked chokepoint       | Alternative route           | Clean energy technologies         | Fossil fuels                      | Extra distance (km) | Extra hours of navigation | Extra fuel consumpti on | Risk profile                                                                            |
| Shanghai (CHN) to Rotterdam (NDL)   | Strait of Malacca        | Via Sunda or Lombok Straits | 51%                               | 31%                               | 2000                | 74 hours                  | +10%                    | Disruptive but manageable; congestion risks on alternative routes                       |
|                                     | Suez Canal/Bab el Mandeb | Via Panama                  | 40%                               | 16%                               | 5300                | 193 hours                 | +27%                    | Severe disruption; industry could adapt but with higher costs and delays                |
|                                     |                          | Via Cape of Good Hope       | 40%                               | 16%                               | 6700                | 243 hours                 | +35%                    | Severe disruption; industry could adapt but with higher costs and delays                |
| Corpus Christi (USA) to Chiba (JPN) | Panama Canal             | Via Suez Canal              | 1.5%                              | 2%                                | 10000               | 502 hours                 | +60%                    | Significant cost and delay impact; drought risk                                         |
| Corpus Christi (USA) to Chiba (JPN) |                          | Via Cape of Good Hope       | 1.5%                              | 2%                                | 13000               | 639 hours                 | +75%                    | Significant cost and delay impact; drought risk                                         |
|                                     | Strait of Hormuz*        | N/A                         | 1%                                | 22%                               | N/A                 | N/A                       | -                       | Extremely high for oil and gas - closure halts all maritime trade from the Persian Gulf |

* All routes leaving and entering Persian Gulf.

Notes: N/A = not applicable. Extra hours are considered at the same speed as the base case, which is 11 knots for tanker, used for the Corpus Christi to Chiba case, and 15 knots for container carrier, used for the Shanghai to Rotterdam case. Extra fuel consumption is assumed to be proportional to the extra distance.

## References

American Public Power Association. (2023). Study Highlights Hacker Vulnerabilities Created by Smart Meters . Retrieved from https://www.publicpower.org/periodical/article/studyhighlights-hacker-vulnerabilities-created-smart-meters

AP News. (2018). Russian hackers used phishing tools in 2017 attack on grid . Retrieved from https://apnews.com/article/2c17bda4ac704df6be66018197f29912

BCG-SIA. (2024). Emerging Resilience in the Semiconductor Supply Chain . Retrieved from https://www.semiconductors.org/wp-content/uploads/2024/05/Report\_Emerging-Resilience-in-the-Semiconductor-Supply-Chain.pdf

Benchmark Minerals Intelligence. (2024). Benchmark Minerals Lithium Ion Battery Gigafactory Assessment . Retrieved from https://www.benchmarkminerals.com/

BNEF. (2025a). Data service . Retrieved from https://about.bnef.com/

Checkpoint. (2026). Cyber Security Report 2026. Retrieved from https://www.checkpoint.com/resources/report/report-cyber-security-report-2026

China, Ministry of Commerce. (2025). The Ministry of Commerce spokesperson answered reporters' questions regarding adjustments to the Catalogue of Technologies Prohibited and Restricted for Export from China . Retrieved from https://www.mofcom.gov.cn/syxwfb/art/2025/art\_072f1b88bcb4415fae1f05bbd569fd50. html

ChinaIOL. (2025). Annual ChinaIOL Database on HVAC, Heating, Compressors and Refrigerants . Retrieved from data.chinaiol.com

CSIS. (2025). Significant Cyber Incidents Since 2006 . Retrieved from https://csis-website-

11/251114\_Significant\_Cyber\_Incidents.pdf?VersionId=GZ0fl\_iuR1WJplsXUf9NzVAHH

prod.s3.amazonaws.com/s3fs-public/2025P7KspWy cybernews. (2023). Denmark hit with largest cyberattack on record . Retrieved from https://cybernews.com/news/denmark-cyberattack-energy-infrastructure-sandworm/

Engineering, I. (2025). Rogue hardware in Chinese inverters could trigger worst blackout threat to date . Retrieved from https://interestingengineering.com/energy/roguehardware-in-chinese-inverters-could-trigger-blackout-threat

EV Volumes. (2025). Global Electric Vehicle Sales Data, Market Trends &amp; Forecasts You Can Trust . Retrieved from https://ev-volumes.com/

Finance Colombia. (2022). Retrieved from https://www.financecolombia.com/epm-falls-victimto-ransomware-attack/

GWEC. (2022). Global wind gearbox supply chain update. Brussels: GWEC Market Intelligence.

GWEC. (2024). Global wind turbine generator supply chain update. GWEC Market Intelligence.

GWEC. (2025). Generators and gearboxes largest facilities globally.

Help Net Security. (2019). Ransomware attack leaves Johannesburg residents without electricity . Retrieved from https://www.helpnetsecurity.com/2019/07/26/ransomwarejohannesburg/

- IBM. (2025). Cost of a Data Breach Report 2025: The AI Oversight Gap. Retrieved from https://www.ibm.com/think/x-force/2025-cost-of-a-data-breach-navigating-ai
- IEA. (2023). Cybersecurity - is the power system lagging behind? Retrieved from https://www.iea.org/commentaries/cybersecurity-is-the-power-system-lagging-behind
- IEA. (2024a). Advancing Clean Technology Manufacturing . Retrieved from https://www.iea.org/reports/advancing-clean-technology-manufacturing
- IEA. (2024b). Energy Technology Perspectives 2024. Retrieved from https://www.iea.org/reports/energy-technology-perspectives-2024
- IEA. (2025b). World Energy Outlook 2025 . Retrieved from https://www.iea.org/reports/worldenergy-outlook-2025
- IEA. (2025c). Global Critical Minerals Outlook 2025 . Retrieved from https://www.iea.org/reports/global-critical-minerals-outlook-2025
- IEA. (2025d). Global Hydrogen Review 2025. Retrieved from https://www.iea.org/reports/global-hydrogen-review-2025
- IEA. (2025e). Hydrogen Production and Infrastructure Projects Database . Retrieved from https://www.iea.org/data-and-statistics/data-product/hydrogen-production-andinfrastructure-projects-database
- IFR. (2024). Record 435,000 robots now working in Japan's factories . Retrieved from https://ifr.org/downloads/press2018/2024-SEP-24\_IFR\_press\_release\_World\_Robotics\_2024\_-\_Japan.pdf

InfoLink. (2025). InfoLink Consulting . Retrieved from https://www.infolink-group.com/ . Retrieved from IMF PortWatch:

International Monetary Fund. (2024). IMF PortWatch https://portwatch.imf.org/

- knowbe4. (2024). KnowBe4 Report Reveals Critical Infrastructure Under Siege with Cyber Attacks Increasing 30 Percent in One Year . Retrieved from https://www.knowbe4.com/press/knowbe4-report-reveals-critical-infrastructure-undersiege-with-cyber-attacks-increasing-30-percent-in-one-year
- knowbe4. (2025). Hidden Threats in Our Power Grid: The Chinese Transformer Backdoor Scandal . Retrieved from https://blog.knowbe4.com/hidden-threats-in-our-power-gridthe-chinese-transformer-backdoor-scandal
- MAYA. (2025). Chinese Inverter Backdoors: A Renewable Energy Cybersecurity Wake-Up Call . Retrieved from https://www.maya-security.com/post/chinese-inverter-backdoors-arenewable-energy-cybersecurity-wake-up-call
- Meier, R. (2025). COMAC delivers more aircraft and gets closer to Embraer. ADN . Retrieved from https://www.airdatanews.com/comac-delivers-more-aircraft-and-gets-closer-toembraer/
- PV Magazine. (2022). Satellite cyber attack paralyzes 11 GW of German wind turbines . Retrieved from https://www.pv-magazine.com/2022/03/01/satellite-cyber-attackparalyzes-11gw-of-german-wind-turbines/
- PV Magazine. (2024). Lithuania bans remote Chinese access to solar, wind, storage devices . Retrieved from https://www.pv-magazine.com/2024/11/18/lithuania-bans-remotechinese-access-to-solar-wind-storage-devices/
- Reuters. (2025). Auto companies face shortages due to China's rare earth restrictions . Retrieved from https://www.reuters.com/business/autos-transportation/auto-companiesface-shortages-due-chinas-rare-earth-restrictions-2025-06-05/

S&amp;P Global. (2025). Commodity Insights . Retrieved from https://www.spglobal.com/commodity-insights/en

SecuretheGrid . (2023). Retrieved from U.S. Continues to Import Large Transformers from China in 2023: https://securethegrid.com/u-s-continues-to-import-large-transformersfrom-china-in-2023/

US Congress . (2024). Retrieved from Attacks on Ukraine's Electric Grid: Insights for U.S. Infrastructure Security and Resilience: https://www.congress.gov/crs-product/R48067

WindEurope. (2023). The State of the European Wind Energy Supply Chain . Retrieved from https://windeurope.org/data/products/the-state-of-the-european-wind-energy-supplychain/

## Chapter 7. Industrial competitiveness

## Highlights

-  Industrial competitiveness is shaped by a wide set of structural drivers, including the  price  of  labour,  energy,  capital  and  raw  materials,  but  also  productivity, manufacturing  efficiency,  infrastructure  quality,  digitalisation,  access  to  skilled labour  and  the  strength  of  innovation  ecosystems.  Stable  policies  and  secure energy systems also underpin competitiveness, by helping firms to commit capital at scale to better technologies and manufacturing plants.
-  Energy-intensive industries account for 30% of global manufacturing value added, 70% of industrial energy use and 20% of manufacturing employment. They play a strategic role in providing the inputs for downstream industries, with implications for economic and national security. Yet they are highly vulnerable to volatile energy prices: energy can represent over two-thirds of total production costs.
-  Decarbonisation reinforces the importance of access to low-cost clean energy in industry. As industry shifts towards electricity and hydrogen, regions with abundant renewable  resources gain competitive advantage. For example, offshoring ironmaking  to  regions  with  low-cost  renewables  -  such  as  Brazil  -  could significantly  narrow  cost  gaps  with  conventional  production  routes,  with  limited impacts on jobs.
-  Input costs vary considerably across countries and regions. Labour costs tend to be lower in emerging economies; in China, labour costs can be five times lower than in Europe or in the United States. Capital costs are typically lower in advanced economies. Regional energy prices also vary substantially, with electricity prices varying by up to a factor of seven across regions, and natural gas varying even more.
-  In clean energy technology manufacturing, there is no single factor that explains China's cost advantage and central position. Structural cost differences, such as energy  and  labour,  account  for  over  two-thirds  of  the  cost  gap  with  Europe  in manufacturing  steps  that  are  particularly  energy-  or  labour-intensive,  such  as upstream solar PV manufacturing and wind turbine blade production. Economies of scale are especially important for heat pumps and solar PV, while for batteries over 40% of the cost gap reflects higher manufacturing efficiency in China.
-  Countries will need to identify and play to their strengths while establishing strategic partnerships  to  offset  weaknesses  in  competitiveness.  For  example,  producing solar PV modules in the European Union with imported wafers from North Africa would cost almost 20% less than producing a fully EU-made module.

## Drivers of competitiveness

Industrial competitiveness refers to how well a country's industries can produce goods and services that succeed in global and domestic markets. This can be achieved  through  a  superior  design,  either  of  a  product  or  a  (manufacturing) process, or by producing at lower cost. For standardised products and commodities, competitiveness is largely determined by relative production costs across countries (OECD, 2022a). In open and competitive markets, lower prices of labour, capital, energy and raw materials typically translate into lower costs of production,  larger  market  shares  and  potentially  higher  revenues  or  profits. Productivity and efficiency - that is, how effectively industries convert inputs into outputs - are also central drivers of relative cost performance.

A wide range of other conditions directly or indirectly influence both the cost base and the quality or attractiveness of manufactured goods. These include access to a skilled workforce, adequate and reliable infrastructure, the degree of digitalisation  and  the  presence  of  an  ecosystem that  supports incremental and disruptive innovation. Enabling factors such as integrated networks of stakeholders along supply chains, with close interactions to build new capabilities and know-how, as well as access to well-developed and sizeable markets also play a role (Figure 7.1). In addition, collaboration to integrate diverse expertise and functions within and across industries is essential for global competitiveness. Other enabling factors that do not affect cost or quality directly, including public and  corporate governance,  transparency,  institutional quality and  political, economic and social stability, also shape the broader environment for industrial competitiveness.

Policy predictability is particularly important; by reducing uncertainty over future cash flows and project risks, a stable and transparent policy environment helps private investors to commit capital at scale. Likewise, a secure energy system one that provides affordable, stable prices and can withstand unexpected shocks - enhances competitiveness across all sectors. These conditions reflect long-term choices  made  by  governments  and  industry,  and  their  interplay  ultimately determines both national industrial performance and investment decisions.

These factors mean that cost advantages alone are not always sufficient to sustain competitiveness.  The  evolution  of  the  semiconductor  industry  provides  a  clear illustration.  North  America  dominated  the  sector  from  the  1950s  through  the 1970s,  while  Japan  built  strong  positions  in  specific  components  in  the  early 1980s. At that time, Chinese Taipei had only a nascent industry with limited global presence.  In  response,  its  government  established  the  Industrial  Technology Research Institute in the 1970s, expanded R&amp;D funding, developed science and software parks and introduced targeted tax incentives and financing mechanisms. These measures supported the creation in the late 1980s of TSMC - the world's leading semiconductor foundry today.

The subsequent expansion of the industry was underpinned by several mutually reinforcing factors: a highly skilled workforce; a tightly integrated network linking universities, research institutes and industry to accelerate innovation, knowledgesharing  and  rapid  prototyping;  strong  co-ordination  between  suppliers  and manufacturers supported by a resilient supply chain; and strategic specialisation in specific  stages  of  the  manufacturing  process.  Together,  these  elements demonstrate how long-term policy consistency, institutional capacity and ecosystem development can secure global competitiveness even in highly capitalintensive, technologically demanding sectors.

## Figure 7.1 Factors influencing industrial competitiveness

## Innovation

- · Inventions. Revealed technology advantage
- · R&amp;D investment. Public and private
- · Venture capital flows
- · Ecosystem (start-ups, partners)
- · Intellectual property protection

## Workforce

- · Match between skills and needs
- · Size in comparison to deployment needs
- · Availability from adjacent industries
- · Degree of specialisation

## Digitalization

- · Use of digital twins (design, operation)
- · Degree of connectivity for measurement (e.g. internet of things) and control (operation)
- · AI-enabled optimisation (material discovery, equipment design and operation)

## Infrastructure

- · Port infrastructure (location and size)
- · Road and rail (density and quality)
- · Airport connectivity and flight frequency

## Supply chain

- · Diversification (of companies and countries)
- · Degree of specialisation
- · Share of domestic supply along all steps
- · Economies of scale
- · Manufacturing capacity

## Cost

- · Raw materials extraction/mining
- · Manufacturing
- · Engineering, procurement and construction
- · Levelised cost of production/service
- · Infrastructure (pipelines, terminals, storage)

## Macroeconomy

- · Labour productivity
- · Contribution to GDP and jobs creation
- · Inflation and currency stability
- · Trade balance
- · Industry profitability

## Markets

- · Domestic market competition
- · Trade openness
- · Electricity grid (access and quality)
- · Market size

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on inputs from World Economic Forum (2018); European Commission (2025b); World Bank (2017); and OECD (2022b).

Competitiveness is largely determined by relative prices of inputs to production, but other factors can also have a major impact on the development of a domestic industry.

Governments can counter unfavourable competitiveness conditions and encourage  firms  to  locate  production  facilities  within  their  borders  by  offering targeted incentives. For example, all OECD member countries employ at least one instrument aimed at attracting or retaining foreign investment. Tax incentives and financial measures remain the most widespread tools, with around three-quarters of OECD countries citing productivity and innovation as the primary objectives of these  schemes  (OECD,  2024a).  The  People's  Republic  of  China  (hereafter, 'China') has likewise drawn on a broad suite of economic incentives to strengthen the competitiveness of its domestic industrial base, including preferential borrowing through state-owned enterprises (OECD, 2024b).

These  incentives  take  a  variety  of  forms.  Direct  financial  support  may  include capital grants, production-linked subsidies, or temporary assistance with energy and operating costs. Tax measures range from preferential rates to exemptions and credits. Governments also provide support through land, infrastructure and utilities - for example, by offering low-cost industrial sites, building transport and grid  connections,  or  guaranteeing  long-term  utility  contracts  at  stable  prices (OECD, 2019).

Public  financing  instruments,  such  as  loans,  guarantees  and  co-investment vehicles,  can  lower  investor  risk  and  improve  access  to  capital.  Meanwhile, workforce training subsidies, R&amp;D grants and integration into regional innovation ecosystems strengthen the long-term competitiveness of industrial facilities.

Technological innovation also shapes industrial competitiveness. Alongside efficiency gains and economies of scale, innovation remains an important lever for improving  product  quality  and  performance,  maintaining  cost  leadership  and reducing  emissions.  Over  time,  these  advantages  lead  to  strong  competitive positions. Patent activity provides one tangible measure of an economy's capacity to generate, protect and commercialise intellectual property. Over the past decade, China's share of global patents has increased rapidly, with the number of patents for clean energy rising four times faster than for all technologies combined (Figure 7.2). By contrast, patent growth in the European Union, Japan, and the United States  has  been  slower.  Yet,  when  assessed  using  metrics  that  include patent quality characteristics such as originality and scope rather than volume  these economies  continue  to  exhibit  strong  specialisation  in  several  key  enabling technologies, including smart grids, that support multiple value chains (IEA, 2024a).

Figure 7.2 Cumulative patents in selected countries and regions, 2013-2024

<!-- image -->

IEA. CC BY 4.0.

Note: Index 2013 = 1.

Source: IEA analysis based on European Patent Office's Worldwide Statistical Patent (PATSTAT) database.

China's share of global patents has increased rapidly over the last decade, with the number of patents for clean energy rising four times faster than for all technologies combined.

## Variations in input costs

The two primary factors of production in any industry - labour and capital - vary considerably  across  countries  and  regions,  reflecting  differences  in  economic structure,  institutional  frameworks  and  risk  profiles.  Labour  costs  refer  to  the expense of hiring a workforce to operate machines and equipment, while capital costs  relate  to  the  expense  of  raising  funds  to  acquire  land,  buildings  and machinery. Broadly, labour costs tend to be lower in emerging economies, while capital costs are typically lower in advanced economies.

Labour costs in advanced economies are generally much higher - sometimes by a wide margin. Manufacturing workers in Europe or the United States cost roughly 5 times more than their counterparts in China and up to 30 times more than in some  emerging  markets  and  developing  economies  (EMDEs).  However,  high wages  are  partly  offset  by  higher  productivity.  Workers  in  regions  with  higher labour costs tend to generate more output, either through better organisation of labour  or  greater  access  to  capital  (i.e.  more  machinery  and  equipment  per worker). In addition, regions with higher labour costs often employ a greater share of skilled labour, with lower-skill tasks more likely to be automated.

The  balance  of  wages  and  productivity  varies  by  sector  and  by  region.  For example, labour productivity  in car manufacturing in 2024 was higher in both the 1 European Union  and  the  United States  than  in  China.  By  this  measure,  these regions held a competitive advantage. Yet when labour costs are factored in, the advantage  shifts  in  the  opposite  direction,  illustrating  how  competitiveness depends on the combined effect of multiple drivers. 2

The availability of specific skill sets is also a critical factor. While many EMDEs have sufficient machine operators or production engineers for generic manufacturing,  they  may  lack  the  specialised  workforce  needed  to  scale innovative  or  complex  production  processes.  Countries  with  diverse  industrial bases,  producing  a  wide  range  of  goods,  including  those  not  readily  available elsewhere, are more likely to cultivate a workforce capable of supporting emerging industries  such  as  clean  energy  technology  manufacturing.  In  this  respect, advanced economies and China retain a notable advantage over most EMDEs.

Capital costs likewise show marked regional differences, though these are less pronounced  than  labour  costs.  These  differences  largely  reflect  the  real  or perceived risks of investment: the higher the risk, the higher the rate of return

1 Defined as gross value added (the value of output minus the value of intermediate inputs to production) per worker.

2 Lower labour costs can be associated with forced labour or other unethical practices; for example, specific forced labour incidents have been reported in China (International Labour Organization, 2025).

demanded by investors. This again gives an advantage to advanced economies and China, where risk perceptions - and, thus, capital costs - are generally lower.

A  common metric for  comparing  capital costs  is  the  weighted  average  cost  of capital (WACC), which reflects the cost of debt and equity financing as well as their  relative  shares.  Together  with  asset  depreciation  periods,  WACC  directly determines the annual contribution of capital costs to levelised production costs. In China, WACC typically ranges between 5% and 6%, compared with above 6% in many EMDEs and sometimes more than 10%.

Figure 7.3 Labour  costs  and  weighted  average  cost  of  capital  in  manufacturing industry for selected regions, 2024

<!-- image -->

IEA. CC BY 4.0.

Note: WACC = weighted average cost of capital. Source: IEA analysis based on IEA (2025b).

Labour costs vary more across countries and regions than capital costs, with the former generally lower in emerging economies, and the latter lower in advanced economies.

Even small changes in WACC can have a large effect on annualised capital costs. For  example,  a  USD 1 billion  investment  with  a  WACC  of  5%  and  a  25-year depreciation period results in annualised capital costs of around USD 70 million. Raising the WACC  to 15%  more than doubles this figure, to around USD 155 million.

Energy - another important production input - is a major determinant of regional differences in industrial competitiveness. Its significance varies widely by sector. In light industries, energy typically represents only a small share of total production costs.  By  contrast,  in  energy-intensive  industries,  it  can  dominate:  energy accounts for 20-40% of costs in metals production and more than 50% in upstream materials such as polysilicon.

Regional energy prices vary substantially, with little commonality across advanced economies,  nor  across  EMDEs.  This  reflects  the  influence  of  local  market conditions and individual government policies. Natural gas and electricity prices

show the widest regional variation, as they are strongly shaped by domestic supply and  demand.  Regions  with  abundant  local  gas  resources  or  easy  access  to pipeline  networks  generally  enjoy  lower  prices  than  those  reliant  on  imported liquefied natural gas (LNG). Some of the lowest natural gas prices are found in the United States and the Middle East, while in regions such as the European Union and Brazil prices can be more than five times higher (Figure 7.4).

Electricity prices broadly track natural gas prices, since gas is often the marginal fuel in liberalised power markets. As a result, electricity prices in the highest-cost regions can be up to seven times those in the lowest-cost regions.

Oil and coal prices show less regional variation because they are globally traded commodities.  Significant  differences  can  nonetheless  arise  due  to  taxation  or subsidies. For example, many European countries and India apply excise duties on  oil products  used  in  combustion,  while  such  duties  are  absent  in  the United States. Conversely, fossil fuel subsidies in many producing countries can make end-user prices significantly lower (OECD, 2024c).

Figure 7.4 Average industrial user energy prices by selected country or region and by fuel, 2024

<!-- image -->

IEA. CC BY 4.0.

Note: End-user prices include all taxes, subsidies and tariffs.

Source: IEA analysis based on IEA (2025c).

Regional energy prices vary substantially, with gas and electricity prices showing the widest variation, as they are strongly shaped by domestic supply and demand.

Taxes, duties and levies also play a major role in determining the electricity prices faced by industry. In some countries, network charges or the costs of renewable support schemes are directly incorporated into electricity bills, while in others they are funded through general government budgets. These policy choices significantly  affect  industrial  energy  costs  and  therefore  competitiveness.  For example, in Germany, taxes accounted for 14% of industrial electricity prices in 2024, compared with 1% in Japan.

## Regional trends in the manufacturing industry

## The importance and structure of manufacturing

Manufacturing remains a central pillar of the global economy, and  its share of global GDP remained broadly constant from 18% in 2000 to 19% in 2024. Global manufacturing value added doubled in real terms over this period, with more than 70% of the growth coming from China and other EMDEs.

China alone increased its share of global manufacturing value added by around 20 percentage points since 2000, underpinned by rapid industrialisation, largescale infrastructure investment and technological catch-up. Manufacturing value added as a share of China's own economy also rose, supported more recently by growth  in  higher-value  manufacturing  segments.  Beyond  China,  other  EMDEs increased their share of global manufacturing value added by around 4 percentage  points,  benefiting  from  improvements  in  technological  complexity and sectoral diversification (Figure 7.5).

Figure 7.5 Manufacturing value added by country or country grouping, 2000-2024

<!-- image -->

| Region's manufacturing VA as a %of world manufacturing VA   | Region's manufacturing VA as a %of region GDP   | Manufacturing VA (Billion USD 2024)   |
|-------------------------------------------------------------|-------------------------------------------------|---------------------------------------|
| 100%                                                        | 100%                                            | 12 000                                |
| 75%                                                         | 75%                                             | 9 000                                 |
| 50%                                                         | 50%                                             | 6 000                                 |
| 25%                                                         | 25%                                             | 3 000                                 |
| 0% 2000                                                     | EMDEs (excl. China) 0% 2000                     | China 0 2000 2024                     |
| AEs                                                         |                                                 |                                       |

IEA. CC BY 4.0.

Notes:  AEs  =  advanced  economies;  EMDEs  =  emerging  market  and  developing  economies;  VA  =  value  added. Manufacturing  VA  is  based  on  International  Standard  Industrial  Classification  (ISIC)  Rev.4  classification.  All  values  are calculated based on constant 2024 dollars.

Source: IEA analysis based on Oxford Economics Limited (2025).

Manufacturing's centre of gravity has been shifting from advanced economies to China since the turn of the century.

In contrast, advanced economies saw their share of global manufacturing value added decline by about 25 percentage points, with manufacturing value added as a share of their total value added falling slightly. This does not necessarily reflect rapid  deindustrialisation:  on  average,  their  per-capita  value  added  has  actually increased, amid a structural shift towards higher-value products.

The structure of manufacturing varies significantly across regions, shaped by the maturity of economies, relative production costs and strategic priorities. Globally, downstream industries account for the bulk of manufacturing value added. This is particularly the case in advanced economies, including Europe, Japan and the United States  (Figure  7.6).  These  regions  leverage  their  established  industrial bases and technological capabilities to drive innovation and raise value added. Downstream  industries  -  including  electronics,  pharmaceuticals  and  transport equipment - represent more than two-thirds of manufacturing value added.

In  China,  upstream  industrial  activities,  including  steel,  cement  and  aluminium production,  and  intermediate  activities,  like  metal  and  plastic  manufacturing, remain more prominent, accounting for over 40% of manufacturing value added. While  China  initially  concentrated  on  expanding  capacity  in  these  upstream segments, its industrial strategy has progressively shifted to encompass highervalue downstream sectors. This transition has been particularly notable in sectors with strong growth potential, like semiconductors, electronics and batteries.

Figure 7.6 Breakdown of manufacturing value added and economic complexity index for selected countries/regions, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: VA = value added; ECI = economic complexity index. This index ranks countries on a continuous scale based on how diversified and complex their exports are, with the highest ranked country currently at 2.52 and the lowest at -2.47. The ECI shown is an average of the values of each country over the 2021-2023 period. For the European Union, a weighted average was calculated based on the industrial VA of each member country. Upstream industry includes iron and steel, non-ferrous metals,  non-metallic  minerals,  chemicals  and  paper.  Intermediate  industry  includes  wood,  plastic,  rubber  and  metal manufacturing. All other manufacturing industries, such as pharmaceuticals, food and beverages, transport equipment and high-tech goods, are included in downstream. The fossil fuel refining sector is excluded.

Sources: IEA analysis based on Oxford Economics Limited (2025) and Growth Lab (2025).

Manufacturing in advanced economies is concentrated in downstream sectors, while India and Brazil focus more on upstream products.

In  several  EMDEs, the share of upstream sectors in total manufacturing value added has increased significantly in recent years - by around 4-5% since 2010 in countries such as India and Brazil. This reflects ongoing infrastructure build-out, the scaling-up of domestic manufacturing capacity and relatively lower labour and production  costs.  Advanced  economies  retain  an  edge  in  producing  more complex, high-value products. Indicators such as the economic complexity index (ECI), which ranks countries on a continuous scale based on how diversified and complex their exports are, show that countries like Korea, Germany and Japan specialise in sophisticated goods that few others can make (Growth Lab, 2025). China and Viet Nam have also moved rapidly up the complexity ladder: China rose from 30th to 16th in global ECI rankings between 2000 and 2023, while Viet Nam climbed from 86th to 48th, signalling growing productive capabilities and a shift towards more specialised manufacturing.

Industries positioned further down the value chain tend to generate higher value added. Sectors drawing on advanced technologies, strong innovation ecosystems and  unique  knowledge  bases  typically  capture  higher  shares  of  value  added because consumers pay a premium for specialised outputs. Upstream industries, by  contrast,  rely  more  on  standardised  technologies  and  process  efficiencies, leading to more commodified products with lower direct value added.

Although upstream industries, which are often highly energy-intensive, generate less direct value added per unit of output, they play a strategic role by supporting activity and value creation in the rest of the economy. Input-output analysis  shows 3 how their outputs become essential inputs for other industries: the iron and steel sector is a prime example, driving activity both upstream and downstream. On average,  each  USD 1 million  of  steel  output  enables  between  approximately USD 0.5 million and USD 1.9 million in total downstream domestic gross output in major  economies  (Figure  7.7).  Multipliers  are  strongest  where  downstream industry is large, and supply chains are predominantly domestic - as in China. Most  of  the  induced  activity  arises  in  metal  fabrication,  motor  vehicles,  and machinery and equipment, where steel is transformed into higher-value products.

3 See the Annex for a description of the methodology.

## Figure 7.7 Downstream domestic multipliers for the iron and steel sector in selected countries and regions, 2024

Downstream linkages

<!-- image -->

IEA. CC BY 4.0.

Notes:  The  multipliers  measure  the  average  domestic  output  that  is  generated  across  downstream  industries  for  each USD 1 million of iron and steel output, once all indirect effects are considered. Only domestic destinations (industries and final demand within the same region) are included. The European Union is treated as one single economy (i.e. any output used everywhere within the European Union is counted as domestic EU use).

Source: IEA analysis based on EXIOBASE v3.9.4 (Stadler (2025)) - an environmentally extended multi-regional input output -(EE MRIO) table.

Every  USD 1 million  of  iron  and  steel output  produced  in  advanced  economies  enables between 1.1 and 1.7 times more domestic output through linkages with downstream sectors.

Differences  in  downstream  linkages  and,  therefore,  multipliers,  reflect  each country's domestic sourcing and patterns of consumption. They shape resilience, competitiveness and exposure to shocks. Stronger domestic linkages amplify the economic contribution of upstream industries but also mean that disruptions in these  sectors  can  propagate  quickly  across  the  economy.  This  holds  for chemicals, petrochemicals, cement, aluminium and pulp and paper, as well as iron and steel. Downstream sectors such as pharmaceuticals or electronics add more value within their own boundaries but have fewer spillovers.

Chemicals  and  petrochemicals  highlight  how  sourcing  structures  influence competitiveness.  For  selected  countries  and  regions,  55-85%  of  intermediate inputs for that sector  are sourced  domestically,  even  in  energy-importing economies,  partly  because  refineries  supply  key  inputs  despite  relying  on imported feedstocks. Downstream integration varies as well: in Europe and the United States, chemical products are more export-oriented, whereas in China and Brazil, around 90% of output is consumed locally. More self-contained systems, with strong internal supply chains and limited reliance on imported intermediates, offer insulation from global disruptions but also carry risks. Domestic slowdowns can  intensify  overcapacity  pressures  and  squeeze  margins  during  economic downturns.

Figure 7.8 Share  of  intermediate  chemicals  and  petrochemicals  sourced  and  used domestically in selected countries and regions, 2024

<!-- image -->

% of output consumed domestically

IEA. CC BY 4.0.

Notes: For the European Union, all 27 Member States are treated as a single internal market, with transactions between EU member states counted as 'domestic', with only flows between those countries and the rest of the world treated as external. The size of the bubble indicates the amount of domestic value added by the chemicals and petrochemicals industry in each country.

Source: IEA analysis based on EXIOBASE v3.9.4 (Stadler [2025]).

In most major economies, the bulk of chemical products are consumed domestically, while the extent to which inputs are sourced domestically is more varied.

## Competitiveness of established industries

Industrial  competitiveness has changed markedly since 2000. Competitiveness has always been a concern for manufacturers, and the growing interconnectedness of the global economy has increased its importance. On a macro level, the size and structure of a country's manufacturing sector provide important  signals  about  its  competitiveness.  However,  they  can  sometimes  be misleading,  as  they  may  reflect  domestic  demand  rather  than  international strength - as has often been the case for China in several sectors. Similarly, high levels  of  specialisation  in  niche  manufacturing  areas  can  be  obscured  within broader sectoral categories. 4

To provide a clearer picture, industrial competitiveness can be assessed using the Revealed  Comparative  Advantage  (RCA)  index  (United  Nations  Trade  and Development, 2025). This measure evaluates whether a country is more or less specialised in a given sector compared with the world average, based on trade data. An RCA value above 1 indicates a comparative advantage, meaning the

4 For example, a broad category such as 'machinery', covering diverse products, can potentially mask specific competitive strengths or weaknesses in sub-sectors such as 'wind turbines or heat pumps'.

sector is more significant in the country's export mix than in global trade overall. 5 Rising RCA values point to a deepening comparative advantage, whether from productivity gains, stronger global demand or successful trade strategies. Falling RCA values suggest relative decline, due to stronger foreign competition, weaker demand, or a deliberate shift towards other sectors. While insightful, RCA is not without  limitations:  trade  data  can  be  shaped  by  non-tariff  barriers,  policy distortions and other structural factors.

RCA analysis highlights significant shifts in manufacturing competitiveness across major economies since 2000 (Figure 7.9). The European Union retains a strong industrial base, but traditional heavy industries have lost relative ground as they adapt within an increasingly competitive global environment. At the same time, the European Union has preserved its comparative advantage in machinery, while policy initiatives - such as the Net-Zero Industry Act - are stimulating investment in manufacturing capacity for clean energy technologies and their key components. The chemicals sector has seen a relative decline in competitiveness, partly due to high energy costs. Nevertheless, innovation and specialisation have allowed  European  producers  to  maintain  capacity  in  high-margin  specialty chemicals and expand further in pharmaceuticals.

In the United States ,  industrial competitiveness has fluctuated in recent years, shaped  by  technological  innovation,  energy  market  dynamics  and  targeted industrial  policies.  RCA  analysis  shows  that  the  country  has  retained  a  strong comparative  advantage  in  chemicals,  supported  by  sustained  investment  in petrochemicals  and  biopharmaceuticals.  Innovation  capacity,  efficient  logistics networks and access to affordable energy have reinforced this position.

The  shale gas boom  significantly reduced  domestic energy costs, while infrastructure expansion - including the construction of LNG export terminals and regulatory changes, such as the repeal of the crude oil export ban in 2015, positioned  the  United States  as  a  leading  exporter  of  oil  and  gas,  with  oil production nearly doubling between 2009 and 2015. This transformation has had far-reaching effects on global supply dynamics.

Figure 7.9 Revealed  comparative  advantage  in selected industrial sectors and countries and regions, 2000-2023

<!-- image -->

IEA. CC BY 4.0.

Notes: Revealed comparative advantage (RCA) is an index used to assess a country's relative advantage or disadvantage in exporting a particular good or sector, based on actual trade data. A high RCA means the sector is more important in the country's export mix compared with the global average. Energy includes both fossil and non-fossil fuels. Not all eight sectors are displayed for each region in order to highlight key trends.

Source: IEA analysis based on CEPII (2025).

Advanced economies tend to have a comparative advantage in high-tech products, though China is also becoming more competitive for these products.

In  parallel,  strong  private  investment  and  supportive  policy  measures  have sustained competitiveness in high-value manufacturing. Companies such as Tesla and Boeing illustrate the depth of private-sector innovation, while initiatives such as the CHIPS  and Science Act have channelled public resources into semiconductors, aerospace and defence supply chains. These combined efforts have helped the  United States  retain  leadership  in  key  segments  of  advanced manufacturing, including automotive and high-tech equipment.

Japan maintains  industrial  competitiveness  by  concentrating  on  a  set  of  hightechnology  sectors  -  notably  automotive  manufacturing,  robotics  and  highprecision  industrial  machinery.  The  electronics  sector  retains  a  comparative advantage despite declines in RCA, and for machinery and transport the indicator confirms a sustained comparative advantage, reflecting long-term specialisation. Co-ordinated policies, including the Green Innovation Fund, alongside instruments such as standards-setting and regional clustering, have enabled Japanese firms to  steadily  move  up  the  value  chain  (New  Energy  and  Industrial  Technology Development Organization,  2024).  The  result  is  a  durable  edge  in  specialised segments where quality, precision and reliability underpin export demand.

China 's manufacturing competitiveness has undergone a marked transformation. Between 2000 and 2010, the country consolidated its role as the global hub for mass production, with a sharp rise in RCA in machinery and transport equipment exports, supported by heavy investment. At the same time, RCA in low-complexity sectors such as textiles declined, reflecting the evolution of a maturing economy. Today, China continues to strengthen its comparative advantage in machinery while low-value manufacturing, such as textiles, continues to lose ground. Strong RCA  gains in electric vehicles (EVs) and exports of renewable energy technologies illustrate its shift towards high-value growth sectors.

Heavy industries, although vast in scale, are largely driven by domestic demand and  less  visible  in  RCA  export  metrics,  particularly  for  industries  with  national production caps or capacity restrictions. Government policies reinforce this shift by  encouraging  downstream  processing  and  domestic  supply  stability,  for instance, through high export duties on unwrought aluminium and the removal of tax  rebates  on  exports  of  semi-finished  aluminium  products.  Together,  these measures  highlight  China's  deliberate  repositioning  towards  more  complex, higher-value manufacturing.

India 's  manufacturing  competitiveness  remains  anchored  in  textiles  and  other light industries, which still dominate its export profile. RCA measures confirm these traditional  strengths,  but  recent  trends  highlight  gradual  industrial  upgrading. Growing capabilities in automobile assembly and pharmaceuticals are emerging as pillars of comparative advantage, supported by policy initiatives such as Make in  India,  which  encourage  dedicated  investment  in  manufacturing.  Structural barriers, including infrastructure bottlenecks and high logistics costs, continue to weigh  on  capital-intensive  sectors,  but  the  overall  trajectory  points  to an incremental broadening of India's industrial base.

Brazil is becoming increasingly competitive in energy and mining, with rising RCA driven  by  abundant  natural  resources,  strategic  investment  and  robust  global demand. By contrast, its comparative advantage in heavy industry has declined, constrained by international competition, infrastructure gaps and limited technological  progress.  National  policies  now  classify  strategic  minerals  as  a matter of 'sovereignty', aiming to limit raw material exports and promote greater domestic  value  addition.  Its  resource  endowment  positions  Brazil  as  a  highly competitive player in energy and resource-based industries, despite the recent weakening of traditional heavy industry.

## Energy-intensive industries

Energy-intensive industries  matter far beyond their direct share of value added 6 or jobs. They account for around 30% of global manufacturing value added and 20% of manufacturing employment, yet are seen as strategic by governments because  they  provide  the  foundational  inputs  for  downstream  manufacturing industries.  Steel,  cement,  aluminium  and  primary  chemicals  are  embedded  in everything  from  cars  and  pharmaceuticals  to  aircraft  and  infrastructure.  This creates  highly  interdependent  ecosystems:  for  example,  just-in-time  vehicle production relies on stable supplies of steel and alloys, and secure food supply relies on fertiliser availability. However, these industries are particularly vulnerable to international competition as most of their products can be easily traded.

Losing domestic capacity in such sectors carries high risks. Once closed, facilities can be extremely difficult to bring back online or rebuild, making supply chains more fragile in times of crisis. Energy-intensive industries also underpin defence and  critical  infrastructure,  making  them  important  for  national  security.  They account for about 70% of global industrial energy demand (and more than 80% of industrial CO  emissions), reflecting their bulk-material nature and the large weight ₂ of energy in their cost structure.

Energy costs are a major determinant of competitiveness in these industries. In some processes, such as ammonia production, energy can represent more than 60% of direct manufacturing costs. Methanol production is even more exposed, with  energy  accounting  for  roughly  90%  of  overall  costs.  As  a  result,  these industries  are  structurally  more  exposed  to  energy  price  volatility  than  other sectors of the economy, for which direct energy inputs typically account for less than  3%  of  their  total  output  value  (Figure  7.10).  A  relatively  small  change  in energy prices can wipe out already thin margins, particularly in globally traded commodities where prices are set by international benchmarks. For example, a primary aluminium producer with energy costs making up 30% of total production costs and operating at a 10% profit margin would lose all profitability if energy prices were to rise by around 35%.

6 Energy intensive industries refer to Iron and steel [ISIC Rev. 4 Group 241 and Class 2431], Chemicals and petrochemicals [ISIC  Rev.  4  Divisions  20  and  21],  Non-ferrous metals [ISIC  Rev. 4  Group  242  and  Class  2432],  Non-metallic  minerals [ISIC Rev. 4 Division 23] and Paper, pulp and print [ISIC Rev. 4 Divisions 17 and 18].

Figure 7.10 Cost of energy inputs as a share of the value of global industrial output by sector, 2022

<!-- image -->

IEA. CC BY 4.0.

Notes: Direct refers to the cost of the energy directly used by companies in the sector; indirect refers to the cost of the energy used to manufacture non-energy intermediates which are inputs for companies in the sector. Energy refers to coke and refined petroleum products and electricity, gas, steam and air conditioning.

Source: IEA analysis based on European Commission (2025a).

Energy-intensive industries are structurally far more exposed to energy price volatility than other sectors of the economy.

Energy  costs  vary  widely  across  regions  once  taxes,  subsidies,  transport  and infrastructure are taken into account. In the global steel sector, coal prices can differ by a factor of around seven, electricity by a factor of eight and natural gas by as much as twenty (Figure 7.11). Price volatility also varies greatly: coal  is generally the least volatile, while electricity prices fluctuate the most. As a result, coal-based production routes are relatively insulated from short-term energy price swings,  whereas  natural  gas-  and  electricity-based  routes  face  much  higher exposure.

Figure 7.11 Average  global  levelised  cost  of  selected  materials  and  energy  related regional variation, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: BF-BOF = blast furnace-basic oxygen furnace; EAF = electric arc furnace; SMR = steam methane reforming. Other costs  include  capital  expenditure  (CAPEX),  operating  expenditure  (OPEX)  and  material  costs.  Energy  includes  fuels consumed for energy and feedstock purposes. Regional variation reflects only differences in fuel price and energy intensity. Fuel prices ranges are USD 1.5-10/GJ for coal, USD 1-20/GJ for natural gas and USD 35-260/MWh for electricity (USD 5100/MWh for aluminium smelting). CO2 pricing and subsidies are not considered. For steel, BF-BOF assumes no scrap input.

Regional differences in energy price play a key role in determining the cost-competitiveness of the leading bulk materials.

This exposure was laid bare during the 2022 energy crisis in Europe. While overall manufacturing held steady, energy-intensive industries contracted sharply (Figure 7.12). Basic chemicals output fell by more than 30%, ammonia production by one-third and in 2023 naphtha consumption dropped to its lowest level since 1975  (Bloomberg,  2023).  Several  steam  crackers  in  the  Netherlands  (Argus, 2024b), France (ICIS, 2024), Italy (Tullo, 2024) and Germany (Argus, 2024a) have since  closed  or  are  set  to  close  under  pressure  from  both  energy  costs  and competition  from  China  and  the  United States,  where  large  new  capacity  has come online. The European Union also lost almost 50% of its primary aluminium capacity due to the energy crisis (European Aluminium, 2025).

Figure 7.12 Industrial  production  indices  and  energy  costs  in  the  European Union, 2015-2025 and polyethylene export market shares by country, 2000-2025

<!-- image -->

<!-- image -->

IEA. CC BY 4.0.

Notes: TTF = Title Transfer Facility; Left-hand chart shows six-month rolling average. Sources: European Commission (2025c); Argus (2025); and CEPII (2025).

EU energy-intensive manufacturing output slumped in the wake of the 2022 energy crisis, while US exports of polyethylene soared, thanks to its access to cheap ethane resources.

By contrast, US petrochemical producers have benefited from cheap shale gas. Abundant low-cost ethane, produced in association with shale gas, has led to a doubling of the US share of global polyethylene exports over the past decade. Ethane itself has become a major export, rising from less than 50 000 barrels per day (kb/d) in 2014 to 500 kb/d in 2024 (US Energy Information Administration, 2025),  with  China  the  leading  buyer.  Similar  dynamics  have  played  out  in  the Middle  East.  Strong  aluminium  export  growth  has  been  supported  by  limited domestic  demand  and  substantial  new  capacity  made  viable  by  low-cost electricity,  enabling  producers  in  the  region  to  compete  effectively  in  global markets.

The  link  between  energy  prices  and  competitiveness  is  set  to  strengthen  as decarbonisation efforts in different countries reshape industrial energy systems. Because electricity and emerging energy carriers such as hydrogen are harder and  more  expensive  to  transport  than  fossil  fuels,  the  geography  of  energyintensive production is likely to shift. Proximity to abundant, low-cost clean power will increasingly influence where industries choose to locate, as energy spending could be several times higher with near-zero emissions technologies.

Aluminium  already  shows  how  cheap  electricity  shapes  global  production patterns.  Primary  smelting  -  one  of  the  most  electricity-intensive  industrial processes - has historically been concentrated in regions with inexpensive, often stranded  hydropower,  such  as  Iceland,  Norway  and  Canada.  These  locations

developed competitive smelting industries precisely because surplus power could not be easily moved to other demand centres. Although rapid growth in Chinese smelting based on captive coal-fired power loosened this relationship in the 2000s, the  trend  is  now  reversing:  hydropower  is  regaining  importance,  and  some producers are exploring solar and wind power for future operations (International Aluminium Institute, 2025) (Rio Tinto, 2024).

The shift  to  low-emissions  production  technologies  will  reinforce  this  clustering effect. As industries adopt electricity- or hydrogen-based processes, the share of energy in total production costs may rise, making access to cheap clean power even more critical. This could create patterns similar to those seen in aluminium, with competitive advantage concentrated in regions rich in solar, wind, hydropower or other low-emissions resources, potentially reshaping global supply chains.

Nevertheless,  energy-intensive  manufacturing  can  remain  competitive  even  in countries  with  relatively  high  energy  prices  when  it  is  anchored  by  strong downstream  ecosystems,  such  as  vehicle  manufacturing  and  the  aerospace sector. This helps explain why the European Union and Japan continue to play a significant role in global steel production despite elevated energy costs, accounting  for  7%  and  4%  of  world  output  respectively  (Table  7.1).  Japan,  in particular, is a major exporter, accounting for about 10% of global steel exports.

Despite energy cost disadvantages, close integration with export-oriented enduse sectors provides important advantages for material producing industries. This is reflected in an RCA of about 3.5 for Japan's vehicle industry and 1.7 for that of the European Union. The United States does not register a comparative advantage in steel, aluminium and other metal exports, but still produces 4% of global steel and 5% of global aluminium. This is sustained by efficient scrap usage, supportive trade policies and demand from competitive downstream sectors such as  automotive  and  aerospace,  where  the  United States  has  an  RCA  of  3.3 (Figure 7.13).

China is the key player in global steel, producing more than half of the world's total, of which most is consumed domestically. As domestic demand has begun to ease,  exports  have  risen  sharply,  reflecting  China's  increasing  comparative advantage.  RCA  analysis  shows  that  its  competitive  position  in  steel  has strengthened steadily, particularly in flat products, which generally carry higher value.  More recently,  China  has  built  new strengths  in  EVs. What  began  as  a domestic-oriented  industry  has  now  become  a  fast-growing  source  of  exports, reshaping its industrial profile.

Figure 7.13 Revealed comparative advantage in selected industries and countries and regions, 2000-2023

<!-- image -->

Notes: Revealed comparative advantage (RCA) is an index to assess a country's relative advantage or disadvantage in exporting a particular good or sector, based on actual trade data. A high RCA means the sector is more important in the country's export mix compared with the global average.

Source: IEA analysis based on CEPII (2025).

Even where heavy industry is becoming less competitive, supply chain integration with downstream sectors gives domestic production some important advantages.

## Focus on the steel industry

Crude steel production remains one of the most energy-intensive industries, with energy and raw materials making up more than two-thirds of production costs. The availability  and  price  of  coal,  natural  gas,  electricity,  iron  ore  and  scrap  are therefore decisive for cost-competitiveness.

Today, around 90% of global ironmaking uses the blast furnace (BF) route, which mostly  uses  coal.  This  route  dominates  in  most  countries,  including  in  China, which is by far the largest iron and steel producer (Table 7.1). Less than 10% of iron is made via the direct reduction process. Production of direct reduced iron (DRI) is concentrated where natural gas is abundant and cheap: the largest DRI producers are in the Middle East (36% of global production), North Africa (9%) and North America (9%). India (37%) is  an  exception,  where most  of  the  DRI production is based on cheap domestic coal.

Making iron is by far the most energy-intensive step in steel production. Steel scrap, when available, can substitute iron demand. Where end-of-life steel stocks are significant and electricity is affordable, scrap-based steelmaking in electric arc furnaces  (EAFs)  is  highly  competitive.  The  United States  (64%  scrap  share  in

metallic inputs) and  European Union  (51%)  rely  far  more  on  scrap-based production than China (24%) or India (20%), reflecting their mature economies with greater stocks of steel in use.

Table 7. 1 Steel production and trade by region and by route, 2024

| Region                    | Share of global crude steel production   | Share of DRI based iron   | Share of scrap input   | Share of global steel export   |
|---------------------------|------------------------------------------|---------------------------|------------------------|--------------------------------|
| China                     | 53%                                      | 0%                        | 24%                    | 28%                            |
| India                     | 8%                                       | 37%                       | 20%                    | 3%                             |
| European Union            | 7%                                       | 0%                        | 51%                    | 14%                            |
| Japan                     | 4%                                       | 0%                        | 37%                    | 10%                            |
| United States             | 4%                                       | 20%                       | 64%                    | 3%                             |
| Eurasia                   | 4%                                       | 12%                       | 33%                    | 6%                             |
| Korea                     | 3%                                       | 0%                        | 39%                    | 8%                             |
| Middle East               | 3%                                       | 93%                       | 17%                    | 4%                             |
| Central and South America | 2%                                       | 9%                        | 43%                    | 2%                             |

Notes: DRI = Direct Reduced Iron. The DRI share is calculated for total iron production. The share of scrap considers all inputs and not just for electric arc furnaces. The share of global exports is based on 2023 data and is calculated using data for semi-finished and finished steel products. Trade within each region is excluded.

Sources: World Steel Association (2025); and CEPII (2025).

Labour  costs  vary  as  much  as  energy  across  regions,  but  this  matters  less because wages are a relatively small part of steel production costs. Raw material costs show smaller regional differences, though transport can be significant; for example, shipping iron ore from Australia to China can add up to 20% to delivered costs. Specialty alloys such as nickel in stainless steel can also heavily influence costs.

Energy efficiency is  another  critical  factor  affecting  cost-competitiveness.  Plant age, the extent of modernisation, the adoption of best operational practices and the quality of raw material inputs all influence overall performance. Given long investment cycles, major refurbishment projects provide key opportunities to raise efficiency levels.

The  levelised  cost  of  producing  steel  varies  widely  worldwide  (Figure  7.14). Carbon pricing further impacts competitiveness. BF-BOF plants, with high coal reliance, are most exposed, while scrap-based production is largely unaffected. Higher-cost producers can compete in niche high-quality segments or regional markets, but fundamental energy economics remain hard to escape, especially in the context of global overcapacity.

Figure 7.14 Levelised  cost  of  steel  production  for  conventional  production  routes according to energy, labour, material and carbon prices, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: BF-BOF = blast furnace-basic oxygen furnace; DRI = direct reduced iron; EAF = electric arc furnace. The levelised cost of production is the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. Energy price ranges are based on those prevailing in 2024. Material input prices vary over time according to market conditions - the range represents price variations over the past decade. The typical cost range represents steel price variations over the past decade. Labour costs represent the range of typical hourly wage rates per tonne of steel in 2024. Input values to reference costs are approximations of global median values: USD 100/MWh for electricity, USD 5/GJ for coal, USD 10/GJ for natural gas, USD 108/t for iron ore, USD 400/t for scrap, USD 6/hour for labour and USD 0/t for CO2. Sources: IEA analysis based on World Steel Association (2025) and BNEF (2025b).

Steel production costs vary significantly across the world, mainly according to differences in production routes and energy input costs.

Among energy-intensive industries, the steel sector has become a decarbonisation  focus  in  many  countries,  supported  by  recent  progress  in developing near-zero emissions technologies. Nonetheless, commercialisation of key near-zero emissions steelmaking routes remains at an early stage. Projects currently in the pipeline amount to around 10 Mt of capacity and an additional 105 Mt  of near-zero  emissions  capable capacity.  Competitiveness  remains  a critical concern; for near-zero emission routes, this depends even more heavily on access to cheap low-emissions electricity than for conventional steelmaking.

The most promising route - hydrogen-based DRI with EAFs - requires high-grade iron ore and very large supplies of affordable low-carbon electricity. Locations with abundant  low-cost  hydropower,  solar,  or  wind  could  make  hydrogen-based steelmaking  cost-competitive  with  conventional  technologies,  especially  under scenarios with higher carbon costs. Such favourable locations exist in countries including Australia, Brazil, China, India and the United States. By contrast, more limited renewable resources and high grid electricity prices in industrial areas in regions like Japan and the European Union mean that production costs for this route can be 50-80% higher than elsewhere, well above regional differences for conventional steel production today (around 25-50%). In fact, these higher costs

have been cited as a major factor behind the recent delay, indefinite suspension, or cancellation of over 15 Mt of hydrogen-based DRI projects.

Governments can influence industrial electricity prices through taxation, levies, permitting  and  infrastructure  planning.  Yet  closing  the  gap  with  regions  rich  in abundant  high-quality  renewable  resources  could  require  substantial  public financial support. One possible solution is offshoring a portion of the ironmaking step  to  regions  with  competitive  renewable  energy  resources  like  Africa,  Latin America or Southeast Asia, and importing DRI for local steelmaking. This could narrow cost differences back down to 30-40% (Figure 7.15).

Figure 7.15 Levelised cost of steel production via hydrogen-based direct reduced iron in the Stated Policies Scenario, 2035

<!-- image -->

₂

IEA. CC BY 4.0.

Notes: H2 DRI = hydrogen-based direct reduced iron; VRE = variable renewable electricity. The levelised cost of production is the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. Grid uses the industrial end-user range of grid electricity for industry in 2024. VRE uses the price range of electricity produced from variable renewables plus the cost of hydrogen storage required to guarantee a minimum load of 80%. The range for imported iron assumes the iron is produced in a region with lower energy price (Brazil for the European Union and Australia for Japan) and imported to produce steel locally. The conventional range gives the cost of unabated conventional primary production of steel with unabated fossil fuels (blast furnace-basic oxygen furnace and DRI-electric arc furnace), with or without carbon pricing, at a value of USD 150/tonne of CO2.

Dedicated renewable generation can considerably reduce hydrogen-based DRI production costs, while the European Union and Japan could import iron to improve competitiveness.

While offshoring ironmaking could shift part of the value chain abroad, it could help prevent the erosion of domestic steel production by addressing the problem of cost-competitiveness in the most energy-intensive steps. Early, proactive policy could safeguard the 75-90% of direct jobs in steelmaking and finishing (Bataille, et al., 2025) (RMI, 2024) (Agora Industry, 2023) and preserve the benefits that stem from close integration with downstream steel-consuming industries in the region (Agora Industry, 2025). Shifting from imports of iron ore to imports of iron

would introduce new dependencies and potential risks, but precedents for such trade arrangements already exist. Notable examples include agreements between Namibia and Germany (Green Hydrogen Innovation Centre, 2024), Oman and Viet Nam (Hydrogen Europe, 2025), and Australia and China (Brown, 2025).

Carbon capture and storage could extend the competitiveness of existing BF-BOF and gas-DRI assets faced with the need to decarbonise, though it adds 30-55% to  capital  costs  and  remains  dependent  on  low-cost  energy.  Proximity  to  CO ₂ storage  sites  and  clustering  with  other  industries  could  make  this  option  more viable.  In  the  longer  term,  other  more competitive  technology  options,  such  as molten oxide electrolysis, could emerge.

Demand for near-zero emissions steel remains modest but is growing, though greater  certainty  on  climate  policies  is  needed  to  build  market  confidence (see Chapter 2). Several major steel-consuming sectors - notably the automotive industry - are facing pressure from shareholders and consumers to decarbonise their value chains. This is creating early demand for near-zero emissions steel. High value-add sectors are among the most capable of absorbing the higher costs of steel in final products.

Voluntary labels for near-zero and low-emission steel are one option to stimulate demand. Certification and labelling initiatives are only just beginning to emerge (Responsible Steel, 2024) (LESS, 2025), yet their potential coverage could reach up  to  72%  of  global  production.  In  parallel,  initiatives  such  as  the  First  Mover Coalition (World Economic Forum, 2025), SteelZero (Climate Group, 2025) and the Industrial Deep Decarbonisation Initiative (IDDI, 2025) are helping to build a customer base. For example, GE Vernova has committed to purchasing near-zero emissions steel for its operations in the United States (SSAB, 2025).

Companies  able  to  move  early  may  benefit  from  initial  'green  premiums'  and secure  strong  positions  in  what  could  become  a  rapidly  growing  near-zero emissions steel market (see Chapter 2). Carbon border adjustments mechanisms, which aim to price the carbon embedded in imported goods, may also bolster the competitiveness of near-zero emissions steel (Box 7.1), though practical difficulties in implementing them might hinder their effectiveness.

## Box 7.1 The EU Carbon Border Adjustment Mechanism (CBAM)

CBAMs  add  a  cost  to  carbon-intensive  imports,  making  lower-carbon  domestic production more  competitive  and  encouraging  producers  abroad  to  reduce emissions. The European Union became the first jurisdiction to establish a CBAM, which is scheduled to come into force in 2026, after a transitional phase from 2023. The mechanism seeks to confirm a price has been paid for the embedded carbon emissions generated in the production of imports into the region and to ensure the carbon price of imports is equivalent to that incurred by EU domestic production. It eventually  aims  to  cover  more  than  50%  of  the  emissions  covered  in  the EU Emissions Trading Scheme (ETS).

This scheme is expected to have a significant impact on the cost-competitiveness of EU  steel production. For example, conventional steel produced  in the European Union is projected to cost around USD 980/t in 2035 in the Stated Policies Scenario (STEPS), compared with import costs of USD 940/t (Figure 7.16).  The CBAM increases costs by USD 100/t, which - added to tariffs - would help EU steel producers to compete.

Figure 7.16 Levelised cost of production of steel in the European Union and cost of imports from Brazil in the Stated Policies Scenario, 2035

<!-- image -->

IEA. CC BY 4.0.

Notes: H2 = hydrogen; CBAM = Carbon Border Adjustment Mechanism. Direct policy costs outside of the EU Emissions Trading  Scheme (ETS) and CBAM are excluded from this analysis but import tariffs are included. Domestic refers to production in western Europe. Imports are from Brazil to western Europe. 'Near-zero emissions' corresponds to H2-DRI technology, while conventional refers to a natural gas-based furnace, both of which are equipped with an electric arc furnace. In all cases, 100% primary production is assumed. A cost of capital of 5.2% is assumed for western Europe and 7.5% for Brazil. Error bars show the impact of variation in hydrogen costs for different locations in each region for the nearzero emissions route (95%-175% for the European Union and 65%-175% for Brazil), and variations of natural gas and electricity prices over the period 2015-2020 (natural gas: 85%-120% for the European Union and 85%-125% for Brazil; electricity: 95%-105% for the European Union and 95%-105% for Brazil). The cost of CO2 is assumed to be USD 150/t.

The CBAM and EU ETS are not expected to have a significant impact on near-zero emissions  production.  Costs  for  producers  that  move  to  hydrogen-based  DRI remain high, at USD 1 100/t, in the same scenario, but importing DRI from low-cost producing regions (e.g. Brazil) and finishing it domestically could bring EU costs close to parity with conventional domestic production while preserving most jobs and value added in the sector. In contrast, importing hydrogen is not competitive. Near-zero emissions steel (imported or made domestically with imported iron) also achieves cost parity with conventional steel imports as a result of CBAM costs.

It is important to remember that steel production costs represent only a small share of most end-products. For example, using near-zero emissions steel and cement would increase the cost of building a house by around 2% and that of making a car by 1%. However, steel remains an important cost driver in some other sectors, such as wind turbines. As a result, any increase in the cost of steel associated with the transition to near-zero emissions production would likely have only a small impact on the final price of consumer products. For regions with limited access to low-cost clean energy, establishing a competitive near-zero emission steel sector will  require  governments  to  adopt  targeted  long-term  policy  support  and  the industry  to build robust  supply  chains  in  partnership  with  other  countries (see Chapter 8).

## Competitiveness of clean energy technologies

## Understanding the manufacturing cost gap

The rapid deployment of clean energy technologies worldwide is generating major economic opportunities in manufacturing them. Capturing these opportunities has become a strategic priority for many governments and industries. At the same time, the high level of concentration of clean energy technology supply chains is prompting governments to explore ways of mitigating associated risks. A growing number of countries have announced industrial strategies aimed at developing domestic manufacturing capacity for clean technologies and their components, though in several cases these plans remain aspirational and are not yet backed by firm policy commitments (See Table 4.1).

Competition is particularly intense with companies located in China - the global leader in clean energy technology manufacturing - and in a small number of other countries  that  have  established  strong  positions  in  specific  segments.  Not  all facilities  in  China  are  Chinese  owned;  some  are  operated  by  international companies  with  long-lasting  experience  in  these  industries.  China's  broader competitive  position  reflects  sustained  advantages  built  up  over  many  years,

including  continuous  technological  innovation,  large-scale  investment,  a  skilled workforce,  well-integrated  supply  chains  and  natural  endowments  such  as resource availability and low-cost labour. Many of these strengths were achieved through a long-term industrial policy that combined direct government support with intense competition among domestic manufacturers, driving consolidation and the emergence of a small number of highly successful firms. Achieving success in other regions will depend on narrowing this competitiveness gap, both by reducing production  costs  and  improving  overall  investment  conditions  for  clean  energy manufacturing.

As in other manufacturing sectors, competitiveness in clean energy technologies depends on several factors,  including  product  quality,  innovation  capacity  and supporting infrastructure. However, production costs are the most decisive factor in  shaping  the  competitive  advantage,  since  lower  costs  usually  translate  into lower prices  and  higher market  share.  This  effect  is  especially  pronounced for technologies  that  can  be  mass  produced,  are  relatively  standardised,  and  are inexpensive to transport. Production costs are influenced by familiar drivers such as energy prices, labour costs, access to the latest technologies and the cost of capital. However, clean energy technology manufacturing is still a relatively young industry, and additional factors - such as manufacturing efficiency, the availability of  skilled  workers  and  the  scale  of  production  facilities  -  are  often  critical determinants.

The  implications  of  lower  equipment  prices  in  final  installation  costs  vary significantly across technologies. For many traded clean technology components -  such  as  PV  modules,  battery  cells,  heat  pumps  and  electrolyser  stacks  equipment  accounts  for  a  relatively  small  share  of  total  installation  costs.  For example, PV modules make up just 15% of total capital expenditure (CAPEX) for utility-scale solar projects, with the remainder coming from mounting structures, cabling and power electronics. Similarly, for electrolysers, stacks account for only around 15% of total CAPEX, while the majority arises from the balance of plant, which includes complex chemical engineering systems (Figure 7.17).

The share of upfront capital costs associated with equipment in total lifetime costs also varies by technology. In power generation, CAPEX represents about threequarters of the levelised cost of electricity (LCOE) for wind and solar. For batteries, the  balance  between  CAPEX  and  operating  expenditure  (OPEX)  is  similar:  in stationary storage systems and battery electric vehicles, OPEX represents just about 20% of total costs. Conversely, for heat pumps and electrolysers, OPEX is dominant,  as  energy  consumption  over  their  lifetime  outweighs  the  initial investment.  Regardless  of  the  technology,  even  when  equipment  CAPEX represents a small share of total production costs, both private and public actors generally  favour  lower-cost  options,  since  small  cost  differences  can  tip  the balance between profitable and loss-making projects.

Figure 7.17 Breakdown of the  levelised  cost  of  energy  service  delivery  for  selected installed technologies, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: OPEX = operating expenditure; CAPEX = capital expenditure; BEV = battery electric vehicle. CAPEX equipment refers to solar PV modules; wind turbine nacelles, blades and towers; battery cells; Heat pump external units and electrolyser stacks. Heat pump is air-to-water. Battery storage refers to a 2-hour system. Delivered energy service relates to the output of the technology, i.e. electricity for solar PV (utility-scale), wind and battery storage, distance driven for BEVs, heat for heat pumps and hydrogen for electrolysers.

The share of equipment capital costs in total lifetime costs is relatively low for solar PV, EVs and electrolysers, and highest for stationary battery storage and onshore wind.

China  holds  advantages  across  most  major  cost  drivers  relative  to  advanced economies, while in comparison with other EMDEs its labour costs and, in some cases, energy costs, are higher. China has long been the world's largest producer of  clean  energy  technologies,  and  this  sustained  leadership  has  given  firms operating there a strong edge  in technical know-how  across  almost all technologies. Electrolysers remain an exception, as large-scale mass manufacturing has yet to be established anywhere.

The  relative  importance  of  different  manufacturing  cost  components  varies  by technology and by stage of the supply chain:

-  Labour costs: Labour generally accounts for less than 5% of total production costs across most steps in China (Figure 7.18). A notable exception is wind turbine blade manufacturing, which has proven difficult to automate because of the scale of the products and the complexity of the operations involved.
-  Energy  costs: Direct  energy  use  can  be  a  major  cost  factor  in  upstream processes  involving  highly  energy-intensive  material  transformation.  For example, energy makes up about half of total costs in polysilicon production, compared with around 5% in solar PV module manufacturing. In batteries, energy accounts for around 20% of anode material production costs but closer to 5% for cell manufacturing.

-  CAPEX: CAPEX contributes between 2% and 15% of the levelised cost of production  (LCOP) for  clean  energy  technology  manufacturing,  though  this varies  by  process.  Assembly-oriented  steps  such  as  solar  PV  module production, nacelle assembly or heat pump manufacturing require relatively simple equipment, so CAPEX accounts for less than 5% of total costs. By contrast, battery cell manufacturing relies on highly complex, fast and precise processes, pushing the CAPEX share closer to 10%.
-  Materials  and  components: The  bulk  of  costs  across  all  clean  energy technologies are associated with inputs of materials and components. Material inputs are typically semi-finished steel and aluminium products, plastics and fibres. Components vary widely, ranging from fully assembled items, such as printed circuit boards, compressors or gearboxes, to semi-finished components like solar glass or separator membranes. The further downstream a  production  step,  the  higher  the  share  of  costs  accounted  for  by  fully assembled components, while upstream stages rely more heavily on raw or semi-finished materials.
- Component directly upstream
- Other component and material costs
- Energy costs
- Fixed OPEX
- Labour costs

Figure 7.18 Breakdown of the levelised cost of production for selected clean energy technologies in China, 2024

<!-- image -->

CAPEX

IEA. CC BY 4.0.

Notes: OPEX = operating expenditure; CAPEX = capital expenditure. Batteries refer to lithium-ion batteries; costs are based on the global weighted average battery chemistry sales. Cathodes and anodes refer to active materials.

The shares of different manufacturing cost components vary by technology and supply chain stage, but materials and components make up the bulk of costs for all technologies

Relative  to  most  advanced  economies,  China  generally  retains  a  significant production  cost  advantage  (Figure  7.19).  This  is  particularly  pronounced  in technologies where labour, capital equipment or small component costs make up significant parts of the overall costs - for example, wind turbine nacelles or heat pumps - since these  inputs  are much  cheaper  in  China.  For  energy-intensive manufacturing steps, such as polysilicon production, the picture is more mixed. In North America, energy prices can be as low as in China, narrowing the cost gap: for example, the LCOP of polysilicon in the United States is estimated to be only just around 15% higher than in China.

Figure 7.19 Additional  cost  of  manufacturing  selected  clean  energy  technologies compared with China, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: Based on the levelised cost of production. Batteries refer to lithium-ion battery cells.

China generally retains a significant cost advantage over advanced economies, while cost gaps with other EMDEs are smaller, due to comparable or lower labour and energy costs.

In EMDEs, cost gaps with China are often smaller, reflecting comparable or even lower  labour  and  energy  costs.  However,  low  production  costs  alone  are  not sufficient to establish global manufacturing hubs: local demand, infrastructure and skilled labour availability are also essential. For energy-intensive processes, some EMDEs with particularly low energy costs - such as countries in the Middle East -  could  achieve  production  costs  even  lower  than  China's.  This  advantage  is already  triggering  investment,  with  two  new  polysilicon  plants  currently  under construction in the region.

## Box 7.2 Analysing regional cost gaps in clean energy technology manufacturing

Our analysis focuses on identifying key strategies that can contribute to closing the manufacturing  competitiveness  gap  with  the  cheapest  producer  for  key  clean energy technologies. This analysis is grounded in detailed, bottom-up assessments of the structure and regional differences in the levelised costs of production for key technologies and components. For supply chain steps that are not currently being produced in a given country, theoretical costs of production were estimated. This allows for an estimation of the cost differences across an entire supply chain if it were to take place in a single region (except for mineral mining and processing).

The  specific  contributors  to  manufacturing  costs  along  different  steps  of  supply chains are based on assessments of plant-level datasets as well as a thorough review of the publicly available literature.

The resulting  regional  differences  in  manufacturing  costs  for  relevant  contributing factors were used to identify, assess and quantify the specific strategies that could be pursued to reduce such differences. The analysis has been enriched and validated through consultations with a wide range of experts in different supply chains, including experts  in  different  relevant  functions  within  manufacturing  companies,  technical analysts and data providers with deep supply chain knowledge.

An assessment of production costs across clean energy technology supply chains shows  that  no  single  factor explains China's  cost advantage.  Comparing production in China with Europe illustrates that structural cost differences, such as  energy  and  labour,  account  for  a  large  share  of  the  gap  in  steps  that  are particularly energyor labour-intensive, including upstream solar PV manufacturing and wind blade production (Figure 7.20). Economies of scale are especially important for heat pumps and solar PV, while for batteries over  40% of the  cost  gap  reflects  higher  manufacturing  efficiency  in  China.  Pathways  to narrow these gaps exist, but they differ markedly by technology (see Chapter 8).

Levelised production costs alone  are not sufficient to determine  whether manufacturing  a  given  technology  in  a  given  region  can  generate  profitable operations and attract private capital. Financial performance indicators such as the  relationship  between  the  average  Return  on  Invested  Capital   (ROIC)  and 7 Weighted  Average  Cost  of  Capital   (WACC)  provide  a  more  nuanced  picture. 8

7 ROIC is calculated by dividing net operating profit after taxes by the invested capital and measures how efficiently a company allocates its capital to generate profits.

8 WACC refers to the average rate of return required by all providers of capital, both debt and equity, based on their proportional contribution to the capital structure.

A company  generates  value  for  private  investors  when  its  ROIC  exceeds  its WACC. In 2019, China's solar PV industry presented a mixed picture, with some firms operating above their WACC. By 2024, however, intense competition had pushed manufacturers along the supply chain into loss-making territory (see Chapter  4).  Since  2024,  more  than  40  Chinese  solar  firms  have  been delisted, gone bankrupt or been acquired (Reuters, 2025c) and financial reports suggest this trend is likely to continue for now (BNEF, 2025a). In response, firms have taken steps to reduce the polysilicon supply glut by cutting capacity by about one-third (Reuters, 2025a) and the government has introduced cost guidelines to establish a price floor for state-owned procurement (Reuters, 2025b), which could help lift capital efficiency. Outside China, solar PV manufacturers have often been loss-making as companies struggled to compete with China, though conditions improved modestly in 2024 thanks to tariffs and other industrial support measures.

Figure 7.20 Difference in production cost between the European Union and China for selected clean energy technologies by contributing factor, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: CAPEX = capital expenditure. Based on the levelised cost of production, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. Batteries refer to battery cells using lithium nickel cobalt manganese oxide (NMC) 811 as cathode active material and graphite as anode active material. Labour cost for battery production in the European Union is calculated as the production weighted average of labour costs in 2024. Heat pumps refer to air-water units. Production efficiency is directly proportional to automation of production processes and inversely proportional to scrap rates and manufacturing lines downtime.

The reasons for China's competitive advantage over Europe differ markedly across clean technologies, so there is no one-size-fits-all solution to bridge the competitiveness gap.

In the wind sector, profitability in China remains under pressure, with ROIC still below WACC  amid  strong competition and oversupply. Elsewhere, wind manufacturing showed signs of recovery in 2024. For batteries, China's industry appears at first glance to struggle to earn its cost of capital, but performance has become  more  diverse:  some  firms  recorded  sharp  declines  in  revenue,  while others posted strong gains and high profitability, contributing to modest overall

improvement. Outside China, high WACC and deteriorating ROIC, reflecting a surge in investment and factories still ramping up, means that value continues to be eroded from an investor perspective.

Taken together, financial performance for clean energy technology manufacturing in China weakened between 2019 and 2024 as competitive pressures intensified, while conditions  outside  China  remained  difficult  (Figure  7.21). The  main exceptions are wind manufacturing outside China, which is now generating profits, integrated  solar  operations,  and  some  top-performing  battery  makers.  With investment  incentives  outside  China  constrained  by  higher  levelised  costs  of production, much of the capital currently being deployed appears to be motivated by long-term strategic considerations, such as securing future market share or technological  leadership,  or  enabled  by  government  policy  support  rather  than near-term returns.

Figure 7.21 Return on invested capital and weighted average cost of capital in China and the rest of the world for solar PV value chains, wind and batteries, 2019-2024

<!-- image -->

WACC

ROIC

IEA. CC BY 4.0

Notes: WACC = weighted average cost of capital; ROIC = Return on Invested Capital. WACC and ROIC are averaged across companies using company revenues weighted by their respective share of total revenues in a particular value chain segment (e.g. polysilicon) and headquarter location.

Sources: IEA calculations based on BNEF (2025b) and S&amp;P Global (2025).

Financial performance for clean energy technology manufacturers in China has weakened with more intense competition, while conditions outside China remain difficult.

## Solar PV

The  economics  of  solar  PV  module  production  have  improved  significantly  in recent years. Between 2019 and 2024, module prices fell by over 60%, reflecting sharp  reductions  in  production  costs,  supported  by  rising  efficiencies  and economies  of  scale,  especially  in  China,  and  intense  competition  between manufacturers. Following the easing of polysilicon supply bottlenecks in 2021-22 (Hall, 2021), prices have remained relatively stable, at around USD 0.10 per Watt since late 2023.

While cell technologies have evolved over time, silicon-based versions continue to  dominate,  accounting  for  around  98%  of  global  production,  with  thin  films representing the remaining share. The result has been relatively minor shifts in the cost  structure  of  PV  modules.  For  example,  the  transition  from  Passivated Emitter and Rear Cell (PERC) - the leading silicon technology from the late-2010s -  to  Tunnel  Oxide  Passivated  Contact  (TOPCon),  which  dominates  today, involved changes in wafer thickness, higher efficiency and increased silver use, but  has  had  only  limited  changes  to  the  cost  structure  (Touloupas  &amp;  Hansen, 2024).  As  a  result,  solar  PV  is  one  of  the  most  homogeneous  clean  energy products: modules are largely commoditised, with cell efficiency per surface area the main differentiator.

In this context, cost-competitiveness is a decisive factor in decisions about where to invest in new manufacturing capacity. China is by far the lowest-cost solar PV producer, with module production costs about half those in the European Union and almost one-fifth less than in India (Figure 7.22). Several factors underpin this advantage. Energy costs account for more than 40% of the cost gap with Europe, though  their significance varies by  production  step:  polysilicon and  wafer manufacturing are highly energy-intensive, whereas cell and module assembly are less so. Labour costs also contribute to the gap, with China benefiting both from lower wages and greater robotisation. As a result, wafer and cell manufacturing capacity remains limited outside China and absent in many advanced economies.

Figure 7.22 Decomposition  of  production  cost  gap  between  China  and  selected countries and regions for solar PV modules, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: CAPEX = capital expenditure. LCOP = levelised cost of production, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. Assumes a vertically integrated supply chain. Assumes domestic production of polysilicon and intermediate components.

Sources: IEA analysis based on InfoLink (2025); BNEF (2025b); IEA (2025c); and Japan External Trade Organization (2025).

China is by far the lowest-cost producer of solar PV modules, with production costs nearly half those in the European Union, thanks to scale and lower labour, energy and CAPEX.

Economies of scale play an important role in determining the cost gap between China and other countries. Chinese manufacturing plants are on average six times larger  across  the  supply  chain  than  their  counterparts  in  advanced  economies (InfoLink, 2025) (Figure 7.23). For example, total EU module installations in 2024 amounted  to  around  60 GW  -  roughly  double  the  capacity  of  a  single  large Chinese  factory.  This  scale  not  only  reduces  unit  costs  but  also  accelerates technology learning.

Figure 7.23 Solar PV supply chain manufacturing plant sizes in China and in advanced economies, 2024

<!-- image -->

IEA. CC BY 4.0.

Source: IEA analysis based on InfoLink (2025).

Chinese  solar  PV  manufacturing  plants  are,  on  average,  six  times  larger  than  their counterparts in advanced economies, lowering unit costs and accelerating learning.

These structural advantages make it difficult for other regions to compete directly with China on cost. Yet, as noted above, the impact of these cost gaps on the overall economics of a solar PV project is only modest, especially for residential systems,  which  dilutes  the  effect  of  cost  differences  on  deployment  decisions (Figure  7.17).  For  example,  relying  solely  on  non-Chinese  modules  in  Europe would increase the total capital costs for a utility-scale project by only around 15%, and even less for residential. Nonetheless, the sharp decline in the prices of solar PV modules has accounted for nearly half of the overall fall in the LCOE of solar PV over the past decade, underpinning the surge in global installations (IRENA, 2025). Against this backdrop, China's sustained cost leadership remains a central concern for existing manufacturers and prospective market entrants alike.

Different  strategies  are  available  to  non-Chinese  solar  PV  manufacturers  to reduce cost gaps and, for governments, to foster domestic industries. These range from developing capabilities across the full supply chain to concentrating efforts on  downstream  activities,  such  as  cell  and  module  production,  while  sourcing wafers from countries with lower energy costs. For example, importing wafers from North Africa into the European Union would reduce the cost gap with China by 40% (Figure 7.24). The downstream focus has two advantages: it is less energyintensive and captures a larger share of the added value in module manufacturing.  However, it does not address security of supply risks unless upstream components are sourced from a diverse set of suppliers.

Figure 7.24 Module manufacturing costs in selected countries and regions, 2024

<!-- image -->

IEA. CC BY 4.0.

Note: The levelised cost of production is based on a comparison of facilities of the same size.

The Europe Union could reduce significantly the solar PV module cost gap with China by importing components, particularly from countries with lower energy costs.

In  the  near  term,  partnerships  with  leading  Chinese  manufacturers  could  also provide  a  route  to  build  capabilities,  particularly  through  joint  ventures  and technology transfers. This is especially relevant as next-generation technologies, such as tandem perovskite-silicon cells, advance through R&amp;D. Their commercialisation is likely  to follow  similar  bottom-up  cost  structures,  meaning that mastery of current silicon processes remains essential.

## Wind turbines

Wind turbine prices vary widely across regions. In Europe and the United States, turbines cost on average around USD 1 million per MW,  compared  with USD 280 000, or about 75% less, in China (BNEF, 2025c). This largely reflects differences  in  the  levelised  cost  of  manufacturing,  with  labour  and  component costs  accounting  for  most  of  the  cost  gap  between  China  -  the  lowest-cost producer - and higher-cost regions; but other factors also contribute to explaining this difference.

In  the  European Union  and  the  United States,  labour  accounts  for  about  onequarter  of  production  costs  for  the  most  labour-intensive  components  such  as blades. By contrast, towers - which can represent up to 20% of turbine costs are more material-intensive and therefore less affected by labour costs; steel and welding costs are the main cost factors.

Nacelles, which house the most complex components, are central to the overall cost  advantage  of  China:  producing  a  nacelle  entirely  in  the  European Union would be about 75% more expensive than in China due to higher labour costs, more  expensive  materials  and  less  integrated  supply  chains  (Figure  7.25).  In practice,  however,  many  nacelle  sub-components  are  made  in  China  and imported  for  assembly  elsewhere,  reducing  the  cost  difference  to  just  10%  in Europe when all components are imported (Figure 7.26). This pattern is global; in Brazil, for instance, a fully domestically manufactured turbine would cost about 30% more than a Chinese turbine, driven largely by higher nacelle component costs.

Beyond  differences  in  manufacturing  costs,  two  additional  factors  influence regional price disparities: turbine size and order volume. Turbines in China tend to be larger on average and are often ordered in bulk for gigawatt-scale wind parks (see Chapter 5, Box 5.3). Larger turbines reduce costs per unit of power output, while large orders support economies of scale in manufacturing. However, there are reports  that  turbine  failure  rates  in  China  are  higher  than  in  other  regions, linked to rapid prototyping and installations, pressure to maintain low prices, and limited incentives for manufacturers to prioritise reliability (Li &amp; Ho, 2024) (Totaro, 2023).

Figure 7.25 Decomposition of production cost gap between China and the European Union and Brazil for wind turbine components, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: CAPEX = capital expenditure; LCOP = levelised cost of production, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. The prices of key blade materials such as carbon fibre, fibre glass and resin are assumed to be equal across regions. All nacelle components are assumed to be domestically produced; however, nacelles manufactured in the European Union today include components sourced internationally. See notes in Figure 7.26 for more details on the components of the nacelle. Costs are weighted averages of onshore and offshore turbines according to deployment.

Sources: IEA analysis based on data from the Center for Wind Power Drives (RWTH); Reichartz et al. (2024); BNEF (2025b); Joint Research Centre (2020); and National Renewable Energy Laboratory (2019).

Wind turbine components cost substantially more to produce in the European Union and Brazil than in China, largely due to more expensive components and labour.

A closer look at nacelle costs highlights the weight of technically advanced subcomponents  such  as  gearboxes,  generators,  transformers  and  associated converters (Figure 7.26). These are among the most expensive items, reflecting both the value of materials - including rare earth elements for permanent magnets mostly used in offshore turbines and large amounts of copper for generators and transformers - and the skilled labour needed for machining and assembly. For these  sub-components,  labour  can  represent  about  35%  of  total  costs,  thus making regions with low labour costs particularly competitive. Importing certain

labour-intensive components  can  help with competitiveness, for example, producing in Europe while importing components from India could cost only 15% more than producing turbines in China, cutting 75% of the production cost gap between Europe and China. By contrast, large cast-iron parts such as the machine carrier, rotor hub and main shaft are more material- and energy-intensive, with costs driven largely by foundry operations and heat treatment.

Design choices also influence production costs. Direct-drive (DD) turbines remove the need for a gearbox but require larger, material-intensive permanent-magnet generators.  Doubly  fed  induction  generators  (DFIGs),  by  contrast,  rely  on gearboxes but do not need rare earth elements. Offshore projects are increasingly dominated  by  DD  systems,  raising  the  material  intensity  of  nacelles.  Total production costs for DD systems can be up to 40% higher than for DFIG systems.

Figure 7.26 Decomposition of production cost gap between China and the European Union for nacelles and the shares of sub-components in total turbine costs in the European Union, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes:  EU  =  European Union.  Production  costs  refer  to  the  levelised  cost  of  production.  Production  costs  of  nacelle components include the generator, gearbox (with roller bearings rather than plain bearings), converter, transformer, machine carrier, pitch system, rotor shaft, rotor hub, yaw drive and bearings. Costs for these components are modelled using the work of  the  Center for  Wind Power Drives, which uses material costs from public sources and may reflect single-day prices. Furthermore, inflation rates were applied to align data years. The shown values are weighted averages between onshore and offshore turbines based on global deployment.

Sources: IEA analysis based on data from the Center for Wind Power Drives (RWTH); Reichartz et al. (2024); Joint Research Centre (2020); National Renewable Energy Laboratory (2019); and BNEF (2025b).

Labour- and energy-intensive sub-components such as the generator, gearbox and heavy materials account for a large share of total nacelle production costs

Beyond the turbine itself, broader industrial dynamics impact competitiveness. In China, the geographic clustering of suppliers reduces transaction and transport

costs and supports economies of scale, reinforcing the country's position as the lowest-cost producer of wind turbine components.

While these differences give China a clear cost advantage in turbine manufacturing, their effect on overall project economics is more limited. Turbines represent only a portion of the capital expenditures for wind projects, and capital costs,  in  turn,  are  only  part  of  the  levelised  cost  of  electricity.  Nonetheless, reducing production costs outside China remains key to future deployment and security of supply.

## Batteries

As  in  other  clean  energy  technology  sectors,  competitiveness  in  the  battery industry  is  determined  by  a  combination  of  factors,  including  manufacturing capability, technological expertise, supply chain integration and access to skilled labour. It is also strongly influenced by  battery chemistry, which  shapes performance characteristics, material requirements and production costs. Today's EV and battery storage markets are dominated by two lithium-ion chemistries: lithium iron phosphate (LFP) and lithium nickel manganese cobalt (NMC). NMC batteries  deliver  higher  energy  density,  enabling  longer  driving  ranges,  but  at higher  cost  and  with  shorter  lifespans  -  though  still  sufficient  for  EV  use.  By contrast,  LFP  batteries  have  traditionally  been  cheaper  and  longer-lasting,  but offered lower range. Recent innovations by Chinese manufacturers have closed much of this gap: modern LFP systems now support ranges of 300 km in small battery electric vehicles and up to 750 km in large SUVs (CATL, 2025).

On  average,  LFP  batteries  were  almost  30%  cheaper  than  NMC  batteries worldwide  in  2024,  reflecting  lower  production  costs  (McKerracher,  2024).  In China,  LFP  production  costs  are  about  one-quarter  lower  than  for  NMC.  LFP batteries already account for nearly half of global EV sales and more than 90% of stationary  storage  demand.  LFP  adoption  for  stationary  uses  is  broadly  even globally, whereas in the EV market, it has been led by China, where LFP made up around three-quarters of the EV market in 2024, compared with just over 10% in Europe and even less in the United States. However, interest outside China is rising rapidly. In emerging economies such as India, Brazil and Southeast Asia, LFP already represents more than half of the electric car market. European and North American automakers are also scaling up LFP use to improve affordability, prompting Korean and Chinese battery manufacturers to announce plans for LFP production in these regions (S&amp;P Global, 2024) (CATL, 2025a).

Figure 7.27 Lithium-ion  battery  cell  production  costs  by  chemistry  in  China  and chemistry sales share by region and application, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: NMC = lithium nickel cobalt manganese oxide; LFP = lithium iron phosphate; NCA = lithium nickel cobalt aluminium oxide; EV = Electric vehicle; BESS = battery energy storage system. NMC production costs refer to NMC811. Production cost is the levelised cost of production, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. Indirect manufacturing costs include administration, retail and R&amp;D costs.  Manufacturing  inefficiencies  are  directly  proportional  to  scrap  rates  and  manufacturing  lines  downtime  and inversely proportional to automation of production processes.

Sources: IEA analysis based on data from IEA (2024b); CRU (2025); BNEF (2025b); EV Volumes (2025); China Automotive Power Battery Industry Innovation Alliance (2025); and battery companies' annual reports.

LFP batteries cost about a quarter less to make than NMC batteries in China, and already account for nearly half of global EV sales and more than 90% of stationary storage demand.

Despite  their  higher  production  costs,  NMC  batteries  will  nonetheless  remain important,  especially  for  applications  demanding  greater  range  than  LFP  can deliver as yet. Research is under way to raise manganese content to reduce the need for more expensive nickel and cobalt as a way of lowering overall material costs, which could narrow the price gap with LFP (GM, 2025). For this reason, expertise in both chemistries remains essential.

China  currently  holds  a  near  monopoly  over  LFP,  with  only  a  handful  of manufacturers able to produce or access the latest generation of this technology, even  within  China.  Given  its  strategic  value,  China  has  introduced  export restrictions on LFP technologies and related equipment that, if fully implemented, would  narrow  options  for  procurement  abroad  (China,  Ministry  of  Commerce, 2025). Investment in capacity elsewhere - including by Korean firms and through Chinese companies with factories overseas - will be needed to strengthen supply chain security and resilience.

Beyond chemistry, competitiveness in the battery industry depends on manufacturing  know-how,  technological  expertise,  availability  of  specialised

labour and the efficiency of supply chains. To date, nearly all EV batteries have been produced by companies headquartered in Asia - particularly in China, Korea and  Japan  leaving both supply chains and skilled workforces heavily concentrated  in  the  region  (IEA,  2025e).  In  2024,  China  alone  accounted  for around 80% of global production, while the European Union and the United States together held about 15%. Although Europe and North America remain far behind China, they are making clear progress in ramping up capacity, largely thanks to heavy  investment  from  major  Korean,  Chinese  and  Japanese  manufacturers (see Chapters 4 and 5).

Battery manufacturing costs remain considerably lower in China than anywhere else. The LCOP for NMC battery cells is around one-fifth higher in Korea than in China,  and  about  50%  higher  in  the  European Union  and  the  United States (excluding  tax  credits).  Much  of  those  cost  gaps  stem  from  differences  in manufacturing efficiency and automation levels. Chinese facilities typically operate with  more  advanced manufacturing  equipment, higher  throughput  per  line  and fewer unplanned stoppages, supported by access to a large pool of skilled labour. This results in both higher productivity and lower staffing needs, reinforcing their competitive edge.

Figure 7.28 Decomposition  of  the  production  cost  gap  for  lithium  nickel  cobalt manganese oxide battery cells between China and selected countries and regions, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: LCOP = levelised cost of production. Based on the LCOP, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. The 'Manufacturing efficiency and automation' cost category is directly proportional to scrap rates and production-line downtime and inversely proportional to automation levels of production processes. Labour in the European Union is calculated as the production weighted average of labour costs in 2024, when the majority of production was concentrated in Poland and Hungary. Indirect manufacturing costs include administration, retail and R&amp;D costs. Energy prices are for the overall industrial sector.

Sources: IEA analysis based on data from IEA (2024b); CRU (2025); BNEF (2025b) and battery companies' annual reports.

Battery manufacturing costs remain considerably lower in China than anywhere else, in large part due to differences in manufacturing efficiency and automation levels.

China's  cost  leadership  in  battery  manufacturing  shapes  the  entire  EV  supply chain, as batteries account for over a quarter of total production costs (including indirect manufacturing costs). While lower labour costs and lower costs for nonpowertrain components (such as the interior, body-in-white and chassis) explain a significant share of the cost advantage of Chinese-made battery electric cars over EU-made equivalents, lower battery prices still account for over one-third of the  estimated  direct  cost  gap.   Other  electric  powertrain  components  are  also 9 cheaper to  produce  in  China,  but  contribute  only  around  5%  to  this  difference (IEA, 2025a).  This  underscores  the  importance  for  other  regions  of  securing access to competitively priced batteries and developing domestic manufacturing capabilities if they are to remain competitive in the EV market.

Figure 7.29 Decomposition  of  the  direct  manufacturing  cost  gap  for  a  small  SUV between the European Union and China, by powertrain, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: LCOP = levelised cost of production; BEV = battery electric vehicle; ICEV = internal combustion engine vehicle; SUV = sport utility vehicle. Only direct manufacturing costs are shown in the figure: overheads like R&amp;D, selling, general and administrative expenses, and profit margins are excluded from the figure scope. Germany is considered as a proxy for the European Union. In both analysed regions, BEV assumes a 150-kW electric drivetrain with a 75-kWh battery and ICEV an 80-kW engine. Other components include the chassis, body-in-white, exterior, interior and electronic equipment. Labour and energy costs relate to the car assembly manufacturing step only.

Source: IEA analysis based on IEA (2025a).

China's  strength  in  battery  manufacturing  carries  through  the  vehicle  supply  chain,  with batteries accounting for over one-third of the BEV direct cost gap with the European Union.

9 Direct manufacturing costs exclude overheads (or indirect manufacturing costs) such as R&amp;D, selling and administrative expenses, manufacturer profit margins and dealer markups.

Foreign investment remains one of the fastest ways to accelerate domestic battery manufacturing in regions with limited expertise. In particular, Chinese, Korean and Japanese firms bring not only capital but also technical knowledge, training and established supply chains. Such partnerships - whether through joint ventures or direct  investment  -  can  help  improve  local  workforce  skills,  reduce  production costs through efficiency gains and secure access to high-quality and lower-cost components.

## Heat pumps

Heat pump  production costs vary widely by region, shaped  by general manufacturing conditions (notably skills, infrastructure and labour) and marketspecific factors such as product type (typically air-to-air or air-to-water), unit size, compressor  choice,  performance  standards  and  regulations.  Final  assembly requires  little  energy  or  raw  materials,  so  components  dominate  overall  costs, accounting for 60-85% of production costs. Compressors are the most complex part, representing about 30% of production costs alone. This gives countries with strong component industries and access to materials a clear competitive edge and explains  why,  as  for  other  technologies,  China  is  the  largest  manufacturer, accounting for over 35% of global heat pump output.

Rotary compressors, commonly used in small heat pump units, are overwhelmingly manufactured in China, which supplies about 90% of global output through vertically integrated supply chains closely linked to heat pump and airconditioner (AC) producers. By contrast, production of scroll compressors, used mainly in larger, more efficient, heat pump units, is more geographically diverse: about one-third come from China, 30% from other Asian countries, over 30% from the  United States  and  about  5%  from  Europe.  Scroll  compressors  offer  higher efficiency and lower noise performance but cost more; combined with more limited demand for larger units, this results in a smaller overall market compared with rotary  compressors.  China's  outsize  role  in  rotary  compressor  manufacturing, together  with  its  large  domestic  market  for  ACs  and  air-to-air  heat  pumps, reinforces its strong competitive position in this segment.

Air-to-air heat pumps also share core components, supply chains and production processes with ACs. This allows AC-like manufacturing scale to reduce costs for heat pumps; shared R&amp;D, as well as testing and distribution spillovers, further reinforce competitiveness in countries with a strong AC base.

Manufacturers located in China and Japan are the main suppliers of air-to-air heat pumps.  The  strength  of  Japanese  companies  reflects  long-standing  expertise across a  range  of  companies  such  as  Daikin,  Panasonic,  Fujitsu  General  and Mitsubishi Electric, supported  by  a  domestic  market  where  over  90%  of households own reversible ACs (which can produce either hot or cold air). China,

however, leads by scale, with production an order of magnitude higher than in Japan. Several major Chinese compressor manufacturers are owned by or closely integrated with leading air-conditioner/HVAC (heating, ventilation and air conditioning)  firms  -  a  structure  that  can  ensure  tight  co-ordination  across  the supply chain. Other compressor suppliers that remain independent are supplying components to multiple original equipment manufacturers (OEMs) that can benefit from a highly localised supply chain. Beyond compressors, China's high-volume production  makes  control  systems,  chips,  motors,  casings,  and  other  shared components  far  cheaper  to  source.  High  production  volumes  and  integrated supply  chains  reduce  per-unit  costs  and  create  spillover  benefits,  such  as streamlined logistics and faster innovation cycles.

Taken  together,  these  structural  factors  translate  into  a  large  competitive advantage for China. Air-to-air models cost 40% less to produce in China than in Japan (Figure 7.30). Over 40% of this cost gap comes from economies of scale and  vertical integration in compressor  manufacturing, 30%  from  cheaper components and raw materials, and over 20% from lower labour and compliance costs. In practice, not all these differences make it to the final product; Japanese firms  have  expanded  production  in  China,  while  maintaining  Japan-focused models at home. This dual footprint allows them to combine domestic expertise with China's economies of scale.

Figure 7.30 Decomposition of the production cost gap for heat pumps between China and selected countries and regions, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes:  LCOP = levelised cost  of production,  which corresponds  to  the  price  that  would  have  to  be  charged  per  unit  of production to achieve a net present value of zero for a given investment. Assumes a typical air-to-air heat pump with capacity of 4 kW, a typical air-to-water heat pump with capacity of 12 kW and a utilisation factor of 85% for both. 'Others' includes costs associated with compliance with local standards such as certification, aesthetics and noise.

China  is  the  lowest-cost  producer  of  both  air-to-air  and  air-to-water  heat  pumps,  thanks mainly to economies of scale and access to low-cost components.

The  cost  gap  for  air-to-water  units  between  China  and  the  European Union  is narrower than for air-to-air, but European units still cost around 60% more. Europe and  China  are  the  largest  markets  for  air-to-water  heat  pumps,  with  China supplying over 15% of European demand, making the China-Europe corridor the biggest global trade flow for heat pumps. Most of the remaining European demand is  met  domestically.  Europe  leads  in  high-efficiency  designs  and  innovation, particularly for large-scale units, but is less competitive in the rest of the market.

Components  represent  about  half  of  the  total  gap  in  production  costs,  with Europe's reliance on scroll compressors - which are larger, more complex and less  geographically  concentrated  than  rotary  compressors  -  limiting  China's competitive advantage. Most of the remaining cost gap stems from cheaper labour costs and lower retail margins.

Closing  this  gap  will  be  difficult.  However,  the  strong  engineering  base  of European compressor and component manufacturers, combined with automation, higher productivity, industrial clustering, joint ventures and technology collaboration offer potential pathways to reduce costs. Importantly, components drive the LCOP but have a very limited impact on retail prices - particularly for airto-water units - with installation and distribution costs, as well as profit margins, playing a bigger role in final costs. In addition, demand is strongly influenced by prevailing electricity-to-gas price ratios, which determine the potential savings that can be made by switching from a gas boiler to a heat pump.

## Electrolysers

Broadly speaking, electrolysers operate in a similar way to batteries, using stacks of connected cells in which water is split into hydrogen and oxygen. Each stack contains an anode and a cathode separated by an electrolyte that carries ions. A porous layer separates the electrodes, water and gases, while bipolar plates link the  cells,  spread  gases  evenly,  manage  heat  and  provide  structural  support. Catalysts accelerate the electrode reactions. Several designs exist depending on materials and configurations, with alkaline electrolysers the most established and widely deployed today (IEA, 2025d).

In alkaline electrolysis, the diaphragm that separates the electrodes is the single largest cost item, representing about 40% of stack manufacturing costs. Along with nickel-based electrodes and the membrane electrode assembly, these core elements  together  typically  make  up  nearly  two-thirds  of  the  total  cost.  The remaining share is linked to support layers and assembly. Other costs include energy use (around 17% in Europe), plant costs (14%) and labour (about 3%, depending  on  automation  and  scale).  Other  non-stack  costs  such  as  power

electronics, gas conditioning, water cooling and circulation, can be almost 40% higher  than  the  stack  costs.  The  rest  of  the  CAPEX  are  non-equipment  costs (Figure 7.17).

China, Europe and the United States are the leading manufacturers of electrolysers today, accounting  for nearly 60%,  16%  and  10%  of  global manufacturing capacity, respectively, in 2024. China's manufacturing costs are almost 60% lower on average than in advanced economies, largely due to access to cheaper materials in core components such as catalysts, economies of scale and optimised supply chains for balance-of-stack items such as seals, frames, separators and gaskets (Figure 7.31).

Figure 7.31 Decomposition of the production cost gap for electrolysers between China and advanced economies, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: LCOP = levelised cost of production; CAPEX = capital expenditure. Based on the LCOP of an alkaline electrolyser, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for  a  given  investment.  Cost  differences  in  components  reflect  different  stack  design  choices.  Assumes  a  1  GW/year manufacturing  plant  and  a  utilisation  factor  of  85%.  The  error  bars  denote  the  variation  in  costs  across  the  advanced economies.

Sources: IEA analysis based on industry announcements Krishnan, et al. (2023); Gerloff (2021); and ExoPeak analysis.

Electrolyser  manufacturing  costs  are  60%  lower  in  China  than  in  advanced  economies, despite lower unit efficiencies, mainly thanks to cheaper components.

In  practice,  there  is  a  trade-off  between  cost,  efficiency  and  durability,  making straight production cost comparisons somewhat misleading. Alkaline electrolysers can be designed with more expensive materials 10  to deliver higher efficiency and

10 Alkaline electrolysers must withstand highly caustic solutions, requiring more expensive zirconia diaphragms and nickelor zinc-based materials.

last longer. Using cheaper alternatives reduces performance: a cost differential of around USD 200/kW corresponds to about three percentage points of efficiency 11 - close to the current gap between Chinese electrolysers and those manufactured elsewhere.  Despite  higher  upfront  costs,  electrolysers  produced  in  advanced economies can therefore be competitive - and in some cases have an advantage - with those from China, not least because electricity prices are a key factor for the levelised cost of hydrogen production. However, as China continues to close the  efficiency  gap,  its  broader  cost  advantage  is  expected  to  reassert  itself, particularly for non-stack components.

Competitiveness is also shaped by market maturity. In 2024, global electrolyser manufacturing capacity stood at 38 GW per year, while actual output was only about 4 GW.  This  severe  underutilisation inflates manufacturing costs: in advanced  economies,  operating  at  20%  utilisation  adds  roughly  USD 160/kW, compared with about USD 70/kW in China due to lower plant CAPEX. Plant size further reinforces the differential. The average Chinese facility is almost 890 MW per  year,  compared  with  320 MW  in  Europe,  where  several  plants  are  below 50 MW.  These  smaller  facilities  can  face  CAPEX  penalties  of  up  to  50%,  but because CAPEX accounts for only a modest share of overall costs, the penalty translates  to  only  about  USD 15/kW  -  albeit  still  a  meaningful  disadvantage  if utilisation remains limited.

Electrolysers remain at an earlier stage of deployment compared with the other clean energy technologies discussed above, leaving greater room for both cost reductions and performance improvements. While China has a clear cost edge today, levelised costs are broadly similar across regions once efficiency is factored in. The  European Union  and  the  United States  maintain  robust  research programmes  focused  on  reducing  stack  costs, improving efficiency and extending  lifetimes,  suggesting  that  global  competitiveness  in  electrolyser manufacturing remains open to shifts as the industry matures (Clean Hydrogen, 2024) (US Department of Energy, 2024).

11 Assuming an electricity price of USD 60/MWh, 5000 full load hours per year and a system lifetime of 25 years.

## References

Agora Industry. (2023). 15 Insights on the Global Steel Transformation . Retrieved from https://www.agora-industry.org/fileadmin/Projekte/2021/2021-06\_IND\_INT\_GlobalSteel/A-EW\_298\_GlobalSteel\_Insights\_WEB.pdf

Agora Industry. (2025). The role of green iron trade in accelerating competitive steel transformation. Retrieved from https://www.agora-industry.org/publications/the-role-ofgreen-iron-trade-in-accelerating-steel-transformation

Argus. (2024a). Dow to close German cracker, other assets by 4Q 2027 . Retrieved from https://www.argusmedia.com/en/news-and-insights/latest-market-news/2707474-dowto-close-german-cracker-other-assets-by-4q-2027

Argus. (2024b). Sabic to begin Geleen cracker closure this week. Retrieved from https://www.argusmedia.com/en/news-and-insights/latest-market-news/2556639-sabicto-begin-geleen-cracker-closure-this-week

Argus. (2025). Argus TTF . Retrieved from https://www.argusmedia.com/en/methodology/keycommodity-prices/argus-ttf

Bataille, C., Pai, S., Stiebert, S., Mishra, M., Patil, G., &amp; Francis, L. (2025). Meeting climate targets will lead to major steel production technology shifts and preserve jobs. Retrieved from https://dx.doi.org/10.2139/ssrn.5278075

Bloomberg. (2023). Europe's Petrochemical Industry Is Heading for Death Row. Retrieved from https://www.bloomberg.com/opinion/articles/2023-11-20/europe-s-petrochemicalindustry-is-heading-for-death-row

BNEF. (2025a). 3Q 2025 Global PV Market Outlook Prospects of a 1TW Solar Market Fading. Retrieved from https://www.bnef.com/insights/37617/view

BNEF. (2025b). Data service . Retrieved from https://about.bnef.com/

BNEF. (2025c). Wind Turbine Price Index 1H 2025: Still on the Rise. BNEF.

Brown, D. (2025). Fortescue inks green iron partnership with China Baowu. Australian Resources &amp; Investment . Retrieved from https://www.australianresourcesandinvestment.com.au/2025/01/10/fortescue-inksgreen-iron-partnership-with-china-baowu/

CATL. (2025). CATL Launches Shenxing Pro, Europe's Optimal Solution for E-Mobility at IAA Mobility 2025 . Retrieved from https://www.catl.com/en/news/6527.html

CEPII. (2025). BACI . Retrieved from https://www.cepii.fr/CEPII/en/bdd\_modele/bdd\_modele\_item.asp?id=37

China Automotive Power Battery Industry Innovation Alliance. (2025). Monthly Data - Power Battery Monthly Information in December 2024 . Retrieved from https://mp.weixin.qq.com/s/W7181pLemWq1eThd4o2vew

China, Ministry of Commerce. (2025). Announcement No.18 of 2025 of The Ministry of Commerce and The General Administration of Customs of The People's Republic of China Announcing the decision to implement export control on some medium and heavy rare earth related items . Retrieved from https://english.mofcom.gov.cn/Policies/AnnouncementsOrders/art/2025/art\_0dd87cbee 7b045bf93fabe6ab2faceee.html

Clean Hydrogen. (2024). Programme Review Rport 2024 . Retrieved from https://www.cleanhydrogen.europa.eu/document/download/6b6584d0-f259-436a-8fe8-3a6bf9d0761c\_en?filename=20242823\_PDF\_EGAA24001ENN\_002.pdf

Climate Group. (2025). SteelZero . Retrieved from https://www.theclimategroup.org/steelzeromembers

CRU. (2025). Multi Commodity Asset Data . Retrieved from https://www.crugroup.com/en/

European Aluminium. (2025). Industry &amp; Market Data. Retrieved from https://europeanaluminium.eu/about-aluminium/aluminium-industry/

- European Commission. (2025a). FIGARO tables . Retrieved from https://joint-researchcentre.ec.europa.eu/projects-and-activities/trade-and-industrial-policy-analysis/inputoutput-accounts/figaro-tables\_en
- European Commission. (2025b). The Draghi report on EU competitiveness . Retrieved from https://commission.europa.eu/topics/eu-competitiveness/draghi-report\_en
- European Commission. (2025c). Eurostat: Production in industry - monthly data . Retrieved from https://ec.europa.eu/eurostat/databrowser/product/page/STS\_INPR\_M

EV Volumes. (2025). Global Electric Vehicle Sales Data, Market Trends &amp; Forecasts You Can Trust . Retrieved from https://ev-volumes.com/

- Gerloff, N. (2021). Comparative Life-Cycle-Assessment analysis of three major water electrolysis technologies while applying various energy scenarios for a greener hydrogen production. Journal of Energy Storage . Retrieved from https://www.sciencedirect.com/science/article/pii/S2352152X21004874
- GM. (2025). News Release Details . Retrieved from https://investor.gm.com/newsreleases/news-release-details/gm-and-lg-energy-solution-pioneer-lmr-battery-celltechnology/

Green Hydrogen Innovation Centre. (2024). Africa's first green hydrogen-based ironworks signs offtake deal as it receives electrolysers . Retrieved from https://isaghic.org/africas-first-green-hydrogen-based-ironworks-signs-offtake-deal-as-it-receiveselectrolysers

Growth Lab. (2025). Country &amp; Product Complexity Rankings . Retrieved from https://atlas.hks.harvard.edu/rankings

Hall, M. (2021). Polysilicon shortage will continue through 2021. PV Magazine . Retrieved from https://www.pv-magazine.com/2021/07/22/polysilicon-shortage-will-continue-through2021/

- Hydrogen Europe. (2025). Meranti Green Steel eyes 2026 FID for 2.5 mtpa green iron project in Oman . Retrieved from https://hydrogeneurope.eu/meranti-green-steel-eyes-2026-fidfor-2-5-mtpa-green-iron-project-in-oman/
- ICIS. (2024). Exxon Mobil to close Gravenchon, France cracker and related derivative units in
- 2024. ICIS . Retrieved from

https://www.icis.com/explore/resources/news/2024/04/11/10989084/exxonmobil-toclose-gravenchon-france-cracker-and-related-derivative-units-in-2024/

- IDDI. (2025). The Industrial Deep Decarbonization Initiative . Retrieved from https://decarbonization.unido.org/projects/iddi/
- IEA. (2024a). A Global Review of Patent Data for Smart Grid Technologies. Retrieved from https://www.iea.org/reports/a-global-review-of-patent-data-for-smart-grid-technologies

- IEA. (2024b). Energy Technology Perspectives 2024. Retrieved from https://www.iea.org/reports/energy-technology-perspectives-2024
- IEA. (2025a). What Next for the Global Car Industry . Retrieved from https://www.iea.org/reports/what-next-for-the-global-car-industry

IEA. (2025b). Cost of Capital Observatory . Retrieved from https://www.iea.org/reports/cost-ofcapital-observatory

- IEA. (2025c). Energy Prices . Retrieved from https://www.iea.org/data-and-statistics/dataproduct/energy-prices

IEA. (2025d).

Global Hydrogen Review 2025.

Retrieved from https://www.iea.org/reports/global-hydrogen-review-2025

- IEA. (2025e). The battery industry has entered a new phase . Retrieved from https://www.iea.org/commentaries/the-battery-industry-has-entered-a-new-phase

InfoLink. (2025). InfoLink Consulting . Retrieved from https://www.infolink-group.com/

International Aluminium Institute. (2025). Primary Aluminium Smelting Power Consumption. Retrieved from https://international-aluminium.org/statistics/primary-aluminiumsmelting-power-consumption/C

International Labour Organization. (2025). Application of International Labour Standards 2025.

IRENA. (2025). Renewable power generation costs in 2024.

- Japan External Trade Organization. (2025). Japan External Trade Organization . Retrieved from Japan External Trade Organization: https://www.jetro.go.jp/world/search/cost.html
- Joint Research Centre. (2020). Raw materials demand for wind and solar PV technologies in the transition towards a decarbonised energy system. European Union. Retrieved from https://publications.jrc.ec.europa.eu/repository/bitstream/JRC119941/rms\_for\_wind\_and \_solar\_published\_v2.pdf
- Krishnan, S., Koning, V., De Groot, M. T., De Groot, A., Mendoza, P. G., Junginger, M., &amp; Kramer, G. J. (2023). Present and future cost of alkaline and PEM electrolyser stacks. International Journal of Hydrogen Energy . Retrieved from

https://www.sciencedirect.com/science/article/pii/S0360319923022590

- LESS. (2025). LESS AISBL Awards First Certifications to Six Companies - A Step Toward Decarbonised Steel . Retrieved from https://lowemissionsteelstandard.org/details/LESSAISBL-Awards-First-Certifications-to-Six-Companies
- Li, J., &amp; Ho, M. (2024). End-year China wind power installation rush reduces electric system reliability. Energy Economics . Retrieved from https://www.sciencedirect.com/science/article/pii/S0140988324002159?
- McKerracher, C. (2024). China's Batteries Are Now Cheap Enough to Power Huge Shifts. Bloomberg . Retrieved from https://www.bloomberg.com/news/newsletters/2024-0709/china-s-batteries-are-now-cheap-enough-to-power-huge-shifts

National Renewable Energy Laboratory. (2019). A detailed Wind Turbine Blade Cost Model. Retrieved from https://docs.nrel.gov/docs/fy19osti/73585.pdf

- New Energy and Industrial Technology Development Organization. (2024). Overview of the Green Innovation Fund Projects . Retrieved from https://greeninnovation.nedo.go.jp/en/about/

OECD. (2019). Measuring distortions in international markets: The aluminium value chain. Retrieved from https://www.oecd.org/content/dam/oecd/en/publications/reports/2019/01 /measuring-distortions-in-international-markets-the-aluminium-value-chain\_058cb425/c82911ab-en.pdf

OECD. (2022a). An Industrial Policy Framework for OECD Countries . Retrieved from https://www.oecd.org/content/dam/oecd/en/publications/reports/2022/05/an-industrialpolicy-framework-for-oecd-countries\_233e3061/0002217c-en.pdf

- OECD. (2022b). Quantifying industrial strategies. Retrieved from https://www.oecd.org/en/publications/quantifying-industrial-strategies-quis\_ae351abf-en.html

OECD (2024a). The Role of Incentives in Investment Promotion . Retrieved from https://www.oecd.org/content/dam/oecd/en/publications/reports/2024/12/the-role-ofincentives-in-investment-promotion\_f27f6ff4/e3338264-en.pdf

OECD. (2024b). Quantifying the role of state enterprises in industrial subsidies.

OECD. (2024c) Retrieved from OECD Inventory of Support Measures for Fossil Fuels 2024: https://www.oecd.org/en/publications/oecd-inventory-of-support-measures-for-fossilfuels-2024\_a2f063fe-en.html

Oxford Economics Limited. (2025). Global Industry Service . Retrieved from https://www.oxfordeconomics.com/service/subscription-services/industries/globalindustry-service/

Reichartz et al. (2024). Introducing a partial bottom-up model for onshore wind turbine CAPEX estimation.

Responsible Steel. (2024). U. S. Steel earns world's first ever certification for ResponsibleSteel Certified Steel at Big River Steel . Retrieved from https://www.responsiblesteel.org/news/u-s-steel-earns-worlds-first-ever-certification-for- responsiblesteel-certified-steel-at-big-river-steel

Reuters. (2025a). China polysilicon firms plan $7 billion fund to shut a third of industry capacity. Reuters . Retrieved from https://www.reuters.com/sustainability/climateenergy/china-polysilicon-firms-plan-7-billion-fund-shut-third-industry-capacity-2025-0731/

Reuters. (2025b). China solar group, regulator propose tendering reforms to boost prices. Retrieved from https://www.reuters.com/business/energy/china-solar-group-regulatorpropose-tendering-reforms-boost-prices-2024-09-02/

Reuters. (2025c). China's solar giants quietly shed a third of their workforces last year. Retrieved from https://www.reuters.com/business/world-at-work/chinas-solar-giantsquietly-shed-third-their-workforces-last-year-2025-08-01/

Rio Tinto. (2024). Rio Tinto signs Australia's biggest renewable power deal as it works to repower its Gladstone operations. Retrieved from https://www.riotinto.com/en/news/releases/2024/rio-tinto-signs-australias-biggest-

renewable-power-deal-as-it-works-to-repower-its-gladstone-operations

RMI. (2024). Green Iron Corridors: Transforming Steel Supply Chains for a Sustainable Future . Retrieved from https://rmi.org/wpcontent/uploads/dlm\_uploads/2024/09/green\_iron\_corridors\_steel\_supply\_chain\_report .pdf

| S&P Global. (2024). BriefCASE: South Korean companies eye low-cost LFP battery market . Retrieved from https://www.spglobal.com/mobility/en/research-analysis/briefcase-south- korean-companies-eye-low-cost-lfp-battery-mkt.html                           |
|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| S&P Global. (2025). S&P Capital IQ . Retrieved from https://www.spglobal.com/market- intelligence/en/solutions/products/sp-capital-iq-pro                                                                                                                   |
| SSAB. (2025). SSAB achieves IEA threshold for near-zero CO 2 emissions steel . Retrieved from https://www.ssab.com/en/news/2025/09/ssab-achieves-iea-threshold-for-nearzero- co2e-emissions-steel                                                           |
| Stadler, K. R.-J. (2025). Exiobase 3 . Retrieved from https://zenodo.org/records/14614930                                                                                                                                                                   |
| Totaro, P. (2023). China's wind turbines are bigger than ever - but they're no more financeable in the West. ReCharge , https://www.rechargenews.com/wind/chinas-wind- turbines-are-bigger-than-ever-but-theyre-no-more-financeable-in-the-west/2-1-1403767 |
| Touloupas, G., & Hansen, B. (2024). From PERC to TOPCon: Navigating the evolution of solar technology. PV Tech . Retrieved from https://www.pv-tech.org/cea-on-perc-and- topcon-solar-technology/                                                           |
| Tullo, A. (2024). Eni to shutter plants in Italy. C&EN . Retrieved from https://cen.acs.org/business/petrochemicals/Eni-shutter-plants-Italy/102/web/2024/10                                                                                                |
| United Nations Trade and Development. (2025). Retrieved from Data Hub: https://unctadstat.unctad.org/EN/RcaRadar.html                                                                                                                                       |
| US Department of Energy. (2024). HFTO Hydrogen Production Overview . Retrieved from https://www.hydrogen.energy.gov/docs/hydrogenprogramlibraries/pdfs/review24/p000_ peterson_2024_obf4cdd3d-5f59-4fe7-88f9-bca9b4de74c6.pdf?sfvrsn=aab8e82_4              |
| US Energy Information Administration. (2025). Petroleum & Other Liquids . Retrieved from https://www.eia.gov/dnav/pet/hist/LeafHandler.ashx?n=pet&s=m_epllea_eex_nus- z00_2&f=a                                                                             |
| World Bank. (2017). Industry Competitiveness and Jobs . Retrieved from https://documents1.worldbank.org/curated/en/171501476992732097/pdf/109333-WP- REVISED-PUBLIC.pdf                                                                                     |
| https://initiatives.weforum.org/first-movers-coalition/steel                                                                                                                                                                                                |
| World Economic Forum. (2025). First Movers Coalition - Steel . Retrieved from                                                                                                                                                                               |
| World Steel Association. (2025). World Steel in Figures 2025 . Retrieved from https://worldsteel.org/data/world-steel-in-figures/world-steel-in-figures-2025/                                                                                               |

## Chapter 8. Strategic considerations for clean energy technology supply chains

## Highlights

-  Securing clean energy technology supply chains depends on minimising the potential economic and social risks resulting from a disruption. These can be significant:  we  estimate  that  each  month  of  an  interruption  in  battery  supply chain  exports  from  the  largest  supplier  would  lead  to  output  loss  worth USD 17 billion  from  electric  car  plants  elsewhere,  with  almost  two-thirds  of these losses in the European Union.
-  Enhancing supply chain security can go hand in hand with improving industrial competitiveness. These objectives are deeply intertwined and have profound implications  for  other  policy  goals  beyond  energy.  Supply  chain  security improves with diversification, which can be supported by increasing domestic production in more countries. But this comes at a cost, especially if the domestic industry struggles to become competitive. There can be trade-offs: a narrow focus  on  improving  cost  advantage  by  sourcing  components  as  cheaply  as possible  risks  leaving  the  industry  more  vulnerable  to  upstream  supply disruptions.
-  Improving the competitiveness of domestic manufacturing can help maximise the economic returns and create other benefits, such as for innovation. The economic opportunity is increasing: the combined global market value for key technologies grows in all IEA scenarios, reaching almost USD 3 trillion by 2035 in the Stated Policies Scenario (STEPS), up from nearly USD 1.2 trillion today.
-  Working  towards  these  policy  objectives  is  complex,  as  such  technologies encompass  a  broad  set  of  components  and  materials,  and  require  diverse competencies and processes. For most countries, it is not possible to compete in  all  steps  of  a  technology  supply  chain,  let  alone  in  all  supply  chains. Governments  will  therefore  need  to  be  mindful  of  respective  strengths  and weaknesses when designing industrial strategies and prioritising action.
-  Strategic international partnerships - based on trade or industrial agreements, and including foreign direct investment - are central pillars of a co-ordinated strategy  to  advance  on  both  policy  objectives.  Policy  measures  that  foster economies of scale, support innovation and address energy prices also provide opportunities for governments to boost competitiveness.

## Competitiveness and security objectives are intertwined

Ensuring  the  competitiveness  and  enhancing  the  security  of  clean  energy technology supply chains are distinct but not wholly independent policy objectives. Supply chain security is first and foremost about minimising the potential economic damage that could result from a supply chain interruption. Ensuring competitiveness is a matter of maximising the domestic economic returns that could arise from developing and operating clean energy technology manufacturing facilities and reaping the associated innovation benefits.

For  clean  energy  technologies,  working  toward  both  of  these  policy  objectives simultaneously is a complex undertaking. Clean energy technologies encompass a broad set of component technologies which require a wide range of industrial competences, from energyand capital-intensive processes, to precision automated chemical processes or advanced mechanical processing steps. For most  countries,  it  would  be  very  difficult  and  hardly  desirable  to  develop  and maintain  international  competitiveness  for  all  clean  energy  technology  supply chains, or for all steps in a given supply chain.

As in most high-tech sectors, specialisation is often a winning strategy, and so taking into account  comparative  advantages  is  important when  designing industrial strategies. Similarly, ensuring appropriate levels of security of supply for clean energy supply chains can require significant government action to diversify highly concentrated supply chains. Policies aimed at either increasing security of supply or improving the competitiveness of industries are likely to come at a cost, at least in the short term.

Ensuring  competitiveness  and  enhancing  security  of  clean  energy  technology supply chains can, in some instances, go hand in hand. For example, the security of supply chains can be improved by increasing the diversity of supply, so that any reduction in access to one particular source of supply could be compensated by alternative sources. For clean energy technology supply chains, increasing the share  of  domestic  production  can  be  a  viable  pathway  to  diversifying  supply, whereby  a  focus  on  the  development  of  a  competitive  domestic  industry  can reduce the cost implications of increased domestic production. A diverse supply chain can prove to be an advantage and improve the competitiveness of domestic industries in case of supply chain disruptions.

Efforts to ensure competitiveness and enhance security of supply are, however, sometimes in tension with one another. Specialising in the final step of the supply chain is often a strategy to enter international markets competitively, since it offers more product diversification  options  than  upstream  products,  which  tend  to  be

more commodified.  However,  a  narrow  focus  on  uniquely  reducing  production costs by sourcing upstream components as cheaply as possible, and downplaying technology  performance  and  quality,  can  leave  an  industry  highly  exposed  to disruptions from a small number of low-cost suppliers. For example, producing solar modules by purchasing solar cells and wafers exclusively from the lowestcost producer country (The People's Republic of China, hereafter, 'China') may result in competitively priced modules, but does not reduce supply chain risks.

Given the close connection between these two policy objectives, some considerations are shared between the two, while others are best considered in isolation. To help governments navigate the complexities involved in selecting or prioritising which clean energy technology supply chain steps to focus on for their security  or competitiveness  goals,  we  provide  in  this  section  a  series  of considerations.  While  these  considerations  are  geared  towards  clean  energy technologies,  many  of  these  aspects  are  also  relevant  for  other  established industries (specific considerations for energy-intensive industries are provided in Box 8.1).

## Figure 8.1  Strategic considerations for enhancing security of supply and competitiveness

<!-- image -->

IEA. CC BY 4.0.

Efforts to enhance security of supply and the competitiveness of clean energy technology manufacturing need to be co-ordinated to maximise impact.

The dynamic nature of clean energy technology supply chains and technologies means that market conditions can change rapidly, and potential opportunities and risks may change over time. It is therefore important to include, from the outset of any policy targeting these objectives, a periodic review to assess the effectiveness of  the  policies  in  place  and  their  suitability  to  current  market  conditions.  Any measures  put  in  place  can  be  assessed  with  regards  to  competitiveness  and security of supply simultaneously, to understand how synergies and trade-offs are playing out. The following set of considerations could be made while assessing progress:

-  Are the components used in the supply chain being sourced from a wider set of supplier countries and/or companies?
-  Have domestic manufacturers increased their local, or global market share?
-  Has innovation activity (measurable in number of patents, private R&amp;D spending, or number of employed researchers) in the given industry increased?
-  Have local prices for a given technology increased or decreased compared to the global average?
-  Have price changes impacted the local demand for a given technology?
-  Are local producers better equipped to deal with potential supply disruptions?

## Box 8.1 Strategic considerations for energy-intensive industries

The  competitiveness  and  operations  of  all  energy-intensive  industries  will  be affected  by  the  energy  transition,  but  the  pace  and  scale  of  these  changes  are inevitably  uncertain.  In  this  context,  governments  looking  to  ensure  security  of supply  and  competitiveness  for  these  industries  need  both  vision  and  flexibility, adapting industrial strategies and energy policy as the market evolves. Security of supply is less of a concern for most energy-intensive industries since raw materials (e.g. iron ore, bauxite, limestone) and energy can be sourced from a large set of global suppliers. Competitiveness, on the other hand, is tightly related to energy prices,  and  the  energy  transition  is  likely  to  further  strengthen  this  link  (see Chapter 7).

A  wide  array  of  policy  measures  are  at  governments'  disposal  to  improve  local competitiveness, but many come at a cost. Trade-offs exist between the cost of support  measures  and  the  risks  associated  with  deindustrialisation,  such  as employment losses, erosion of technical expertise, and weakened security of supply for downstream industries. Governments may consider focusing first of all on 'lowregrets' actions - measures that strengthen both competitiveness and resilience under a wide range of future scenarios - and identifying strategic sectors that are vital  for  economic, defence and supply chain security. Tools may include energy

costs mitigation, trade measures, or support to mitigate production cost premiums for  low-emissions  production  routes.  Considerations  vary  according  to  different regional factors, including each country's energy prices and existing industrial base, and  interlinkages  between  energy-intensive  industries  and  other  strategic  local industries  downstream  along  supply  chains.  Different  archetype  cases  could  be identified across regions based on different combinations of those factors.

## Archetype #1: High energy price environment and leading industries

Prioritise energy efficiency: While energy-intensive industries inherently have the economic incentive to improve energy efficiency (particularly when operating in high energy price locations), any potential further improvements should be exploited to minimise  energy  costs.  Energy  efficiency  can  be  further  incentivised  through regulation, information dissemination and financial schemes (IEA, 2025c) . However, major energy efficiency investments in conventional plants may not be economically justified if they are approaching the end of their operational lifetimes.

Leverage comparative advantages: Long-standing know-how, product quality, and strong customer links will remain important strengths to maintain the competitive advantage of these industries in countries that fit into this archetype. Governments can  foster  sector-specific  innovation  and  deploy  expertise  at  national  labs  or universities to help retain or increase their competitive edge. This, however, may not be sufficient to offset long periods with significantly higher energy costs.

Build  strategic  partnerships: Public  leadership  can  help  companies  create  new cross-border supply chain connections by removing barriers, aligning incentives and co-ordinating the build-out of infrastructure. Governments could consider establishing  win-win  partnerships to  offshore the  most  energy-intensive  steps  of supply chains to regions with cheaper energy, and focus on retaining downstream jobs and more specialised semi-finishing and finishing industries (see Chapter 7).

## Archetype  #2:  Low  energy  price  environment  and  emerging  or  existing industries

Seize the opportunity: Governments can seek to develop partnerships to develop strategic energy-intensive industries to boost production for exports and growing domestic markets, to enhance infrastructure and to encourage economic development.  Countries  facing high energy  prices with leading established industries could be good candidates for partnerships. Stable policy frameworks are vital  to  attract  investment  in  new  or  emerging  industries:  policy  and  regulatory uncertainty are a major cause of high financing costs and lower investment to date in many emerging markets and developing economies (IEA, 2025b).

Strengthen  local  capacity: Partnerships  could  help  establish  domestic  material production to supply the domestic market as well as opening new export markets, reducing import dependence for the producing country and strengthening supply

chain  diversification  and  competitiveness  of  downstream  industries  in  targeted export countries. To avoid any form of extractive investment, agreements should be mutually beneficial,  so  that  the  host  country  benefits  from  local  job  and  broader economic developments. Over time, these investments can build know-how and position countries to move further up the value chain.

Focus on flexible assets: Investing in production capacity that is near-zero emission capable can be a good strategy to diversify and expand access to targeted export markets that have or will have different environmental requirements. This would also allow industrial assets to benefit from ongoing or upcoming  infrastructure developments in the future that allow for the use of alternative energy sources.

## Archetype #3: Low energy price environment and leading industries

Maintain global roles: Continue to exploit comparative advantages, while fostering a  diverse  domestic  base  to  reduce  geopolitical  risks.  Focus  on  high  quality, specialised and innovative products to build an industry that is resilient to potential changes in relative energy prices and global competition.

Secure supply chains: Where geographic concentration is high, diversify export and import partners, encourage strong domestic supply chains and explore alternative sources of raw materials.

Positioning for the energy transition: Consider investments that could serve global demand for low-emissions products and identify locations that are best suited for low-emissions  production.  Flexible  and  near-zero  capable  designs  could  offer  a compromise between retaining competitiveness in existing markets, while providing a head-start for low-emissions material markets that could grow rapidly in the future.

## Mapping the supply chain

A  useful  starting  point  is  to  map  the  entire  supply  chain  with  a  view  to  the positioning of a given country at every step of the supply chain, identifying how each step is connected to economic activities in other supply chains within the country, and understanding the key cost components for each technology. This mapping  stage  is  crucial  before  developing  policies  targeting  both  security  of supply and competitiveness.

Clean  energy  technology  supply  chains  often  comprise  an  array  of  complex components, materials and minerals. While some inputs will be common to many supply chains (e.g. copper), others will be highly specialised (e.g. a specific rare earth element). Mapping a supply chain requires careful technical assessment of each component, which in turn requires data. Data on fundamental quantities like

demand, production, manufacturing capacity and trade flows is often unavailable, incomplete or outdated. The data compiled for this and other IEA publications on energy technology supply chains constitute important contributions to improving the data landscape in this area. Nonetheless, further international collaboration on data  collection  methodologies  and  standards  could  help  facilitate  this  crucial mapping step.

Cybersecurity considerations might have implications for the assessment of risk related to certain steps of the supply chain. For this reason, distinguishing between 'smart' components - i.e. those that have the potential to compromise the digital security of the networks where they operate, such as inverters or advanced meters - and pure hardware components (e.g. solar PV modules) is particularly important.

Moreover,  clean  energy  technology  supply  chains  are  often  composed  of technologies or components that continuously evolve as the technologies advance and  so  supply  chain  mappings  are  not  static;  keeping  abreast  of  the  ongoing technological trends can help anticipate changes. Tools such as the IEA's C lean Energy  Technology  Guide (IEA,  2026a)  and  the  IEA's The  State  of  Energy Innovation annual report (IEA, 2026b) can help in this regard, but may need to be complemented  by  more  granular  assessments  adapted  to  the  technology  and regional context.

Understanding  the  production  cost  structure  of  each  technology  can  help governments to shed light on the main drivers behind supply chain security and competitiveness,  including  whether  a  technology  may  be  limited  by  access  to critical minerals, exposed to high energy prices or constrained by capital-intensive manufacturing steps.

## Key considerations on security of supply

Improving the security of supply for a given clean energy technology supply chain requires  a  clear  analytical  framework  to  ensure  the  efficacy  and  efficiency  of suggested measures. The potential impact of a disruption is directly linked to the level of concentration (i.e. the share of imports sourced by a single country, entity or facility) and the fungibility in the most vulnerable step along the supply chain, as well as to the economic relevance of industrial activities that would be affected by such disruption.

## Assessing possible sources of disruptions

The first step is to list potential hazards - be they geopolitical, physical or others -that  might  affect  supply  chains  and  lead  to  disruptions,  and  assess  their likelihood. Some trade measures, in particular, can be extrajudicial, meaning that

they might affect production even outside the borders of the country in question. Physical  hazards,  meanwhile,  can  include  natural  hazards  or  other  accidents, which  might  affect  the  ability  to  produce  or  transport  a  given  good.  A  more comprehensive discussion of supply chain risks is provided in Chapter 6 of Energy Technology Perspectives 2023 (IEA, 2023).

Assessing  the  likelihood  of  disruption  depends  on  many  factors  that  are  not necessarily tied to concentration. However, the higher the supply concentration, the greater the likelihood that a disruption may have sizeable consequences. An assessment of global concentration levels is a useful start, but governments may need to develop more granular and country-specific assessments to better inform their decisions. This includes mapping precise supply chains for their own country and  identifying  critical  trade  infrastructure,  including  key  routes,  facilities  and institutional  arrangements  that  support  them.  Some  of  the  key  information  to consider for each individual component in a supply chain includes:

-  Geographical concentration : Share of supply dependency by country or region.
-  Company  concentration : Share of supply dependency  by company  or conglomerate. Knowledge about the ownership of the companies involved can also help assess risks related to extrajudicial trade measures.
-  Facility  concentration :  Share  of  supply  dependency  of  each  manufacturing facility.
-  Trade concentration : Share of supply sourced by trade route, including maritime routes and land-based routes. Maritime chokepoints and ports can be critical for the security of maritime trade, while individual highways or railways can be critical for land-based trade.

## Assessing potential impacts of disruptions

A potential interruption of supplies for clean energy technologies does not have the same disruptive impact on the economy as an interruption of energy supplies. Energy is necessary to run and operate equipment used in all productive activities as well as in dwellings. As such, a halt or restriction of energy supplies has impacts that  are  measured  economy-wide,  and  has,  in  several  instances,  resulted  in considerable economic damage that necessitated several years of recovery.

Clean  energy  technologies,  meanwhile,  are  capital  equipment,  which  either produces energy carriers (e.g. solar PV, electrolysers) or delivers energy services (e.g.  electric  cars,  heat  pumps).  An  immediate  supply  chain  disruption  can severely affect the industries directly involved, making it essential to understand how much economic activity depends on a given technology or component. At the economy-wide level,  however,  the  impact  may remain  manageable,  helped  by alternative suppliers and temporary substitution with fossil fuel powered technologies.

When imports of an intermediate product are  reduced  or  halted,  factories  that depend on that input must scale back or suspend production, and output prices may rise. The first-order monetary loss in such a scenario is the value of the lost output.  These  estimates  reflect  the  immediate,  direct  loss  from  factories  that cannot operate without the affected inputs. They do not capture how the wider economy might adjust over time. For example, we estimate that each month of a halt in battery cell exports  from  China  would  lead  to  an  output  loss  of USD 17 billion from electric car factories elsewhere, with facilities in the European Union - the largest importer - accounting for almost two-thirds of the losses. Each month of disruption of Chinese exports of wafers would mean that solar PV  cell production plants outside China  lose output worth around USD 1 billion, with more than 40% of the affected output located in Southeast Asia and India. A sustained halt to production may have wider economic and social impacts, including layoffs.

Figure 8.2 Value of produced goods that would be affected by a year-long interruption in upstream supply chain components, by region, 2024

<!-- image -->

A halt in exports of battery cells or solar PV components from China would lead to annual output losses worth billions in manufacturing facilities elsewhere.

The risks of disruptions to the supply of clean energy technologies have become evident as a result of recent measures. The full implementation of such measures -though  uncertain  -  could  restrict  access  to  capital  equipment,  with  direct implications for the ability of firms to maintain or expand manufacturing capacity. For example, since 2023, China has expanded export controls to cover high-purity graphite, rare earth elements, advanced lithium iron phosphate (LFP) technologies  and,  in  some  cases,  the  specialised  equipment  used  to  produce them (IEA, 2026b). Similar restrictions have been applied elsewhere, including the

United  States'  controls  on  advanced  semiconductor  manufacturing  tools  (US Congressional Research, 2025). Further detail is provided in Chapter 4.

Above and beyond the potential impact of disruptions to the supply of technology hardware, there is a need for particular care related to devices connected to the internet in the context of clean energy technology supply chains. The connectivity of such devices can have security consequences if exposed to malicious cyber actions (see Box 6.1).

## Measures to address security of supply risks

There is no single accepted definition of supply chain security, nor is there a fixed threshold for what constitutes adequate diversification. A safe level of diversification can be understood as a configuration in which alternative supply options, whether domestic or international, and sufficient flexibility in the system, allow major disruptions to be absorbed without causing economic impacts greater than the cost of maintaining that resilience.

Supply  chain  security  can  be  improved  either  by  reducing  the  probability  of hazards occurring, or by reducing the impact that these may have. Increasing the diversity of supply is a key means for doing so and requires action by the private and  public  sector  alike.  Private  actors  often  have  their  own  risk  mitigation measures  already  in  place,  although  they  may  not  always  fully  price-in  the downstream impacts  of  disruptions,  and  might  struggle  to  deal  with  'unknown unknowns' for which probability assessments are impossible to conduct (OECD, 2025).

Governments have different tools at their disposal. They can facilitate diversification  by  supporting  domestic  supply  (where  domestic  production  only accounts  for  a  small  share  of  total  supply)  and  by  collaborating  with  other governments to scale up production in their countries and build partnerships. They can also trade with a more diverse set of countries through collaboration; they can discourage excessive reliance on any single supplier and let the market adjust; or they  can  deploy  a  combination  of  both  measures.  Collaboration  with  partner countries that have competitive advantages in a given technology is an obvious pathway.  The  industrial  competitiveness  assessment  in  Chapter  7  can  help identify potential partners to target, but country-specific assessments will need to be conducted. Measures available to governments include:

-  Foreign direct investment: Governments can lay the groundwork for investment in partner countries with lower structural cost by establishing memorandums of understanding or other bilateral agreements, which typically serve as a first step in defining areas of co-operation. These agreements can then be operationalised through  targeted  financial  support  measures  -  such  as  loan  guarantees  for

investments from domestic development  finance institutions -to expand production capacity in specific supply chain steps.

-  Trade agreements: Governments can facilitate trade agreements with partner countries (other than the largest trading partner) that have existing or growing production capacity for a given step of the supply chain in order to foster access to those products.
-  Trade measures: Governments can use trade policy tools to disincentivise or incentivise trade with other suppliers. The impact on trade costs could impact trade routes and increase diversification.
-  Conditions for public procurement or subsidies: Adding supply chain securityrelated  criteria  to  access  subsidies  or  public  procurement  tenders.  Such  a measure could incentivise the sourcing of a given supply chain from sources other than from the largest producer.

Supporting domestic supply can also increase supply security. Governments have a very wide range of tools at their disposal to support domestic supply, again either supporting domestic production or affecting imports.

-  Tariffs and non-tariff measures can  limit  exposure  of  the  market  for  a  given technology to the global market, creating an incentive for domestic production.
-  Local  content  requirements can  create  more  limited  pockets  of  market protection that can support domestic production.
-  Production  subsidies targeting  either  capital  or  operational  expenditure  can stimulate domestic producers.

These measures can have rapid impacts, but they always come at a cost and do not  solve  the  underlying  structural  issues.  For  that  reason,  many  of  these measures  must  be  time-bound  and  monitored  carefully,  and  governments  will need to balance security objectives with affordability considerations. Some of the measures above can result in domestic price increases. Therefore, understanding how the market would respond to higher prices is important to gauge the amount of  demand destruction that such a measure would entail. Stimulating domestic production can be less costly for countries that already have a globally competitive industry  for  the  target  technology.  Nonetheless,  boosting  domestic  production requires  careful  balance  with  and  attention  to  competitiveness  (see  the  next section).

Supporting recycling and the circular economy can also help support security of supply. While recycling is particularly important for minerals and metals, circularity, together  with  other  demand-side  measures,  can  help  reduce  overall  levels  of demand. For example, supporting schemes to re-use batteries from automotive applications in stationary storage applications can reduce the overall demand for batteries, effectively generating a domestic demand source.

Technology substitution can also play an important role in reducing medium- to long-term supply chain vulnerabilities. The early commercialisation of sodium-ion batteries  could  ease  reliance  on  a  wider  range  of  battery  metals.  Permanent magnets  that  use  fewer  rare  earth  elements  and  transformers  that  avoid grain-oriented  electrical  steel  could  also  offer  substitution  pathways.  Some  of these options can already be reflected in procurement and tendering decisions, while others belong to medium- and long-term industrial strategies.

Stockpiling is also a typical tool for enhancing security of supply, but in the case of clean energy technologies this is most likely to only be effective for minerals and metals (IEA, 2026c). Several countries are already developing or expanding strategic stockpiles for critical minerals such as rare earth elements (Bloomberg, 2026). By contrast, most clean energy technologies and their components are too diverse  and  complex  for  stockpiling  to  be  a  universally  useful  tool.  However, certain clean energy technologies are increasingly moving towards commodification -for example, solar PV  supply chain components  are increasingly standardised. Commodified technologies might eventually be more suitable  for  stockpiling;  however,  technical  considerations  regarding  shelf  life should always be considered.

## Prioritising competitiveness actions

It is important to consider that supporting a domestic industry for strategic reasons comes at a cost to government budgets and to consumers when the industry is not cost-competitive. Such support must be used carefully, as investing in sectors with weak long-term prospects can create path dependence and lock-in effects that  become  costly  and  difficult  to  unwind.  Yet,  in  many  cases,  unlocking  the economic opportunities of a new industry requires government support to increase competitiveness.  Achieving  low  costs  of  production  is  an  important  factor  for competitiveness,  but it is not the only one. Producing  high-performance, innovative,  or  specialised  products  is  another  way  to  gain  or  retain  global competitiveness. For example, some producers outside China are specialising in higher-value and less price-sensitive markets that are less common in Chinese portfolios, such as high-density nickel manganese cobalt (NMC) batteries, flexible proton exchange membrane (PEM) electrolysers, or highly reliable wind turbines.

An opportunity assessment framework - which assesses the likelihood of success of competitiveness measures and quantifies the benefits that could be achieved if the measures were successful - can serve as a guiding principle.

## Assessing the likelihood of success

There  are  many  examples  of  government  policies  aimed  at  boosting  the competitiveness of specific industries. The extent of success varies, and there is a large body of literature on this topic that allows to draw lessons on the reasons for success  or  the  conditions  under  which  certain  measures  can  become counterproductive (IMF, 2025). The topic remains complex, nevertheless, but it is clear that there are several factors to take into account for countries that aim to develop  a  competitive  industry  on  a  given  technology.  Without  aiming  to  be exhaustive, we present a list of key considerations here:

-  Size of the competitiveness gap: Understand the level of the production cost difference  between  a  local  industry  and  the  lowest-cost  producers  at  the technology  frontier  (See  Chapter  7).  Distinguish  between  structural  reasons (labour, energy) for the cost gap and technology or know-how related reasons.
-  Synergies with existing industries : Most countries have specialised in certain sectors and have developed a pool of skilled workers for that sector; it is therefore important to map how new industries might interact with existing industries, both in terms of demand and supply.
-  Supply: For countries with strong mechanical industries (transport equipment, aerospace, machine tools) it might be easier to establish a competitive clean energy technology industry that requires large mechanical components (wind is  a  key  example),  as  skills  can  more  easily  be  transferred.  Countries  with specialised  electronics  industries  might  have  a  workforce  and  industrial environment that  is  more  conducive  to  achieving  a  competitive  solar  PV  or battery industry. For countries starting with little or no relatable industries, it can be more difficult to reach international competitiveness.
-  Demand: it  is  important  to  clarify  the  extent  to  which  certain  clean  energy technologies might interact with other economic sectors. Batteries are a key example, with their strong connection to electric car manufacturing, as well as with growing demand sectors, such as grid storage or the defence sector.
-  Level  of  maturity  of  the  industry :  It  is  important  to  understand  the  level  of maturity of a clean energy technology industry at home and in other countries. Infant industries can achieve rapid production cost declines as production volumes increase, making  them  stronger candidates for targeted support. Mature industries, by contrast, see slower productivity and cost improvements, limiting the gains that policy intervention can deliver. Evidence of sustained cost declines in a certain  industry  is  a  good  indication  that  it  might  eventually  reach  global competitiveness under the right circumstances.
-  Availability  of  trade  partners: Assessing  the  feasibility  of  meaningful  cooperation  with  trade  partners  that  already  produce,  or  have  the  potential  to produce, certain supply chain components at a competitive cost, is important to determine  a  balanced  strategy  for  international  collaboration  in  order  to  help domestic industries reach global competitiveness.

## Assessing the potential costs and benefits

Enhancing the competitiveness of an existing industry - or establishing a new one - requires careful consideration of the potential costs and benefits of government measures.  While  these  will  typically  be  linked  to  the  policy  measures  that  are ultimately  chosen,  there  are  some  upfront  considerations  to  take  into  account ahead  of  the  design  of  support  schemes.  A  non-exhaustive  list  includes  the following key questions:

-  What  is  the  potential  market  size? The  potential  market  size  of  a  given technology provides an indication of the future revenues for companies in a given industry. Although a large market in itself does not necessarily make an industry strategic from a policy perspective, it is nonetheless a simple metric that reveals the upper bound of the economic opportunity involved. Distinguishing between domestic and global market sizes can inform strategy, as achieving competitiveness may be more feasible in domestic markets than in international ones.
-  Can the industry become profitable? Whether or not a productive industry can become profitable is an important consideration as to its ability to become selfsustaining and generate growth. Beyond demand projections, profitability depends on structural characteristics such as market size, the underlying cost structure of production  (including  capital  intensity  and  learning-curve  potential),  and  the degree of competitive intensity shaped by market concentration and barriers to entry. Predicting profitability is very difficult, but economic analysis can help to identify  cases  in  which  reaching  profitability  is  very  unlikely  and  guide  policy makers toward interventions that use public resources most effectively.
-  Does  the  industry  have  important  employment  potential? Supporting  the creation  of  jobs  is  an  important  policy  consideration,  but  not  all  industries  are equally labour-intensive. Assessing the impacts of a prospective investment on the creation of a future workforce, as well as on the types and skill level of jobs can help size the benefits of gaining competitiveness in each industry.
-  What  is  the  innovation  potential? Innovation  is  a  key  engine  of  economic growth, which makes it desirable for policy support to an industry to generate know-how  and  high-tech  products.  Certain  industries  have  higher  innovation intensity than others. Therefore, gauging the innovation spillovers from a certain industry is important to quantifying the benefits of government action.

Figure 8.3  Global market size by selected clean energy technology in the Stated Policies Scenario, 2035

<!-- image -->

IEA. CC BY 4.0.

The  market  size  potential  varies  widely  across  different  clean  energy  technology  supply chain steps.

## Measures to improve competitiveness

Closing the cost-competitiveness gap in clean energy technology manufacturing is possible, but requires a focus on areas where efficiency gains, scale  effects  and  innovation  can  make  a  particular  difference  rather  than  only trying to address structural disadvantages that concern access to cheap energy or  labour.  Efforts  to  improve  competitiveness  can  be  costly  at  the  start  as investments and support measures might be required, while economic and social benefits might take some time to materialise. Lithium-ion battery production is a key example: the production cost in Europe could be cut by over 25% through measures  to  improve  manufacturing  efficiency  and  secure  access  to  cheaper components, which are key opportunities for policy action (see Figure 7.20).

Economies of scale are  indispensable  for  any  technology  that  can  be  massmanufactured, and no manufacturer will invest in new capacity without confidence in future demand. Such confidence is closely linked to government policy, and the tools are available and proven: energy efficiency and emissions standards for road vehicles, for example, give clarity to investors on the market opportunity for electric vehicles and batteries. Targets for clean energy deployment and long-term public procurement programmes are other potential tools.  Large,  predictable  markets also encourage standardisation, learning by doing and lower unit costs - a key driver behind  wind  turbine price reductions in recent years. Tax  credits, concessional loans and investment guarantees can help attract capital for larger plants, although the goal must be to reach competitive scale. For those reasons, 'ramp  up'  subsidies  might  be  considered  that  help  protect  firms  in  reaching commercial production but have a clear end date to ensure that subsidy reliance does not translate into poor performance.

Innovation is a necessary condition for success, though insufficient on its own. Governments  can  make  a  difference  through  direct  involvement  in  research,

development and demonstration projects, or through incentives for private sector projects. Achieving technology breakthroughs is a desirable outcome, but only if they  deliver  significant  improvements  over  today's  low-cost  and  sufficiently performing products. Other global producers will inevitably continue to innovate and optimise at the same time, which means that closing the innovation gap is a moving target.  Public  funds  are  usefully  focused  on  technologies  that  promise significant  performance  gains,  or  that  can  help  lower  the  production  cost  gap with others,  or  both  (Box 8.2 ).  This  requires  an  approach  that  supports  earlystage  pilots  and  demonstrations,  embeds  mechanisms  to  learn  from  these projects, and includes clear conditions for phasing out support as technologies  mature  and  become commercially viable.

## Box 8.2 The role of innovation in boosting competitiveness

Technological innovation has been central to reducing costs and improving the performance of  clean  energy technologies,  and  much  of  today's  deployment  is possible only thanks to past advances. Innovation can reshape the competitive landscape for a given technology in three main ways: by lowering manufacturing costs; enabling designs with superior performance compared to existing options; and  creating  products  that  combine  improved  performance  with  manufacturing processes  that  rely on cheaper  inputs. Several emerging  technologies  in manufacturing and product design have recently reached the demonstration phase and could soon be commercialised on a large scale.

Figure 8.4 Technology readiness level timeline for selected emerging clean energy technologies and production processes

<!-- image -->

IEA. CC BY 4.0.

Notes: CSRs = calcium silicate rocks (e.g. basalt). Solid-state cooling uses caloric effects in solid materials (e.g. baro-, magneto-, elasto- and electro-caloric) instead of vapour compression refrigeration. Source: IEA, 2026b.

Manufacturing  costs can  be  reduced through  process  innovations that  improve efficiency.  Those  targeting  energy  efficiency  can  be  especially  relevant  for narrowing the cost gap between China and advanced economies. For batteries, a promising  next  step  is  dry  electrode  coating  -  an  emerging  technology  that eliminates solvents and the energy-intensive drying stage in battery cell manufacturing. This innovation could reduce energy use in the coating step by about 20% (Degen et al., 2023) and lower total cell manufacturing costs by around 5-10% versus conventional process, including CAPEX, labour and energy savings (Greitemeier et al., 2026).

New designs and technologies with superior performance can open markets and create a first-mover advantage for the countries that develop them, on the condition that they are supported by intellectual property rights protection, the availability of local  expertise  and  the  development  of  robust  industrial  ecosystem  and  supply chains  (IEA,  2025a).  Solid-state  batteries  (SSBs)  are  a  leading  example.  They promise higher energy density and improved safety compared with today's lithiumion  batteries,  which  could  provide  a  competitive  edge  to  early  developers.  Yet, SSBs are expected to carry a higher price tag, at least initially, making them more suitable  for premium  market  segments  in  the  initial  stages  of  deployment (see question 5 in Chapter 1).

Some  technological  innovations  can  simultaneously  improve  performance  and enhance  cost  competitiveness.  These  include  technologies  that  replace  critical minerals with more abundant materials, or that require significantly less material and/or energy inputs while at the same time delivering superior performance. Such advances not only offer a first-mover advantage to countries that develop them, but also allow those countries to decouple from existing supply chains that were built  on  the  basis  of  earlier  competitive  advantages.  A  particularly  important example is perovskite solar cells. The material requirements for these cells are far lower than for conventional silicon cells, and many of the emerging manufacturing routes operate at lower temperatures (Afre and Pugliese, 2024). This means the energy  intensity  of  production  is  considerably  lower  per  unit  of  power  output, lowering the impact of energy prices on cost competitiveness. These cells can be used in tandem with silicon cells, reducing the silicon requirements, or - in the longer term - could be used standalone, thus completely substituting silicon.

Encouraging international partnerships, whether through industry partnerships with  established  equipment  makers  or  through  government  collaboration  with trade partners, is another important area of potential action. New market entrants in  complex  industries,  such  as  batteries  or  solar  PV,  often  struggle  with  low manufacturing yields. Partnerships with established equipment makers can raise

quality faster, enable transfer know-how and strengthen local supply chains. Highyield factories, with less waste and fewer defects, mean lower costs. To reinforce and  scale  these  gains,  governments  can  deepen  broader  international  cooperation through coalitions of willing partners, more supportive trade agreements, and efforts to lower tariff and non-tariff barriers.

Lowering energy prices is a key priority in segments where energy costs strongly influence  competitiveness,  particularly  for  solar  PV  manufacturing.  Structural measures, such as wholesale market reform and expanding the role of low-cost renewable generation,  can  provide  competitive  prices  for  energy-intensive  and strategic clean technology manufacturing. This can significantly narrow the cost gap with other countries.

## References

Afre and Pugliese. (2024). Perovskite Solar Cells: A Review of the Latest Advances in Materials, Fabrication Techniques, and Stability Enhancement Strategies. Micromachines , 192. Retrieved from https://www.mdpi.com/2072-666X/15/2/192

Bloomberg. (2026). Trump to Launch $12 Billion Critical Mineral Sockpile to Blunt Relience on China . Retrieved from https://www.bloomberg.com/news/articles/2026-02-02/trumplaunches-12-billion-minerals-stockpile-to-counter-china

Degen et al. (2023). Energy consumption of current and future production of lithium-ion and post lithium-ion battery cells. Nature Energy . Retrieved from https://www.nature.com/articles/s41560-023-01355-z

Greitemeier et al. (2026). Costs and carbon footprint analysis of dry manufacturing battery LiFePO4-based cathodes. Cell Reports Physical Science . Retrieved from https://www.sciencedirect.com/science/article/pii/S2666386425006575

IEA. (2023). Energy Technology Perspectives. Retrieved from https://www.iea.org/reports/energy-technology-perspectives-2023

IEA. (2025a). How can innovation help secure future battery markets and mineral supplies? Retrieved from https://www.iea.org/commentaries/how-can-innovation-help-securefuture-battery-markets-and-mineral-supplies

IEA. (2025b). Cost of Capital Observatory . Retrieved from https://www.iea.org/reports/cost-ofcapital-observatory

IEA. (2025c). Gaining an Edge. Retrieved from https://www.iea.org/reports/gaining-an-edge

- IEA. (2026a). ETP Clean Energy Technology Guide. https://www.iea.org/data-andstatistics/data-tools/etp-clean-energy-technology-guide.

IEA. (2026b). The State of Energy Innovation. Retrieved from https://www.iea.org/reports/thestate-of-energy-innovation-2026

IEA. (2026c). Designing an effective strategic stockpiling system for critical minerals . Retrieved from https://www.iea.org/commentaries/designing-an-effective-strategicstockpiling-system-for-critical-minerals.

IMF. (2025). World Economic Outlook.

OECD. (2025). OECD Supply Chain Resilience Review. Paris.

US Congressional Research. (2025). Retrieved from https://www.congress.gov/crsproduct/R48642

## Annex - Definitions

## Glossary

This  glossary  provides  general  information  on  terminology  used  in  this  report, including definitions of technologies, fuels and processes, as well as descriptions of scenarios used.

Ad valorem tariff: A  tariff  rate  levied  as  a  fixed  percentage of the value of an imported product at customs. This value includes the product's price, in this report modelled as the LCOP plus a profit margin, along with freight and insurance costs.

Announced capacities: Refers to the aggregate stated capacity - or estimated nominal maximum output - of potential manufacturing facilities (projects) that have been announced. This includes projects for building new facilities or expanding existing ones that are at different stages of development. 'Committed' projects include those that have already reached a final investment decision (FID), or are under construction, whereas 'preliminary' projects include those that have not yet reached  an  FID,  meaning  feasibility  studies  or  earlier  steps  are  underway. Wherever data is available, we distinguish committed projects from preliminary announcements  across  the  key  technologies  in  focus,  which  allows  for  more robust projections of future manufacturing capacity.

Battery: Batteries considered in the ETP-2026 report include advanced electrochemical energy storage technologies based on lithium-ion (Li-ion) or post Li-ion  batteries  used  in  road  transport  or  stationary  storage  applications.  If  not stated otherwise, battery always refers to lithium-ion battery cells, except when discussing  market  sizes  and  import/export  values,  where  it  refers  to  final applications or traded goods (a combination of lithium-ion battery cells, packs and systems).

Breakbulk shipping: Refers to the transportation of goods that are too large or cumbersome to be placed in containers, or that are transported individually rather than in bulk. Breakbulk cargo typically includes items like machinery, vehicles, steel and construction materials. These items are loaded, stacked and transported piece  by  piece  using  cranes  and  other  handling  equipment,  often  requiring specialised handling and stowage.

Bunkering: The process of supplying fuels to a ship.

CAPEX: Capital expenditures (or expenses).

Clean energy technology: An energy technology that results in minimal or zero emissions of CO2 and pollutants. For the purposes of this report, clean energy technologies  refer  to  the  following:  Batteries,  Electric  cars,  Electrolysers,  Heat pumps, Solar PV, and Wind.

Container shipping: The transport of goods using large, standardised containers that can be easily transferred between different modes of transportation (ships, trains,  trucks)  without  unloading  the  cargo  itself.  These  containers  come  in standard sizes (e.g. 20-foot and 40-foot containers) and are used to ship a wide variety of goods, from consumer products to machinery. Container ships are used to transport containers.

Critical materials: A wide range of minerals and metals that are essential in clean energy technologies and other modern technologies and have supply chains that are vulnerable to disruption. Although the exact definition and criteria differ among countries, critical minerals for clean energy  technologies typically include chromium,  cobalt,  copper,  graphite,  lithium,  manganese,  molybdenum,  nickel, platinum group metals, zinc, rare earth elements and other commodities, as listed in the Annex of the IEA special report on the Role of Critical Minerals in Clean Energy Transitions (IEA, 2021).

Current Policies Scenario (CPS): This scenario sets out a pathway for the future of the energy system in which no change in energy-related policies is assumed beyond what is already in place. The CPS therefore builds on a narrow reading of today's policy settings, only considering those that are adopted in legislation and regulation, and assuming no change, even where governments have indicated their intention to do so. Where existing policies target a range of outcomes, it is assumed that the lower end of the range is achieved. In the CPS, policies that are time-bound or that target specific years are not strengthened after they expire. Alongside  this  view  of  the  policy  landscape,  the  CPS  also  offers  a  generally cautious perspective on the speed at which new energy technologies are deployed and integrated into the energy system. It tends to project slower growth in the adoption of new technologies in the energy system than seen in recent years, or than projected in the STEPS.

Critical materials: A wide range of minerals and metals that are essential in clean energy technologies and other modern technologies and have supply chains that are vulnerable to disruption. Although the exact definition and criteria differ among countries, critical minerals for clean energy  technologies typically include chromium,  cobalt,  copper,  graphite,  lithium,  manganese,  molybdenum,  nickel, platinum group metals, zinc, rare earth elements and other commodities, as listed in the Annex of the IEA special report on the Role of Critical Minerals in Clean Energy Transitions (IEA, 2021).

Deadweight  tonnage  (DWT): A  measure  used  in  shipping  to  indicate  the maximum weight a ship can safely carry, including cargo, fuel, fresh water, ballast water, provisions, crew and passengers. It represents the carrying capacity of the vessel, excluding the ship's own weight (the hull, engines, etc.).

Dry bulk shipping: Refers to the transportation of unpackaged, loose commodities in large quantities that are solid and dry. These goods are typically stored directly in the hold of a ship without the use of containers or packaging. Common examples of dry bulk cargo include coal, grain, iron ore, cement and salt. The ships used for this purpose are called bulk carriers or dry bulk carriers.

Electric  cars: Refer  to  EVs  that  belong  to  the  passenger  light-duty  vehicles category such as cars, SUVs and passenger pick-up trucks.

Electric vehicles (EVs): Vehicles that use electricity as a source of propulsion. Electric  vehicles  comprise  battery  electric  vehicles  (BEVs)  and  plug-in  hybrid electric vehicles (PHEVs).

Electrolysers: A device that uses direct electrical current to drive an otherwise non-spontaneous  chemical  reaction.  Commonly  used  in  the  production  of chemicals  such  as  chlorine.  Water  electrolysers  split  water  into  hydrogen  and oxygen,  for  the  production  of  hydrogen,  and  are  increasingly  being  applied  to energy  challenges  such  as  the  conversion  of  CO2  to  useful  products  and  the reduction  of  iron  ore.  In  the  context  of  the ETP-2026 report,  if  not  otherwise specified, electrolysers refer to water electrolysers for the production of hydrogen, including all  major  technologies such as alkaline, proton exchange membrane, solid oxide electrolysis and others. Manufacturing capacity refers to the assembly capacity, and upstream components capacity is not considered.

Export tax: A tax imposed on commodities being exported out of the country.

Freight rate: The price charged by a carrier (shipowner or charterer) or freight forwarder to transport goods from one place to another. This price is determined by the cost of transporting goods, as well as market conditions.

Heat pumps: A device that consumes energy, usually electricity, to transfer heat from a source to a sink using a refrigeration cycle (compression, condensation, expansion and evaporation of a refrigerant working fluid). The devices can extract heat from the  outside  air  (air-source  heat  pump),  shallow  subsurface  (groundsource heat pump) or other nearby sources as water. These may be designed to operate reversibly to provide air conditioning as well as heating, or only to provide heating.  The  performance  of  a  heat  pump,  expressed  as  the  coefficient  of performance (COP) or seasonal coefficient  of  performance  (SCOP),  is usually such that the heat delivered is several multiples of the energy contained in the input electricity. Heat pumps in this report refer to those that deliver heat directly

to households and residential or commercial buildings for space heating and/or domestic hot water provision. They include natural source heat pumps, including reversible  air  conditioners  used  as  primary  heating  equipment.  They  exclude reversible air conditioners used only for cooling, or used as a complement to other heating equipment, such as a boiler.

HS codes: Harmonized System (HS) Codes are a standardised numerical system used to classify internationally traded goods, developed by the World Customs Organization (WCO). HS codes are used by authorities to identify products, to determine tariffs applicable to a product and to collect trade statistics. Internationally standardised HS codes consist of a two-digit number ('Chapter'), four-digit number ('Heading') and six-digit number ("Sub-Heading').

Import quota: A  limit  on  the  quantity  of  a  product  that  can  be  imported  into  a country in a given period. There are two types: absolute and tariff rate. An absolute import quota strictly limits the physical quantify of a product that can enter into a country,  while  a  tariff-rate  import  quota  allows  a  certain  quantity  to  enter  at  a reduced tariff rate, and once this is reached, the product can still enter but at a higher tariff.

Import tariff: An import tariff is a customs duty levied on an imported product. There are  different  types  of  tariffs:  ad  valorem  tariffs,  specific  tariffs,  tariff-rate quotas  (see  the  relevant  entries  in  this  glossary)  and  compound  tariffs,  which combine an 'ad valorem' duty and a 'specific' duty, added together or subtracted from each other.

International  marine  bunkers: Includes  marine  fuels  delivered  to  ships  of  all flags  that  are  engaged  in  international  navigation.  The  international  navigation may take place at sea, on inland lakes and waterways, and in coastal waters. Consumption  by  ships  engaged  in  domestic  navigation  is  excluded.  The domestic/international split is determined on the basis of port of departure and port of arrival, and not by the flag or nationality of the ship.

Inter-regional  trade: This  covers  all  trade  flows  that  move  between  distinct modelling regions, but does not capture any flows of international trade that might be taking place between countries belonging to the same modelling region.

Investment overnight: These are the capital costs (USD) that are considered to be incurred in a single time period ('overnight'), i.e. at the time of installation of a facility or deployment of a technology. They are calculated by multiplying the unit capital  expenditure,  without  accounting  for  discount  rates  with  the  capacity additions (GW or GWh of annual capacity).

Investment  spending: Investment  spending  (USD)  is  derived  from  overnight investments using the assumption of an even distribution of expenditure over the

period  between FID and the start of operations. This period is assumed to be 2 years for all materials, technologies and components considered in the analysis, apart from solar PV modules and cell facilities, for which we assume a period of 1 year. An even spending profile during this period is assumed, meaning that an investment with a 2-year FID-to-operation period will see 50% of the spending take place in the year the facility becomes operational and 50% the year before.

Investments: Investments always refer to manufacturing capacity investment if not stated  otherwise.  Investments for manufacturing  of  clean technologies  and materials refer to greenfield capacity additions only. They do not include upgrades to existing facilities for clean technologies, while for materials the conversion of existing capacity to near-zero ones is accounted for (assuming the same cost as greenfield investment).

Levelised  cost  of  production  (LCOP): A  measure  of  the  average  cost  of producing a unit of output from a manufacturing facility over its lifetime.

Local  content  requirements: Policies that specify a minimum  share  of domestically  manufactured  goods,  domestically  supplied  services  or  domestic labour  that  must  contribute  to  a  product  or  service,  often  expressed  as  a percentage of the final value. Certain incentives may be available only for products that meet these local content thresholds.

Low-emissions  fuels: Includes  bioenergy,  low-emissions  hydrogen  and  lowemissions hydrogen-based fuels.

Low-emissions hydrogen: Includes hydrogen which is produced through water electrolysis  with  electricity  generated  from  a  low-emissions  source  (such  as renewables, e.g. solar and wind turbines, and nuclear). Hydrogen produced from biomass or from fossil fuels with carbon capture, utilisation and storage (CCUS) technology  is  also  counted  as  low-emissions  hydrogen.  Production  from  fossil fuels  with  CCUS  is  included  only  if  upstream  emissions  are  sufficiently  low,  if capture  -  at  high  rates  -  is  applied  to  all  CO2  streams  associated  with  the production route, and if all CO2 is permanently stored to prevent its release into the  atmosphere.  The  same  principle  applies  to  low-emissions  feedstocks  and hydrogen-based  fuels  made  using  low-emissions  hydrogen  and  a  sustainable carbon source (of biogenic origin or directly captured from the atmosphere).

Low-emissions  hydrogen-based  fuels: Includes  fuels  produced  from  lowemissions hydrogen. Includes ammonia, methanol and other synthetic hydrocarbons (gases and liquids) made from low-emissions hydrogen when any carbon inputs, e.g. from CO2, are not from fossil fuels or fossil-derived process emissions.

Manufacturing  capacity: The  maximum  amount  of  a  material,  component  or technology a facility is nominally able to produce.

Maritime chokepoint: A strategic, narrow passage connecting two larger areas of the world's oceans and seas. They are often straits or canals through which a significant share of global vessels transit.

Market  size: The  market  size  (USD)  for  clean  technologies  and  materials  is calculated based on the demand for this technology or material multiplied by its global unit price. In the calculation of total market size for clean technologies as a whole, only the final components are taken into account if these are in a serial supply chain, e.g. the market size for PV is equal to the market size for modules. For the case of the EV and batteries supply chain, the market size includes the total value of all electric cars (with their batteries), as well as the value of batteries (pack  or  system)  used  in  electric  two-  and  three-wheelers,  light  commercial vehicles, buses, trucks, and stationary storage (altogether referred to as 'other batteries').

Modern bioenergy: Bioenergy including liquid  biofuels  (biogasoline,  biodiesel, biojet kerosene, other liquid biofuels), biogases (biogas, biomethane) and all solid bioenergy products, except the traditional use of biomass.

NACE codes: NACE (Nomenclature statistique des Activités économiques dans la  Communauté Européenne [Statistical Classification of Economic Activities in the European Community]) Codes are a standardised numerical system to classify industrial sectors within the European Union. NACE codes are used by authorities to  for  statistical  purposes  and  can  correspond  with  the  United  Nations  ISIC classification system.

Near-zero emissions materials: in  this  report,  technologies  that  can  produce steel  from  iron  ore,  aluminium  from  bauxite,  and  ammonia  with  emissions intensities that are compatible with the IEA Net Zero Emissions by 2050 Scenario are referred to as 'near-zero emissions technologies', and their outputs as 'nearzero emissions materials''.

Net Zero Emissions by 2050 Scenario (NZE Scenario): This  is  a  normative scenario that maps out a global pathway for the energy sector to achieve net zero carbon dioxide (CO2) emissions by 2050, consistent with the long-term goal of limiting the rise in global average temperatures to 1.5°C (with a 50% probability). In contrast with previous editions, the NZE Scenario used in ETP-2026 is no longer a low-overshoot scenario: it assumes that warming exceeds 1.5°C degrees for several decades before returning below 1.5°C by 2100. This adjustment reflects persistently high emissions in recent years and the slow deployment of some key technologies. Achieving this pathway requires not only a very rapid transformation

of the energy sector but also large-scale deployment of CO2 removal technologies, which remain unproven at large scale.

Non-tariff  measures  (NTM): Policy  measures,  other  than  ordinary  customs tariffs, that can potentially have an impact on the value, quantity or quality of traded goods. These typically include regulations and technical specifications, such as requirements for efficiency, durability, environmental impact or safety, which can have  a  significant  impact  on  trade  costs,  especially  if  they  differ  significantly between countries.

OPEX: Operating expenses (or operational expenditure), including both fixed and variable operating expenses.

Ro-Ro (roll-on/roll-off) shipping: Ro-Ro shipping involves the transportation of vehicles and wheeled cargo, such as cars, trucks, trailers and heavy machinery, that can be driven directly on and off the ship.

Shipping activity: In ETP-2026 , shipping activity is defined as the mass of cargo multiplied by the distance over which the cargo is moved.

Specific tariff: A fixed charge levied at the point of import based on a defined physical quantity, such as per tonne or per unit, regardless of the value of the imported product.

Stated  Policies  Scenario  (STEPS): This  scenario  is  designed  to  reflect  the direction  of  travel  of  the  global  energy  sector  based  on  current  energy-related policies, including those that have already been adopted, announced, or are in the advanced planning stage - even if they are not yet enshrined in law or regulations. Examples of the latter include power sector development plans aimed at achieving a certain mix of generation assets by a specific date, regulatory reforms in the transport sector and energy efficiency targets for appliances. Policy targets are not assumed to be automatically met: in each case, their prospects are assessed taking account of market, infrastructure readiness and financial constraints. The STEPS assumes that time-bound policies continue beyond the currently-stated durations and retain a similar pace of change. However, it does not assume that aspirational goals, such as those included in the Paris Agreement, are achieved.

Traditional  use  of  biomass: Refers  to  the  use  of  solid  biomass  with  basic technologies,  such  as  a  three-stone  fire  or  basic  improved  cook  stoves  (ISO tier &lt;3),  often  with  no  or  poorly  operating  chimneys.  Forms  of  biomass  used include wood, wood waste, charcoal, agricultural residues and other bio-sourced fuels such as animal dung.

Total  cost  of  ownership  (TCO): The  total  costs  associated  with  acquiring, operating, and maintaining an asset over its lifecycle.

Twenty-foot equivalent unit (TEU): A standard unit of measurement used in the shipping industry to describe the capacity of container ships, and the volume of cargo handled at ports. Represents the size of a standard shipping container of size 20x8x8.5 ft.

Utilisation rate: The  proportion  of the maximum capacity of a facility which is used on average over a set period of time. For the purposes of ETP-2026 and its respective modelling, this period is a calendar year. The default assumption the maximum practical utilisation rate is 85%.

Value added: A measure which reflects the value generated by producing goods and services. Value added is measured as the value of output minus the value of intermediate consumption.

Wet  bulk  shipping: Wet  bulk  shipping  involves  the  transportation  of  liquid commodities in large volumes, such as crude oil, petroleum products, liquefied natural gas (LNG), chemicals, and other liquid cargo. These materials are typically carried  in  tankers,  which  are  specially  designed  to  transport  fluids  safely.  The ships used are referred to as tankers, with specialised variants like oil tankers and chemical tankers.

## Abbreviations and acronyms

AAM

anode active material

AC

air conditioner

ADD

antidumping duties

AE

advanced economies

AI

artificial intelligence

ASEAN

Association of Southeast Asian Nations

BECCS

bioenergy with carbon capture and storage

BEV

battery electric vehicles

BF

blast furnace

BF-BOF

blast furnace-basic oxygen furnace

CAM

cathode active material

CAPEX

capital expenditure

CBAM

Carbon Border Adjustment Mechanism

CCDC

Concessional Custom Duty Certificates

CCfD

carbon contract for difference

CCS

carbon capture and storage

CCUS

carbon capture utilisation and storage

CDR

carbon dioxide removal

COP

coefficient of performance

CORSIA

Carbon Offsetting and Reduction Scheme for International Aviation

CO2

carbon dioxide

| CPS    | Current Policies Scenario                        |
|--------|--------------------------------------------------|
| CSAM   | Central and South America                        |
| CSPF   | cooling seasonal performance factor              |
| CVD    | countervailing duties                            |
| DAC    | direct air capture                               |
| DD     | direct-drive                                     |
| DFIG   | doubly fed induction generators                  |
| DRI    | direct reduced iron                              |
| DRC    | Democratic Republic of the Congo                 |
| DSO    | distribution system operator                     |
| EAF    | electric arc furnace                             |
| EBIT   | earnings before interest and tax                 |
| ECI    | Economic Complexity Index                        |
| EMDE   | emerging markets and developing economies        |
| ETP    | Energy Technology Perspectives                   |
| ETS    | Emissions Trading Scheme                         |
| EV     | electric vehicle                                 |
| FCEV   | fuel cell electric vehicle                       |
| FDI    | foreign direct investment                        |
| FID    | final investment decision                        |
| GDP    | gross domestic product                           |
| GEC    | Global Energy and Climate                        |
| GHG    | greenhouse gas                                   |
| G7     | Group of Seven                                   |
| HEFA   | hydroprocessed esters and fatty acids            |
| HFC    | hydrofluorocarbon                                |
| HJT    | heterojunction technology                        |
| HS     | Harmonized System                                |
| HVAC   | heating, ventilation and air conditioning        |
| H 2    | hydrogen                                         |
| ICE    | internal combustion engine                       |
| ICEV   | internal combustion engine vehicle               |
| IDDI   | Industrial Deep Decarbonisation Initiative       |
| IMF    | International Monetary Fund                      |
| IMO    | International Maritime Organization              |
| IRA    | Inflation Reduction Act                          |
| ISIC   | International Standard Industrial Classification |
| ISO    | International Organization for Standardization   |
| IT     | information technology                           |
| LCOE   | levelised cost of electricity                    |
| LCOP   | levelised cost of production                     |
| LESS   | Low Emission Steel Standard                      |
| LFP    | lithium iron phosphate                           |
| Li-ion | lithium-ion                                      |
| LNG    | liquefied natural gas                            |

LPG

liquefied petroleum gas

MaT

Manufacturing and Trade

MEPS

Minimum Energy Performance Standards

MeOH

methanol

MREE

magnet rare earth elements

NACE

Nomenclature of Economic Activities

NCA

lithium nickel cobalt aluminium oxide

NH3

ammonia

NMC

lithium nickel manganese cobalt oxide

NZIA

Net-Zero Industry Act

NZE

Net Zero Emissions by 2050 Scenario

OEM

original equipment manufacturer

OPEC

Organization of the Petroleum Exporting Countries

OPEX

operating expenditure

PEM

proton exchange membrane

PERC

Passivated Emitter and Rear Cell

PFE

Prohibited Foreign Entity

PHEV

plug-in hybrid electric vehicle

PV

photovoltaic

RCA

revealed comparative advantage

RD&amp;D

research, development and demonstration

REE

rare earth elements

ROIC

return on invested capital

RoW

Rest of World

SAF

sustainable aviation fuel

SMR

small modular reactor

SSB

solid-state battery

STEPS

Stated Policies Scenario

SUV

sport utility vehicle

TCO

total cost of ownership

TRL

technology readiness level

TSO

transmission system operator

TOPCon

Tunnel Oxide Passivated Contact

USMCA

United States-Mexico-Canada Agreement

VALCOE

value-adjusted levelised cost of electricity

VC

venture capital

WACC

weighted average cost of capital

WTIV

wind turbine installation vessels

ZCRB

zero-carbon-ready buildings

ZETI

Zero-emission Technology Inventory

## Units of measure

°C

degrees Celsius

EUR

euro

EJ

exajoule

GBP

pound sterling

GJ

gigajoule

GW

gigawatt

GWh

gigawatt hour

GWth

gigawatt thermal

kb/d

thousand barrels per day

kg

kilogramme

km

kilometre

kVA

kilovolt-ampere

kW

kilowatt

mAh

milliampere hour;

Mgt

million gross tonnes

Mt

million tonnes

Mtpa

million tonnes per annum

MVA

megavolt amperes

MW

megawatt

MWh

megawatt hour

TEU

twenty-foot equivalent units

t

tonne

TW

terawatt

TWh

terawatt hour

USD

United States dollars

V

volts

Wh/kg

Watt-hour per kilogramme

<!-- image -->

See the Manufacturing and Trade Model Documentation (IEA, 2026) and the IEA glossary for a further explanation of many of the terms used in this report.

## Currency conversions

| Exchange rates (2024 annual average)   | 1 US dollar (USD) equals:   |
|----------------------------------------|-----------------------------|
| British pound sterling                 | 0.78                        |
| Canadian dollar                        | 1.37                        |
| Chinese yuan renminbi                  | 7.20                        |
| Euro                                   | 0.92                        |
| Indian rupee                           | 84.60                       |
| Japanese yen                           | 151.37                      |
| Korean won                             | 1 363.37                    |
| New Zealand dollar                     | 1.65                        |
| Thai baht                              | 35.29                       |

## Regional groupings

Advanced  economies: Australia,  Austria,  Belgium,  Bulgaria,  Canada,  Chile, Colombia,  Costa  Rica,  Croatia,  Cyprus, 1,2 Czech  Republic,  Denmark,  Estonia, Finland,  France,  Germany,  Greece,  Hungary,  Iceland,  Ireland,  Israel,   Italy, 3 Japan, Korea, Latvia, Lithuania, Luxembourg, Malta, Mexico, Netherlands, New Zealand, Norway, Poland, Portugal, Romania, Slovak Republic, Slovenia, Spain, Sweden, Switzerland, Türkiye, United Kingdom and United States.

Africa: Algeria, Angola, Benin, Botswana, Cameroon, Côte d'Ivoire, Democratic Republic  of  the  Congo,  Egypt,  Equatorial  Guinea,  Eritrea,  Ethiopia,  Gabon, Ghana,  Kenya,  Kingdom  of  Eswatini,  Libya,  Madagascar,  Mauritius,  Morocco, Mozambique, Namibia, Niger, Nigeria, Republic of the Congo (Congo), Rwanda, Senegal,  South  Africa,  South  Sudan,  Sudan,  United  Republic  of  Tanzania (Tanzania),  Togo,  Tunisia,  Uganda,  Zambia,  Zimbabwe  and  other  African countries and territories. 4

Asia Pacific excluding China: Southeast Asia regional grouping and Australia, Bangladesh, Democratic People's Republic of Korea (North Korea), India, Japan, Korea, Mongolia, Nepal, New Zealand, Pakistan, Sri Lanka, Chinese Taipei, and other Asia Pacific countries and territories. 5

Central and South America: Argentina, Plurinational State of Bolivia (Bolivia), Bolivarian  Republic  of  Venezuela  (Venezuela),  Brazil,  Chile,  Colombia,  Costa Rica,  Cuba,  Curaçao,  Dominican  Republic,  Ecuador,  El  Salvador,  Guatemala, Guyana,  Haiti, Honduras, Jamaica, Nicaragua, Panama,  Paraguay,  Peru, Suriname, Trinidad and Tobago, Uruguay and other Central and South American countries and territories. 6

1 Note by Republic of Türkiye: The information in this document with reference to 'Cyprus' relates to the southern part of the island. There is no single authority representing both Turkish and Greek Cypriot people on the island. Türkiye recognises the Turkish Republic of Northern Cyprus (TRNC). Until a lasting and equitable solution is found within the context of the United Nations, Türkiye shall preserve its position concerning the 'Cyprus issue'.

2 Note by all the European Union Member States of the OECD and the European Union: The Republic of Cyprus is recognised by all members of the United Nations with the exception of Türkiye. The information in this document relates to the area under the effective control of the Government of the Republic of Cyprus.

3 The statistical data for Israel are supplied by and under the responsibility of the relevant Israeli authorities. The use of such data  by  the  OECD  and/or  the  IEA  is  without  prejudice  to  the  status  of  the  Golan  Heights,  East  Jerusalem  and  Israeli settlements in the West Bank under the terms of international law.

4 Individual data are not available and are estimated in aggregate for: Burkina Faso, Burundi, Cabo Verde, Central African Republic, Chad, Comoros, Djibouti, Gambia, Guinea, Guinea-Bissau, Lesotho, Liberia, Malawi, Mali, Mauritania, Sao Tome and Principe, Seychelles, Sierra Leone and Somalia.

5 Individual  data  are  not  available  and  are  estimated  in  aggregate  for:  Afghanistan,  Bhutan,  Cook  Islands,  Fiji,  French Polynesia, Kiribati, Macau (China), Maldives, New Caledonia, Palau, Papua New Guinea, Samoa, Solomon Islands, TimorLeste, Tonga and Vanuatu.

6 Individual  data are not available and are estimated in aggregate for: Anguilla, Antigua and Barbuda, Aruba, Bahamas, Barbados, Belize, Bermuda, Bonaire, Sint Eustatius and Saba, British Virgin Islands, Cayman Islands, Dominica, Falkland Islands (Malvinas), Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and Grenadines, Saint Maarten (Dutch part), Turks and Caicos Islands.

China: Includes (The People's Republic of) China and Hong Kong, China.

Emerging market and developing economies: All other countries not included in the advanced economies regional grouping.

Eurasia: Armenia,  Azerbaijan,  Georgia,  Kazakhstan,  Kyrgyzstan,  the  Russian Federation (Russia), Tajikistan, Turkmenistan and Uzbekistan.

Europe: European Union  regional  grouping  and  Albania,  Belarus,  Bosnia  and Herzegovina, Gibraltar, Iceland, Israel,  Kosovo, Montenegro, North Macedonia, 7 Norway,  Republic of Moldova, Serbia, Switzerland, Türkiye, Ukraine and United Kingdom.

European Union: Austria, Belgium, Bulgaria, Croatia, Cyprus, 5,6 Czech Republic, Denmark, Estonia, Finland,  France, Germany, Greece,  Hungary, Ireland,  Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovak Republic, Slovenia, Spain and Sweden.

Latin America: Central and South America regional grouping and Mexico.

Middle  East: Bahrain,  Islamic  Republic  of  Iran  (Iran),  Iraq,  Jordan,  Kuwait, Lebanon, Oman, Qatar, Saudi Arabia, Syrian Arab Republic (Syria), United Arab Emirates and Yemen.

North Africa: Algeria, Egypt, Libya, Morocco and Tunisia.

Other  Africa: Angola,  Benin,  Botswana,  Burkina  Faso,  Burundi,  Cabo  Verde, Chad, Côte d'Ivoire,  Djibouti,  Cameroon,  Central  African  Republic,  Democratic Republic of the Congo, Comoros, Eritrea, Ethiopia, Equatorial Guinea, Gabon, Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Kingdom of Eswatini, Lesotho, Liberia, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Republic of the Congo (Congo), Rwanda, Sao Tome and Principe, Senegal,  Seychelles,  Sierra  Leone,  Somalia,  South  Sudan,  Sudan,  United Republic of Tanzania (Tanzania), Togo, Uganda, Zambia and Zimbabwe.

North America: Canada, Mexico and United States.

Southeast  Asia: Brunei Darussalam,  Cambodia,  Indonesia,  Lao  People's Democratic  Republic  (Lao  PDR),  Malaysia,  Myanmar,  Philippines,  Singapore, Thailand and Viet Nam. These countries are all members of the Association of Southeast Asian Nations (ASEAN). Timor-Leste joined ASEAN on 26 October 2025 and is excluded from this grouping for this publication, but is included in aggregate within the overarching Asia Pacific excluding China group.

## References

IEA. (2021). The Role of Critical Minerals in Clean Energy Transitions. Retrieved from https://www.iea.org/reports/the-role-of-critical-minerals-in-clean-energy-transitions

IEA. (2026). Manufacturing and Trade Model Documentation. Retrieved from https://www.iea.org/reports/manufacturing-and-trade-model

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual M ember countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject to the IEA's work is licenced under International Licence.

<!-- image -->

Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA - March 2026 Cover design: IEA Photo credits: © Getty Images

Revised version s : April and July 2026 Information notice found at: www.iea.org/corrections