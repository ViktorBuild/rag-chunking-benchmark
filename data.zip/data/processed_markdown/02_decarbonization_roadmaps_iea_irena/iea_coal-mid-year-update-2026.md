---
document_id: iea_coal-mid-year-update-2026
title: "Iea Coal-Mid-Year-Update-2026"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_coal-mid-year-update-2026.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Coal Mid-Year Update 2026

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 14 Association countries and beyond.

## IEA M ember countries:

This publication, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Revised version, September 2026 Information notice found at: www.iea.org/corrections

Source: IEA. International Energy Agency Website: www.iea.org

IEA Accession countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Chile Colombia Costa Rica Brazil Israel

Romania

## IEA A ssociation countries:

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Abstract

The current  conflict  in  the  Middle East  has  shaken  global  energy  markets  and supply chains for a range of other key commodities. While disruptions to shipping through the Strait of Hormuz do not directly affect coal supply, coal markets are experiencing knock-on effects from the crisis.

In certain markets, coal is the main alternative to natural gas for power generation. As a result, higher natural gas prices could support coal demand in the electricity sector, which accounts for two-thirds of global coal consumption. In addition, a reassessment of energy strategies is leading some countries and industries to turn to coal, especially coal produced domestically, to reduce their exposure to gas market volatility.

Against a volatile energy backdrop, this mid-year update offers a comprehensive assessment of the latest trends in coal demand, production, trade and prices. It also provides updated forecasts for 2026 and 2027, taking into account recent market dynamics, economic conditions and geopolitical developments - including in China, which continues to drive global coal trends.

## Acknowledgements, contributors and credits

This International Energy Agency (IEA) publication has been prepared by the Gas  and  Coal  Markets  Division  (GCM),  headed  by  Dennis  Hesseling,  who provided useful suggestions and comments throughout the process. Carlos Fernández Alvarez has led and co-ordinated the analysis.

The authors of the report were Stephan Terhorst and Carlos Fernández Alvarez.

Other IEA colleagues provided important contributions, including Marc Casanovas,  Eren  Çam,  Carina  Gwennap,  Najia  Malik,  Gergely  Molnár, Frederick  Ritter  and  Tiffany  Yuan.  Special  thanks  to  Brian  Motherway  for  his comments and guidance.

Timely  and  comprehensive  data  from  the  IEA  Energy  Data  Centre  were fundamental  to  the  report.  Seydou  Dia,  Zuzana  Dobrotkova,  Tony  Goma, Mohamed  Jidril  and  Luca  Lorenzoni  provided  invaluable  support  during  the process.

This report is possible due to the support of the IEA Communication and Digital Office (CDO). Particular thanks go to Liv Gaunt, Poeli Bojorquez, Astrid Dumond, Isabelle Nonain-Semelin, Julia Horowitz, Maria Ahmad and Jethro Mullen. Nicola Clark edited the report.

Our  gratitude  goes  to  the  Institute  of  Energy  Economics  at  the  University  of Cologne (EWI) for sharing its breadth of coal expertise and modelling.

For questions and comments, please contact Carlos Fernández Alvarez (Carlos.Fernandez@iea.org).

<!-- image -->

## Overview

## Global coal demand reached a new record in 2025 …

For the first time in half a century, coal-fired power generation declined in both China 1 and India in 2025, driven by the huge expansion of renewable energy in China and an early, unusually strong monsoon in India. Global steel production the second-largest coal-consuming sector - also fell. Yet the world's coal demand still  rose  by  0.3%  to  8.84 billion  tonnes  (Bt),  a  new  record,  highlighting  how declines  in  some  major  markets  were  offset  by  growth  elsewhere.  In  the United States,  strong  electricity  demand,  higher  natural  gas  prices  and  policy support  drove  an  increase  in  coal  consumption,  interrupting  the  broad  decline seen over the past two decades. Growth also came from coal-intensive industries, including nickel production in Indonesia and coal-to-chemicals in China.

## … and the energy crisis caused by the conflict in the Middle East is set to drive it higher in 2026

Global  energy  markets  have  been  shaken  by  the  ongoing  conflict  in  the Middle East.  Although  virtually  no  coal  shipments  pass  through  the  Strait  of Hormuz - as the Middle East is neither a major producer nor consumer of coal the disruption has nonetheless affected coal markets by pushing up natural gas prices due to the plunge in LNG shipments through the Strait. This has in turn encouraged more coal-fired generation in countries with gas-fired power fleets and spare coal capacity. The effects of higher gas prices have been visible in China, Korea, Japan, Europe and beyond, with regulatory measures reinforcing the shift towards coal consumption in some markets. The use of coal to produce chemical products in China has also risen, with higher oil prices improving the economics of coal-based alternatives. However, the overall impact of this has been limited, since many Chinese coal-to-chemicals plants were already operating at high capacity.

A particularly strong El Niño weather phenomenon in 2026 is also expected to support  coal  demand  by  increasing  cooling  needs  and  reducing  hydropower output  in  some  major  coal-consuming  countries  in  Asia,  such  as  India  and Viet Nam.  The  IEA's  most  recent  annual Coal  Market  Report , published  in December 2025, forecast a small decline in global coal demand this year. But since  then,  upward  revisions  -  mainly  reflecting  the  impact  of  the  Middle East

1 In this report, 'China' refers to the People's Republic of China and Hong Kong (China).

conflict and weather-related factors - have reversed the outlook. This Mid-Year Coal Update now forecasts that global coal demand will grow by 1.2% in 2026, bringing total consumption to 8.94 Bt and marking another record year.

## Coal's path in 2027 remains uncertain

The volatile situation in the Strait of Hormuz makes the outlook for the trajectory of coal demand in 2027 highly uncertain. If LNG flows through the Strait of Hormuz gradually recover towards pre-war levels and natural gas prices settle below 2026 levels,  global  coal  demand  is  forecast  to  fall  by  0.4%  to  8.91 Bt,  but  if  LNG shipments  through  the  Strait  remain  constrained,  global  coal  demand  could increase further.

## Global coal production stayed at a record high in 2025 …

In 2025, global coal production matched the record high of 9.1 Bt set the previous year.  In  China  -  which  accounts  for  more  than  half  of  global  output  -  coal production rose by 1.4%, broadly in line with recent years, bringing the cumulative increase since 2020 to more than 1 Bt. In the United States, output rebounded as coal demand strengthened. India and Australia kept output at roughly the same levels as in 2024, while output edged down in Russia and Indonesia.

## … but will likely contract this year

Global coal production is expected to decline by around 1 % in 2026, although it is  set to remain  above  9  Bt  for  a  third  consecutive  year.  With  the  gap between  production  and  consumption  narrowing,  a  period  of  large  stockpiling globally has ended for now.

In China, production fell in June and July by around 10% year-on-year, the result of  emergency  safety  inspections  triggered  by  a  coal  mine  explosion  in  Shanxi province in May, which was the deadliest accident to occur at a Chinese coal mine in years. Nonetheless, we expect a recovery in production volumes through the end of the year, driven by sustained demand and energy security concerns.

In India, coal production is set to increase by more than 1%, as captive and private mines continue to expand production, while growth in output from Coal India, the country's largest coal producer, is expected to moderate.

In  Indonesia,  production  is  set  to  extend  its  decline  this  year  after  supply outpaced  consumption in 2025 and prices fell. However, stronger-thanexpected demand for  exports has  led  us  to  raise  our  output forecast  slightly from  our December report.

In the United States, coal production is expected to decline by 3%, while demand is forecast to fall by 7%, supporting stock building and increased exports.

In  the  Russian  Federation  (hereafter,  'Russia'),  coal  producers  remain  under severe financial pressure, with many operating at a loss and facing heavy debt burdens. However, higher prices since March have provided some relief.

## Global coal output is forecast to rebound slightly in 2027

As  with  demand,  the  outlook  for  coal  production  in  2027  will  depend  on  the evolution of the conflict in the Middle East. If LNG flows through the Strait recover, global  coal  production  is  expected  to  increase  by  around  0.3%,  reflecting  a rebound in production in China after this year's decline. The increase could be larger if LNG flows remain constrained, providing support for higher natural gas prices and therefore greater coal use. On the other hand, a rebound in LNG flows would reduce demand for internationally traded coal, weighing on production from the  world's  major  exporters.  However,  government  policies  to  expand  coal production are still expected to support further supply growth in some countries, such as India and Kazakhstan.

## Coal trade contracted in 2025 after reaching an all-time high …

As of 2025, demand among major importers like Japan, Korea, Chinese Taipei and the European Union had been in structural decline for several years, reducing their import requirements. Until last year, growth in coal imports by China - the world's  largest  importer  -  had  largely  offset  the  declines  seen  elsewhere. However,  when  Chinese  imports  started  to  ebb  in  2025,  global  coal  trade contracted, and rising imports in parts of Southeast Asia were too small to make up the difference.

## … but disruptions from the ongoing Middle East conflict could push coal trade higher in 2026

Gas-to-coal switching in import-dependent markets, notably Japan and Korea, has led to greater demand for traded coal. At the same time, the Shanxi coal mine accident  in  China  has  tightened  domestic  supply,  particularly  for  coking  coal. Together,  these  factors  have  contributed  to  higher  demand  on  international markets. As a result, we have revised our forecast for global coal trade upwards since  December,  especially  for  thermal  coal  imports.  On  the  supply  side, Indonesia's  lower  production  targets  have  unsettled  thermal  coal  markets. Australia's  producers  appear  best  placed  to  fill  this  gap,  while  tighter  supply conditions may also provide some relief to struggling exporters in Russia.

## Trade volumes are likely to contract in 2027 once gas-to-coal switching eases

In China - and, to a lesser extent, in India - the balance between domestic and imported coal remains highly price sensitive. Together with logistical and quality considerations, this  adds  uncertainty to trade  forecasts for  these  countries.  By contrast,  thermal  coal  trade  patterns  in  Korea,  Japan,  Chinese  Taipei  and  the European Union are currently  easier to forecast.  In  these  regions,  imports  are expected to resume their earlier declines if the gas-to-coal switching associated with  the  Hormuz  crisis  fades.  Overall,  we  expect global coal  trade  volumes to contract  next  year,  with  thermal  coal  trade  falling  more  sharply  than metallurgical coal trade.

## The conflict in the Middle East has supported a recovery in coal prices

Our Coal Market Report published in December 2025 concluded that prices had fallen close to marginal supply costs, indicating the subsequent recovery was a normal market adjustment and not a return to crisis conditions. By February 2026, the Newcastle free-on-board (FOB) thermal coal price had reached USD 115 per tonne, 7% above its December level.

Several factors further supported coal prices in the first half of 2026. Higher natural gas  prices,  linked  to  the  conflict  in  the  Middle East,  made  coal  more  costcompetitive for power generation, supporting coal demand. Export restrictions and regulatory uncertainty in Indonesia added to price pressures, particularly for lowcalorific coal. Meanwhile, safety inspections following the mining accident in China in  May  bolstered  prices,  particularly  for  coking  coal.  Supply  disruptions  at  the Cerrejón mine in Colombia contributed to a tighter Atlantic market.

As a result, FOB Newcastle thermal coal prices averaged USD 139 per tonne in June 2026 before declining slightly to USD 131 per tonne in August. This was up sharply from the depressed levels of late 2025, but still far below the extraordinary highs observed during the 2022 energy crisis, when prices exceeded USD 400 per tonne.

## Demand

## Slight growth of global coal demand in 2025 masked diverging regional trends

Global coal demand rose by 0.3% in 2025 to 8.84 billion tonnes (Bt), narrowly surpassing the previous year's record high. That modest increase suggested that coal demand had entered a period of broad stability after the rapid growth earlier in the decade.

This global picture, however, masked diverging regional trends. Coal demand in China  was  unchanged  at  4 956 million  tonnes (Mt),  while  India's  fell  by  1%  to 1 299 Mt.  And  yet  for  the  first  time  in  50 years,  both  countries  generated  less electricity  from  coal  than  the  year  before.  China's  coal-fired  power  generation declined in the first half of 2025, despite strong electricity demand, as the rapid uptake of renewable electricity more than met additional demand. Industrial coal use also weakened - with the exception of the coal-to-chemicals sector. China nevertheless remains the dominant force in global coal markets, accounting for more than 56% of consumption. Its power sector alone consumes about one-third of the world's coal, meaning that small changes in Chinese electricity demand, renewables  output  (including  hydropower)  or  coal-plant  utilisation  can  have  a significant impact on global coal demand.

In India, an early, strong and prolonged monsoon lifted hydropower output while reducing  electricity  demand  for  cooling  and  agriculture  and  others.  Coal-fired generation and power-sector coal demand declined as a result, although industrial coal use continued to grow.

By contrast, coal demand in the United States rose by more than 9.5% to 410 Mt. Strong electricity demand, higher natural gas prices and support from the current Administration boosted coal-fired generation, which accounts for 93% of US coal demand. In the European Union, weak wind and hydropower output in the early part of 2025 temporarily increased power-sector coal use in the first quarter. But the longer-term trend continued: coal consumption fell by 6%, with decreases in both electricity generation and industry. Mature Asian economies such as Japan, Korea  and  Chinese Taipei  also  saw  coal  demand  decline,  reflecting  the  shift towards lower-carbon power systems and declining industrial use.

Coal-fired power generation remained the main driver of global coal demand in 2025, accounting for 5 954 Mt. Metallurgical coal demand was broadly unchanged from 2024 at 1 174 Mt, despite a decline in steel production.

## Unexpected shocks push global demand higher in 2026

Global coal demand is set to increase by 1.2% in 2026 to reach 8.94 Bt, reversing previous  forecasts  of  a  decline.  The  change  mainly  reflects  the  crisis  in  the Middle East and an unusually strong El Niño weather pattern. Although shipping disruptions  in  the  Strait  of  Hormuz  do  not  directly  affect  coal  markets,  tighter natural gas supply has pushed up prices, prompting some electricity systems to switch  from  gas  to  coal.  This  trend  has  also  been  supported  by  temporary measures allowing greater use of coal-fired generation in some countries. Higher cooling demand and lower hydropower output linked to El Niño have also added to coal use.

China's coal demand is expected to increase by 1% in 2026 to 5 Bt, following the upward revision of earlier forecasts. Coal-fired generation continues to be shaped by growth in electricity demand, hydropower availability and the rapid expansion of solar and wind capacity. Strong electricity demand, weak wind generation and higher liquefied natural gas (LNG) prices have all supported coal use in the power sector. Meanwhile, a spike in oil prices has boosted coal-to-chemicals production, though the effect has been limited because many plants were already operating at  high  load  factors.  Steel  and  cement  production,  which  peaked  in  2020,  are expected to continue declining in 2026.

Coal demand in India is expected to return to its historical growth trend in 2026, following last year's temporary decline. Rising electricity demand will continue to support coal use in the power sector, despite the rapid expansion of renewable capacity. El Niño conditions can increase cooling needs while reducing hydropower availability, providing a further boost to coal consumption. Industrial demand also remains strong, underpinned by growth in pig iron, direct reduction of iron (DRI) and cement production, the three largest coal-consuming sectors. Overall, India's coal demand is expected to increase by 4.2% to reach 1 353 Mt in 2026.

Coal demand in Japan is expected to decline slightly, by 1% in 2026 to 161 Mt, as weaker  industrial  consumption  is  partially  offset  by  modest  growth  in  power generation. Although nuclear and renewable generation are expected to increase, driven by solar photovoltaic (PV) expansion, higher natural gas prices linked to the Middle East crisis have supported coal-fired generation beyond what would otherwise have been expected. A government decision to remove restrictions on coal-fired power plants eligible for capacity payments will provide further support to coal generation.

In Korea, coal demand is now expected to rise by 6% to 119 Mt, reversing previous expectations of a decline. Low nuclear availability and higher natural gas prices have boosted coal-fired generation, which jumped 30% year-on-year in the first

quarter of 2026. However, the restart of nuclear reactors later in the year could slow this trend by reducing reliance on coal-fired power generation.

In Chinese Taipei, coal demand remains constrained by gas-fired generation and the  transition  towards  low-carbon  energy.  However,  the  end  of  nuclear  power generation has heightened concerns over energy security.

Among members of the Association of Southeast Asian Nations (ASEAN), growth in coal demand is set to continue in 2026, reaching around 574 Mt. This will be driven  mainly  by  the  power  sector,  particularly  in  Indonesia  and  Viet Nam.  In Indonesia, the region's largest coal consumer, coal remains the backbone of the electricity  system,  especially  for  captive  power  plants  serving  energy-intensive industries  including  nickel,  cement  and,  increasingly,  aluminium  production.  In Viet Nam, coal-fired generation remains a major source of electricity supply, with demand supported by heatwaves and the need to replenish coal stocks. El Niño conditions could provide further support for coal use by increasing cooling demand and  reducing  hydropower  output.  Elsewhere  in  Southeast Asia,  including  the Philippines and Malaysia, coal demand is expected to remain broadly stable, as existing coal-fired plants are already operating at high load factors.

Coal demand in the United States is expected to decline by 7% in 2026, reversing the temporary increase in 2025. Even so, demand will remain above its 2024 level. Policy support from the current Administration - including emergency orders and the postponement of plant retirements - has slowed the pace of decline. At the same  time,  concerns  about  system  reliability  and  rising  electricity  demand  including from data centres - have helped keep coal-fired plants in operation. That said, coal-fired generation remains under pressure from cheap natural gas and the expansion of renewable capacity, and coal's share of electricity generation is expected to shrink further in 2026.

In  the  European Union,  coal  demand  is  set  to  continue  its  structural  decline, although  the  fall  is  now  expected  to  be  less  pronounced  than  previously anticipated. Total annual coal demand is now expected to reach 276 Mt in 2026. Higher  gas  prices  have  reduced  the  expected  decline  in  countries,  such  as Germany and Poland, where gas generation and spare coal capacity remains available.  Weather-related  events,  such  as  cold  spells,  could  also  temporarily increase  coal  use.  Nevertheless,  the  combination  of  expanding  of  renewable capacity, growing nuclear availability in some markets, policies to phase out coal and weakening industrial demand are expected to reduce coal consumption over the longer term.

Global demand for coking coal is expected to remain broadly stable in 2026, as contrasting regional trends offset one another. India will remain the primary source of growth in metallurgical coal demand, driven by rising pig iron production to meet stronger steel demand. Most of this additional steel output is expected to come

from the blast furnace-basic oxygen furnace (BF-BOF) production route, which relies  on  coking  coal.  In  China,  demand  for  metallurgical  coal  is  expected  to decline very slightly (less than 1%) in 2026, despite continued weakness in the steel sector. Coke production increased in the first half of 2026, helping to support demand.  Across  developed  economies,  coking  coal  demand  is  expected  to decline in 2026, with only a few exceptions, including Germany.

Despite differing regional and sectoral trends, global coal demand is expected to edge higher in 2026. Strong growth in India and Southeast Asia, together with upward revisions to demand forecasts in China, Europe, Japan and Korea, more than offsets the anticipated declines in other advanced economies. The upward revisions largely reflect mostly higher natural gas prices, but also policy measures and El Niño-related weather conditions.

## Global coal consumption and annual growth, 2024-2027

<!-- image -->

IEA. CC BY 4.0.

Notes: EU = European Union, ASEAN = Association of Southeast Asian Nations, JKT = Japan, Korea and Chinese Taipei.

## Global coal demand could decline in 2027 if Middle East tensions ease

If Middle East tensions ease, global coal demand is expected to fall by 0.4% in 2027,  to  8.91 Bt,  which  is  still  above  2025  levels.  Some  of  the  factors  that supported increased coal use in 2026 are projected to fade: the natural gas price premium that encouraged gas-to-coal switching in several power markets should narrow, for example, while expanding renewable generation and cheaper LNG will

put renewed pressure on coal-fired power. As a result, coal-fired generation is expected to decline, and growth in some sectors - particularly coal-to-chemicals production in China - will not be enough to offset the fall.

China remains the dominant driver of global coal demand - and this is unlikely to change for some time. The country's power sector will continue to determine the trajectory  of  coal  demand,  with  consumption  shaped  by  factors  that  include electricity  demand  growth,  hydropower  availability  and  renewable  generation. Following stronger-than-expected coal-fired generation in 2026, coal use in the power sector is expected to decline slightly in 2027 as renewable output expands and  grid  integration  improves  while  electricity  demand  continues  to  grow. Coal-to-chemicals production will continue its expansion, supported by efforts to reduce oil dependence and strengthen energy security. Industrial coal use is likely to decline, albeit slowly, given the challenges of replacing coal in heavy industry and in applications such as silicon or ferroalloys production. Overall, we expect China's coal demand to edge down only marginally, remaining close to 5 Bt.

India is expected to remain a major source of coal demand growth in 2027, as rising electricity demand and industrial activity continue to support consumption. Coal  use  in  the  ASEAN  region  could  also  increase  further,  driven  by  rising electricity demand in countries such as Indonesia, Viet Nam and the Philippines though demand will remain sensitive to weather conditions affecting hydro output, particularly  in  Viet Nam  and,  to  a  lesser  extent,  LNG  prices.  Mature  Asian economies  such  as  Japan  and  Korea,  by  contrast,  are  expected  to  continue reducing  coal  use  as  nuclear  generation  and  renewables  weigh  on  coal-fired power, once gas prices lose their current premium.

In other advanced economies, coal demand is expected to extend its structural decline. In the European Union, expanding renewables generation, coal phaseouts  and  the  fading  of  temporary  natural  gas-price  support  should  continue  to reduce  coal  use.  In  the  United States,  policy  measures  and  delayed  plant retirements may keep higher-than-planned coal capacity available, but coal-fired generation is likely to remain under pressure from renewables and gas. Overall, the balance of risks points to a slight decline in global demand in 2027 - though weather,  fuel  prices  and  energy  security  concerns  remain  key  sources  of uncertainty, particularly given the fragile geopolitical context and the tangled links between major energy fuel and sources.

<!-- image -->

## Production

## Global coal production stayed close to record levels in 2025, led by China and India

In 2025,  global  coal  production  remained  close  to  an  all-time  record,  at 9.1 billion tonnes  (Bt),  as  strong  output  in  China  and  India  offset  declines  in several export-oriented producing countries. Both China and India see domestic coal  production  as  central  to  their  energy  security  strategies.  Following  coal shortages in 2021, both countries sharply expanded their coal output, ramping up supply to historically high levels even as demand did not grow at the same pace and inventories accumulated across the supply chain.

China  remained  by  far  the  world's  coal  largest  producer,  with  output  reaching 4.71 Bt in 2025. The recovery in Shanxi province, after a 2024 mining accident temporarily constrained production, has further bolstered China's coal output. But high  inventories  and  weakening  import  demand  have  reduced  the  incentive  to expand production further.

In India, 2025 coal production hovered at around 1.1 Bt for a second consecutive year, supported by continued efforts to strengthen domestic supply and reduce reliance on imports. Coal India Limited (CIL) remained the backbone of national production, while captive and commercial mines continued to make an important contribution to growth. However, high inventories have started to constrain further expansion: Large pithead stocks and comfortable power-plant inventories reduced the need  to accelerate output further, while growing  domestic  capacity is increasingly  displacing  imports,  particularly  among  electric  utilities  and industrial users.

Indonesia, the world's third-largest  coal  producer  and  the  leading thermal  coal exporter,  saw  output  fall  by  more  than  5.5%  from  its  2024  record,  as  lower international prices and weaker demand from key Asian trading partners reduced incentives to maximise production.

In Australia, output was constrained by mine disruptions due to industrial action and adverse weather and weaker market conditions for metallurgical coal. The United States was a temporary exception to the broader trend, with production rising more than 3 % year-on-year, thanks to stronger domestic demand amid new government policy measures that favour coal-fired generation.

Elsewhere, the outlook in Russia remained uncertain amid ongoing international trade  sanctions,  weak  prices  and  financial  pressure  on  coal  producers  due  to debts accumulated in recent years. South Africa recorded a modest increase in production, but rail and port constraints continued to limit exports. Colombia saw a sharp drop as falling prices and operational disruptions linked to blockades at El Cerrejón mine rail weighed on output.

## Output is expected to dip in 2026 amid abundant inventories

Global coal production is expected to edge lower (-0.7%) from 2025, marking its first  annual  decline  after  several  years  of  growth.  The  dip  reflects  elevated inventories  at  the  end  of  2025  and  policy  measures  that  have  constrained production in several major producing countries.

China remains by far the world's largest producer, with output still expected to exceed 4.62 Bt. The growth of recent years, however, has been constrained by high  inventories,  and  reversed  by  renewed  safety  inspections  following  a  fatal accident  in  May  in  Shanxi  province,  one  of  the  country's  most  important  coalproducing provinces and its main coking coal region. More than 100 mines, with a combined annual capacity of over 100 million tonnes (Mt) were temporarily shut, and only part of that capacity was back online by early June. As a result, coal production in June and July fell by around 10% year-on-year, the steepest drop since 2016. We expect production to recover over the remainder of the year as some idled capacity returns. Even so, healthy inventories at major ports and power plants should limit the need for a broader increase in output.

India's  coal  production  is  expected  to  set  a  new  record  at  1 095 Mt  in  2026, supported by the government's continued efforts to bolster domestic supply and lower  import  dependence.  High  pithead  inventories,  however,  have  tempered output  momentum.  Coal  India  Limited  (CIL),  which  accounts  for  around  threequarters of national production, reported lower figures in May as pithead stocks remained  elevated.  Amid  this  overcapacity,  the  company  has  been  meeting customer demand by drawing down inventories. Thermal coal imports have also fallen, particularly among power plants. Record auction volumes aimed at replacing imported coal underscore the government's commitment to import substitution.

Indonesia is expected to make the largest supply adjustment among the world's major producers in 2026, with output projected to fall by more than 12 Mt (1 5 . %). The government has lowered its coal production target to 641 Mt, well below the previous  year,  creating  fresh  uncertainty  for  both  producers  and  international buyers. At the same time, weaker demand from key Asian importers and higher domestic market obligations - which require more coal to be sold domestically at regulated prices - had lowered production incentives. Ongoing policy discussions

over  export  taxes,  revenue-sharing  arrangements,  mining  permits  and  the possible centralisation of exports through a state-controlled entity have added yet more uncertainty. However, increasing demand owing to the Middle East crisis has improved export perspectives. As the largest flexible supplier of thermal coal to  Asian markets, any reduction in Indonesia's output or export availability has significant implications for seaborne supply.

Australia remains a major supplier of both metallurgical and high calorific value (CV) thermal  coal  to  international  markets.  Domestic  demand,  including  for lignite  in  Victoria,  will  continue  to  support  some  production,  even  as  overall consumption declines. We expect output to reach 452 Mt in 2026, bolstered by a recovery in exports.

Elsewhere, coal production trends are being shaped by a mix of market conditions, logistics constraints and policy changes. Russia's outlook remains uncertain, as trade sanctions, transport bottlenecks and weak profitability continue to weigh on producers, even as its coal remains attractive to some Asian buyers, particularly when offered at discount prices. Output in South Africa is expected to recover only modestly (+2.1%) from 2025 levels, despite rail disruptions on the Richards Bay corridor that continue to limit exports. Production and exports in Colombia are also rebounding from last year's lows, despite temporary disruptions from blockades affecting Cerrejón, the country's largest mine.

In the United States, domestic coal demand is forecast to decline by 7% in 2026, despite  policy  support.  However,  we  expect  production  to  fall  by  only  3%,  as inventory  rebuilding  after  the  2025  drawdown  and  stronger  exports  (driven  by higher international prices) partly offset falling domestic consumption. European Union  coal  production  is  set  to  decline  by  5.3%,  in  line  with  falling demand. A handful of member states still produce lignite, but following the closure of the Czechoslovak Youth Mine (CSM) in the Czech Republic, Poland is now the only remaining producer of hard coal in the bloc.

## Coal output will rebound slightly in 2027, after the fall in 2026

After years of supply growth running ahead of demand, global coal markets are gradually moved closer to balance. However, production is projected to increase slightly by around 26 Mt in 2027 and leaving global output above 9 Bt for a fourth straight year. This moderate upturn reflects a small rebound after the contraction in 2026 driven by Chinese restrictions, as a result of the accident in Shanxi in May. That follows in an ongoing historically high coal output, highlighting the enduring role of domestic coal in the energy systems of major producing countries.

China's coal output is expected to recover in 2027 from the downturn caused by the mining accident in 2026 to stabilise domestic production. Production levels continue to be influenced by domestic demand, the competitiveness of imports and energy-security considerations. India, by contrast, is projected to set another production record, with growth increasingly driven by captive and commercial mines,  while  Coal  India  Limited  adjusts  its  output  in  line  with  demand  and inventory levels. Indonesia is likely to see a further decline in coal production, although the fall should be less pronounced than in 2026 as the slowdown in export demand moderates.

In the United States, coal production is projected to fall further, as the structural decline  in  domestic  demand  outweighs  the  effects  of  higher  exports  and  coalfriendly  government  policy.  Australian  output  is  also  expected  to  edge  lower, constrained by mine-level factors and a limited scope for expanding thermal coal supply.  In  Russia,  production  is  also  likely  to  remain  under  pressure  as  trade sanctions,  weak  profitability  and  high  debt  levels  continue  to  weigh  on  coal producers.  South African  output  could  increase  marginally  if  rail  performance improves, although transport bottlenecks will remain a key constraint. In Colombia, production is expected to stabilise in 2027 following the recovery in 2026, while any boost from the new Administration's more supportive stance toward the coal sector is likely  to materialise  only  over  the  longer  term.  Coal  production  in  the European Union is set to continue its decline as coal demand declines and coal phase-outs advance across the bloc.

<!-- image -->

## Trade

## After a record 2024, global coal trade declined in 2025 as China reduced their imports

Global coal trade retreated in 2025 after hitting an all-time high the previous year, with total imports falling by around 4% to 1.48 billion tonnes (Bt). The decline was concentrated in thermal coal, with weaker demand across most major importing countries reducing trade volumes to around 1.11 Bt. By country, China accounted for  most of the drop: imports there fell from a record 548 million tonnes (Mt) in 2024 to around 495 Mt in 2025 as sluggish demand, strong domestic production and ample inventories curbed the need for foreign coal. India's import growth also stalled, while purchases in Japan, Korea, Chinese Taipei and the European Union extended previous declines. Southeast Asia was the main exception, with resilient demand in several countries helping to offset some of the declines elsewhere.

## Coal imports of selected countries in Asia, 2017-2027

<!-- image -->

All rights reserved.

Source: IEA analysis; includes content supplied by Dow Jones Energy Ltd; Copyright © Dow Jones Energy. All rights reserved.

On the supply side, Indonesia accounted for the largest reduction in thermal coal exports,  with  shipments  falling  to  517 Mt  in  2025  from  557 Mt  in  2024,  mainly reflecting the drop in Chinese imports. Australia's thermal coal exports remained broadly stable at 209 Mt. Colombia's thermal coal shipments dropped sharply to

45 Mt - their lowest level since 2003 - while exports from the United States also declined. Russia, by contrast, maintained thermal coal exports at around 130 Mt, with continued sales to Asian markets offsetting the effects of sanctions, logistical constraints and weak profitability.

Global  trade  in  metallurgical  coal  also  weakened  in  2025,  retreating  from  the record  level  reached  in  2024  amid  softer  coal  demand  for  steel  and  reduced Chinese import requirements. Australia remained the world's largest exporter of metallurgical coal, shipping around 142 Mt, while Mongolia continued to be a key supplier  to  the  Chinese  market.  Russia  and  Canada  also  remained  important suppliers, while shipments from the United States declined from the previous year. As a swing supplier, the US export volumes are sensitive to prices.

## Trade forecasts revised up for 2026 as a result of the Middle East crisis

We now expect global coal trade volumes to edge higher in 2026, contrary to our December  forecast  of  a  contraction,  as  a  result  of  the  ongoing  crisis  in  the Middle East, which has pushed up import demand in some countries as well as a surge in Chinese imports from neighbouring Mongolia.

Seaborne thermal coal demand is projected to fall to around 1 062 Mt in 2026 from about 1 074 Mt in 2025. This is driven primarily by China, whose seaborne thermal coal imports are projected to drop to around 310 Mt from 325 Mt in 2025 as the country draws on its high inventories and increases Mongolian imports.

India and Europe remain the main sources of decline in seaborne thermal coal demand. India's imports are projected to fall to around 160 Mt in 2026 from 167 Mt in 2025, as high inventories and efforts to substitute imports with domestic coal weigh  on  purchases  from  both  utilities  and  industrial  consumers.  In  Europe, however, the main driver is the drop in Türkiye, where we expect a drop of 8 Mt down to 30 Mt, owing to weaker coal demand for power generation.

Stronger demand elsewhere should temper those declines. Japan's imports of thermal coal, for example, are expected to remain firm at around 124 Mt, following an  upward  revision  due  to  the  conflict  in  the  Middle East,  while  Korea's  coal imports are forecast to rise by more than 10% from 2025 amid a series of nuclear outages and higher natural gas prices.

Southeast Asia remains the only major source of sustained import growth, with regional imports of coal expected to increase to around 164 Mt from 156 Mt in 2025, led by Viet Nam, where imports will likely reach 62 Mt, up from 55 Mt last year.  Power generation demand in Viet Nam continues to outstrip domestic coal supply, despite government efforts to encourage production.

Global exports of thermal coal are therefore expected to decline only marginally in 2026, as weaker seaborne trade outweighs higher rail-based exports mainly from Mongolia to China. Indonesia is responsible for much of the decline, with exports projected to fall sharply to around 4 9 5 Mt from 517 Mt in 2025 as weaker demand in key markets weighs on shipments. Indonesian export flows also remain subject to  uncertainty  over  production  targets,  export  policies  and  regulatory  changes, including  the  planned  transition  to  a  new  state-owned  company,  Danantara Sumberdaya Indonesia (DSI), which will eventually oversee all coal exports. The system entered an experimental phase in June and is scheduled to become fully operational in September.

Other major  exporters  are  expected  to  fare  better.  South Africa  should  see  its shipments increase slightly to around 71 Mt, despite recent train derailments and other rail corridor constraints that continue to affect coal flows to Richards Bay, the main exporting port. Australian and Russian exports are forecast to increase to around 216 Mt and 132 Mt, respectively, underscoring their relative resilience amid challenging market conditions.

## Changes in thermal coal exports from selected countries, 2025-2027

<!-- image -->

Meanwhile, global trade in metallurgical coal is poised for a significant jump in 2026. Seaborne demand for metallurgical coal is projected to rise by 16 Mt from 304 Mt in 2025, reflecting stronger demand from India and Indonesia, which is offsetting weaker Chinese seaborne imports and softer demand in Japan, Korea

and Chinese Taipei. Indonesia's coking coal imports are expected to surge by 38% as it ramps up coke exports, meaning that it will overtake China to become the world's largest coke exporter.

The  bigger  story,  however,  is  China's  accelerating  shift  away  from  seaborne supply and towards Mongolia. Mongolian coking coal exports to China by rail are expected  to  surge  more  than  50%  to  around  91 Mt.  Chinese  purchases  from Mongolia,  which  were  already  on  the  rise,  have  jumped  amid  disruptions  to domestic  production  after  a  mining  accident  in  Shanxi  province  in  May prompted temporary  closures  for  safety  inspections.  The  impact  has  been particularly  significant for coking coal, as more than half of Chinese coking coal is produced in Shanxi.

Elsewhere,  Australia  will  remain  the  dominant  exporter  of  metallurgical  coal  exceeding 150 Mt in 2026 - although weather and operational disruptions might continue to constrain shipments. Russia, meanwhile, faces continued pressure from sanctions and logistics bottlenecks as its exports are routed to Asian markets through  Far East  ports.  The  export  volumes  from  the  United States,  a  price sensitive exporter, depend on price levels.

## Changes in metallurgical coal exports from selected countries, 2025-2027

<!-- image -->

## Global coal trade is set to resume its decline in 2027 driven by thermal coal

Despite  the  resilience  of  metallurgical  coal  seen  in  2026,  overall  coal  trade volumes will likely retreat to 2025 levels next year, as shipments of thermal coal continue to decline across much of Asia and Europe. The main driver is China, where demand for imported thermal coal remains weak. Meanwhile, the structural decline  in  imports  by  the  European Union,  Japan,  Korea  and  Chinese Taipei continues unabated. India's thermal coal imports are expected to remain broadly stable, with stronger industrial demand offsetting lower import requirements from the power sector. Southeast Asia remains the only major source of import growth for thermal coal, led by Viet Nam and the Philippines. But this increase is too small to outweigh falling imports in China and other mature import markets.

On the export side, Indonesia is expected to account for the largest decline in thermal coal shipments, reflecting weaker demand from key Asian buyers and rising domestic consumption. Russian exports are also projected to fall, although the outlook remains uncertain given ongoing trade sanctions, logistical constraints and the effect of government support measures. Colombian thermal coal exports are  expected  to  drop  further  amid  weak  Atlantic  demand,  while  exports  from Australia and South Africa remain broadly stable. Taken together, these shifts are expected to reduce global thermal coal exports to around 1 087 Mt.

Unlike thermal coal, metallurgical coal trade is expected to remain broadly stable in 2027. Stronger import demand from India, driven by expanding steel production and limited  domestic  supplies  of  high-quality  coking  coal,  is  expected  to  offset weaker  demand  in  China  and  other  mature  economies.  Australia,  the  largest metallurgical coal exporter, is expected  to capture most  of the resulting increase  in  export  volumes,  while  the  United  States  also  benefits  from stronger  demand.  By  contrast,  Mongolia's  export  outlook  remains  closely tied  to  Chinese  import  demand.

## Prices

## Coal prices have recovered from marginal-cost levels, but remain well below 2022 highs

The  global  coal  market  continued  to  stabilise  in  2025,  following  the  extreme dislocations of the 2022 energy crisis, when thermal coal prices surged above USD 400/t across several major benchmarks. Prices rose in the first half of 2026 but  remained  well  below  those  exceptional  2022  highs.  This  recovery  is  best understood as a rebound from weak year-end 2025 prices, when international coal had fallen close to marginal supply costs. As prices climbed from that floor, the conventional  pricing  relationship  between  coal  grades  held  within  its  historical range, with coking coal continuing to trade at a premium to thermal coal.

By  the  end  of  2025,  many  coal  price  benchmarks  had  fallen  to  levels  that squeezed  producer  margins,  particularly  for  low-calorific  thermal  coal  and Australian coking coal. Against that backdrop, the price recovery in early 2026 reflected an improvement in market fundamentals. By February, the Newcastle free-on-board (FOB) thermal coal prices were 7% higher than in December. Over the following months, benchmark prices strengthened further, if unevenly across regions and coal qualities.

Newcastle  6 000 kilocalories per kilogramme  (kcal/kg) FOB  recovered  from  the weak  levels  seen  in  early  2025  and  was  assessed  at  USD 136/t  by  late August 2026. Indonesian 4 200 kcal/kg FOB rose from USD 45/t at the start of 2026  to  USD 66/t  by  the  end  of  August.  In  metallurgical  coal,  prices  remained below  earlier  highs  but  strengthened  later  in  the  first  half  of  2026.  The  hard coking  coal  FOB  Australia  index  reached  USD  245/t  in  July,  around  30% above 2025 levels.

Several factors have reinforced the recent recovery in prices. Higher gas prices linked  to  conflict  in  the  Middle East  improved  coal's  competitiveness  in  power generation  and  supported  thermal  coal  demand.  Regulatory  uncertainty  and export-related measures in Indonesia - the world's largest thermal coal exporter - added further upward pressure, particularly in the low-calorific segment. In the Atlantic basin, Colombia's Cerrejón mine, a key supplier of thermal coal to Europe, declared  force  majeure  on  1 June  following  rail  blockades,  tightening  prompt supply to European buyers. In China, a mining accident in Shanxi curbed domestic coal output and supported prices, with a more pronounced impact on coking coal. The loss of some Iranian gas-based steel output may have also increased reliance on coal-based steel production elsewhere, further accentuating metallurgical coal

demand. Intense summer weather conditions linked to El Niño boosted electricity demand across parts of Asia, further supporting coal consumption.

Even so, coal markets in the first half of 2026 remained more stable than during the  crisis years,  with  prices  increasingly  shaped  by  regional  disruptions, weather-related  demand  and  procurement  behaviour  rather  than  by  a  broadbased global shortage.

## Price markers for different qualities of coal, 2022-2026

<!-- image -->

All rights reserved.

Notes: FOB = free on board. Newcastle = Port on the east coast of Australia.

Source: IEA analysis based on data from Argus Media group. All rights reserved (full disclaimer on copyright page).

## International thermal coal prices recovered in the first half of 2026 after weakening through 2024 and 2025

After the sharp correction from the historic price spikes of 2022, global thermal coal prices continued to ease through 2024 and 2025 as supply remained ample and demand growth softened in several key importing markets. Newcastle FOB and  Amsterdam-Rotterdam-Antwerp  (ARA) CIF  (cost,  insurance  and  freight) prices  declined  from  the  higher  levels  seen  in  2024,  while  South China CFR (cost  and  freight)  remained  under  pressure  from  abundant  Chinese  domestic supply  and  rising  stock  levels.  As  a  result,  by  late  2025  major  thermal  coal benchmarks had fallen  close  to  marginal  supply  costs,  particularly  for  lowercalorific  material,  marking  a  clear  shift  away  from  the  crisis-driven  pricing  of previous years.

## Thermal coal price markers, 2024-2026

<!-- image -->

All rights reserved.

Notes: ARA = Amsterdam Rotterdam Antwerp. FOB = free on board. CIF = cost, insurance and freight. CFR = cost and freight.

Source: IEA analysis based on data from Argus Media group. All rights reserved (full disclaimer on copyright page).

The  price  trajectories  of  the  three  main  thermal  coal  benchmarks  diverged somewhat over 2024 and 2025, though all moved lower overall. Newcastle FOB 6 000 kcal/kg remained the highest of the three for most of the period,  trading  around  USD 130-145  per  tonne  through  much  of  2024  before falling towards USD 100/t in early 2025. ARA CIF 6 000 kcal/kg followed a similar downward  path,  while  South China CFR 5 500 kcal/kg  softened  more  steadily, dropping to the lowest of the three benchmarks by mid-2025.

In the first half of 2026, thermal coal prices recovered from those late-2025 lows. Newcastle FOB 6 000 kcal/kg rose to USD 150/t, ARA CIF increased to around USD 130/t, and South China CFR 5 500 kcal/kg also rebounded visibly from its earlier trough. All three benchmarks reached their highest levels on a weekly basis since the start of 2024 by mid-2026.

Although thermal coal prices corrected sharply after the 2021-2023 energy crisis, they did not return to pre-crisis levels and remained structurally higher thereafter. At the same time, observed price volatility  declined from the exceptional levels 2 recorded  during  the  crisis  period.  This  combination  -  elevated  price  levels alongside lower volatility was underpinned by strong coal demand through early 2026. Prices have risen further since early March 2026. This renewed upward

2  In this context, price volatility is defined as evolution of the weekly change in a price index.

movement has triggered a pronounced geographical divergence in weekly price volatility. In Europe, where the ARA benchmark is somehow linked to the volatile Title Transfer Facility (TTF) gas market, weekly price swings surged, approaching the  extremes  seen  during  the  energy  crisis.  Asia  followed  a  different  pattern: steadier growth in coal demand improved conditions for sellers and supported more stable price formation. As a result, short-term movements in Newcastle and  South China  benchmarks  remained  comparatively  subdued,  even  as benchmark prices rose.

## Average weekly price changes and average of thermal coal price markers, 2017-2026

<!-- image -->

All rights reserved.

Notes: ARA = Amsterdam Rotterdam Antwerp. FOB = free on board. CIF = cost, insurance and freight. CFR = cost and freight. Standard deviation has been computed based on weekly average prices.

Source: IEA analysis based on data from Argus Media group. All rights reserved (full disclaimer on copyright page).

The rebound in thermal coal prices in the first half of 2026 therefore reflected a combination  of  recovering fundamentals  and  market-specific  tightening. In Europe, higher gas prices and supply disruptions in the Atlantic basin supported ARA prices.  In  Asia,  stronger  power-sector  demand,  weather-related  cooling needs and selective procurement by utilities supported Newcastle and South China prices. Low-calorific coal also strengthened, partly because regulatory  uncertainty  in  Indonesia  affected  expectations  for  seaborne  supply. Nevertheless,  the  upturn  remained  moderate  and  uneven  across  benchmarks, with  prices  shaped  by  regional  supply  conditions  and  procurement  behaviour rather than a broad-based shortage of thermal coal.

## Coal prices rose moderately after the conflict in the Middle East broke out

Comparing the two crisis episodes shows that international thermal coal prices reacted far more strongly to the outbreak of the war in Ukraine than to the conflict in  the  Middle East.  When  the  full-scale  invasion  of  Ukraine  began  in  2022, ARA prices  rose  sharply,  reflecting  a  severe  gas-supply  shock  to  European energy markets. Reduced Russian pipeline gas deliveries, the European Union's ban on Russian coal imports, weak hydropower output and tight conditions across the European electricity system - worsened by widespread outages in the French nuclear fleet - pushed gas prices higher and reinforced gas-to-coal switching in power generation. Floodings in Australia further tightened coal supply. Since then, new suppliers have entered the global LNG market, and Europe has diversified its import sources, notably through increased LNG imports from the United States. As  a  result,  the  rise  in  thermal  coal  prices  that  followed  the  conflict  in  the Middle East in the end of February 2026 was more moderate and started from a substantially lower price base. In Asian markets - which are more directly exposed to energy trade risks in the Middle East - thermal coal prices also rose, though not to the same extent as after the outbreak of the war in Ukraine.

This suggests that the supply shock differed markedly between the two episodes. The disruption to international coal and gas trade in 2022 was both larger and more immediate than the disruptions experienced in 2026. Although the current conflict  has  driven  coal  prices  higher,  the  reaction  of  international  benchmark prices has been far more muted than in 2022.

## Evolution of the European coal price index: 2022 vs. 2026

<!-- image -->

All rights reserved.

Note: W = Week.

Source: IEA analysis based on data from Argus Media group. All rights reserved (full disclaimer on copyright page).

## Russian coal discounts increased with higher prices

Historically,  thermal  coal  prices  from  Australia  and  South Africa  have  broadly tracked Russian export prices. But that relationship broke down after Russia's fullscale invasion of Ukraine, as sanctions and trade restrictions disrupted market access and increased the commercial and logistical risks associated with Russian coal.  Russian  exports  consequently  traded  at  steep  discounts  to  the  main international benchmarks.

Those discounts narrowed through 2024 and 2025, as global coal prices retreated from crisis-era highs towards more typical market levels. By late 2025, with many international benchmarks approaching marginal supply costs, Russian exporters had  less  scope  to  maintain  large  discounts  without  eroding  their  margins. Throughout 2024 and 2025, Russian coal shipped from eastern ports such as Vostochny remained more competitive than coal exported via Black Sea ports, reflecting better access to Asian buyers and a greater ability to redirect volumes within the Pacific market. Prices for eastern-port Russian prices tracked materially closer to the Australian and South African benchmarks, while Black Sea prices stayed consistently lower for most of the period. This reflected ongoing differences in market access, freight economics and buyer base. Even so, Russian producers continued to face profitability pressures from lower outright price levels, persistent discounts and rising export costs.

## High-caloric-value thermal coal price markers by origin, 2022-2026

<!-- image -->

All rights reserved.

Notes: FOB = free on board.

Source: IEA analysis based on data from Argus Media group. All rights reserved (full disclaimer on copyright page).

In the first half of 2026, Russian coal continued to trade at a discount to Australian and South African  benchmarks,  but  the  gap  increased    as  international  prices recovered from their late-2025 lows. Cost pressures remained a key constraint on Russian  export  competitiveness  in  2026.  Black  Sea  and  Baltic  exports  faced greater  pressure  than  Far  Eastern  cargoes,  reflecting  less  favourable  route economics and market access. As a result, Russian coal remained an important source of supply in regional markets, particularly in Asia, but continued to depend on discounts to stay competitive.

## Coal forward prices are more stable than oil and gas

Throughout  2025,  ARA CIF  coal,  Brent crude oil  and  TTF natural gas  all  traded within  relatively  narrow  ranges  compared  to  the  extreme  volatility  of  2022.  Coal forward prices also pointed to limited expectations of a sharp rebound. Together, these signals suggested that markets had largely moved beyond crisis-era pricing, with coal increasingly valued on fundamentals rather than fears of supply shortages.

This  changed  in  early  March 2026,  when  the  conflict  in  the  Middle  East  sent energy prices higher. Brent crude reacted most sharply, while TTF gas also rose. ARA coal prices increased as well, but by less than the other two fuels. The muted response suggests that coal was affected mainly through its links to gas and power markets, rather than by any direct disruption to European coal supply.

The forward curves suggest that markets viewed the coal-price increase as more limited  and  short-lived  than  the  movements  in  oil  and  gas.  Brent  and  TTF responded more sharply to heightened geopolitical risk, while the ARA coal curve shifted only modestly higher, implying that tighter coal-market conditions were not expected to persist.

Oil and gas forward curves also pointed to a gradual easing from the elevated spot prices  reached  after  the  outbreak  of  the  conflict,  while  still  holding  above  preMarch 2026 levels. By contrast, the coal curve implied a more moderate price path through 2026 and 2027. The comparison highlights that, in the first half of 2026, European coal prices were supported mainly by higher gas prices and powersector demand, while the impact of the Middle East crisis remained far smaller than for other energy commodities.

## ARA coal spot prices and forward curves vs. selected energy commodities, 2025-2027

<!-- image -->

All rights reserved.

Notes: ARA = Amsterdam Rotterdam Antwerp. CIF = cost, insurance and freight. TTF = Title Transfer Facility. Source: IEA analysis based on data from Argus Media group. All rights reserved (full disclaimer on copyright page).

<!-- image -->

## Annex

## Abbreviations and acronyms

API

Argus/McCloskey's Coal Price Index

ARA

Amsterdam, Rotterdam, and Antwerp

ASEAN  Association of Southeast Asian Nations

CFR

cost and freight

CIF

cost, insurance and freight

CIL

Coal India Limited

FOB free on board

IEA

International Energy Agency

OECD Organisation for Economic Co-operation and Development

SCCL

Singareni Collieries Company Limited

USD

United States dollar

## Glossary

Bt

billion tonnes

kcal

kilocalorie

kg

kilogramme

Mt

million tonnes

TWh

terawatt hours

See the IEA glossary for a further explanation of many of the terms used in this report.

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual Member countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject  to  the IEA's Notice  for  CC-licenced  Content,  this  work is licenced under  a  Creative  Commons  Attribution  4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area. Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

Where Argus Media is identified as the source of data or information published by the IEA, Argus makes no warranties, express or implied, as to the accuracy, adequacy, timeliness, or completeness of its data or IEA 's presentation of that data, or its fitness for any particular purpose. Argus shall not be liable for any loss or damage arising from any party's reliance or use of such data, and disclaims any and all liability related to or arising out of use of the data to the fullest extent permissible by law. Views or opinions set out in this report are not approved by or necessarily representative of the views or opinions of Argus Media.

Although some of the data are supplied by IEA Member-country governments, largely on the basis of information they in turn receive from oil companies and/or third party data suppliers, neither these governments, oil companies, nor the thirdparty data suppliers necessarily share the Secretariat's views or conclusions as expressed in Coal Mid-Year Update 2026 . The Coal Mid-Year Update 2026 is prepared for general circulation and is distributed for general information only. Neither the information nor any opinion expressed in the Coal Mid-Year Update 2026 constitutes an offer, or an invitation to make an offer, to buy or sell any securities or any options, futures or other derivatives related to such securities.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Revised version, September 2026 Information notice found at: www.iea.org/corrections

Typeset in France by IEA - September 2026 Cover design: IEA Photo credits: © Shutterstock

<!-- image -->