---
document_id: iea_electric-car-markets-in-a-time-of-uncertainty
title: "Iea Electric-Car-Markets-In-A-Time-Of-Uncertainty"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_electric-car-markets-in-a-time-of-uncertainty.pdf"
tables_detected: 4
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Electric Car Markets in a Time of Uncertainty

An update to the Global EV Outlook 2026

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 14 Association countries and beyond.

## IEA M ember countries:

This publication, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. International Energy Agency Website: www.iea.org

IEA Accession countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Chile Colombia Costa Rica Brazil Israel

Romania

## IEA A ssociation countries:

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Acknowledgements, contributors and credits

This report was prepared by the Energy Technology Policy (ETP) Division of the Directorate of Sustainability, Technology and Outlooks (STO) of the International Energy Agency (IEA).

The project was designed and directed by Timur Gül, Chief Energy Technology Officer.  Araceli  Fernandez  Pales,  Head  of  the  Technology  Innovation  Unit, provided strategic guidance throughout the development of the project. Elizabeth Connelly co-ordinated the analysis and production of the report.

The main authors of the report were (in alphabetical order): Elizabeth Connelly, Mathilde  Huismans  and  Jules  Sery.  Other  IEA  colleagues  that  made  valuable contributions to the report include Teo Lombardo and Leonardo Paoli. Lizzie Sayer edited the manuscript.

,

Laura  Cozzi, Director of Sustainability, Technologyand Outlooks (STO) provided  valuable  insights  and  feedback.

The  IEA's  Communications  and  Digital  Office  provided  support  in  producing the  report,  providing  website  materials  and  promoting  it.  Thanks  go  to  Jethro Mullen, Maria  Ahmad,  Isabella  Batten,  Poeli Bojorquez,  Curtis  Brainard,  Astrid Dumond, Merve Erdil, Grace Gordon, Julia Horowitz, Lucile Wall.

IEA analysis related to electric vehicles is supported by member governments of the CEM Electric Vehicles Initiative.

## Table of contents

| Executive summary..................................................................................................................                                                         |
|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Introduction...............................................................................................................................                                                 |
| The 2026 energy crisis has put EVs in the spotlight ...................................................7                                                                                    |
| Trends in global car markets ..................................................................................................                                                             |
| Global car markets are under pressure in 2026..........................................................8                                                                                    |
| Electric car sales have grown in more than 90 countries over H1 2026, compared to H1 2025.................................................................................................9 |
| Car exports from China continue to expand while those from other major producing regions have stagnated ...........................................................................15       |
| Implications for the global car industry............................................................................... 19                                                                  |
| Incumbent car makers are losing market share........................................................19                                                                                      |
| Automotive component supply chains are changing.................................................21                                                                                          |
| Employment at risk in incumbent car-making regions ..............................................24                                                                                         |
| Drivers of change and future strategies.............................................................................. 26                                                                    |
| Annex....................................................................................................................................... 31                                             |

## Executive summary

## Electric car sales prove resilient despite a weakening global car market

Road transport and electric vehicles (EVs) have been in the spotlight amid the current energy crisis. Road vehicles account for nearly half of global oil use, making the sector particularly exposed to fuel price spikes and supply disruptions. The sector is also a key driver of oil imports in import-dependent regions. Policy and industry responses to the energy crisis - especially those related to EVs have the potential to further accelerate changes in a global car industry that is already in flux.

Electric car sales rebounded in the second quarter of 2026, even as global car sales declined. Sales of electric cars were 4% higher year-on-year (y-o-y) and 35% above the first quarter of 2026. As a result, electric car sales in the first half  of  2026  were  only  slightly  lower  than  in  the  first  half  of  last  year,  as  the increase in second quarter sales almost entirely offset the first-quarter decline. Meanwhile, global car sales were down by around 5% y-o-y in the first half of the year, primarily due to a drop in sales in the world's two largest car markets - China and the United States. Overall, EVs accounted for 24% of global car sales, slightly higher than in the first half of 2025.

Electric car sales are now expected to reach 29% of total car sales worldwide in 2026. In Australia, Brazil, India, Korea and Viet Nam - all sizeable electric car markets - sales have roughly doubled since the beginning of the energy crisis, compared  with  the  same  period  (March-June)  in  2025.  Together  with  strong second-quarter market momentum and policy support for EVs in Latin America, Southeast Asia and Europe, these trends support the expectation that electric car sales will grow around 10% this year, compared to 2025. The pace of recovery of the  Chinese  car  market  remains  the  main  constraint  on  global  sales  growth. Electric car sales in the country are expected to reach similar levels as in 2025, though the EV sales share is expected to grow to more than 60% in 2026.

## Shifting trade flows and intensifying competition are reshaping the global car industry

Surging  car  exports  are  partially  shielding  Chinese  manufacturers  from declining domestic sales. Total car sales in China declined over 20% y-o-y in the first half of 2026 with around 2.5 million fewer cars sold - equivalent to all cars sold in the United Kingdom and the Netherlands in 2025. In response, Chinese

car exports grew by 65% y-o-y in the first half of the year, helping limit the decline in  Chinese  car  production  to  around  6%  y-o-y.  Electric  car  exports  grew  even faster,  increasing  by  over  120%  and  fully  compensating  for  the  decrease  in domestic electric car sales. As a result, the share of electric cars in China's car exports rose from around 35% in 2025 to more than 45% in the first half of 2026.

The rapid rise in Chinese EV exports is creating new market opportunities and  uncertainties. Electric  car  exports  from  China  have  grown  faster  than overseas  sales  of  those  vehicles,  with  the  gap  widening  more  recently;  over 1 million electric car exports from China over the last 18 months have not yet been registered as sales in other countries. While shipping times may explain some of this gap, the scale of the difference points to above-norm inventory build-ups in some  destination  markets.  When  these  cars  will  be  sold,  and  at  what  price, remains an important market uncertainty.

Competition is intensifying in the electric car market, where incumbent car manufacturers are less present. Carmakers operating primarily in the internal combustion engine (ICE) vehicle segment still account for around 98% of ICE car sales, but only around 55% of global electric car sales. Chinese carmakers have expanded rapidly both at home and abroad, including in emerging markets, where they hold a particularly high share of EV sales. With China and other emerging economies  set  to  represent  60%  of  global  car  demand  over  the  next  decade, success in these markets will increasingly determine future market leadership.

## Policy, innovation and partnerships will determine future competitiveness

The  market  success  of  electric  cars  is  transforming  global  automotive supply  chains  and  industrial  structures. Value  is  shifting  from  traditional mechanical components towards batteries, electronics and software, with China occupying a leading position across much of the battery value chain. The rise of software-defined  vehicles,  pioneered  by  the  EV  industry,  is  also  creating  new sources  of  competitive  advantage,  while  increasing  pressure  on  incumbent manufacturers and suppliers to adapt. These shifts have significant implications for employment, supply chain resilience and industrial competitiveness.

China's EV leadership reflects decades of industrial policy, innovation and scale. Chinese  manufacturers  benefit  from  integrated  supply  chains,  strong battery  capabilities  and  production  costs  that  are  around  35%  lower  than  in advanced economies. Closing the competitiveness gap will require co-ordinated action by governments and industry, including stable demand signals, support for innovation,  stronger  battery  ecosystems  and  improvements  in  manufacturing efficiency. Automakers are increasingly using joint ventures and strategic alliances to access technology, battery expertise, manufacturing capacity and new markets.

## Introduction

## The 2026 energy crisis has put EVs in the spotlight

The conflict in the Middle East beginning on 28 February 2026 and ensuing energy crisis  has renewed focus on oil use in road transport as a key energy security concern. Road vehicles account for nearly half of global oil use, making the sector particularly  exposed  to  price  spikes  and  supply  disruptions.  Such  an  energy security concern is not new - the oil crises of the 1970s led to the introduction of fuel economy standards in many countries, significantly cutting the average fuel consumption of cars.

Today,  electric  vehicles  (EVs)  are  in  the  spotlight  as  part  of  potential  policy responses, thanks to the opportunity they present to enhance energy security for oil-importing countries while at the same  time shielding consumers  and businesses from price fluctuations. Several governments - particularly in hard-hit, oil -import-dependent regions like Southeast Asia - have introduced temporary tax breaks  for  EVs,  scrappage  schemes  and  fleet  electrification  programmes  to reduce oil use and buffer future fuel price shocks. Elsewhere, there are signs of a reaction  among  consumers  - for  example,  Australia's  ~34%  surge  in  gasoline prices earlier this year coincided with a near-tripling of electric car sales in April 2026 year-on-year.

While  a  lag  in  consumer  responses  and  policy  implementation  means  the  full effects will take time to materialise, the crisis has clearly reinforced the case for EVs as a way to address energy security and fuel cost concerns. The 2026 energy crisis may therefore further accelerate ongoing shifts in global car markets towards more electrification.  However,  these  shifts  could  accentuate  economic  security concerns and potential job losses in car manufacturing in countries that today have sizeable  automotive  industries  focused  on  manufacturing  internal  combustion engine (ICE) cars.

This  short  report  aims  to  provide  market  and  policy  updates  from  the  second quarter (Q2) of 2026 and discusses some of the implications. It builds on findings published  in  the  Global  EV  Outlook  2026  and  the  2025  Energy  Technology Perspectives Special Report What Next for the Global Car Industry?

## Trends in global car markets

The global car industry is being reshaped by three fundamental and concurrent shifts.  The rapid  adoption  of  EVs  is  at  the  forefront,  as  sales  surged to record levels in 2025 with one in every four new cars sold worldwide being electric. At the same time, the geography of car markets is in flux. Sales in traditional markets have plateaued, while they rose in emerging markets and developing economies including the People's Republic of China (hereafter, 'China'), which together now account for about half of global car sales, up from just one-fifth at the start of this century. The third shift is in the location of car manufacturing hubs and trade flows: China's output has increased by more than 50% during the past decade, propelling it to become the world's largest car exporter in 2024 as output in many advanced economies stagnated. Collectively, these three shifts mark a pivotal moment for the automotive sector, and the extent and pace of electrification will be especially critical in shaping the industry's future trajectory.

## Global car markets are under pressure in 2026

At the global level, car sales rose for decades until 2017, interrupted only by the fallouts of economic crises. After 2017, however, total sales started to decline, gradually at first and then dropping precipitously during the Covid-19 pandemic in 2020. Sales resumed their upward trajectory from 2021, with the recovery in global sales being driven exclusively by electric cars and hybrids. This marks a major technological transition away from pure ICE vehicles.

Across the first six months of 2026, however, global car sales have been under pressure, and the general expectation is for 2026 to register a decline relative to 2025. Two key markets are driving this trend. The first is China, the world's largest car market, which saw a decline in total car sales in the first half of 2026 of over 20% according to the China Passenger Car Association (CPCA), relative to the same period of 2025. In addition to broader macroeconomic pressures, changes in policy are contributing to declining car sales in China: at the beginning of 2026, China's previous trade-in scheme was updated with a reduction in the subsidy available  for  the  most  affordable  cars.  At  30%  year-on-year,  the  drop  in  sales during H1 2026 was larger for conventional cars than for electric cars, for which sales fell by less than 20%. The CPCA expects, as of mid-June 2026, car sales in China to be 14% lower than in 2025. However, there is significant uncertainty, with other industry stakeholders and analysts expecting anything from a 3% to a 20% decline across the full year.

<!-- image -->

IEA. CC BY 4.0.

Notes: ICEV = internal combustion engine vehicle; HEV = hybrid electric vehicle; EV = electric vehicle; FCEV = fuel cell electric vehicle; AEs = advanced economies; EMDEs = emerging markets and developing economies. 'HEV' includes only full hybrid electric cars (FHEV). 'ICEV' includes both conventional ICE cars and mild-hybrid electric cars (MHEV), typically featuring 48V hybrid powertrain architectures. 2026 sales ('2026e') are estimated based on market trends through the first half of 2026. See Annex for regional groupings.

Sources: IEA analysis based on data from Marklines and EV Volumes.

The second major driver of the expected global decline in total car sales is the United States, which saw total car sales fall by over 3% year-on-year in the first half of 2026, despite a rebound in May and June. Across the full year, car sales in the United States are expected to be close to 3% lower than in 2025.

## Electric car sales have grown in more than 90 countries over H1 2026, compared to H1 2025

## Second-quarter 2026 electric car sales grew 4% year-onyear and 35% compared to the first quarter

Over 9 million electric cars were sold worldwide in the first half of 2026, with more than 5 million sold in the second quarter alone. Global second-quarter sales were 35% higher than first-quarter sales in 2026, but were not sufficient to compensate for the decline in the first quarter: across the first six months of 2026, global electric car sales were around 1% lower compared to the same period of 2025. Despite more than 90 countries seeing higher year-on-year sales, the almost 20% drop in electric car sales in China strongly impacted global sales volumes.

While electric car sales dropped at a global level, their share in overall car sales remained strong, including in China, where electric cars represented over 60% of

total car sales in the second quarter of 2026, compared to less than 55% across 2025. Globally, across the first half of 2026, electric cars represented 24% of all cars sold, 1 percentage point higher than in the first half of 2025.

<!-- image -->

Europe recorded the strongest growth in electric car sales of the major EV markets during the first half of 2026. Second-quarter electric car sales were higher than those in the first quarter, resulting in 2026 H1 sales being 30% higher than those in the first half of 2025. Countries with particularly strong sales across the first six months of 2026 include Germany, where 140 000 more electric cars were sold than  over  the  same  period  of  2025,  the  United Kingdom  (+100 000),  France (+95 000),  Italy  (+75 000)  and  Spain  (+40 000).  Across  the  European Union, electric car sales have grown to represent more than 30% of total car sales during the  first  half  of  2026,  compared  to  27%  in  2025.  The  EV  sales  share  in  the United Kingdom has also grown, to 38% in H1 2026.

## Monthly electric car sales across the first half of the year, 2025-2026

Europe

Other Southeast Asia

<!-- image -->

<!-- image -->

Other Asia Pacific (excl. China)

<!-- image -->

China

China

<!-- image -->

<!-- image -->

Latin America

United States and Canada

<!-- image -->

IEA. CC BY 4.0.

Notes: Y-o-y = year-on-year, where the growth in electric car sales between March and June of 2026 is shown relative to those months in 2025. See Annex for regional groupings.

Sources: IEA analysis based on data from EV Volumes, ACEA and CPCA.

In the  United States,  second  quarter  electric  car  sales  exceeded  275 000, representing a 20% increase compared to the first quarter of 2026. However, sales were  about  a  quarter  lower  than  Q2  2025,  in  part  due  to  the  ending  of  the US federal tax credit at the end of the third quarter of 2025. While monthly sales picked up in March 2026, compared to in January and February, sales shares averaged 7%, lower than the average of 10% across 2025.

Outside of the major EV markets, electric car sales in H1 2026 were around 75% higher than in H1 2025. Growth was even higher when comparing the months following the start of the energy crisis: electric car sales from March to June 2026 were more than 80% higher than those during the same period of 2025. Notably, in a number of other sizeable electric car markets: Australia, Brazil, India, Korea and Viet Nam - where sales reached more than 100 000 in the first half of 2026 sales have roughly doubled in the period since the beginning of the energy crisis, compared with the same period (March-June) of 2025. Smaller markets have also seen  remarkable  year-on-year  growth  over  this  period,  including  Colombia (+300%), New Zealand (+180%), Singapore (+110%) and Uruguay (+170%).

As a result, electric car sales in Latin America more than doubled in H1 2026 compared  to  the  same  period  of  2025  and  increased  by  around  130%  when comparing  March-June.  Sales  across  Australia,  Korea  and  New Zealand  also doubled year-on-year during the first half of 2026. In India, H1 sales were up over 90%, and in Southeast Asia, H1 sales were 75% higher in 2026 than in 2025. In Africa, sales more than doubled, reaching over 30 000, with sales in South Africa growing more than fivefold and sales in Egypt more than threefold.

## Policy responses to the energy crisis include support for EVs

Following the start of the conflict in the Middle East, a number of countries have implemented response measures aimed at reducing transport energy demand, especially  in  the  near-term.  These  measures  have  included  fuel  rationing, promotion of teleworking, carpooling and the use of public transport, as well as increased biofuel blending with gasoline and diesel.

In  addition,  some  countries  have  recently  announced  policies  aimed  at  more structural  changes  that  would  support  the  adoption  of  EVs  over  conventional ICEVs.  For  instance,  countries  including  the  Netherlands  and  Ireland  have announced  scrappage  schemes  through  which  consumers  are  incentivised  to trade in relatively old conventional cars for the purchase of a new electric car. Other countries,  such  as  the  United Kingdom  and  Australia,  have  included  EV charging infrastructure support as part of their emergency responses. Nevertheless, most announced EV-related policies focus on promoting near-term adoption. However, China's Ministry of Transport has set a 2030 target for electric trucks to reach 40% of heavy truck sales in the country.

## EV-related policy announcements since the start of the conflict in the Middle East

| Country                   | Date announced   | Policy description                                                                                                                                                                                                                                                                                                                                            |
|---------------------------|------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Asia Pacific              |                  |                                                                                                                                                                                                                                                                                                                                                               |
| Australia                 | 12 May           | A fuel resilience package includes tax benefits for electric cars and funding to roll out kerbside fast chargers and accelerate the electrification of Australia's postal delivery fleet.                                                                                                                                                                     |
| Cambodia                  | 29 March         | Reductions in customs tariffs and export-import duties were introduced for selected items including EVs and charging equipment.                                                                                                                                                                                                                               |
| Lao PDR                   | 13 March         | Prime Ministerial Order No. 40/PM and subsequent Memorandum of Understanding aims to promote the nationwide use of EVs.                                                                                                                                                                                                                                       |
| Lao PDR                   | 12 May           | The government is temporarily suspending the import of fuel-powered vehicles until the end of 2026 and introducing EV tax incentives.                                                                                                                                                                                                                         |
| Thailand                  | 20 April         | The government is providing THB 5 billion (Thai baht) for a soft loan programme, including for EV purchases.                                                                                                                                                                                                                                                  |
| Viet Nam                  | 14 April         | The government is drafting a resolution to extend preferential excise tax rates for EVs through the end of 2030.                                                                                                                                                                                                                                              |
| Europe                    |                  |                                                                                                                                                                                                                                                                                                                                                               |
| European Union            | 17 July          | The European Commission presented an Electrification Action Plan aimed at accelerating cost-effective electrification across transport, industry and buildings. Actions related to road transport electrification include strengthening public procurement, supporting accelerated roll-out of charging infrastructure and enabling vehicle-to-grid charging. |
| France                    | 10 April         | Public funding for electrification will increase from EUR 5.5 billion to EUR 10 billion per year by 2030, which includes the renewal of the social leasing programme for electric cars.                                                                                                                                                                       |
| Hungary                   | 19 June          | The revised Recovery Plan includes a component on sustainable transport which includes objectives related to deploying zero-emission buses, supporting company uptake of EVs and financing the roll-out of EV charging stations.                                                                                                                              |
| Ireland                   | 3 June           | The ICE2EV pilot scrappage scheme offered EUR 5 000 for 2 000 eligible applicants scrapping ICEVs first registered in 2013 or earlier, to be used for the purchase of a new battery electric car.                                                                                                                                                             |
| Netherlands               | 20 April         | A trade-in scheme is being introduced for individuals with low incomes who wish to trade in their petrol or diesel car for a second-hand electric car.                                                                                                                                                                                                        |
| Spain                     | 20 March         | Income tax deductions for the purchase of electric and fuel cell vehicles and the installation of charging points have been extended until 31 December 2026.                                                                                                                                                                                                  |
| United Kingdom            | 21 April         | Plans to introduce legislation to increase EV charging provision in new buildings and those undergoing major renovations, as well as to give renters and leaseholders greater access to charging by making it easier to request and install charge points.                                                                                                    |
| Africa                    |                  |                                                                                                                                                                                                                                                                                                                                                               |
| Kenya                     | 22 May           | Presidential announcement that 100 000 EVs will have import duties waived.                                                                                                                                                                                                                                                                                    |
| Rwanda                    | 14 April         | Government of Rwanda directive requires all public institutions to ensure that at least 30% of newly procured vehicles are electric.                                                                                                                                                                                                                          |
| Americas                  |                  |                                                                                                                                                                                                                                                                                                                                                               |
| Brazil                    | 23 June          | The government approved additional zero-tariff import quotas for CKD and SKD electric and hybrid vehicle kits for a period of six months beginning from 1 July 2026.                                                                                                                                                                                          |
| California, United States | 13 July          | The Governor of California signed a bill that creates a new instant rebate programme for zero-emissions cars and is part of a broader USD 600 million investment in clean transportation.                                                                                                                                                                     |
| Chile                     | 23 March         | The Chile Moves Forward Plan includes preferential credit for taxis and buses to switch to EVs.                                                                                                                                                                                                                                                               |

## Regional dynamics have shifted slightly in a weaker car market, but global EV sales are expected to continue to grow in 2026

Uncertainty is the watchword for global car markets for the remainder of 2026, as the combination of economic pressures in key car markets, cost pressures on the car industry and the prospect of continued volatility in fuel prices cast doubts over the pace at which global car sales could recover. Overall, we expect car sales to rebound somewhat over the second half of the year, but - over the course of 2026 as a whole - to remain around 2% below the level reached in 2025. Global electric car  sales,  meanwhile,  are  expected  to  grow  around  10%  in  2026,  reaching 23 million  and  a  share  of  29%  of  total  car  sales.  This  represents  an  upward revision of the global EV sales share by 1 percentage point from the estimate published in the Global EV Outlook 2026 (GEVO-26) in May 2026, although the overall global growth is similar.

This  upward  revision  reflects  strong  market  momentum  in  some  of  the  newly emerging electric car markets during the second quarter of 2026, including in Latin America, Australia and New Zealand, India, and, to a lesser extent, Southeast Asia. Policy support in these markets and in Europe also plays a role. Further global  growth  is  held  back  by  the  overall  decline  in  the  car  market  in  China; expected  2026  electric  car  sales  have  been  revised  down  from  the  estimate released in GEVO-26, to reach similar sales volumes as in 2025 (13.2 million). Nonetheless, the expectation is for EV sales to represent more than 60% of car sales in China across the full year, a new record.

## Global electric car sales by region, 2020-2026e

<!-- image -->

IEA. CC BY 4.0.

Note: 2026e = expected sales in 2026.

Sources: IEA analysis based on data from EV Volumes, ACEA, EAFO and country submissions.

## Car exports from China continue to expand while those from other major producing regions have stagnated

In 2025, the number of cars produced in China reached around 30 million - 10% higher than 2024 and over two-and-a-half times the production levels in 2010. As a result, China's share of global car production exceeded 35% in 2025, up from less than 20% in 2010. Meanwhile, the European Union represented less than 15% of  global  car  production  in  2025,  down  from  around  23%  in  2010.  North America,  on  the  other  hand,  has  maintained  a  similar  share  of  global  car production to 2010, at less than 20%.

In 2023, although China produced over twice as many cars as the European Union,  car exports were  similar. However,  after overtaking the European Union  to  become  the  world's  largest  car  exporter  in  2024,  China exported over 65% more cars than the European Union the following year. China is  the  only  major  car-producing  region  that  has  seen  significant  growth  in  car exports this decade, as growth in car production (+50%) has exceeded growth in domestic car sales (+25%).

<!-- image -->

Car exports from China grew 65% over the first half of 2026 compared to the same period  the previous  year,  as  OEMs  looked  to  overseas  markets  to  help compensate for lower domestic sales. By the end of June, Chinese car exports had reached over 5 million since the start of 2026, whereas exports during the same  period  of  2025  were  closer  to  3 million.  As  a  result  of  this  growth,  car

production in China fell only around 6% year-on-year over the first half of the year, despite domestic car sales falling by over 20%. Exports of ICE cars grew more slowly than electric car exports and, as a result, the share of electric cars in China's car exports increased from over 35% in 2025 to over 45% in H1 2026. Notably, electric car exports from China have grown over 120% over the first six months of 2026,  fully  compensating  for  the  decrease  in  domestic  electric  car  sales. Meanwhile, ICE car wholesales were down roughly 15% during the first half of 2026,  as  increased  exports  did  not  fully  compensate  for  depressed  domestic sales.

## Domestic vehicle sales and exports from China, 2025-Q2 2026

<!-- image -->

Notes: Q = quarter; NEV = new energy vehicles (includes battery, plug-in hybrid and fuel cell electric vehicles); ICEV = internal combustion engine vehicle (includes non-plug-in hybrid electric vehicles). Wholesale sales refer to factory-level shipments by automakers to dealers and other distribution channels, including vehicles for export. Source: IEA analysis based on data from China Association of Automobile Manufacturers (CAAM).

<!-- image -->

Exports of electric cars from China have increased faster than sales of those cars, rising more than 120% year-on-year versus just 75% during H1 2026. We estimate that, across the last 18 months, over 1 million electric car exports from China were not yet registered as sales in other countries. While it can take months for carcarrying vessels from China to reach their destination markets, it is likely that, given the sheer number, there are also inventories of electric cars from China building up in various export markets.

## Electric car exports from China and overseas sales by region, 2025-H1 2026

<!-- image -->

## Overseas sales by region

<!-- image -->

Other Asia Pacific

Rest of World

IEA. CC BY 4.0.

Note: H = half. Estimates of June 2026 sales are used to fill data gaps; when combined for relevant countries, this represents less than 15% of the monthly overseas sales of Chinese exports. Sources: IEA analysis based on data from CAAM and EV Volumes.

Chinese imports have accounted for a rising share of total electric car sales in several markets over the first half of 2026. While they have held fairly steady in the European Union in H1 2026, at around 20%, Chinese imports have continued to grow in the United Kingdom, particularly driven by increased sales of Chery and BYD models.

Outside  of  Europe  and  the  United States,  electric  car  imports  from  China represented 55% of total electric car sales, and in some cases have been driving up sales growth. In South Africa, electric car sales increased around sixfold yearon-year across the first half of this year, and Chinese imports grew to represent 90% of all the new electric cars sold in the country. Similarly, in Argentina, electric car sales have been accelerating ever since BYD entered the market in 2025. Electric car sales in Argentina reached around 9 000 during the first half of 2026 alone, compared to less than 2 200 across all of 2025, with BYD imports alone representing close to 90% of sales so far this year. Although the share of Chinese EV imports in Australia and New Zealand has only increased modestly, from 70% to  80% from H1 2025 to H1 2026, Chinese import volumes have grown 140% year-on-year - faster than electric car sales have grown in the region.

## Share of Chinese imports in electric car sales during the first half of the year in selected markets, 2025-2026

<!-- image -->

IEA. CC BY 4.0.

Notes: H = half. June 2026 imports for Argentina and South Africa are estimated. Source: IEA analysis based on data from EV Volumes.

## Implications for the global car industry

## Incumbent car makers are losing market share

The drop in global car sales during H1 2026 has exacerbated pressures on the car industry that have been building up over the past couple of years, driven by regional shifts in global car markets along with the strong increase in electric car sales. Incumbent OEMs operating primarily in the ICE vehicle segment continue to dominate car sales, accounting for close to 90% of sales worldwide. However, they only accounted for about 55% of the fast-growing electric car sales segment in  2025.  Relatively  new  entrants  that  are  focused  on  EV  production  captured around 45% of global EV sales in 2025, up from less than 35% in 2019. Electric car sales continue to grow, and are projected to reach around 50% by 2035 based on the policies in place today. Incumbent carmakers therefore appear set to face challenges from OEMs that are favoured in the EV segment when it comes to future market shares.

## Global car production by carmaker group and headquarters, 2025

## All cars (82.7 million)

<!-- image -->

## Electric cars (21.9 million)

<!-- image -->

IEA. CC BY 4.0.

Note: OEM HQ = original equipment manufacturer headquarters. Source: IEA (2026), Global EV Outlook 2026.

The rapid growth of China's car market over the past two-and-a-half decades has underpinned global regional shifts in car sales; in 2025, China was responsible for 30% of global car sales, up from just 2% in 2000. The more recent rise of Chinese OEMs in the Chinese market means that they have now captured around 25% of new car sales worldwide.

Electric car sales now exceed conventional car sales in China, and so the market share  of  Chinese  OEMs  -  predominantly  EV  makers  -  has  squeezed  that  of foreign OEMs operating in the country. Japanese OEMs have seen their market share in China fall from over 20% in 2019 to 12% in 2025, and the market share of European OEMs in China fell from around 25% to 15% over the same period.

New car sales by location of carmaker headquarters and powertrain in selected regions, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: OEM HQ = original equipment manufacturer headquarters; ICEV = internal combustion engine vehicle, which here includes non-plug-in hybrids; EV = electric vehicle, including battery electric and plug-in hybrid electric. Total 2025 new car sales per region are shown along the top. Sales share refers to the powertrain share in total new car sales. Most sales by foreign OEMs in China are part of joint ventures with Chinese firms, which prior to 2022 was a requirement to enter the market. See Annex for regional groupings.

Sources: IEA analysis based on Marklines and EV Volumes.

The majority of sales by Chinese OEMs are made in the domestic market, but they are also seeing success in overseas EV markets. Despite Chinese OEMs selling more conventional cars overseas than electric cars in 2025, they commanded a far  greater  market  share  of  overseas  electric  car  sales  (close  to  25%)  than overseas  conventional  vehicle  sales  (5%).  In  Latin  America,  which  represents around 5% of global car sales, Chinese OEMs have captured almost 90% of the growing electric car market, far higher than their share in the conventional vehicle market (less than 10%). Similarly, Chinese OEMs are successfully selling electric cars in the Middle East, Southeast Asia and India. Across emerging markets and developing economies (EMDEs) other than China, Chinese OEMs represent 60%

of electric car sales, compared to 10% of conventional car sales. In some markets, such as in Southeast Asia and India, domestic EV makers also hold significant shares of the growing electric car market. In Southeast Asia, for example, electric cars grew to represent around a quarter of total car sales in H1 2026, of which 55% were from Chinese OEMs and 30% by VinFast, an EV maker from Viet Nam.

These markets are increasingly important for the global car industry: China and other emerging economies are projected to represent almost 60% of global car sales by 2035. As such, the prospect of increasing EV sales alongside the growing success of new market entrants - especially EV makers - in EMDEs could have important implications  for the  traditional  OEMs that  have  previously  dominated conventional  car  sales  in  these  markets.  Japanese  OEMs,  for  example,  are particularly present in the conventional car market in India (50%), Southeast Asia (65%), the Middle East (55%) and Latin America (25%), but hold negligible shares of the electric car market in these regions. Similarly, European OEMs represent 35% of Latin America's conventional car market, but only around 5% of its EV market.  The  success  of  EV  makers  from  China  and  other  emerging  producer countries  in  these  markets  could  echo  the  success  of  Chinese  OEMs  in  the Chinese market, with similar implications for incumbent OEMs.

In line with these ongoing changes, the inflation-adjusted revenues of the world's 26 largest carmakers have decreased since 2018. In 2025, automaker revenues declined 2% after a 4-year-long period of growth. Meanwhile, total industry profits fell 65%, largely driven by profit losses at European and North American OEMs, which were not offset by an increase in the profits of Japanese OEMs. Global profits  dropped  below  levels  last  seen  in  2020,  when  automotive  markets worldwide were severely disrupted by the pandemic. However, in this instance, the drop in profits is attributable to accounting adjustments rather than a drop in sales volumes.

However,  despite increasing competition, incumbent  OEMs  retain  several enduring  advantages,  including  deep  brand  recognition,  global distribution networks, and strong positions in premium segments, where margins are highest and competition is less intense. Importantly, they continue to dominate ICE sales, which are likely to remain substantial for some time.

## Automotive component supply chains are changing

The market success of electric cars in recent years is reshaping car manufacturing processes more broadly. Vehicle component supply chains have historically been regionally clustered systems centred around mechanically engineered parts for ICE vehicles. They are now shifting to highly globalised, battery-centric networks dominated by materials, electronics and chemistry - with China currently at the

core. This transition creates both risks for incumbent suppliers and opportunities for new entrants and regions able to build competitive battery supply chains.

In particular, EVs require very different components to ICEVs, leading to reduced demand  for  traditional  components  such  as  engines  and  gearboxes,  and increased  demand for  batteries,  electronics  and  critical  minerals.  Around  onequarter  of  an  electric  car's  value  relates  to  its  battery,  which  is  the  key  factor determining  its  difference  in  cost  to  an  ICE  vehicle.  EV-specific  components represented only 10% of the automotive supplier market in 2024, but their share has grown nearly sevenfold since 2019. ICE-specific components hold 20% of the market.  Traditional  Tier  1  (component)  and  Tier  2  (parts)  suppliers  remain important for non powertrain components, which still account for the rest of the -market, but these suppliers face pressure in powertrain segments.

Supply chains for batteries are highly concentrated geographically, especially in China, which dominates production of battery cells and upstream components, and  is  the  leading  exporter  of  EV-related  components.  This  concentration increases exposure to risks such as export controls or supply disruption.

The  restructuring  of  supply  chains  is  also  shifting  where  economic  value  is created; regions with battery capabilities stand to capture more value from EV production, and regions that remain dependent on battery imports, such as the European Union, may lose value. As a result, governments and firms are now seeking to diversify supplies and to boost domestic production, although there can be a trade-off with cost-competitiveness, at least in the initial stages. Nevertheless, most value still lies in vehicle assembly and non powertrain components, limiting -the economic impact of partial import dependence.

At the same time, the transition to EVs is accelerating another structural shift: a move towards software-defined vehicles (SDVs). Battery electric vehicles (BEVs) are mechanically simpler than ICEVs and hybrids, making them more compatible with digitalisation and automation, and pure-play EV makers have pioneered the development  of  SDVs,  in  which  a  growing  share  of  vehicle  functionality  is controlled  and  improved  through  software.  Manufacturers  can  use  over-the-air updates to deploy new features, performance improvements, batterymanagement refinements and cyber-security patches across a vehicle's lifetime. This shift  creates  new opportunities around software, semiconductors, sensors and  connected  services,  but  also  adds  pressure  on  incumbent  suppliers  and automakers to adapt their development processes, partnerships and capabilities beyond traditional mechanical engineering.

## Global market or manufacturing capacity share of selected car components, by company headquarters

<!-- image -->

IEA. CC BY 4.0.

Notes: CAM = cathode active material; HVAC = heating, ventilation, and air conditioning. Regional allocation is based on company headquarters. Non-powertrain and internal combustion engine components refer to market share (2023) for the largest suppliers of each component. Battery cells and components refer to manufacturing capacity share (2024). Source: IEA (2025), What Next for the Global Car Industry?

## Employment at risk in incumbent car-making regions

The car manufacturing industry is a major employer, with a workforce of more than 10 million globally, which  only  adds  to  its significance for policy makers. Employment is concentrated in major car-producing regions, especially China and the  European Union,  which  together  account  for  nearly  half  of  global  car employment, production and value added.

A higher concentration of employees, however, does not equal higher production or  gross  value  added.  Nearly  60%  of  employees  are  based  in  EMDEs,  which capture 50% of global production and 40% of gross value added. This reflects the importance of labour-intensive vehicle component  manufacturing in these economies, as well as a lower level of automation.

## Car manufacturing employees by region, 2010-2024

<!-- image -->

IEA. CC BY 4.0.

Notes: AEs = advanced economies; EMDEs = emerging markets and developing economies. Employment in 'car' manufacturing includes a subset of ISIC Division 29, as well as an estimate of electric vehicle battery manufacturing jobs (from ISIC Division 27) - see the source below for details. Figures for 2024 are estimated for some countries. Source: IEA (2025), What Next for the Global Car Industry?

Automation,  robotisation  and  the  integration  of  artificial  intelligence  (AI)  are reducing the need for lower-skilled and repetitive tasks in car manufacturing. While these  technologies  create  demand  for  some  higher-skilled  roles,  these  are typically fewer in number, potentially resulting in a net reduction in employment. High  automation  of  production  can  help  countries  with  higher  labour  costs  to remain competitive on the global market. In 2021, Korea had the highest robot density in the automotive industry, with 1 robot for every 3.5 employees, nearly twice as many as in Germany, Japan and the United States (over 6.5 employees per robot), and almost 4 times higher than in China (13 employees per robot), although China is catching up.

In addition to 'direct' employment, such as in car assembly, the industry generates 'indirect employment', for example in upstream industries like steel, and services like  retail  or  marketing.  In  2023,  Japan's  automotive  industry  employed almost 900 000  people,  and  as  many  as  1.4 million  when  including  materials  and equipment supply.

Employment  remains  highly  geographically  concentrated  in  clusters,  such  as Detroit  in  the  United States,  Nagoya  in  Japan,  and  Shanghai  in  China.  This clustering can reduce logistics costs and support specialised labour pools, but can also  leave  some  regions  highly  dependent  on  jobs  in  the  sector,  increasing vulnerability to localised economic shocks if production moves elsewhere.

As a result of the shifts underway in the car market, some traditional OEMs, for example those in Europe, have announced significant layoffs in recent years. In 2026 Volkswagen indicated that it may need to cut a further 50 000 jobs by 2030, in addition to the 50 000 reductions previously announced (of which 37 000 have been already made), citing cost pressures and vehicle oversupply in the European market.  Similarly, Ford,  GM  and  Stellantis  have  already  cut  a  combined 20 000 jobs  this  decade  in  the  United States.  Generally,  these  OEMs  have attributed the layoffs to technological changes in the automotive industry, linked to the rise of software-defined vehicles, autonomous vehicles and EVs, and AI.

The overall impact of EV market uptake on employment in different regions is uncertain, but it will depend heavily on supply chain localisation and success in building domestic  EV  manufacturing  ecosystems,  as  well  as  the  pace  of automation.

## Drivers of change and future strategies

## For decades, Chinese policies have targeted building an EV industry and market, powered by battery innovation

China's emergence as an EV powerhouse is rooted in two decades of sustained and comprehensive industrial  policy,  which  fostered  domestic  market  creation, manufacturing  scale,  and  innovation.  EVs  were  featured  in  national  industrial development plans as early as 2001, setting the vision for a domestic industry to reduce  oil  import  reliance  and  challenge  foreign  dominance  in  the  automotive sector. From the late 2000s onward, China rolled out multiple policies to cultivate EV supply and demand, including multi-city demonstration programmes, consumer purchase subsidies, tax exemptions and local incentives (like  privileges in  major cities) to spur early EV adoption. By mandating fleets of 'new energy vehicles' (NEVs), supporting public procurement of electric buses and expanding charging  infrastructure, authorities jump-started  a  domestic  EV  market.  In addition,  supporting regulations  such  as  fuel  economy  standards  were refined, and  a NEV  credit mandate  was  implemented,  which  effectively required automakers to increase the share of NEVs in their domestic passenger car sales. As  a  result,  growing  EV  adoption  has  supported  a  number  of  China's  policy priorities around  industrial  development,  air  pollution  reduction  and  energy efficiency - especially with a view to reducing oil imports.

China's  approach  has  combined  demand  stimulus  with  strong  supply-side support.  The  government offered low-cost financing and subsidies to domestic electric car and battery manufacturers, encouraged joint ventures between foreign and  domestic  firms  that  promoted  technology  transfer,  and  supported  the development of NEV industrial clusters with integrated supply chains. Ambitious targets (such as 5 million NEVs by 2020) and consistent policy signals attracted investment, and innovation policy focused on battery technology to ensure China's competitive  edge.  R&amp;D  programmes  and  patents  in  lithium-ion  batteries  were strongly promoted, and China now leads the world in lithium-ion battery patents. Chinese firms have also spearheaded advances in lithium iron phosphate (LFP) battery chemistry. Thanks to this broad policy support, China's EV market and industry have scaled dramatically, and Chinese firms like BYD, CATL and SAIC have become world leaders in EV and battery manufacturing.

Policy  in  China  has  recently  begun  to  shift  away  from  supporting  EV  scale-up towards  promoting  high-quality  development  of  the  country's  EV  automotive

industry. In 2026, the purchase tax exemption for NEVs was replaced with a 50% exemption, along with new technical requirements determining eligibility. From the beginning of 2028 there will no longer be any purchase tax exemption for NEVs. In  addition,  after  15  years  of  benefiting  from  vehicle  tax  exemptions,  from  the beginning of 2027, plug-in hybrid electric cars - including extended range electric vehicles  -  will  be  subject  to  annual  vehicle  ownership  taxes,  in  the  order  of CNY 360-660 (Yuan renminbi) (USD 50-90). While this policy change does not affect  battery  electric  personal  cars,  ownership  taxes  will  start  to  be  applied  to battery electric commercial vehicles. Finally, new rules published in July 2026 will phase  in  consumption  taxes  on  batteries,  starting  at  2%  in  April  2027  and increasing to 4% in April 2028. As a result, EV manufacturers who produce their own batteries will have the advantage of being able to avoid the consumption tax; for EV manufacturers sourcing batteries externally, the 2% tax rate could increase the cost of producing an electric car by over USD 100 or almost 1%. The taxes apply to mature battery technologies, notably lithium-ion batteries, while sodiumion and solid-state batteries will remain tax free until the end of 2028, providing an incentive to develop and commercialise those technologies.

## Domestic competition made EV manufacturing costcompetitive in China, but manufacturer margins are low

China's electric car industry now enjoys a significant cost advantage over its global competitors,  achieved  through  scale,  integration  and  innovation.  Producing  a battery electric car in China is around 35% cheaper than in advanced economies. This is partly a result of structural factors: labour and operating costs are lower in China, and the country's industrial  logistics  are  highly  efficient,  benefiting  from decades of manufacturing experience.

The EV cost gap is largely driven by China's leadership on battery manufacturing. Battery  packs  account  for  roughly  one-third  of  a  battery  electric  car's  direct production cost, and the gap in average battery prices between China and Europe and North America has grown over the past year. In 2025, EV batteries were about 35% cheaper in China than in Europe, compared to around 30% cheaper in 2024, and are now 30% cheaper than in North America, from 25% in 2024. Chinese battery giants have achieved their cost-competitiveness through massive scale and learning-by-doing, as well as by advancing cheaper chemistries such as LFP. China's integrated domestic supply chain - from mineral refining to cell production to vehicle assembly - further reduces costs by eliminating inefficiencies and import dependencies.

## Decomposition of the production cost gap for lithium nickel cobalt manganese oxide battery cells between China and selected countries and regions, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: LCOP = levelised cost of production. Based on the LCOP, which corresponds to the price that would have to be charged per unit of production to achieve a net present value of zero for a given investment. The 'manufacturing efficiency and automation' cost category is directly proportional to scrap rates and production-line downtime and inversely proportional to automation levels of production processes. Labour in the European Union is calculated as the production weighted average of labour costs in 2024, when the majority of production was concentrated in Poland and Hungary. Indirect manufacturing costs include administration, retail and R&amp;D costs. Energy prices are for the overall industrial sector. Source: IEA (2026), Energy Technology Perspectives 2026.

Intense competition in China's EV market has also pressured manufacturers to streamline  operations,  cut  prices  and  accept  narrower  profit  margins.  For example, BYD reportedly eliminated around 100 000 positions in 2025 to better optimise  costs  and  improve  operational  efficiency.  The  domestic  Chinese  EV landscape is crowded with both established state-backed automakers and dozens of  new  entrants,  including  pure-play  EV  start-ups.  Average  profit  margins  for Chinese automakers are often below those of traditional Western and Japanese rivals.  Chinese  EV  manufacturers  have  prioritised  scaling  up  production  and innovation over short-term profitability, reinvesting earnings to expand capacity, improve technology and undercut competitors on price. This strategy, supported by  patient  domestic  investors  and  government  policies,  has  yielded  dramatic growth in sales and global presence. However, the sustainability of this intense domestic competition has led to suggestions that market consolidation is already underway - with more traditional ICE-focused companies exiting the market first - and may accelerate.

## There are strategies that can help close the competitiveness gap with China

Strengthening EV cost-competitiveness requires a co-ordinated focus on scale, batteries and manufacturing efficiency. Governments can enable this by creating stable demand signals, sharing early stage investment risks and supporting skills -and  innovation,  while  avoiding  permanent  cost  distortions.  For  automakers,

strategies may include prioritising high-volume EV platforms, deepening partnerships across the battery and supplier ecosystem, and adopting cost competitive -chemistries such as LFP, alongside continued R&amp;D. Manufacturing efficiency and automation can account for a large share of cost differences in EV battery manufacturing, which can be closed with experience. Partnerships across the battery value chain - for example through joint ventures to co-locate battery cell plants - can accelerate learning-by-doing and transfer of manufacturing know-how. At the same time, diversifying battery material supply (and boosting recycling) can support long-term resilience and cost control.

Recent policy steps in this direction include Europe's battery support measures, such as the European Union's Battery Booster under the Automotive Package and the  proposed  Industrial  Accelerator  Act,  which  seeks  to  ensure  that  foreign investment in strategic battery and EV value chains brings technology transfer, EU  partnerships  and  supply  chain  integration.  Industry  is  moving  in  a  similar direction with OEMs increasingly entering battery manufacturing joint ventures to localise  cell  supply,  reduce  costs,  secure  technology  access  and  comply  with regional industrial policy.

## Recent announcements reinforce OEM partnerships for EV manufacturing

Recent  announcements  underscore  a  growing  trend  in  strategic  partnerships between global automakers, increasingly centred on leveraging China's cost-competitive EV ecosystem while scaling deployment across major markets. In China, joint ventures remain a key entry point, with foreign OEMs deepening collaborations  with  domestic  partners  to  access  the  large  Chinese  domestic market, manufacturing capacity, supply chains and local market expertise. For example, Stellantis has announced a more than CNY 8 billion project under its joint venture with Dongfeng Group to produce EVs in a factory in Wuhan intended for  sales in the domestic Chinese and export markets. At the same time, such partnerships are being extended internationally, particularly into Europe, where joint  ventures  aim  to  combine  Chinese  technology  and  cost  advantages  with established local distribution networks and after-sales capabilities. For example, a  non-binding  Memorandum  of  Understanding  (MoU)  between  Stellantis  and Dongfeng Group agrees to support the sales and manufacturing of Dongfeng EVs in Europe, leveraging existing production capacity at Stellantis factories. Nissan and Chery have also signed an MoU to explore contract manufacturing in Nissan's Sunderland plant in the United Kingdom. Outside Europe, Renault has partnered with Geely in Brazil to produce and sell EV models, while Malaysia's Proton is using its partnership with Geely to develop and locally assemble EV models for the domestic Malaysian market.

More  broadly, partnerships are evolving beyond  traditional manufacturing alliances  to  encompass a  wider  range  of  activities,  including  joint  engineering, purchasing  and  platform  development.  This  reflects  a  growing  recognition  that competitiveness in EV markets depends not only on vehicle assembly, but also on access to integrated supply chains, battery technologies and software capabilities, such as those enabling aspects of automation. For example, Hyundai Motor Group is expanding collaboration with NVIDIA to advance next-generation autonomous driving technologies.

Recent announcements also highlight a shift  towards the  development of  new business models, with automakers expanding into software-enabled services and forming cross-industry collaborations to accelerate EV deployment and improve profitability. In particular, Ford announced that their European commercial vehicle brand, Ford Pro, is evolving from vehicle manufacturer to 'productivity partner' as part  of  their  strategy  for  Ford  Pro  to  generate  a  quarter  of  its  earnings  from software and services, which includes using connected vehicle data and predictive intelligence to identify issues for their customers before they become problems.

In parallel, the geographic footprint of EV production is expanding into emerging markets,  supported  by  a  combination  of  policy  incentives  and  partnerships between  domestic  and  international  firms.  In  Brazil,  for  example,  a  wave  of announcements  points  to  increasing  localisation  of  EV  manufacturing,  with Chinese OEMs (such as BYD, Great Wall Motors, SAIC and Geely) both investing directly in production  facilities and  leveraging  partnerships  with  incumbent manufacturers (such as General Motors and Renault) to utilise existing capacity. This hybrid approach - combining greenfield investment with joint production - is enabling rapid market entry while limiting upfront costs and risks.

These developments indicate that partnerships are becoming a central pillar of automakers'  EV  strategies.  They  enable  faster  scaling,  facilitate  technology transfer and support market access across regions. At the same time, they reflect intensifying global  competition,  with  Chinese  firms  playing  an  increasingly prominent role not only as manufacturers, but also as providers of technology and industrial ecosystems shaping the next phase of the automotive transition.

## Annex

## Abbreviations and acronyms

ACEA

European Automobile Manufacturers' Association

AEs

advanced economies

BEV

battery electric vehicle

CAAM

China Association of Automobile Manufacturers

CPCA

China Passenger Car Association

CNY

Yuan renminbi

EAFO

European Alternative Fuels Observatory

EMDE

emerging market and developing economy

EUR

Euro

EV

electric vehicle

FCEV

fuel cell electric vehicle

HEV

hybrid electric vehicle

ICEV

internal combustion engine vehicle

LFP

lithium iron phosphate

MoU

Memorandum of Understanding

NEV

new energy vehicle

OEM

original equipment manufacturer

SDV

software-defined vehicle

THB

Thai baht

USD

United States dollar

See the IEA glossary for a further explanation of many of the terms used in this report.

## Regional groupings

Advanced  economies: Australia,  Austria,  Belgium,  Bulgaria,  Canada,  Chile, Colombia, Costa Rica, Croatia,  Cyprus, 1,2   Czech  Republic,  Denmark,  Estonia, Finland,  France,  Germany,  Greece,  Hungary,  Iceland,  Ireland,  Israel, 3 Italy,

1 Note by Republic of Türkiye: The information in this document with reference to 'Cyprus' relates to the southern part of the island. There is no single authority representing both Turkish and Greek Cypriot people on the island. Türkiye recognises the Turkish Republic of Northern Cyprus (TRNC). Until a lasting and equitable solution is found within the context of the United Nations, Türkiye shall preserve its position concerning the 'Cyprus issue'.

2 Note by all the European Union Member States of the OECD and the European Union: The Republic of Cyprus is recognised by all members of the United Nations with the exception of Türkiye. The information in this document relates to the area under the effective control of the Government of the Republic of Cyprus.

3 The statistical data for Israel are supplied by and under the responsibility of the relevant Israeli authorities. The use of such data  by  the  OECD  and/or  the  IEA  is  without  prejudice  to  the  status  of  the  Golan  Heights,  East  Jerusalem  and  Israeli settlements in the West Bank under the terms of international law.

Japan, Korea, Latvia, Lithuania, Luxembourg, Malta, Mexico, Netherlands, New Zealand, Norway, Poland, Portugal, Romania, Slovak Republic, Slovenia, Spain, Sweden, Switzerland, Türkiye, United Kingdom and United States.

Africa: Algeria, Angola, Benin, Botswana, Cameroon, Côte d'Ivoire, Democratic Republic  of  the  Congo,  Egypt,  Equatorial  Guinea,  Eritrea,  Ethiopia,  Gabon, Ghana,  Kenya,  Kingdom  of  Eswatini,  Libya,  Madagascar,  Mauritius,  Morocco, Mozambique, Namibia, Niger, Nigeria, Republic of the Congo (Congo), Rwanda, Senegal,  South  Africa,  South  Sudan,  Sudan,  United  Republic  of  Tanzania (Tanzania),  Togo,  Tunisia,  Uganda,  Zambia,  Zimbabwe  and  other  African countries and territories. 4

Asia Pacific excluding China: Southeast Asia regional grouping and Australia, Bangladesh, Democratic People's Republic of Korea (North Korea), India, Japan, Korea, Mongolia, Nepal, New Zealand, Pakistan, Sri Lanka, Chinese Taipei, and other Asia Pacific countries and territories. 5

Caspian: Armenia,  Azerbaijan,  Georgia,  Kazakhstan,  Kyrgyzstan,  Tajikistan, Turkmenistan, Uzbekistan.

Central and South America: Argentina, Plurinational State of Bolivia (Bolivia), Bolivarian  Republic  of  Venezuela  (Venezuela),  Brazil,  Chile,  Colombia,  Costa Rica,  Cuba,  Curaçao,  Dominican  Republic,  Ecuador,  El  Salvador,  Guatemala, Guyana,  Haiti, Honduras, Jamaica, Nicaragua, Panama,  Paraguay,  Peru, Suriname, Trinidad and Tobago, Uruguay and other Central and South American countries and territories. 6

China: Includes (The People's Republic of) China and Hong Kong, China.

Emerging market and developing economies: All other countries not included in the advanced economies regional grouping.

Eurasia: Armenia,  Azerbaijan,  Georgia,  Kazakhstan,  Kyrgyzstan,  the  Russian Federation (Russia), Tajikistan, Turkmenistan and Uzbekistan.

Europe: European Union  regional  grouping  and  Albania,  Belarus,  Bosnia  and Herzegovina, Gibraltar, Iceland, Israel,  Kosovo, Montenegro, North Macedonia, 7

4 Individual data are not available and are estimated in aggregate for: Burkina Faso, Burundi, Cabo Verde, Central African Republic, Chad, Comoros, Djibouti, Gambia, Guinea, Guinea-Bissau, Lesotho, Liberia, Malawi, Mali, Mauritania, Sao Tome and Principe, Seychelles, Sierra Leone and Somalia.

5 Individual  data  are  not  available  and  are  estimated  in  aggregate  for:  Afghanistan,  Bhutan,  Cook  Islands,  Fiji,  French Polynesia, Kiribati, Macau (China), Maldives, New Caledonia, Palau, Papua New Guinea, Samoa, Solomon Islands, TimorLeste, Tonga and Vanuatu.

6 Individual  data are not available and are estimated in aggregate for: Anguilla, Antigua and Barbuda, Aruba, Bahamas, Barbados, Belize, Bermuda, Bonaire, Sint Eustatius and Saba, British Virgin Islands, Cayman Islands, Dominica, Falkland Islands (Malvinas), Grenada, Montserrat, Saint Kitts and Nevis, Saint Lucia, Saint Pierre and Miquelon, Saint Vincent and Grenadines, Saint Maarten (Dutch part), Turks and Caicos Islands.

Norway,  Republic of Moldova, Serbia, Switzerland, Türkiye, Ukraine and United Kingdom.

European Union: Austria, Belgium, Bulgaria, Croatia, Cyprus, 5,6 Czech Republic, Denmark, Estonia, Finland,  France, Germany, Greece,  Hungary, Ireland,  Italy, Latvia, Lithuania, Luxembourg, Malta, Netherlands, Poland, Portugal, Romania, Slovak Republic, Slovenia, Spain and Sweden.

Latin America: Central and South America regional grouping and Mexico.

Middle  East: Bahrain,  Islamic  Republic  of  Iran  (Iran),  Iraq,  Jordan,  Kuwait, Lebanon, Oman, Qatar, Saudi Arabia, Syrian Arab Republic (Syria), United Arab Emirates and Yemen.

North Africa: Algeria, Egypt, Libya, Morocco and Tunisia.

Other  Africa: Angola,  Benin,  Botswana,  Burkina  Faso,  Burundi,  Cabo  Verde, Chad, Côte d'Ivoire,  Djibouti,  Cameroon,  Central  African  Republic,  Democratic Republic of the Congo, Comoros, Eritrea, Ethiopia, Equatorial Guinea, Gabon, Gambia, Ghana, Guinea, Guinea-Bissau, Kenya, Kingdom of Eswatini, Lesotho, Liberia, Madagascar, Malawi, Mali, Mauritania, Mauritius, Mozambique, Namibia, Niger, Nigeria, Republic of the Congo (Congo), Rwanda, Sao Tome and Principe, Senegal,  Seychelles,  Sierra  Leone,  Somalia,  South  Sudan,  Sudan,  United Republic of Tanzania (Tanzania), Togo, Uganda, Zambia and Zimbabwe.

North America: Canada, Mexico and United States.

Southeast  Asia: Brunei Darussalam,  Cambodia,  Indonesia,  Lao  People's Democratic  Republic  (Lao  PDR),  Malaysia,  Myanmar,  Philippines,  Singapore, Thailand and Viet Nam. These countries are all members of the Association of Southeast Asian Nations (ASEAN). 7

7 Timor-Leste joined ASEAN on 26 October 2025 and is excluded from this grouping for this publication, but is included in aggregate within the overarching Asia Pacific excluding China group.

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual Member countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject  to  the  IEA's  Notice  for  CC-licenced  Content,  this  work is licenced under  a  Creative  Commons  Attribution  4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area. Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA - July 2026

Cover design: IEA Photo credits: ©

ShutterStock

<!-- image -->