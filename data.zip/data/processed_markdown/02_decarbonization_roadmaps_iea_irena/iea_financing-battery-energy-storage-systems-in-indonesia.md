---
document_id: iea_financing-battery-energy-storage-systems-in-indonesia
title: "Iea Financing-Battery-Energy-Storage-Systems-In-Indonesia"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_financing-battery-energy-storage-systems-in-indonesia.pdf"
tables_detected: 69
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Financing Battery Energy Storage Systems in Indonesia

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 14 Association countries and beyond.

## IEA M ember countries:

This publication, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Revised version, September 2026 Information notice found at: www.iea.org/corrections

Source: IEA. International Energy Agency Website: www.iea.org

IEA Accession countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Chile Colombia Costa Rica Brazil Israel

Romania

## IEA A ssociation countries:

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Abstract

Indonesia's Rencana Usaha Penyediaan Tenaga Listrik (RUPTL) 2025-2034, or Electricity Supply  Business  Plan,  represents  a  concrete  pathway  towards achieving the country's objectives to expand its power sector and integrate lowemissions  generation.  Within  this  framework,  battery  energy  storage  systems (BESS) are  identified  as  critical  elements  of  Indonesia's  future  power  grid.  By strengthening system reliability and stability, facilitating the integration of variable renewable energy, and extending access to low-emissions electricity in isolated regions, BESS can offer essential services which will only become more valuable as  Indonesia's  demand  for  electricity  grows.  However,  deployment  of  the technology  remains  in  its  early  stages  in  the  country  today,  and  meeting  the RUPTL's  objectives  will  require  both  public  and  private  actors  to  significantly scale-up investment.

Against this backdrop, Indonesia needs business models and financing structures that are adapted to its conditions. Constraints on spending by the country's stateowned  utility,  PLN,  mean  that  the  private  sector  has  the  potential  to  play  a significant role in the development of Indonesia's BESS fleet. This report examines how private capital can be mobilised to accelerate BESS deployment across all regions  of  the  country.  Current  risks  associated  with  BESS  development  especially from the perspective of project sponsors and financiers - are identified and addressed through adaptive business models. The analysis also identifies the level of investment needed to complete the RUPTL's BESS pipeline and examines how this spending can be financed. Finally, the report takes a deep dive into the RUPTL by examining the bankability level of archetypal projects and quantifying how these projects can be remunerated.

By identifying the risks and opportunities associated with BESS development in Indonesia, this report aims to support policy makers, regulators, project investors and financiers in creating bankable conditions for the achievement of the RUPTL's battery storage ambitions.

## Acknowledgements, contributors and credits

This report was led by Zoé Hemez under the guidance of Cecilia Tam, Head of the Energy Investment Unit, and Tim Gould, Chief Energy Economist.

The  lead  authors  of  the  analysis  were  Zoé  Hemez  (investment  modelling  and sources of finance), Marta González Rodrigo (business models and regulation) and Inchan Hwang (financial modelling and bankability).

Additional contributions were provided by Yinglun Teng (cost of capital) and Divya Midha (India case study).

Key contributions were made by James Bragg, Shobhan Dhir, Michael Drtil, Teo Lombardo, Grace Henry, Camille Paillard, Max Schoenfisch and Hasti Wiandita. Lorenzo  Maria  Filippo  Albertini,  Lauren  Chan,  Ryan  Cheng  and  Vrinda  Tiwari provided essential support.

The IEA Communications and Digital Office produced the report. Special thanks go to Astrid Dumond (editing and publication), Poeli Bojorquez (visualisations), Liv Gaunt (editing and publication), Isabelle Nonain-Semelin (editing and publication) and Lucile Wall (visualisations). Sincere thanks also go to Erin Crum, who carried editorial responsibility.

This study was completed in partnership with the Ministry of Energy and Mineral Resources (MEMR) Directorate General of Electricity and PT Perusahaan Listrik Negara  (PLN).  The  authors  wish  to  extend  their  sincere  thanks  to  these collaborators for their sustained engagement.  Special  thanks  go  to Axel Priambodo, who co-ordinated the collaboration among the International Energy Agency (IEA), MEMR and PLN.

Numerous experts were consulted and provided valuable information throughout this study, including reviewing drafts of the report. We are very grateful for their engagement throughout the study. The experts consulted include (in alphabetical order of institution):

Mutia Prabawati and Pramudya Arif (Akuo Energy); Atsumasa Sakai and Tristan Knowles  (Asian  Development  Bank);  Avinash  Kumar  (BSES  Rajdhani  Power); Amit  Mohan,  Jon  Campbell-Copp  and  Teun  Geurts (Climate  Fund Managers); Shraddha  Suresh,  Paul  Pulickal  Mathew  and  Daniel  Foster  Morris  (Climate Investment Funds); Hari Solagratia and Harry Gembira (Climate Policy Initiative); Soo Hern Ang, Helge Muenkel and Nattana Pongsriieam (DBS Bank); Muhammad

Kuncoro (Directorate General of Electricity (MEMR)); Thorsten Roobeek (Dutch Ministry of Foreign  Affairs (MBZ));  Augustine  Nyirenda  (Electricity Supply Corporation of Malawi (ESCOM)); Eloïse O'Carroll (European Union delegation to Indonesia);  Sean  Tan  (Gurin  Energy);  Francisco  Laveron  Simavilla  and  Pilar Gonzalez  Fernandez  (Iberdrola);  Johannes  Meusburger  (INCOSC);  Michael Waldron (Independent consultant); Moris Nuaimi (Indonesia Investment Coordinating Board (BKPM)); Ricky Faizal (PT PLN (Persero) - Electricity System Planning  and  Control);  Danan  Wiratmoko  (PT  PLN  (Persero)  -  Finance);  Puti Faraniza,  Rio  Kaswiyanto  and  Agung  Marsallindo  (PT  SMI);  Thibault  L'Huby (Siemens); Shinji Ayuha (Sumitomo Mitsui Trust Asset Management); Liu Siming (Trina Solar); Emi Fatma Widayan and Achmed Shahram (UNOPS ETP); Dacre Purchase and Maya Prabawati (UPC Renewables).

This analysis has been supported by the Clean Energy Transitions Programme, the IEA's flagship initiative to transform the world's energy system to achieve a secure and sustainable future for all.

## Table of contents

| Executive summary..............................................................................................................         | 7                                                                                                                 |
|-----------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Setting the scene: BESS and Indonesia's energy transition.........................................                                      | 13                                                                                                                |
| Introduction to battery energy storage systems........................................................13                                |                                                                                                                   |
| Overview of Indonesia's power sector......................................................................18                            |                                                                                                                   |
| Indonesia's investment landscape............................................................................24                          |                                                                                                                   |
| BESS project implementation in Indonesia.....................................................................                           | 27                                                                                                                |
| Overview of existing business models......................................................................27                            |                                                                                                                   |
| Key regulations for BESS remuneration ...................................................................35                             |                                                                                                                   |
| BESS remuneration in Indonesia .............................................................................43                          |                                                                                                                   |
| Investment needs and financing structures for BESS in Indonesia.............................                                            | 51                                                                                                                |
| Investment needs and sources of finance                                                                                                 | ................................................................51                                                |
| Financing structures for BESS                                                                                                           | .................................................................................62                               |
| Implications for achieving RUPTL 2025-2034 objectives...............................................                                    | 75                                                                                                                |
| BESS as a maturing asset class and Indonesia's pipeline........................................75                                       |                                                                                                                   |
| Ownership and financing of BESS in Indonesia........................................................77                                  |                                                                                                                   |
| Bankability assessment............................................................................................80                    |                                                                                                                   |
| Key recommendations .......................................................................................................             | 90                                                                                                                |
| Strategies for overcoming investment barriers and mitigating risks                                                                      | ..........................90                                                                                      |
| Summary of priority actions......................................................................................97                     |                                                                                                                   |
| Annex ................................................................................................................................. | 100                                                                                                               |
| India case study                                                                                                                        | .....................................................................................................100          |
| Methodology                                                                                                                             | ..........................................................................................................103     |
| Definitions                                                                                                                             | ..............................................................................................................115 |
| Abbreviations and acronyms..................................................................................118                         |                                                                                                                   |
| Units.......................................................................................................................119         |                                                                                                                   |

## Executive summary

## Indonesia's power sector is facing major evolutions in both supply and demand

Demand for electricity in Indonesia is set to rise sharply over the next ten years,  underpinning  rapid  deployment  of  new  generation  capacity  and battery  energy  storage. In  the  International  Energy  Agency  (IEA's)  Stated Energy Policies Scenario (STEPS), electricity demand  rises from nearly 500 terawatt-hours (TWh) in 2025 to nearly 800 TWh by 2035, driven especially by  residential  space  cooling  as  both  urban  and  rural  regions  see  continued economic growth and households see income levels rise. The Electricity Supply Business Plan (Rencana Usaha Penyediaan Tenaga Listrik [RUPTL]) 2025-2034 published by state-owned utility PT Perusahaan Listrik Negara (PLN) addresses demand growth by aiming to install 69 gigawatts (GW) of power capacity, including 6 GW of standalone storage and 3.6 GW of hybrid (solar PV-plus-BESS) capacity. Low-emissions technologies account for less than 10% of PLN's installed capacity in  2025,  but  they  constitute  three-fifths  of  planned  capacity  additions  in  the RUPTL, representing a significant step in PLN's shift away from fossil power. This report considers only the RUPTL 2025-2034 as its scope and does not include additional renewable energy development objectives.

By helping to integrate variable renewable energy, battery energy storage systems (BESS) will be a key enabler of reliable low-emissions electricity supply. BESS can perform a wide range of services that support grid stability and reliability,  improve  the  integration  of  electricity  generated  by  wind  and  solar photovoltaic  (PV)  systems,  and  enhance  access  to  low-emissions  electricity  in isolated  regions.  The  BESS  projects  in  the  RUPTL  satisfy  four  broad  needs: standalone  assets  provide  load  smoothing  and  ancillary  services,  while  hybrid systems  combine  storage  with  solar  PV  generation  to  facilitate  renewables integration and improve access to low-emissions electricity in remote areas.

The  primary  barrier  to  BESS  deployment  in  Indonesia  lies  in  a  limited pipeline of bankable projects, rather than financing constraints. Domestic and  international  capital  markets  have  demonstrated  interest  in  supporting Indonesia's clean energy ambitions, while concessional lenders such as multilateral  climate  funds  and  development  finance  institutions  (DFIs)  have established BESS-specific facilities. However, uncertainty over long-term visibility of  cash  flows  stemming from a lack of BESS-specific regulation, especially for standalone assets, leads current projects to face bankability challenges.

## Current planning indicates a larger role for the private sector, with over 25% of future BESS capacity allocated to independent power producers

PLN is largely tasked with developing standalone battery storage assets that will support the national grid, while hybrid (solar PV-plus-BESS) installations are generally allocated to independent power producers (IPPs). Of  the  roughly  6 GW  of  standalone  battery  storage  outlined  in  the  RUPTL's Accelerated  Renewable Energy  Development  (ARED)  scenario,  nearly  90%  is planned for the regions of Sumatra and Java, Madura and Bali. These regions are the largest in Indonesia according to population, electricity consumption and grid infrastructure development. As a result, these standalone BESS installations will primarily serve as network assets and are closely aligned with PLN's mandate to provide reliable electricity to its customers. Hybrid installations in the regions of Sulawesi and Nusa Tenggara, however, come with additional complexity - in both development and operation - which can benefit from the technical expertise of IPPs.

Constraints on PLN's balance sheet mean that private capital is essential to meet  BESS  deployment  targets. As  Indonesia's  state-owned  utility,  PLN  is mandated to provide reliable power to its customers at tariffs that are regulated by the state's Ministry of Energy and Mineral Resources (MEMR).  Despite maintaining investment-grade credit ratings, the utility's balance sheet relies on government subsidies and equity injections to cover costs and make necessary investments. The participation of IPPs in building out the RUPTL's BESS pipeline is instrumental to meeting investment needs in a financially sustainable manner, especially amid competing priorities for transmission, distribution, and generation infrastructure.  Moreover,  our  analysis  suggests  that  replacing  PLN-run  diesel generation  with  hybrid  (solar  PV-plus-BESS)  installations  could  create  further headroom  and  strengthen  energy  security  for  PLN  by  displacing  the  cost  of imported fuel and reducing exposure to fuel price volatility.

## Completing the RUPTL's battery energy storage system pipeline will require total investment of USD 5 billion

IEA  analysis  shows  that  investment  needs  in  BESS  projects  across  all regions  average  nearly  USD 560 million  annually  from  2026  to  2034. This annual spending lies below the country's total investment in solar PV in 2025, but is  well  above  historical  investment  in  BESS,  implying  a  rapid  acceleration  in spending.  Capital  expenditure,  which  is  determined  by  capital  costs,  grid connection  costs  and  technology  degradation  rates,  varies  according  to  the degree of grid development in each region. In the first half of the RUPTL, one-third of spending  is  concentrated  on  the  island  of Kalimantan  to  support  the development of nearly 0.6 GW of standalone systems for Indonesia's new capital

city,  Nusantara.  By  contrast, the  second half of the RUPTL sees the region of Java, Maduraand Bali account for the largest share (three-fifths) of spending as PLN builds nearly 3.5 GW of storage to address rapid growth in electricity demand in its most populous region.

Despite  being  responsible  for  over  70%  of  total  capacity  additions,  PLN accounts for only 60% of overall BESS spending needs from 2026 to 2034. Cumulative investment for PLN is estimated to reach nearly USD 3 illion by 2034, mainly towards development in the regions of Sumatra and Java, Madura and Bali. Private sector investment accounts for the remaining USD 2 billion. Projects led by IPPs tend to be in more remote and isolated areas, driving up BESS technology and grid  connection  costs  and  leading  those  projects  to  face  more  bankability hurdles than those in Sumatra and Java, Madura and Bali.

Commercial debt accounts for the largest share of financing for the RUPTL's BESS pipeline, though international public financiers are key to bridging gaps  in  bankability  for  first-of-a-kind  projects. Based  on  the  financing structures considered in this analysis, commercial financiers provide an estimated USD 2.5 billion to deploying Indonesia's BESS projects, representing half of total investment needs. Public finance, which generally comes in the form of equity injections from the government of Indonesia, the country's state-backed development bank PT Sarana Multi Infrastruktur (PT SMI), or sovereign wealth funds Indonesia Investment Authority (INA) and Danantara, provides an estimated USD 2.3 billion. International public finance (IPF) from multilateral climate funds, export credit agencies (ECAs), multilateral development banks (MDBs), DFIs or bilateral lending reaches an estimated USD 275 million. Despite accounting for a relatively small share of total investment, the concessional and other favourable terms  associated  with  some  of  IPF  make  it  an  essential  tool  for  crowding  in additional private investment.

Concessional funding is critical to establishing first-of-a-kind projects in the RUPTL,  and  must  be  phased  out  gradually. Grants  and  below-market-rate loans are particularly effective when used to mitigate precise obstacles such as hedging costs to mitigate currency risk or revenue uncertainty in the first few years of operation. Meanwhile, capacity building and technical assistance programmes can support the design of BESS-specific regulation. Our analysis suggests that an estimated USD 460 million in grants and concessional loans from international and domestic public financiers - representing nearly 10% of total investment - is needed.  For  Indonesia's  first  standalone  BESS  projects,  replacing  commercial debt  with  concessional  terms  could  lower  necessary  availability  payments  by around 6%, improving bankability and reducing PLN's financial burden. Concessional funding should be accompanied by clear exit strategies to ensure

capital recycling. Moreover, the use of concessional funding - while important should  not  replace  the  development  of  regulation  that  provides  long-term frameworks for projects to succeed.

## Remaining uncertainties around BESS implementation result in bankability challenges

Regulatory foundations for BESS remuneration have been established, but additional  details  are  needed  to  boost  investor  confidence. Uncertainties around  regulation  and  permitting  are  cited  by the IEA's Cost  of Capital Observatory  as  the  main  drivers  of  the  weighted  average  cost  of  capital  in Indonesia, which lies between 9% and 11% for BESS projects. Initial regulatory frameworks  for  hybrid  installations  have  been  implemented  through  MEMR Regulations 5/2025 and 19/2025 and Presidential Regulation 112/2022. Together, these lay the foundation for IPPs developing hybrid assets to recover costs of both the generation and storage components through the signing of power purchase agreements (PPAs) with PLN. A lack of parallel regulations concerning standalone  BESS  installations  is  currently  the  largest  barrier  to  bankability  for these types of projects.

Business models for BESS remain highly dependent on asset configuration and operational use cases, which in turn directly affect revenue certainty and bankability. Within the scope of BESS projects connected to PLN's electricity network,  two  main  models  are  considered:  full  tolling  schemes  for  standalone BESS,  and  PPAs  for  hybrid  projects.  While  these  structures  provide  revenue visibility,  uncertainties  remain  regarding  their  practical  implementation.  Limited clarity around intended BESS use cases, remuneration for specific services and battery degradation can delay investment decisions, ultimately constraining the pace of BESS deployment.

Financing over 7 GW of BESS will require multiple sources of capital, each playing  a  distinct  and  complementary  role  across  the  capital  stack. Multilateral development banks, DFIs, ECAs and other providers of concessional capital can absorb the project-specific risks that commercial lenders are not yet willing to assume during construction and early market formation. As Indonesia's BESS market matures, commercial financing is critical to replicating successful projects and reducing the state's fiscal burden. The scale at which lenders operate is also an important consideration: local banks, with limited experience financing BESS, are likely to be more cautious on technology and performance risk, while international lenders are more  sensitive to currency and  regulatory risk. A syndicated structure that combines both domestic and international lenders is therefore well suited to addressing the full range of risks for Indonesia's first wave of BESS projects.

## Six guiding pillars for to accelerate BESS deployment

Address regulatory risk by clarifying remuneration structures and technical and  operational  expectations. Investor  and  lender  confidence  in  Indonesia's emerging pipeline of BESS projects depends heavily on visibility over how assets are expected to be used and remunerated. The classification of BESS as network or generation assets, permitting and licensing requirements, and careful integration  of  BESS  into  the  national  grid  code  enable  developers  to  design systems  that  are  well  suited  to  PLN's  needs.  Meanwhile,  financiers  require visibility  over  project  cash  flows  before  being  able  to  provide  capital  to  new projects - this can be addressed through standardised tolling agreements, PPAs and  ancillary  service  procurement  agreements.  Our  analysis  finds  that,  for standalone  BESS,  steady  capacity  payments  of  an  estimated  USD 111  per kilowatt (kW) to USD 297/kW per year would be sufficient to deliver the returns that commercial investors seek. Meanwhile, the addition of battery storage to solar PV projects,  which  ultimately  improves  solar  PV  utilisation  and  facilitates  their integration  into  PLN's  network,  raises  PPA  prices  by  a  range  of  USD 8  per megawatt-hour (MWh) to USD 18/MWh across the RUPTL's main regions.

Prioritise  the  long-term  system  benefits  offered  by  the  first  standalone assets over their short-term profitability. Early standalone BESS projects face bankability challenges, which result from regulatory uncertainty and relatively high financing costs. While Indonesia's first standalone projects may not be profitable in their first years of operation, they will provide long-term grid flexibility that will be essential to maintaining a reliable grid as the country addresses rapidly rising demand for electricity and ambitious targets for the development of renewable generation.

Prioritise financing for the development and construction phases of hybrid projects. While hybrid BESS benefits from well-established regulatory frameworks, the technology remains in its early stages in Indonesia. As a result, hybrid BESS projects struggle to secure financing in phases before the start of commercial operation. Targeted public support, such as guarantees or subordinated  debt  from  international  public  financiers,  can  help  to  unlock commercial lending in subsequent project stages.

Establish pilot projects that clearly demonstrate the range of services BESS can offer. Early pilot projects in the regions with the highest needs for storage can accelerate learning, build investor confidence and demonstrate the full value of BESS services. While standalone projects in Java, Madura and Bali can be used to show  BESS'  role  as  network  assets,  hybrid  projects  in  Sulawesi  can demonstrate  how  BESS  can  be  used  to  improve  utilisation  of  renewable generation assets.

Tailor  concessional  funding  and  technical  assistance  programmes  to address  specific  challenges. Concessional  support  is  essential  to  de-risking early BESS projects, particularly first-of-a-kind projects in the easternmost islands of Indonesia where isolation and small system sizes pose challenges to bankability. Targeted instruments, such as first-loss guarantees, long-tenor loans and grants, can  address  financing  barriers  for  de-dieselisation  projects,  while  technical assistance and capacity building are well suited to projects in regions with more mature grids. However, well-defined exit strategies ensure that future projects do not develop a dependency on concessional capital.

Engage a broad range of stakeholders early and often to demonstrate a longlasting  commitment  to  BESS  development. Visible  alignment  among  key stakeholders in Indonesia is necessary to address political risk, which is perceived in  particular  by  international  developers  and  financiers.  Close  co-ordination between MEMR and PLN will ensure that regulations are well suited to BESS' needs, while regular engagement with developers and capital providers brings technical expertise. Cross-cutting institutions such as Danantara are positioned to facilitate  engagement  across  many  corners  of  the  public  and  private  sectors. Meanwhile, regional co-ordination - especially with other member states of the Association of Southeast Asian Nations (ASEAN) - can strengthen the resilience of supply chains and battery recycling facilities.

## Setting the scene: BESS and Indonesia's energy transition

## Introduction to battery energy storage systems

Battery energy storage systems (BESS) are highly versatile technologies that can provide a variety of services that range from supporting grid stability and reliability, facilitating the integration of variable renewable energy (VRE), and accelerating access to electricity through the development of off-grid systems.

Over the past decade, significant capital cost declines for BESS technologies which  are  largely  based  on  lithium-ion  batteries  -  have  enabled  their  uptake primarily in advanced economies and the People's Republic of China (hereafter, 'China').  However,  emerging  market  and  developing  economies  (EMDE)  including countries in the Association of Southeast Asian Nations (ASEAN) region - are expected to account for a growing share of global BESS investments as they pursue ambitions for the deployment of low-emissions power against the backdrop of rapidly rising demand for electricity. This shift is already well underway, with total investment in utility-scale BESS in EMDE (excluding China) nearly tripling from 2024 to 2025.

## Battery energy storage systems are critical components in developing secure and reliable electricity systems

While lithium-ion batteries have traditionally been used to power small electronic devices  and,  more  recently,  to  electrify  transportation,  utility-scale  BESS  are rapidly becoming an essential component of power systems around the world. By absorbing or injecting active power rapidly, BESS can help maintain reliable and flexible power systems. The main purpose of the grid is to transport electricity from generators to consumers - but to do so successfully, the two must always be in equilibrium.  Power  systems  that  rely  on  conventional,  fossil-based  electricity generation, such as coal and natural gas power plants, have historically maintained equilibrium by ramping electricity generation up or down to match demand.

However, power systems today are evolving as new, low-emissions sources of electricity  generation  such  as  solar  photovoltaic  (PV)  and  wind  account  for  a growing share of electricity supply. These VREs have a limited ability to modulate generation to match demand, creating the need for new sources of energy storage and  grid  flexibility.  While  these  services  have  historically  been  provided  by

pumped hydropower using reservoirs and natural gas peaker plants, BESS have emerged  as  additional  sources  of  storage  and  are  essential  to  maintaining  a secure supply of electricity. As a result of significant technology improvements and manufacturing  capacity  expansion,  the  global  average  cost  of  turnkey  2-hour storage  duration  BESS  declined  by  46%  from  2020  to  2025,  and  costs  are expected to continue declining. The falling cost of BESS, combined with similar trends for solar PV, has led to both standalone storage systems and hybrid (solar PV or wind generation paired with storage) systems to become cost-competitive with conventional thermal generation in many countries around the world.

Today, nearly all utility-scale BESS installations use lithium-ion chemistries, which benefit  from  energy  densities  that  are  four  to  five  times  higher  than  those  of modern lead acid chemistries. Lithium-ion batteries consist of two electrodes, the positive cathode and negative anode, between which lithium ions move to store or  release  energy  as  the  battery  charges  or  discharges.  A  porous  separator prevents  direct  contact  between  the  cathode  and  anode,  while  an  electrolyte enables ions to move between them.

Two  chemistries  of  lithium-ion  chemistries  dominate  the  BESS  market  today: lithium iron phosphate (LFP) and lithium nickel manganese cobalt oxide (NMC). While the high energy density of NMC chemistries makes them well suited for space-constrained  applications,  LFP  batteries  dominate  utility-scale energy storage  installations  due  to  their  lower  costs,  longer  cycle  lives  and  improved thermal stability. Despite the two chemistries accounting for roughly equal shares of global demand in 2020, LFP batteries nearly tripled their share of the market by 2025, now accounting for over 90% of the BESS market globally.

## Advanced battery storage shares of global market by chemistry, 2020-2025 and 2030

<!-- image -->

IEA. CC BY 4.0.

Notes: LFP = lithium iron phosphate. Nickel-based includes lithium nickel cobalt manganese oxide (NMC) and lithium nickel cobalt aluminium oxide (NCA). Others includes chemistries such as sodium-ion and vanadium redox flow. A small share of lithium iron manganese phosphate (LFMP) is included within the LFP category in 2035. The above figure does not include lead-acid chemistries.

A complete utility-scale BESS installation includes much more than the battery cells themselves. Battery cells are assembled into racks, which are stacked within containers to optimise energy density. Battery racks are located inside a system container alongside balance-of-system components,  which  include thermal management and safety systems. Outside the container, components include the power conversion system (PCS), which uses inverters to convert direct current (DC) into alternating current (AC); transformers and switchgear, which connect the PCS at the appropriate grid voltage level; and an energy management system, which controls battery dispatch and interfaces with the system operator. Finally, systems include infrastructure that connects the batteries to the grid or sources of power generation (in the case of hybrid installations).

## Battery energy storage system and associated generation and grid components

<!-- image -->

Notes: Standalone BESS configurations do not include a solar PV generation component. AC = alternating current. DC = direct current.

By charging and discharging electricity quickly and precisely, BESS provide a wide range of services to enhance power-system reliability and flexibility, making them the  multi-tool  of  electricity  networks.  A  primary  function  of  BESS  is  energy arbitrage, in which batteries charge while electricity prices are low and discharge when  they  are  high.  Other  services  such  as  renewables  shifting  and  firming, congestion relief, and the provision of peak capacity help to mitigate curtailment of renewable generation and improve the overall efficiency of power systems.

Another range of BESS functions can be described as ancillary services, in which assets ensure grid stability  and  a  high  quality  of  power  supply.  Fast  response times make batteries particularly suited to rapid frequency response and voltage support. In networks with rising shares of solar PV and wind generation, ancillary services are especially useful for smoothing VRE output over brief (seconds to minutes) time periods to maintain grid stability.

Finally, BESS can serve as highly strategic assets, deferring big-ticket investment in network expansion. In areas where transmission and distribution lines are highly utilised  and  local  electricity  pricing  mechanisms  are  in  place,  BESS  can  help  to relieve bottlenecks during periods of high electricity production or consumption by being located at points with large price differentials. When paired with solar PV or wind generation, BESS can support the development of distributed energy systems and microgrids in isolated areas, accelerating access to decarbonised electricity.

## Summary of battery energy storage system services

| Type                               | BESS service                                                                                                                                       |
|------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------|
| System reliability and flexibility | Wholesale energy arbitrage; renewables smoothing, shifting, and firming; peak capacity reserves                                                    |
| Ancillary services                 | Black-start capabilities; frequency regulation; voltage support; synthetic inertia services; spinning and non- spinning reserves; ramping reserves |
| Grid support and optimisation      | Congestion relief; transmission and distribution grid investment deferral; mini-grids                                                              |

Notes: See Annex for complete definitions of BESS services. For more information regarding BESS services, see IEA (2024), Batteries and Secure Energy Transitions .

## Global deployment of BESS is expanding rapidly

Over the last ten years, global installed capacity of utility-scale BESS increased by an average of 65% annually from 1.6 gigawatts (GW) in 2015 to over 220 GW by the  end  of  2025.  Most  of  today's  BESS  capacity  additions  exist  in  China  and advanced economies. China alone accounted for 60% of cumulative additions over the  last  decade,  while  advanced  economies,  driven  by  the  United  States,  the

European Union and Australia and New Zealand, account for 35%. Even though only 5% of global BESS installed capacity is currently located in EMDE excluding China,  additions  are  rapidly  scaling  up  to  meet  the  dual  challenge  of  rising VRE penetration and increased demand for electricity. For instance, installed BESS capacity in India more than doubled from 2024 to 2025, while Saudi Arabia saw significant  standalone  utility-scale  storage  installations  -  totalling  nearly  3  GW  come online in the same year.

Utility-scale BESS installations exceeded 2 GW across the ASEAN region by the end of 2025. Installed capacity in the region grew by 25% that year, mainly driven by  installations  in  Malaysia  and  the  Philippines.  In  Malaysia,  for  instance,  the 100 megawatt (MW)/400 megawatt-hour (MWh) Lahad Datu BESS in Sabah - one of the largest in Southeast Asia - is helping to enhance grid stability, reduce reliance on diesel and support renewable integration. However, battery storage remains in its early stages in Indonesia: by the end of 2025, approximately 30 MW of capacity were operational in the country. A 5 MW pilot project developed by PT Perusahaan Listrik Negara (PLN) in collaboration with Indonesia Battery Corporation, PT Indonesia Power and PT Pembangkitan Jawa Bali became the country's first operational BESS asset in 2022.

At the same time that global BESS capacity additions have risen significantly, the capital cost of utility-scale systems has declined significantly. The global average capital cost for two-hour-duration storage systems declined by around 46% from 2020 to 2025. These cost declines are largely driven by a significant expansion in battery manufacturing capacity, particularly  in  China,  where  economies of  scale, price competition among domestic producers and manufacturing and technological innovations have pushed costs down. The growing share of LFP chemistries - which are less reliant on expensive materials such as cobalt and nickel - has also placed downward  pressure  on  capital  costs.  A  similar  trend  for  solar  PV  technologies, whose costs went down threefold from 2015 to 2025, is today strengthening the competitiveness of hybrid installations that can turn intermittent renewable energy into firmer sources of power.

Despite capital cost declines, the significant increase in capacity additions has led global  utility-scale  BESS  investment  (including  utility-scale  and  behind-the-meter applications) to rise from roughly USD 1.3 billion in 2015 to USD 78 billion in 2025, and is expected to surpass USD 100 billion in 2026. The largest single share (30%) of  investment  occurred  in  China  at  USD  24  billion,  while  advanced  economies together spent USD 46 billion in 2025, equivalent to 60% of the global total. In 2025, Southeast Asia invested USD 0.6 billion in BESS.

## Historical investment in utility-scale BESS by region, 2020-2025

<!-- image -->

IEA. CC BY 4.0.

Notes: MER = market exchange rate. EMDE = emerging market and developing economies. Sources: IEA analysis based on Bloomberg (2025), Lithium-ion Battery Price Survey and Benchmark Mineral Intelligence (2026) dataset.

As power systems around the world seek to secure their supplies of electricity and increase their shares of low-emissions generation, BESS capacity installations are expected to rise rapidly. Under the International Energy Agency (IEA) Stated Energy Policies Scenario (STEPS), global installed BESS capacity exceeds 1 300 GW by 2035. China and advanced economies continue to account for a significant share of utility-scale BESS capacity, representing 62% and 24%, respectively, of cumulative global  additions  over  the  next  decade.  The  share  of  BESS  capacities  in  EMDE excluding China also rises rapidly from 5% in 2025 to 13% in 2035, driven primarily by India and the Middle East. Capacity in Southeast Asia alone increases by an average of over 20% annually over the next decade.

## Overview of Indonesia's power sector

Today, electricity generation in Indonesia is dominated by coal-fired power plants. However, growing electricity demand, combined with objectives to reduce reliance on fossil fuels, signals major shifts for the Ministry of Energy and Mineral Resources (MEMR) and PLN, the country's primary decision makers on energy strategy.

## PLN's 2025-2034 electricity supply plan sets ambitious goals for renewables and battery energy storage

Power generation in Indonesia today is dominated by fossil fuels, especially coalfired thermal power plants. In 2025, coal accounted for 50% of Indonesia's total installed capacity. Low-emissions power - including solar PV, wind, geothermal and hydropower - together accounted for 16 GW of installed capacity in 2025, an 85%  increase  relative  to  ten  years  previous.  With  hydropower  and  geothermal together accounting for 70% of Indonesia's low-emissions power capacity in 2025, VRE generation today constitutes a relatively small portion of the country's grid mix.

Total sales of electricity by PLN  grew  by  61%  from  2015  to  2025  to 323 terawatt-hours  (TWh),  with  41%  of  generation  in  2025  flowing  towards households. However, by 2034 PLN expects that total electricity sales will exceed 500 TWh, once again growing by 60% relative to 2025 levels. A near-doubling in electricity sales to industrial consumers accounts for 44% of the total growth from 2025 to 2034. Meanwhile, increasing access to electrified space cooling leads nearly 200 TWh of generation to flow towards households by 2034. Indonesia's rapid growth in electricity demand is similar in scale to that of the Southeast Asian region as a whole. In fact, in the STEPS, Southeast Asia is among the world's fastest-growing regions in terms of electricity demand; rising by over 50% from 2025 to 2035.

The Rencana Usaha Penyediaan Tenaga Listrik (RUPTL), or Electricity Supply Business  Plan,  is  Indonesia's  primary  electricity-sector  planning  document. Prepared in  collaboration  with  MEMR  and  PLN,  the  document  establishes  the country's  expected  electricity  demand,  generation  and  transmission  capacity additions, and total investment needs for the subsequent decade. While informed by the Rencana Umum Ketenagalistrikan Nasional (RUKN), or National Electricity Plan,  which  defines  the  country's  long-term  strategy  for  its  power  sector,  the RUPTL more  directly  translates  Indonesian  energy  policy  into  detailed  project pipelines.  The  government  of  Indonesia  has  announced  additional  plans  for renewable  energy  development  outside  of  the  framework  of  the  RUPTL;  most notably a plan to develop 100 GW  of solar PV supported by nearly 150 gigawatt-hours (GWh) of BESS by 2030. However, this report considers solely the RUPTL 2025-2034 in its analysis of BESS and solar PV-plus-BESS additions.

## Indonesia's current grid mix and RUPTL capacity additions (left) and PLN's electricity sales by consumer type as assumed by the RUPTL, 2015-2034 (right)

<!-- image -->

IEA. CC BY 4.0.

Notes: RE Base = Renewable Indonesia Base scenario, ARED = Accelerated Renewable Energy Development scenario. 2025 installed capacity includes captive coal power.

Fossil power includes coal, natural gas, and oil-fired generation. Storage includes battery storage and pumped hydropower. Low-emissions power includes solar PV, wind, geothermal, hydro, and biomass generation.

Source: PLN (2025), RUPTL 2025-2034.

The  document  also  presents  two  cases  for  power  system  development:  the relatively  conservative  Renewable  Indonesia  Base  (RE  Base)  scenario,  which prioritises affordability and grid reliability, and the Accelerated Renewable Energy Development (ARED) scenario, which favours deployment of renewable energy and  targets  carbon  dioxide  (CO2)  emissions  reductions  of  151  million  tonnes compared with business-as-usual conditions. The analysis presented in this report is based on capacity additions outlined in the ARED scenario, which is also aligned with the STEPS.

Indonesia's most recent RUPTL, applying to the period from 2025 to 2034, signals a notable departure from historical trends in the country's power sector. With a strong  emphasis  on  the  deployment  of  low-emissions  power,  the  RUPTL establishes Indonesia's commitment to renewable energy development. In total, PLN  plans  for  the  addition  of  over  42  GW  of  low-emissions  power  by  2035, including 13 GW of solar PV, 7 GW of wind and 5 GW of geothermal power. Nearly 70% of power capacity additions are allocated to independent power producers (IPPs), with the remaining additions to be developed by PLN itself. The RUPTL also  estimates  that  capital  expenditures  totalling  IDR 2 800 trillion  (Indonesian rupiah) - or USD 165 billion - will be needed to complete all power generation and transmission capacity additions outlined in the document.

For  the  first  time,  the  RUPTL  2025-2034  also  outlines  the  additions  of  both standalone and hybrid BESS, thus recognising the role of battery energy storage in  enhancing  grid  stability  and  facilitating  the  integration  of  VRE.  The  ARED scenario adds over 6 GW of standalone BESS, three-fifths of which is located on the islands of Java, Maduraand Bali. These assets are expected to be used mainly to  support  grid  reliability  and  flexibility  through  short-duration  load  smoothing, frequency regulation, and voltage support. Meanwhile, a total of 3.6 GW of hybrid installations, most of which is located on the island of Sulawesi, will be used to optimise  the  utilisation  of  electricity  generated  by  solar  PV  installations.  PLN estimates that, for every 1 GW of solar PV in hybrid installations, between 0.1 and 0.3 GW of BESS will also be added. Finally, a pipeline of projects totalling 0.5 GW on  the  islands  of  Maluku,  Papua  and  Nusa  Tenggara  is  expected  to  support access  to  electricity  in  Indonesia's  most  isolated  regions  by  creating  mini-grid systems and replacing small-scale diesel generation.

## RUPTL regional groupings capacity additions in the ARED scenario

<!-- image -->

Notes: BESS capacity includes standalone additions and the storage component of solar PV-plus-BESS additions. VRE capacity includes solar PV, wind, and the generation components of solar PV-plus-BESS and wind-plus-storage additions. Total final energy consumption refers to the year 2025.

Sources: IEA analysis based on PLN (2025), RUPTL 2025-2034 and PLN (2025), 2025 Statistical Report.

## Indonesia's regulated, single-buyer electricity market makes PLN the most important player in BESS development

Indonesia's electricity sector is characterised by a highly centralised structure, with PLN operating  as  a  vertically  integrated  state-owned  utility  across  generation, transmission, distribution and retail. PLN served more than 80 million households in 2025 and accounts for most of the electricity supply, covering close to 70% of Indonesia's  power  generation.  This  dominant  position  reflects  a  long-standing policy framework in which the state retains control over electricity as a strategic sector.

The current market structure is the result of several reform attempts. Early efforts in  the  2000s  aimed  to  introduce  unbundling  and  competition  were  partially reversed  following  constitutional  rulings  emphasising  the  state's  obligation  to control  electricity  provision.  The  Electricity  Law  30/2009  ultimately  reaffirmed PLN's role as a vertically integrated utility. While IPPs are allowed to participate in generation, their role remains limited to selling electricity to PLN under long-term power purchase agreements (PPAs) and subject to obtaining an electricity supply business licence (Izin Usaha Penyediaan Tenaga Listrik [IUPTL]), which sets the

Setting the scene: BESS and Indonesia's energy transition

framework for market entry and operation. While PLN is not formally designated as the sole off-taker of electricity, it effectively acts as a dominant single buyer in practice,  as  most  electricity  generated  by  IPPs  is  sold  to  the  utility.  This arrangement  centralises  system  operation  and  investment  decisions,  enabling PLN to retain control over dispatch, network development and long-term planning, while limiting the scope for competition beyond generation. The conditions and procedures for obtaining an IUPTL are primarily set out in MEMR Regulation 11/2021  on  the  implementation  of  electricity  business,  within  the broader framework established by Electricity Law 30/2009.

The  regulatory  framework  is  led  by  MEMR,  whose  Directorate  General  of Electricity  (DJK)  oversees  licensing,  tariffs  and  system  planning,  while  the Directorate  General  of  New  and  Renewable  Energy  and  Energy  Conservation (EBTKE) drives renewable  energy  deployment.  Other  government  bodies  also play an important role in shaping the sector. The Ministry of National Development Planning  (BAPPENAS)  coordinates  long-term  infrastructure  and  development planning  across  ministries  and  helps  integrate  electricity  sector  priorities  into national  economic  plans.  The  National  Energy  Council  (DEN),  chaired  by  the President and comprising representatives from government, industry and academia,  is  responsible  for  coordinating  the  implementation  of  the  National Energy Policy (KEN) and aligning energy strategies across government institutions.  Tariff-setting  remains  highly  regulated  and  is  closely  linked  to  the Biaya Pokok Penyediaan (BPP), which represents PLN's per-kilowatt-hour cost of electricity supply. End-user tariffs are benchmarked against the BPP but are not fully cost-reflective  due  to  heavy  subsidisation:  in  2024,  PLN  received  an estimated total  of  IDR  713.5  trillion  (USD  46  billion)  in  subsidies.  Finally,  tariff adjustments are infrequent due to political and affordability considerations, limiting flexibility in response to cost fluctuations.

As  a  result,  PLN  operates  under  a  strong  public  service  obligation  to  ensure universal access and affordability. Regulated tariffs are often below cost-recovery levels, requiring the utility to rely on government support. PLN's financial model therefore  depends  heavily  on  state  subsidies  and  compensation  mechanisms, which  are  managed  by  the  Ministry  of  Finance.  In  practice,  this  reliance  is substantial: in 2022  alone,  subsidy  and  compensation  transfers  from  the government  of  Indonesia  amounted  to  around  IDR  123  trillion  (approximately USD 9  billion). However,  these  transfers  do  not  always  fully  cover  rising operational and investment costs, leading to structural financial pressure. At the same time, PLN faces constraints on its ability to adjust tariffs, optimise spending or expand borrowing, as these decisions are closely supervised by government authorities to maintain fiscal discipline and affordability objectives.

Internally, PLN has been restructured into several sub-holdings, particularly for generation  to  improve  efficiency  and  facilitate  access  to  financing,  notably including  PLN  Nusantara  Power  and  PLN  Indonesia  Power,  as  well  as  subholdings  in  transmission  and  distribution  (PLN  Transmisi  and  PLN  Distribusi, respectively).  The  recent  creation  of  sovereign  wealth  fund  Daya  Anagata Nusantara (Danantara), under Law 1/2025, as a strategic holding entity for stateowned enterprises introduces an additional layer of oversight aimed at improving governance and capital allocation across state-owned enterprises, including PLN. Although its role in the power sector is still evolving, Danantara has the potential to be directly involved in the execution of procurement procedures as well as the funding of selected projects.

## Selected government and PLN stakeholders in Indonesia's power sector

<!-- image -->

Ministry

PLN Subholdings

IEA. CC BY 4.0.

Notes: MoF = Ministry of Finance; MEMR = Ministry of Energy and Mineral Resources; BAPPENAS = Ministry of National Development Planning; DEN = Dewan Energi Nasional; DJK = Directorate General of Electricity; EBKTE: Directorate General of New and Renewable Energy and Energy Conservation; IPP = independent power producer, T&amp;D = transmission and distribution.

Within this centralised framework, the operation of grid infrastructure and system flexibility  assets  remains  largely  under  PLN's  control,  with  limited  participation from private actors beyond generation. In most cases, IPPs are responsible for building  the  power  lines  that  connect  their  storage  assets  to  PLN's  network. Ownership  and  operation  of  these  lines  is  then  transferred  to  PLN  upon

completion.  Private  developers  may  develop  dedicated  transmission  lines  in specific cases - particularly when developing projects in remote areas.

Overall, Indonesia's power sector remains defined by a state-driven, centralised model, where PLN's vertically integrated structure, combined with regulated tariffs and  strong  fiscal  support,  ensures  system  stability  and  affordability  but  limits competitive dynamics. The challenge going forward will be to balance this model with the increasing need for flexibility, private investment and innovation to support the energy transition.

## Indonesia's investment landscape

Indonesia's BESS market presents a combination of large investment needs and unique set of financing conditions supported by strong growth momentum and uncertain global rates environment. This section reviews the macro environment for investment  and  the  financial  position  of  PLN  as  the  key  investor  and stakeholder for Indonesia's BESS sector.

## Macro environment for investing

Indonesia is a large, fast-growing Group of Twenty (G20) economy with relatively deep  domestic  capital  markets,  but  continues  to  carry  the  structural  risks  and institutional constraints for emerging markets. It currently holds investment-grade ratings  from  all  three  major  agencies  at  BBB  from  S&amp;P,  BBB  from  Fitch,  and Baa2 from Moody's. However, both Moody's and Fitch changed their outlook to negative in the first quarter of 2026, citing uncertainty around the financing and governance of Danantara, the new sovereign investment holding company that now oversees PLN among other state-owned enterprises.

Market pricing reflects these concerns. Indonesia's ten-year sovereign yield has risen from around 6% in January 2026 to around 7.0% by June 2026, against a US ten-year  Treasury  yield  of  around  4.5%.  This  spread  of  around  265  basis points  is  the  additional  return  investors  would  demand  for  holding  Indonesian sovereign debt rather than US government debt, compensating them mainly for country risk premium that includes fiscal, policy and currency uncertainty. Over the past decade, the spread has narrowed considerably, but this compression was driven mainly by the rise in US yields rather than a repricing of Indonesian risk. Within 2026, the direction has reversed, with the spread re-widening by close to 70 basis points as markets responded to the rating outlook revisions, currency pressure and fiscal concerns.

10-year bond movement in the United States and Indonesia, 2018 to Q1-2026

<!-- image -->

IEA. CC BY 4.0.

Sources: IEA analysis based on Investing.com (2026), Indonesia 10-year bond yield; Investing.com (2026), United States 10-year bond yield.

Sovereign yields affect clean energy investment as they anchor the cost of debt and the equity return expectations applied to BESS projects in the country. Higher sovereign yields could be translated into higher required capacity payments and PPA tariffs for BESS projects for domestic and international investors.

Despite these conditions, Indonesia is recognised as an important market for longterm asset allocation and the clean energy transition. It is the largest economy and power system in Southeast Asia, with electricity demand growing by around 5% per year from 2025 to 2035, while the RUPTL 2025-2034 targets renewables as the largest source of capacity additions for the first time. Its growth trajectory and policy ambitions  make  Indonesia  a  strong  example  of  how  clean  energy investment  can  support  an  emerging  market's  overall  development.  Moreover, lessons  can  be  learned  from  how  stakeholders  address  challenges  related  to technical and regulatory uncertainties, currency risk, and fiscal constraints.

## PLN balance sheet analysis

PLN is  the  central  counterparty  for  virtually  all  grid-scale  power  investment  in Indonesia.  It  is  the  sole  transmission  and  distribution  operator,  the  dominant generator  and the  sole  off-taker  for  IPPs.  As  a  result,  the  bankability  of  every standalone and hybrid BESS project in Indonesia depends on PLN's creditworthiness, given that PLN serves as the primary source of project revenues.

PLN is one of the largest utilities in Asia, with total assets of IDR 1 837 trillion (approximately  USD  110  billion)  at  the end  of 2025.  Total liabilities are IDR 773 trillion (USD 47 billion), the largest component of which is interest-bearing

debt in the form of bank loans (IDR 212 trillion/USD 13 billion), bonds and sukuk ijarah , a variety of bond under Islamic finance (IDR 194 trillion/USD 12 billion) and multilateral  facilities.  Operational  performance  has  been  strong,  with  reported revenues of IDR 583 trillion (around USD 35 billion), up 6.8% year-on-year and continuing a multi-year growth trend in electricity sales.

At the same time, PLN operates within a regulated tariff framework. Retail tariffs are set by the government and have been held broadly flat since 2017 in support of affordability objectives, with the gap to cost-reflective levels bridged by subsidy and compensation transfers, which reached IDR 200 trillion (USD 12 billion) in the 2025 fiscal year (an electricity subsidy of IDR 87 trillion and compensation income of IDR 113 trillion), equivalent to around a third of total revenues. These transfers are  an  integral  part  of  PLN's  revenue  model  and  reflect  the  public  service obligations the company carries.

The scale of PLN's existing debt and its reliance on government transfers under the regulated tariff framework together define the boundaries of PLN's balance sheet capacity. Preserving the company's quasi-sovereign credit standing, which is one of its most valuable assets as a borrower, requires keeping leverage within the thresholds that rating agencies and lenders apply. Funding even a minority share  of  the  RUPTL's  BESS  pipeline  through  new  lending  would  multiply  the PLN's debt exposure, which has already risen by 10% year-on-year. Given that PLN's revenues are set within the regulated tariff and transfer framework, any additional PLN debt must ultimately be serviced from the same fiscal envelope that funds the subsidy and compensation transfers.

To  address  this  challenge,  PLN  has  created  holding  companies  to  bring substantial  financial  capacity  of  their  own.  PLN  Nusantara  Power's  financial statements  for  the  2025  fiscal  year  show  total  assets  of  IDR  358  trillion (USD 22 billion)  against  liabilities  of  just  IDR  42.5  trillion  (USD  2.5  billion),  a conservatively geared position with considerable headroom to absorb project-level investment. However, the sub-holding structure is one of the enabling mechanisms  to  address  the  headroom  rather  than  a  complete  solution.  The bankability of the underlying projects still rests on the offtake contracts written by PLN (Persero) and, behind them, on the tariff and transfer framework described above. How those contracts are designed and priced therefore determines the project's financial structuring.

This  approach  is  reflected  in  the  RUPTL  2025-2034,  which  envisages  BESS projects being funded from both the PLN group's own balance sheet and IPPs. Much of the BESS build-out could be financed by private capital, supported by enabling  tariff  structures  for  standalone  and  hybrid  projects  and  priced  with reference  to  PLN's  off-taker credit and  the  macro  environment  described previously. The risks and challenges that shape this pricing are discussed in the following chapter.

## BESS project implementation in Indonesia

## Overview of existing business models

Battery  energy  storage  systems  (BESS)  operate  under  a  range  of  revenue streams and business models that vary depending on their application, system configuration  and  off-takers'  strategy.  These  systems  can  be  deployed  as standalone assets or integrated with generation sources in hybrid projects, with each framework determining how value is captured.

Business models are shaped by market design, regulatory framework and the relative importance of different services within the power system. In some cases, BESS revenues are driven by single-use applications, while in others they rely on stacked value streams that combine multiple services to improve project viability. The choice of model ultimately reflects local system needs, contractual structures and  the  maturity of electricity markets,  which  define  both  the risks and opportunities for storage deployment.

Indonesia's market structure, with PT Perusahaan Listrik Negara (PLN) acting as the sole off-taker and system operator, constrains the range of business models available for BESS. As a result, standalone projects are likely to be remunerated under a full tolling agreement, while power purchase agreement (PPA) contracts are more  common  for  BESS  projects  co-located  with  generation  assets. Nevertheless,  a  broader  range  of  business  models  has  emerged  in  liberalised electricity markets, reflecting different market designs and opportunities for BESS assets to access multiple value streams.

## Full tolling models offer long-term visibility but eliminate upside potential

A tolling agreement for a BESS asset is a fixed-priced capacity offtake agreement. Under this model, the asset owner makes all or a portion of the battery's capacity exclusively  available  to  a  third-party  off-taker  in  exchange  for  a  regular,  fixed payment. This provides a stable, predictable revenue stream for the BESS owner, while giving the off-taker access to battery capacity without having to build and operate it itself.

The  tolling  fee  compensates  the  asset  owner  for  making  the  storage  capacity available and covers aspects such as degradation and operation and maintenance services.  The  owner  retains  responsibility  for  construction,  performance  and

availability, and maintains ownership of the asset and its residual value at the end of  the  contract  period.  The  off-taker,  in  turn,  secures  dispatch  rights  over  the contracted capacity without bearing upfront capital expenditure.

From  a  financing  perspective,  tolling  arrangements  provide  a  high  degree  of revenue certainty, particularly when contracted with a creditworthy off-taker under long-term  agreements.  This  can  support  limited-recourse  project  financing  by reducing  exposure  to  market  risk  and  stabilising  cash  flows.  However,  the bankability  of  such  arrangements  depends  on  the  clarity  of  contractual  terms, including  the  allocation  of  operational  risks,  compensation  mechanisms  for underperformance or degradation, and the robustness of availability payments. The  absence  of  standardised  contract  structures  or  market  precedents  may increase  perceived  risk  for  lenders,  particularly  where  tolling  agreements  are shorter than the expected economic life of the asset.

## Examples of full tolling business models

This  model  is  widely  used  in  more  mature  and  liberalised  electricity  markets, particularly in the United States, in Australia and increasingly in parts of Europe.

For instance, in the United Kingdom, Drax signed a ten-year tolling agreement in January 2026  with West  Burton C  Limited (owned  by Fidra Energy) for 250 megawatts (MW)/500 megawatt-hours (MWh) of new BESS capacity. Under this  arrangement,  Drax  will  pay  a  fixed  annual  tolling  fee  from  the  commercial operation  date  (expected  in  2029)  in  exchange  for  full  dispatch  rights  and operational  control,  while  Fidra  Energy  remains  responsible  for  construction, maintenance and asset availability throughout the contract period. This structure enables the off-taker to procure system flexibility without incurring upfront capital expenditure, while providing the asset owner with contracted revenues.

Similar  arrangements  are  observed  in  Australia,  where  the  200  MW/400  MWh Rangebank BESS in Victoria, operational since December 2024, operates under a full tolling agreement with Shell Energy securing 100% of the battery's capacity for 20 years.

From an independent  power  producer  (IPP)  perspective,  the  viability  of  tolling arrangements in Indonesia remains subject  to  several  uncertainties.  While  the model can, in principle, provide stable and predictable revenues, its effectiveness depends  on  the  robustness  of  the  contractual  framework,  including  payment security  arrangements,  risk  allocation  and  the  enforceability  of  contractual provisions.  In  the  absence  of  established  precedents  for  standalone  BESS, developers  face  challenges  in  assessing  key  parameters  such  as  contract duration, revenue adequacy and risk allocation.

## Schema of main players in full tolling business model, economic and power flows

<!-- image -->

## Hybrid models support firm electricity generation and improve BESS utilisation

Hybrid models have been gaining increasing attention worldwide in recent years. These  solutions  can  take  different  forms,  as  they  combine  multiple  energy sources. Within the scope of this report, the focus is on configurations where a renewable energy project (solar photovoltaic [PV] or wind) is paired with BESS. In this structure, both assets are complementary and mutually beneficial, contributing to  grid  stability  and  security  of  supply.  The  BESS  can  supply  electricity  when renewable generation is not producing due to weather conditions, while it can be charged when renewables are generating but electricity demand is low.

Beyond  their  technical  complementarity,  hybrid  systems  can  provide  flexibility services,  reduce  curtailment  of  renewable  generation  and  optimise  the  use  of existing grid infrastructure. From an investment perspective, these configurations can improve project economics by diversifying revenue streams, including energy arbitrage  and,  where  permitted  by  market  rules  and  project  design,  ancillary services. However, their deployment depends on enabling regulatory frameworks and market design, as well as overcoming challenges such as higher upfront costs and integration complexity.

Hybrid systems are often supported by long-term PPAs, which provide stable and predictable revenues. Under these contracts, an off-taker commits to purchasing electricity at an agreed price over a defined period. In hybrid configurations, the presence of BESS can enhance the value of PPAs by improving dispatchability and allowing better alignment between generation profiles and demand.

In some more mature markets, hybrid projects may be structured through separate contractual  arrangements  for  the  generation  asset  and  the  battery,  reflecting differences  in  asset  lifetimes,  cost  structures  and  operational  roles.  This  can involve,  for  example,  distinct  PPAs  or  remuneration  mechanisms  for  each component, allowing risks and revenues to be allocated more precisely. However, such  approaches  remain  largely  unexplored  in  Indonesia,  where  BESS  are typically embedded within a single PPA framework.

## Examples of hybrid PPA business models

A recent example of hybrid solar and storage PPAs can be found in Malaysia, where data  centre  developer  DayOne  signed  large-scale  bilateral  agreements  with subsidiaries  of  Tenaga  Nasional  Berhad  (TNB).  The  contracts  cover  around 1.5 gigawatts (GW) of solar PV combined with 2.2 gigawatt-hours (GWh) of battery storage, deployed as hybrid systems pairing BESS with both ground-mounted and floating solar installations. These  projects are structured under Malaysia's Corporate  Renewable  Energy  Supply  Scheme  (CRESS),  enabling  long-term renewable  electricity  procurement  -  alongside  renewable  energy  credits  -  to support  decarbonisation  of  energy-intensive  users  such  as  data  centres  while improving system flexibility.

This  case  illustrates  how  solar  PV-plus-BESS  projects  can  be  enabled  through dedicated procurement frameworks and bankable long-term PPAs, with corporate demand acting as a key anchor. It also highlights the role of storage in enhancing the  integration  of  variable  renewables  and  ensuring  reliability  of  supply.  Such models  remain  less  developed  in  Indonesia,  where  regulatory  and  procurement uncertainties continue to constrain similar hybrid configurations.

Another example can be found in Chile, where Grenergy has signed a 12-year hybrid PPA linked to the fifth phase (Algarrobal) of its Oasis de Atacama platform, one of the largest solar PV-plus-BESS developments globally. The contract covers the supply of around 350 GWh per year starting in 2028 to an investment-grade off-taker.

The project combines 242 MW of solar PV capacity with approximately 1.4 GWh of battery  storage,  allowing  electricity  to  be  delivered  beyond  daylight  hours.  This hybrid  structure  enables  the  shifting  of  solar  generation  to  higher-value  periods, effectively  providing  a  form  of  dispatchable  renewable  energy  and  enhancing system flexibility.

More broadly, the Oasis de Atacama platform - which includes multiple phases and several gigawatt-hours of storage (including a 3.5 GWh BESS component in later phases) - has secured over USD 1.2 billion in non-recourse financing, supported by long-term PPAs with creditworthy counterparties. This demonstrates how hybrid PPAs can underpin large-scale BESS deployment by providing predictable revenue streams while capturing the added value of storage.

In Indonesia, hybrid BESS projects are expected to be structured under long-term PPAs,  which  remain  the  main  contractual  framework  for  IPPs.  Under  these arrangements, the off-taker, PLN,  commits  to purchasing electricity at a predetermined tariff  rate  over  a  defined  period,  providing  a  degree  of  revenue certainty.  The  integration  of  BESS  can  enhance  the  value  of  these  PPAs  by improving  the  dispatchability  of  renewable  generation  and  allowing  a  better alignment between production profiles and system needs.

## Schema of main players in a hybrid PPA business model, economic and power flows

<!-- image -->

## BESS business models beyond the Indonesian market framework

## The full merchant model comes with high risks and high rewards

The  full  merchant  model  exposes  BESS  assets  entirely  to  market  revenues, offering both high risks and potentially high rewards. Under this model, the asset owner  does  not  rely  on  long-term  contracted  payments  but  instead  generates income from participation in wholesale electricity markets, ancillary services and

other flexibility mechanisms.  Revenues  therefore  depend  on  market  price dynamics, volatility and the availability of services that can be monetised, which can vary significantly over time.

For asset owners, this model provides maximum upside potential, particularly in markets with strong price signals and well-developed flexibility services. However, it also entails significant revenue uncertainty and exposure to market risk, as well as higher transaction costs and increased operational complexity, which can affect bankability and financing conditions. For off-takers, the merchant model offers full optionality  and  avoids  long-term  contractual  commitments,  allowing  them  to procure flexibility directly from the market as needed. However, this approach may expose buyers to price volatility and uncertainty over the availability of services, particularly during periods of high demand when storage capacity is constrained. This structure is most viable in mature and liberalised electricity systems, where transparent price formation and liquid markets enable storage assets to capture multiple value streams.

Fully merchant BESS projects are most commonly observed in markets such as the Electric Reliability Council of Texas (ERCOT) in the United States, the National Electricity  Market  (NEM)  in  Australia,  and  the  United  Kingdom,  where  storage operators rely on energy arbitrage and ancillary service revenues without longterm contracted capacity payments.

## Partial tolling balances stable remuneration with bounded entry into the market

The  partial  tolling  agreement  offers  a  hybrid  structure  that  balances  stable remuneration  with  limited  exposure  to  market  dynamics.  Under  this  model,  a portion  of  the  battery's  capacity  is  contracted  under  fixed  payments,  ensuring predictable revenues for the asset owner, while the remaining capacity is either merchant or subject to alternative contractual arrangements. This allows asset owners to secure a baseline level of income while retaining some upside from market participation, such as energy arbitrage or ancillary services.

For off-takers, partial tolling provides greater flexibility compared with full tolling arrangements.  It reduces  long-term  financial commitments  and  contracted volumes, while still securing access to dedicated storage capacity when needed. At the same time, it allows off-takers to optimise procurement strategies by relying on market-based flexibility for part of their needs, rather than locking in the full capacity under fixed payments.

This  structure  is  particularly  relevant  in  markets  where  revenue  streams  are sufficiently mature to support a combination of contracted and merchant exposure, enabling both parties to balance risk mitigation with value maximisation. Partial tolling structures are increasingly observed in mature and liberalised markets such

as Australia, the United Kingdom and the United States.  In these markets, several BESS  projects  combine  contracted  revenues  with  merchant  participation  in wholesale and ancillary service markets, allowing asset owners to secure stable revenues  while  retaining  exposure  to  upside  from  price  volatility  and  system service revenues.

## End-of-life considerations for BESS: Recycling and ownership structures

BESS  are  expected  to  have  an  operational  lifetime  of  around  10-15  years, depending on battery chemistry, cycling intensity, environmental conditions and operational strategy. In practice, end of life does not necessarily mean that the battery can no longer operate, but rather that its performance has degraded below the level required for the intended application, often measured through reduced usable capacity, lower round-trip efficiency or increasing maintenance needs. At that  stage,  several  pathways may be considered: continued operation at lower performance,  refurbishment  or  repowering  through  replacement  of  modules, second-life use in less demanding stationary applications, or final decommissioning and recycling.  Across  major markets,  the  growing  volume  of end-of-life  batteries  has  made  recycling  an  increasingly  important  element  of battery policy, not only for environmental reasons but also for resource security and the recovery of critical materials such as lithium, nickel and cobalt.

Internationally,  leading  jurisdictions  are  moving  towards  more  comprehensive frameworks for battery end-of-life management.  In the European Union, Regulation  (EU)  2023/1542  establishes  a  life-cycle-based  framework  covering sustainability,  collection,  reuse  and  recycling  of  batteries,  including  industrial batteries used in storage applications. The regulation introduces binding targets for material recovery, including 50% lithium recovery by 2027 and 80% by 2031, as well as minimum recycled-content requirements in new batteries and a digital battery passport  for  industrial batteries above  2 kilowatt-hours  (kWh)  from February 2027. China has also introduced a range of policies promoting battery traceability  and  producer responsibility,  while  several  provinces  have  launched pilot frameworks for the tracking and recycling of retired energy storage batteries. These approaches reflect a broader shift towards circular economy frameworks and highlight the importance of clearly assigning end-of-life responsibilities.

The  allocation  of  end of life  responsibilities  depends  strongly  on  ownership --structures  under  different  contracting  models,  notably  PPA  and  full  tolling frameworks. Under PPA-based structures, where storage is typically combined with generation, the asset usually remains part of the project company (typically a special purpose vehicle), implying that the IPP retains responsibility for maintenance, repowering and end of life management unless otherwise specified. --In contrast, under full tolling models, the asset owner contracts out operational

rights while retaining ownership, requiring clear contractual allocation of degradation risk,  residual  value  and  decommissioning  obligations.  Across  both models, the definition of ownership at contract expiry is critical, particularly given the shorter effective lifetime and performance uncertainty of battery assets.

In  Indonesia,  recent  regulatory  developments  have  significantly  altered  this allocation  of  ownership.  Historically,  renewable  PPAs  followed  a  build-ownoperate-transfer (BOOT) model, under which assets were transferred to PLN at the end of the contract, implicitly shifting long-term ownership and associated lifecycle risks to the utility. With the introduction of MEMR Regulation 5/2025, where PPAs for BESS in hybrid projects are regulated for the first time, greater flexibility has been introduced through longer contract durations (up to 30 years) and the possibility of adopting build-own-operate (BOO) or other contractual structures, allowing IPPs to retain ownership of assets beyond the contract term. This shift improves bankability and aligns more closely with the technical characteristics of storage, but also transfers greater responsibility for long-term asset management to project developers, as BESS replacement obligation falls on the IPP.

At the same time, Indonesia's regulatory framework for battery recycling remains limited,  relying  mainly  on  general  hazardous  waste  provisions  with  limited guidance  specific  to  lithium-ion  batteries  or  utility-scale  storage.  As  BESS deployment scales up, aligning ownership structures with clear recycling obligations  and  life-cycle  management  rules  will  be  critical  to  ensure  both environmental sustainability and project bankability. In addition, compliance with internationally recognised safety and testing standards, such as IEC 62933-5-2 (safety standards for grid-connected electrochemical technologies), UL 9540/9540A (thermal runaway and fire prevention standards) and NFPA 855 (safe installation standards), can further support project bankability by facilitating  permitting  processes,  improving  insurability,  and  reducing  perceived technology and operational risks among lenders and investors.

## Remaining uncertainties for business models in Indonesia

Despite growing interest in BESS in Indonesia, significant uncertainties remain around the business models that could underpin investment and support project bankability. These uncertainties are particularly relevant in a market where PLN remains  the  dominant  off-taker  and  system  operator,  limiting  the  range  of commercial structures available to private investors. Globally, BESS projects can rely  on  a  variety  of  remuneration  mechanisms,  including  capacity  payments, ancillary  service  revenues,  energy  arbitrage  and  hybrid  models  that  combine multiple  value  streams.  In  Indonesia,  however,  such  monetisation  pathways remain limited and insufficiently defined, particularly for standalone projects.

A key uncertainty relates to the intended use cases of BESS and how PLN may choose to dispatch these assets in practice. Project economics depend heavily on whether  batteries  are  used  for  renewable  integration,  peak  shaving,  reserve provision, network support or island system reliability, as each use case implies different cycling patterns, performance requirements and degradation profiles. At present, there is limited clarity on how these services would be prioritised, valued or remunerated, and whether revenue stacking would be permitted. This reduces revenue visibility and complicates project financial modelling.

From  an  IPP  perspective,  the  lack  of  standardised  and  bankable  contractual arrangements  represents  an  additional  barrier.  While  hybrid  BESS  may  be structured through a PPA linked to a renewable generation asset, and standalone systems may potentially rely on a full tolling model, both approaches remain at an early  stage  of  development.  Key  issues  such  as  risk  allocation,  availability requirements,  indexation,  compensation  for  battery  degradation,  replacement obligations and the treatment of underutilisation are not yet clearly established. As a result, developers and lenders face difficulties in assessing long-term cash flow stability and allocating risks.

These challenges are particularly acute for standalone BESS, which remains the least  defined  segment  despite  growing  market  interest.  While  PLN's  planning documents  increasingly  recognise  the  role  of  storage  in  supporting  system flexibility and  renewable  integration, a clearer commercial  and  regulatory framework  will  be  needed  to  translate  this  strategic  interest  into  investable opportunities.  Establishing  fit-for-purpose  business  models,  with  transparent remuneration principles and clearer contractual precedents, will be essential to unlock private participation and accelerate BESS deployment in Indonesia.

## Key regulations for BESS remuneration

The role of BESS in Indonesia's power sector has gained increasing attention in recent years, reflecting the growing need for system flexibility, renewable energy integration and grid reliability. As deployment progresses, the development of a clear regulatory framework is essential to provide certainty for project developers, investors and lenders, and to support the emergence of viable business models. While Indonesia does not yet have a dedicated framework for standalone storage projects,  several  regulations  have  established  important  foundations  for  the deployment  of  BESS,  primarily  as  a  component  of  hybrid  renewable  energy projects. Presidential Regulation 112/2022 represented the first explicit recognition of energy storage as a complement to renewable generation assets. Subsequent regulations, including MEMR Regulation 5/2025 governing PPAs and MEMR Regulation 19/2025, have further clarified the  contractual,  procurement and  remuneration  arrangements  applicable  to  projects  incorporating  storage. Together, these regulations form the main regulatory basis for BESS deployment

in Indonesia today. As the market continues to develop, further clarification of the roles, remuneration mechanisms and operational requirements associated with storage may help facilitate  broader  deployment and support the emergence of additional business models, including standalone applications.

## Presidential Regulation 112/2022

First issued  by  MEMR's  Directorate  General  of  Electricity  (DJK)  in  2022, Presidential  Regulation  112/2022  (hereafter,  'PR  112')  aims  to  accelerate  the deployment of renewable energy for electricity generation in Indonesia, in line with national  energy  transition  and  emissions reduction  objectives.  The  regulation -prohibits the development of new coal fired power plants and establishes a new -framework for the procurement and remuneration of renewable energies.

Under PR 112, renewable energy tariffs are no longer benchmarked against PLN's system-wide Biaya Pokok Penyediaan (BPP), which is largely driven by low cost -and subsidised coal generation. Instead, the regulation introduces a ceiling tariff mechanism, differentiated by renewable technology and project location. This shift improves price signals for renewable energy, supports the participation of IPPs, and results in a more technology appropriate remuneration framework as tariffs -are no longer anchored to fossil fuel generation costs.

BESS are regulated under PR 112 as hybrid or enabling components integrated with renewable generation. Battery related charges are capped at a share of the -applicable  base  tariff,  indicating  that  storage  is  recognised  primarily  as  a  cost component supporting variable renewable energy (VRE) integration. Standalone BESS  are  not  explicitly  regulated  or  remunerated  under  the  current  tariff framework, limiting their deployment to use cases linked to renewable generation.

## Electricity purchase price

PR 112 introduces  a  ceiling  tariff  mechanism  ( harga  patokan  tertinggi )  as  the reference price for all renewable energy electricity purchases by PLN, expressed in USD cents per kWh. Prices are differentiated by technology, installed capacity, and project location, the latter through a location factor ranging from 1.00 (Java, Madura, Bali) to 1.50 (Papua), which is particularly relevant for hybrid projects targeting remote or off-grid areas.

Ceiling prices follow a two-period structure, with higher tariffs applicable during the first ten years of operation to support capital recovery, stepping down for the remainder of the contract term. For solar PV and wind, the ceiling price applies with no escalation during the PPA term. For hybrid projects equipped with battery storage,  the  BESS  component  is  subject  to  a  separate  ceiling  of  60%  of  the applicable electricity purchase price, automatically serving as the minister's price approval;  prices  exceeding  this  threshold  require  explicit  ministerial  consent.

Where project-specific cost structures cannot be accommodated within the ceiling price  framework,  an  agreed  price  ( harga  kesepakatan ) may  be  negotiated between the IPP and PLN, subject to ministerial approval.

Ceiling tariff prices for privately developed hybrid solar PV-plus-BESS projects, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: kWh = kilowatt-hour. MW = Megawatt. Ceiling tariffs for small islands are not shown in the figure. Only ceiling tariffs for the first ten years are shown in the figure.

Source: IEA analysis based on Presidential Regulation 112/2022 (2026)

Where grid connection infrastructure is required to link the power plant to PLN's network, the associated costs are negotiated separately between the parties and capped  at  30%  of  the  electricity  purchase  price,  automatically  serving  as  the minister's  approval.  Costs  exceeding  this  threshold  require  explicit  ministerial consent.

## Procurement procedure

Article 14 provides for two procurement methods for electricity purchases: direct appointment  ( penunjukan  langsung )  and  direct  selection  ( pemilihan  langsung ). The  choice  of  procurement  method  depends  on  the  technology  used  and,  for certain generation sources, specific project characteristics, including ownership arrangements.

In the case of solar PV projects coupled with BESS, electricity procurement shall be conducted through direct selection. In the case of only one bidder after two rounds, the purchase shall be executed through direct appointment.

## Procurement procedure under PR 112/2022

| Characteristic   | Direct appointment                                                       | Direct selection                                                           |
|------------------|--------------------------------------------------------------------------|----------------------------------------------------------------------------|
| Principles       | Administrative, technical and financial document evaluation is required. | Selection on basis of the lowest price offer subject to the ceiling price. |
| Timeline         | 90 calendar days from submission to signature.                           | 180 calendar days from submission to signature.                            |

Source: Republic of Indonesia (2022), Peraturan presiden Republik Indonesia nomor 112 tahun 2022 tentang percepatan pengembangan energi terbarukan untuk penyediaan tenaga listrik.

All procurement processes begin with a pre-qualification stage, where business entities are screened. PLN maintains and publishes a list of selected providers, updated every three  months, that  constitutes  a  prerequisite  for  participation  in subsequent tenders.

Following the procurement process, the winning business entity enters into a PPA with PLN, at which point it is formally designated as a power plant developer. The PPA terms are governed by guidelines established by the minister.

## Regulation 5/2025

Issued on March 2025, MEMR Regulation 5/2025 establishes specific guidelines for  PPAs  between  IPPs  and  PLN  as  the  sole  off-taker  for  renewable  energy sources, replacing MEMR Regulation 10/2017, which covered both renewable and conventional technologies under a single framework. Under this new regulation, energy storage is, for the first time, brought within the scope of PPA frameworks. The  regulation  implements  the  PPA  structure  outlined  by  PR  112/2022  and represents  a  significant  step  towards  improving  the  bankability  of  renewable energy projects in Indonesia.

The regulation fixed the  maximum  PPA  duration  to  30  years  from  commercial operation  date  (COD),  improving  project  bankability  by  strengthening  the  debt service  coverage  ratio  (DSCR).  The  longer  contract  tenure  increases  revenue certainty  over  the  project  lifetime  and  enables  longer  debt  repayment  periods, reducing annual debt service obligations and improving access to financing for capital-intensive  hybrid  projects.  The  ownership  scheme  shifts  from  BOOT  under which assets transferred to PLN at expiry - to a BOO structure, allowing IPPs to retain ownership of project assets, including storage components, which has  implications  for  residual  asset  value  and  refinancing.  For  agreements extending beyond 30 years, the applicable tariff reverts to the highest reference price determined after the first 10 years rather than the originally contracted tariff, discouraging over-reliance on long-tenor extensions. New  minimum  PPA

provisions  are  introduced  covering  electrical  installation  certification,  use  of domestic products, environmental attributes, refinancing mechanisms and language requirements.

The regulation replaces the previous BPP-linked tariff with a take-or-pay structure based on contracted energy and availability factor, under which PLN is obliged to purchase electricity up to the contracted level at the PPA tariff. Excess generation may be sold to PLN at up to 80% of the PPA tariff subject to demand - relevant for  hybrid  projects  where  battery  dispatch  may  push  output  above  contracted levels.  A  deemed  dispatch  mechanism  requires  PLN  to  compensate  IPPs  for curtailed energy, providing protection against grid curtailment risk. The application of availability penalties to intermittent technologies nonetheless remains ambiguous, warranting close attention in PPA negotiations for hybrid configurations.

The regulation reduces the cap on performance security from up to 20% to 10% of project cost and strengthens lender protections through clarified step-in rights before COD, reducing construction-phase risk for hybrid projects. Tariff adjustments  are  permitted  for  changes  in  taxes,  levies  and  environmental obligations, providing partial cost pass-through protection for IPPs.

## Regulation 19/2025

Issued in December of 2025 by MEMR's Directorate General of New Renewable Energy and Energy Conservation (EBTKE), Regulation 19/2025 represents one of the first official recognitions of BESS within the framework of Indonesia's power infrastructure. Regulation 19 aims to facilitate the development of hybrid power plants, with a particular focus on projects replacing diesel generation in remote or isolated  areas  of  Indonesia.  Hybrid  power  plants  are  defined  as  those  pairing renewable  energy  generation  with  other  renewable  energy,  non-renewable energy, and/or BESS.

In addition to accepting  BESS  as  a  component  of  hybrid  power  plants, Regulation 19 establishes a procurement scheme and tariff-setting framework for such installations. The electricity generated by IPP-developed hybrid power plants is purchased by PLN through the signing of a PPA, and the electricity purchase price negotiated between PLN and the IPP must fall within a range determined by MEMR. These floor and ceiling prices have yet to be defined quantitatively but are expected to be announced in a ministerial decree. According to Regulation 19, PLN is entitled to state compensation in the case that purchase of electricity from a hybrid power plant results in an increase in system BPP.

While Regulation 19, in addition to its upcoming ministerial decree defining the permissible range of PPA prices, represents an important improvement in the legal framework  for  BESS  in  Indonesia,  some  uncertainties  persist  for  prospective

hybrid power plant developers. For instance, the definition of technical parameters, such as the sizing of BESS assets relative to associated renewable energy assets, are not explicitly addressed. However, the foremost uncertainty lies in how BESS are treated within the single hybrid PPA signed between IPPs and  PLN.  Specific  guidance  on  which  services  BESS  assets  are  permitted  to provide and whether they can stack multiple revenues is necessary for developers to accurately anticipate project cash flows. Moreover, additional details determining whether IPPs or PLN are responsible for BESS dispatch, and whether BESS assets co-located with renewable generation are permitted to charge from PLN's grid, would further clarify developers' position as operators of the hybrid power plant.

## Comparison of key BESS-related regulations

| Characteristic             | Regulation 112/2022                                                                                                                                                                                                                                                                                                                                                                                                                                 | Regulation 19/2025                                                                                                   |
|----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------|
| Date issued                | September 2022                                                                                                                                                                                                                                                                                                                                                                                                                                      | December 2025                                                                                                        |
| Technologies targeted      | Geothermal, hydroelectric, solar PV, wind, biomass, biogas, ocean energy and biofuel. BESS are considered as enabling technologies with PV and wind projects.                                                                                                                                                                                                                                                                                       | Hybrid power plants (combining renewable power with other renewables, non- renewable power, and/or BESS).            |
| Objective                  | Development of renewable sources of energy generation.                                                                                                                                                                                                                                                                                                                                                                                              | Accelerate de-dieselisation efforts in remote and isolated areas while scaling up renewable energy deployment.       |
| procedure                  | Direct selection for hydropower, solar PV, wind, biogas, biomass, biofuels and tidal power. Pre- qualified participants respond to tenders and tariffs are determined by the lowest bids (which cannot exceed a ceiling tariff). Direct appointment for hydropower utilising dams or reservoirs constructed by the government, geothermal, and expansion project. No competitive process, and PLN directly negotiates PPA price with relevant IPPs. | Procurement Direct selection, qualified participants to tenders. Tariffs determined falling between ceiling tariffs, |
| Electricity purchase price | Must not exceed a ceiling price determined by MEMR.                                                                                                                                                                                                                                                                                                                                                                                                 | Must fall between a price floor and ceiling determined by MEMR.                                                      |

| Characteristic             | Regulation 112/2022                                                                                                                                                                                                               | Regulation 19/2025                                                                                                           |
|----------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|
| Other tariff components    | Network tariffs cannot exceed 30% of the negotiated electricity purchase price. Battery storage charges cannot exceed 60% of the negotiated electricity purchase price. Over this price, approval from the minister is mandatory. | Network tariffs cannot exceed 5% of the negotiated electricity purchase price.                                               |
| Locational differentiation | Java, Maduraand Bali: 1.0 Sumatra, Kalimantan, and Sulawesi: 1.1 Nusa Tenggara: 1.2 North Maluku and Maluku: 1.25 West Papua and Papua: 1.5                                                                                       | Locational factors are applied but have yet to be defined quantitatively.                                                    |
| Contract type and parties  | PPA between IPP and PT PLN.                                                                                                                                                                                                       | Single PPA signed between IPP developer and PLN.                                                                             |
| Contract price stability   | Ceiling tariff benchmark is reviewed annually by MEMR.                                                                                                                                                                            | Price remains unchanged over the duration of the contract, but price floor and ceiling are revised at least every two years. |
| Status                     | Effective from September 2022.                                                                                                                                                                                                    | Awaiting ministerial decree to quantitatively define price floor and ceiling.                                                |

Source: PricewaterhouseCoopers (2026), Legal Alert 54/2026, Umbra Law (2026), Client alert: New MEMR regulation on hybrid power plants for small islands or isolated areas, Republic of Indonesia (2022), Peraturan presiden Republik Indonesia nomor 112 tahun 2022 tentang percepatan pengembangan energi terbarukan untuk penyediaan tenaga listrik, Ministry of Energy and Mineral Resources (2025), Peraturan nomor 19 tahun 2025 tentang pembangkit listrik tenaga hibrida

## Remaining regulatory uncertainties for BESS deployment in Indonesia

Despite  recent regulatory progress  -  including PR  112/2022  and  MEMR regulations  5/2025  and  19/2025  -  several  uncertainties  continue  to  affect  the development and bankability of BESS in Indonesia, potentially slowing progress towards the deployment targets outlined in PLN's Rencana Usaha Penyediaan Tenaga Listrik (RUPTL), or Electricity Supply Business Plan.

Standalone  BESS  remain  undefined  within  the  current  regulatory  framework. While storage is recognised in the context of hybrid or integrated systems, there is no clear legal classification or dedicated licensing regime for standalone assets providing grid services. While Indonesia's Badan Pusat Statistik (BPS, or Central Agency of Statistics) explicitly includes battery storage in its industrial business classification  for  electrical  storage  facilities,  additional  specifications  on  how

MEMR regulations apply to standalone BESS are not yet available. This creates ambiguity  around  procurement  eligibility,  applicable  remuneration  mechanisms and  licensing  requirements,  ultimately  limiting  the  emergence  of  independent storage business models and constraining investment to projects coupled with generation.

In  addition,  the  co-existence  of  MEMR  5/2025  and  MEMR  19/2025  introduces uncertainty regarding the classification and treatment of projects. The boundary between  grid-connected  renewable  energy  projects  under  MEMR  5/2025  and hybrid  systems  in  isolated  or  small  networks  under  MEMR  19/2025  remains unclear, particularly for projects with partial grid connectivity or evolving system configurations.  This  lack  of  clarity  complicates  the  selection  of  the  applicable procurement framework, tariff structure and contractual arrangements, increasing development risk for project developers.

Further uncertainty arises from the pending publication of pricing benchmarks and ceiling tariffs under MEMR 19/2025. The absence of these reference values limits visibility on project revenues and constrains the ability of developers to structure competitive bids and secure financing. In this context, ensuring that ceiling tariffs appropriately reflect not only the generation asset but also the installed capacity and system value of the BESS component would be essential to enable costreflective remuneration and support project viability.

While MEMR 5/2025 strengthened the contractual framework for project financing, debt  tenors  available  from  commercial  lenders  may  remain  shorter  than  PPA durations.  This  could  limit  the  extent  to  which  longer-term  contracts  improve project bankability, particularly for capital-intensive BESS projects.

More broadly, procurement processes would benefit from greater transparency and  clarity in their design  and  implementation.  Strengthening  visibility  on evaluation criteria, tender timelines and contractual allocation of risks would help reduce  perceived  regulatory  risk,  enhance  investor  confidence  and  facilitate broader participation from IPPs.

Finally, uncertainties remain regarding the role of IPPs and the extent of private sector  participation  in  storage  deployment,  as  well  as  evolving  technical  and system integration requirements. Clarification in these areas -including ownership structures, dispatch rules and grid integration standards - will be critical to  ensure  consistency  across  projects  and  support  the  scaling  of  BESS  in Indonesia.

## BESS remuneration in Indonesia

The remuneration of BESS services is the single most important determinant of project bankability. However, the dual role of BESS as consumers and producers of electricity, together with their ability to provide a variety of services, also makes them more complex to remunerate than traditional generation assets. Identifying transparent tariff schemes that satisfy both PLN's and IPPs' needs is essential to improving cash flow predictability for investors and financiers.

## Challenges for BESS assets and PLN

Like  renewable  energy  technologies,  BESS  projects  are  associated  with  high upfront  capital  costs  and  comparatively  low  operational  costs.  Capital  costs typically account for over 90% of the levelised cost of electricity (LCOE) of solar PV-plus-BESS hybrid projects and around 60% of utility-scale standalone projects' levelised cost of storage (LCOS). As a result, the level and frequency at which assets are remunerated determine how capital costs are recovered throughout the project's lifetime.

The  ability  for  BESS  to  provide  a  wide  range  of  system  services  -  including renewables smoothing, capacity reserves, and frequency and voltage support means that higher economic values for both standalone and hybrid assets come from the provision of multiple  services,  a  practice  known  as  revenue  stacking. However,  successful  revenue  stacking  is  dependent  upon  the  availability  of remuneration frameworks that explicitly value these services and allow assets to participate  across  them.  Revenue  stacking  also  introduces  additional  technical complexity;  as  a  result,  clear  definitions  of  system  needs  provide  essential operational parameters within which BESS developers can design their assets.

Unlike traditional generation assets such as natural gas power plants and solar PV installations, BESS are both producers and consumers of electricity. While hybrid assets have the possibility of charging exclusively from the generation asset with which they are paired, standalone installations must charge from the grid. As a result, the rate at which BESS should be charged for consuming grid electricity must be clearly defined, either as a fixed rate or as a percentage of the rate at which BESS sell electricity to PLN. Moreover, BESS can benefit from provisions that prevent the double-charging of taxes and network tariffs on BESS assets as they both consume and produce electricity.

## Challenges faced by PLN in compensating IPP assets

Much of  PLN's  planning  and  investment  decisions  are  tied  to  the  BPP,  which measures  the  utility's  average  cost  of  electricity  supply  in  each  of  its  distinct systems.  The  BPP  considers  factors  such  as  historic  fuel  costs,  operating

expenses and capital recovery for existing generation assets; as a result, PLN has an incentive to prioritise investments that minimise increases in average system costs, which can make it more challenging to justify higher upfront investments with longer-term system benefits. In fact, the RUPTL 2025-2034 endeavours to meet rising demand for electricity without raising the country-wide BPP, mainly by recognising  the  value  of  upfront  investments  in  VRE,  which  benefit  from  low operational costs and zero fuel purchases over the long term. Indonesia's overall BPP was estimated at IDR 1 970/kWh in 2025, and decreases to IDR 1 622/kWh by 2034 in the RUPTL's Accelerated Renewable Energy Development (ARED) scenario (USD 0.11/kWh and 0.09/kWh, respectively).

## Changes to system-level BPP in the RUPTL's ARED scenario, 2025-2034

<!-- image -->

IEA. CC BY 4.0.

Note: ARED = Accelerated Renewable Energy Development; BPP = Biaya Pokok Penyediaan (system cost of electricity supply).

Source: IEA analysis based on PLN (2025), RUPTL 2025-2034.

BESS assets, however, do not conveniently fit into PLN's current methodology for calculating  BPP  because  they  do  not  independently  generate  electricity  and provide  additional  services  that  are  not  quantified  under  current  Indonesian regulatory frameworks. The only existing legal classification of BESS today is as a capital component of hybrid power plants. Therefore, the addition of electricity storage tends to increase the contribution to BPP of VRE generation without also reflecting cost savings associated with improved system flexibility, reliability and reduced requirements for additional generation capacity to meet planning reserve margins. The resulting BPP estimation then risks being too high, leading PLN to base  investment  decisions  on  information  that  does  not  truly  reflect  long-term system costs.

Under  current  methodology,  system  BPP  incorporates  fuel  costs  by  dividing historical fuel expenditures by total generation over an equivalent period of time. While having the advantage of using data that are readily available to PLN, this approach can result in an estimation of system costs that emphasises historic costs over forward-looking trends. Consequently, long-term investment decisions are not based on estimates that accurately anticipate future costs, leading fossil fuel-based generation - notably coal-fired power plants - to appear unrealistically cost-competitive.

Although the average system cost of electricity supply, represented by BPP, is used to distinguish between investment decisions, it bears limited relation to the retail  tariff  at  which  PLN  sells  electricity  to  consumers.  Obligations  to  maintain affordability, enforced  through  Electricity Law  30/2009,  mean  that  PLN  is frequently  required  to  sell  electricity  to  final  consumers  at  a  price  below  the corresponding  system  BPP,  with  the  difference  between  retail  tariffs  and  BPP being compensated for by significant government subsidisation and, to a lesser extent, cross-subsidisation by commercial and industrial tariffs. The Indonesian government  provided  an  estimated  IDR  176  trillion  (nearly  USD  10  billion)  in support to PLN and electricity consumers to maintain affordability, equivalent to 0.7% of the country's total gross domestic product (GDP) in that year.

Note: BPP = Biaya Pokok Penyediaan (system cost of electricity supply).

<!-- image -->

Sources: IEA analysis based on PLN (2025), RUPTL 2025-2034. and PLN (2025), 2025 Statistical Report.

Because consumer electricity tariffs are not fully cost-reflective, PLN has a limited ability to pass on the costs of capital-intensive projects to consumers. Moreover, the political sensitivity of electricity affordability in Indonesia incentivises PLN to minimise costs rather than seeking out the possibility of increases in consumer tariffs  to  accommodate  the  need for  power  sector  expansion.  Consideration  of

these  challenges  is  essential  to  addressing  the  remuneration  of  BESS:  while payments  must  be  sufficiently  flexible  to  allow  assets  to  perform  a  range  of services, they must also minimise upfront financial burden on PLN.

## Types of BESS compensation

The remuneration of BESS assets, as well as their abilities to combine multiple revenue  streams  by  providing  a  variety  of  services,  is  the  single  biggest determinant  of  project  bankability.  While  regulations  112/2022,  05/2025,  and 19/2025 establish frameworks for the PPA contracts to be negotiated between IPPs and PLN, uncertainties around how these contracts would relate to BESS services  persist.  The  following  section  outlines  in  detail  the  three  types  of remuneration that BESS assets receive, their compatibilities with current policies in  Indonesia  and  how  these  can  be  further  integrated  into  MEMR's  regulatory frameworks.

## Capacity-based remuneration

The  simplest  of  the  three  types  of  remuneration,  capacity-based  payments, compensate BESS assets for their ability to provide system services when called upon. Assets are typically remunerated on a per-megawatt and per-hour basis for their installed capacity,  regardless  of  whether  they  are  dispatched.  Under capacity-based remuneration schemes, BESS usually provide services related to grid  stability  and  reliability,  such  as  black-start  capabilities  and  peak  capacity reserves.  The  full  tolling  business  model  employs  capacity  payments  as  the primary source of remuneration, prioritising stable and predictable revenues that strengthen  project  bankability.  Such  mechanisms  are  therefore  well  suited  for BESS projects that primarily aim to support the electricity network, such as those designated by the RUPTL for the system of Java, Madura and Bali.

Capacity-based  payments  are  also  currently  the  most  compatible  type  of remuneration under Indonesia's current regulatory framework, but only for hybrid projects. In order for BESS projects to be remunerated under a capacity-based mechanism, they must be treated as a component of the capital expenditures of renewable energy projects. However, current regulation does not explicitly define standalone BESS as a distinct asset class, making such projects incompatible with existing regulatory structures.

## Availability-based remuneration

Similarly to its capacity-based counterpart, availability-based remuneration operates on a per-megawatt and per-hour basis. However, where capacity-based payments  are  linked  to  the  installed  power  of  BESS  assets,  availability-based payments  typically  include  additional  requirements  around  asset  performance

such as response time and accuracy. This is because availability-based payments are  generally  used  to  remunerate  the  provision  of  ancillary  services  such  as frequency  regulation  and  voltage  support.  The  regularity  of  availability-based payment  also  makes  this  mechanism  compatible  with  the  full  tolling  business model. As BESS asset operators gain sufficient experience to be able to meet operational standards reliably, the addition of availability-based payments through, for instance, the creation of ancillary service procurement agreements (ASPAs) can enable operators to 'stack' multiple revenue streams.

As with capacity-based payments, availability-based remuneration in Indonesia is currently possible only for BESS that are paired with renewable energy assets under hybrid projects. Regulation 19/2025 lays the groundwork for performance standards  for  the  BESS  component  of  hybrid  assets,  which  include  flexibility capabilities to respond to demand-side fluctuations, frequency and voltage control stability,  and  the  inclusion  of  an  energy  management  system  that  optimises operational  cost  while  preserving  frequency  and  voltage  quality.  While  these standards are an important first step to enabling availability-based remuneration, regulatory clarity could be further improved through the quantification of performance requirements. Moreover, existing MEMR regulation has yet to explicitly define ancillary services as they relate to BESS assets. Clear identification of which services fall under this category, with quantified links to performance standards, will be important enablers of PLN's first ancillary service procurements.

## Energy-based remuneration

Energy-based payments compensate BESS assets on a per-kilowatt-hour basis for electricity  that  is  consumed or injected onto the grid. The most common service remunerated through energy-based payments is energy arbitrage, in which BESS assets are charged when electricity prices are low and discharged when electricity prices  are  high,  therefore  benefiting  from  electricity  price  spreads.  While  such remuneration  does  not  come  with  the  predictability  of  capacity-  and  availabilitybased payments, energy arbitrage allows BESS assets to access significant upside potential, especially within systems with growing shares of solar PV generation.

As a merchant mechanism, energy-based remuneration often utilises transparent spot pricing in liberalised electricity markets  to  drive charging/discharging decisions. As a result, Indonesia's vertically integrated and single-buyer system using fixed tariffs is not currently able to accommodate energy arbitrage services. However, such mechanisms could become a possibility should PLN ever choose to  adopt  time-of-use  electricity  pricing.  Such  a  mechanism,  which  would  align electricity prices with daily demand trends, would enable BESS operators to be remunerated on a per-kilowatt-hour basis based on when they choose to charge or discharge their assets.

BESS services and expected remuneration approach

| Service type                       | BESS service                                             | Expected remuneration approach   | Current readiness level in Indonesia   |
|------------------------------------|----------------------------------------------------------|----------------------------------|----------------------------------------|
| System reliability and flexibility | Black-start capabilities                                 | Capacity                         |                                        |
| System reliability and flexibility | Renewables smoothing                                     | Capacity Capacity                |                                        |
| System reliability and flexibility | Peak capacity                                            |                                  |                                        |
| System reliability and flexibility | Renewables Renewables firming                            | Availability Availability        |                                        |
| System reliability and flexibility | Electricity price arbitrage                              | Energy                           |                                        |
| Ancillary services                 | Contingency reserve                                      | Capacity                         |                                        |
| Ancillary services                 | Ramping reserve                                          | Capacity                         |                                        |
| Ancillary services                 | Frequency regulation                                     | Availability                     |                                        |
| Ancillary services                 | Voltage support                                          | Availability                     |                                        |
| Grid support                       | Synthetic inertia services Transmission and distribution | Availability                     |                                        |
| and optimisation                   | investment deferral                                      | N/A                              |                                        |
|                                    |                                                          |                                  |                                        |

= insufficient regulatory and/or market frameworks;       = additional definitions necessary in regulation and/or grid codes;

= achievable under existing frameworks.

Notes: Readiness levels are indicative and will vary depending on project type and location.

BESS assets are rarely remunerated specifically as a result of transmission and distribution investment deferral; the benefit of this service comes in the form of savings to the network operator itself.

## Blended remuneration schemes in emerging economies

While energy arbitrage by BESS assets is today most commonly found in systems with a well-established fleet of battery installations - as is the case in Australia, Germany  and  parts  of  the  United States  -  some  countries  have  succeeded  in integrating energy-based payments for storage assets using frameworks that do not rely on electricity spot markets. The ability to combine the predictability of capacityor availability-based payments with the upside potential of energy-based remuneration - consistent with the partial tolling business model - enables BESS operators to harness the full potential of their assets by providing a wide range of system services.

In South Africa, state-owned utility Eskom is vertically integrated and accounted for nearly 90% of the country's electricity generation in 2025. The Renewable Energy Independent  Power  Producers  Procurement  Programme  enables  BESS  assets developed by IPPs to sell power to Eskom through long-term PPA contracts. In project procurement stages, Eskom also offers five-year contracts for operations and  maintenance  (O&amp;M)  services.  Together,  these  contracts  provide  steady remuneration to IPP developers. Meanwhile, assets that charge during periods of low-cost generation (especially during midday) and discharge during peak demand periods  support  Eskom  in  avoiding  the  costs  of  more  expensive  peaker  plant generation,  thereby  generating  energy-based  value  for  the  utility  without  the presence of an entirely liberalised wholesale electricity market.

In the Philippines, BESS assets receive a significant portion of their remuneration through  ASPAs,  in  which  operators  are  compensated  at  a  rate  of  PHP 2.08 (Philippine pesos) per kilowatt (kW) per hour (USD 0.034/kW/hr) in exchange for providing the National Grid Corporation of the Philippines (NGCP) with frequency reserves and PHP 1.50/kW/hr (USD 0.02/kW/hr) for contingency reserves. Since these services are performance-linked, payments act as availability-based remuneration.  The  Philippines  has  also  developed  a  wholesale  electricity  spot market (WESM) system that allows electricity producers to engage in market-based competition. The rate at which electricity injected by BESS assets is compensated on the WESM is determined by the sum of ancillary service payments and variable costs, enabling developers to recover O&amp;M expenses through energy payments.

## Case study on Viet Nam's PPA framework for standalone BESS assets

Like Indonesia, Viet Nam's power sector operates under a single-buyer system in which Viet Nam Electricity (EVN), the country's state-owned utility, sells electricity at  government-regulated  retail  tariff  levels.  With  an  objective  of  increasing  the share of renewables in primary energy supply to 15-20% by 2030 and around

65-70% by 2045, Viet Nam faces many of the same challenges related to power sector expansion and increased need for system flexibility as Indonesia. These similarities  make  Viet Nam's  Circular  62,  the  country's  first  comprehensive framework for BESS PPAs, particularly instructive in Indonesia.

Circular  62  applies  to  standalone  BESS  projects  with  capacities  exceeding 10 MW. Prices negotiated between IPPs and EVN must be greater than VND 0 (Vietnamese dong) per kilowatt-hour and cannot exceed an annually determined maximum price 𝑃𝑃 𝐶𝐶 , which is defined as follows:

<!-- formula-not-decoded -->

where 𝑃𝑃 𝐶𝐶𝐶𝐶 is the asset's fixed investment cost annualised over its economic life, 𝐹𝐹𝐹𝐹𝐹𝐹𝐹𝐹 is the fixed O&amp;M cost, and 𝑃𝑃 𝐵𝐵𝐶𝐶 is the variable cost of charging the BESS asset.  Annualised  investment  cost  ( 𝑃𝑃 𝐶𝐶𝐶𝐶 )  takes  into  consideration  the  asset's upfront  investment,  economic  life,  and  a  weighted  average  cost  of  capital  that assumes a capital structure of 70% debt and 30% equity. The variable cost of charging  ( 𝑃𝑃 𝐵𝐵𝐶𝐶 ),  meanwhile,  provides  pricing  visibility  to  operators  by  being benchmarked against Viet Nam's off-peak manufacturing retail tariff.

By  combining  fixed  and  variable  cost  components,  the  maximum  PPA  price outlined  by  Circular  62  successfully  combines  availability-  and  energy-based payments, in which the former enables developers to recover costs at a maximum internal  rate  of  return  (IRR)  of  12%  and  the  latter  compensates  the  actual discharge  of  the  asset.  In  addition  to  establishing  this  price  range  for  PPAs, Circular 62 defines technical parameters relating to BESS asset design, including discharge duration, total number of expected charge/discharge cycles over the project's  lifetime, annual  capacity  loss  rate,  rates  of  self-consumption  and transmission and distribution losses, and availability requirements.

Circular  62  aims  to  improve  revenue  projections  and,  by  extension,  project bankability by clearly defining remuneration structures for utility-scale standalone BESS.  While  the  framework  does  not  explicitly  address  how  assets  may  be compensated  for  the  provision  of  ancillary  services,  it  does  demonstrate  that bankable  payment  mechanisms  that  combine  availability-based  with  energybased  remuneration  can  exist  under  single-buyer  systems.  Moreover,  the provision of transparent formulas that place a cap on IRR enables IPPs to recover upfront costs while maintaining affordability standards for EVN.

## Investment needs and financing structures for BESS in Indonesia

## Investment needs and sources of finance

Understanding the level of investment needed to achieve the objectives of the Rencana  Usaha  Penyediaan  Tenaga  Listrik  (RUPTL),  or  Electricity  Supply Business Plan; who is responsible for those investments; and how they can be financed is necessary to identifying potential risks. Capital structures can then take these risks into consideration to arrive at financing models that are best suited to enhancing project bankability.

## Investment needs for the RUPTL's ARED scenario

The RUPTL's objective of adding around 6 gigawatts (GW) of standalone battery energy storage system (BESS) capacity and 3.6 GW of hybrid generation capacity has the potential to bring substantial benefits to Indonesia's evolving electricity grid. By supporting grid stability and reliability, BESS can help to prevent system failures  while  also  protecting  essential  infrastructure  from  potentially  damaging frequency or voltage fluctuations. Moreover, the provision of peak capacity and ramping reserve services can provide PT Perusahaan Listrik Negara (PLN) an alternative  to  calling  upon  expensive  diesel  generators  during  periods  of  high demand, while also absorbing more power from solar photovoltaic (PV) and wind generation. In the United Kingdom, BESS installations helped consumers save an estimated USD 27 million from January to April 2026 by reducing curtailment of wind  power  and  discharging  at  a  lower  price  than  fossil  fuelled  peaker  plants. Nearly 40% of these savings occurred in the months of March and April, when the cost of fuel inputs for gas-fired generation increased significantly.

Finally,  hybrid  solar  PV  and  BESS  installations  have  already  become  costcompetitive  with  small-scale  diesel  generation  in  remote  regions  (see  next chapter). In Indonesia, where connecting hundreds of small islands to the national grid  would  be  expensive  and  time-consuming,  hybrid  installations  have  the potential  to  more  quickly  improve  access  to  decarbonised,  reliable  sources  of electricity.

A total of USD 5 billion is needed to achieve the battery storage additions detailed in the RUPTL's Accelerated Renewable Energy Development (ARED) scenario from 2025 to  2034, roughly  equivalent  to  the  country's  spending  on  fossil  fuel power in 2025 alone. This level of investment takes into consideration the capital

expenditures for standalone systems and the BESS component of hybrid systems, grid connection expenses and additional spending on battery capacity augmentations.

## Total investment needs by cost scenario, 2025-2034 cumulative

<!-- image -->

IEA. CC BY 4.0.

Note: MER = market exchange rate. Source: See Annex for the full methodology and sources used for investment needs modelling.

Even though battery costs are rapidly declining, the use cases and associated technical specifications of BESS installations that PLN will choose to prioritise can have significant impacts on capital costs. In order to capture a realistic range of investment needs based on varying decisions, three cost scenarios are modelled. Each  of  these  scenarios  differs  based  on  relative  costs  in  different  PLN subsystems with varying degrees of isolation, annual battery degradation rates, capacity of BESS relative to solar PV in hybrid installations, and battery storage duration:

-  Cost  efficiencies  scenario :  PLN  prioritises  the  lowest-cost  technologies, opting  for  shorter  storage  durations  (mainly  one  to  two  hours)  and  smaller shares  (10%)  of  BESS  capacity  relative  to  solar  PV  installations.  Annual degradation rates are kept low (1%) as a result of strict limitations on battery cycling, and installation costs are minimally variable across regions due to a prioritisation of easily accessible locations.
-  RUPTL-aligned scenario : PLN adheres to the technical parameters that are implied in the RUPTL, prioritising systems with four-hour storage durations and sizing  BESS  to  20%  of  solar  PV  additions  in  hybrid  projects.  Annual degradation rates are 2% and the variation in capital and installation costs across  subsystems  is  proportional  to  that  of  system-level  Biaya  Pokok Penyediaan (BPP) in 2025.

-  High costs scenario : The decision to expand into a wider variety of use cases compels PLN to invest in technologies ranging from one- to eight-hour storage durations, and the storage component of hybrid projects is equivalent to 30% of  the  solar  PV  component's  generation  capacity.  More  frequent  battery cycling brings annual degradation rates to 3%, and the expansion into more remote  areas  results  in  a  higher  degree  of  cost  differentiation  across subsystems.

## Breakdown of differences in total investment across cost scenarios, 2025-2034

<!-- image -->

IEA. CC BY 4.0.

Note: MER = market exchange rate. Source: See Annex for the full methodology and sources used for investment needs modelling.

Total spending in the cost efficiencies scenario reaches USD 3.8 billion - threequarters  of  the  RUPTL-aligned  scenario's  USD  5  billion.  Over  55%  of  this difference can be accounted for by the use of technologies with shorter storage durations. Where the RUPTL-aligned scenario mainly opts for systems that can charge or discharge at maximum power for up to four hours, the cost efficiencies scenario favours one- and two-hour batteries. In general, the per-kilowatt capital costs of power storage batteries increase by a factor of 1.7 for every doubling in storage  duration,  implying  cost  reductions  when  shorter-duration  batteries  are used. However, these savings come at the expense of a more limited range of services. While most of the services expected to be delivered by standalone BESS assets  can  be  performed  using  one-  and  two-hour  duration  storage,  longerduration BESS  in  hybrid projects will become  increasingly important for renewables shifting as variable renewable energy penetration in the grid mix rises.

In  the  high  costs  scenario,  total  investment  for  the  RUPTL's  ARED  pipeline reaches USD 7.7 billion. Greater levels of deployment of standalone and hybrid BESS projects in isolated regions account for one-third of the increase relative to the RUPTL-aligned scenario. Meanwhile, the shift in annual degradation rate from

2%  to  3%  increases  total  investment  by  20%  as  a  result  of  greater  capacity augmentation needs. Increasing the BESS-to-solar PV ratio in hybrid installations from 20% to 30% accounts for a 25% increase in total investment. While the high costs scenario results in an additional USD 2.6 billion of investment, it also offers a  higher  degree  of  flexibility  through  the  availability  of  many  BESS  services. Moreover,  the  installation  of projects in isolated regions  contributes  more substantially to PLN's objective to improve electricity access without undertaking expensive grid expansions.

## Average annual investment needs by subsystem and scenario, 2026-2034

<!-- image -->

IEA. CC BY 4.0.

Note: MER = market exchange rate. Source: See Annex for the full methodology and sources used for investment needs modelling.

While  spending  on  utility-scale  BESS  prior  to  2025  was  minimal,  annual investment reaches USD 550 million from 2026 to 2029 and USD 560 million from 2030 to 2034 according to the RUPTL-aligned scenario. Driven by the construction of Indonesia's new capital city of Nusantara, the island of Kalimantan accounts for one-third of investment in the first half of the RUPTL period, reaching close to USD 180 million annually. Similar trends apply in the first half of the cost efficiencies scenario, though the region of Java, Madura and Bali takes on a slightly larger share  of  total  investment  (24%)  as  fewer  projects  are  undertaken  in  remote regions. In the high costs scenario, spending in the region of Maluku, Papua and Nusa Tenggara reaches an average of USD 190 million annually as projects in isolated regions - especially hybrid installations that aim to replace ageing diesel generators - are prioritised.

By contrast, investment during the second half of the RUPTL period - from 2030 to 2034 - is dominated by the region of Java, Madura and Bali, which accounts for around 60% of investment across all three cost scenarios. This is a result of rapidly  rising  electricity  demand  in  the  country's  most  populous  islands,  which

drives a need for additional sources of system flexibility. This rising demand in electricity is addressed in part by additions of renewable energy generation in the region Sulawesi, which is at times paired with BESS to create hybrid systems. In the high costs scenario, which assumes a BESS-to-generation sizing ratio of 30%, spending in Sulawesi exceeds USD 160 billion annually from 2030 to 2034.

## Share of investment by technology (left) and total investment by cost component (right) by region, 2025-2034

<!-- image -->

IEA. CC BY 4.0.

Note: MER = market exchange rate; SMT = Sumatra; JMB = Java, Madura and Bali; KLM = Kalimantan; SLW = Sulawesi; MPNT = Maluku, Papua and Nusa Tenggara.

Source: See Annex for the full methodology and sources used for investment needs modelling.

In the RUPTL-aligned scenario, system capital costs - which include expenses for physical battery equipment and associated infrastructure, engineering, procurement and construction (EPC) costs, and additional development margins -  account  for  over  three-quarters  of  total  investment.  Augmentation,  in  which battery capacity is replaced to keep assets' nameplate capacities consistent as equipment naturally degrades with time, is another important source of capital expenditure for developers. A total of nearly USD 90 billion, or 18% of spending, across  all  five  regions  is  invested  in  additional  BESS  capacity  to  account  for annual degradation rates of 2%. While investment needed for the connection of BESS projects to PLN's grid infrastructure is relatively small, its share of total costs varies by region. For example, cumulative BESS additions in Kalimantan are 40% higher than in Maluku, Papua and Nusa Tenggara; however, the higher degree of isolation for projects on Indonesia's easternmost islands results in grid connection spending that is USD 4 million higher than in Kalimantan.

## The cost of capital for BESS remains high in Indonesia

An elevated cost of capital is a barrier to scaling BESS in Indonesia. The cost of capital reflects the minimum rate of return required to justify an investment and is particularly important  for  capital-intensive  technologies  such  as  BESS  and renewable power technologies, where financing costs make up a large share of lifetime project costs.

The weighted average cost of capital (WACC) - the weighted average of financing costs from both debt and equity - for utility-scale BESS in Indonesia was in the range of 9-11% in 2024. This is almost double levels seen in advanced economies (5-6.5%).  While  this  is  competitive  relative  to  other  emerging  market  and developing economies (EMDE), the premium materially impacts project costs and bankability. Notably within the Association of Southeast Asian Nations (ASEAN), the  Philippines  (7-8%)  sees  a  lower  cost  of  capital  than  Indonesia,  reflecting established regulatory framework and remuneration mechanisms, greater market experience in deploying BESS, and a lower cost of debt from domestic lenders. Despite  showing  a  country  premium,  the  2024  cost  of  capital  for  BESS  in Indonesia does not come with a substantial technology premium, as evidenced by its  alignment  with  other  technologies  such  as  solar  PV  (8.5-11%),  natural  gas generation (9-10%), hydropower (9-11%) and offshore wind (10.5-11.5% in 2023).

## Weighted average cost of capital for utility-scale BESS in selected countries and advanced economies, 2024

<!-- image -->

WACC range

IEA. CC BY 4.0.

Note: Median WACC (nominal, post-tax, local currency) gathered from survey respondents. Responses capture a mix of actual WACC from financed projects, and WACC expectations from respondents.

Source: IEA (2025), Cost of capital observatory dashboard.

Cost of capital reflects real and perceived risks faced by investors at the country, sector and project levels. Market participants surveyed through the IEA Cost of Capital Observatory cite political, regulatory and permitting risks as the key risks contributing to elevated cost of capital in Indonesia.

Policy and regulatory shifts can add to perceived risks for investors. The absence of an established business model and remuneration for standalone BESS means that prospective  investors  do  not  have  visibility over  long-term  revenues, preventing  projects  from  being  considered  for  financing.  Procurement  and permitting processes are viewed by developers as complex and slow-moving, and the involvement of multiple government bodies adds to the risk of project delays. A  lack  of  transparency  in  procurement  and  permitting  also  reinforces  risk perceptions. Moreover, projects may incur currency risk if the currency of BESS revenues - most likely to be in Indonesian rupiah - differ from the currency through which  the  project  receives  financing.  In  these  cases,  a  depreciation  in  local currency would hamper the project's ability to repay debt obligations.

Finally, a mismatch between the loan tenor and asset life can make debt servicing more  challenging.  Most  domestic  commercial  lending  to  the  private  sector  is between  three  and  five  years,  with  longer  tenors  for  loans  to  state-owned enterprises (SOEs). This is significantly shorter than the expected average lifetime of BESS assets, which generally lies between 10 and 15 years. As a result, annual debt servicing requirements may be particularly high and even risk refinancing, in which  front-loaded  debt  service  creates  a  cash  flow  shortfall  during  the  BESS asset's first operating years, compelling developers to seek new financing under potentially less favourable terms.

## Sources of finance and concessional funding

While total investment needs indicate the magnitude of capital needed to achieve the RUPTL ARED scenario's BESS objectives, understanding where that capital comes from - and how it is financed - can give more precise indications of how the  necessary  capital  can  be  mobilised.  The  following  section  breaks  down investment needs  according to the RUPTL-aligned  scenario by sponsor, instrument and financier.

The RUPTL 2025-2034 directly allocates capacity additions for standalone BESS and hybrid projects to PLN (and its sub-holdings or subsidiaries) and independent power  producers  (IPPs).  Capacities  allocated  to  PLN's  sub-holdings  can  be undertaken solely by that entity or in collaboration with IPPs in a joint venture, in which case the PLN sub-holding retains a majority (51% or greater) ownership share of the project. For the purposes of this analysis, investments associated with the  capacities  allocated  to  PLN's  sub-holdings  are  therefore  considered  to  be SOE-led.

In the RUPTL-aligned scenario, PLN and its sub-holdings account for USD 3 billion, or 60%, of total investment. PLN is the main sponsor in the regions of  Sumatra  and  Java,  Madura  and  Bali,  where  standalone  BESS  projects  are closely  aligned  with  the  utility's  mandate  to  maintain  the  reliability  of  electricity supply. The state-owned utility also invests close to USD 115 million in the region of Maluku, Papua and Nusa Tenggara, where projects that emphasise improved access to electricity - rather than system reliability - require public participation to achieve bankability.

## Sponsor breakdown of total BESS investment in the RUPTL-aligned cost scenario by region

<!-- image -->

IEA. CC BY 4.0.

Note: JMB = Java, Madura and Bali; MPNT = Maluku, Papua and Nusa Tenggara; SOE = state-owned enterprise. Source: Sponsorship shares are directly calculated according to RUPTL 2025-2034 capacity additions. See Annex for the full methodology and sources used for the sources of finance modelling.

Through the participation of IPPs, the private sector contributes an additional USD 2 billion - mainly in the regions of Kalimantan; Sulawesi; and Maluku, Papua and Nusa  Tenggara.  Taken  together,  these  regions  account  for  over  80%  of  the country's additions of solar PV-plus-BESS hybrid additions. The higher degree of complexity of hybrid projects - which PLN has limited experience in developing justifies the involvement of IPPs, which can often bring high degrees of technical experience. Moreover, current regulation more readily enables IPPs to monetise the BESS component of hybrid assets through bundled PPA agreements, while PLN  is  constrained  to  recovering  the  costs  of  new  generation  assets  through regulated electricity tariffs that broadly fall beneath required levels.

Overall,  PLN  generally  favours  projects  that  directly  support  its  mandates  and strategic  initiatives,  and  that  are  located  in  relatively  low-risk  geographies  with existing transmission and distribution grid infrastructure. This preference is driven by constraints on the utility's balance sheet: with a high level of legacy debt and

limited ability to generate revenue beyond the sale of electricity at regulated tariff levels, PLN is compelled to prioritise BESS projects that serve primarily as network - rather than generation - assets.

## Instrument breakdown of total BESS investment in the RUPTL-aligned cost scenario by region

<!-- image -->

Debt includes capital raised through loans, bonds, or lines of credit that must be repaid with interest. Includes capital which must be repaid at both market and concessional rates.

Equity is measured by the value of a sponsor's ownership of an asset. Rather than interest payments, equity holders can receive dividends from operational profits and also benefit from asset appreciation.

IEA. CC BY 4.0.

Source: S&amp;P Capital IQ (2026), PT Perusahaan Listrik Negara corporate finance dataset, accessed July 2026; Green Street Infrastructure (2026), Infrastructure project finance dataset, accessed July 2026. See Annex for the full methodology

Note: JMB = Java, Madura and Bali; MPNT = Maluku, Papua and Nusa Tenggara. and sources used for the sources of finance modelling.

The instruments used to finance BESS investments are closely tied to the type of sponsor that is making those investments. As an SOE and provider of essential grid services, PLN must remain in solid fiscal health and avoid becoming overly dependent on debt. PLN thereby tends to rely more heavily on equity financing for the assets it owns directly, particularly in regions where project risks are relatively low.  From  2025  to  2034,  75%  of  the  USD  2.6  billion  in  total  equity  flows  are invested in the regions of Sumatra and Java, Madura and Bali.

By  contrast,  debt  finances  at  least  60%  of  investments  in  the  regions  of Kalimantan; Sulawesi; and Maluku, Papua and Nusa Tenggara, totalling USD 2.5 billion  across all regions. IPPs, which are the main sponsors of investments in these  regions,  generally  use  project  finance  models  to  structure  their  projects financially, which allow them to raise debt relative to project cash flows. Domestic debt providers, as well as international financiers, also favour hybrid projects over standalone assets due to the long-term revenue visibility offered by bundled PPAs. Projects in the region of Kalimantan receive the greatest absolute level of debt investments, totalling USD 680 million.

The relative shares of equity and debt used to finance the RUPTL's BESS pipeline can provide insights into project bankability and potential risks. Equity financing generally comes with higher financing costs but is also better suited to absorbing risks  associated  with  first-of-a-kind  projects  -  when,  for  instance,  cash  flow

certainty is limited for standalone projects. Regions such as Sumatra and Java, Bali and Madura therefore risk delays in deployment should PLN's balance sheet grow more constrained. Debt, on the other hand, is associated with lower financing costs but requires more concrete revenue streams. Providing cash flow certainty through  stable regulatory frameworks  is  therefore  essential to scaling up deployments  in  the  regions  of  Kalimantan;  Sulawesi;  and  Maluku,  Papua  and Nusa Tenggara.

## Financier breakdown of total BESS investment in the RUPTL-aligned cost scenario by region

<!-- image -->

IEA. CC BY 4.0.

Note: JMB = Java, Madura and Bali; MPNT = Maluku, Papua and Nusa Tenggara; MCFs = multilateral climate funds; DFIs = development finance institutions; ECAs = export credit agencies.

Source: See Annex for the full methodology and sources used for the sources of finance modelling.

Half  -  or  USD  2.5  billion  -  of  the  investment  needed  for  the  RUPTL's  BESS additions is financed by commercial providers, which include both domestic and international commercial  banks.  This  is  particularly  true in regions  where development is led by IPPs, which predominantly finance their projects through debt acquired from commercial banks. Domestic commercial banks such as Bank Mandiri, Bank Rakyat Indonesia, Bank Central Asia, and Bank Negara Indonesia are most likely to finance hybrid installations that benefit from long-term PPAs, and  are generally less sensitive to political risks than their international counterparts. While PLN's regulated income makes the utility investment-grade for  many  commercial  debt  providers,  lenders  typically  prefer  to  engage  with projects  that  are  financed  on-balance  sheet,  which  minimises  the  risk  of  loan repayment delays due to insufficient BESS revenues.

The government of Indonesia, by contrast, finances the equity portion of PLN-led investments, which totals USD 2.1 billion from 2025 to 2034. Meanwhile, public debt  providers  include  PT  Sarana  Multi  Infrastruktur  (PT  SMI)  -  the  country's

state-backed infrastructure development institution - as well as Indonesia's two sovereign  wealth  funds,  Indonesia  Investment  Authority  and  Daya  Anagata Nusantara (Danantara).

The  third  and  final  portion  of  investment  is  financed  by  international  public financiers, which provide around USD 275 million in funding. The region of Maluku, Papua and Nusa Tenggara accounts for 31% of this total, with an additional 20% supporting investment in Kalimantan. International public financiers use a wide range of instruments, including loans, grants, guarantees, results-based financing and blended finance structures, to support BESS projects - often at concessional financing rates. These instruments are particularly crucial for supporting first-of-akind  projects,  especially  in  geographies  with  limited  access  to  existing  grid infrastructure, by reducing the cost of capital and shouldering first-loss risks to strengthen private investor confidence.

## The Indonesia Just Energy Transition Partnership

An important potential source of both concessional and commercial finance is the Indonesia  Just  Energy  Transition  Partnership  (JETP).  Established  in  2022,  the JETP aims to mobilise USD 20 billion in  financing  from both  public  and  private sources to support Indonesia in reaching its decarbonisation and renewable energy development  targets  by  2030.  The  Comprehensive  Investment  and  Policy  Plan (CIPP)  created  within  the  framework  of  the  JETP  is  a  non-binding  pathway  for Indonesia  to  achieve  peak  power  sector  emissions  of  250  million  tonnes  and  a renewables share of 44%, both by 2030.

Under the CIPP, battery energy storage is considered a critical contributor of system flexibility and reliability, which itself becomes increasingly important as the share of renewables  in  Indonesia's  grid  rises.  Moreover,  the  health  benefits  of  replacing incumbent diesel power with solar PV-plus-BESS installations, especially on small or  isolated  island  systems, fit squarely  within  JETP  priorities.  As  a  result,  BESS projects - especially first-of-a-kind installations in Indonesia's easternmost region of Maluku, Papua and Nusa Tenggara, are strong candidates for JETP funding.

Concessional  finance  broadly  constitutes  capital  support  that  is  offered  with favourable terms relative to market conditions. Multilateral climate funds (MCFs), development  finance  institutions  (DFIs),  export  credit  agencies  (ECAs)  and bilateral lending are common sources of concessional capital, though domestic public financiers  may  also  offer  support  on  concessional  terms.  Financial instruments include grants, guarantees, and loans offered at relatively low interest rates and/or long tenors, while additional support through capacity building, policy

development and technical assistance can facilitate the transfer of valuable skills and knowledge. By assuming subordinate positions in project capital structures, concessional financiers play an important role in de-risking early-stage projects and boosting project bankability enough to encourage private sector participation.

## Annual investment and concessional financing share in the RUPTL-aligned scenario, 2026-2034

<!-- image -->

IEA. CC BY 4.0.

Source: See Annex for the full methodology and sources used to estimate concessional financing needs.

The  RUPTL-aligned  scenario  estimates  that  USD  460  million,  or  9%  of  total investment required to install its BESS pipeline, is needed to support the RUPTL's first BESS  projects, in addition to projects located in isolated regions. Concessional financing needs are highest in the first half of the RUPTL period, averaging USD 53 million annually from 2025 to 2029. However, this declines to an average of USD 39 million from 2030 to 2034 as regulation, financing structures and revenue streams are proven and project sizes are scaled up. Due to limited access to grid infrastructure, the region of Maluku, Papua and Nusa Tenggara receives  20%  of  total  concessional  capital.  However,  the  high  volume  of standalone projects in Java, Madura and Bali - which currently face bankability challenges  due  to  a  lack  of  regulatory  frameworks  to  define  remuneration  ultimately drives this region to receive nearly half of total concessional financing over the RUPTL period.

## Financing structures for BESS

While business models shape how a BESS project generates revenue, financing structures determine the project's capital stack, the return requirement necessary for project viability, and how risk is allocated among stakeholders. The type of

financing structure is largely determined by the level of certainty around revenue streams and, to a lesser extent, who is sponsoring investments.

## Summary of financing models

|                       | Corporate finance (on- balance-sheet)                                           | Project finance (off-balance- sheet)                                                                                      |
|-----------------------|---------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------|
| Ownership             | Utility-owned (PLN)                                                             | Project company (special purpose vehicle) owned by IPP sponsors and/or PLN                                                |
| Main instruments used | State capital injection, corporate loans and bonds (often sovereign guaranteed) | Sponsor equity, project debt (non- recourse or limited recourse)                                                          |
| Credit basis          | PLN corporate credit and/or sovereign support                                   | PPA bankability and off-taker (PLN) credit risk                                                                           |
| Repaid through        | PLN's consolidated revenues (tariffs and government compensation)               | Project revenues under the PPA (capacity or tolling payments)                                                             |
| Ideally suited to     | Network assets, grid-connected BESS providing system services                   | Hybrid assets with a contracted revenue stream (e.g. tolling or capacity payments)                                        |
| Key advantages        | Speed, lower cost of capital via sovereign backing                              | Mobilises private capital, no direct burden on PLN balance sheet, transfers construction and performance risk to sponsors |
| Risks                 | Crowds PLN's constrained balance sheet and competes with other CAPEX            | Higher transaction costs and longer lead times; potential foreign exchange mismatch                                       |

Notes: Non-recourse financing means lenders are repaid solely from project cash flows, with no claim on sponsors' balance sheets beyond their equity commitment. Limited-recourse structures add narrowly defined sponsor obligations, typically during construction. Off-balance sheet does not imply purely private ownership. PLN, its subsidiaries or other SOEs can participate in the project company as minority or majority shareholders.

## Financing for PLN-led projects

Projects developed by PLN and its sub-holdings will typically rely on corporate financing structures, which raise capital at the company level and use PLN's entire balance sheet, rather than project cash flows. A combination of sovereign-backed and corporate loans from institutions including the Ministry of Finance, PT SMI and  commercial  banks  provide  debt,  while  equity  is  made  available  through government injections or PLN's retained earnings. Corporate financing structures

provide PLN with the flexibility to allocate capital internally, allowing the utility to prioritise projects that most directly support objectives related to improving system reliability and grid stability.

Relatively lower transaction complexity, in addition to the security that comes with having debt be secured by a combination of PLN's total revenues, regulated tariffs, and the government of Indonesia's support through subsidies and cash injections, mean  that  corporate  financing  structures  are  generally  associated  with  lower financing costs. However, PLN's capacity to take on additional debt is constrained by its already highly leveraged balance sheet, restrictions on borrowing limits due to its status as an SOE and single borrower limits. As a result, both standalone and hybrid BESS projects that are supported by corporate finance must compete with  other  essential  investments  such  as  transmission  and  distribution  grid expansions and generation additions.

<!-- image -->

BESS  projects  that  are  closely  aligned  with  PLN's  mandates  -  especially standalone installations in regions with well-developed grids - are best suited to corporate  financing  structures.  However,  lenders  under  corporate  financing structures  make  capital  available  at  a  broad,  balance-sheet  level,  and  are therefore more concerned with PLN's overall cash flow rather than that of specific BESS assets. As a result, this financing structure does not provide incentives to measure BESS performance, and therefore is not well suited to the development

of  frameworks  for  availability-based  payments  and  the  provision  of  ancillary services whose remuneration is linked to asset performance. Standalone BESS assets that serve as extensions of transmission grid infrastructure by providing frequency  regulation,  voltage  support  and  congestion  management  services  therefore  having  minimal  operational  complexity  -  are  most  likely  to  succeed under corporate financing structures.

## Financing for IPP-led projects

In contrast to PLN's corporate financing approach, BESS installations developed by IPPs are most likely to follow a project financing model. Under this approach, IPPs begin by creating a special purpose vehicle (SPV) that is responsible for development and ownership of the asset. The SPV may be formed by a single private developer but can also be established by a consortium of sponsors that includes other private developers, institutional investors and, in some cases, PLN or its sub-holdings. The SPV then raises capital - typically a mix of non-recourse debt  and  sponsor  equity  -  that  is  repaid  directly  through  the  BESS  asset's contracted revenues. Therefore, lenders will carefully consider the details of an asset's design, including services provided and technical characteristics (such as storage  duration,  degradation  rate  and  round-trip  efficiency),  as  well  as  the availability  of  regulatory  frameworks  that  guarantee  the  ability  for  assets  to generate steady cash flows.

Under project financing models, lenders' perceptions of risk - and resulting cost of capital - are closely tied to the predictability of the asset's revenue streams. The SPV is ring-fenced from its parent company (or companies), so lenders have a limited access to sponsors' balance sheets to recoup their investments. As a result, project financing  structures  are  just as  well suited  to experienced developers  managing  a  variety  of  assets  as  they  are  to  new  market  entrants. Under Indonesia's direct selection procurement procedure, which uses competitive  tendering  to  allocate  projects  to  IPPs,  the  use  of  project  financing structures  can  therefore  put  downward  pressure  on  the  tariff  that  PLN  offers private developers by enabling the participation of a broader range of developers, including those who are willing to assume the risks of bidding low prices in order to win projects - with the prospects that BESS projects will become profitable over the long term.

<!-- image -->

Because lenders expect long-term, predictable revenue streams, project finance is well suited to hybrid BESS projects with clearly defined tariffs and standalone BESS installations that receive availability-based payments in exchange for the provision of specific grid and ancillary services such as capacity reserves, load smoothing and frequency regulation. Under power purchase agreements (PPA) contracts or ancillary services procurement agreements, these projects receive steady cash flows that can accommodate high leverage ratios and thereby reduce the amount of equity that project sponsors must contribute. Taken together, these characteristics  facilitate  rapid  deployment  in  regions  where  PLN  prefers  not  to employ its own balance sheet - especially across the eastern islands of Maluku, Papua and Nusa Tenggara.

In the case of joint ventures between IPPs and PLN, which are explicitly permitted under  the  RUPTL  2025-2034,  project  financing  models  can  still  accommodate shared ownership while maintaining the benefits of SPV ring-fencing. While PLN or its sub-holding will account for a minimum of 51% of shareholding in the SPV, the IPP (or consortium thereof) can retain ownership of the asset throughout its development, construction and operation phases. PLN's involvement can facilitate permitting, land access and grid connection, while the IPP contributes expertise in the development and operation of the asset. This hybrid structure therefore allows PLN to gain experience in installing BESS assets that it can then apply to its own projects.

## Types of independent power producers

While this report refers to IPPs as a broad group, in reality they comprise a variety of different types of private developers. IPPs will have varying levels of experience in  developing  BESS,  as  well  as  distinct  tolerances  for  risk  and  expectations  for internal  rate  of  return.  One  way  to  distinguish  between  different  IPPs  is  by considering where they generally do business:

Local  developers  such  as  Xurya  Daya  Indonesia,  PT  Sumber  Energi  Surya Nusantara and MedcoEnergi operate primarily in Indonesia. As a result, they are likely to rely more on local banks, face tighter borrowing limits and may have limited access to international capital. However, their familiarity with Indonesia translates to a robust knowledge of local regulations and permitting procedures, while lending from domestic banks reduces currency risk.

Regional developers including Sembcorp Industries (Singapore), ACEN Renewables  (Philippines),  and  Vena  Energy  (Singapore)  operate  in  Southeast Asian countries. These developers generally have access to regional commercial banks such as DBS (Singapore) and Maybank (Malaysia), which may offer capital at lower  rates than local institutions. Technical  assistance  programmes  or collaborations with PLN through joint ventures can support regional developers in addressing challenges related to regulatory unfamiliarity, especially  for their first Indonesian projects.

International  developers  such  as  ib  vogt  (Germany),  EDF  (France)  and    (Saudi Arabia) have global portfolios and operate with larger balance sheets than their local and regional counterparts. Their scale facilitates access to international lenders, and often leads them to favour a portfolio - rather than project-by-project - approach to development.  However,  international  developers  require  high  degrees  of regulatory certainty before entering new markets.

## The role of concessional and blended finance

According to the RUPTL-aligned costs scenario, an annual average of USD 300 million  in  financing  on  PLN's  balance  sheet,  as  well  as  an  annual average of USD 210 million in private sector financing, will be required to deploy the RUPTL's full BESS pipeline. Given the historically low levels of investment in BESS so far, these figures represent significant increases in spending over a short period of time. While constraints on PLN's balance sheet may limit PLN's ability to raise  more  debt  without  negatively  impacting  its  credit  rating,  private  sector investors currently lack the long-term visibility on revenue streams that is needed

to secure  sufficient  financing.  However,  concessional  funding  can  play  an important role in boosting the bankability of the RUPTL's first BESS projects and bridge investment gaps.

Concessional finance refers to funding in the form of loans, grants, guarantees or equity  that  is  provided  on  more  favourable  terms  than  those  of  commercially available sources of finance. Typically offered through bilateral support, multilateral development banks, bilateral DFIs and ECAs - concessional finance can lower the cost of capital by providing funding at below-market interest rates. Longer loan tenors are also particularly beneficial to BESS projects, which typically have  lifetimes  that  exceed  the  tenors  of  commercial  loans.  Blended  finance structures, in which concessional instruments are combined with commercial debt or  equity,  can catalyse  further  private  sector  investments  by assuming specific risks, such as delays in project development or technology underperformance.

Structures that integrate concessional support move traditional instruments into less risky portions of the capital stack

Capital stack without concessional financing

## Capital stack with concessional financing and other support

Senior debt

Subordinated debt

Preferred equity

Common equity

Senior debt

Subordinated debt

Concessional debt

Preferred equity

Common equity

Grants, capacity building, and technical assistance

Higher priority of repayment translates to lower risk for investors

Lower priority of repayment results in higher risk

IEA. CC BY 4.0.

In PLN-sponsored projects, structured according to corporate financing principles, concessional finance generally appears in the form of sovereign-backed loans or equity injections channelled  through  the government  of  Indonesia. Equity injections  from  the  state  to  PLN  -  either  directly  or  through  state-backed development banks such as PT SMI - can be funded by low-interest, long-tenor loans provided by MDBs such as the World Bank or the Asian Development Bank (ADB). As a result, PLN's needs for commercial borrowing are reduced and its balance sheet benefits from a lower leverage ratio. Since corporate finance does not  distinguish  between  the  costs  and  revenues  from  each  of  PLN's  assets, sovereign-backed  loans  or  equity  injections  may  require  clear  earmarking  or disbursement conditions that are linked to performance in order to ensure that BESS projects receive the concessional funding as intended.

By  contrast,  BESS  assets  developed  by  IPPs  with  project  finance  structures typically receive concessional financing directly at the SPV level. Loans provided at below-market interest rates bring down the cost of capital, and can also take subordinated  positions  to  ensure  that  commercial  lenders  are  repaid  first. Meanwhile, guarantees can mitigate concerns about regulatory uncertainty, which is particularly important for first-of-a-kind projects that often serve to demonstrate how regulations are implemented in practice. In joint ventures between IPPs and PLN, concessional finance is also provided directly at the SPV level to support both parties. The ring-fenced nature of project financing structures often makes them favourable to MDBs relative to corporate financing, as it allows them to target precise projects and more accurately measure additionality.

The  use  of concessional financing instruments for targeted projects can demonstrate the bankability of BESS assets and their revenue structures, thus allowing similar projects to subsequently be scaled up and more rapidly deployed. Therefore, concessional funding is most effective when used precisely to support first-of-a-kind projects, assets in higher-risk regions or projects aiming to benefit from yet-untested revenue streams. For instance, the first utility-scale standalone installation on the island of Java and the first solar PV-plus-BESS project on the island of Sulawesi are likely to benefit from relatively higher shares of concessional funding  than  similar  projects  in  subsequent  years.  These  instruments  must  be used  in  combination  with  exit  strategies  that  clearly  define  the  stage  at  which concessional financing is no longer provided. The achievement of certain projects or market conditions can trigger the exit of below-market rate loans, thus enabling that capital to be recycled towards other projects.

## Concessional finance for BESS projects in South Africa and Cambodia

Established  in  2008,  the  Climate  Investment  Funds  (CIF)  is  one  of  the  world's largest multilateral climate funds (MCF). CIF channels concessional financing and technical assistance through six multilateral development banks (MDBs) to address high  financing  costs,  accelerating  the  deployment  of  low-emissions technologies and facilitating the ability of private actors to support energy projects in emerging markets. CIF's Clean Technology Fund (CTF) supports BESS investment, notably through  its  Renewable  Energy  Integration  (REI)  programme  and  its  Dedicated Private Sector Program (DPSP), under which the Global Energy Storage Program (GESP),  launched  by  CIF  in  2019,  is among  the  world's  first investment programmes dedicated to piloting storage solutions for renewable power including BESS.

South  Africa's  battery  energy  storage  programme,  implemented  by  state-owned utility  Eskom  and  supported  by  the  CTF,  is  among  the  largest  grid-scale  BESS installations on the African continent. Targeting a total of 360 MW/1440 MWh of BESS  deployment,  the  programme  benefits  from  multiple  CTF  contributions, including  a  USD  215  million  concessional  loan  under  the  stewardship  of  the World Bank and USD 58 million in funding administered by the African Development Bank  (AfDB).  The  CTF  also  supported  the  development  of  South  Africa's BESS-specific grid codes and expansion of Eskom's operational capacity.

Meanwhile, multilateral development banks also play an essential role in providing concessional financing products and technical assistance to BESS projects in EMDE. For instance, ADB has approved financing for a 250 MW/500 MWh BESS project in Cambodia, which is designed to address growing electricity demand by storing and releasing  renewable  energy  and  strengthening  Cambodia's  interconnectivity  with neighbouring networks. The project is backed by a USD 40 million concessional loan and USD 5 million grant from ADB, and mobilizes an additional USD 18.4 million in cofinancing provided by the Green Climate Fund and the United Kingdom, managed by ADB through its ASEAN Catalytic Green Finance Facility. In some cases, ADB can also provide local currency financing to address the foreign exchange risk that emerges from the use of USD-denominated loans.

## Remaining uncertainties for financial models

While  both  PLN  and  IPPs  are  well  accustomed  to  the  corporate-  and  projectfinance  structures  outlined  above,  some  uncertainties  -  which  elevate  risks perceived  by  project  sponsors  and  lenders  -  persist.  The  first  BESS  projects deployed in Indonesia will likely demonstrate whether these risks are real or simply perceived, but policy actions are also within reach to alleviate these risks explicitly.

The first uncertainty lies in the presence of foreign exchange risk, which occurs when the currency in which a project generates revenue differs from that of its financing.  In the case  that  the  revenue-generating  -  or  local  -  currency depreciates,  investors  will  face  challenges  in  repaying  lenders.  In  Indonesia, BESS revenues will be denominated in Indonesian rupiah. By contrast, the likely use of imported equipment and involvement of international lenders means that a significant portion of capital expenditure and debt is likely to be denominated in foreign currencies. In PLN-led projects, the state-owned utility depreciation in the value  of  rupiah  relative  to  foreign  currencies  results  in  foreign-currency  debt repayments  becoming more  expensive. In  IPP-led  projects  and  joint  ventures, which are likely to rely on a higher share of debt to finance BESS investments, foreign exchange risk also has the potential to increase the cost of capital. Lenders may require higher interest rates, shorter loan tenors or third-party guarantees to mitigate currency volatility.

## Mitigation of foreign exchange risk in EMDE

Institutional  investors  evaluate  investment  risks  in  EMDE  by  analysing  projectspecific risks, sovereign risks, political and regulatory risks, and foreign exchange (FX) risks. Among these, FX risk is consistently cited as one of the single largest barriers  for  institutional  investors  to  enter  EMDE  infrastructure  markets.  While currency  risk  cannot  be  completely  removed  as  long  as  the  currencies  of  a project's  financing  and  revenues  do  not  align,  strategies  exist  to  mitigate  and distribute it among stakeholders.

One  solution  is  local  currency  financing,  which  MDBs  and  domestic  financing institutions have previously provided in Southeast Asia. However, local currency financing is generally not feasible for global commercial investors, whose funding base  is  raised  in  hard  currency.  Another  approach  is  a  sovereign  -  or  FX  guarantee  provided  by  the  host  government  or  a  DFI.  In  such  structures, commercial investors can recover losses from FX mismatches by calling on the guarantee when depreciation exceeds an agreed threshold.

A further option is currency hedging, but the availability of such products varies significantly by market. They tend to be available only for short tenors (6 to 24 months) and at high cost, well short of the ten-plus-year year life of an energy infrastructure asset. Development-backed facilities such as TCX can provide local currency hedging in EMDE, but their hedging capacity remains limited relative to financing needs in the region. In practice, the most sustainable mitigation entails mobilising domestic institutional capital for local currency financing by deepening domestic capital markets and building institutional investor capacity over time.

## Foreign exchange movement of selected currencies against the US dollar, 2010-2025

<!-- image -->

IEA. CC BY 4.0.

Note: IDR = Indonesian rupiah; EUR = euro; CNY = Chinese Yuan renminbi; INR = Indian rupee; PHP = Philippine peso; VND = Vietnamese dong.

Source: International Monetary Fund (2026) International Financial Statistics Exchange Rates dataset.

An additional uncertainty, this time relating to the implementation of concessional financing, lies in the design of transparent exit strategies. Concessional capital is most  effective  when  it  mitigates  precise  risks  for  early-stage  or  first-of-a-kind projects, such as uncertainty in remuneration structures or technology performance.  Exit  strategies  thus  define  how  concessional  mechanisms  are gradually  phased  out  as  markets  mature,  PLN  and  IPPs  gain  experience  in developing  BESS  projects,  and  commercial  lenders  grow  more  confident  that successful projects can be replicated. Effective exit strategies also facilitate the recycling of capital - especially by international public financiers and Indonesia's state-backed  financial  institutions  -  towards  new  nascent  projects  rather  than becoming  entrenched  in  long-term  commitments.  Time-bound  concessionality provisions, step-down interest rates or sunset clauses can be used to structure exit  strategies.  Performance-based  triggers,  which  signal  the  withdrawal  of concessional finance once predefined targets or milestones have been achieved, are  also  effective.  Well-structured  exit  strategies  help  to  strengthen  investor confidence  by  improving  visibility  for  long-term  financing  structures,  while  also facilitating the development  of  more  active  commercial  markets  as  these financiers take over when concessional support is no longer needed.

The execution of joint  ventures  between  PLN  and  IPPs  brings  forth  additional uncertainties in financial structuring. In the RUPTL's ARED scenario, over 10% of hybrid projects and over 50% of standalone BESS projects are allocated to PLN's sub-holdings, which may choose to form partnerships with IPPs. Collaboration between the state-owned utility and private sector developers means striking a balance between the corporate finance and project finance structures,

respectively, that each is most familiar with. For instance, PLN usually shoulders construction, operational and technology risks across the asset it develops, while IPPs  operating  under  project  finance  use  contractual  agreements  with  EPC contractors, operators or the SPV itself to distribute these risks. As a result, joint venture  agreements  must  carefully  consider  which  entity  bears  distinct  risks across  the  lifetime  of  the  project.  Another  important  ambiguity  in  joint  venture structures comes from the potential for PLN to experience conflicts of interest due to its dual positions as a shareholder in the BESS asset's SPV and sole off-taker of  its  services.  In  the  case  that  performance  standards  -  which  facilitate  the provision of availability-based payments and ancillary services - are established, joint  venture  agreements  must  transparently  outline  how  PLN  is  expected  to enforce penalties against an asset that it partially owns.

## Saguling floating solar PV plant

The Saguling floating solar PV power plant illustrates the advantages that PLN can enjoy by partnering with IPPs, especially for first-of-a-kind projects. Located on the Saguling  reservoir  in  West  Java,  the  92 megawatt-peak  power  plant  began construction in October of 2025 and - upon completion in November of 2026 - is expected  to  generate  around  130 gigawatt-hours  of  electricity  annually.  PLN's subsidiary Indonesia Power, which primarily builds and operates generation assets, paired with Saudi Arabian developer Acwa to develop the plant in 2022. Under their joint venture agreement, Indonesia Power maintains a 51% majority stake in the SPV, called IAT Saguling, with Acwa possessing the remaining 49%. The plant is to be developed under a build-own-operate scheme by Acwa, which has signed a 25-year PPA with PLN as the sole off-taker.

In May 2025, IAT Saguling secured USD 60 billion in financing from the French and German DFIs Proparco and DEG, respectively, as well as the UK bank Standard Chartered for the development, construction and operation of the project. These funds were raised in the context of , which aims to mobilise USD 20 billion in public and private financing to support the country's energy sector ambitions.

Acwa plays a key role in the development of renewable energy projects throughout the Middle East, Africa and Asia. With a portfolio of 52 GW in operational renewable energy projects at the end of 2025, the developer has acquired vast experience in developing wind and solar PV assets, especially in regions that historically rely on high shares of fossil power. The expertise offered by Acwa's involvement boosts bankability  while  allowing  PLN  to  expand  upon its  technical  capacity  to  develop similar projects in the future.

Finally, the alignment of capital structures between PLN and IPPs in the context of joint ventures requires careful consideration. While PLN typically borrows based on sovereign-linked sources and may be constrained by balance sheet limits, IPPs broadly  rely  on  highly  leveraged,  non-recourse  debt.  As  a  result,  joint  venture agreements must determine the levels of debt and equity that are best suited to the SPV's objectives. Moreover, any special rights - such as step-in powers, veto rights or preferential dividend treatment - that accompany PLN's equity stake in the SPV must be explicitly defined. Such transparency enables lenders to more precisely  understand  the  SPV's  capital  structure,  therefore  accelerating  the achievement of financial close on projects.

## Implications for achieving RUPTL 2025-2034 objectives

## BESS as a maturing asset class and Indonesia's pipeline

Battery energy storage has matured over the past decade from a niche technology into an established infrastructure asset class. Institutional investors increasingly underwrite  standalone  and  hybrid  battery  energy  storage  systems  (BESS)  in developed markets on the basis of contracted and merchant revenue models, supported by the expansion of variable renewable energy (VRE) and sustained decline in battery costs. Indonesia's latest Rencana Usaha Penyediaan Tenaga Listrik (RUPTL), or Electricity Supply Business Plan, reflects this shift, positioning BESS as a strategic pillar of the power system plan.

## A maturing global asset class

Institutional investors' interest in BESS has grown rapidly as returns in mainstream renewables have become increasingly compressed. Competition in utility-scale renewables has increased for both solar photovoltaic (PV) and wind, narrowing the premium available to institutional investors. Against this backdrop, BESS have emerged as an attractive infrastructure investment opportunity, offering elevated return potential, lower competition for assets, and a premium for the complexity of structuring and operating the BESS asset. Moreover, the pairing of BESS with renewable generation - especially solar PV - can enhance project economics by increasing the utilisation rate of the generation asset.

In  advanced  economies,  BESS  have  moved  past  the  proof-of-concept  stage. BESS are considered an investable, bankable asset class across the construction, operational  and  refinancing  stages.  Specialised  fund  managers  in  Europe successfully executed dedicated BESS strategies over the past decade in listed and unlisted markets. Capacity additions in the United States also accelerated sharply from 2020 to 2025 as a result of falling costs and tax credit support.

In emerging market and developing economies, BESS remain at a nascent stage due  to  uncertainty  around  revenue  models.  Nonetheless,  global  investors  are increasingly looking towards Southeast Asian markets, including Indonesia, for the next phase of growth. Such investors are carefully approaching BESS opportunities by scrutinising the availability and bankability of revenue streams, the credit quality of the off-taker, the regulatory framework governing grid services,

and the ability to manage currency and policy risks within an acceptable return profile.  Where  these  conditions  can  be  established,  BESS  offer  a  potentially attractive route to clean energy investment in high-growth emerging markets.

## Indonesia's BESS pipeline under the RUPTL

The Accelerated Renewable Energy Development (ARED) scenario in the RUPTL 2025-2034 marks a step change in Indonesia's ambition for battery storage. Total planned BESS capacity reaches nearly 8 gigawatts (GW) across standalone and hybrid projects. The pipeline comprises two distinct project archetypes, each with a different function in the power system and different economics.

Two BESS archetypes in the RUPTL 2025-2034

| Characteristic          | Standalone BESS                              | Hybrid BESS (solar PV + storage)          |
|-------------------------|----------------------------------------------|-------------------------------------------|
| Primary system function | Grid stability and VRE integration           | VRE integration and diesel displacement   |
| Expected revenue model  | Capacity- or availability-based payment      | Generation-based PPA                      |
| Key economic value      | Flexibility, frequency regulation, smoothing | VRE utilisation and fuel cost savings     |
| Applicable regions      | Java, Madura and Bali, Sumatra, Kalimantan   | Sulawesi, Maluku, Papua and Nusa Tenggara |

Notes: Standalone = grid-connected BESS not co-located with generation. Hybrid = BESS co-located with a utility-scale renewable energy project and contracted jointly with it. VRE = variable renewable energy; PPA = power purchase agreement.

Source: Analysis based on RUPTL and industry interviews.

On  the  large,  interconnected  grids  of  Java,  Madura  and  Bali,  Sumatra  and Kalimantan,  standalone  BESS  dominate  with  4.2 GW,  1.1 GW  and  0.7 GW storage  capacity  planned  respectively.  In  these  systems,  BESS  underpin  grid stability and renewables integration through frequency regulation, smoothing and ancillary services. The expected revenue model is a capacity- or availability-based payment, a mechanism that has yet to be established in Indonesia for standalone BESS.

The other two island groups, Sulawesi and Maluku, Papua and Nusa Tenggara, are expected to deploy predominantly hybrid projects. In Sulawesi alone, rising electricity demand is driving a pipeline of 1.5 GW of storage capacity paired with utility-scale renewables, with a further 1.5 GW across Maluku, Papua and Nusa Tenggara to support de-dieselisation. In these systems, BESS are combined with renewable generation to displace expensive diesel-fired generation and reduce

fuel imports. The revenue model is anchored by long-term PPAs, which current regulations permit for hybrid renewable energy and storage projects.

This distinction is important from an investment perspective. The bankability of standalone  BESS  projects  depends  on  the  development  of  BESS  revenue mechanisms, such as availability payments or ancillary service markets, which have yet to be established in Indonesia. By contrast, hybrid projects can rely on contracted  revenues  through  conventional  power  purchase  agreement  (PPA) structures, making them more readily bankable under existing market arrangements. As a result, the near-term investment case for BESS in Indonesia is likely to be driven by hybrid projects in Sulawesi and Maluku, Papua and Nusa Tenggara, while the large-scale deployment of standalone BESS on Java, Madura and  Bali,  Sumatra  and  Kalimantan  will  depend  on  further  evolution  of  market design and storage remuneration frameworks.

## Ownership and financing of BESS in Indonesia

Standalone and hybrid BESS are treated differently under the current regulatory framework in Indonesia with direct implications for the ownership and financing of each BESS archetype. Each therefore draws on a different pool of investors with distinct  return  requirements,  risk  appetites  and  constraints.  Understanding  this investor  landscape  is  critical  for  structuring  transactions  and  for  designing  the regulatory  and  market  frameworks  needed  to  mobilise  capital  at  the  scale  of RUPTL ambitions.

## Ownership: Equity investors

Across both archetypes, PT Perusahaan Listrik Negara (PLN), the state-owned utility,  and  its  subsidiaries  are  expected  to  be  the  primary  equity  investors, reflecting their central role in delivering the RUPTL pipeline. The two archetypes differ in the breadth of equity participation beyond PLN, and therefore in how fast private capital can accelerate deployment.

For standalone BESS, private sector participation remains largely to be defined. Standalone  projects  are  likely  to  be  classified  as  grid  infrastructure,  which  in Indonesia remains under PLN's ownership. This means the pace of standalone deployment  is  potentially  tied  to  PLN's  balance  sheet,  which  faces  competing priorities. Private firms could act as engineering, procurement and construction contractors or greenfield developers, building projects for a fee or a development premium,  subject  to  establishing  an  enabling  regulatory  framework  for  such transactions.  Other  state-owned  enterprises  (SOEs)  and  domestic  sovereign

wealth  funds  could  co-invest  in  standalone  BESS  projects  or  platforms  at  the holding company level, keeping ownership within sovereign entities, though this too would require regulatory clarity.

For hybrid BESS, the range of potential equity investors is broader. Hybrid projects are considered as generation assets, allowing an independent power producer (IPP) to own and operate the project and sell power to PLN under a long-term PPA. The most likely owners other than PLN are renewable energy IPPs that are already  active in Indonesia,  bringing project development  experience  and familiarity with PLN as an off-taker. Strategic investors, including regional utilities and  equipment  manufacturers,  could  take  stakes  to  establish  a  foothold  in  a growing storage market. Other SOEs and sovereign wealth funds could participate as co-investors alongside private developers, combining sovereign capital with private sector delivery.

The composition of this investor base can evolve as the market and regulatory framework  mature.  In  the  near  term,  hybrid  opportunities  could  attract  private developers  and  IPP  platforms  prepared  to  take  first-mover  risks,  including untested procurement processes and limited operating history. As early projects establish  operational  track  records,  infrastructure  funds  and  other  long-term owners could enter by acquiring stakes in operational assets if permitted, allowing early  movers  to  recycle  capital  into  new  development.  Over  the  longer  term, institutional  investors  such  as  pension  funds  and  insurance  companies  could consider  investment,  subject  to  an  established  record  of  contracted  revenues, comfort with PLN's credit standing, and the ability to manage currency risk at an acceptable cost.

## Financing: Local and international lenders

For standalone BESS, the absence of a dedicated tariff framework means that project-level  financing  is  unlikely  to  be  viable.  Without  contracted,  bankable revenue streams, lenders would not be able to underwrite project debt unless it carried sovereign or equivalent guarantees. Debt is therefore more likely to be raised  at  the  holding  company  level,  for  example  through  a  loan  to  a  PLN subsidiary  secured  against  a  portfolio  of  BESS  assets.  At  this  level,  the  most accessible  sources  of  debt  are  multilateral  development  bank  (MDB)  and development finance institution (DFI) loans to the PLN group and export credit agency (ECA) facilities  linked  to  equipment  supply,  both  of  which  may  require sovereign or PLN guarantees.

For hybrid BESS, financing  can  be  structured  at  the  project  or  portfolio  level, drawing  on  a  broader  range  of  lenders. Debt  is most  expensive  during development and construction phases when projects are most exposed to delays

and regulatory uncertainty, and improves once a project reaches COD with a longterm PPA in place. Before COD, direct lending is likely to come from MDBs and DFIs, local banks where PLN or sovereign backing is available, and ECA facilities tied to equipment delivery and construction milestones.

Across both archetypes, the lender base could broaden over time subject to early projects establishing track records and the development of a dedicated revenue framework. For hybrid BESS, as early projects reach commercial operation date (COD) and establish payment track records, commercial banks could refinance construction  debt  on  improved  terms,  with  contracted  PPA  revenues  providing sufficient security. Successful refinancings could open the door to portfolio-level debt  and  institutional  lenders,  reducing  reliance  on  concessional  capital.  For standalone BESS, a broader lender base would depend on the development of a dedicated revenue framework, without which lending is likely to remain confined to the PLN group at the holding company level. Broadening the lender base is critical because PLN's borrowing capacity is limited, and the RUPTL pipeline is unlikely to be financed by the PLN group and concessional lenders alone.

## Investor and financing framework for Indonesian BESS

|        | Standalone BESS                                                                                                                                                                                                                                                                                                                                                               | Hybrid BESS                                                                                                                                                                                                                                                                                                                                                                   |
|--------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Equity | Primary • PLN and subsidiaries Secondary • Other SOEs and SWFs as potential co-investors at holding company level                                                                                                                                                                                                                                                             | Primary • PLN and subsidiaries Secondary • Renewable energy IPPs • Strategic investors • Other SOEs and SWFs                                                                                                                                                                                                                                                                  |
| Debt   | Holding company financing • MDB/DFI loans to PLN group • Transition or green bond issuance at PLN or subsidiary level • ECA loans linked to equipment supply (subject to sovereign/PLN guarantee) • Local bank balance sheet lending (subject to sovereign backing) • International bank balance sheet lending (subject to MDB/DFI credit enhancement or sovereign guarantee) | Project financing (before COD) • MDB/DFI direct lending • Local bank direct lending (subject to PLN/sovereign backing) • International bank direct lending (subject to MDB/DFI credit enhancement) • ECA facilities (subject to equipment delivery and construction milestones) Project financing (after COD) • International commercial banks • Local banks • ECA facilities |

Note: SWFs = sovereign wealth funds.

## Bankability assessment

This  section  presents  an  illustrative  bankability  assessment  of  the  two  BESS archetypes  identified  in  the  RUPTL,  modelling  the  revenue  levels  each  would require to meet commercial return thresholds across Indonesia's five main island systems. The analysis quantifies how required tariffs vary by region and over time, tests their sensitivity to capital costs and financing terms, and illustrates where concessional capital would be most effective in mobilising private investment.

## Modelling framework

The bankability assessment tests whether the two BESS archetypes identified in the RUPTL, standalone and hybrid BESS, can be financed on terms suitable to both commercial investors and PLN. The analysis models illustrative project cash flows over a ten-year asset life and solves for the minimum revenue level at which each archetype meets target returns and financial thresholds listed under financial assumptions  below.  It  is  intended  to  illustrate  the  approximate  revenue  levels required for each archetype and their sensitivity to key variables rather than to replicate project-level due diligence. A full methodology is provided in the Annex.

Standalone and hybrid BESS projects are modelled separately as they provide different services and benefit from different revenue streams. Standalone BESS are modelled as a 100 megawatt (MW), four-hour system and is assumed to earn 100% of its revenue from an availability-based payment, expressed in US dollars per kilowatt per year. Hybrid BESS are modelled as a one-hour battery co-located with a 100 MW solar PV plant and is assumed to earn its revenue through a longtern PPA, expressed in US dollars per megawatt-hour. The hybrid model captures only the incremental PPA uplift needed to cover the BESS component, treating

the  solar  PV  as  financed  and  viable  in  on  its  own.  The  hybrid  result  should therefore be read as the additional PPA tariff attributable to the battery, not the allin tariff for the combined project.

## Financial assumptions

| Parameters                               | Value                          | Source   |
|------------------------------------------|--------------------------------|----------|
| Cost of debt (commercial rate)           | 7.50%                          | 1, 2     |
| Cost of debt (blended concessional rate) | 4.50%                          | 2, 3     |
| Cost of equity                           | 13.5%                          | 1, 2, 3  |
| Gearing (debt share)                     | 65% (standalone); 70% (hybrid) | 1, 2, 3  |
| Minimum DSCR                             | 1.5x                           | 1, 2, 3  |
| Debt tenor                               | 10 years                       | 2, 3     |
| Revenue and OPEX escalation              | 3% per year                    | 2, 3, 5  |
| Corporate tax rate                       | 22%                            | 1        |
|                                          | 4-hour standalone: USD 0.6-    | 4, 5     |

1.6 million

CAPEX (per MW)

1-hr hybrid: USD 0.2-0.6 million

Grid connection: USD 20 000-

57 000

Notes: DSCR = debt service coverage ratio. CAPEX ranges reflect regional variation, with Java, Madura and Bali at the low end and Maluku, Papua and Nusa Tenggara at the high end. Hybrid BESS figures cover the storage and grid connection components only, excluding solar PV. Values shown are for 2025; the model applies declining cost trajectories over 2025-2034, with solar PV falling by approximately 5.5% per year, BESS by approximately 3.5-4% per year, and grid connection costs remaining broadly flat. OPEX is expressed as a percentage of the CAPEX of the respective component.

Sources: 1 = interview with PLN; 2 = interview with PT Sarana Multi Infrastruktur and other commercial lenders; 3 = interview with MDBs and DFIs; 4 = BNEF Energy Storage System Cost Survey (2025) and PLN RUPTL 2025-2034;

- 5 = interview with global BESS utility companies.

For each archetype, the model builds a full project cash flow, covering revenue, operating costs, debt service, depreciation and tax. It then solves for the lowest revenue  level  that  provides  the  target  equity  return  over  the  asset  life,  while maintaining bankability. The model also calculates a break-even tariff, which is the level of remuneration at which the project covers operating costs and debt service but earns a 0% equity return.

## Standalone BESS: Required availability payment

In the absence of an established tariff structure for standalone BESS, this analysis offers a directional guide for regulators and policymakers seeking to quantify and design  an  availability-based  payment  for  the  RUPTL  pipeline.  For  each  island system, the financial model solves for the availability payment required to deliver a 13.5% equity internal rate of return, assuming commercial debt priced at 7.5% and a 65:35 debt-to-equity structure.

## Average availability payment for standalone BESS with commercial financing, weighted by annual capacity additions, 2025-2034

<!-- image -->

IEA. CC BY 4.0.

Notes: kW = kilowatt.

Source: IEA internal modelling based on industry consultations. See Annex for the full methodology and sources used in the financial modelling.

The  required  payment  varies  widely  across  the  five  systems.  For  projects commissioned in the first year of RUPTL deployment, the target tariff ranges from approximately USD 111 per kilowatt (kW) per year in Java, Madura and Bali, the lowest-cost  system,  to  almost  USD 300/kW/year  in  Maluku,  Papua  and  Nusa Tenggara.  Since  financing  terms  are  held  constant  across  regions,  this  nearthreefold spread reflects differences in CAPEX alone, driven by the regional cost multipliers applied in the model to capture logistics, delivery and construction cost differences across five island systems.

The analysis also determines each region's break-even tariff, the level at which a project  covers  its  operating  costs  and  debt  service  but  provides  no  return  on equity.  The  gap  between  the  two,  around  30%  across  all  systems,  defines  a project's commercial viability. A tariff close to breakeven would offer little equity return and would need to be financed largely by SOEs rather than commercial investors. A tariff below the breakeven point would erode equity investors' capital return and, once fully exhausted, expose lenders to payment defaults. In practice,

lenders would model this default in advance, and would not be able to finance the standalone project at such levels.

The  weighted  average  tariff  level  lies  at  around  USD 140/kW/year,  with  each region  weighted  according  to  its  capacity  additions.  This  indicates  the  single payment level that would cover the RUPTL pipeline as a whole. Because Java, Madura and Bali and Sumatra account for the majority of the standalone BESS pipeline,  the  average  sits  close  to  their  tariffs,  well  below  what  the  regions  of Kalimantan,  Sulawesi,  and  Maluku,  Papua  and  Nusa  Tenggara  would  require. This highlights that a flat nationwide tariff for standalone BESS could potentially fail to attract commercial lenders and investors in the islands with higher BESS CAPEX.

<!-- image -->

IEA. CC BY 4.0.

Note: Values show the required payment at the capital costs projected for each year over the RUPTL 2025-2034 planning horizon; commissioning under the plan is expected to phase in over the period. Source: IEA internal modelling based on industry consultations. See Annex for the full methodology and sources used in the financial modelling

The required availability payment, which is determined upon project commissioning and remains constant throughout the contract's duration, declines steadily across the deployment period in every system, falling by roughly a quarter over the ten-year planning horizon as battery capital costs decline along the cost curve  used  in  the  RUPTL-aligned  investment  scenario.  This  means  a  project commissioned  later  in  the  decade  can  achieve  the  same  equity  return  at  a materially lower tariff than an identical project built today.

This  trajectory  shapes  when  and  where  concessional  capital  would  be  most needed. The financing challenge is concentrated in the first wave of projects, when CAPEX and the required tariff are highest, especially in Kalimantan, Sulawesi, Maluku, Papua and Nusa Tenggara. Deploying concessional capital strategically could demonstrate the project viability and establish the commercial precedents

to crowd in private capital over time. As costs fall and the required tariff converges towards  an  affordable  level  for  PLN  and  the  government  of  Indonesia,  the concessional capital can be retired over time without undermining the bankability of subsequent projects.

## Tariff sensitivity to capital cost and cost of debt for standalone BESS

IEA. CC BY 4.0.

<!-- image -->

Notes: bps = basis points. The base tariff is indexed to 100 and reflects fully commercial financing at a 7.5% cost of debt. In the  left  panel,  the  300  basis  point  reduction  corresponds  to  a  blended  cost  of  debt  falling  from  7.5%  to  4.5%  through concessional loans. In the right panel, the 300 basis point increase corresponds to the cost of debt rising to 10.5% under an

adverse macroeconomic environment. Capital cost changes of ±10% are applied to total CAPEX. Source: Internal IEA modelling based on industry consultations. See Annex for the full methodology and sources used in the financial modelling

This  sensitivity  analysis  attributes  the  change  in  the  required  tariff  to  its  two principal cost drivers, the cost of debt and CAPEX, applied sequentially from the base tariff and indexed to 100. The left panel presents favourable movements and the right panel adverse movements, showing the contribution of each driver and their combined effect.

On the left, a 300 basis point decline in the cost of debt reflects a scenario where concessional lenders provide the majority of project debt, lowering the blended rate from 7.5% to 4.5%, close to the limit of what concessional capital can achieve. This reduces the required tariff by 6%. A further 10% decrease in CAPEX in line with battery costs declining faster than the base trajectory reduces the tariff by an additional 12%, roughly double the effect despite being the smaller relative change compared to cost of debt. In practice, this suggests that concessional finance has a modest effect on the tariff level with bankability driven primarily by the CAPEX trajectory. The role of concessional capital is catalytic to lower the entry cost of the market's initial projects and to scale back as the CAPEX declines.

On the right, a 300 basis point increase in the cost of debt reflects an adverse macroeconomic environment with the blended rate rising from 7.5% to 10.5%. This

is a plausible downside scenario as seen during the Covid-19 pandemic and other periods of emerging market stress. The higher cost of debt raises the required tariff  by  7%,  and  a  further  10%  increase  in  CAPEX,  reflecting  supply  chain pressures or cost overruns, raises it by an additional 12%, bringing the combined effect  to  almost  20%.  In  practice,  this  is  the  scenario  investors  will  stress-test before making investment decisions. A tariff that is bankable only under favourable macroeconomic and market conditions may not attract institutional capital at scale, and the resilience of the revenue mechanisms will be scrutinised closely for the first projects due to limited precedents.

Standalone BESS CAPEX is expected to fall by more than 25% over the next tenyear RUPTL period, which will improve bankability assuming all else being equal. The  cost  of  debt  does  not  offer  a  comparable  improvement.  It  moves  in  both directions  with  macroeconomic  conditions  and  its  reduction  is  often  bounded, anchored  by  long-term  sovereign  bond  yields  and  the  limited  availability  of concessional capital. This reiterates that the improvement in the standalone BESS investment  case  is  likely  to  derive  from  declining  technology  costs  rather  than financing terms.

The  sensitivity  analysis  also  reinforces  the  role  of  concessional  capital  at  the inception stage, supporting early projects and establishing precedents in select island systems rather than serving as a permanent feature of project financing. Without this early support, the initial projects may struggle to reach financial close, keeping risk premiums elevated for subsequent projects. While falling technology costs  will  improve  the  economics  regardless,  the  pace  at  which  projects  are deployed with private capital depends on establishing these early precedents.

## Hybrid BESS: Required PPA uplift

The  second  archetype  under  the  RUPTL  is  a  hybrid  project  pairing  solar  PV generation with battery energy storage. In this configuration, BESS are used to shift a portion of daytime generation into the evening peak. The financial model assumes  that  the  solar  PV  plant  is  already  fully  bankable,  and  its  capital expenditures and operating costs are excluded from the bankability analysis. The model examines how much the additional revenue would be required for the BESS component  and  its  associated  grid-connection  costs  to  reach  a  13.5%  equity return, assuming 70% debt at a 7.5% interest rate, and a minimum debt service coverage ratio target of 1.5x.

The representative configuration used in the model is a 100 MW solar PV plant paired  with  a  30 MW,  one-hour  battery  used  for  peak  shifting  rather  than  bulk storage function. For each region, the model solves for the annual capacity-based revenue the battery requires and divides it by the solar plant's annual generation to express the result as a tariff uplift to the PPA in USD per megawatt-hour. This

uplift  should  be  interpreted  as  the  premium  required  to  convert  variable  solar output  into  a  firmer,  more  dispatchable  product,  not  as  the  all-in  tariff  for  the combined project.

The required uplift at the start of the RUPTL period ranges from approximately USD 8/MWh in Java, Madura and Bali to approximately USD 18/MWh in Maluku, Papua and Nusa Tenggara. This regional dispersion is driven by two competing effects:  higher  BESS  and  grid-connection  costs  in  Kalimantan,  Sulawesi  and Maluku, Papua and Nusa Tenggara raise the revenue the BESS must recover, while the higher solar capacity factors in Sulawesi and Maluku, Papua and Nusa Tenggara  spread  that  cost  across  greater  generation.  The  required  uplift  in Maluku, Papua and Nusa Tenggara is over twice that in Java, Madura and Bali, suggesting that government support and concessional finance could be directed towards projects in these higher CAPEX regions.

## Required PPA uplift for hybrid PV-plus-BESS by region

| Region     |   BESS CAPEX (million USD) |   Target annual tariff (million USD) | Solar capacity factor (%)   |   Annual PV generation (GWh) |   Incremental PPA increase (USD/MWh) in RUPTL 2025 |   Incremental PPA uplift (USD/MWh) in RUPTL 2034 |
|------------|----------------------------|--------------------------------------|-----------------------------|------------------------------|----------------------------------------------------|--------------------------------------------------|
| Sumatra    |                       8.72 |                                 1.49 | 16%                         |                        140.2 |                                               10.7 |                                              7.8 |
| JMB        |                       6.93 |                                 1.19 | 17%                         |                        148.9 |                                                8   |                                              5.8 |
| Kalimantan |                      14.66 |                                 2.52 | 17%                         |                        148.9 |                                               16.9 |                                             12.3 |
| Sulawesi   |                      14.76 |                                 2.53 | 19%                         |                        166.4 |                                               15.2 |                                             11   |
| MPNT       |                      18.58 |                                 3.19 | 20%                         |                        175.2 |                                               18.2 |                                             13.2 |

Notes: GWh = gigawatt-hour; JMB = Java, Madura and Bali; MPNT = Maluku, Papua and Nusa Tenggara. BESS CAPEX is the total CAPEX of the 30 MW battery and its grid connection; the solar PV component is excluded. Target annual tariff is the  revenue  the  30  MW  BESS  must  earn  each year to meet  the  financing  assumptions  used  in  the  model. Annual PV generation is calculated from the 100 MW solar plant's regional solar capacity factor. The incremental PPA uplift is the target annual tariff divided by annual PV generation, shown at capital costs prevailing at the start and end of the RUPTL period. Regional CAPEX differences reflect variations in logistics, delivery and construction costs across island systems.

Source: IEA internal modelling based on industry consultations. See Annex for the full methodology and sources used in the financial modelling

The required tariff uplift declines by roughly a quarter in every region over the next ten-year RUPTL period as BESS CAPEX falls along the cost curve used in the RUPTL-aligned  investment  scenario.  By  the  end  of  the  period,  it  ranges  from approximately  USD  6/MWh  in  Java,  Madura  and  Bali  to  approximately  USD 13/MWh  in  Maluku,  Papua  and  Nusa  Tenggara.  Projects  commissioned  later therefore require a lower uplift than earlier ones.

The economics of hybrid projects ultimately rest on the diesel generation they replace. BESS costs follow a structural declining trajectory, driven by manufacturing scale and continued technology improvement, while diesel

generation costs depend largely on fuel prices, which are volatile and difficult to project for the same period. To the extent that diesel costs remain at recent levels or rise, the economics of hybrid projects improve each year as the uplift required to finance hybrid projects falls while the cost of the diesel generation it avoids does not fall with it.

Therefore, commissioning timing for hybrid project is itself an economic variable as BESS costs are expected to decline sharply over the next ten years. Projects commissioned too early bear higher CAPEX, while delayed deployment prolongs reliance  on  diesel  generation  and  defers  the  market  precedents  on  which subsequent  investment  depends.  In  practice,  this  implies  pacing  hybrid  BESS deployment with the growth of solar capacity in each system, so that batteries arrive as the need for firming emerges rather than ahead of it.

<!-- image -->

IEA. CC BY 4.0.

Notes: Values show the required tariff uplift at the capital costs projected for each year over the RUPTL 2025-2034 planning horizon; commissioning under the plan is expected to phase in over the period. The uplift reflects the incremental tariff required to finance the BESS component and associated grid connection costs, with the solar plant assumed independently bankable. Financing terms are held constant across regions and over time. Source: IEA internal modelling based on industry consultations. See Annex for the full methodology and sources used in the financial modelling

To examine what drives the tariff uplift, the financial model tests its sensitivity to BESS CAPEX and the cost of debt in the highest-cost region of Maluku, Papua and Nusa Tenggara and the lowest-cost region of Java, Madura and Bali. Each cell reports the required tariff uplift at a given combination of CAPEX and interest rate with the two regions shown side by side to illustrate the uplift range of the potential pipeline.

Tariff uplift for hybrid BESS under varying CAPEX and interest rates for Maluku, Papua and Nusa Tenggara (top row of each cell) and Java, Madura and Bali (bottom row of each cell) (USD/MWh)

|       |      | Annual interest rate   | Annual interest rate   | Annual interest rate   | Annual interest rate   | Annual interest rate   |
|-------|------|------------------------|------------------------|------------------------|------------------------|------------------------|
|       |      | 10.5%                  | 9%                     | 7.5%                   | 6%                     | 4.5%                   |
|       |      |                        |                        | (base)                 |                        |                        |
|       | +10% | MPNT:                  | 21.0                   | 20.3                   | 19.6                   | 18.9                   |
|       |      | 21.7                   | 9.2                    | 8.9                    | 8.6                    | 8.3                    |
|       |      | JMB: 9.5               |                        |                        |                        |                        |
|       | +5%  | 20.6                   | 19.9                   | 19.2                   | 18.6                   | 17.9                   |
|       |      | 9.1                    | 8.7                    | 8.4                    | 8.2                    | 7.9                    |
| CAPEX | Base | 19.5                   | 18.8                   | 18.2                   | 17.6                   | 16.9                   |
|       |      | 8.6                    | 8.3                    | 8.0                    | 7.7                    | 7.4                    |
|       | -5%  | 18.4                   | 17.8                   | 17.1                   | 16.5                   | 16.0                   |
|       |      | 8.1                    | 7.8                    | 7.5                    | 7.3                    | 7.0                    |
|       | -20% | 17.3                   | 16.7                   | 16.1                   | 15.5                   | 15.0                   |
|       |      | 7.6                    | 7.3                    | 7.1                    | 6.8                    | 6.6                    |

Notes: MPNT = Maluku, Papua and Nusa Tenggara. JMB = Java, Madura and Bali.

Each value is the required PPA uplift in USD per MWh, calculated as the annual revenue the BESS component must earn to meet financial targets, divided by the solar plant's annual generation. CAPEX variations apply to the 30 MW battery and its grid connection. The central cell (USD 8.0/MWh) matches the base case in the uplift analysis. Values reflect capital costs at the start of the RUPTL period and would decline over time as battery costs fall.

Source: IEA internal modelling based on industry consultations. See Annex for the full methodology and sources used in the financial modelling

The required tariff uplift is more sensitive to CAPEX than to financing costs. In Maluku,  Papua  and  Nusa  Tenggara,  the  uplift  ranges  from  USD 16.1/MWh  to USD 20.3/MWh across the ±10% CAPEX range at the base interest rate (7.5% per year), and from USD 16.9/MWh to USD 19.5/MWh across ±300 basis points in the interest rate at the base CAPEX. The same pattern holds in Java, Madura and Bali, where the uplift sits at less than half the level of Maluku, Papua and Nusa Tenggara, reflecting its lower capital cost. The least favourable outcome modelled for Java, Madura and Bali (USD 9.5/MWh) remains well below the most favourable outcome for Maluku, Papua and Nusa Tenggara (USD 15.0/ MWh), underscoring the  case  for  directing  concessional  capital  support  towards  the  higher-cost systems to achieve regional balance.

Compared with recent utility-scale solar PPAs in Indonesia, the storage uplift is modest in the lower CAPEX islands but more consequential in the higher CAPEX ones. The all-in tariff for hybrid projects is typically lower than the cost of the dieselfired generation it would displace based on historical utility-scale solar and dieselbased electricity costs in Indonesia. The role of concessional finance is therefore narrower  than  in  the  case  of  standalone  projects.  It  is  not  a  precondition  for

viability, but a way to widen the margin against the displaced supply cost and bring forward the earliest projects in the higher CAPEX islands, where risk premiums are highest.

## Implications for scaling the RUPTL pipeline

The modelling results suggest markedly different pathways to scale for the two BESS configurations identified in the RUPTL.

Hybrid solar PV-plus-BESS presents the more immediate opportunity. Because these projects earn contracted revenue under conventional PPA structures, they are bankable under existing regulatory arrangements and clear commercial return thresholds  in  the  systems  where  they  displace  diesel  generation.  The  binding constraint is therefore not viability but the availability of construction-stage finance and  the  risk  mitigation  instruments  such  as  first-loss  tranches,  partial  credit guarantees and political risk cover, which can facilitate the entry of commercial lenders into the pre-completion phase at scale.

Standalone  BESS  faces  a  more  fundamental  constraint.  In  the  absence  of  a dedicated  remuneration  mechanism,  there  is  currently  no  contracted  revenue against which project-level debt can be raised, and deployment depends instead on PLN's balance sheet, MDB and DFI lending, and sovereign-backed borrowing. Establishing  an  availability-payment  framework,  even  at  a  modest  initial  scale, would convert standalone BESS from a balance-sheet obligation for PLN into a financeable asset class for private capital.

Indonesia's BESS financing ecosystem remains at an early stage of development, with  limited  transaction  precedents  available  to  lenders  and  investors.  Initial projects are therefore important not only for the capacity they add but also for establishing  contractual,  financing  and  risk-allocation  structures  that  can  be replicated across subsequent deployments. The strategic priority is to sequence that support deliberately, concentrating it where the financing gap is widest and the  demonstration value is  highest,  so  that  public  capital  catalyses  the  market rather than substitutes for it.

## Key recommendations

## Strategies for overcoming investment barriers and mitigating risks

Achieving  the  objectives  of  the  Rencana  Usaha  Penyediaan  Tenaga  Listrik (RUPTL), or Electricity Supply Business Plan, for standalone and hybrid battery energy  storage  systems  (BESS)  deployment  requires  careful  consideration  of project  business  models,  financing  structures  and  collaboration  among  key stakeholders. The following chapter provides guidance on how decision makers in Indonesia can address the challenges identified in previous sections of the report.

## Strengthen regulatory certainty by explicitly integrating BESS into remuneration frameworks and grid codes

Regulatory uncertainties are regularly cited  by  key  stakeholders  as  substantial barriers  to  investor  confidence  for  both  standalone  and  hybrid  BESS  projects. Without  clear  definitions  of  the  expectations  that  the  Ministry  of  Energy  and Mineral Resources (MEMR) and PT Perusahaan Listrik Negara (PLN) have for battery performance, developers will struggle to design projects that are adapted to the needs of Indonesia's power sector, while a lack of visibility over cash flows prevents lenders from being able to trust that their loans will be repaid. First, legally classifying  standalone  BESS  as  a  network asset  and the  BESS  component of hybrid projects as generation assets will send a strong signal to developers on how  different  assets  are  expected  to  be  used.  Moreover,  clarifying  whether standalone assets are required to obtain a license to generate electricity for public use  (Izin  Usaha  Penyediaan  Tenaga  Listrik  [IUPTL]),  as  well  as  the  explicit allowance for BESS components within hybrid systems to benefit from the same IUPTL as their co-located generation assets, will clarify initial uncertainties around project permitting.

An additional  area  of  clarification  concerns  Indonesia's  Kerjasama  Pemerintah dengan Badan Usaha (KPBU), or public-private partnership framework, established  under  Presidential  Regulation  38/2015.  The  regulation  provides  a procurement  and  financing  pathway  for  critical  infrastructure  that  is  already familiar to Indonesian regulators, developers and financiers. The explicit identification of standalone BESS assets as being eligible for procurement through the KPBU framework, complemented by MEMR regulation detailing remuneration

and contractual structures for these assets, can facilitate the operationalisation of PR 38/112 for storage projects which provide essential services to Indonesia's grid.

Next, PLN and MEMR can work together to explicitly define their expectations for the  distinct  services  that  BESS  assets  can  provide.  These  definitions  can  be integrated into Indonesia's grid code to ensure that all BESS assets will be held to identical  performance  standards,  regardless  of whether they  are  developed  by independent power producers (IPPs) or PLN itself. For grid stability and flexibility, decision makers can explicitly define the timescales used to distinguish between renewables  smoothing,  load  shifting  and  renewables  firming;  as  well  as  the response  times  expected  for  the  provision  of  black-start  capabilities  or  peak capacity injections. Ancillary services, which are typically contingent upon BESS performance rather than sole capacity, can also benefit from clear definitions of system needs: for example, BESS asset operators must be regularly updated on network conditions in order to understand when they might be called upon by PLN to  provide  frequency  regulation  services.  In  some  cases,  grid  codes  that  were originally designed for thermal generation assets must also be adapted to reflect the unique abilities of BESS. For instance, existing grid codes include both ramp rate limitations, which are intended to protect the network from sudden spikes in injection, and primary frequency response obligations, which establish expectations  for  assets  to  step  in  when  network  frequency  reaches  unhealthy levels.  These  specifications  are  in  direct  conflict  with  one  another,  and  BESS operators would benefit from a clear hierarchy in how they apply to storage assets.

Finally,  specific  remuneration  frameworks  for  each  of  the  services  that  PLN expects to receive from BESS assets must be defined. Grid flexibility and stability services, which will generally be procured through standalone systems, can be integrated  directly  into  tolling  agreements  that  are  based  on  asset  capacity. However, current requests for proposals (RFPs) tend to stipulate the provision of ancillary services without clarifying how they will be remunerated. The separate provision  of  ancillary  services  procurement  agreements  (ASPAs),  in  which  the type  and  quality  of  ancillary  services  is  clearly  defined,  would  grant  BESS developers and operators the option to engage in revenue stacking. Moreover, the contractual separation of essential flexibility services (through tolling agreements) and ancillary services (through ASPAs) also enables operators to gain experience in handling their BESS assets by focusing solely on the former throughout the first years of the project,  while  then  having  the  option  to  introduce  the  provision  of ancillary services - which come with additional operational complexity - once they have acquired sufficient expertise.

Under current power market frameworks, the ability for BESS operators to engage in market-based energy arbitrage is limited. However, over the longer term, MEMR may consider implementing more granular time-of-use electricity pricing, which

would then lead to opportunities for energy arbitrage. As the country integrates more variable renewable energy into its power sector, time-of-use pricing will also strengthen the business case for hybrid projects that can extract more value from solar photovoltaic (PV) and wind generation, which come at near-zero variable costs.

## For the development of standalone systems, prioritise long-term system needs

Standalone BESS projects in Indonesia currently face more bankability challenges than hybrid configurations due to the absence of regulation specifically recognising standalone storage systems as network assets. The RUPTL allocates over  80%  of  standalone  capacity  additions  to  PLN  and  its  sub-holdings  for development,  which  translates  to  an  estimated  USD 3.4 billion  in  investment needs to 2034. However, competing priorities to develop other generation and network  projects, in addition to balance  sheet  constraints and  borrowing limitations, mean that PLN is unlikely to be capable of financing each of these projects itself.

An assessment of RUPTL projects indicates that the tariff required to achieve bankability  for  standalone  projects  is  more  sensitive  to  capital  costs  than  to financing costs; given that BESS capital costs are expected to decline by around 30% from 2025 to 2034, this is a positive result. However, additional steps can be taken to minimise capital costs, such as the procurement of BESS equipment in bulk orders to take advantage of economies of scale. Moreover, PLN can benefit from declining costs by addressing battery degradation through capacity augmentation partway through the project's lifetime, rather than oversizing project capacity at commercial operation date (COD). Finally, the careful consideration of the storage durations used for standalone assets can significantly reduce overall capital  expenditures.  While  the  RUPTL  plans  to  prioritise  four-hour  storage duration  assets  for  its  standalone  projects,  it  also  intends  to  use  these  assets mainly  for  load  smoothing  and  ancillary  services,  which  can  generally  be performed  over  much  shorter  charge/discharge  cycles.  In  2025,  a  doubling  in storage duration led to a 1.7-fold increase in per-megawatt capital costs. As a result,  shifting  to  a  combination  of  two-hour  and  one-hour  standalone  storage duration  assets  for  its  standalone  projects  has  the  potential  to  save  PLN  an estimated USD 1 billion, while broadly maintaining the utility's ability to benefit from improved grid stability and flexibility.

The status of standalone BESS as nascent technologies within Indonesia's power sector means that early projects may require several years of operation before becoming  profitable. However,  this  possibility should  not  deter PLN  from prioritising  these  projects  as  strategically  important  investments.  While  early projects will face tighter economics, they will also create value by improving PLN's

operational experience and informing regulatory adjustments, ultimately reducing risks  and  improving  bankability  for  subsequent  investments.  For  PLN,  moving forward on standalone BESS projects today, rather than waiting for capital costs to  decline,  will  offer  benefits  to  grid  flexibility  and  power  quality  that  will  only become more important as demand for electricity in Indonesia grows rapidly.

## Crowd in commercial financing for hybrid projects by derisking the early stages of BESS project development

In contrast to standalone BESS configurations, hybrid systems are already clearly recognised by Presidential Regulation 112/2022 and MEMR Regulation 19/2025. As a result, project developers and financiers have relatively clear visibility over how MEMR and PLN envision remuneration structures for these projects. The standardisation of power purchase agreement (PPA) contracts, however, would give project developers and lenders greater foresight into detailed project cash flows, which would allow them to more confidently agree upon investment plans, financing  products  and  equitable  risk-allocation  structures.  Transparent  PPA contracts  should  be  developed  in  collaboration  among  MEMR,  PLN  and  key renewables developers and used across all RFPs. This level of consistency will also help developers to accurately understand MEMR's and PLN's expectations around asset performance.

The main obstacle that hybrid projects now face in Indonesia relate to their abilities to  access financing during their development and construction phases. Among many existing facilities, including the Indonesia-Sustainable Least-Cost Electrification (ISLE) programme provided to PLN by the World Bank Group to support the deployment of renewable and BESS projects, loans become available only  upon  the  achievement  of  agreed  results,  which  usually  occurs  at  or  after COD.  However,  PLN's  equity  alone  may  not  be  sufficient  to  support  projects through development and construction.

This 'valley of death' challenge is even more present among IPPs, which rely on commercial lending to finance their projects. The cost of debt from commercial banks is likely to be at least 7.5%, placing additional pressure on project cash flows to meet debt servicing requirements. However, public support from domestic or international financiers can play a key role in supporting hybrid projects through their early stages. Interventions such as guarantees that specifically address preCOD risks or the provision by international public financiers of subordinated debt through the development and construction phases can go a long way towards improving project bankability. Rather than replacing commercial financing, these mechanisms serve to enable it by supporting the very phases of BESS projects that commercial lenders see as the most risky. Moreover, when applied to the first hybrid  projects  in  each  region,  they  can  rapidly  improve  bankability  for  the

remainder of the RUPTL's hybrid project pipeline by demonstrating that the risks perceived by commercial financiers in the development and construction phases are often unrealistically high.

## Prioritise developing the RUPTL's first BESS projects in the regions where they can most easily achieve bankability

Identifying the regions where BESS projects are most likely to achieve bankability is critical to accelerating early deployment and thus improving investor confidence. Location -especially a project's degree of isolation from national grid infrastructure - has an important role in determining project costs and services delivered. Before venturing into full-scale projects, PLN and MEMR can develop strategic  pilot  projects  that  enable  them  to  develop  experience  with  operating BESS assets and strengthen local operations and maintenance capacity, all while creating a replicable model for larger deployments.

The RUPTL's first standalone projects are most likely to succeed in the region of Java, Madura and Bali, where grid infrastructure is most developed and electricity demand  is  highest.  Taken  together,  this  region  is  best  suited  to  allowing standalone systems to prove their value by providing essential grid services such as  load  smoothing,  peak  capacity  reserves  and  frequency  regulation.  Careful intra-regional  planning can also allow standalone BESS assets to be optimally placed so that they can also provide congestion relief services when transmission and distribution networks are overwhelmed.

For  hybrid  project  configurations,  early  opportunities  are  likely  to  be  most successful in the region of Sulawesi, which generally receive the highest levels of solar irradiation in Indonesia. As a result, strong generation profiles lead to more robust project economics. The costs of project development in this region is also closely aligned with Indonesia-wide averages, meaning that they are not expected to  result  in  significant  burdens  on  system  Biaya  Pokok  Penyediaan  (BPP),  or average cost of electricity supply. Growing electricity demand makes Sulawesi a strong candidate to demonstrate the ability of hybrid assets to turn intermittent solar PV generation into reliable power while meeting expectations for the internal rate of return and supplying at a lower cost than diesel generators.

Taken together, the careful consideration of suitable locations for pilot projects Java, Madura and Bali for standalone systems and Sulawesi for hybrid assets can play a substantial role in lowering the cost of capital for future projects. Such initiatives allow MEMR and PLN to gain the experience necessary to tackle more complex projects in the isolated region of Maluku, Papua and Nusa Tenggara.

## Leverage concessional financing to support dedieselisation initiatives in Maluku, Papua and Nusa Tenggara

Concessional financing will play an essential role in de-risking Indonesia's first BESS projects, especially in eastern regions where system needs are high but projects struggle to reach commercial bankability. In particular, early projects in Maluku, Papua and Nusa Tenggara face higher costs due to a greater degree of isolation and limited system size. Moreover, hybrid projects that are intended to contribute to PLN's de-dieselisation initiatives face tight project economics when they are replacing operational diesel generation assets. As a result, concessional instruments  are  necessary  to  absorb  risks  that  are  currently  too  high  for commercial financiers to take on.

Targeted support through the provision of low-interest loans, longer loan tenors, grants or first-loss guarantees can significantly improve financing costs for BESS projects:  while  concessional  interest  rates  help  to  reduce  the  burden  of  debt service  payments  in  a  project's  early  years,  long-tenor  loans  help  to  align repayment periods with the operational lifetimes of BESS assets. In regions with relatively higher degrees of grid infrastructure development, such as Java, Madura and Bali, lower financing costs mean that projects may not require concessional loans to achieve bankability. However, support in the form of technical assistance, capacity building and policy design can help MEMR and PLN more quickly acquire the experience needed to deploy BESS projects at scale.

The impact of concessional finance is maximised when it is deployed to address precise  risks  or  phases  of  the  project  lifetime  that  create  obstacles  to  project bankability.  For  instance,  loans  offered  on  concessional  terms  can  be  used  to cover the costs of feasibility studies, system needs assessments, or logistics and construction  in  isolated  regions.  The  mitigation  of  currency  risk  through  the provision of loans in Indonesian rupiah can also go a long way towards reassuring lenders  that  BESS  assets  will  be  capable  of  generating  sufficient  revenues  to service  loans.  When  used  to  mitigate  specific  risks,  concessional  support facilitates the successful development of projects that can then be replicated using traditional financial products.

Although  concessional  support  is  most  important  for  early-stage  projects,  it  is expected  that  some  level  of  below-market-rate  financing  will  be  necessary throughout  the  2025-2034  timeline.  This  results  from  the  fact  that  new  project types  and  locations  are  gradually  phased  in,  which  means  that  PLN  and developers will regularly face challenges that they have not previously encountered. However, all concessional support must be paired with transparent exit strategies to avoid long-term dependence and facilitate the recycling of capital into  new  projects.  The  utilisation  of  exit  triggers,  such  as  the  deployment  of  a

defined  level  of  BESS  capacity,  the  successful  operation  of  an  asset  over  a defined number of years, or the stabilisation  of  revenues  under  BESS-specific regulatory  frameworks,  is  a  structured  approach  to  preventing  the  risk  of dependence.  This  being  said,  it  is  also  important  to  gradually  step-down concessional funding, rather than removing it too suddenly, once these triggers are activated.

## Establish a working group comprising key stakeholders to support implementation of BESS in Indonesia

Concrete alignment among Indonesia's key institutions, such as MEMR, PLN, the Ministry of Finance, Danantara and varied financial institutions, is frequently cited as a much-needed initiative for accelerating BESS deployment. Developers and financiers,  especially  international  ones,  seek  demonstrations  of  collaboration among governments, utilities and industries in order to mitigate concerns around political  or  regulatory  risks.  Because  PLN  must  deliver  electricity  at  affordable rates within strict financial constraints, close co-ordination with MEMR is essential to  ensuring that BESS-related regulations accurately reflect system needs and costs. The joint preparation of a BESS deployment roadmap, for instance, which directly translates RUPTL ambitions into policy adjustments, would go a long way towards demonstrating alignment between MEMR and PLN.

Co-ordination with developers and financiers, who frequently bring a high degree of technical experience in developing storage technologies, is also essential. Such collaboration can take the form of a regular consultations or structured dialogues through  the  creation of a BESS  development  task  force,  which  includes representatives  from  all  relevant  stakeholders.  Indonesia's  sovereign  wealth funds, especially Danantara, can also play a valuable role in bringing together key stakeholders and translating MEMR's policy objectives into tangible frameworks that are consistent with PLN's financial and operational constraints.

Finally, Indonesia's BESS deployment ambitions are not isolated from those of neighbouring countries. Strengthening co-ordination between Indonesia and other Southeast Asian countries can be mutually beneficial to addressing obstacles that exist on a regional scale: for example, the creation of regional supply chains and manufacturing  hubs  can  ultimately  lower  capital  costs  for  BESS  technologies across all Southeast Asian countries and enhance resiliency. Similarly, Southeast Asian countries can work together to jointly develop battery recycling facilities that address risks related to battery waste treatment. Given its significant expected growth in electricity demand and robust momentum to move forward on BESS development  objectives,  Indonesia  is  well-positioned  to  become  a  leader  in Southeast  Asia's  emerging  BESS  market  while  ensuring  that  early  projects receive the support necessary to succeed.

## Summary of priority actions

The recommendations listed above can be translated into distinct actions to be undertaken by government, PLN, project developers and financiers. Short-term actions emphasise the formal integration of standalone BESS into Indonesia's grid code and regulatory frameworks, in addition to the development of pilot projects that resolve early uncertainties around system design, operation and remuneration.  Over  the  medium  term,  actions  primarily  focus  on  unlocking additional revenue streams, especially through the provision of ancillary service procurement agreements. Finally, long-term actions address challenges that are more likely to arise after Indonesia's first BESS projects are operating, such as end-of-life treatment and recycling. Throughout all actions, co-ordination among stakeholders through formal working groups, as well as collaboration with other member  states  of  the  Association  of  Southeast  Asian  Nations  (ASEAN)  to establish  regional  supply  chains,  is  critical  to  ensuring  that  Indonesia's  battery energy storage fleet is developed in a sustainable and cost-effective manner.

## Precise actions for government, PLN, developers and financiers

| Timeline               | Action                                                                                                                                                                                                                                                                                                                                                                                                                      | Challenge(s) addressed                                                                                           |
|------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------|
| Short term (1-2 years) | System integration of BESS  Standardise the technical characteristics expected for BESS assets connected to PLN's national grid  Clearly define the services that BESS are expected to provide  Ensure that the national grid code considers BESS functionality, especially regarding ramp rates and frequency response obligations  Develop pilot projects: standalone in Java, Madura and Bali and hybrid in Sulawesi | Operational risk and lack of BESS design standards                                                               |
| Short term (1-2 years) | Remuneration and contractual structures  Create standardised tolling agreements for standalone projects and PPA frameworks for hybrid projects, clearly specifying which services are requested and their remuneration mechanism  Define how ownership of BESS assets is determined at the end of contractual periods                                                                                                     | Insufficient visibility over revenue streams for network services; uncertainty over end-of-life responsibilities |

| Timeline                           | Action                                                                                                                                                                                                                                                                                                                                                                        | Challenge(s) addressed                                                                           |
|------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------|
| Short term (1-2 years) (continued) | Regulation  Legally recognise standalone BESS as a network asset  Clarify whether standalone BESS assets require an IUPTL to operate  Clarify whether IUPTLs obtained for hybrid projects cover both the generation and storage assets                                                                                                                                     | Lack of regulatory specificity for standalone BESS                                               |
| Short term (1-2 years) (continued) | concessional support through both financial products and technical assistance  Create financial products that prioritise support during the development and construction phases  Prioritise offering rupiah-denominated loans where possible Economy-wide and regional co-ordination  Form a working group representatives from government, developers and financiers, and | COD financing; and currency risk                                                                 |
| Short term (1-2 years) (continued) | comprising PLN, establish regular consultations                                                                                                                                                                                                                                                                                                                               | Knowledge sharing and stakeholder engagement                                                     |
| Medium term (3-5 years)            | Remuneration and contractual structures  Create standardised ancillary service procurement agreements                                                                                                                                                                                                                                                                        | Insufficient visibility over ancillary services remuneration                                     |
| Medium term (3-5 years)            | Regulation  Establish a methodology for integrating the services provided by BESS into system BPP  Explicitly permit BESS assets to engage in revenue stacking                                                                                                                                                                                                              | Capturing the value of BESS in overall system costs; ability to receive multiple revenue streams |
| Medium term (3-5 years)            |                                                                                                                                                                                                                                                                                                                                                                               |                                                                                                  |

| Timeline                            | Action                                                                                                                                                                                                                                                                                                                               | Challenge(s) addressed                                       |
|-------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------|
| Medium term (3-5 years) (continued) | Access to financing  Define appropriate exit triggers for concessional financing Economy-wide and regional co-ordination  Publish a joint roadmap that establishes Indonesia's long-term vision for the role of BESS in its energy and industrial strategies  Establish regular knowledge sharing with other ASEAN members states | Recycling of concessional capital Demonstrated commitment by |
| Long term (5+ years)                | Regulation  Introduce granular time-of-use electricity pricing to open up opportunities for energy price arbitrage  Establish recycling standards for lithium-ion batteries used in stationary storage                                                                                                                             | Facilitate energy- based payments; decommissioning risk      |
| Long term (5+ years)                | Economy-wide and regional co-ordination  Co-ordinate with other ASEAN member states to create a regional supply chain and recycling system for BESS technologies                                                                                                                                                                    | Development of domestic or regional supply chains            |

## Annex

## India case study

India's BESS market has moved from pilot projects to large-scale procurement, supported by national planning, competitive tendering, viability gap funding and state-level policies. The Central Electricity Authority's revised Resource Adequacy Planning projects a requirement of 80 gigawatts (GW)/321 gigawatt-hours (GWh) of BESS and 94 GW/567 GWh of pumped storage by 2035. Moreover, 102 GWh of energy storage system (ESS) capacity was tendered in 2025, a year-on-year jump  of  1.4  times  in  terms  of  cumulative  capacity.  BESS  tendered  capacity increased even faster, rising from 4 GWh in 2023 to 60 GWh in 2025. By March 2026, cumulative ESS tenders reached 247 GWh, including 111 GWh of BESS. The market also broadened in 2025, with around 50 new players entering the BESS developer space. Alongside established power producers such as JSW Energy,  Greenko  and  Torrent  Power,  newer  entrants  included  infrastructure investors  such  as  IndiGrid;  engineering,  procurement  and  construction  (EPC) companies  such  as  Pace  Digitek  and  Bondada  Engineering;  and  emerging renewable energy developers such as Oriana Power and Kintech Synergy.

## Cumulative tendered capacity for battery energy storage in India, 2023-2025

<!-- image -->

Source: India Energy Storage Alliance (2026), Annual Report 2025.

India's storage procurement has diversified across tenders for standalone BESS, solar PV-plus-BESS, and firm and dispatchable renewable energy. According to the Institute for Energy Economics and Financial Analysis (IEEFA), standalone BESS accounts for around 60% of the tendered standalone ESS capacity, with a majority  of  projects  addressing  daily  peak  management  and  short-term  grid flexibility with two-hour storage duration technologies. This growth coincided with declining battery prices and supportive policy measures such as the introduction and expansion of the viability gap funding for standalone BESS projects.

National  agencies  such  as  Solar  Energy  Corporation  of  India  Ltd. 1 ,  National Thermal Power Corporation, National Hydroelectric  Power  Corporation Limited and Satluj Jal Vidyut Nigam 2 have administered large procurements, while state utilities and distribution companies are increasingly active. State-level targets are also emerging: Andhra Pradesh has targeted 25 GWh of BESS by 2029; Bihar 4.5 GWh of BESS by 2030 and Maharashtra's 2026 policy targets an estimated equivalent storage capacity of 100 GWh per day by 2035/36.

India's regulatory framework treats energy storage as part of the power system, with classification linked to use case. Storage assets can be developed, owned, leased or operated by generators, transmission licensees, distribution licensees or  independent  storage  service  providers.  This  allows  BESS  to  function  as generation-linked  storage,  a  network  asset,  a  distribution-level  resource  or  a standalone storage service. Supply-side incentives focus on domestic manufacturing and value addition. For example, India's production-linked incentive programme for advanced chemistry cells supports 50 GWh of advanced chemistry  cell  manufacturing.  Battery  testing,  safety  and  waste-management frameworks are developing through Central Electricity Authority safety regulations, Ministry  of  New  and  Renewable  Energy  battery-testing  guidance,  and  battery waste-management amendments.

Standalone  BESS  business  models  remain  dominated  by  build-own-operate (BOO), EPC and build-own-operate-transfer (BOOT). The India Energy Storage Alliance's  first-quarter  2026  energy  storage  market  tracker  records  67  GWh  of cumulative standalone BESS tenders from March 2022 to March 2026, of which 44.3 GWh used BOO, 14.4 GWh EPC and 2.1 GWh BOOT.

1 Solar Energy Corporation of India provides a payment security mechanism to de-risk developer cash flows by ensuring timely payments through a structured security fund and intermediary contracting with distribution companies. 2 Satluj Jal Vidyut Nigam is a central public sector undertaking under the Ministry of Power that develops hydropower,

renewable energy and storage projects.

## Standalone BESS system in New Delhi, India

The  20  megawatt  (MW)/40  megawatt-hour  (MWh)  project  in  Delhi  by  BSES Rajdhani Power Limited (BRPL) and the Global Energy Alliance for People and Planet (GEAPP) represents one of India's first commercial utility-scale standalone, grid-connected BESS  deployments.  The  project is implemented  through a dedicated special purpose vehicle (SPV) under a 12-year BOOT structure. The SPV finances,  builds,  owns  and  operates  the  BESS  asset,  supported  by  GEAPP's concessional debt (70% CAPEX at 1% interest) and private equity. BRPL provides land, grid connectivity and charging energy; schedules dispatch; and pays the SPV a fixed annual capacity tariff, with ownership transferring to BRPL at the end of the contract  period.  The  project  discovered  a  final  tariff  of  INR  58  (Indian  rupee) lakh/MW/year ( approximately USD 62 000/MW/year), reflecting the risks and costs associated with an early-stage BESS market.

The project  provides  key  lessons  for  emerging  markets  on  enabling  early-stage BESS deployment. The SPV-based model helps ring-fence project risks, mobilise private  capital  and  enable  utilities  to  access  storage  services  without  upfront ownership or operational risks. The project also highlights the importance of early regulatory engagement, technical assistance and blended finance in establishing bankable BESS markets. Estimates suggest projected benefits around 1.5 times tariff cost  over the lifetime of the asset. Energy arbitrage is estimated to account 1 for the largest share (~75%), followed by ancillary services and deferral of capital expenditures.

- 1 Projected benefit stack versus tariff (INR lakh/MW/year). The benefits were estimated based on the monetisable value streams and energy modelling on BRPL's 2023 fiscal year data.

Standalone  BESS  tariffs  have  fallen  sharply  as  tender  volumes  have  risen. Between 2022 and 2025, average standalone BESS tariffs declined by roughly 80%,  falling  from  INR  10.8  lakh/MW/month  (USD  11  500/MW/month)  to  INR 2.2 lakh/MW/month  (USD  2  342/MW/month)  for  two-hour  projects.  The  IEEFA estimates benchmark tariffs of INR 2.3 lakh/MW/month (USD 2 449/MW/month) for two-hour,  two-cycle,  twelve-year  systems  and  INR  4.3  lakh/MW/month (USD 4 578/MW/month) for four-hour, one-cycle, twelve-year systems.

Public finance has been central to standalone BESS procurement. The Viability Gap Funding (VGF) scheme was introduced to address the early-stage bankability challenges  of  standalone  BESS  projects,  where  high  upfront  costs,  limited operating  history  and  evolving  revenue  models  constrain  private  financing, especially prior to the commercial operation date (COD). Concessional support could  help  bridge  the  financing  gaps  and  enable  greater  IPP  participation, especially  in  emerging  markets  such  as  Indonesia.  VGF  1  (2023)  supported 13.2 GWh with around 30% of CAPEX support and an estimated INR 3 760 crore (approximately USD 4 billion) support envelope. VGF 2 was launched in 2025 to

support 30 GWh, funded through INR 5 400 crore (approximately USD 5.8 billion)VGF-supported  BESS  projects  have  also  begun  to  include localisation requirements: the second VGF tranche requires 20% domestic value addition for BESS using the VGF. Of the 2025 standalone BESS allocations, VGF support  was  present  in  most  large  tenders.  Commercial  financing,  however, remains conservative. The IEEFA indicates lender return expectations of around 15-20%  internal  rate  of  return  for  BESS  projects,  reflecting  limited  operating history, battery degradation  risk, uncertain augmentation  costs,  input-price volatility and off-taker risk. The structure of the BRPL-GEAPP project, described above, shows how concessional debt can lower tariff discovery: 70% of CAPEX was financed at 1% interest, enabling commercial equity participation.

India's next phase is focused on converting a large tender pipeline into operational assets while preserving tariff sustainability and ensuring long-term system value. As of April 2026, operational BESS capacity stands at approximately 5.9 GWh, indicating  that  the  sector  is  still  at  an  early  execution  stage  despite  a  rapidly expanding  pipeline.  Going  forward,  the  focus  will  be  on  strengthening  project bankability  and  ensuring  sustainable  tariffs  through  improved  bid  design,  costreflective benchmarking and robust payment security mechanisms. Greater clarity on technical and contractual frameworks, including performance standards and augmentation requirements, will further enhance investor confidence. In parallel, sharper definition of use cases across peak management, congestion relief and ancillary services will help optimise system value and improve dispatch outcomes, enabling  India's  BESS  ecosystem  to  scale  in  a  structured  and  financially sustainable manner.

## Methodology

## Investment needs and sources of finance

## Overview

Identifying  investment  needs  is  an  essential  step  to  successfully  deploying  a pipeline  of  BESS  projects,  as  doing  so  enables  decision  makers  to  more accurately weigh the costs and benefits of development, identify opportunities for cost savings, and prioritise investments that will have the highest impact per dollar. While PLN's RUPTL  2025-2034  estimates that total investment for the development  of Indonesia's full power  sector will be IDR  2 780 trillion (USD 155 billion), the document does not provide investment totals for individual technologies. As a result, this report models investment needs for the RUPTL's BESS pipeline under the Accelerated Renewable Energy Development scenario.

The report then goes on to connect modelled investment needs with the IEA's existing sources  of  finance  model,  which  provides  further  breakdowns  on investment sponsorship, instrument and financing.

## Data sources

The  IEA  exclusively  uses  reputable  and  peer-reviewed  data  sources  in  its modelling  of  investment  needs  and  sources  of  finance.  Capacity  additions  of BESS  are  drawn  directly  from  data  tables  in  Chapter  V  of  PLN's  RUPTL 2025-2034. Technical specifications on system design, including battery storage duration,  storage-to-generation  sizing  ratios,  battery  lifetimes  and  degradation rates  are  also  acquired  through  the  RUPTL,  when  available,  or  through  direct communication between the IEA and PLN. Additional technical specifications are gathered from Benchmark Mineral Intelligence datasets.

Capital cost data for lithium-ion BESS are gathered from Bloomberg New Energy Finance (BNEF)'s Energy Storage System Cost Survey (2025). Capital expenditure  includes  the  cost  for  battery  packs  and  racks,  balance-of-system components, developer margins, and overhead. Additional data on grid connection costs are also sourced from the BNEF's cost survey. The estimation of investment needs in this report does not include the cost of land acquisition, operations  and  maintenance  (O&amp;M),  decommissioning,  or  recycling  of  BESS components.

The  sources  of  finance  analysis  utilises  the  financial  characteristics  of  BESS projects led by PLN and independent power producers (IPPs). The main sources of data used for this analysis include:

-  S&amp;P Capital  IQ  -  corporate  balance  sheets  and  ownership.  Primarily  used  to calculate debt and equity shares for PLN-led projects and joint ventures.
-  Green  Street  Infrastructure  -  transactions,  ownership  and  financing  of  BESS assets at the project level. Primarily used to estimate debt and equity shares for IPP-led projects.
-  World Bank projects database - project-by-project descriptions of BESS projects financed by the World Bank Group and quantitative financing figures. Primarily used  to  estimate  the  share  of  concessional  financing  in  total  BESS  project investments.
-  Asian Development Bank (ADB) project database - project-by-project descriptions of BESS projects financed by ADB and quantitative financing figures. Primarily used  to  estimate  the  share  of  concessional  financing  in  total  BESS  project investments.
-  Climate Investment Funds, Global Energy Storage Platform (GESP) project list individual descriptions  of  GESP-funded  projects  including  descriptions  and

concessional funding and co-financing amounts. Primarily used to estimate the share of concessional financing in total BESS project investments.

-  The Indonesia technology catalogue - specifications around technical parameters and costs for a wide range of power technologies in Indonesia.

Today, BESS remain a nascent technology in Indonesia and data representing projects in the country are limited. As a result, the models detailed below prioritise Indonesian BESS (standalone and hybrid) projects where available and otherwise use data from similar markets to reinforce data quality. These markets primarily include other Southeast Asian countries, including Cambodia, the Lao People's Democratic Republic (PDR), Malaysia, Myanmar, the Philippines, Thailand and Viet  Nam.  Data  on  projects  in  other  middle-income  countries,  including  Brazil, India and South Africa, are also considered.

## Investment methodology

The investment model created for this report quantifies annual capital expenditure requirements for both standalone BESS systems and the storage components of hybrid solar PV-plus-BESS projects based on the RUPTL's  Accelerated Renewable Energy Development (ARED) scenario. Investment needs are broken down across the RUPTL's five major systems: Sumatra; Java, Madura and Bali (JMB); Kalimantan; Sulawesi; and Maluku, Papua and Nusa Tenggara (MPNT).

First, annual capacity additions for each of these regions are identified based on data tables provided in Chapter V of the RUPTL 2025-2034. Additions are reported in megawatts across most regions, except for Sulawesi and Maluku, Papua and Nusa  Tenggara,  where  they  are  reported in megawatt-hours.  To  ensure consistency,  additions  in  these  regions  are  converted  to  megawatts  using  an assumed  storage duration of four hours -consistent with assumptions communicated by PLN.

Investment needs are highly dependent on the cost of BESS technologies, which are  themselves  determined  by  the  technical  characteristics  of  the  systems installed. Because BESS remain nascent in Indonesia and some technical details remain  to  be  defined  by  PLN  and  MEMR,  the  investment  model  uses  three scenarios  to  represent  the  range  of  costs  and  resulting  investment  needed  to achieve the RUPTL pipeline. These scenarios are designed as follows:

-  Cost efficiencies scenario : PLN prioritises the lowest-cost technologies, opting for shorter storage durations (mainly one to two hours) and smaller shares (10%) of BESS capacity relative to solar PV installations. Annual degradation rates are kept low (1%) as a result of strict limitations on battery cycling, and installation costs  are  minimally  variable  across  regions  due  to  a  prioritisation  of  easily accessible locations.

-  RUPTL-aligned  scenario :  PLN  adheres  to  the  technical  parameters  that  are implied in the RUPTL, prioritising systems with four-hour storage durations and sizing BESS to 20% of solar PV additions in hybrid projects. Annual degradation rates are 2% and the variation in capital and installation costs across subsystems is proportional to that of system-level BPP (average cost of electricity supply) in 2025.
-  High costs scenario : The decision to expand into a wider variety of use cases compels PLN to invest in technologies ranging from one- to eight-hour storage durations, and the storage component of hybrid projects is equivalent to 30% of the  solar  PV  component's  generation  capacity.  More  frequent  battery  cycling brings annual degradation rates to 3%, and the expansion into more remote areas results in a higher degree of cost differentiation across subsystems.

## Technical parameters defining investment needs scenarios

| Scenario          | Standalone storage duration             | Hybrid storage duration   | Annual degradation rate   | BESS:Solar PV sizing ratio   | Locational multipliers                                         |
|-------------------|-----------------------------------------|---------------------------|---------------------------|------------------------------|----------------------------------------------------------------|
| Cost efficiencies | 1 hr: 20% 2 hr: 50% 4 hr: 30% 8 hr: 0%  | 2 hours                   | 1%                        | 1:5                          | Limited deviation from country average                         |
| RUPTL- aligned    | 1 hr: 15% 2 hr: 15% 4 hr: 70% 8 hr: 0%  | 1 hour                    | 2%                        | 1:3                          | Weights determined by regional BPP relative to country average |
| High costs        | 1 hr: 20% 2 hr: 20% 4 hr: 40% 8 hr: 20% | 2 hours                   | 3%                        | 1:2                          | Greater variability across regions                             |

Capital  costs  are  derived  from  BNEF's  Energy  Storage  System  Cost  Survey (2025), consistent with all other BESS investment modelling conducted by the IEA. These  values  include  a  broad  range  of  system  components,  including  battery packs and racks, balance-of-system equipment, energy management systems, power  conversion  components,  and  developer  margins  and  overhead.  Global average costs for two- and four-hour systems are provided by BNEF and used to extrapolate costs for one- and eight- hour systems. Given the limited capacity of BESS manufacturing facilities  in  Southeast  Asia,  batteries  are  assumed  to  be imported primarily from China. Regional variation in system costs, which arises

due to different transportation, installation and labour costs, are reflected in each scenario by regional multipliers detailed above.

Grid connection and EPC costs are estimated separately. Global averages for markets outside of China are also extracted from BNEF datasets and scaled to Indonesia  based  on  the  ratio  of  Indonesia's  BESS  capital  costs  relative  to non-China  capital  costs.  Costs  are  calculated  for  two-  and  four-hour  storage durations and linearly extrapolated for one- and eight- hour systems. The same locational multipliers used to differentiate capital costs across regions are applied to grid connection and EPC costs. For hybrid installations, grid connection and EPC costs are proportional to the share of storage capacity in total solar PV-plusBESS capacity.

Next, an oversizing factor is used to calculate capacity augmentation needs based on annual battery degradation rates defined across each scenario. The oversizing factor is determined according to the following formula:

<!-- formula-not-decoded -->

Where 𝐹𝐹 𝑂𝑂 is the oversizing factor, 𝑅𝑅 𝐶𝐶 is the annual rate of degradation, and 𝑇𝑇 is the asset  lifetime (ten years). Technology  degradation  is  assumed  to  be addressed by oversizing BESS projects at the beginning of their lifetimes, rather than adding BESS capacity partway through the asset's lifetime. While the latter strategy is expected to result in lower total investment needs due to the continued decline in battery capital costs, the former approach offers a higher degree of price certainty and contractual simplicity. The oversizing factor is applied only to capital costs, and not grid connection and EPC costs, under the assumption that grid infrastructure does not require augmentation.

Annual investment is calculated for each region by multiplying annual capacity additions  by  their  corresponding  capital  cost  values.  Standalone  and  hybrid investments are calculated independently and then combined to determine total annual BESS investment by region.

## Sources of finance methodology

The IEA's  sources  of  finance  model  allocates  investment  requirements  across sponsor, instrument and financier types; and was adapted for this report to reflect specific conditions for BESS and Indonesia. These calculations rely on capacity allocations in the RUPTL and debt-equity ratios derived from PLN's balance sheet and existing project finance data.

First,  sponsorship  is  determined  according  to  standalone  and  hybrid  BESS capacity  allocations  listed  in  Chapter  V  of  the  RUPTL.  The  document  assigns projects to PLN, PLN's sub-holdings (SH-PLN) and IPPs. For hybrid projects, it is

assumed  that  the  generation  and  storage  components  of  each  project  are developed by the same sponsor(s). As with the investment methodology listed above, megawatt-hour values are converted to megawatts in Sulawesi and MPNT based  on  an  assumed  four-hour  storage  duration.  For  each  region  and  year, sponsorship shares are calculated by dividing the capacity allocated to PLN and SH-PLN by total additions, with the remainder assigned to IPPs. While capacities allocated to SH-PLN are permitted to pursue joint ventures with IPPs, the RUPTL specifies that PLN is to maintain a majority stake in such arrangements, which is why  these  additions  are  considered  to  be  sponsored  by  PLN.  Resulting sponsorship shares are then applied to total investment to determine the portions financed by PLN and IPPs.

## Sponsor breakdown

<!-- image -->

Note: The RUPTL stipulates that PLN is to retain a majority stake in projects sponsored by joint ventures between PLN and IPPs. Such projects are therefore identified as PLN-sponsored in IEA analysis.

Next, instrument (debt and equity) shares are determined using available project finance data, accessed through Green Street Infrastructure datasets, and PLN's 2024 balance sheet (the most recently published version at the time of analysis), accessed  through  S&amp;P  Capital  IQ.  Projects  sponsored  by  PLN  and  its  subholdings are assumed to be financed on-balance sheet: shares of debt and equity from PLN's balance sheet are therefore applied to PLN's portion of investment. For IPPs, BESS projects are assumed to be financed off-balance sheet. Weighted average debt and equity ratios are therefore calculated based on the financing

structures  of  over  20  solar  PV,  wind,  hybrid  and  BESS  projects  across  Asia (excluding China, Korea and Japan). Resulting debt and equity shares are then applied to IPPs' portion of investment.

## Instrument breakdown

## Instrument breakdown

Note: BCA = Bank Central Asia; BRI = Bank Rakyat Indonesia.

<!-- image -->

Finally,  investments  are  broken  down  by  financier  types,  which  represent  the ultimate  providers  of  capital.  International  public  finance  (IPF)  from  multilateral climate  funds,  export  credit  agencies,  and  development  finance  institutions (among others) are expected to provide a key role in de-risking early projects. As a result, IPF shares are highest in the early years of deployment and decline over time as project bankability improves. The degree of IPF involvement is also likely to  vary  across  regions:  for  instance,  Sumatra  and  Java,  Madura  and  Bali  are expected to require relatively little support due to their mature power systems, while Maluku, Papua and Nusa Tenggara will require more concessional support due  to  higher  project  complexity.  Shares  of  IPF  are  determined  based  on benchmarks  obtained  from  projects  supported  by  providers  of  concessional finance, including the World Bank, the ADB and Climate Investment Funds (CIF). The below shares are applied to each region's and year's investments to the level of financing sourced from international providers.

Assumed international public finance shares by year and region

| Region     | 2025   | 2026   | 2027   | 2028   | 2029   | 2030   | 2031   | 2032   | 2033   | 2034   |
|------------|--------|--------|--------|--------|--------|--------|--------|--------|--------|--------|
| Sumatra    | 0%     | 5%     | 5%     | 2%     | 2%     | 0%     | 0%     | 0%     | 0%     | 0%     |
| JMB        | 10%    | 5%     | 2%     | 2%     | 2%     | 0%     | 0%     | 0%     | 0%     | 0%     |
| Kalimantan | 0%     | 10%    | 10%    | 5%     | 5%     | 5%     | 2%     | 0%     | 0%     | 0%     |
| Sulawesi   | 10%    | 10%    | 5%     | 5%     | 2%     | 2%     | 0%     | 0%     | 0%     | 0%     |
| MPNT       | 50%    | 40%    | 30%    | 20%    | 10%    | 5%     | 2%     | 2%     | 2%     | 2%     |

Notes: JMB = Java, Madura and Bali. MPNT = Maluku, Papua and Nusa Tenggara. IPF is to be provided in the first year that capacity additions appear for each region.

Public financing is defined as the equity portion of PLN's investment, consistent with the assumption that PLN's equity is treated as public capital due to its status as a state-owned enterprise. Commercial financing is defined as the sum of PLN's debt portion  and  all  IPP  investment,  excluding  IPF.  For  each  year  and  region, financing portions are therefore calculated according to the following formulas:

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

<!-- formula-not-decoded -->

Where 𝐹𝐹 𝐼𝐼𝐼𝐼𝐼𝐼 is international public finance, 𝐼𝐼 is total investment for the corresponding year and region, 𝐼𝐼𝑃𝑃𝐹𝐹 is the share of IPF for the corresponding year and region, 𝐹𝐹 𝐼𝐼𝑃𝑃𝐵𝐵 is public finance, 𝐹𝐹𝐶𝐶𝐶𝐶 𝐼𝐼𝑃𝑃𝑃𝑃 is capacity allocated to PLN and its subholdings, 𝐹𝐹𝐶𝐶𝐶𝐶 𝑇𝑇𝑇𝑇𝑇𝑇𝑇𝑇𝑇𝑇 is  total  capacity  additions, 𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸𝐸 𝐼𝐼𝑃𝑃𝑃𝑃 is  PLN's  total  equity  in 2024, 𝑇𝑇𝑇𝑇𝐸𝐸𝐶𝐶𝑇𝑇 𝐼𝐼𝑃𝑃𝑃𝑃 is PLN's total assets in 2024, 𝐹𝐹 𝐶𝐶𝑂𝑂𝐶𝐶 is commercial finance, 𝐷𝐷𝐷𝐷𝐷𝐷𝐸𝐸 𝐼𝐼𝑃𝑃𝑃𝑃 is PLN's total debt in 2024, and 𝐹𝐹𝐶𝐶𝐶𝐶 𝐼𝐼𝐼𝐼𝐼𝐼 is capacity allocated to IPPs.

## Financier breakdown

<!-- image -->

The  sources  of  finance  analysis  also  allows  this  report  to  identify  the  level  of concessional  finance  that  is  expected  to  be  provided  to  achieve  the  RUPTL's BESS  pipeline.  In  this  analysis,  IPF  is  always  considered  to  be  provided  on concessional terms. Moreover, debt offered to PLN by domestic public banks such as PT SMI - is also considered to be concessional. This is because, when lending to an Indonesian state-owned enterprise, Indonesian public banks are not expected  to  perceive  political  and  regulatory  risks  to  the  same  extent  as international lenders. The share of financing provided to PLN by domestic public banks  is  determined  through  direct  consultation  between  the  IEA  and  PLN's finance  divisions,  and  is  applied  to  PLN's  total  debt  investment  as  calculated above.

## Financial modelling and cash flow analysis

The bankability assessment estimates the minimum revenue level at which each of  the  two  BESS  archetypes  identified  in  the  RUPTL  2025-2034  -  standalone BESS and hybrid solar PV-plus-BESS - meets the return and credit thresholds that  commercial  investors  and  lenders  would  apply  to  an  Indonesian  power project. The analysis is designed as a directional guide for policy makers, PLN and prospective investors. It quantifies the approximate revenue requirement for a  representative  project  in  each  of  the  five  island  systems,  traces  how  that requirement evolves over the RUPTL deployment period as capital costs decline and tests its sensitivity to the principal cost and financing drivers. It is not intended

to replicate project-level due diligence, and the results should not be read as tariff recommendations for any specific transaction. All monetary values are expressed in nominal US dollars.

Both archetypes are assessed with the same discrete annual cash flow model, built over a ten-year horizon: an investment year (Year 0), in which the full capital cost is incurred, followed by ten years of operations (Years 1-10), corresponding to  the  assumed  economic  life  of  the  battery  system.  The  model  constructs  a complete  levered  project  cash  flow  for  a  trial  revenue  level,  comprising  the following elements.

Revenue . Annual revenue in Year 1 equals the trial tariff multiplied by contracted capacity, and escalates at 3% per year thereafter, so that revenue in year t equals the Year1 level multiplied by (1.03)^(t-1). Revenue is assumed to be earned on the full contracted capacity in every operating year.

Operating costs . Fixed O&amp;M costs are modelled as a percentage of the capital cost of each asset component per year (2.5% for the battery system and 1.0% for the grid connection), escalating at the same 3% rate as revenue. No variable O&amp;M or  charging  cost  is  modelled,  consistent  with  an  availability-based  revenue structure in which charging energy is supplied by the off-taker (standalone) or by the co-located solar plant (hybrid).

Depreciation and tax . The full capital cost is depreciated on a straight-line basis over the ten-year asset life. Corporate income tax is applied at 22% to earnings after depreciation and interest.

Debt . Debt is sized as a fixed share of total capital cost (65% for standalone and 70% for  hybrid  projects)  and  repaid  as  a  level  annuity  over  a  ten-year  tenor, matching the asset life, at the applicable interest rate (7.5% in the commercial base case). Interest and principal in each year are computed from the annuity schedule.

Equity  cash  flow  and  credit  metrics .  Cash  flow  available  for  debt  service (CFADS) is equal to EBITDA (earnings before interest, taxes, depreciation, and amortisation) less levered tax; the debt service coverage ratio (DSCR) is CFADS divided  by  scheduled  debt  service  in  each  year  and  is  reported  against  a 1.5x covenant benchmark. Equity cash flow is CFADS less debt service, with the equity investment (35% or 30% of capital cost) incurred in Year 0.

The model reports the unlevered project internal rate of return, the levered equity internal rate of return and the minimum DSCR over the debt tenor at any trial tariff, benchmarked against target values of 7.5%, 13.5% and 1.5x respectively.

Capital expenditures (CAPEX). CAPEX inputs vary across island systems in the standalone case, and vary alongside the solar capacity factor in the hybrid case.

Costs for the battery system, expressed in US dollar per megawatt for the relevant duration (four-hour standalone; one-hour hybrid), and for the grid connection are drawn from the IEA investment model underlying the RUPTL-aligned investment scenario, which reflects regional differences in logistics, installation and balanceof-system costs.

For the  analysis  of  tariffs  by  commissioning  year,  capital  costs  follow  the  cost curve  of  the  RUPTL-aligned  investment  scenario,  under  which  battery  capital costs decline by approximately 28% between 2025 and 2034 in each system, with grid connection costs declining more modestly. Solar PV capital costs, used for reference in the hybrid configuration, follow the IEA Global Energy and Climate Model 2025 Stated Policies Scenario trajectory. The bankable and break-even tariffs are re-solved for each island system and each commissioning year using the applicable year's capital cost, with all financial parameters held constant. The pipeline-weighted  average  tariff  reported  in  Chapter  4  weights  each  island system's bankable tariff by its standalone BESS capacity in the RUPTL pipeline (Sumatra 1 075 MW; Java, Madura and Bali 4 213 MW; Kalimantan 725 MW; Sulawesi 516 MW; Maluku, Papua and Nusa Tenggara 80 MW).

## Limitations

The analysis is illustrative by design, and several simplifications should be borne in mind when interpreting the results.

Single  revenue  stream .  Each  archetype  is  assumed  to  earn  one  contracted revenue stream, an availability payment for standalone projects and a PPA uplift for hybrid projects. No merchant, ancillary service, arbitrage or capacity market revenue stacking is modelled, reflecting the absence of such markets in Indonesia today.

Financing structure . Debt is repaid as a level annuity over a tenor equal to the asset life, rather than sculpted to cash flows, and the DSCR covenant is reported as a check rather than imposed as a binding constraint. At the bankable tariff the minimum DSCR falls marginally below 1.5x in early operating years; enforcing the covenant strictly would require slightly lower gearing and raise the required tariff by  an  estimated  2-3%.  Financing  terms  are  held  constant  across  regions  and years, whereas in practice pricing would reflect system-specific and counterparty risk.

Construction and timing . The full capital cost is incurred in a single investment year, with no  construction period phasing,  interest during  construction or drawdown schedule. Working capital, debt service reserve accounts and upfront financing fees are excluded. These exclusions modestly understate the effective capital requirement and therefore the required tariff.

Asset life and residual value . The ten-year asset life is conservative relative to warranted battery lifetimes of 15 years or more, and no residual or terminal value is credited at the end of the horizon. Revenue is assumed to be earned on full contracted capacity throughout; battery degradation and any augmentation capital required to maintain contracted capacity are treated as implicitly covered within the fixed O&amp;M allowance rather than modelled explicitly.

Currency . The  model  is denominated  in  US  dollars, implicitly assuming USD-denominated  or  USD-indexed  revenues,  consistent  with  prevailing  IPP contracting practice in Indonesia. No currency mismatch between revenues, costs and  debt  service  is  modelled,  and  no  hedging  cost  is  included.  Projects  with rupiah-denominated revenues would face materially different financing conditions.

Hybrid  configuration .  The  hybrid  results  isolate  the  battery  component  and assume the solar plant is  independently  bankable;  they  therefore  exclude  any interaction  between the two components in financing, and exclude curtailment, charging  losses  and  round-trip  efficiency  effects  on  the  solar  plant's  saleable output. The one-hour, 30% sizing reflects a peak-shifting function; longer-duration configurations would carry higher capital costs and require a larger uplift.

Data basis . Capital cost inputs derive from the IEA investment model and industry consultations rather than observed Indonesian transaction data, of which there are very little for BESS. As transaction precedents accumulate, both the level and the regional dispersion of costs should be recalibrated.

Within these limitations, the framework provides a consistent, transparent basis for  comparing  revenue  requirements  across  archetypes,  island  systems  and commissioning years, and for assessing where and when concessional support is most likely to be decisive.

## Definitions

Active power: The real electrical power delivered to or absorbed from the grid. In BESS, active power determines the charging and discharging rate of the battery.

Ancillary services procurement agreement (ASPA): A contractual agreement between  a  system  operator  and  a  BESS  asset  owner  through  which  ancillary services are procured and often remunerated through availability payments.

Anode: The negative electrode, typically made of graphite, in a lithium-ion battery.

Black start :  The capability by a BESS (or other electricity generator) to restart parts of a grid after a blackout without the support of an external power supply.

Cathode: The positive electrode in a lithium-ion battery. Technologies used for stationary storage  most commonly use lithium iron phosphate (LFP) cathodes. The  composition  of  battery  cathodes  determines  properties  such  as  energy density, cost sensitivities and overall battery performance.

Congestion  relief :  The  reduction  of  strain  on  transmission  or  distribution  by strategically charging or discharging of BESS assets, thus relieving bottlenecks in power  flows,  improving  system  reliability  and  reducing  curtailment  of  excess electricity.

Commercial operation date (COD) : The date upon which a project becomes fully operational, begins delivering contracted services and generates revenue.

Contingency  reserve :  The  provision  of  backup  power  to  be  injected  on  the system  in  the  case  of  unexpected  outages  or  generator  failures.  Contingency reserves can generally be injected instantly by BESS assets.

Currency  risk :  Also  called  foreign  exchange  risk,  currency  risk  occurs  when project revenues are denominated in a local currency (such as Indonesian rupiah) while  debt  obligations  are  denominated  in  a  foreign  currency  (such  as  United States dollars). If the local currency weakens against the foreign currency, project revenues may become insufficient to fulfil debt obligations.

Energy arbitrage : A BESS service that addresses electricity price differentials by charging the asset when prices are low and discharging when prices are high. Energy arbitrage is remunerated through energy-based payments and therefore becomes most valuable in systems with wholesale power markets or granular time-of-use electricity pricing.

Frequency  regulation  services : The  stabilisation  of  grid  frequency  through nearly instantaneous injections or absorptions of power.

Hybrid  BESS: Under  Indonesian  regulation,  hybrid  BESS  refers  to  storage systems co-located with one or more sources of renewable (including solar PV, wind,  hydropower  or  biomass),  diesel,  or  hydrogen  generation  and  integrated under a single project structure.

Independent power producer (IPP): A private sector developer that finances, builds and occasionally operates BESS projects.

Institutional investors: Investors that generally invest large pools of capital and seek stable, long-term returns, such as pension funds, sovereign wealth funds, insurers and asset managers.

Levelised  cost  of  energy  (LCOS): An  indicator  of  the  expected  average production  cost  for  each  unit  of  electricity  generated  by  a  technology  over  its economic lifetime. The LCOE combines into a single metric all the cost elements directly associated  with  a given  power  technology,  including  construction, financing, fuel, maintenance and costs associated with a carbon price. It does not include network integration or other indirect costs.

Levelised cost of storage (LCOS) : Measures the lifetime cost of delivering one unit of stored electricity, taking into consideration capital expenditures, operation and maintenance (O&amp;M) costs, efficiency losses and degradation.

Load following :  The  steady  adjustment  of  power  output  to  match  changes  in electricity demand or generation.

Load shifting: A BESS service in which assets are charged during periods of low demand  and  discharged  during  periods  of  high  demand,  thereby  reducing curtailment and improving utilisation rates of intermittent renewable generation. Load  shifting  generally  refers  to  the  storage  and  release  of  electricity  over durations of several minutes to several hours.

Load smoothing : A BESS service similar to load shifting (see above), but over more rapid timescales of seconds and minutes.

Non-recourse debt: Financing that is secured by a project's (or special purpose vehicle's) assets and cash flows rather than the ultimate project sponsor's balance sheet.

Peak capacity reserves: The provision of additional  power  during  a  system's periods  of  highest  demand,  thereby  reducing  the  need  for  load  shedding  and thermal peaker plants.

Power purchase agreement (PPA): A long-term contract (often 10 to 20 years) that defines the tariffs at which an off-taker purchases determined quantities of electricity or services from a BESS asset owner.

Preferential  dividend  treatment: A  contractual  agreement  wherein  specified shareholders are prioritised for the receipt of dividends. Such arrangements are used to attract investors with lower risk tolerances.

Ramping  reserve: The  charging  or  discharging  of  BESS  assets  during  rapid changes in generation or demand (respectively).

Reactive  power: Electrical  power  exchanged  with  the  grid  to  support  voltage control and system stability. Reactive power does not involve a net transfer of energy and can be provided by a BESS through its power conversion system.

Retail electricity market: Markets selling electricity directly to end users, often by large- scale aggregators that acquire electricity on wholesale markets. Retail prices are driven by prices on wholesale markets and distribution costs.

Ring-fencing: The isolation of a project's assets, liabilities and cash flows from its ultimate parent company, generally through the creation of a special purpose vehicle.

Standalone BESS: Storage assets that are not paired with generation assets and are therefore generally treated as network components.

Stated  Energy  Policies  Scenario  (STEPS): The  IEA  scenario  that  reflects today's  policy  settings  together  with  announced  policy  intentions  and  targets, provided they are supported by detailed implementation plans. It illustrates the direction of the energy system based on current policy frameworks and serves as a benchmark for assessing future energy trends.

Step-down interest rates: Concessional loans in which interest rates gradually decline over time as project revenues stabilise and risks fall.

Step-in powers: Privilege that allows lenders or public financiers to temporarily take control of a project if they consider it to be under financial stress.

Sunset clauses: Included in concessional financing structures, sunset clauses define  an  end  date  for  support  mechanisms,  thereby  mitigating  long-term dependence.

Time-bound concessionality provisions: Limit  the  provision  of  concessional support  to specified phases  of  a  project's life, such  as  development  or construction.

Voltage  support: The  stabilisation of network  voltage through  the rapid absorption or injection of reactive power, thereby maintaining power quality.

Wholesale electricity markets: Markets that enable  bulk  trading  of  electricity among generators, system operators and retailers. Wholesale prices are reflective of supply-demand conditions and system constraints.

## Abbreviations and acronyms

AC

Alternating current

ADB

Asian Development Bank

ARED

Accelerated Renewable Energy Development

ASEAN

Association of Southeast Asian Nations

ASPA

Ancillary service procurement agreement

BAPPENAS

Ministry of National Development Planning

BESS

Battery energy storage system

BOO

Build-own-operate

BOOT

Build-own-operate-transfer

BPP

biaya pokok penyediaan (PLN's system cost of electricity supply)

BRPL

BSES Rajdhani Power Limited

CAPEX

Capital expenditure

CFADS

cash flow available for debt service

CIPP

Comprehensive Investment and Policy Plan

COD

Commercial Operation Date

DC

Direct current

DEN

Dewan Energi Nasional

DFI

Development finance institution

DJK

Directorate General of Electricity

DSCR

Debt service coverage ratio

EBITDA

Earnings before interest, taxes, depreciation and amortisation

EBTKE

Directorate General of New and Renewable Energy and Energy

Conservation

ECA

Export credit agency

EMDE

Emerging market and developing economies

EPC

Engineering, procurement and construction

EVN

Viet Nam Electricity

FX

Foreign exchange

GEAPP

Global Energy Alliance for People and Planet

GESP

Global Energy Storage Platform

IDR

Indonesian rupiah

IEA

International Energy Agency

INA

Indonesia Investment Authority

INR

Indian rupee

IPF

International Public Finance

IPP

Independent power producer

IRR

Internal rate of return

IUPTL

Electricity Supply Business License

JETP

Indonesia Just Energy Transition Partnership

JMB

Java, Madura and Bali

KPBU

Kerjasama Pemerintah dengan Badan Usaha

LCOE

Levelised cost of electricity

LCOS

Levelised cost of storage

LFP

Lithium iron phosphate

MCFs

Multilateral climate funds

MDB

Multilateral development bank

MEMR

Ministry of Energy and Mineral Resources

MER

Market exchange rate

MoF

Ministry of Finance

MPNT

Maluku, Papua and Nusa Tenggara

NMC

Lithium nickel manganese cobalt oxide

O&amp;M

Operation and maintenance

OPEX

Operational expenditure

PCS

Power conversion system

PHP

Philippine pesos

PLN

PT Perusahaan Listrik Negara

PPA

Power purchase agreement

PT SMI

PT Sarana Multi Infrastruktur

PV

Photovoltaic

RE Base

Renewable Indonesia Base

RFP

Request for proposals

RUPTL

Rencana Usaha Penyediaan Tenaga Listrik: PLN's Electricity Supply

Business Plan

SOE

State-owned enterprise

SPV

Special purpose vehicle

STEPS

Stated Energy Policies Scenario

US

United States

USD

United States dollar

VGF

Viability Gap Funding

VND

Vietnamese dong

VRE

Variable renewable energy

WACC

Weighted average cost of capital

WESM

Wholesale electricity spot market

## Units

bps

basis points

GW

gigawatt

GWh

gigawatt-hour

kW

kilowatt

kWh

kilowatt-hour

MW

megawatt

MWh

megawatt-hour

TWh

terawatt-hour

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual Member countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

For further information, please contact the Energy Investment Unit (investment@iea.org).

<!-- image -->

Subject  to  the IEA's Notice  for  CC-licenced  Content,  this  work is licenced under  a  Creative  Commons  Attribution  4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area. Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Revised version, September 2026 Information notice found at: www.iea.org/corrections

Typeset in France by IEA - September 2026 Cover design: IEA Photo credits: © Shutterstock

<!-- image -->