---
document_id: iea_asean_energy_security_2024
title: "ASEAN Energy Security Review"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IEA"
year: 2024
original_file: "iea_asean_energy_security_review.pdf"
tables_detected: 106
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## ASEAN Energy Security Review

Strengthening energy systems for a growing region

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 14 Association countries and beyond.

## IEA M ember countries:

This publication, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. International Energy Agency Website: www.iea.org

IEA Accession countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Chile Colombia Costa Rica Brazil Israel

Romania

## IEA A ssociation countries:

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Nigeria

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Abstract

This report reviews ASEAN's energy security considerations and policy options as the  region  faces  rapidly  growing  energy  needs  and  an  increasingly  complex energy landscape. Energy security has long been an important priority for ASEAN member  states,  and  its  significance  has  grown  alongside  economic  growth, industrial  development,  urbanisation  and  rising  living  standards,  which  have continued to drive strong growth in energy demand across the region. Southeast Asia is emerging as one of the main centres of energy demand growth globally. Energy  systems  remain  highly  diverse  across  ASEAN  member  states  and continue to rely on a mix of domestic resources, regional trade and international imports. Ensuring a secure, affordable and sustainable energy supply is therefore essential not only for maintaining economic momentum and social development, but also for strengthening the region's resilience to geopolitical shocks, volatile fuel prices, extreme weather events and the changing dynamics of global energy markets.

The  region  faces  a  broad  set  of  interconnected  energy  security  challenges, including  rising  dependence  on  imported  oil  and  LNG,  exposure  to  strategic maritime choke points, uneven preparedness for supply disruptions, the need to maintain reliable and affordable electricity systems, and emerging risks linked to clean  energy  supply  chains  and  critical  minerals.  As  the  report  shows,  energy security will increasingly depend on diversified supply, greater use of domestic resources,  and  accelerated  electrification  and  efficiency  within  an  integrated, systems-based approach. Next to these policies, the report covers a wide range of  additional  options  to  address  energy  security  challenges.  These  include expanding strategic stocks, investing in infrastructure, and improving demand-side flexibility;  accelerating  clean  energy  deployment  where  it  reduces  exposure  to imported  fuels;  improving  emergency  planning  and  market  monitoring;  and deepening regional co-operation through more effective mechanisms for information  sharing, co-ordinated  response,  cross-border  infrastructure  and collective  preparedness.  Taken  together,  these  measures  can  help  ASEAN manage near-term risks while building a more secure and flexible energy system for the longer term.

## Acknowledgements, contributors and credits

This report was prepared by the Energy Markets and Security (EMS) Directorate of the International Energy Agency (IEA) in close co-operation with its Office of Global Energy Relations and the IEA Regional Co-operation Centre in Singapore.

The report was designed and directed by Dennis Hesseling. The lead authors per chapter  were  Dennis  Hesseling  and  Sue-Ern  Tan  (executive  summary  and introduction), David Martin, Cuauhtemoc Lopez-Bassols and Alara Kocabas (oil and  biofuels),  Akos  Losz  (gas  and  low-emissions  gases),  Carlos  Fernandez Alvarez and Tiffany Yuan (coal and solid biofuels), Camille Paillard and Peerapat Vithayasrichareon  (electricity),  Renee  Stephens  and  Federico  Callioni  (energy efficiency and demand-side management), and Milosz Karpinski (critical minerals). Additional contributions were made by Ana Alcalde Báscones, Sophie Attali, Piotr  Bojek,  Andrew  Klain,  Carina  Gwennap,  Chris  Matthew,  Shane McDonagh, Hunor Papolczi, Nikesh Radha, Akiko Sasakawa, and Yinglun Teng.

Shinichi Kihara, Director of the Energy Markets and Security Directorate of the IEA, provided strategic guidance and direction for the report.

Other IEA colleagues who provided valuable feedback, analysis and data for the report include Jemima Storey, Jérôme Bilodeau, Alessandro Blasi, Toril Bosoni, Eren Cam, Peter Coleman, Amrita Dasgupta, Dan Dorner, Jason Elliott, Rodrigo Fernandez,  Paolo  Frankl,  Sam  Gee,  Tim  Gould,  Tetsuya  Mizuno,  Brendan Reidenbach, Philippe Rose, Alessio Scanziani, Melanie Slade and Ors Sumeghy.

Relations  and  meetings  in  the  region  were  managed  by  Sue-Ern  Tan,  Simon Rolland, Ranya Oualid and Hasti Wiandita.

Sydnie McCormick acted as project secretary and provided essential administrative support. Lucy Bonsall provided graphic support.

This  report  was  developed  in  close  co-ordination  with  the  ASEAN  Centre  for Energy  (ACE),  the  ASEAN  Secretariat  and  ASEAN  member  states.  Particular thanks go to Septia Buntara (ASEC) and Beni Suryadi (ACE) for their collegial co-operation.

Senior  government  officials  and  international  experts  provided  input  both  inperson and through virtual consultations. Their information and suggestions were of great value. They include (in alphabetical order of the country covered or in which they are based):

## Brunei :

-  Brunei Shell Petroleum
-  Department of Electrical Services
-  Department of Energy
-  Electrical Authority Brunei Darussalam
-  Petroleum Authority of Brunei Darussalam
-  PetroleumBRUNEI

## Cambodia :

-  Energy Lab
-  Ministry of Mines and Energy

## Indonesia :

-  Asia Zero Emission Community
-  Economic Research Institute for ASEAN and East Asia
-  Institute for Essential Service Reform
-  Ministry of Energy and Mineral Resources of Indonesia
-  National Energy Council
-  Persero
-  Security and Downstreaming Task Force
-  Shift Institute

## Lao People's Democratic Republic:

-  Energy Lab

## Malaysia:

-  Petroleum Unit of the Energy Division, Ministry of Economy Malaysia

## Philippines:

-  Department of Energy

## Singapore :

-  Energy Market Authority
-  Energy Market Company
-  ISEAS - Yusof Ishak Institute
-  Ministry of Trade and Industry

## Thailand:

-  Department of Alternative Energy Development and Efficiency
-  Electricity Generating Authority of Thailand
-  Energy Policy and Planning Office
-  PTT Public Company Limited

## Timor-Leste:

-  Electricidade de Timor-Leste, Empresa Pública
-  Ministry of Petroleum and Mineral
-  Ministry of Public Works
-  Murak Rai Timor, Empresa Pública
-  National Mineral Authority

## Viet Nam:

-  Institute of Energy
-  Ministry of Industry and Trade
-  National Power System and Market Operator
-  Petrovietnam
-  Viet Nam National Coal and Mineral Industries Group

Peer reviewers provided essential feedback to an earlier draft of the report, which improved  the  quality  of  the  work.  They  include  Siddharth  Goel,  Elrika  Hamdi, Tisha-Nok Krecke and Rena Kuwahata (Agora Energiewende), David Fyfe (Argus Media), Anna Rellama (Arthur D. Little), Elaine Lim (Energy Market Authority plus National Environment Agency and Construction Authority, Singapore), Li Zhenhui (Energy  Market  Company,  Singapore),  Putra  Adhiguna  (Energy  Shift  Institute, Indonesia), Bethany Hebditch (Foreign, Commonwealth &amp; Development Office, UK),  Yoshiaki  Shibata  (Institute  of  Energy  Economics,  Japan),  Fabby  Tumiwa (Institute  for  Essential  Services  Reform,  Indonesia),  Christopher  Len  (ISEAS  Yusof Ishak Institute and Future Energy Storage &amp; System Integration Alliance,

Singapore),  Akira  Yabumoto  (J-Power,  Japan),  Simon  Fitzgerald  (Minerals Council  of  Australia),  Madhavi  Srinivasan  (Nanyang  Technological  University, Singapore),  Matthew  Wittenstein  (World  Bank  Group)  and  Harry  Tchilinguirian (independent expert). Singapore GasCo and Singapore LNG Corporation (SLNG) also provided comments. The earlier draft was also checked by Laila Nowell (Asia Natural Gas &amp; Energy Association), Mark Hutchinson (Future Energy Storage &amp; System Integration Alliance, Singapore) and Dean Rizzetti (EnergyLab Asia).

The IEA Communications and Digital Office (CDO) provided support in producing, launching and promoting the report. Particular thanks go to Astrid Dumond and Liv Gaunt.

Justin French-Brooks edited the report.

This report was made possible thanks to the generous support of Loughborough University.

The  individuals and  organisations that contributed to this report are not responsible for its contents. Any errors or omissions are the sole responsibility of the IEA.

## Table of contents

| Executive summary..............................................................................................................11       |                                                                                                             |
|-----------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------|
| Recommendations by fuel and technology ......................................................................                           | 13                                                                                                          |
| Introduction: Energy security context, framework and overview                                                                           | .................................... 17                                                                     |
| ASEAN regional energy profile                                                                                                           | ........................................................................................ 17                 |
| Energy demand trends                                                                                                                    | ........................................................................................... 17              |
| Composition of the energy mix ...............................................................................                           | 18                                                                                                          |
| Import dependency ratios                                                                                                                | ....................................................................................... 19                  |
| Energy intensity and efficiency ...............................................................................                         | 22                                                                                                          |
| Assessment framework and time horizon ......................................................................                            | 23                                                                                                          |
| Overview of chapters........................................................................................................25          |                                                                                                             |
| Oil and biofuels security review..........................................................................................27            |                                                                                                             |
| Oil demand.........................................................................................................................28   |                                                                                                             |
| Crude and product supply................................................................................................29              |                                                                                                             |
| Oil production..........................................................................................................29              |                                                                                                             |
| Refining capacity and throughput ...........................................................................                            | 30                                                                                                          |
| Liquid biofuels.........................................................................................................31              |                                                                                                             |
| Five-year outlook and implications .................................................................................                    | 34                                                                                                          |
| Oil security assessment ...................................................................................................             | 35                                                                                                          |
| Supply-side security................................................................................................36                  |                                                                                                             |
| Demand-side readiness..........................................................................................37                       |                                                                                                             |
| Exposure to economic and price risk......................................................................                               | 38                                                                                                          |
| Oil stockholding as a resilience tool........................................................................                           | 39                                                                                                          |
| Stockholding models                                                                                                                     | ........................................................................................... 41              |
| Regional co-operation                                                                                                                   | ......................................................................................... 44                |
| A path forward                                                                                                                          | .....................................................................................................46     |
| In-depth analysis: Indonesia                                                                                                            | ............................................................................................ 47             |
| Natural gas and low-emissions gases security review                                                                                     | ..................................................... 49                                                    |
| Gas demand.......................................................................................................................49     |                                                                                                             |
| Gas supply.........................................................................................................................51   |                                                                                                             |
| Natural gas production............................................................................................51                    |                                                                                                             |
| Low-emissions gases                                                                                                                     | .............................................................................................51             |
| Biomethane                                                                                                                              | .........................................................................................................51 |
| Low-emissions hydrogen.....................................................................................53                           |                                                                                                             |
| Gas trade............................................................................................................................54 |                                                                                                             |
| Five-year outlook...............................................................................................................55      |                                                                                                             |
| Gas security assessment .................................................................................................               | 57                                                                                                          |

| Supply-side security ......................................................................................................... 57                                                                                                                    |
|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Domestic production base ............................................................................................... 57                                                                                                                          |
| Import dependency .......................................................................................................... 58                                                                                                                      |
| Exposure to choke points.................................................................................................60                                                                                                                          |
| Infrastructure adequacy ................................................................................................... 62                                                                                                                       |
| Demand-side readiness....................................................................................................65                                                                                                                          |
| Exposure to economic and price risk..............................................................................67                                                                                                                                  |
| System resilience..............................................................................................................67                                                                                                                    |
| Strategic buffers and stocks.............................................................................................67                                                                                                                          |
| Infrastructure resilience....................................................................................................68                                                                                                                      |
| Climate and weather resilience........................................................................................69                                                                                                                             |
| Coal and solid biofuels security review..............................................................................71                                                                                                                              |
| Coal demand......................................................................................................................71                                                                                                                  |
| Coal in metal production .................................................................................................. 72                                                                                                                       |
| Coal supply........................................................................................................................73                                                                                                                |
| Coal reserves...................................................................................................................73                                                                                                                   |
| Domestic production ........................................................................................................ 74                                                                                                                      |
| Import dependency and supply diversification..................................................... 75 biofuels....................................................................................77                                                  |
| Modern sustainable solid                                                                                                                                                                                                                             |
| Five-year outlook...............................................................................................................80                                                                                                                   |
| Demand...........................................................................................................................80                                                                                                                  |
| Supply..............................................................................................................................81                                                                                                               |
| Phase-out plans and transition pathways ........................................................................ 81                                                                                                                                  |
| Coal security assessment ................................................................................................ 83                                                                                                                         |
| Supply-side security.........................................................................................................83 readiness...................................................................................................84       |
| Demand-side                                                                                                                                                                                                                                          |
| Exposure to economic and price risk ............................................................................... 86                                                                                                                               |
| Electricity and renewables security review........................................................................87 Electricity demand ............................................................................................................ |
| Electricity supply...............................................................................................................87                                                                                                                  |
| ............................................................................................................ 88                                                                                                                                      |
| Electricity markets                                                                                                                                                                                                                                  |
| Electricity security                                                                                                                                                                                                                                 |
| Supply..............................................................................................................................90                                                                                                               |
| assessment.......................................................................................91                                                                                                                                                  |
| Supply-side security.........................................................................................................92                                                                                                                      |
| System adequacy................................................................................................92 System resilience ................................................................................................94               |
| Solar PV and wind supply chains ........................................................................ 96                                                                                                                                          |

| Exposure to economic and price risk ...............................................................................                      | 98                                                                                                                        |
|------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------|
| System flexibility ............................................................................................................          | 100                                                                                                                       |
| Regional co-operation....................................................................................................102             |                                                                                                                           |
| Priorities to support APG implementation..........................................................103                                    |                                                                                                                           |
| Energy efficiency and demand-side management...........................................................104                               |                                                                                                                           |
| Energy efficiency.............................................................................................................           | 106                                                                                                                       |
| Policy landscape .............................................................................................................           | 107                                                                                                                       |
| Buildings ........................................................................................................................       | 107                                                                                                                       |
| Appliances                                                                                                                               | ..................................................................................................................... 109 |
| Transport .......................................................................................................................        | 111                                                                                                                       |
| Electrification                                                                                                                          | .....................................................................................................113                  |
| Industry..........................................................................................................................       | 114                                                                                                                       |
| Demand-side flexibility ...................................................................................................              | 116                                                                                                                       |
| Critical minerals security review.......................................................................................                 | 119                                                                                                                       |
| Critical minerals overview..............................................................................................119              |                                                                                                                           |
| Critical minerals supply..................................................................................................               | 121                                                                                                                       |
| Five-year outlook.............................................................................................................           | 123                                                                                                                       |
| Critical minerals security assessment ..........................................................................                         | 123                                                                                                                       |
| Supply-side security.......................................................................................................              | 124                                                                                                                       |
| Exposure to economic and price risk                                                                                                      | ............................................................................. 125                                         |
| Regional                                                                                                                                 | co-operation....................................................................................................126       |
| Annex................................................................................................................................... | 127                                                                                                                       |
| Abbreviations and                                                                                                                        | acronyms..........................................................................................127                     |
| Units of measure............................................................................................................             | 128                                                                                                                       |

## Executive summary

As demonstrated by the energy crisis resulting from the current conflict in the  Middle  East,  the  energy  security  challenge  in  ASEAN  countries  is intensifying  as  they  experience  growing  energy  demand,  rising  import exposure and more interconnected energy systems. Rapid economic growth, industrial development, urbanisation and rising living standards are driving strong increases in energy demand across Southeast Asia, up by almost 30% per capita over the last 10 years. At the same time, the region's energy systems are more exposed to external fuel markets, strategic maritime routes, climate-related risks and the supply chains that underpin clean energy technologies. Energy security increasingly depends on the resilience of integrated systems, the ability to manage shocks and price volatility, and the capacity to align near-term security needs with longer-term transition objectives.

The region faces several interconnected risks. Oil demand continues to grow while regional crude production has fallen by 40% since its peak in the 1990s, increasing dependence on imported crude, which has risen by 30% since 2015, and refined products. Natural gas remains important for power generation and industry but rising LNG import needs expose several economies to regional and global gas market volatility and infrastructure constraints. Coal continues to support electricity security  and  industrial  activity  in  many  ASEAN  member  states,  and  transitions need to ensure adequate, affordable and reliable alternatives. Electricity systems face rising demand, the risk of fuel supply disruption, and increasing requirements for  flexibility  and  grid  investment  as  electrification  and  the  share  of  variable renewable  increases,  alongside  growing  climate-related  risks.  Critical  minerals and clean  energy  supply  chains  create  new  opportunities  for  ASEAN  but  also expose them to global supply-chain concentrations.

Looking  ahead,  these  challenges  are  likely  to  intensify.  Electricity  demand  in Southeast Asia is projected to expand at an average annual rate of around 5.4% during 2026-2030, driven by rising demand for cooling, data centres and industry. Coal demand is expected to continue growing at around 4.4% per year over the same period, the fastest increase of any region worldwide. Gas consumption in the region is projected to rise by more than 3% annually over the coming years. Finally, for the region's most import-dependent fuel, ASEAN net oil product imports are expected to increase by around 5% between 2025 and 2031. These trends point to a clear need for timely action.

While the energy security risks differ by country and fuel, they point to the need for  a  common  policy  agenda  centred  on  three  broad  reinforcing  strategies:

diversifying energy supply sources and routes, making greater use of domestically available energy resources; and accelerating electrification alongside efficiency improvements. A holistic systems-based approach is essential, recognising the growing interdependence between electricity, fuels and end-use sectors.

Regional co-operation is central to this agenda and the ASEAN Plan of Action for Energy  Cooperation  (APAEC)  2026-2030  provides  the  strategic  framework.  In addition, energy co-operation through the ASEAN Power Grid (APG), the ASEAN Memorandum of Understanding on the Trans-ASEAN Gas Pipeline Project and the ASEAN Framework Agreement on Petroleum Security (APSA) provides an important foundation for collective action. This review shows  that these agreements should be further operationalised and strengthened to bolster regional energy  security.  A  stronger  regional  approach  would  complement  national resilience  measures  by  helping  ASEAN  member  states  prepare  for  external energy market shocks, manage infrastructure and affordability risks, and share flexibility and emergency support across borders. The following recommendations capture the main actions needed to strengthen energy security across the ASEAN countries' fuels, technologies and enabling systems.

## Summary of key recommendations

| Area                                        | Key recommendation                                                                                                                                                                                                                                                                                                                          | Main security objective                                                                      |
|---------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------|
| Cross-cutting regional co-operation         | Further operationalise and strengthen ASEAN energy security mechanisms through stronger information sharing, market monitoring, emergency procedures, implementation follow-up and practical arrangements for regional support during disruption.                                                                                           | Strengthen collective preparedness and resilience to fuel, price and infrastructure shocks.  |
| Oil, petroleum products and liquid biofuels | Further operationalise APSA, strengthen the secretariat role of the ASEAN Centre for Energy (ACE), conduct regular regional emergency exercises, assess national stockholding, demand- side preparedness and sustainable liquid biofuel supply chains and strengthen emergency response measures.                                           | Reduce exposure to crude and product import disruption and improve crisis response capacity. |
| Natural gas and low-emissions gases         | Maintain economically viable domestic production, expand LNG import infrastructure where needed, improve pipeline connectivity and storage where appropriate, develop a co-ordinated gas emergency response mechanism under APSA, and support low-emissions gases.                                                                          | Improve gas supply availability, flexibility and resilience while avoiding overbuilding.     |
| Coal and solid biofuels                     | Maintain coal supply security where coal remains important, improve transparency and co-ordination of measures affecting regional trade, assess coal stockholding needs and opportunities for sustainably sourced modern solid biofuels, and develop transition roadmaps that account for adequacy, affordability and replacement capacity. | Preserve reliability while preparing credible and secure transition pathways.                |

| Area                                         | Key recommendation                                                                                                                                                                                                                                               | Main security objective                                                                                     |
|----------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------|
| Electricity and renewables                   | Update electricity security planning to integrate adequacy, flexibility, grids, climate resilience, fuel security and affordability; accelerate grid investment; and use the APG to share resources, reserves, flexibility and emergency support.                | Ensure reliable, affordable and resilient power systems as demand grows and the renewables share increases. |
| Energy efficiency and demand-side management | Strengthen regional harmonisation, targets, compliance, financing and data; expand efficiency measures in transport, buildings, appliances and industry; and unlock demand-side flexibility through smart meters, time-of-use pricing and aggregation platforms. | Reduce demand growth, import exposure and peak system stress while improving flexibility.                   |
| Critical minerals                            | Develop critical mineral strategies accounting for dependencies, focus on comparative strengths, increase regional co-operation on data sharing and standards, and diversify investment partnerships.                                                            | Capture more value from critical minerals while reducing exposure to global supply chains.                  |

## Recommendations by fuel and technology

Oil,  petroleum  products  and  liquid  biofuels. The  region's  oil  emergency preparedness  can  be  strengthened  by  further  operationalising APSA  and supporting the effective functioning of ACE as the APSA secretariat with guidance from ASEAN member states. A strengthened secretariat could support regular reviews of APSA procedures, enhance regional oil market monitoring and, subject to  member  states'  agreement,  facilitate  country-level  reviews  and  assist  with putting co-ordinated emergency response measures into operation. The secretariat could also establish a liquid biofuel taskforce to support regional supply chain  development,  identify  import  and  export  opportunities  between  member states for these fuels, and collectively set sustainability criteria for an integrated regional market. Regular capacity-building activities, including regional oil emergency response workshops and exercises, would help test APSA's strengths and limitations,  identify  gaps  in  national  preparedness  and  build  confidence  in cross-border co-operation during severe disruption.

At the national level, ASEAN member states can strengthen domestic oil resilience by building more robust stockholding policies, demand-side measures and clear crisis  procedures,  and  by  the  development  of  sustainable  liquid  biofuel  supply chains. Countries with domestic resources can consider how to increase domestic oil  production by adopting fiscal regimes that are predictable and supportive of investment. Member states with high import dependence could assess whether existing commercial inventories are sufficient for severe supply disruption and, where  needed,  develop  sustainable  financing  and  governance  models  for strategic petroleum reserves. Member states - particularly smaller or highly importdependent economies - could explore voluntary and commercially based regional stockholding  and  storage  arrangements,  to  complement  national  systems. Longer-term, countries could consider supporting the expansion and upgrading of

domestic  refining  capacity,  thereby  orienting  strategic  stockholding  measures towards crude oil. For LPG, however, dedicated additional strategic storage may be a more appropriate solution. Leading liquid biofuel-producing member states could  continue  increasing  sustainable  production  by  leveraging  commercial production pathways and developing new pathways to capitalise on non-traditional feedstocks.  More  nascent  markets  could  leverage  expertise  elsewhere  in  the region to develop a domestic industry and reduce import dependence.

Natural gas and low-emissions gases. Regional co-operation on gas security through  APSA  and  collaboration  with  international  partners  can  strengthen ASEAN  member  states'  gas  resilience.  A  dedicated  co-ordinated  emergency response mechanism  for natural gas under the Coordinated Emergency Response Measures framework of APSA could help clarify roles, procedures, data collection and market monitoring during crises. Regional gas market integration should  be  pursued  where  projects  have  a  positive  cost-benefit  case,  including through  infrastructure  that  improves  interconnectivity  and  interoperability  and allows ASEAN member states to share supply more effectively. Local biomethane production,  supported  through  targeted  policies,  incentives  and  experiencesharing, could improve the regional gas balance where it is developed sustainably and at scale.

ASEAN countries could strengthen gas supply availability, flexibility and resilience by maintaining economically viable domestic production, expanding LNG import infrastructure where needed, and, where appropriate, improving pipeline connectivity and developing gas storage capacity. However, investment decisions will need to account for uncertainty over future gas demand, the pace of clean energy deployment and the risk of overbuilding infrastructure. These investments will be increasingly important as several economies become more dependent on LNG imports and more exposed to global gas market shocks. National planning frameworks  can  benefit  from  considering  not  only  supply  volumes,  but  also contract flexibility, appropriate infrastructure redundancy, storage options and the ability of gas systems to respond during disruption.

Coal and modern solid biofuels. The role of coal differs significantly between ASEAN  member  states  depending  on  resource  endowment,  power  sector structure,  industrial  demand  and  net  zero  ambitions.  Overall  priorities  include strengthening  regional  co-operation  and  transparency  to  support  reliable  coal trade and minimise unintended regional impacts of domestic market interventions.

For member states that rely on coal for power generation or industry, their policy should focus on maintaining security of supply while preparing credible decarbonisation transition pathways. ASEAN member states that rely on coal for power  generation  can  evaluate  whether  coal  stockholding  requirements  are needed to strengthen power system resilience. Given the relatively low cost of coal  storage,  member  states  without  stockpiling  obligations  could  assess  the benefits of minimum inventories for coal-fired power plants. For ASEAN member

states  with  net  zero  commitments,  coal  transition  roadmaps  need  to  explicitly consider security of supply as well as decarbonisation considerations, including co-firing. These roadmaps should assess power system adequacy, the availability of replacement capacity, fuel switching to modern sustainable solid biofuels, grid readiness,  affordability and  the  economic  implications  of  early retirement, particularly in member states with young coal fleets.

Electricity  and  renewables. Electricity  security  should  evolve  to  reflect  the changing  risk  profile  of  power  systems.  Planning  frameworks  that  integrate resource adequacy, flexibility, grid development, climate resilience, fuel security and  affordability  are  better  positioned  to  identify  emerging  vulnerabilities.  As electricity  grids  are  central  to  enhancing  system  resilience,  grid  infrastructure should  be  expanded  and  modernised  to  keep  pace  with  demand  growth  and renewables  deployment,  while  being  more  resilient  to  the  effects  of  climate change.

Regional co-operation through the APG can complement national investment by enabling  ASEAN  member  states  to  share  renewable  resources,  reserves, flexibility and emergency support across a wider geographical area. Realising the electricity  security  benefits  of  the  APG  will  require  participating  countries  to introduce enabling domestic conditions and effective co-operation arrangements. The region's diverse renewable energy resource potential, including solar, wind, hydropower, geothermal and modern sustainable biomass, can support greater diversification of electricity supply while reducing exposure to imported fossil fuels. As  variable  renewables  expand,  key  measures  to  effectively  integrate  them include  flexible  power  plants,  enhanced  grid  capacity,  storage  deployment, demand-side  measures,  accurate  forecasting,  and  improved  system  operation practices and market frameworks. Alongside renewables, the potential of nuclear to contribute to energy security should be explored.

Demand-side  flexibility  should  become  a  standard  component  of  electricity security strategies. Better visibility and understanding of demand patterns, rooftop solar PV, behind-the-meter resources, cooling demand, electric vehicles and new large  loads  will  be  essential  as  electrification  accelerates.  Policies  and  market frameworks including tariffs, incentives, technical requirements and aggregation platforms should enable demand response and distributed resources to support system reliability, resilience and affordability.

Energy efficiency and demand-side management. Energy efficiency is often the most cost-effective means of strengthening energy security because it reduces energy  demand,  lowers  energy  expenditure,  and  reduces  the  need  for  energy infrastructure investment  and  fuel  imports.  ASEAN  can  strengthen  energy efficiency by enhancing regional co-operation on policy frameworks, target setting, updating  energy  efficiency  plans  and  improving  compliance  monitoring  and enforcement across all sectors. A co-ordinated regional framework that supports fuel  economy  standards  for  light-  and  heavy-duty  vehicles,  vehicle  labelling,

electric vehicle regulations and  interoperable charging  infrastructure could accelerate progress in transport efficiency. For appliances and buildings, ASEAN can further harmonise and strengthen minimum energy performance standards and  energy  labelling,  especially  for  air  conditioners,  refrigerators  and  lighting. Voluntary labelling and building certification schemes could progressively move towards mandatory approaches where appropriate, while building energy codes can be expanded in coverage and stringency.

ASEAN  countries  can  strengthen  industrial  energy  efficiency  through  energy management  programmes,  capacity  building  and  incentives  for  using  highefficiency technologies such as industrial motors. Demand-side flexibility, enabled by  measures  such  as  smart  meters  and  time-of-use  pricing,  can  reduce  peak demand, improve resilience and support more secure power systems. Greater transparency and more consistent data availability would support implementation and allow policy makers to track whether efficiency gains are reducing demand growth and import exposure. Sharing best practices on financing can help ASEAN member  states  improve  access  to  finance  for  projects,  replicate  successful approaches and scale up investment in cost-effective improvements.

Critical minerals. The main security question on critical minerals for the region is how  to  capture  more  value  from  them  while  reducing  the  risk  of  exposure  to concentrated global supply chains. Global processing remains highly concentrated, and recent export controls imposed outside the region have shown how quickly disruption can affect industries. These risks are especially relevant for ASEAN economies seeking to expand manufacturing and clean energy industries, since even  resource-rich countries can  depend  on  external  suppliers for equipment, technologies, and components. ASEAN member states thus need to manage  their  reliance  on  using  imported  technologies,  refined  materials  and specialised components. A more strategic approach could help ASEAN member states assess where domestic or regional capabilities can be developed, where diversification  is  needed,  and  where  partnerships  with  external  suppliers  will remain essential.

A more integrated ASEAN approach to critical minerals would combine national industrial policies with stronger regional co-operation. Priorities include improving geological data, developing shared standards, supporting responsible mining and processing, expanding recycling and circular economy measures, and identifying opportunities for regional value chains across mining, refining, manufacturing and end-use sectors. This would help ASEAN capture more economic value from its resource base  while strengthening resilience to supply disruptions, trade restrictions and external technology dependencies.

## Introduction: Energy security context, framework and overview

The strategic importance of Southeast Asia in the global energy landscape has been  steadily  growing  for  many  years,  and  the  trajectory  shows  no  signs  of reversing. The region is projected to account for nearly 20% of the increase in global energy demand to 2035 under today's policy settings. At the same time, recent  geopolitical  tensions,  including  the  conflict  in  the  Middle  East,  have highlighted Southeast Asia's exposure to energy imports and global energy price volatility.

Against this backdrop, this report - agreed under the ASEAN IEA Work Plan and prepared in co-ordination with ASEAN Centre for Energy (ACE) - is particularly timely as  governments  across  the  region  consider  policy  and  investment strategies amid the strong prioritisation of energy security.

Reflecting the growing  importance  of  Southeast  Asia  and  the  deepening partnership between the IEA and ASEAN, the IEA has significantly expanded its engagement across the region. This includes its co-operation with four ASEAN member states that are Association countries of the IEA: Indonesia, Singapore, Thailand  and  Viet Nam.  This  engagement  was  further  strengthened  with  the opening of the IEA Regional Co-operation Centre in Singapore in late 2024, the IEA's first office outside Paris.

## ASEAN regional energy profile

## Energy demand trends

Southeast Asia is one of the world's fastest-growing regions. Its GDP grew by nearly 5% in 2024 and is projected to rise by an average of 4% per year through to 2035, supported by the region's role as a global manufacturing hub.

As ASEAN economies have expanded, their total energy demand has risen by 40%  since  2015,  reflecting the region's growing  industrial, transport and household energy needs.

Industry is the largest end-use sector in Southeast Asia and has been the main driver of energy demand growth since 2015, supported by expanding manufacturing  activity,  non-energy-intensive  industries  and  non-ferrous  metal production. Transport has also been a major source of demand growth, particularly

for  oil,  with  rising  road  freight  activity,  higher  incomes,  limited  public  transport alternatives and growing vehicle ownership shaping mobility needs across ASEAN countries.  In  buildings,  rising  incomes,  urbanisation  and  expanding  access  to electricity and clean cooking have reshaped household energy demand.

Electricity demand has increased by more than 60% since 2015, driven by wider access, higher industrial consumption, urbanisation, and rising demand for cooling and other appliances. About 97% of households now have access to electricity, putting the region on track to achieve universal access by 2030. Over the coming decade, electricity demand is expected to grow faster than overall energy demand.

## Composition of the energy mix

Rising energy demand has driven major shifts in Southeast Asia's energy mix over the past decade. Between 2015 and 2025, total ASEAN energy demand increased by more than 40%, driven by strong economic growth and rising electricity demand. To meet this growing demand, energy supply expanded across all major fuel and energy sources. In 2025, coal and oil each accounted for around 30% of the total energy supply - 540 million tonnes of coal and roughly 9 mb/d of oil respectively while natural gas contributed close to one-fifth, corresponding to 200 bcm of gas. Bioenergy and waste accounted for around 12%, wind, solar and other renewables for  around  7%,  and  hydro  for  around  3%.  LPG  consumption,  which  has  grown strongly over the past decade, in particular in Cambodia and Indonesia, makes up about 5% of total final consumption in the region (around 300 mb of total annual consumption  in  2025).  Taken  together,  the  ASEAN  energy  mix  is  gradually diversifying, even as fossil fuels remain central to meeting demand.

## Energy supply by source in ASEAN, 2015 and 2025

<!-- image -->

Notes: PJ =petajoule. Data for Timor-Leste were not available.

Source: IEA (2026), World Energy Balances, accessed 1 August 2026. Data for 2025 include estimates.

Investment trends provide another indication of how the region's energy system is evolving. Fossil fuels accounted for 60% of total energy investment over the past decade, with coal receiving the largest share. Investment in coal-fired generation has increased steadily over the past two decades, bringing installed capacity to 121 GW  last  year.  However,  annual  clean  energy  investment  in  the  region increased from USD 30 billion to USD 47 billion over the last decade, with annual fossil fuel investment falling from USD 70 billion to USD 50 billion during the same period.

At the same time, Southeast Asia is becoming more important in clean energy supply chains. In 2023, Malaysia, Thailand and Viet Nam were the largest solar PV manufacturers after the People's Republic of China (hereafter, 'China'). The region also holds substantial critical mineral resources. Indonesia produces more than  60%  of  the  world's  nickel  and  attracted  over  USD 50 billion  of  greenfield mining investment between 2014 and 2023, more than 90% of the global total. Chinese  investment  has  been  central  to  the  expansion  of  Indonesia's  nickel refining  sector,  reaching  USD 30 billion  in  2024,  and  Chinese  companies  now account for around 75% of the country's refining capacity.

## Import dependency ratios

Import dependency in the ASEAN region differs markedly by fuel. While crude oil and  oil  products  remain  significant  sources  of  import  dependency  for  many ASEAN economies, natural gas and coal continue to exhibit regional net export positions, albeit with a wide variation between countries. These differences reflect variations in resource endowment, production capacity and energy consumption patterns  across  ASEAN  member  states.  This  section  provides  the  current backdrop for the fuel security assessments that follow.

Crude oil is a major source of import dependency in many ASEAN member states. Although Indonesia, Malaysia, Brunei Darussalam and Thailand remain exporters of crude oil, regional oil output has declined by around 40% since its peak in the 1990s. Since 2015, crude oil imports have risen by more than 30%, increasing exposure to international markets and external supply risks. Oil products present a  related  but  distinct  source  of  exposure.  Regional  refineries  meet  much  of Southeast Asia's refined product demand,  providing some  buffer against disruption  in  product  markets.  However,  this  downstream  resilience  remains constrained by reliance on imported crude as refinery feedstock, with around 45% of  refined  oil  products  derived  from  Middle  Eastern  crude.  This  dependence, compounded by relatively inflexible refineries configured to process medium and heavy  Gulf  crudes,  represents  a  structural  weakness  in  the  region's  energy system.

## Trade balances by fuel type in ASEAN, 2015-2025

<!-- image -->

## Natural gas trade

## Coal trade

<!-- image -->

IEA. CC BY 4.0.

Notes: All trade data include intra-regional trade. Data for oil and oil products for the year 2025 are based on estimates. Data for Timor-Leste were not available.

Source: IEA (2026), World Energy Balances, accessed 1 August 2026.

ASEAN remains a net gas exporter, but if current trends continue the region could become a net importer of gas by the end of the decade. Natural gas is largely supplied from within the region, with around 90% of demand met by production within ASEAN, mainly from Indonesia, Malaysia and Thailand. LNG accounts for more than 85% of the region's net gas export balance. However, LNG imports have increased steadily in recent years, reflecting growing import requirements in several ASEAN member states. Countries such as Indonesia and Malaysia both import and export LNG due to regional supply-demand mismatches, infrastructure constraints and long-term export commitments. As domestic production declines and import requirements grow, ASEAN's gas export surplus is expected to narrow, with the region becoming a net gas importer towards the end of the decade.

Coal presents a markedly different picture. ASEAN remains a net coal exporter, but  this  position  rests  heavily  on  Indonesia,  which  accounts  for  nearly  90%  of

regional  production  and  acts  as  a  key  balancing  supplier  in  international  coal markets. Despite this regional export position, several ASEAN member states, including the Philippines and Viet Nam, are increasingly reliant on imported coal (often from within the region) for their power sector needs, while limited regional coking coal resources make  imports critical for steelmaking and metals processing.

While these indicators provide a regional perspective on energy security, they can mask important differences between ASEAN member states. Resource endowments, infrastructure and fuel trade patterns vary considerably across the region,  meaning  that  national  energy  security  outcomes  may  differ  from  the regional picture. The indicators below therefore complement the regional analysis by highlighting these country-level differences.

Import dependency by ASEAN member state and fuel type, latest available year

| Country           | Crude oil   | Oil products   | Natural gas   | Coal   |
|-------------------|-------------|----------------|---------------|--------|
| Brunei Darussalam | 43%         | 0%             | 0%            | 100%   |
| Cambodia          | n/a         | 100%           | n/a           | 99%    |
| Indonesia         | 32%         | 36%            | 0%            | 0%     |
| Lao PDR           | n/a         | 100%           | n/a           | 0%     |
| Malaysia          | 25%         | 0%             | 15%           | 90%    |
| Myanmar           | 100%        | 97%            | 1%            | 2%     |
| Philippines       | 97%         | 78%            | 58%           | 62%    |
| Singapore         | 100%        | 0%             | 100%          | 100%   |
| Thailand          | 87%         | 0%             | 37%           | 60%    |
| Viet Nam          | 56%         | 42%            | 9%            | 55%    |

Notes: Import dependency = net imports ÷ supply, where net imports comprise both trade from within and outside ASEAN. n/a = not applicable (no domestic consumption). Calculations use 2025 annual data except for crude oil and oil products, which use 2024 annual data. Data for Timor-Leste were not available.

Recent disruptions to global energy markets, including the 2022 global energy crisis  caused  by  Russia's  full-scale  invasion  of  Ukraine  and  the  more  recent conflict in the Middle East, have brought the energy security implications of fuel import dependency to the forefront. Prior to the Middle East conflict, around 60% of  Southeast  Asia's  crude  oil  imports  and  one-third  of  its  natural  gas  imports originated from the Middle East. The resulting disruption to fuel markets exposed vulnerabilities linked to import dependency, limited diversification and concentrated  supply  routes,  contributing  to  higher  energy  prices,  inflationary pressures and broader economic risks across the region.

While  import  dependency  provides  a  useful  indication  of  exposure  to  external energy markets, fuel security outcomes also depend on factors such as supply diversification, infrastructure resilience, stockholding and the ability to respond to disruption. These broader considerations are examined further in the individual fuel and technology chapters of this review.

## Energy intensity and efficiency

Energy intensity and efficiency trends are important indicators of how effectively ASEAN economies use energy as demand continues to grow.

ASEAN's energy intensity has improved modestly, easing from around 3.15 GJ to an estimated 3.01 GJ per thousand USD between 2015 and 2025, but improving more slowly than the global average. At the same time, energy use per capita has continued to climb, from around 38 GJ to 49 GJ, reflecting rising demand across the region's economy.

## Primary energy intensity and annual improvement in ASEAN, 2010-2025e

<!-- image -->

IEA. CC BY 4.0.

Notes: Primary energy intensity = total energy supply ÷ GDP (USD 2021 PPP). PPP = purchasing power parity. Positive energy intensity progress reflects a reduction in energy intensity levels. Source: IEA (2026), Energy Efficiency Progress Tracker.

Against rising energy demand, energy efficiency has become a growing policy focus across ASEAN. Ten of the eleven ASEAN member states have established energy efficiency or energy savings targets extending to between 2030 and 2060, while under the ASEAN Plan of Action for Energy Cooperation (APAEC) 20262030, the region aims to achieve a 40% reduction in energy intensity based on total primary energy supply by 2030, compared with 2005.

While these targets set a common direction, progress varies across sectors. In industry, most  ASEAN  member  states  have  introduced  mandatory  energy management requirements,  audits  and  energy-saving  measures,  with  targeted incentives  such  as  tax  relief  for  efficient  machinery  in  Thailand  and  dedicated financing in Viet Nam. In transport, governments across the region are accelerating EV uptake, but progress in improving the efficiency of conventional vehicle fleets has been slower, with mandatory fuel economy standards for both light- and heavy-duty vehicles still largely absent. In buildings, energy codes that deliver  sector-wide  savings  are  in  place  across  most  ASEAN  member  states, although  there  remains  significant  scope  to  strengthen  implementation  and enforcement to unlock deeper efficiency gains.

Energy efficiency's role in strengthening resilience and reducing import exposure is examined further in the Energy efficiency and demand management chapter.

## Assessment framework and time horizon

Energy  security  needs  to  be  assessed  across  fuels,  technologies  and systems. Recent energy market disruptions have reinforced the importance of secure, affordable and sustainable energy supply, while also showing that energy security risks are becoming more interconnected. Traditional risks linked to fuel availability, import dependency, infrastructure adequacy and emergency preparedness  remain  central.  At  the  same  time,  new  risks  are  emerging  from electricity system transformation, growing dependence on critical minerals, clean energy supply chains, climate impacts and cyber resilience. This report therefore applies  a  common  framework  across  the  chapters,  while  recognising  that  not every dimension is equally relevant for every fuel or technology.

For the purposes of this review, energy security is understood to be the ability to ensure  the  uninterrupted  availability of energy  at  affordable prices, while maintaining the flexibility and resilience needed to manage shocks and longerterm  stresses.  The  framework  below  sets  out  the  main  factors  considered throughout the report. It should be read as a common reference point rather than a checklist applied mechanically to every chapter. The oil, gas and coal chapters use the framework most directly, while the electricity, critical minerals, and energy efficiency  and  demand-side management chapters apply it in ways that reflect their specific role in the wider energy system.

The framework considers five interconnected dimensions: supply-side security, demand-side readiness, exposure to economic and price risk, system resilience, and emergency planning. Together, these dimensions provide a structured lens for assessing ASEAN countries' exposure to fuel and technology risks, their ability to reduce or shift demand during stress periods, the affordability implications of energy  market  shocks,  the  resilience  of  infrastructure  and  systems,  and  the

preparedness of institutions to respond during crises. They are not meant as a measurement tool to assess the energy security situation quantitatively.

## Energy security assessment framework

## Supply-side security

## Demand-side security

## Can sufficient energy be physically delivered?

- · Resource endowment and production capacity
- · Import dependency
- · Diversity of supply sources and routes, chokepoints

## Can energy demand be reduced and shifted?

- · Energy efficiency
- · Electrification and fuel switching
- · Demand-side flexibility

## Exposure to economic and price risk

## Can energy be supplied at stable and affordable prices?

- · Contract coverage
- · Spot market dependence
- · Energy conservation measures
- · Infrastructure adequacy including storage

## System resilience

## Emergency preparedness

## Can the energy system absorb and recover from disruptions?

- · Strategic buffers and stocks
- · Infrastructure resilience
- · Climate and weather resilience
- · Cyber resilience

## Are institutions prepared to manage a crisis?

- · Emergency plans and procedures
- · Established governance mechanisms
- · Data quality and market monitoring capabilities
- · International cooperation and solidarity

IEA. CC BY 4.0.

The assessment focuses primarily on a five-year horizon. This timeframe is long enough to capture expected changes in demand, supply, infrastructure, investment and policy implementation, and short enough to remain relevant for current  government  mandates  and  near-term  regional  co-operation.  Where relevant, the report also refers to longer-term transition objectives, such as net zero  targets,  coal  retirement  plans,  clean  energy  supply  chains  and  strategic stockholding goals, but the main emphasis is on risks and policy options that can be addressed in the coming five years. The longer-term outlook to 2050 is covered in the IEA's Southeast Asia Energy Outlook 2026.

- · Exposure to price volatility

## Overview of chapters

The six thematic chapters that follow cover the main areas of the ASEAN energy system. The oil, gas and coal chapters follow a broadly similar structure: each starts with recent market developments and a five-year outlook, before assessing security risks related to supply, import dependency, infrastructure, price exposure, system  resilience  and  emergency  preparedness.  The  chapters  on  electricity, critical  minerals, and energy efficiency and demand-side management are less directly comparable, as each addresses a different part of the energy system and therefore applies the common energy security assessment framework in a more tailored way.

Oil  and  biofuels  security  review. This  chapter  examines  ASEAN  countries' growing oil demand, declining regional crude production and continued reliance on imported crude and refined products. It also reviews refining capacity, biofuels, five-year  supply-demand  trends,  oil  stockholding  arrangements,  demand-side response and the scope for stronger regional emergency preparedness.

Natural gas and low-emissions gases security review. This chapter assesses the role of natural gas in the ASEAN energy system, including gas demand and production, LNG and pipeline trade, low-emissions gases and the outlook to 2030. It  focuses  on  rising  LNG  import  needs,  exposure  to  global  gas  market  risks, infrastructure adequacy, demand-side flexibility, system resilience and emergency planning.

Coal and solid biofuels security review. This  chapter  reviews  coal demand, reserves, production, trade and infrastructure across ASEAN countries, highlighting  the  region's  overall  net  export  position  and  the  large  differences between ASEAN member states. It also considers the implications of coal use in power  generation  and  industry,  import  dependency  for  some  ASEAN  member states,  metallurgical  coal  exposure,  stockholding  practices  and  the  interaction between coal security and transition planning.

Electricity and renewables security review. This chapter examines electricity demand  and  supply  trends,  the  adequacy,  reliability  and  resilience  of  power systems,  and  the  security  implications  of  increased  electrification  and  rising shares  of  variable  renewables  and  distributed  resources.  It  considers  system flexibility, grid integration, affordability, climate resilience, supply chains for solar PV  and  wind,  and  the  role  of  regional  co-operation  through  power  system interconnections.

Energy efficiency and demand-side management. This chapter assesses how energy efficiency and demand-side measures can reduce energy security risks by lowering  demand  growth,  easing  import  dependency  and  improving  system flexibility. It reviews progress on energy intensity, policy frameworks and sector-

specific measures in buildings, appliances, transport and industry, as well as the emerging role of demand-side flexibility in electricity systems.

Critical minerals security review. This  chapter focuses on ASEAN countries' role  in  critical  mineral  supply  chains,  with  particular  attention  paid  to  resource endowments, mining and processing capacity, investment conditions and policy frameworks.  It  assesses  how  critical  minerals  can  contribute  to  economic development and clean energy supply chains, while also identifying risks related to  supply  concentration,  permitting,  infrastructure,  financing  and  environmental and social governance.

## Oil and biofuels security review

The IEA's World Energy Outlook 2025 highlighted the accelerating shift in global oil  demand  towards  Asia.  As  an  increasing  share  of  global  oil  consumption  is concentrated in Southeast Asia, the region is playing an increasingly influential role in shaping global energy markets.

This shift is a direct consequence  of  sustained  economic  growth,  rapid urbanisation and rising prosperity across the region, and also declining consumption in other regions of the world. Expanding middle classes are driving the surging demand for transport fuels, petrochemicals and electricity generation. This growth story brings with it a series of structural challenges that policy makers need to consider now so that they can develop pathways to strengthen security of supply while continuing to ensure prosperity for their citizens.

In common with many countries in Asia, ASEAN member states are net importers of  both  crude  oil  and  oil  products.  Moreover,  growing  import  dependency  is contributing to a widening gap between regional product supply and demand.

<!-- image -->

Consequently, disruptions to global oil and product markets can have significant implications for energy security in the region. Strengthening regional preparedness, including through closer co-operation on emergency planning and co-ordinated government and industry responses, can help enhance resilience to future supply shocks.

## Oil demand

ASEAN is a key region for global oil demand growth. During the decade to 2025, consumption  rose  by  an  average  of  1.7%  per  year,  almost  double  the  global average.  This  was  recorded  despite  an  almost  11%  drop  in  2020  due  to  the impacts  of  the  Covid-19  pandemic  on  international  travel,  tourism  and  trade. Strong  underlying  gains  across  the  product  mix  saw  Southeast  Asian  nations' share of world oil consumption rise from 6.2% in 2015 to 6.8% in 2025. The overall rise of 1.1 mb/d during the decade accounted for one-eighth of the total global increase. As Chinese demand growth has slowed in recent years, the importance of ASEAN countries has increased, accounting for one-sixth of the global increase between 2022 and 2025.

The  2026  Middle  East  conflict  has  added  headwinds  to  regional  oil  demand growth.  Demand  is  now  expected  to  decline  by  150 kb/d  in  2026,  or  2.1%, compared with pre-conflict expectations of growth of around 160 kb/d. Indicators of weaker consumption are already visible, including a 330 kb/d decline in regional demand in the second quarter of 2026 and a 10% drop in net product imports relative to an already weak baseline. Demand is projected to recover by 320 kb/d in 2027, although this would recoup only part of the growth lost in 2026.

The  medium-term  outlook  points  to  a  resumption  of  the  upward  trend  that prevailed over most of the previous decade. Average demand growth during 20252031 is expected to be 1.8%, or 130 kb/d, per year. Premium refined fuels are projected  to  account  for  more  than  80 kb/d  per  year  of  this  increase,  with  the majority of the growth in the form of middle distillates, notably diesel and jet fuel. Although  EV  penetration  is  gradually  increasing,  its  effect  on  transport  fuel demand is expected to emerge only progressively, leaving demand for middle distillates  supported  by  continued  growth  in  freight  and  aviation  activity.  The remaining 50 kb/d of the average annual increase is overwhelmingly in the form of petrochemical feedstocks, naphtha and LPG (which is also used extensively as a cooking fuel), and fuel oil for bunker demand, centred on Singapore.

Indonesia  remains  ASEAN's  largest  economy  and  oil  consumer,  with  demand approaching  2 mb/d.  It  is  also  expected  to  account  for  a  significant  share  of demand growth over the medium term, rising by an average of 70 kb/d between 2025 and 2031, equivalent to a compound growth rate of 3.3%. This increase is driven by gasoil and gasoline (up by a combined 50 kb/d per year), with a minor contribution from projected developments in petrochemical capacity. Viet Nam is also expected to make a substantial contribution to regional oil demand growth, with  higher  GDP  translating  into  a  3.7%  annual  growth  rate.  Driven  by  rising economies like these, ASEAN is expected to become the single largest regional

contributor to oil demand growth in the medium term. The rate of increase has slowed sharply  in  China,  and  Southeast  Asian  nations  are  also  set  to  exceed India's growth, despite having less than half its population.

<!-- image -->

## Crude and product supply

## Oil production

ASEAN  oil  production  has  been  on  a  downward  trajectory  for  more  than two decades, as investment has increasingly been geared towards natural gas in a region with predominantly mature oil basins. Every producer in the region, with the exception of Indonesia, is experiencing managed decline to varying degrees. The region's combined upstream output has dropped from 2.5 mb/d in 2015 to 1.8 mb/d  in  2025.  Production  is  forecast  to  fall  by  150 kb/d  from  1.8 mb/d  to 1.6 mb/d during 2025-2031, with Malaysia accounting for two-thirds of the drop.

After  nearly  three decades  of  sustained  decline,  Indonesia's  oil  production  is expected  to  return  to  growth  over  the  forecast  period.  Having  fallen  from approximately 820 kb/d in 2015 to 600 kb/d in 2025, output is projected to rise to around 730 kb/d by 2031, making Indonesia a notable exception among ASEAN producers. Almost half of this increase is expected to be driven by condensate volumes from Eni's Ganal Hub development in East Kalimantan, with further gains supported  by  upstream  fiscal  reforms,  enhanced  oil  recovery  optimisation  and continued  investment  commitments  from  operators  including  Petronas  and PetroChina.

Viet Nam has seen a number of new upstream developments, including the startup  of  the  KNT-KTN  (White  Whale)  and  the  Bach  Ho  (White  Tiger)  oilfields  by Vietsovpetro in 2025. Looking ahead, Murphy Oil's Lac Da Vang (Golden Camel) project is scheduled to begin operation in 2027. These projects are projected to partly  mitigate  declines  as  the  country's  output  falls  from  190 kb/d  to  170 kb/d through to 2031. Should Murphy Oil sanction the proposed Jai Su Vang (Golden Sea Lion) project, the country's output would remain broadly flat into the 2030s.

## Upstream oil production in ASEAN, 2015-2031

<!-- image -->

IEA. CC BY 4.0

Note: mb/d = million barrels per day.

## Refining capacity and throughput

ASEAN refining capacity stands at around 5.5 mb/d, with crude and condensate processing averaging about 4.1 mb/d in 2026. The region remains a net importer of both crude and refined products, while refinery utilisation remains relatively low, reflecting reliability issues at older plants and ongoing modernisation work.

Refining capacity has increased by around 10% since 2015, supported by new crude-to-chemicals  refineries  and  expansion  projects  in  Brunei Darussalam, Malaysia, and Viet Nam. These additions have more than offset closures of older capacity,  but  the  sector  continues  to  face  competitive  pressure  from  exportoriented refining centres in the Middle East and China.

Recent capacity growth has strengthened the region's downstream position, but it has  also  reinforced  the  importance  of  crude  supply  security.  Several  major refineries are highly integrated with petrochemicals and designed around specific crude slates, leaving parts of the system exposed to disruption affecting Middle Eastern supply routes.

Further capacity additions to 2031 are expected to be limited. Investment is likely to focus mainly on improving reliability, increasing light product yields, integrating petrochemicals  and  biofuels,  and  strengthening  logistics,  rather  than  on  largescale expansion of crude distillation capacity.

## Liquid biofuels

Liquid biofuel demand in ASEAN has expanded rapidly as member states seek to reduce fossil fuel imports while increasing the share of renewable energy in the transport sector. Since 2010, demand has increased more than twelvefold from just over 25 kb/d to more than 360 kb/d in 2025. Biodiesel accounts for 85% of this growth, ethanol for 10%, and renewable diesel, 1  marine biodiesel and biojet fuel 2 for the remaining 5%.

## Liquid biofuel demand in ASEAN, 2010-2025

<!-- image -->

IEA. CC BY 4.0

Note: kb/d = thousand barrels per day. Data for Brunei Darussalam, Cambodia, Laos and Timor-Leste were not available. Source: IEA (forthcoming), Renewables 2026.

Regionally,  Indonesia  accounts  for  the  bulk  of  ASEAN  liquid  biofuel  demand growth, contributing around 75% of the increase since 2010. This reflects the rapid strengthening of its biodiesel mandate, which rose from 1% in 2009 to 35% in 2023. Thailand and Malaysia together account for a further 20% of regional growth,

1 Biodiesel and renewable diesel can reduce greenhouse gas emissions when produced sustainably, but they differ in their production  processes  and  fuel  properties.  Biodiesel  is  produced  using  a  process  known  as  transesterification,  where feedstocks such as vegetable oils and waste oils react with alcohols in the presence of a catalyst to produce a fuel that is typically  blended in limited quantities with conventional diesel. Renewable diesel is produced using a process known as hydrotreatment, where similar feedstocks react with hydrogen at high temperatures to produce a fuel that is chemically similar to petroleum diesel and can be used as a direct replacement.

2 Biojet fuel is a sustainable aviation fuel (SAF) produced primarily from biomass feedstocks. SAF can also be produced from low-emissions hydrogen and carbon dioxide (e.g. synthetic fuels). This report only includes SAF produced from biomass (e.g. biojet fuel).

also largely supported by biodiesel blending requirements. Thailand introduced a 5% mandate in 2012 and increased it to 7% by 2024, while Malaysia moved from a 7% mandate in 2019 to 10% by 2025. The remaining growth comes from the Philippines, where ethanol and biodiesel mandates support demand, Singapore, where  marine  biodiesel  production  has  expanded  to  serve  shipping  between Europe  and  the  Asia  Pacific  region,  and  Viet Nam  with  an  ethanol  blending mandate.

Rising  liquid  biofuel  consumption  has  helped  several  ASEAN  member  states reduce exposure to imported fossil fuels. I n 2025, ethanol displaced around 10% of gasoline demand in Thailand, while biodiesel reduced diesel import dependency  by  around  5%  in  Thailand,  10%  in  Malaysia  and  up  to  35%  in Indonesia.

Change in  fuel  import  dependency  from  blending  liquid  biofuels  in  selected  ASEAN member states, 2025

<!-- image -->

Notes: Import dependency is calculated as total net imports of oil products (gasoline and diesel), net imports of crude for domestically refined oil products, net imports of biofuels (ethanol, biodiesel and renewable diesel) and net imports of biofuel feedstocks  for  domestically  produced  biofuels,  divided  by  the  total  consumption  of  oil  products  and  biofuels.  The counterfactual scenario assumes that all biofuel consumption in the given year is directly replaced with imported oil products. Source: IEA (forthcoming), Renewables 2026; IEA (2025), Oil 2025.

Liquid biofuel demand in ASEAN countries is projected to increase by 50% by 2030, increasing from more than 360 kb/d in 2025 to over 550 kb/d in 2030. This expansion is supported by stronger transport fuel mandates, rising fuel demand and  efforts  to  reduce  fossil  fuel  import  exposure.  Biodiesel  remains  the  main source of additional demand, accounting for around 75% of regional growth to 2030, while ethanol and renewable diesel each contribute around 10%. Biojet fuel accounts for most of the remainder, supported by emerging domestic sustainable

aviation  fuel  (SAF)  mandates  and  future  compliance  with  International  Civil Aviation  Organization  (ICAO)  Carbon  Offsetting  and  Reduction  Scheme  for International Aviation (CORSIA).

## Forecast liquid biofuel demand in ASEAN, 2025-2030

<!-- image -->

2025

Indonesia

Philipines

Growth

Malaysia

Singapore

2030

Thailand

Viet Nam

IEA. CC BY 4.0

Note: kb/d = thousand barrels per day. Data for Brunei Darussalam, Cambodia, Laos and Timor-Leste were not available. Source: IEA (forthcoming), Renewables 2026.

Indonesia again leads regional growth, accounting for more than three-quarters of the  increase  by  2030.  This  reflects  the  continued  implementation  of  its  B40 biodiesel  mandate  amid  overall  increases  in  demand  for  diesel,  with  further progress towards B50 limited by current production capacity. Growth in Indonesia is also supported by some progress towards domestic blending targets of 10% ethanol and renewable diesel by 2028, as well as a 2.5% SAF target by 2030. Malaysia and Thailand contribute an additional 15% to regional growth, supported by  continuing,  and  higher,  blending  mandates  for  biodiesel  in  both  countries alongside the introduction of a 1% SAF mandate in Malaysia beginning in 2027. The remainder of the increase is from the Philippines, supported by rising transport fuel demand and existing mandates; Viet Nam, where consumers can no longer buy  unblended  gasoline  and  must  purchase  E5  or  E10  blends  amid  higher gasoline prices linked to the Middle East conflict; and Singapore, where marine biodiesel expands for Europe-bound shipping under FuelEU Maritime, alongside a domestic 3-5% SAF blending mandate by 2030.

This  growth  can  help  further  increase  the  share  of  renewable  energy  in  the transport  sector  while  reducing  reliance  on  imported  fossil  fuels;  however, sustainability  remains  the  foundation  for  continued  growth.  This  makes  robust sustainability frameworks essential to ensure that rising demand delivers verified emissions reductions and improves energy security without adverse impacts on land, water or biodiversity.

750

500

250

0

## Five-year outlook and implications

Notwithstanding the upstream and downstream projects noted above, ASEAN is expected  to  remain  a  net  importer  of  both  crude  oil  and  oil  products.  This underscores the energy security challenge that governments in the region face. Crude imports are expected to dip in 2026, reflecting lower shipments from the Middle East. Over the medium term, import needs are expected to rebound to almost 3 mb/d as declining regional output contrasts with the ongoing increase in crude processing and product demand.

<!-- image -->

ASEAN net product imports are set to increase by around 5% between 2025 and 2031, to 2.2 mb/d. The 2026 Middle East conflict temporarily curtailed product imports  during  the  first  half  of  2026  and  reduced  product  stocks,  tightening markets and supporting product cracks and refining margins. The normalisation of product trade should start to accelerate in the second half of 2026 and provide governments  with  an  opportunity  to  restore  and/or  build  strategic  crude  and product  stocks.  However,  the  positive  long-term  trend  in  demand  growth  will necessitate ever greater imports across all product categories, from LPG to light and middle distillates, as well as fuel oil.

ASEAN countries' net imports of LPG have increased by 50% since the start of the  decade  and  more  than  doubled  over  the  past  ten  years  to  500 kb/d.  The combination of dwindling regional natural gas liquids (NGL) production and strong demand growth will continue to present a particular challenge because refineries

themselves  produce  only  a  small  amount  of  LPG  as  a  share  of  total  output. Moreover,  exports  from  the  Middle  East  still  constitute  nearly  50%  of  import volumes in 2026, notwithstanding the increase in cargoes from the United States in  recent  years.  Consequently,  with  limited  alternative  supply  options,  careful consideration should be given to how best to improve importing nations' energy security for these niche fuels.

<!-- image -->

The global oil market is forecast to see a rebound in Middle Eastern production and exports during 2027. Consequently, oil market balances are expected to flip from  undersupplied  in  Q4  2026  to  oversupplied  by  Q1  2027,  with  the  surplus continuing  throughout  next  year.  Consequently,  ASEAN  national  governments have an opportunity to establish or expand government-held stocks of crude and products and absorb part of the surplus.

## Oil security assessment

Oil security risks in ASEAN are being driven by rising demand, declining regional crude production, growing dependence on imported crude and refined products, and exposure to maritime choke points. The detailed oil market context is covered in the preceding market analysis. This assessment therefore focuses on the main energy security dimensions used across this report: supply-side security, demandside  readiness,  exposure  to  economic  and  price  risk,  system  resilience  and emergency preparedness.

## Supply-side security

ASEAN's supply-side security exposure is concentrated in three areas: dependence on imported crude and products, reliance on a limited number of external suppliers, and the risk associated with the use of two of the world's main choke points: the Strait of Hormuz and Strait of Malacca. As mentioned previously, most ASEAN economies face increasing exposure to external supply disruptions.

## Crude oil balance for selected ASEAN member states, 2024

Note: kb/d = thousand barrels per day.

<!-- image -->

Regional refining capacity provides an important but incomplete buffer. Approximately 89% of product demand is met by refineries located in Southeast Asia, but many of these refineries depend on imported crude, much of it from the Middle East. While refining capacity reduces exposure to disruptions in international  product  markets, countries with limited domestic crude production remain exposed to risks affecting crude imports, including disruptions to shipping routes, facilities and systems used to receive and transport imports, and supplies of suitable crude grades. Increasing diversification of crude supply sources and transport routes can help mitigate some of these vulnerabilities.

## Refinery output and demand for selected ASEAN member states, 2024

Note: kb/d = thousand barrels per day.

<!-- image -->

This  exposure  is  amplified  by  the  concentration  of  maritime  trade  through  two choke  points.  The  Strait  of  Hormuz  remains  the  critical  exit  route  for  Middle Eastern crude, while the Strait of Malacca is the main corridor for oil flows into East and Southeast Asia. Disruption affecting either route would have immediate implications for regional crude and product supply, especially for ASEAN member states with limited refining capacity or commercial storage.

Recent  supply  disruptions  in  the  Middle  East  rapidly  translated  into  price increases,  logistical  constraints  and  concerns  over  the  availability  of  certain refined products across ASEAN economies. These impacts also have implications for factors directly relevant to governments, such as GDP and inflation. The crisis underlined that many national systems are designed for continuity under normal market conditions, but have more limited tools for managing severe international supply disruption. In response, some ASEAN countries are considering additional investment in refining and storage infrastructure, including Cambodia's recently announced  plans  to  develop  its  first  oil  refinery.  Next  to  this,  ASEAN  could consider supporting liquid biofuel developments in the region by setting up a joint liquid biofuels taskforce.

## Demand-side readiness

Demand-side  readiness  is  important  because  oil  use  in  ASEAN  countries  is concentrated in the transport sector, where short-term alternatives remain limited. In several  ASEAN  member  states,  including  Indonesia  and  Malaysia,  fuel subsidies  and  administered  pricing  mechanisms  have  historically  played  an important role in shielding consumers from international oil price fluctuations. More

broadly, fuel subsidies, price stabilisation mechanisms and regulated fuel prices remain common across the region. While these measures can support affordability and social stability, they may also weaken incentives to reduce consumption in response to higher prices,  resulting  in  demand  remaining  higher  than  it  would under fully market-based pricing.

Recent  supply  disruptions  have  demonstrated  that  governments  can  reduce demand at the margin through measures such as teleworking, public conservation campaigns, carpooling, reduced travel and fuel purchase restrictions. However, these measures were generally introduced nationally rather than in a regionally co-ordinated  manner,  which  could  in  some  cases  enhance  their  effectiveness. This lack of explicit cross-border co-ordination means that certain measures may fail to fully achieve their intended outcome; for instance, a price freeze introduced in one country can stimulate 'tank tourism', thereby intensifying market tightness in neighbouring states.

For example, Myanmar adopted a targeted approach of an even-odd licence plate system, restricting road traffic on alternating days, which cut transport demand. Fuel  rationing  and  fuel  purchase  restrictions  were  introduced  in  some  ASEAN member states, including Myanmar and Viet Nam, reflecting the severity of supply pressures.  Lao PDR introduced a temporary three-day school week as part of broader measures to manage the impacts of fuel supply constraints and several ASEAN  member  states,  including  Cambodia,  the  Philippines  and  Thailand, introduced  air  conditioning  limits,  reflecting  its  significance  as  a  source  of electricity demand in tropical climates.

Over the longer term, fuel efficiency, the availability of integrated, modern and affordable public transport, the electrification of two- and three-wheelers, targeted modal shift and sustainable biofuel blending can help reduce exposure to oil import disruption.

## Exposure to economic and price risk

ASEAN's growing oil import dependency increases exposure to international price volatility, import  bills  and  fiscal  pressures.  Price  spikes  affect  households, businesses and public budgets, especially where transport fuels remain heavily used and fuel subsidies or price controls are deployed to shield consumers. These effects also ripple across the wider economy: higher jet fuel costs push up airfares, natural  gas  and  feedstock  price  increases  can  strain  fertiliser  production  and availability,  and  LPG  shortages  affect  household  cooking  and  heating  costs, compounding inflationary pressure across multiple sectors.

During recent oil market disruptions, several ASEAN member states introduced or expanded  fuel  subsidies,  tax  reductions,  price  caps  and  targeted  support  for

transport users. These measures can provide short-term relief, but may weaken fiscal space and reduce incentives for demand adjustment if they are broad-based or prolonged.

Unilateral  export  restrictions  can  also  increase  regional  price  and  supply  risks. Measures taken to protect domestic consumers may be understandable during a crisis,  but  they  can  disrupt  supply  chains  for  neighbouring  import-dependent economies. This points to the need for clearer regional arrangements that balance national emergency actions with collective resilience.

## Selected demand-side and consumer support measures in ASEAN member states

IEA. CC BY 4.0.

<!-- image -->

## Oil stockholding as a resilience tool

Oil  stocks  remain  the  primary  tool  for  managing  physical  supply  disruption because  they  can  be  released  rapidly  to  add  liquidity  to  an  increasingly  tight market,  sustaining  economic  activity  without  requiring  immediate  changes  to consumption  behaviour.  Demand-side  measures,  while  undoubtedly  useful  in constraining consumption, carry the risk of curbing economic activity itself, with wider negative effects across the economy.

As such,  demand-side  measures  are  best  reserved  for  situations  of  sustained scarcity or prolonged disruption that can no longer be effectively managed through stock releases alone, whereas stock releases offer a supply-side response that buys  time  and  preserves  economic  continuity  in  the  short  term.  Stockholding systems  vary  widely  between  ASEAN  countries,  and  most  rely  primarily  on commercial or industry-held inventories rather than dedicated emergency buffers.

These commercial inventories are indispensable in ensuring continuity of supply and provide a robust first layer of protection, but in many cases, even if they are ample, they are designed more for normal market operations and a relatively small disruption, struggling to shield the economy  from  severe  and  prolonged international supply disruption.

The ASEAN Framework Agreement on Petroleum Security (APSA) provides an important  regional  foundation  for  oil  emergency  co-operation,  recognising  the value of co-ordinated response and oil stockpiling. However, full operationalisation remains a challenge. Owing to the uneven levels of stockholding capacity across member  states,  regional  co-operation  -  whereby  countries  voluntarily  provide additional supply to a state facing an oil shortfall ('a member state in distress') remains an ambition that is difficult to currently realise.

## APSA

APSA is the ASEAN Framework Agreement on Petroleum Security, signed on 16 October  2025  in  Kuala  Lumpur,  which  renews  and  replaces  the  2009  ASEAN Petroleum Security Agreement, and exists to enhance member states' collective petroleum security amid ASEAN's growing status as a net oil (and soon natural gas)  importer.  The  APSA  is  ASEAN's  key  voluntary  regional  mechanism  for strengthening  preparedness  and  coordinated  responses  to  petroleum  supply disruptions. It establishes short-term co ordinated emergency response measures (CERM), including a commitment for member states to supply petroleum equal to 10%  of  a  distressed  state's  normal  domestic  requirement  during  a  "critical shortage"  (at  least  a  10%  shortfall  lasting  30+  days),  all  on  a  voluntary  and commercial  basis,  alongside  medium-  and  long-term  measures  like  resource exploration, supply diversification, energy efficiency, market liberalisation and oil stockpiling. Governance is assigned to the ASEAN Ministers on Energy (AMEM) as  the  main  policy  body,  supported  by  the  Senior  Officials  Meeting  on  Energy (SOME), the ASEAN Centre for Energy as secretariat, and ASCOPE for technical advice, with the agreement entering into force 90 days after the tenth ratification and remaining valid for ten years

The development of dedicated strategic petroleum reserves remains at different stages across the region. Viet Nam has the clearest long-term objective, while Indonesia,  the  Philippines,  Cambodia,  Malaysia,  Thailand,  Myanmar,  Lao PDR and  Timor-Leste  are  considering,  studying  or  gradually  developing  additional storage and reserve arrangements. For many ASEAN member states, the main challenge  is  to  design  systems  that  are  affordable,  enforceable  and  suited  to national market structures.

## Stockholding models

International experience points to several possible models, including governmentheld  stocks,  industry  obligations,  central  stockholding  agencies  and  hybrid arrangements. Government stocks are those owned directly by the state, typically financed  through  the  central  government  budget  and  held  exclusively  for emergency purposes. Agency stocks are stocks held by a separate agency, either on  behalf  of  the  government  or  domestic  industry.  The  agency  structure  and arrangements  vary  from  country  to  country  and  can  range  from  governmentsponsored schemes to industry-created initiatives,  but  in  all  cases  compulsory stocks cannot be released without government approval. Government and agency stocks are commonly referred to as 'public stocks'. Obligated industry stocks are stocks held by industry in order to meet minimum stockholding requirements set by government. Typically, these are requirements placed on certain companies (e.g. importers, refiners, wholesalers) to hold a minimum level of stocks based on their share of imports or sales in the domestic market.

The appropriate model for ASEAN economies will depend on import dependency, domestic production, refining capacity, storage infrastructure, fiscal resources and market structure, but will also vary according to each country's appetite for building these stocks. Regional or shared storage arrangements may also be relevant in the ASEAN region and may also better suit smaller economies.

The table below illustrates selected international stockholding models that could inform ASEAN policy design, while recognising that the most appropriate model should be shaped by national circumstances and regional co-operation priorities.

## Table of selected IEA countries' stockholding models

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| IEA country   | Public stocks   | Industry obligation                                                                                                                                                                              | Note on emergency oil stockholding regime   |
|---------------|-----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------|
|               |                 | Industry-based stockholding agency (EBV) required to hold 90 days of net imports; all oil producers and importers are obliged to be members of EBV and pay fees according to their market share. | Germany                                     |
|               |                 | Government agency, NORA, responsible for ensuring Ireland's 90-day requirement.                                                                                                                  | Ireland                                     |
|               |                 | to hold 70 days of their average daily imports, sales or production in the previous 12 months. Additionally, industry holds mandatory LPG stocks of 40 days of consumption.                      | Japan                                       |
|               |                 | 40 days of previous year's sales. Additionally, industry holds mandatory 30 days of LPG stocks and 15 days of naphtha stocks. Government agency, KNOC, holds government                          | Korea                                       |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| IEA country    | Public stocks   | Industry obligation                                                                                                                                                                                                                                                                                                | Note on emergency oil stockholding regime                                                                                                                                                                                                                                                                               |
|----------------|-----------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                |                 | Oil refiners and traders have an obligation to hold 12% of their sales above 100 kt in previous year. Industry covers about 20% of the national 90-day stockholding requirement (based on inland consumption in previous year), while government stockholding agency (COVA) is required to hold the remaining 80%. | Netherlands                                                                                                                                                                                                                                                                                                             |
| Spain          |                 |                                                                                                                                                                                                                                                                                                                    | Industry has an obligation to hold 50 days of previous year's imports and additional mandatory industry LPG stocks of 20 days of previous year's sales. Stockholding agency, CORES, holds remainder to reach 92 days.                                                                                                   |
| Türkiye        |                 |                                                                                                                                                                                                                                                                                                                    | Refineries are obliged to hold at least 20 days of oil stocks, and each fuel and LPG distribution licensee is obliged to hold at least 20 days of product stocks, based on average daily sales of the previous year. The refineries must hold the difference to reach the total of 90 days on behalf of the government. |
| United Kingdom |                 |                                                                                                                                                                                                                                                                                                                    | Refiners are obligated to hold 67.5 days of supply, while importing companies must hold stocks equivalent to 58 days.                                                                                                                                                                                                   |
| United States  |                 | The US has total of 60                                                                                                                                                                                                                                                                                             | government Strategic Petroleum Reserve (SPR) design storage capacity of 713.5 mb over four underground storage sites in Texas and Louisiana with a operational caverns.                                                                                                                                                 |

The establishment of strategic stocks need not constitute a major additional fiscal burden for governments, provided that appropriate institutional and cost-recovery mechanisms are put in place.  For  ASEAN  member states  the  key  question  is therefore not only whether to hold strategic stocks, which is a strategic choice to be  taken  by  each  nation,  but  also  how  to  design  financing  and  governance arrangements that make stockholding both affordable and sustainable over the long term.

A key initial consideration in establishing emergency oil stocks is to determine who will hold  the  stocks  and,  therefore,  who  will  carry  the  legal,  financial  and operational  responsibility  for  them.  If  stocks  are  to  be  held  by  a  central stockholding entity,  its  legal  status  should  be  clearly  defined,  preferably  as  an independent, purpose-made legal entity able to purchase stocks, contract storage services, hold assets on its balance sheet and act as the contractual counterpart to  industry.  Financing  arrangements  will  depend  on  the  chosen  stockholding model:  costs  may  be  recovered  through  a  small  levy  or  stockholding  fee incorporated  into  retail  prices,  financed  directly  through  government  loans  or bonds, or treated as debt whose interest and related carrying costs are recovered over time through fees, including at the pump. Where costs are recovered through levies  or  stockholding  fees,  the  financial  burden  is  shifted  from  the  general government  budget  to  fuel  consumers  and  market  participants,  rather  than

taxpayers more broadly, creating a direct link between the funding of the system and  petroleum  consumption.  Equally  important  is the establishment  of a transparent and rules-based release mechanism that defines when, how and by whom stocks may be released. This mechanism should ensure that emergency stocks are used for the benefit of the whole population, are insulated from shortterm political  decisions  and  are  released  only  in  response  to  genuine  physical supply disruptions.

## Overview of how emergency oil stocks are financed in IEA member countries

| IEA country   | Obligated industry stocks financed by companies   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   |
|---------------|---------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|
|               | Initial set- up costs                             | Initial set-up costs                                   | Initial set-up costs                                   | Initial set-up costs                                   | Running costs                                          | Running costs                                          | Running costs                                          |
|               |                                                   | Government budget                                      | Government- backed loan                                | Bank loans/ bonds                                      | Government budget                                      | Levy on industry                                       | Tax                                                    |
| Australia     |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Austria       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Belgium       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Canada        |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Czechia       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Denmark       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Estonia       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Finland       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| France        |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Germany       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Greece        |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Hungary       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Ireland       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Italy         |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Japan         |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Korea         |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Latvia        |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Lithuania     |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Luxembourg    |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| IEA country    | Obligated industry stocks financed by companies   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   | Public (government/agency) stocks: financing methods   |
|----------------|---------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|--------------------------------------------------------|
|                | Initial set- up costs                             | Initial set-up costs                                   | Initial set-up costs                                   | Initial set-up costs                                   | Running costs                                          | Running costs                                          | Running costs                                          |
|                |                                                   | Government budget                                      | Government- backed loan                                | Bank loans/ bonds                                      | Government budget                                      | Levy on industry                                       | Tax                                                    |
| Mexico         |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Netherlands    |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Norway         |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| New Zealand    |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Poland         |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Portugal       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Slovakia       |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Spain          |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Sweden         |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Switzerland    |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| Türkiye        |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| United Kingdom |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |
| United States  |                                                   |                                                        |                                                        |                                                        |                                                        |                                                        |                                                        |

## Regional co-operation

Interest in strategic petroleum reserves is likely to increase as ASEAN's import dependency grows, oil supply routes remain exposed to geopolitical disruption, and petroleum products continue to play an important role in transport, aviation, shipping and petrochemicals.

ASEAN has established a valuable framework for regional co-operation through APSA. Building on APSA's provisions for consultation, information exchange and co-operation during petroleum supply disruptions, further progress could focus on strengthening  information-sharing  arrangements,  especially  data  transparency, enhancing preparedness activities including through workshops and exercises, and  improving  understanding  of  how  ASEAN  member  states  could  voluntarily co-ordinate their responses and provide each other with assistance during severe supply disruptions.

The main challenges faced by countries in the region are financing, governance and infrastructure development, but also the establishment of practical

<!-- image -->

<!-- image -->

<!-- image -->

arrangements for regional co-operation during emergencies. Strategic reserves require  upfront  investment,  clear  rules  on  ownership  and  release,  sufficient storage and logistics capacity, and an understanding of how voluntary regional co-operation and mutual assistance could operate during a disruption, considering national circumstances, commercial arrangements and individual energy security priorities.

ASEAN  member  states  have  made  some  progress  through  the  imposition  of mandatory  industry  obligations and  the  development  of  some  emergency response mechanisms. Building on these efforts, continued investment in storage infrastructure, strengthened governance frameworks and deeper regional co-operation  can  further  support  the  development  of  robust  and  resilient  oil security  arrangements.  While  approaches  will  differ  between  ASEAN  member states,  effective  emergency  response  and  stockholding  mechanisms  will  be central to ASEAN's oil security strategy.

## Overview of oil stockholding in ASEAN member states

|                   | Strategic petroleum reserve                                         | Private mandatory stocks                                                                                                                                                                     | Target                                                                                                                                                                                                                               |
|-------------------|---------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Brunei Darussalam | No                                                                  | Minimum of 50% of each producer's/importer's existing storage capacity                                                                                                                       | N/A                                                                                                                                                                                                                                  |
| Cambodia          | No Currently conducting feasibility study on SPR                    | 30 days based on total selling volume                                                                                                                                                        | Considering expanding private mandatory stocks and building an SPR for crude                                                                                                                                                         |
| Indonesia         | Yes, but not implemented yet Fuel storage capacity: maximum 25 days | 20-23 days                                                                                                                                                                                   | Aim to expand reserves up to three months. SPR: By 2035, 9.64 mb of gasoline and 10.17 mb of crude                                                                                                                                   |
| Lao PDR           | No                                                                  | N/A                                                                                                                                                                                          | N/A                                                                                                                                                                                                                                  |
| Malaysia          | No Currently conducting feasibility study on SPR                    | N/A                                                                                                                                                                                          | Considering building a SPR                                                                                                                                                                                                           |
| Myanmar           | Yes Storage capacity for 60 days of emergency stock                 | No                                                                                                                                                                                           | 30 days by 2020 45 days by 2045 90 days by 2050                                                                                                                                                                                      |
| Philippines       | Currently planning to build a SPR                                   | Inventory policy requires refiners to hold 30 days' worth of crude and products, importers/bulk suppliers to hold 15 days' worth of products, and LPG importers to hold 7 days' worth of LPG | Proposed law (not yet enacted) to build an SPR covering at least 90 days of national consumption on 26 March 2026 Increasing minimum inventory requirements for petroleum products from 15 to 30 days and for LPG from 7 to 21 days. |

|              | Strategic petroleum reserve           | Private mandatory stocks                                                                             | Target                                          |
|--------------|---------------------------------------|------------------------------------------------------------------------------------------------------|-------------------------------------------------|
|              | No                                    | Power generation companies are required to maintain diesel reserves as a backup to natural gas       | Singapore No                                    |
| Thailand     | No Completed feasibility study on SPR | 25 days                                                                                              | N/A                                             |
| Timor- Leste | No                                    | 15 days                                                                                              | Plans to build SPR for fuel                     |
| Viet         | Yes                                   | 20 days for key traders/ producing wholesalers with distribution systems and 5 days for distributors | Nam after 2030 National reserve infrastructure: |

Notes: mb = million barrels; N/A = not applicable; SPR = strategic petroleum reserve.

Source: IEA analysis based on government sources, ACE, and ERIA.

## A path forward

The Middle East crisis of 2026 has highlighted both the challenges associated with the  ASEAN  region's  growing  import  dependency  and  reliance  on  vulnerable maritime  choke  points,  and  the  opportunities  to  further  strengthen  regional co-operation and  preparedness.  It has underscored  the value of shared frameworks,  strengthened  national  preparedness  and  co-ordinated  regional response arrangements, as appropriate.

ASEAN already has an important foundation for co-operation through mechanisms such as APSA, which can continue to evolve in line with the region's changing energy security needs. Looking ahead, the post-crisis period presents an  opportunity  to  strengthen  the  implementation  of  existing  ASEAN  energy security  mechanisms,  including  APSA,  and  to  further  enhance  co-ordination, information sharing and preparedness arrangements. Continued efforts to clarify practical procedures for co-operation and mutual support during severe disruption could help improve the effectiveness of the regional response.

Once the  immediate  impacts  of  the  crisis  recede,  there  may  also  be  value  in reviewing  the  effectiveness  of  different  policy  responses,  including  measures affecting  regional  energy  trade,  from  both  national  and  regional  perspectives. Sustained political commitment and co-operation among ASEAN member states will strengthen the region's collective resilience as energy markets are increasingly interconnected and vulnerable to supply and price disruption.

## In-depth analysis: Indonesia

Indonesia  transitioned  to  being  a  net  importer  of  crude  in  2013.  Since  then, declining upstream production has increased the country's import requirements. This has been partially mitigated by lower domestic crude processing, resulting in current net crude imports of around 300 kb/d in recent years.

Upstream production and crude balance in Indonesia, 2018-2031

<!-- image -->

However, the 100 kb/d refinery expansion and upgrade project at the Balikpapan refinery,  completed  in  late  2025,  has  improved  reliability  elsewhere  in  the Pertamina refining system and is expected to sustain crude import requirements at around 400 kb/d for the next two years. Towards the end of the decade, the recovery in upstream output that is expected to follow on from the recent upstream fiscal reforms could narrow Indonesia's net import requirement if the increased condensate production is processed domestically.

## Refined product demand and output in Indonesia, 2018-2031

<!-- image -->

IEA. CC BY 4.0.

Notes: kb/d = thousand barrels per day; LPG = liquefied petroleum gas.

Despite the expected increase in refined product output, domestic product supply fails to keep pace with forecast demand growth over the balance of the decade, and thus Indonesia remains a net importer of key products.

## Balance of trade in gasoline and LPG by volume in Indonesia, 2018-2031

<!-- image -->

Notes: kb/d = thousand barrels per day; LPG = liquefied petroleum gas.

## Natural gas and low-emissions gases security review

Natural gas remains a key component of the ASEAN region's energy system, but the region's gas sector is undergoing a period of significant transition. Declining domestic production, rising LNG import requirements and growing exposure to global gas market risks are increasing the importance of gas security. At the same time,  the  region  retains  important  advantages,  including  a  sizeable  domestic resource  base,  established  gas  and  LNG  infrastructure,  and  opportunities  for closer  regional  market  integration.  While  low-emissions  gases  are  expected  to play  only  a  limited  role  in  the  ASEAN  gas  supply-demand  balance  through  to 2030,  timely  action  over  the  next  five years  could  establish  the  conditions  for sustained growth beyond 2030, particularly for biomethane. This chapter reviews recent  and  projected  gas  market  developments,  assesses  the  region's  gas security across multiple dimensions and examines the outlook for low-emissions gases.

Taken as a whole, ASEAN countries represent a large and growing gas market. At the same time, they are characterised by considerable diversity, with significant differences in the size, maturity and role of natural gas. The region is also a major producer of natural gas, although output from many mature producing areas has entered  structural  decline.  New  upstream  projects  are  expected  to  support production recovery in some ASEAN member states from 2028 onwards, although regional output is projected to stay below 2025 levels by 2030. While the region remains a net exporter of natural gas, rapidly growing LNG imports are steadily eroding its export surplus, and it is expected to become a net gas importer by the end of the decade.

## Gas demand

Total gas consumption in ASEAN was close to 180 bcm in 2025 - about twice the size of Japan's gas market, more than half that of the European Union, and roughly equivalent  to  the  total  gas  demand  of  the  African  continent.  Around  85%  of regional gas consumption is concentrated in three mature markets, with Malaysia and Indonesia each accounting for around 30% of the total and Thailand making up  nearly  25%.  The  remaining  ASEAN  member  states  -  including  Brunei Darussalam, Myanmar,  Singapore, the Philippines and Viet Nam -have comparatively small gas markets, while Cambodia, the Lao PDR and Timor-Leste have no natural gas in their domestic energy mix.

The sectoral breakdown of gas demand is similarly diverse across the region. Overall, the power sector is the largest consumer of natural gas, accounting for nearly half of total demand, followed by industry (around 30%) and the energy sector (around 20%). However, this regional picture masks significant differences across ASEAN member states. In the two largest gas markets, Indonesia and Malaysia, as well as in Viet Nam, industry accounts for a considerable share of gas demand, approaching or exceeding that of the power sector.  By contrast, power  generation  dominates  gas  demand  in  other  gas-consuming  ASEAN member  states,  accounting  for  more  than  70%  on  average.  Gas  use  in  the residential,  commercial  and  transport  sectors  is  negligible  across  the  region, owing to the lack of heating demand and limited or non-existent gas distribution networks;  together  these  sectors  accounted  for  less  than  1%  of  total  gas consumption in 2025.

## Gas consumption by sector in ASEAN, 2025

<!-- image -->

<!-- image -->

Note: bcm = billion cubic metres.

Between 2015 and 2025, the ASEAN region experienced rapid urbanisation and population growth, sustained economic growth (averaging around 4% per year), rising demand for cooling and growing electricity use in industry, which together contributed  to  an  increase  of  around  70%  in  electricity  consumption.  Despite rapidly  rising  primary  energy  demand  and  electricity  consumption,  total  gas consumption  across  the  region  increased  relatively  modestly,  by  around  6%, corresponding to an average annual growth rate of around 0.6%.

Gas  use  in  the  power  sector  remained  flat  in  absolute  terms,  as  most  of  the increase in electricity  demand was met by other sources, particularly coal and hydropower, and to a lesser extent solar PV and other renewables. As a result, virtually all growth in regional gas consumption between 2015 and 2025 was in the industrial and energy sectors, where gas use increased by around 21% and 16%, respectively. Industrial demand was supported by the expansion of energy-

intensive  industries,  such  as  chemicals  and  aluminium  production,  as  well  as broader growth in manufacturing across the region. By contrast, gas use in the transport sector declined by around 70%, largely reflecting reduced consumption in Thailand.

## Gas supply

## Natural gas production

The ASEAN region is a significant producer of natural gas, with output of around 210 bcm in 2025, more than 30 bcm higher than the region's gas consumption. Malaysia (80 bcm), Indonesia (70 bcm) and Thailand (30 bcm) are the region's three largest  producers,  together  accounting  for  around  85%  of  total  output. Brunei  Darussalam,  Myanmar,  the  Philippines  and  Viet Nam  also  produce meaningful volumes, although at a considerably smaller scale.

Between 2015 and 2025, regional gas production declined by around 10 bcm/yr (4%). Output fell in most of the region's mature gas-producing ASEAN member states, including  Brunei  Darussalam,  Indonesia,  Myanmar,  the  Philippines, Thailand and Viet Nam, as production from ageing fields declined. These losses were only partly offset by production growth in Malaysia, supported by new field developments and capacity expansions.

## Low-emissions gases

ASEAN member states, including their energy infrastructure, are highly exposed to  the  impacts  of  climate  change  and  extreme  weather  events.  Eight  of  the eleven ASEAN member states, representing more than 95% of the region's gas consumption,  have  formally  adopted  net  zero  emissions  targets.  Six  of  these (Brunei Darussalam, Cambodia, the Lao PDR, Malaysia, Singapore and Viet Nam) aim to achieve net zero by 2050, while Indonesia and Thailand have set targets for 2060 and 2065, respectively.

Low-emissions gases, particularly biomethane, are well positioned to enhance the region's gas supply security while supporting progress towards decarbonisation objectives. However, deployment has so far been limited, and significant policy, regulatory, economic and infrastructure barriers remain to scaling up production materially over the medium term. As a result, low-emissions gases are expected to remain a niche component of the ASEAN gas supply mix through to 2030.

## Biomethane

The  ASEAN  region  has  considerable  potential  for  biogas  and  biomethane production, but total output in 2024 amounted to just over 2 bcm of gas-equivalent,

of which only around 0.03 bcm was biomethane. Unlike biogas, biomethane is fully interchangeable with natural gas and can be transported and distributed through existing gas infrastructure.

Current production is dominated by Thailand, which accounts for about 60% of the region's combined biogas and biomethane output, supported by a feed-in tariff introduced in 2022. However, significant untapped potential remains across the region.  The  ASEAN  region  as  a  whole  has  sustainable  feedstock  resources equivalent to around 65 bcm of natural gas, about 35% of the region's current gas consumption.  Most  of  this  potential  is  concentrated  in  Indonesia,  followed  by Thailand and Viet Nam, with additional resources in Myanmar, the Philippines, Malaysia, Cambodia and Lao PDR.

Cost estimates indicate that biomethane can be produced at a relatively modest premium to imported LNG prices across the region. However, only around onefifth  of  the  region's  technical  potential  is  located  within  20 km  of  existing  gas transmission pipelines, posing a significant barrier to wider deployment.

Localised production and use (for example, at captive industrial sites), together with  targeted  policy  support,  could  help  unlock  a  larger  share  of  the  region's considerable  resource  base  over  the  longer  term,  strengthening  gas  supply security, expanding energy access and supporting decarbonisation at the same time.

The ASEAN region is now beginning the transition from traditional biogas towards biomethane production, supported by recent policies such as Thailand's updated Alternative  Energy  Development  Plan  2024  and  Malaysia's  National  Biomass Action Plan 2023-2030. Key policy drivers include the decarbonisation of domestic industry, particularly to help manufacturers meet international requirements such as  the  European  Union's  Carbon  Border  Adjustment  Mechanism,  as  well  as reducing methane emissions from the palm oil sector through the treatment of palm oil effluent.

At  the  same  time,  a  new  wave  of  bio-LNG  projects  is  emerging.  The  largest announced project in the world, the Straits Bio-LNG plant in Malaysia, is expected to  produce  around 0.36 bcm per year, while dozens of other bio-LNG projects have been announced across Indonesia, Malaysia and Thailand. These investments are driven by growing demand for low-emissions fuels in maritime shipping, opportunities to export biomethane to Singapore to help decarbonise its gas-dependent power sector, and the potential to displace natural gas imports in domestic markets, particularly during periods of high LNG prices such as those experienced during the Middle East crisis in 2026.

However, despite these initiatives, the scope for scaling up biomethane production is  limited  over  the  medium  term.  Even  under  a  supportive  policy  environment, biomethane production across the ASEAN region is unlikely to exceed 1 bcm by 2030.

## Low-emissions hydrogen

Current low-emissions hydrogen production in the ASEAN region is negligible. Between  2022  and  2025,  five ASEAN  member  states  (Indonesia,  Lao PDR, Malaysia,  Singapore  and  Viet Nam)  adopted  national  hydrogen  strategies  or roadmaps, signalling policy interest in the technology. At the regional level, the ASEAN Plan of Action for Energy Cooperation (APAEC) 2026-2030 also supports greater  co-operation  on  emerging  technologies  such  as  hydrogen,  alongside broader  engagement  with  Dialogue  Partners  and  international  organisations. However, deployment remains at an early stage across both supply and demand.

On the supply side, according to the IEA's Hydrogen Production and Infrastructure Projects Database, around 40 low-emissions hydrogen or derivative fuel projects have been announced across the ASEAN region, representing around 5.5 Mt of annual production capacity (equivalent to around 18 bcm of natural gas on an energy-equivalent basis). About 75% of this pipeline is concentrated in Indonesia and  Malaysia  alone,  with additional projects announced  in  Thailand, the Philippines  and  Viet Nam.  However,  only  less  than  1 Mt  of  annual  production capacity (equivalent to around 3 bcm of natural gas) is associated with projects scheduled to start up by 2030, and the vast majority of these remain at an early stage of development. As of mid-2026, only three projects were under construction, representing around 50 kt of annual production capacity (equivalent to  0.2 bcm  of  natural  gas).  In  addition,  the  Philippines  and  Indonesia  have undertaken preliminary exploration for natural hydrogen, although no commercially viable discoveries have been reported to date.

On the demand side, only a handful of small-scale deployment projects have been announced in recent years. These include a planned 55-65 MW ammonia-fired power plant with associated terminal and bunkering infrastructure in Singapore (announced in 2025 and currently undergoing front-end engineering and design), and a 2 MW ammonia-fired gas turbine demonstration at a petrochemical site in Malaysia (scheduled for completion in 2027).

Despite sustained policy interest and a sizeable project pipeline, low-emissions hydrogen is unlikely to achieve meaningful commercial-scale deployment across the  ASEAN region before 2030. High production costs relative to conventional fuels  and  other  low-emissions  alternatives,  combined  with  high  capital  costs, limited hydrogen infrastructure, and the absence of certification schemes, binding

targets and demand-side incentives, as well as the high price sensitivity of the region's major gas-consuming sectors, are expected to constrain both supply and demand growth over the medium term.

## Gas trade

The ASEAN region as a whole is a net exporter of natural gas,  with  outflows exceeding inflows by around 30 bcm in 2025. More than 85% of this net export balance was in the form of LNG, while the remainder consisted of pipeline gas exports from Myanmar to China.

The region's three LNG-exporting ASEAN member states - Brunei Darussalam, Indonesia and Malaysia - were among the world's earliest LNG exporters, having shipped their first cargoes in 1972, 1977 and 1983, respectively. Together, they exported around 66 bcm of LNG in 2025, with Malaysia accounting for the largest share (37 bcm), followed by Indonesia (22 bcm) and Brunei Darussalam (6 bcm).

Seven  ASEAN  member  states  operate  LNG  import  terminals,  which  together received  about  39 bcm  of  LNG  in  2025.  Around  two-thirds  of  these  imports (27 bcm) originated from outside the ASEAN region, while just over 30% (12 bcm) were supplied from within the region. More than 8 bcm of these intra-regional flows were domestic deliveries within Indonesia and, to a much lesser extent, Malaysia.

Singapore, Indonesia and Malaysia also have LNG reloading infrastructure, which together reloaded around 1.6 bcm of LNG in 2025, contributing to supply flexibility, not only within the ASEAN region but also across the wider Asia Pacific region.

Extra-regional  pipeline  gas  trade  is  limited  to  exports  from  Myanmar  to  China under  a  30-year  long-term  gas  supply  contract,  which  started  in  2013.  These pipeline exports have averaged around 4 bcm per year in recent years and are expected to remain broadly stable through to 2030. Within the ASEAN region, cross-border pipeline gas trade is concentrated in Singapore, which is connected by pipeline to both Indonesia and Malaysia. In 2025, Singapore imported more than 4 bcm from Indonesia and more than 2 bcm from Malaysia. Imports from Malaysia  are  expected  to  continue  beyond  2030,  whereas  the  current  supply contract with Indonesia expires at the end of 2028. Although the renewal of the Indonesian  supply  contract  remains  uncertain,  similar  concerns  were  raised before its previous expiry, and the agreement was ultimately extended for a further five years in 2023.

In addition to these commercial cross-border flows, a handful of pipelines transport gas from jointly developed offshore resources. These include the Yadana pipeline, which  delivers  gas  from  Myanmar's  offshore  Yadana  field  to  the  grids  of  both Myanmar  and  Thailand,  and  the  Malaysia-Thailand  Joint  Development  Area, which  supplies  gas  to  both  countries.  Until  production  ceased  in  2025  due  to

resource  depletion,  all  gas  produced  from  Timor-Leste's  offshore  Bayu-Undan field  was  also  transported  by  pipeline  to  Australia's  Darwin  LNG  terminal  for liquefaction and export.

Between 2015 and 2025, the region's net gas export balance declined by almost half (around 30 bcm). This reflected a modest decrease in LNG exports alongside a more than threefold increase in LNG imports, while cross-border pipeline trade remained broadly stable over the period. The region's net natural gas surplus is projected to shrink further between 2025 and 2030, and ASEAN is expected to become a net gas importer towards the end of the decade. Import requirements are projected to widen in the period to 2030 and beyond, despite a recovery in indigenous gas production in some ASEAN member states, notably Indonesia and Viet Nam, towards the end of the decade.

## Pipeline gas and LNG trade balance in ASEAN, 2015-2030

<!-- image -->

## Five-year outlook

Between 2025 and 2030, gas consumption in the ASEAN region is expected to increase  by  around  18%  (more  than  30 bcm/yr),  corresponding  to  an  average annual  growth  rate  of  more  than  3%,  significantly  higher  than  the  average recorded between 2015 and 2025. This growth is expected to be driven primarily by the power sector, with around 24 GW of gas-fired generation capacity being added across the region, resulting in a nearly 30% (25 bcm/yr) increase in gas consumption  for  power  generation  over  the  five years  to  2030.  Industrial  gas consumption is expected to grow more modestly, by around 20% (10 bcm/yr), while  gas  use  in  the  energy  sector  is  projected  to  decline  by  around  7% (2.5 bcm/yr) as regional natural gas production and LNG exports continue to fall.

## Gas demand by sector in ASEAN, 2015-2030

<!-- image -->

IEA. CC BY 4.0.

Note: bcm = billion cubic metres.

During the same period, gas production is expected to decline in several of the ASEAN  region's mature producing member  states, particularly Malaysia, Myanmar and Thailand. Conversely, Indonesia and Viet Nam are expected to see significant  production  growth  by  the  end  of  the  decade  as  a  handful  of  new upstream projects come online. In Indonesia, output is set to be supported by the Geng North,  Gehem,  Gandang  and  Gendalo  developments,  while  in  Viet Nam additional production is expected from the Block B and Su Tu Trang (White Lion) Phase 2B gas projects. As a net result, regional gas production is expected to continue declining through most of the decade, although the pace of decline is set to slow towards 2030. Even so, total ASEAN gas production in 2030 is projected to fall by close to 10 bcm (or 4%) from its 2025 level.

## Gas production by producing ASEAN member state, 2015-2030

<!-- image -->

IEA. CC BY 4.0.

Note: bcm = billion cubic metres.

## Gas security assessment

## Supply-side security

## Domestic production base

The  ASEAN  region  possesses  a  substantial  natural  gas  resource  base  and extensive production infrastructure, enabling it to remain a net exporter of natural gas as of 2025. However, this production base has been in structural decline for more  than  a  decade,  with  maturing  fields,  declining  reserves  and  limited  new discoveries gradually eroding the region's supply capacity.

At  the  end  of  2025,  proven  natural  gas  reserves  across  the  ASEAN  countries stood  at  around  3.7 tcm,  equivalent  to  an  estimated  18 years  of  production  at current output levels, although a growing share of these reserves is located in higher-cost, technically complex or otherwise challenging areas. Indonesia and Malaysia  account  for  the  largest  share  of  these  reserves  at  26%  and  25%, respectively,  while  Viet Nam  and  Myanmar,  at  19%  and  17%,  also  possess substantial resources but have historically faced greater above-ground challenges in  bringing  them  to  market.  Other  ASEAN  member  states  have  comparatively modest  and/or  rapidly  depleting  reserves.  Total  proven  reserves  in  the  region declined by more than a third between 2015 and 2025 (from around 5.8 tcm to 3.7 tcm today), reflecting a prolonged period during which reserve additions from new discoveries and field developments failed to keep pace with production.

## Natural gas discoveries and exploration CAPEX allocated to gas in ASEAN, 2015-2025

<!-- image -->

IEA. CC BY 4.0.

Notes: bcm = billion cubic metres; CAPEX = capital expenditure. Source: IEA analysis based on data from Rystad Energy.

Exploration  activity  has  accelerated  since  the  price  spikes  and  energy  crisis triggered by Russia's invasion of Ukraine in 2022. A series of new discoveries -

particularly in Indonesia since 2023 and, more recently, around the Malampaya field  in  the  Philippines  in  2026  -  together  with  the  development  of  earlier discoveries in Viet Nam, are expected to temporarily slow the region's production decline towards the end of the decade. Nevertheless, regional gas production in 2030 is still projected to be nearly 10 bcm (4%) lower than in 2025.

## Import dependency

The ASEAN region as a whole remains a net exporter of natural gas, with a net surplus  of  around  30 bcm  in  2025.  Four  of  the  region's  leading  producers (Malaysia,  Indonesia,  Myanmar  and  Brunei Darussalam)  are  significant  net exporters and are expected to remain so through to 2030. By contrast, the region's four other major gas-consuming economies (Singapore, Thailand, the Philippines and  Viet Nam)  were  net  importers  in  2025  and  are  projected  to  remain  net importers throughout the outlook period.

## Net pipeline gas and LNG trade in ASEAN by country, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: bcm = billion cubic metres. LNG = liquified natural gas. As of 2025, Cambodia and Lao PDR do not produce, consume or trade natural gas. Timor-Leste's natural gas production and exports from the county's only developed gas field, BayuUndan, were negligible in 2025, and the field ceased production and exports entirely in mid-2025.

Net import dependency among these four ASEAN member states ranges from just over  10%  in  Viet Nam  to  100%  in  Singapore.  By  2030,  import  dependency  is projected to reach close to 40% in Viet Nam, 60% in Thailand and 80% in the Philippines, while Singapore is expected to remain fully dependent on imported gas throughout the outlook period.

The concentration of supplier countries varies across the net-importing ASEAN member  states,  but  generally  remains  at  manageable  levels,  with  the  largest source country accounting for around 20-40% of total imports. The region's largest importers, Singapore and Thailand, have more diversified import portfolios than the smaller net importers, the Philippines and Viet Nam.

## Import dependency of net-importing ASEAN member states, 2025-2030

<!-- image -->

Among the net-exporting ASEAN member states that also import gas, supplier country  concentration  is  considerably  higher,  with  the  largest  source  country accounting for 80-100% of imports. However, this is generally less of a concern from a security of supply perspective because these ASEAN member states have a surplus of domestically produced gas or LNG. In Indonesia, for example, the dominant supply source consists of LNG from export terminals located within the country, while in Myanmar only a single LNG cargo was received in 2025, leaving little scope for diversification.

Note: bcm = billion cubic metres

<!-- image -->

The ASEAN region as a whole received more than two-thirds of its LNG imports from outside the region. Of these extra-regional imports, Australia and Qatar were by far the largest suppliers in 2025, together accounting for around 65% of extraregional imports and 45% of total LNG imports into ASEAN member states.

## Concentration of LNG import source countries in ASEAN, 2025

Note: LNG = liquefied natural gas.

<!-- image -->

## Exposure to choke points

The ASEAN region, through its growing reliance on LNG imports from outside the region,  is  increasingly  exposed  to  two  of  the  world's  principal  maritime  choke points: the Strait of Hormuz and the Strait of Malacca.

## Strait of Hormuz

The Strait of Hormuz is an international waterway connecting the Persian Gulf with the Gulf of Oman and the Arabian Sea. At its narrowest point the strait is around 50 km wide, with separate navigable channels of around 4 km for inbound and outbound  ship  traffic.  In  2025,  around  110 bcm  of  LNG  transited  the  Strait  of Hormuz, the sole maritime outlet for LNG exports from Qatar and the United Arab Emirates  beyond  the  Persian  Gulf.  Around  20%  of  ASEAN's  LNG  imports (7.7 bcm)  passed  through  the  Strait  of  Hormuz,  with  Singapore  accounting  for around 55% of these volumes and Thailand for another 40%.

The Middle East crisis, which began on 28 February 2026, highlighted the risks associated with this critical maritime choke point. During the first eight months of 2026,  LNG  flows  through  the  strait  fell  by  close  to  65%  (50 bcm)  y-o-y,  with virtually no LNG exports from Qatar and the United Arab Emirates in April. LNG deliveries to the ASEAN region via the strait declined even more sharply, falling

by around 75%, with no deliveries from either Qatar or the United Arab Emirates between  April  and  August.  Affected  LNG  importers  across  the  ASEAN  region responded by increasing spot market procurement rather than curtailing imports, with the United States and Australia supplying the largest share of replacement cargoes from outside the region.

Some ASEAN member states also adopted precautionary measures to mitigate the impact of the disruption. In March 2026, the Philippines invoked emergency powers to regulate electricity prices, increase coal-fired generation and secure assurances from Indonesia that it would not restrict additional coal exports to the country.  Around  the  same  time,  Thailand  instructed  power  plant  operators  to increase  the  share  of  coal  in  the  electricity  mix  and  ordered  the  restart  of two decommissioned units at the 0.6 GW Mae Moh coal-fired power plant. Despite these measures, however, the ASEAN region's combined LNG imports increased by  around  20%  y-o-y  during  the  first  eight  months  of  2026,  underscoring  the region's  growing  dependence  on  LNG  imports  and  the  limited  scope  for  fuel switching, even in a period of elevated prices.

## Strait of Malacca

The Strait of Malacca is a maritime choke point between Indonesia, Malaysia and Singapore, linking the Indian Ocean with the Pacific Ocean via the South China Sea.  At  its  narrowest  point,  the  strait  is  just  3 km  wide,  making  navigation challenging and increasing the risk of disruption from collisions, accidents and in  the  past  -  also  piracy.  Unlike  the  Strait  of  Hormuz,  however,  the  Strait  of Malacca can be bypassed via the Sunda Strait (between the Indonesian islands of  Java  and  Sumatra) and the Lombok Strait (between the islands of Bali and Lombok). While these alternative routes add sailing time and cost, they provide flexibility in the event of disruption.

In 2025, an estimated 95 bcm of LNG transited the Strait of Malacca, 3  mainly from Middle Eastern exporters to Asian importers. It is estimated that a just over half of ASEAN LNG trade (around 21 bcm out of 39 bcm) involved transit  through  or within  the  strait.  The  largest  flows  comprised  LNG  shipments  from  Qatar  to Singapore and Thailand, and Australian cargoes delivered to Malaysia, whose LNG import terminals are located directly on the Strait of Malacca.

3 Based on data for the first half of 2025 only. See: https://www.eia.gov/international/analysis/specialtopics/world\_oil\_transit\_Chokepoints.

## ASEAN LNG imports transiting critical maritime choke points, 2025

<!-- image -->

IEA. CC BY 4.0.

Note: bcm = billion cubic metres.

Source: IEA analysis based on data from ICIS LNG Edge.

## Infrastructure adequacy

## LNG regasification capacity

With  ASEAN's  LNG  imports  more  than  tripling  between  2015  and  2025,  and projected  to  double  again  between  2025  and  2030,  sufficient  regasification capacity  will  remain  critical  to  the  region's  gas  security  and  could  become  a bottleneck  to  further  growth  in  LNG  imports.  In  2025,  ASEAN  member  states imported just under 40 bcm of LNG against a total regasification capacity of more than 80 bcm/yr, leaving around 50% as spare capacity.

By 2030, however, the region's LNG imports are projected to reach nearly 80 bcm, bringing  aggregate  demand  close  to  the  limits  of  currently  available  capacity. Among the seven ASEAN member states that already import LNG, all but two (comprising Indonesia, Malaysia, Myanmar,  Singapore and Thailand) are projected to approach or exceed their existing regasification capacity limit by 2030. Cambodia is expected to become the region's eighth LNG-importing country by the  end  of  the  decade,  with  small  but  sufficient  capacity  to  cover  the  gas requirements  of  the  900 MW  combined-cycle  gas-fired  power  plant  associated with the Botum Sakor LNG terminal, which is currently under construction.

Across the ASEAN region, more than 25 bcm/yr of new regasification capacity is currently under construction. However, even with these projects completed, the average utilisation of the region's import capacity could still exceed 70% by 2030, more than twice the current global average of just under 35%. In some ASEAN

member states, including Malaysia, Indonesia and Thailand, utilisation rates could reach  around  80-90%  by  2030  despite  the  capacity  additions  underway, highlighting the potential need for further investment in LNG import infrastructure if current trends persist.

## LNG import capacity and LNG imports in ASEAN, 2025 and 2030

<!-- image -->

IEA. CC BY 4.0.

Notes: bcm = billion cubic metres; LNG = liquefied natural gas; regas = regasification.

## LNG storage

Gas storage capacity in the ASEAN region is entirely in the form of LNG storage tanks, storage at floating storage and regasification units (FSRUs) and floating LNG (FLNG) facilities. Total LNG storage capacity is just over 3 bcm, of which more than 2 bcm is located at import terminals and less than 1 bcm at export facilities.

This capacity is primarily used to smooth operational flows by decoupling LNG cargo arrivals from send-out at regasification terminals and to ensure continuous feedgas flows at export facilities. However, at least one facility in the region has excess  LNG  storage  capacity  used  for  commercial  optimisation  and  regional trading. At the Arun LNG complex in Indonesia, two of the terminal's four storage tanks are used by TotalEnergies under a terminal use agreement with Pertamina, supporting trading and portfolio optimisation in the broader Asian LNG market.

Total storage capacity in ASEAN countries is equivalent to less than 2% of the region's annual gas consumption, owing in part to the region's lack of seasonal heating demand. This is well below the levels in other gas-consuming regions and markets.  For  example,  storage  capacity  exceeds  25%  of  annual  demand  in Europe  where  seasonal  demand  swings  are  more  pronounced,  while  in  other LNG-dependent Asian economies, such as Japan and Korea, storage capacity is equivalent to close to 15% of annual demand.

## LNG storage capacity in ASEAN by country, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: bcm = billion cubic metres; LNG = liquefied natural gas. Source: IEA analysis based on data from ICIS LNG Edge.

## Cross-border interconnections

Cross-border  natural  gas  interconnections  within  ASEAN  remain  limited  and provide  only  modest  additional  resilience  in  the  event  of  supply  disruption. Excluding  pipeline  connections  associated  with  jointly  developed  offshore  gas fields  -  notably  between  Myanmar  and  Thailand  and  between  Malaysia  and Thailand - Singapore is the only ASEAN member state with commercial crossborder pipeline imports, receiving gas from both Indonesia and Malaysia. While these pipelines had a combined nominal spare capacity of more than 3 bcm in 2025, their ability to provide additional supplies during an emergency is likely to be  constrained  by  gas  availability  rather  than  pipeline  capacity.  Moreover,  the long-term continuity of these supplies remains uncertain, with Singapore's import contract  with  Indonesia  due  to  expire  at  the  end  of  2028  and  its  contract  with Malaysia in 2031, although similar uncertainty ahead of the previous expiry was ultimately resolved through a contract extension. As a result, for the region as a whole, existing cross-border pipeline interconnections provide only limited operational flexibility for responding to regional gas supply disruption.

Governments across the region recognised the energy security benefits of closer regional gas market integration and greater cross-border connectivity early on, and formalised their support for the Trans-ASEAN Gas Pipeline (TAGP) initiative through the signing of a memorandum of understanding (MoU) in 2002, which entered  into  force  in  2004.  However,  progress  towards  an  integrated  regional pipeline network has been slower than originally envisaged due to a combination of commercial, technical and regulatory challenges, including the high cost and technical complexity of offshore gas pipelines, limited regulatory harmonisation across ASEAN member states, and insufficient multilateral co-operation on market integration and removal of cross-border barriers. Reflecting these challenges, as

well as the growing role of LNG in the region's gas trade, the TAGP concept has evolved over time. The latest extension of the MoU, concluded in 2024 for a further ten-year  period  through  to  2034,  places  greater  emphasis  on  strengthening regional connectivity through LNG infrastructure and so-called "virtual pipelines", including LNG import terminals, reloading facilities, break-bulk services and smallscale LNG distribution, complementing existing and potential pipeline connectivity where commercially viable, and potentially  offering  greater  flexibility  and  lower costs than new cross-border pipelines.

Ultimately,  strengthening  regional  gas  security  will  require  not  only  physical infrastructure,  including  LNG-based  connectivity  (and  an  adequately  skilled workforce  to  support  its  construction  and  operation),  but  also  deeper  regional market  integration,  stronger  multilateral  co-operation,  and  greater  regulatory co-operation,  compatibility  and,  where  appropriate,  alignment.  Together,  these could facilitate cross-border gas trade, reduce market barriers and improve the region's collective ability to respond to gas supply disruption. More transparent and liquid regional trading arrangements could also support the emergence of a regional gas or LNG price benchmark that reflects supply-demand fundamentals within  the  ASEAN  region,  which  could  improve  market  flexibility  and  supply security over time.

## Underground gas storage

Due to the limited seasonal variation in gas and LNG demand across the region, there are no operating or planned underground gas storage facilities in the ASEAN region. However, at least one potential site (Indonesia's Parigi formation) has been extensively studied for underground storage development.

## Demand-side readiness

Demand-side flexibility is a key component of the gas supply emergency response toolkit in mature gas markets, including in Europe, where the European Union and members of the Energy Community have established a common framework to safeguard  gas  supplies  to  protected  customers  during  emergencies.  In  the ASEAN  region,  however,  the  scope  for  such  measures  is  more  limited. Residential, commercial and public services account for only a negligible share of gas demand across the region, leaving little scope to protect these consumers by curtailing demand in other sectors.

Industrial  gas  demand,  which  is  typically  the  greatest  source  of  demand-side flexibility  during  supply  disruption  through  mechanisms  such  as  interruptible contracts,  is  heavily  concentrated  in  Indonesia  and  Malaysia,  which  together account for almost three-quarters of ASEAN's industrial gas consumption. As both ASEAN member states are major net exporters of natural gas with large upstream

operations and some flexibility in their LNG sales arrangements, the need to curtail gas supplies to domestic industry may be more limited than in import-dependent economies.

Nevertheless, several import-dependent economies, including Singapore, Thailand  and  Viet Nam,  have  sizeable  industrial  gas  demand  that  could,  in principle, provide some short-term flexibility during emergencies. In these ASEAN member  states,  temporary  reductions  in  industrial  gas  consumption  could potentially allow gas supplies to be reallocated to higher-priority uses, including electricity generation and, in the case of Thailand, potentially to the vehicle fleet fuelled by compressed natural gas (CNG) in the transport sector.

Across ASEAN, and particularly in the region's import-dependent economies, the power  sector  is  by  far  the  largest  consumer  of  natural  gas.  As  a  result,  fuel switching in the power generation sector offers the greatest potential source of demand-side  flexibility  during  gas  supply  disruption,  although  the  available potential varies considerably between ASEAN member states. In Brunei Darussalam, Myanmar, Singapore and Thailand, gas-fired power plants have little or no ability to switch to alternative dispatchable generation sources, although  some  gas-fired  fleets,  notably  Singapore's  have  dual-fuel  capability. Malaysia  has  a  sizeable  coal-fired  generation  fleet,  but  it  already  operates  at utilisation rates above  75%,  leaving  limited  scope  to  substitute coal-fired generation for gas in the short term. Indonesia, the Philippines and Viet Nam have sufficient spare coal-fired capacity, in principle, to replace most or all gas-fired generation. In practice, however, the extent to which fuel switching could be used during an emergency is limited by geographic constraints in Indonesia and the relatively  high  utilisation  of  existing  coal-fired  plants  in  the  Philippines  and Viet Nam, leaving only less-efficient units available to increase output.

Utilisation of dispatchable fossil fuel generation capacity in selected ASEAN member states, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: GW = gigawatts. Countries with smaller and larger generation fleets are shown on two separate graphs for better visibility.

## Exposure to economic and price risk

In  2025,  ASEAN  countries  sourced  approximately  45%  of  their  LNG  imports through spot markets and short-term contracts, slightly above the global average of around 43%. Exposure to spot and short-term procurement varied considerably between  ASEAN  member  states.  Indonesia  secured  most  of  its  LNG  imports under long-term contracts, primarily from domestic suppliers, while the Philippines and Viet Nam, for example, relied on spot market purchases for the majority of their imports. Thailand and Malaysia had a more balanced procurement portfolio, with spot and short-term volumes accounting for a share of imports broadly in line with the regional and global averages.

Among the region's LNG importers, Singapore and Thailand were the most directly affected by the closure of the Strait of Hormuz during the Middle East conflict in 2026, having received around 4 bcm and 3 bcm of LNG from Qatar, respectively, in 2025. Following the disruption of these supplies at the end of February 2026, both  ASEAN member states turned to the spot market to secure replacement cargoes, exposing them to higher LNG procurement costs.

## LNG imports by sales basis in ASEAN, 2025

<!-- image -->

IEA. CC BY 4.0.

Note: LNG = liquefied natural gas.

Source: IEA analysis based on data from GIIGNL and ICIS.

## System resilience

## Strategic buffers and stocks

Given the absence of underground gas storage, limited LNG storage capacity, constrained fiscal resources in at least some ASEAN economies, and the fact that the region as a whole remains a net exporter of natural gas, strategic gas reserve

mechanisms are not widely used. Singapore is currently the only ASEAN member state to operate a dedicated strategic gas reserve scheme through its Standby LNG Facility (SLF).

The  SLF  was  introduced  by  Singapore's  Energy  Market  Authority  in  2021  in response to tightening global LNG market conditions and heightened concerns over gas supply security following the sharp LNG price spike in early 2021. The facility is designed to ensure the availability of gas for electricity generation during supply  disruption  or  periods  of  severe  market  stress.  The  scheme  maintains physical  LNG  buffer  stocks  within  Singapore's  existing  LNG  import  terminal infrastructure, allowing emergency gas supplies to be made available to power generators when required. In 2025, the Singapore government established the state-owned Singapore GasCo to further strengthen supply security by centralising gas procurement. Since April 2026, in response to the Middle East crisis, the company has taken over responsibility for managing the SLF and has stepped up short-term and spot market LNG purchases, alongside its mediumand long-term procurement activities. Although Singapore's approach reflects the specific characteristics of its gas market - including complete import dependency, limited domestic storage options and a power system overwhelmingly reliant on natural  gas  -  it  demonstrates  that  strategic  LNG  buffer  mechanisms  can strengthen  supply  resilience  without  requiring  dedicated  underground  storage facilities. As LNG import dependency increases across parts of the ASEAN region, similar  approaches,  adapted  to  national  market  conditions  and  institutional arrangements, could warrant further consideration as part of broader efforts to strengthen gas security. This applies in particular to the possibility to establish a co-ordinated gas emergency response mechanism under APSA.

## Infrastructure resilience

While  a  comprehensive  assessment  of  the  ASEAN  region's  gas  infrastructure resilience is not readily available, the history of outages at its LNG liquefaction terminals offers insight into the main vulnerabilities affecting its upstream, pipeline and LNG infrastructure.

Of the roughly 11 bcm of LNG production disrupted between 2015 and 2025, 4  the largest  share  (35%) was associated with force majeure-type events. The most significant  single  point  of  failure  was  Malaysia's  Sabah-Sarawak  Gas  Pipeline, which transports feedgas produced offshore Sabah to the Bintulu LNG complex in Sarawak. Between 2015 and 2025, unplanned disruptions affecting the pipeline alone accounted for a combined 4 bcm of lost LNG supply. Since entering service in  2014,  the  pipeline  has  experienced  a  series  of  integrity-related  incidents,

4 Disrupted volumes linked to unplanned LNG outages are calculated on the basis of the prevailing production rate over the preceding 12 months.

including a fire in 2014, gas leaks in 2018 and 2019, a rupture and fire in 2020, and a further leak in September 2022 linked to soil movement and subsidence. Following this series of failures, Petronas announced plans to decommission the pipeline by the end of 2027.

Plant failures (25%) and upstream feedgas supply issues (17%) were also among the leading causes of LNG production outages in Brunei Darussalam, Indonesia and Malaysia, reflecting in part the age of the region's legacy infrastructure. A further 22% of unplanned outages were attributed to unspecified causes, limiting the extent to which the underlying vulnerabilities can be assessed.

## Unplanned LNG capacity outages in ASEAN, 2015-2025

<!-- image -->

IEA. CC BY 4.0.

Notes: LNG = liquefied natural gas; bcm = billion cubic metres. Disrupted volumes linked to unplanned LNG outages are calculated on the basis of the prevailing production rate over the preceding 12 months. Source: IEA analysis based on data from ICIS.

## Climate and weather resilience

Natural gas infrastructure and gas-fired power plants across ASEAN are highly exposed to weather-related hazards, including extreme heat, flooding, droughts and tropical cyclones, with flood risk posing the greatest threat. Nearly 25% of the region's existing and under-construction gas-fired power plants are located in river floodplains, increasing their vulnerability to disruption from extreme rainfall and flooding. Extreme heat also reduces the performance of gas-fired power plants, lowering output by up to 1% for every 1 °C increase in ambient temperature above 16 °C.  More  than  30%  of  the  region's  gas-fired  power  plants  are  exposed  to extreme heat (daily maximum temperatures exceeding 35 °C) for at least 40 days per year.

Levels of climate hazard and exposure by ASEAN member state, 2025

|                   |   River flooding |   Coastal flooding |   Drought |   Tropical cyclones |
|-------------------|------------------|--------------------|-----------|---------------------|
| Brunei Darussalam |              4.8 |                3.3 |       2.1 |                 0   |
| Cambodia          |              8.6 |                3.7 |       4.2 |                 1.8 |
| Indonesia         |              8.4 |                8.1 |       3.3 |                 1.6 |
| Lao PDR           |              8.2 |                0   |       1.1 |                 1.4 |
| Malaysia          |              6.8 |                6.4 |       3.1 |                 0   |
| Myanmar           |              8.8 |                8   |       0.9 |                 5.8 |
| Philippines       |              6.7 |                8.9 |       3.5 |                 9.2 |
| Singapore         |              0   |                2   |       0   |                 0   |
| Thailand          |              9.8 |                5.6 |       5.4 |                 1.6 |
| Timor-Leste       |              0   |                3.3 |       1.9 |                 0.5 |
| Viet Nam          |              9.9 |                9.6 |       4.5 |                 5.9 |
| Global average    |              4.5 |                3.5 |       3.4 |                 1.6 |

Notes: Each cell colour in the table indicates the level of climate hazard and exposure. The levels of climate hazard and exposure to river flooding, coastal flooding, drought and tropical cyclones are assessed using the indicators in the INFORM Risk Index 2026 and are defined as Low (0-2.99), Medium (3-6.99) and High (7-10). In the figure, exposure was calculated for floodplains with a 1-in-500-year return period. It includes operational power plants and power plants under construction. Source: IEA (2026), Southeast Asia Energy Outlook 2026.

Tropical cyclones pose an additional risk, particularly in Myanmar, the Philippines and  Viet Nam,  where  they  threaten  gas  infrastructure  and  power  generation assets. Cyclone-related disruption can also affect LNG supplies from Australia, the  largest  external  supplier  of  LNG  to  the  ASEAN  region,  as  several  export terminals are located in cyclone-prone regions in northern and western Australia. These  climate-related  risks  underscore  the  importance  of  strengthening  the resilience of both domestic gas infrastructure and international LNG supply chains to support regional energy security.

## Coal and solid biofuels security review

Coal plays a significant but highly varied role across the ASEAN region and is used in every member state except Timor-Leste. While coal accounts for only a small share of the energy mix in Brunei Darussalam, Myanmar and Singapore, ASEAN  is  an  important  driver  of  global  coal  demand,  led  by  Indonesia  and Viet Nam. Taken as a whole, ASEAN is a net exporter of coal due to Indonesia's large  export  volumes,  but  this  masks  considerable  diversity  between  member states  in  demand,  available  supply  and  production.  The  following  sections examine coal demand and its drivers, the region's reserves, production and trade, and the implications for energy security.

## Coal demand

Coal demand in ASEAN is underpinned by electricity generation, which accounts for  about  75%  of  overall  consumption,  with  industry  making  up  the  remainder. Demand is projected to continue rising over the next five years, driven by strong economic  and  electricity  demand  growth,  including  from  potential  data  centre demand,  new  coal-fired  power  generation  capacity  and  expanding  industrial activity. Indonesia continues to lead regional consumption, representing over half of  the  total,  followed  by  Viet Nam,  the  Philippines,  Malaysia,  Thailand  and Lao PDR.

According to the latest IEA forecasts, ASEAN is expected to record the world's fastest  growth  in  coal  demand  at  4.4%  per  year  on  average  through  to  2030. Indonesia and Viet Nam account for most of this growth. By 2029, Indonesia is expected to become the third-largest coal consumer in the world after China and India, surpassing  the  United States.  Despite  the  expansion  of  renewables deployment,  coal  demand  in  the  power  sector  remains  resilient  due  to  strong growth in electricity demand. In addition, the availability and affordability of coal, industry's reliance on it, and contractual aspects such as the existence of coalfired  power  plants  with  long-term  power  purchase  agreements  (PPAs)  makes substitution challenging. In Indonesia and to a lesser extent Viet Nam, social and economic aspects related to jobs also play a role in maintaining coal's dominant position  in  the  energy  mix,  particularly  in  regions  with  a  high  geographical concentration and historical legacy of coal production, such as East and Central Kalimantan

While  expectations  of  abundant  LNG  supply  later  in  the  decade  had  been anticipated to strengthen competition with coal, ASEAN member states across the region may reassess the role of LNG in their energy mix after the recent crisis in the Middle East. In Indonesia, the transition away from captive coal generation remains  particularly  challenging,  as  replacement  technologies  must  provide reliable  24/7  electricity  in  a  logistically  feasible  way,  and  compete  with  the country's low-cost domestic coal. Coal consumption in industry is also expected to grow, with steel, nickel and aluminium production driving demand growth.

## Coal demand in ASEAN, 2022-30

<!-- image -->

IEA. CC BY 4.0.

Notes: 2022-2024 are historical data, 2025 are preliminary estimates and 2026-30 are forecasts. Mt = million tonnes.

## Coal in metal production

The  production  of  critical  minerals,  in  particular  nickel  and  aluminium,  is  an important driver of coal demand in Indonesia. The country's nickel processing and refining sector has rapidly expanded over the past decade, producing around 60% of the global nickel supply and operating over 50 nickel smelting facilities. Most nickel  production  relies  on  rotary  kiln  electric  furnace  technology,  which  uses thermal and metallurgical coal both as a process input and as a source of heat and electricity.

Aluminium  smelting  is  also  expanding,  notably  in  North Kalimantan,  adding around 30 TWh of baseload electricity demand and reinforcing reliance on coalfired generation in the near term. Without substantial changes to processing routes or power generation technology, coal demand from the metals sector will increase as smelter capacity and output increase.

Opportunities exist to reduce metal production's carbon intensity and its demand for  coal.  In  nickel  production,  generating  electricity  to  power  the  furnace  is responsible for over 60% of coal use in rotary kiln electric furnaces, highlighting the potential role of lower-emission power sources to vastly reduce coal demand and carbon emissions from nickel production. For example, Vale has integrated hydropower into its nickel smelting operations in Indonesia, reducing the amount of coal needed and 60% of the emissions from the process. Other companies are exploring solid biomass solutions to replace coal directly without major modifications  to  existing  boilers,  particularly  through  the  use  of  torrefied  wood pellets  ("black  pellets"  or  "bio-coal").  Viet Nam,  for  example,  has  a  domestic torrefaction facility. Such fuels could provide a lower-emissions alternative to coal and help reduce coal dependency while longer-term investments in renewable power and industrial decarbonisation are developed. The contribution of biomass will depend on the sustainability of feedstock production, processing and supply chains, underlining the importance of robust sustainability standards and certification frameworks.

## Coal supply

## Coal reserves

ASEAN holds nearly 40 billion tonnes of coal reserves, representing 3% of the global  total  and  equivalent  to  approximately  80 years  of  supply  at  the  region's current  consumption  rate.  While  several  ASEAN  member  states  have  coal reserves,  only  Indonesia,  Lao PDR,  Thailand  and  Viet Nam  each  hold  over one billion tonnes. Indonesia ranks among the top ten countries globally for coal reserves, accounting for 83% of total coal reserves in ASEAN. However, these reserves are primarily lower-grade thermal coal. Notably, the region does not have significant  coking  coal  deposits,  which  are  essential  for  blast  furnace  steel production.

Coal is categorised by its calorific value (CV), with higher-CV coals considered higher grade and commanding a price premium. Generally, low-CV refers to a CV below 4 200 kcal/kg, mid-CV  refers to a CV  between  4 200 kcal/kg and 5 700 kcal/kg and high-CV refers to a CV above 5 700 kcal/kg. Indonesia holds 32 billion tonnes of coal reserves, of which 24 billion are low CV, 4.5 are medium CV and 3.5 are high CV. Most of the reserves are in Kalimantan and Sumatra, with  smaller  volumes  in  other  islands  like  Sulawesi  and  Papua.  Coking  coal reserves are very limited, located in Central Kalimantan.

<!-- image -->

Viet Nam holds 3.5 billion tonnes of coal reserves, mostly anthracite and some bituminous coal. Thailand holds over 1 billion tonnes of lignite reserves in the north of the country. Lao PDR has over 1 billion tonnes of identified reserves, primarily lignite in the north of the country and anthracite in the south. Malaysia has coal reserves  of  around  half  a billion  tonnes  (sub-bituminous  coal)  in  the  Sarawak region of Borneo island.

In the  Philippines,  around  360 Mt  of  mostly  sub-bituminous  mineable  coal reserves have been identified across 19 coal districts located on different islands, although production is centred on Semirara. Under the Philippines Conventional Energy Contracting Program, 3 predetermined areas comprising 18 coal blocks are being offered for development and production, including reserves on Semirara and in Cagayan and Isabela.

In  Cambodia,  two companies  are  conducting  exploration  along  the  CambodiaThailand  border  with  an  estimated  total  about  110 Mt  of  reserves.  A  state-led exploration project, Coal for National Security, is underway and expects to identify around 100-200 Mt of reserves. Other privately held licences for exploration have also been granted.

## Domestic production

Coal  production  in  the  ASEAN  region  is  highly  concentrated,  with  Indonesia accounting for around 90% of its output and ranking as the world's third-largest producer after China and India. Unsurprisingly, the largest coal producers in the ASEAN  region  are  the  holders  of  its  largest  reserves:  Indonesia,  Viet Nam, Lao PDR, the Philippines and Thailand.

Indonesia  produces  primarily  sub-bituminous  coal  for  thermal  purposes,  which includes some lignite, with limited production of metallurgical coal. Since 2010, Indonesia's  coal  production  has  expanded  by  an  average  of  6%  annually,  the fastest-growth among major coal-producing countries. While most production in Indonesia is carried out by private companies, the Domestic Market Obligation requires  producers  to  sell  a  regulated  portion  of  their  output  to  the  domestic market.

Viet Nam is ASEAN's second-largest coal producer. Viet Nam National Coal and Mineral  Industries  Holding  Corp  Ltd  (Vinacomin),  a  company  owned  by  the government of Viet Nam, is the owner of all operating coal mines in the country.

Lao PDR, the Philippines and Thailand are the next largest producers of coal. Coal production  in  Lao PDR  expanded  significantly  about  a  decade  ago  when  the Hongsa mine in the north of the country began supplying the Hongsa power plant, which  exports  electricity  to  Thailand.  The  Philippines  surpassed  20 Mt  of  coal production in 2025; 90% of its domestic production is sub-bituminous coal mostly for export, but it also serves domestic needs. In Thailand, the Mae Moh coal mine supplies the Mae Moh power plant.

Cambodia  and  Malaysia  have  a  number  of  small  mines.  In  Malaysia,  limited production  in  Sarawak,  on  Borneo  island,  meets  demand  from  nearby  power plants. In Cambodia, licences for exploration and mining have been granted along the  northern  border  with  Thailand.  Coal  production  is  100%  lignite,  and  coal exports are not permitted.

## Coal production by type in ASEAN, 2025

<!-- image -->

IEA. CC BY 4.0.

Note: Mt = million tonnes.

## Import dependency and supply diversification

ASEAN is a net exporter of coal, with exports in 2025 at 538 Mt and imports at 194 Mt,  resulting  in  a  net  surplus  of  344 Mt,  about  two-thirds  of  its  total consumption. However, only Indonesia and Lao PDR are net exporters of coal.

Of the coal imported into ASEAN member states, Indonesia is the largest supplier (102 Mt), with ships typically loaded at ports in East and South Kalimantan, where the bulk of exports originate. Australia (39 Mt) and Russia (17 Mt). are the next largest exporters to ASEAN countries. Over 70% of Lao PDR's coal exports are intra-ASEAN.

ASEAN  member  states  are  far  more  dependent  on  outside  countries  for metallurgical coal: of the region's 30 Mt met coal demand, just 6 Mt is supplied by Indonesia.  The  majority  comes  from  Australia  (12 Mt),  Russia  (5 Mt),  the United States (1.5 Mt), Mozambique and Canada.

## Imports and exports of coal in ASEAN, 2025

<!-- image -->

Note: Mt = million tonnes.

Indonesia is the largest coal exporter in the world, exporting over 500 Mt in 2025. China (213 Mt in 2025) is the largest destination of Indonesian exports, followed by  India  (101 Mt),  the  Philippines  (38 Mt),  South  Korea  (29 Mt)  and  Malaysia (27 Mt). This export dominance can be attributed in part to its efficient logistics, in which coal is transported from river ports by barges to ocean jetties and loaded onto ships for international delivery. Using barges is less expensive, requires lower capital investment and is more flexible than rail, while being far more efficient than trucks.  This  logistical  advantage  has  allowed  Indonesia  to  expand  its  export capacity  from  low-cost  mines.  However,  barge  transport  does  expose  trade  to weather risks. For instance, dry weather and low water levels in Indonesia's Barito River in Central Kalimantan this year affected producers' ability to export.

Cambodia and Malaysia have a small number of mines. While Indonesia is a major thermal coal exporter, it has become increasingly reliant on imports of coking coal to  support  growing  demand  from  its  metallurgy  and  smelting  sectors.  Its  main suppliers are Australia, Canada, Russia and the United States. Simultaneously,

Indonesia  is  increasing  its  coke  production  capacity  and  became  the  world's second-largest coke exporter after China at over 7 Mt, and the largest metallurgical coke exporter in 2025 (excluding China's semi-coke exports).

Viet Nam has undergone a significant shift, moving from net coal exporter to net coal importer in 2015 as domestic demand growth outpaced production, which is constrained  by  geological  conditions  and  rising  costs.  Coal  imports  reached around 65 Mt in  2025,  making  Viet Nam  the  world's  fifth-largest  coal  importer; Indonesia (23 Mt in 2025) and Australia (22 Mt) are its main suppliers. Efforts are underway  to  expand  cross-border  coal  trade  with  Lao PDR,  including  via  a conveyor belt project.

The Philippines imported 38 Mt of coal in 2025, falling for the first time since 2020 (down 5% y-o-y), with Indonesia supplying 99% of the volume. All imports are thermal coal, used almost entirely for power generation, with about 2 Mt for other industrial  uses.  Most  coal-fired  power  plant  boilers  are  designed  specifically  to function at highest efficiency with Indonesian coal or a blend with Indonesian coal.

Malaysia imported 36 Mt in 2025, a record for the country. Indonesia is the main supplier (27 Mt), followed by Russia (3 Mt). Imports are mostly thermal coal, but Malaysia also imported 3 Mt for industrial purposes.

Thailand imported 19 Mt in 2025, a 21% decrease over the past decade. Indonesia is its largest supplier (14 Mt in 2025), followed by Australia (4 Mt). All imports are thermal coal.

## Modern sustainable solid biofuels

Modern sustainable solid biofuels are organic material derived from agricultural, forestry, industrial or municipal solid waste residues (e.g. bagasse, wood pellets, wood  waste).  When  sourced  sustainably  they  can  be  combusted  directly  or upgraded mechanically, thermally or thermochemically to improve fuel properties, to generate  renewable  heat  and  electricity.  Solid  biomass  can  also  partly substitute  for  coal  through  co-firing  in  existing  coal-fired  plants,  an  approach established in Indonesia and being considered elsewhere in Southeast Asia. They can complement intermittent renewables, such as solar PV and wind, to provide dispatchable  renewable  electricity,  diversify  power  supply  and  support  grid integration. In addition, they can reduce dependence on fossil fuel imports while supporting sustainable land and waste management practices when integrated with existing agricultural, forestry and waste management value chains.

Since  2015,  the  capacity  of  power  generation  fuelled  by  solid  biofuels  in  the ASEAN region has increased by around 40% from roughly 6 GW to almost 10 GW. Feedstock for these fuels has consisted primarily of agricultural, organic industrial waste and forestry residues, including bagasse from sugar production, rice husks,

palm oil residues such as empty fruit bunches and palm kernel shells, and timber by-products such as wood chips. The resource base is concentrated in ASEAN member states with large agricultural sectors, particularly Thailand and Indonesia, which account for almost 80% of solid biofuel-based electricity generation in the region.

## Solid biofuel-based power generation capacity in ASEAN, 2015-2025

<!-- image -->

IEA. CC BY 4.0.

Notes: GW = gigawatts. Other ASEAN member states with noteworthy solid biofuel-based power generation capacity are Malaysia, Viet Nam and the Philippines. Sources: IEA (2025), Renewables 2025; IRENA (2026), Renewable Energy Statistics 2026; and based on data from S&amp;P Global.

Several ASEAN member states are also significant exporters of solid biofuels. Viet Nam is  the  world's  second-largest  wood  pellet  exporter,  supplying  around 6-7 Mt annually primarily to Japan, Korea and Europe. Other noteworthy exports are forestry-based wood pellets from Malaysia and Indonesia, each close to 1 Mt annually,  and  Thailand  at  slightly  less  than  0.5 Mt.  Additionally,  Indonesia produces 14 Mt of palm kernel shells, of which around 35% are exported, most notably to Japan.

The capacity of power generation fuelled by sustainable solid biofuels in ASEAN is expected to increase by an additional 20% by 2030, reaching more than 11 GW. Additions are expected to be spread across different sustainable solid biofuels such as agricultural, industrial and forestry residues, as well as municipal waste. Growth  is  led  by  agricultural  biomass,  reflecting  the  availability  of  low-cost residues  from  sugar,  rice  and  palm-oil  value  chains,  while  industrial  residues continue to provide a stable resource base from agriculture and pulp and paper industries.

Municipal waste is expected to record the strongest relative growth from a small base (up by 60% between 2025 and 2030), supported by national waste-to-energy

ambitions. These include Thailand's Alternative Energy Development Plan 20242037 target of 1.1 GW of municipal waste power capacity by 2037. The strategy also aims to increase bioenergy-based power generation capacity to 5.5 GW by 2037,  increasing  today's  installed  capacity  by  a  third.  Thailand's  biomass feedstock resource base is dominated by agricultural feedstocks and residues. Sugar cane, cassava, rice straw, bagasse and palm residues are considered the most  promising  resources  due  to  their  large  domestic  availability,  established supply chains and suitability for bioenergy and biorefinery applications. Viet Nam also envisages the development of electricity production from solid waste and solid organic  by-products  through  a  power  generation  capacity  target  of  2.2 GW  by 2030  in  its latest National  Power  Development  Plan  (PDP8).  In  contrast, Indonesia's 10-year national strategy (RUPTL 2025-2034) envisages renewables being dominated by solar PV, wind and hydro, albeit co-firing  solid biofuels  in existing coal-fired power plants to reduce coal consumption.

## Solid biofuel-based power generation capacity forecast in ASEAN, 2025-2030

<!-- image -->

IEA. CC BY 4.0.

Notes: GW = gigawatts. Agricultural biomass covers rice husks, bagasse, palm residues, energy crops and other residues; industrial biomass residues cover sugar and pulp and paper industry residues, black liquor and other by-products; woody biomass covers wood waste solids, forestry residues, sawdust, bark, wood chips and pellets. Sources: IEA (2025), Renewables 2025; IRENA (2026), Renewable Energy Statistics 2026; and based on data from S&amp;P Global.

Continued  use  of  these  fuels  will  depend  on  a  sustainable,  cost-competitive feedstock supply. Because transport and handling costs can significantly affect power generation costs, solid biofuels are most competitive when sourced locally or  regionally.  However,  several  ASEAN  member  states  are  major  exporters  of white wood  pellets, suggesting  scope  to  reassess  potential  expansion  of sustainable supply which could be directed to domestic energy production. This could strengthen energy security and reduce reliance on imported fossil fuels.

Emerging  solid  biofuel  technologies  could  further  expand  their  contribution  to renewable heat and power in the region by improving energy density and flexibility. Torrefied  or  steam-exploded  wood  pellets,  for  example,  have  higher  energy density,  better  water  resistance  and  improved  grindability  than  conventional pellets,  reducing  storage  costs  and  making  them  more  suitable  for  co-firing  or making  viable  the  conversion  of  existing  coal-fired  power  and  industrial  heat systems. Similarly, bio-coal, an advanced solid biofuel also known as biocarbon, can  replace  metallurgical  coal  as  a  chemical  reductant  in  metals  production, reducing both operational emissions and the embodied carbon of finished metals. Companies such as Arbaflame and AIREX have begun producing these fuels as demand for lower-emissions industrial fuels grows in Europe and North America.

## Five-year outlook

## Demand

Coal demand in the ASEAN region is projected to continue rising through to 2030, growing by around 4.4% per year to reach 647 Mt, the fastest growth of any region worldwide. Indonesia is projected to account for over 56% of this growth, while Viet Nam and the Philippines also see steady increases linked to power sector development.

Indonesia's  coal  demand  is  projected  to  rise  to  344 Mt  by  2030,  with  power generation and metals processing accounting for the bulk of incremental volumes. Coking coal consumption, both to meet demand from the domestic steel industry and for coke exports, is forecast to increase by over 60% through to 2030. This trajectory positions Indonesia as the largest coal consumer in ASEAN and on track to become the third-largest globally. Coal demand in Viet Nam is projected to rise steadily to 134 Mt by 2030, with power generation driving the majority of growth and industry providing additional support.

Outside  Indonesia  and  Viet Nam,  coal  demand  remains  tied  mainly  to  power generation. In the Philippines, consumption is forecast to reach 57 Mt by 2030 as coal-fired generation continues to provide baseload supply alongside accelerating renewables deployment. Malaysia's coal use is expected to remain broadly stable to 2030. In Thailand, demand is forecast to remain at around 35 Mt in 2030, as higher electricity demand and the extended operation of the Mae Moh lignite plant sustain  output  despite  renewable  additions  and  greater  LNG  availability.  In Lao PDR, coal-fired generation remains primarily export-oriented, with the Hongsa power plant supplying Thailand and new projects in Xekong and other provinces targeting Cambodia and Viet Nam, reinforcing regional interconnections.

## Evolution of coal consumption in ASEAN and forecast change by country, 2024-2030

<!-- image -->

IEA. CC BY 4.0.

Note: Mt = million tonnes.

## Supply

Indonesia and Lao PDR are the only net exporters of coal in the ASEAN region. As regional demand continues to grow and no major production increases are expected in other ASEAN member states, import dependency across the rest of ASEAN is  likely  to  rise  further.  For  metallurgical  coal,  the  supplier  mix  is  not expected to change materially over the forecast period, with Australia remaining the largest source of imports, followed by Russia, the United States, Canada and Mozambique.

## Phase-out plans and transition pathways

Coal has significant environmental impacts throughout its life cycle - from mining and transport to consumption. Open pit mining, common in Indonesia, disturbs land, while underground  mining  can  cause  subsidence  and  affects  water resources. These effects can persist long after a mine closes if land rehabilitation measures are inadequate.

Coal-fired power generation is also the world's largest source of CO2 emissions. Carbon  capture, utilisation and  storage (CCUS)  technologies  can  reduce emissions  from  coal-fired  power  plants,  but  their  economic  competitiveness relative  to  other  low-carbon  technologies  remains  uncertain  in  many  markets, particularly  without  substantial  policy  and  commercial  incentives  to  become economically  feasible.  Their  deployment  in  ASEAN  will  likely  remain  limited through to 2030.

Coal consumption, especially in power plants, is also a primary source of local air pollution, which can be reduced by improving the adoption of existing technologies to efficiently capture particulates, sulphur and nitrogen oxides. Methane emissions from  coal  mining  represent  an  additional  environmental  concern,  with  difficulty measuring them in open pit mining.

ASEAN member states have set out a range of long-term energy transition and emissions reduction objectives in their Nationally Determined Contributions, which are expected to influence future coal demand and investment patterns. Transition pathways vary considerably between ASEAN countries, reflecting differences in resource endowments, energy systems and development priorities. In this section we explore the ambitions and challenges of the six largest coal consumers in the region, with impacts on their coal phase-out plans.

Indonesia has committed to reach net zero by 2060 or earlier. This presents some challenges  as  coal  is  expected  to  remain  important  for  both  the  power  and industrial  sectors,  particularly  for  nickel  processing.  Coal  is  also  an  important provider  of  jobs,  as  well  as  state  revenues  through  taxes  and  royalties.  Some regions in Indonesia, such as East and South Kalimantan, are among the most coal-dependent regions in the world.

Different  transition  pathways  involve  different  risk  profiles.  The  expansion  of renewable  energy  is  an  important  pathway,  while  its  large-scale  deployment requires  extensive  investment  in  generation  assets,  transmission  infrastructure and  energy  storage.  In  addition,  as  a  result  of  the  dependence  of  those technologies on critical mineral supply chains, energy security risks may shift from fuel supply chains to technology and material supply chains during the transition process.  On  the  other  hand,  greater  reliance  on  natural  gas  may  increase exposure to international fuel markets. These risks should be assessed alongside the risks associated with continued coal use while reducing its emissions footprint, through  efficiency  and  flexibility  upgrades,  biomass  or  hydrogen  co-firing,  fuel switching, methane abatement, and CCUS.

In 2021 Viet Nam announced its target to reach net zero by 2050. The country's updated Power Development Plan VIII foresees no new coal-fired power plants being built  after  2030,  coal  capacity  being  capped  at  31 GW  (from  the  current 28 GW) and plants that exceed 40 years of operation being closed if they cannot be converted into clean fuels, such as hydrogen or ammonia.

Malaysia is committed to achieving net zero by 2050. This requires a dramatic reduction in the coal-fired share of power generation, from over 50% today to near zero. In principle, coal-fired power plants in Malaysia will be retired as their PPAs expire, the first in 2029 and the last in 2044. This signal provides predictability and sufficient time to prepare substitution. The period from 2028 to 2033 needs to be prepared properly, as coal-fired power generation is set to halve in five years.

While the Philippines has not set a formal net zero emissions target, it has set a target to increase renewables' share of generation to 35% by 2030 to reduce its greenhouse gas footprint. The country has also introduced policies to limit the development  of  additional  coal-fired  generation  beyond  those  already  under construction.

In October 2025, Thailand moved its net zero target to 2050, 15 years earlier than the  previous  2065.  The  country,  with  only  6 GW  of  coal  plants  in  operation accounting for 15% of total generation, is well placed to remove coal-fired power generation from the electricity mix.

Cambodia has had a moratorium on new coal-fired power plants beyond those already approved up to 2021, and a coal-fired power plant sited near Botum Sakor National Park was cancelled in 2023, to be replaced by an LNG plant.

Several ASEAN  member  states, including Indonesia, Viet Nam and the Philippines, are also participating in international initiatives designed to support energy transitions, including Just Energy Transition Partnerships (JETPs) aimed at  accelerating  investment  in  cleaner  energy  technologies  and  power  system development, and the Energy Transition Mechanism aimed at achieving an early phase-out of coal-fired plants. Some components of these initiatives have faced funding challenges.

## Coal security assessment

Coal security risks differ significantly between ASEAN member states. The region remains a major coal producer and net exporter overall, but this position is heavily shaped by Indonesia's dominant role in regional production and exports. Several ASEAN  member  states  remain  highly  dependent  on  imported  coal  for  power generation, while demand for metallurgical coal and coal-based industrial energy is  expected  to  grow  in  selected  markets.  This  assessment  focuses  on  three dimensions of the energy security assessment framework most relevant to coal: supply-side security, demand-side readiness, and exposure to economic and price risk. In contrast to the other thematic chapters, for coal the demand-side readiness section addresses the longer-term issue of the transition towards a net zero future. This reflects coal's status as the most carbon-intensive fuel.

## Supply-side security

ASEAN's coal supply-side risks are defined by member states' ability to access sufficient coal supplies at an affordable price. ASEAN is a net exporter of coal, and so its supply-side risks are shaped less by aggregate regional scarcity than by concentration, trade dependency and fuel-specific differences between thermal and metallurgical coal.

Indonesia provides the bulk of regional coal output and is the main supplier for several ASEAN importers. While coal is generally a liquid and globally traded fuel, this concentration creates a regional vulnerability if Indonesian  supply  is constrained, domestic demand rises sharply or export restrictions are introduced during  periods  of  market  stress.  For  instance,  as  Indonesia  is  the  dominant supplier for ASEAN thermal coal importers, policies set in Indonesia relating to licensing  and  permitting  requirements,  production  quotas  and  the  Domestic Market  Obligation  can  all  have  an  impact  on  coal  supplies  for  importers. Additionally, transport disruption caused by meteorological events, such as low river levels, can create supply risks.

For  thermal  coal,  the  main  security  challenge  is  therefore  not  the  absence  of regional resources, but the dependence of several ASEAN member states on a limited set of suppliers and logistical routes. Cambodia, Malaysia, the Philippines, Thailand and Viet Nam are all net importers, mainly for power generation. Their exposure differs according to the role of coal in their power mix, the availability of domestic alternatives, port and stockyard capacity, supplier concentration, coal dependency among end-use sectors, and the flexibility of power systems to switch to other fuels or generation sources during disruption.

Metallurgical  coal  presents  a  more  specific  vulnerability.  ASEAN  has  limited coking  coal  resources,  which  are  mainly  concentrated  in  Indonesia,  while metallurgical  coal  demand  is  expected  to  grow  with  steelmaking  and  metals processing  in  Indonesia,  Malaysia,  Viet Nam  and,  potentially,  the  Philippines. Current procurement is diversified across at least five external suppliers, including Australia,  Canada,  Mozambique,  Russia  and  the  United  States,  and  no  one country supplies more than 50% of ASEAN's consumption. However, the strategic importance  of  metallurgical  coal  for  industry  warrants  continued  monitoring  of supplier  concentration,  contract  coverage,  transport  routes  and  stockholding practices to ensure supply security. Given the relatively low cost of storing coal and coke, strategic or commercial stockpiles can provide a practical buffer against temporary supply disruptions for both thermal and metallurgical coal.

## Demand-side readiness

Demand-side readiness for coal is defined here as the ability of the energy system to adjust in the face of disruption in a secure and resilient manner, reducing coal dependency without compromising electricity security or industrial output. Unlike oil, where short-term behavioural measures can temporarily reduce demand, coal demand in ASEAN is concentrated in power generation and industrial processes, where  short-term  demand  reduction  options  are  more  limited.  This  makes advance planning especially important, as different pathways carry different types of risks and timelines. For instance, large-scale renewable deployment requires grid and flexibility upgrades, greater reliance on natural gas can increase exposure

to international fuel markets, and CCUS  development carries financing challenges. Thus, the question is not necessarily which pathway is chosen, but ensuring the transition is achieved in a secure, resilient and orderly manner.

The most important fuel-switching challenge is managing the transition away from coal while maintaining secure and affordable electricity supply. Several ASEAN member states, including Indonesia, Malaysia and Viet Nam, have adopted net zero targets or long-term decarbonisation objectives. Achieving these goals will require  coal  plant  retirement,  reduced  utilisation,  conversion  or  retrofitting  with technologies such as CCUS where feasible.

In ASEAN member states with large and relatively young coal fleets, premature retirement  without  sufficient  replacement  capacity  could  create  risks  if  power system adequacy is not properly addressed, particularly as building new power generation capacity and expanding the electricity grid can face extended timelines. It can also increase reliance on imported fuels if coal is replaced with gas, or raise electricity  costs  in  particular  if  the  non-depreciated  coal  assets  need  to  be recovered.

The risk of stranded assets is particularly relevant in Indonesia and Viet Nam, where substantial coal-fired capacity has been added since 2015 and many plants have remaining technical and economic lifetimes extending well beyond current transition timelines. An ACE study found that around 30 GW of coal-fired capacity could  be  at  risk  of  becoming  stranded  by  2055  under  a  scenario  with  greater renewable energy deployment and carbon pricing. While the age profile of the ASEAN coal fleet suggests that a large share of plants will be more than 25 years old  by  2040,  early  retirement  will  nevertheless  require  careful  planning.  This includes mobilising appropriate financing mechanisms to recover non-depreciated assets while co-ordinating replacement capacity, grid expansion, system flexibility and the timing of investments in renewable energy, storage, transmission and, where appropriate, other dispatchable resources. In some cases, repurposing or co-firing existing coal assets with lower-emission fuels may provide an alternative pathway  to  reducing  emissions  while  limiting  the  risk  of  stranded  assets  and supporting system reliability.

Industrial  coal  demand  also  requires  forward-looking  demand-side  planning, particularly  with  the  growth  of  nickel  processing-linked  captive  coal  power  in countries such as Indonesia. In nickel processing, coal-based captive power and coal-intensive processing routes currently provide reliable and low-cost energy for industrial production, albeit with high emissions. The dominant rotary kiln electric furnace route relies heavily on coal for process heat, metallurgical use and reliable captive power generation. This creates a structural source of coal demand that may persist even as grid-connected power systems decarbonise.

However, continued reliance on these assets may raise future transition costs, complicate net zero pathways and create export risks if importing ASEAN member

states  apply  stricter  sustainability  standards  to  nickel  supply  chains.  ASEAN governments can reduce these risks by encouraging cleaner power supply and industrial planning for industrial clusters, assessing  alternative processing technologies such as high-pressure acid leaching where appropriate, and avoiding further lock-in of captive coal infrastructure where lower-carbon options are viable.

## Exposure to economic and price risk

Coal  price  and  affordability  risks  vary  across  ASEAN  depending  on  whether member states are producers, exporters, importers or large consumers. Importdependent ASEAN member states are exposed to international coal price volatility, freight costs and currency movements, particularly where coal plays a major role in electricity generation. At the same time, coal exporters and producers face risks from  changing  global  demand,  evolving  environmental  standards  and  policy measures that may affect future trade and investment.

Domestic coal pricing policies can support affordability and supply security, but they  can  also  create  unintended  risks  if  they  weaken  producer  incentives. Indonesia's Domestic Market Obligation and regulated domestic coal prices have helped  shield  the  power  sector  from  international  price  volatility,  but  such mechanisms need careful design and periodic review. If regulated prices are set too  low  or  procurement  mechanisms  are  insufficiently  flexible,  producers  may have weaker incentives to supply the domestic market, increasing potential risk of shortages, load-shedding or emergency interventions.

The June 2026 load-shedding and rolling blackouts in Indonesia highlighted the importance of maintaining capacity adequacy, reliable fuel supply arrangements, adequate stockpiles and sufficient flexibility in procurement and logistics systems to respond to unexpected disruptions. While the causes of such events can be multifaceted, they underscore the need to ensure that domestic pricing and supply arrangements remain compatible with secure and reliable electricity provision. As the largest supplier in ASEAN, domestic shortages or changes in export policy can therefore  affect neighbouring  countries  that  rely  on  Indonesian  coal.  This underlines the need for transparent market monitoring, early warning mechanisms and regional co-operation to avoid abrupt measures that could amplify supply risks across the ASEAN region.

More broadly, coal security policies need to balance affordability, reliability and transition risks. Broad  price  controls  or  untargeted  subsidies  may  protect consumers in the short term, but can distort investment and supply incentives if maintained  for  too  long.  A  more  resilient  approach  would  combine  targeted affordability measures, transparent pricing and procurement frameworks, adequate  stockholding  at  power  plants  and  industrial  facilities,  and  transition planning that reduces exposure to coal price volatility over time.

## Electricity and renewables security review

Southeast Asia's electricity systems are undergoing rapid transformation, driven by rising electrification and rapid demand growth, changing generation mixes with increased penetration of variable renewable energy (VRE) and distributed energy resources,  and  evolving  market  structures.  The  share  of  electricity  in  final consumption  has  been  rising across the region, with electricity currently accounting for 23% of final consumption, higher than the global average. Ensuring secure, reliable and affordable electricity supply is becoming increasingly vital as systems expand and integrate new technologies while transitioning away from fossil-fuel generation.

## Electricity demand

The  ASEAN  region  has  experienced  some  of  the  world's  fastest  growth  in electricity demand, with an average annual increase of 6% since 2015. In 2024, regional electricity demand increased sharply by 8.6%, before easing to close to 3% in 2025 as milder weather and slower economic growth moderated electricity consumption. Indonesia accounts for around one-third of total electricity consumption in the region and is also the largest contributor to demand growth. Electricity use is currently concentrated in industry and buildings, with transport electrification still at an early stage. However, national targets and plans across the region emphasise the electrification of transport as a core pillar of long-term energy and climate strategies. For example, transport electrification is promoted in  the  APEC  2026-2030  as  well  as  in  Malaysia's  National  Energy  Transition Roadmap.

## Electricity supply

On the  supply  side,  despite  strong  growth  in  renewable  energy  over  the  past decade, coal remains the backbone of ASEAN's power system, providing nearly half of total electricity generation. Coal accounted for around 70% of generation in Indonesia, almost 60% in the Philippines and nearly 50% in Viet Nam. The coal fleet is relatively young, with an average age of around 15 years, implying limited retirements  in  the  near  term.  Natural  gas  also  plays  a  central  role  in  several ASEAN  member  states,  particularly  in Brunei Darussalam,  Singapore  and Thailand. Hydropower dominates the generation mix in Lao PDR and contributes substantially in Cambodia, Myanmar and Viet Nam.

While hydropower remains the dominant renewable resource in the region, solar PV has driven most renewable capacity expansion in recent years. Installed solar capacity reached nearly 38 GW in 2025, more than 15 times the capacity installed a decade ago. This deployment of variable renewables remains concentrated in a few members states, with only Viet Nam exceeding 10% in its generation mix. However, with a technical potential for utility-scale solar PV and wind estimated at around 20 TW, there is significant scope to expand these resources.

## Power generation mix by fuel and total power generation in ASEAN by country, 2025

<!-- image -->

IEA. CC BY 4.0.

Notes: Other includes manufacturing gases, chemical heat, industrial waste, non-renewable municipal waste and any other non-specified. TWh = terawatt hours. Three-letter country codes: BRN = Brunei Darussalam; KHM = Cambodia; IDN = Indonesia; LAO = Lao PDR; MYS = Malaysia; MMR = Myanmar; PHL = Philippines; SGP = Singapore; THA = Thailand; VNM = Viet Nam. No data available for Timor-Leste.

## Electricity markets

Power  sector  structures  in  the  ASEAN  region  range  from  vertically  integrated utilities to liberalised  market  frameworks,  creating  different  implications  for ensuring  reliable  and  affordable  electricity  supply.  Most  member  states  apply least-cost  or  merit  order  dispatch  principles,  although  the  implementation  and transparency  of  these  mechanisms  vary  depending  on  market  structure  and institutional arrangements. In vertically integrated systems, centralised planning and  procurement  can  support  resource  adequacy  by  allowing  governments  or utilities to co-ordinate generation investment with expected demand, but may also reduce competitive pressure and weaken incentives for efficient operation and investment. In more liberalised markets, competition can strengthen price signals and  support  efficient  short-term  dispatch  and  investment  decisions,  although ensuring adequate capacity and managing price volatility can require separate market and regulatory arrangements.

In several member states, including Thailand, Indonesia and Viet Nam, dispatch decisions are influenced by contractual obligations such as PPAs and fuel offtake

contracts.  Where  contracted  generation  is  not  aligned  with  demand  or  system needs,  this  can  sometimes  lead  to  oversupply  situations  and  limit  operational flexibility, resulting in uneconomic curtailment of VRE. The balance between longterm  contracting  and  exposure  to  market  signals  is  therefore  an  important consideration for both system security and the cost of electricity supply.

By  contrast,  the  Philippines  and  Singapore  operate  competitive  wholesale electricity  markets  based  on  market  bidding.  These  systems  feature  relatively short  dispatch  intervals,  five minutes  in  the  Philippines  and  thirty minutes  in Singapore,  with  gate  closure  close  to  real  time.  Both  countries  have  also developed mechanisms to procure ancillary services. For example, the Philippines launched  an  ancillary  services  market  in  2024  to  complement  the  contracted capacity procured through the Ancillary Service Procurement Agreement.

These  market-based  arrangements  can  improve  operational  efficiency  and provide  stronger  price  signals,  but  they  do  not  necessarily  translate  into  lower electricity prices for consumers. The Philippines and Singapore also have among the  highest  electricity  prices  in  ASEAN,  reflecting  a  combination  of  market conditions, fuel costs, import dependency, network charges and other policy costs.

## Market frameworks and key system operation practices of ASEAN member states

|                   | Market structure                  | Procurement of system services   | Dispatch interval   | Gate closure           |
|-------------------|-----------------------------------|----------------------------------|---------------------|------------------------|
| Brunei Darussalam | Vertically integrated             | No formal market                 | 60 min              | N/A                    |
| Cambodia          | Single buyer                      | No formal market                 | 60 min              | N/A                    |
| Indonesia         | Single buyer                      | No formal market                 | 60 min              | N/A                    |
| Lao PDR           | Single buyer                      | No formal market                 | 60 min              | N/A                    |
| Malaysia          | Single buyer                      | No formal market                 | 30 min              | N/A                    |
| Myanmar           | Single buyer                      | No formal market                 | 60 min              | N/A                    |
| Philippines       | Liberalised market                | Market + contract                | 5 min               | 9 min ahead            |
| Singapore         | Liberalised market                | Market + contract                | 30 min              | 65 min before dispatch |
| Thailand          | Single buyer                      | No formal market                 | 30 min              | N/A                    |
| Timor Leste       | Vertically integrated             | No formal market                 | 60 min              | N/A                    |
| Viet Nam          | Single buyer + retail competition | No formal market                 | 30 min              | N/A                    |

Notes: Dispatch interval refers to a given time interval in which generators are scheduled to operate. For market-based systems, the dispatch interval determines how often the market operator clears bids and schedules generation. In nonliberalised markets, the dispatch interval refers to the period during which system operators issue dispatch instructions to generators.  However,  they  may  redispatch  at  any  desired  time  according  to  system  needs.  Gate  closure  timing  is  only applicable to liberalised markets. N/A = not applicable.

Source: IEA (2025), Integrating Solar and Wind in Southeast Asia.

Market structures are also evolving in the region. At a regional level, the expansion of multilateral power trading through the ASEAN Power Grid (already operational between Lao PDR, Thailand, Malaysia and Singapore) is a chance to broaden access  to  electricity  markets  and  improve  the  ability  of  system  operators  and market  participants  to  respond  to  changing  system  conditions.  Viet Nam  is progressively developing more  competitive wholesale and  retail electricity markets, including through its direct power purchase agreement framework and ongoing  review  of  competitive  market  design.  Thailand  is  considering  greater competition in electricity supply through third-party access and wheeling arrangements, while Malaysia is introducing greater short-term competition within its single-buyer model through the New Enhanced Dispatch Arrangement, which allows generators without long-term PPAs to participate in electricity supply.

## Five-year outlook

## Demand

Electricity demand in Southeast Asia is projected to continue expanding rapidly, growing at an average annual rate of 5.4% during 2026-2030, driven by rising demand for cooling, data centres and industry. Indonesia is expected to drive the largest  share  of  this  growth,  accounting  for  about  40%  of  additional  electricity demand over the period. Viet Nam is projected to account for 26% of demand growth, followed by Thailand and Malaysia at 8%, and the Philippines at 7%.

## Supply

On the supply side, coal-fired generation is forecast to increase at an average annual rate of around 4% during 2026-2030. Despite this growth, coal's share in the electricity mix is expected to decline slightly over the outlook period. Gas-fired generation is expected to expand by 5% per year on average through to 2030, slower than previously anticipated before the Hormuz crisis.

Renewable generation is expected to expand at a strong pace as ASEAN member states  accelerate  the  deployment  of  wind  and  solar  PV.  Wind  generation  is projected to grow by around 26% annually, while solar PV is expected to increase by about 23% per year over the forecast period. As a result, the combined share of wind and solar PV in the electricity mix is expected to rise from around 5% in 2025 to 11% by 2030. Hydropower will remain the dominant renewable resource in the region, although its share of total renewable generation is projected to fall to below 50% by 2030 as wind and solar PV expand.

## Electricity generation change in ASEAN and selected ASEAN member states, 2025-2030

<!-- image -->

IEA. CC BY 4.0.

Note: ASEAN data do not include Timor-Leste due to lack of available data.

The  outlook  remains  sensitive  to  fuel  market  and  geopolitical  developments, including those in the Middle East. Continued reliance on imported LNG and coal for power generation means that disruption to fuel supply chains or international fuel  prices  could  affect  generation  costs  and,  depending  on  market  and  tariff structures, wholesale electricity prices and retail tariffs over the outlook period. These risks are likely to be more pronounced in gas-reliant systems and those with wholesale electricity market exposure, where changes in fuel costs can be reflected more quickly in electricity prices. While the baseline outlook points to continued growth in both fossil fuel and renewable generation, fuel market volatility could  affect  the  cost,  affordability  and  reliability  implications  of  this  expansion, particularly in systems with high import dependency.

## Electricity security assessment

Electricity  security  is  the  electricity  system's  capability  to  ensure  uninterrupted availability  of  electricity  by  withstanding  and  recovering  from  disturbances  and contingencies. The ASEAN region is facing a widening set of electricity security challenges  due  to  a  tightening  supply  and  demand  balance,  changes  in  the generation mix with more VRE, and constrained electricity networks. The region is  also  becoming  increasingly  reliant  on  imported  LNG  and  coal  for  power generation, as outlined in the previous chapters, which exposes it to fuel supply disruption and price volatility. At the same time, cybersecurity threats and more frequent climate-related events such as droughts and heavy storms are already affecting system security. These trends create complex policy trade-offs between maintaining reliability and affordability while advancing emissions reduction and renewable energy deployment.

Electricity security should be assessed across several dimensions of the energy security assessment framework. Supply-side security depends on the adequacy of the systems to meet rising demand, including sufficient availability of generation and grids (including interconnections). Demand-side readiness depends on the ability  to  manage  peak  loads,  improve  efficiency  and  mobilise  demand-side flexibility  as  electrification  expands;  this  is  assessed  in  the  chapter  on  Energy efficiency and demand-side management. Exposure to economic and price risk is shaped by fuel import dependency, power sector cost recovery, tariff design and investment needs. System resilience depends on the ability of power systems to absorb  and  recover  from  disruptions,  including  extreme  weather  events  and infrastructure failures, and the flexibility of the system to accommodate solar and wind  generation.  Emergency  planning  requires  clear  operational  procedures, reliable data,  effective  system  operation  and  regional  co-operation.  These dimensions highlight the need for integrated electricity security planning, stronger grid  and  flexibility  investment,  and  greater  attention  to  climate  resilience  in infrastructure and system operation.

## Supply-side security

## System adequacy

In electricity systems, a key dimension of supply-side security is system adequacy, which refers to the system's ability to meet all levels of demand under normal operating conditions. Adequacy assessment is forward-looking and a key part of power system planning to identify potential reliability risks and inform investment decisions.  The  metrics  used  for  adequacy  assessment  can  be  grouped  into two broad  categories:  deterministic  metrics  such  as  reserve  margin, 5 and probabilistic  metrics  including  loss  of  load  probability  (LOLP),  loss  of  load expectation  (LOLE)  and  expected  energy  not  served  (EENS). 6  These  metrics provide some information on the likelihood of lost load and primarily give a signal as to whether the system has sufficient capacity.

Most ASEAN member states continue to rely primarily on traditional deterministic reserve  margin  metrics  for  reliability  targets.  In  several  countries,  including Indonesia and Brunei Darussalam, reserve margin criteria are often set well above international standards, which can result in overinvestment in generation capacity. However,  as  power  systems  become  more  complex,  driven  by  increased uncertainty in demand and supply and an increasing share of VRE, there is a growing trend towards probabilistic metrics to capture system risk and extreme

5 Reserve margin is the available capacity margin expressed as a percentage of peak demand.

6 LOLP is the probability that supply will be insufficient to meet demand during a given timeframe (hr/year). LOLE is the expected duration that demand will not be met (hr/year). EENS is the magnitude of unserved energy (MWh).

conditions. A number of countries, including Malaysia, Singapore, Thailand and Viet Nam,  have  already  adopted  or  are  moving  towards  probabilistic  reliability criteria as part of their adequacy assessment.

Power system reliability metrics and criteria in ASEAN

| Country           | Metrics and criteria                                                                              |
|-------------------|---------------------------------------------------------------------------------------------------|
| Brunei Darussalam | Reserve margin: 45%                                                                               |
| Cambodia          | Reserve margin: 20%                                                                               |
| Indonesia         | Reserve margin: 35% for Java-Bali LOLP: 1 day/year                                                |
| Lao PDR           | Reserve margin: 15%                                                                               |
| Malaysia          | Peninsular Malaysia reserve margin: 25% (20% in 2037); LOLP: 1 day/year Sabah reserve margin: 35% |
| Myanmar           | Reserve margin: 15% (20% from 2027)                                                               |
| The Philippines   | Reserve margin: 25%                                                                               |
| Singapore         | LOLH: 3 hours/year; reserve margin 27%                                                            |
| Thailand          | Reserve margin 15% (moving to LOLP: 0.7 day/year)                                                 |
| Timor-Leste       | No data                                                                                           |
| Viet Nam          | LOLE: 12 hours/year Reserve margin: 15%                                                           |

Source: ACE (2026), AIMS III Phase 3 - Integrated Resource and Resilience Planning.

The diversity of reliability metrics and criteria across ASEAN reflects differences in  system  characteristics  and  planning  practices.  No  single  assessment  or indicator  can  provide  a  complete  picture  of  electricity  security.  While  system adequacy assesses whether sufficient resources are expected to be available to meet demand, it does not have a direct link with actual quality of electricity service experienced  by  consumers.  A  system  with  a  high  reserve  margin  may  still experience frequent power outages.

System  average  interruption  frequency  index  (SAIFI)  and  system  average interruption  duration  index  (SAIDI)  reflect  the  quality  of  electricity  services  by measuring the frequency and duration of interruptions experienced by consumers. Network reliability varies widely across the region. Singapore records among the lowest  interruption  frequency  and  duration  globally,  as  reflected  in  SAIFI  and SAIDI indicators. Cambodia, Lao PDR and Myanmar experience more frequent and  longer electricity supply interruptions, pointing to persistent reliability challenges  due  a  combination  of  generation,  transmission  and  distribution disruption.

## System average interruption duration index and system average interruption frequency index in ASEAN, 2020

<!-- image -->

IEA. CC BY 4.0.

Notes: BRN = Brunei Darussalam; KHM = Cambodia; IDN = Indonesia; LAO = Lao PDR; MYS = Malaysia; MMR = Myanmar; PHL = the Philippines; SGP = Singapore, THA = Thailand; VNM = Viet Nam; SAIDI = system average interruption duration index; SAIFI = system average interruption frequency index.

Source: IEA analysis based on data from the World Bank archive (2020), Doing Business (Getting Electricity) (accessed 29 April 2026).

## System resilience

Climate-related  disruption  is  emerging  as  one  of  the  region's  main  electricity security risks, impacting every segment of the electricity system and potentially leading  to  large-scale  outages.  Southeast  Asia  is  among  the  regions  most exposed to extreme weather events and its energy infrastructure is particularly vulnerable  to  weather-related  hazards.  More  frequent  and  intense  heatwaves, floods,  droughts  and  tropical  cyclones  have  had  significant  impacts  on  the electricity system through increased peak demand, lower power plant performance,  reduced  hydropower  availability  and  physical  damage  to  grid infrastructure.

Electricity  grids  are  among  the  most  climate-vulnerable  elements  of  power systems and a leading source of climate-related outages in the region. Around 20% of  electricity  grids  in  Southeast  Asia  face  the  threat  of  tropical  cyclones. Several  countries  have  experienced  major  disruption  associated  with  extreme weather events in recent years. Tropical cyclones have caused major outages in Viet Nam and the Philippines by damaging electricity networks; severe flooding and  storm-related  events  have  disrupted  power  supplies  in  Indonesia;  and droughts and heatwaves have contributed to power supply shortages in Cambodia and Lao PDR.

A s disruptions become more frequent and severe, electricity systems will need to be more resilient and able to absorb, accommodate and recover from both shortterm shocks and long-term changes. This can be done with procedures including reserve management, emergency operating procedures, load shedding arrangements, special protection schemes and system restoration plans.

## Selected major supply disruptions in Southeast Asia

| Country   |   Year | Key factors       | Extent of outages                                                                                                                                   |
|-----------|--------|-------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------|
| Viet Nam  |   2024 | Tropical cyclones | • Damage to power plants and electricity grids with estimated costs of nearly USD 33 million • Supply disruption to more than 6.4 million customers |
| The       |   2021 | Tropical cyclones | Philippines Mindanao                                                                                                                                |
| 2019-     |   2020 | Drought           | Cambodia unavailability of • Disruption to 41%                                                                                                      |
| Lao PDR   |   2024 | Drought           | • Power outages as 26 hours                                                                                                                         |
| Indonesia |   2026 | Storm             | transmission line                                                                                                                                   |

Sources: ACE (2025), Before the next dry season; Lao News Agency (2024), Laos urges consumers to conserve electricity.

Strengthening  electricity  grids  also  plays  a  key  role  in  enhancing  system resilience.  Beyond  climate-related  risks,  electricity  grids  in  several  ASEAN member  states  also  face  challenges  with  congestion  and  bottlenecks,  which present electricity security risks. Grid infrastructure development in the region is not  keeping  pace  with  electricity  demand  growth  and  renewable  deployment. Viet Nam  has  experienced  grid  congestion  in  transmission  and  distribution networks,  leading  to  renewable  curtailment  as  solar  and  wind  capacity  has expanded much faster than grid infrastructure. The Philippines faces transmission bottlenecks  between  generation-rich  areas  and  major  demand  centres,  interisland constraints and dependence on submarine cable infrastructure. Lao PDR faces limitations on its domestic grids and the need to strengthen its transmission backbone to improve system reliability and maximise utilisation of its hydropower resources. For Timor-Leste, the medium-voltage distribution networks have been

the  primary  source  of  outages,  with  ongoing  upgrades  to  substations,  network automation, digitalisation and a transition away from radial network structures. 7

The rapid expansion of data centres is adding a further emerging challenge for grid resilience. Data centre electricity demand in Southeast Asia is expected to more than double between 2025 and 2030, with much of this growth concentrated in regional hubs. Their large and geographically concentrated loads can require significant  additions  to  local  generation  and  network  capacity,  while  their  high reliability requirements leave limited tolerance for supply interruptions. In Singapore, where data centres already account for a sizeable share of electricity demand, continued expansion requires additional power supply and grid capacity, alongside access to low-emissions sources as new tenders for data centres have minimum  requirements for clean electricity procurement. As data centre development accelerates across the region, insufficiently planned network and generation investment could create localised capacity and congestion constraints, while increasing competition for affordable and clean electricity.

More  broadly,  ageing  grid  infrastructure  in  the  region  will  require  substantial investment to expand and modernise networks, both to keep pace with growth in renewables and demand, and to withstand impacts related to climate change. A meshed grid topology, particularly around major generation and demand centres, can offer flexibility with multiple paths for power flows, enhancing redundancy by adding extra backup layers in case of failure, and reducing the impact of localised outages.  Annual  investment  in  grids  and  storage  in  the  region  will  need  to substantially  increase  to  meet  announced  targets,  reaching  USD 30 billion  by 2035 from USD 13 billion today.

## Solar PV and wind supply chains

The ASEAN region is one of the world's largest solar PV manufacturing bases and is the only major manufacturing hub outside China with production capacity across the entire value chain. In 2025, regional manufacturing capacity exceeded 80 GW for modules, 85 GW for cells, 55 GW for wafers and 16 GW for polysilicon. The region  is  particularly  important  for  wafer  production,  representing  the  largest manufacturing  centre  outside  China.  Manufacturing  capacity  is  concentrated primarily in Malaysia, Thailand, Viet Nam and, increasingly, Indonesia.

Regional manufacturing capacity substantially exceeds domestic demand for solar PV equipment. Most production facilities were developed to serve export markets, particularly  the  United States,  making  ASEAN  an  important  contributor  to  the geographical  diversification  of  global  solar  PV  supply  chains.  The  region  has

7 The information on grids in Lao PDR, the Philippines and Timor-Leste was gathered during country consultations.

benefited from competitive manufacturing costs, established industrial ecosystems and favourable trade access, attracting substantial investment from international manufacturers over the past decade.

Note: GW = gigawatts

Source: IEA (2025), Renewables 2025.

<!-- image -->

ASEAN manufacturing capacity is expected to remain broadly stable through to 2030. Production capacity for cells, wafers and polysilicon is projected to remain close to current levels, while module manufacturing capacity is expected to decline moderately  as  manufacturers  relocate  part  of  their  production  in  response  to evolving  international  trade  policies  and  import  restrictions,  particularly  in  the United States.

Overall, ASEAN is among the world's most secure regions in terms of solar PV supply  chain  self-sufficiency.  Existing  manufacturing  capacity  is  sufficient  to supply projected regional demand across modules, cells and wafers throughout the forecast period. Only polysilicon production could become a limiting factor by 2030, with regional demand expected to exceed domestic manufacturing capacity as solar PV deployment accelerates.

However, manufacturing ownership remains highly concentrated. Approximately 70% of module manufacturing capacity, 55% of cell production and almost 80% of wafer manufacturing are owned by Chinese companies. While these facilities are physically  located  within  ASEAN,  the  concentration  of  ownership  may  create vulnerabilities through dependence on foreign investment decisions, technology transfer and corporate supply chain strategies.

The security of wind turbine supply chains is considerably weaker than for solar PV. Of the main wind turbine components, ASEAN currently has manufacturing

capacity  only  for  towers,  with  annual  production  estimated  to  be  equivalent  to approximately 40 GW of wind capacity, expected to increase to close to 50 GW by 2030. These facilities are located primarily in Viet Nam and largely serve export markets  rather  than  regional  deployment.  As  a  result,  ASEAN  remains  almost entirely dependent on imported equipment for other major turbine components nacelles and blades - limiting supply chain resilience and reducing opportunities for local industrial value creation.

This  dependency  has  had  limited  implications  to  date  because  regional  wind deployment  has  remained  modest,  averaging  less  than  1 GW  annually  since 2021. However, wind installations are expected to accelerate significantly during the second half of this decade, reaching almost 8 GW per year by 2030 as more ASEAN member states introduce competitive procurement schemes and expand renewable energy targets.

Without corresponding investment in domestic manufacturing capabilities, growing  wind  deployment  will  increase  reliance  on  imported  equipment  and associated exposure to global supply chain disruptions.

## Exposure to economic and price risk

Electricity security is ASEAN is closely linked to exposure to imported fossil fuels, particularly natural gas and oil, which can transmit international fuel-price volatility into  electricity  costs.  The  degree  of  exposure  varies  across  the  region,  but  is particularly  high  in  countries  that  rely  heavily  on  imported  fuels  for  power generation.  Singapore,  for  example,  imports  the  natural  gas  that  accounts  for around 95% of its electricity generation, while the share exceeds 60% in Thailand. Exposure can also increase temporarily when domestic resources are constrained,  such  as  during  Viet Nam's  dry  season,  when  lower  hydropower output increases reliance on thermal generation.

The recent disruption affecting the Strait of Hormuz illustrates how exposure to imported fuels can translate into electricity price pressures. The effects have been most apparent in the two Southeast Asian countries with wholesale spot electricity markets,  the  Philippines  and  Singapore.  In  the  Philippines,  higher  fuel  costs significantly increased prices in its wholesale electricity spot market, prompting the government to suspend the market on 26 March as part of a series of emergency measures to  address  energy  supply  risks  and  price  volatility.  An  administered pricing mechanism was introduced before market operations resumed on 1 May. In Singapore, wholesale electricity prices generally increased after the start of the conflict,  in  line  with  the  increase  in  gas  prices.  Although  long-term  contracting arrangements  limit  the  spot  price  impact  on  Singapore's  consumers,  these increases have fed through to end-user prices with a lag, with a 17% increase in the regulated tariff announced for the July-September period.

The  economic  impact  of  fuel  price  shocks  also  depends  on  how  costs  are distributed between households, industry, utilities and governments. Across the region, subsidies and regulatory mechanisms  often limit pass-through to households, including through lifeline tariff programmes  in Thailand, the Philippines  and  Lao PDR,  or  subsidies  provided  to  small  businesses,  as  in Indonesia. These measures can protect vulnerable consumers, but may increase fiscal costs or shift costs between consumer groups, including to industrial users through cross-subsidisation.

In several countries, including Myanmar, the Philippines and Thailand, electricity bills already represent a substantial share of household incomes. This limits the scope for passing higher fuel and system costs through to consumers, even as utilities  need  sufficient  revenues  to  expand  and  modernise  electricity  systems. Governments  therefore  face  a  trade-off  between  preserving  affordability  and recovering  the  costs  required  to  maintain  reliable  supply  and  support  rising electricity  demand, with regulated retail tariffs currently often set below system costs.  The  appropriate  balance  will  depend  on  countries'  existing  affordability pressures,  subsidy  burdens  and  fiscal  space,  with  phased  tariff  increases  or concessional financing for system investments potentially needed where affordability constraints are greatest.

## Monthly electricity consumption and bills as a percentage of average household income in ASEAN, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes TWh = terawatt hours. BRN = Brunei Darussalam; KHM = Cambodia; IDN = Indonesia; LAO = Lao PDR; MYS = Malaysia; MMR = Myanmar; PHL = the Philippines; SGP = Singapore; THA = Thailand; VNM = Viet Nam; EU = European Union. No data available for Timor-Leste.

Source: IEA (2025), Integrating Solar and Wind in Southeast Asia.

Some  ASEAN  member  states  are  also  exploring  structural  measures  to  limit electricity  price  increases  for  end-use  consumers.  In  Thailand,  electricity  tariff

reforms  are  underway,  which  include  removal  of  public  levies  from  household electricity bills, differentiated tariffs for large consumers such as data centres and revised electricity rates for residential consumers.

Reducing reliance on imported fuels can provide a longer-term route to improving affordability.  Solar  PV  can  reduce  the  fuel  component  of  electricity  costs  by displacing  generation  from  imported  fossil  fuels.  In  Thailand,  several  solar  tax incentive programmes support residential and commercial deployment, such as income  tax  deductions  and  corporate  tax  exemptions.  In  Timor-Leste,  where virtually all electricity is generated from diesel, solar PV constitutes a central part of the country's strategy to diversify its power mix while maintaining affordability. The Hormuz crisis  has  also  accelerated  interest  in  solar  in  some  markets;  for example, the import value of panels into the Philippines increasing by 145% during the three months following the start of the crisis. However, the affordability benefits of solar will depend on how fuel savings translate into lower electricity costs for consumers,  including  through  tariffs  for  grid-supplied  consumers  and  avoided electricity purchases for self-consuming consumers, as well as how network and system integration costs are recovered.

## System flexibility

System flexibility 8 is critical to electricity security. It enables the system operator to maintain a continuous balance between electricity supply and demand, which is becoming less predictable because of increasing VRE penetration. There are four main sources of flexibility: power plants; electricity grids; energy storage; and demand response. In addition, accurate forecasting of generation and demand and enhanced operational rules are key measures to effectively integrate VRE and meet flexibility needs. While renewable forecasting accuracy has significantly improved, demand  forecasting is becoming increasingly challenging with increased  electrification  across  end-use  sectors.  In  most  systems,  flexibility resources  and  operational  arrangements  are  not  keeping  pace  with  evolving system requirements.

The IEA's phases of VRE integration framework provides a basis for identifying system-level  challenges  and  priority  measures  to  enable  the  secure  and  costeffective uptake of VRE according to the context of each country's power system. Radical  changes  to  manage  greater  variability  are  generally  not  required  until Phase 3.  From  now  until  2030,  most  ASEAN  member  states  are  expected  to remain in Phases 1 and 2, where VRE integration has minor to moderate impacts at the system level and remains manageable. Flexibility requirements can be met

8 Power system flexibility is the ability of a power system to reliably and cost-effectively manage the variability and uncertainty of supply and demand across all relevant timescales, from ensuring instantaneous stability of the power system to supporting long-term security of supply.

through improved operational practices and more efficient use of existing system assets,  particularly  conventional  generation  and  electricity  grids.  Viet Nam  is currently the only country in ASEAN in Phase 3, with around 13% of generation from VRE in 2024; it has been experiencing greater swings in the supply-demand balance, prompting the need for flexibility that goes beyond using existing assets and operational practices. As countries progress to Phase 3, the need emerges for fast-responding flexibility resources including battery storage and demand-side flexibility (see in the chapter on Energy efficiency and demand-side management).

## Phase assessment of VRE integration in ASEAN countries and comparison with higherphase systems, 2024 and 2030

<!-- image -->

IEA. CC BY 4.0.

Notes: VRE= variable renewable energy. The phase assessments for 2030 are based on the IEA's Renewables forecast (main case). The assessments are not based solely on VRE share of annual generation, but also include a set of indicators that evaluate a power system's ability to balance generation across multiple timescales. The methodology used is part of the IEA's phases of VRE integration assessment framework provided in the IEA Integrating Solar and Wind in Southeast Asia report. No data available for Timor-Leste.

As  the  share  of  VRE  increases,  ASEAN  member  states  are  adopting  various measures to increase system flexibility and ensure electricity security, including improved  renewables  forecasting,  system  operational  practices  and  rules  and market frameworks. Malaysia, the Philippines, Singapore, Thailand and Viet Nam have introduced sophisticated renewables forecasting systems to support costeffective and secure system operation with VRE. The Philippines and Singapore have the most advanced market frameworks in the region, which play a key role in meeting system flexibility needs across different time horizons, including short dispatch and settlement intervals, and ancillary service procurement mechanisms.

Beyond operational improvements, ASEAN  member  states are gradually diversifying  flexibility resources.  Hydropower  reservoirs  continue  to  provide seasonal and daily flexibility in Lao PDR, while battery energy storage systems are  playing  an  increasingly  important  role  in  Malaysia,  the  Philippines  and Singapore. At the distribution level, improving visibility and control of distributed energy resources, including rooftop solar PV, is becoming an emerging priority, particularly in the Philippines and Timor-Leste, with the need for greater real-time monitoring and operational control.

As the ASEAN region's power systems continue to evolve, investments in grids, flexibility resources and operational capabilities are expected to play a larger role in maintaining security of supply.

## Regional co-operation

Regional  co-operation  through  cross-border  interconnections  can  strengthen electricity security while reducing overall system costs and fossil fuel dependency. By linking power systems across large geographical areas, regional interconnections allow ASEAN member states to share renewable resources and flexibility  services.  This  can  help  manage  demand  fluctuations  and  extreme weather events, reduce vulnerability to supply disruptions and strengthen system resilience.

The  ASEAN  Power  Grid  (APG)  is  a  key  strategic  initiative  for  regional  power co-operation and electricity connectivity. It was first formalised through the APG memorandum of understanding (MoU) signed in 2007 and strengthened through the APG  Enhanced  MoU  in  2025  with  the  goal  of  accelerating  regional interconnectivity  and  multilateral  power  trade.  The  APG  is  also  one  of  the  key programme areas under the ASEAN Plan of Action for Energy Cooperation 20262030. The momentum behind the APG is building with several key milestones in 2025, including:  the  endorsement  of  the  terms  of  reference  for  the  Submarine Power  Cable  Development  Framework  and  the  ASEAN  Regional  Renewable Energy Certificate Framework; the launch of the APG Financing Initiative, with financing support of up to USD 12.5 billion announced by the World Bank and the Asian Development Bank; and the Lao PDR-Thailand-Malaysia-Singapore Power Integration Project entering Phase 2.

The scale and complexity of APG interconnectors are also set to increase as much of the project pipeline consists of subsea cable and grid-to-grid projects, areas where  the  region  has  relatively  limited  experience.  Around  USD 27 billion  of investment  will  be  required  between  2025  and  2040  to  deliver  the  pipeline  of projects proposed in the ASEAN Interconnection Masterplan Study III and other announced  interconnection  projects  -  a  14-fold  increase  compared  with  total interconnector investment in Southeast Asia since the 1970s. Realising the full

benefits of cross-border interconnection will also require domestic grid investment. This  underscores  the  importance  of  clear  implementation  responsibilities  and stronger regional co-operation, alongside credible financing structures.

## Priorities to support APG implementation

Realising the electricity security benefits of the APG will require enabling domestic conditions and effective co-operation arrangements among participating countries to support cross-border power  trade  and  move  the  APG  from  vision  to implementation.  These cover  governance,  regulatory  framework,  and  technical and commercial arrangements that participating countries should align in order to develop and operate cross-border interconnectors and undertake power trade.

Priority areas for co-operation arrangements to support cross-border power trade and the implementation of the APG include effective institutional co-ordination, transparent approaches to transmission tariff and wheeling charges, cross-border cost-benefit analysis and cost allocation, co-ordinated system planning, grid code interoperability  and  data  sharing. 9 These  arrangements  will  be  essential  to facilitate cross-border power trade, attract investment in regional interconnectors and enable the APG to fully contribute to electricity security in ASEAN.

9 The priority co-operation arrangements were identified from a survey and stakeholder consultations conducted as part of the 2026 Singapore - IEA Regional Training, involving ASEAN ministries, regulators, utilities and international partners.

## Energy efficiency and demand-side management

Energy  demand  in  the  ASEAN  region  is  expected  to  grow  by  2.6%  per  year through to 2035 if no new policy actions are taken, with electricity increasing at a faster  pace,  rising  by  around  4%  per  year,  as  a  result  of  increased  industrial activity, growing populations and higher incomes. The conflict in the Middle East has  exposed  the  region's  dependence  on  imported  fossil  fuels  to  cover  these growing  needs,  resulting  in  fuel  shortages,  rising  costs  and  disrupted  supply chains.  Governments  have  reacted  with  emergency  measures  to  reduce  the impact on consumers.

Energy  efficiency  can  become  a  key  pillar  of  ASEAN  member  states'  energy security strategy and help mitigate these risks by alleviating demand growth, thus reducing the reliance on fuel imports, improving grid reliability and acting as a buffer to supply shocks. Long-standing efficiency policies, such as building codes, performance standards and energy efficiency obligations, have contributed to a 20%  reduction  in  fossil  fuel  imports  across  major  IEA  economies  in  the  past 20 years. In ASEAN member states, while energy intensity progress has been slower, the energy savings achieved mean that imports today are around 10% lower than they otherwise would have been. This difference suggests that ASEAN member states have substantial scope to further reduce fuel imports and enhance energy security through accelerated energy efficiency improvements.

## Fuel imports in 2023 and annual avoided imports due to energy efficiency improvements since 2000

<!-- image -->

IEA. CC BY 4.0.

Notes: PJ = petajoules; Fuel imports are net of exports, marine bunkers and aviation bunkers. Savings in the Philippines comprise  industry  and  buildings  efficiency  progress.  Savings  in  Singapore  comprise  industry,  buildings  and  transport efficiency progress. Savings in Thailand comprise industry and buildings efficiency progress.

In  the  electricity  sector,  the  implementation  of  energy  efficiency,  demand-side response and flexibility measures can help reduce peaks and smooth demand profiles.  This  in  turn  increases  energy  system  resilience  and  contributes  to  a reduction  in  costs  by  lowering  required  capacity  reserves  and  avoiding  the operational costs of gas-fired peaking plants. Energy efficiency measures targeted towards electricity demand reduction can defer costly infrastructure upgrades and free up capacity for new users, at a lower cost compared with new supply and transmission infrastructure.

The 2026 energy crisis has prompted the implementation of an array of measures in  the  region  to  slash  energy  demand,  improve  energy  security,  and  relieve pressure  on  households  and  businesses.  Some  ASEAN  member  states  were among the first globally to respond with policy action at the onset of the crisis, as many were hardest hit by their high dependence on oil imports from the Middle East. Within a week of the crisis, the Philippines and Thailand had already taken action to reduce oil consumption. Responses globally and in the region included energy  conservation  measures  for  immediate  and  short-term  energy  demand reductions, structural measures to reduce energy intensity and achieve longerterm  energy  security  benefits,  and  consumer  price  support.  The  range  of measures implemented provides important lessons on the variety and breadth of options available. Fuel subsidies or increased subsidy budgets were among the more popular response measures. While subsidies can help to relieve pressure on  energy  bills,  when  untargeted  they  can  run  counter  to  energy  efficiency objectives  and  reduce  the  life  cycle  cost  advantages  of  energy  efficiency technologies.

## Common measures implemented in ASEAN in response to the 2026 energy crisis

| Energy conservation                                                                                                                                                                                                                                                                                       | Structural (energy efficiency, electrification, other)                                                                                                                                 | Price support                                                                                                                                                     |
|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Awareness campaigns asking energy consumers to save energy Encouraging working from home Efforts to limit private travel and promote use of public transport Limits on official travel and greater use of online meetings Transport restrictions Encouraging adjustment of cooling temperature set points | Scaling up energy efficiency programmes and measures Accelerating electrification, particularly in the transport sector Promoting electric cooking Encouraging renewable energy supply | Fuel tax cuts, fuel subsidies or increased subsidy budgets Fuel-price caps or stabilisation measures Targeted support to cushion households and vulnerable groups |

## Energy efficiency

Energy intensity, measured as the primary energy required per unit of economic output (GDP), has seen a slow improvement in ASEAN so far this decade, staying below  0.5%.  Average  progress  in  the  region  has  been  well  below  the  global average both in the period 2010-2019 and 2019-2025.

Current  trends  show  significant  potential  for  energy  efficiency  progress  in  the region  through  more  stringent  standards  for  appliances,  further  adoption  of building energy  codes,  increased  coverage  of  fuel  economy  standards  in transport,  the  promotion  of  energy  audits  and  energy  management  systems  in industry, and increased and smart electrification of end uses.

The energy efficiency potential is acknowledged across ASEAN member states in the region. Most have set energy intensity progress targets through to 2030 and 2040  that  are  generally  more  ambitious  than  current  trends.  Additionally,  an ASEAN efficiency target was established in the ASEAN Plan of Action for Energy Cooperation (APAEC) 2026-2030, aiming to achieve a 40% reduction in energy intensity based on total primary energy supply by 2030, compared with 2005. This target represents an average annual energy improvement target of over 4% per year for the rest of the decade.

## Average annual energy intensity progress in ASEAN, 2010-2019 and 2019-2025e

<!-- image -->

IEA. CC BY 4.0.

Source: IEA (2026), Energy Efficiency Progress Tracker.

A common barrier to realising this potential is access to finance, a critical enabler of energy efficiency progress. ASEAN member states have introduced a range of fiscal  measures  to  encourage  investment  in  energy-efficient  technologies  and practices. Expanding  and  refining these mechanisms  can  help  overcome

constraints, accelerate the deployment of efficiency and electrification measures, and strengthen energy security by moderating energy demand, reducing exposure to fuel price volatility and lowering reliance on imported energy.

## Policy landscape

## Buildings

Energy demand in buildings currently represents about 20% of total final demand in  the  region.  However,  population  growth  together  with  progress  in  energy access,  rising  living standards  and  higher  incomes  are  reshaping  energy consumption trends in the region. The implementation of energy efficiency policies can support the region's future energy security. Building energy codes can ensure that  new  and  renovated  buildings  comply  with  minimum  standards  of  energy efficiency, while energy certificates provide information to make better purchasing decisions and  fiscal and  non-fiscal incentives encourage  households  and developers to invest in energy-efficient equipment and solutions. Enabling smart, grid-interactive  buildings  can  help  manage  peak  loads  and  the  integration  of higher levels of VRE supplies. Some of these measures are already in force in ASEAN member states, but there is significant scope for greater ambition.

At the regional level, the ASEAN Centre for Energy (ACE) is working to encourage improvements in building sector energy efficiency through targeted activities, such as the Programme for Energy Efficiency in Buildings in ASEAN. ACE also issues awards that recognise leading private sector efforts to implement building energy efficiency.

Most  ASEAN  member  states  have  adopted  building  energy  codes,  which  are commonly  set  through  a  broader  policy  framework  of  legislation,  regulations, technical standards and implementation guidelines rather than a single legislative instrument.  Singapore  stipulates  mandatory  energy  efficiency  requirements  for large  new  buildings  and  renovations.  The  Philippines,  Thailand  and  Viet Nam stipulate mandatory energy efficiency requirements for many types of large new buildings and renovations, while Indonesia specifies mandatory energy efficiency requirements for commercial buildings, and additional requirements through the Smart Building  Regulation.  Malaysia  requires  all  building  types  to  meet  a  roof thermal performance standard, and new or renovated non-residential buildings with large air-conditioned areas must meet a building performance standard and implement an energy management  system. Brunei Darussalam's energy efficiency guidelines are mandatory for government buildings and voluntary for commercial buildings. Cambodia and Myanmar have green building or passive cooling  criteria  in  place,  and  Cambodia  is  progressing  efforts  to  develop  its building energy code.

Participation in building energy certification and labelling schemes is voluntary in many  ASEAN  member  states,  including  Brunei  Darussalam,  the  Philippines, Singapore, Thailand and Viet Nam. Cambodia has a voluntary scheme available and is progressing the development of a building rating and certification scheme for  possible  implementation  by  the  government.  Malaysia  sets  a  mandatory requirement for office buildings with a gross floor area of 8 000 m 2  or above to display  an  energy  intensity  label.  Indonesia's  Smart  Building  Regulation  has established  mandatory,  recommended  or  voluntary  classifications  according  to building type, with certification delivered through a national platform. Cambodia's Green  Building  Council  offers  green  building  certification  and  the  country  is currently progressing the development of a green building rating system.

Indonesia,  the  Philippines,  Thailand  and  Viet Nam  incentivise  building  energy performance  through  their  national  energy  efficiency  awards.  Indonesia  and Malaysia offer incentives in the form of government-funded building energy audits. Singapore  provides  cash  incentives  for  building  energy  efficiency  retrofits  and allows  developers  up  to  3%  additional  gross  floor  area  for  developments  that achieve higher sustainability performance, including energy efficiency standards. Thailand provides revolving funds and subsidies for energy-conserving activities, and Malaysia offers a green building tax incentive. Several ASEAN member states are fostering the involvement of energy service companies (ESCOs), including Indonesia, the Philippines, Singapore and Viet Nam. Malaysia and Thailand have focused  on  deploying  ESCOs  to  improve  the  energy  efficiency  of  government buildings.

Building sector energy efficiency regulations, information and incentives in ASEAN

| Building energy                                  | Building energy certificates and labelling   | codes Incentives for higher building performance   |
|--------------------------------------------------|----------------------------------------------|----------------------------------------------------|
| Brunei Darussalam Mandatory buildings);          | Voluntary (govt)                             | (government voluntary -                            |
| Voluntary guidelines; energy code in development | Voluntary (non-govt) In development (govt)   | Cambodia -                                         |
| Mandatory (commercial buildings)                 | In force (govt)                              | Indonesia Available                                |
| -                                                | -                                            | Lao PDR -                                          |
| Mandatory (selected non- residential buildings)  | In force (govt)                              | Malaysia Available (non-fiscal, fiscal)            |
| Voluntary; compliance methods in development     | In development (hybrid)                      | Myanmar -                                          |

Notes: govt = a government-led scheme; non-govt = a non-government led scheme such as a green building council scheme; hybrid = a scheme that is co-delivered by a government and non-government entity.

|                 | Building energy codes                           | Building energy certificates and labelling   | Incentives for higher building performance   |
|-----------------|-------------------------------------------------|----------------------------------------------|----------------------------------------------|
| The Philippines | Mandatory (large new buildings and renovations) | Voluntary (non-govt)                         | Available (non-fiscal, fiscal)               |
| Singapore       | Mandatory (large new buildings and renovations) | Voluntary (hybrid)                           | Available (including fiscal)                 |
| Thailand        | Mandatory (large new buildings and renovations) | Voluntary (hybrid)                           | Available (non-fiscal, fiscal)               |
| Timor-Leste     | -                                               | -                                            | -                                            |
| Viet Nam        | Mandatory (large new buildings and renovations) | Voluntary (non-govt)                         | Available (non-fiscal)                       |

Data centres are creating a new source of electricity demand in the region, with their electricity demand in Southeast Asia set to more than double between 2025 and 2030, partially  due  to  the  establishment  of  regional  hubs  in  Malaysia  and Singapore. Both ASEAN member states have adopted policy mechanisms in this regard.  Malaysia  has  introduced  a  guideline  and  technical  code  establishing voluntary  power  usage  effectiveness  (PUE)  standards,  and  incentives  are available  for  qualifying  new  data  centre  investments  that  meet  a  range  of sustainability,  green  technology  and  other  eligibility  criteria.  Similarly,  under  its Green  Data  Centre  Roadmap,  Singapore  has  introduced  a  green  building certification process for data centres, introduced technical standards on efficient data centre IT equipment and on safely running facilities at higher temperature and humidity levels, and a grant to help data centre businesses procure equipment meeting the standards. Companies applying to enter or expand in Singapore's data centre market through its second Data Centre Call for Application process need to meet these stringent energy efficiency standards.

## Appliances

Rising appliance ownership has led to electricity becoming the main energy source in buildings today, and appliances are a major driver of electricity demand growth in the region. Appliance usage is also a driver of increasing oil demand - growing LPG consumption for cooking and water heating has increased LPG demand in buildings by around 30% in the past decade. Almost all ASEAN member states have introduced a mix of measures to improve the energy efficiency of appliances, with MEPS and energy labelling chief among them. Regionally, foundational steps have been taken to harmonise efforts to facilitate improved implementation and effectiveness.

ASEAN  has  set  an  ambitious  target  for  harmonised  MEPS  for  room  air conditioners,  aiming  for  a  cooling  seasonal  performance  factor  (CSPF)  of 6.09 Wh/Wh by 2030, a level broadly aligned with international benchmarks for highly efficient room air conditioners. Although most countries in the region have MEPS in place, these are not yet fully aligned with the regional target. Singapore has  already  reached  and  exceeded  the  regional  benchmark,  with  MEPS equivalent to 6.1 Wh/Wh for single-split air conditioners and stringent requirements also applying to multi-split systems, and Malaysia is set to achieve the target in 2030 for smaller air conditioners (&lt;4.5 kW rated cooling capacity). Most ASEAN member states are still well below, falling in the 3-4 Wh/Wh range. This means that there is potential to nearly double the stringency of the lower MEPS levels by 2030.

Air conditioners are a major driver of electricity demand in the ASEAN region. Only 18% of households had an air conditioner in 2019, compared with almost 30% today. The stock of air conditioners is set to triple by 2035. Ownership levels today vary,  from  around  80% in  Brunei  Darussalam and  Singapore  to  below  20%  in Indonesia  and  the  Philippines,  and  around  5%  in  Myanmar.  As  incomes  rise, significant increases in ownership rates are projected. For example, in Indonesia the share of households with air conditioning is set to increase to 85% by 2050. Cooling demand in the region is set to further accelerate due to the increase in the number of cooling degree days expected in the region in the absence of additional measures to mitigate climate change. These trends could drive up cooling demand in Southeast Asia sixfold between 2024 and 2050, placing a significant new load on electricity grids. The implementation of well-designed MEPS and labelling can help mitigate the growth of electricity demand for air conditioners by ensuring a minimum  level  of  efficiency  for  new  models  and  guiding  consumers  to  more efficient  models,  while  complementary  policies  to  improve  building  envelope performance can ensure intended efficiency gains are realised.

For lighting equipment, ASEAN member states are advancing efforts to harmonise MEPS. They agreed to progress towards introducing mandatory MEPS with a minimum  efficacy  threshold  of  80 lm/W  for  LED  and  fluorescent  lamps.  Five member states have so far introduced such MEPS. To help achieve these regional targets, ASEAN's  Mutual  Recognition  Agreements  facilitate  compliance  by ensuring test reports and certifications are recognised across ASEAN member states, easing conformity assessment procedures. Most countries in the region have  aligned  with  the  regional  targets,  while  others  have  lower  efficiency requirements.  Additionally,  in  some  cases  MEPS  are  not  technology-neutral, which allows low-efficiency products such as incandescent or halogen lamps to be sold in the market, despite being below the efficiency requirements for LEDs.

Mandatory MEPS for fans and rice cookers have been introduced by a handful of ASEAN member states, and Thailand has introduced energy labelling for these

appliances.  Five  member  states  have  introduced  MEPS  for  refrigerators  with another  three  having  developed  drafts.  Many  other  types  of  appliances  and equipment  are  covered  by  MEPS  and  labelling.  Thailand's  energy  labelling scheme covers 27 product types, while Viet Nam's covers 19 and the Philippines' covers 8. By comparison, MEPS and labelling regulations in both Malaysia and Singapore cover 10 product categories, while Indonesia covers 8. Several ASEAN member  states  have  implemented  accompanying  information  tools,  including campaigns  and  interactive  product  registers,  including  Indonesia,  Malaysia, Singapore and Thailand.

In  2025,  ACE  launched  an  online  database  of  registered  appliances  from  all ASEAN  member  states,  including  air  conditioners,  refrigerators  and  lighting products. The system aims to support effective and harmonised energy efficiency implementation in the region by enabling regulators to upload and share product compliance data, reducing trade barriers and facilitating compliance with efficiency standards across the region.

## Appliance sector minimum energy performance standards in ASEAN

|                   | Air conditioners (capacity <8 kW)   | Rice cookers        | Refrigerators   | Lighting equipment   | Fans                |
|-------------------|-------------------------------------|---------------------|-----------------|----------------------|---------------------|
| Brunei Darussalam | COP >= 2.9                          | -                   | Draft           | -                    | -                   |
| Cambodia          | - (Draft)                           | -                   | -               | -                    | -                   |
| Indonesia         | CSPF >= 3.4                         | Yes                 | Yes             | Yes (>80 lm)         | Yes                 |
| Lao PDR           | -                                   | -                   | Draft           | -                    | -                   |
| Malaysia          | CSPF >= 4.1                         | Yes                 | Yes             | Yes (<80 lm)         | Yes                 |
| Myanmar           | -                                   | -                   | Draft           | Yes (>80 lm)         | -                   |
| The Philippines   | CSPF >= 3.08                        | -                   | Yes             | Yes (>80 lm)         | Yes                 |
| Singapore         | WCOP > 4.86                         | -                   | Yes             | Yes (>80 lm)         | -                   |
| Thailand          | CSPF >= 3.9                         | - (Voluntary label) | Yes             | Yes (>80 lm)         | - (Voluntary label) |
| Timor-Leste       | -                                   | -                   | -               | -                    | -                   |
| Viet Nam          | CSPF >= 3                           | Yes                 | Yes             | Yes (<80 lm)         | Yes                 |

Notes: COP = coefficient of performance; CSPF = cooling seasonal performance factor; WCOP = weighted coefficient of performance; lm = lumen; kW = kilowatt.

## Transport

The  transport  sector  accounts  for  about  30%  of  total  final  consumption  in  the region, consumes around 60% of oil products and is the main driver of rising oil demand.  Road  transport  alone  accounts  for  over  90%  of  the  sector's  energy demand. Fuelled by population growth, rising incomes and increasing

urbanisation, the light-duty vehicle (LDV) fleet in ASEAN is growing rapidly, with EVs playing an important role in improving fleet efficiency. In many countries in the region, two- and three-wheelers are the most prevalent mode of transport, being more numerous than cars and highly amenable to electrification. Heavyduty  vehicles  (HDVs),  where  energy  demand  is  also  growing  rapidly,  are  less readily  electrified.  Improving  transport  energy  efficiency  requires  both  more efficient  vehicles  and  greater  use  of  energy-efficient  modes  such  as  public transport.

The region is highly dependent on imported oil to fuel the transport sector, with around  66%  of  oil  demand  in  ASEAN  being  met  by  imports  in  2024.  For  this reason, the conflict in the Middle East is having a substantial impact on ASEAN member states, as fuel prices increase and as some oil products, such as diesel, face  tight  supply  constraints.  This  highlights  the  role  of  energy  efficiency  and demand-side measures to ease the impact and shelter consumers from shocks.

Meeting  the  growing  demand  for  transport  services  while  increasing  regional energy security will require implementation of a suite of policies. Several national plans or strategies exist, many containing ambitious targets for EV adoption. The APAEC provides regional strategic direction for the sector's energy transition, as did the ASEAN Fuel Economy Roadmap (2018-2025). The roadmap set a target for a 26% reduction in new LDV fuel consumption in the decade to 2025, while the APAEC envisages the sector decarbonising through strengthened fuel economy standards,  fuel  switching,  low-carbon  mobility  solutions  and  public  transport adoption.  To  date,  concrete  action  on  improving  LDV  fuel  economy  has  been limited to a few ASEAN member states and a few key policies.

The import of inefficient used vehicles hinders transport sector energy efficiency progress.  Used  vehicle  imports  are  banned  in  Indonesia,  the  Philippines  and Thailand,  while  Brunei  Darussalam,  Malaysia,  Singapore,  Timor-Leste  and Viet Nam permit them subject to certain age and emission limitations. Cambodia, Lao PDR, and Myanmar are yet to establish similar restrictions.

Light-duty  vehicle  fuel  economy  standards  and  labelling,  import  limitations  and  EV incentives, ASEAN

|                   | Fuel economy standards and labelling   | Used import limitations   | Incentives for electric vehicles                        |
|-------------------|----------------------------------------|---------------------------|---------------------------------------------------------|
| Brunei Darussalam | -                                      | <4-5 yr, Euro 4           | -                                                       |
| Cambodia          | -                                      | -                         | Purchase tax preferences for                            |
| Indonesia         | None, but LCGC                         | Banned                    | Purchase tax preferences for local                      |
| Lao PDR           | -                                      | -                         | Temporarily suspended imports of powered light vehicles |
| Malaysia          | None, but LCMB                         | <4-5 yr, Euro 4           | Road and purchase tax benefits                          |

Notes: LCGC = Low Cost Green Car scheme, which provides tax incentives for small-engine cars that meet specified criteria, including  a  minimum  fuel  efficiency  of  20 km/l  and  local  content  requirements.  LCMB  =  Low  Carbon  Mobility  Blueprint contains a progressive average fuel economy target for all new vehicles and commits to introducing labelling. '&lt;4-5 yr', 'Euro 4' and other entries in the Used import limitations column refer to banning the importation of vehicles that do not meet these restrictions, adapted from United Nations Environment Programme. Used import bans and limitations may apply to certain vehicle types or classes and exemptions may apply. EV = electric vehicle; yr = year.

|                 | Fuel economy standards and labelling   | Used import limitations   | Incentives for electric vehicles                     |
|-----------------|----------------------------------------|---------------------------|------------------------------------------------------|
| Myanmar         | -                                      | -                         | -                                                    |
| The Philippines | Labelling                              | Banned                    | Excise tax exemption for EVs                         |
| Singapore       | Tax-driven (implicit)                  | <3 yr, Euro 5             | Comprehensive policy package                         |
| Thailand        | CO 2 excise (implicit) Labelling       | Banned                    | Purchase tax preferences and subsidies for local EVs |
| Timor-Leste     | -                                      | <4-5 yr                   | Proposed EV purchase tax incentives                  |
| Viet Nam        | Labelling                              | <4-5 yr, Euro 4           | Purchase tax preferences for EVs                     |

Transport fuel policies can support energy security by reducing demand for oil imports. Implementation varies across the region. As a whole, ASEAN member states  are  making  progress  towards  improving  diesel  fuel  quality,  a  necessary enabler for best practice Euro 6 or equivalent air pollutant emissions standards, with  synergies  for  fuel  economy  improvements.  Fossil-fuel  subsidies,  which totalled more than USD 30 billion in the region in 2023, place a substantial burden on government finances, and universal subsidies can counter progress towards improved energy efficiency and energy security progress.

## Electrification

Intense  competition  among  key  manufacturers  has  allowed  the  cost  of  EV production  to  fall  dramatically  and  accelerate  the  uptake  of  EVs  in  emerging market and developing economies faster than previously projected. This dynamic has been a key enabler for increasing the share of EVs in LDV sales in Thailand (22%), Indonesia (11.5%), Malaysia (6.8%) and the Philippines (4.6%) by the end of the first half of 2025. Lao PDR has introduced a temporary ban on the import of fuel-powered LDVs, which is set to accelerate the uptake of EVs this year. In other ASEAN member states, incentives for imported EVs are generally declining or have been removed but they remain in place for domestically manufactured or assembled EVs. Member states such as Indonesia, Malaysia and Thailand are looking to capture the value of increasing EV sales by introducing policies that spur investment in domestic EV manufacturing or assembly. Viet Nam has seen particular success with its domestic EV brand, VinFast, helping Viet Nam reach a 35.1% EV sales share in the first half of 2025.

More rapid EV deployment can contribute to a reduction in the demand for road fuels and thus oil imports, increasing energy security in the region. Investing in

manufacturing  capacity  could  help  ASEAN  member  states  meet  their  own ambitious EV targets. Additionally, efforts to improve the fuel economy of internal combustion engine vehicles remain important given the expected growth in the demand for transport services and the large proportion of vehicles sold on the ASEAN market that still depend on fossil fuels.

## Industry

Energy  demand  in  the  industrial  sector  comprises  about  35%  of  total  final consumption in the region, and the sector is a major consumer of coal, natural gas and electricity. Despite the relevance of the sector, energy efficiency policies are lagging. Energy efficiency policies in the industrial sector include the implementation of requirements for energy management systems for large energy consumers or mandating annual audits of industrial and commercial premises to identify energy-savings measures. The implementation of these measures can be accelerated with fiscal incentives such as low interest loans and grants, and nonfiscal incentives such  as  awards.  A  mix  of  incentives  is  currently being implemented by ASEAN member states. Additionally, regulating the efficiency of industrial equipment, such as motors, through MEPS can prevent low-efficiency equipment from entering the market.

In  the  region,  only  three  countries  have  MEPS  for  industrial  motors,  with requirements linked to the International Electrotechnical Commission (IEC) motor efficiency classes. Singapore has set minimum efficiency requirements at the IE3 level,  while  Thailand  and  Viet Nam  have  set  the  IE1  efficiency  level  as  the threshold. These are significantly below today's world's best MEPS, which sit at IE4,  exposing  ASEAN's  industrial  participants  and  business  partners  to  lowefficiency models.

Many  ASEAN  member  states  have  set  requirements  for  large  companies  to undertake mandatory energy audits and implement energy management systems, based  on  minimum  annual  energy  demand  thresholds.  Indonesia has a requirement for the implementation of energy management systems at facilities consuming more than 167 TJ per year. Malaysia requires the implementation of management systems and cost-effective savings measures for companies with annual  demand  above  21.6 TJ,  while  Singapore  has  similar  requirements  for specific energy-intensive companies consuming 54 TJ of energy or more per year. In the Philippines, medium-sized and large energy-consuming establishments are subject to mandatory  energy  management  requirements,  including  annual reporting of energy consumption and the implementation of energy management systems, while larger establishments must also employ certified energy professionals and conduct periodic energy audits to verify energy management

performance. In Thailand, energy audits and energy management systems are mandatory for designated companies with consumption above 1 000 toe (42 TJ) or those with peak electricity demand above 1 MW.

The  ASEAN  Energy  Management  and  Accreditation  System  (AEMAS)  has provided capacity building, training and certification in energy management across the region through a harmonised regional curriculum, strengthening the recognition of energy managers as professionals and helping member states to address  energy  management  skills  shortages.  Building  on  the  foundations  of AEMAS,  ASEAN  is  preparing  the  Sustainable  ASEAN  Energy  Management Certification  Scheme  (SAEMAS),  an  enhanced  regional  standard  for  certifying energy management professionals through an integrated curriculum of classroom and  practical  energy  audit  training  that  will  strengthen  the  region's  energy management  training  system  and  advance  mutual  recognition  of  professional competencies across ASEAN member states. Support from international partners will be critical to accelerating its implementation and scaling its impact. Across the region a lack of publicly accessible information on the level of regulated entities' compliance with mandatory requirements makes it difficult for peer monitoring to occur and for stakeholders more broadly to understand policy effectiveness and results achieved.

## Industrial sector energy regulations and incentives, ASEAN

|                                                                                                        | Energy management requirements                                                                                                                                                                              | MEPS for motors   | Incentives                                        |
|--------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------------------|---------------------------------------------------|
| Brunei Darussalam                                                                                      | Published handbook with advice on audits and energy management for companies                                                                                                                                | -                 | -                                                 |
| Cambodia Offers                                                                                        | training for energy managers; currently developing regulatory framework                                                                                                                                     | -                 | Available: revolving fund                         |
| Indonesia Mandatory energy audits and energy management systems for facilities with demand over 167 TJ |                                                                                                                                                                                                             | -                 | Available: awards; potential green finance        |
| Lao PDR                                                                                                | No formal energy management/audit programme but some support for training energy managers                                                                                                                   | -                 | -                                                 |
| Malaysia must                                                                                          | Companies consuming over 21.6 TJ annually implement energy management and cost- savings measures                                                                                                            |                   | - Available: awards, tax incentive, energy        |
| managers; work ongoing to develop a                                                                    | Currently offers support and training for energy policy framework                                                                                                                                           | -                 | Myanmar -                                         |
| The Philippines                                                                                        | annually report energy consumption and implement energy management, with larger establishments also required to conduct energy audits, employ energy professionals and verify energy management performance | -                 | Available: awards, tax incentive, green financing |

|                                 | Energy management requirements                                                                                     | MEPS for motors   | Incentives                            |
|---------------------------------|--------------------------------------------------------------------------------------------------------------------|-------------------|---------------------------------------|
| Singapore                       | Companies consuming over 54 TJ annually must implement energy management and enact cost- effective saving measures | IE3               | Available: grants                     |
| Thailand                        | Mandatory audits and energy management designated companies consuming                                              | IE1               | Available: awards, tax incentives     |
| Timor-Leste No policy framework | identified                                                                                                         | -                 |                                       |
| Viet Nam                        | Mandatory audits and energy management for companies consuming over 1 000 toe                                      | IE1               | Available: awards, fund (in progress) |

Many ASEAN member states have developed free energy efficiency guidance for industry.  Brunei  Darussalam  has  published  information  on  concepts  regarding energy management and energy audits, Thailand has published information on energy  management  and  energy  conservation  for  factories,  while  Viet Nam regularly releases videos on a range of energy efficiency topics and case studies, and has published information on saving electricity in industrial buildings. Malaysia and Singapore have developed accessible guidelines that support stakeholders to understand  and  implement  industrial  sector  energy  efficiency  requirements. Informational resources such as these fulfil an important role in driving energy efficiency improvements in the region and helping to moderate increasing energy demand.

## Demand-side flexibility

The combination of energy efficiency, electrification and demand-side flexibility can deliver extensive and responsive energy security outcomes in the ASEAN region. Demand-side flexibility can facilitate the integration of variable renewables into the grid by shifting demand to periods of high electricity production, and can improve grid reliability by flattening demand curves, while also reducing reliance on fossil fuels during peak demand hours. Demand-side flexibility coupled with end-use efficiency measures can offer a cost-effective route to enhancing energy security, helping to protect consumers from high energy costs. IEA analysis shows that demand-side flexibility in Thailand could reduce national peak demand by up to 13%, free up to 15% of transmission capacity on many network corridors, and lower power system operating costs by around 9-11% by 2030. ASEAN member states have begun to implement demand-side flexibility strategies, with several policies already implemented and a number under development.

Several ASEAN governments have sought to harness the shifting potential that can be achieved through demand-side response programmes, widely implemented  in  the  industrial  sector  and  increasingly  at  the  residential  level.

Singapore's Interruptible Load and Demand Response programmes have been in place  since  2004  and  2016  respectively,  with  enhancements  made  since, including those tested through regulatory sandboxes; Singapore also conducted a household demand response pilot that concluded in 2025. Thailand's Demand Response Control Center co-ordinates demand-side management, compensating power users for reduced power consumption; and Viet Nam has conducted pilots and programmes for commercial and non-commercial users respectively.

Smart meter deployment is critical to underpin demand-side flexibility initiatives. Smart meters for residential users are being rolled out to varying degrees within ASEAN member states. Brunei Darussalam and Singapore are working towards a  complete  rollout  of  smart  meters  in  the  near  term.  Both  countries  offer  free installation of smart meters in existing homes. Singapore's rollout, expected to be completed this year, targets households, while Brunei Darussalam is rolling out smart prepayment meters for all electricity consumers. Bangkok's Metropolitan Electricity Authority is aiming to install 4.3 million smart meter units by 2032, while a rollout of around 12 million smart meters is planned for Manila and surrounding provinces in the Philippines.

Several  ASEAN  member  states  have  time-of-use  (ToU)  electricity  pricing  that encourages consumers to shift demand according to market signals, or variable electricity pricing with cheaper rates for lower energy consumers and higher rates for higher energy consumers. Malaysia, the Philippines, Singapore, Thailand and Viet Nam have variable or ToU pricing for residential, commercial and industrial consumers, whereas Cambodia and Indonesia have variable or ToU pricing only for the industrial and commercial sectors. In some ASEAN member states, such as in Viet Nam, the pricing is set in legislation, while in others it is established by electricity retailers  and  may  be  voluntary,  such  as  in  the  Philippines  and Singapore. Brunei Darussalam, Lao PDR, Myanmar and Timor-Leste are yet to introduce any variable or ToU electricity pricing.

Achieving fully scaled and successful demand-side flexibility capability requires interoperability across the energy system, ensuring that end-use technologies can communicate and exchange information effectively. Thailand has already adopted communications standards for buildings automation and control networks through the  Building  Automation  and  Control  Network,  while  it  uses  Open  Automated Demand Response (OpenADR) to provide a standardised information exchange model for demand response.

End-use  devices  and  equipment  need  a  minimum  level  of  smart  capability  to interact  with  the  grid  and  be  utilised  for  demand-side  flexibility.  Singapore  has made a start addressing this challenge, introducing its national standard for EV charging  systems,  new  guidance  on  smart  grid  integration  and  provisions  for wireless and smart charging capabilities.

## Cross-sectoral demand-side flexibility policies, ASEAN

|                   | Smart meter installation                                  | Dynamic or flexible tariffs                 |
|-------------------|-----------------------------------------------------------|---------------------------------------------|
| Brunei Darussalam | Yes - a complete rollout is underway                      | -                                           |
| Cambodia          | -                                                         | Yes (industrial; commercial)                |
| Indonesia         | Yes - rollout underway                                    | Yes (industrial; commercial)                |
| Lao PDR           | Plans for a limited rollout                               | -                                           |
| Malaysia          | Yes - rollout underway                                    | Yes (industrial; commercial; residential)   |
| Myanmar           | -                                                         | -                                           |
| The Philippines   | Yes - rollout underway                                    | Yes (industrial; commercial; residential)   |
| Singapore         | Yes - a complete rollout is underway                      | Yes (industrial; commercial; residential) - |
| Thailand          | Yes - piloted and planned limited rollout                 | Yes (industrial; commercial; residential)   |
| Timor-Leste       | Limited installations                                     | -                                           |
| Viet Nam          | Required for all new residential and commercial buildings | Yes (industrial; commercial; residential)   |

Smart  meters  and  interoperability  are  important  enablers  of  efficient  gridinteractive  buildings,  and  enable  consumers  to  become  active  participants  in maintaining  system  reliability  and  energy  security.  By  providing  the  data  and communications  infrastructure needed  to  co-ordinate flexible demand  and distributed  energy  resources,  they  facilitate  the  development  of  aggregation models that can reduce peak demand, improve system resilience and support the integration of VRE.

Virtual power plants (VPPs) represent one of the key enablers of demand-side flexibility. These  are  networks  that aggregate  distributed resources using advanced data analytics to provide flexibility to the market. As the ASEAN region's electricity demand grows and the deployment of VRE sources scales up, ASEAN member states are exploring the role of VPPs. Singapore is conducting a two-year VPP  regulatory sandbox pilot, while Thailand ran a regulatory sandbox programme between 2020 and 2023 to test technologies including behind-themeter solar and battery systems, demand-side flexibility tools and peer-to-peer energy trading. Thailand plans to upgrade its Demand Response Control Center to a Virtual Power Plant Platform by 2027.

## Critical minerals security review

## Critical minerals overview

Critical minerals are becoming an increasingly important part of ASEAN's energy security agenda. The region holds significant mineral resources, has been rapidly expanding processing capacity, and is already embedded in clean energy and industrial supply chains. This creates major opportunities for investment, industrial development and export growth, but also introduces new sources of vulnerability linked to supply concentration, environmental performance, infrastructure constraints, technology dependence and exposure to changing trade policies. The ASEAN Ministerial Meeting on Minerals (AMMin) is ASEAN's highest policymaking body for co-operation on minerals.

The ASEAN region occupies several positions across critical mineral value chains. It is a producer of key minerals, an emerging processing centre, and a growing manufacturing  hub  for  energy  technologies  for  both  regional  deployment  and export.  These  roles  are  closely  connected:  stronger  upstream  production  can support midstream processing and downstream manufacturing, while expanding clean energy industries will increase the region's own demand for reliable material inputs. The ASEAN Minerals Development Vision (AMDV) and the 4th ASEAN Minerals Cooperation Action Plan (AMCAP-IV) 2026-2030 recognise this opportunity by emphasising the need to leverage ASEAN's mineral endowment, attract investment, support sustainable economic development and expand the region's  presence  across  integrated  value  chains.  In  addition,  the  ASEAN Principles for Sustainable Minerals Development provide a shared framework to advance sustainability  in  minerals  exploration,  extraction  and  processing.  With global demand for critical minerals projected to grow substantially by 2040 - with nickel  demand  almost  doubling,  cobalt  and  rare  earth  elements  increasing  by around 50-60%, and copper by around 30% - ASEAN can play a strategic role in diversifying global supply chains.

ASEAN's  current  position  is  strongest  in  nickel.  Indonesia  is  now  the  world's largest  nickel  producer  and  the  leading  nickel  refiner,  supported  by  rapid investment in mining and processing. This has made the region an increasingly important player in global battery and EV supply chains. At the same time, the concentration  of  regional  activity  in  Indonesia  creates  risks,  including  a  link between  nickel  processing  and  growth  in  captive  power  requirements,  largely supplied through emissions-intensive coal-based generation, pressure on power and port infrastructure and the need to manage environmental and social impacts as production and refining expand.

Other  ASEAN  member  states  also  have  important  roles  and  potential.  The Philippines is a major nickel producer, Viet Nam has rare earth resources and growing  manufacturing  capacity,  and  Malaysia,  Thailand  and  Viet Nam  are relevant  to  electronics,  solar  PV  and  battery-related  supply  chains.  However, many parts of the regional value chain remain underdeveloped. Gaps remain in geological data, upstream project development, midstream processing, refining, recycling, technology capabilities and the infrastructure needed to connect mineral resources with industrial demand.

For  ASEAN, the main security question is therefore not only access to critical minerals, but how to capture more value from the sector for local communities and the  economy  while  reducing  exposure  to  concentrated  global  supply  chains. Global processing remains highly concentrated, particularly in China for graphite, rare  earths  and  several  battery  minerals.  Recent  export  controls  affecting  rare earths,  magnets  and  battery-related  supply  chains  have  shown  how  quickly disruption can affect automotive, electronics, defence, energy  and  digital industries. These risks are especially relevant for ASEAN economies seeking to expand  manufacturing  and  clean  energy  industries,  since  even  resource-rich ASEAN  member  states  can  remain  dependent  on  external  suppliers for processing equipment, refining technologies, magnets, battery components and advanced manufacturing inputs.

The regional policy challenge is twofold. First, ASEAN can strengthen its position as a reliable supplier of responsibly produced minerals and processed materials. This  requires  clearer  permitting  processes,  stronger  environmental  and  social governance,  investment  in  infrastructure,  skills  and  power  supply,  and  better alignment between mining policy and industrial strategy. Second, ASEAN needs to  manage  its  own  exposure  to  imported  technologies,  refined  materials  and specialised components. A more strategic approach could help ASEAN member states assess where domestic or regional capabilities can be developed, where diversification  is  needed,  and  where  partnerships  with  external  suppliers  will remain essential.

A more integrated ASEAN approach to critical minerals would combine national industrial policies with stronger regional co-operation. Priorities include improving geological data, developing shared standards, supporting responsible mining and processing, expanding recycling and circular economy measures, and identifying opportunities for regional value chains across mining, refining, manufacturing and end-use sectors. This would help ASEAN capture more economic value from its resource base  while strengthening resilience to supply disruptions, trade restrictions and external technology dependencies.

## Critical minerals supply

As laid out in the IEA's Southeast Asia Energy Outlook 2026, the ASEAN region has significant potential to consolidate its position as both a major producer of critical  minerals  and  a  key  region  supporting  efforts  to  diversify  global  supply chains.  The  region  holds  a  substantial  share  of  global  mineral  reserves, accounting for around 51% of global nickel reserves, as well as approximately 20% of bauxite reserves and 17% of tin reserves. It also hosts important reserves of cobalt, rare earth elements and copper, which are critical for energy, transport, advanced manufacturing, electronics and other strategic industries. Although most processing  and  manufacturing  currently  take  place  outside  ASEAN,  these resource  endowments  underline  the  important  role  the  region  can  play  in contributing to more diversified critical mineral supply chains. Mined output across cobalt, copper, nickel and rare earths in Southeast Asia is projected to increase by a weighted average of 30% by 2035 in the base case, based on current policies, announced projects and expected market developments, although mined copper production is expected to decline by one-quarter over the same period. By 2035, Southeast Asia's refined output is projected to increase by a weighted average of 130%, driven primarily by nickel refining in Indonesia, as well as threefold growth in  rare  earths  and  cobalt  refining.  As  global  demand  for  critical  minerals  is projected to rise substantially by 2040, with nickel demand almost doubling, cobalt and  rare  earth  elements  increasing  by  50-60%  and  copper  growing  by  30%, Southeast Asia's expanding supply positions the region as an important source of additional supply to meet this rising demand.

Indonesia anchors supply in the region, accounting for 63% of global mined nickel production and 12% of global cobalt output in 2024, both of which are widely used in batteries for EVs  and  consumer  electronics.  Indonesia's  2020  ban  on unprocessed  nickel  exports  accelerated  domestic  refining,  attracting  almost USD 14 billion  in  smelter  investment  and  expanding  domestic  capacity  from 2 facilities to more than 30.

An  important  co-benefit  has  been  the  increased  recovery  of  cobalt,  which  is produced as a by-product of nickel laterite processing and has enabled cobalt output to scale rapidly. Indonesia also imports nickel ore from the Philippines, the region's second-largest global nickel producer, which accounted for 10% of global mined output in 2024. While Indonesia hosts more than 40% of global refined nickel production, Indonesian companies own only around 10% of that capacity, with most ownership held by Chinese companies.

In  May  2026,  Indonesia  and  the  Philippines  formalised  a  co-ordinated  nickel supply  corridor  under  an  MoU,  committing  to  move  200 000 tonnes  of  ore  per month  from  Philippine  mines  to  Indonesian  smelters  starting  June  2026  and establishing a structured partnership between upstream Philippine producers and Indonesia's downstream processing capacity.

Indonesia enforces strict export bans on unprocessed minerals like bauxite and iron ore and stopped all raw bauxite ore exports in June 2023. Iron ore and iron sand  also  face  strict  export  prohibitions  under  national  mining  laws  and  the government  continues  to  uphold  these  bans  in  2026,  refusing  to  reopen  raw material export channels. While this policy is aimed at forcing companies to build local smelting and processing plants, there are clear delays in such investment transpiring in this area.

Rare earth elements, including light rare earth elements such as neodymium and praseodymium, and heavy rare earth elements such as dysprosium and terbium, are  essential  for  permanent  magnets  used  in  EV  motors  and  a  wide  range  of energy and high-tech applications where high temperature resistance is required. Upstream mining of these magnet rare earth elements is concentrated in Myanmar, which accounted for just under 20% of total global mined rare earth supply and more than 40% of heavy rare earth elements, while Thailand contributed around 2% of both as of 2024.

It is notable how Asian performance in critical mineral exploration spending has remained robust. While spending globally fell by over 10% in 2025, with the largest declines reported in Australia and the United States at around 25%, Asia Pacific recorded a 20% increase in spending on critical mineral exploration in the same year.

As extraction expands in ASEAN, the region has an opportunity to move up the critical minerals value chain and become a critical minerals hub that leverages its mineral resources to support downstream manufacturing, create new industrial bases  and  produce  higher-value  products  rather  than  mostly  exporting  raw materials.

## ASEAN's share of global mined production and reserves for selected minerals, 2024

<!-- image -->

IEA. CC BY 4.0.

Notes: REE = rare earth elements. Reserves data for rare earth elements in Myanmar are not accounted for in the chart due to lack of reliable data, but the country is one of the largest mined producers of medium and heavy rare earths in the world.

Sources: Production based on data from IEA (2025), Global Critical Minerals Outlook 2025. Reserves from the US Geological Survey.

## Five-year outlook

In  Southeast  Asia,  the  regulatory  landscape  is  characterised  by  strengthening state intervention and industrial policy. Governments throughout the region are prioritising strategies to increase local value addition from extracted resources. These strategies include policies such as restrictions on the export of unprocessed materials  and  a  particular  emphasis  on  developing  integrated  EV  ecosystems. Multilateral and regional institutions are giving greater attention to the minerals sector, reflecting the region's growing role in critical mineral supply chains.

The AMDV and AMCAP-IV provide a regional framework to support value-chain and workforce development, attract investment and promote responsible supply. In  parallel,  the  Asian  Development  Bank  launched  the  Critical  Minerals to --Manufacturing Financing Partnership Facility in March 2026 to de risk early stage --investments in midstream processing, manufacturing and recycling through co -financing, risk sharing and knowledge sharing. The region is capitalising on fast---growing regional demand while facilitating financing and expanding partnerships across the value chain.

Some major critical mineral producers in the region, such as Indonesia, Malaysia, the Philippines, Singapore,  Thailand  and  Viet Nam,  have  signed  strategic partnerships  with  major  consuming  countries  to  increase  co-operation  in  the critical  minerals  sector.  Whilst  partnerships  and  collaborations  entered  into  by individual countries on their own are valuable, countries can capture additional value  if  such  partnerships  have  a  regional  dimension  and  scale,  to  aggregate opportunities across ASEAN member states and build a larger, more diversified and comprehensive portfolio.

A short summary of the critical minerals policies of selected ASEAN countries is provided in the 'Securing critical minerals' section of the IEA's Southeast Asia Energy Outlook 2026.

## Critical minerals security assessment

The  ASEAN  region's  dual  role  as  both  a  producer  of  critical  minerals  and  a consumer of material inputs for its manufacturing sector creates opportunities and risks  across  the  value  chain.  The  crisis  in  the  Middle  East  has  affected  global critical  minerals markets by inflating energy and logistical costs for mining and processing operations, adding to existing vulnerabilities linked to market concentration,  price  volatility  and  technological  uncertainty.  These  pressures come at a time when global capital expenditure on critical mineral projects fell by 9%  year-on-year  in  2025,  underscoring  the  need  for  ASEAN  to  strengthen resilience across both mineral supply and downstream industrial supply chains.

## Supply-side security

The rapidly expanding clean energy technology manufacturing sector in ASEAN countries requires mineral inputs. The localisation of manufacturing capacity does not necessarily translate into supply chain security, as facilities may be dependent on technologies, precursor materials and upstream inputs that are concentrated outside the region. Battery cell manufacturing capacity across ASEAN increased from 16 GWh in 2023 to 26 GWh in 2024, and committed projects would lift that capacity to over 80 GWh by 2030. The level of exposure to global supply chain concentration  varies  by  mineral.  The  ASEAN  region  is  the  world's  leading producer of nickel and home to the largest refined rare earths production facility outside China, providing a strong production base to underpin manufacturing and exports. However, while the region's mineral resources are vast, in view of the current lack of processing and refining capacity, ASEAN's overall competitiveness in this area remains low and, despite ore extraction and exports, the countries in the region remain highly dependent on imports of critical minerals in a form ready for technological applications.

The region also  supplies  around  one-quarter  of  global  sulphur  and  half  of  the global seaborne sulphur trade passes through the Strait of Hormuz, which poses additional  challenges  during  the  ongoing  conflict  and  related  restrictions  on passage.  Sulphur  is  a  key  feedstock  for  sulphuric  acid,  which  is  essential  for fertiliser  production  and  the  processing  of  a  range  of  critical  minerals  such  as copper,  lithium,  cobalt,  nickel  and  rare  earths.  Disrupted  sulphur  supplies prompted China to curb sulphuric acid exports in May 2026, creating ripple effects across both mineral and fertiliser value chains. The resulting surge in acid prices increased production costs for several critical minerals, with acid costs overtaking energy costs to become the largest cost component in some cases.

In Indonesia, high-pressure acid leaching (HPAL), a process used to refine nickel ore into the nickel intermediate mixed hydroxide precipitate (MHP), relies heavily on sulphuric acid for leaching. Although Indonesia produces most of its sulphuric acid domestically, it depends heavily on imported sulphur and roughly 75% of its supply  is  sourced  from  the  Middle  East.  In  2025,  Indonesian  sulphur  imports increased sharply to 5.35 Mt - up by around 48% from 3.6 Mt in 2024 (for more details, see the IEA's Southeast Asia Energy Outlook).

While  Indonesia  is  less  exposed  due  to  domestic  production,  China's  ban  on sulphuric acid exports from May until the end of 2026 could remove the flexible supply that HPAL producers have relied on to cover shortfalls. Reduced availability and  higher  prices  of  sulphuric  acid  could  further  increase  cost  pressures  on Indonesian nickel production.

## Exposure to economic and price risk

Attracting  investment  into  minerals  production,  processing  and  downstream manufacturing  is  central  to  the  AMDV.  The  way  in  which  such  investment  is applied can introduce further dependencies and risks.

The concentration of investment sources and trade relationships can introduce risks.  An  estimated  75%  of  nickel  refining  capacity  in  Indonesia  is  linked  to investment from Chinese companies, and t he Philippines is the world's largest exporter of nickel ores, with 72% of its 55 Mt of nickel exports in 2025 destined for China. Even as these investments and exports provide economic and revenue benefits, they can create increased exposure to domestic market dynamics in the dominant  offtaker  and  create  reliance  on  external  technology  and  expertise  if concentration  risks  are  not  carefully  managed.  The  development  of  durable domestic  expertise  and  technology  should  be  considered  alongside  attracting investment, including efforts to build workforce skills, technical and managerial expertise, local supplier ecosystems, R&amp;D  capacity  and mechanisms  for technology and knowledge transfer.

Mining and processing activities have often come with environmental and social costs in ASEAN. They include water and land pollution, and impacts on coastal communities  dependent  on  fisheries  for  livelihoods.  In  the  Philippines,  mining activities  that  affect  indigenous  communities  require  free,  prior  and  informed consent.  At  the  same  time,  investors  from  OECD  countries  and  development finance institutions may  apply  environmental  and  social  safeguards  as  a precondition for investment. Failure to adequately identify, mitigate and manage environmental and  social impacts can undermine  community  acceptance, constrain access to finance, and result in permitting delays, disputes or project disruption. The ASEAN Principles for Sustainable Minerals Development set out a shared framework to advance sustainability in the sector.

Further risks may be introduced where minerals processing is linked to emissionsintensive  processes  and  energy  sources  such  as  coal  power.  This  may  have implications for competitiveness and market access - such as through exposure to policies like the EU Carbon Border Adjustment Mechanism - and for access to financing  where  investors  consider  the  emissions  intensity  of  investments.  In response, countries may consider measures to reduce emissions associated with minerals production. For example, Indonesia launched the National Roadmap for Nickel Industry Decarbonisation in 2025, targeting emissions reduction of up to 81% in the nickel industry by 2045 through measures such as energy and material efficiency, fuel substitution, material substitution and use of low-carbon electricity.

Oil-driven cost inflation driven by the impacts of the Strait of Hormuz crisis can further dampen the investment signals for new mines and refineries. This poses potential  challenges  for  emerging  markets  such  as  those  in  ASEAN,  where

nascent processing capacity is already vulnerable to shifts in investor confidence (for more details, see the IEA's South-East Asia Energy Outlook). ASEAN member states - Indonesia in particular - face more direct exposure to the crisis. Against heightened geopolitical tensions, a sustained rise in sulphur prices could weaken the  economics  of  hydrometallurgical  nickel  production.  Some  Indonesian  MHP producers  have  already  suspended  long-term  sales  to  reassess  exposure  to sulphur supply disruption.

## Regional co-operation

Mineral endowments, industrial structures and value chain presence differ across the ASEAN region. Each country has the potential to play a role in regional value chains.  For  example,  Myanmar  and  Lao PDR  are  among  the  world's  largest producers  of  mined  rare  earths.  Malaysia  hosts  the  world's  largest  rare  earth processing facility outside China. Indonesia and the Philippines hold world-leading nickel  reserves,  with  Indonesia  also  leading  processing,  while  multiple  ASEAN member states are seeking to develop battery  and  EV  manufacturing  sectors. Singapore is the regional hub for finance and commodities trading.

ASEAN has established institutional foundations for co-operation through sectoral bodies such as AMMin, and sectoral visions and plans through the AMDV and AMCAP-IV  2026-30.  Although  external  partners  will  continue  to  be  of  critical importance as the region develops its minerals sector, expanding intra-regional trade, investment and value chain co-operation can support the creation of more diversified and resilient mineral supply chains.

<!-- image -->

## Annex

## Abbreviations and acronyms

ACE

ASEAN Centre for Energy

AEMAS

ASEAN Energy Management and Accreditation System

AMCAP-IV

4th ASEAN Minerals Cooperation Action Plan

AMDV

ASEAN Minerals Development Vision

AMMin

ASEAN Ministerial Meeting on Minerals

APAEC

ASEAN Plan of Action for Energy Cooperation

APG

ASEAN Power Grid

APSA

ASEAN Framework Agreement on Petroleum Security

ASEAN

Association of Southeast Asian Nations

CAGR

compound annual growth rate

CAPEX

capital expenditure

COP

coefficient of performance

CCS

carbon capture and storage

CCUS

carbon capture, utilisation and storage

CNG

compressed natural gas

CSPF

cooling seasonal performance factor

CV

calorific value

EENS

expected energy not served

ESCO

energy service company

EV

electric vehicle

GDP

gross domestic product

HDV

heavy-duty vehicles

HPAL

high-pressure acid leaching

Lao PDR

Lao People's Democratic Republic

LDV

light-duty vehicle

LNG

liquefied natural gas

LOLE

loss of load probability

LOLP

loss of load expectation

LPG

liquefied petroleum gas

MEPS

minimum energy performance standards

met

metallurgical

MHP

mixed hydroxide precipitate

MoU

memorandum of understanding

NGL

natural gas liquids

PPA

power purchase agreement

PV

photovoltaic

SAF

sustainable aviation fuel

SAIDI

system average interruption duration index

SAIFI

system average interruption frequency index

SLF

Standby LNG Facility

SPR

strategic petroleum reserve

TAGP

Trans-ASEAN Gas Pipeline

ToU

time of use

VPP

virtual power plant

VRE

variable renewable energy

WCOP

weighted coefficient of performance

See the IEA glossary for a further explanation of many of the terms used in this report.

## Units of measure

bcm

billion cubic metres

bcm/yr

billion cubic metres per year

GJ

gigajoule

GW

gigawatt

GWh

gigawatt hours

kb/d

thousand barrels per day

kcal/kg

kilocalories per kilogram

km

kilometre

km/l

kilometres per litre

kt

thousand tonnes

kW

kilowatt

lm

lumen

MJ

megajoule

mb

million barrels

mb/d

million barrels per day

mt

million tonnes

m 2

square metre

MW

megawatt

PJ

petajoule

tcm

trillion cubic metres

toe

tonnes of oil equivalent

TJ

terajoule

TW

terawatt

TWh

terawatt hour

Wh

watt hour

## Energy conversion factors

|      | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   | Multiplier to convert to:   |
|------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|-----------------------------|
|      | EJ                          | Mtoe                        | MBtu                        | bcme                        | Mtce                        | TWh                         |
| EJ   | 1                           | 23.88                       | 9.478 x 10 8                | 27.78                       | 34.12                       | 277.8                       |
| Mtoe | 0.04187                     | 1                           | 3.968 x 10 7                | 1.163                       | 1.429                       | 11.63                       |
| MBtu | 1.0551 x 10 -9              | 2.520 x 10 -8               | 1                           | 2.931 x 10 -8               | 3.60 x 10 -8                | 2.931 x 10 -7               |
| bcme | 0.036                       | 0.860                       | 3.412 x 10 7                | 1                           | 1.228                       | 10                          |
| Mtce | 0.02931                     | 0.700                       | 2.778 x 10 7                | 0.8141                      | 1                           | 8.141                       |
| TWh  | 0.0036                      | 0.086                       | 3 412 x 10 6                | 0.1                         | 0.1228                      | 1                           |

Notes: There is no generally accepted definition of barrel of oil equivalent (boe); typically the conversion factors used vary from 7.15 to 7.40 boe per tonne of oil equivalent. Conversions to and from billion cubic metres of natural gas equivalent (bcme) are given as representative multipliers but may differ from the average values obtained by converting natural gas volumes between International Energy Agency (IEA) balances due to the use of country-specific energy densities. Lower heating values (LHV) are used throughout.

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual Member countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject  to  the  IEA's  Notice  for  CC-licenced  Content,  this  work is licenced under  a  Creative  Commons  Attribution  4.0 International Licence.

This document, as well as any data and map included herein, are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area. Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA - September 2026 Cover design: IEA Photo credits: © shutterStock

<!-- image -->