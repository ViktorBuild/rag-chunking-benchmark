---
document_id: iea_kenya_climate_resilience_2024
title: "National Climate Resilience Assessment for Kenya"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IEA"
year: 2024
original_file: "iea_kenya_climate_resilience_assessment.pdf"
tables_detected: 28
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Kenya 2024

Energy Policy Review

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 13 Association countries and beyond.

This publication and any map included herein are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. International Energy Agency Website: www.iea.org

## IEA M ember countries:

IEA A ssociation countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Argentina

Brazil

China

Egypt

India

Indonesia

Kenya

Morocco

Senegal

Singapore

South Africa

Thailand

Ukraine

The European Commission also participates in the work of the IEA

<!-- image -->

<!-- image -->

## Foreword

Welcoming Kenya into the IEA family as an Association Country in June 2023 was a milestone in our longstanding engagement on energy issues in Africa. This was a profoundly important step. Kenya has proven itself a regional and global leader on key energy topics, making the country's voice an integral one in the broader IEA family.

Since then, co-operation between Kenya and the IEA has gone from strength to strength.  Kenya  hosted  the  IEA's  9th  Annual  Global  Conference  on  Energy Efficiency in Nairobi in May 2024, and has played a key role in elevating the crucial issue of universal clean cooking access in Africa, helping the IEA spearhead a far-reaching collaborative effort to propel this pressing challenge towards the top of the global energy agenda.

Kenya has shown outstanding leadership in Africa  on  a range  of  issues, from universal  energy  access  to  the  development  of  renewable  energy,  especially geothermal,  and  energy  innovation.  I  congratulate  Kenya  for  the  impressive progress it has made over the past two decades in improving access to electricity, reaching an access rate of 75%, one of the highest in sub-Saharan Africa. This illustrates Kenya's commitment to reaching its energy development goals. The IEA looks forward to continuing our strong partnership with Kenya as it continues to drive progress in its energy sector.

Much of Kenya's ongoing work will be facilitated by the updated 'Kenya National Energy Policy'. This builds on the bedrock of policies and programmes, expertise and institutions that Kenya has at its disposal to help the country reach its energy goals. I hope that this IEA in-depth review, developed in close collaboration with the Ministry of Energy and Petroleum, will play a meaningful part in that journey.

This report aims to support Kenya's efforts on universal access to modern energy, continued  development  of  renewables,  and  improved  energy  efficiency,  as  it works towards achieving its Vision 2030 goals. At the Africa Climate Summit in Nairobi, His Excellency President Ruto and I called for a 'New Energy Pact for Africa,'  one  that  would  deepen  collaboration  between  African countries and  its international  partners. I trust this  in-depth  review  will  serve  as  a  tool  to  inspire further co-operation and help Kenya reach its energy and climate goals.

Dr Fatih Birol

Executive Director

International Energy Agency

## Table of contents

| Executive summary..................................................................................................................         | 7                                                                                                                                 |
|---------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------|
| 1. General energy policy........................................................................................................            | 15                                                                                                                                |
| Country overview.................................................................................................................           | 15                                                                                                                                |
| Governance and policy frameworks....................................................................................                        | 17                                                                                                                                |
| Statistics and data                                                                                                                         | ............................................................................................................... 21                |
| Recommendations...............................................................................................................              | 22                                                                                                                                |
| 2. Electricity ............................................................................................................................ | 23                                                                                                                                |
| Overview..............................................................................................................................      | 23                                                                                                                                |
| Guiding policies ...................................................................................................................        | 23                                                                                                                                |
| Electricity supply and demand.............................................................................................                  | 26                                                                                                                                |
| Networks..............................................................................................................................      | 28                                                                                                                                |
| Recommendations...............................................................................................................              | 33                                                                                                                                |
| 3. Renewable energy..............................................................................................................           | 35                                                                                                                                |
| Renewable generation.........................................................................................................               | 35                                                                                                                                |
| Recommendations...............................................................................................................              | 41                                                                                                                                |
| 4. Access to electricity...........................................................................................................         | 43                                                                                                                                |
| Increasing access to electricity............................................................................................                | 43                                                                                                                                |
| Challenges to electricity access..........................................................................................                  | 47                                                                                                                                |
| Recommendations...............................................................................................................              | 49                                                                                                                                |
| 5. Access to clean cooking ...................................................................................................              | 51                                                                                                                                |
| Cooking solutions by fuel                                                                                                                   | .................................................................................................... 52                           |
| Challenges to access to clean cooking...............................................................................                        | 56                                                                                                                                |
| Recommendations...............................................................................................................              | 58                                                                                                                                |
| 6. Energy security...................................................................................................................       | 59                                                                                                                                |
| Liquid fuels...........................................................................................................................     | 59                                                                                                                                |
| Coal and critical minerals                                                                                                                  | .................................................................................................... 63                           |
| Electricity security................................................................................................................        | 65                                                                                                                                |
| Recommendations...............................................................................................................              | 67                                                                                                                                |
| 7. Energy efficiency................................................................................................................        | 69                                                                                                                                |
| Buildings                                                                                                                                   | .............................................................................................................................. 70 |
| Appliances                                                                                                                                  | ........................................................................................................................... 72    |
| Transport                                                                                                                                   | ............................................................................................................................. 74  |

| Industry................................................................................................................................ 75   |
|-----------------------------------------------------------------------------------------------------------------------------------------------|
| Recommendations............................................................................................................... 76             |
| 8. Energy and climate ............................................................................................................ 77         |
| Emissions profile ................................................................................................................. 77        |
| Nationally Determined Contributions................................................................................... 78                     |
| Climate strategies and policies............................................................................................ 78                |
| Climate risks and infrastructure resilience .......................................................................... 79                     |
| The role of carbon markets ................................................................................................. 80               |
| Recommendations............................................................................................................... 82             |
| 9. Energy investment ............................................................................................................. 83         |
| Current investment patterns................................................................................................ 83                |
| Attracting further investment ............................................................................................... 86              |
| Recommendations............................................................................................................... 91             |
| Annexes................................................................................................................................... 93 |
| Acknowledgements, contributors and credits ..................................................................... 93                           |
| Energy balances and key statistical data............................................................................ 95                       |
| Abbreviations and acronyms............................................................................................... 97                  |
| Units of measure ................................................................................................................. 98         |

## Executive summary

Kenya has put in place significant energy policies and strategies, and with strong institutions and ambitious targets, the country is well-positioned to reach its energy goals and continue its economic growth and development.

As  the  largest  economy  in  Eastern  Africa  and  a  regional  leader  in  energy development,  Kenya  has  made  remarkable  progress  in  increasing  the  rate  of access to electricity among its population, putting the country on track to reach universal access to electricity by 2030. Kenya has set an ambitious target in its Vision 2030 of becoming a newly industrialising middle-income country with a high quality of life by 2030. A strong emphasis is put on infrastructure development, including  for  energy.  Kenya's  high  renewable  energy  potential  and  skilled workforce position the country well for sustainable energy development.

Bioenergy,  mainly  traditional  biomass  used  for  cooking,  accounts  for  nearly two-thirds  of  total  energy  supply.  Geothermal,  solar,  wind  and  hydropower  are increasingly prominent in the mix, mainly used for electricity generation. Imported oil completes the energy supply and is mostly concentrated in the transport sector. Energy  production,  supply  and  consumption  has  been  driven  up  by  strong economic and population growth in the past decade.

The Ministry of Energy and Petroleum oversees Kenya's energy sector, supported by various semi-autonomous governmental agencies. The sector operates under the Energy Act of 2019 and the National Energy Policy, mandated to be updated every  five  years.  Despite  strong  policies,  the  regulatory  environment  remains complex. Co-ordination and alignment with other government entities and sectors remain critical for effective implementation of Kenya's ambitious plans. Furthermore,  while  Kenya  has  improved  coverage,  quality  and  timeliness  of energy  balances  and  data,  there  is  need  for  more  structured  and  accessible energy data.

## A diverse electricity mix with strong renewable generation

Kenya is well-positioned to maintain its role  as a  regional  leader  in renewable power generation, with geothermal presenting great potential as Kenya targets 100% renewable electricity generation and universal electricity access by 2030.

Kenya has a diverse electricity mix, with nearly 90% of generation from renewable sources, including geothermal (47%), hydro (21%), wind (16%) and solar (4%) in

2023. The country is one of the lowest-cost geothermal power developers in the world and is home to the Lake Turkana Wind Project, the largest wind farm in Africa.

The power sector has around 3.3 GW of installed generation capacity, of which 950 MW is from geothermal, over 800 MW from hydropower and almost 800 MW from wind and solar combined. The remaining capacity comes from oil, mostly in the form of diesel generators (nearly 700 MW) and bioenergy. The recent addition of geothermal (around 750 MW geothermal capacity additions in the last decade) and variable renewable capacity has supplemented existing large-scale hydropower projects.

Kenya aims to scale up biomass co-generation by 2030, focusing on industrial waste and bioethanol for clean cooking. Biogas production from municipal and livestock  waste  also  holds  promise,  with  about  21 000  digesters  currently  in operation.

Historically,  progress  in  renewable  generation  was  guided  by  a  feed-in  tariff programme, which since 2021 has been evolving into an auction scheme under the Renewable Energy Auction Policy to attract investment in larger projects.

The increase in variable renewable energy capacity leads to the need for energy storage systems, which can provide grid services and stability. Kenya's electricity grid shares interconnections with Ethiopia, Tanzania and Uganda, and additional interconnectors with other East African countries can further support the exchange of power for balancing and supply.

## Increased competition to expand power generation and grid infrastructure

Addressing  grid  losses,  increasing  competition,  and  ensuring  investment  in infrastructure will be key for Kenya's sustainable growth and universal access to electricity.

The electricity sector is state-led but open to independent players. In 2024, Kenya introduced regulations to open transmission and distribution networks to private investment, fostering competition and efficiency.

Kenya's electricity networks face substantial losses, estimated at 23% in 2023, due to technical failures, theft, and billing anomalies, causing frequent outages. Efforts  to  curb  these  losses  and  improve  system  efficiency,  such  as  smart management systems, are being considered.

The Integrated National Energy Plan will play a critical role in aligning electricity sector  planning  with  national  energy  goals,  including  the  expansion  of  power generation and grid infrastructure.

The Energy Act of 2019 envisions a structure with an independent system operator and open access for new transmission and distribution licensees.

## A regional leader in electricity access

Kenya is a leader in East Africa for expanding electricity access, increasing the rate from 37% in 2013 to 79% in 2023. The country is on track to achieve universal access by 2030, and urban electrification has already reached 100%. However, affordability of electricity remains a challenge.

The Last Mile Connectivity Project (LMCP), launched in 2015, cut the number of people without access to electricity in rural areas by almost half, from 20 million to 11 million. The  project  prioritises households  within  600 meters  of  existing transformers and includes a gender component to promote women's participation. The project aims to provide electricity to an additional 280 000 households in 2024 and 2025. Kenya has also utilised off-grid solutions, mainly solar-powered minigrids  in  remote  areas,  to  expand  access.  These  are  used  by  one  in  five households.  Kenya  is  the  largest  and  most  mature  market  for  solar  off-grid solutions globally, and accounts for almost 74% of solar home system sales in East Africa in 2023.

Affordability remains a major challenge, with Kenya's electricity prices among the highest in Africa, driven by inflation, the removal of subsidies, and a depreciated currency  driving  up  inflation.  In  the  meantime,  Kenya  has  a  vibrant  innovation scene and is a regional hub for start-ups, especially in relation to energy access, which can help provide affordable options to households. The regulator introduced new tariff  structures  in  2023  aim  to  lower  the cost  of  electricity  for  low-income households, representing about 70% of customers.

## Ensuring affordability for all fuels for greater uptake of clean cooking solutions in rural areas

Kenya has made substantial progress in increasing the clean cooking access rate from  only  10%  in  2013  to  31%  in  2023,  but  69%  of  households,  mainly concentrated in rural areas, still rely on polluting fuels. The burden is most acute on women and children, who are exposed to indoor air pollution, and deprived of pursuing education or paid work by the time it takes to collect fuelwood.

Firewood remains the primary cooking fuel in Kenya for half of the population, followed by liquefied petroleum gas (LPG), charcoal and kerosene, with significant disparities  between  urban  and  rural  households.  The  newly  launched  Kenya

National  Cooking  Transition  Strategy  (KNCTS)  provides  a  clear,  integrated roadmap to reach universal access by 2028. The KNCTS envisions that by 2050, half of Kenyan households will use LPG for cooking. To make this happen, the government is removing the value-added tax (VAT) on LPG and directing all public institutions to transition to the fuel by 2025. The KNCTS also foresees that 30% will use  bioethanol,  partially  relying  on  local  production,  and  10%  will  use electricity. However, the lack of affordable electric stoves and lack of access to reliable  electricity  hinder  the  uptake  of  electric  cooking.  The  remaining  10%  of households will use biogas and other low emission or clean burning sustainable biomass. However, VAT on improved cookstoves remains one of the highest in the region.

Affordability of cleaner fuels remains a major challenge, often leading households to  revert  to  biomass.  Soaring  fuel  prices  in  the  last  few  years  have  led  to  a decrease  in  incentives  and  financial  support  for  clean  cooking  solutions  for households.

Like much of the rest of the world, adherence to traditional cooking methods, as well as the lack of awareness of alternative cooking solutions, further hinders clean cooking uptake, which the government is tackling through awareness campaigns and transitioning of public institutions.

Ensuring fuel supply and price stability is essential for the sustained use of clean cooking solutions. For long-term stability, clean cooking needs to be integrated into broader energy planning, linking it with economic growth and electricity supply strategies.

## Investing in ensuring energy security to support growth in energy demand

Kenya's  growing  demand  in  the  buildings  and  transport  sectors  is  making  the country heavily reliant on imported oil products, leading to efforts to reduce its dependency.

To  address  the  growing  oil  consumption,  Kenya  is  focusing  on  efforts  to  limit dependence  on oil product imports through energy efficiency measures, electrification of the transport sector and the promotion of biofuels, including plans to develop sustainable aviation fuels. The government also aims to develop local manufacturing  of  EV  parts  and  is  examining  ways  to  establish  domestic  value chains for this purpose.

Kenya  experiences  frequent  power  outages,  which  can  be  addressed  by strengthening and expanding the existing grid and supporting additional domestic electricity  supply.  Enhancing  resilience  of  the  electricity  infrastructure  to  cyber threats and climate change is critical for strengthening Kenya's energy security.

Kenya currently has no mining sites for critical minerals, but geological surveys have indicated potential reserves of minerals (such as copper, fluorspar, graphite, manganese, niobium and zinc) needed for clean technology manufacturing. The promotion  of  local  processing  of  the  minerals  could  benefit  Kenya's  industry sector, economic growth and energy security.

## Sustained progress in energy efficiency in all sectors

The buildings and transport sectors, which are heavily reliant on bioenergy and oil products,  drive  Kenya's  energy  consumption  with  efficiency  efforts  required  in these sectors. Kenya's overall energy intensity has decreased by 14% from 2010 to 2023.

The 2020 National Energy Efficiency and Conservation Strategy sets ambitious targets for energy efficiency improvements including increasing the annual rate of energy efficiency improvements from 0.2% to 3% by 2025.

The buildings sector, which accounts for two-thirds of total final consumption, is largely  dependent  on  biomass.  In  addition  to  clean  cooking  solutions  that  are helping households  move  away  from  traditional  biomass,  the  government introduced  the  2024  National  Building  Code  to  promote  sustainable  building practices in all buildings. Kenya  has  also implemented  minimum  energy performance standards (MEPS) for appliances, but enforcement is lacking, and the market remains dominated by lower-efficiency models.

The transport sector represents 22% of Kenya's total final consumption (2023), primarily  accounted  for  by  petroleum  products.  Most  vehicles  in  Kenya  are imported as second-hand, including heavy duty vehicles and trucks. The electric vehicle (EV) market in Kenya is currently very small. However, the government aims to increase the use of EVs through incentives such as the introduction of an e-mobility  tariff,  reducing  the  excise  duty  on  EVs  and  developing  charging infrastructure. To improve the fuel economy standards and labelling for vehicles, the government aims to restrict the age of imported second-hand vehicles from eight to five years and implement vehicle emissions inspections.

Industry accounts for a small proportion of total energy consumption, at 12% in 2023, and has experienced slow growth. Coal (43%) and oil (17%) account for the biggest energy consumption in the sector. Efficiency efforts in the industry sector have  focus  on  audits,  capacity  building,  and  trainings  for  energy  efficiency professionals.

## Ambitious goals for greenhouse gas emissions reduction need finance, capacity building and technical expertise

While Kenya's contribution to global greenhouse gas emissions (GHGs) is minor, the country faces significant threats from climate change.

Policies,  including  the  submission  of  Kenya's  updated  Nationally  Determined Contribution (NDC) in 2020, aim to reduce GHG emissions by 32% by 2030, with the energy sector to contribute 45% of these reductions. Kenya's GHG emissions reached 21.2 Mt CO2-eq in 2021, an increase from 14 Mt CO2-eq in 2010, with 52% of the emissions attributed to the transport sector.

Achievement  of  Kenya's  GHG  emissions  target  in  the  NDC  is  conditional  on almost  80%  of  the  required  funding  coming  from  international  sources.  Kenya launched its Long-Term Low Emission Development Strategy (LT-LEDS) in 2023, aiming  to  achieve  a  net-zero  emission  economy  by  2050,  but  implementation remains challenging due to data, finance and human resource needs.

Kenya has issued over 50 million credits via the Clean Development Mechanism and Voluntary Carbon Market standards. Through the National Policy on Climate Finance, Kenya aims to establish a Climate Change Fund, the largest in Africa, and  enhance  carbon  markets.  Furthermore,  a  number  of  innovative  initiatives exist,  including  direct  air  capture  technology  powered  by  geothermal  energy, which aims to be operational in the near term.

Kenya  has  integrated  climate  resilience  into  its  national  development  plans through policies such as the National Climate Change Action Plan 2023-2027, LT-LEDS  2022-2050  and  Climate  Change  Act  (Amendment  2023),  as  climate change poses a threat to the country's transport, telecommunications and water supply  infrastructure,  as  well  as  energy  assets.  The  hydropower  sector  is particularly vulnerable, as Kenya has experienced numerous floods and droughts over the past decade.

## An attractive investment environment with room to mobilise greater levels of private capital

Kenya's  energy  sector  has  become  an  attractive  destination  for  international public  and  private  capital.  Public  investment,  especially  in  grids  and  rural electrification,  has  been  crucial  in  driving  the  sector's  growth.  However,  the government is increasingly relying on development finance institutions (DFIs) and private investment to fund key projects due to limited fiscal space.

Kenya's attractive policy environment for investors, along with strong growth, a large, skilled workforce and developed tech and fintech infrastructure, has made

Nairobi a hub for innovators and start-ups. However, private investors still face a series of both actual and perceived risks, which limit their involvement to the more established  sectors  where  these  risks  are  considered  lower,  such  as  power generation and electricity access, and pushes up the cost of capital. DFIs therefore continue to play a key role in both derisking private capital and in funding areas such as grids, clean cooking and end-use sectors.

The  government  has  an  Energy  Transition  and  Investment  Plan  2023-2050 (ETIP), which can provide investors with a clear sense of the focus areas. The ETIP estimates a need for USD 600 billion in investments to 2050, with the power and transport sectors accounting for nearly 90%. To support the implementation of the ETIP, the government could develop roadmaps and clarify priorities where private  sector  investment  is  needed.  Furthermore,  clarification  around  fiscal incentives  for  solar  products  and  clean  cooking  solutions  are  necessary  to stimulate greater private sector investment and ensure affordable energy access.

Over the longer term, there is significant scope for the role of Kenya's domestic financial sector to take on a larger role in the energy sector. Kenya has one of the most developed financial markets on the continent, with relatively well-capitalised commercial banks and a growing pool of institutional investor capital. In recent years,  efforts  have  been  made  to  blend  local  commercial  bank  capital  with financing  from  DFIs  in  order  to  extend  tenors  and  reduce  the  cost  of  capital. Meanwhile, on the institutional side, green bonds are being explored - with the issuance  of  clean  cooking  bonds  in  2023  -  as  well  as  the  creation  of  a  local currency guarantee scheme. These developments should allow for a growth in local currency  financing,  which  is  particularly  important  for  the  growth  of locally-owned energy businesses.

## 1. General energy policy

## Country overview

The Republic of Kenya (hereafter 'Kenya') is a country in East Africa that borders Ethiopia, Somalia, South Sudan, the United Republic of Tanzania and Uganda. The capital city, Nairobi, is located in the south-central part of the country and is where most of the economic activity takes place. Inland territories in the central and  south-western  parts  of  the  country  towards  the  border  of  Uganda  and Lake Victoria  are  the  most  populated,  as  well  as  around  the  coastal  city  of Mombasa, Kenya's second-largest city. Kenya formally became independent from the United Kingdom in 1963 and joined as a member of the Commonwealth the same year.

The population of Kenya reached 55 million in 2023, with a growth rate of 2% per year. The median age in Kenya is 19.6, with 37% of total population under 14. The population is ethnically diverse, and the official languages are Swahili and English.

Kenya's Human Development Index score is relatively low, ranking 146th out of 193 countries. Out of the whole population, almost 8% live in extreme poverty (less than USD 2.15 a day) and more than one-third live in overall poverty with a lack of accessibility to adequate food and other basic expenses. One factor of food insecurity is climate change in arid and semi-arid regions, which comprises 80% of the country's land.

In 2023, Kenya had a gross domestic product (GDP) of USD 107.4 billion and a GDP per capita  equal  to  USD 1 950.  In  2023,  Kenya's  GDP  by  sector  was: services (tourism, finance, retail) at 55%, agriculture at 22%, and industry at 17%. A  significant  portion  of  Kenya's  economy  is  informal,  and  is  estimated  to  be equivalent to as much as 25-30% of the country's official GDP.

Kenya's  total  exports  surged  to  USD 7.8 billion  in  2023,  a  56%  increase  from 2020, while total imports reached USD 20.3 billion, growing by 59% from 2020. Petroleum products were by far the first imported product by value, accounting for USD 4.7 billion in 2023, followed by machinery at USD 2.2 billion.

## Growing energy demand

In the past decade, Kenya's economic and population growth drove up energy production,  supply  and  consumption  (Figure 1.1).  Electricity  consumption  has increased  significantly,  from 6.6 terawatts  hour  (TWh)  in  2012  to  10.5 TWh  in

2023. The country's domestic energy production covers a significant share of total energy supply at 80% in 2022, mainly thanks to the use of domestic bioenergy and geothermal sources.

Kenya's energy system is dominated by renewable energy, with two-thirds of total energy supply covered by bioenergy and an increasing share of geothermal, solar, wind  and  hydro.  Imported  oil and  coal complete  Kenya's  energy  supply (Figure 1.2).

Figure 1.1  Trends of GDP, population and key indicators in Kenya, 2005-2023

<!-- image -->

IEA. CC BY 4.0.

Notes: GHG = greenhouse gas; TES = total energy supply. Greenhouse gas emissions only available until 2022. Source: IEA (2024), World Energy Balances (database).

Figure 1.2  Energy production, total energy supply and total final energy consumption by fuel in Kenya, 2010-2023

<!-- image -->

IEA. CC BY 4.0.

Note: PJ = petajoule.

Source: IEA (2024), World Energy Balances (database).

Energy  demand  has  increased  since  2010  especially  from  the  transport  and buildings sectors, with the industry sector also growing but at a slower pace. The buildings  sector  is  responsible  for  the  highest  share  of  energy  demand  (68% in 2023), followed by transport (20%) then industry (12%).

Bioenergy is used mainly in buildings, either directly as firewood or transformed into charcoal. The transport sector relies exclusively on oil, while Kenya's industry sector  has  a  diversified  energy  mix,  made  up  of  coal,  electricity  and  oil (Figure 1.3).

<!-- image -->

Source: IEA (2024), World Energy Balances (database).

## Governance and policy frameworks

## Kenya has strong economic growth, but still requires reforms to end poverty and reduce foreign debt

As the largest economy in East Africa, Kenya has undergone significant political and  economic  reforms  over  the  past  decade,  fostering  sustainable  economic growth,  social  development  and  political  stability.  Kenya's  economic  growth slowed to 4.8 % in 2022 from 7.6% in 2021 due to drought, rising commodity prices and global financial conditions. In 2023, Kenya's GDP growth rose to 5.6%, but is expected to slow down again in 2024. In September 2022, Kenya experienced its highest inflation rate in five years at 9.2%, exacerbated by a decline in agricultural production  due  to  climate  change.  Underlying  social  crises  of  poverty  and inequalities remain a challenge in Kenya. The country has experienced drastically increasing commodity prices of food, fuel and electricity, with the price level being 6.9% higher in January 2024 than in January 2023. Further, Kenya's domestic and foreign debt has reached USD 80 billion, representing approximately 70% of its GDP.

The National Tax Policy of 2023 was created as part of the Kenyan government's efforts to enhance predictability and transparency in tax policies and is aligned with the Fourth Medium-Term Plan (2023-2027) of Vision 2030. To support the Policy,  the  Kenyan  government  proposed  the  Finance  Bill  2024,  aimed  at changing the taxation system by increasing several existing taxes and introducing new  ones  to  increase  the  government  budget  by  USD 2.7 billion  to  minimise budget deficits and new borrowing. The bill included a 16% tax on bread and a 25% tax on cooking oil, as well as an eco-levy on environmentally harmful goods such as mobile phones, plastic and diapers. The president withdrew the bill in June  2024  after  mass  protests  erupted,  mainly  led  by  unemployed  youth (the youth  unemployment  rate  was  more  than  12%  in  2021,  compared  to  the national unemployment rate of 5.7%), that on some occasions resulted in violence.

## Governance and overarching policy frameworks

The Ministry of Energy and Petroleum is tasked with developing and implementing policies to create an enabling environment for the efficient operation and growth of  Kenya's  energy  sector.  It  determines  strategic  directions  to  facilitate  sector growth  while  providing  a  long-term  vision  for  all  stakeholders.  It  promotes  the development  of  hydropower,  geothermal  and  renewable  energy;  oversees  the rural  electrification  programme;  and  provides  guidance  on  energy  regulation, security and energy efficiency.

Under the Ministry of Energy and Petroleum, several semi-autonomous governmental agencies operate: Kenya  Electricity Transmission Company (KETRACO),  Kenya  Power  and  Lighting  Company  (KPLC),  the  Energy  and Petroleum Regulatory Authority (EPRA), the Rural Electrification and Renewable Energy  Corporation  (REREC),  and  the  Geothermal  Development  Company (GDC). The Kenya Electricity Generating Company (KenGen), the leading power generation company in Kenya, has 70% government ownership and 30% private shareholder ownership.

EPRA was established under Section 9 of the Energy Act and is responsible for energy sector regulation, including regulating the generation, trade, transmission, distribution, supply and use of electricity, including renewables. EPRA oversees demand  forecasting  and  system  planning,  maintains  data  and  statistics,  and determines tariffs and tariff structures.

While KenGen is responsible for the generation of electricity, KETRACO plays a critical role in distribution and supply. KETRACO manages the national power grid and  the underlying power  networks,  ensuring  that electricity is efficiently distributed  to  households,  businesses  and  industrial  customers  across  the country.  While  KETRACO  operates  and  manages  the  high-voltage  network (132 kilovolts [kV] and above), KPLC is the system operator that operates and

maintains  the  medium-  and  low-voltage  distribution  network.  Retail  electricity distribution  and  system  operation  within  the  country  is  the  primary  purview  of KPLC.

Kenya's overarching law, the Constitution of Kenya of 2010, establishes that the national  government  is  responsible  for  the  protection  of  the  environment  and natural resources, as well as energy policy including electricity and gas reticulation and energy regulation. Kenya has undertaken considerable efforts to address its core national development objectives as reflected in its Vision 2030 (unveiled in 2008), which aims to transform Kenya into a newly industrialising middle-income country with  a  high  quality  of  life  by  2030  in  a  clean  and  secure  environment. Vision 2030 strongly emphasises infrastructure development, including for energy. The development of Vision 2030 involved extensive stakeholder dialogue among government bodies, private enterprises and civil society and is broadly considered to be a consensus for the country's future.

Progress is best demonstrated through advances in electricity access rates, which reached 79% in 2023, while simultaneously achieving nearly 90% of electricity generation via renewable energy sources in the same year. The prioritisation of renewable  energy  technologies  for  growth  is  reflective  of  the  government's commitment to the Paris Agreement and the principals set out in Kenya's Climate Change Act from 2016, which was revised in 2023.

## The five-year review of the 2018 National Energy Policy provides an opportunity for growth in the energy sector

Kenya has a number of energy policies, roadmaps and strategies that have been conceived to  provide  an  enabling  environment  for  growth,  centring  around  the foundational Energy Act of 2019. The Act establishes the energy sector entities and regulates production, supply and use of energy. It also establishes EPRA. The Energy Act further calls for updating the National Energy Policy of 2018 every five years to ensure the overarching policy can adapt and respond to changing technologies,  global  trends  and  policies.  The  2023  mandated  review  is  being carried out through  a  consultative  process,  engaging  stakeholders  across 11 thematic  areas,  with  completion  expected  in  late  2024  or  early  2025.  This required five-year update involved diverse stakeholders and ensures a comprehensive  and  timely  policy  that  aligns  with  national,  regional  and  global trends in the energy and related sectors.

The National Energy Policy provides a comprehensive overview of the state of the energy sector and provides recommendations for various sub-themes. The policy recommendations in the 2018 document cover topics such as coal, renewable energy  (including  geothermal  and  hydro),  electricity,  energy  efficiency  and conservation,  land,  environment,  health  and  safety,  energy  services,  energy

financing,  energy  pricing,  and  socio-economic  issues.  The  ongoing  review process in 2024, which also includes participation from the public, comes at an opportune time and will address changes in the energy landscape, in particular within access, security and resilience, economic competitiveness, energy efficiency, geopolitics, and technological innovation.

Kenya's significant number of energy-related laws, strategies, regulations, policies and  programmes  underscore  the  country's  strong  focus  on  energy  policy. However, the multitude of laws and policies may also present challenges. In some cases, for instance, no clear and detailed implementation plans exist.

Due  to  the  cross-sectoral  nature  of  energy  policies  and  planning,  effective co-ordination and consultation are essential for coherent, efficient and successful execution.  Kenya's  wide  array  of  energy-related  policies  and  plans  and  the vibrancy of its energy sector means that co-ordination and alignment among the various cabinet ministries and semi-autonomous governmental agencies, whose activities affect different aspects of government policy on energy, is a critical factor for successful energy sector development. In addition to the Ministry of Energy and Petroleum and all its subsidiary units, effective policy making for the energy sector  requires  close  co-ordination  with  the  Office  of  the  Presidency  and  the ministries responsible for transport, agriculture, climate and environment, trade, industry, rural development, housing, and other relevant portfolios. This highlights the necessity of having an integrated approach that leads to effective prioritisation, prevents  redundancy,  simplifies  procedures,  and  improves  monitoring  and implementation.

Involving non-governmental stakeholders, such as the private sector, is crucial when  developing  a  new  strategy  or  policy  to  ensure  a  comprehensive  and contextually relevant plan. The  IEA  commends  Kenya  for  consulting  with non-governmental stakeholders when drafting government strategies, policies and plans, most recently and notably in the new Kenya National Cooking Transition Strategy 2024. Despite this, non-governmental stakeholders report inefficient and unstructured communication with ministries, and sense a lack of co-ordination and harmonisation. Fluid communication and co-operation between departments and with other stakeholders could increase the efficiency with which Kenya reaches its ambitious development goals.

Further, in the absence  of  allocated  budgetary  resources,  implementation schedules  and  administrative  accountability,  progress  may  fall  short  of  stated goals and targets. The ongoing preparations for the National Energy Policy review and  the  government's  Integrated  National  Energy  Plan  aim  to  tackle  these challenges and offer a clearer framework for the implementation of Kenya's energy objectives.

## High renewable energy potential and a skilled workforce make Kenya attractive for green industry

Kenya's  high  renewable  energy  potential  means  the  country  is  well  placed  to attract green industry. Industrial growth and investment, co-ordinated among both the  Kenyan  government  and  the  private  sector,  can  spur  domestic  economic growth, create valuable employment and skills, and expand the market share of low-carbon industrial products and manufactured goods. This potential has been recognised through international programmes  such  as  the  African Green Industrialisation Initiative launched by the Kenyan president at COP28 in Dubai and aimed at scaling up green industries across the continent.

Kenya  boasts  a  skilled  workforce  across  the  energy  and  related  sectors, particularly engineering technicians, electrical engineering technicians and geologists. The focus on skills and technical certifications within its labour force will  need  to  grow  at  a  pace  that  matches  the  expanding  reach  of  the  energy network,  particularly  in  rural  areas.  Technical  and  vocational  education  and training will need to cater to the skill requirements of emerging technologies such as hydrogen production. Capacity-building programmes such as the IEA energy efficiency training  week or other similar capacity training programmes, may be able to assist with further institutional skills requirements.

Employment  in  the  energy  sector  is  gender-informed  and  public  utilities  have targets for female participation in the sector. The Constitution of 2010 mandates that no one gender should make up greater than two-thirds of the composition of public  committees.  Much  progress  has  been  made  in  the  last  ten  years,  and women now occupy at large senior positions such as management positions and on boards.

Further, Kenya has a people-centred, inclusive approach to energy for development, with clear steps taken to advance rural electrification rates, working closely  with  community  leaders  and  administrative  counties.  This  includes  the introduction of targeted subsidies, such as the domestic lifeline tariff.

## Statistics and data

In the area of energy data and statistics, the Ministry of Energy and Petroleum and the Kenya National Bureau of Statistics (KNBS) are the main sources of data used at the IEA. KNBS is the official statistical agency for the government of Kenya and was established by an act of parliament - the Statistics Act, 2006 No. 4 - as a semi-autonomous government agency under the Ministry of State for Planning, National Development and Vision 2030. The legal framework for data is embedded in  the  Energy  Act  of  2019,  which  establishes  the  energy  sector  entities  and regulates the production, supply and use of energy.

KNBS  includes  statistics  on  firewood  and  charcoal  in  its  economic  surveys, although  the  data  fluctuate  considerably.  The  significant  increase  observed following the years 2019/20 can be attributed to the energy crisis in 2021 and the subsequent increase in energy prices, but all in all it would be good to understand the underlying  data  collection  or  estimation  methodologies,  given  national relevance.

In  recent  years,  Kenya  has  improved  the  coverage,  quality  and  timeliness  of energy balances and related data, but the quality of the data could be significantly improved for all fuels and sectors. Key areas for improvement could include a focus  on  aligning  electricity  data  originating  from  various  sources  and  further disaggregating demand-side data for all sectors across different fuels. Given that responsibility for compiling energy statistics is divided between several institutions, enhanced communication between these institutions needs to be a high priority.

Currently, energy statistics for Kenya are available through reports on different institutions' websites such as EPRA, KPLC and KNBS. Furthermore, there is no structured database containing all national energy supply and demand data that are  publicly  accessible  for  users  to  make  full  or  customised  data  extractions. Access to  and  dissemination  of  national  energy  statistics  can  be  improved  by having a publicly accessible online platform with a schedule of data releases and user-friendly formats (infographics, spreadsheets, csv).

There currently appears to be limited metadata available. Such metadata would be extremely valuable for understanding data trends and ensuring transparency and robustness in data-collection methods.

## Recommendations

To reach its objectives, the government of Kenya could consider:

-  Developing clear, prioritised and well-co-ordinated implementation plans to deliver on  Kenya's  overall  strategy  for  modernising  its  energy  sector,  including  the availability of a skilled workforce.
-  Enhancing  inter-ministerial  co-ordination  to  promote  effective  development  of Kenya's energy sector.
-  Maintaining and improving the timeliness, completeness and accuracy of national energy data, especially for demand-side data, including by aligning collection and reporting methodologies.
-  Modernising  the  national energy  statistics system  by  establishing a data dashboard, including  upgrading  the data management infrastructure  through  a centralised data repository.

## 2. Electricity

## Overview

Kenya has abundant renewable energy resources, with wind, solar, geothermal and hydro accounting for nearly 90% of generation. Furthermore, it is one of the lowest-cost geothermal power developers in the world. As a result of its sustained electrification efforts, electricity access has risen to 79% from 37% over the past decade.  However, Kenya's electricity sector has experienced low growth over the last two decades despite an aggressive electrification programme.

The power sector has roughly 3.3 gigawatts (GW) of installed generation capacity and  is  dominated  by  renewable  sources,  which  account  for  80%  of  capacity. Geothermal is the largest source of electricity generation followed by hydro, wind, oil and solar photovoltaics (PV). Kenya has made notable progress in recent years in diversifying its sources of electricity by increasing generation from geothermal, wind  and  solar PV  and  decreasing  its  reliance  on  hydro,  which  is  prone  to variability with fluctuations of water availability.

## Guiding policies

The Ministry of Energy and Petroleum published the National Energy Policy in 2018. Its objective is to ensure an affordable, competitive, sustainable and reliable supply of energy at the least cost to meet national and county development needs while protecting and conserving the environment. It identifies the key challenges facing  the  electricity  sector  and  outlines  the  policies  and  strategies  needed  to overcome them in the short, medium and long term.

A new Energy Act was developed and gazetted on 31 March 2019. It amended the Energy Act of 2006, consolidated the laws relating to energy, and delineated the  functions  of  the  national  and  devolved  levels  of  government  concerning energy. It redefined the mandate of energy-dedicated public authorities, regulated the development of renewable energy sources, and established a framework for electricity supply and consumption. The Energy Act also established EPRA as the successor to the Energy Regulatory Commission.

The Power Generation and Transmission Master Plan, published in 2015 by the Ministry of Energy and Petroleum, sets out the country's long-term plan for key elements of the power sector for the period 2015-35. The Plan identifies suitable expansion pathways for the Kenyan power system in line with defined planning criteria and frameworks.

The Kenya National Electrification Strategy is a roadmap for achieving universal access to electricity, a cornerstone of the country's development agenda. It sets out a strategy to achieve electricity access for all households and businesses in Kenya over the shortest possible timetable and at an acceptable quality of service.

In January 2021, the Ministry of Energy and Petroleum published its Renewable Energy Auction Policy (REAP), which outlines the approach for renewable energy procurement in Kenya by means of competitive auctions. Later in the same year, EPRA published several benchmark tariffs to be reviewed annually and applied to all  wind  and  solar  projects  (regardless  of  capacity),  as  well  as  small  hydro, biomass and biogas projects greater than 20 megawatts (MW), pursuant to the REAP.

The Feed-in Tariff Policy (2021) is a revision of the 2012 Feed-in Tariff Policy with substantial changes introduced to align with the Energy Act of 2019 and other changes since the previous Act. The new policy limits feed-in tariffs to small-scale biomass, biogas and small hydro projects (up to 20 MW). All solar and wind power projects, as well as other renewable energy projects larger than 20 MW, will be procured  under  the  REAP,  which  provides  that  EPRA  may  run  a  competitive process before awarding a generation licence under the Energy Act.

Published in 2021 by the Ministry of Energy and Petroleum, the Updated Least Cost Power Development Plan (LCPDP): Study Period 2020-2040, is intended to guide power policy and investment decisions in the country. Following this, the Ministry  published  a  ten-year  LCPDP for the  period  2021-30,  derived from  the longer-term  LCPDP.  The  update  is  intended  to  make  long-term  planning assumptions more predictable, given the greater certainty in planning for a 10-year period compared to a 20-year one. The objective of the LCPDP is to ensure that the demand-supply balance is not skewed too heavily towards supply to avoid stranded generation investments and resulting higher system costs. The Plan also focuses  on  system  requirements  for  the  integration of renewable  energy technologies and provides guidance on affordable tariffs.

The National Climate Change Framework Policy and National Climate Change Action Plan also have implications for the electricity sector, notably in terms of energy infrastructure resilience.

## Governance and market oversight

Kenya has made significant  progress  in  modernising  its  electricity  sector.  The power sector governance framework has evolved continuously since the 1990s to reflect changing market fundamentals, support the development of new technologies and ensure a reliable electricity supply for its growing economy. The government adopted policy and regulatory reforms to attract new investments,

improve competition and gradually open the market to private investment. This process culminated in the adoption of the Energy Act in 2019, which liberalised electricity supply.

The  key  agencies  involved  in  managing  and  regulating  the  electricity  sector include  the  Ministry  of  Energy  and  Petroleum,  EPRA,  KPLC,  KenGen,  GDC, KETRACO and REREC (see Chapter 1).

The Ministry of Energy and Petroleum promotes the development of renewable energy; oversees the rural electrification programme; and provides guidance on energy regulation, security and energy efficiency.

EPRA regulates the generation, trade, transmission, distribution, supply and use of electricity as well as overseeing demand forecasting and system planning and determining tariffs.

Following enactment of the Energy Act of 2019, REREC was mandated to lead Kenya's clean energy programmes and implement rural electrification projects. The  Renewable  Energy  Resource  Advisory  Committee  is  an  inter-ministerial committee that advises the Minister for Energy on the criteria for the allocation of renewable resources, licensing of renewable energy resource areas, management of water resources, development of dams and reservoirs for power generation, and the management and development of renewable energy sources.

The purpose of the Energy and Petroleum Tribunal is to resolve disputes arising from  licences  issued  or  declined  by  EPRA.  The  Public-Private  Partnerships Directorate  is  mandated  to  facilitate  the  implementation  of  the  Public-Private Partnership Programme and Projects in Kenya.

The electricity sector is largely state-dominated but there are some independent players in the generation market. KenGen, the largest power producer in Kenya, produces power from hydro, geothermal, thermal and wind sources, selling power to customers on a wholesale basis. Several independent power producers (IPPs) supply power to the grid, and approximately 30% of power generation comes from generation assets operated by IPPs.

The Kenya Power and Lighting Company (Kenya Power) owns and operates most of the electricity distribution assets in Kenya. The government owns slightly over half of the company with the remainder listed on the Nairobi Securities Exchange. KETRACO is a state-owned entity that owns, operates and maintains the highvoltage electricity transmission grid and regional power interconnectors. Following the  adoption  of  the  Energy  Act  of  2019,  KETRACO  was  designated  as  the transmission system operator.

GDC is a fully government-owned company charged with developing steam fields and  selling  geothermal  steam  for  electricity  generation  to  KenGen  and  other stakeholders.

## Electricity supply and demand

## Electricity capacity

At around 3.3 GW, the total generating capacity of the Kenyan power system is relatively small compared to its population. Geothermal is the largest source of capacity with 950 MW, followed by hydro, which accounts for around 830 MW; oil at around 680 MW; wind with 470 MW; and solar PV with 330 MW (Figure 2.1). As mentioned above, in the case of solar, wind and small hydro additions, Kenya's plan is to transition from a system based on feed-in tariffs to an auction scheme. While the initial auctions have yet to be announced, firm pricing structures coupled with a reliable schedule would accelerate expansion.

Hydropower, traditionally the largest source of electricity, has remained stagnant over the past decade. The largest resources can be found along the Tana River to the north of Nairobi and on the Turkwel River in the west of the country. Kenya has  ample  wind  resources  and  the  highest  wind  speeds  can  be  found  in  the north-west of the country around Lake Turkana where Kenya hosts Africa's largest wind farm. The 310 MW plant can supply up to 10% of Kenya's peak electricity demand. Other large plants can be found at Kipeto and Ngong.

<!-- image -->

Source: IEA (2024), Electricity Information (database).

Geothermal energy is heat derived from the sub-surface of the earth. Depending on its characteristics, geothermal energy can be used for local or district heating and cooling purposes or can be harnessed to generate carbon-free electricity if

the temperature is adequate. The Great Rift Valley in Kenya is a rich resource of geothermal energy, and the country first initiated the development of geothermal power generation  in  this  region  in  the  1970s.  To  date,  the  bulk  of  geothermal projects have been developed in the Olkaria area in the Hell's Gate National Park. Smaller projects have been developed in Menengai about 100 kilometres (km) to the north of Olkaria.

## Electricity generation output

Total  electricity  demand  in  2022  was  around  13 300 gigawatt hours  (GWh). KenGen  delivered  around  8 000 GWh,  independent  power  producers  around 4 500 GWh, and the remainder came from small rural producers and REREC-owned  Garissa  Solar  Power  Plant.  Electricity  generation  output  is dominated  by  renewables,  which  accounted  for  almost  90%  of  electricity generation in 2022. Electricity production has increased significantly over the past decade, largely the result of significant growth in geothermal energy capacity. The share  of  electricity  generation  from  geothermal  sources  increased  from  15% electricity  output (1.1 terawatt hours [TWh]) in 2010 to 47% (5.5 TWh) in 2023. Hydropower is the next largest source of electricity supply, accounting for around 21% (3 TWh) of generation in 2023 (Figure 2.2).

The share of hydropower in generation output in 2010 was 45% but the volume remained flat as total output increased. In recent years, the share of wind energy has grown significantly, from 5% in 2018 to 17% in 2022. Solar PV contributed for around 3% of electricity generation in 2022, more than double that of the previous year thanks to the commissioning of several new projects.

## Figure 2.2  Electricity generation by source in Kenya, 2010-2023

<!-- image -->

IEA. CC BY 4.0.

Source: IEA (2024), World Energy Balances (database).

Given the high share of renewables in the generation mix, the carbon intensity of the power sector is low, albeit somewhat dependent on the share of hydropower

available. For instance, when hydropower resources are low, oil capacity may run, leading to an increase in GHG emissions from the power sector. This effect can be observed by the sharp increase in GHG emissions from the power sector in 2017, following severe droughts in 2016 that decreased hydropower generation (Figure 2.3).

Nonetheless, recent trends in wind and solar PV capacity additions suggest that emissions from the  sector  are  likely  to  decline  in  the  coming  years  if  capacity expansion can meet demand for electricity. Conversely, Kenya's legacy feed-in tariff programme spurred multiple new solar PV and wind project announcements, but  power  purchase  agreement  (PPA)  renegotiations,  in  part  related  to  cost concerns, and land-rights issues led to project cancellations.

<!-- image -->

The increasing share of variable renewables is seen by both government and the private sector as a future challenge for system operations, and work is underway to  improve  dispatch  models,  system  services  and  storage  options  (including ancillary services, regional interconnections, battery storage, etc.).

## Networks

Following the adoption of the Electric Power Act of 1997, Kenya embarked on a series of reforms that led to the unbundling of generation from transmission and distribution services in the electricity market. As a result, KenGen took on power generation functions while Kenya Power assumed control of most transmission and  distribution  services.  This  marked  the  beginning  of  Kenya's  path  toward opening the electricity market and introducing competition in power generation. The size of the transmission network (400 kV, 220 kV and 132 kV) is approximately 6 300 km, of which around 3 900 km is owned by Kenya Power and 2 400 km is owned by KETRACO.

In 2024, Kenya introduced regulatory changes to end the existing monopolies in transmission and distribution held by KETRACO and Kenya Power, respectively. The Energy (Electricity Market, Bulk Supply and Open Access) Regulations 2024 provide  open  access  to  the  transmission  and  distribution  systems  for  privately owned distribution companies at a tariff. While implementation of these rules is at an early stage, they fail to address problems such as the allocation of existing fixed contracts entered into by the current sole off-taker, whose costs would be spread over a smaller customer base should wholesale or retail competition enter the market without this (and other problems) being addressed. Ideally, this move would increase competition, efficiency and reliability and improve the quality of service  within  the  electricity  market  while  attracting  investment  in  generation, transmission,  distribution  and  retail  supply.  With  planned  interconnections  of Kenya's electricity network with Tanzania and other Eastern Africa Power Pool (EAPP) countries, which is set to commence trading as early as 2025, as well as the strengthening of the interconnection with Uganda through the Nile Equatorial Lakes  Countries  Electric  Grids  Interconnection  Project,  the  government  views these  regulatory  changes  as  having  the  potential  to  boost  market  and  supply options  for  both  power  generation  and  large  consumers.  Kenya  could  access Southern  Africa  Power  Pool  via  Tanzania  once  the  Kenya-Tanzania  and Tanzania-Zambia interconnections are completed.

While KPLC oversaw a large grid expansion programme, which resulted in the growth of customer connections, the country also has a growing number of off-grid and mini-grid systems, led by solar home systems and solar-powered mini-grids. Almost one in five Kenyans accesses electricity through off-grid connections and Kenya has the highest share of households that access electricity through solar home systems globally.

Power sector planning has historically been done in an independent manner but will now have to be co-ordinated with the Integrated National Energy Plan, which covers  all  energy  sectors.  For  the  Integrated  National  Energy  Plan  to  be successful, there will need to be an increased level of co-ordination for demand forecasting  as  well  as  assessments  for  either  electrification  of  other  sectors (e.g. industry, transportation, agriculture, etc.) or policies around demand stimulation for electricity. Stakeholder consultation is an important factor to ensure that power sector infrastructure is balanced with future demand projections.

The Generation and Transmission Master Plan is the main implementation plan for the power sector. One of the main inputs comes from the LCPDP, which is developed by public entities and publicly owned companies and based on power sector modelling.

Clarity  on  future  electricity  demand  and  energy  generation  will  be  important  to project the need for grid expansion and financing and drive sector development.

In this regard, the three scenarios of low, medium and high in the LCPDP mediumcase scenario is well grounded in reasonable assumptions and can be used to plan future investment in power generation, transmission and distribution.

Kenya's  electricity  grid  shares  interconnections  with  Ethiopia,  Tanzania  and Uganda. The Kenya-Ethiopia connection has a technical potential of 2 000 MW but  imports  on  the  line  are  limited  to  300 MW  pending  completion  of  ongoing reinforcements of the Kenya network expected for 2026. The installed capacity, coupled  with  the  import  agreements,  is  sufficient  to  meet  Kenya's  present electricity demand. For example, construction of the Kenya-Tanzania Interconnector, a 96-km, 400 kV double circuit line between Isinya and Namanga is underway.  Funded  by  the  African  Development  Bank  and  the  Kenyan government, the line is expected to facilitate power exchange between Ethiopia, Kenya, Tanzania, the EAPP and Egypt and Sudan in the north.

Growing interconnections between countries in East Africa support the exchange of power for balancing and supply. The EAPP has been under development for several years and seems to be reaching maturity in a form where it could become active in a few years with day-ahead market trading expected as early as 2025.

## Network losses

Many  electricity  systems  in  Africa  face  extremely  high  network  losses,  which averaged 15% across the continent in 2020 - almost twice the global average of 8%. These losses result from underinvestment and ageing infrastructure, though other factors such as overgrown vegetation (especially in remote areas), natural disasters,  vandalism  and  theft  contribute.  In  2023,  losses  on  Kenya's  power system were estimated to be as high as 23%, about half of which were technical losses arising from leakages within the transmission and distribution lines. The remaining  losses  were  attributed  to  power  theft  and  billing  and  collection anomalies.

These losses, alongside taxes and the cost of power generation, affect the final cost  of  electricity,  highlighting  a  potential  to  increase  efficiencies  that  would translate  into  lower  costs.  To  reduce  system  losses,  the  government  could consider  embedding  measures  to  reduce  power  system  losses  and  improve system  efficiency  in  the  overall  strategy  for  delivering  universal  access  to electricity. This could include applying smart solutions to power system management to identify and respond to system-loss hotspots at  the  county  or individual distribution transformer level.

In addition to high levels of system losses, the average frequency and duration of power  outages  in  Kenya  is  above  global  averages.  On  average,  customers experienced around 45 unplanned outages in the year to June 2023, increasing from 29 (2020/21) and 38 (2021/22), with individual outages lasting on average

nearly 5 hours. To address this problem, the national regulator, EPRA, recently proposed limits to the System Average Interruption Frequency Indicator (SAIFI) the number of times an average customer is hit by a blackout - at 20 per year.

Further,  the  regulator  proposed  a  limit  of  80 hours  for  total  time  an  individual customer  experiences  an  outage  in  one  year.  EPRA  already  established performance indicators, including a System Average Interruption Duration Index (SAIDI), a SAIFI and a Customer Average Interruption Duration Index, for the next four years, when it approves retail tariffs. It would be beneficial to combine actions to  reduce  the  frequency  and  duration  of  power  outages  with  reforms  to  the flexibility/ancillary  services  market  that  would  attract  other  service  providers  to invest in energy storage, demand-side response and other technologies such as static  synchronous  compensators to  manage  grid  frequency  stability  and  the piloting of battery energy storage in several regions.

Kenya also experiences episodes of vandalism, which weakens infrastructure. In the 2022/23 financial year, Kenya Power reported a 46% increase in cases of transformer vandalism, with 242 transformers impacted compared to 165 in the previous year. Low reliability of the electricity system hampers further electrification and could be a major obstacle for the adoption of new technologies for clean cooking and e-mobility.

## Technical codes

The Kenya National Transmission Grid Code is the primary technical code for the transmission system, setting out the technical regulations for connecting to and using  the  system.  Furthermore,  the  code  has  been  developed  considering  the EAPP  and  East  African  Community  Interconnection  Code  (EAPP IC).  As  a member of the  EAPP, Kenya  adheres to  the  requirements  imposed  on  EAPP member countries, which also apply to users of the Kenya National Transmission System.

## Retail market and energy prices

The adoption of the Energy Act of 2019 marked out the future structure of the electricity sector with an independent system operator as well as envisaging new transmission and distribution licensees and open access to both the transmission and distribution systems. The law introduced a licensing regime for traders and retailers and broadened the concept of an eligible consumer who can purchase power from the source of their choice. This provision enables competition between generators and retailers to supply clients at both the wholesale and retail levels. The Act sets out the future structure of the electricity sector. The process has not been completed and it will be important to clarify roles and responsibilities in the power sector as to when the system operation is transferred and how investment

in  grid  expansion  will  be  financed.  It  is  also  important  to  highlight  that  what  is envisaged in the Act has not yet been pursued and that several significant hurdles remain to making it a reality. Instead, the Act is only likely to be realised gradually and  slowly  over  time  and  one  could  argue  that  the  decision makers'  cautious approach is warranted.

Source: IEA (2024), Energy Prices (database).

<!-- image -->

The current market is a single buyer model, with generators entering into a PPA with the single buyer, KPLC. There is currently no market for services for system operations,  but  EPRA  has  released  draft  Energy  Regulations  for  Electricity Market, Bulk Supply and Open Access. To ensure confidence in the regulations and future electricity markets, there is a need for greater stakeholder consultation, as several elements of these draft rules require further elaboration and refinement.

EPRA is responsible for determining electricity tariffs in Kenya. The Schedule of Tariffs 2022/23-2025/26 established the cost items incorporated into the retail tariff charged  by  KPLC,  and  took  effect  from  1 April 2023.  EPRA  declared  a  4% reduction in electricity bills for 6.3 million domestic customers who consume less than  30 kilowatt hours  (kWh),  accounting  for  more  than  70%  of  domestic customers. EPRA also provides for certain tariff adjustments, including regular pass through of foreign exchange and inflation changes, which are added to the end-user tariff (see Chapter 4).

## Recommendations

## To reach its objectives, the government of Kenya could consider:

-  Assigning clear roles and responsibilities in the power sector (as mandated by the Energy Act of 2019) before implementing new market structures. This can support the  many  developments  in  the  power  sector  and  enhance  power  system operations.
-  Strengthening the reliability of the transmission and distribution grids to reduce power outages and mobilising the capital necessary to upgrade the medium- and low-voltage network.
-  Harmonising planning approaches and tools for power sector modelling to ensure improved optimisation of energy supply and demand-side projections.

## 3. Renewable energy

## Renewable generation

## Renewable energy already provides the vast majority of Kenya's electricity

Renewable  energy  accounted  for  nearly  80%  of  Kenya's  total  energy  supply in 2022, with traditional biomass  accounting  for  62%,  mostly  for  cooking. Renewable electricity accounted for the remaining 18%. Kenya currently has over 2.6 GW of installed renewable energy generation capacity accounting for nearly 90% of power generation in 2023. Geothermal power (47%) provided the highest share  of  renewable  electricity,  followed  by  hydropower,  wind  and  solar  PV (Figure 3.1).  Kenya  has  abundant  resources,  including  untapped  potential  for additional geothermal resources. The country has a 2030 target for 100% of power generation from renewable energy and 100% access to electricity by 2030.

Source: IEA (2024), World Energy Balances (database).

<!-- image -->

## A strong policy framework has set the groundwork for the continued development of renewable energy

Several policies are guiding Kenya towards its 100% renewable generation goal. They  include:  the  Energy  Act  of  2019,  the  Bioenergy  Strategy  2020,  the Renewable  Energy  Auctions  Policy,  the  Feed-in  Tariffs  Policy  on  Renewable Energy Resources and the Energy (Net-Metering) Regulations 2024.

The  Energy  Act  of  2019  set  the  framework  for  the  development  of  additional policies, including the Renewable Energy Auctions Policy and the Feed-in Tariffs (FIT)  Policy  on  Renewable  Energy  Resources.  In  addition  to  outlining  the establishment of resource maps and inventory, it splits renewable resources into two  groups,  the  first  being  biomass,  biodiesel,  bioethanol,  charcoal,  fuelwood, solar, wind, tidal waves, hydropower, biogas and municipal waste and the second geothermal resources.

The Act gives the EPRA broad regulatory authority over areas including, but not limited  to,  paperwork  and  forms,  fees  and  royalties,  qualifications,  geothermal development, ecological impacts of projects, licensing, energy pricing, and the management of all renewable resources.

In addition to the Energy Act of 2019, the LCPDP provides a ten-year overview for power system growth, including demand-supply projections and levelised costs of energy. The LCPDP provides a roadmap for the expansion of the power system and  includes  four  key  areas:  1) load  forecast;  2) generation  plan;  3) ancillary services  requirements;  and  4) tariff  evolution.  The  currently  publicly  available LCPDP is for 2020-30 and updates country-level conditions post Covid-19 while taking  into  account  various  additional  inputs,  such  as  the  Revised  IPP/PPA Taskforce Report 2020, the Sustainability Report for KPLC, the revised project list and external feedback.

## Abundant geothermal resources allow for both geothermal for power and direct uses

Geothermal capacity holds the highest share of both capacity and generation for renewable energy, with 950 MW of installed capacity (2022). The power stations located in the Great Rift Valley are primarily owned and operated by KenGen, with the  largest  complex  being  the  Olkaria  Geothermal  Project. Independent  power producers  have  also  built  successful  installations  in  the  country.  The  Kenyan government  has  identified  14 additional  areas  for  development,  which  has  an estimated potential of 7-10 GW.

The Energy Act assigns all undeveloped geothermal resources to the national government, which can grant exploration licences for up to two years (with the possibility of renewal). Licences for power production can be assigned for up to 30 years, with the power producer retaining the right to use the post-generation water. The Act creates a framework for the cost of geothermal energy and outlines royalties for the resource extracted: 2.5% for the first ten years and 2-5% for the remaining  years  of  the  licence.  Finally,  the  Act  creates  a  framework  for  the industrial or commercial use (direct utilisation) of geothermal resources.

In  addition  to  geothermal  for  power,  Kenya  has  identified  the  direct  use  of geothermal for uses in agriculture, industry, fisheries and tourism. GDC has a pilot demonstration  programme  for  milk  pasteurisation,  aquaculture,  greenhouses, laundry facilities and grain drying. In 2023, GDC entered into a 25-year agreement to provide steam for cement production, including power uses (a 4 MW plant) and heat for drying. Additional uses for geothermal by-products could include cooling and tea drying. Currently, there is no specific policy supporting the direct use of geothermal energy.

## The development of large-scale hydropower has slowed, but small-scale hydropower can increase electrification

Kenya  has  around  830 MW  of  installed  hydropower  capacity,  with  large-scale projects  typically  owned  by  KenGen,  including  the  country's  largest  dam,  the Gitaru Power  Station  (225 MW).  Two  additional  large  dams,  the  Thwake Multipurpose Dam (33 MW) and the Grand High Falls Dam (500 MW), are being pursued by the government.

The country also has numerous small hydropower installations, with many of the plants owned and operated by the Kenya Tea Development Agency and located within  the  tea-growing  counties  in  Kenya.  In  addition  to  grid  connected  small hydropower  plants, there are numerous  installations, which are not grid connected,  which  provide  power  to  communities  or  businesses.  Aiding  the development of small-scale hydropower is the FIT Policy on Renewable Energy Resources Generated Electricity (small hydro, biomass and biogas), which was originally introduced in 2008, with revisions in 2010, 2012 and finally 2021. The current iteration of the Policy is for biomass, biogas and small hydropower plants under 20 MW and sets a ceiling capacity (10% of total system capacity) for the programme.

The  Policy  outlines  standard  PPA  terms,  including  contract  length  and  a framework for the development of pricing, including fixed and adjustable costs operation and maintenance costs, which are indexed to the consumer price index. In addition, the policy outlines roles and responsibilities for EPRA for PPA contract review and general payment terms for the off-taker. All projects participating in the FIT programme require a PPA.

## Reaching 100% renewable energy in power generation will require additional variable renewable energy

Solar  PV  and  wind  power  currently  total  almost  800 MW  of  installed  capacity combined. Grid-connected solar PV makes up the majority of the installed solar PV capacity, but there is also a substantial amount of off-grid solar PV. For wind, the Lake Turkana Wind Power Project (310.5 MW) accounts for nearly two-thirds

of  total wind  capacity.  It  is  the  largest  wind  power  project  in  Africa,  with construction being completed in 2017 and connection to the national grid occurring in 2018. The majority of this capacity was sourced via a FIT, with development done by KenGen and IPPs.

Prior to the FIT, Kenya relied heavily on run-of-river hydropower for the majority of its domestic power generation. However, following a drought in the mid-2010s, the FIT system sourced quick-start heavy fuel oil generators to help meet supply gaps.  This  has  been  changed  to  a  new  procurement  method:  the  Renewable Energy  Auctions  Policy,  introduced  in  2021.  The  new  auction  system  was introduced, in part, to replace those generators.

New  variable  renewable  energy  (and  any  renewable  energy  projects  above 20 MW) will be governed by the auction system that is technology-neutral with key considerations being price, location and financial viability for the developer. The programme  consists  of  two  stages:  1) prequalification;  and  2) a  technical  and financial evaluation. Bids are evaluated by price, with projects being awarded from lowest bid until the auction volume is achieved. In the new auction programme, developers are responsible for obtaining a grid connection study, land rights and interconnection cost. The policy transfers those projects which were awarded a FIT in the previous FIT programme, to the new auction scheme.

Figure 3.2  Total renewable energy capacity and renewable energy capacity additions in Kenya

Source: IEA (2024), World Energy Balances (database).

<!-- image -->

Development challenges include land-rights issues, which have previously led to project delays and cancellations. Land rights are managed at the county level, independent from federal programmes for renewable procurement. In addition, new development of renewable capacity has been on hold, as projects previously awarded a FIT are transferred to the auction programme.

To manage the variability of solar PV and wind systems, installations might need to  be  paired  with  energy  storage  systems  for  grid  reliability.  In  addition  to  the storage  requirement  for  renewable  projects,  the  country  is  currently  piloting  a 100 megawatt hour (MWh) battery storage system through loans from the World Bank and the Green Climate Fund. Kenya currently has a draft market regulation, which would include an ancillary services market, under review.

## Distributed energy resources are currently active and can increase electrification, but could impact demand

Small-scale  installations  or  solar  PV  can  be  roughly  split  into  two  segments: 1) embedded generation that may or may not be connected to the grid given the system size (systems above a certain size must register  as  a  generator);  and 2) off-grid  systems,  such  as  mini-grids,  pay-as-you-go  (PAYGo)  or  solar  home systems. Kenya is major market for third-party solar kits.

In 2024, the government passed a net metering programme. The programme has a maximum system size of 1 MW with the total capacity capped at 100 MW over the  first  five  years  from  the  start  of  the  programme.  The  regulation  outlines timelines  for approvals,  costs  and  associated  responsibilities,  standardised system agreements and the net metering credit rate of 50% of the exported power.

Off-grid  systems  and  programmes  were  previously  overseen  by  the  Rural Electrification  Authority,  which  was  transitioned  to  the  Rural  Electrification  and Renewable Energy Corporation in the Energy Act of 2019. Kenya is the strongest market in East Africa for PAYGo solar PV systems, accounting for nearly 60% of the region's market share. In addition to PAYGo systems, Kenya also has a large number of solar home systems.

However,  demand  is  a  current  barrier  to  an  additional  increase  of  renewable energy capacity in Kenya. The current high amount of installed renewable capacity indicates that an increase in renewable capacity would need to be matched by an increase in demand. The country does have agreements for regional imports of electricity, for example a 400 MW agreement with Ethiopia for hydropower, which could potentially be replaced by domestic generation. However, the length of the contract, 27 years, indicates replacing this capacity with domestic generation may be challenging.

The  new  Electricity  Regulations  (2024)  would  allow  for  the  development  of renewable energy projects which would be directly contracted with a consumer, which could help spur additional development. However, the decoupling of the electricity  market  could  create  additional  market  concerns,  such  as  system balancing and decreased demand for the incumbent utility, Kenya Power.

## Incentives and mandates could be used to spur Kenya's abundant bioenergy potential

Traditional biomass products are the primary use of bioenergy in Kenya, mainly for cooking, though there are currently programmes in place to encourage the use of clean cooking fuels and equipment (see Chapter 5). The country's Bioenergy Strategy 2020 outlines best practices for bioenergy use worldwide and identifies sources and uses of bioenergy in Kenya. The strategy includes an overview of options for the optimisation of Kenya's bioenergy potential, though many of these measures have yet to be implemented.

The primary biomass fuels are woody biomass, crop residue and animal waste, while significant amounts are also derived from government or communal forests. Industry  also  uses  biomass  for  thermal  processes.  While  biomass  for  power generation and heat represents a small portion of the overall power generation mix  in  Kenya,  the  country  has  a  target  of  600 MW  of  biomass  co-generation by 2030. In addition, the government sees potential in industrial waste as a fuel for biomass co-generation.

Kenya  has  an  estimated  21 000  biogas  digesters  throughout  the  country, producing an estimated 29-131 MW of installed power generation capacity. The government has  identified  biogas  as  having  high  potential  for  cost  and  labour savings while also reducing the use of fuelwood and charcoal use in households. Potential feedstocks for biogas plants are municipal and livestock waste.

Outside  of  power  generation,  bioenergy  for  cooking  and  heating  (including traditional  biomass)  accounts  for  a  substantial  portion  of  Kenya's  total  energy consumption. The use of biofuels in Kenya is mostly focused on cooking, as the country is seeking to adopt clean cooking practices. Bioethanol is an alternative clean fuel for cookstoves and has a growing market share owing to private sector participation. Most of the bioethanol is imported, though the government plans to build  two  new  bioethanol  production  facilities  using  molasses  and  cassava feedstocks.

Noticeably, biofuels have not been used for transportation. The Energy Act of 2019 empowers the Cabinet Secretary to promote the development and use of biofuels, and  the  bioenergy  strategy  mentions  a  potential  2%  blend  of  biodiesel  with traditional diesel fuel and 10% ethanol-gasoline blend. However, there is currently no  specific  legislation  for  blending  of  biofuels  in  transport  fuels.  Currently,  the country's  feedstocks  (vegetable  oil  from  the  processing  of  castor,  croton  and cottonseeds) are exported for the processing of biofuel products.

Kenya has a national biogas programme - the Kenya National Domestic Biogas Programme - which is aligned with the African Biogas Partnership Programme.

The Programme promotes the installation of small-scale biodigesters across the country to help reduce the dependence on fuel wood and charcoal.

A major barrier to the uptake of biofuels is the absence of regulations and blending mandates to create a domestic market for feedstocks and production. There is currently a programme to send feedstocks for production in Europe, only to be re-imported for use by Kenya Airways. In addition, Eni has recently received a grant from the International Finance Corporation and the Italian Climate Fund to expand the production and processing of biofuels from oilseeds.

## Green hydrogen has the potential increase domestic fertiliser production through policy incentives

Kenya  has  released  a  Green  Hydrogen  Strategy  and  Roadmap  for  green hydrogen  production.  The  guidelines  outline  a  two-phase  roadmap  for  the production of green hydrogen. The first phase (2023-27) focuses on increasing domestic demand to replace 20% of imported ammonia-based fertiliser and 100% of imported methanol. The second phase (2028-32) will focus on both domestic production and regional and global exports. For domestic use, this second phase aims to replace  50%  of  ammonia-based  fertiliser  imports  and  decarbonise  the transportation and power generation sectors.

The guidelines set definitions for the type of power plant used for green hydrogen production: a captive plant, grid-connected plant or a wheeling plant. Each of these types has its own specific criteria, with additional criteria set out for land and water use. Crucially, the roadmap establishes a one-stop shop to support developers on guidelines and incentives. The document also provides the necessary documentation and timelines for developers when creating a proposal for a green hydrogen project in Kenya, along with the expected amount of time it will take the government to review these documents.

The document includes incentives for green hydrogen production, which include: a  ten-year  tax  holiday,  a  value-added  tax  exemption  on  raw  materials  and machinery,  a  single  operation  licence,  exemption  from  stamp  duty,  a  fixed corporate tax rate after the tax exemption expires, 100% investment depreciation, and  no  currency  exchange  controls.  Finally,  the  roadmap  establishes  special economic zones with additional incentives.

## Recommendations

To reach its objectives, the government of Kenya could consider:

-  Ensuring that the framework for renewable energy auctions is consistent with the Least-Cost Power Development Plan and explicitly details additional government

and regulatory requirements, and including total capacity, an indicative timeline, bidding criteria and grid capacity information for priority areas for development.

-  Advancing  consultation  with  all  major  stakeholders  to  promote  direct  uses  of geothermal resources such as agriculture, cooling, manufacturing and/or renewable hydrogen for energy storage.
-  Fostering the development of a market for cooking and transport biofuels by, for example, use of domestic feedstocks and blending mandates for transport.

## 4. Access to electricity

## Increasing access to electricity

## Rapid increase in access to electricity has made Kenya a regional leader

Kenya  has  made  considerable  progress  in  increasing  access  to  electricity. 1 Access has more than doubled over the past decade, from 37% in 2013 to 79% in 2023, making it the country with the highest electricity access rate in East Africa (Figure 4.1). Kenya is on track to provide electricity to its entire population by 2030, in line with national plans and Sustainable Development Goal (SDG) 7 targets.

## Figure 4.1  Access to electricity in Kenya, 2010-2023

<!-- image -->

Source: IEA (2024), Access to Electricity.

Although  Kenya  has  a  high  national  electricity  access  rate  compared  to  the sub-Saharan African 2  rate of 50%, there are strong disparities between the rates in urban and rural areas. In 2023, 100% of the urban population had access to electricity. However, the population in Kenya is largely rural, with only about onethird living in urban areas. Access rates have climbed from 30% in 2010 to 70% in  2023  in  rural  areas,  providing  roughly  15 million  people  with  access.  There

1 The IEA defines access to electricity as a household receiving enough electricity to power at least a minimum level of services that is capable of growing over time. The IEA minimum level of services is defined as the 'basic bundle', which includes more than one light, phone charging and a radio, broadly equivalent to a range of 50-75 kWh per household per year, depending on efficiency levels. In the case of off-grid solar, the IEA considers in the access definition solar home systems of 10 watt-peaks and above. See the IEA Guidebook for Improved Electricity Access Statistics.

2 Sub-Saharan Africa includes all African countries excluding the North African countries Algeria, Egypt, Libya, Morocco and Tunisia. In this report, South Africa is included in sub-Saharan Africa.

remain around 11 million people living in rural areas who lack access to electricity services. Kenya's priority now is to focus on the most remote populations in rural areas while still investing in increasing the level and quality of services provided by electricity for the people that already have access.

The  government  of  Kenya  has  developed  a  comprehensive  and  clear  set  of strategies, policies and plans to achieve universal access to electricity and 100% renewable power by 2030, notably Kenya Vision 2030, which aims to transform Kenya into  a  newly  industrialising,  middle-income  country;  the  Kenya  National Electrification Strategy; the Energy Act; and the Rural Electrification Programme. Electricity demand in Kenya grew by 15% from 2018 to 2022 as GDP expanded over the same period by about 18%, with a record-high peak demand of almost 2 100 MW  in  June  2022.  The  government  focused  measures  on  demand stimulation  to  promote  greater  electricity  consumption  and  utilisation  of  grid networks, with a significant emphasis on electrifying transport.

It  is  critical  that  electricity  access  plans  are  aligned  with  a  broader  vision  of socio-economic development to ensure broader long-term results.

## The Last Mile Connectivity Project has successfully connected millions to the grid

Much of Kenya's recent progress on electricity access can be attributed to the country's  National  Electrification  Strategy,  launched  in  2018  with  the  goal  of achieving universal access to electricity by 2022. From 2018 to 2023, the access rate increased from 65% to 79%, and the urban access rate of nearly 100% was also  achieved  during  this  period.  This  expansion  was  achieved  despite  global setbacks from Covid-19 and the global energy crisis, underscoring the success of the Kenya National Electrification Strategy.

The main approach underpinning the drive towards universal electricity access is the Last Mile Connectivity Project (LMCP). Launched in 2015, the Project aimed to maximise utilisation of existing distribution transformers across 47 counties to their  maximum capacity through extension of the low-voltage network to reach around 1.2 million people. In support of electricity access plans, all public facilities and households located within a radius of 600 metres from an existing transformer were  prioritised  for  connection.  In  addition  to  providing  increased  electricity access,  new  transformer  installations  on  existing  grid  networks  to  promote households' electricity connection have been undertaken. This approach has led to significant improvements in access to electricity for households in rural areas, halving  the  number  of  people  without  access  to  electricity  in  rural  areas  from 20 million in 2015 to around 11 million today.

Between July and December 2023, Kenya Power added more than 250 000 households  to  its  consumer  base  thanks  to  the  LMCP,  bringing  its cumulative grid-connected consumer base to almost 9.5 million at the end of 2023. However,  as  the  majority  of  these  households  are  in  rural  areas,  they  use significantly lower amounts of electricity than their urban counterparts, usually only for limited lighting and to charge phones. The programme, therefore, did not boost Kenya  Power's  power  sales.  More  demand  and  productive  uses  stimulation activities  could  boost  electricity  use  and  increase  the  sales  of  the  electricity provider while at the same time catalysing economic growth and in the long term addressing the affordability issue.

In May 2024, the government announced that it had secured funding for the fourth round  of  the  LMCP,  providing  electricity  to  an  additional  280 000 households across 32 counties, excluding Nairobi and Mombasa. This phase of the project is expected to be completed within 18 months.

The LMCP has a built-in gender component where gender was taken into account from  the  start,  including  capacity  building  for  Kenya  Power  staff  and  gender mainstreaming workshops. The programme envisions that at least 30% of the job opportunities that are created in the construction phases of the project will target women. Further, the Project will provide access to electricity for low-consumption last-mile connections where more than one-third of households are headed by women. Providing access to electricity can contribute to closing gender disparities and facilitate women's economic empowerment in relation to education, paid work and healthcare.

Before  kicking  off  the  LMCP,  Kenya  focused  on  rural  electrification  in  public institutions,  with  the  Government's  Digital  Learning  Programme  (2013-2016) aiming to electrify all public schools. The national grids were extended to schools, while solar PVs were installed at those schools where the grid was inaccessible. The programme provided a network across the country that helped further connect households  in  the  vicinity  of  the  connected  schools.  The  programme  is  still ongoing with REREC.

In 2010, the access rate in urban areas was only 27%, less than in rural areas. This was largely due to the informal settlements in the cities, such as Kibera in Nairobi, Africa's most  populous  slum.  Through  using  a  community-based approach in its informal settlements programme, Kenya Power managed to go from 5 000 households to over 150 000 households connected to electricity in just one year, from May 2014 to May 2015. Through collaboration with World Bank supported  programmes  such  as  the  Kenya  Informal  Settlements  Improvement Project and the Global Partnership on Output-Based Aid, the access rates in urban informal settlements helped drastically improve the urban access rate to nearly 100% in 2023.

Other  electrification  programmes  include  the  Rural  Electrification  Programme under  Vision  2030  and  the  Transmission  Network  Improvement  Project,  which aims to improve power transfer capacity to address system gaps and enhance universal  electricity  access.  In  addition,  Phase 1  of  the  World  Bank's  Kenya GREEN  Programme  (2024-2028)  makes  available  roughly  USD 100 million  in support of KPLC's aim to connect 1.6 million additional on-grid customers by June 2028.

## Off-grid and mini-grid solutions help provide important access to otherwise hard-to-reach populations

Solar home systems are a helpful transitional measure to reach universal access to electricity, as they can reach remote populations with difficulties to access the national grid. Even in areas with extensive low-voltage networks such as in the Central Region, the cost of providing connections is high due to the need to run lines to scattered households in dispersed settlements. Kenya is the largest and most mature market for solar off-grid solutions globally, surpassing India in 2019, and accounting for 74% of solar home system sales in East Africa in 2023, though in recent years there have been lower levels of investor attention.

The government removed the import duties and VAT on solar PV products in 2021 to make solar energy more affordable to households and businesses. However, import  duties  still  remain  on  solar  PV  parts,  leading  local  companies  to  report having to pay import duty and VAT on individual parts for domestic assembly or repairs.

The Kenya Off-Grid Solar Access Project (KOSAP) is a five-year initiative started in 2018 3 by the World Bank and Kenya's Ministry of Energy and Petroleum whose aim is to enhance energy access in underserved Kenyan counties with the goal of promoting solar technology use, largely through a distributed model. The project targets  the  14 out  of  47 counties  in  the  country  the  government  defines  as marginalised  and  aims  to  provide  energy  access  via  solar  technology.  The component  objectives  of  KOSAP  include  the  construction  of  157 mini-grids through public-private partnership (PPP); the sale of 250 000 solar home systems and 150 000 clean cooking solutions; and the installation of stand-alone solar PV systems with water pumps in 473 community facilities.

As of February 2023, the Kenyan government had deployed 62 fully operational mini-grids and had 28 additional ones under construction as part of its electrification efforts. The private sector is also involved, with more than 50 private mini-grids in operation and around 150 under development.

3 The project end date was extended to 2025 to accommodate disruptions related to the global pandemic.

The 2021-2030 LCPDP highlights Kenya's intention to develop solar PV mini-grids to  improve rural  electrification.  With  this  in  mind,  EPRA  developed  the  Energy (Mini-Grid) Regulations 2021 to provide clear regulatory guidelines for mini-grid development.  The  Regulations  apply  to  those  wishing  to  develop  a  mini-grid project with an installed capacity of up to 1 MW. They include requiring a Mini-Grid Construction Permit from EPRA as well as a licence to operate the generation and distribution infrastructure.

## Challenges to electricity access

## Rising electricity prices continue to hinder affordable electricity access

Affordability remains one of the biggest challenges to achieving universal access to electricity in Kenya. Despite having a high share of low-cost renewable energy, including geothermal, which represents 90% of the country's power generation, electricity end-user prices in Kenya remain some of the highest on the continent, at  0.256 USD/kWh  as  of  September  2023  (compared  to  0.191 USD/kWh  in Rwanda,  0.190 USD/kWh  in  South Africa,  0.173 USD/kWh  in  Uganda  and 0.058 USD/kWh in the Democratic Republic of the Congo).

Kenya has experienced high inflation in recent years leading to increased cost of living, especially for the poorest households. According to KNBS, the general price level was 6.9% higher in January 2024 than in January 2023; 10.6% higher for transport; 9.7% higher for housing, water, electricity, gas and other fuels; and 7.9% higher for food. Prices for electricity skyrocketed in 2023 compared to the previous year, with an increase of almost 70% for 50 kWh and almost 50% for 200 kWh between  August  2022  and  August  2023,  both  due  to  increased  tariffs  and increased global fuel prices, as well as to improve cost recovery and the financial health of KPLC. In 2024, prices have dropped slightly from month to month, but this does not come close to bringing them down to 2022 levels.

Price increases on electricity can be attributed to new tariffs and the removal of electricity subsidies. It can also partly be attributed the weakening of the Kenyan shilling  to  the  US dollar,  as  well  as  to  global  trends  with  increasing  costs attributable  to  the  Covid-19  pandemic  and  heightened  geopolitical  tensions  in Eastern Europe and the Middle East, which have disrupted international trade. Conflict  has  also  impacted global fuel and commodity prices, which has had a limited  impact  on  Kenyan  electricity  tariffs.  In  January  2022,  the  government introduced a 15% subsidy to reduce the price of electricity for households but the subsidy was not extended beyond its expiration in December 2022. New electricity tariffs  were  introduced  in  April  2023,  increasing  the  end-user  bill  by  19%  for customers consuming 30-100 kWh and by 14% for those consuming more than

100 kWh compared to the tariffs from 2018. For low-income households, a new tariff ('lifeline tariff') reduced the end-user bill by 4% compared to 2018 tariffs. The tariffs  were  amended  after  the  commissioning  of  several  new  power  plants  to ensure  financial  viability  and  sustainability  for  KPLC,  and  to  allow  for  system expansion.  The  new  tariffs  rebalance  the  electricity  costs,  with  low-income households paying less for electricity and middle- and high-income households paying a greater share of the cost. The band for the lifeline tariff was also raised several times:  its  current  band  of  0-30 kWh  per  month  benefits  about  6 million households, or more than 70% of electricity consumers.

## Improving quality of connections and tracking access through community participation

Data collection on access to electricity remains a challenge due to difficulties in reaching and tracking rural communities and methodologies used when defining and tracking  access.  Further,  data  on  factors  such  as  reliability  and  quality  of connections at the household level are not collected widely. Closing the access gap and reaching universal access to electricity in Kenya requires greater scaling, which  today  is hindered  by  traditional planning and  customer  acquisition approaches. Today, this often relies on workers going village to village to assess the current electrification and energy needs at the community level.

Timely  data  on  access  to  electricity  is  essential  for  tracking  progress  towards universal electrifications and for policy makers to plan electrification campaigns. The IEA has developed a Guidebook for Improved Electricity Access Statistics, which  provides  a  foundation  for  how  to  improve  methodologies  using  readily available supply-side data from electric utilities, mini-grid operators and off-grid system distributors to track access to electricity trends, which can be a tool used by governments to achieve their access goals in time.

Kenya has implemented programmes for promoting greater community involvement  and  ownership  of  connections.  However,  these  programmes  lack regulatory  frameworks  for  integration  into  projects.  The  Guide  to  Community Engagement  for  Power  Projects  in  Kenya,  developed  by  the  government  and USAID in  2018,  provides  useful  guidelines  and  tools  for  increased  community participation  in  electricity  projects.  Further  actions,  such  as  training  community representatives to participate in local power system monitoring and maintenance, could provide significant benefits for tracking quality of connections.

Kenya is actively enhancing its data collection on electricity provision, as well as for monitoring overall connection quality and broader power system health. Kenya Power  has  set  out  plans  to  install  smart  meters  or  advanced  sensors  at 1 300 distribution  feeders,  73 000 distribution  transformers  and  600 000 large consumers across the country. This is part of efforts to improve overall system

monitoring and bring in additional revenue. As of February 2024, Kenya Power had  installed  67 000 new  smart  meters,  which  has  increased  the  company's annual sales by KES 347 million (Kenyan shilling, approximately USD 2.6 million) by  saving  on  operating  expenses  and  commercial  costs.  By  December  2024, Kenya Power plans to have installed smart meters for all big electricity users, small and medium-sized enterprises, and customers who consume over 200 kWh on advanced metering infrastructure.

At  the  household  level,  more  granular  data  on  broader  productive  uses  of electricity,  such as for lighting, mobile phones, appliances and electric cooking (e-cooking), is limited. However, there is potential for improvement through the rollout  of  smart  meters  and  application  of  other  tools  such  as  geographic information systems.

## Recommendations

## To reach its objectives, the government of Kenya could consider:

-  Reinforcing  national  policy  frameworks  that  deliver  access  to  electricity  and promote affordability (including affordability of connection), while balancing cost recovery and utility financial sustainability alongside long-term power reliability, quality and durability considerations.
-  Setting out a least-cost pathway for the delivery of universal access to electricity by 2030 that clarifies the roles and responsibilities of national and county-level government; sets guidelines for on- and off-grid solutions; and aims to increase levels of energy services and productive uses.
-  Strengthening electricity demand data collection and monitoring at the national and county levels.
-  Promoting inclusivity of electricity access projects within local communities. This could include delivering capacity-building programmes for power system monitoring.

## 5. Access to clean cooking

## Kenya is a regional champion in clean cooking access, but efforts are still needed to transition away from biomass

Kenya  is  a  regional  champion  of  clean  cooking   access  and  has  made  great 1 progress in increasing the access rate from only 10% in 2013 to 31% in 2023 (76% urban, 12% rural), putting it ahead of its neighbouring countries and other East African countries as well as of the sub-Saharan African average of 22%. Despite this progress, around three-quarters of Kenyan households still rely on traditional  biomass  such  as  firewood  or  charcoal,  and  kerosene  for  cooking. Further, the number of people without access remained almost stable between 2010 and 2023 at around 40 million, as high population growth has outpaced the clean cooking rate (Figure 5.1).

## Figure 5.1. Access to clean cooking in Kenya, 2010-2023

<!-- image -->

IEA. CC BY 4.0.

Source: IEA (2024), Access to Clean Cooking.

The Kenyan government's ambition is to reach universal access to clean cooking by 2028. Several strategies on biomass and clean cooking support this goal, such as  the  Bioenergy  Strategy  2020.  The  government,  in  May  2024,  released  the

1 Clean  cooking  is  defined  as  cooking  solutions  that  release  less  harmful  pollutants,  and  which  are  more  efficient  and environmentally sustainable than traditional cooking options that use solid biomass (e.g. a three-stone fire), coal or kerosene. For more information, see: the IEA website. The IEA SDG 7.1 indicators for clean cooking are defined as households primarily cooking with clean fuels, including liquefied petroleum gas (LPG), electric cooking, ethanol, biogas and improved biomass cookstoves of ISO Tier &gt; 3. However, official SDG 7 indicators exclude all solid biofuels (wood, charcoal, etc.) from access to clean cooking due to gaps in data gathering on improved biomass cookstoves.

Kenya  National  Cooking  Transition  Strategy  (KNCTS).  The  Strategy  is  much welcomed by ministries, private stakeholders and the international community, as well as the IEA.

The KNCTS lays out the pathways to reach universal access to clean cooking by 2028 and to contribute to the Nationally Determined Contribution (NDC) target to reduce their GHG emissions by 32% by 2030. The Strategy's objectives include: establishing a baseline scenario of Kenya's cooking sector, including looking at the current energy mix for cooking, barriers to uptake, the enabling environment and  opportunities;  assessing  gender  dimensions  in  Kenya's  cooking  sector; determining the appropriate cooking fuel mix to reach universal access by 2028; and developing a roadmap to reach this goal.

Kenya has also developed the Kenya National Electric Cooking Strategy, which feeds  into  the  KNCTS.  It  focuses  on  how  energy-efficient  electric  cooking strategies can be scaled up in Kenya to minimise the risks associated with the use of  biomass  for  cooking,  improving  environmental  sustainability  and  stimulating electricity demand growth.

Kenya has for many years had several strategies and policies related to clean cooking; however, implementation plans have been lacking and there have been low  and  inconsistent  budget  allocations  to  clean  cooking  at  the  national  level, which has hindered the scaling up of clean fuels. Strategies such as the Kenya Ethanol Cooking Masterplan, the Bioenergy Strategy, the National Growth LPG Strategy  and  the  Electric  Cooking  Strategy  (draft)  have  lacked  coherence  and co-ordination, making implementation and budgeting difficult. The new KNCTS provides harmonisation to the clean cooking sector in Kenya and an improved enabling environment to develop the sector. It also provides a clear integrated roadmap covering all fuels, including budget allocations and time frames, on how to reach its goal of universal access to clean cooking by 2028.

## Cooking solutions by fuel

## Three-stone open fires remain the most common cooking solution

According to the Kenya Demographic and Health Survey of 2022, the three-stone open  fire   has  historically  been  and  remains  the  most  used  fuelwood-based 2 cooking option in the country, with 49% of  households using this solution as their

2 Traditional cooking set-up where the cooking vessel is placed near open flame to limit heat loss.

primary solution in 2022. The KNCTS finds that nationally, 52% of the population uses firewood as their main cooking fuel, with the number being as high as 81% in rural areas (Figure 5.2).

## Figure 5.2. Primary cooking technology in Kenya, 2022

Source: IEA analysis based on data from Kenya National Cooking Transition Strategy.

<!-- image -->

Improved cookstoves 3  is a valid transitional solution towards clean cooking as they allow more efficient use of fuel, limited release of smoke and have higher safety standards. They are generally the cheapest and most practical means of providing improved cooking solutions to households, as they do not require switching fuels or  developing  new  infrastructure.  The  use  of  improved  cookstoves  is  rapidly growing, with more than 4 million improved cookstoves manufactured in Kenya sold  since  2014.  Import  duties  on  improved  cookstoves  remain  high,  at  35%, compared to the  common  East  African  Community  (EAC)  import  duty  of  10% applied  in  the  other  EAC  countries.  The  higher  import  duty  on  imported  clean cookstoves is an effort to promote local manufacturing.

The  government  has  implemented  the  World  Bank  Multi-Tier  Framework  for Cooking  to  identify  what  stoves  meet  certain  standards  as  a  way  to  ensure deployed stoves are providing the expected results and can be classified as clean cooking.  The  Kenya  Industrial  Research  and  Development  Institute,  Dedan Kimathi  University  of  Technology  Centre  for  Energy  Studies,  the  University  of Nairobi and Strathmore University have established testing laboratories for quality testing  of  improved cookstoves. There are also proposals to establish regional testing laboratories for cookstoves in energy centres across the country.

3 Intermediate and advanced improved biomass cook stoves (ISO tier ≥ 3). It excludes basic improved stoves (ISO tier 0 -2).

More than 50% of Kenyan households use more than one device for cooking and one in six use three or more. This is referred to as fuel stacking. This means that the number of each stove type sold in Kenya may be significantly higher than the number  of  households  actually  using  the  stove  as  their  primary  fuel.  Some households may use several types of cooking devices for different meals or even for different parts of a single meal.

## Continued demand for charcoal fuels illegal logging

Around 12% of households use a type of charcoal cookstove as their primary cookstove  appliance,  and  in  urban  areas,  more  than  80%  of  households  use charcoal  as  their  primary  or  secondary  source  for  cooking.  The  mean  annual charcoal consumption from households in Kenya is almost 400 kg per year.

Rapid increase in charcoal demand due to high prices of cleaner alternatives has led to a widened supply-demand gap, resulting in unsustainable charcoal demand and deforestation. To address these challenges, the government established the Forest (Charcoal) Rules in 2009 to regulate the production, transportation and marketing of charcoal by requiring producers to formally register and receive a certificate. To further prevent deforestation and biodiversity loss, the government imposed a national ban on logging (and therefore charcoal production) in 2017. Despite  the  ban,  illegal  logging  continues,  fuelled  by  corruption  and  a  lack  of enforcement and of monitoring capacities of the forest land.

In July 2023, the logging ban was lifted, and the government said there will be responsible forest management where firewood and charcoal production in certain forests  can  be  sustained  and  new  jobs  can  be  created.  Despite  these  efforts, households  continue  to  use  large  amounts  of  charcoal  due  to  the  lack  of affordability of cleaner solutions. This continuation of high demand continues to sustain the illegal logging and charcoal trades.

## Kenya is scaling up the use of LPG and bioethanol to achieve access to clean cooking goals

From 1999 to 2022, the number of households using LPG for cooking increased more than threefold, with the proportion rising from around 9% in 1999 to 31% in 2022 (63% urban and 9% rural). LPG is, therefore, the most common fuel among those considered to have access to clean cooking. However, due to fuel stacking, there may be a large number of households that use LPG only occasionally and in combination with other more polluting fuels such as firewood or charcoal.

In  the  KNCTS,  to  reach  universal  access  to  clean  cooking  by  2028,  Kenya foresees 50% of households using LPG for cooking (up from 35% as previously foreseen). The government has shown support for the use of LPG for cooking, for

instance by removing the 16%  VAT in 2023 to stimulate its use. The government also introduced LPG market regulations by standardising cylinders to work with any  LPG  provider.  The  government  aims  to  use  LPG  as  a  transitional  fuel, targeting  for  it  to  be  phased  out  completely  by  2050  in  line  with  its  net zero emissions goal. However, all LPG is currently imported and there are limited plans to  start  domestic  production,  which  exposes  the  country  to  increased  risk  in currency  fluctuations  and  cost  of  supply.  In  late  2023,  the  Kenya  Pipeline Company  acquired  an  old,  closed  refinery  in  Mombasa  that  previously  stored oil-based products to consider developing LPG storage (see Chapter 6).

The  government's  Clean  Cooking  Energy  Compact  of  2021  aims  to  transition public schools and institutions away from biomass, providing an opportunity for children to positively impact their family's cooking practices. The government's LPG Strategy aims for all schools to use LPG for cooking, and the president of Kenya has directed all public institutions to transition to LPG for cooking by 2025. While these are worthwhile measures, they do not address the problem of biomass use in households, and there is a risk that households and institutions will revert to biomass if the LPG price surges, or the VAT regime become less favourable. The VAT on LPG has been introduced and removed several times, making the market less  predictable.  A  16%  VAT  was  reintroduced  in  Kenya  in  July  2021, causing many households to switch back to biomass. The restoration of the VAT removal for LPG sales through the Finance Act of 2023 is a welcome measure, but should the government decide to reinstall the VAT it should be accompanied by  schemes  to  protect  the  welfare  of  the  poorest  households  through  income support or subsidy.

The use of bioethanol for cooking is growing at a fast pace in Kenya, especially in urban areas, but still accounts for less than 1% of cooking fuels. Most bioethanol is imported. The government is looking at increasing domestic production and is planning on building two new bioethanol production facilities (see Chapter 3).

In  addition to the  50% LPG target, the KNCTS foresees that by 2028, 30% of households will be using bioethanol, 10% will be using electricity, 3% will be using biogas, and 7% will be using low emissions or clean burning sustainable biomass stoves such as those using briquettes or pellets. The IEA commends the diversity of clean cooking solutions being championed in Kenya. However, the number of households  currently  using  bioethanol  for  cooking  is  small  at  less  than  1%. Reaching 30% by 2028 will require a rapid increase in investments in supply and distribution infrastructure and subsidies to ensure that bioethanol is an attractive option  for  households.  The  sustainability  of  bioethanol  supply  must  also  be  a consideration  to  avoid  undue  competition  over  land  used  for  crops  and  food production,  deforestation  and  biodiversity loss, impact  on  water  use,  and emissions related to production (see Chapter 6).

There is currently no widespread use of bioethanol for transportation in Kenya. However, there have been discussions to turn an inactive refinery in Mombasa into a bio-refinery, potentially producing biofuels for cooking, transport and heating (see Chapter 6). With increased production of biofuels, the potential competition of bioethanol in the cooking and transportation sectors must be considered when expanding the biofuels sector.

Although about 25% of households in Kenya own at least one electric cooking appliance, only 3.5% of these are considered complete cooking solutions, such as electric pressure cookers, induction cookers, rice cookers and electric hobs. The remaining  21.5%  are  task-specific  appliances  such  as  electric  kettles,  water heaters and microwaves, which does not fall under the definition of clean cooking technologies. Despite this, only 0.2% of households use electricity as their primary source for cooking. This is largely attributed to the high cost of such stoves, cost of electricity and unreliability of the electricity provided.

Achieving universal access to clean cooking by 2028 will require scaling up access to solutions such as LPG, electricity, biogas, bioethanol and improved biomass cookstoves.  This  implies  efforts  including  investing  in  supply-  and  distribution infrastructure for clean cooking fuels and stoves and establishing and reinforcing policies  for  implementing  the  KNCTS  roadmaps  including  targeted  affordability measures and incentives.

## Challenges to access to clean cooking

## Cooking with biomass disproportionately affects women and children, and is a major CO2-emitter

With around three-quarters of Kenyan households still relying on traditional solid biomass  (such  as  firewood)  and  kerosene  for  cooking,  a  large  part  of  the population, especially women and children, are exposed to unnecessary health risks. This is estimated to cost the economy KES 5.7 trillion (USD 39 billion) each year in negative climate and health impacts. Further, cooking with polluting fuels is estimated to contribute to the death of over 23 000 Kenyans every year due to exposure to indoor air pollution.

In  sub-Saharan  Africa,  women  in  households  without  cleaner  fuels  spend  an average of five hours each day collecting firewood and cooking their meals. This not only impacts their health significantly but also deprives them of opportunities like  access  to  education,  economic  activities,  which  could  give  them  financial independence. Transitioning from cooking on a traditional open fire to using an improved cookstove could reduce their daily cooking time by one hour, improving both economic opportunities and health.

The  National  Climate  Change  Action  Plan  2018-2022  notes  that  improving biomass cooking efficiency and increasing the update of clean cookstoves is an important measure to reach the NDCs' emissions reduction targets.

## Regulations, cultural awareness, data collection and affordability are challenges to scaling up clean cooking

The role of the private sector in the clean cooking market is growing rapidly, giving consumers options to choose their preferred clean cooking fuel, including LPG, bioethanol, e-cooking, biodigesters and other improved cookstoves. The VAT on LPG was removed in July 2023, making the fuel more affordable to consumers and investors. However, VAT on imported clean cookstoves remains at 16% in Kenya, in addition to a 35% import duty, as an effort to protect and promote local manufacturing. Uncertainties regarding VAT exemptions as well as a lack of a transparent regulatory framework may disincentivise foreign private investment in the cooking sector in Kenya (see Chapter 9).

Providing  affordable  stoves  is  not  enough  to  ensure  that  households  continue using clean cooking solutions in the long term. The lack of affordable fuel for a cleaner burning stove technology can lead many to revert back to biomass. The government is considering establishing a clean cooking electricity tariff utilising digital  tracking  of  electricity  usage  that  is  separately  metered  to  ensure  more households  can  afford  e-cooking  solutions.  This  initiative  could  contribute  to greater uptake of electric cooking appliances on the Kenyan market, as well as to the financial viability of the power sector through demand stimulation. The current electricity tariffs include a customer band for those consuming 30-100 kWh/month. Although this is not referred to as an 'e-cooking tariff', it was introduced partly to promote the uptake of e-cooking, as it targets the typical consumption range for the low-income households that might consider cooking with electric stoves.

To  ensure  the  sustainable  development  of  clean  cooking,  it  should  be  part  of integrated energy planning strategy that targets long-term economic growth so that  people  can  sustain  the  cost  of  clean  cooking  fuels  in  the  long term.  This requires Kenya to incorporate planning for electricity supply with clean cooking and  other  development  goals,  and  that  the  creation  of  new  businesses  and productive uses are supported and stimulated in tandem. Kenya has made great strides in helping households and institutions access clean cookstoves through various programmes, as well as introducing some incentives for cleaner cooking fuels.  However,  ensuring  supply  and  price  stability  for  such  fuels  is  key  for ensuring  clean  cooking  solutions  households  can  afford  and  sustain  over  the long term. Cultural barriers and lower awareness of alternative options for cooking also play a role in hindering the switch from cooking with traditional fuels, such as coal, charcoal or firewood, to less polluting solutions such as LPG or e-cooking. Preferences in food taste and methods of cooking leave many hesitant to make

the switch, and limited access to information on the potential benefits of switching can further limit willingness. The Behaviour Change Communication Strategy is one government approach to address these challenges. Mama Doing Good, an organisation that implements programmes for the Office of the First Lady of Kenya, also  works  to  promote  the  adoption  of  clean  and  efficient  cooking  options. Transitioning  of  public  institutions  to  clean  cooking  can  further  contribute  to bolstering awareness of cooking with clean fuels.

Tracking  access  to  clean  cooking  is  complex  and  further  contributes  to  the challenges of scaling up access. The Kenya Institute of Public Policy Research and  Analysis  collects  statistics  on  households  and  submits  them  to  KNBS. However, household statistics vary between national and county level. The 2022 Kenya Demographic and Health Survey contains the latest and most comprehensive tracking of access across households in Kenya.

## Recommendations

## To reach its objectives, the government of Kenya could consider:

-  Developing  an  implementation  action  plan  for  faster  uptake  of  clean  cooking solutions that takes a multi-stakeholder approach; setting out a robust monitoring and evaluation framework for tracking progress against the targets in the KNCTS, with clearly defined roles and responsibilities.
-  Embedding energy efficiency in regulations governing the clean cooking sector, including minimum energy performance standards, labelling and testing capacity in co-operation, where appropriate, with neighbouring countries.
-  Developing an investment plan for the KNCTS which outlines the most appropriate clean  cooking  technology  given  geospatial  and  socio-economic  conditions, relative  costing  of  those  technologies,  and  steps  to  access  finance  for  clean cooking from different sources, including development finance institutions, private sources, public sources, etc.
-  Developing a stable fiscal incentive regime that emphasises affordability for the end user,  clearly  linked  to  the  number  of  households  gaining  access,  and  is aligned across clean cooking fuels and technologies listed in the KNCTS.

## 6. Energy security

Kenya's progress in developing an innovative and clean energy sector is having a positive impact on strengthening the country's energy security. A wide range of renewable energy sources provides secure domestic supply of electricity, covering almost the entire generation mix and demand, reducing Kenya's dependence on imported fossil fuels for its electricity supply.

A significant proportion of its energy supply, particularly fossil fuels, is imported. Kenya's energy imports consist mainly of oil products (88% of total energy imports in 2022), as the country has no oil production and no active oil refinery. Other energy imports include coal (11%) and electricity (0.4%).

## Liquid fuels

## Oil product imports meet domestic demand

Oil consumption in Kenya is growing and is expected to continue to do so. From 2005 to  2023,  oil  consumption  in  Kenya  more  than  doubled,  driven  mainly  by growing  gasoline  and  diesel  consumption  in  the  transport  sector,  but  also  by increasing household consumption of LPG (Figure 6.1).

Despite some signs of decoupling between GDP growth and oil supply, economic development  and  population  growth  are  expected  to  further  contribute  to increased oil demand in the coming years. It is, therefore, important to ensure that a reliable and diversified oil supply can adequately meet growing demand. At the same time, efforts to limit oil consumption through energy efficiency measures, the electrification  of  transport  and  the  promotion  of  biofuels  would  help  to  reduce dependence on imports of oil products.

Figure 6.1  Oil demand by sector in Kenya, 2005-2023, and correlation with GDP and population, 1971-2023

<!-- image -->

Note: kb/d = thousand barrels per day.

Source: IEA (2024), World Energy Balances (database).

Kenya does not produce crude oil but reserves have been identified in the South Lokichar Basin in the Turkana region. International oil companies had plans to start  oil  production  in  the  early  2010s,  and  to  construct  a  pipeline  from  the production site to Lamu, where a refinery could be built.

In 2020,  preliminary  production  wells  successfully  completed  two  years  of exploration. EPRA is reviewing a field development plan that uses data gathered from the preliminary wells and aims to produce first oil in 2028 and up to 120 kb/d by 2030. An outcome is expected by the end of 2024. Once the review of the field development  plan  is  complete,  the  government  expects  to  take  an  informed decision on whether to allow commercial oil production.

At  COP28 in the United Arab Emirates, Kenya joined the Beyond Oil and Gas Alliance, and received funding to plan for a just, managed and orderly transition away from oil.

In the past, Kenya produced oil products at a refinery owned by Kenya Petroleum Refineries Limited (KPRL) in Mombasa. KPRL operated the only refinery in East Africa, but it ceased operations in 2013 owing to a lack of profitability. In late 2023, the complex was acquired by the Kenya Pipeline Company, which uses it to store oil products, including the development of LPG storage. There may be potential to convert the facility to produce biofuels (see next section).

As a result of the refinery closure, all oil products are imported from overseas through the port of Mombasa, which acts as a hub for the region. Oil imports come mainly from  the  United Arab Emirates,  followed  by  Saudi Arabia,  Malaysia  and India.  Some  oil  products  are  used  domestically;  others  are  re-exported  to East African countries.

The ability to quickly respond to oil supply disruptions is a critical element of oil security. Solutions to ensure short-term oil security include the development of sufficient emergency oil stocks that can be quickly released in case of need, along with demand-restraint measures aimed to limit oil demand. The government has prepared a draft regulation on the establishment and maintenance of emergency oil stocks equivalent to 15 days of consumption, including the establishment of a Petroleum  Strategic  Stocks  Management  Committee.  The  IEA  welcomes  this measure  and  encourages  the  government  to  implement  the  regulation  and  to prepare  a  manual  with  guidelines  and  procedures  for  the  implementation  of emergency measures.

## Clean fuels adoption, electrification and efficiency can reduce demand for oil products

Alternative energy sources for the transport sector and improved fuel economy can break the link between economic growth and oil consumption and help limit the country's dependence on oil product imports (Figure 6.2). On a global scale, biofuels and electricity are set to reduce oil demand in the transport sector by almost 9% of projected demand in 2028. Fuel economy standards - regulations on the average fuel consumption of new or imported vehicles - can also make a significant  contribution  to  reducing  oil  consumption.  Alternative  energy sources and energy efficiency measures also help reduce emissions, and support Kenya's target  of  not  increasing  transport  emissions  by  more  than  6.34 Mt CO2-eq compared to 2015.

<!-- image -->

The number of electric vehicles in Kenya is low (1.6% of new vehicle registrations in 2023, compared to 18% globally), although being slightly higher than the African average of nearly 1%. However, the government has plans to increase the use of EVs, and annual registration of EVs increased significantly, from 475 in 2022 to 2 694 in 2023. The Draft E-Mobility Policy aims to develop infrastructure for EVs and improve fiscal and non-fiscal measures for consumers (see Chapter 7). The document also includes plans to introduce measures to support local manufacture of EV parts, including local battery manufacturing, recycling and reuse.

The IEA commends Kenya for its plans to expand the use of EVs, which can make a significant contribution to reducing oil demand in transport. The IEA encourages the government to support the development of charging points and infrastructure to increase the electrification of transport. Targeted support for the electrification of  public  transport  should  continue,  as  the  introduction  of  electric  buses,  for example, has recently gained momentum.

In addition to the expansion of EVs, the use of biofuels can provide an alternative energy source for the sector while creating jobs and contributing to GDP growth. Bioethanol  is  currently  used  for  clean  cooking  (see  Chapter 5),  partly  from domestic production - using cassava and sugar cane feedstocks - and partly from imports.

Kenya  currently  produces  some  feedstocks  for  the  production  of  transport biofuels. These are mainly non-edible seeds not in competition with the food chain or  forests.  They  are  grown  on  degraded  lands  identified  jointly  with  local institutions  and  with  smart  agriculture  techniques,  such  as  cover  cropping  and intercropping. Seeds are processed in some plants in the country, operated by the Italian  multinational  energy  company,  Eni:  a  plant  in  Makueni  County  has  a capacity of 15 000 tonnes (t) per year of vegetable oil. Another plant in Mombasa has a production capacity of 55 000 t/year. A recent investment of EUR 210 million backed by the International Finance Corporation and the Italian Climate Fund contributes to increase the production of oil seeds to 200 000 t/year by 2026 and support up to 200 000 local farmers by providing inputs, tools and training.

Kenya is also at the forefront of the adoption of sustainable aviation fuel (SAF). Kenya Airways  in  2023  became  the  first  African  airline  to  operate  a  long-haul commercial flight from Africa to Europe blending SAF with kerosene, using Eni Biojet SAF produced from renewable raw material. Kenya Airways has committed to comply with EU regulation to use a proportion of SAF on all flights departing from European airports by 2025.

However, there is no widespread use of transport biofuels in the country. Blending mandates for biofuels in transport or heating fuels provide a strong incentive to increase biofuel production, helping to limit the growth of oil use in transport and

decarbonise  the  national  energy  mix.  Biofuel  production  can  use  agricultural by-products  as  feedstocks,  providing  new  income  streams  for  the  agricultural sector, creating jobs and contributing to national economic growth.

The  Bioenergy  Strategy  2020-2027  proposed  the  introduction  of  blending mandates  for  heating  and  transport,  but  these  have  not  been  implemented. Finalisation of the regulation would create market incentives for local production of biofuels in the country and reduce the risks associated with reliance on imports of fossil fuels  and  biofuels,  for  both  cooking  and  transport,  including  the depreciation  of  the  Kenyan  shilling  and  exposing  oil  prices  to  international geopolitical risks.

The  currently  inactive  infrastructure  at  the  Mombasa  refinery  presents  an opportunity to develop a bio-refinery to produce biofuels using feedstocks from Kenya and the region, potentially producing biofuels for clean cooking, transport and heating. The refinery is currently  managed by the government, which has received offers by private companies for converting it to a bio-refinery. A local bio-refinery could also enable domestic production of SAF, which Kenya Airways has committed to using and currently imports. The production of SAF also provides an  opportunity  for  Kenya  to  use  hydrogen  produced  from  excess  renewable electricity from the grid.

An additional challenge for the government is to strike a delicate balance between the advantages of increasing domestic consumption of biofuels and sustainability criteria. The use of domestic by-products that do not affect land/water use and are not in competition with land crops and food should be prioritised. The import of biofuels adds emissions for their transportation, as well as concerns on security of supply, and increasing the use of land for domestic production of biofuels that are not  by-products  of  other  agricultural  process  can  compete  with  food  security, cause deforestation and have impacts on biodiversity.

## Coal and critical minerals

## Geological resources need careful management to protect communities and the environment

Coal use in Kenya increased from less than 0.5 million tonnes (Mt) in 2015 to almost 1.5 Mt in 2023 (Figure 6.3). Coal is used in industry, with growing demand from the cement, iron, steel and chemicals sectors. All coal is imported, as the country does not have any domestic production. Some sources indicate potential coal deposits in Kenya (Mui Basin in Kitui Country), but to date no coal mining has occurred.

## Figure 6.3  Coal demand in Kenya, 2005-2023

Note: kt = kilotonne. Source: IEA (2024), World Energy Balances (database).

<!-- image -->

The energy transition to clean technologies in Kenya and across the globe will require new raw materials that are critical for clean technology manufacturing. Existing geological surveys indicate that the country has the potential to produce a wide range of critical minerals (such as copper, fluorspar, graphite, manganese, niobium, zinc) and rare earth elements. The Mining Act of 2016 opened the mining sector to more players and established the Directorate of Geological Surveys under the Ministry of Petroleum and Mines, responsible for collecting  Kenya's  geological  data.  In  October  2023,  the  Kenyan  parliament proposed revamping the Mining Act of 2016 to promote transparency, efficiency and sustainability in Kenya's mining sector.

Any mining activities in the country should follow strict environmental, social and governance standards to ensure that workers and communities are protected from  environmental  and  social  harm  and  that  projects  supporting  energy transitions  are  people-centred  and  inclusive.  Various  initiatives,  such  as  the Initiative  for  Responsible  Mining  Assurance,  provide  guidance  and  audits  to support improved practices at the top of the supply chain of materials supporting the energy transition. Additionally, when harnessing its natural critical mineral resources, it would be beneficial for Kenya to also promote local processing of these materials.

## Electricity security

## Reliability and resilience of energy infrastructure is key to energy security

As the country electrifies, it needs to ensure electricity security, which is defined as  the  ability  of  the  electricity  system  to  ensure  uninterrupted  availability  of electricity by preventing and quickly recovering from disturbances and contingencies.

An  average  Kenyan  consumer  frequently  experiences  long  power  outages. According  to  EPRA,  the  SAIFI -  the  number  of  times  an  average  customer experiences  a  blackout -  increased  from  26 in 2020 to 48 in 2023  (the  global median is around 2.5). The SAIDI - the average duration of power outages - was more  than  100 hours/year  in  2023  (the  global  median  is  around 3).  EPRA proposed in March 2024 regulations to limit SAIFI to 20 per year and SAIDI to 80 hours per year.

To reduce the frequency and duration of power outages in the short term, the government  could  consider  supporting  KPLC  in  addressing  the  reliability  of distribution transformers, which have been identified as weak points leading to power outages. For the longer  term,  EPRA  could  aim  to set targets  to  further reduce unplanned blackouts each year, total unplanned outages and maximum duration per outage. Accompanying measures to achieve these targets, such as specific  reinforcements  to  the  electricity  grid,  should  also  be  clearly  identified. Also,  it  would  be  beneficial  to  combine  actions  to  reduce  the  frequency  and duration of power outages with reforms to the flexibility/ancillary services market that would attract investment in energy storage, demand-side response and other technologies (see Chapter 2).

Ensuring adequate supply of electricity at any given moment is fundamental for avoiding  electricity  disruption.  The  system  peak  demand  averaged  2 057 MW in 2022,  above  the  average  available  domestic  capacity  of  2 035 MW,  which increases the country's reliance on its interconnections with Ethiopia, Tanzania and  Uganda.  While  trade  with  Tanzania  and  Uganda  is  bi-directional,  Kenyan imports from Ethiopia have increased to reach 0.9 TWh in 2023, which is more than 6% of domestic electricity demand.

Integration  of  the  regional  electricity  market  helps  to  stabilise  the  electricity system, but reliance on electricity imports from Ethiopia highlights the shortfall in domestic generating capacity. Looking ahead, electricity demand is set to continue to  increase  at  an  average  of  almost  6%  per  year  from  2024  to  2026.  The 2021-2030  LCPDP  projects  a  50%  increase  of  both  domestic  generation  and import capacity from 2023 to 2030, while peak demand is projected to double in

the same time frame. This would lead to halving the reserve margin based on firm capacity - the difference between installed capacity and peak demand - from 47% of  peak  demand  in  2023  to  14%  in  2030,  increasing  the  risk  of  electricity generation shortfall (Figure 6.4).

Moreover, the electricity mix in 2030 is expected to have a higher share of variable renewable generation, which is associated with higher loss of load expectation. To ensure security of electricity supply, the government of Kenya could consider including  low  loss  of  load  expectation  requirements  in  its  electricity  planning exercise. At the same time, growth of electricity generation and demand should go hand-in-hand with adequate investment in the electricity grid for building new lines or upgrading existing equipment.

## Figure 6.4  Electricity capacity and peak demand in Kenya, 2023 and 2030 scenario

<!-- image -->

IEA. CC BY 4.0.

- * The vision scenario is based on the development patterns highly driven by Vision 2030 growth projections and the implementation of flagship projects.

Note: LNG = liquefied natural gas.

Source: IEA based on Kenya (2024), Least Cost Power Development Plan 2021-2030.

The quality of equipment in the grid affects its reliability. While there are effective standards  that  utilities  may  comply  with,  no  minimum  energy  performance standards have been adopted for distribution transformers in Kenya. The adoption of  a  nationwide mandatory minimum energy performance standard (MEPS) for distribution  transformers  would  help  increase  the  reliability  of  the  system.  In addition, close monitoring of the status of the grid would allow prompt response to disruptions and equipment failure, minimising the time of power loss. This could be done with digital devices or by training local technicians.

The energy and electricity infrastructure's resilience to cyber, physical and other threats  should  also  be  monitored.  The  Communication  Authority  of  Kenya  is tasked to monitor cybersecurity. In 2023, it reported a record high of 860 million incidents, including interrupting power supply. Increasing the level of awareness of the need for cyber resilience in the energy sector, encouraging risk identification

and exchange of information on vulnerabilities and actual incidents, and adapting regulations to a fast-evolving digital environment would help Kenya protect against cyber threats.

Climate change is also a threat to Kenya's energy security. Recurring droughts, erratic rainfall patterns and floods are already affecting the Kenyan energy system. In the next decades, climate change is expected to increase significantly and affect electricity consumption for cooling, decrease the efficiency of electricity generation and the safety of transmission. Increasing probability of floods and draughts is also threatening the resilience of the energy system, affecting the electricity grid, hydropower  plants  and  availability  of  biomass.  The  IEA  commends  Kenya  for publishing a National Adaptation Plan 2015-2030 in 2015, addressing threats to the energy system stemming from climate change.

## Recommendations

To reach its objectives, the government of Kenya could consider:

-  Increasing the resilience of the energy sector, taking concrete actions to mitigate cyber,  physical  and  other  threats,  for  example  by  addressing  the  reliability  of distribution transformers.
-  Ensuring that sustainable technologies and responsible practices are adopted and that local communities are engaged when energy or mineral extraction projects are developed in the country.

## 7. Energy efficiency

## The majority of Kenya's energy consumption is in the buildings and transport sectors, primarily reliant on bioenergy and oil products

Kenya has a relatively low energy intensity compared to other countries in the East African region at just over 3 000 megajoules per thousand 2015 USD, the second lowest  among  the  eight  countries  of  the  EAC.  Overall  energy  intensity  has decreased by 14% from 2010 to 2023.

Although  accounting  for  just  over  5%  of  total  energy  consumption,  electricity consumption has increased significantly, almost doubling from around 5.8 TWh in 2010 to around 10.5 TWh in 2023. Electricity consumption per capita in Kenya increased by 30% over the same period to nearly 0.2 MWh/capita, compared to a global average of 3.4 MWh/capita. Per capita consumption in 2023 was more than three times below the average for the continent of over 0.6 MWh/capita.

## The government of Kenya has policies and strategies for accelerating energy efficiency progress in support of its climate change and energy access goals

Kenya is aiming to place energy efficiency at the centre of its policy action, as efficient use of energy would support the country's goal to provide a secure supply of energy to everyone. The Kenyan government has set out a series of energy efficiency  policies  and  strategies,  providing  a  clear  direction  for  improvements across key sectors.

The main guiding document for energy efficiency policy and implementation in Kenya  is  the  National  Energy  Efficiency  and  Conservation  Strategy  (NEECS), released by the Ministry of Energy and Petroleum in 2020, which was produced under provisions set out in the Energy Act of 2019. The Energy Act is set for review in 2024. The NEECS includes situational analysis and quantitative targets for five thematic sectors: households, buildings, industry and agriculture, transport, and power utilities. It sets economy-wide targets for energy efficiency, including:

-  Increasing  the  annual  rate  of  energy  efficiency  improvements  from  0.2%  per annum (2019) to 3% per annum by 2025, in support of achieving SDG 7.
-  Ensuring energy efficiency contributes to Kenya's NDC through increasing annual emission reductions from energy supply and consumption to 7.6 Mt CO2-eq by 2025, up from 6.9 Mt CO2-eq in 2015.

The National Cooling Action Plan for Kenya, released in 2022, is a five-year plan (2023-27) that aims to support access to sustainable and energy-efficient cooling for  all  Kenyans.  Aligned  with  Kenya's  climate  commitments,  the  plan  sets  out actions to:

-  accelerate the market  transition to high-efficiency cooling appliances  and equipment
-  transition the cooling sector away from high global warming potential refrigerants
-  increase access to agricultural cold chain solutions.

The  Draft  National  E-Mobility  Policy,  introduced  in  March  2024,  sets  goals  to create an enabling environment for the growth and adoption of EVs in Kenya. The draft policy sets goals to:

-  develop an integrated and comprehensive policy, legal and regulatory framework to promote the adoption of e-mobility
-  improve fiscal and non-fiscal measures to accelerate EV adoption
-  reduce over-reliance on the road maintenance levy collected on petrol and diesel fuel.

Kenya has also shown leadership at the regional and international level to promote greater action on energy efficiency. On 21-22 May 2024, the Ministry of Energy and  Petroleum  co-hosted  with  the  IEA  the  9th  Annual  Global  Conference  on Energy Efficiency in Nairobi. The conference attracted over 550 participants from 67 countries, with 30 governments officially represented, over 40 senior business leaders and more than 26 000 online viewers. The success of the conference and strong leadership from Kenya highlighted a commitment to drive energy efficiency progress both domestically and at a regional level, in particular across sectors, including clean cooking, buildings, electric mobility and industry.

## Buildings

## The buildings sector is Kenya's largest energy consumer, primarily reliant on bioenergy, with more stringent enforcement of energy efficiency measures needed to address future growth

The  buildings  sector  is the dominant  energy-consuming  sector  in  Kenya, accounting for just over two-thirds of total final energy consumption. Consumption in the sector increased by 23% from 2010 to 2023. In 2023, bioenergy accounted for  over  90%  of  total  final  consumption  in  the  buildings  sector,  with  remaining consumption from oil products (5.5%) and electricity (3.8%). Electricity consumption in the sector has doubled since 2010 and that from oil increased by

28%. Bioenergy has been the primary driver of overall growth in residential energy consumption over the past three decades (1990-2023), doubling over this period and accounting for almost 92% of total growth in residential energy consumption.

Public buildings represent a significant portion of the energy demand within this sector. KPLC estimates that there are over 20 000 public buildings in Kenya with annual  energy  consumption  of  700 GWh (around  10%  of  Kenya's  total  annual energy consumption), with energy costs of USD 120 million. Over the next few years, energy consumption will continue to grow as the residential and commercial buildings sectors expand, with total building stock expected to increase by over 25% between 2018 and 2025. A shift to more efficient sources of energy and investment in efficient buildings has been limited by a range of factors, including consumer perceptions of high costs for more efficient buildings, limited financing and lack of mandatory regulations for energy efficiency in buildings.

The  NEECS sets out  objectives  to  improve  the  energy  efficiency  of  buildings, including through the establishment of a mandatory building energy code. There are  also  aims  to  introduce  MEPS  and  increase  the  share  of  energy  efficiency compliant building stock from 0% to 10% in new buildings, supported by incentives for green finance.

In  February  2024,  the  Ministry  for  Lands,  Public  Works,  Housing  and  Urban Development published its  National  Building  Code  2024,  which  is  expected  to become effective in 2025, pending parliamentary approval. The national building code  was  last  updated  in  2022  to  include  provisions  for  sustainable  building practices. The 2024 revision includes plans to introduce elements in the building code related to e-mobility and charging infrastructure, as well as broader aims to improve  skills  and  qualifications  in  the  buildings  sector.  To  date,  however,  a mandatory building code has not yet been adopted.

In commercial building, over the past decade the government has also placed a growing focus on promoting best practice for energy management. In 2021, EPRA published updated Energy Management Regulations which highlighted that only 43%  of  the  facilities  covered  by  the  regulation  had  carried  out  energy  audits between 2012 and 2020. The regulation requires mandatory energy audits for every owner of a designated (industrial, commercial and institutional) facility with an annual energy consumption of more than 180 000 kWh, the development of energy management plans aiming to achieve at least 50% of the recommended energy savings within three years of submission, and more stringent reporting and disclosure requirements.

The  NEECS  also  sets  objectives  for  promotion  of  energy  services  companies (ESCOs)  for  energy  efficient  upgrades  and  the  renovation  of  existing  public buildings,  aiming  for  five  established  ESCOs  by  2025  from  a  baseline  of  zero in 2019.  In  2021  the  Kenyan  government,  in  partnership  with  the  African

Development Bank, launched a process for establishing a utility-run super ESCO under KPLC. The super ESCO is not yet active but would focus on key areas including energy studies and audits, establishing energy performance contracts, and mobilising broader financing for energy efficiency projects and programmes.

## Appliances

## Kenya has introduced measures to improve appliance efficiency, but the market remains dominated by lowerefficiency models

Electricity  consumption  from  appliances  and  cooling  systems  in  Kenya  could increase significantly as the country makes progress towards universal electrification targets. The effects of climate change are projected to accelerate demand for household cooling appliances as a result of increased frequency of hot  weather  conditions.  According  to the  National  Cooling  Action  Plan,  energy demand from residential refrigerating appliances and room air conditioning alone could reach approximately 7% to 13% of the projected total electricity demand in Kenya by 2030.

Kenya has introduced measures  aimed  at  improving  appliance  efficiency,  and currently  has  MEPS  covering  six  appliance  types:  motors,  air  conditioners, refrigerators,  compact  fluorescent  lamps,  magnetic  ballasts,  and  fluorescent lamps. In 2016, requirements were introduced for the first time for use of energy efficiency labels on  selected  electrical appliances  manufactured,  imported, distributed and  sold  for  use  in  Kenya,  as  well  as  stipulating  the  testing requirements prior to labels being issued by the regulator.

The Kenya Label, introduced by EPRA, is a labelling scheme that tags the highest performing  appliance  with  five  stars  and  the  lowest  with  one  star,  providing consumers with information to decide on what they want to buy. The label includes information  on  average  annual  energy  consumption,  manufacturer  and  licence number, and follows a standard format across different appliance types. Currently air conditioners, refrigerators/freezers, induction motors and fluorescent lamps are the only appliances on the market with a Kenya Energy Label. Since 2021, the regulator  has  maintained  an  extensive  registry  of  appliances  meeting  MEPS covering four key categories: refrigerators, air conditioners, motors and fluorescent lamps.

Under the NEECS, the government plans to expand the coverage of MEPS to include televisions, computers, cookers and light-emitting diodes (LEDs). It also aims to scale up testing facilities, improve energy efficiency labelling and reduce electricity consumption  from  lighting.  Since  their  introduction  in  2016,  the

government of Kenya has revised MEPS for room air conditioners and domestic refrigerators twice, in 2019 and 2020, and aims to further revise these in 2025. The government is also aiming to accelerate harmonisation of MEPS with other countries in the East Africa region through partnering with the East African Centre of Excellency for Renewable Energy and Energy Efficiency.

Despite measures introduced to promote appliance energy efficiency, the majority of models available on the market are of lower-efficiency classes. According to IEA analysis, the majority of refrigerators on the market are of the lowest efficiency class 1 Star  (63%),  followed  by  2 Star  (30%).  The  share  of  3-5 Star  models  is minimal. As an import-only market for air conditioners and domestic refrigerators, Kenya is exposed to issues of dumping and imports of second-hand appliances. Import of these appliances results in increased energy bills, higher energy demand and strain on grids as cumulative use increases. For refrigerators, a majority of models on the market are imported from the People's Republic of China followed by Thailand and India.

It  is  not  necessarily the case, however, that more efficient appliance models in Kenya result in a higher purchase price. Analysis of the market in Kenya indicates that for USD 300, consumers could purchase an air-conditioning unit that is more than twice as efficient as low-efficiency alternatives (Figure 7.1). The limited or lack of availability of higher efficiency models, however, reduces opportunities for consumers  to  obtain  them,  therefore  missing  out  on  the  longer-term  energy savings potential. In addition, limited competition in the market results in limited availabilities and products, with a range of efficiencies being available for the same price, reducing  the  ability  for increased  product  efficiency  to  be  reflected accurately in final consumer prices.

Figure 7.1  Normalised purchase price versus energy efficiency rating in Kenya (wall-mounted split type), 2023

<!-- image -->

Energy efficiency (W/W)

IEA. CC BY 4.0.

Notes: The normalised purchase price represents the air-conditioner price normalised with a cooling capacity of 12 000 British thermal units (BTU) per hour. The cooling capacity of air conditioners used in this analysis ranges from 9 000 BTU/hour to 35 000 BTU/hour.

Source: IEA original Kenya air conditioning market analysis.

## Transport

## Kenya's transport fleet is primarily made up of internal combustion engines, with the dynamic electric-mobility market in its nascent stages of growth

The  transport  sector  accounted  for  around  20%  of  Kenya's  total  final  energy consumption in 2023, and is the primary user of petroleum products, consuming over three-quarters of all oil products. It is also the fastest growing sector in terms of final energy consumption over the past decade, doubling from 2010 to 2023. Energy consumption in the transport sector was dominated by diesel (54%) and gasoline (45%) in 2023, with a minimal proportion of electricity consumption.

As of 2022, Kenya had around 4.6 million vehicles, with petrol and diesel vehicles accounting for the large majority and an estimated 3 753 EVs at the end of 2023, up from only 1059 the year before. Primarily an importing country, 72% of energy consumption in the Kenyan transport sector is based on imported fossil fuels and 85% of all imported vehicles into Kenya are second hand. The country is exposed to the issue of dumping of often inefficient and second-hand vehicles, including heavy duty vehicles and trucks.

Under  the  NEECS,  actions  for  the  transport  sector  focus  on  two  main  areas: 1) improving  the  fuel  economy  of  Kenya's  fleet  of  light  duty  vehicles  from 7.5 litres (L)/100 km (2019) to 6.5 L/100 km (2025), and increasing the share of EVs from 0% to 5% in total vehicle imports. Globally, the average fuel economy of light duty vehicles was 6.9 litres gasoline equivalent per 100 km (Lge/100 km) in 2022.  The  government  is  also  aiming  to  initiate  fuel  economy  standards  and labelling for vehicles, restrict the age of imported second-hand vehicles from eight to five years, and implement vehicle emissions inspections.

The  Draft  E-mobility  Policy,  introduced  in  March  2024,  includes  objectives  to develop supporting infrastructure for EVs, improve fiscal and non-fiscal measures for consumers, and scale up socio-economic measures. In line with this, EPRA set out EV charging and battery swapping infrastructure guidelines, which aim to increase accessibility, promote affordable tariffs and generate new employment opportunities. EPRA has also granted approval for a special e-mobility tariff within the electric mobility category for EV charging, reduced the excise duty on EVs from 20% to 10%, and made EVs exempt from VAT.

Electric  mobility  is  also  seen  as  a  strategic  sector  for  promoting  demand stimulation, as around 40% of installed energy generation capacity is unutilised. It is estimated that daily curtailed energy could be utilised to support an additional 7 000 electric buses and 200 000 electric motorcycles on the road. In the public transport sector, Kenya also aims to electrify its public bus fleet by 2027. The local

start-up BasiGo has developed its model E9 Kubwa, a locally assembled electric bus, with aims to deliver 1 000 over the next three years.

In May  2024,  during  a  visit  of  President  Ruto  to  the  United  States,  the US International Development Finance Corporation announced a USD 10 million direct loan to BasiGo to facilitate procurement of buses and batteries for sale in Kenya, as well as USD 10 million to the Kenyan company Roam Electric, which supports assembly and production of electric motorcycles.

## Industry

Industry accounts for a small proportion of overall energy consumption, with energy efficiency efforts primarily focused on expanding audits, compliance and training.

Growth in industry and manufacturing has been limited over the past few decades due to factors including high energy costs, globalisation and regional competition. These factors have increased competition of domestically produced goods with imported  products  and  limited  investment  in  domestic  manufacturing.  Industry accounted for around 12% of total energy consumption in 2023, a lower share than the global average (28%), growing by 70% since 2010.

Over half of energy consumption in industry comes from fossil fuels, mainly led by coal (43%) and oil (17%) while electricity consumption accounts for 23%. Large and medium-sized enterprises (commercial and industrial consumers) account for over  50%  of  total  national  electricity  consumption.  The  manufacturing  sector accounts for around 12% of fuel consumption, the second-largest after transport (86%).

Despite slower than anticipated growth in industry, overall value added by the sector has shown significant growth in the last two decades, from USD 1.9 billion in 2000 to over USD 20 billion in 2022. Manufacturing is now included as a key policy  focus  under  Kenya's  'Buy  Kenya-Build  Kenya'  initiative  and  the  Kenya Association  of  Manufacturers,  working  closely  with  the  Ministry  of  Trade, Investment  and Industry,  has  developed  a  plan  dubbed  'Kenya  Manufacturing 20by30'. This is a plan to increase the manufacturing sector's contribution to GDP from 7.2% in 2022 to 20% by 2030.

The  NEECS  set  out  plans  to  improve  industrial  competitiveness  and  energy efficiency,  including  increasing  the  coverage  of  audits,  training  and  capacity building  for  licensed  audit  professionals,  promoting  captive  power  use,  and establishing energy efficiency benchmarks. There are approximately

4 000 entities  designated  for  energy  efficiency  audits  due  to  annual  electricity consumption over 120 000 kWh, of which 1 800 had undergone audits by 2019. The NEECS set a target to deliver the remaining 2 200 audits by 2025 with an expected budget of nearly USD 32 million.

Other measures for promoting energy efficiency include aims to establish a trading market for green and white certificates based around energy performance targets and training of energy professionals in the ESCO market. To expand awareness of  industry  and  commercial  energy  efficiency  and  promote  best  practices,  the Kenya Association of Manufacturers in collaboration with the Kenyan government established its Centre for Energy Efficiency and Conservation in 2006. The Centre supports programmes to help companies identify energy wastage and savings potential and offers subsided energy auditing services.

## Recommendations

To reach its objectives, the government of Kenya could consider:

-  Enhancing  the  long-term  capacity  of  relevant  departments  at  the  national  and county level to implement, enforce and monitor energy efficiency regulations and standards.
-  Embedding energy efficiency principles and approaches in the country's plans for promoting demand stimulation, universal access to electricity and clean cooking.
-  Setting out a clear roadmap for the implementation of mandatory building energy codes and minimum energy performance standards for appliances and communicating  this  roadmap  to  stakeholders.  Co-operation  and  alignment  in regional  forums  on  building  and  appliances  regulations  enables  lower  market entrance barriers and lower cost to consumers.
-  Providing support to the ESCO market that can increase confidence and attract investment, in addition to expanding public procurement programmes under the established super ESCO.
-  Co-ordinating with customs to collect data on appliance and vehicle imports, which can inform strategies for addressing imports of low efficiency and second-hand models.

## 8. Energy and climate

Like the rest of the African continent, Kenya's contribution to global climate change is  very minor, accounting for a fraction of global energy-related CO2 emissions today, with emissions per capita among the lowest in the region. In contrast, the country  faces  significant  threats  from  changing  climate  systems.  Mindful  of  its commitments and the imperative to address climate change, Kenya is actively taking steps to confront the challenges ahead. Notable among these actions was the adoption of the Kenya National Adaptation Plan (NAP) 2015-2030 in 2015, the submission of its updated NDC in December 2020, and the adoption of the Climate Change (Amendment) Act in September 2023.

## Emissions profile

In 2022,  Kenya's  energy-related  GHG  emissions  were  28 Mt  CO2-eq.  This compares  to  25 Mt CO2-eq  in  2020  and  20 Mt CO2-eq  in  2010.  The  main contributors to energy-related GHG emissions are buildings and transport, which accounted for 41% and 39% of the total emissions in 2022, respectively (Figure 8.1).

Figure 8.1  Greenhouse gas emissions by sector in Kenya, 2005-2022

<!-- image -->

Source: IEA (2024), Greenhouse Gas Emissions from Energy (database).

Transport is a key driver of emissions in the economy, most notably the expansion in  road  transport  use  over  the  past  decade.  The  transport  sector  is  a  major consumer  of  petroleum  products,  accounting  for  almost  three-quarters  of  all petroleum  products  imported  into  the  country.  By  2020,  Kenya  had  around 4.6 million vehicles,  with  petrol  and  diesel  vehicles  accounting  for  98%  of  the national fleet. The  National Energy  Efficiency and  Conservation  Strategy established targets for CO2 emissions reductions, as well as for improving fleet

fuel  economy,  increasing  e-mobility  and  improving  public  transport  systems. Nonetheless,  the  emissions  intensity  of  the  economy  remains  low  and  at 77 grammes  of  carbon  dioxide  (g CO2)/USD  is  well  below  the  IEA  average  of 184 g CO2/USD. Likewise, with emissions of 96 g CO2/USD, the power sector is a low emitter, especially compared to the IEA average of 320 g CO2/USD.

## Nationally Determined Contributions

In  December  2020,  Kenya  submitted  its  updated  NDC  to  the  United  Nations Framework Convention on Climate Change. Kenya aims to reduce GHG emissions by 32% by 2030 relative to the business-as-usual scenario of 143 Mt CO2-eq  in  line  with  its  sustainable  development  agenda  and  national circumstances. Around 45% of the emissions reductions are expected to come from the energy sector, most notably from increased electricity generation and energy efficiency, with 21% of the mitigation cost coming from domestic sources and 79% of the mitigation cost subject to international support.

## Climate strategies and policies

Long-term low-emission development strategies (LT-LEDS) are crucial frameworks that guide countries in aligning their developmental goals with the Paris Agreement's objective to limit global warming  to well below 2°C. In September  2023,  Kenya  announced  its  LT-LEDS,  with  the  goal  of  steering Kenya towards a net zero emissions future by 2050. Kenya's submission brings the global total to 68 countries, even though the majority of LT-LEDS have been developed  by  high-  or  middle-income  nations.  One  reason  for  this  is  that developing an LT-LEDS is very complex, requiring extensive data alongside an in-depth analysis and understanding of climate action in diverse socio-economic contexts. All this demands financial resources and human resources with specific capacities.  The  IEA  welcomes  the  announcement  of  Kenya's  LT-LEDS  and suggests the country develop the human and technical capacity necessary for the realisation of its strategy.

The  National  Policy  on  Climate  Finance  outlines  Kenya's  legal  and  policy framework for climate financing and identifies the role of climate finance in key economic sectors. It aims to support climate actions in energy and transport as well as in sectors such as agriculture, forestry, trade and tourism. It describes the policy  interventions  the  Kenyan  government  intends  to  make  with  respect  to climate  financing, including establishing a national Climate  Change  Fund, identifying climate financing sources, creating a national system for tracking them, enhancing Kenya's carbon-trading system and exploring the possibility of green bonds.

The Kenya NAP 2015-2030, finalised in 2015, is a strategic framework addressing climate change impacts and promoting adaptation measures in Kenya. It builds upon the foundation established by the National Climate Change Action Plan and aligns with the Constitution of Kenya and Vision 2030. The NAP aims to integrate climate  resilience  into  Kenya's  development  plans  by  proposing  macro-level adaptation actions across sectors. Its main  objectives include integrating adaptation into national- and county-level planning processes while enhancing the resilience of public and private sector investment. According to the first review of the NAP in 2022, many initiatives have been implemented in the agriculture and livestock sectors, such as increasing crop productivity by increasing area under irrigation by 4 933 hectares in June 2020.

The Kenya Climate Change Adaptation Programme, administered by Tana and Athi  Rivers  Development  Authority,  contributes  to  various  sectors  such  as agriculture, energy  and  water  management.  While  focusing  on  enhancing resilience to climate change, its objectives also include improving food security and water management systems in response to climate change.

Kenya is a major producer of tea, coffee, fresh fruit and dairy products. Farmers, who are  used  to  rain-fed  farming  systems,  are  being  pushed  into  dryer,  more marginal areas where they become increasingly vulnerable to drought and the unpredictability  of  weather  patterns  resulting  from  climate  change.  Under  the Integrated  Programme  funded  by  the  Adaptation  Fund,  five  projects  aimed  at enhancing climate resilience and food security are being implemented in selected counties. These projects include establishing milk cooling and processing plants in Kajiado County and constructing check dams for water management in Makueni County.  Although  the  national  government  allocated  KES 700 million  for  the expansion of a milk cooling plant in December 2023, with 10% completion, there is no update on the Wanduli Check Dam in Makueni County since its completion.

## Climate risks and infrastructure resilience

Climate  change  poses major threats to  Kenya's  transport,  telecommunications and water supply infrastructure, as well as energy assets. Infrastructure damage can  result  from  extreme  weather  events,  as  well  as  forced  migration,  political instability, famine, declining labour productivity, poor sanitation and deterioration in public health. All of these have implications for the ease, cost and viability of clean energy transitions, as well as progress in meeting the SDGs.

In Kenya, regardless of the emissions scenario, temperatures are projected to rise, with a high-emission scenario indicating rapid temperature increases by mid-century. Increased heat and extreme weather conditions will have significant implications for the country, including more frequent and intense rainfall events in some regions and decreased rainfall in arid zones. These changes will impact the

resilience of energy-system  infrastructure, affecting hydropower  generation potential, solar PV output and network capacities.

Kenya  faces  a  wide  range  of  natural  and  human-induced  hazards,  such  as droughts, floods, landslides, human and animal disease, pests, earthquakes, and urban and forest fires, that can impact on the welfare of the population and their access to basics services such as energy and telecommunications. In the first quarter of 2024, intense rainfall affected several regions in Kenya, including the coastal area, central areas including Nairobi, the Western Highlands, Rift Valley, Lake Victoria Basin, the south-eastern lowlands and some north-eastern regions. Over 55 000 households were displaced and almost 300 lives lost. Many of the hazards  are  associated  with  the  country's  diverse  geo-climatic  and  socioeconomic  conditions. While the population contends with these hazards, especially  droughts  and  floods,  their  magnitude,  frequency  and  impacts  have become more severe. This is aggravated by climate change and human-induced factors that has resulted in more areas being affected. Mindful of the risks the country faces, the government has developed and implemented several policies to manage emergencies and emerging crises.

The National Disaster Response Plan, for example, outlines principles, procedures, roles and responsibilities for disaster response in Kenya. It addresses various  hazards,  including  droughts,  floods,  landslides  and  fires,  and  provides guidance  for  effective  disaster  management.  The  National  Policy  for  Disaster Management  recognises  the  role  of  climate  change  in  increasing  Kenya's vulnerability  to  disasters.  It  aims  to  institutionalise  mechanisms  for  addressing disasters and associated vulnerabilities, with a focus on climate change resilience. The Climate Risk Management Framework for Kenya seeks to harmonise climatechange  and  disaster-risk  policies.  It  identifies  priority  areas  for  government intervention and outlines strategies for programme co-ordination and implementation.

## The role of carbon markets

Carbon markets can lower the cost of reducing GHG emissions. Expanding and linking  markets  internationally  can  drive  down  the  cost  of  achieving  emission reduction targets, helping to stimulate the needed investments. While the Climate Act represents a major step towards reforming the operation of carbon markets in Kenya, enabling regulations have not been published. To strengthen the operation of the carbon market, the final set of regulations could mandate the disclosure of carbon credits purchase and use (by volume, type and project) by all companies active in Kenya; support the creation of an advance market purchase-commitment coalition  of  different  actors  for  high-quality  credits  (e.g. clean  cookstoves  and direct  air  capture  and  storage);  and  allow  the  development  of  guidelines  for high-quality carbon credits generation.

While Kenya estimates a need for over USD 17 billion to support its mitigation actions up to 2030, it intends to mobilise domestic resources to cover 21% of the budget, with the remaining 79% reliant on international support. One avenue for attracting  financial  assistance  is  through  voluntary  carbon  markets.  Kenya  has leveraged existing market mechanisms, issuing over 50 million carbon credits via the Clean  Development  Mechanism  (CDM)  and  Voluntary  Carbon  Market standards. With the largest CDM portfolio in Eastern Africa, Kenya also hosts a substantial Voluntary Carbon Market portfolio as well.

The  Climate  Change  (Amendment)  Act  aims  to  regulate  carbon  projects  and trading in Kenya, imposing various requirements on stakeholders in the carbon market. It signifies the government's commitment to mitigating the adverse effects of  climate  change  and  establishes  the  National  Climate  Change  Council,  the regulatory  body  in  charge  of  Kenya's  national  climate  change  co-ordination framework.

Under Article 6 of the Paris Agreement, countries can voluntarily co-operate to achieve emission reduction targets outlined in their NDCs. Kenya intends to utilise voluntary co-operation under Article 6, with plans to develop domestic legislation and institutional frameworks governing engagement in market mechanisms. Many Kenyan CDM activities may be eligible for transition, pending the availability of the transition process under the Article 6.4 Supervisory Body (the entity tasked with developing and supervising the requirements and processes needed to operationalise Article 6.4).

## Innovative financing and technology initiatives in Kenya

In December 2023, the European Investment Bank and the Central Bank of Kenya launched an initiative to strengthen domestic financial institutions' commitment to financing  climate-related  investment  and  enable  commercial  banks  to  mobilise climate  finance  that  will  support  the  transition  to  a  net zero  economy  while strengthening  the  climate  resilience  of  the  financial  systems.  The  initiative  will tackle barriers that hold back engagement by commercial banks and will enable the Central Bank of Kenya to incorporate climate risk into its regulatory framework. The scheme increases the impact of climate-related investment by developing a green taxonomy for the financial sector that supports scaling up green investment aligned with the goals of the 2015 Paris Agreement.

In  January  2024,  the  African  Development  Bank  and  the  United  Kingdom announced the  selection  of  the  Transmission  Network  Improvement  Project  in Kenya as a beneficiary project under the Room to Run Sovereign transaction. This means  that  up  to  USD 59 million  of  the  USD 116 million  total  project  cost corresponding to the climate mitigation component of the loan was made possible by means of the additional capital mobilised by the UK government's guarantee.

The funding will contribute to addressing transmission network capacity limitations, improving the reliability and quality of electricity supply, and reducing high power system losses. It will also support the extension and reinforcement of the national electricity grid system and the Last Mile Connectivity Program.

Direct air capture (DAC) technologies extract CO2 directly from the atmosphere, for CO2 storage or utilisation. Twenty-seven DAC plants have been commissioned to date  worldwide.  In  Naivasha,  Kenya,  Project  Hummingbird  is  deploying 100 machines,  making  it  the  world's  second-largest  DAC  pilot.  The  project  is developed by Octavia Carbon and Cella Mineral Storage and is largely powered by  geothermal  energy.  Kenya's  geological  conditions  and  geothermal  energy potential make it an ideal location for scaling up the project since DAC projects can operate with minimal net emissions, aided by waste heat from geothermal plants.  This  initiative  aims  to  store  mineralised  carbon  deep  underground, positioning Kenya as a promising destination for DAC deployment in East Africa.

The Carbon Offsetting and Reduction Scheme for International Aviation (CORSIA) is  a  global  market-based  measure  operated  by  the  International  Civil  Aviation Organization  to  reduce  emissions  from  international  aviation  while  minimising market  distortion  and  respecting  the  special  circumstances  and  respective capabilities of the International Civil Aviation Organization member states. Kenya participates  in  CORSIA through  the  Kenya  Civil  Aviation  Authority.  Meanwhile, Kenya Airways has been engaged in carbon offsetting programmes since 2011 in collaboration with CORSIA and Astral Aviation. Kenya Airways is also a voluntary participant  in  CORSIA  pilot  phases,  monitoring,  reporting  and  verifying  the emissions from its international flights since 2019 and is participating in the first offsetting phase in 2024.

## Recommendations

To reach its objectives, the government of Kenya could consider:

-  Developing  the  human  capacity  and  skill  sets  necessary  to  develop  plans  to implement the Long-Term Low-Emission Development Strategy.
-  Transposing into law the necessary enabling regulations for the Climate Change (Amendment) Act as soon as possible.
-  Preparing a detailed climate risk and impact assessment for the energy sector, which will inform the energy-planning framework, and factoring climate resilience assessments into energy infrastructure decision making.

## 9. Energy investment

Kenya is one of the largest economies in Africa and since 2014 has been ranked as  a  lower  middle-income  country  based  on  its  per  capita  income  level. GDP growth  has  been  strong,  generally  more  than  5%  over  the  last  decade (except for 2020, owing to the Covid-19 pandemic). The country has been effective at attracting international public and private capital, and has a growing domestic financial  ecosystem  that  is  likely  to  become  increasingly  active  in  the  energy sector.

## Current investment patterns

## Public spending acts as the bedrock for energy investments, particularly in grids and rural electrification

The government is facing multiple financial pressures, particularly efforts to keep the cost of living down for the population following a period of high inflation and rising global interest rates combined with growing debt service payments. Kenya has  taken  on  significant  public  debt  and  in  2023,  according  to  the  National Treasury, the country's public debt-to-GDP ratio stood at 70% (compared to the International  Monetary  Fund's  recommended  threshold  of  50%  for  developing countries). The debt service-to-revenue ratio stood at 58.8% (compared to the International Monetary Fund's recommendation of 30%). This limits the government's ability to take on new debt to fund infrastructure projects while also further limiting the fiscal space of the public utilities.

Despite this, public spending on the energy sector has been relatively consistent over  the  last  five  years,  with  a  spike  in  FY2022/23  (Figure 9.1).  Historically, government spending on energy has focused on maintaining and expanding the grid networks, making up 65% of energy spending between FY2021-24, but plans for FY2024/25 see rural electrification accounting for roughly the same share as grids. Both areas are complex for private sector investment, either due to a lack of prior experience (transmission grids) or to high risk of non-payment from the end users (rural electrification). These are, therefore, important focus areas for government spending going forward.

Figure 9.1  Government spending on the energy sector by focus area in Kenya, 2021-2025

<!-- image -->

IEA. CC BY 4.0.

- *Coal mining not included in the 2024/25 budget.

Source: Government of Kenya, The National Treasury and Economic Planning.

## Kenya remains an attractive destination for private investment, but local entrepreneurs struggle to access financing

Kenya  presents  an  attractive  policy  environment  for  investors,  with  foreign investors receiving the same treatment as local investors. Given its strong growth and position as the entry point for trade into inland East African countries, including Rwanda and Uganda, Kenya is home to the regional hubs for many multinationals. The large skilled workforce and developed tech and fintech infrastructure have also  made  Nairobi  a  hub  for  innovations  and  start-ups,  including  in  relation  to energy access.

Venture capital and private equity make up the largest sources of private capital flows into Africa, and Kenya has been one of the major markets for this type of capital (Figure 9.2). Over the last ten years, Kenya has attracted over USD 350 million in venture capital into energy projects. However, private capital from  abroad  is  still  more  readily  available  for  foreign-owned  or  expat-founded businesses.  For  example,  in  2021,  the  World  Resources  Institute  published a study on impact investing in energy companies in Kenya and found that 69% of investment  went  to expat-founded  businesses.  This  leaves locally owned companies with less access to international private capital, relying primarily on local commercial banks (see section below). This can be complicated for highly price-sensitive  areas  like  energy  access,  where  it  is  important  to  have  the cheapest  capital  possible,  which  involves  grants  or  concessional  funding  from sources like development finance institutions (DFIs) or impact investors.

Figure 9.2  Energy-related venture capital investments in Africa, by country, 2014-2023

<!-- image -->

Note: VC = venture capital.

Source: Cleantech Group (2024).

## Development finance institutions play an important role in direct project financing, as well as derisking for private sector investments

Over the last ten years, DFIs have disbursed roughly USD 1.6 billion in energyrelated projects in Kenya, demonstrating the combination of a willingness on the part of the Kenyan government to partner with donors and the presence of a solid pipeline of projects for investment. The vast majority of DFI energy spending to date  has  gone  into  grids  (57%)  and,  more  recently,  policy  support  (28%) (Figure 9.3).

Going forward, DFIs will continue to bolster public spending in areas of the energy sector that are not yet commercially viable. While the government is seeking to mobilise more private sector financing into grids, DFIs will continue to be important sources of finance, as shown  with the African Development Bank and United Kingdom funding injection of up to USD 59 million into the Transmission Network Improvement Project in January 2024. DFIs are also active in funding demonstration  projects  in  key  demand-side  activities,  like  energy  efficiency programmes or EVs and mass transit.

Figure 9.3  Disbursements from development finance institutions to Kenya, 2013-2022

<!-- image -->

DFIs  also  play  a  vital  role  in  derisking  private  sector  investments,  providing guarantees or  other  credit  enhancements.  These  blended  finance  transactions have become increasingly common, with sub-Saharan Africa accounting for nearly half of the climate-related blended finance transactions between 2020 and 2022. Kenya has been one of the top recipient countries of these deals, given that the country  has  relatively  lower  risks  than  many  of  its  regional  peers  and  there  is already interest from the private sector in the country's energy sector.

The use of blended finance is also important to keep the cost of capital affordable. In recent  surveys  carried  out  for  the IEA's  Cost  of  Capital  Observatory, respondents confirmed that they were able to provide capital to utility clean energy projects in Kenya at 8.5-9.0% in 2022 (latest data within the Observatory). While this was lower than other countries on the continent, it was still two to three times higher than Europe or North America. Respondents to the survey noted that they expected  the  cost  of  capital  to  increase,  primarily  due  to  dollar  shortages experienced across the country in 2023 (which have since eased in 2024) and rising global interest rates.

## Attracting further investment

## National roadmaps can ensure that investment from all sources is well co-ordinated and prioritised to meet energy transition needs

In February 2024, the government  published the Energy Transition and Investment Plan 2023-2050. The Plan estimated that USD 600 billion in investment  would  be  necessary  to  reach  the  country's  energy,  transport  and industry goals by 2050. The bulk of this investment will occur in the power and

transport  sectors,  which  account  for  nearly  90%  of  investment  by  2050.  This spending expectation is USD 165 billion more than the business-as-usual case, but this would help drive numerous socio-economic benefits, including potentially supporting an additional 500 000 new jobs by 2050.

The  Energy  Transition  and  Investment  Plan  presents  a  high-level  view  of investment needs, which can be followed up with the creation of sector-specific roadmaps that include clear target setting and project mapping where possible (for example, for grid development or utility-scale power). These detailed roadmaps can  also  identify  where  the  private  sector  is  expected  to  play  a  key  role.  This facilitates greater private sector investment by providing clarity over priorities. It also ensures that the private sector is being deployed as efficiently as possible to achieve the government aims.

An additional advantage of such roadmaps is that they allow for the targeting of concessional financing to areas where it can have the most catalytic impact. There is  a  large  donor  presence  in  Kenya,  with  concessional  involvement  across  all elements  of  the  energy  sector.  This  concessional  activity  could  be  targeted towards areas that are less commercial - such as providing energy access to the most vulnerable households, as seen under KOSAP - or to provide equity capital to help spur the development of more local climate-related start-ups.

Clear roadmaps also help remove uncertainty for investors, as uncertainty can be a major deterrent. While Kenya has a strong regulatory environment, in recent years there has been increased uncertainty due to the moratorium on PPAs and the  introduction  of  a  new  procurement mechanism  for  power  projects. Despite these  uncertainties,  innovative  funding  solutions  are  being  explored  to  drive investment,  including  addressing  the  key  challenge  of  how  to  finance  the maintenance, expansion and modernisation of transmission infrastructure, such as  through  PPPs.  Progress  is  being  made  on  the  creation  of  Africa's  first independent transmission project between the government, Africa50 and PowerGrid India, with three other lines identified for potential PPPs.

## Energy access financing has been complicated by uncertainty over the fiscal regime and its impact on costs

The Kenyan government has overseen a rapid expansion of electricity access, to 75% in 2022, while there has been slower progress in clean cooking, with just 31% access  in  2023.  Despite  this  progress,  energy  access  projects  have  faced  a complex investment environment in recent years as pressure on consumers due to  Covid-19 and the subsequent cost of living spikes have affected profitability within the sector.

While there are already multiple government and donor-led programmes to drive universal access targets, the private sector plays a vital role in providing financing. Margins in the sector are small to keep products affordable to end users, so fiscal regimes governing the sector require sensitive design that allows for commercial business models, affordable end products and demand stimulation, all while not depriving the government of key revenue that can be reinvested.

Under  the  current  fiscal  incentive  regime,  some  off-grid  appliances,  including some clean cookstoves, are subject to import duties of 35% as well as VAT of 16%, making them unaffordable for large portions of the population. Over the last decade, Kenya has put in place several amendments concerning the VAT rate applied to solar equipment and accessories. The Finance Act of 2016 amended the VAT Act of 2013 to provide a VAT exemption on the supply of specialised solar equipment  and  accessories  and  raw  materials  or  inputs  that  are  used  in  the manufacturing of equipment that exclusively uses or stores solar power. However, there  has  been  a  lack  of  clarity  over  the  implementation  of  these  exemptions, particularly in relation to appliances that could also feasibly be powered by the grid, such as many solar televisions or solar refrigerators. These appliances are an important part of demand stimulation, but without fiscal incentives, it is harder for them to remain affordable for end users or profitable for private companies to sell.

Table 9.1. Fiscal incentives for selected solar products in key markets

|            | Solar home system   | Solar home system   | Solar PV   | Solar PV    | Solar water pumps   | Solar water pumps   | Solar televisions, refrigerators and fans   | Solar televisions, refrigerators and fans   |
|------------|---------------------|---------------------|------------|-------------|---------------------|---------------------|---------------------------------------------|---------------------------------------------|
|            | VAT                 | Import duty         | VAT        | Import duty | VAT                 | Import duty         | VAT                                         | Import duty                                 |
| Kenya      | Exempt              | 0%                  | Exempt     | Exempt      | 16%                 | 0%                  | 16%                                         | 25%                                         |
| Uganda     | 0%                  | 0%                  | Exempt     | Exempt      | 18%                 | 0%                  | 18%                                         | 25%                                         |
| Mozambique | 17%                 | 8%                  | 17%        | 7.5%        | 16%                 | 5%                  | 16%                                         | 20%                                         |
| Nigeria    | 10%                 | 0%                  | 5%         | 5%          | 7.5%                | 5%                  | 7.5%                                        | 20%                                         |

Sources: Energy for Growth Hub (2022), How the global energy crisis is improving the prospects of solar in Nigeria; BDO (2022), The East African Regional Handbook on Solar Taxation; Renewable Energy Association of Nigeria (2020), Policy Research on the Imposition of 10% Tariff Duties on Solar Components: Making a Way for Solar in Nigeria; GOGLA (2022), Off-Grid VAT and Duty Tracker; Africa Clean Energy (2021), Impact Assessment of VAT and Import Duty Exemptions for Stand-Alone Solar in Nigeria; Energypedia (2022), Solar Home System Challenges for the Private Sector in Mozambique; GET.invest, (n.d.); Club of Mozambique (2023), Mozambique: New VAT Code in force in January 1st.

A similar story is visible in clean cooking, where incentives have been unclear, particularly in relation to LPG, which saw VAT levies cut to 8% in 2022 and then fully removed  in  2023.  Several  studies  have  demonstrated  the  benefits  of incentives for clean cooking. In 2021, the Clean Cooking Alliance calculated that a  VAT  of  16%  on  LPG  and  improved  cookstoves  would  generate  roughly KES 48.6 billion in government revenues by 2030. However, the study found that, compared  to  a  scenario  where  both  LPG  and  improved  cookstoves  had

VAT exemptions, there would be significantly lower stove uptake, resulting in an additional KES 94.6 billion in healthcare, environmental and affordability-related costs, more than offsetting any revenue gains from the VAT. Moreover, another study looking at clean cooking practices across low- and middle-income countries found  that  the  proportion  of  households  using  traditional  cooking  technologies increased 1-2 percentage points following the VAT exemption removal on LPG and  improved  cookstoves.  These  studies  demonstrate  the  value  of  fiscal incentives,  not  just  as  a  means  to  attract  private  investment,  but  also  to  drive quicker uptake of clean cooking solutions.

The Draft National Green Fiscal Incentives Framework indicates that the Treasury will review the incentive framework for the off-grid and clean cooking sectors. Any incentive review should also seek to ensure consistency with priorities set by the Ministry of Energy and Petroleum and the Ministry of Environment. Private sector engagement can play an essential role in ensuring these incentives are designed in a way that does not block investments. The benefits of such engagement have already been visible in relation to the Climate Change (Amendment) Act, when discussions with the private sector led to a reduction of the proposed level of tax on revenue generated by private companies from the sale of carbon emission reduction credits.

## Local finance can play a larger role in clean energy financing with the right instruments and derisking mechanisms

Kenya has one of the most developed financial markets on the continent. Banks are well-capitalised, behind only South Africa and Nigeria, with a lower share of market concentration among the top three banks. Kenya also has one of the most advanced regulations  in  Africa  relating  to  environment,  social  and  governance risks - part of a trend that has served as a tailwind to clean energy investments globally.  These  environment,  social  and  governance  regulations  help  banks  to factor in the risks associated with climate change and help incentivise lending to green  activities. Kenya's  regulations  include  transparent  financial  reporting standards and climate stress testing for banks (one of only six countries in Africa, as of October 2023, to have this). In October 2021, the Central Bank of Kenya issued the Guidance on Climate-Related Risk Management to commercial banks and mortgage  finance  companies,  which  in  the  long  run  is  likely  to  help  drive investment into clean energy investments.

Despite this, there are still some limitations on commercial banks' activities in the energy  sector.  Commercial  banks  can  struggle  to  finance  larger  scale  energy projects,  which  currently  often  occur  via  project  finance  structures,  given  a mismatch over tenors. Banks are often unable to provide debt for more than a

5- to 7-year tenor, whereas energy projects generally require debt over 15-20 years. For energy access projects, banks generally provide capital at high interest rates - often around 20% - with significant collateral requirements that are prohibitive for most locally owned businesses. Given that these businesses also struggle to access international sources of debt finance, this can lead to an over-reliance on equity financing, which is generally more expensive and is also in shorter supply. These issues are not unique to Kenya, and a common solution is to include commercial banks in a blended capital structure, whereby DFIs or other institutional investors provide the longer-term capital.

Figure 9.4  Banking assets and credit to the private sector in selected sub-Saharan African countries, 2023

<!-- image -->

IEA. CC BY 4.0.

Sources: World Bank (2024), World Development Indicators; European Investment Bank (2024), Finance in Africa.

Figure 9.5  Pension fund allocations by sector, selected sub-Saharan African countries

<!-- image -->

IEA. CC BY 4.0.

Source: Annual reporting from country regulators.

Alongside  commercial  banks,  pension  funds  in  Kenya  represent  an  excellent source of long-term, patient capital to fund energy projects. Between 2006 and the end  of  2020,  assets  under  management  in  Kenyan  pensions  grew  sevenfold. However, as seen across the continent, roughly half of Kenyan pension assets are invested in government securities, where they can secure risk-free rates of 18%.

While  this  reduces  pension  funds'  incentive  to  invest  in  alternative  assets, including infrastructure, steps have been taken to further develop capital market expertise in this area. For example, the European Investment Bank is working with the Central Bank  of  Kenya  to  develop  a  green  taxonomy,  following  the development of a Green Sovereign Bond Taxonomy. Green bonds have already proved a useful tool for assets in Kenya, including real estate (Acorn issuance to develop student housing in 2019) and clean cooking (first-of-its-kind issuance by Burn  in  2023).  A  further  advancement  is  expected  with  the  creation  of  the Dhamana  Guarantee  Company,  a  provider  of  local  currency  guarantees  for pension funds. Dhamana will be modelled on existing successful infrastructure guarantee facilities, such as InfraCredit Nigeria, which has issued over 16 guarantees since its launch in 2017, allowing 19 local pension funds to invest in infrastructure projects. Replicating this model in Kenya could prove instrumental in unlocking this source of more patient capital.

## Recommendations

## To reach its objectives, the government of Kenya could consider:

-  Building  on  the  Energy  Transition  and  Investment  Plan  by  creating  sector roadmaps that specify clear targets and identify where private financing is most needed.
-  Reviewing fiscal incentives for off-grid appliances to ensure that energy and fiscal priorities  are  aligned  and  that  customers  can  access  affordable  solutions  for electricity and clean cooking.
-  Continuing to strengthen the green finance industry via the introduction of a green taxonomy  and  providing  clarity  on  the  Draft  National  Green  Fiscal  Incentives Framework to facilitate greater access to climate finance.
-  Working with donors and development finance institutions to support capacity building  at  commercial  banks  and  develop  capital  market  instruments designed to mobilise domestic financing sources into energy projects.

## Annexes

## Acknowledgements, contributors and credits

The  IEA  review  team  visited  Nairobi  from  18  to  22  March  2024  and  met  with government officials and public and private sector stakeholders across the energy sector. This report is based on information from these meetings, the review team's assessment of Kenya's energy policy and analysis by the IEA. The members of the review team were Jonathan Elkind (Columbia University, team leader); Paola Isabel  Da  Costa  Barbosa  (Brazil);  Stephan  Skare  Enevoldsen  (Denmark); Christoper Metz (United Kingdom); and from the IEA Secretariat, Zakia Adam, Jenny Birkeland, Trevor Criswell, Syrine El Abed, Conor Gask, Emma Gordon, Kieran McNamara and Alessio Scanziani.

Syrine El Abed designed and directed the report. Jenny Birkeland assisted with co-ordinating  the  report,  and  wrote  the  chapters  on  access  to  electricity  and access  to  clean  cooking;  Zakia Adam  wrote  the  section  on  energy  statistics; Trevor Criswell wrote the chapter on renewable energy; Jonathan Elkind wrote the chapter  on  general  energy  policy;  Conor Gask  wrote  the  chapter  on  energy efficiency; Emma Gordon wrote the chapter on energy investment; Kieran McNamara wrote the chapters on electricity and energy and climate; and Alessio Scanziani wrote the chapter on energy security and prepared the figures, supported by Naomi Trick. The report benefitted from reviews and insights from other IEA staff, including, Carlos Fernandez Alvarez, Sophie Attali, Heymi Bahar, Nouhoun Diarra, Zachary Egan, Paolo Frankl, Oliver Joy, Milosz Karpinski, Alison Pridmore,  Pietro  Rinaldi,  Ali  Al  Saffar,  Melanie  Slade,  Cecilia  Tam,  Gianluca Tonolo, Fabian Voswinkel, Adam Ward, Mary Burce Warlick and Daniel Wetzel. Astrid  Dumond  and  Isabelle  Nonain-Semelin  managed  the  editing,  layout  and publication of the report. Jennifer Allain edited the report. The graphic design of the report was done by Poeli Bojorquez.

The IEA extends thanks to Minister of Energy and Petroleum, J. Opiyo Wandayi; former  Minister  of  Energy  and  Petroleum,  Davis  Chirchir;  and  Secretary  for Renewable  Energy,  Eng.  Isaac  Kiva,  who  led  the  government  teams  and  coordinated the review in Nairobi.

The  IEA  thanks  the  numerous  individuals  from  the  following  organisations, institutions and businesses that provided valuable insights for the report: Agence Française  de  Développement  (AFD),  Africa Minigrid  Development  Association, ATIDI, BBOXX, BioLite, BURN Manufacturing, High Commission of Canada in Kenya, CAP-A, CircleGas, CLASP, Clean Cooking Association of Kenya, Climate Champions, Cygnum Capital, Delegation of the European Union to Kenya, EED

Advisory,  EEnovators,  Energy  and  Petroleum  Regulatory  Authority  (EPRA), ENGIE,  Equity  Bank,  Finergreen,  Geothermal  Development  Company  (GDC), GIZ,  EnDev,  Gogla,  HDF  Energy,  JICA,  KenInvest,  Kenya  Association  of Manufacturers, Kenya Electricity Generating Company (KenGen), Kenya Electricity Transmission  Company  (KETRACO),  Kenya  Power  and  Lighting Company  (KPLC),  Kenya  Renewable  Energy  Association  (KEREA),  Kenya Pension Funds Investment Consortium (KEPFIC), KOKO Networks, Ministry of Energy and Petroleum, Modern Energy Cooking Services (MECS), Milele, Mukuru Stoves,  Netherlands  Embassy  in  Kenya,  Norfund,  Octavia  Carbon,  Persistent Energy,  SEforALL,  SNV,  Sunking,  TDB  Group,  UN  Habitat,  U.S.  Embassy  in Kenya, World Bank and WWF.

## Energy balances and key statistical data

|                                                |    | 2005   | 2010   | 2015   | 2020   | 2022   | 2023   |
|------------------------------------------------|----|--------|--------|--------|--------|--------|--------|
| Indicators                                     |    |        |        |        |        |        |        |
| Population (millions)                          |    | 36     | 42     | 47     | 52     | 54     | 55     |
| GDP (billion USD, 2015 prices and PPPs)        |    | 111    | 140    | 176    | 211    | 238    | 252    |
| TES/GDP (toe per thousand 2015 USD PPP)        |    | 6.1    | 5.8    | 5.9    | 5.5    | 5.1    | 5.0    |
| Share of renewables in TES                     |    | 85%    | 80%    | 81%    | 80%    | 80%    | 80%    |
| Share of renewables in power generation        |    | 74%    | 64%    | 86%    | 94%    | 88%    | 90%    |
| Share of modern renewables in power generation |    |        |        |        |        |        |        |
| Total energysupply(PJ)                         |    | 678    | 815    | 1 042  | 1 165  | 1 226  | 1 260  |
| Coal                                           |    | 4      | 6      | 13     | 21     | 30     | 37     |
| Oil                                            |    | 101    | 155    | 182    | 207    | 218    | 212    |
| Natural gas                                    | -  | -      | -      | -      | -      | -      |        |
| Renewables                                     |    | 574    | 654    | 847    | 937    | 977    | 1 008  |
| Hydro                                          |    | 11     | 12     | 12     | 15     | 11     | 10     |
| Bioenergy                                      |    | 527    | 604    | 671    | 734    | 759    | 772    |
| Solar PV                                       |    | 0      | 0      | 0      | 0      | 1      | 2      |
| Wind                                           |    | 0      | 0      | 0      | 5      | 8      | 7      |
| Geothermal                                     |    | 36     | 38     | 163    | 182    | 199    | 217    |
| Other renewables                               |    | 0      | 0      | 0      | 0      | 0      | 0      |
| Others                                         |    | 0      | 0      | 0      | 0      | 1      | 3      |
| Electricity output (TWh)                       |    | 5.7    | 7.2    | 9.7    | 11.7   | 12.9   | 12.7   |
| Coal                                           | -  |        | -      | -      | -      | -      |        |
| Oil                                            |    | - 1.5  | 2.6    | 1.4    | 0.8    | 1.6    | 1.3    |
| Natural gas                                    | -  | -      | -      | -      | -      | -      |        |
| Renewables                                     |    | 4.2    | 4.6    | 8.3    | 10.9   | 11.3   | 11.4   |
| Hydro                                          |    | 3.0    | 3.2    | 3.5    | 4.2    | 3.0    | 2.7    |
| Bioenergy                                      |    | 0.2    | 0.3    | 0.2    | 0.2    | 0.3    | 0.2    |
| Solar PV                                       |    | 0.0    | 0.0    | 0.1    | 0.1    | 0.4    | 0.5    |
| Wind                                           |    | 0.0    | 0.0    | 0.1    | 1.3    | 2.1    | 2.0    |
| Geothermal                                     |    | 1.0    | 1.1    | 4.5    | 5.1    | 5.5    | 6.0    |
| Other renewables                               | -  | -      | -      | -      | -      | -      |        |
| Others                                         | -  | -      | -      | -      | -      | -      |        |
| Imports (PJ)                                   |    | 141    | 184    | 225    | 247    | 276    | 284    |
| Coal                                           |    | 4      | 6      | 13     | 21     | 30     | 37     |
| Oil                                            |    | 137    | 178    | 212    | 225    | 244    | 243    |
| Natural gas                                    | -  | - 0    | -      | -      | -      | -      |        |
| Electricity Bioenergy                          |    | 0      | 0      | 0      | 0      | 1      | 3 1    |
|                                                |    |        | 0      | 0      | 0      | 0      |        |
| Others                                         |    | 1E-06  | 0      | -1E-06 | 0      | 0      | 0      |

|                                    |    | 2005   | 2010   | 2015   | 2020   | 2022   | 2023   |
|------------------------------------|----|--------|--------|--------|--------|--------|--------|
| Total final energyconsumption (PJ) |    | 420    | 508    | 606    | 664    | 696    | 704    |
| Coal                               |    | 4      | 6      | 13     | 21     | 30     | 37     |
| Oil                                |    | 78     | 115    | 162    | 182    | 188    | 181    |
| Natural gas                        | -  | -      | -      | -      | -      | -      |        |
| Electricity                        |    | 17     | 21     | 29     | 32     | 37     | 38     |
| Bioenergy                          |    | 321    | 365    | 402    | 429    | 441    | 448    |
| Others                             |    | 0      | -1E-06 | 0      | 0      | 1E-06  | 0      |
| Buildings (PJ)                     |    | 338    | 388    | 437    | 462    | 474    | 477    |
| Coal                               | -  | -      | -      | -      | -      | -      |        |
| Oil                                |    | 16     | 20     | 27     | 26     | 26     | 26     |
| Natural gas                        | -  | -      | -      | -      | -      | -      |        |
| Electricity                        |    | 6      | 9      | 14     | 16     | 18     | 18     |
| Bioenergy                          |    | 316    | 359    | 396    | 419    | 430    | 433    |
| Others                             |    | -1E-06 | 0      | 0      | 1E-06  | 0      | 0      |
| Industry (PJ)                      |    | 42     | 51     | 59     | 58     | 73     | 87     |
| Coal                               |    | 4      | 6      | 13     | 21     | 30     | 37     |
| Oil                                |    | 22     | 26     | 24     | 11     | 14     | 15     |
| Natural gas                        | -  | -      | -      | -      | -      | -      |        |
| Electricity                        |    | 11     | 12     | 15     | 16     | 19     | 20     |
| Bioenergy                          |    | 5      | 7      | 7      | 10     | 11     | 15     |
| Others                             |    | 0      | -1E-06 | -1E-06 | 0      | 0      | -1E-06 |
| Transport (PJ)                     |    | 40     | 69     | 111    | 144    | 148    | 140    |
| Coal                               | -  | -      | -      | -      | -      | -      |        |
| Oil                                |    | 40     | 69     | 111    | 144    | 148    | 140    |
| Natural gas                        | -  | -      | -      | -      | -      | -      |        |
| Electricity                        | -  | -      | -      | -      | -      | -      |        |
| Bioenergy                          | -  | -      | -      | -      | -      | -      |        |
| Others                             |    | 0      | 0      | 0      | 0      | 0      | 0      |
| GHG emissions (Mt CO 2 -eq)        |    | 15     | 20     | 23     | 25     | 28     |        |
| Coal                               |    | 0      | 1      | 1      | 2      | 3      |        |
| Oil                                |    | 7      | 11     | 13     | 14     | 15     |        |
| Natural gas                        |    | 0      | 0      | 0      | 0      | 0      |        |
| Other                              |    | 7      | 8      | 9      | 9      | 10     |        |

## Abbreviations and acronyms

CDM

Clean Development Mechanism

COP

Conference of the Parties

CORSIA

Carbon Offsetting and Reduction Scheme for International Aviation

DAC

direct air capture

DFI

development finance institution

EAC

East African Community

EAPP

East African Power Pool

EPRA

Energy and Petroleum Regulatory Agency

ESCO

energy services company

EU

European Union

EUR

euro

EV

electric vehicle

FIT

feed-in tariff

FY

fiscal year

GDC

Geothermal Development Company

GDP

gross domestic product

GHG

greenhouse gas

IEA

International Energy Agency

IPP

independent power producer

KenGen

Kenya Electricity Generating Company

KES

Kenyan shilling

KETRACO

Kenya Electricity Transmission Company

KNBS

Kenya National Bureau of Statistics

KNCTS

Kenya National Cooking Transition Strategy

KOSAP

Kenya Off-Grid Solar Access Project

KPLC

Kenya Power and Lighting Company

KPRL

Kenya Petroleum Refineries Limited

LCPDP

Least Cost Power Development Plan

LED

light-emitting diode

LMCP

Last Mile Connectivity Project

LNG

liquefied natural gas

LPG

liquefied petroleum gas

LT-LEDS

long-term low-emission development strategy

MEPS

minimum energy performance standard

NAP

Kenya National Adaptation Plan

NDC

Nationally Determined Contribution

NEECS

National Energy Efficiency and Conservation Strategy

PAYGo

pay-as-you-go

PPA

power purchase agreement

PPP

public-private partnership

PV

photovoltaic

REAP

Renewable Energy Auction Plan

REREC

Rural Electrification and Renewable Energy Corporation

SAF

sustainable aviation fuel

SAIDI

System Average Interruption Duration Index

SAIFI

System Average Interruption Frequency Index

SDG

Sustainable Development Goal

USD

United States dollar

VAT

value-added tax

## Units of measure

BTU/hour

British thermal units per hour

g CO2

gramme of carbon dioxide

GW

gigawatt

GWh

gigawatt hour

kb/d

thousand barrels per day

km

kilometre

kt

kilotonne

kV

kilovolt

kWh

kilowatt hour

L

litre

Mt

million tonnes

Mt CO2

million tonnes carbon dioxide

MW

megawatt

MWh

megawatt hour

PJ

petajoule

t

tonne

TWh

terawatt hour

Lge

litres of gas equivalent

International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those  of  the  IEA's  individual  Member  countries  or  of  any  particular  funder  or collaborator.  The  work  does  not  constitute  professional  advice  on  any  specific issue  or  situation.  The  IEA  makes  no  representation  or  warranty,  express  or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject to the IEA's Notice for CC-licenced Content, this work is licenced under a Creative Commons Attribution 4.0 International Licence.

Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications

International Energy Agency

Website: www.iea.org

Contact information: www.iea.org/contact

Typeset in France by IEA January 2025

<!-- image -->

Government action is pivotal in building secure, inclusive and sustainable energy systems. Energy policy is critical not just for the energy sector but also for meeting environmental, economic and social goals. Governments need to respond to national specific needs, adapt to regional contexts, and help address global challenges. In this context, the International Energy Agency (IEA) conducts Energy Policy Reviews to support governments in developing more impactful energy and climate policies.

This Energy Policy Review of Kenya was prepared in collaboration between the government of Kenya and the IEA, whose strong partnership achieved an important milestone in 2023 when Kenya joined the IEA family as an Association country.

The review leverages the IEA's extensive knowledge and the inputs of expert peers from IEA member countries to assess Kenya's most pressing energy challenges and provide recommendations backed by international best practices, especially as Kenya revises its 2018 Energy Policy to adapt it to current energy trends and needs.

The report highlights Kenya's leadership in areas such as promoting universal access to modern energy and developing its renewable energy capacity, especially geothermal. It also encourages the exchange of best practices among countries to foster learning and strengthen political will for a sustainable and affordable clean energy future.