---
document_id: irena_global_renewables_outlook_2020
title: "Global Renewables Outlook: Energy Transformation 2050"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IRENA"
year: 2020
original_file: "irena_global_renewables_outlook_2020.pdf"
tables_detected: 465
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## GLOBAL RENEWABLES OUTLOOK

E D I T I O N :

2020

<!-- image -->

<!-- image -->

## © IRENA 2020

Unless  otherwise  stated,  material  in  this  publication  may  be  freely  used,  shared,  copied, reproduced,  printed  and/or  stored,  provided  that  appropriate  acknowledgement  is  given  of IRENA as the source and copyright holder. Material in this publication that is attributed to third parties may be subject to separate terms of use and restrictions, and appropriate permissions from these third parties may need to be secured before any use of such material.

## IRENA (2020), Global Renewables Outlook: Energy transformation 2050

(Edition: 2020), International Renewable Energy Agency, Abu Dhabi. ISBN 978-92-9260-238-3

Available for download: www.irena.org/publications For further information or to provide feedback: info@irena.org

## About IRENA

The International Renewable Energy Agency (IRENA) serves as the principal platform for international co-operation, a centre of excellence, a repository of policy,  technology,  resource  and  financial  knowledge,  and  a  driver  of  action on  the  ground  to  advance  the  transformation  of  the  global  energy  system. An intergovernmental organisation  established  in  2011,  IRENA  promotes  the widespread adoption  and  sustainable  use  of  all  forms  of  renewable  energy, including bioenergy, geothermal, hydropower, ocean, solar and wind energy, in the pursuit of sustainable development, energy access, energy security and low-carbon economic growth and prosperity. www.irena.org

## DISCLAIMER

This publication and the material herein are provided 'as is'. All reasonable precautions have been taken by IRENA to verify the reliability of the material in this publication. However, neither IRENA nor any of its officials, agents, data or other third-party content providers provides a warranty of any kind, either expressed or implied, and they accept no responsibility or liability for any consequence of use of the publication or material herein.

The information contained herein does not necessarily represent the views of all Members of IRENA. The mention of specific companies or certain projects or products does not imply that they are endorsed or recommended by IRENA in preference to others of a similar nature that are  not  mentioned.  The  designations  employed,  and  the  presentation  of  material  herein,  do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

## ACKNOWLEDGEMENTS

This  outlook  was  prepared  by  IRENA's  Renewable  Energy  Roadmap  (REmap)  and Policy  teams.  The  technology  chapters  (1,  3  and  5)  were  authored  by  Dolf  Gielen, Ricardo Gorini, Nicholas Wagner, Rodrigo Leme and Gayathri Prakash, with valuable additional  contributions  and  support  from  Luca  Lorenzoni,  Elisa  Asmelash,  Sean Collins, Luis Janeiro and Rajon Bhuiyan. The socio-economic chapters (2, 4 and 6) were authored by Rabia Ferroukhi, Michael Renner, Bishal Parajuli and Xavier Garcia Casals. Valuable additional contributions for socio-economic chapters were made by Amir Lebdioui (London School of Economics/University of Cambridge), Kelly Rigg (The Varda Group) and Ulrike Lehr (GWS). Macro-economic modelling (E3ME) results were provided by Eva Alexandri, Unnada Chewpreecha, Zsófi Kőműves, Hector Pollitt, Alistair Smith, Jon Stenning, Pim Vercoulen and other team members at Cambridge Econometrics, UK.

This outlook also benefited from contributions by IRENA experts: Toshimasa Masuyama and  Seungwoo  Kang  (bioenergy),  Francisco  Boshell  and  Arina  Anisie  (enabling technologies  for  grid  integration),  Carlos  Guadarrama  (greening  economies),  Paul Durrant and Sean Ratka (hard-to-decarbonise sectors), Michael Taylor, Pablo Ralon and Harold Anuta (power generation costs and fossil-fuel subsidies), Emanuele Taibi and Raul Miranda (power system dispatch model and the role of hydrogen) and Elena Ocenic (Swedish power system innovation needs).

IRENA appreciates the valuable chapter reviews (1,3 and 5) provided by David Wogan (Asia  Pacific  Energy  Research  Centre  -  APERC),  Randolph  Bell  (Atlantic  Council), Morgan Bazilian (Colorado School of Mines), Ruud Kempener (European Commission - Directorate-General for Energy), Ioannis Tsiropoulos (European Commission - Joint Research  Centre),  Michael  Hackethal  (German  Federal  Ministry  of  Economics  and Technology - BMWi), Eric Williams (King Abdullah Petroleum Studies and Research Center  -  KAPSARC),  Andres  Schuschny  (Latin  American  Energy  Organization  OLADE), Maged K. Mahmoud (Regional Centre for Renewable Energy and Energy Efficiency - RCREEE), Kieran Coleman and Mark Silberg (Rocky Mountain Institute), Deger Saygin (SHURA Energy Transition Center), and Jeffrey Logan (U.S. National Renewable Energy Laboratory - NREL).

Valuable  review  and  feedback  were  also  received  from  IRENA  colleagues:  Ahmed Abdel-Latif,  Prasoon  Agarwal,  Fabian  Barrera,  Hürrem  Cansevdi,  Pablo  Carvajal, Laura  Casado  Fulgueiras,  Yong  Chen,  Nopenyo  Dabla,  Celia  García-Baños,  Arieta Gonelevu Rakai, Gurbuz Gonul, Zoheir Hamedi, Hyun Ko, Paul Komor, Reem Korban, Neil MacDonald, Asami Miketa, Gayathri Nair, Elizabeth Njoki Wanjiru, Elizabeth Press, Alessandra Salgado, José Torón, Badariah Yosiyana and Benson Zeyi.

Chapters in this outlook were edited by John Carey, Steven Kennedy and Lisa Mastny.

IRENA  is  grateful  for  the  generous  support  of  the  Federal  Ministry  for  Economic Affairs and Energy of Germany, which made the publication of this outlook a reality.

Available for download:

www.irena.org/publications

For further information or to provide feedback: info@irena.org

## F O R E WO R D

This  first Global  Renewables  Outlook arrives  while  the  world  suffers  through  the COVID-19 pandemic, which brings dramatic numbers of people infected, a mounting death toll, and social and economic disruption for regions, countries and communities.

The priority now remains to save as many lives as possible, bring the health emergency under control and alleviate hardship. At the same time, governments are embarking on the monumental task of devising stimulus and recovery packages. These are at a scale to shape societies and economies for years to come.

This response must align with medium- and long-term priorities. The goals set out in the United Nations 2030 Agenda and the Paris Agreement can serve as a compass to keep us on course during this disorienting period. They can help to ensure that the short-term solutions adopted in the face of COVID-19 are in line with medium- and long-term development and climate objectives.

Stimulus and recovery packages should accelerate the shift to sustainable, decarbonised economies and resilient inclusive societies. The Nationally Determied Contributions (NDCs) to be presented by the end of this year, as required under the Paris Agreement, should be the backbone of the stimulus package.

In this respect, the Global Renewables Outlook shows the path to create a sustainable future energy system. It highlights climate-safe investment options until 2050 and the policy framework needed to manage the transition. Building on earlier Global Energy Transformation reports,  it  also  grapples  with  the  decarbonisation  of  challenging industry and transport sectors and presents a perspective on deeper decarbonisation.

Raising regional and country-level ambitions will be crucial to meet interlinked energy and climate objectives. Renewables, efficiency and electrification provide a clear focus for action until mid-century. Several regions are poised to reach 70-80% renewable energy use in this outlook. Electrification of heat and transport would similarly rise across the board.

The nature of this crisis calls for a major state role in the response. This involves defining the strategies and initiating direct interventions for the way out. Expansionary budget policies may be envisaged to support this effort.

Economies need more than a kick-start. They need stable assets, including an inclusive energy  system  that  supports  low-carbon  development.  Otherwise,  even  with  the global slowdown momentarily reducing carbon dioxide (CO2) emissions, the eventual rebound  may  restore  the  long-term  trend.  Fossil-fuel  investments  would  continue polluting the air, adding to healthcare costs and locking in unsustainable practices.

Although  renewable  energy  technologies  may  be  affected  by  the pandemic  just  like  other  investments,  energy  market  dynamics  are unlikely to disrupt investments in renewables. Price volatility undermines the viability of unconventional oil and gas resources, as well as longterm contracts, making the business case for renewables even stronger. One further result would be the ability to reduce or redirect fossil-fuel subsidies towards clean energy without adding to social disruptions.

## A renewable energy roadmap

Economic recovery packages must serve to accelerate a just transition. The  European  Green  Deal,  to  take  an  existing  example,  shows  how energy investments could align with global climate goals. The time has come to invest trillions, not into fossil fuels, but into sustainable energy infrastructure.

Recovery measures could help to install flexible power grids, efficiency solutions,  electric  vehicle  (EV)  charging  systems,  energy  storage, interconnected hydropower, green hydrogen and multiple other clean energy technologies. With the need for energy decarbonisation unchanged,  such  investments  can  safeguard  against  short-sighted decisions and greater accumulation of stranded assets.

COVID-19 does not change the existential path required to decarbonise our  societies  and  meet  sustainability  goals.  By  making  the  energy transition  an  integral  part  of  the  wider  recovery,  governments  can achieve a step change in the pursuit of a healthy, inclusive, prosperous, just and resilient future.

While each country must work with a different resource mix, all of them need a 21st-century energy system. The response must provide more than just a bail-out for existing socio-economic structures.

Now,  more  than  ever,  public  policies  and  investment  decisions  must align with the vision of a sustainable and just future. Making this happen requires a broad policy package - one that tackles energy and climate goals hand in hand with socio-economic challenges at every level. A just transition should leave no one behind.

I hope sincerely that this new publication helps to show the way.

Francesco La Camera

<!-- image -->

Director-General, IRENA

## CONTENTS

<!-- image -->

<!-- image -->

|    | THIS REPORT AND ITS FOCUS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                 | THIS REPORT AND ITS FOCUS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                 | . . 12   |
|----|---------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------|----------|
|    | KEY FINDINGS . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                              | . . . . . . . . . . . . . . . . . . .                                                                                                                   | . . 14   |
|    | SUMMARY . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | SUMMARY . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . . 18   |
|    | A widening gap between rhetoric and action . . . . . . . . . . . . . . . . . . .                                                                        | . . . . . .                                                                                                                                             | . . 19   |
|    | Transformative energy developments . . . .                                                                                                              | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                             | . 22     |
|    | Planning for the long term . . . . . . .                                                                                                                | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                       | . 33     |
|    | Global socio-economic impact . . . .                                                                                                                    | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                             | . 40     |
|    | Regional socio-economic impact . . . . . . . . . . .                                                                                                    | . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                   | . 43     |
|    | Towards the transformative decarbonisation of societies . . . . . . . . .                                                                               | .                                                                                                                                                       | . 54     |
|    | THE ROADMAP TO 2050 . . . . . . . . . . .                                                                                                               | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                 | . 56     |
| 01 | 1.1                                                                                                                                                     | Drivers for the energy transformation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                     | . 57     |
|    | 1.2                                                                                                                                                     | A widening gap between reality and what is needed . . . . . . . . . . . . .                                                                             | . 64     |
|    | 1.3                                                                                                                                                     | An ambitious and yet achievable climate-resilient transformative pathway to 2050: What does the transformation entail? . . . . . . . . .                | . 67     |
|    | 1.4                                                                                                                                                     | Outlook for 2030 and NDC formulation . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                          | . . 91   |
|    | 1.5                                                                                                                                                     | Investment must be redirected . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                               | . 95     |
|    | GLOBAL SOCIO-ECONOMIC IMPACT . . . . . . . . . . . . . .                                                                                                | . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                   | . 98     |
| 02 | 2.1                                                                                                                                                     | Jobs and skills . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                       | 100      |
|    | 2.2                                                                                                                                                     | Gross domestic product . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                      | 109      |
|    | 2.3                                                                                                                                                     | Welfare . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .               | . . 111  |
|    | 2.4                                                                                                                                                     | Conclusion . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                    | . 113    |
| 03 | REGIONAL ENERGY TRANSFORMATION: TECHNO-ECONOMIC CONTEXT . .                                                                                             | REGIONAL ENERGY TRANSFORMATION: TECHNO-ECONOMIC CONTEXT . .                                                                                             | . 116    |
|    | 3.1                                                                                                                                                     | Context and characteristics . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                         | . 118    |
|    | 3.2                                                                                                                                                     | Priorities and drivers . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                              | . 125    |
|    | 3.3                                                                                                                                                     | IRENA's transformative pathway to 2050 . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                            | 129      |
|    | 3.4                                                                                                                                                     | Key actions . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                   | . 133    |
| 04 | REGIONAL SOCIO-ECONOMIC IMPACTS . . .                                                                                                                   | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                       | 136      |
|    | 4.1                                                                                                                                                     | Background . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                          | . 137    |
|    | 4.2                                                                                                                                                     | Socio-economic indicators of the energy transition: Jobs . . . . . . .                                                                                  | . 141    |
|    | 4.3                                                                                                                                                     | Socio-economic indicators of the energy transition: GDP . . . . . . .                                                                                   | . 151    |
|    | 4.4                                                                                                                                                     | Policy conclusions . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                | 156      |

<!-- image -->

<!-- image -->

| GETTING TO ZERO . . . . . . . .                         | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                     | 158   |    |
|---------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-------|----|
| 5.1                                                     | Getting to zero: technology options and costs . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                           | 159   | 05 |
| 5.2                                                     | Eliminating the remaining emissions including in challenging sectors such as industry and transport . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | 170   | 05 |
| 5.3                                                     | Very high shares of renewable power . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                 | . 176 | 05 |
| 5.4                                                     | The role of hydrogen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                          | 180   | 05 |
| 5.5                                                     | Challenging sectors: Transport . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                      | 183   | 05 |
| 5.6                                                     | Challenging sectors: Industry . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                   | 186   | 05 |
| 5.7                                                     | Challenging sectors: Natural gas infrastructure . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                           | . 191 | 05 |
| TOWARDS THE TRANSFORMATIVE DECARBONISATION OF SOCIETIES | TOWARDS THE TRANSFORMATIVE DECARBONISATION OF SOCIETIES                                                                                                                                     | 192   |    |
| 6.1                                                     | A transformative transition . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                 | 193   | 06 |
| 6.2                                                     | Overcoming challenges . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                               | 196   | 06 |
| 6.3                                                     | Policy interventions for a decarbonised society . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                           | 201   | 06 |
| 6.4                                                     | Foundations for success: Resources, institutions and international co-operation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                     | 204   | 06 |
| . . . . . . . .                                         | . . . . . . . .                                                                                                                                                                             |       |    |
| REFERENCES . . . . . . .                                | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                     | 206   |    |
| ABBREVIATIONS . . . . . .                               | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                           | . 211 |    |
| REGIONAL FACTSHEETS . . . . . .                         | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                             | . 212 |    |
| EAST ASIA . . . . . . SOUTHEAST                         | EAST ASIA . . . . . . SOUTHEAST                                                                                                                                                             |       |    |
| ASIA . .                                                | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                         | 220   |    |
| EUROPEAN UNION                                          | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                       | 236   |    |
| REST OF EUROPE . . . .                                  | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                           | 244   |    |
| . . .                                                   | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                   | 260   |    |
| MIDDLE EAST ANDNORTHAFRICA .                            | MIDDLE EAST ANDNORTHAFRICA .                                                                                                                                                                |       |    |
| NORTH AMERICA . .                                       | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                       | 268   |    |
| OCEANIA . . . . .                                       | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                           | 276   |    |
| SUB-SAHARAN AFRICA                                      | . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                 | 284   |    |

## FI G U R E S

| SUMMARY   | Figure S.1   | The changing nature of energy and fossil-fuel use . . . . . . . . . . . . . . . . . . . . . .                                                                                                          | . . 21   |
|-----------|--------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|----------|
|           | Figure S.2   | Renewables in the world's energy mix: Six-fold increase needed. . . . . . .                                                                                                                            | . 23     |
|           | Figure S.3   | An increasingly electrified energy system . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                | . 25     |
|           | Figure S.4   | The need for power system flexibility . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                          | . . 27   |
|           | Figure S.5   | Vital to any future energy system: Hydropower and bioenergy. . . . . . . . .                                                                                                                           | . 29     |
|           | Figure S.6   | Hydrogen: A key part of future energy systems . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                        | . . 31   |
|           | Figure S.7   | The bulk of emission reductions: Renewables and efficiency . . . . . . . . . . .                                                                                                                       | . 33     |
|           | Figure S. 8  | New investment priorities: Renewables, efficiency and electrification of heat and transport. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . 34     |
|           | Figure S.9   | The energy transition: Benefits compared to costs . . . . . . . . . . . . . . . . . . . . . .                                                                                                          | . 35     |
|           | Figure S.10  | Different transition paths for different regions . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                   | . 38     |
|           | Figure S.11  | Welfare gains: Influenced by health benefits and emission reduction . .                                                                                                                                | . 42     |
|           | Figure S.12  | A hundred million energy jobs: Regional distribution . . . . . . . . . . . . . . . . . . .                                                                                                             | . 44     |
|           | Figure S.13  | Energy sector job gains: Exceeding losses in every region . . . . . . . . . . . . . .                                                                                                                  | . 45     |
|           | Figure S.14  | An estimated 42 million jobs in renewables: Regional distribution . . . . .                                                                                                                            | . 47     |
|           | Figure S.15  | Largest drivers of GDP gains: Transition effects and trade. . . . . . . . . . . . . .                                                                                                                  | . 50     |
|           | Figure S.16  | Regional differences in GDP gains per capita. . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                  | . . 51   |
|           | Figure S.17  | Regional-level welfare improvements driven by social and environmental gains. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .              | . . 52   |
| CHAPTER 1 | Figure 1.1   | Pressing needs and attractive opportunities . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                    | . 57     |
|           | Figure 1.2   | Solar and wind power: Expected cost reductions until 2030 . . . . . . . . . . .                                                                                                                        | 60       |
|           | Figure 1.3   | Energy subsidies: Overall reduction in the Transforming Energy Scenario                                                                                                                                | . 62     |
|           | Figure 1.4   | Renewables, energy efficiency, electric vehicles and hydrogen can provide bulk of necessary emissions reductions by 2050 . . . . . . . . . . . . . . . . . .                                           | . 65     |
|           | Figure 1.5   | To meet agreed global climate goals, renewables would need to provide two-thirds of the world's energy supply . . . . . . . . . . . . . . . . . . . . . . .                                            | . 67     |
|           | Figure 1.6   | Solar, wind and other renewable power generation until 2050 . . . . . . . . .                                                                                                                          | . 69     |
|           | Figure 1.7   | Hourly electricity dispatch in 2050: No major system flexibility issues . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                | . 70     |
|           | Figure 1.8   | Renewable electricity: The world's largest energy carrier by 2050 . . . .                                                                                                                              | . 72     |
|           | Figure 1.9   | Energy intensity improvement rate: 3.2% increase needed yearly . . . . .                                                                                                                               | . 73     |
|           | Figure 1.10  | Electrification with renewables: Ensuring 60% lower energy-related CO 2 emissions in 2050 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .      | . 75     |
|           | Figure 1.11  | Low-cost electricity for transport . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                     | . 76     |
|           | Figure 1.12  | Smart charging: System-level and local flexibility via electric vehicles                                                                                                                               | . 77     |

| Figure 1.13   | Technologies, business models and regulatory frameworks for EV smart charging . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .       | . 78   |           |
|---------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------|-----------|
| Figure 1.14   | System-wide transformation: Changes in all sectors of energy use . .                                                                                                                    | . 84   |           |
| Figure 1.15   | Internet of Things (IoT) as a driver for power system transformation                                                                                                                    | . 86   |           |
| Figure 1.16   | Different visions of the future: Scenarios presented in other major energy studies . . . . . . . . . . . . . . . . . . .                                                                | . 89   |           |
| Figure 1.17   | Emerging consensus on the role of renewable power . . . . . . . . . . . . . . . .                                                                                                       | 90     |           |
| Figure 1.18   | Nationally Determined Contributions: Currently insufficient to meet Paris Agreement climate goals . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                       | . 91   |           |
| Figure 1.19   | Renewable energy share needs to grow in all sectors . . . . . . . . . . . . . . . .                                                                                                     | . 93   |           |
| Figure 1.20   | NDCs with targets for renewables: Numbers by region . . . . . . . . . . . . . . .                                                                                                       | . 94   |           |
| Figure 1.21   | Energy investments 2016-2030 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                            | . 95   |           |
| Figure 1.22   | Energy investments 2016-2050 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                            | . 97   |           |
| Figure 2.1    | Close interplay between the energy sector and the economy . . . . . . . .                                                                                                               | . 99   | CHAPTER 2 |
| Figure 2.2    | Energy sector jobs growth: Reaching 100 million in 2050 . . . . . . . . . . . .                                                                                                         | 100    |           |
| Figure 2.3    | Renewable energy jobs: Dominated by solar energy technology . . . .                                                                                                                     | 102    |           |
| Figure 2.4    | Deep-dive analysis: Majority of jobs will be created in construction and installation and for workers and technicians . . . . . . . . . . . . . . . . . . . . . . .                     | 103    |           |
| Figure 2.5    | Energy sector job gains and losses: Four cases . . . . . . . . . . . . . . . . . . . . . . .                                                                                            | 105    |           |
| Figure 2.6    | Economy-wide jobs: Increase by 6.5 million . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                        | 107    |           |
| Figure 2.7    | Renewable energy, energy sector and overall economy . . . . . . . . . . . . . .                                                                                                         | 108    |           |
| Figure 2.8    | Transforming Energy Scenario boosts global GDP . . . . . . . . . . . . . . . . . . . .                                                                                                  | 109    |           |
| Figure 2.9    | Global per-capita GDP gains outstrip investment costs . . . . . . . . . . . . . .                                                                                                       | 110    |           |
| Figure 2.10   | Welfare gains: Influenced by health benefits and emission reduction                                                                                                                     | . 111  |           |
| Figure 3.1    | World population growth: From 7.5 billion today to over 9.7 billion by 2050 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | 118    | CHAPTER 3 |
| Figure 3.2    | Uneven wealth distribution among regions . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                        | 119    |           |
| Figure 3.3    | Energy consumption per capita: Rising in step with wealth and access                                                                                                                    | 120    |           |
| Figure 3.4    | Energy-related CO 2 emissions: Current level in regions . . . . . . . . . . . . . . .                                                                                                   | 121    |           |
| Figure 3.5    | Fossil fuel imports and exports: Net balance by region . . . . . . . . . . . . . . .                                                                                                    | 122    |           |
| Figure 3.6    | Energy-intensive industries: High demand concentrated in East Asia                                                                                                                      | 123    |           |
| Figure 3.7    | Urban air quality: A major concern in fast-growing cities . . . . . . . . . . . . .                                                                                                     | 124    |           |
| Figure 3.8    | Renewable electricity: Cheaper than average in most regions . . . . . . .                                                                                                               | 125    |           |
| Figure 3.9    | Planned Energy Scenario: Different prospects for each region . . . . . . .                                                                                                              | 126    |           |
| Figure 3.10   | Global energy decarbonisation: Different regional transition paths . . .                                                                                                                | 130    |           |
| Figure 3.11   | Transforming Energy Scenario: Varying investment needs by region                                                                                                                        | 132    |           |
| Figure 3.12   | Global energy decarbonisation: Swift action needed in all sectors . . .                                                                                                                 | 134    |           |

## FI G U R E S (continued)

| CHAPTER 4   | Figure 4.1   | Some regions feature prominently in population and job distribution, others in GDP distribution . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .               | . 138   |
|-------------|--------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|
|             | Figure 4.2   | North America, Oceania and the European Union: Per capita GDP well above the global average . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                             | . 139   |
|             | Figure 4.3   | Growth rates of population, jobs and GDP vary across regions . . . . . . . .                                                                                                                                  | . 140   |
|             | Figure 4.4   | Clean energy investment per capita varies widely among regions . . . . .                                                                                                                                      | . 141   |
|             | Figure 4.5   | A hundred million energy jobs: Regional distribution . . . . . . . . . . . . . . . . . . .                                                                                                                    | . 143   |
|             | Figure 4.6   | All regions gain more energy sector jobs than they lose . . . . . . . . . . . . . . . .                                                                                                                       | . 144   |
|             | Figure 4.7   | An estimated 42 million jobs in renewables: Regional distribution . . . . .                                                                                                                                   | . 145   |
|             | Figure 4.8   | The European Union stands to gain the most jobs economy-wide . . . . .                                                                                                                                        | . 148   |
|             | Figure 4.9   | Indirect and induced effects: Strongest in the European Union and North America . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                 | . 149   |
|             | Figure 4.10  | All regions except two see GDP rise . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                 | . 151   |
|             | Figure 4.11  | The largest drivers of GDP gains: Indirect and induced effects, and trade . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . | . 152   |
|             | Figure 4.12  | Regional differences in GDP gains per capita . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                                            | . 154   |
|             | Figure 4.13  | Welfare improvements at regional levels driven by social and environmental gains . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                  | . 155   |
| CHAPTER 5   | Figure 5.1   | Industry and transport: The bulk of remaining emissions in 2050 . . . . . .                                                                                                                                   | . 160   |
|             | Figure 5.2   | The Deeper Decarbonisation Perspective: Getting to "net-zero" and eventually 'zero' . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                 | . 161   |
|             | Figure 5.3   | Renewables and efficiency: Achieving the bulk of emission reductions                                                                                                                                          | . 165   |
|             | Figure 5.4   | CO 2 cuts with renewables: Two-thirds of the way to zero . . . . . . . . . . . . . . .                                                                                                                        | . 166   |
|             | Figure 5.5   | Every USD 1 spent brings USD 3-8 payback in environmental and health returns . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .        | . 167   |
|             | Figure 5.6   | Affordable CO 2 mitigation: Efficiency, renewables and structural change                                                                                                                                      | . 168   |
|             | Figure 5.7   | Mitigation costs under different scenarios: From USD 23 to USD 156 per tonne of CO 2 . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .      | . 169   |
|             | Figure 5.8   | CO 2 emissions from industry: Two-thirds of the remainder in the Transforming Energy Scenario . . . . .                                                                                                       | . 171   |
|             | Figure 5.9   | Four innovative solutions for Sweden's power system . . . . . . . . . . . . . . . . . .                                                                                                                       | . 178   |
|             | Figure 5.10  | Green hydrogen production costs: Approaching competitiveness with blue hydrogen . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                 | . 181   |
| CHAPTER 6   | Figure 6.1   | The global Green New Deal: At the heart of solutions to achieve social, economic and environmental objectives . . . . . . . . . . . . . . . . . . . . . . . . .                                               | . 193   |
|             | Figure 6.2   | Diverse energy transition outcomes for regions and countries . . . . . . . . .                                                                                                                                | . 196   |
|             | Figure 6.3   | Renewable energy innovation: Leading countries . . . . . . . . . . . . . . . . . . . . . . .                                                                                                                  | . 198   |
|             | Figure 6.4   | A comprehensive package: Deployment, enabling and integrating policies . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                          | 202     |

## TABLES AND BOXES

## TABLES

| Table 2.1   | A roadmap to 2050: Tracking key socioeconomic indicators of the global energy transformation . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .   | . 113   |
|-------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------|
| Table 3.1   | Annual investments in the Transforming Energy Scenario by region through 2050 (USD billion/yr) . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                   | . 133   |
| Table 5.1   | Key decarbonisation solutions by sector . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                | . 172   |
| BOXES       | BOXES                                                                                                                                                                                      |         |
| Box 1.1     | Renewable power generation costs continue to decline . . . . . . . . . . . . . . . . .                                                                                                     | . 60    |
| Box 1.2     | Energy subsidies in the energy transformation . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                        | . 62    |
| Box 1.3     | Overview of power system flexibility in the energy transformation . . . . .                                                                                                                | . 70    |
| Box 1.4     | Electrification with renewables: Driving the transformation of energy services . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                     | . 74    |
| Box 1.5     | Smart charging for electric vehicles . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                     | . 76    |
| Box 1.6     | Bioenergy . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                            | . 80    |
| Box 1.7     | Stepping forward to a digitalised and interconnected world . . . . . . . . . . . . .                                                                                                       | . 86    |
| Box 1.8     | Scenarios comparison . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                           | . 88    |
| Box 2.1     | Drivers of gains and losses in the energy sector . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                       | 104     |
| Box 2.2     | Drivers of economy-wide jobs and gdp . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                                 | 106     |
| Box 2.3     | Structure of the welfare indicator . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                       | . 112   |
| Box 5.1     | Carbon capture, utilisation and storage . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .                                                                              | . 173   |
| Box 5.2     | Innovation to support high shares of variable renewable power . . . . . . . . .                                                                                                            | . 177   |
| Box 6.1     | The just transition mechanism of the European Green Deal . . . . . . . . . . . . . .                                                                                                       | 195     |
| Box 6.2     | Leveraging capacities to support the energy transition: The case of Brazil                                                                                                                 | 199     |

## THIS REPORT AND ITS FOCUS

The International Renewable Energy Agency (IRENA) has produced a succession of studies aiming to quantify and guide the transformation of the world's energy system. These  roadmaps  provide  an  ambitious,  yet  technically  and  economically  feasible, pathway for deploying low-carbon technologies to create a clean, sustainable energy future.

One of IRENA's initial studies, outlined in a key chapter of Perspectives for the Energy Transition (IEA  and  IRENA,  2017),  focused  on  the  technical  feasibility  and  socioeconomic benefits of long-term global decarbonisation. The subsequent Global Energy Transformation: A Roadmap to 2050 (IRENA, 2018a),  expanded on the implications of accelerated uptake of renewables and investigated the associated investment needs, examined key transition requirements by sector, and offered further insights into the socio-economic implications.

The  second  edition  of  the Global  Energy  Transformation roadmap  (IRENA,  2019a) updated  IRENA's  analysis  of  key  countries  and  regions  and  underlined  the  role  of renewables-based electrification as a key enabling solution. The report also offered new findings on the costs, subsidies and investment needs of the transition. IRENA's socio-economic analysis delved into the effects of the global transition in terms of gross domestic product (GDP) and jobs as well as an assessment of potential impacts of climate damages.

This Global  Renewables  Outlook reviews  the  ongoing  energy  transformation  with closer examination of needs and impacts at the regional level, in both energy and socio-economic  terms.  Going  further  than  the  previous  studies,  this  report  also outlines a vision for transformative energy policies as the conduit to the creation of a deeply decarbonised global society. On the innovation and technology side, the study grapples with reducing carbon dioxide (CO2) emissions in challenging sectors, such as shipping, aviation and heavy industry. Addressing such challenges soon will be crucial to achieve net-zero emissions in the second half of the century.

Chapter  1  provides  an  overview  of  IRENA's  Renewable  Energy  Roadmap  (REmap) energy transformation analysis,  highlighting  key  technology  solutions  and  a  vision for a global energy pathway to 2050. Chapter 2 highlights the global socio-economic implications of the energy transformation using the indicators GDP, employment and welfare.  Chapter  3  outlines  regional  techno-economic  transformation  pathways  to 2050, while Chapter 4 describes regional variations in the socio-economic indicators. Chapter  5  explains  how  to  reduce  energy  and  industrial  process-related  CO2 emissions to zero and offers solutions for challenging sectors. Chapter 6 discusses the  comprehensive  policy  package,  massive  resource  mobilisation  and  enhanced international co-operation needed to accelerate the transformative decarbonisation for  a  sustainable  society  and  to  ensure  a  just  transition.  In  addition,  key  data  and indicators for 10 regions are provided at the end of the report.

## CENARIOS AND PERSPECTIVES IN THIS OUTLOOK S

This outlook report presents several scenarios and their socio-economic outcomes:

The 'Planned Energy Scenario (PES)' is  the  primary  reference  case  for  this study,  providing  a  perspective  on  energy  system  developments  based  on governments' current energy plans and other planned targets and policies (as of 2019), including Nationally Determined Contributions under the Paris Agreement unless the country has more recent climate and energy targets or plans.

The 'Transforming Energy Scenario (TES)' describes an ambitious, yet realistic, energy transformation pathway based largely on renewable energy sources and steadily  improved  energy  efficiency  (though  not  limited  exclusively  to  these technologies). This would set the energy system on the path needed to keep the rise in global temperatures to well below 2 degree Celsius (°C) and towards 1.5°C during this century.

The 'Deeper Decarbonisation Perspective (DDP)' provides views on additional options to further reduce energy-related and industrial process CO2 emissions beyond the Transforming Energy Scenario. It suggests possibilities for accelerated action in specific areas to reduce energy and process-related CO2 emissions to zero in 2050-2060.

The 'Baseline  Energy  Scenario  (BES)' reflects  policies  that  were  in  place around the time of the Paris Agreement in 2015, adding a recent historical view on energy developments where needed.

The socio-economic analysis of  these  scenarios is  carried out with a macroeconometric  model  (via  E3ME  model)  that  links  the  energy  system  and  the world's  economies  within  a  single  and  consistent  quantitative  framework. It  analyses  the  impact  of  the  energy  transition  on  variables  such  as  GDP, employment and welfare to inform energy system planning, economic policy making, and other measures undertaken to ensure a just and inclusive energy transition at the global, regional and national level.

These various possible paths for energy investment and broader socio-economic development are explored over the crucial three-decade time frame remaining until  mid-century.  This  report  considers  policy  targets  and  developments  until April 2019. Policy changes and targets announced since then are not considered in the present analysis.

The  report  builds  on  IRENA's  REmap  (Renewable  Energy  Roadmap)  approach, which has formed the basis for a succession of global regional, country-level and sector-specific  analyses  since  2014  as  well  as  IRENA's  socio-economic  analysis that captures an increasingly comprehensive picture of the impact of the energy transition on economies and societies.

<!-- image -->

## GLOBAL RENEWABLES OUTLOOK EDITION: 2020

- · The  health,  humanitarian,  social  and  economic  crises  set  off  by  the  COVID-19 pandemic requires a decisive, large-scale response guided by appropriate social and economic measures. As countries consider their economic stimulus options, they must still confront the challenge of ensuring sustainability and strengthening resilience  while  improving  people's  health  and  welfare.  The  need  remains  for  an accelerated path to meet global climate goals through the decarbonisation of our societies.
- · The  Transforming  Energy  Scenario  outlined  here  -  coupled  with  an  additional Deeper Decarbonisation Perspective - offers a sustainable, low-carbon climatesafe foundation for stable, long-term economic development. It  promises more jobs, higher economic growth, cleaner living conditions and significantly improved welfare. This ambitious outlook would also cut 70% of the world's energy-related carbon  dioxide  (CO2)  emissions  by  2050.  Over  90%  of  this  reduction  would  be achieved through renewables and energy efficiency measures.
- · The energy transition can drive broad socio-economic development, guided by comprehensive policies to foster the transformative decarbonisation of societies. This holistic approach would align energy decarbonisation with economic, environmental  and  social  goals.  The  proposed  European  Green  Deal  -  including international support for clean energy - provides an example. Economic stimuli after the 2020 health crisis could move many societies in a similar direction.
- · The ultimate global climate goal would be to reach zero emissions. This outlook also explores ways to cut CO2 emissions beyond 2050 to net-zero and potentially even zero. Hydrogen and synthetic fuels, direct electrification, advanced biofuels and  carbon  management  will  be  crucial,  along  with  innovative  business  models, structural changes and behavioural adaptation.
- · Still, the last portion of the world's CO2 emissions will be the hardest and most expensive  to  eliminate. An  ambitious  energy  transition  would  still  leave  global emissions at about one-third of their current levels, with energy-intensive industries, shipping  and  aviation  still  emitting  heavily  in  2050.  The  Deeper  Decarbonisation Perspective highlights options to get such sectors to zero. While much remains to be seen, an estimated 60% of the reductions in this final stretch could come from renewables, 'green hydrogen' and renewable-based electrification.

## Low-carbon investment options

- · Energy-related CO2 emissions have risen by 1% per year over the past decade. While the health shock and oil slump may suppress emissions in 2020, a rebound would restore the long-term trend.
- · The Transforming Energy Scenario instead offers a climate-safe path, sufficient to  keep  global  warming  this  century  'well  below  2°C'  in  line  with  the  Paris Agreement. It could also help to guide continual updates of national climate pledges, which can be strengthened with enhanced renewable energy targets.
- · This outlook for the transformation of the energy system also indicates higher GDP  growth,  achieving  2.4%  more  by  mid-century  than  current  plans  would achieve. The cumulative gain between now and 2050 amounts to USD 98 trillion, greatly exceeding the additional investments needed for transforming the energy system.
- · The envisaged transformation would effectively pay for itself, with every dollar spent bringing returns between three and eight dollars. The Transforming Energy Scenario would cost USD 19 trillion more than the Planned Energy Scenario, while bringing benefits worth at least USD 50 trillion by 2050. The Deeper Decarbonisation Perspective  would  cost  another  USD  16  trillion  to  achieve  net-zero  emissions,  or another USD 26 trillion to fully eliminate CO2 emissions, for a total cost of USD 45 trillion, yet cumulative savings would still be higher at USD 62 trillion or more.
- · Along  with  a  sustainable  energy  future,  the  transition  promises  new  patterns of socio-economic development. The  changing  investment focus in this outlook would increase jobs in renewables to 42 million globally by 2050, four times more than today. Energy jobs overall would reach 100 million by 2050, about 40 million more than today. The transition would result in 7 million more jobs economy-wide compared to current plans. Environmental and health benefits, along with broad improvements in people's welfare, would be felt in every region of the world.
- · People's well-being would improve faster and further, with a 13.5% higher welfare indicator  under  the  Transforming  Energy  Scenario  by  2050. The  divergence mainly  reflects  of  lower  air  pollution,  which  would  result  in  better  health  across every region. Everywhere, the transition promises to improve people's welfare.

## Co-ordination for a smooth transition

- · Ramping up regional ambitions will be crucial to meet interlinked energy and climate goals. Renewables, efficiency and electrification provide a clear focus for action to cut the bulk of emissions at the regional and country levels. Despite varied transition paths, all regions would see higher shares of renewable energy use, with Southeast Asia, Latin America, the European Union and Sub-Saharan Africa poised to reach 70-80% shares in their total energy mixes by 2050. Similarity, electrification of end uses like heat and transport would rise everywhere, exceeding 50% in East Asia, North America and much of Europe.
- · Despite clear global gains, the transition's structural and labour-market impacts will vary among locations, job types and sectors. As renewables, energy efficiency and other transition-related sectors grow, other energy jobs will decline. But  strategies  to  ensure  a  just  transition  could  help  to  minimise  dislocations  for individuals and communities.
- · Different  socio-economic  starting  points  will  contribute  to  different  regional energy transitions. On-the-ground impact will stem from dependence on fossil fuels and  other  commodities,  pre-existing  industrial  productivity,  evolving  technology choices,  and  the  depth  and  diversity  of  domestic  supply  chains.  Regional  and national transition plans, institutional structures, capabilities and policy ambitions also vary, bringing different results in 2050.
- · Rapid decarbonisation calls for unprecedented policy initiatives and investments. The  Climate  Investment  Platform  announced  in  2019  aims  to  drive  clean  energy uptake  in  line  with  Paris  Agreement  goals.  Sub-regional  investment  forums  will help to create the right conditions, improve access to finance and prepare bankable projects.
- · Completing the global energy transition in time to stave off catastrophic climate change  requires  intensified  international  co-operation. The  aim  is  to  enable governments and other institutions to adopt a wide array of ambitious policies, all aimed at strengthening public resolve and ensuring that no one is left behind.
- · Ultimately, success in mitigating the climate threat will depend on the policies adopted, the speed of their implementation and the level of resources committed. Moving forward, investment decisions could be assessed based on their compatibility with  building  an  inclusive  low-carbon  economy.  Anything  less  would  hinder  the transformative decarbonisation of societies.

<!-- image -->

<!-- image -->

## A WIDENING GAP BETWEEN RHETORIC AND ACTION

The gap between aspiration and the reality in tackling climate change remains as significant as ever, despite mounting evidence of the harm that climate change is causing. Negative effects of climate change are becoming more evident year by year (NASA, WMO, 2020). Yet global energy-related CO2 emissions, despite levelling off periodically, have risen by 1% per year on average over the last decade.

The distribution of efforts among countries remains uneven, with certain countries pursuing net-zero emissions while others continue to lack policy targets. Government  plans  have  yet  to  fully  capture  the  reality  of  the  markets.  Nationally Determined  Contributions  (NDCs)  within  the  Paris  Agreement  framework  are  in many cases less ambitious than the latest energy plans and market developments. According to  IRENA  estimates,  current  NDC  power  targets  only  cover  40%  of  the renewable electricity deployment needed by 2030 to set the world on course to meet key climate goals (IRENA, 2019b).

The  health,  humanitarian,  social  and  economic  crises  set  off  by  the  current COVID-19 pandemic could either widen the gap or accelerate the decarbonisation of our societies. Much will depend on how countries respond in terms of economic stimulus.  The  challenges  of  ensuring  sustainability,  strengthening  resilience  and improving people's health and welfare will be paramount. The Transforming Energy Scenario (TES) identified in this report shows how to achieve stable, climate-safe, sustainable  long-term  energy  and  economic  development.  The  resulting  outlook  further enhanced by the Deeper Decarbonisation Perspective (DDP) - could guide low-carbon  policy  measures,  helping  to  ensure  coherence  between  rhetoric  and action in tackling climate change.

This report presents several possible scenarios for the evolution of energy-related CO2  emissions. In  the  Baseline  Energy  Scenario  (BES),  energy-related  emissions increase by a compound annual rate of 0.7% per year to 43 gigatonnes (Gt) by 2050 (up from 34 Gt in 2019), resulting in a likely temperature rise of 3°C or more in the second half of this century. The Planned Energy Scenario (PES), or main reference case,  sees  emissions  increase  slightly  by  2030  and  then  decline  to  33  Gt,  roughly today's level, by 2050. This would result in a likely global temperature rise of 2.5°C in the second half of this century. IRENA's Transforming Energy Scenario , in contrast, sees emissions fall at a compound rate of 3.8% per year to some 10 Gt, or 70% less than today's level, by 2050, keeping the expected temperature rise well below 2°C.

Main report Chapters 1 and 5

The Deeper Decarbonisation Perspective would reduce emissions to zero by as early as 2050 or latest by 2060, consistent with holding the line at 1.5°C.

Recent energy trends confirm the need to accelerate a reduction in CO2 emissions. Renewable energy forms a key part of any viable solution. Renewable energy shares, the energy intensity of GDP and the electrification of final uses of energy have all shown improvements in recent years, yet the pace of those improvements does not put the world on track to meet the goals of the Paris Agreement. Efforts are also needed to reduce emissions outside the energy sector.

Fossil fuels continue producing negative effects in many parts of the world. These include  high  levels  of  air,  water  and  soil  pollution,  and  persistent  energy-import dependence.  Currently,  air  pollution  causes  7  million  premature  deaths  per  year (WHO, 2020). With an estimated 840 million people still lacking access to electricity and 2.6 billion lacking access to clean cooking fuels, the world has a pressing need for  clean,  sustainable energy solutions. For now, some regions are increasing their dependency on energy imports (IEA, IRENA, UNSD, World Bank, WHO, 2019).

The Transforming Energy Scenario would cut fossil-fuel use by about 75% by midcentury. Looking ahead under the Planned Energy Scenario, primary energy demand increases from around 600 exajoules (EJ) today to 710 EJ by 2050 (see Figure S.1), yet the amount of fossil fuels remains roughly similar to today's level, showing the increasing role renewable energy plays. However, given the need to reduce emissions, fossil-fuel  consumption  cannot  stay  at  today's  level.  In  the  Transforming  Energy Scenario it declines by 75% compared to today's level, to 130 EJ by 2050 - roughly equivalent to just the energy demand of China today. The largest consumption declines would take place in coal, down by 41% and 87% in 2030 and 2050, respectively. Oil would see the second largest declines, of 31% and 70% in 2030 and 2050, respectively. Natural gas would have an increase of 3% by 2030 (the Planned Energy Scenario has natural gas growth of over 40% by 2030), but it would decline 41% by 2050.

<!-- image -->

Figure S.1.     The changing nature of energy and fossil-fuel use

Energy-related CO2 emissions, energy demand and fossil-fuel outlook

<!-- image -->

| Indicator                          | Historical progress 2015-2018/2019   | Where we are heading ( • PES/2030 and 2050)   | Where we are heading ( • PES/2030 and 2050)   | Where we need to be ( • TES/2030 and 2050)   | Where we need to be ( • TES/2030 and 2050)   |
|------------------------------------|--------------------------------------|-----------------------------------------------|-----------------------------------------------|----------------------------------------------|----------------------------------------------|
| Energy-related CO 2 emissions (Gt) | 32 Gt 34 Gt 2015 2019e               | 35 Gt 2030                                    | 33 Gt 2050                                    | 25 Gt 2030                                   | 9.5 Gt 2050                                  |
| Energy demand (EJ TPES)            | 571 EJ 599 EJ 2015 2018              | 647 EJ                                        | 710 EJ                                        | 556 EJ 2030                                  | 538 EJ 2050                                  |
| Fossil-fuel use (EJ TPES)          | 2015 2018 468 EJ 485 EJ              | 2030 450 EJ                                   | 2050 440 EJ                                   | 313 EJ 2030                                  | 130 EJ 2050                                  |
| Change in fossil-fuel demand       | Change in fossil-fuel demand         | - 10 % - 28 %                                 | +41 % +53 % 0 % +2 %                          | Gas Coal +3 % - 41 % - - 87 %                | Oil - 70 - 31 %                              |
|                                    |                                      | 2030 2050 2030 Coal                           | 2050 2030 2050 Gas Oil                        | 2030 2050 2030 2050 41                       | 2030 2050 %                                  |

Note: TPES = total primary energy supply. e = estimate; Gt = gigatonnes; EJ = exajoules.

Based on IRENA scenarios (PES and TES), along with IEA (2019a, 2019b) for 2015-2018 historical progress of energy demand and fossil-fuel use.

<!-- image -->

Main report

Chapters

1 and 5

## TRANSFORMATIVE ENERGY DEVELOPMENTS

The energy sector has started changing in promising ways, with widespread adoption of renewables and related technologies boding well for a sustainable future. Renewable technologies are dominating the global market for new power generation capacity. Solar PV and wind are increasingly the cheapest source of electricity in many markets, and most renewable power sources will be fully cost competitive within the next decade (IRENA, 2019c).

Renewable power generation is now growing faster than overall power demand. A new milestone was reached in 2019 when renewable electricity generation increased by more than the increase in electricity demand, while fossil-fuel electricity generation decreased. This is the first time in decades that fossil-fuel-based generation declined when overall electricity generation increased (Kåberger, 2019).

The electrification of transport is showing early signs of disruptive acceleration. Progress in accelerating the transition is seen in the rapid cost reductions of solar PV and wind (including offshore), how key enabling technologies such as batteries and electric vehicles are experiencing rapid reductions in costs, and how green hydrogen is viewed as a potential game changer.

Yet  renewables  are  growing  too  slowly  in  major  energy-consuming  sectors  like buildings  and  industry. Deployment  in  these  areas  remains  well  below  the  levels needed to create a climate-safe energy system. Slowing progress in energy efficiency and biofuels development must be turned around quickly.

The  share  of  modern  renewable  energy  in  global  final  energy  consumption  has increased only slightly since 2010, staying around a threshold of about 10%. 1 In simple terms, while renewables are increasing, so is energy demand. In the Planned Energy Scenario, the share of modern renewable energy in final energy supply would increase to 17% by 2030 and 25% by 2050. In the Transforming Energy Scenario, this share would increase to 28% by 2030 and 66% by 2050. Therefore, the share would need to increase six-fold compared to today, and two-and-a-half times compared to the Planned Energy Scenario.

<!-- image -->

Energy  efficiency  improvements  must  be  scaled  up  rapidly  and  substantially. Energy  efficiency  and  renewable  energy  are  the  two  key  solutions  to  enable  the global energy transformation. Yet the improvement in energy intensity has slowed. The improvement in 2019 was only an estimated 1.2%, less than the average of 1.8% per year over the last decade (IEA, 2019a). In the Transforming Energy Scenario, the rate of energy intensity improvement needs to increase to 3.2% per year, nearly three times the improvement during 2019 and roughly double compared to recent historical trends. Renewable energy and energy efficiency are 'ready-to-go' solutions, available for significant scale-up now.

Renewable energy and energy efficiency together offer over 90% of the mitigation measures needed to reduce energy-related emissions in the Transforming Energy Scenario. To  achieve  this  reduction  energy-related  CO2  emissions  need  to  fall  by 3.8%  per  year  on  average  until  2050,  to  70%  below  today's  level.  That  compares to an average annual increase of 1% over the last decade, with a flatlining in 2019. Figure S.2 shows the share of renewable energy and the energy efficiency improvement rate that is needed to achieve the necessary reductions.

Figure S.2.     Renewables in the world's energy mix: Six-fold increase needed

Renewable energy share and energy efficiency improvement rate

<!-- image -->

| Indicator                                | Historical progress 2015-2018   | Where we are heading ( • PES / 2030 and 2050)   | Where we need to be ( • TES / 2030 and 2050)   |
|------------------------------------------|---------------------------------|-------------------------------------------------|------------------------------------------------|
| energy in TFEC                           | 9.5 % 10.5 % 2015 2018          | 17 % 25 % 2030 2050                             | 28 % 66 % 2030 2050                            |
| Energy intensity improvement rate (%/yr) | 1.8 % 2015-2018                 | 2.4 % 2.6 % 2030 2050                           | 3.2 3.6 % 2030 2050                            |

Based on IRENA scenarios (PES and TES), along with IEA (2019a, 2019b) for 2015-2018 historical progress of energy share in total final energy consumption (TFEC).

<!-- image -->

## Five technology pillars for the future of energy

## FIRST PILLAR: ELECTRIFICATION

Renewable power generation technologies are setting records for low costs and new capacity despite falling renewable energy subsidies and slowing global GDP growth. In the Transforming Energy Scenario, electricity would become the central energy carrier by 2050, growing from a 20% share of final consumption to an almost 50% share; as a result, gross electricity consumption would more than double.

<!-- image -->

The  rate  of  growth  in  the  percentage  share  of  electricity  (percentage  point 'ppt')  in  final  energy  needs  to  quadruple,  from  an  increase  of  0.25  ppt/yr  to 1.0  ppt/yr. To  put  this  into  perspective,  an  additional  1 000  terawatt-hours  (TWh)  of electricity demand for electrification of end uses has to be added every year on top of current plans - equivalent to adding the entire electricity generation of Japan every year. To supply this additional renewable electricity demand, over 520 gigawatts (GW) of new renewable capacity would need to be added per year. In parallel, the share of renewable electricity in generation has to rise from 26% currently to 57% by 2030 and 86% by 2050. This rise is being accelerated by declining costs: four-fifths of solar PV and wind projects to be commissioned in 2020 will produce electricity cheaper than any fossil-fuel alternative (IRENA, 2019c).

The electrification of end uses will drive increased power demand to be met with renewables. In the transport sector, the number of electric vehicles (EVs) will increase from around 8 million in 2019 to over 1 100 million in the Transforming Energy Scenario by 2050 (see Figure S.3). For heating, heat pumps offer efficiency gains ranging from two to four times higher than conventional heating systems, and the number of heat pumps installed by 2050 would need to increase 10-fold. The shift to these highly efficient electrification technologies also brings increases in energy efficiency.

<!-- image -->

Figure S.3.     An increasingly electrified energy system

Renewable electricity share in electricity generation, electrification share, and select technologies

01

<!-- image -->

<!-- image -->

| Indicator                   | Historical progress 2015-2018/2019   | Where we are heading ( • PES/2030 and 2050)   |              | Where we need to be ( • TES/2030 and 2050)   |               |
|-----------------------------|--------------------------------------|-----------------------------------------------|--------------|----------------------------------------------|---------------|
| Renewable share electricity | 23 % 26 % 2015 2018                  | 38 % 2030                                     | 55 % 2050    | 57 % 2030                                    | 86 % 2050     |
| share final                 | 19 % 20 % 2015 2017                  | 24 % 2030                                     | 30 % 2050    | 29 % 2030                                    | 49 % 2050     |
| Technologies                |                                      |                                               |              |                                              |               |
| Electric                    | 7.9 mln 1.2 mln 2015 2019e           | 269 mln 2030                                  | 627 mln 2050 | 379 mln 2030                                 | 1109 mln 2050 |
| Heat pumps (mln units)      | 38 mln 20 mln 2017 2019e             | 63 mln 2030                                   | 119 mln 2050 | 155 mln 2030                                 | 334 mln 2050  |

Based on IRENA scenarios (PES and TES), along with Spiegel (2020), IEA (2019a, 2019b), IEA and IRENA (2017) and IRENA (2019a) for 2015-2018 historical progress.

<!-- image -->

<!-- image -->

## SECOND PILLAR:

## INCREASED POWER SYSTEM FLEXIBILITY

<!-- image -->

Flexibility in power systems is a key enabler for the integration of high shares of variable renewable electricity - the backbone of the electricity system of the future. A climate-friendly energy system is decentralised, digitalised and electrified. Today, countries are integrating variable renewable energy (VRE) at a share of over 30% on an annual basis (and in some cases much higher), which means that instantaneous penetration of VRE can, at times, approach, or even exceed, electricity demand. These periods of electricity surpluses can then offer new business opportunities for further electrification. In the Transforming Energy Scenario, 73% of the installed capacity and over 60% of all power generation would come from variable resources (solar PV and wind), up from 10% of power generation today.

Power systems must achieve maximum flexibility, based on current and ongoing innovations in enabling technologies, business models, market design and system operation. On  a  technology  level,  both  long-term  and  short-term  storage  will  be important for adding flexibility, and the amount of stationary storage (which excludes EVs)  would  need  to  expand  from  around  30  gigawatt-hours  (GWh)  today  to  over 9 000 GWh by 2050 (see Figure S.4). When storage available to the grid from the EV fleet  is  included,  this  value  will  increase  by  over  14 000  GWh  to  23 000  GWh. However, most flexibility will still be achieved through other measures, including grid expansion  and  operational  measures,  demand-side  flexibility  and  sector  coupling. IRENA estimates that smart solutions, such as smart charging of EVs, can significantly facilitate  the  integration  of  VRE  by  leveraging  storage  capacity  and  the  flexibility potential of the demand side. Investment in end-use electrification, power grids and flexibility will need to increase from USD 13 trillion in the Planned Energy Scenario to USD 26 trillion in the Transforming Energy Scenario over the period to 2050.

<!-- image -->

<!-- image -->

| Figure S.4. The need for power system flexibility VRE share in generation and capacity, storage technologies 02   | Figure S.4. The need for power system flexibility VRE share in generation and capacity, storage technologies 02   | Figure S.4. The need for power system flexibility VRE share in generation and capacity, storage technologies 02   | Figure S.4. The need for power system flexibility VRE share in generation and capacity, storage technologies 02   | Figure S.4. The need for power system flexibility VRE share in generation and capacity, storage technologies 02   |
|-------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------|
| Indicator                                                                                                         | Historical progress 2015-2018/2019                                                                                | Where we are heading ( • PES/2030 and 2050)                                                                       | Where we are heading ( • PES/2030 and 2050)                                                                       | Where we need to be ( • TES/2030 and 2050)                                                                        |
| in (%)                                                                                                            | generation 4.5 % 10 % 2015 2018                                                                                   | 19 % 2030                                                                                                         | 36 % 2050                                                                                                         | 35 % 61 % 2030                                                                                                    |
| GWof (GW)                                                                                                         | Solar Wind 2015 2019e 222 GW 582 GW 416 GW 624 GW                                                                 | 2030 2037 GW 1455 GW                                                                                              | 2050 4474 GW 2434 GW                                                                                              | 8828 GW 2030 2050 3227 GW 6044 GW                                                                                 |
| Enabling Technologies                                                                                             | Enabling Technologies                                                                                             |                                                                                                                   |                                                                                                                   |                                                                                                                   |
| Storage                                                                                                           | 30 GWh 2019e                                                                                                      | 370 GWh 2030                                                                                                      | 3400 GWh 2050                                                                                                     | 9000 GWh 745 GWh 2050                                                                                             |
|                                                                                                                   | 200 GWh 2019e                                                                                                     | 3294 GWh 2030                                                                                                     | 7546 GWh 2050                                                                                                     | 14145 GWh 5056 GWh 2050                                                                                           |

Based on IRENA scenarios (PES and TES), along with Bohlsen (2020), GWEC (2020), IEA (2019a) and IRENA analysis and IRENA (2019d, 2019f) for 2015-2018 historical progress.

<!-- image -->

<!-- image -->

## THIRD PILLAR:

## CONVENTIONAL RENEWABLE SOURCES

Hydropower,  bioenergy,  solar  thermal  and  geothermal  renewable  energy  all  have significant  scale-up  potential  and  represent  over  one-quarter  of  the  mitigation potential  in  the  Transforming  Energy  Scenario.  Two  technologies  that  can  play particularly important roles are hydropower and bioenergy.

Hydropower can bring important synergies to the energy system of the future. In the Transforming Energy Scenario, hydropower capacity would need to increase 25% by 2030, and 60% by 2050, while pumped hydro storage capacity would need to double. When including both types of hydropower, around 850 GW of newly installed capacity is required in the next 30 years - or roughly adding the entire power system capacity  of  the  European  Union  in  2020.  The  synergies  between  hydropower  and other  renewable  energy  technologies  in  power  system  operation  include  the  cost effectiveness of using hydropower to counteract the short-term variability of wind and  solar  generation,  and  seasonal  complementarities  in  resource  patterns.  Multipurpose hydropower infrastructure also can provide co-benefits such as regulating river flows and reducing flooding.

Increasing hydropower capacity does not specifically entail only building new dams: options also exist to upgrade turbines and systems in existing plants, utilise run-of-river designs and electrify non-power dams. Yet for new hydropower plants, planners need to consider local environmental impacts, and engage in discussions with communities in  the  impacted  areas.  Hydropower plants will  also  need  operational  changes  that reflect changing power system needs, including faster and more frequent ramping, and planning practices that include evaluating the impacts of climate change on water supply and reservoir storage requirements. Due to longer planning cycles for new hydropower dam construction, policy makers and planners need to start thinking now about  new  projects.  For  existing  dams,  investments  are  needed  to  modernise  old hydro plants.

Bioenergy will become increasingly vital in end-use sectors. Bioenergy makes up a large share of renewable energy use today and will remain a significant source of fuel for power and heat generation in industry and as a fuel used in transport. The share of primary energy that is met with modern bioenergy (which excludes traditional uses of  biofuel)  will  increase  from  5%  today  to  10%  in  the  Planned  Energy  Scenario.  In the  Transforming  Energy  Scenario,  bioenergy  plays  an  important  role,  particularly in sectors that are hard to electrify, such as in shipping and aviation and in industry, both for process heat and use as a feedstock. In the Transforming Energy Scenario, the share of primary energy met with modern bioenergy increases to 23% (see Figure S.5). Meanwhile, traditional uses of bioenergy, which cover a large share of bioenergy demand  today,  must  be  phased  out  and  replaced  with  cleaner  options,  including modern bioenergy and other renewables.

Bioenergy  must  be  produced  in  ways  that  are  environmentally,  socially  and economically  sustainable.  The  potential  is  enormous  to  produce  bioenergy  cost effectively and sustainably on existing farmlands and grasslands, and to use residues from  existing  production  forests  without  encroaching  upon  rainforests.  Bioenergy from such sources would make use of surplus crop potential and not threaten food production (IRENA, 2016a).

Figure S.5.     Vital to any future energy system: Hydropower and bioenergy

03

Hydropower capacity, bioenergy shares, and liquid biofuel production

<!-- image -->

| Indicator                              | Historical progress 2015-2017/2018/2019   | Where we are heading ( • PES/2030 and 2050)   |                  | Where we need ( • TES/2030 and   | to be 2050)      |
|----------------------------------------|-------------------------------------------|-----------------------------------------------|------------------|----------------------------------|------------------|
| (GW)                                   | Hydropower 1099 GW 1189 GW 2015 2019      | 1356 GW 2030                                  | 1626 GW 2050     | 1444 GW 2030                     | 1822 GW 2050     |
| Pumped hydro storage (GW)              | 112 GW 121 GW 2015 2019                   | 200 GW 2030                                   | 300 GW 2050      | 225 GW 2030                      | 325 GW 2050      |
| provided bioenergy                     | by 8.7 % 9.5 % 2015 2018                  | 9 % 2030                                      | 10 % 2050        | 12 % 2030                        | 23 % 2050        |
| Share of provided bioenergy            | TPES by 4.1 % 5.1 % 2015 2018             | 8 % 2030                                      | 10 % 2050        | 12 % 2030                        | 23 % 2050        |
| Liquid biofuel production (bln litres) | 129 bln ltr 136 bln ltr 2015              | 285 bln ltr 2030                              | 393 bln ltr 2050 | 378 bln ltr 2030                 | 2050 652 bln ltr |

Based on IRENA scenarios (PES and TES), along with Bohlsen (2020), IEA (2019s), IRENA (2019d, 2019e, 2019f) and IRENA analysis for 2015-2018 historical progress.

Note: The total bioenergy share includes traditional uses of biofuels. In PES their use is reduced considerably by 2030, but not entirely phased out, whereas in PES their use is entirely phased out by 2030. TPES = total primary energy supply

<!-- image -->

<!-- image -->

## FOURTH PILLAR: GREEN HYDROGEN

Hydrogen can offer a solution for types of energy demand that are hard to directly electrify. Today,  around  120  megatonnes  (Mt)  (14  EJ)  of  hydrogen  is  produced  per year (IRENA, 2019g). But almost all of this comes from fossil fuels or from electricity generated  by  fossil  fuels,  with  a  high  carbon  footprint;  less  than  1%  is  'green' hydrogen. Yet progress is being made and in early 2020 the world's largest green hydrogen  production  plant  with  10  MW  electrolyser  capacity  began  operation  in Japan (Recharge, 2020).

<!-- image -->

Green hydrogen is produced by renewable electricity through electrolysis, and costs are falling fast. Green hydrogen will become cost competitive with 'blue' hydrogen (produced from fossil fuels combined with carbon capture and storage [CCS]) in the next few years in locations with favourable low-cost renewable electricity. As costs fall  further,  green  hydrogen will  be  cheaper than blue hydrogen in many locations within the next 5 to 15 years. Certain energy-intensive industries may in the future relocate  to  areas  with  good  renewable  energy  resources  to  tap  this  potential  to produce  cheap  green  hydrogen;  examples  include  iron  making  and  ammonia.  The first  plant  producing  ammonia  from  green  hydrogen  is  expected  to  open  in  2020 (Yara, 2019).

Hydrogen  can  be  processed  further  into  hydrocarbons  or  ammonia,  which  can then help reduce emissions in shipping and aviation. The  natural  gas  industry  is also looking at hydrogen as a promising solution for greening the gas system and extending the life of existing infrastructure. However, this approach must be viewed with caution in light of unclear prospects of actually being able to significantly reduce emissions of the gas system and the potential to lock in carbon-intensive infrastructure. A  hydrogen  commodity  trade  is  nascent,  but  hydrogen  could  become  the  clean energy vector that makes it possible to tap into ample remote, low-cost renewable energy resources - a development that could have important geopolitical implications as  well  as  further  accelerating  the  demand  for  renewable  power  generation.  By 2050, there would be 160 Mt (19 EJ) of green hydrogen produced annually in the Transforming Energy Scenario (see Figure S.6). That amount, however, would only cover 5% of global energy demand today, with an additional 2.5% being met with blue hydrogen. Significant scale-up of electrolysers is necessary to produce that amount, requiring additions of between 50 GW and 60 GW per year of new capacity from now until 2050.

<!-- image -->

Figure S.6.     Hydrogen: A key part of future energy systems

Evolving hydrogen production, costs and electrolyser capacity

04

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Indicator   |                                                        | Historical progress 2015-2018   | Where we are heading ( • PES / 2030 and 2050)   | Where we are heading ( • PES / 2030 and 2050)   | Where we need to be ( • TES / 2030 and 2050)   | Where we need to be ( • TES / 2030 and 2050)   |
|-------------|--------------------------------------------------------|---------------------------------|-------------------------------------------------|-------------------------------------------------|------------------------------------------------|------------------------------------------------|
|             | Blue H 2 (Mt and EJ)                                   | 0.6 Mt / 0.08 EJ 2015 - 2018    | 10 Mt 1.25 EJ 2030                              | 40 Mt / 5 EJ 2050                               | 30 Mt 3.75 EJ 2030                             | 80 Mt / 10 EJ 2050                             |
|             | Green H 2 (Mt and EJ)                                  | 1.2 Mt / 0.16 EJ 2015 - 2018    | 9 Mt 1.1 EJ 2030                                | 25 Mt / 3 EJ 2050                               | 25 Mt / 3 EJ 2030                              | 160 Mt / 19 EJ 2050                            |
|             | Green H 2 production costs (USD/kg)                    | 4.0 - 8.0 USD/kg 2015 - 2018    | 2.5 - 5.0 USD/kg 2030                           | 2050 1.6 - 3.3 USD/kg                           | 1.8 - 3.2 USD/kg 2030                          | 2050 0.9 - 2.0 USD/kg                          |
|             | Electrolysers (GW)                                     | 2016 0.04 GW                    | 100 GW 2030                                     | 270 GW 2050                                     | 270 GW 2030                                    | 2050 1700 GW                                   |
|             | Electricity demand to produce H 2 from renewables (GW) | 2016 0.26 TWh                   | 450 TWh 2030                                    | 1200 TWh 2050                                   | 1200 TWh 2030                                  | 2050 7500 TWh                                  |

Based on IRENA analysis

Note: Hydrogen produced from fossil fuels without CCS is called grey hydrogen, with CCS is called blue hydrogen, and if made from renewable power through electrolysis it is called green hydrogen. RE = Renewable Energy

<!-- image -->

## FIFTH PILLAR:

## FOSTER INNOVATION TO ADDRESS CHALLENGING SECTORS

In the Transforming Energy Scenario, half of energy demand could be supplied by electricity by 2050, but the remaining half must also be considered. Of this, onethird  is  already  supplied  by  end-use  renewable sources, with the remaining twothirds by fossil fuels. Solutions to further reduce fossil-fuel use include increased direct use of renewable energy (bioenergy, solar thermal, geothermal heat), energy efficiency  and  structural  changes  that  can  reduce  energy  demand,  and  deeper electrification. However, more will still be needed, in particular for sectors such as shipping,  aviation  and  heavy  industry.  To  put  it  in  perspective,  three-quarters  of the remaining emissions in the Transforming Energy Scenario in 2050 are from the aviation, shipping and heavy industry sectors.

<!-- image -->

This report presents views on how reduce these remaining emissions in the Deeper Decarbonisation  Perspective  (DDP). The  Deeper  Decarbonisation  Perspective  is not a scenario in itself, rather it is an enhancement of additional technology options on top of the Transforming Energy Scenario. In challenging sectors such as freight, shipping,  aviation  and  heavy  industry,  advances  in  biofuels,  synthetic  fuels,  new materials  and  the  circular  economy  will  all  be  necessary.  Industry  is  the  dominant energy  consumption  sector  in  many  countries  such  as  China,  where  the  sector consumes around half of final energy. There is an urgent need to find solutions for key sectors, such as iron and steel, cement and petrochemicals, which make up the bulk of industry energy demand. Innovation is also needed to find zero CO2 emission solutions for industrial process emissions and for non-energy uses in these sectors. Innovation will also continue to be crucial to address transport modes that are hard to electrify, namely aviation and shipping.

The  Deeper  Decarbonisation  Perspective  shows  how  the  remaining  energy  and industrial process-related CO2 emissions in the Transforming Energy Scenario can be  cut  to  zero.  Renewable  energy  provides  60%  of  the  reduction  needed  when including  renewables,  green  hydrogen and renewables-based electrification; 37% of  reductions  come  from  energy  efficiency  and  other  structural  and  behavioral changes; and the remaining 3% of reductions come from carbon capture, utilisation and storage (CCUS) and nuclear. Overall, when considering reductions in energy and industrial process-related CO2 emissions from the Baseline Energy Scenario to zero, renewables make up 43% of the reductions, energy efficiency 26%, EVs 12%, green  hydrogen  9%,  blue  hydrogen  and  CCS/Carbon  dioxide  removal  (CDR)  7%, behavioural changes 2%, and nuclear under 1% (EVs and behavioural changes could also be considered as part of energy efficiency, or for the case of EVs, renewables if powered by renewable electricity. However, to show their relative importance they are shown separately).

<!-- image -->

## PLANNING FOR THE LONG TERM

To achieve the Energy Transformation Scenario, energy-related CO2 emissions need to fall by 3.8% per year on average until 2050. Annual energy-related CO2 emissions would need to decline by 70% below today's level by 2050. In the Transforming Energy  Scenario  by  2050,  over  half  of  the  necessary  reductions  in  emissions come from renewable energy (both power and end use), followed by around onequarter coming from energy efficiency (see Figure S.7). When including direct and indirect electrification (such as green hydrogen and technologies like EVs), the total reductions increase to over 90% of what is required. The Deeper Decarbonisation Perspective then describes how reducing the remaining emissions to zero - over two-thirds of which come from challenging sectors such as aviation, shipping and heavy  industry  -  will  require  additional  renewable  energy,  electrification  (both direct use and green hydrogen), energy efficiency, carbon management, and other structural and habit changes. Outside the energy sector, efforts also are needed to reduce emissions from non-energy use, emissions from land use, land-use change and forestry (LULUCF), and fugitive gases in the coal, oil and gas industries.

Figure S.7.     The bulk of emission reductions: Renewables and efficiency

Energy-related CO2 emissions, 2010-2050

<!-- image -->

Based on IRENA analysis

<!-- image -->

<!-- image -->

<!-- image -->

A  climate-safe  future  calls  for  the  scale-up,  and  redirection,  of  investment  to clean energy technologies. Fossil-fuel investments need to be shifted to renewables and  energy  efficiency  instead,  while  subsidies  to  fossil  fuels  must  be  phased out.  Overall,  total  investment  in  the  energy  system  in  the  Transforming  Energy Scenario would need to reach USD 110 trillion by 2050, or around 2% of average annual GDP over the period (see Figure S.8). Of that total, over 80% needs to be invested in renewables, energy efficiency, end-use electrification, and power grids and flexibility. If  viewed in annual terms, USD 3.2 trillion needs to be invested in the global energy system every year to 2050. That compares to recent historical investment  (2014-2018)  in  the  energy  system  of  around  USD  1.8  trillion  per  year (IEA, 2019c), and USD 2.9 trillion per year in the Planned Energy Scenario.

The Deeper Decarbonisation Perspective would require additional investment of USD 20 trillion over the USD 110 trillion of investments in the Transforming Energy Scenario, for a total investment need of USD 130 trillion to reach zero emissions. To help navigate these new investment 'waters', and to accelerate a shift of finance into climate-friendly technologies, IRENA is working with partners on the Climate Investment  Platform  (CIP)  to  unlock  financial  resources  for  the  clean  energy transition,  particularly  in  developing  countries.  By  addressing  the  key  risks  and barriers that hinder the scale-up of renewable investment, CIP will accelerate the low-carbon energy transition and promote sustainable growth.

Figure S.8.     New investment priorities: Renewables, efficiency and electrification of heat and transport

<!-- image -->

Based on IRENA analysis

The payback for accelerating renewables deployment and efficiency measures is many times larger than the costs. In the Transforming Energy Scenario, every USD  1  spent  for  the  energy  transition  would  bring  a  payback  of  between USD 3 and USD 8 (see Figure S.9). Or to put it in cumulative terms, the Transforming Energy Scenario would have an additional cost of USD 19 trillion over the period to 2050 but would result in a payback of between USD 50 trillion and USD 142 trillion in reduced environmental  and  health  externalities.  The  Deeper  Decarbonisation  Perspective would cost an additional USD 16 trillion to achieve net-zero emissions, or an additional USD 26 trillion to achieve fully zero emissions (with no carbon offsets).

Therefore, the total additional costs to reach zero range from USD  35  to USD  45  trillion. Yet these  higher  costs are still significantly lower  than  the USD 62 to USD 169 trillion in savings from reduced externalities that would result from  reaching  zero  emissions.  Another  way  to  look  at  costs  is  how  much  it  takes to  mitigate  one  tonne  of  CO2  over  the  period.  For  the  Transforming  Energy Scenario, this cost would be USD 34/t CO2. For the DDP net-zero, the cost would be USD 100/t CO2, and for DDP fully zero, it would be USD 156/t CO2.

## Figure S.9.     The energy transition: Benefits compared to costs

Cumulative system costs and savings from reduced externalities for Transforming Energy Scenario for the period to 2050, and DDP for the period to 2060 (USD trillion)

<!-- image -->

Based on IRENA analysis

<!-- image -->

<!-- image -->

Climate change may have significant detrimental and destabilising effects on the world's financial system. Fires,  floods,  drought,  extreme  weather,  rising  seas  and other  impacts  of  climate  change  will  take  an  increasing  economic,  environmental and human toll - which must be borne in the end by taxpayers, governments and communities (IMF, 2019). In addition, the health costs of pollution are increasingly of major concern for many cities, particularly in the developing world. Central banks, financial  institutions  and  insurance  companies  are  starting  to  take  note  and  to incorporate assessments of climate risk into their financial planning. Key institutions that  have  announced  steps  to  incorporate  climate  risk  include  the  International Monetary Fund, Blackrock, Norway's sovereign wealth fund and KfW Group.

Investments that  continue  to  expand  fossil-fuel  supply  infrastructure  are  shortsighted and increasingly risky. Such  investments  will  lead  to  significant  stranded assets and will lock in fossil-fuel  emissions  for  decades  to  come  that  will  also  risk achieving the aims of the Paris Agreement (Tong et al. ,  2019). Recent low oil prices serve as a reminder of the volatility of markets for oil - and other fossil fuels - and of  the  geopolitics  associated  with  our  current  energy  system.  Existing  renewable technologies, energy efficiency and some emerging renewables-based technologies can take the reins instead and supply energy across a wide range of energy services at lower cost than fossil fuels, especially when they are coupled with expensive, and often  unproven,  carbon  removal  or  recycling  technologies.  While  some  action  is necessary  to  explore  opportunities  to  make  existing  fossil-fuel  assets  cleaner  and lower carbon, particularly in sectors such as in industry, where some CCS may be necessary, governments and investors should generally avoid investments into new fossil-fuel supply infrastructure.

Due to the slow progress to date in reducing emissions from the energy sector, already  USD  11.8  trillion  in  assets  will  need  to  be  stranded  by  2050  in  the Transforming Energy Scenario. Moreover, further delaying action for another 10 years would result in an additional USD 7.7 trillion in stranded assets by 2050. Limiting the amount of future stranded assets requires greater attention today on the risks that companies, banks and investors face from climate change and the response to climate change. One effort to make those risks more visible is the Task Force on ClimateRelated Financial Disclosure, which is helping to develop voluntary climate-related financial risk disclosures.

<!-- image -->

Policy makers need to establish long-term integrated energy planning strategies, define  targets,  and  adapt  policies  and  regulations  that  promote  and  shape  a climate-friendly energy system. To capture the overarching impacts of the energy transformation, an integrated energy planning approach is required that combines a holistic, energy system-wide and long-term planning perspective. Long-term energy scenarios have a multiplicity of uses that can support planning for a climate friendly energy system. They can be used to open the dialogue needed among stakeholders to reach consensus, or to raise ambitions of roadmaps for long-term targets and identify short-term challenges when planning the clean energy transition. The boundaries of scenarios need to be expanded beyond the power sector to also integrate traditional fuels, industrial  processes,  LULUCF  and  other  economy-wide  impacts.  Overall, there needs to be broader participation and stronger co-ordination across different stakeholders and government institutions involved in the energy scenario building and  energy  planning  process.  This  should  also  contribute  to  setting  long-term strategies that consider both energy and climate needs (coupled with the Sustainable Development Goals and the NDCs).

## REGIONS PROVIDE THE LINK BETWEEN GLOBAL ASPIRATIONS AND LOCAL ACTION

While climate change is a global threat, transforming the energy sector involves different paths for different regions. Energy transition plans and priorities inevitably differ from country to country. Still, countries within a region also tend to face similar challenges, which can facilitate regional approaches. It may be easier for regions to co-operate and act together on regional energy transition goals than for countries to act alone. Energy transition actions at the regional and country levels must be aligned and consistent with global climate objectives. The inter-regional collaborations must also explicitly address issues of fairness and justice. Ramping up country and regional ambition and interlinking energy and climate is key for the energy transition. IRENA is committed to that effort and will be starting a series of regional investment forums to  discuss  opportunities  with  countries  in  those  regions  to  accelerate  the  energy transformation.  The  results  of  this  report  will  be  used  to  facilitate  discussions.  A regional focus allows for better 'action on the ground'.

<!-- image -->

G

L

O

B

A

L

R

E

N

E

W

A

B

L

E

S

O

U

T

L

O

O

K

## Figure S.10        Different transition paths for different regions

Regional indicators including emissions, energy demand and electrification shares in the Transforming Energy Scenario

<!-- image -->

Transforming Energy Scenario (TES)

<!-- image -->

<!-- image -->

| Regions                         | Emissions Energy-related CO 2 (Gt CO 2 /yr)   | Emissions Energy-related CO 2 (Gt CO 2 /yr)   | CO 2            | Electrification in end-use consumption (% in TFEC)   | Electrification in end-use consumption (% in TFEC)   | Electrification in end-use consumption (% in TFEC)   |
|---------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------|------------------------------------------------------|------------------------------------------------------|------------------------------------------------------|
|                                 | 2017                                          | 2030                                          | 2050            | 2017                                                 | 2030                                                 | 2050                                                 |
| East Asia                       | 11.2 Gt CO 2 /yr                              | 8.4 Gt CO 2 /yr                               | 2.2 Gt CO 2 /yr | 25 %                                                 | 37 %                                                 | 58 %                                                 |
| European Union                  | 3.4 Gt CO 2 /yr                               | 1.9 Gt CO 2 /yr                               | 0.6 Gt CO 2 /yr | 22 %                                                 | 30 %                                                 | 49 %                                                 |
| Latin America and the Caribbean | 1.2 Gt CO 2 /yr                               | 1.0 Gt CO 2 /yr                               | 0.6 Gt CO 2 /yr | 18 %                                                 | 26 %                                                 | 39 %                                                 |
| Middle East and North Africa    | 2.5 Gt CO 2 /yr                               | 2.0 Gt CO 2 /yr                               | 1.1 Gt CO 2 /yr | 19 %                                                 | 20 %                                                 | 38 %                                                 |
| North America                   | 6.2 Gt CO 2 /yr                               | 3.7 Gt CO 2 /yr                               | 1.4 Gt CO 2 /yr | 20 %                                                 | 28 %                                                 | 52 %                                                 |
| Oceania                         | 0.4 Gt CO 2 /yr                               | 0.4 Gt CO 2 /yr                               | 0.1 Gt CO 2 /yr | 23 %                                                 | 22 %                                                 | 45 %                                                 |
| Rest of Asia                    | 3.5 Gt CO 2 /yr                               | 3.8 Gt CO 2 /yr                               | 2.0 Gt CO 2 /yr | 18 %                                                 | 26 %                                                 | 47 %                                                 |
| Rest of Europe                  | 2.0 Gt CO 2 /yr                               | 1.6 Gt CO 2 /yr                               | 0.7 Gt CO 2 /yr | 18 %                                                 | 23 %                                                 | 38 %                                                 |
| Southeast Asia                  | 1.4 Gt CO 2 /yr                               | 1.6 Gt CO 2 /yr                               | 0.8 Gt CO 2 /yr | 18 %                                                 | 20 %                                                 | 42 %                                                 |
| Sub-Saharan Africa              | 0.8 Gt CO 2 /yr                               | 0.6 Gt CO 2 /yr                               | 0.3 Gt CO 2 /yr | 7 %                                                  | 23 %                                                 | 48 %                                                 |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Note: 2017 data based on IEA (2019b), Global Carbon Atlas (2019) and IRENA analysis.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

S

U

M

M

A

R

Y

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Renewable energy share in TPES (%)   | Renewable energy share in TPES (%)   |      | Renewable energy share in power generation (%)   | Renewable energy share in power generation (%)   |      | Clean energy investments (USD billion per year)   | Clean energy investments (USD billion per year)   |
|--------------------------------------|--------------------------------------|------|--------------------------------------------------|--------------------------------------------------|------|---------------------------------------------------|---------------------------------------------------|
| 2017                                 | 2030                                 | 2050 | 2017                                             | 2030                                             | 2050 | 2016-2030 2016-2050                               |                                                   |
| 7 %                                  | 27 %                                 | 65 % | 23 %                                             | 60 %                                             | 90 % | 1120 USD bln 763                                  | bln                                               |
| 15 %                                 | 39 %                                 | 71 % | 31 %                                             | 55 %                                             | 86 % | 424 USD bln 323 USD                               | bln                                               |
| 30 %                                 | 53 %                                 | 73 % | 65 %                                             | 85 %                                             | 93 % | 154 USD bln 118 USD bln                           |                                                   |
| 1 %                                  | 9 %                                  | 26 % | 3 %                                              | 27 %                                             | 53 % | 198 USD bln 148 USD bln                           |                                                   |
| 10 %                                 | 30 %                                 | 67 % | 23 %                                             | 60 %                                             | 85 % | 609 USD bln 487 USD bln                           |                                                   |
| 10 %                                 | 39 %                                 | 85 % | 25 %                                             | 66 %                                             | 93 % | 37 USD bln 34 USD                                 | bln                                               |
| 8 %                                  | 27 %                                 | 58 % | 18 %                                             | 52 %                                             | 81 % | 420 USD bln 376 USD bln                           |                                                   |
| 6 %                                  | 19 %                                 | 54 % | 27 %                                             | 42 %                                             | 82 % | 244 USD bln 165 USD bln                           |                                                   |
| 13 %                                 | 41 %                                 | 75 % | 20 %                                             | 53 %                                             | 85 % | 143 USD bln 141 USD bln                           |                                                   |
| 7 %                                  | 43 %                                 | 89 % | 26 %                                             | 67 %                                             | 95 % | 95 USD bln 105 USD                                | bln                                               |

<!-- image -->

<!-- image -->

TFEC = total final energy consumption; TPES = total primary energy supply.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Main report Chapter 2

<!-- image -->

## GLOBAL SOCIO-ECONOMIC IMPACT

Renewable  energy  technologies  lie  at  the  heart  of  the  energy  transition.  The transition roadmap outlined here points to a more sustainable energy system and lays the foundation for new patterns of socio-economic development. This report examines the transition's likely effects on employment and GDP, while also providing a  composite  indicator  of  human  welfare.  The  analysis  is  based  on  a  model  that integrates energy, the economy and the environment. Its results can inform energy system planning, economic policy making, and other policies undertaken to ensure a just and inclusive energy transition at the global, regional and national levels.

## JOBS

In  the ambitious but achievable Transforming Energy Scenario, jobs in the overall energy  sector  -  comprising  transition-related  technologies  (renewable  energy, energy efficiency, and power grids and energy flexibility),  fossil fuels and nuclear power - could reach 100 million by 2050. This is 15% more than under the Planned Energy  Scenario  (which  reflects  current  national  commitments  and  plans)  and  72% more than total  energy  employment  at  present.  Underlying  the  total  are  significant changes in the composition of employment. New jobs in transition-related technologies and sectors are expected to outweigh job losses in fossil fuels and nuclear energy. In 2050, energy efficiency alone could employ 21 million people, and power grids and energy flexibility another 14.5 million - 21% and 14% more, respectively, than under the Planned Energy Scenario. By contrast, the 22 million jobs in fossil fuels in 2050 would be 27% fewer than in the Planned Energy Scenario.

nvestment  projected  under  the  Transforming  Energy  Scenario  would  stimulate I considerable job growth, most of this directly in renewables, where employment would rise to 42 million jobs by 2050. This  is  64% more than expected under the Planned Energy Scenario and close to four times the number of jobs in the sector today. Solar photovoltaic (PV) would account for almost half of these jobs, followed by  bioenergy  and  wind.  Among  segments  of  the  renewable  energy  value  chain, construction and installation jobs would dominate, accounting for 47% of the total. In  terms  of  occupational  profile,  construction  and  factory  workers,  together  with technicians, would hold a 77% share of total employment.

<!-- image -->

This expanded renewable energy workforce will require specific knowledge and skill sets. The labour market must be able to meet those needs, which would entail education,  (re-)training  and  social  policies,  among  other  measures.  Beyond  the deployment  of  renewable  energy  technologies,  other  sectoral  and  economy-wide transition trends are sure to affect the evolution of employment in the broader energy sector.

The  Transforming  Energy  Scenario  would  also  achieve  a  net  increase  -  close  to 7 million - in the total number of jobs created economy-wide by 2050, 0.15% more than  under  the  Planned  Energy  Scenario.  The  economy-wide  employment  figure reflects key assumptions and drivers, including not only investments, but also indirect and induced effects across many sectors of the economy, as well as changes in trade patterns.  Notwithstanding  the  overall  net  job  gain,  reallocations  of  investment  and changed consumption patterns would trigger job losses in some areas.

Maximising  the  job  creation  potential  of  the  energy  transition  requires  a  solid understanding  of  future  skill  requirements  and  effective  ways  to  facilitate  the corresponding shifts in the labour force. Just  and inclusive transition policies can limit labour market disruptions i.e. ,  the job losses and misalignments that can be expected to occur during the energy transition.  Targeted  education  and  capacitybuilding  policies  must  anticipate  impending  changes  and  nurture  the  diverse  and growing labour force required by the transition.

## GROSS DOMESTIC PRODUCT

Global GDP in 2050 would be 2.4% higher under the Transforming Energy Scenario than  under  the  Planned  Energy  Scenario. The  cumulative  gain  would  be  about USD 98 trillion,  a  finding  shaped  by  several  drivers  in  the  global  economy.  Frontloaded investments would contribute most to GDP growth during the first years of the transition and retain a positive but relatively small impact thereafter. GDP gains can be explained in great part by changes in consumer spending in response to fiscal policy, as well as other indirect and induced factors. By comparison, trade would add only marginally more to global GDP gains under the Transforming Energy Scenario than under the Planned Energy Scenario, as global trade flows remain broadly balanced in both scenarios.

The  cumulative  gains  in  global  GDP  (USD  98  trillion)  would  greatly  exceed  the investment costs of transforming the energy system (USD 15 trillion). The world's GDP would grow by USD 367 per capita per year under the Transforming Energy Scenario,  substantially  greater  than  the  additional  per  capita  total  investment (USD 54) needed to produce those gains. Increased investment and the prospects of economic growth and job creation could all help to obtain political buy-in. Still, the ultimate goal of the transition is to improve people's welfare through clean energy supply, economic and social development, and mitigation of climate change.

<!-- image -->

## WELFARE

Welfare would improve faster and further under the Transforming Energy Scenario - with global welfare gains estimated at 13.5% by 2050 - than under the Planned Energy Scenario. The composite welfare indicator in the IRENA model reflects the multidimensional  nature  of  human  welfare,  encompassing  economic,  social  and environmental components (Figure S.11). The economic dimension is measured via household consumption and a composite of total investment and employment. The social  dimension  reflects  spending  on  education  and  health.  The  environmental dimension entails greenhouse gas emissions and the consumption of materials. The bulk  of  the  welfare  gains  under  the  Transforming  Energy  Scenario  would  take  the form of social and environmental gains, reflecting significant health improvements from curbing air pollution and greenhouse gas emissions.

The  energy  transition  would  bring  substantial  socio-economic  benefits  at  the global level. Yet at the country and regional levels, outcomes could vary widely. This is  owing  to  variations  in  regional  and  country-specific  socio-economic  structures and their complex interactions with the energy system. The specific challenges and opportunities in each part of the world call for local solutions.

Figure S.11.     Welfare gains: Influenced by health benefits and emission reduction

Global welfare indicator under the Transforming Energy Scenario in 2030 and 2050

<!-- image -->

## REGIONAL SOCIO-ECONOMIC IMPACT

The transition will occur in countries and regions at varying stages of development and with different economic structures. Differences include resource endowment, industrial  productive  capacity,  industrial  support  policies,  trade  structures  and domestic supply chains. All these factors determine the degree to which any economy can take advantage of the opportunities offered by the energy transition. Accordingly, results will vary among individual regions in terms of jobs, GDP and welfare.

The regional impacts of the transition, both in the energy sector as a whole and in  its  constituent  parts,  are  sure  to  vary. Careful  analysis  of  the  likely  outcomes will  be  required  for  conventional  energy  (fossil  fuels  and  nuclear)  and  transitionrelated (renewables, energy efficiency, and system flexibility and grid enhancement) industries.  The  net  impact  of  the  Transforming  Energy  Scenario  will  depend  on the  current  structure  of  the  energy  sector  in  each  region,  on  regional  energy sector roadmaps, and on regional trade patterns associated with transition-related equipment.

Differences in resource endowment, industrial productive capacity, industrial support policies, trade structures and domestic supply chains determine the degree to which any economy can take advantage of the opportunities offered by the energy transition

<!-- image -->

<!-- image -->

## ENERGY SECTOR JOBS

The total number of energy sector jobs is expected to expand under the Transforming Energy Scenario to nearly 100 million (up from 58 million in 2017), but their spread will be uneven among regions. Asia dominates with a 60% share of all energy sector jobs in 2050 (Figure S.12). Compared with the Planned Energy Scenario, all regions gain jobs under the Transformed Energy Scenario. But Southeast Asia experiences the largest differential (81%), followed by Oceania (57%), Sub-Saharan Africa (36%) and North America (28%).

Figure S.12      A hundred million energy jobs: Regional distribution

Energy sector jobs in 2050 under the Transforming Energy Scenario, by region

<!-- image -->

Caribbean

Africa

Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

The number of jobs created in the overall energy sector will vary by technology and region. The jobs impacts in absolute numbers are largest in Asia and lowest in Oceania and Latin America. In East Asia and the Rest of Asia region, job losses are the highest of all, yet they are nonetheless surpassed by gains in transition-related technologies (Figure S.13).

Figure S.13      Energy sector job gains: Exceeding losses in every region

Difference in energy sector employment in 2050 between the Transforming Energy and Planned Energy scenarios, by region and sector

<!-- image -->

Based on IRENA analysis

S

U

M

M

A

R

Y

## TRANSITION-RELATED JOBS

Jobs intrinsically linked to the transition include those in renewable energy, energy efficiency, power grids and energy flexibility.

Under the Transforming Energy Scenario, the employment share of transition-related technologies  will  rise  against  that  of  conventional  technologies  in  all  regions. The transition-related share ranges from a high of 85% for North America and the European Union to a low of 60% for Sub-Saharan Africa and Rest of Europe (non-EU). Southeast Asia and Latin America will have the highest shares of jobs in renewable energy (83% and 72% respectively), while North America and the Middle East and North Africa (MENA) should fall at the lower range (40% and 45% respectively). In energy efficiency jobs,  North  America  is  far  ahead  of  other  regions,  at  45%  of  its total energy sector jobs; the share is 29% in the European Union. Southeast Asia has the lowest share of energy efficiency jobs (7%), while the share in other regions lies between 10% and 25%. With respect to power grids and energy flexibility , the share of jobs is highest in the Rest of Asia (22%) and the Rest of Europe (17%) and lowest in Southeast Asia (6%).

Employment gains can be realised in every region by 2050 in all transition-related technologies. In renewable energy , the relative increase in the Transforming Energy Scenario over the Planned Energy Scenario ranges from more than 20% in East Asia and Latin America to 380% in Oceania. In energy efficiency , regions would experience a relative gain ranging from 10% to 115%, with the Rest of Europe and the Rest of Asia regions faring best. In power grids and energy flexibility , the gains will range from about 6% in the Rest of Europe, East Asia and the Rest of Asia to almost 65% in North America.

The regional distribution of renewable energy employment in 2050 varies widely under the Transforming Energy Scenario. The share of the world's renewable energy jobs  is  as  high  as  36%  in  East  Asia  but  as  small  as  1%  in  Oceania,  which  largely reflects the size of populations, workforces and investments (Figure S.14). In terms of technology, solar will account for half of all renewables jobs in North America and in Asia, followed by Europe with 30%. By contrast, bioenergy is most prominent, with a share of over 60% of renewables jobs, in Latin America, Southeast Asia, Sub-Saharan Africa and the Rest of Europe. Wind is strongest in East Asia and the European Union, with about 25% of jobs; the figure is about 15% in North America and the MENA region. Hydro jobs account for 15% of all renewable energy jobs in the Rest of Asia and 10% in Latin America and the MENA region.

<!-- image -->

Figure S.14     An estimated 42 million jobs in renewables: Regional distribution

Renewable energy jobs in 2050 under the Transforming Energy Scenario, by region

<!-- image -->

Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

12.3

35.8

%

7.1

North

America

%

7.7

Latin

America and the

Caribbean

%

6.4

European

Union

%

4.9

Middle

East and

North

Africa

%

4.8

4.1

%

%

16  %

SubSaharan Africa Rest of Europe Southeast Asia Rest of Asia All regions gain more energy sector jobs than they lose as jobs in transition-related technologies outweigh the loss of jobs in the fossil-fuel sector

East

Asia

%

%

0.7

Oceania

<!-- image -->

## CONVENTIONAL ENERGY JOBS

In contrast to the gains for transition-related technologies, the Transforming Energy Scenario leads to lower projected employment in the conventional energy sector in all regions. For fossil fuels , the largest declines, of around 40%, are projected for North America, East Asia and the European Union. The Rest of Asia follows with a roughly 30% decline, while Latin America and the MENA region would drop about 25% each. Fossil-fuel job losses concern not only exporters but also importers that have built up extensive infrastructure, distribution networks, assets and human knowhow around these forms of energy. In nuclear energy , all regions are set to lose jobs as well, with declines ranging from 20% in Latin America, East Asia and the Rest of Asia, to as much as 65% in Europe and North America.

Even as conventional energy employment shrinks overall, the share of conventional energy jobs remains high in some regions. Conventional energy jobs account for up to 40% of energy sector employment in Sub-Saharan Africa, the MENA region and the Rest of Europe compared with 10% to 15% in the European Union, the Americas and East Asia. The remaining conventional energy employment reflects a continuing degree of reliance on these sources.

As  the  energy  transition  accelerates,  the  job  loss  in  conventional  technologies becomes more pronounced. For the design of just transition policies that leave no one behind, detailed analysis will be needed to understand the structure of qualifications in the jobs lost and the composition of the labour force.

## ECONOMY-WIDE EMPLOYMENT

Energy is an integral part of every economy, interacting with every other sector, affecting relative wages and generating income to be spent in other sectors. The embedded character of the energy sector within the wider socio-economic system, and the complex dynamics of the transition, will induce positive or negative effects in other economic sectors. In turn, other sectors may contribute favourably or adversely to  transition  challenges  within  the  energy  sector.  A  holistic,  just  transition  policy framework is needed to bring about the best possible outcome.

Whether a region experiences growth or decline in economy-wide jobs depends on various factors, including energy transition roadmaps and regional socio-economic structures. The  European Union and North America, respectively, are expected to gain 2.4% and 1% in economy-wide jobs in 2050 over the Planned Energy Scenario. These regional gains are significantly higher than the global average gain of 0.15%. All other regions gain less than 0.5% in economy-wide employment, and some even face a loss of jobs (MENA region, Rest of Europe, Latin America, Southeast Asia and the Rest of Asia). Sub-Saharan Africa shows no significant change.

Despite  new,  transition-related  job  opportunities,  labour  market  challenges  are sure to arise in various sectors of the economy. The  loss  of  jobs  in  the  fossil-fuel sector is the most prominent example of these challenges, but other sectors may also be affected. In fact, the analysis indicates that across entire economies, some regions face the prospect of lower 2050 employment under the Transforming Energy Scenario than under the Planned Energy Scenario. At the economy-wide level, some regions, such as the European Union, North America and East Asia, experience a strong net positive benefit owing to their economies' ability to capitalise on indirect and induced effects  of  the  energy  transition.  Sub-Saharan  Africa  and  the  Rest  of  Asia  lack  this ability, given their less diversified and weaker supply chain structures. Others, such as coal and hydrocarbon dependent regions, face a net negative outcome in comparison to the Planned Energy Scenario.

Structural realities may translate into different kinds of labour market misalignments of a temporal, spatial, educational or sectoral nature - a potential in any transition. The quantification of potential sectoral job misalignments, as revealed by the present socio-economic analysis, should inform policy making on the just transition. Because labour challenges are context-specific, a just transition will depend on context-specific policies in each region and country.

## GROSS DOMESTIC PRODUCT

In the period 2019-2050, the average difference  in GDP between the two scenarios amounts  to  2%  globally,  but  the  gains  in  individual  regions  show  considerable variation. The projected results range from a gain of almost 5% in the European Union to a loss of 0.5% in the MENA region. Regions scoring better than the global average include Southeast Asia and East Asia, while the Rest of Europe, North America, the Rest of Asia and Sub-Saharan Africa fall below the average. The MENA region and Oceania are the two exceptions that would experience less GDP growth under the Transforming Energy Scenario than under the Planned Energy Scenario.

Trade plays a prominent role in shaping the future of some regional economies. The large GDP gains in Southeast Asia and Sub-Saharan Africa are attributable to a strong increase in net exports, whereas the MENA region faces the opposite dynamic, driven by the loss of hydrocarbon exports. The positive trade effect in Latin America and the Rest of Asia is quite pronounced; North America, by contrast, faces a drag from reductions in fossil-fuel trade and even more so trade in other goods and services (Figure S.15).

<!-- image -->

Whether a region experiences growth or decline in economy-wide jobs depends on various factors, including energy transition roadmaps and regional socio-economic structures

Figure S.15      Largest drivers of GDP gains: Transition effects and trade

Effect of three sets of drivers on the differences in regional GDP between the Transforming Energy and Planned Energy scenarios over the 2019-2050 period

## Gains/losses (%)

<!-- image -->

nvestment levels are another important driver of the transition's regional socioI economic outcomes. At the global level, transition-related clean energy investments average  USD  122  per  capita  per  year.  Among  regions,  the  amounts  vary  widely, from  about  USD  50  per  capita  per  year  in  Sub-Saharan  Africa  to  more  than  USD 450 per capita per year in North America. Not only are the macroeconomic impacts consequently higher where investments are larger, but the multipliers in each economy play a significant role in determining the strength of investment effects.

The  presence  of  robust  supply  chains  allows  indirect  and  induced  effects  to contribute positively to the economy, especially if supported by appropriate fiscal policies. This  is  particularly  the  case in some of the major economic regions, such as  the  European  Union,  East  Asia  and  North  America.  Additional  employment  is  a key factor in triggering induced effects, as it leads to additional wage income, which has multiplier effects through increased consumer spending. Fiscal policies are most effective  if  they  are  based  on  a  clear  understanding  of  the  local  socio-economic context in a given region or country. But their successful implementation hinges on the presence of complex administrative infrastructure.

The diverging outcomes of the transition process can be attributed to different regional  socio-economic starting points. This  means  that  even  if  all  regions  had the  same  level  of  ambition  and  success  in  implementation,  their  results  would  be different. The underlying causes can be traced back to several country factors and structural  realities:  macroeconomic  conditions,  fossil  fuel  and  other  dependencies, institutional fabrics and capabilities, investment patterns and trade positions.

Under  the  Transforming  Energy  Scenario,  the  cumulative  global  GDP  gains  of USD 98 trillion by 2050 translate into an average of USD 367 per capita each year. The distribution of these gains is uneven across the regions. The European Union is expected to gain as much as USD 2 950 per capita per year, reflecting its strong socio-economic  structures,  but  for  most  regions  the  gain  is  between  USD  650  to about USD 100. Sub-Saharan Africa is projected to experience a modest increase of about USD 30, while the MENA region and Oceania would see a decline relative to the Planned Energy Scenario (Figure S.16). Variations in economic outcome contribute to the differences in the welfare estimates for these regions.

## Figure S.16      Regional differences in GDP gains per capita

Cumulative GDP gains by region under the Transforming Energy Scenario compared with the Planned Energy Scenario (in USD, per person per year)

<!-- image -->

Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

<!-- image -->

## WELFARE

The transition would bring significant improvements in people's welfare in every region. Compared to the Planned Energy Scenario, the Transforming Energy Scenario strengthens the welfare index between 10% in the European Union and 17% in Oceania. The Rest of Asia, the Americas, and Sub-Saharan Africa fare slightly better than the global average, while the remaining regions score slightly lower.

Welfare gains are mostly due to progress in social and (secondarily) environmental indicators. Social  indicators  include  two  sub-components:  health  and  education. On the health side, improvements due to reduced air pollution have the strongest effect across all regions, with people suffering most from air pollution achieving the greatest welfare gains. Among the two environmental sub-indicators, the mitigation of greenhouse  gas  emissions  features  more  prominently  than  changes  in  the consumption of materials. Again, this is true across all regions. The economic indicator (composed of employment and consumption and investment) is most evident in the European Union and North America (Figure S.17).

Figure S.17      Regional-level welfare improvements driven by social and environmental gains

Composite welfare indicator in 2050 under the Transforming Energy Scenario, by region

<!-- image -->

Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

## IMPLICATIONS

All regions of the world can expect to derive benefits from the energy transition, but thorough, granular analysis is needed to understand the reasons for regional differences. Individual regions will not gain equally in the transition-related sectors (renewables, energy efficiency, and power grids and energy flexibility), and they will face losses in the conventional energy sector to different degrees.

Regional outcomes will vary for GDP, employment and human welfare. With regard to jobs, the outcome for different regions will also diverge for the energy sector and its main components (transition-related and conventional energy) and with regard to the economy as a whole.

Differences in regional socio-economic outcomes can be traced back to contrasts in  their  structural  conditions,  industrial  capacities  and  trade  patterns,  and  the depth and diversity of domestic supply chains. Existing structures can be altered over time through policy ambition and far-sighted planning. Taking full advantage of the opportunities offered by the energy transition requires that interlinkages between the energy transition and the wider economy be analysed at sub-regional and national levels.

To  achieve  a  successful  transition,  energy  policies  must  be  mainstreamed  into economic,  industrial,  labour,  educational  and  social  policies. Cross-cutting and coherent policy making can deliver on climate and energy ambitions; put in place a mix of  programmes,  projects  and  initiatives  to  generate  successful  outcomes;  and  avoid or reduce potential misalignments in labour markets as the energy transition unfolds.

Unforeseen developments. The novel coronavirus (COVID-19), its impact on the global economy and the resulting fall in oil prices in early 2020 serve as reminders of how unforeseen factors can disrupt both actual trends and planned  processes.  These  developments  confirm  the  importance  of  close inter-connections between the energy system and the wider economy. Amid the complexities of the real world, deep-rooted structural dependencies will require persistent efforts to overcome.

Coronavirus is sure to affect the energy transition, too, threatening global supply chains in many sectors. Oil price volatility could have contradictory effects,  in  part  because  oil  plays  a  marginal  role  in  the  power  sector  but is much more important in the transport sector, which accounts for half of total demand, and where without low-emission transport policies in place, an  extended  period  of  low  oil  prices  may  impact  the  speed  of  electric vehicle adoption. Conversely, oil price volatility may undermine the viability of  unconventional  oil  and  gas  resources  as  well  long-term  contracts.  The severity and duration of such impacts remain to be seen. Yet they will not change the path required to build a low-carbon society.

<!-- image -->

## TOWARDS THE TRANSFORMATIVE DECARBONISATION OF SOCIETIES

<!-- image -->

Rapidly  mounting  climate  concerns,  rampant economic inequality and simmering social justice  issues  require  a  comprehensive  global economic transformation. These challenges call for  holistic  solutions,  with  renewable  energy playing a key role. A successful energy transition is  central to the achievement of interconnected objectives, such as meeting climate goals, fostering  economic  development,  creating  jobs and promoting shared welfare.

The  decarbonisation  of  the  global  economy  in a  relatively  short  time  frame  calls  for  unprecedented, large-scale policy interventions and massive  resource  mobilisation. The  confluence of social justice, economic and climate issues has prompted calls for a global 'Green New Deal' to bring about massive shifts in the world's energy system and economy, accompanied by measures to  ensure  a  just  transition  for  affected  workers and communities through public interventions on an unprecedented scale. The key lies not just in a given set of policies but in the recognition that a transformative decarbonisation of societies is needed.

extends  to  the  multiple  facilities  required  for extracting,  processing  and  distributing  oil,  gas and  coal.  This  has  implications  for  the  sectors that provide supply chain inputs, and for institutions that educate and train the workforce. However, dependence is hardly limited to energy exporters. Importers, too, have built up extensive infrastructure, distribution networks, assets and human know-how around oil, gas and coal. Such forms of dependence may become a liability as the energy transition unfolds.

As  countries and  regions  embark  on  their transformation pathways, their respective, different  starting  points  reflect  their  various structural dependencies and the depth of their  domestic  supply  chains. These  factors, including dependencies  on  fossil fuels and other commodities,  technologies  and  trade, will  inevitably  be  reflected  in  the  outcomes  of the energy transition in 2050. Despite positive outcomes at the global level, the energy transition  is  likely  to  generate  very  different outcomes for individual regions and countries.

Fossil-fuel  dependence  is  reflected  in  flows of  finance  and  economic  structures. Beyond export  revenues  for  producers  (as  a  share  of their GDP or government budgets), dependence

In addition to structural factors that need to be addressed, unforeseen developments may well influence the energy transition. The outbreak of the coronavirus is disrupting global supply chains in  many  sectors,  including  renewable  energy. The  oil  price  volatility  observed  in  early  2020 has  contradictory  effects.  It  is  unlikely  to  have a significant impact on renewables in the power sector (where oil plays a limited role) but could affect the speed of electrification in the transport sector. Oil price volatility could also undermine the viability of unconventional oil and gas (Box on "Unforeseen developments"). It is difficult to know how disruptive these developments will prove to be. While the short-term impacts loom large,  they  seem  less  likely  to  alter  the  longterm planning horizons for decarbonisation and sustainable development.

As countries around the world grapple with the challenge of transforming an energy system and by extension a global economy - that relies on  polluting  conventional  energy  resources, notions  of  a  'Green  New  Deal'  are  receiving growing  attention  in  Europe  and  elsewhere. While this term is inspired by the New Deal of the 1930s, the name chosen for a given set of policy proposals  is  less  important  than  recognising the  need  for  a  holistic  approach  to  the  energy transition that simultaneously addresses economic, social and ecological problems.

Market mechanisms alone will not bring about emissions  reductions  on  the  scale  required in  coming  decades  to  transform  the  energy system and overcome structural dependencies. Alongside private sector financing, much stronger  public-sector  interventions  and  global collaborative  efforts  are  needed  to  ensure  the transition to a green, just and inclusive economy. Countries  need  to  acquire  or  further  develop their  industrial  capabilities  and  leverage  them to  take  advantage  of  emerging  opportunities in green  technology  development.  Technological  transitions,  such  as  the  rapid  uptake  of renewables  and  energy  efficiency  measures, can provide a temporary window of opportunity for  lagging  economies  to  catch  up.  Likewise, pre-existing productive capabilities, particularly in manufacturing sectors with high spillovers to the rest of the economy, can provide a promising basis for innovation in green technologies.

A  successful  energy  transition  will depend on  a  package  of  proactive,  coherent  publicsector  interventions. In  addition  to  measures to  support  technological  innovation,  bolstered by  knowledge  sharing  and  exchanges  of  best practices,  such  a  package  includes  policies  on the  deployment  and  integration  of  renewables into  energy  distribution  systems  and  end-use applications, as well as measures  to  ensure sufficient  system  flexibility  as  variable  renewables (solar  and  wind)  grow  in  importance.  Further, enabling policies include industrial policies, labour-market interventions, educational and  skills  development,  and  social  protection measures.  Strategies  for  a  just  and  inclusive transition aim to avoid or minimise dislocations for individuals, communities, countries and regions,  thus  ensuring  broad  benefits  from  the energy transition.

Success  will  depend  on  the  strengthening  of institutions,  and  also  on  broadening  policy co-ordination  and  cohesion. At  the  national level, robust institutions can play a key role in accelerating  the  energy  transition  and  driving change  at  the  scale  and  magnitude  needed.

Co-operation is  as  important  at  the  international level as it is within any country, not least because of tremendous variations in the ability of individual countries to marshal necessary resources, raise institutional  capacities  and  develop  technical know-how.  A  shared  willingness  to  draw  on lessons learned and best practices will benefit all and can herald a strengthened multilateralism for decarbonisation. This includes a rethinking of rules  governing the global trade system with a view to supporting an ambitious and successful energy transition.

Mobilising  resources  on  a  massive  scale  is indispensable. At  the  international  level,  the Climate Investment Platform announced in September 2019 by the International Renewable Energy Agency, the United Nations Development Programme, the multi-partner Sustainable Energy for All initiative, and the Green Climate Fund aims to mobilise energy-transition investments  on  a  scale  commensurate  with climate goals. Sub-regional i nvestment forums,  co-ordinated  by  IRENA,  are  intended to create enabling conditions, improve access to finance and assist developers in the preparation of bankable renewable energy projects. 1

Ultimately, the success of the energy transition in  mitigating  the  climate  crisis  will  depend on  the  policies  adopted,  the  speed  of  their implementation  and  the  level  of  resources committed. In our interconnected world, international co-operation and solidarity are not  only  desirable,  they  are  a  vital  condition for addressing climate change, economic inequality  and  social  injustice.  Moving  forward, investment decisions should be evaluated on the extent to which they accelerate the shift towards an inclusive low-carbon economy.  Anything  short  of  that  can  seriously hamper the path towards a transformative decarbonisation of our societies.

1 To learn more, see https://irena.org/irenaforcip .

<!-- image -->

## 1.1  Drivers for the energy transformation

Climate change has become a major concern of this century. The urgent response to that concern is an energy transformation that swiftly reduces the carbon emissions that cause climate change. The Paris Agreement establishes a clear goal to limit the increase of global temperature to 'well below' 2 degrees Celsius (°C), and ideally to 1.5 °C, compared to pre-industrial levels, by this century. To realise this climate target, a profound transformation of the global energy landscape is essential.

Rapidly shifting the world away from the consumption of fossil fuels and towards cleaner renewable forms of energy is critical to reach the climate goals agreed upon in Paris. Such a transformation is possible with the rapid replacement of conventional fossil fuel generation and uses with low-carbon technologies. Decarbonising the energy sector and reducing carbon emissions are the key objectives of the energy transformation roadmaps of the International Renewable Energy Agency (IRENA), which examine and provide an ambitious, yet technically and economically feasible, pathway for the deployment of lowcarbon technology towards a more sustainable clean energy future. But the reduction of carbon emissions is not the only reason why the world should embrace the energy transformation. There are many other drivers behind it (Figure 1.1).

Figure 1.1     Pressing needs and attractive opportunities Key drivers for the energy transformation

GLYPH&lt;141&gt;

<!-- image -->

<!-- image -->

## Rapid decline in costs for renewable energy:

Global weighted average costs  for  electricity  from all of the commercially available  technologies  for  renewable power  generation  have  kept  falling  in recent  years. For  example,  the  decline in the cost of electricity from utility-scale solar  photovoltaic  (PV)  projects  since 2010 has been remarkable. Between 2010 and  2019,  the  global  weighted  average levelised cost of electricity (LCOE) from solar PV fell 82%, reaching USD 68.4 per megawatt-hour (MWh), while the cost of electricity  from  onshore  wind  declined 45% to USD 52.8/MWh. In the last two years, solar corporate procurement jumped 44% worldwide, soaring to 5.4 gigawatts (GW) in 2018 and 9.6 GW in 2019 (Martin, 2020).

Between  2017  and  2018,  nearly  half of  all  solar  PV  auctions  were  held  in South  and  East  Asia  and  the  Pacific, owing to high levels of solar irradiance and  the  falling  cost  of  the  technology. India alone allocated 17 GW of solar PV capacity  auctions  at  an  average  price of USD 42.3/MWh. Likewise, China awarded 5 GW of solar PV at an average price  of  USD  64.6/MWh  in  a  total  of 10 auctions, and the Philippines received bids  as  low  as  USD  43.9/MWh  in  a 50  MW  auction.  IRENA'S  database  of power  purchase  agreement  (PPA)  and auction results suggests that the cost of solar PV generation will continue to fall in 2020.

Onshore wind auctions were most widely used  in  Europe,  followed  by  South  and East Asia and the Pacific. Offshore wind projects in Europe are now increasingly competitive with fossil fuel sources on  a subsidy-free  basis in wholesale electricity markets ( e.g. , subsidy-free bids  in  Germany  and  the  Netherlands). Germany  alone  auctioned  more  than 5  GW  in  seven  rounds  over  2017-2018 at  an  average  price  of  EUR  51.65/MWh (USD 58.7/MWh).

In  the  United  States,  non-hydropower renewable energy resources such as solar PV  and  wind  are expected to be the fastest-growing sources of electricity generation in the next two years. Biomass auctions were concentrated  mainly  in  Europe  and  the Americas.  Argentina  awarded  143  MW of biomass at an average price of USD 107.5/MWh under the second round of the RenovAr programme. Concentrating solar power (CSP) was  auctioned  mainly  in  Central  and Western Asia,  specifically  in  the  United Arab  Emirates,  where  Dubai  awarded 700  MW  at  a  price  of  USD  73/MWh (IRENA, 2019h).

<!-- image -->

## Air quality improvements:

Air pollution is a major public health crisis, caused mainly by unregulated, inefficient  and  highly  polluting  energy sources ( e.g. ,  fossil fuel combustion and chemical-related  emissions).  The  switch to clean renewable energy sources, along with  cost  reductions  and  developments in electromobility, would  improve  the air quality  in  cities and  bring  greater prosperity by reducing ill health. It would also bring modern energy access to rural areas and increase productivity.

The benefits from reduced pollution and improved health could outweigh the overall  system  costs  of  renewables.  The total savings in improved health, reduced subsidies  and  lower  impacts  of  climate change  would  be  worth  as  much  as USD 160 trillion cumulatively over a 30-year period.

Thus,  every  dollar  spent  in  transforming the global energy  system  provides  a payoff of at least USD 5, and potentially more  than  USD  7,  depending  on  how externalities are valued.

<!-- image -->

Reduction of carbon emissions and climate change  impacts: Shifting away  from  fossil  fuel  use to renewable sources not  only  reduces  carbon  emissions,  it would also reduce the impacts of climate change and improve conditions for society and business.

<!-- image -->

## Universalisation of energy global energy would help lead

## access:  Transforming  the system to clean  energy  access  for

everyone. The  current  lack  of  energy access for millions of people is a cause of  great  inequality.  Renewable  energy technologies  can  be  applied  to  rural areas  where  the  grid  has  yet  to  reach, bringing rural electrification, community energy initiatives and distributed energy resources that can greatly improve people's lives and stimulate local economies.

Enhancement  of  energy

<!-- image -->

security: For countries heavily dependent on imported fossil fuels, energy security is a significant issue. Renewables can provide  a  more  secure  alternative  to fossil fuels by increasing the diversity of energy sources through local generation, thus contributing to the flexibility of the system and improving resistance to shocks.

## Socio-economic benefits:

<!-- image -->

Transforming  the  global energy system would also bring large socioeconomic benefits, which are  crucial  to  influencing  any  political decision. The transition process itself will bring about profound structural changes in labour markets, resulting in four types of  job  effects:  job  creation,  elimination, substitution and transformation (IRENA, 2020a). The  development  of  a local renewable energy industry has the potential to create  jobs that can  be filled by people of all genders and from all  disciplines  and  backgrounds.  Should local industries not be developed, countries with energy security problems would  just  move  from  importing  fossil fuels to importing renewable  energy equipment.

On the other hand, some jobs will become redundant, specifically  in  fossil fuel production but also in other sectors such as conventional automobiles (as electrification of transport takes place).  Some  of  these  jobs  will  be  lost, but others could be saved through re-orientation  measures.  Shifting  to  a renewable-powered  future  also  allows for retaining existing expertise from the  fossil  fuel  industry,  particularly  for renewable  industries  such  as  offshore wind. For instance, the expertise of workers and technicians in building support  structures  for  offshore  oil  and gas  sites  could  potentially  be  used  to build  foundations  and  substations  for offshore wind turbines (IRENA, 2019e).

The energy transformation would boost  gross  domestic  product  (GDP) by 2.5% and total employment by 0.2% globally  by  2050.  In  addition,  it  would bring  broader  social  and  environmental benefits.

<!-- image -->

## Box 1.1 RENEWABLE POWER GENERATION COSTS CONTINUE TO DECLINE

In  most parts of the world today, renewables have become the lowest-cost source of new power generation. As costs continue to fall for solar and wind technologies, this will be true in a growing number of countries.

Data  from  the  IRENA  Renewable  Cost  Database  show  that  since  2010,  the  global  weighted average  LCOEs  from  bioenergy,  geothermal,  hydropower,  and  onshore  and  offshore  wind projects  have  all  been  within  the  range  of  fossil  fuel-fired  power  generation  costs,  while  for onshore wind, solar PV and CSP, costs continue to decline rapidly (IRENA, 2019i). Between 2012 and 2018, the LCOE of solar PV fell by 77%, CSP by 46%, onshore wind by 35% and offshore wind by 20%. Costs are expected to continue to decline for solar and wind power technologies to 2030 (Figure 1.2).

- CSP: By 2030, the central LCOE value of CSP plants in G20 countries is likely to decline by
- 35% to USD 0.086 per kilowatt-hour (kWh) from a central estimate of USD 0.132/kWh in 2018. The range of CSP LCOE estimates is also expected to narrow from between USD 0.077/kWh and USD 0.357/kWh to between USD 0.044/kWh and USD 0.214/kWh. Cost reduction drivers vary according to the specific  type  of  technology.  For  example,  parabolic  trough  systems  can  be expected to benefit from a step-change reduction related to the switch to molten salt as a heat

LCOE development of CSP, solar PV, offshore and offshore wind technologies

Figure 1.2     Solar and wind power: Expected cost reductions until 2030 (G20 country averages), 2018-2030

GLYPH&lt;127&gt;

<!-- image -->

transfer fluid. This switch simplifies the plant layout,  improves  power block efficiency and reduces the cost of storage. In the case of solar tower systems, a more evolutionary approach from  current  state-of-the-art  technological features  is  more  likely  that  does  not  involve major general plant design modifications.

- Onshore wind: Onshore wind is expected to  see  a  decline  of  25%  between  2018  and 2030 ,  as  the  continued  shift  to  larger  wind turbines  with  higher  hub  heights  and  swept areas  improves  the  capacity  factor  for  this resource. Installed cost reductions provide an important contribution as well, as increases in the  scale  of  deployment  and  manufacturing process improvements continue the historical trend  towards  lower  costs.  Innovations  in operation and maintenance (O&amp;M), including real-time  data  and  predictive  maintenance and  the  synergies  from  the  management  of large  portfolios  of  turbines,  also  yield  more efficient and timely operations.
- Solar  PV:  The  global  weighted  average LCOE for solar PV can be expected to continue its downward trend to reach USD 0.040/kWh by 2030  (a 58%  reduction from 2018). This decline will be driven by continued improvements  in  module  efficiency  levels, driven  by  a  market  shift  towards  increased dominance of advanced cell architecture such as the PERC (passivated emitter rear contact) cell  technology  in  the  period  towards  2025. Over  the  longer  term,  newer  architectures with  even  higher  efficiency  levels  can  be expected to drive further improvements.

In  terms  of  cost  components  along  the  PV value  chain,  the  ingot/wafer  process  cost reductions  will  be  the  most  significant;  they will be driven by polysilicon cost reductions, lower utilisation due to decreased kerf losses and manufacturing optimisation. At the cell  manufacturing  level,  diamond  wire  and silver  paste  costs  will  continue  to  decline. Cost  reductions  for  PV  glass  backsheet  and encapsulant  components  are  likely  to  also contribute  to  cheaper  module  assembly  to

2030.  An  important  market  shift  towards higher adoption of bifacial cells and modules, driven by the prevalence of the PERC architecture  and  its  compatibility  with  that technology, can also be expected.

- Offshore wind: Offshore wind is becoming competitive  with  other  renewable  energy technologies with improvements in the full life cycle of processes ( i.e. , from development down to O&amp;M). The technology is improving, with larger turbines and higher turbine ratings (with up to 20 MW turbines expected to be used for projects in 2030). As a result, capacity factors are increasing, boosting energy yields and reducing total installed and O&amp;M  costs. Furthermore, competitiveness and  LCOE  reductions  have  been  driven  by the  recent  projects  (since  2017)  as  lower auction prices and zero subsidy projects have increased  competitive  pressures  (including consolidation)  across  the  supply  chain.  The increased deployments and growing maturity of offshore wind markets in Europe and China between  2010  and  2019  have  also  reduced risks  and  uncertainty  for  investors.  That  has led to increased interest in the offshore wind sector and has reduced the costs of financing.

Considering historical LCOE trends (where technology  trends  and  market  drivers  have been  investigated and  modelled)  and  PPA prices for projects being deployed up to 2030, IRENA  anticipates  a  central  LCOE  estimate of USD 0.054/kWh in 2030 - an almost 55% drop from the 2018 LCOE of USD 0.115/kWh . The LCOE range in 2030 is wider with a more aggressive  expectation  for  average  LCOE  in established  offshore  wind  markets  ( e.g. , the United Kingdom (UK), Germany and China) of USD 0.039/kWh and an average expectation in newer markets ( e.g. , Turkey and Japan) close to the 2018 weighted average, at USD 0.110/kWh.

<!-- image -->

## Box 1.2     NERGY SUBSIDIES IN THE E ENERGY TRANSFORMATION

As countries examine their plans in Nationally Determined Contributions (NDCs) under the Paris Agreement, significant attention is being paid to minimise the costs of the transition. However, ignoring the health and environmental costs of incumbent resources can result in sub-optimal investment decisions in the market and by policy makers. One area that deserves more attention in this debate is the size and impact of environmentally harmful subsidies to fossil fuels.

For virtually all of the modern era of energy usage, the energy sector has operated with a range of subsidies that have, to a greater or lesser extent, distorted market functioning (indeed, the sector has often actively sought these subsidies). In many cases, what policy makers or industries considered temporary subsidies - both well intentioned and egregious ones alike - have persisted for decades, as industry has actively  sought  to  ensure  their  continuation.  In  some  instances,  industry  has  even actively framed the debate to exclude such policies from consideration, on the basis that they are not subsidies.

Figure 1.3    Energy subsidies: Overall reduction in the Transforming Energy Scenario Total direct energy sector subsidies by fuel/source, 2017, 2030 and 2050 in the Transforming Energy Scenario

GLYPH&lt;129&gt;

<!-- image -->

IRENA has estimated the direct subsidies  to  fossil  fuels  ( i.e. ,  excluding externalities) at USD 447 billion in 2017 (IRENA,  forthcoming  b)  based  on  data from the Organisation for Economic Co-operation  and  Development  (OECD) and the International Energy Agency (IEA) (Figure 1.3). Meanwhile, the indirect subsidies to fossil fuels from underpricing of their negative externalities ( e.g. , health costs from  local pollution and climate change) were an estimated USD 2 630 billion in 2017.

Subsidies  to  fossil  fuels  are  especially damaging to environment, because they exacerbate  the  existing  underpricing  of fossil fuels that typically do not pay the full  cost  for  their  negative  externalities ( e.g. ,  health  costs  from  local  pollution). Environmentally  harmful  subsidies  for fossi fuels are around 19 times larger than support to renewables, which was around USD  166  billion  in  2017.  The  order  of magnitude of this problem is significant, and these indirect subsidies are estimated to  be  19  times  higher  than  those  to renewables in 2017. Environmentally friendly support schemes to renewables, energy efficiency and other clean energy sources  that  lead  to  the  displacement of fossil fuels when the negative externalities of fossil fuels from air pollution and climate costs remain underpriced, therefore help improve the economic  efficiency  of  the  sector,  by helping correct for  market  failure.  They do  this  by  shifting  energy  generation and use towards technologies that reduce the negative externalities of fossil fuels.  In  2017,  subsidies  for  renewables were estimated at USD 166 billion, with around USD 38 billion for transport and USD 128 billion for power generation.

The  evolution  of total energy  sector subsidies  to  2050,  assuming  the  virtual elimination of existing fossil fuel subsidies (by 2050 almost all the subsidies to fossil fuels  derive  from  carbon  capture  and storage)  and  the  increased  deployment of renewables  and  energy  efficiency, would result in a decline in total annual subsidies to the energy sector between 2017 and 2050. The switch from environmentally  harmful  subsidies  for fossil fuels to environmentally friendly ones  would  result  in  a  25%  decline  in total direct energy  sector subsidies to  USD  475  billion  between  2017  and 2050, which is around 45% lower than they  would  have  been  in  the  Planned Energy Scenario in 2050.

<!-- image -->

## 1.2    A widening gap between reality and what is needed

To set the world on a pathway towards meeting the aims of the Paris Agreement, energy-related carbon dioxide (CO2) emissions need to be reduced by a minimum of  3.8%  per  year  from  now  until  2050,  with  continued  reductions  thereafter. However, trends over the past five years show annual growth in CO2 emissions of 1.3%. If this pace were maintained, the planet's carbon budget would be largely exhausted by 2030, setting the planet on track for a temperature increase of more than 3°C above pre-industrial levels. This case cannot be considered as a climate-compatible scenario, as many governments, by signing the Paris Agreement in 2015, committed to reducing their emissions.

Figure  1.4  shows  the  possible  paths  of  annual  energy-related  CO2  emissions  and reductions as per three scenarios: the Baseline Energy Scenario (BES) (indicated by the orange line); the Planned Energy Scenario (PES) (indicated by the yellow line); and  IRENA's  energy  transformation  pathway  -  the  Transforming  Energy  Scenario (TES) (indicated by the blue line).

In the Baseline Energy Scenario, which does not necessarily imply the fulfilment of all  plans  and  pledges  of  countries  and  considers  only  the  policies  in  place  around the  time  of  the  Paris  Agreement  (2015),  energy-related  emissions  are  expected  to increase at a compound annual rate of 0.7% per year to 43 gigatonnes (Gt) by 2050 (up from 34 Gt in 2019), resulting in a likely temperature rise of 3 °C or more by the end of the century. However, several countries have made efforts in the last three years to implement policies and revise their targets in line with higher deployment of clean energy technology. Most of the efforts and ambition are oriented towards increasing renewable power generation capacities, followed by energy efficiency improvement targets and a subsequent rise in electrified transport and heat applications.

If  the plans and pledges of countries are met as reflected in the Planned Energy Scenario, then energy-related CO2 emissions are expected to increase each year until 2030, before dipping slightly by 2050 to just below today's level. However, to  limit  the  global  temperature  rise  to  well  below  2  °C  and  towards  1.5  °C  as  per the Paris Agreement targets, annual energy-related CO2 emissions would need to fall more than 70% from now until 2050. In absolute terms, emissions would be reduced from 34 Gt today to below 10 Gt in 2050. A large-scale shift to renewable energy and electrification measures could deliver three-quarters of the needed reductions (electrification and renewables contributing to an emissions mitigation potential of 75%), or as much as 90% with ramped up energy efficiency measures.

<!-- image -->

To achieve such levels of emissions reductions, an acceleration is needed across a spectrum of sectors and technologies, ranging from rapid deployment of renewable power generation capacities such as wind, solar PV, etc., to deeper electrification of the  end-uses of transport ( e.g. ,  electric  vehicles,  EVs)  and  heat  ( e.g. ,  heat  pumps) powered  by  renewables,  direct  renewable  use  ( e.g. , solar thermal, biomass), energy  efficiency  ( e.g. ,  thermal  insulation  of  buildings,  process  improvement)  and infrastructure investment ( e.g. , power grids, flexibility measures such as storage).

IRENA's Transforming Energy Scenario outlines a climate-friendly pathway with energy-related  CO2  emissions  reductions  of  70%  by  2050  compared  to  current levels,  with  9.5  Gt  of  remaining  energy-related  CO2  emissions  by  mid-century (Figure 1.4). Of the remaining 9.5 Gt of energy-related CO2 emissions in 2050, just under one-quarter is emitted for both electricity generation and transport, one-third in industry, 5% in buildings and the remaining 15% in other sectors (agriculture and

## Figure 1.4     Renewables, energy efficiency, electric vehicles and hydrogen can provide bulk of necessary emissions reductions by 2050

Annual energy-related CO2 emissions in the Baseline Energy Scenario, the Planned Energy Scenario and the Transforming Energy Scenario, and mitigation contributions by technology in the three scenarios, 2010-2050

<!-- image -->

Note: The Transforming Energy Scenario includes 250 Mt/year in 2050 of carbon capture, utilisation and storage for natural gas-based hydrogen production (blue hydrogen). RE = renewable energy; EE = energy efficiency.

Based on IRENA analysis

district energy). The Transforming Energy Scenario is focused on energy-related CO2 emissions reductions, which make up around two-thirds of global greenhouse gas emissions.

Beyond 2050, further efforts will also be needed, and emissions will need to fall to zero. The solutions needed to reduce the remaining 9.5 Gt of energy-related CO2 emissions and 10.4 Gt of energy and process-related CO2 emissions within that decade have yet to be fully analysed, although some solutions are in sight. In the transport sector,  freight,  air  and  shipping  could  be  decarbonised  further  through  a  mix  of electrification, biofuels, carbon-neutral synthetic fuels and hydrogen. In the industry sector, synthetic materials from biomass carbon and CO2 could be used to replace petrochemical products. Zero-carbon steel and chemical industries would need to be achieved, through a combination of a circular economy, and hydrogen and biomass feedstocks.  Most  buildings  would  need  to  be  zero  energy  through  high  efficiency and  building-integrated  renewables.  Smart  and  sustainable  city  and  infrastructure planning would need to become ubiquitous.

Chapter 5 of this report further explores IRENA's Deeper Decarbonisation Perspective (DDP)  to  reduce  the  Transforming  Energy  Scenario  emissions  to  zero  in  the 2050-2060 time frame.

<!-- image -->

## 1.3    An ambitious and yet achievable climateresilient transformative pathway to 2050: What does the transformation entail?

The  transition  to  increasingly  electrified  forms  of  transport  and  heat,  when combined  with  increases  in  renewable  power  generation,  would  deliver  around 60% of the energy-related CO2 emissions reductions needed by 2050. If additional reductions from the direct use of renewables are considered, the share increases to 75%. When adding energy efficiency, the share increases to over 90% of the energyrelated CO2 emissions reductions needed to set the world on a pathway to meeting the Paris Agreement targets.

The total share of renewable energy would need to rise from around 14% of total primary energy supply (TPES) in 2017 to around 65% in 2050. Under the Planned Energy  Scenario,  this  share  increases  to  only  27%,  while  under  the  Transforming Energy Scenario it increases to 65% (Figure 1.5). The renewable energy mix would change,  with  the  share  of  renewables  from  bioenergy  decreasing  from  two-thirds to one-third, and with a much higher share of solar- and wind-based energy in the Transforming Energy Scenario in 2050. TPES would also have to fall slightly below 2017 levels, despite significant population and economic growth.

## Figure 1.5     To meet agreed global climate goals, renewables would need to provide two-thirds of the world's energy supply

Total primary energy supply, renewable and non-renewable share, for the Planned Energy Scenario and the Transforming Energy Scenario, 2017, 2050

## TPES (EJ/yr)

Note: PES and TES (IRENA), 2017 values based on IEA (2019b)

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

In  the  period  from  2010  to  2017,  global  primary  energy  demand  grew  1.1%  per year.  In  the  Planned  Energy  Scenario,  this  is  reduced  to  0.6%  per  year  to  2050, whereas  in  the  Transforming  Energy  Scenario,  the  energy  demand  growth  turns negative and results in a decline of 0.2% per year to 2050 (Figure 1.5).

Scaling  up  electricity  from  renewables  is  crucial  for  the  decarbonisation  of the  world's  energy  system. The  most  important  synergy  of  the  global  energy transformation  comes  from  the  combination  of  increasing  low-cost  renewable power technologies and the wider adoption of electricity for end-use applications in  transport  and  heat  and  hydrogen  production.  To  deliver  the  energy  transition at  the  pace  and  scale  needed would require almost complete decarbonisation of the electricity sector by 2050. The Transforming Energy Scenario sets a pathway to  achieve  an  86%  share  for  renewables  in  the  power  generation  mix  by  2050 (Figure 1.6). On the end-use side, the share of electricity in final energy consumption would increase from just 20% today to almost 50% by 2050. The share of electricity consumed in industry and buildings would double. In transport, it would increase from just 1% today to over 40% by 2050.

Solar  PV  and  wind  energy  would  lead  the  way  in  the  transformation  of  the global  electricity  sector. Wind  power  would  be  a  major  electricity  generation source, supplying more than one-third of total electricity demand. Solar PV power would follow, supplying 25% of total electricity demand (Figure 1.6), which would represent more than a 10-fold rise in solar PV's share of the generation mix by 2050 compared to 2017 levels. In the context of total installed capacity by 2050, much greater capacity expansion would be needed for solar PV (8 519 GW) as compared to wind (6 044 GW).

Hydropower  can  bring  important  synergies  to  an  energy  system  of  the  future. For example, hydropower will play an important role in helping to integrate higher shares  of  variable  renewable  energy  (VRE).  In  the  Transforming  Energy  Scenario, hydropower capacity would increase by two-thirds to 2 147 GW by 2050 compared to current levels. In other words, around 850 GW of new installed capacity is required in the next 30 years. Of that, pumped storage would need to more than double to 325 GW, providing storage and energy flexibility.  In  addition  to  the  new  capacity, an estimated more than 600 GW of the current aging hydropower fleet will require refurbishment. That offers a timely opportunity to modernise hydropower to provide greater flexibility to support the variable sectors.

Hydropower also can play the additional roles of regulating river flows and reducing flooding.  Increasing  hydropower  capacity  does  not  entail  only  building  new  dams; options also exist to upgrade turbines and systems in existing plants and to electrify non-power  dams.  For  new  hydropower  plants,  planners  need  to  consider  local environmental  impacts  and  to  involve  discussion  with  communities  in  the  impacted areas. Hydropower plants will need operational changes that reflect changing power system needs, including faster and more frequent ramping, and planning practices that include evaluating the impacts of climate change on water supply and reservoir storage requirements. Due to longer planning cycles for hydropower dams, policy makers and planners would need to start thinking now about new projects. With enabling policies, market  conditions,  common  frameworks  to  scale  investments  and  well-prepared projects, hydropower will be one of the key technologies in coming decades.

T

H

E

R

O

A

D

M

A

P

T

O

2

0

5

0

Figure 1.6     Solar, wind and other renewable power generation until 2050 Breakdown of electricity generation and total installed capacity by source, 2017-2050

<!-- image -->

<!-- image -->

Note: PES and TES (IRENA), 2017 values based on IEA (2019b)

Notes: CSP = concentrating solar power;

TWh = terawatt-hour.

<!-- image -->

## Box 1.3 OVERVIEW OF POWER SYSTEM FLEXIBILITY IN THE ENERGY TRANSFORMATION

A dispatch of the power system considered in the Transforming Energy Scenario was simulated for the year 2050 to further analyse the operation of the global power system developed by IRENA and to provide insights for the 2050 power system based on IRENA's energy scenarios.

Hourly dispatch of the global system was analysed for the whole world (at the national level for G20 countries, and otherwise regionally in line with the geographic disaggregation of the present report),  along  with  national/regional  renewable  resource  and  demand  profiles  as  well  as  unit commitment and dispatch constraints of generators such as minimum stable levels and ramping speed. This makes it possible to explore how such a system would work in terms of unit cycling, system ramping, and curtailment of VRE, and to assess how the different flexibility  resources across the power system contribute to the operation of the system, as illustrated in Figure 1.7.

Figure 1.7     Hourly electricity dispatch in 2050: No major system flexibility issues One-week dispatch of the UK power systems showing how select technologies balance demand and supply with large shares of solar and wind in 2050

GLYPH&lt;127&gt;

<!-- image -->

The  analysis  revealed  that  there  are  no macroscopic flexibility issues that lead to significant unserved energy in the power system  in  any  country  or  region,  and that  curtailments  of  variable  renewable wind and solar power are limited. While such findings are encouraging, they must be  considered  within  the  limitations  of modelling  that  assumes  no  transmission constraints at the sub-national level, which is  already  a  challenge  in  some  countries. Such high-level representation means that VRE  curtailment  and  unserved  energy demand are inherently underestimated and are only present in modelling when quite severe.  To  compensate  for  this,  pumped hydro was not considered in the analysis, as a lack of sub-national  transmission constraints would lead to overly optimistic results  driven  by  high  use  of  the  large pumped  hydro  capacity  existing  today and  additional  expected  capacity  in  the Transforming Energy Scenario.

The main sources of flexibility to achieve  a  system  with  low  curtailment and negligible unserved energy are: large-scale deployment of EVs with a combination  of  smart  charging  and vehicle-to-grid capacities, hydrogen production using electrolysis, battery storage and demand response. Interplay among different flexibility options such as these is fundamental; some are  complementary  ( e.g. , batteries  and hydrogen), but most will compete against each other, such as vehicle-to-grid, demand-side management and batteries, as  found  in  this  analysis.  The  analysis shows  that  the  energy  transformation requires not just technology deployment, but also the integration of different technologies.

The  results  of  this  analysis  reveal  that most technical solutions for an operable 2050  Paris-compliant  power  system  are available today. For some of the solutions that  remain  on  the  horizon  ( e.g. , low inertia/synthetic inertia operations), a variety  of  technical  measures  are  being trialled in front-runner countries. However, additional challenges may appear when  moving  beyond  the  Transforming Energy Scenario, from an 86% to a 100% renewable  power  system.  A  completely decarbonised  power  system  will  need new solutions, some of which are under discussion ( e.g. , seasonal storage enabled by green gas from renewable power), to close this gap.

IRENA's model-based analysis, performed  using  the  commercial  power system  software  PLEXOS,  shows  how flexibility  can  make  a  Paris-compliant power  system  operable and  how  such operations are likely to look by mapping potential  challenges  that  need  to  be addressed  to  make  this  happen,  from market and regulatory design to control of  distributed  assets  in  close-to-real-time.

Due  largely  to  increased  renewable  electrification  and  direct  renewables  use, the  share  of  renewable  energy  in  total  final  energy  consumption  (TFEC)  would also  rise  considerably. The  Planned  Energy  Scenario  sees  an  increase  in  the share  of  renewables  in  TFEC  from  17%  in  2017  to  25%  by  2050.  The  Transforming Energy Scenario results in a much higher share of 66%. Therefore, more than a sixfold  acceleration  in  the  percentage  point  (ppt)  increase  in  the  renewable  energy share  would  be  needed  (from  around  0.25  ppt/yr  increase  in  the  Planned  Energy Scenario, to almost 1.5 ppt/yr) to raise the overall share from 17% to 18.5% in the first year and then incrementally to reach 66% in 2050 (Figure 1.8).

## Figure 1.8     Renewable electricity: The world's largest energy carrier by 2050

Breakdown of total final energy consumption by energy carrier in 2017 and in the Transforming Energy Scenario 2050 (EJ)

## TFEC (%)

<!-- image -->

The energy intensity of the global economy would fall two-thirds by 2050 in the Transforming Energy Scenario. In recent years, energy intensity has been improving at around 2.3% per year; however, it is projected to have decreased to just above 1% in 2018. Nonetheless, the Planned Energy Scenario projects that this will accelerate to  2.4%  per  year.  The  Transforming  Energy  Scenario  results  in  an  energy  intensity improvement of 3.2% per year (Figure 1.9). Energy intensity improvements are driven by electrification, renewable energy and energy efficiency.

## Figure 1.9     Energy intensity improvement rate: 3.2% increase needed yearly

Energy intensity improvement and its contributions from Planned Energy Scenario to the Transforming Energy Scenario, 2017-2050

<!-- image -->

Scenario

Note: The categories listed in the energy intensity improvement represent an aggregated sum of measures in power and end-use sectors under each technology option. 'Renewables' implies energy intensity improvements achieved with respect to deployment of renewable technologies in the power sector (wind, solar PV, etc.) and in end-use direct applications (solar thermal, etc.). 'Energy efficiency' contains efficiency measures deployed in the industry, buildings and transport sectors ( e.g. ,  improving insulation of buildings; more efficient appliances, etc.). Energy efficiency also includes structural changes that encompass mode shifts, such as the service sector increasing share in GDP and consuming less energy compared to other industrial sectors. 'Electrification' denotes electrification of heat and transport applications such as deploying heat pumps and EVs. The Planned Energy Scenario already considers some improvements due to structural changes, but in the Transforming Energy Scenario, additional reductions are achieved.

Based on IRENA analysis

<!-- image -->

## Box 1.4     LECTRIFICATION WITH RENEWABLES: E DRIVING THE TRANSFORMATION OF ENERGY SERVICES

A far-reaching energy transition is required to address the urgent need to combat climate  change  and  to  develop  sustainably. In  this  transition,  clean  electricity  will become the principal  fuel,  combined  with  'smart'  digital  technologies  that  make  it possible to take full advantage of the growing amounts of cheap renewable power.

Electrification  with  renewables  unlocks  the  potential  synergies  between  major increases in the use of electricity and renewable power generation by co-ordinating their  deployment  and  use  across  demand  sectors: power,  transport,  industry  and buildings. Costs of renewable electricity, namely from wind and solar PV, have continued to decline rapidly and are set to fall further as installed costs drop and performance continues to improve, making these technologies competitive compared to all fossil fuel generation sources.

Thanks to its versatile nature as an energy carrier that can be used for almost all enduses, electricity represents a low-cost option to decarbonise the energy sector. At the same time, the electricity generated by renewables can vary depending on prevailing weather conditions and having a high share of VRE in a power system poses increased operational challenges.

Electrification with renewable energy strategies meets these emerging operational challenges by looking beyond the generation side of the power system and tapping all available sources of flexibility. This includes the use of smart digital devices, information technologies, active demand management, energy storage, network interconnections and  power-to-X  carriers.  As  such,  smart  electrification  with  renewables  creates  a virtuous cycle, where electrification drives new uses and markets for renewables, which then accelerates the switch to electricity for end-uses, creating more flexibility and thus driving further renewables growth and technological innovation. Growth and innovation also reduce costs and create additional investment and business opportunities.

In  addition,  sector  coupling  would  make  a  significant  contribution  to  climate  goals (BNEF, 2020). IRENA's work on the landscape of innovations shows how sector coupling opens new flexibility opportunities for integrating VRE into the grid (IRENA, 2019j).

The shift to renewable energy could reduce CO2 emissions from the power sector by 64% compared to the Planned Energy Scenario ,  while deep electrification of the end-use sectors could reduce emissions from buildings, transport and industry by 25%, 54% and 16%, respectively.  As  a  result,  as  seen  in  Figure  1.10,  the  overall  impact  of electrification  with  renewables would reduce total energy sector emissions by more than 60% compared to the Planned Energy Scenario. Adding direct use of renewable energy  (such  as  solar  thermal  for  heating  or  biofuel  for  transport)  and  efficiency measures would achieve emissions reductions of more than 90%, which is compatible with the well-below 2 °C climate goal established in the Paris Agreement.

Figure 1.10     Electrification with renewables: Ensuring 60% lower energy-related CO2 emissions in 2050

Transforming Energy Scenario CO2 reductions from electrification with renewables vs. other reduction measures in 2050

€

GLYPH&lt;129&gt;

<!-- image -->

GLYPH&lt;129&gt;

GLYPH&lt;143&gt;

Based on IRENA analysis

<!-- image -->

## Box 1.5     MART CHARGING FOR ELECTRIC VEHICLES S

The advent of electric vehicles promises to be a game changer for the world's shift to sustainable energy and particularly to renewable power generation. Along with transforming the transport sector, EVs present a viable opportunity to introduce much higher shares of renewables into the overall power generation mix. Such developments offer a tantalising prospect - particularly for cities - to decarbonise transport while also cutting air  and  noise  pollution,  reducing  fuel  import  dependence and adopting new approaches to urban mobility.

Steady  cost  reductions  for  renewable  power  generation  make  electricity  an attractive  low-cost  energy  source  to  fuel  the  transport  sector. Scaling  up  EV deployment also represents an opportunity for power system development, with the potential  to  add  much-needed  flexibility  in  electricity  systems  and  to  support  the integration of high shares of renewables.

Some regions, such as the European Union, are decisively promoting electromobility. Some  EU  countries  have  ambitious  objectives  to  phase  out internal combustion engine sales by 2030-2040. Further, in April 2019 the European Parliament  and  the  Council  adopted  Regulation  (EU)  2019/631,  which  sets  CO2 emissions  performance  standards  for  new  passenger  cars  and  light  commercial vehicles in the region after 2020. From 2021, the EU fleet-wide average emissions target for new cars will be 95 grams of CO2 per kilometre. EVs are now the only available option to comply with this limit, but the electricity fuelling the cars must

Figure 1.11     Low-cost electricity for transport Total electric cars between 2010 and 2050 in the Transforming Energy Scenario (Millions)

&lt;

<!-- image -->

Note: 2019 data based on Spiegel (2020)

be renewable. Therefore, EV deployment must go hand in hand with more rapid penetration of renewables in the electricity mix.

Cars today, including EVs, typically spend around 95% of their lifetime parked. These idle  periods,  combined  with  battery  storage  capacity,  could  make  EVs  an  attractive flexibility  solution  for  the  power  system.  Each  EV  could  potentially  become  a  micro grid-connected storage unit that provides a broad range of services to the system. On the other hand, the impact of uncontrolled charging on peak demand can be great. Simultaneous and uncontrolled charging of EVs during the mornings or evenings may exacerbate stress on the distribution grid and increase peak loads. While the growth in total electricity demand may be marginal, the increase in loads may require large investments to reinforce local grids. Smart-charging approaches, which adapt charging cycles via dynamic pricing and digital technologies, would therefore be crucial. They can reduce the distribution grid investments needed for the uptake of EVs between 40% to 90% based on country and grid conditions.

<!-- image -->

## Figure 1.12     Smart charging: System-level and local flexibility via electric vehicles

Range of flexibility services provided by electric vehicles

GLYPH&lt;141&gt;

<!-- image -->

Source: IRENA (2019j)

## Box 1.5     SMART CHARGING FOR ELECTRIC VEHICLES (continued)

Figure 1.13     Technologies, business models and regulatory frameworks for EV smart charging

Impact of electric vehicle smart charging on the electricity grid

GLYPH&lt;129&gt;

<!-- image -->

,

ˆ

Source: IRENA (2019j)

€

GLYPH&lt;129&gt;

## Smart charging could provide flexibility at both the system and local levels.

At the system level, smart charging could facilitate balancing in the wholesale market.  Depending  on  the  type  of  smart  charging,  the  EV  charging  patterns could be controlled to flatten peak demand, fill load valleys and support realtime balancing of the grid by adjusting their charging levels. Also, by injecting electricity back to the grid, EVs could provide ancillary services to transmission system operators. At the local level, smart charging could help distribution system operators manage congestion and could help customers manage their energy consumption and increase their rates of renewable power self-consumption.

Emerging innovations in smart charging for EVs span not just technologies but also business models and regulatory frameworks. These will be crucial to integrate renewable energy sources while avoiding network congestion. While incentives for smart charging infrastructure are in place, the actual deployment depends on market incentives. The potential is vast: by 2025, the car battery electricity storage capacity on the road may equal more than one-third of the hourly nameplate generation capacity in the EU.

IRENA's innovation outlook on smart charging for electric vehicles investigates the complementarity potential between VRE sources - solar PV and wind power -  and  EVs  and  considers  how  this  potential  could  be  tapped  through  smart charging up to mid-century (IRENA, 2019j).

<!-- image -->

<!-- image -->

## Box 1.6 BIOENERGY

Bioenergy is the largest form of renewable energy in use today, globally accounting for  70%  of  the  renewable  energy  supply  and  for  10%  of  the  total  primary  energy supply. The largest share of bioenergy use is in the industry sector. About one-quarter of the bioenergy is used in the transport sector, mostly in the form of liquid biofuels from crops such as sugar cane and maize. The rest is used for cooking, heating and power, through combustion of feedstocks such as wood and straw.

Cooking  with  biomass  is  done  largely  outside  of  the  modern  energy  sector  in developing  countries. Inefficient  traditional  cookstoves  paired  with  solid  fuels  and kerosene emit indoor smoke that imperils the health of mainly women and children and causes nearly 4 million premature deaths every year. Much of the wood fuel used in  the  stoves  is  collected  in  an  unsustainable  manner  from  local  forests,  which  is  a major driving force of deforestation and forest degradation. Thus, detrimental cooking practices must be replaced with clean, efficient, modern energy-use systems that use improved  cookstoves  fuelled  with  sustainably  produced  bioenergy  such  as  wood, biogas or ethanol (IRENA, 2017a).

Heating  with  biomass  includes  both  high-temperature  process  heat  for  industry and  low-temperature  space  heating  for  homes,  apartments  and  office  buildings. The agro-processing industry gets heat using crop residues from farms, while lumber, pulp and paper industries get heat using wood residues from forests. Buildings can be heated through town-scale district heating systems or building-scale furnaces, both of  which  use  feedstocks  such  as  wood  chips  and  pellets  very  efficiently.  There  is  a large potential to expand wood production through improved management of existing forests, as exemplified in Sweden where the volume of standing trees has doubled over the last century (IRENA, 2019k).

Electricity generation from biomass is most often provided through combined heat and power (CHP) systems. These can be designed to use a wide range of agricultureand forest-derived feedstocks and operate at close to 100% efficiency (IRENA, 2018b). Power production  from  biomass  is  also  relatively  flexible,  so  it  can  help  to  balance output over time on electricity grids with high shares of variable wind and solar power.

An important niche that will need to be efficiently explored is the use of biomass residues  generated  in  bio-based  industries  such  as  pulp  and  paper,  lumber  and timber, and food processing and biofuels. These sectors usually offer large amounts of biomass resources that can be used for energy production. To a large extent, the modern part of those industries already taps into those resources, mostly for electricity and heat generation, in stand-alone applications or co-generation systems. Other less readily available biomass resources are often not used at all. In those situations, specific policies providing incentives for the use of this additional biomass are fundamental.

Transport fuels from biomass would be indispensable for decarbonising the global economy. Transport will become much more electrified, but not everywhere, not in all sectors and not all at once. It follows that there would be a large need for biofuels for several decades to come. While EVs will come to dominate light vehicle fleets and will

be  powered increasingly  by  renewable  electricity,  they  can  only  enter  markets  with well-developed  power  grids  and  charging  infrastructure.  Moreover,  fleets  take  two decades to turn over. Heavy long-distance freight trucks, marine ships and airplanes are unlikely to be fully electrified due to the higher energy density they require. Hence, all forms of biofuels have to be deployed more widely as the immediate climate solution (IRENA,  2020b).  While  technical  and  institutional  challenges  remain  in  scaling  up the deployment of advanced biofuels, conventional biofuels (for example, sugarcane ethanol) have huge potential for increasing production capacity in Africa (IRENA, 2019l).

Bioenergy  should  be  obtained  in  ways  that  are  environmentally,  socially  and economically  sustainable. The  potential  is  enormous  for  cost-effective  bioenergy production on existing farmlands and grasslands, without encroaching on rainforests and in surplus to growing food requirements. Pockets of potential that do not involve carbon-releasing  land-use  change  -  either  direct  or  indirect  -  include  energy  crops grown on land made available by raising food crop yields or reducing food waste, as well as set-aside lands or contaminated lands on which food production is prohibited. They also include biogas from agricultural wastes such as livestock manure and from municipal solid waste, which can reduce emissions of methane. Greater use could be made of food crop residues and forestry residues, while maintaining sufficient residues to enrich the soil and preserve biodiversity (IEA, 2017; IRENA, 2016b).

Bioenergy could bring synergies for enhancing food supply and restoring degraded land. There is excellent potential for farmers to raise wood in an agroforestry approach in  which  nitrogen-fixing  wood  crops  naturally  fertilise  food  crops  planted  alongside them  (IRENA,  2019k).  Short-rotation  wood  crop  cultivation  on  degraded  land  can provide  multiple  socio-economic  and  environmental  benefits,  such  as  enhancing energy  security  without  constraining  food  crops  or  other  land-use  options;  greatly increasing the productivity of the land; providing extra financing incentive that could in turn increase the likelihood of success for land restoration commitments; lightening the burden of women and children collecting firewood over long distances; and generating employment and income, thereby reducing poverty (IRENA, 2017b).

Advanced biofuels need stable regulations and technology development. The vast demand  for  biofuels  in  the  low-carbon  transport  sector  pathway  requires  greater investment, estimated at more than USD 20 billion per year. Regulatory uncertainties are  one  of  the  most  important  barriers  to  ramping  up  the  investments  to  the  level needed. Other barriers are the cost and availability of financing, and the high costs of biofuels production compared to other fuels (IRENA, 2019m).

<!-- image -->

<!-- image -->

<!-- image -->

Even though almost half of final energy use would be sourced from electricity, fuels and other direct uses of energy would still make up half of energy demand. In the transport and industry sectors, the share of electricity would increase to around 40% by 2050, with most of the energy still coming from fuels.

Modern  bioenergy  can  play  a  vital  role  in  the  energy  transition  if  scaled  up significantly. Although  greater  amounts  of  modern  bioenergy,  such  as  liquid biofuels  and  biomass  pellets,  have  been  used  in  recent  years,  its  growth  pace is insufficient to support  the  requirements  of  the  energy  transition.  A  much stronger and concerted effort is needed, particularly in sectors for which bioenergy  could  provide  key  solutions  (shipping,  aviation  and  various  industrial applications). Primary modern bioenergy demand  would grow from around 30 exajoules (EJ) in 2016 to 125 EJ by 2050 in the Transforming Energy Scenario. Liquid biofuels consumption would reach 652 billion litres, up from 129 billion litres in 2016.

Bioenergy  will  have  to  be  sourced  from  sustainable  and  affordable  feedstocks, such  as  agricultural  and  forestry  residues  or  municipal  solid  waste. Inefficient traditional cookstoves emit indoor smoke that imperils the health of mainly women and children. Much of the wood fuel they use is collected on an unsustainable basis from local forests. They must be replaced with clean and efficient modern cookstoves, which must be fuelled with sustainably produced wood or ethanol. There is excellent potential for farmers to raise wood in an agroforestry approach in which nitrogenfixing wood crops naturally fertilise food crops planted alongside them.

<!-- image -->

Renewable  energy  and  energy  efficiency,  in  combination  with  electrification  of heat and transport applications, are the key ingredients to achieve a sustainable energy future. By  2050, renewables (including electricity generated by renewable sources) would dominate the transport and buildings sectors, reaching 57% and 81% of  those  sectors'  total  final  energy  consumption,  respectively.  Renewables  would account for one-quarter of final energy use for industry. In all sectors, electricity would account for the largest share of renewable energy use, complemented by direct uses of biomass, geothermal and solar thermal.

Hydrogen has emerged as an important part of the clean energy mix needed for a  sustainable future. Important  synergies  exist  between  hydrogen  and  renewable energy, as hydrogen can boost renewable electricity market growth and broaden the reach of renewable solutions. Electrolysers can add demand-side flexibility and offer seasonal storage of solar and wind power. Falling costs for hydrogen produced with renewable energy, combined with the urgency of cutting greenhouse gas emissions, have given clean hydrogen unprecedented political and business momentum.

The  energy  transformation  will  require  widespread  and  profound  changes  in all  sectors  of  the  energy  system. Integrated  energy  planning  will  be  required that  combines  a  holistic  perspective  on  energy  system  and  long-term  planning  to successfully achieve the energy transformation and capture its many benefits. The government institutions have important roles to play in ensuring that energy planning involves all key  stakeholders,  including  energy  producers,  energy  consumers, financial  institutions  and  private  investors.  For  instance,  in  the  transport  sector, energy and digital and information technologies infrastructures should be planned in  an  integrated  manner  across  the  sectors,  and  the  necessary  costs  and  taxation systems should be well aligned with the overall energy transition targets and benefits.

Figure 1.14 shows some of the key energy system indicators that can be used to track the progress of the energy transformation.

<!-- image -->

## Figure 1.14     System-wide transformation: Changes in all sectors of energy use

A roadmap to 2050: Tracking progress of key energy system indicators to achieve the global energy transformation

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                                 | 2010                            | Today 2017*/2018/ 2019e**       | Transforming 2030               | Energy 2040                     | Scenario 2050                   | On/Off track                    | Implications                                                                                                                                                  |
|-----------------------------------------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Electrification with renewables                                 | Electrification with renewables | Electrification with renewables | Electrification with renewables | Electrification with renewables | Electrification with renewables | Electrification with renewables | Electrification with renewables                                                                                                                               |
| Share of electricity in final energy consumption (TFEC)         | 18 %                            | * 20 %                          | 29 %                            | 38 %                            | 49 %                            | Off track                       | Focus on electric mobility and electrifying heat in buildings and industry, and on synthetic fuels and feedstocks - see further recom- mendations below.      |
| Renewable energy share in power generation                      | 20 %                            | 26 %                            | 57 %                            | 75 %                            | 86 %                            | Progress                        | Emphasise solar and wind deployment, but also maximise solid biomass and biogas in the niche applications where they make sense.                              |
| Annual solar PV additions                                       | 17 GW/yr                        | GW/yr 93 **                     | GW/yr 300                       | GW/yr 355                       | GW/yr 360                       | Progress                        | Accelerate solar deployment by reinforcing existing policy and market support.                                                                                |
| Annual wind additions                                           | 31 GW/yr                        | GW/yr 60 **                     | GW/yr 200                       | GW/yr 210                       | GW/yr 240                       | Off track                       | Plan for wind industry and required logistics to enable accelerated deployment. Consider the large potential of offshore deployment.                          |
| Passenger electric cars on the road                             | <0.5 mln                        | 7.9 mln **                      | 379 mln                         | 744 mln                         | 1 109 mln                       | Progress                        | Enact measures to support getting electric cars purchasing price down and invest heavily in charging infrastructure.                                          |
| Heat pumps                                                      |                                 | 38 mln                          | 155 mln                         | 259 mln                         | 334 mln                         | Off track                       | Promote public awareness about the advantages of heat pumps and create special lines of finance to project developers that can disseminate the technology.    |
| Hydrogen production with renewable electricity                  |                                 | 0.16 EJ                         | 3 EJ                            | 8 EJ                            | 19 EJ                           | Emerging                        | Find the niches where this makes sense today and support commercial-scale pilot projects.                                                                     |
| Renewable energy in end uses                                    | Renewable energy in end uses    | Renewable energy in end uses    | Renewable energy in end uses    | Renewable energy in end uses    | Renewable energy in end uses    | Renewable energy in end uses    | Renewable energy in end uses                                                                                                                                  |
| Total renewable energy share increase in TFEC relative to today |                                 | ppt/yr 0.2                      | ppt/yr 0.8                      | ppt/yr 1.2                      | ppt/yr 1.7                      | Off track                       | Besides electrification, keep strong focus on solar thermal heating in buildings and liquid biofuels in transport.                                            |
| Solar thermal collectors                                        | mln m2 290                      | mln m2 686                      | mln m2 2000                     | mln m2 3800                     | mln m2 5800                     | Progress                        | Promote public awareness about the advantages of solar thermal and create special lines of finance to project developers that can disseminate the technology. |
| Transport liquid biofuels                                       | bln litres/yr 100               | bln litres/yr 136 *             | bln litres/yr 378               | bln litres/yr 510               | bln litres/yr 652               | Off track                       | Start with long-term, credible blending mandates and increase the use of advanced biofuels for domestic and international shipping and aviation.              |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Note: The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019d; 2019e) which consider developments as of the third quarter of 2019. Today LCOE values are G20 weighted averages.

Note: IRENA analysis and today values based on IRENA (2019d, forthcoming a), GWEC (2020), Spiegel (2020), Global Carbon Atlas (2019), IEA (2019a, 2019b).

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

T

H

E

R

O

A

D

M

A

P

T

O

2

0

5

0

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

|                                                |                                                | Today 2017*/2018/                              | Transforming Energy                            | Transforming Energy                            | Transforming Energy                            | On/Off                                         |                                                                                                                                                                                    |
|------------------------------------------------|------------------------------------------------|------------------------------------------------|------------------------------------------------|------------------------------------------------|------------------------------------------------|------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
|                                                | 2010                                           | 2019e**                                        | 2030                                           | 2040                                           | Scenario 2050                                  | track                                          | Implications                                                                                                                                                                       |
| Energy efficiency                              |                                                |                                                |                                                |                                                |                                                |                                                |                                                                                                                                                                                    |
| Energy intensity improvement rate              | 1.2% per year 2000-2010                        | 2.3 % 2010-2017 per year                       | 3.3 % 2017-2030 per year                       | 3.3 % 2017-2040 per year                       | 3.2 % 2017-2050 per year                       | Off track                                      | Promote efficiency standards and efficient appliances and create conditions for project developers that speed deploy- ment of energy efficiency technologies.                      |
| Total final energy consumption per capita      | GJ per cap 51                                  | GJ per cap 55                                  | GJ per cap 43                                  | GJ per cap 41                                  | GJ per cap 38                                  | Off track                                      | Promote efficiency standards and efficient appliances and create conditions for project developers that speed deploy- ment of energy efficiency technologies.                      |
| Electricity generation and consumption aspects | Electricity generation and consumption aspects | Electricity generation and consumption aspects | Electricity generation and consumption aspects | Electricity generation and consumption aspects | Electricity generation and consumption aspects | Electricity generation and consumption aspects | Electricity generation and consumption aspects                                                                                                                                     |
| Onshore wind LCOE                              | USD/MWh 80                                     | USD/MWh 55                                     | USD/MWh 50                                     | USD/MWh 45                                     | USD/MWh 40                                     | On track                                       | Promote competitive bidding for solar and wind capacity additions and reform market regulation to accommodate these sources                                                        |
| Solar PV LCOE                                  | USD/MWh 347                                    | USD/MWh 96                                     | USD/MWh 58                                     | USD/MWh 48                                     | USD/MWh 38                                     | Progress                                       | Promote competitive bidding for solar and wind capacity additions and reform market regulation to accommodate these sources                                                        |
| Smart meters in the residential sector         |                                                | of households 25 %                             | of households 50 %                             | of households 77 %                             | of households 82 %                             | Progress                                       | Accelerate smart meter installa- tions in existing buildings and mandate their installation in new buildings.                                                                      |
| Total fossil fuel demand                       | Total fossil fuel demand                       | Total fossil fuel demand                       | Total fossil fuel demand                       | Total fossil fuel demand                       | Total fossil fuel demand                       | Total fossil fuel demand                       | Total fossil fuel demand                                                                                                                                                           |
| Oil demand                                     | mln barrels/ day 87                            | mln barrels/ day 97                            | mln barrels/ day 60                            | mln barrels/ day 41                            | mln barrels/ day 22                            | Off track                                      | Increase liquid biofuels and electrificati- on in the transport sector. Support pilot projects for bio-refineries and synthetic feedstock use for petrochemicals in industry.      |
| Natural gas demand                             | bcm/yr 3307                                    | bcm/yr 3952                                    | bcm/yr 4000                                    | bcm/yr 3400                                    | bcm/yr 2250                                    | Off track                                      | Push renewable hydrogen, solid biomass and electrification in the buildings and industry sectors on top of strong energy efficiency measures.                                      |
| Coal demand                                    | Mtce/yr 4963                                   | Mtce/yr 5458                                   | Mtce/yr 3190                                   | Mtce/yr 2000                                   | Mtce/yr 713                                    | Off track                                      | Stop building new coal power plants and accelerate the retirement of existent coal power facilitieis. Need for new carbon-free iron making processes.                              |
| Total fossil fuel reduction relative to today  |                                                |                                                | -20 %                                          | -41 %                                          | -64 %                                          | Off track                                      | End subsidies for fossil fuels. Support training programmes to retrain displaced workers from fossil fuel industries.                                                              |
| Energy-related CO 2 emissions                  | Energy-related CO 2 emissions                  | Energy-related CO 2 emissions                  | Energy-related CO 2 emissions                  | Energy-related CO 2 emissions                  | Energy-related CO 2 emissions                  | Energy-related CO 2 emissions                  | Energy-related CO 2 emissions                                                                                                                                                      |
| Total CO2 reduction relative to today          |                                                |                                                | -27 %                                          | -48 %                                          | -71 %                                          | Off track                                      | Correct market distortion and price the external costs of CO2. Avoid fossil fuel infrastructure stranding by avoiding unneces- sary investment in new production and distribution. |
| Emissions per capita                           | CO2 per cap 4.3 t                              | CO2 per cap 4.4 t                              | CO2 per cap 2.9 t                              | CO2 per cap 2.0 t                              | CO2 per cap 1.1 t                              | Off track                                      | Correct market distortion and price the external costs of CO2. Avoid fossil fuel infrastructure stranding by avoiding unneces- sary investment in new production and distribution. |

## Box 1.7     TEPPING FORWARD TO A DIGITALISED AND S INTERCONNECTED WORLD

Digitalisation  is  a  key  amplifier  of  the  power  sector  transformation,  enabling  the management of large amounts of data and optimising increasingly complex power systems. Our  increasingly  digitalised  world  is  becoming  ever  more  interconnected. The growing importance of digitalisation in the power sector is partially a consequence of  increasing  decentralisation  ( e.g. ,  increased  deployment  of  power  generators  at  the distribution level) and electrification ( e.g. , the emergence of EVs, heat pumps and electric boilers).  Recent  analysis  from  IRENA  shows  how  all  these  new  small  and  distributed assets on the supply and demand sides are adding complexity to the system and making monitoring, management and control crucial for the success of the energy transition.

Internet of Things in context: Smart grids connecting smart devices from both the demand

Figure 1.15     Internet of Things (IoT) as a driver for power system transformation and supply sides

<!-- image -->

The  Internet  of  Things  (IoT)  is  one  of  the digital technologies that can support the  energy  transition. Simply  put,  the  IoT transforms physical objects into 'smart' devices to collect, communicate, monitor and interpret  information  from  their  surroundings in real time.

IRENA  has  studied  the  role  of  the  IoT  in power  sectors  with  rapidly  increasing  shares of renewables. IoT applications enable 'smart  grids'  by  enhancing  the  visibility  and responsiveness of grid-connected devices. For example, IoT technology has the potential to increase the visibility, flexibility and responsiveness of grid-connected smart assets for the system  operator.  Such  innovations range from sensors that enable data gathering to automated control ( e.g. ,  smart thermostats maximising energy efficiency by adjusting the temperature of consumers' homes depending on whether they are at home).

By connecting energy suppliers, consumers and grid  infrastructure,  IoT  technology  facilitates the  bi-directional  flow  of  data,  the  operation of increasingly complex power systems (which benefit  the  most  from  IoT  integration)  and the establishment of new business models by enabling clients to further monetise the value created by their assets through demand-side management.

IoT  technologies,  and  in  particular  the  data that the devices generate and the automated control they provide, are underpinning a historic transformation that will lead to cleaner, more distributed and increasingly 'smart' grids. Access to more, higher-quality data  across  the  whole  value  chain  enables better decision-support tools (such as artificial intelligence)  and  enables  remote  control  and automated execution of decisions ( e.g. , control of millions of devices with immediate actions, such as algorithm trading or self-driving cars).

The rise of the IoT enables the use of artificial intelligence, powered by big data, as it provides  the  granular  information  needed  to feed machine learning algorithms. Blockchain is  another digital technology that has a role to play in complex power systems , decreasing transaction costs by  managing  data  more openly and securely while automating transactions via smart contracts.

## By  2025,  75  billion  devices  worldwide  are expected to be Internet connected, providing

a wealth of information to consumers , manufacturers and utility providers. The benefits  of  the  IoT  are  manifold,  but  despite these benefits, IoT technology still faces serious challenges that need to be overcome before widespread implementation is possible. The biggest challenges are the reliability of the technology,  data  privacy  and  cybersecurity. These challenges could be overcome through effective collaboration among power and information technology companies, policy makers  and  regulators,  and  end-users.  The explosion  of  data  generated,  due  in  part  to the proliferation of IoT devices, will power new technologies and unlock new industries in the coming years and decades, leading the way to a renewable-powered future (IRENA, 2019o).

<!-- image -->

<!-- image -->

<!-- image -->

## Box 1.8     CENARIOS COMPARISON S

Beyond  IRENA's  Transforming  Energy  Scenario,  several  other  scenarios  have recently  been  published  to  explore  transition  pathways  for  the  energy  system  in the coming decades. These include, for comparison, one recent 'forecast' scenario, DNV-GL's Energy Transition Outlook 2019 (DNV GL, 2019); one business-as-usual (BAU) scenario,  McKinsey's  New  Global  Energy  Perspectives  2019  (McKinsey,  2019);  and seven decarbonisation scenarios that claim compatibility with Paris Agreement targets: the IEA's 2019 'SDS' scenario (IEA, 2019a), Shell's 2018 'Sky' scenario (Shell, 2018), Greenpeace's 2015 'Advanced' scenario (Greenpeace, 2015), Equinor's 2019 'Renewal' scenario (Equinor, 2019), the scenarios in the 'Achieving the Paris Climate Agreement Goals' report from  the Institute for Sustainable Futures at the University of Technology Sydney (UTS-ISF, 2019),  and  the  'Below  1.5°C'  and  '1.5°C  High'  scenarios  from  the Intergovernmental Panel on Climate Change (IPCC, 2018).

All of the scenarios examined, even when consistent with the Paris targets according to the scenario authors, show different visions of the future. This is not surprising, as it  reflects the complexity and uncertainties in the energy transition and the different approaches and assumptions regarding the development of renewable energy, as well as the different combinations of electrification and emissions reductions strategies and overall carbon budgets.

Figure 1.16 shows the wide range of results regarding the degree of electrification and the depth of long-term decarbonisation realised by the scenarios considered.

The business-as-usual scenario (McKinsey's New Global Energy Perspectives 2019)  estimates  that  the  share  of  electricity  in  total  final  energy  consumption will grow from current levels to around 29% by 2050. Under these same BAU  scenario,  global  energy-related  CO2  emissions  in  2050  would  be  around 27 Gt/year, far from compatible with the objectives of the Paris Agreement.

The recent forecast by DNV GL predicts a much faster transformation of the global energy sector, reaching an electrification share of 45% by 2050 together with global energy-related CO2 emissions of 18 Gt/year in 2050, which, according to the authors, are incompatible with a 2°C pathway, despite the strong degree of electrification. Within the scenarios claiming compatibility with the Paris Agreement, the electrification share in 2050 varies substantially as well, from 31% in the IEA 2019 'SDS' scenario to 52% in the Greenpeace 'Advanced' scenario. With a share of 49% of electrification in 2050, IRENA's Transforming Energy Scenario is on the upper hand of the various forecasts, showing the importance of electrification in the energy transition.

Figure 1.16     Different visions of the future: Scenarios presented in other major energy studies Global energy-related CO2 emissions in 2050 vs. electrification rate in various energy scenarios

Š

Œ

<!-- image -->

Ž

Š

Ž

Ž

Š

Source: DNV GL, McKinsey, Equinor, 2019; IEA, 2019a; Shell, 2018; Greenpeace, 2015

<!-- image -->

## Box 1.8     CENARIOS COMPARISON (continued) S

Figure  1.17  shows  the  relationship  between  energy  demand,  energy  efficiency and share of renewable energy in the scenarios considered. There are two main considerations. First, the scenarios with high renewable energy shares are also the ones with the lowest total primary energy supply. Second, there is a significant difference  between  achieving  the  2  °C  versus  the  1.5  °C  targets.  While  carbon emissions in the energy sector must be drastically reduced to achieve either climate target,  achieving  the  1.5  °C  target  would  also  require  significant  structural  and lifestyle changes.

Figure 1.17     Emerging consensus on the role of renewable power

Shares of renewables in total primary energy in 2040 and 2050 in various climate scenarios

†

<!-- image -->

'

1 IEA SDS 2018 data for 2050 are unavailable, 2040 data are shown. Source: DNV GL, McKinsey, Equinor, UTS-ISF, 2019; IEA, 2019a; Shell, 2018; Greenpeace, 2015

GLYPH&lt;143&gt;

GLYPH&lt;143&gt;

GLYPH&lt;127&gt;

GLYPH&lt;141&gt;

GLYPH&lt;143&gt;

GLYPH&lt;144&gt;

GLYPH&lt;127&gt;

GLYPH&lt;141&gt;

GLYPH&lt;143&gt;

GLYPH&lt;144&gt;

GLYPH&lt;127&gt;

ƒ

'

GLYPH&lt;127&gt;

ƒ

'

GLYPH&lt;143&gt;

‰

GLYPH&lt;144&gt;

Š

GLYPH&lt;127&gt;

GLYPH&lt;143&gt;

## 1.4  Outlook for 2030 and NDC formulation

National Determined  Contributions (NDCs)  are the backbone  of the Paris Agreement, signed  by  the  197  member  states  of  the  United  Nations  Framework Convention on Climate Change (UNFCCC) in 2015. NDCs include mitigation actions, and in most cases adaptation actions as well, that a country can put in place to stay in line with the agreement. The year 2020 represents a significant milestone in global efforts  to  cut  energy-related  CO2  emissions.  As  countries  review  and  update  their NDCs, they could simultaneously raise their ambitions to scale up renewable energy. The new NDC round offers an important chance to strengthen targets for renewables in the power sector and beyond.

Present NDC pledges are far from sufficient to meet climate goals. For  example, within the power sector, current NDC power targets overlook 59% of the potential for renewable electricity deployment in line with the Paris Agreement by 2030. For a  climate-compatible  transformation,  more  extensive  deployment  of  renewable generation capacity, amounting to 7.7 terawatts (TW) (or 3.3 times current global capacity),  could  be  achieved  cost  effectively  and  would  bring  considerable  socioeconomic benefits (Figure 1.18).

Figure 1.18     Nationally Determined Contributions: Currently insufficient to meet Paris Agreement climate goals Renewable energy installed capacity in different scenarios

+

<!-- image -->

+

NDC power targets even fall short of countries' existing strategies and plans. Only 85 countries have included unconditional renewable power pledges in their current NDCs - compared to 135 with non-NDC domestic renewable power targets (either national or sub-national). Aligning the next round of NDCs closely to those real-world targets  could  increase  global  renewable  power  capacity  to  5.2  TW  (or  2.2  times current global capacity) by 2030.

NDCs do not reflect the actual growth of renewable power, with global capacity growing by an average of 8.6% per year since 2015. Implementing  current  NDCs would translate into annual capacity growth of only 4% for 2015-2030, even though annual  renewable  power  growth  already  averaged  5.9%  during  2010-2014.  With current deployment trends, the 3.2 TW foreseen in current NDC power targets for 2030 would already be realised by 2022.

Under the Transforming Energy Scenario, the share of renewable energy in total final energy consumption would rise considerably from around 17% in 2017 to 28% by 2030. This is a much higher increase in renewable share when compared to the Planned Energy Scenario, where the share of renewables in TFEC would increase to only 19% by 2030 (Figure 1.19).

At a sectoral level, the buildings sector could have the highest share of renewable energy in TFEC, and overall renewables could ramp up to a 40% share by 2030, from 35% (when including traditional use of biofuels) or 13% (excluding traditional use of biofuels). (Figure 1.19) Energy efficiency is key and consists mainly of measures such as retrofitting, refurbishing and renovating buildings, and implementing stricter standards for domestic appliances and for emissions from new buildings.

The second highest share would be in the industry sector, where renewables would reach a 29% share by 2030 from 13% in 2017. There is a large potential to improve efficiency  in  the  industrial  sector,  and  the  global  industrial  energy  consumption could be reduced by about a quarter thanks to improvements in industrial processes. Measures to improve efficiency or decrease consumption include setting or mandating minimum  standards  on  energy  efficiency  and/or  on  the  carbon  intensity  of  fuels, adopting  demand-side  management  solutions,  developing  material  recycling  and strengthening waste management.

The transport sector would have the lowest share, but the highest growth, with a 16% share of renewables in TFEC by 2030, compared to only 3% in 2017. Energy efficiency is critical for the transport sector. On the one hand, fuel efficiency can be achieved through the adoption of technologies, such as EVs, plug-in hybrid EVs and gasoline hybrid-electric vehicles, as they all have the potential to reduce petroleum use and greenhouse gas emissions. On the other hand, modal shifting also has a high energy efficiency potential. These shifts include innovative mobility services such as car sharing, increasing connectivity and autonomous driving.

<!-- image -->

Scaling  up  electricity  from  renewables  is  crucial  for  the  decarbonisation  of  the world's energy system. Increasingly, electrification with renewables is seen as a major solution, and the contribution of renewable electricity will be the single largest driver for change in the global energy transformation. The Transforming Energy Scenario sets a pathway to achieve a 57% share for renewables in the power generation mix by 2030, up from 25% in 2017.

The role of electricity  as  an  energy  carrier  will  also  increase,  growing  from  a  20% share of final energy consumption to an almost 30% share in the Transforming Energy Scenario in 2030, with gross electricity consumption increasing 10 times from 25 600 terawatt-hours (TWh) in 2017 to 35 900 TWh in 2030. By 2030 in the Transforming Energy Scenario, one-third of the world's electricity would come from solar and wind power.

Figure 1.19     Renewable energy share needs to grow in all sectors Share of renewable energy in total final energy consumption by end use

in the Transforming Energy Scenario

## Renewable energy share in TFEC (%)

<!-- image -->

Note: TES (IRENA) 2017 values based on IEA (2019b)

Many  countries  recognise  the  need  to  scale  up  renewable  power. To date, 135  countries  have  renewable  electricity  targets  in  their  national  and  sub-national energy  plans,  and  140  NDCs  mention  renewables  in  the  power  sector.  But  only 105 NDCs include quantified targets for renewable electricity (Figure 1.20). To drive the changes needed for a climate-safe future, NDCs must become more ambitious in  2020,  reaching for the levels necessary to meet climate goals and extending to end-uses, such as direct heat and transport.

Renewables provide a readily available climate mitigation and adaptation tool that supports multiple Sustainable Development Goals. With these aims at the forefront, NDCs in 2020 offer an immediate opportunity to strengthen renewable energy targets in the power sector and beyond.

## Figure 1.20     NDCs with targets for renewables: Numbers by region

Number of NDCs with renewables targets

<!-- image -->

Source: (IRENA, 2019b)

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

T

H

E

R

O

A

D

M

A

P

T

O

2

0

5

0

## 1.5  Investment must be redirected

Government plans in place today call for investing at least USD 95 trillion in energy systems over the coming three decades. But  those plans and related investments are not always channelled towards climate-proof systems. The investments must be redirected. To ensure a climate-safe future, they need to flow into an energy system that prioritises renewables, efficiency and associated energy infrastructure.

IRENA's Transforming Energy Scenario shows that cumulative investments of nearly USD 10  trillion  should  be  redirected  from  fossil  fuels  and  related  infrastructure to  low-carbon  technologies  by  2030. Cumulative  investments  in  the  energy system over the period to 2030, including infrastructure and efficiency, would reach USD 60 trillion (Figure 1.21).

Nearly  USD  9.6  trillion  of  cumulative  investments  would  be  needed  to  scale  up renewable  power  generation  capacity  through  2030.  In  annual  terms,  this  would imply  doubling  investments  in  renewable  power  generation  capacity  to  USD  676 billion per year until 2030 compared to USD 289 billion invested in 2018 (FS-UNEP and BNEF, 2019).

Figure 1.21     Energy investments 2016-2030

Cumulative energy sector investments over the period to 2030

## Planned Energy Scenario investments between 2016 and 2030 (USD trillion)

Transforming Energy Scenario investments between 2016 and 2030 (USD trillion)

<!-- image -->

Based on IRENA analysis

<!-- image -->

<!-- image -->

Looking  ahead  to  longer  time  horizons  up  to  2050,  with  a  different  energy investment  mix  and  USD  15  trillion  of  additional  investment,  the  global  energy system  could  become  much  more  climate  friendly,  with  cost-effective  renewable energy technologies underpinned by more efficient use of energy. USD 3.2 trillion - representing around 2% of GDP worldwide - would have to be invested each year to achieve the low-carbon energy transformation. This is around USD 0.5 trillion more than under current plans. While cumulative global energy investments by 2050 would then be 16% higher, their overall composition would shift decisively away from fossil fuels.

Renewables and associated infrastructure account for nearly half of the difference in  total  investment,  with  energy  efficiency  and  electrified  transport  and  heat applications absorbing the rest. Investment to build up renewable power generation capacity needs to be twice as high as currently foreseen, reaching USD 22.5 trillion by 2050 (Figure 1.22).

Energy efficiency requires investments of USD 1.1 trillion per year, more than four times the present level. With solar and wind power on the rise, grid operators need new equipment to make the whole power system operate flexibly. Some of the solutions are market based, while others require investment in modern technology solutions. Quick-ramping thermal generation back-ups, pumped hydro, reinforced transmission and distribution grids, digital control equipment, vastly expanded storage capacity, and demand-side management through heat pumps, electric boilers and behind-themeter batteries are just some of the areas for power system investment.

Climate change impacts will result in high economic costs. More (and more severe) fires,  floods,  droughts  and  extreme  weather  will  take  larger  economic  tolls,  which must be borne in the end by individuals (taxpayers) and governments. In addition, the health costs from pollution are of increasing concern for many cities, particularly in the developing world. The energy transition pathway presented in IRENA's Transforming Energy Scenario will avoid between USD 65 billion and USD 157 billion in additional annual external costs related to climate and air pollution in 2050, costs that would otherwise have to be internalised in the financial system by banks and governments.

In  addition,  delaying  action  on  accelerating  the  energy  transition  will  almost double the amount of stranded assets. Those additional stranded assets will have a value of USD 7 700 billion over the period to 2050 that will have to be written off on the balance sheet of companies, public utilities or governments. As one of the policy measures to reduce stranded assets, countries are already paying for accelerated coal plant closures. Germany's phase-out of coal plants is costing USD 44 billion (Wacket, 2019), for example, while the Netherlands and several US states are absorbing the costs using securitisation bonds.

<!-- image -->

## Figure 1.22     Energy investments 2016-2050

Cumulative energy sector investments over the period to 2050

## Planned Energy Scenario investments between 2016 and 2050 (USD trillion)

## Transforming Energy Scenario investments between 2016 and 2050 (USD trillion)

1

5

<!-- image -->

<!-- image -->

Based on IRENA analysis

## Several innovations are happening in the area of financing clean energy projects:

- ·   Central  banks,  financial  institutions  and  insurance  companies  are  starting  to  take  note  and incorporate climate risk into their financial planning assessments. The Bank for International Settlements  recently  launched  an  open-ended  fixed  income  fund  (Hinge,  2019)  -  a  'green bond fund' for central banks.
- ·   The  International  Monetary  Fund  recently  announced  that  it  would  integrate  environmental risks as part of its economic analysis of counties, and that some countries are at high risk of 'carbon shocks' to their economies (Healy, Marchand, 2019).
- ·   The CEO of Blackrock announced a change in investment strategy, saying that climate change has put the world 'on the edge of a fundamental reshaping of finance' (Fink, 2020).
- ·   Additionally, some groups are starting to talk about trade measures that could be levied on countries that do not adequately address their carbon emissions - for instance, carbon tariffs could be placed on imports from countries that are deemed to be acting too slowly to address emissions.

To help navigate these new and innovative investment waters and to accelerate a shift of finance into climate-friendly technologies, IRENA is working with partners on the Climate Investment Platform (CIP) 1 towards unlocking financial resources for the clean energy transition, particularly in  developing countries. By addressing the key risks and barriers that hinder the scale-up of clean  energy  investment,  CIP  will  accelerate  the  low-carbon  energy  transition  and  promote sustainable growth.

1 For more details, see www.climateinvestmentplatform.com.

3

<!-- image -->

Renewable  energy  technologies  are  at  the  heart  of  the  needed  energy  transition. The roadmap for the transition points to a more sustainable energy system and lays the  foundation  for  achieving  socio-economic  development.  The  energy  transition discourse  has  thus  far  been  largely  technology-oriented  and  disconnected  from the  socio-economic  aspects  upon  which  it  is  built  and  its  long-term  sustainability depends.  A  true  and  complete  transition  includes  both  the  energy  and  the  socioeconomic  system  transition,  and  their  interlinkages.  Therefore,  a  wider  picture  is needed, viewing energy and the economy as part of a holistic system.

Socio-economic footprint analyses (IRENA, 2016c, 2019a, 2020a) have captured an increasingly comprehensive picture of the impact of the energy transition. For these analyses, IRENA has undertaken a macro-econometric approach (via E3ME model) that links the energy system and the world's economies within a single and consistent quantitative framework, and analyses variables such as GDP, employment and welfare (Figure 2.1).  Its results can inform energy system planning, economic policy making, and other policies undertaken to ensure a just and inclusive energy transition at the global,  regional  and  national  level.  Forthcoming  IRENA analysis looks at structural and distributional  impacts  of  transition  pathways,  which  may  become  increasingly relevant in the current global situation.

The socio-economic outcomes are explained through drivers fuelled by the energy transition: changes in investment, changes in trade flows and patterns, and indirect and induced effects, including those triggered by fiscal policy.

Section 2.1 identifies the key drivers of the energy transition's impacts on jobs and skills.  Section  2.2  focuses  on  GDP.  Section  2.3  presents  the  welfare  indicator  and associated impacts.

Figure 2.1 Close interplay between the energy sector and the economy Sketching the socio-economic footprint of the transition

<!-- image -->

<!-- image -->

## 2.1  Jobs and skills

This  section  offers  an  overview  of  insights,  first  for  the  energy  sector  as  a  whole, then for its constituent parts ( i.e. ,  transition-related technologies and conventional technologies). This includes an analysis of drivers of gains and losses, illustrated by four  hypothetical  cases.  Finally,  there  is  an  analysis  of  impacts  in  the  economy  as a whole. All of these observations  contrast the differences in outcomes under the Planned Energy Scenario and the Transforming Energy Scenario.

## JOBS IN THE OVERALL ENERGY SECTOR

Under  the  Transforming  Energy  Scenario,  jobs  in  the  overall  energy  sector  comprising transition-related technologies (renewable energy, energy efficiency, and power grids and energy flexibility 1 ), fossil fuels and nuclear power - could reach 100 million by 2050. Figure 2.2 presents estimates of overall energy sector jobs by 2030 and 2050 under the two scenarios, contrasting developments for segments of the energy sector.

Figure 2.2 Energy sector jobs growth: Reaching 100 million in 2050 Global energy sector jobs under the Planned Energy and Transforming Energy scenarios,

in 2017, 2030 and 2050

<!-- image -->

- 1 Power grids and energy flexibility makes reference to all those elements that provide the flexibility needed to operate a power system with high shares of renewable power, and includes storage, demand management, and the power transmission and distribution grids.

The 100 million jobs figure is 15% more than under the Planned Energy Scenario and 72% greater than the present-day total. But the overall numbers do conceal significant changes in the composition of jobs. New jobs in transition-related technologies and sectors are expected to outweigh job losses in fossil fuels and nuclear energy.

## Transition-related technologies

The evolution of employment in the energy sector as a whole depends not only on the deployment of renewable energy technologies, but on other factors as well. On the one hand, energy efficiency and system flexibility yield more jobs under the Transforming Energy Scenario than under the Planned Energy Scenario. On the other hand, the number of jobs in fossil fuel extraction and power plant operations will decline as the transition progresses under either scenario, challenging the workforce in this sector. This section provides a detailed breakdown of estimated jobs in renewables, followed by the jobs in energy efficiency, and power grids and energy flexibility.

Jobs in the renewable energy sector. The  Transforming  Energy  Scenario  leads  to an  increase  of  renewable  energy  jobs.  Figure  2.3  presents  the  global  evolution  of renewable energy jobs, by technology, from 2017 2  to 2030 and 2050 for both the Planned Energy and Transforming Energy scenarios. The latter would yield close to 30 million renewable energy jobs by 2030 and 42 million by 2050. The 2050 estimate represents a 64% increase over the Planned Energy Scenario.

This is the workforce that will be required to install, operate and maintain the renewable energy capacities projected under the Transforming Energy Scenario. But this large workforce,  with  its  manifold  skills  and  occupational  profiles,  will  not  materialise automatically and a successful transition will depend on appropriate education and capacity building policies.

The projection cited above, as well as the detailed analysis behind it (IRENA, 2020a), is the linchpin of a successful matching of demand for, and supply of, skills. Estimates of how those jobs are likely to be distributed across segments of the value chain, and across economic sectors and occupational groups, can guide governments as they make policy for industrial development and capacity expansion. Energy sector policy makers should consult and co-ordinate closely with the renewable energy industry and with educational institutions.

For a subset of five renewable energy technologies 3 , Figure 2.4 presents an example of this type of information, breaking down the jobs needed in 2050 into segments of the

2 RENA has been monitoring renewable energy jobs since 2011, producing an annual review (IRENA, 2019p) I with updated results. These monitoring results have been used to calibrate the macroeconomic model for the year 2017. Once calibrated, the model allows for filling gaps in the monitoring procedure (technologies and countries without data), providing a full picture of initial renewable energy employment and its forecasted evolution in response to implementation of the energy transition roadmap.

3 The technologies included are solar photovoltaics (PV), solar water heaters (SWH), onshore wind, offshore wind and geothermal, representing a total of around 25 million jobs - about 59% of the total 42 million renewable energy jobs projected for 2050. These are the technologies for which the skill requirements are best known. The analysis draws from IRENA's work on leveraging local capacities (IRENA, forthcoming c, 2018c, 2017e, 2017f). The skill structure for additional technologies can be fleshed out as the leveraging analysis for those technologies becomes available.

value chain and broad occupational groups. Construction and installation dominate the  first  distribution  with  a  47%  share,  while  workers  and  technicians  dominate the  second  with  a  77%  share.  Increasing  the  geographical  granularity  to  focus  on regional results (Chapter 4) affords additional insights into the value chain and skills distributions of the jobs needed to support the transition. Such data is a prerequisite for  transition  policies  that  budget increases in education and training, assess local strengths, and identify tasks and functions that can be successfully localised.

Jobs  in  energy  efficiency: In  2050,  energy  efficiency  could  employ  21.3  million people. This is 3.7 million or 21% more jobs compared to the Planned Energy Scenario. Compared to the current-day situation, the Transforming Energy Scenario will more than double the number of jobs.

Jobs in power grids and energy flexibility: In 2050, 14.5 million people will be working in jobs related to power grids and energy flexibility in the Transforming Energy Scenario. This is 14% more than under the Planned Energy Scenario. Similar to energy efficiency jobs, the number of jobs will more than double compared to the current number of jobs.

Figure 2.3

Renewable energy jobs: Dominated by solar energy technology Global renewable energy jobs for the Planned Energy Scenario and the Transforming Energy Scenario in 2017, 2030 and 2050

Jobs (million)

<!-- image -->

## Figure 2.4

G

L

O

B

A

L

S

O

C

I

O

-

E

C

O

N

O

M

I

C

I

M

P

A

C

T

## Deep-dive analysis: Majority of jobs will be created in construction

## and installation and for workers and technicians

Jobs in selected renewable energy technologies by value chain

segment and occupational category in 2050

Jobs (million)

Based on IRENA analysis

<!-- image -->

## Jobs in conventional technologies

By contrast, the fossil fuel sector would shed jobs.  A projected 22 million jobs under the Transforming Energy Scenario in 2050 would be 8 million below the 30 million under the Planned Energy Scenario, or 27% fewer. Compared to today's employment levels, the sector will lose over 6 million jobs.

Similarly, the nuclear energy sector will offer close to 0.15 million fewer jobs (a 23% reduction)  than  today  and  0.3  million  fewer  (a  42%  reduction)  compared  to  the Planned Energy Scenario in 2050.

Before  moving  on  to  results  for  the  economy  as  a  whole,  it  is  worth  emphasising that  job  trends  in  the  energy  sector  will  vary  with  each  region's  degree  of  fossil fuel dependence, the ambitiousness of its transition plans, regional trade balances associated with sales of transition-related equipment and the relative weight of these factors in each region. Box 2.1 offers four hypothetical cases that illustrate different combinations of job gain and loss within parts of the energy sector, with different net outcomes. Regional insights are provided in Chapter 4 and in the Regional factsheets.

## Box 2.1 DRIVERS OF GAINS AND LOSSES IN THE ENERGY SECTOR

Although  the  Planned  Energy  Scenario leads  to  an  overall  increase  in  energy sector employment,  jobs  will be  lost in some sub-sectors, namely those related  to  fossil  fuels.  The  effects  will vary  depending  on  the  factors  at  play in  a  given  region.  Figure  2.5  illustrates four  cases  in  terms  of  the  employment difference between the Transforming Energy Scenario and the Planned Energy Scenario,  highlighting  the  underpinning factors and transition challenges.

<!-- image -->

Based on IRENA analysis

CASE  1. The  increase  in  the  number  of jobs  in  the  energy  sector  is  higher  than the  increase  in  renewable  energy  jobs alone. This means that the increase in jobs in  the  other  two  technological transition pillars (energy efficiency and energy flexibility) is higher than the loss of jobs in fossil fuels. This is the most favourable situation  for  the  energy  sector,  offering opportunities  for  people  who  lose  their jobs in fossil fuels to find new ones in the energy sector. A smooth transition can be achieved by reducing the dependence on fossil  fuels  and  implementing  ambitious policies  geared towards creating a large number of domestic jobs in renewables, efficiency and flexibility.

<!-- image -->

Figure 2.5     Energy sector job gains and losses: Four cases

<!-- image -->

CASE  2. The  increase  in  the number  of  jobs  in  the  energy sector is positive overall but lower than the increase of jobs in  renewables,  despite  the  loss of jobs in fossil fuels being lower than the increase in the number of jobs in renewables. A higher dependence of the regional economy on fossil fuels, a lower transition  ambition,  or  a  lower number of domestic transitionrelated jobs leads to less favourable results than in Case 1. Although the overall balance in the energy sector is still positive, there  is  a  higher  relative  loss, increasing the challenges for those who lose their jobs to find new ones in the energy sector.

CASE 3. The increase in renewable energy jobs is smaller  than  the  reduction  in fossil fuel employment, but energy efficiency and flexibility still  provide  a  positive  balance in  the  energy  sector.  This  gain in  the  energy  sector  manages to provide job opportunities for  lost  fossil  fuel  jobs,  but  the challenge for labour reallocation is  greater  than  for  Case  1  and Case  2  because  of  the  higher relative weight of the lost jobs. Larger  differences  in  requisite skills contribute to the challenge.

CASE 4. The number of lost jobs in  fossil  fuels  is  greater  than  the number  gained in renewables, efficiency  and  flexibility,  providing an overall negative balance within  the  energy  sector.  This is  the  most  unfavourable  and challenging case, which can arise  in  regions  and  countries that have 1) a labour market heavily dependent on fossil fuels, 2)  low  transition  ambition,  and 3) high dependence on imports of transition-related technologies. In this case, the energy sector does not provide job opportunities for all  who  lose  their  jobs  in  fossil fuels, requiring solutions for a just transition to be found outside the energy sector.

## JOBS IN THE OVERALL ECONOMY

The switch to low-carbon technologies will certainly change the occupational and skills pattern in the energy sector. But beyond the energy sector, the Transforming Energy Scenario will also have economy-wide impacts. These cross-cutting effects come with job gains and losses resulting from multiple interactions within the economy driven by three sets of factors (Box 2.2 and Figure 2.6).

Figure 2.6 shows that global employment under the Transforming Energy Scenario is  0.15%  higher  (an  additional  6.5  million  jobs)  than  under  the  Planned  Energy Scenario.  As  seen,  the  contribution  of  different  drivers  to  the  economy-wide  jobs footprint varies. The investment driver typically exerts its influence at the outset of an installation, and thus makes an initial contribution. Across the entire time period considered, however, changes in consumer expenditure due to indirect and induced effects dominate economy-wide employment impacts.

## Box 2.2 DRIVERS OF ECONOMY-WIDE JOBS AND GDP

The drivers of job and GDP gains and losses include changes in investment and trade, as well as induced and indirect effects:

<!-- image -->

<!-- image -->

<!-- image -->

## CHANGES IN INVESTMENT

This driver concerns the net impact of overall investment  in  the  economy and  includes  the  effect  of increasing transition-related investments (renew-ables, energy efficiency, energy flexibility, grids, etc.) as well as  declining  investments  in conventional energy.

## CHANGES IN TRADE

This driver includes the effects of both energy and non-energy trade. An  increase  in  imports,  or reduction in exports, has a  negative  impact  on  GDP, while a decrease in imports or  increase  in  exports  has the reverse effect.

## NDUCED AND INDIRECT I EFFECTS

This driver captures changes in  consumer  spending  due to consumer  price  effects and fiscal policy. The driver also  includes    changes  in economic  activities  due  to supply chain impacts  arising from payments to producers in  the  supply  chain,  and other effects associated with changes in employment levels or wages for existing employees.

## Figure 2.6 Economy-wide jobs: Increase by 6.5 million

Difference in global economy-wide employment between the

Transforming Energy and Planned Energy scenarios

## Change in employment from Planned Energy Scenario (%)

<!-- image -->

Based on IRENA analysis

The impact of the Transforming Energy Scenario on jobs varies within the energy sector and has implications throughout the economy. This is illustrated in Figure 2.7 with the global increase in employment under that scenario relative to the Planned Energy Scenario at three different levels: in renewable energy, the energy sector as a whole and across the entire economy.

The energy sector gains 13.3 million jobs, which is lower than the 16.3 million jobs gained in renewables alone. While renewables, energy efficiency, and power grids and  energy  flexibility  all  gain  jobs  under  the  Transforming  Energy  Scenario,  the remaining sub-sectors are hit especially hard by the transition. In this case the fossil fuels sub-sector is the clear loser within the energy sector (8.2 million jobs fewer than in the Planned Energy Scenario).

This  is  an  understandable  outcome  of  the  transition,  as  fossil  fuels  and  related technologies  are  expected  to  be  phased  out.  Nonetheless,  the  socio-economic consequences of this phase-out, if not properly addressed, may become barriers to the transition. Awareness of this misalignment is already high in the energy sector, as evidenced by increased calls for just and inclusive transition policies.

Job gains in the energy sector (13.3 million) surpass the number of additional jobs economy-wide  (6.6  million).  This,  too,  is  to  be  expected,  given  that  the  energy transition entails measures that directly affect the energy sector while affecting other parts of the economy less directly. Several dynamics produce these results, including how  overall  investment  is  distributed  across  sectors  of  the  economy,  sectoral  job intensities, and how the transition drivers affect each sector. Another crucial factor is  the  ability  and  size  of  multipliers  in  the  existing  economic  structure  to  support transition-related technologies.

What these results point to is the need for a holistic, just transition policy framework that looks beyond the energy sector since job loss can affect sectors other than fossil fuels.

Figure 2.7 Renewable energy, energy sector and overall economy Global employment job differential in 2050 (increment of jobs from Planned Energy Scenario to Transforming Energy Scenario), by sector

<!-- image -->

Based on IRENA analysis

<!-- image -->

## 2.2  Gross domestic product

GDP is the most commonly used indicator for income and growth. In line with earlier IRENA estimates (IRENA, 2019a), the Transforming Energy Scenario boosts global GDP in 2050 by 2.4% over the Planned Energy Scenario. The cumulative gain from 2019 to 2050 amounts to USD 98 trillion. 4  The gain is influenced by several drivers in the global economy and is illustrated in Figure 2.8. The investment driver contributes most heavily to the gain during the first years of the transition, remaining positive but with a relatively low impact thereafter. The trade driver makes marginal contributions to global GDP gains over the Planned Energy Scenario, given the intrinsic requirement of  global  trade  being  balanced  in  normal  terms.  The  largest  share  of  the  positive global  GDP  results  is  explained  by  changes  in  consumer  spending  in  response  to changes in fiscal policy considered in this analysis. 5

## Figure 2.8 T

ransforming Energy Scenario will boost global GDP Difference in global GDP between Transforming Energy Scenario and Planned Energy Scenario

<!-- image -->

- 4 All U.S. dollar values in this chapter are 2015 constant values.
- 5 Carbon taxation is in line with the Integrated Assessment Model and the 2˚C limit on global warming (IPPC, 2014). The applied revenue recycling policy applied in the analysis assumes government revenue neutrality by balancing the evolution of taxes linked to the transition (carbon taxation, oil royalties) with income taxes. The implications of the revenue recycling policy were discussed in the section on employment.

In  per  capita  annual  terms, 6   the  difference  in  the  gains  realised  under  the  two scenarios  is  USD  367/person-year.  Figure  2.9  compares  this  per  capita  value  with the net overall investment requirement 7  (USD 54/person-year) and the clean energy investment  requirement  (USD  122/person-year).  The  figure  shows  that  additional investment together with appropriate policies, primarily in the clean energy sector, has significant economic effects, contrary to conventional beliefs that climate-related investments will adversely affect the economy.

Figure 2.9 Global per-capita GDP gains outstrip investment costs Per capita annualised GDP values under the Transforming Energy Scenario, using average population for 2019-2050

<!-- image -->

Based on IRENA analysis

6 Using the average world population for the years between 2019 and 2050.

7 The additional investment needed in the overall energy sector is lower than the additional investment needed in the clean energy sector. This is due to the fact that the transformation of the energy sector under the Transforming Energy Scenario entails a reduction of investment in conventional technologies and greater investment in clean energy sector when compared with the Planned Energy Scenario.

## 2.3  Welfare

Jobs  and  GDP  growth,  as  described  above,  are  the  standard  measures  of  socioeconomic analysis.  To  address  concerns  that  these  indicators  do  not  fully  capture whether the quality of life improves due to the energy transition, this section presents a composite indicator that comes closer to measuring the multidimensional nature of welfare improvements (IRENA, 2016c).

The indicator includes economic, social and environmental dimensions aggregated from sub-indicators. Each indicator is derived from two sub-indicators. The economic dimension  is  obtained  from  household  consumption  and  investment  as  well  as employment.  The  social  indicator  consists  of  spending  on  education  and  health impacts from air pollution. The environmental indicator is made up of greenhouse gas emissions and consumption of materials. More detail is provided in Table 2.1.

As measured by this method, global welfare improves faster and further under the Transforming Energy Scenario than under the Planned Energy Scenario, surpassing it by 13.5% by 2050 (Figure 2.10). The social and environmental dimensions predominate, reflecting  the  significant  improvements  in  health  obtained  by  curbing  air  pollution and reducing greenhouse gas emissions.

Figure 2.10 Welfare gains: Influenced by health benefits and emission reduction Global welfare indicator under the Transforming Energy Scenario in

2030 and 2050

<!-- image -->

<!-- image -->

<!-- image -->

## Box 2.3     TRUCTURE OF THE WELFARE INDICATOR S

To construct the welfare indicator used in this analysis, results from the macroeconomic model  are  used  to  create  six  sub-indicators  that  inform  three  welfare  dimensions (economic, social and environmental). Since each sub-indicator has its own units, the six are expressed in terms of the percentage difference between the Transforming Energy Scenario and the Planned Energy Scenario, then weighted equally and aggregated into the overall indicator.

| Dimension       | Sub-indicator               | Detail                                                                                                                                                                                                            | Units                     | Weight in aggregated indicator   |
|-----------------|-----------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------|----------------------------------|
| Economic        | Consumption plus investment | Sum of both household consumption and economy- wide investment ( i.e. , capital formation) in each year and country                                                                                               | Constant 2015 USD         | 1/6                              |
| Economic        | Employment                  | Economy-wide employment in all the 43 economic sectors considered, in each year and country                                                                                                                       | Number of jobs            | 1/6                              |
| Social          | Spending on education       | Public and private spending on education, in each year and country                                                                                                                                                | Constant 2015 USD         | 1/6                              |
| Social          | Health impacts              | Energy consumption in power generation and end use sectors (TJ) differentiated by fuel and multiplied by health externality (USD/TJ) for each fuel from IRENA analysis, in each year and country                  | Constant 2015 USD         | 1/6                              |
| Environ- mental | Greenhouse gas emissions    | Cumulative greenhouse gas emissions (using the global value for the indicator in all countries). Cumulative values are used because they are the ones that relate to the associated externality (climate change). | Tonnes of CO 2 equivalent | 1/6                              |
| Environ- mental | Consumption of materials    | Cumulative use of materials excluding fossil fuels. Cumulative values are used because they are the ones that relate to the associat-ed externality in most cases (depletion of finite resources).                | Gigatonnes                | 1/6                              |

Adapted from IRENA, 2016c

## 2.4  Conclusion

The socio-economic footprint of the energy transition as quantified in the Transforming Energy Scenario conveys a positive message on a global scale. Jobs and GDP growth will be positive while welfare improves significantly (see Table 2.1 for key numbers). When examined at the country and regional levels, however, the socioeconomic footprint  will  vary  more  or  less  widely  from  the  global  footprint,  owing to the variety of socio-economic structures and their complex interactions with the energy transition. The complex challenges also call for local solutions. Likewise, the opportunities offered by the energy transition are unique for each region, as further explained in Chapter 4.

Table 2.1     A roadmap to 2050: Tracking key socioeconomic indicators of the global energy transformation

|                                     | 2019       | 2030        | 2050        |
|-------------------------------------|------------|-------------|-------------|
| Global                              |            |             |             |
| Population (thousands) region-wide  | 7 656137   | 8 379 776   | 9 358 932   |
| GDP (USD 2015)                      |            |             |             |
| GDP (million): PES                  | 83 643985  | 117 717 477 | 214 272 530 |
| GDP (million): TES                  | 85 247 810 | 120 011 802 | 219 366861  |
| GDP changes (million): TES vs. PES  | 1 603826   | 2 294325    | 5 094331    |
| GDP changes (%): TES vs. PES        | 1.92%      | 1.95%       | 2.38%       |
| Per capita GDP (thousand): PES      | 10.93      | 14.05       | 22.89       |
| Per capital GDP (thousand): TES     | 11.13      | 14.32       | 23.44       |
| Employment                          |            |             |             |
| Economy-wide employment (thousands) |            |             |             |
| Employment: PES                     | 3 714 168  | 4051588     | 4238092     |
| Employment: TES                     | 3 721 777  | 4058720     | 4244626     |
| Employment changes: TES vs. PES     | 7 608.94   | 7 132       | 6 534       |
| Employment changes (%): TES vs. PES | 0.20%      | 0.18%       | 0.15%       |

<!-- image -->

<!-- image -->

Table 2.1     A roadmap to 2050: Tracking key socioeconomic indicators of the global energy transformation (continued)

<!-- image -->

Global

2017

2030

2030

2050

2050

(PES)

770

33 255

20 306

20 283

11 507

86121

2.13%

## Energy sector jobs (thousands)

Nuclear power

Fossil fuels

Renewables

Energy efficiency

Energy flexibility &amp; grid

Total

Energy jobs in economy-wide employment (%)

(TES)

696

29 133

29 543

29 189

12 078

100 640

2.48%

(PES)

739

29 878

25 578

17 561

12 721

86478

2.04%

(TES)

430

21 680

41 902

21 265

14 494

99771

2.35%

## Renewable Energy Jobs (thousands)

| Bioenergy                                             | 4371   | 7 154   | 10 890   | 6 998   | 14 090   |
|-------------------------------------------------------|--------|---------|----------|---------|----------|
| Solar                                                 | 4286   | 7 916   | 11 717   | 11 501  | 18 698   |
| Hydropower                                            | 2 389  | 2 747   | 3 013    | 2 569   | 2 759    |
| Wind                                                  | 1 160  | 2 374   | 3 744    | 4355    | 6 057    |
| Geothermal                                            | 80     | 113     | 156      | 150     | 238      |
| Ocean                                                 | 1      | 2       | 25       | 4       | 60       |
| Total                                                 | 12 288 | 20306   | 29543    | 25 578  | 41 902   |
| Renewable energy jobs in energy-sector employment (%) |        | 23.58%  | 29.36%   | 29.58%  | 42.00%   |

## Job differential in 2050 (thousands)

Economy-wide

Changes in conventional energy (A)

Changes in transition related technologies (B)

Net energy sector jobs (A+B)

6 534

-8 507

21 801

13 294

560

28 085

12 288

9 507

7,439

57 879

| Technology jobs (thousands)   | Technology jobs (thousands)   | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      | 14 132                        | Construction & installation       | 11 639                            | Workers & technicians                   | 19 044                                  |
| Solar water heaters (SWH)     | 4249                          | Manufacturing                     | 7 061                             | Experts                                 | 2 541                                   |
| Onshore wind                  | 5 048                         | O&M                               | 5 976                             | Engineers & higher degrees              | 2 246                                   |
| Offshore wind                 | 1 009                         | Biofuel supply                    | -                                 | Marketing and administrative            | 846                                     |
| Geothermal                    | 238                           |                                   |                                   |                                         |                                         |
| Total                         | 24676                         |                                   | 24676                             |                                         | 24676                                   |

<!-- image -->

| Welfare improvement (%): TES vs. PES   | 2030   | 2050   |
|----------------------------------------|--------|--------|
| Indicator/year                         |        |        |
| Economic                               | 0.34   | 0.49   |
| Social                                 | 4.53   | 8.70   |
| Environmental                          | 2.03   | 4.29   |
| Total                                  | 6.9    | 13.5   |

<!-- image -->

<!-- image -->

<!-- image -->

This  chapter  provides  a  regional  perspective  on  the  implications  of  the  energy transformation for ten broad regions spanning the globe. While there may be a single global  climate  objective,  different  energy  transformation  pathways  need  to  be considered and solutions tailored to fit regional circumstances.

These regions were defined based on geographical grouping, without consideration of socio-economic, political or cultural aspects. Any regional split tends to be somewhat arbitrary  and  could  hide  important  differences  among  countries  that  affect  the implications of the energy transformation in each case. Even so, examining IRENA's energy transformation results at the regional level can offer valuable insights. As the sections that follow demonstrate, important distinctions exist between regions.

<!-- image -->

## 3.1  Context and characteristics

## POPULATION

Figure 3.1     World population growth: From 7.5 billion today to over 9.7 billion by 2050 Expected population trends from 2018 to 2050

<!-- image -->

IRENA anlaysis based on E3ME.

Note: Oceania including PNG.

Most growth is expected in the Rest of Asia and in Sub-Saharan Africa. Small growth is expected in Southeast Asia, the Middle East and North Africa, Latin America and the Caribbean, North America and Oceania, whereas East Asia, the EU and the Rest of Europe show declining numbers.

<!-- image -->

R

E

G

I

O

N

A

L

E

N

E

R

G

Y

T

R

A

N

S

F

O

R

M

A

T

I

O

N

S

:

T

E

C

H

N

O

-

E

C

O

N

O

M

I

C

C

O

N

T

E

X

T

## GDP

Figure 3.2     Uneven wealth distribution among regions GDP PPP per capita, deviation from global average, in 2018

<!-- image -->

Note: Analysis based on 2018 values (World Bank Group, 2019a).

Distribution of wealth is unequal. In North America, the EU and Oceania, per capita GDP is well above the global average, whereas Southeast Asia, the Rest of Asia and Sub-Saharan Africa rank at the bottom. The contrast is more relevant in the face of demographics, as 78% of the population growth is expected to come from the poorest regions.

<!-- image -->

G

L

O

B

A

L

R

E

N

E

W

A

B

L

E

S

O

U

T

L

O

O

K

## ENERGY CONSUMPTION AND ACCESS TO ELECTRICITY AND CLEAN COOKING FUELS

Figure 3.3     Energy consumption per capita: Rising in step with wealth and access Energy consumption per capita and access to clean cooking and electricity

<!-- image -->

Note: Access to electricity, 2017 values (World Bank Group, 2019b), access to clean cooking, 2016 values (World Bank Group, 2019c), TFEC, 2017 values (IEA, 2019b).

Richer regions display the highest energy consumption per capita, and the three poorest regions the lowest. Similar patterns can be seen for access to clean cooking fuels  and  electricity,  although  most  regions  display  electricity  access  rates  above 90%. The notable exception is Sub-Saharan Africa, where electricity access is only 45%, well below the world average of 89%.

<!-- image -->

## CO2 EMISSIONS IN THE ENERGY SECTOR

Figure 3.4     Energy-related CO2 emissions: current level in regions Energy-related CO2 emissions, per capita and total, in 2018

<!-- image -->

Note: Analysis based on 2018 values (Global Carbon Atlas, 2019).

Low access to energy results in low emissions per capita. Total emissions are highly influenced by total population. Some regions with rather low emissions per capita become prominent in total emissions because of their large populations.

<!-- image -->

G

L

O

B

A

L

R

E

N

E

W

A

B

L

E

S

O

U

T

L

O

O

K

## FOSSIL FUEL DEPENDENCE

## Figure 3.5     Fossil fuel imports and exports: Net balance by region

Energy security measured as the proportion of net imports of fossil fuels in total primary fossil fuel energy supply, in 2017

<!-- image -->

Note: Analysis based on 2017 values (IEA, 2019b).

Most regions are currently net exporters of fossil fuels (negative bars above), with Southeast  Asia  and  North  America  practically  at  zero. In  a  carbon-constrained world, these net exporters would stand to lose if they are not prepared for the drop in global fossil fuel demand. Conversely, the Rest of Asia, East Asia and the EU could benefit greatly from reducing their external dependence on fossil fuels.

<!-- image -->

## ENERGY-INTENSIVE INDUSTRIES

Figure 3.6     Energy-intensive industries: High demand concentrated in East Asia Regional share in global energy consumption of energy-intensive industries,

in 2017

<!-- image -->

Note: Analysis based on 2017 values considering iron and steel, chemical and petrochemical, non-metallic minerals, non-ferrous metals, food, tobacco and paper industries (IEA, 2019b).

East  Asia  concentrates  almost  50%  of  the  global  energy  demand  in  energyintensive industries (such as iron and steel, chemical and petrochemical, non-ferrous metals  and  non-metallic  minerals).  These  industries  correspond  to  an  important share of global greenhouse gas emissions and are among the most challenging to decarbonise.

<!-- image -->

G

L

O

B

A

L

R

E

N

E

W

A

B

L

E

S

O

U

T

L

O

O

K

## URBANISATION AND URBAN AIR QUALITY

## Figure 3.7     Urban air quality: A major concern in fast-growing cities

Urbanisation and urban air quality

<!-- image -->

Note: Urbanisation, 2018 values (World Bank Group, 2019d), air quality (based on PM 2.5 concentration), 2016 and 2017 values (WHO, 2019).

In all but three regions (the Rest of Asia, Sub-Saharan Africa and Southeast Asia), more than 60% of the population lives in cities. This makes urban air quality a major concern. With expanding populations and urbanisation rates, a shift to renewables would help curb the most critical instances of urban air pollution, improving health conditions and quality of life.

<!-- image -->

## COST-COMPETITIVENESS

## Figure 3.8     Renewable electricity: Cheaper than average electricity price in most regions

Renewable electricity costs compared to electricity prices

<!-- image -->

Note: Costs denote 2018 values (IRENA, 2019i), electricity prices denote 2019 values (GlobalPetrolPrices, 2019).

Renewable electricity costs are higher than electricity prices, on average, in only 2 of the 10 regions (the Middle East and North Africa region and the Rest of Europe). In all other regions, renewable costs are at least 20% lower than current electricity prices. This shows the potential for renewables to reduce prices of electricity.

## 3.2  Priorities and drivers

Figure  3.9  outlines  key  indicators  showing  the  status  of  the  energy  transition  in each  region.  The  indicators  reveal  how  each  region  has  drivers  for  embracing  the transformation, ranging from energy security, to emissions reductions and better air quality, to universalisation of energy access and economic development. This section provides more detail about the characteristics of three clusters of regions and some of the measures, technologies and changes that are needed to accelerate the energy transformation.

G

L

O

B

A

L

R

E

N

E

W

A

B

L

E

S

O

U

T

L

O

O

K

Figure 3.9     Planned Energy Scenario: Different prospects for each region

Status and key indicators for the energy transition in different regions in the Planned Energy Scenario

Local pollution

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Regions                      | Population (million)   | TFEC per capita (GJ per capita)   | (based on number of indicated cities) • Good • Moderate • Unhealthy   | Energy-related emissions (tCO 2 per capita)   | Energy-related emissions (tCO 2 per capita)   |   GDP per capita (PPP, constant 2011 $) 2018 |    |
|------------------------------|------------------------|-----------------------------------|-----------------------------------------------------------------------|-----------------------------------------------|-----------------------------------------------|----------------------------------------------|----|
| East Asia                    | 1618 2018 1515 2050    | 2017 62                           | 0% 260 Cities                                                         | 2018 6.8                                      | 2050 3.3                                      |                                        17968 |    |
| EU-28                        | 512 2018 497 2050      | 2017 88                           | 23% 1 941 Cities                                                      | 2018 6.4                                      | 2050 3.9                                      |                                        38270 |    |
| Latin America                | 465 2018 536 2050      | 41 2017                           | 7% 91 Cities                                                          | 2018 2.3                                      | 2050 3.1                                      |                                        13426 |    |
| Middle East and North Africa | 484 2018 677 2050      | 2017 51                           | 0% 80 Cities                                                          | 2018 5.7                                      | 2050 5.9                                      |                                        17825 |    |
| North America                | 492 2018 591 2050      | 2017 163                          | 82% 284 Cities                                                        | 2018 12.8                                     | 2050 11.5                                     |                                        45173 |    |
| Oceania                      | 42 2018 52 2050        | 100 2017                          | 96% 28 Cities                                                         | 2018 10.8                                     | 2050 11.8                                     |                                        32889 |    |
| Rest of Asia                 | 2070 2018 2601 2050    | 2017 21                           | 0% 119 Cities                                                         | 2018 1.9                                      | 2050 2.8                                      |                                         7330 |    |
| Rest of Europe               | 2018 2050 231 208      | 2017 99                           | 28% 123 Cities                                                        | 2018 8.8                                      | 2050 12                                       |                                        22742 |    |
| Southeast Asia               | 642 2018 749 2050      | 2017 28                           | 0% 35 Cities                                                          | 2018 2.3                                      | 2050 4.1                                      |                                        11642 |    |
| Sub-Saharan Africa           | 1041 2018 1947 2050    | 2017 18                           | 50% 4 Cities                                                          | 2018 0.7                                      | 2050 0.6                                      |                                         3519 |    |

Note: PES based on IRENA; population, IRENA analysis based on E3ME (Oceania including PNG) for emissions per capita, population estimations based on IRENA analysis were used; TFEC, 2017 values (IEA, 2019b); local pollution (based on PM 2.5 concentration), 2016/2017 values (WHO, 2019); emissions, 2018 values (Global Carbon Atlas, 2019); GDP PPP (World Bank Group, 2019a); access to electricity, 2017 values (World Bank Group, 2019b), access to clean cooking, 2016

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

R

E

G

I

O

N

A

L

E

N

E

R

G

Y

T

R

A

N

S

F

O

R

M

A

T

I

O

N

S

:

T

E

C

H

N

O

-

E

C

O

N

O

M

I

C

C

O

N

T

E

X

T

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Energy access (% population with access to Clean Cooking and Electricity )   | Energy access (% population with access to Clean Cooking and Electricity )   | Renewables Competitiveness (LCOE - price)/price Non-competitive Competitive   | Fossil fuel dependence   | Resource availability (Generation in PES by 2050 over technical potential)   | Resource availability (Generation in PES by 2050 over technical potential)   | Resource availability (Generation in PES by 2050 over technical potential)   |
|------------------------------------------------------------------------------|------------------------------------------------------------------------------|-------------------------------------------------------------------------------|--------------------------|------------------------------------------------------------------------------|------------------------------------------------------------------------------|------------------------------------------------------------------------------|
|                                                                              | 89% 99%                                                                      |                                                                               | high                     | 4.6%                                                                         | 13.5%                                                                        | 10.3% 9.4%                                                                   |
|                                                                              | 95% 100%                                                                     |                                                                               | very high                | 3.0%                                                                         | 1.7%                                                                         | 2.8% 11.4%                                                                   |
|                                                                              | 87% 98%                                                                      |                                                                               | low                      | 0.7%                                                                         | 1.3%                                                                         | 0.7% 4.8%                                                                    |
|                                                                              | 89% 98%                                                                      |                                                                               | very low                 | 0.1%                                                                         | 1.4%                                                                         | 0.4% 3.9%                                                                    |
|                                                                              | 93% 100%                                                                     |                                                                               | medium                   | 2.4%                                                                         | 4.5%                                                                         | 0.5% 1.8%                                                                    |
|                                                                              | 72% 89%                                                                      |                                                                               | very low                 | 0.2%                                                                         | 6.7%                                                                         | 0.1% 2.9%                                                                    |
|                                                                              | 46% 91%                                                                      |                                                                               | high                     | 2.3%                                                                         | 2.3%                                                                         | 2.3% 8.1%                                                                    |
|                                                                              | 92% 100%                                                                     |                                                                               | low                      | 0.1%                                                                         | 0.5% 0.0%                                                                    | 2.0%                                                                         |
|                                                                              | 60% 95%                                                                      |                                                                               | medium                   | 4.3%                                                                         | 32.8%                                                                        | 0.2% 11.8%                                                                   |
|                                                                              | 16% 45%                                                                      |                                                                               | low                      | 0.1%                                                                         | 2.0% 0.1%                                                                    | 2.4%                                                                         |

<!-- image -->

values (World Bank Group, 2019c); LCOE, 2018 values (IRENA, 2019i), electricity prices, 2019 values (GlobalPetrolPrices, 2019); fossil fuel dependence (proportion of net imports of fossil fuels in TPES), 2017 values (IEA, 2019b); resource availability: solar PV (Korfiati et al., 2016), geothermal (in this case, a "realistic" potential is considered, see (Deng et al., 2015)), wind (Bosh, Staffel, hawkes, 2018, 2017), biomass (IRENA, 2014), hydro (Hydropower &amp; Dams-World Atlas, 2014).

<!-- image -->

<!-- image -->

Countries have been grouped in three main clusters, reflecting similar drivers for the transformation of the energy system.

## CLUSTER A: NORTH AMERICA, EU-28, REST OF EUROPE, OCEANIA

Cluster A generally consists of high-income countries that expect limited, or declining, population growth until 2050. Energy consumption per capita is generally well above the global average. Under the Planned Energy Scenario, energy-related CO2 emissions in the regions will rise over the next three decades except in the EU-28. By 2050, emissions are expected to double in Oceania. In North America, despite an expected 10% increase in overall energy demand until 2050, emissions are expected to remain flat. Conversely, energy-related  CO2  emissions  in  the  EU-28  will  fall  by  one-third  by  2050  compared  to  current  levels. However,  the  Transforming  Energy  Scenario  requires  that  these  large  emissions-contributing  regions deploy solutions to rapidly reduce their emissions by at least 80% compared to current levels.

The key drivers for the transformation of the energy system in these regions include:

- ➜ Enhancing energy security: There is a need to diversify the energy supply away from fossil fuels to competitive renewable sources.
- ➜ Competitiveness of the economy and leadership in innovation: The deployment of renewable energy technologies offers a strong business case for investors and could foster a green economy and reinforce these countries as clean technology leaders.
- ➜ Reducing emissions: Many of these countries are responsible for large amounts of historical emissions and should lead in reducing emissions in the years to come. Renewable energy and energy efficiency are the key tools to achieve this aim.

## CLUSTER B: MIDDLE EAST AND NORTH AFRICA (MENA) AND EAST ASIA

Cluster B generally consists of middle-income countries that have experienced robust growth in recent decades. Final energy consumption per capita in these regions is slightly above the global average and is expected to grow slightly by 2050. Currently these regions as a whole contribute a large share of global CO2 emissions, driven largely by East Asia. As a result of enabling policies and measures, energy-related CO2 emissions in East Asia are expected to fall by more than half in the next three decades, led by action in China. In the MENA region, energy-related CO2 emissions are expected to continue to rise in the next three decades, due mainly to rapid population growth and to low energy prices resulting from subsidies for fossil fuels.

Plummeting oil  demand  and  prices  as  experienced  in  early  2020s  could  result  in  profound  economic consequences for the countries that are major exporters of fossil fuels.

The key drivers for the transformation of the energy system in these regions include:

- ➜ Reducing emissions and improving air quality: An effective transformation of the energy mix from one dominated by fossil fuel sources to one dominated by renewable energy sources would reduce pollution  levels,  vastly  improving  urban  air  quality,  and  enhance  overall  environmental  conditions, thereby reducing health damages.
- ➜ Diversifying the economy: Supporting and leveraging clean energy technology, including new enabling technologies such hydrogen and batteries, would drive economic development. The current oil price volatility  takes  place  against  the  backdrop  of  a  rapidly  changing  energy  system  that  is  moving  us towards a more sustainable and equitable energy world. Given the long-term planning horizons involved and the momentum that currently exists in the energy transformation, it is unlikely to be interrupted by short term volatility in fossil fuel price.
- ➜ Enhancing consumer awareness and engagement: Promoting social initiatives and actions (including demand-side measures) could increase the pace of the energy transition in the region by improving energy efficiency.

## CLUSTER C: SUB-SAHARAN AFRICA, SOUTHEAST ASIA, REST OF ASIA, AND LATIN AMERICA AND THE CARIBBEAN

Cluster C generally consists of middle- to low-income developing countries that have experienced mixed growth in recent decades. Final energy consumption per capita in these regions is generally below the global average. In the next three decades, modern energy consumption per capita (which excludes traditional uses of bioenergy) is expected to increase in most of these regions. These regions have  made  remarkable  progress  in  providing  electricity  access  in  the  last  decade;  however,  gaps remain in achieving full electrification in some countries. Access to clean cooking fuels is an area of significant  concern for some of the countries. In the Planned Energy Scenario, energy-related CO2 emissions trends vary among regions. Emissions are expected to nearly double in Southeast Asia and the Rest of Asia, and to increase slightly in Sub-Saharan Africa and Latin America and the Caribbean. Air pollution remains a major problem, mainly in urban areas in these regions, and will only worsen with increased reliance on fossil fuels.

The key drivers for the transformation of the energy system in these regions include:

- ➜ Universalisation of access and infrastructure improvement: A  key priority is to provide energy service needs for the existing and growing population. Scaling up renewable energy deployment would be a business opportunity as well as a strategic option to increase energy access and the resilience of the energy system.
- ➜ Reducing emissions and improving air quality: Shifting away from fossil fuels and traditional uses of bioenergy to modern renewable energy sources would improve local air quality while reducing carbon emissions.
- ➜ Economic development and cost-competitiveness of renewables: Maximising use of the huge, diverse, dispersed and competitive renewable energy potential in the regions would bring energy system costs down while adding value to the economy and creating jobs.

## 3.3  IRENA's transformative pathway to 2050

Figure 3.10 outlines key indicators that show how each region can move from where it is today to where it would need to be in 2030 and 2050, as detailed in the Transforming Energy Scenario. The indicators show that significant acceleration is needed across a range of sectors and technologies, including deeper electrification of end-use sectors and higher shares of renewables.

Looking at the regional findings, some trends can be identified. In terms of energy demand growth, while energy use does not increase in Europe, the MENA region and North America, the other regions see some growth.

<!-- image -->

G

L

O

B

A

L

R

E

N

E

W

A

B

L

E

S

O

U

T

L

O

O

K

## Figure 3.10           Global energy decarbonisation: Different regional transition paths

Regional indicators including emissions, energy demand and electrification shares in the Transforming Energy Scenario

<!-- image -->

## Transforming Energy Scenario (TES)

<!-- image -->

<!-- image -->

| Regions                         | Emissions Energy-related CO 2 (Gt CO 2 /yr)   | Emissions Energy-related CO 2 (Gt CO 2 /yr)   | CO 2            | Electrification in end-use consumption (% in TFEC)   | Electrification in end-use consumption (% in TFEC)   | Electrification in end-use consumption (% in TFEC)   |
|---------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------|------------------------------------------------------|------------------------------------------------------|------------------------------------------------------|
|                                 | 2017                                          | 2030                                          | 2050            | 2017                                                 | 2030                                                 | 2050                                                 |
| East Asia                       | 11.2 Gt CO 2 /yr                              | 8.4 Gt CO 2 /yr                               | 2.2 Gt CO 2 /yr | 25 %                                                 | 37 %                                                 | 58 %                                                 |
| European Union                  | 3.4 Gt CO 2 /yr                               | 1.9 Gt CO 2 /yr                               | 0.6 Gt CO 2 /yr | 22 %                                                 | 30 %                                                 | 49 %                                                 |
| Latin America and the Caribbean | 1.2 Gt CO 2 /yr                               | 1.0 Gt CO 2 /yr                               | 0.6 Gt CO 2 /yr | 18 %                                                 | 26 %                                                 | 39 %                                                 |
| Middle East and North Africa    | 2.5 Gt CO 2 /yr                               | 2.0 Gt CO 2 /yr                               | 1.1 Gt CO 2 /yr | 19 %                                                 | 20 %                                                 | 38 %                                                 |
| North America                   | 6.2 Gt CO 2 /yr                               | 3.7 Gt CO 2 /yr                               | 1.4 Gt CO 2 /yr | 20 %                                                 | 28 %                                                 | 52 %                                                 |
| Oceania                         | 0.4 Gt CO 2 /yr                               | 0.4 Gt CO 2 /yr                               | 0.1 Gt CO 2 /yr | 23 %                                                 | 22 %                                                 | 45 %                                                 |
| Rest of Asia                    | 3.5 Gt CO 2 /yr                               | 3.8 Gt CO 2 /yr                               | 2.0 Gt CO 2 /yr | 18 %                                                 | 26 %                                                 | 47 %                                                 |
| Rest of Europe                  | 2.0 Gt CO 2 /yr                               | 1.6 Gt CO 2 /yr                               | 0.7 Gt CO 2 /yr | 18 %                                                 | 23 %                                                 | 38 %                                                 |
| Southeast Asia                  | 1.4 Gt CO 2 /yr                               | 1.6 Gt CO 2 /yr                               | 0.8 Gt CO 2 /yr | 18 %                                                 | 20 %                                                 | 42 %                                                 |
| Sub-Saharan Africa              | 0.8 Gt CO 2 /yr                               | 0.6 Gt CO 2 /yr                               | 0.3 Gt CO 2 /yr | 7 %                                                  | 23 %                                                 | 48 %                                                 |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Note: TES based on IRENA analysis, 2017 values based on Global Carbon Atlas (2019), IEA (2019b).

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

R

E

G

I

O

N

A

L

E

N

E

R

G

Y

T

R

A

N

S

F

O

R

M

A

T

I

O

N

S

:

T

E

C

H

N

O

-

E

C

O

N

O

M

I

C

C

O

N

T

E

X

T

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Renewable Energy share   |      | Renewable Energy share   |              |      |      |                                 |
|--------------------------|------|--------------------------|--------------|------|------|---------------------------------|
| in TPES (%)              |      |                          | in Power (%) |      |      |                                 |
| 7 %                      | 27 % | 65 %                     | 23 %         | 60 % | 90 % | East Asia                       |
| 15 %                     | 39 % | 71 %                     | 31 %         | 55 % | 86 % | European Union                  |
| 30 %                     | 53 % | 73 %                     | 65 %         | 85 % | 93 % | Latin America and the Caribbean |
| 1 %                      | 9 %  | 26 %                     | 3 %          | 27 % | 53 % | Middle East and North Africa    |
| 10 %                     | 30 % | 67 %                     | 23 %         | 60 % | 85 % | North America                   |
| 10 %                     | 39 % | 85 %                     | 25 %         | 66 % | 93 % | Oceania                         |
| 8 %                      | 27 % | 58 %                     | 18 %         | 52 % | 81 % | Rest of Asia                    |
| 6 %                      | 19 % | 54 %                     | 27 %         | 42 % | 82 % | Rest of Europe                  |
| 13 %                     | 41 % | 75 %                     | 20 %         | 53 % | 85 % | Southeast Asia                  |
| 7 %                      | 43 % | 89 %                     | 26 %         | 67 % | 95 % | Sub-Saharan Africa              |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

The highest shares of renewable energy in total primary energy supply in 2030 would be reached by Latin America and the Caribbean, at 53%, followed by Sub-Saharan Africa at 43%. The EU would be at 31%. In contrast, the MENA region would have the lowest share at just 9%. However, by 2050 regional developments would be different, with the highest shares of renewables in TPES reached in Sub-Saharan Africa and Oceania,  at  levels  above  80%,  followed  by  Southeast  Asia,  Latin  America  and  the Caribbean, and the EU above 70%. As in 2030, the MENA region would still have the lowest share at just 26% in 2050.

Similarly,  electrification  would  have  varying  growth  trends  across  the  regions.  The share of electricity consumption in final energy use in 2050 is the highest in East Asia at 58%, led by China. The Rest of Asia, North America and the EU have shares around 50%. Lower shares, at around 40%, occur in the MENA region, Southeast Asia, Latin America and the Caribbean, and the Rest of Europe.

The levels of investment in renewable energy needed to implement the Transforming Energy Scenario vary greatly by region and are not necessarily correlated with current shares of renewables. The main driver for investment levels in a region is generally population,  followed  by  income  level.  The  highest  level  of  average  annual  clean energy investments over the period to 2050 will be seen in East Asia followed by North America, the Rest of Asia and the EU (Figure 3.11 and Table 3.1).

Figure 3.11     Transforming Energy Scenario: Varying investment needs by region Annual investments in the energy transformation by region through 2050

USD billion/yr

<!-- image -->

Source: IRENA (2019q)

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 3.1     Annual investments in the Transforming Energy Scenario by region through 2050 (USD billion/yr)

|                              |   Renewables | Energy efficiency   |   Electrification of heat and transport |   Power grids and flexibility |   Others a | Total   |
|------------------------------|--------------|---------------------|-----------------------------------------|-------------------------------|------------|---------|
| East Asia                    |          268 | 229                 |                                     139 |                           105 |         22 | 763     |
| European Union               |           82 | 147                 |                                      33 |                            56 |          5 | 323     |
| Latin America                |           31 | 59                  |                                      10 |                            15 |          3 | 118     |
| Middle East and North Africa |           18 | 96                  |                                       5 |                            23 |          6 | 148     |
| North America                |          119 | 221                 |                                      74 |                            65 |          8 | 487     |
| Oceania                      |           13 | 13                  |                                       3 |                             4 |          1 | 34      |
| Rest of Asia                 |           93 | 157                 |                                      54 |                            52 |         20 | 376     |
| Rest of Europe               |           25 | 94                  |                                      30 |                             6 |         10 | 165     |
| Southeast Asia               |           45 | 56                  |                                      11 |                            22 |          7 | 141     |
| Sub-Sahara Africa            |           43 | 25                  |                                      16 |                            18 |          3 | 105     |
| Global                       |          735 | 1 099               |                                     374 |                           372 |         86 | 2 667   |

Source: IRENA (2019q)

a.   Electrolysers for hydrogen production, biofuel supply, and carbon capture and storage combined with improved materials for industry.

## 3.4  Key actions

This  report  makes  clear  that  a  global  energy  transformation  is  urgently  required,  and  that  renewable energy, energy efficiency and electrification are the main cornerstones of that transition. Technologies for these pillars are available today, are deployable at a large scale quickly and are cost-competitive. The Paris Agreement was signed in 2015, and since then energy-related CO2 emissions have risen by around 5%.

The coming years are critical: there is a need for a leap in collective ambition levels. Countries, and regions,  must  push  for  an  energy  transition  that  puts  the  world  on  a  global  pathway  to  reduced emissions, despite differing views on the mitigation measures needed. Key actions are needed now to promote the changes that are conducive to the energy transformation, including:

- ➜ Transformation of the power sector to accommodate growing shares of variable renewable energy;
- ➜ Promotion of digitalisation as a key enabler to amplify the energy transformation;
- ➜ Acceleration of the electrification of the transport and heating sectors as a crucial component of the next stage of energy transformation;
- ➜ Adoption of hydrogen produced from renewable electricity to help reduce fossil fuel reliance in challenging sectors to reduce emissions;
- ➜ Development of biomass supply chains that are key to meeting growing demand for sustainable bioenergy.

Decarbonising the global energy system requires swift and decisive policy action in the power, industry, buildings and transport sectors. An overview of major actions at the sector level is presented in Figure 3.12.

## Figure 3.12.     Global energy decarbonisation: Swift action needed in all sectors

Key actions at a sectoral level to realise the energy transformation to 2050

## Power

## Transport

<!-- image -->

## ACCELERATE RENEWABLE CAPACITY ADDITIONS TO GENERATE ADEQUATE POWER WITH LOW-CARBON TECHNOLOGIES

- 1)    Identify and map renewable energy resources and develop a portfolio of financeable projects for the medium to long term.
- 2)   Construct no new coal power plants and plan and implement an end-of-life phase-out of coal capacities.

## UPDATE GRID PLANNING TO ACCOMMODATE RISING SHARES OF VARIABLE RENEWABLE ENERGY (SOLAR AND WIND)

- 1)    Develop a flexible power system (with flexible supply, storage, demand response, power-to-X, electric vehicles, digital and ICT technologies, etc).
- 2)   Update grid codes.
- 3)   Deploy micro-grids to improve resilience and expand energy access with renewable sources.
- 4)   Deploy super-grids to interconnect regions.
- 5)   Deploy cost-reflective tariff structures by properly readjusting the balance between volumetric charges (USD/kWh), fixed charges ( e.g. USD/metermonth) and, where applicable, demand charges (USD/kW).

## SUPPORT DISTRIBUTED ENERGY RESOURCE DEPLOYMENT

- 1)    Incentivise energy consumers to become prosumers.
- 2)   Support regulatory and pricing policies, including rights to generate and sell electricity, tariff regulation and grid-arrival policies.
- 3)   Enable energy aggregators to foster use of distributed energy resources.

Source: IRENA (2019a)

<!-- image -->

## REDUCE TRANSPORT VOLUME AND CONGESTION

- 1)    Adopt advanced digital communication technologies to improve urban transport planning and services ( e.g. re-routing to reduce traffic congestion).
- 2)   Promote mobility services ( e.g. automonous driving, vehicle-sharing).
- 3)   Accelerate the shift from passenger cars to public transport (electric railways, trams or buses).
- 4)   Deploy low-emissions city trucks.

## ACCELERATE THE SHIFT TO ELECTRIC MOBILITY

- 1)    Set minimum standards for vehicle emissions.
- 2)   Give electric vehicles (EVs) priority in city access.
- 3)   Incentivise the development of charging infrastructure.
- 4)   Strengthen links between the power and transport sectors with integrated planning and policy designs (vehicle-to-grid services).

## PRIORITISE BIOFUELS IN ROAD FREIGHT, AVIATION AND SHIPPING

- 1)    Introduce specific mandates for advanced biofuels, accompanied by direct financial incentives and financial de-risking measures.
- 2)   Adopt supporting policies to scale up sustainable production of first- and secondgeneration biofuels.
- 3)   Eliminate fossil-fuel subsidies and implement carbon and energy taxes to increase the competitiveness of renewable-fuelled shipping and aviation.

## Industry

<!-- image -->

## REDUCE ENERGY CONSUMPTION IN INDUSTRIES

- 1)    Promote circular economy (material recycling, waste management, improvements in materials efficiency, and structural changes such as reuse and recycling).
- 2)   Establish energy efficiency standards and ramp up actual efficiency levels.

## ENABLE CORPORATE SOURCING OF RENEWABLES

- 1)    Support a credible and transparent certification and tracking system for corporate renewable energy use.
- 2)   Consider an energy market structure that allows for direct trade between companies of all sizes and renewable energy developers, e.g. through power purchase agreements (PPAs).
- 3)   Work with utilities and other electricity suppliers to provide green corporate procurement options.
- 4)   Empower companies to invest directly in self-generation.

## ACCELERATE LOW-CARBON TECHNOLOGY DEPLOYMENT FOR INDUSTRIAL PROCESS HEATING

- 1)    Remove existing barriers and Incentivise lowcarbon heating methods ( e.g. solar thermal heating, modern bioenergy and heat pumps).
- 2)   Support emerging biomass and hydrogen technologies. Replace fossil fuel-based with renewable-based feedstocks and process heat ( e.g. in iron and steel subsectors, ammonia production).

## Buildings

<!-- image -->

## REDUCE ENERGY CONSUMPTION IN BUILDINGS

- 1)    Establish or enhance energy-efficient building codes and standards (including for appliances and equipment).
- 2)   Adopt retrofitting and renovation programmes, including financing schemes.
- 3)   Incentivise retrofits and adjust construction codes in cities and states.
- 4)   Combine energy efficiency and renewable energy measures ( e.g. public policies to integrate these technologies in renovations of public buildings).

## SUPPORT AND FOSTER DER DEPLOYMENT

- 1)    Remove barriers that prevent prosumers from actively helping to transform the energy system.
- 2)   Promote community ownership models and innovative financing schemes.
- 3)   Accelerate the roll-out of smart meters.
- 4)   Capitalise on smart-home and digitalisation schemes to allow demand management and strengthen grid services.

## SCALE UP THE RENEWABLE SHARE IN THE BUILDINGS SECTOR

- 1)    Promote low-carbon heating technologies ( e.g. heat pumps, solar heating, modern bioenergy for heating and cooling).
- 2)   Apply these renewable energy technologies through district heating.
- 3)   Phase out traditional biomass as a cooking fuel and replace it with clean and efficient cookstoves (biogas, modern solid biomass, electricity).

<!-- image -->

Socio-economic  footprints  provide  essential  insights  for  transition  planning  and policy making at the global level (Chapter 2), at the regional level (Chapter 4) and the country level (IRENA, 2020a and forthcoming country studies).

This chapter presents socio-economic footprints of the world's ten regions analysed in Chapter 3. The first section briefly describes the socio-economic context underlying the analysis. The second presents the results of the socio-economic footprint of the energy transition for each region. Some of the policy implications are presented in the concluding section, but also in Chapter 6, where the contours of a policy framework for  a  just  energy  transition  are  considered  as  part  of  a  broader  discussion  of  the transformative decarbonisation of societies.

## 4.1  Background

The  socio-economic  footprints  of  the  world's  regions  differ  significantly  from aggregate global results and from each other. This is due to regional differences in 1)  the  prevailing  socio-economic  context  and  structures  at  the  start  of  the  energy transition;  2)  the  energy  transition  roadmap  envisioned  for  each  region  under  the Transforming  Energy  Scenario  and  the  resources  available;  and  3)  changes  in economic structures and policy support for the energy transition.

The  energy  transition  interacts  in  multiple  ways  with  the  socio-economic  context in  each  region,  producing  its  socio-economic  footprint.  It  occurs  in  countries  and regions that are at different stages of development, in different states of economic growth, with differing economic structures, and with populations possessing different capacities and needs. It is, therefore, essential to analyse the Transforming Energy Scenario and understand regional effects in detail.

For  this  purpose,  major  socio-economic  developments  such  as  population  growth are maintained at equal levels for any given time and region under the two scenarios.

<!-- image -->

GDP, employment and welfare effects are determined macro-econometrically, using the E3ME simulation model. 1

The  main  socio-economic  variables  used  to  contextualise  the  analysis  include  the regional  distribution  of  population,  employment  and  GDP  at  the  beginning  of  the transition, as well as the evolution of each variable over time. Figure 4.1 shows the regional  distribution  of  population,  economy-wide  employment  and  GDP,  ranked in  decreasing  order  of  population.  More  than  half  of  global  GDP  arises  from  the European Union and North America. Sub-Saharan Africa, Southeast Asia, and Oceania each account for small shares of global GDP. Shares of jobs in global employment are highest in Asia, which also account for the highest share of population.

Figure 4.1     Some regions feature prominently in population and job distribution, others in GDP distribution

Regional shares of global population, economy-wide employment and GDP in 2019

<!-- image -->

IRENA analysis based on E3ME.

1 E3ME is Cambridge Econometrics' macro-econometric model. IRENA's socio-economic footprint analysis uses the E3ME model to evaluate the systemic implications of transition roadmaps.

Absolute  numbers  can  camouflage  important  differences  on  a  per  capita  basis. Figure  4.2  compares  regional  per  capita  GDP  figures.  The  dashed  line  indicates the global average of USD 11 000. 2  North America, Oceania (despite its small share of global GDP) and the European Union are well above it. The rest of Europe, East Asia and the Middle East and North Africa (MENA) have close to the average, while other  regions  fall  below  it.  Figure  4.3  shows  the  evolution  of  the  socio-economic context  in  each  region  and  the  world  over  the  transition  period  (2019-2050),  in terms of the compound annual growth rate (CAGR) 3  of population, economy-wide employment and GDP. 4

The additional investment required to deploy clean energy technologies provides an essential input to regional development under the Transforming Energy Scenario.

Figure 4.2     North America, Oceania and the European Union: Per capita GDP well above the global average

Distribution of per capita GDP in 2019

## USD thousands

<!-- image -->

IRENA analysis based on E3ME.

2 All U.S. dollar values in this chapter are 2015 constant values.

3 The compound annual growth rate is a measure of growth over a given period - in this instance 2017-2050. It can be thought of as the constant annual growth rate needed to move from the initial to the final value over that period.

4 This is based on IPCC SS1 and SS2. The shared socio-economic pathways are part of a new scenario framework, established by the climate change research community to facilitate the integrated analysis of future climate impacts, vulnerabilities, adaptation and mitigation. The SSP2 represents a middle-of-the-road socio-economic context, while the SSP1 is linked to a socio-economic narrative centered on sustainable development.

Figure 4.3      Growth rates of population, jobs and GDP vary across regions

CAGR of population, economy wide employment and GDP in ten regions worldwide under the Transforming Energy Scenario, 2019-2050

<!-- image -->

IRENA analysis based on E3ME.

Figure 4.4 presents the per capita distribution of the additional clean energy investment 5 needed for the transition  mapped  out  in  the  scenario. With  the  global  average  standing  at USD 122 per capita per year, investment differs  across  the  regions,  from  around USD  50  per  capita  per  year  in  subSaharan Africa to USD 455-555 in North America and Oceania.

The regional distributions of per capita  GDP  (Figure  4.2)  and  per  capita additional clean energy investment (Figure  4.4)  follow  similar  patterns.  The path  of  investment  over  time  will  affect the regional socio-economic  footprint, as  will  the  region's  readiness  to  absorb investment  and  benefit  from  it.  These can have major impacts on distributional patterns  of  the  regional  socio-economic footprint (forthcoming IRENA).

5 Additional investment is the investment in renewables, energy efficiency and energy flexibility needed for the Transforming Energy Scenario, minus that needed for the Planned Energy Scenario. The total additional investment is presented in Chapter 3 and in IRENA (2019a). In absolute terms, the cumulative total additional investment is USD 15 trillion, while the cumulative additional clean energy investment is USD 36 trillion. Globally, total additional average per capita investment during the transition is USD 54 per capita per year (using the average 2019-2050 population). Total additional investment is lower mainly because of the reduction in fossil-fuel investment occurring in parallel with clean energy investment.

Figure 4.4      Clean energy investment per capita varies widely among regions Annual per capita additional clean energy investments for the Transforming Energy Scenario, by region, through 2050

<!-- image -->

Based on IRENA analysis

Note: Per capita investment figures were calculated on basis of each region's average population during the period 2019-2050.

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

## 4.2    Socio-economic indicators of the energy transition: Jobs

The  energy  transition  affects  different  sectors  and  supply  chains  of  the  economy, induces technological changes and shifts investment - all with significant effects on employment, and hence on people's livelihoods. The most obvious changes will occur in  the  energy  sector,  with  more  jobs  in  renewables,  energy  efficiency  and  energy flexibility,  and  fewer  jobs  in  fossil  fuels.  Here,  the  regional  distribution  of  natural resources,  both  conventional  and  renewable,  plays  a  role  as  important  as  that  of manufacturing capacities and services. 6

As the changes induced by the energy transition move through the economy as a whole, they bring about additional job gains and losses. These are described in this section for each region, beginning with employment in the overall energy sector and its constituent parts, then in the overall economy. Understanding these employment shifts will enable decision makers to pursue policies that ensure a just transition and leave no one behind.

- 6 Regional Factsheet presents further details on jobs in renewables and in the energy sector as a whole for each of the ten world regions considered in this report.

The  following  text  distils  findings  from  IRENA's  econometric  modelling  work.  Job numbers  presented  are  for  2050  under  the  Transforming  Energy  Scenario,  unless otherwise  specified.  Gains  or  losses  describe,  in  absolute  or  relative  terms,  the difference  between  the  Planned  Energy  Scenario  and  the  Transforming  Energy Scenario.

## JOBS IN THE OVERALL ENERGY SECTOR

Employment in the energy sector is made up of jobs in the three transition-related technologies  (renewable  energy,  energy  efficiency,  and  power  grids  and  energy flexibility)  plus  jobs  in  the  conventional  sectors  (fossil  fuel  and  nuclear  industry) (IRENA,  2020a). 7   The  regional  and  technological  distribution  of  the  100  million energy sector jobs in 2050 under the Transforming Energy Scenario is illustrated in Figure 4.5. Asia is dominant with a 60% share (and East Asia alone accounts for about 35%). Compared with the Planned Energy Scenario, all regions gain jobs under the Transforming Energy Scenario. But Southeast Asia experiences the largest differential (81%),  followed  by  Oceania  (57%),  Sub-Saharan  Africa  (36%)  and  North  America (28%).

As shown in Chapter 2, the rise in total energy jobs between the two scenarios in 2050 (from around 87 to 100 million) results from gains in transition-related technologies and smaller losses in  fossil  fuel  and  nuclear  sector  jobs.  Figure  4.6  shows  the  net employment effects in the energy sector for different regions. Interregional variations are explained by differences in the current structure of the energy sector, different energy sector roadmaps and the regional trade balances associated with transitionrelated equipment.

<!-- image -->

All regions create more energy sector jobs, even those where fossil fuel job loss is significant.

7 Globally, jobs in renewables increase from 26 to 42 million; energy efficiency from 18 to 21 million; and energy flexibility from 13 to 15 million. Jobs in fossil fuels decrease from 30 to 22 million; nuclear from 0.7 to 0.4 million.

Figure 4.5      A hundred million energy jobs: Regional distribution

Energy sector jobs in 2050 under the Transforming Energy Scenario, by region (in millions)

<!-- image -->

Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

Figure 4.6      All regions gain more energy sector jobs than they lose

Difference in employment by 2050 between the Transforming Energy and Planned Energy scenarios, by region and sector (in millions)

<!-- image -->

## Transition-related jobs

Under the Transforming Energy Scenario, transition-related technologies (consisting of renewable energy, energy efficiency, and energy flexibility and grid enhancement) experience growth in employment across the world. In all regions, these technologies will employ more people in 2050 than conventional technologies will - accounting for as much as about 85% of all energy jobs in North America, the European Union, Latin America and the Caribbean and East Asia to about 60% in Sub-Saharan Africa and the rest of Europe.

Among  the  transition-related  technologies,  renewable  energy  jobs  feature  most prominently  in  Southeast  Asia  and  Latin  America  and  the  Caribbean  (with  shares of  64%  and  62%,  respectively,  of  all  transition-related  employment),  about  double the share in the MENA region and the rest of Europe. By contrast, energy efficiency jobs weigh in most heavily in North America (45%), while energy flexibility and grid enhancement jobs have the highest share (22%) in rest of Asia.

Additional  findings  for  these  categories  of  transition-related  technologies,  with particular focus on renewable energy, follow below.

## Renewable energy jobs

About  42  million  people  will  work  in  manufacturing,  installing,  operating  and maintaining  renewable  energy  systems  in  2050  under  the  Transforming  Energy Scenario, most in solar energy, followed by bioenergy and wind energy (see Figure 4.7).  The  greatest  number  of  these  jobs  will  be  created  in  Asia:  East  Asia  (36%), Southeast Asia (16%) and the rest of Asia (12%). The Americas rank second (15%), evenly split between North America and Latin America and the Caribbean. Europe holds a 10% share (with the European Union accounting for 6% and the rest of Europe for 4%). The shares for Sub-Saharan Africa and the MENA region are 5% each.

## Figure 4.7      An estimated 42 million jobs in renewables: Regional distribution

Renewable energy jobs in 2050 under the Transforming Energy Scenario, by region (in millions)

15.0

<!-- image -->

## Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

12.3

%

35.8

%

7.1

%

7.7

%

6.4

%

4.9

%

4.8

%

4.1

16  %

%

%

0.7

In terms of technology share in each region, solar will account for half of all renewables jobs in North America and Asia, followed by Europe with 30%. By contrast, bioenergy is  most  prominent, with a share of over 60% of renewables jobs, in Latin America and  the  Caribbean,  Southeast  Asia,  Sub-Saharan  Africa  and  the  rest  of  Europe. Wind is strongest in East Asia and the European Union with around 25% of jobs, and around 15% in North America and the MENA region. Hydro jobs account for 15% of all renewable energy jobs in rest of Asia and 10% in Latin America and the Caribbean and the MENA region.

In East Asia, renewable energy employment consists chiefly of jobs in solar energy and wind energy. To a large extent, investment in installations accounts for this result, driven by ambitious targets for the electricity sector. Many employment opportunities arise in manufacturing, trade and services. In addition, the region's exports of solar and wind technologies remain high, although manufacturing of the former is largely automated and, thus, of decreasing relevance to employment.

Southeast Asia starts from different initial conditions and will take a different route in the energy transition. Some solar manufacturers have recently moved to the region. But future developments will also be driven by bioenergy, which requires primarily domestic inputs and creates jobs in the labour-intensive agricultural sectors of the region.

The rest of Asia follows a mixed pattern between these two approaches, without the strong contribution of wind energy observed in East Asia. In Latin America and the Caribbean, a mature bioenergy sector makes a substantial contribution to regional employment,  because  the  biomass  and  the  technology  needed  to  process  it  are largely domestic operations, as is the distribution of biofuels.

North America and Europe hold similar shares of global renewable energy employment, albeit with different specialisations. While North America generates jobs in the solar industry (manufacturing, sales and installation), Europe has a larger role for wind energy.

## Energy efficiency

The share of energy efficiency jobs among all energy sector jobs in 2050 is projected to  be  highest  in  North  America  (45%).  In  the  European  Union,  it  will  be  29%.  It  is expected to be lowest in Southeast Asia (7%), while other regions fall between 10% and 25%.

Individual regions also fare differently when it comes to the job growth differential between  the  Planned  Energy  Scenario  and  the  Transforming  Energy  Scenario. Thanks to higher investments, the rest of Europe is estimated to more than double employment  in  energy  efficiency.  The  rest  of  Asia  also  experiences  a  significant increase (75%), while gains in other regions vary between 10% and 30%.

## Power grids and energy flexibility

With respect to power grids and energy flexibility, the share of jobs is highest in the rest of Asia (22%) and the rest of Europe (17%) and lowest in Southeast Asia (6%). Compared to the Planned Energy Scenario, the gains will range from over 65% in North America to more modest increases of about 6% in the rest of Europe, East Asia and the rest of Asia.

## Conventional energy

In  contrast  to  the  transition-related  technologies,  projected  2050  employment  in the conventional energy sector is lower in all regions in the Transformation Energy Scenario compared to the Planned Energy Scenario. The largest drop, around 40%, is likely to occur in North America, East Asia and the European Union. The rest of Asia follows with a decline of more than 30%, while Latin America and the Caribbean and the MENA region face a reduction of about 25% jobs.

Most of these losses will  take  place  in  the  fossil  fuel  industries.  They  concern  not only  exporters  but  also  importers  who  have  built  up  extensive  infrastructures, distribution networks, assets and human know-how around these forms of energy. Such  developments  notwithstanding,  the  share  of  conventional  energy  jobs  does remain high in some regions.  They will still account for up to 40% in Sub-Saharan Africa, the MENA region and the rest of Europe compared with just 10% to 15% in the European Union, the Americas and East Asia.

Coal mining is a labour-intensive sector that will lose many jobs in regions such as East  Asia,  the  rest  of  Europe,  and  countries  in  Sub-Saharan  Africa,  such  as  South Africa. Other fossil fuel rich regions, notably the MENA region and North America, will also lose jobs in oil and gas.

In the nuclear energy sector, all regions are expected to lose jobs, ranging from 20% in Latin America and the Caribbean and the rest of Asia to around 65% in Europe and North America. This is mainly due to the age of the nuclear power plants. Notably, nuclear energy jobs often require highly educated experts, who would likely need different kinds of compensatory measures than fossil fuel sectors. However, the work force in the nuclear industry is older on average than in other energy sectors, so job losses can be more readily absorbed by pension schemes.

For the design of transition policies, the structure of qualifications in the lost jobs will  be  as  relevant  as  the  age  structure  of  the  labour  force  and  the  sub-regional distribution. Detailed analysis will be needed to design optimal policies.

Energy is an integral part of the economy, interacting with every other economic sector, affecting relative wages and generating income to be spent in other sectors.

<!-- image -->

## ECONOMY-WIDE JOBS

Energy  is  an  integral  part  of  the  economy,  interacting  with  every  other  economic sector, affecting relative wages and generating income to be spent in other sectors. Thus, labour impacts of the transition reach beyond the energy sector.

Figure 4.8 presents the economy-wide difference in regional employment between the Transforming Energy Scenario and the Planned Energy Scenario. Some regions enjoy gains significantly higher than the global average, while others experience a reduction.

The European Union shows the largest and most positive effect, with a 2.4% gain, followed by North America (1%) in 2050. Oceania and East Asia also benefit, but more marginally. With the exception of Sub-Saharan Africa, which shows no overall change,

Figure 4.8      The European Union stands to gain the most jobs economy-wide Difference in regional employment in 2050 between the Planned Energy Scenario and the Transforming Energy Scenario (% and millions)

<!-- image -->

Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

all other regions experience a decline of jobs. However, it is important to note that this loss is not absolute, but rather relative compared to likely outcomes under the Planned Energy Scenario.

As noted previously, whether a region experiences a gain or reduction in economywide jobs during the transition depends on both the inputs from the energy transition roadmap and the region's initial socio-economic and structural development. Countries that  are  well  integrated  in  international  trade  and  have  a  diversified  economy  are likely  to  gain  from  an  investment-oriented  strategy.  Such  regions  are  best  able  to absorb investment and expand their activities in machinery, electronics, services and the public sector. The workforce is qualified and administrative barriers are low. This holds true for North America, Europe and Oceania, and increasingly for East Asia.

Figure 4.9      Indirect and induced effects: Strongest in the European Union and North America Role of three sets of drivers in the differences in regional economy-wide employment between the Transforming Energy Scenario and the Planned Energy Scenario for the 2019-2050 period

## Gains/losses (%)

<!-- image -->

To gain insights into what drives the net effects described so far, the jobs footprint is evaluated dynamically across the transition period, with the effect of each driver quantified for each region. Figure 4.9 shows the average role that each set of drivers plays  during  the  transition  on  economy-wide  employment  between  the  Planned Energy Scenario and the Transforming Energy Scenario. The various drivers affect each region in strikingly different ways.

Change in employment numbers is of course only one dimension. Equally if not more critical is the issue of altered occupational and skills patterns as the energy transition takes hold. This will have profound impacts on labour markets and on educational and training institutions as skills demand and supply may show significant, even if temporary, mismatches.

In all regions, the transition-related job gains will surpass losses in conventional energy (see  Regional  Factsheets).  However,  the  transition  can  still  produce  labour  market misalignments in regions and countries that must be considered in defining related policies. The challenge is greater in those regions and countries where economy-wide results indicate less job growth under the Transforming Energy Scenario than under a business-as-usual approach (shown in Figure 4.8).

The misalignments can be grouped into four categories, namely temporal, spatial, educational  and  sectoral.  Job  gains  and  losses  may  not  happen  within  the  same time scale. New jobs may not be created in the same locations where jobs are lost. The specific educational and skill requirements may diverge. And finally, given that clean energy solutions will draw on a different set of supply chain inputs than the conventional  energy  industry,  some  economic  sectors  will  gain  while  others  lose. Avoiding or minimising these types of misalignments will be a major task of transition policy-making.

Change in employment numbers is only one critical dimension; altered occupational and skills patterns is another.

<!-- image -->

## 4.3.   Socio-economic indicators of the energy transition: GDP

GDP has been the indicator most commonly used to guide economic policy and remains a proxy of well-being. The potential impact of the transition on GDP, therefore, is vital to understand, while simultaneously restructuring economies in line with the goal of improving welfare (see section 4.2.4). The Transforming Energy Scenario leads to a global increase in GDP compared with the Planned Energy Scenario, as demonstrated in  Chapter 2; the regional impacts are presented in Figures 4.10 and 4.11. Regional GDP is driven by regional investment, the region's trade with the world, and induced and indirect effects in the region (see Chapter 2 and IRENA, 2019a).

Figure 4.10 presents the regional distribution of the differences in GDP between the Transforming Energy Scenario and the Planned Energy Scenario in 2050. Six regions (the  MENA  region,  Oceania,  Sub-Saharan  Africa,  the  rest  of  Asia,  North  America, and the rest of Europe) have lower gains than the world average; two of them (the MENA region and Oceania) experience a reduction in GDP in 2050 compared with the Planned Energy Scenario. Three regions (Southeast Asia, East Asia and Latin America and the Caribbean) show GDP differences close to the world average in 2050. Only the European Union registers a GDP difference under the Transforming Energy Scenario that is higher than the world average.

Figure 4.10      All regions except two see GDP rise Percentage difference in regional GDP between the Planned Energy Scenario

and the Transforming Energy Scenario, 2050

<!-- image -->

Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

<!-- image -->

The  reasons  for  these  very  different  regional  GDP  results  reside  in  the  regional distribution  of  the  inputs  associated  with  the  energy  transition  roadmap,  differing regional macroeconomic structures and the linkages between regions.

IRENA's analysis demonstrates the impact on regional GDP of the three main drivers described in Chapter 2. Figure 4.11 shows how much GDP changes during 2019-2050 between the Planned Energy and Transforming Energy scenarios.

Figure 4.11      The largest drivers of GDP gains: Indirect and induced effects, and trade

Role of three sets of drivers in the differences in regional GDP between the Transforming Energy Scenario and the Planned Energy Scenario for the 2019-2050 period

## Gains/losses (%)

<!-- image -->

Trade: Trade plays a prominent role in shaping the future of some regional economies. The large GDP gains in Southeast Asia and Sub-Saharan Africa are attributable to a strong increase in net exports while the MENA region faces the opposite dynamic, driven by the loss of hydrocarbon exports. The positive trade effect in Latin America and the Caribbean and rest of Asia is quite pronounced while North America faces a drag from reductions in fossil fuel trade and even more so trade in other goods and services.

Investment: The level of investment is another important driver of the socio-economic outcome at regional levels. At the global level, transition-related energy investments average USD 122 per capita per year. Among regions the amounts vary widely, from around USD 50 per capita per year in Sub-Saharan Africa to USD 555 per capita per year in Oceania. Not only are the macroeconomic impacts consequently higher where investments are larger, but the multipliers in each economy play a significant role in determining the strength of investment effects.

Indirect and induced effects: The presence of robust supply chains allows indirect and induced effects to contribute positively to the economy, especially if supported by appropriate fiscal policies. This is particularly the case in some of the major economic regions,  such  as  the  European  Union,  East  Asia  and  North  America.  Additional employment leads to additional income, which has multiplier effects by increasing consumer spending and economic activity. Fiscal policies are most effective if they are based on a clear understanding of the local socio-economic context in a given region or country. Furthermore, their successful implementation hinges on the presence of a complex administrative infrastructure.

If the energy transition brings employment gains in a given region, induced effects contribute  positively  to  its  economy.  Additional  employment  leads  to  additional income, which has multiplier effects through additional consumer spending. This is the  case  in  Europe,  East  Asia  and  North  America.  These  results  highlight  the  fact that when structural conditions of an economy (and its underlying supply chains) are well-positioned to embrace the challenges and opportunities of the energy transition, considerable gains can be expected not only in employment, but also in GDP.

When structural conditions of an economy are wellpositioned to embrace the challenges and opportunities of the energy transition, considerable gains can be expected in GDP and employment.

<!-- image -->

Whereas  Figure  4.10  presents  the  regional  distribution  of  GDP  in  the  year  2050, Figure  4.12  shows  the  cumulative  results  between  2019  and  2050, i.e. ,  the  sum  of GDP differences between the Planned Energy Scenario and the Transforming Energy Scenario.  For  the  world,  this  cumulative  difference  in  GDP  is  USD  98  trillion  (see Chapter 2), which in per capita annual terms (using the average population in the years between 2019 and 2050) represents USD 367 per capita per year.

<!-- image -->

The European Union is expected to gain as much as USD 2 950 per capita per year, but for most regions it is between USD 660 to about USD 100. Sub-Saharan Africa is  projected  to  experience  a  modest  increase  of  around  USD  30,  while  the  MENA region and Oceania see a decline relative to the Planned Energy Scenario. Variations in economic footprint contribute to the differences in the welfare estimates for these regions (Figure 4.12).

## Figure 4.12      Regional differences in GDP gains per capita

Regional cumulative GDP gain under the Transforming Energy Scenario compared with the Planned Energy Scenario (in USD, per person per year)

<!-- image -->

Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

## WELFARE

Although  employment  and  GDP  are  relevant  indicators  for  the  public  debate,  the improvement of people's well-being must be the ultimate target of any change or transition. Welfare, therefore, is one of the most important socio-economic indicators of the energy transition. The strong positive impact of the transition on global welfare is presented in Chapter 2 (a positive difference of 13.5%). 8

<!-- image -->

Figure 4.13 shows its regional distribution in 2050. The Transforming Energy Scenario leads to a much more significant improvement in welfare than the Planned Energy Scenario. Some regions fare better than others, with Oceania seeing an improvement in  welfare  above  17%,  while  Europe  improves  by  10%  and  the  other  regions  fall between these levels.

Figure 4.13      Welfare improvements at regional levels driven by social and environmental gains Gain in welfare indicator in 2050 between the Transforming Energy and Planned Energy scenarios (in %)

<!-- image -->

## Based on IRENA analysis

Disclaimer: The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

- 8 For further details on the structure of the welfare indicator for each of the 10 regions, as well as its evolution over time (2030 and 2050), see Regional Factsheets.

Among the different welfare dimensions (as described in Chapter 2), the social and environmental ones dominate the gains in every region. Within the social dimension, the  reduction  in  illness  and  disease  caused  by  local  air  pollution  accounts  for  the most improvement. Hence, regions currently experiencing more outdoor and indoor air  pollution achieve greater welfare improvements as the transition progresses. In some regions,  such  as  Latin  America  and  the  Caribbean  and  East  Asia,  the  other component of the social dimension (spending on education) also sees a very sizeable improvement as the transition advances.

Noteworthy is the share of the economic dimension in certain regions, including the European Union and North America, portraying the relatively higher economic and employment gains illustrated in the results above.

The dominant component within the environmental dimension, which is composed of sub-indicators on greenhouse gas emissions and consumption of materials, is the mitigation of global greenhouse gas emissions. The benefits from emission reductions are shared by all regions.

## 4.4  Policy conclusions

The  foregoing  analysis  shows  that  all  regions  of  the  world  can  expect  to  derive benefits from the energy transition. However, settling for a broadly positive picture is simply not sufficient. As our modelling results indicate, individual regions will not gain equally much in the transition-related sectors; all will need to address impending losses in conventional energy, but some more so than others; and they must prepare for considerable differences in the extent to which their overall economies are able to benefit from the various drivers of the transition, i.e. , investments, trade, and indirect and induced effects.

The  expected  regional  outcomes  also  vary  depending  on  whether  one  examines impacts on GDP, employment or human welfare. Welfare gains are the area where gains are strong for all regions. The reason is that lower air pollution from the adoption of  cleaner  energy  benefits  people  irrespective  of  economic  prowess.  Within  the category of jobs, this chapter has focused on projected developments in the energy sector as a whole, plus its main constituent parts, transition-related and conventional energy, as well as the connections to the economy at large. Individual regions fare differently in each of these categories, sometimes strongly so.

The most important lesson, therefore, is the need for thorough analysis of the reasons for these regional differences. Ultimately, even more granular and detailed analysis is required in each country, as regional averages may conceal significant differences among countries. Understanding the socio-economic impacts is essential for countries exploring ways to maximise benefits, minimise adjustment burdens, and meet multiple objectives such as stimulating economic growth and employment, improving energy security, expanding energy access and mitigating climate change.

As mentioned in this chapter, differences in the regional socio-economic footprints can be traced back to differences in their structural conditions, industrial capacities, trade structures, and the depth and diversity of domestic supply chains. All help determine the degree to which a given economy can take advantage of the opportunities offered by  the  energy  transition.  It  must  be  understood  that  some  countries  face  greater challenges than others.

But while existing structures can help or hinder a country's ability to benefit from the transition, they are not written in stone. They can be altered over time, as know-how is accumulated, skills taught, supply chain capacities built, and institutional capacities enhanced. Policy ambition and far-sighted planning are critical. As such, transition planning needs to assess not only existing socio-economic structures, but also be aware of the profound changes the transition will bring about in labour markets. These can produce misalignments in many regions, which will unfold against the broader reality of structural unemployment that remains a critical issue for most countries.

To achieve a successful and just transition, investments in renewable energy, energy efficiency, and electrification of transport and other facets of the energy transition must be co-ordinated and integrated with other policies specific to the energy sector and broader policies to enhance the technical strengths and structural capacities of the economy. In other words, policies specific to the energy sector must be mainstreamed into  economic,  industrial,  labour,  education  policies  and  social  policies.  The  socioeconomic indicators that a given policy aims to address should be clearly identified in order to overcome challenges and maximise benefits from the energy transition.

Cross-cutting and coherent policy-making can deliver on climate and energy ambitions, and put in place a mix of programmes, projects and initiatives to generate successful outcomes. In this context, it is essential to understand the structural conditions of specific economies and their related dependencies, including commodity, trade and technological (see Chapter 6).

IRENA's analysis underscores the urgency of policies for economic diversification as they leverage local capabilities along segments of value chains and address labour market rigidities. The specifics will vary from country to country, but a comprehensive package will need to include a broad mix of policies and interventions (see Chapter 6). In  that,  the  energy  sector  -  as  a  critical  enabler  of  growth  and  development - is fundamental.

<!-- image -->

## GETTING TO ZERO

<!-- image -->

Ensuring  that  global  temperatures  stop  rising  will  require  that,  by  the  second half  of  this  century,  emissions  eventually  reach  zero,  or  net  zero. Additional mitigation  measures  will  therefore  be  needed  beyond  what  was  presented  earlier in the Transforming  Energy  Scenario.  This  chapter  considers  these  increased mitigation needs and, with the Deeper Decarbonisation Perspective (DDP), presents enhancements to that scenario showing what more could be done.

## 5.1  Getting to zero: Technology options and costs

Carbon dioxide emissions represent three-quarters of greenhouse gas emissions , 1 with energy-related CO2 (combustion of fossil fuels) and industrial process emissions making up over 80% of CO2 emissions and the remainder coming from land use, landuse change and forestry (LULUCF). Efforts are therefore needed across the energy, industrial and land-use sectors to reduce emissions. Significant efforts are needed in certain sectors, such as in industry and transport, that are sometimes referred to as 'hard-to-decarbonise' or "hard-to-abate" sectors.

The analysis presented in this report separates CO2 emissions into three categories: energy-related, industrial process and LULUCF 2 . The previous chapters of the report focus only on energy-related CO2. This chapter expands the focus to include industrial processes due to the significance of these emission sources to the industry sector.

1 wo-thirds of the remainder is methane, with most of the rest coming from nitrous oxide and fluorinated gases. T

2 ULUCF emissions are considered in the overall carbon budget, including assumptions for LULUCF that L result in net-zero emissions for the period 2018-2100. However, detailing the measures that reduce LULUCF emissions are outside the scope of this report and are not analysed in detail, as this chapter is limited to energy-consuming sectors. The assumption is that CO  emissions from LULUCF would fall from 5.5 Gt in 2018 2 to zero by mid-century at the latest, and that LULUCF subsequently would become a net absorber of CO  over 2 the remainder of the 21st century. As a result, cumulative CO  emissions from LULUCF between 2018 and 2100 2 would be zero.

<!-- image -->

In the Transforming Energy Scenario, 9.5 Gt of energy-related CO2 emissions remains in 2050. Around 2.9 Gt of process emissions was emitted globally in 2016, which in the  Planned  Energy  Scenario  will  increase  to  3.6  Gt  by  2050.  In  the  Transforming Energy Scenario, this is reduced over 75% to 0.9 Gt. Carbon capture and storage (CCS) accounts for 2 Gt of the 2.7 Gt reduction, but reductions also are achieved through forms  of  carbon  management,  including  offsetting  through  carbon  dioxide  removal (CDR) or reduced through material efficiency and the circular economy. Therefore, the Transforming Energy Scenario would result in 10.4 Gt of remaining net CO2 emissions in 2050. Figure 5.1 outlines these remaining CO2 emissions and their sources in 2050, with the bulk of these emissions found in the transport and industry sectors.

Figure 5.1     Industry and transport: The bulk of remaining emissions in 2050 Energy-related and industrial process CO2 emissions  in the Transforming Energy Scenario, 2050

CO2 (Gt/yr)

<!-- image -->

<!-- image -->

There  are  two  general  approaches  to  reducing  emissions  to  zero: completely decarbonising all energy and industrial processes so that no CO2 is emitted at all (the 'zero' emissions approach), and offsetting any remaining emissions through the use of CDR to achieve net-zero emissions (the 'net-zero' emissions approach). Examples of CDR include reforestation, afforestation, direct air capture, enhanced weathering and bioenergy CCS.

The optimal mix of these two approaches ('zero' and 'net zero') needs to be further explored, in particular given the uncertainties about the types of technologies and solutions that could reduce these remaining emissions. The Deeper Decarbonisation Perspective described in this chapter do not constitute a new scenario; instead, they explain the two types of approaches that could further reduce the remaining emissions in the Transforming Energy Scenario in order to achieve zero, or net-zero, emissions.

The  time  scales  on  which  these  approaches  could  be  implemented  are  also highly uncertain. Given that delivering the Transforming Energy Scenario by 2050 is  already a significant challenge, the additional measures described in the Deeper Decarbonisation  Perspective  may  require  longer  to  fully  implement.  The  following analysis assumes a policy objective to deliver the 'net-zero' or 'zero' approaches in the decade following 2050. It might be possible to shorten those time frames with sufficiently  robust  policy  measurements,  investment  and  improvements  through innovation, but that is highly uncertain.

Figure 5.2 outlines, by technology category, the reductions that would occur by sector in the two approaches.

Figure 5.2     The Deeper Decarbonisation Perspective: Getting to "net zero" and eventually 'zero' (figure continues on next page)

Remaining energy and process-related CO2 emissions in the Transforming Energy Scenario

<!-- image -->

G

L

O

B

A

L

R

E

N

E

W

A

B

L

E

S

O

U

T

L

O

O

K

Figure 5.2     (continued)

Reductions in energy and industrial process CO2 emissions in the Deeper Decarbonisation Perspective 'zero' (left page) and 'net zero' (right page) approaches

Possible path to zero energy and process emissions by 2060 (Gt CO ) 2

Share of reductions by sector (Transforming Energy Scenario to zero)

<!-- image -->

Note: The Transforming Energy Scenario includes 250 Mt/yr in 2050 of carbon capture, utilisation and storage for natural gas-based hydrogen production (blue hydrogen).

Deeper Decarbonisation Perspective to net zero energy and process emissions at the latest by 2060 (Gt CO )

2

0

Transforming Energy

Scenario  2050

Renewable power

Renewables &amp; heat pumps

Waste incineration

Renewables

Structural &amp;

behavioural changes

Clinker substitutes

Electric trucks

Electrification

Energy efficiency

Reduced fossil fuel demand (refineries)

-0.

Others (incl. synfuels)

Structural &amp;

behavioural changes

0

Zero energy &amp;

process CO  emissions

2

Hydrogen (steel)

## Deeper Decarbonisation Perspective to net zero energy and process emissions at the latest by 2060 (Gt CO ) 2

<!-- image -->

Gas CCS

Nuclear

CCS

Synfuels

G

E

Green gas

T

T

I

N

G

T

O

Z

E

R

O

Reducing the remaining emissions in the Transforming Energy Scenario requires numerous activities. For the power sector, emissions are reduced to zero through full deployment of zero-carbon electricity sources, mainly renewable energy coupled with storage or coupled with the use of hydrogen, although combining CCS with existing natural  gas  plants  also  plays  a  limited  role.  The  buildings  sector  and  the  district heating sector are also fully decarbonised through increased electrification, which in turn is sourced from fully decarbonised electricity, or through the use of renewable end-use technologies, such as solar thermal or bioenergy, or through green hydrogen.

After  these  approaches,  the  remaining  sectors  with  energy-related  emissions  are industry,  transport  and  some  other  small  sectors  such  as  refining,  forestry  and fisheries.  These  sectors  have  6.7  Gt  of  energy-related  emissions  remaining  in  the Transforming Energy Scenario.

The  Deeper  Decarbonisation  Perspective  'net-zero'  approach  reduces  these remaining energy-related emissions to 3.4 Gt; therefore, it is assumed that an equal amount of carbon sinks  is  needed  to  offset  these  emissions  to  arrive  at  net  zero, although the type of carbon sink is not defined. With robust policy measures and successful innovation it may be possible to reduce emissions from these sectors to zero  without  the  need  for  carbon  sinks.  The  Deeper  Decarbonisation  Perspective 'zero' approach assumes further technology deployment, along with structural and behavioural changes, to arrive at fully zero emissions.

There is  also  0.8  Gt  of  remaining  industrial  process  emissions  in  the  Transforming Energy  Scenario  that  is  not  sequestered  or  offset.  The  Deeper  Decarbonisation Perspective assumes that these remaining emissions are reduced through methods outlined in this chapter and that no further sequestering or offsetting of emissions for industrial process are needed.

A  summary  overview  of  the  methods  used  to  reduce  both  energy  and  process emissions under the Baseline Energy Scenario, the Transforming Energy Scenario and the two Deeper Decarbonisation Perspectives is presented in Figure 5.3. The reductions that result in shifting from the Baseline Energy Scenario to the Planned Energy Scenario reduce annual CO2 emissions by 9.9 Gt. Almost half of the reductions are  a  result  of  renewable  energy,  with  one-quarter  coming  from  energy  efficiency and  the  remainder  coming  largely  from  end-use  electrification,  primarily  electric vehicles. This represents how government plans have changed over the last few years, reflecting the positive developments for renewable power and EVs.

In the Transforming Energy Scenario, annual CO2 emissions are reduced in total by 26.3 Gt, with almost half coming from renewable energy, followed by a 24% reduction from  energy  efficiency,  largely  technical  efficiency  measures  but  also  including structural changes such as the circular economy and other measures that reduce the consumption of energy-intensive and carbon-intensive products. Of the remaining emissions, 11% of reductions come from EVs, with the remainder split between green and blue hydrogen, CCS and others.

The Deeper Decarbonisation Perspective 'zero' approach reduces the remaining 10.4 Gt of annual CO2 emissions to zero. It  shows  a  roughly  equal  importance  of renewables,  energy  efficiency  and  other  approaches  for  reducing  the  remaining emissions to zero, each contributing around one-third. Of the others, green hydrogen

(which includes synthetic fuels and use as a feedstock) plays the most important role. For  the  Deeper  Decarbonisation  Perspective  'net-zero'  approach,  renewables  and energy efficiency still play an important role, but a large contributor to reductions is  CDR,  which  reduces  the  reduction  amount  that  is  required  across  the  other approaches.

Overall,  when  looking  at  the  technology  groupings  that  result  in  reducing  annual energy  and  industrial  process-related  CO2  emissions  (a  decline  from  the  Baseline Energy Scenario value of 46.5 Gt to a value of zero in the Deeper Decarbonisation Perspective  'zero'  approach),  renewables  make  up  43%,  energy  efficiency  and structural changes 26%, EVs 12%, green hydrogen 9%, and the remainder a mix of blue hydrogen, CCS (9%), behavioural change and nuclear energy (Figure 5.3).

Figure 5.3     Renewables and efficiency: Achieving the bulk of emission reductions Mitigation potential per technology grouping by scenario, 2020-2050 (PES, TES), 2020-2060 (DDP)

## Energy and industrial process-related CO2 emission reductions (Gt CO2)

<!-- image -->

Figure 5.4 looks more broadly at how emissions are reduced from the Baseline Energy Scenario to zero. It shows the relative contributions in four categories:

- 1) Renewable energy , including direct uses of renewable energy ( e.g. , biofuels, solar thermal), renewable power and both direct ( e.g. ,  EVs, heat pumps) and indirect electrification ( e.g. , green hydrogen, synthetic fuels);
- 2) Energy  efficiency ,  including  structural  changes  ( e.g. ,  circular  economy,  modal shifts) and behavioural changes ( e.g. , flying less);
- 3) Carbon  management  solutions , including  CDR  ( e.g. , reforestation,  direct  air capture), bio-energy with carbon capture and storage (BECCS), CCS, and carbon capture, utilisation and storage (CCUS) (including blue hydrogen); and

## 4) Nuclear energy .

In both the Deeper Decarbonisation Perspective 'zero' and 'net-zero' approaches, around two-thirds of CO2 emissions are from renewable energy, around one-quarter are from energy efficiency, and the remainder are from carbon management, with a small additional share from nuclear energy.

## Figure 5.4     CO  cuts with renewables: Two-thirds of the way to zero 2

Contribution of energy and industrial process-related CO2 emission reductions from the Baseline Energy Scenario to the Deeper Decarbonisation Perspective 'zero' (left) and 'net-zero' (right) approaches (%), 2020-2060

<!-- image -->

<!-- image -->

The  costs  for  reducing  emissions  vary,  but  overall  costs  are  lower  than  the savings  that  result from  reduced  externalities. In the Transforming Energy Scenario,  every  USD  1  spent  for  the  energy  transition  would  bring  a  payback  of between USD 3 and USD 8 (Figure 5.5). Or, in cumulative terms, the Transforming Energy  Scenario  would  have  an  additional  cost  of  USD  19  trillion  over  the  period to 2050 but would result in a payback of between USD 50 trillion and USD 142 trillion in reduced environmental and health externalities.

The Deeper Decarbonisation Perspective would cost an additional  USD  16  trillion to achieve net-zero emissions, or an additional USD 26 trillion to achieve fully zero emissions (with no carbon offsets). Therefore, the total additional costs to reach zero range from USD 35 trillion to USD 45 trillion. Yet these higher costs are still much lower than the USD 62 trillion to USD 169 trillion in savings from reduced externalities that would result from reaching zero emissions.

## Figure 5.5     Every USD 1 spent brings USD 3-8 payback in environmental and health returns

Cumulative costs and savings for the Transforming Energy Scenario and the Deeper Decarbonisation Perspective 'zero' and 'net zero' , 2020-2050 (TES), 2020-2060 (DDP) (trillion USD 2015 )

<!-- image -->

<!-- image -->

Figure 5.6     Affordable CO2 mitigation: Efficiency, renewables and structural change Mitigation costs for select technologies and groupings, 2050

<!-- image -->

The overall costs do not account for the fact that many of the technologies presented in this report are much cheaper than fossil fuel alternatives, as can be seen in Figure 5.6. Mitigation costs measure the cost at which a tonne of CO2 can be avoided, or reduced, by another zero-carbon technology. For energy efficiency measures for electricity, the mitigation costs fall in the USD -150/tonne to USD -20/tonne range. Heating efficiency measures range from USD -100/tonne to USD +70/tonne. The mitigation costs of most renewables  are  between  USD  -50/tonne  and  USD  +50/tonne  (even  when  including infrastructure  costs).  These  numbers  are  lower  than  the  costs  for  CCS,  which  range from USD +50/tonne to USD +80/tonne, or for nuclear, which averages USD +80/tonne.

Another way to look at it is in the cost to mitigate one tonne of CO2 over the period. For the Transforming Energy Scenario, which reduces annual emissions to 10 Gt by 2050,  the  cost  would  be  USD  34  per  tonne  of  CO2.  The  Deeper  Decarbonisation Perspective, which reduces the remaining emissions to zero, has higher costs. For the  'net-zero'  approach,  the  cost  is  USD  100  per  tonne  of  CO ,  but  for  the  'zero' 2 approach it is USD 156 per tonne of CO2.

Figure 5.7     Mitigation costs under different scenarios: From USD 23 to USD 156 per tonne of CO2 Cumulative mitigation costs, cumulative CO2 reductions and average mitigation costs for the period to 2050 for the Transforming Energy Scenario, and to 2060 for the

Deeper Decarbonisation Perspective

Additional costs for the DDP (USD trillion)

<!-- image -->

<!-- image -->

<!-- image -->

Average

Cumulative costs (USD trillion)

Cumulative CO2

mitigation cost reduced (Gt)

(USD/t CO2)

| Transforming Energy Scenario                  | 19                      |    |   559 |   34 |
|-----------------------------------------------|-------------------------|----|-------|------|
| Deeper Decarbonisation Perspective "net zero" | 19 + 16 (total 35)      | 16 |   165 |  100 |
| Deeper Decarbonisation Perspective "zero"     | 19 + 16 + 10 (total 45) | 26 |   165 |  156 |

<!-- image -->

<!-- image -->

## 5.2    Eliminating the remaining emissions including in challenging sectors such as industry and transport

## OVERVIEW

As the analysis presented above shows, reaching 'net zero' or 'zero' requires further action in several sectors. The following sections describe the options to achieve that, as well as some of the challenges remaining.

The power sector would need to move to full deployment of zero-carbon electricity sources. That implies most power systems shifting to very high shares of renewables (90% plus, with some reaching 100%). Section 5.3 outlines how some countries are approaching that challenge.

New  clean  energy  vectors  such  as  hydrogen  and  its  derivatives  will  play  an important role. Section 5.4 discusses how the role of hydrogen could grow. CCUS also has a role to play, as discussed in Box 5.1.

However, for some sectors the current options are limited and the optimum pathway to  remove  emissions  is  uncertain.  These  sectors  are  sometimes  called 'hard-todecarbonise' or "hard-to-abate" sectors and are discussed below and in sections 5.5, 5.6 and 5.7.

## REDUCING EMISSIONS IN CHALLENGING SECTORS

This  report  classifies  certain  transport  and  industry  sub-sectors  as  challenging sectors in which to reduce emissions. Some have energy service needs that require high-temperature heat or high energy density, which can be difficult to supply with electricity. Some, like the petrochemical sector, also need feedstocks to produce endproducts. And some processes, such as making cement clinker or steel, produce CO2 emissions.  While  the  Transforming  Energy  Scenario  has  already  assumed  significant growth in solutions in these sectors to reduce emissions - such as direct electrification with  renewables,  bioenergy,  hydrogen  and  synthetic  fuels  -  additional  innovative solutions will be necessary to reduce emissions. Many of these solutions are either costly or still in the early stages of technology deployment, and are not yet ready at scale.

Figure  5.8  details  the  remaining  CO2  emissions  in  the  Transforming  Energy Scenario.  In  the  industry  sector,  the  largest  remaining  emitters  are  in  cement, chemicals,  and  steel  and  iron,  followed  by  aluminium.  In  transport,  the  largest remaining  emitters  are  freight  (from  a  combination  of  road,  rail  and  shipping followed by aviation) and passenger road transport.

<!-- image -->

Figure 5.8     CO  emissions from industry: Two-thirds of the remainder 2 in the Transforming Energy Scenario

Breakdown of energy-related and industrial process CO  emissions 2 in 2016

Breakdown of energy-related and industrial process CO  emissions in the Transforming 2 Energy Scenario in 2050

<!-- image -->

Note:  Steel = Iron and steel, Min. = non-metallic minerals ( e.g. cement), Chem. = chemicals, Alum. = aluminium, Other Ind. = other industry sectors, SH = space heating, WH = water heating, Cook. = cooking, Cars = passenger cars, Pass. road other = passenger road excluding cars ( e.g. buses, two-three wheelers), Rail &amp; Av. = passenger rail and aviation, Freight = all freight modes, Power = electricity generation

G

E

T

T

I

N

G

T

O

Z

E

R

O

As explained earlier, there remains 9.8 Gt of energy-related CO2 emissions in the Transforming Energy Scenario, with the bulk of those emissions coming from nonelectricity energy sources. In addition, there is 3.6 Gt of CO2 emissions from industrial processes in 2050, the bulk of which come from the cement and iron/steel sectors. In  the  Transforming  Energy  Scenario,  CCS  and  CDR  are  assumed  to  reduce  this 3.6 Gt by about 2.0 Gt/yr, with an additional 0.7 Gt/yr that can be reduced through materials efficiency and the circular economy. That would leave 0.9 Gt/yr of process emissions that are still emitted into the atmosphere in 2050. Of the combined energy and  industrial  process  emissions  remaining  in  the  Transforming  Energy  Scenario, 70% would come from the industry and transport sectors.

The sectors discussed in this section broadly include the following areas:

- · Specific transport modes , namely road freight transport, aviation and shipping;
- · Energy-intensive  industries , namely  iron  and  steel,  aluminium,  chemicals  and petrochemicals, and cement;
- · The gas system - the current systems for transport, transmission and distribution of natural gas.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Table 5.1.     Key decarbonisation solutions by sector

| Sectors                                                               | Key solutions                |
|-----------------------------------------------------------------------|------------------------------|
| Direct electrification, green hydrogen, biofuels                      | Road freight transport       |
| Biofuels, synfuels from green hydrogen, electrification               | Aviation                     |
| Synfuels from green hydrogen, biofuels, electrification               | Shipping                     |
| Green hydrogen, CCS, biomass, circular economy                        | Iron and steel               |
| Biomass, green hydrogen, circular economy                             | Chemicals and petrochemicals |
| Electrification, circular economy                                     | Aluminium                    |
| CCS, circular economy, renewable energy and waste                     | Cement and lime              |
| Green hydrogen, synthetic methane from green hydrogen, cleaned biogas | Greening the gas system      |

In  addition,  opportunities  exist  to  reduce  emissions  through  action  on  energy efficiency and greater use of the principles of the circular economy. The  circular economy includes  recycling,  reuse,  materials  substitution,  more  efficient  materials design and the use of sustainable biomass resources. The most common example of the circular economy is recycling. Another option is reusing the parts of a good after  consumer  use.  Alternatively,  the  worn  parts  of  a  good  can  be  repaired  or remanufactured before turning them into new end-products (re-use).

Circular  flows  reduce  the  need  to  extract  primary  resources,  reduce  the  need  to dispose  of  waste  and  reduce  energy  needs.  For  example,  recycling  of  materials  is often more energy efficient than the production of primary materials from natural resources. A reduction of 50% or more of energy and resource use can be achieved for many sectors and products (Gielen and Saygin, 2018). In addition, the same material can be recycled several times without losing quality properties.

Examples of how the circular economy can help reduce emissions in certain industrial sectors  are  widespread.  More  efficient  use  of  materials  and  greatly  increased recycling and reuse within a more circular economy could reduce primary production and emissions by as much as 40% globally - and more in developed economies - with the greatest opportunities in plastics and metals. A circular steel economy can reduce the use of natural gas, coal and coke, and a shift to a circular plastics economy can reduce petrochemical use.

## Box 5.1 CARBON CAPTURE, UTILISATION AND STORAGE

The  technical  potential  of  carbon  capture,  utilisation  and  storage  (CCUS)  is significant in some parts of the world, but progress has been slow. Development of  CCUS  has  been  hampered  by  the  high  mitigation  cost,  the  lumpiness  of investments, technological setbacks, NIMBY (not in my backyard) concerns and uncertainties  regarding  long-term  policy  commitments.  In  the  Transforming Energy Scenario, CCUS plays only a limited role. However, for certain industrial processes, such as cement clinker making and waste incineration plants, no other major mitigation option is currently on the table. For others, such as steel making and some chemical processes, CCUS may be cost-competitive compared to other mitigation measures. Therefore, CCUS warrants further development for certain applications.

The  use  of  bioenergy  in  combination  with  CCUS  also  offers  the  prospect  of negative emissions. The Drax Power Station in the UK has started carbon capture from  biomass  burning,  but  on  a  small  scale.  The  hope  is  that  the  Drax  pilot project, which is capturing one tonne of CO2 a day, will pave the way for a largescale rollout of the technology, which could eventually pull 10 Mt a year of CO2 out of the power plant's smokestack. However, the pilot under way at the North Yorkshire facility is not currently storing any CO2 (FT, 2019).

<!-- image -->

## MAKING PROGRESS IN CHALLENGING SECTORS

Later sections of this chapter discuss specific sectors, but there are number of general principles and trends that apply across many of the sectors. In summary, realising the progress envisioned in the Deeper Decarbonisation Perspective will require urgent, sustained,  multilateral  action  on  multiple  fronts.  In  particular,  closer  collaboration between industry and a broad range of governments, aided by international bodies, is needed to achieve the following:

## Develop a deep evidence base to inform decisions on technology pathways:

- ·   Potential solutions  are  slowly  emerging  in  most  sub-sectors,  but  significant technology uncertainty remains, and the optimum pathways are not yet self-evident.
- ·   Greater clarity is needed urgently now, in the 2020s, because a massive and rapid ramp-up of deployment will be needed in the 2030s and 2040s.
- ·   A  significant  increase  in  demonstration  and  pilot  projects  is  needed  in  a  diverse range of countries to gather evidence on what is feasible and optimum and to inform key decisions to be made in the 2020s. Learnings from those projects should be shared widely.

## Take immediate action on energy efficiency, on reducing energy intensity and on the circular economy:

- ·   Improved energy efficiency and the efficient use of resources is a no-regret strategy and  applies  to  all  sectors.  Attention  to  energy  efficiency  must  be  coupled  with systemic analysis of opportunities to reduce energy intensity.
- ·   Greater  attention  needs  be  given  to  life-cycle  and  circular  economy  analyses  for specific  sectors,  exploring  strategies  for  recycling,  materials  efficiency,  materials substitution, etc.
- ·   Policies to  promote  energy  efficiency,  such  as  minimum  energy  performance standards and integrated resource planning, as well as policies to enable reductions in energy intensity, should be applied more aggressively. More directive policy tools such as technology-forcing regulations will likely also be needed in some cases.

## Innovate to drive down the cost of a range of solutions:

- ·   The costs of potential decarbonisation solutions vary widely; however, on average the costs are above the costs of the measures in the Transforming Energy Scenario.
- ·   Increased support is needed for innovation across the innovation chain (research, development and demonstration) including taking a systemic approach to innovation where technology development is partnered with innovations in business models and changes in the way processes operate, and is enabled by innovative approaches to policy and market design.
- ·   Cost  reduction  is  driven  by  both  innovation  and  scale-up.  In  the  short  term, deployment will  be  limited,  but  encouraging  early  adoption  in  niche  or  selected markets can assist in building scale and reducing costs.
- ·   Some  of  the  promising  pathways  for  decarbonisation  are  innovative  with  supply chains and manufacturing processes. For example, shifting iron ore processing to regions with readily available renewable electricity, and using the direct reduced iron (DRI) process, could lead to reductions in China's iron and steel CO2 footprint.

## Explore international approaches to certification and regulation:

- ·   Green  products  and  energy  carriers  will  require  certification  systems,  to  enable development of markets and ensure sustainable sources, etc.
- ·   Global  approaches  will  be  needed  to  facilitate  cross-border  trade  and  to  build economies of scale.

## Develop policy measures to incentivise investment:

- •   Credible long-term policy signals are needed to mobilise the necessary investments.
- ·   Global sectoral approaches are ideally needed to ensure a level playing field. Past attempts have struggled, and new approaches ( e.g. , carbon border tax) need to be explored in detail by front-running countries and regions.

## Focus on the outcomes needed, not the existing processes:

- ·   The goal is to meet the industrial need while removing carbon emissions from a wide variety of processes. Each industrial process is unique, and the solutions may need to be too.
- ·   Imaginative approaches exist that are not yet being explored, and others can likely be created if the problem is viewed from the right angle. Examples include: ammonia as  a  shipping  fuel;  wood  in  construction;  biorefineries  co-producing  biomaterials and energy; biomass with CCS in cement kilns, etc.
- ·   The  specifics of the industrial need must be analysed, in close collaboration with industry experts, to creatively explore how the goal can be achieved in a different, low-carbon way.

## Identify pressure points for global change:

- ·   A  handful  of  specific  and  well-defined  opportunities  exist  to  make  an  early  but significant difference, and can help build confidence and scale.
- ·   Defining an optimal low-carbon pathway for all shipping worldwide, for example, is  a  major  task,  but  assessing  alternatives  that  could  be  implemented  in  a  single shipping route from China to Europe via Singapore alone is more manageable.
- •   Other examples include:
- - Singapore loads about one-fifth all fossil fuels used for shipping.
- - China accounts for over half of today's iron and steel production.
- -   Very large trucks (&gt; 15-tonne weight capacity) are responsible for over 75% of total freight truck CO2 emissions.

<!-- image -->

## 5.3  Very high shares of renewable power

The Transforming Energy Scenario documents the need for the power sector to take a decisive and rapid turn to renewables in order to achieve the Paris Agreement goals. Meeting these goals in the power sector will require large increases in global renewable  power  investment,  accelerating  the  phase-out  of  fossil  fuel  use  for electricity generation, and strong policy support.

In the Transforming  Energy  Scenario,  the power  sector  sees a significant transformation, reaching an 86% renewable energy share in electricity generation by  2050, up  from  26%  in  2018.  In  this  scenario,  many  countries  have  renewables shares above 95% by 2050, with some at 100% (for details see Box 1.3). However, power sector emissions are still at around 2 Gt in 2050 and will need to be reduced to zero.

Fortunately, the path forward for the power sector is emerging. Renewable energy can provide the bulk of power supply. The technologies are available and marketproven, the costs are modest, and the policy tools are well-documented and effective. Reducing the sector's emissions to zero can be achieved through full deployment of zero-carbon electricity sources, almost entirely renewable energy. Many countries are already starting to show how power systems can operate with very high shares of variable renewable energy (Enerdata, 2019; Hill, 2020), and over the coming decades this  will  increasingly  become  the  norm.  It  is  therefore  crucial  that  countries  share experiences and knowledge.

<!-- image -->

## Box 5.2    NNOVATION TO SUPPORT HIGH SHARES I OF VARIABLE RENEWABLE POWER

A number of countries, such as Uruguay and Costa Rica, already have very high, approaching  100%,  shares  of  renewable  energy  in  their  power  systems,  and  a growing number of countries aspire to follow suit. Sweden, for example, has a policy objective of 100% renewable power by mid-century. IRENA, in collaboration with the Swedish Energy Agency, has applied its innovation framework for the power sector transformation (elaborated in the report Innovation landscape for a renewable-powered future (IRENA, 2019o)), to the case of Sweden. The project assessed  which  innovative  solutions  could  help  Sweden  achieve  its  ambitious policy  target  by  2040.  By  combining  innovations  in  enabling  technologies, business  models,  market  design  and  system  operation,  the  project  developed four solutions for integrating high shares of VRE into the Swedish power system (Figure 5.9).

While  each  combination  of  innovations  offers  a  solution  for  certain  segments of the power sector's value chain, a holistic approach to these solutions creates major system-wide flexibility options, including direct and indirect electrification of  end-use  sectors  (transport,  buildings  and  industry)  with  renewables,  longterm hydrogen storage and the provision of innovative grid services from various assets, such as batteries, electrolysers and EVs via smart charging technologies. Best  practices  in  VRE  integration  were  also  collected  and  considered  in  the analysis. Overall, these experiences, together with the essential infrastructure for a decarbonised power system in place, indicate that obtaining a 100% renewable power system in Sweden with an increasingly higher share of VRE, from 11% today up to over 42% (39% wind, 3% solar PV) by 2040, is achievable. R

<!-- image -->

G

L

O

O

K

## Box 5.2    continued) (

Figure 5.9     Four innovative solutions for Sweden's power system

## Solution I tion I Solu

## Enabling technologiesgies Enabling technolo

- ·  Utility-scale batteries tteries ·  Utility-scal ba
- ·  Internet of Things Things ·  Internet of
- ·  Artificial intelligence and big data g data ·  Art ficial intelligence an bi

## Market designsign Market de

- ·  Increasing time granularity in electricity marketsarkets ·  Increasing time granularity in electricity m
- ·  Innovative ancillary servicesrvices ·  Innovative ancillary se

## System operation ation System oper

- ·  Advanced weather forecasting of variable renewable  wable power generationration ·  Advanced weather forecasting of variable ren power gene
- 3 Provides innovative ancillary services both from conventional tional and variable renewable energy sources; ources; 3 Provides innovative ancillary services both from conven and va iable renewable energy s

<!-- image -->

## Solution I n I Solutio

- 3 Ensures the security and stability of the power system and  m and the provision of new ancillary services, including frequency  uency and voltage support from VRE sources; ources; 3 Ensures the security nd stability of th power syste the provision of new ancillary servi es, including freq and voltage support from VRE s
- 3 Enables the provision of such ancillary services with the help  e help of more precise solar and wind power generation forecasts. ecasts. 3 Enables the provision of such ancillary serv ces with th of more precise solar and wind power generation for

## Solution IIion II Solut

## Enabling technologiesgies Enabling technolo

- ·  Internet of Things Things ·  Internet of
- ·  Artificial intelligence and big data g data ·  Art ficial intelligence an bi
- ·  Blockchain kchain ·  Bloc
- ·  Supergridsrgrids ·  Supe

## Market designsign Market de

- ·  Increasing time granularity in electricity marketsarkets ·  Increasing time granularity in electricity m
- ·  Regional marketsarkets ·  Regional m
- 3 Improves flexibility in the existing pan-European market  arket design; design; 3 Improves flex bility in the existing pan-European m

Innovative ancillary illary services from both   both conventional and l and variable renewable  wable energy sources ources Innov tive anc services from conventiona variable rene energy s

<!-- image -->

- 3 Fosters collaboration among system operators in Sweden, eden, the Nordic, Baltic and wider European region; region; 3 Fosters collaborati among syst m operators in Sw the Nordic, Baltic and wider European
- 3 Ensures clear and effective division of responsibilities to  ties to manage an increasingly complex, decentralised and d and digitalised power system. ystem. 3 Ensures clear and effective division of responsibili manage an increasingly complex, decentralise digitalised power s

## Solution II  n II Solutio

Pan-European market arket as flexibility provider vider with effective ctive collaboration among  mong system operatorsrators Pan-European m as flexibility pro with effe collabor tion a system ope

<!-- image -->

## Solution III

## Enabling technologies

- •  Behind-the-meter batteries
- •  EV smart charging
- •  Renewable power-to-heat

G

- •  Internet of Things
- ·  Artificial intelligence and big data
- •  Blockchain
- •  Aggregators

## Business models

## Market design

- •  Time-of-use tariffs
- •  Innovative ancillary services
- •  Market integration of distributed energy resources

## System operation

- •  Future role of distribution system operators
- •  Co-operation between transmission and distribution system operators
- •  Virtual power lines
- 3 Aggregates distributed energy resources to optimise distribution system operation;

<!-- image -->

## Solution III

- 3 Balances supply and demand daily;
- 3 Manages network congestion at the distribution level in the context of wind shortage/surplus in the short term, until transmission projects with long lead times are implemented.

System-friendly integration of distributed energy resources

<!-- image -->

## Solution IV

## Enabling technologies

- •  Renewable power-to-heat
- •  Renewable power-to-hydrogen
- •  Artificial intelligence and big data

## Market design

- •  Increasing time granularity in electricity markets
- •  Innovative ancillary services
- •  Regional markets
- 3 Decarbonises end use sectors such as direct heat and transport via electrification with renewable energy sources;

<!-- image -->

## Solution IV

- 3 Enhances flexibility and helps maintain system stability via direct and indirect electrification via power-to-X technologies (such as renewable power-to-heat and renewable power-to-hydrogen);
- 3 Is part of a truly complex, yet disruptive solution, for sectors that are difficult to eliminate emissions completely, such as iron and steel industries.

Decarbonisation of end-use sectors via electrification with renewable energy sources

<!-- image -->

## 5.4  The role of hydrogen

Although hydrogen is not a primary energy source, it can be produced from fossil fuels  either  without  CCS  (grey  hydrogen)  or  with  CCS  (blue  hydrogen),  or  from renewable  power  through  electrolysis  (green  hydrogen). Hydrogen  is  already an  industrial  commodity,  and  currently  around  120  Mt  per  year  of  grey  hydrogen is  produced and consumed, mostly in the refining industry and for the production of  ammonia.  Dedicated  hydrogen  pipelines  have  been  in  operation  for  decades. Although hydrogen production is already 'at scale', it is not yet clean; today 96% of all hydrogen is produced from fossil fuels and the remainder from electrolysis, mainly in the chlor-alkali process.

As this report shows, electrification of half of all final energy use is possible by 2050 in the Transforming Energy Scenario. Of  this,  roughly  85%  is  consumed  as electricity directly, and 15% is renewable electricity used to produce green hydrogen (representing around 5-6% of TFEC). Of the remaining half of final energy, one-third is  provided  by  direct  use  of  renewables.  But  even  with  this  significant  scale-up  of renewable  electricity,  green  hydrogen  and  direct  uses,  there  remains  one-third  of energy demand whose related emissions will eventually need to be addressed - and here green hydrogen can play an expanded role.

Green hydrogen is currently more expensive than conventional hydrogen production from fossil fuels (grey hydrogen). However, the cost of green hydrogen is falling rapidly due to the combined effects of reduced electrolyser cost and cheaper renewable power, to the point where it can compete with blue hydrogen in the near future (see Figure 5.10).

The  cost  of  renewable  power  (used  to  make  the  green  hydrogen),  the  cost  and performance of electrolysers, and the electrolyser load factor determine the green hydrogen  production  cost.    Production  costs  of  around  USD  2-3  per  kilogram  for green hydrogen are feasible in the coming decade in the best locations. Low cost can also be achieved earlier at locations with good renewable energy resources.

Green hydrogen production also has the potential to create a virtuous cycle for renewables-based electricity grids, as hydrogen can provide much-needed flexibility to power systems, acting as a buffer to non-dispatchable renewable generation, and has a potential role for seasonal balancing of renewable generation by storing large amounts of hydrogen in salt caverns and other underground reservoirs.

As  a  consequence  of  the  potential  for  low-cost  green  hydrogen,  certain  energyintensive  industries  may  in  the  future  be  located  at  sites  that  meet  such  criteria. A  potential  boom  of  renewables  and  green  hydrogen  in  Australia  may  be  one example, as the country has announced two feasibility studies to explore renewable ammonia  at  commercial  scale  (Paul,  2019).  In  Norway,  the  first  plant  producing ammonia from green hydrogen is expected to open in 2020 (Yara, 2019). Iron making may follow later.

In the Transforming Energy Scenario, hydrogen has the potential to supply nearly 29  EJ  of  global  energy  demand  by  2050. Two-thirds  of  that  would  come  from renewable sources, requiring at minimum around 7 500 TWh of renewable electricity, roughly equivalent to 30% of global electricity generation today.

G

E

T

T

I

N

G

T

O

Z

E

R

O

Figure 5.10     Green hydrogen production costs: Approaching competitiveness with blue hydrogen Hydrogen production costs from solar and wind vs. fossil fuels with carbon capture

and storage, 2020-2050

## Levelised cost of hydrogen (USD/kg H2)

<!-- image -->

Note: Electrolyser costs: 770 USD/kW (2020), 540 USD/kW (2030), 435 USD/kW (2040) and 370 USD/kW (2050). CO2 prices: USD 50 per tonne (2030), USD 100 per tonne (2040) and USD 200 per tonne (2050).

Hydrogen is already employed in industry in significant quantities; however, this grey hydrogen will have to be replaced by a combination of blue and green hydrogen. There is significant potential to reduce emissions in chemicals, refining, and iron and steel  using  green  hydrogen  to  replace  fossil  fuel-based  feedstocks  and  to  provide high-temperature  heat.  In  the  Transforming  Energy  Scenario,  just  under  14  EJ  of renewable hydrogen would be consumed in the industrial sector in 2050, mainly in the iron and steel industry, in chemicals and also for ammonia production.

The transport sector would be the second largest user of renewable hydrogen with 4 EJ consumed per year by 2050. In the transport sector, hydrogen can be used in fuel cell electric vehicles (FCEVs), mostly for heavier freight transport, or to produce synthetic  fuels  for  shipping  or  aviation.  In  the  buildings  sector,  hydrogen  can  be blended with natural gas or used to produce synthetic methane and injected in gas grids, although this application is limited to around 1 EJ.

<!-- image -->

Green  hydrogen  can  be  processed  further  into  hydrocarbons,  also  known  as synthetic  fuels  or  e-fuels. With  the  exception  of  synthetic  ammonia  production, synthetic fuels play a limited role in the Transforming Energy Scenario, but they will need significant scale-up when the remaining one-third of energy needs to reduce emissions to zero. In an earlier brief, IRENA outlined activity in the shipping sector to explore the use of fuels produced from hydrogen (IRENA, 2019r). The aviation sector is also looking into e-fuels as a possible solution - in addition to advanced biofuels (bio-jet).

The natural gas industry is also looking at hydrogen as a promising solution for greening the gas system, extending the life of existing infrastructure (see section 5.7).  Some  view  the  gas  grid  in  this  scenario  functioning  as  a  large-scale  storage asset, accommodating and distributing low-cost renewable electricity. Projects are being  developed  in  the  Netherlands,  the  UK,  Northern  France  and  Italy.  However, more work needs to be done, and barriers related to economics and standards must be overcome.

It  is  important  to  consider  scale. Even  the  installation  of  50  GW  of  electrolysers, 330 times more than are in operation today, would still only allow the production of enough fuel to provide 10% of global shipping's energy needs. To produce the 19 EJ of green hydrogen in the Transforming Energy Scenario, much more capacity than this would be needed - around 1 700 GW of electrolysers by 2050 - and despite this growth, green hydrogen would still only provide around 5-6% of global final energy. Blue hydrogen could provide an additional 2.5% of global final energy, for a total of all hydrogen in the 7-8% range.

In  a  scenario where global emissions reach zero, hydrogen could be the missing link in the transformation of the global energy system. The Deeper Decarbonisation Perspective  presented  in  this  chapter  outline  some  ways  in  which  hydrogen,  and hydrogen  based-fuels,  can  play  a  larger  role  beyond  the  Transforming  Energy Scenario - specifically in industry, transport and the buildings sector. In the long run, hydrogen could become a key element in 100% renewable energy systems (IRENA, 2018c; Butler, 2020). In such a case, as more and more electrolysis is deployed, as well as with more renewables, green hydrogen will increasingly become more costcompetitive.  The  current  drive  towards  the  hydrogen  economy  has  a  remarkable momentum and a wide scope.  Today's  role  of  clean  hydrogen  is  modest,  but  the growth potential is significant.

<!-- image -->

## 5.5  Challenging sectors: Transport

## Transport accounts for around one-quarter of global energy-related CO2 emissions.

The  path  forward  to  provide  transport  services  while  reducing  CO2  emissions  is becoming clear for some, but not all, transport modes. For light-duty vehicles (cars, sport-utility vehicles and small trucks), battery electric vehicles have shown dramatic improvements  in  range  (kilometres  per  charge),  cost  and  market  share.  The  path forward here is clear: electrify the light-duty vehicle fleet and provide that electricity from renewable sources. For other modes, the path is less clear, although there is significant untapped potential for sustainable liquid biofuels. Additional solutions will be  needed  for  road  freight  transport,  aviation  and  shipping.  Potential  solutions  in these transport modes are described in the following sub-sections.

## ROAD FREIGHT TRANSPORT

Currently, freight transport (trucks, ships and trains) represents more than 40% of transport's total energy demand. That demand is projected to increase by 20%, from 25 EJ in 2016 to 30 EJ in 2050. In the Planned Energy Scenario, emissions from all modes of freight transport will increase to 3.8 Gt per year by 2050. In the Transforming Energy Scenario, freight's CO2 emissions would decline by almost 75% compared to the  Planned  Energy  Scenario,  to  just  under  1  Gt  of  CO   annually  by  2050.  Around 2 0.6 Gt per year of reductions would come from the use of biofuels in trucks and ships. Another 1.5 Gt of CO2 emissions could be cut by efficiency measures across all modes of freight transport, and the remainder of reductions could come from switching to electricity, especially for freight trains and delivery trucks.

Several technologies that are being developed are potential options for reducing emissions to zero in road freight transport. Plug-in  battery  EVs  and  fully  electric trucks  could  account  for  the  majority  of  commercial  light-to-medium  duty  trucks that  typically  travel  100  to  200  kilometres  per  day.  Battery  technology  continues to  improve,  and  a  recent  study  (UCS,  2019)  shows  that  already  27  manufacturers are offering 70 different models of electric trucks in the United States alone. Many are developing and implementing lithium-ion technology in delivery vans and semitrucks for use by logistics companies.

While the main trend in delivery trucks seems to be towards EVs, the outlook is not as clear for heavy-duty trucks. Some manufacturers are planning to provide batteryelectric heavy-duty trucks, and some also are considering alternative fuels that can also reduce emissions. Hydrogen is one option, but it may be less competitive if battery performance improves rapidly. Also being considered are electric highways, which use overhead catenary lines to power heavy-duty trucks over long distances. Those trucks would then use battery power for the shorter travel to regional distribution centres.

Alternative options could be producing synthetic fuels, or e-fuels, that can be used in internal combustion engines, or the use of clean biogas (biomethane) and conventional and advanced liquid biofuels. Biofuels are already being commercialised for trucks in some countries, but major barriers to widespread production and adoption remain (IRENA, 2019m).

<!-- image -->

<!-- image -->

## AVIATION

Aviation,  and  jet  fuel  use  in  particular,  is  one  of  the  fastest-growing  sources  of greenhouse gas emissions. Emissions  from  aviation  are  around  0.9  Gt  of  CO   per 2 year, or 2-3% of global emissions, and the figure is higher if upstream emissions in fuel production and non-CO2 greenhouse effects are considered. By 2050 in the Planned Energy Scenario, emissions would increase to 2.1 Gt/yr, whereas in the Transforming Energy  Scenario  they  decline  to  around  0.7  Gt,  despite  an  expected  increase  in passenger activity of more than 200%.

There are four main ways to deliver net-zero aviation: develop new electric aircraft, produce  drop-in  fuels  (including  bio-jet),  change  the  fuels  of  existing  aircraft  (for instance to synthetic fuels) and take the emissions out of the atmosphere.

Aviation  emissions  can  be  reduced  by  1.5%  annually  through  improved  fuel efficiency in new  aircraft, aircraft modifications, airport restructuring and optimised navigational systems (IRENA, 2017c). However, a significant longer-term reduction in emissions would require airlines to use more fuels that are renewable and  sustainable,  such  as  biofuels  developed  for  jet  aircraft.  Although  sustainable and clean alternative propulsion technologies are in development, such as electricor solar-powered aircraft for long-distance flights, synthetic fuels or even cryogenic hydrogen as a fuel, these options are unlikely to be ready for commercial use until later in the century.

Biofuels for jet aircraft,  known in the industry as bio-jet, are therefore the only currently available option to achieve significant reductions in aviation emissions. In the Transforming Energy Scenario, liquid biofuel production overall would increase five-fold from 130 billion litres in 2016 to 652 billion litres in 2050, and over 100 billion litres  of  bio-jet  would  be  consumed  in  the  aviation  sector  (IRENA,  2017d).  This,  in addition to efficiency and operational improvements, would be the main reasons for the reductions in CO2 emissions in the Transforming Energy Scenario.

Although  the  market  for  bio-jet  is  currently  very  limited,  and  price  information  is also limited, bio-jet use is likely to grow rapidly in the coming decades. However, its widespread use will depend on a supportive regulatory framework and/or on significant carbon pricing. Widespread use will also require longer-term cost reductions, which are critical to close the gap with conventional jet fuel. Emissions reductions in aviation are challenging, but they are necessary for the full decarbonisation of the transport sector.

In addition to bio-jet fuel, research is exploring the production of synthetic jet fuel using green hydrogen. In particular, a project at Rotterdam's Innovation Campus is combining highly innovative technologies to produce jet fuel made (partly) from CO2 to help achieve a carbon-neutral future for the aviation sector. The project captures CO2 from the air and then combines the CO2 with hydrogen produced by splitting water into hydrogen and oxygen with electrolysis. The result is a synthetic gas that can be transformed into jet fuel. The project is still at the demonstration stage, however. Synthetic jet fuels still have a long way to go before becoming fully competitive, due mainly to their high costs.

## SHIPPING

On average, the shipping sector is responsible for around 3% of annual global greenhouse gas emissions. In the absence of suitable mitigation policies, the International Maritime Organization (IMO) estimates that greenhouse gas emissions associated with the shipping sector could grow between 50% and 250% by 2050. In this context, the IMO states that shipping CO2 emissions need to fall by at least 50% by 2050, compared to 2008 (IMO, 2018).

Despite efficiency gains, and the development of solutions, such as the switch to fossil-based liquefied natural  gas  (LNG),  emissions  have  continued  to  rise  as  trade  volumes  grow.  To  reduce  emissions, therefore, the shipping sector would eventually need to shift to renewable fuels or alternative means of propulsion.

Alternative fuel options all have different advantages and disadvantages, and there is no consensus on  which  option  is  best. Liquid  biofuels,  renewable  hydrogen  and  other  hydrogen-derived  fuels such as ammonia, as well as wind and solar applications, are being considered as fuel alternatives. From a technological perspective, liquid biofuels are mature, require few adjustments to the existing engines  of  ships  and  port  infrastructure,  and  can  have  considerable  emissions  reduction  benefits, even as blends. However, three main barriers limit biofuel potential in the shipping sector: economics, availability and sustainability concerns.

Another option is synthetic fuels (electrofuels or e-fuels), which are produced using electricity as the main energy input. The electricity is used to produce hydrogen, which is then combined with CO2, alcohols or hydrocarbons, or nitrogen in order to produce ammonia. Common synthetic fuels being considered include methanol and ammonia. These fuels can effectively decrease and even eliminate emissions if they are produced from green hydrogen created through electrolysis using renewable power. Most plants producing e-fuels are at pilot scale, although a commercial-sized methanol plant is producing 5 million litres per year in Iceland, and another commercial-scale plant is slated to come online in Norway in 2020.

Waste-based fuels could also play a role. The fuels can be produced using gases from waste treatment processes or flue gas from non-renewable sources, such as steel mill flue gases; or they can be made from waste plastics and/or rubber. These types of fuels are considered to be recycled carbon fuels. Although they are not considered to be renewable, the claimed benefit is that because they recycle gases that would otherwise have been emitted, their use for a secondary purpose would not result in  additional  emissions.  A  third  pathway  is  the  production  of  fuels  from  plastic-to-fuel  plants.  An estimated 70 million litres per year are currently produced using this method.

Finally, wind and solar power have historically played important roles in the shipping sector. Given the size and weight of today's commercial vessels, wind and solar alone cannot provide the necessary power to move the load of large ships. They can, however, improve overall efficiency by reducing fuel consumption. Yet there are still barriers to the adoption of these technologies in the shipping sector, including surface availability and cargo space limitations for wind, while for solar PV technologies, environmental salinity can be an issue.

The shipping sector may see significant change in the coming years, although the direction remains unclear.  This  poses  both  a  risk  and  an  opportunity,  depending  on  the  direction  and  magnitude  of the change.

<!-- image -->

## 5.6 Challenging sectors: Industry

Industry is responsible for over one-quarter of global energy-related CO2 emissions, and an additional 8% of global CO2 emissions come from industrial processes within industry. So in total, industry is responsible for around one-third of global energy and industrial process-related CO2 emissions. A few industries account for the majority of the industry sector's energy use: iron and steel, non-ferrous metals (notably aluminium), chemicals and petrochemicals, and non-metallic minerals (notably cement).

Currently, few economically viable solutions exist for reducing CO2 emissions at scale in these industrial sectors. While the Transforming Energy Scenario does result in  reductions  in  industrial  emissions  of  60%  by  2050,  largely  by  focusing  on  lowhanging fruits (such as energy efficiency measures and low to medium temperature process  heat),  the  sector  remains  the  single  largest  emission  source.  Therefore, industry will require the development and commercialisation of new zero-emission technology solutions that will drive down emissions not just by 60%, but eventually to net zero.

Over the past few decades, significant progress has been achieved in reducing the industry sector's emissions of substances that deplete the ozone layer, as outlined in the Montreal Protocol, as well as greenhouse gases such as nitrous oxide (N2O), sulphur hexafluoride  (SF6)  and  others  (UNEP,  2020).  This  demonstrates  that  reductions  in industrial emissions are possible under the right regulatory conditions.

The  dominant  remaining  industrial  greenhouse  gas  is  CO2. Its  emissions  can  be divided into energy-related emissions from fossil fuel combustion to generate process heat  in  the  form  of  hot  water,  steam  and  direct  heat;  and  process  emissions  such as  those  from  limestone  calcination  during  the  cement-making  process.  Emissions also arise throughout the life cycles of industrial products, such as fugitive emissions during the use of solvents, lubricants and other compounds, and emissions from postconsumer plastic waste incineration.

This section focuses on options to reduce direct emissions from some key industry sub-sectors  related  to  fossil  fuel  combustion  and  industrial  processes.    All  types of  low-carbon  technologies,  including  renewable  energy,  electrification,  CCUS  and energy efficiency,  will  play  important  roles  moving  forward.  But  industry  also  has some unique opportunities related to the choice of feedstocks and product mixes that deserve more attention.

<!-- image -->

## CEMENT AND LIME

Cement is produced by mixing finely ground cement clinker with smaller quantities of other inorganic materials such as gypsum. Cement clinker, in turn, is produced by calcination of limestone. Calcinated limestone is the key component in cement, and calcination is the main energy-consuming process in the cement industry, which makes it very challenging to reduce CO2 emissions in this industrial sub-sector.

In  2016,  the  cement  industry  emitted  around  4  Gt  of  CO2,  with  around  2  Gt  of that total being process emissions. China is by far the largest producer of cement worldwide, accounting for 57% of global production in 2016, and it also had the largest global lime production in 2017; if India is included then two-thirds of global cement production  takes  place  in  just  two  countries.  In  the  Planned  Energy  Scenario,  the cement industry will increase its total emissions to 4.7 Gt/yr by 2050, as demand for cement increases 25%. In the Transforming Energy Scenario, emissions are reduced to just over 3 Gt/yr by 2050, but the cement sector remains the largest single source of CO2 emissions in industry.

Cement emissions from clinker manufacture have two main sources: 1) process CO2 released by the calcination of carbonate minerals (limestones) in the kiln feed, and 2)  energy-derived  CO2  released  by  combustion  of  the  fuels  used  to  heat  the  kiln feed. Cement clinker is characterised by a high level of process CO2 emissions due to the large proportion of limestone required for its manufacture and high process temperatures  of  1 000  °C  or  more.  The  chemical  precalciner  reaction  needed  to produce lime results in emissions of around 0.5 tonnes of CO2 per tonne of clinker that is the result of processing around 1.2 tonnes of limestone for the production of lime. This process results in around 60% of the total CO2 emissions from cement making.

The cement industry is not easy, because reducing CO2 emissions is challenging due to high process emissions related to the production of clinker. Cement clinker can be substituted with other materials that have similar properties, such as supplementary cementitious metals and alternative cement formulations. Unfortunately, properties and feedstock requirements limit the practical use of the formulations with high CO2 reduction  potentials.  In  the  short  term,  advanced  technological  and  experimental methods are needed to establish a better understanding of the potential of these alternative cements. These alternative binders could provide a simple yet promising solution for cement clinker replacement if they can compete on cost when deployed at industrial scale. Research and innovation are crucial, since the potential application of novel  binder  can  be  fully  realised  only  through  detailed  investigation  and characterisation of binders with the help of cutting-edge technologies.

Emissions can be reduced in cement by other means, including the use of biofuels, waste and other alternatives for process heating, and by efficiency measures resulting from the wide-scale adoption of best practices in cement making, such as efficient motors and grinding.

<!-- image -->

<!-- image -->

<!-- image -->

For these reasons, carbon capture, utilisation and storage warrants discussion for the cement industry, as no other major mitigation option for cement clinker making currently  exists.  CCUS  constitutes  a  niche  application  in  the  Transforming  Energy Scenario, limited to a few applications in industry. Nevertheless, there is a need to scale up CCUS to over 2 Gt per year to address CO2 emissions in a few industry segments, specifically in the cement sector. Further increases in CCUS may be necessary if the cement sector is to reach net-zero emissions. A co-benefit of using CCUS in cement kilns is that it could be combined with biomass combustion that would not only reduce emissions, but also create an opportunity to achieve negative emissions through the use of bioenergy CCS.

Lime is used in a wide range of products, with the largest applications in the iron and steel, pulp and paper, sugar and construction industries. In most industrialised countries, the lime industry consists of a small number of large corporations, while in most developing countries, lime kilns (ovens) are typically small operations using local technology. CO2 emissions arise in lime production from the decarbonisation of limestone and magnesium carbonate, from fuel combusted in the process and from indirect emissions from electricity consumed in the process. CO2 emissions reductions can  be  achieved  through  the  use  of  more  efficient  kilns  and  through  improved management of existing kilns using similar techniques to those in the cement industry.

## CHEMICALS AND PETROCHEMICALS

The chemical and petrochemical sector produces products that are derived from fossil  fuel  feedstocks as well as from other inorganic raw materials. The  organic chemical industry is the largest energy-using sub-sector and typically uses a steam cracking process to make olefins (ethylene, propylene and butadiene) from naphtha, ethane, propane or other crude oil-derived feedstocks. In addition to providing raw materials to produce organic chemicals and plastics, fossil fuels are an energy source. In contrast, inorganic chemicals production ( e.g. , chlorine, phosphate) also consumes energy, but uses much less than the production of organics and often in the form of electricity where emissions take place outside of the sector's boundaries.

In  2015,  this  industry  sub-sector  emitted  around  2  Gt  of  CO2  (including  process emissions),  and  in  the  Planned  Energy  Scenario  emissions  will  grow  to  2.8  Gt per year by 2050. In the Transforming Energy Scenario, emissions decline to just over 1 Gt using some of the technologies and processes listed in this section.

Chemicals and petrochemical products have wide, consolidated demand today, and most of them could be displaced in alternative ways, such as power-to-chemicals and  biomass-based  products. Most  of  the  industry's  activities  ( i.e. , refineries, ammonia production, bulk chemicals, etc.) rely on hydrogen from fossil fuels, a wellestablished industry with decades of experience. Hydrogen from renewables thus has the potential to replace fossil fuel-based feedstocks in high-emissions applications. In order to make the synthetic fuels and feedstocks from hydrogen, a source of CO2 will be needed (or nitrogen in the case of ammonia). Several options exist, but the use of CO2 from direct air capture or CCUS from bioenergy are two possible sources.

The  growth  of  the  petrochemical  industry,  and  especially  the  surge  in  the  use  of single-use plastic that is then usually incinerated, is increasing the difficulty of cutting emissions from the sector (Pooler, 2020). Bioplastics made from renewable sources such  as  sugar  cane  or  starch  are  promising  sustainable  alternatives  to  traditional plastics.

A complementary option is the circular economy, which includes recycling, reuse, materials substitution and more efficient materials design. However, new economic and financing tools,  new regulatory frameworks and even digital marketplaces for the management of a circular economy would be needed to promote and steer its development. Similarly, a societal rethinking will be essential to promote customer interest and to acknowledge the value that can be created by the shift from a linear economy to a circular one.

## IRON AND STEEL

Production of iron and steel is one of the largest sources of industrial emissions, representing up to 9% of global fossil fuel CO2 emitted in 2017. A significant share of the total energy consumed for iron and steel production comes from the use of coal and coke as chemical reducing agents for iron production in traditional blast furnaces that result in CO2 emissions. Coal and coal by-products represent 78% of the sector's total energy demand (accounting for the energy content of blast furnace and coke oven gases as by-products).

In 2016, the sector emitted a combined total of just over 3 Gt (including process emissions) of CO2, and under the Planned Energy Scenario this would remain stable. Demand for steel and iron would increase around 15% over the period in this scenario, but advances in manufacturing efficiency and recycling would keep emissions stable. In the Transforming Energy Scenario, emissions would decline to 1.2 Gt/yr by 2050, assuming  that  some  of  the  following  technologies  and  approaches  become  more widespread.

The industry is pursuing several key low-emission production routes that would help accomplish further reduction. The first is hydrogen from renewables, which has received increasing attention as an enabler of emissions reductions in the production of  iron  through  the  direct  reduction  of  iron  ore    (IRENA,  2019g).  Hydrogen-based iron  making  is  technically  feasible  ( i.e. ,  direct  reduced  iron,  or  DRI),  and  various producers are working to develop this option further (Gielen et. al. ,  2020; HYBRIT, 2016; GrInHy2.0, 2019). The second is the application of CO2 capture and storage to processes that rely on coal and coke (European Commission, 2016). However, project costs have turned out to be higher than anticipated, and development has stalled.

In addition, biomass products can substitute for coal and coke. For instance, in Brazil, small-scale blast furnaces that use charcoal for iron production are being deployed on a significant scale, with biomass being co-processed in coke ovens. Another option is  for  the  steel  industry  to  relocate  electric  arc  furnaces  to  areas  with  ample,  lowcost renewable electricity. The sector has already begun building new facilities where inexpensive renewable electricity is available in abundance, such as the Nucor and EVRAZ plants in the United States that will be powered mostly by wind and solar PV.

<!-- image -->

<!-- image -->

## ALUMINIUM

Aluminium production has the highest energy demand of any non-ferrous metal.

The  production  of  aluminium  accounts  for  around  0.8%  of  global  greenhouse  gas emissions, and it is the largest electricity-consuming portion of the manufacturing industry, accounting for more than 800 TWh of electricity use in 2015. Fossil fuels are consumed for alumina production, while most of the energy used in the aluminium industry is in the form of electricity used for smelting. The smelting of aluminium is a very energy-intensive process, and over 80% of smelting greenhouse gas emissions are indirect (electricity-related) emissions. The remaining emissions come from direct (on-site) emissions plus the emissions associated with the production of alumina.

In the Transforming Energy Scenario, aluminium production grows from 167 Mt per year in 2015 to 269 Mt per year in 2050; however, CO2 emissions decline by more than 70% compared to the Planned Energy Scenario in 2050. Much of the reduction is  the  result  of  a  power  system  with  86%  renewable electricity,  but  reductions  are also  achieved  from  reduced  anode  use,  since  less  primary  aluminium  is  produced (after accounting for the increase in direct CO2 emissions from switching to recycled aluminium  production).  The  remainder  of  the  reduction  is  from  energy  efficiency measures  (including  gains  from  novel  smelting  technologies)  and  biofuels  use  in alumina plants. A key step would be to continue locating plants to areas with available renewable electricity as the share of renewables increases in power generation.

The  sector  could  potentially  have  the  highest  use  of  renewables  among  all industry  sectors,  with  the  share  of  renewables  jumping  to  60%  by  2050  under the Transforming Energy Scenario. This is an outcome of significant electricity use in  production  processes  coupled  with  renewable  power.  In  addition,  the  share  of recycled aluminium production would reach half of all production. One option for the industry is to relocate smelting to areas with ample, low-cost renewable electricity. The aluminium sector has already begun building new facilities where inexpensive renewable electricity is available in abundance, such as in Iceland.

A number of emerging technologies already exist to reduce the electricity needed for  smelting,  while  biofuels  can  easily  replace  fossil  fuels  in  low-  and  mediumtemperature  alumina  production. The  challenge  is  to  accelerate  the  adoption  of these new approaches, especially in this subset of the industry sector where energy costs play a large role in business decisions. In addition, aluminium smelters can act as virtual batteries for the integration of variable renewable energy (Amelang, 2017). They can operate with surplus renewable electricity, thereby increasing flexibility to power systems and further increasing the viability of siting smelters in areas with an ample supply of VRE sources.

<!-- image -->

## 5.7  Challenging sectors: Natural gas infrastructure

Some argue that natural gas is an appropriate fuel for the energy transition due to its lower carbon emissions compared to other fossil fuels, and its use is growing worldwide. However, while natural gas does have lower carbon intensity than other fossil fuels, it is not a zero-carbon solution. The carbon intensity of natural gas use also can vary greatly based on whether the gas is consumed locally via a pipeline, or  converted  to  LNG  and  transported  long  distances.  For  instance,  the  life-cycle carbon intensity of natural gas exported from the United States to Europe or Asia for use in power generation can add almost 30% to the carbon intensity of the fuel, when all steps are considered, from liquefaction, to transport, to regasification and conversion (Traywick et. al. , 2020). Additionally, methane leakage during production and distribution can be substantial, further increasing the associated warming effect attributed to natural gas (Alvarez et. al. , 2018).

In  the  context  of  policy  objectives  of  'zero'  or  'net-zero'  emission  energy systems, projects that are now under construction or planned in the natural gas industry are not consistent with these goals. This raises questions about the future use of gas infrastructure and the risks associated with investments in the natural gas supply - that is, stranded assets and high costs to decommission gas infrastructure. The reuse of the gas infrastructure for green gas, such as carbon-free hydrogen and biomethane, thus offers a strategy for helping to avoid stranding assets while also accelerating greenhouse gas mitigation.

Gas systems can be greened using a combination of upgraded biogas, synthetic methane produced from green hydrogen and CO2, as well as direct green hydrogen injection into the grid. All three options present interesting emerging opportunities for the use of gas infrastructure, which can help minimise asset stranding, as well as create opportunities for accelerated deployment of renewable energy.

The global biogas supply in 2015 was 1.5 EJ, which represents under 0.5% of total global energy. However, the global potential of biogas could reach more than 35 EJ (IRENA, forthcoming d), which could meet around 30% of natural gas demand. In the Transforming Energy Scenario, biogas supply would increase to 14.4 EJ by 2050 - ten times today's level.

The production of hydrogen or synthetic methane from renewables is technically feasible, although  currently  costly. In the longer term, cost reductions for electrolysers and the continually falling costs of renewable electricity will improve the economics of hydrogen from renewable sources in the coming decade. The transport of hydrogen via existing and refurbished gas pipelines is currently being explored, with the upgrading of pipelines required when concentrations of hydrogen start to exceed around 20% of the total gas.

Using more hydrogen might reduce new infrastructure investment needs and help to accelerate a transition, but it would also mean that equipment standards would need to be adjusted, which may take time. This potential for switching to hydrogen should not be used as a justification to build new pipelines for 'brown gas' now, with the excuse of replacing it with 'green gas' in the future. Gas and hydrogen should become greener as soon as possible to avoid any additional contribution to emissions.

<!-- image -->

<!-- image -->

## 6.1  A transformative transition

As countries around the world grapple with the challenge of transforming an energy system - and by extension a global economy - that relies on polluting conventional energy resources, notions of a 'Green New Deal' are receiving growing attention. Both the name and the underlying intent are inspired by the massive mobilisation of resources and institutional capacity that took place under the New Deal launched by U.S. President Franklin Delano Roosevelt in the 1930s. The original New Deal entailed fiscal,  monetary  and  banking  reforms;  public  works;  and  a  series  of  regulatory measures adopted in response to the devastating global financial crisis known as the Great Depression.

In the aftermath of another financial crisis, the Great Recession of 2008, Roosevelt's idea  was  revived  in  form  of  a  global  Green  New  Deal.  Scholars  and  international institutions such as the United Nations Environment Programme called for the new scheme  to  incorporate  the  climate  change  dimension  (Simms  et  al.,  2008;  UNEP, 2009), amid growing acknowledgment of the close interconnections between socioeconomic and environmental dynamics.

Today, the confluence of concerns over social justice, economic inequality, and rapidly mounting climate threats is driving renewed discussions about a global Green New Deal. As illustrated in Figure 6.1, the concept is essentially a comprehensive policy package that aims to bring together the objectives of achieving climate goals; fostering economic development and jobs creation; and guaranteeing social equity and welfare for society as a whole. The energy transition is at the heart of these objectives.

Figure 6.1      The global Green New Deal: At the heart of solutions to achieve social, economic and environmental objectives The broader objectives of a Green New Deal

<!-- image -->

Several different approaches to making economies fit for purpose in today's world have  been  proposed.  Despite  different  circumstances,  institutional  contexts  and geographies, these initiatives share several characteristics:

- · They acknowledge the need for unprecedented action in the face of grave socioeconomic and environmental dangers , calling for the mobilisation of resources on a scale commensurate with the existential crisis.
- · They endorse or imply the need for greater public intervention as a remedy. This view is in line  with  the  perspective  that  market-driven approaches alone will not suffice and that strong policy tools are needed to reach targets for reductions in greenhouse gas emissions determined to be scientifically necessary.
- · They emphasise the opportunities for tackling other social issues simultaneously (such as equity, the sustainable use of resources, and human health), thus producing synergies and greater prosperity for all.
- · They regard justice for workers and communities affected by necessary economic restructuring as an essential priority of  the energy transition - as expressed, for example, in the European Green Deal - so that the carbon neutrality goal by 2050 goes hand in hand with a socially inclusive approach (see Box 6.1).

Whether  a  given  set  of  policies  incorporates  the  words  'Green  New  Deal'  is  less important than its recognition of the imperative of a transformative decarbonisation of societies. This far-reaching form of decarbonisation requires a holistic approach to addressing linked economic, social and ecological problems (Asici and Bunul, 2012), and to advancing the energy transition. Many parts of the world are still recovering from the financial crisis that began in 2008, and yet massive financial resources must be mobilised now to combat climate change.

<!-- image -->

The energy transition is at the heart of achieving climate goals; fostering economic development and job creation; and guaranteeing social equity and welfare for society as a whole.

## Box 6.1     HE JUST TRANSITION MECHANISM T OF THE EUROPEAN GREEN DEAL

The European Green Deal proposed by the European Commission in December 2019  recognises  that  climate  change  and  environmental  degradation  pose an  existential  threat  to  the  region  and  the  world.  The  proposal  presents  a new  growth  strategy  to  make  the  Union's  economy  resource-efficient  and competitive, with the goal of achieving climate neutrality by 2050. The European Green Deal outlines  investments  and  innovations  focused  on  decarbonising the energy sector, making buildings more energy-efficient, increasing cleaner forms of transport, and supporting greater sustainability in industry, among other objectives.

To reach these goals, a European Green Deal Investment Plan is to mobilise at least EUR 1 trillion over a decade. The initiative acknowledges that the energy transition will entail profound economic and social transformations, and that some regions of Europe will be affected differently from others. As part of the plan, the 'Just Transition Mechanism' will seek to mobilise at least EUR 100 billion over the period 2021-2027 to support workers and citizens in the regions hit hardest by the transition. The following financing sources have been identified:

- ·   A  'Just  Transition  Fund'  with  EUR  7.5  billion  in  fresh  EU  funds.  Matching funds from Member States, the European Regional Development Fund and the European Social Fund Plus will bring funding to EUR 30-50 billion.
- ·   A dedicated 'Just Transition Scheme' under InvestEU, with the objective of attracting private investment to support regions in decarbonising, diversifying and strengthening their economies, may mobilise up to EUR 45 billion.
- ·   A 'Public Sector Loan Facility' from the European Investment Bank, backed by the EU budget, is to mobilise another EUR 25-30 billion for purposes such as district heating networks and building renovation.

Sources: European Commission, 2019a and 2020.

<!-- image -->

<!-- image -->

## 6.2  Overcoming challenges

Done right, the energy transition not only avoids the use of polluting fuels but creates a vibrant, climate-resilient economy with benefits for all. IRENA's analysis shows that its transition pathway offers strong employment and welfare gains.

Despite positive outcomes at the global level, IRENA's analysis also indicates that the energy transition will generate highly diverse outcomes for regions and countries (see Chapter 4). Individual countries embark on the transition from different starting points defined by their existing socio-economic structures. Their pathways are also strongly influenced by their level of policy ambition. Two sets of conditions influence the ability of countries to derive benefits from the energy transition: (1) the depth, strength and diversity of their national supply chains; and (2) varying degrees of dependency on fossil fuels and other commodities, technologies and trade patterns (see Figure 6.2).

Figure 6.2     Diverse energy transition outcomes for regions and countries

Structural elements that shape the outcomes of the energy transition

<!-- image -->

Adapted from IRENA, 2020a

Policies devised to drive and support the energy transition and the broader economic transformation must be built on the strengths of individual countries.

As the transition progresses, the differing structural realities in individual countries translate into both challenges and opportunities. Policies devised to drive and support the energy transition and the broader economic transformation must be built on the strengths of individual countries. But they must equally enable them to overcome their structural  dependencies so as to take fuller advantage of emerging opportunities. Among these dependencies, three types stand out, namely commodity dependence, technological dependence and trade dependence.

Commodity dependence . Any  energy  system brings with it a certain dependence on basic commodities (fuels, metals, and other materials) that may be more readily available in some countries than in others. This dependence, which can take a variety of  forms,  manifests  itself  not  only  in  the  energy  sector,  but  also  in  the  economy at  large.  The  economies  of  over  half  the  countries  of  the  world,  and  two-thirds  of developing countries, are regarded as commodity-dependent in terms of their export profiles (UNCTAD, 2019).

Beyond  export  revenues,  dependence  extends  to  the  many  facilities  needed  for extracting,  processing,  and  selling  energy,  and  has  implications  for  the  sectors providing supply-chain inputs, as well as for institutions that educate and train the workforce. However, dependence is hardly limited to sellers. Energy importers, too, have  built  up  extensive  infrastructures,  distribution  networks,  assets  and  human know-how around oil, gas and coal.

Such  forms  of  dependence  may  become  a  liability  as  the  energy  transition  unfolds. Fossil fuel exporters are expected to face reductions in market demand in the context of growing movements for fossil fuel divestment and decarbonisation (Elgouacem et al. , 2020). Both sellers and buyers are increasingly exposed to the risks of stranded assets.

Technological dependence. The  capacity  to  innovate,  develop  and  commercialise technologies is an important indicator of a country's ability to push ahead and take advantage of emerging economic opportunities.

Patent filings are one way to assess countries' technological innovation capabilities. Figure  6.3.  shows  that  during  2018,  three  quarters  of  patents  pertinent  to  the renewable energy sector were filed in just four countries. Many countries are unlikely to be able to integrate the high value-added segments of renewable energy value chains and generate associated employment unless, as described in the next section of this chapter, they take urgent steps towards building and leveraging local capabilities.

Cross-economy linkages are typically less pronounced in construction or in operations than in manufacturing, which requires a multitude of components and other inputs from a range of sectors. This is precisely why technological dependence could become an obstacle to unleashing the wider socioeconomic benefits of the energy transition.

Figure 6.3      Renewable energy innovation: Leading countries

Patents filed for renewable energy technologies in 2018

<!-- image -->

Source: IRENA online patent data platform

The starting point of a country - as expressed in its pre-existing productive capabilities and resource endowment - plays an important role in its ability to develop renewables and other green technologies. Some countries have succeeded in strengthening their capabilities and integrating high value-added segments of renewable energy value chains.

China  is  an  example,  given  its  emergence  as  the  dominant  low-cost  producer  of renewable energy technologies such as photovoltaic cells and modules. The country has pursued a mix of enabling policies (see Figure 6.4) and was able to draw on its well-developed domestic supply chains and manufacturing clusters, as in the Yangtze River Delta (Ball et al. , 2017). Similarly, Brazil succeeded in developing a competitive wind turbine manufacturing sector by leveraging pre-existing domestic capabilities in aircraft manufacturing (see Box 6.2).

<!-- image -->

## Box 6.2     EVERAGING CAPACITIES TO SUPPORT L THE ENERGY TRANSITION: THE CASE OF BRAZIL

Innovation scholars argue that catching up with advanced economies involves taking advantage of the window of opportunity temporarily created by  technological  transitions  (Perez  and  Soete,  1988;  Lee,  2013).  The  energy transition  may  represent  such  a  chance  for  developing  countries.  The  key question is how countries can best exploit industrial opportunities presented by  the  transition  and  the  attendant  expansion  of  global  renewable  energy value chains.

Pre-existing  productive  capabilities,  particularly  in  manufacturing  sectors with high spillovers to the rest of the economy, appear to play a key role for innovation in green technologies (Anzolin and Lebdioui, forthcoming). In the case  of  Brazil,  Hochstetler  (forthcoming)  shows  that  among  the  key  factors behind  the  success  of  the  wind  turbine  manufacturing  sector  was  a  mix  of industrial policies, financial incentives and tax exemptions, and the leveraging of pre-existing domestic capabilities in aircraft manufacturing.

Whether  developing  countries  can  acquire  the  capabilities  needed  to  take advantage of current opportunities in green technology development therefore depends on several factors. Not all countries will necessarily be able to replicate such experiences, and new patterns of dependence could emerge. As noted by  the  United  Nations  Economic  and  Social  Council  (2019),  'for  developing countries  that  lack  domestic  technological  and  policy  capabilities  related  to frontier technologies, fulfilling their potential in this regard will require capacity development efforts and related resource support.'

<!-- image -->

As the energy transition takes hold, new types of dependencies are emerging, not only  in  renewable  energy  technologies  directly,  but  also  in  related  fields  such  as battery storage technologies and materials. At present, the bulk of lithium-ion battery production takes place in a few Asian countries, a situation that is giving rise to efforts elsewhere, such as Europe, to limit this new form of technological dependence (Martín, 2019; European Commission, 2019c).

Trade dependence. As renewable technologies become more affordable, more and more countries undoubtedly benefit from increased access to clean energy. However, the  design  and  manufacturing  of  the  bulk  of  renewable  energy  equipment,  along with high-value service inputs, still resides in a handful of countries. Many countries, especially those in the developing world, remain consumers rather than producers of technologies such as solar PV panels and wind turbines, limiting associated jobs and other socio-economic benefits deleting to construction, operations and maintenance. These segments of the value chain tend to be low value-added, with limited economic multipliers and fewer cross-linkages to other sectors.

Unless they are able to diversify into higher value-added activities, many countries may not be able to maximise the benefits that arise from the energy and green economy transitions. This presents policy makers with some basic choices, i.e. , whether to focus on making renewable energy imports as cheap as possible, or to take steps to nurture local capacities and localise certain inputs along the value chain.

These  choices  will  be  contingent  on  the  specific  circumstances  of  each  country, notably its market structure and socio-economic outlook. Some countries may find it  of interest to build local capacities. In such cases, a logical progression might be to  start  with  domestic  assembly  of  equipment;  then  to  develop  specifications  and standards  that  enable  locally  appropriate  equipment  designs;  and  eventually  to move into manufacturing certain components or to provide various services linked to renewable energy projects.

Unforeseen  developments. The  dependencies  discussed  above  are  structural  in nature and accordingly will require persistent efforts to overcome. The outbreak of the coronavirus and its impact on economic growth and oil demand1 and price, serve as  reminders that in a complex world, there are also unforeseen factors that have the potential of disrupting an actual trend or a planned process. It highlights a key contention of this report, namely that the close inter-connections between the energy system and the wider economy are of prime importance.

The close inter-connections between the energy system and the wider economy are of prime importance for a successful energy transition.

1 The International Energy Agency in revising expectations for demand growth. said global oil demand is set to contract in 2020 - the first full-year decline in more than a decade.

The  outbreak  of  coronavirus  will  have  an  impact  on  the  energy  transition  too, threatening  global  supply  chains  in  many  sectors  (Economist,  2020).  The  oil  price volatility can  have  contradictory  effects,  such  as  undermining  the  viability  of unconventional oil and gas resources as well as long-term contracts or lowering fuel costs for motorists, which may encourage more driving and could lessen the appeal of electric vehicles. The severity and duration of the impacts in both cases remain to be seen but will not change the path required to build a low-carbon society.

The bottom line. The foregoing dependencies underscore the need for careful crafting of a series of policy interventions to enable a transition in which no one is left behind. A just and inclusive transition requires a global compact among countries, adequate mobilisation of resources and a tailoring of measures attuned to the challenges faced by various countries.

## 6.3  Policy interventions for a decarbonised society

IRENA's transformation scenarios aim to move the world towards meeting the goals of  the  Paris  Agreement.  The  Transforming  Energy  Scenario,  if  achieved,  will  result in  a  70%  reduction  in  CO   emissions  by  2050,  setting  the  world  on  a  path  toward 2 limiting the rise in the average global temperature to well below 2°C. It is an ambitious goal, yet an achievable one if resources are mobilised and policies initiated at a level commensurate with the challenge.

Ensuring that global temperatures stop climbing will require that early in the second half of this century, net emissions reach zero. Additional mitigation measures will be needed as outlined in IRENA's Deep Decarbonisation Perspective, which highlight the important role of emerging technologies in mitigating CO2 emissions stemming from energy production, transport, industrial processes and wasteful behaviours.

The  energy  transition  is  playing  out  in  the  context  of  intricate  interactions  of  the energy system with the wider economy and the natural environment (IRENA, 2018a). The associated socioeconomic results, analysed at the global level (Chapter 2) and regional level (Chapter 4), provide essential insights for transition planning and policy making. The contours of a policy framework that considers the economic structure and elements for a just transition are illustrated in Figure 6.4. The specifics will vary from country to country, but a comprehensive package will have to include a broad mix of policies and interventions, including deployment and integrating policies and a set of closely connected enabling policies, as described below.

<!-- image -->

Figure 6.4     A comprehensive package: Deployment, enabling and integrating policies Policy framework for a just transition

Source: IRENA (2019q)

<!-- image -->

Co-ordinated deployment policies and related measures are required to facilitate the integration of renewables into energy distribution systems and end-use applications, and to ensure sufficient system flexibility as variable renewables grow in importance (IRENA, 2019q).

Enabling policies ensure that the energy transition is implemented in ways that are broadly beneficial and that avoid or minimise dislocations for individuals, communities, countries and regions. They include the following:

- ·   Well-designed industrial policies that build, enhance, and appropriately leverage domestic economic capacities (IRENA, 2017e, 2017f and 2018d), based on a careful

analysis of relevant and transferable material assets and human expertise. Enhancing and leveraging domestic capabilities requires carefully crafted incentives and rules, business-incubation  initiatives,  supplier-development  programmes,  support  for small and medium enterprises, and promotion of key industry clusters.

- ·   Effective labour-market interventions that  offer  adequate  employment  services (matching jobs with qualified applicants; promoting employee well-being; facilitating on- and off-job training; and implementing job safety nets), along with measures to facilitate labour mobility, such as relocation grants.
- ·   Targeted educational and skills development policies  and  programmes  to  take  full advantage of the job opportunities that emerge from the energy transition. Co-ordinated by government, strategic collaboration between educational institutions and renewable energy industries can help to reduce or avoid mismatches between skills demand and supply. Special attention is needed to detect opportunities for reorienting the skills and expertise of fossil fuel workers towards the clean energy sector.
- · Social-protection  measures that  provide  support  for  vulnerable  workers  and  their communities so that they do not shoulder an unfair burden of the energy transition. This includes measures for income stability through unemployment insurance and other programmes, policy incentives for employers to retain (and retrain) workers where possible, and flexible, longer-term employment contracts to promote job stability.
- ·   Proactive just-transition strategies designed to minimise socio-economic disruption. In addition to the policies enumerated above, these may also encompass public investments and economic diversification measures for affected regions and communities.

Many of the measures discussed here involve governmental action. But one of the distinguishing marks of many renewable energy technologies is that their decentralised aspects allow citizens to be more involved and empowered in the energy transition, as recognised by the European Union's new electricity market rules in 2019. 2  Community energy  projects  can  bring  about  a  greater  degree  of  democratisation  of  energyrelated decision making, and thus be an important component of a broader societal transformation spurred by energy transition.

2 Welcoming the European Parliament's adoption of new proposals for the design of electricity markets, the European Commission commented: 'Through the revised Directive, these new rules will put consumers at the heart of the transition - giving them more choice and greater protection. Consumers will be able to become active players in the market thanks to access to smart meters, price comparison tools, dynamic price contracts and citizens' energy communities. At the same time, energy poor and vulnerable consumers will enjoy better protection' (European Commission, 2019b).

<!-- image -->

## 6.4    Foundations for success: Financial mobilisation, policy cohesion and international co-operation

The  global  energy  transition  requires  an  unprecedented  mobilisation  of  financial resources, driven by the unwavering commitment of governments, the private sector and  civil  society.  Governments  must  adopt  a  wide  array  of  policies  to  strengthen public resolve and ensure that no one is left behind. As the massive financial resources mobilised to counter the 2008 economic crisis demonstrated, countries and societies are collectively capable of such ambitious undertakings. The uncharted territory of COVID-19 and its aftermath presents now another test of our shared resolve for a better future.

Financial  mobilisation  underpinning  energy  transitions  around  the  world will require far larger sustained investment in clean energy solutions, including renewable energy  and  related  technologies,  such  as  efficiency,  storage  and  on-  or  off-grid electrification. Energy investments must occur in tandem with ample funds to minimise social dislocation. Along with ensuring access to clean energy for every individual and community, adjustments must be made to ensure a smooth transition. These include diversifying and revitalising local and regional economies; introducing measures to retrain workers and impart new skills; and offering social-protection programmes.

Strengthening institutions and policy cohesion will be essential. At the national level, robust  institutions  and  dedicated  energy  transition  policies  are  decisive  in  driving change at the required scale and pace. Energy ministries have a crucial role in setting out policies and enabling frameworks, but cohesion across sectors and agencies is essential  to  achieve  a  broad  economic  and  industrial  transformation.  Success  will depend on collaboration among a broad range of stakeholders.

International co-operation is  equally  important,  not  least  because  of  tremendous variations in the ability of individual countries to marshal necessary resources, increase institutional capacities and develop technical know-how. A shared willingness to draw on lessons learned and best practices can herald a strengthened multilateralism for decarbonisation. Such international co-operation must address the needs of countries at varying stages of their energy transitions, ranging from some being committed to carbon neutrality or 100% renewables, to others still at the early stages of tapping their renewable energy resources.

At the same time, international co-operation must be creative enough to overcome challenges and help to accelerate the global learning curve. It must be agile enough to  respond  to  unexpected  developments  and  disruptions  during  the  long-term undertaking to build decarbonised societies and economies.

IRENA, encompassing 160 member countries and over 20 states in accession in early 2020, provides a valuable avenue for co-operation. Its robust and timely knowledge base  and  comprehensive  range  of  platforms,  partnerships  and  tools,  reflects continuous, active engagement on energy transitions worldwide. Established in 2011, the  intergovernmental  agency  works  with  governments,  key  global  and  regional organisations  and  the  private  sector  to  bring  about  a  sustainable  and  equitable energy future.

The recently formed Climate Investment Platform (CIP) provides a prime example of international co-operation to advance clean energy. Announced at the UN Secretary General's Climate Action Summit in September 2019, it is led by the United Nations Development Programme (UNDP), Sustainable Energy for All (SEforALL) and IRENA in  co-operation  with  the  Green  Climate  Fund  (GCF).  Working  with  all  interested partners, the CIP aims to mobilise investments in alignment with climate objectives, with an initial focus on regional and national energy transitions. To promote targeted action  on  the  ground,  IRENA  is  co-ordinating  the  development  of  sub-regional operational  frameworks  for  CIP  implementation.  As  part  of  this  effort,  IRENA  will convene regular investment forums at the regional level to support decision makers in creating enabling conditions, assist developers in preparing bankable projects, and improve access to finance. 2

Ultimately, advancing the global energy transition will depend on the policies that are adopted, the speed at which they are deployed and the level of resources committed. In  our  interconnected  world,  international  co-operation  and  solidarity  are  not  only desirable; they are a vital condition to address climate change, economic inequality, and social injustice.

Moving forward, therefore, every investment decision should be based on its potential to accelerate the structural shift towards inclusive, low carbon economies. Anything short  of  this  can  severely  obstruct  the  paths  to  be  followed  for  a  transformative decarbonisation of societies.

2 o learn more, see: T https://irena.org/irenaforcip.

<!-- image -->

Moving forward, all investment decisions should be assessed on the basis of their potential to dramatically accelerate the structural shift towards an inclusive low-carbon economy.

## REFERENCES

Alvarez, R. A. et al. (2018) , 'Assessment of methane emissions from the U.S. oil and gas supply chain', Science 361, 186-88, https://doi.org/10.1126/ science.aar7204.

Amelang, S. (2017) , 'How can Germany keep the lights on in a renewable energy future?' Clean Energy Wire, 26 January, www.cleanenergywire. org/factsheets/how-can-germany-keep-lightsrenewable-energy-future.

Anzolin, G. and Lebdioui, A. (forthcoming) , 'The Holy Trinity: Industrial policy, climate change and sustainable green growth', European Journal of Development Research .

Asici, A.A., Bünül, Z. (2012) , Green new deal: a green way out of the crisis? Environment Policy Governance 22 (5), 295-306.

Ball, J. et al. (2017) , The new solar system: China's evolving solar industry and its implications for competitive solar power in the United States and the world , Steyer-Taylor Center for Energy Policy and Finance, Stanford University, March.

BNEF (2020) , Sector Coupling in Europe: Powering Decarbonisation, Potential and Policy Implications of Electrifying the Economy , Bloomberg New Energy Finance.

Bohlsen, M. (2020) , 'Lithium miners news for the month of January 2020', Seeking Alpha, https:// seekingalpha.com/article/4318882-lithium-minersnews-for-month-of-january-2020 (accessed 3 March 2020).

Bosch, J., Staffel, I. and Hawkes, A. D. (2018) , 'Temporally explicit and spatially resolved global offshore wind energy potentials', Energy 163, 76681, https://doi.org/10.1016/j.energy.2018.08.153.

Bosch, J., Staffel, I. and Hawkes, A. D. (2017) , 'Temporally-explicit and spatially-resolved global onshore wind energy potentials', Energy 131, 207-17, https://doi.org/10.1016/j.energy.2017.05.052.

Butler, N. (2020) , 'It is time to unlock the potential of hydrogen', Financial Times , 2 February, www.ft.com/ content/8505cb1c-4354-11ea-abea-0c7a29cd66fe.

Deng, Y. Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. and de Jager, D. (2015) , 'Quantifying a realistic, worldwide wind and solar electricity supply',

Global Environmental Change 31 , 239-52, https://doi. org/10.1016/j.gloenvcha.2015.01.005.

DNV-GL (2019) , Energy transition outlook 2019. A global and regional forecast to 2050 , https://eto. dnvgl.com/2019.

Economist (2020) , 'The new coronavirus could have a lasting impact on global supply chains', 15 February, www.economist.com/ international/2020/02/15/the-new-coronaviruscould-have-a-lasting-impact-on-global-supplychains.

Elgouacem, A., Halland, H., Botta, E. and Singh, G. (2020) , The fiscal implications of the low-carbon transition , Organisation for Economic Co-operation and Development, Paris.

Enerdata (2019) , 'Share of wind and solar in electricity production', Global Energy Statistical Yearbook 2019 , https://yearbook.enerdata.net/ renewables/wind-solar-share-electricity-production. html (accessed 5 March 2020).

Equinor (2019) , Energy perspectives 2018: Longterm macro and market outlook , June, www.equinor. com/en/news/energy-perspectives-2019-delayingclimate-action-increases-the-challenge.html.

European Commission (2020) , 'The European Green Deal Investment Plan and Just Transition Mechanism explained', 14 January, https:// ec.europa.eu/commission/presscorner/detail/en/ qanda\_20\_24.

European Commission (2019a) , 'A European Green Deal. Striving to be the first climate-neutral continent', https://ec.europa.eu/info/strategy/ priorities-2019-2024/european-green-deal\_en.

European Commission (2019b) , 'Clean Energy for All Europeans: Commission welcomes European Parliament's adoption of new electricity market design proposals', 26 March, https://ec.europa.eu/ commission/presscorner/detail/en/IP\_19\_1836.

European Commission (2019c) , 'European Battery Alliance', https://ec.europa.eu/growth/industry/ policy/european-battery-alliance\_en.

European Commission (2016) , 'STEELANOL', Innovation and Networks Executive Agency, European Commission, https://ec.europa.eu/inea/ en/horizon-2020/projects/h2020-energy/biofuels/ steelanol (accessed 4 March 2020).

Fink, L. (2020) , 'Larry Fink's letter to CEOs', BlackRock, USA.

FS-UNEP and BNEF (2019) , Global trends in renewable energy investment 2019 , Frankfurt School UNEP Collaborating Centre for Climate &amp; Sustainable Energy Finance, Frankfurt, www.fs-unep-centre.org.

FT (2019) , 'Tata to build UK's biggest carbon capture project', Financial Times , 26 June, www.ft.com/content/ b45d94b6-97fc-11e9-8cfb-30c211dcd229.

Gielen, D. and Saygin, D. (2018) , Global industrial carbon dioxide emissions mitigation: Investigation of the role of renewable energy and other technologies until 2060 , Colorado School of Mines, Payne Institute, Golden, Colorado.

Global Carbon Atlas (2019) , Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/ essd-11-1675-2019.

Global Petrol Prices (2019) , 'Electricity prices around the world', www.globalpetrolprices.com/ electricity\_prices/ (accessed 5 March 2020).

Greenpeace (2015) , Energy [r]Evolution. A sustainable world energy outlook 2015 , Greenpeace, SolarPower Europe and Global Wind Energy Council, Brussels.

GrInHy2.0 (2019) , 'GrInHy2.0', www.green-industrial-hydrogen.com (accessed 4 March 2020).

GWEC (2020) , Global wind report 2019 , Global Wind Energy Council, Brussels.

Healy, C. and Marchand, T. M. (2019) , SEA change: Delivering a zero carbon economy in Southeast Asia , E3G, Berlin.

Hill, J. (2020) , 'Germany hits record 61 per cent renewables for month of February 2020', RenewEconomy, 2 March, https://reneweconomy. com.au/germany-hits-record-61-per-centrenewables-for-month-of-february-99434.

Hinge, D. (2019) , 'BIS launches green bond fund for central banks', Central Banking, 27 September, www. centralbanking.com/central-banks/reserves/4456611/ bis-launches-green-bond-fund-for-central-banks.

Hochstetler, K. (forthcoming) , Political economies of energy transition: Wind and solar power in Brazil and South Africa , Cambridge: Cambridge University Press.

HYBRIT (2016) , 'HYBRIT - Fossil-free steel', www. hybritdevelopment.com (accessed 4 March 2020).

Hydropower &amp; Dams (2014) , Hydropower &amp; Dams - World Atlas , International Journal of Hydropower and Dams, https://www.hydropower-dams.com/ world-atlas/ (accessed 5 March 2020).

IEA (2019a) , World Energy Outlook 2019 , Analysis, International Energy Agency, Paris.

IEA (2019b) , IEA Beyond 20/20 - 2019 edition , International Energy Agency, Paris.

IEA (2019c) , World Energy Investment 2019 - Analysis , International Energy Agency, Paris.

IEA (2017) , IEA Bioenergy annual report 2017 , International Energy Agency, Paris.

IEA and IRENA (2017) , Perspectives for the energy transition: Investment needs for a low-carbon energy system , International Energy Agency and International Renewable Energy Agency, Paris and Abu Dhabi.

IEA, IRENA, UNSD, World Bank and WHO (2019) ,

Tracking SDG7: The Energy Progress Report 2019 , International Energy Agency, International Renewable Energy Agency, United Nations Statistics Division, World Bank and World Health Organization, Washington, D.C.

IMF (2019) , The economics of climate - Finance and development - A quarterly publication of the International Monetary Fund , International Monetary Fund, Washington, D.C.

IMO (2018) , 'Low carbon shipping and air pollution control', International Maritime Organization, www.imo.org/en/MediaCentre/HotTopics/GHG/ Pages/default.aspx (accessed 4 March 2020).

IPCC (2018) , Global warming of 1.5°C: An IPCC Special Report on the impacts of global warming of 1.5°C above pre-industrial levels and related global greenhouse gas emission pathways , Intergovernmental Panel on Climate Change, Geneva.

IPCC (2014) , Climate Change 2014: Synthesis Report. Contribution of Working Groups I, II and III to the Fifth Assessment Report of the Intergovernmental Panel on Climate Change , Intergovernmental Panel on Climate Change, Geneva.

IRENA (forthcoming a) , Cost reduction potential for solar and wind to 2030 in the G20 , International Renewable Energy Agency, Abu Dhabi.

IRENA (forthcoming b) , Energy subsidies: Evolution in the global energy transformation , staff technical paper, IRENA, Abu Dhabi.

IRENA (forthcoming c) , Renewable energy benefits: Leveraging local capacity for solar water heaters , International Renewable Energy Agency, Abu Dhabi.

IRENA (forthcoming d) , Reaching zero: Reducing emissions with renewables (provisional title), International Renewable Energy Agency, Abu Dhabi.

IRENA (2020a) , Measuring the socio-economics of transition: Focus on jobs , International Renewable Energy Agency, Abu Dhabi.

IRENA (2020b) , Discussions on sustainable aviation take place in Abu Dhabi , press release (accessed 6 March 2020).

IRENA (2020c) , Innovative solutions for 100% renewable power in Sweden , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019a) , Global energy transformation (GET): A roadmap to 2050 (2019 edition), International Renewable Energy Agency, Abu Dhabi.

IRENA (2019b) , NDCs in 2020: Advancing renewables in the power sector and beyond , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c) , Renewable power generation costs in 2018 , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019d) , Future of solar photovoltaic Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019e) , Future of wind - Deployment, investment, technology, grid integration and socioeconomic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019f) , Renewable energy statistics 2019 , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019g) , Hydrogen: A renewable energy perspective , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019h) , Renewable energy auctions: Status and trends beyond price , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019i) , Renewable power generation costs in 2018 , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019j) , Innovation outlook: Smart charging for electric vehicles , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019k) , Bioenergy from boreal forests: Swedish approach to sustainable wood use , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019l) , Sustainable rural bioenergy solutions in sub-Saharan Africa: A collection of good practices , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019m) , Advanced biofuels: What holds them back? International Renewable Energy Agency, Abu Dhabi.

IRENA (2019n) , Internet of things - Innovation landscape brief , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019o) , Innovation landscape for a renewable-powered-future , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019p) , Renewable energy and jobs - Annual review 2019 , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019q) , Transforming the energy system and holding the line on rising global temperatures , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019r) , Navigating the way to a renewable future: Solutions to decarbonise shipping , International Renewable Energy Agency, Abu Dhabi.

IRENA (2018a) , Global energy transformation: A roadmap to 2050 (2018 edition) , International Renewable Energy Agency, Abu Dhabi.

IRENA (2018b) , Bioenergy from Finnish forests: Sustainable, efficient, modern use of wood , International Renewable Energy Agency, Abu Dhabi.

IRENA (2018c) , Hydrogen from renewable power: Technology outlook for the energy transition , International Renewable Energy Agency, Abu Dhabi.

IRENA (2018d) , Renewable energy benefits: Leveraging local capacity for offshore wind , International Renewable Energy Agency, Abu Dhabi.

IRENA (2017a) , Biogas for domestic cooking: Technology brief , International Renewable Energy Agency, Abu Dhabi.

IRENA (2017b) , Bioenergy from degraded land in Africa: Sustainable and technical potential under Bonn Challenge pledges , International Renewable Energy Agency, Abu Dhabi.

IRENA (2017c) , Sustainable flight with biofuels , International Renewable Energy Agency, Abu Dhabi.

IRENA (2017d) , Biofuels for aviation: Technology brief, International Renewable Energy Agency , Abu Dhabi.

IRENA (2017e) , Renewable energy benefits: Leveraging local capacity for solar PV , International Renewable Energy Agency, Abu Dhabi.

IRENA (2017f) , Renewable energy benefits: Leveraging local capacity for onshore wind , International Renewable Energy Agency, Abu Dhabi.

IRENA (2016a) , Boosting biofuels: Sustainable paths to greater energy security , International Renewable Energy Agency, Abu Dhabi.

IRENA (2016b) , Measuring small-scale biogas capacity and production , International Renewable Energy Agency, Abu Dhabi.

IRENA (2016c) , Renewable energy benefits: Measuring the economics , International Renewable Energy Agency, Abu Dhabi.

IRENA (2014) , Global bioenergy - Supply and demand projections: A working paper for REmap 2030 , International Renewable Energy Agency, Abu Dhabi.

IRENA Patents Data Online Platform INSPIRE , http://inspire.irena.org/.

Kåberger. T. (2019) , '2019 Global power sector develop  ments: RE finally dominated growth', Renewable Energy Institute, 2 March, www.renewable-ei.org/en/activities/column/ REupdate/20200302.php.

Korfiati, A., Gkonos, C., Veronesi, F., Gaki, A., Grassi, S., Schenkel, R., Volkwein, S., Raubal, M. and Hurni, L., (2016) , 'Estimation of the global solar energy potential and photovoltaic cost with the use of open data', International Journal of Sustainable Energy Planning and Management 9, https://doi. org/10.5278/ijsepm.2016.9.3.

Lee, K. (2013) , Schumpeterian analysis of economic catch-up, knowledge, path-creation and the middleincome trap , Cambridge: Cambridge University Press.

Martin, J. R. (2020) , 'US surge pushes global corporate solar PPAs near 10GW-a-year mark', PV-Tech, 30 January, www.pv-tech.org/news/ us-surge-pushes-global-corporate-solar-ppas-near10gw-a-year-mark.

Martín, J. R. (2019) , 'Europe approves US$3.5bn for R&amp;D in major push to create sustainable battery manufacturing ecosystem', Energy Storage News, https://www.energy-storage.news/news/europewages-multi-billion-crusade-to-nurture-batteryecosystem.

McKinsey (2019) , 'New global energy perspective 2019: Reference case', McKinsey &amp; Company, www. mckinsey.com/industries/oil-and-gas/our-insights/ global-energy-perspective-2019.

NASA (2020) , 'Climate change evidence: How do we know?' Global Climate Change Vital Signs of the Planet, US National Aeronautics and Space Administration, https://climate.nasa.gov/evidence/ (accessed 6 March 2020).

Paul, S. (2019) , 'Australia backs trials to produce green hydrogen to make ammonia', Reuters , 29 September, www.reuters.com/article/us-australiahydrogen-incitec-pivot/australia-backs-trials-toproduce-green-hydrogen-to-make-ammoniaidUSKBN1WF0CF.

Perez and Soete (1988) , 'Catching up in technology: Entry barriers and windows of opportunity', in G. Dosi et al., eds., Technical Change and Economic Theory, London: Francis Pinter, 458-79.

Pooler, M. (2020) , 'Surge in plastics production defies environmental backlash', Financial Times , 11 February, www.ft.com/ content/4980ec74-4463-11ea-abea-0c7a29cd66fe.

Recharge (2020) ,"Japan opens world's largest green-hydrogen plant near Fukushima disaster site", 9 March 2020, https://www.rechargenews. com/transition/japan-opens-worlds-largestgreen-hydrogen-plant-near-fukushima-disastersite/2-1-769361 (accessed: 12 March 2020).

Shell (2018) , 'Shell Scenarios Sky. Meeting the goals of the Paris Agreement', Shell Global, April, https:// www.shell.com/energy-and-innovation/the-energyfuture/scenarios/shell-scenario-sky.html.

Simms, A., et al. (2008) , A Green New Deal. Joined-up policies to solve the triple crunch of the credit crisis, climate change and high oil prices, New Economics Foundation, https://neweconomics. org/2008/07/green-new-deal.

Spiegel (2020) , 'Elektroautos: Vollbremsung bei Elektro-Wachstum in USA und China (Electric cars: full braking on electric growth in USA and China'), Der Spiegel , 26 February, www.spiegel.de/auto/ elektroautos-vollbremsung-bei-elektro-wachstumin-usa-und-china-a-662f780e-1053-4665-a4f6c7ff1443673a.

Tong, D., Zhang, Q., Zheng, Y., Caldeira, K., Shearer, C., Hong, C., Qin, Y. and Davis, S. J. (2019) , 'Committed emissions from existing energy infrastructure jeopardize 1.5 °C climate target', Nature 572, 373-77, https://www.nature.com/ articles/s41586-019-1364-3.

Traywick, C. et al. (2020) , 'Gas exports have a dirty secret: A carbon footprint rivaling coal's', Bloomberg Green, 23 January, www.bloomberg. com/news/articles/2020-01-23/gas-exports-havedirty-secret-a-carbon-footprint-rivaling-coal-s.

UCS (2019) , 'Ready for work: Now is the time for heavy-duty electric vehicles', Union of Concerned Scientists, https://www.atlasevhub.com/resource/ ready-for-work-now-is-the-time-for-heavy-dutyelectric-vehicles/ (accessed 11 December 2019).

UNCTAD (2019) , State of commodity dependence 2019 , United Nations Conference on Trade and Development, Geneva.

UN ECOSOC (2019) , The impact of rapid technological change on sustainable development. Report of the Secretary-General , Geneva, 4 March, https://unctad.org/meetings/en/ SessionalDocuments/ecn162019d2\_en.pdf.

UNEP (2020) , Handbook for the Montreal Protocol on Substances that Deplete the Ozone Layer, Fourteenth edition , United Nations Environment Programme, Nairobi.

UNEP (2009) , Global Green New Deal Policy Brief , United Nations Environment Programme, Nairobi.

UTS-ISF (2019) , Achieving the Paris Climate Agreement goals, global and regional 100% renewable energy scenarios with non-energy GHG pathways for +1.5°C and +2°C , University of Technology Sydney - Institute for Sustainable Futures (UTS-ISF), Sydney, www.springer.com/gp/ book/9783030058425.

Wacket, M. (2019) , 'Germany to start closing black coal plants in 2020: draft law', Reuters , 5 September, https://www.reuters.com/article/ us-germany-politics-climate-change/germany-tostart-closing-black-coal-plants-in-2020-draft-lawidUSKCN1VQ1U9.

World Bank Group (2019a) , GDP, PPP (constant 2011 international $) , World Bank Group.

World Bank Group (2019b) , Access to electricity (% of population) , World Bank Group.

World Bank Group (2019c) , Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

World Bank Group (2019d) , Urban population , World Bank Group.

WHO (2020) , 'Air pollution - Overview', World Health Organization, www.who.int/westernpacific/ health-topics/air-pollution (accessed 6 March 2020).

WHO (2019) , WHO Global Ambient Air Quality Database (update 2018) , World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

Yara (2019) , 'Yara and Nel collaborate to produce carbon free hydrogen for ammonia production', Yara. https://www.yara.com/news-and-media/ news/archive/2019/yara-and-nel-carbon-freehydrogen-for-fertilizer-production/ (accessed 3 March 2020).

## ABBREVIATIONS

°C

degrees Celsius

bcm

billion cubic metres

BES

Baseline Energy Scenario

bln

billion

CCS carbon capture and storage

CCUS

carbon capture, utilisation and storage

CDR carbon dioxide removal

CHP

combined heat and power

CIP

Climate Investment Platform

CO2

carbon dioxide

CSP concentrating solar power

DDP

Deeper Decarbonisation Perspective

DH

district heat

DRI direct reduced iron

EJ exajoule

EU European Union

EUR

Euro

EV electric vehicle

FCEV

fuel cell electric vehicle

G20

Group of Twenty

GCF Green Climate Fund

GDP gross domestic product

GJ

gigajoule

Gt gigatonne

GW

gigawatt

GWEC

Global Wind Energy Council

GWh

gigawatt-hour

H2

Hydrogen

IEA International Energy Agency

IMF

International Monetary Fund

IMO International Maritime Organization

IRENA

International Renewable Energy Agency

kg

kilogram

kWh

kilowatt-hour

LCOE

levelised cost of electricity

LNG

liquefied natural gas

LULUCF

land use, land-use change and forestry

m 2

square metre

MENA

Middle East and North Africa

mln

million

Mt

megatonne

Mtce

megatonne of coal equivalent

Mtoe

million tonnes of oil equivalent

MW

megawatt

MWh

megawatt-hour

N2O

nitrous oxide

NDC

Nationally Determined

Contribution

O&amp;M

operation and maintenance

OECD

Organisation for Economic

Co-operation and Development

PES

Planned Energy Scenario

PPA

power purchase agreement

ppt

percentage point

PV

photovoltaic

R&amp;D

research and development

RE

renewable energy

REmap

renewable energy roadmap

analysis by IRENA

SDG

Sustainable Development Goal

SEforALL

Sustainable Energy for All

SF6

sulphur heaxfluoride

t

tonne

TES

Transforming Energy Scenario

TFEC

total final energy consumption

TJ

terajoule

toe tonne of oil equivalent

TPES

total primary energy supply

TW

terawatt

TWh

terawatt-hour

UK

United Kingdom

UNDP

United Nations Development

Programme

UNFCCC

United Nations Framework

Convention on Climate Change

USD

US dollar

VRE

variable renewable energy

WHO

World Health Organization

yr

year

## ENERGY

## TRANSFORMATION EAST ASIA

Regional analysis covers five countries:

- • China
- • Japan
- · Democratic People's Republic of Korea (DPRK)
- • Mongolia
- • Republic of Korea (ROK)

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

Current:

21% of global population , mainly in China (87%), Japan (8%) and ROK and DPRK (5%).

2050 outlook:

Average 0.2% per year decline to 1 515 million, or 16% of global population.

IRENA analysis based on E3ME.

Current:

Around the global average (10.9).

2050 outlook:

Swift development;

PES:

CAGR = 3.4%

<!-- image -->

IRENA analysis based on E3ME.

<!-- image -->

<!-- image -->

## Energy consumption per capita:

## Electricity access:

## Clean cooking access:

Current: above global average (51 GJ/year).

Near-total in China, Japan and ROK; lower in Mongolia (&gt;85%) and DPRK (44%).

Only 43% in Mongolia.

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019).

<!-- image -->

Current status:

## Supply and demand roughly in balance ;

China is world's largest coal producer; ROK and Japan rely heavily on fossil-fuel imports.

2050 outlook:

Air pollution and resource challenges ; vast untapped renewable energy potential . PES: The total generation (est. 15993 TWh) represents 36% of overall renewable power potential.

Note: Current status, IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

<!-- image -->

Current status:

Over half of global metal and minerals, chemicals, and iron and steel energy demand is concentrated in the region.

2050 outlook:

IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Recent:

2050 outlook:

Deploy a mix of emerging clean technologies and carbon capture solutions .

Region's annual emissions: 11.4 Gt (2018).

34% of global energy-related emissions.

- · PES: 53% reduction to 5.4 Gt with enabling policies.
- • Increased CO2 emissions from transport.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

<!-- image -->

China: Rapid, mainly coal-fueled development accelerating since 2010, reducing poverty; death rate from air pollution now 2nd highest (after India's); new regulations cut air pollution by 20% in 2015-17.

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

## Electricity price:

## Renewable power costs:

## Auction prices:

Mid-range (for households and industries) compared to other regions.

Onshore wind around G20 average (USD 0.05/kWh). Solar PV below G20 average (USD 0.096/kWh).

Lower than other regions; China's largest solar auction (1 GW new capacity) achieved lowest price (USD 0.077/kWh) in 2017.

0

.

1

2

0

.

1

2

<!-- image -->

,

'

GLYPH&lt;157&gt;

LCOE based on IRENA (2019a) and electricity prices based on Global Petrol Prices (2019). Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

0

.

9

## ENERGY TRANSFORMATION: KEY BENEFITS

## CLEAN ENERGY SUPPLY

- Lower CO2 emissions
- Better local air quality
- Leverage innovation (hydrogen, batteries, etc.)

## ENERGY INDEPENDENCE

## SUSTAINABLE DEVELOPMENT

- Added economic value
- Higher employment
- Empowered societies and improved awareness

<!-- image -->

<!-- image -->

<!-- image -->

1

<!-- image -->

2

- Diversified energy supply
- Resilience to external shocks
- Lower investment risks

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading   | Where we are heading   | Where we are heading   | Where we need to be   | Where we need to be   | Where we need to be   |
|-----------------------------------------------|-----------------------------------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|
| East Asia                                     | 2017                                          | 2030 (PES)             | 2040 (PES)             | 2050 (PES)             | 2030 (TES)            | 2040 (TES)            | 2050 (TES)            |
| Energy (EJ)                                   |                                               |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 159                                           | 185                    | 172                    | 159                    | 166                   | 148                   | 129                   |
| Consumption (TFEC)                            | 102                                           | 114                    | 107                    | 100                    | 105                   | 97                    | 89                    |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 7%                                            | 17%                    | 27%                    | 39%                    | 27%                   | 44%                   | 65%                   |
| Consumption (TFEC)                            | 8%                                            | 20%                    | 30%                    | 43%                    | 31%                   | 49%                   | 70%                   |
| Power generation                              | 23%                                           | 42%                    | 59%                    | 73%                    | 60%                   | 77%                   | 90%                   |
| Electricity share in final energy consumption | Electricity share in final energy consumption |                        |                        |                        |                       |                       |                       |
| End-use consumption                           | 25%                                           | 33%                    | 40%                    | 48%                    | 37%                   | 47%                   | 58%                   |
| Industry                                      | 26%                                           | 39%                    | 45%                    | 53%                    | 41%                   | 51%                   | 65%                   |
| Transport                                     | 3%                                            | 7%                     | 20%                    | 33%                    | 14%                   | 30%                   | 46%                   |
| Buildings                                     | 32%                                           | 44%                    | 48%                    | 52%                    | 45%                   | 51%                   | 57%                   |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |                        |                        |                        |                       |                       |                       |
| Bioenergy                                     | 14                                            | 74                     | 74                     | 74                     | 82                    | 84                    | 87                    |
| Hydropower                                    | 349                                           | 484                    | 533                    | 582                    | 490                   | 539                   | 588                   |
| Solar PV                                      | 186                                           | 1175                   | 1734                   | 2305                   | 1644                  | 2396                  | 3118                  |
| Wind                                          | 169                                           | 706                    | 1407                   | 2106                   | 1263                  | 1990                  | 2696                  |
| Biofuels                                      | Biofuels                                      |                        |                        |                        |                       |                       |                       |
| Liquid biofuels (billions of litres per year) | 5                                             | 31                     | 32                     | 33                     | 36                    | 36                    | 37                    |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |                        |                        |                        |                       |                       |                       |
| Annual level (Gt CO 2 /yr)                    | 11.2                                          | 10.3                   | 7.8                    | 5.4                    | 8.4                   | 5.3                   | 2.2                   |
| Reduction vs. today                           | NA                                            | -8%                    | -30%                   | -52%                   | -25%                  | -53%                  | -80%                  |

## East Asia

Where we are heading Planned Energy Scenario 2016/thinspace-/thinspace2050 (PES)

Where we need to be Transforming Energy Scenario 2016-2050 (TES)

## Energy system investments (average annual, 2016-50) USD billion/year

| Power                                |   314 |   386 |
|--------------------------------------|-------|-------|
| - Renewable                          | 172   | 246   |
| - Non-renewable                      |  63   |  35   |
| - Power grids and system flexibility |  80   | 105   |
| Industry (RE + EE)                   |  25   |  35   |
| Transport (electrification + EE)     | 101   | 114   |
| Buildings (RE + EE)                  | 133   | 196   |
| Biofuel supply                       |   5.4 |  13.4 |
| Renewable hydrogen - electrolysers   |   2.2 |   5.9 |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019b; 2019c) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| East Asia                           | 2019e      | 2030       | 2050       |
|-------------------------------------|------------|------------|------------|
| Population (thousands) region-wide  | 1 621 179  | 1 627 194  | 1 514 571  |
| GDP (USD 2015)                      |            |            |            |
| GDP (million): PES                  | 17 550968  | 25 739 253 | 46369936   |
| GDP (million): TES                  | 18 075 537 | 26 577 659 | 47 521 377 |
| GDP changes (million): TES vs. PES  | 524 569    | 838 406    | 1 151 441  |
| GDP changes (%): TES vs. PES        | 3          | 3.3        | 2.5        |
| Per capita GDP (thousand): PES      | 10.8       | 15.8       | 30.6       |
| Per capita GDP (thousand): TES      | 11.1       | 16.3       | 31.4       |
| Employment                          |            |            |            |
| Economy-wide employment (thousands) |            |            |            |
| Employment: PES                     | 997 554    | 979 427    | 839 204    |
| Employment: TES                     | 1 001 937  | 984319     | 839 750    |
| Employment changes: TES vs. PES     | 4382       | 4892       | 545        |
| Employment changes (%): TES vs. PES | 0.44%      | 0.50%      | 0.06%      |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

East Asia

2017

2030

(PES)

2050

(PES)

2030

(TES)

2050

(TES)

## Energy sector jobs (thousands)

| Nuclear power                              | 139    | 222    | 254    | 215    | 185    |
|--------------------------------------------|--------|--------|--------|--------|--------|
| Fossil fuels                               | 9 952  | 10 170 | 7 765  | 8 765  | 4800   |
| Renewables                                 | 4617   | 8 494  | 12 194 | 10 591 | 15 007 |
| Energy efficiency                          | 1 912  | 7 521  | 7 748  | 9 672  | 8 852  |
| Power grids and energy flexibility         | 2 339  | 4406   | 5 332  | 4746   | 5 673  |
| Total                                      | 18 959 | 30813  | 33 293 | 33 989 | 34517  |
| Energy jobs in economy-wide employment (%) |        | 3.1%   | 4.0%   | 3.5%   | 4.1%   |

## Renewable energy jobs (thousands)

| Bioenergy                                             | 414   | 1 069   | 801    | 1 185   | 1 005   |
|-------------------------------------------------------|-------|---------|--------|---------|---------|
| Solar                                                 | 3 211 | 5 571   | 7 630  | 6 725   | 9 404   |
| Hydropower                                            | 469   | 621     | 716    | 604     | 688     |
| Wind                                                  | 519   | 1 225   | 2 999  | 2 061   | 3 844   |
| Geothermal                                            | 4     | 7       | 46     | 12      | 50      |
| Ocean                                                 | 0     | 1       | 2      | 4       | 15      |
| Total                                                 | 4617  | 8 494   | 12 194 | 10 591  | 15 007  |
| Renewable energy jobs in energy-sector employment (%) |       | 27.6%   | 36.6%  | 31.2%   | 43.5%   |

## Job differential in 2050 (thousands) TES vs. PES

| Economy-wide                                   | 545    |
|------------------------------------------------|--------|
| Changes in conventional energy (A)             | -3 034 |
| Changes in transition related technologies (B) | 4257   |
| Net energy sector jobs (A+B)                   | 1 223  |

## Jobs in 2050: TES / East Asia

| Technology jobs (thousands)   | Technology jobs (thousands)   | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      | 7 896                         | Construction & installation       | 5 894                             | Workers and technicians                 | 9 972                                   |
| Solar water heaters (SWH)     | 1 437                         | Manufacturing                     | 4236                              | Experts                                 | 1 475                                   |
| Onshore wind                  | 3 144                         | Operation and maintenance         | 3 098                             | Engineers and higher degrees            | 1 275                                   |
| Offshore wind                 | 699                           | Biofuel supply                    | -                                 | Marketing and administrative            | 505                                     |
| Geothermal                    | 50                            |                                   |                                   |                                         |                                         |
| Total                         | 13 228                        |                                   | 13 228                            |                                         | 13 228                                  |

Welfare improvement (%):

| TES vs. PES   | 2030      | 2050      |
|---------------|-----------|-----------|
| Indicator     | Indicator | Indicator |
| Economic      | 0.6       | 0.4       |
| Social        | 3.8       | 7.4       |
| Environmental | 1.9       | 4         |
| Total         | 6.3       | 11.8      |

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply , Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world , www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition, International Energy Agency, Paris.

IRENA (2019a), Renewable Cost Database , 2019.

IRENA (2019b), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->

## ENERGY

## TRANSFORMATION SOUTHEAST ASIA

Regional analysis covers the 10 member states of the Association of Southeast Asian Nations:

- • Brunei Darussalam
- •   Lao People's
- • Malaysia
- • Cambodia
- Democratic
- • Indonesia

Republic

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

IRENA analysis based on E3ME.

<!-- image -->

2050 outlook:

Current:

2050 outlook:

Current:

## 8.5% of global population .

Highest regional share in Indonesia (41%) followed by Philippines (16%) and Viet Nam (15%).

Average 0.5% per year increase to 749 million , or 8% of global population.

Well below the global average (10.9).

<!-- image -->

Rapid development;

PES:

CAGR = 4.2%

IRENA analysis based on E3ME.

<!-- image -->

- • Myanmar
- • Philippines
- • Singapore
- • Thailand
- • Viet Nam

<!-- image -->

## Energy consumption per capita:

## Electricity access:

## Clean cooking access:

Current: well below the global average (51 GJ/year).

Some countries have not yet achieved full electrification. All governments plan for 100% electricity access before 2030.

40% of the region's population lack access to modern fuels for cooking.

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019).

## Fossil fuel net import

<!-- image -->

Current status:

Indonesia: Large coal deposits; Malaysia: Moderate oil and gas reserves.

2050 outlook:

## Region shifting to net fossil-fuel imports; Vast untapped renewable energy potential.

PES: The total generation (est. 3664 TWh) represents 25% of overall renewable power potential.

Note: Current status, IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

<!-- image -->

Current status:

Regional energy use ranges from 1% of global levels in some industries up to 9% (region's highest share) in food and tobacco .

2050 outlook:

IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Recent:

The region becoming more industrialised; Need for emissions reductions and specific solution to decarbonize in challenging sectors such as heavy industry.

Region's annual emissions: 1.5 Gt (2018). 4% of global energy-related CO2 emissions.

2050 outlook:

- PES: Almost doubling to 2.9 Gt per year , coal and natural-gas use drive increase, with more limited increase in oil demand.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

<!-- image -->

Unhealthy air pollution levels in 22% of region's cities and moderately unhealthy levels in most of rest; Dataset (limited to 35 cities) points to poor and deterioriating urban air quality across region.

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

Electricity price: USD 0.10-0.11/kWh average across region (lower compared to other regoins).

## Renewables cost and auctions:

Cost-competitiveness of renewables increasingly reflected in region;

Viet Nam has auctioned 5.5 GW (2019), region's largest installed solar PV capacity.

GLYPH&lt;143&gt;

,

<!-- image -->

LCOE based on IRENA (2019a) and electricity prices based on Global Petrol Prices (2019).

Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

## ENERGY TRANSFORMATION: KEY BENEFITS

## ENERGY ACCESS AND INFRASTRUCTURE

- Diversified energy supply
- Lower system costs
- Green industrial revolution

1

<!-- image -->

2

- Greater energy self-sufficiency
- Low-cost renewable energy use
- Increased regional interconnections
- Increasingly electrified transport

<!-- image -->

3

- Economic growth driven by trade gains
- High growth in renewable energy jobs
- Better air quality and improved health
- Improved education and empowered citizens

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY SECURITY

## SUSTAINABLE DEVELOPMENT

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading   | Where we are heading   | Where we are heading   | Where we need to be   | Where we need to be   | Where we need to be   |
|-----------------------------------------------|-----------------------------------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|
| Southeast Asia                                | 2017                                          | 2030 (PES)             | 2040 (PES)             | 2050 (PES)             | 2030 (TES)            | 2040 (TES)            | 2050 (TES)            |
| Energy (EJ)                                   |                                               |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 28                                            | 40                     | 50                     | 60                     | 39                    | 48                    | 54                    |
| Consumption (TFEC)                            | 18                                            | 21                     | 27                     | 31                     | 21                    | 25                    | 28                    |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 13%                                           | 28%                    | 29%                    | 31%                    | 41%                   | 59%                   | 75%                   |
| Consumption (TFEC)                            | 12%                                           | 16%                    | 19%                    | 22%                    | 27%                   | 48%                   | 68%                   |
| Power generation                              | 20%                                           | 31%                    | 34%                    | 37%                    | 53%                   | 73%                   | 85%                   |
| Electricity share in final energy consumption | Electricity share in final energy consumption |                        |                        |                        |                       |                       |                       |
| End-use consumption                           | 18%                                           | 22%                    | 26%                    | 31%                    | 20%                   | 32%                   | 42%                   |
| Industry                                      | 22%                                           | 16%                    | 19%                    | 23%                    | 16%                   | 22%                   | 27%                   |
| Transport                                     | 0.2%                                          | 1%                     | 2%                     | 3%                     | 3%                    | 11%                   | 23%                   |
| Buildings                                     | 30%                                           | 68%                    | 77%                    | 83%                    | 63%                   | 82%                   | 91%                   |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |                        |                        |                        |                       |                       |                       |
| Bioenergy                                     | 7                                             | 26                     | 32                     | 37                     | 66                    | 111                   | 176                   |
| Hydropower                                    | 39                                            | 41                     | 51                     | 70                     | 71                    | 81                    | 100                   |
| Solar PV                                      | 4                                             | 54                     | 109                    | 198                    | 106                   | 399                   | 647                   |
| Wind                                          | 1                                             | 5                      | 8                      | 11                     | 13                    | 22                    | 32                    |
| Biofuels                                      | Biofuels                                      |                        |                        |                        |                       |                       |                       |
| Liquid biofuels (billions of litres per year) | 7                                             | 34                     | 39                     | 62                     | 47                    | 57                    | 93                    |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |                        |                        |                        |                       |                       |                       |
| Annual level (Gt CO 2 /yr)                    | 1.4                                           | 2                      | 2.6                    | 2.9                    | 1.6                   | 1.3                   | 0.8                   |
| Reduction vs. today                           | NA                                            | 45%                    | 81%                    | 106%                   | 15%                   | -10%                  | -46%                  |

## Southeast Asia

Where we are heading

Planned Energy

Scenario 2016/thinspace-/thinspace2050

(PES)

Where we need to be Transforming Energy Scenario 2016-2050 (TES)

## Energy system investments (average annual, 2016-50) USD billion/year

| Power                                |   39 |   66 |
|--------------------------------------|------|------|
| - Renewable                          | 12   | 39   |
| - Non-renewable                      | 13   |  5   |
| - Power grids and system flexibility | 15   | 22   |
| Industry (RE + EE)                   |  7   | 13   |
| Transport (electrification + EE)     | 10   | 20   |
| Buildings (RE + EE)                  | 27   | 40   |
| Biofuel supply                       |  3.2 |  6.9 |
| Renewable hydrogen - electrolysers   |  0   |  0   |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019b; 2019c) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| Southeast Asia                      | 2019e    | 2030      | 2050      |
|-------------------------------------|----------|-----------|-----------|
| Population (thousands) region-wide  | 647 605  | 700587    | 749 019   |
| GDP (USD 2015)                      |          |           |           |
| GDP (million): PES                  | 2 465787 | 3 981 401 | 10 065561 |
| GDP (million): TES                  | 2 495821 | 4155 442  | 10 360523 |
| GDP changes (million): TES vs. PES  | 30034    | 174 041   | 294962    |
| GDP changes (%): TES vs. PES        | 1.2      | 4.4       | 2.9       |
| Per capita GDP (thousand): PES      | 3.8      | 5.7       | 13.4      |
| Per capita GDP (thousand): TES      | 3.9      | 5.9       | 13.8      |
| Employment                          |          |           |           |
| Economy-wide employment (thousands) |          |           |           |
| Employment: PES                     | 319 692  | 354 865   | 369 980   |
| Employment: TES                     | 319 792  | 354 512   | 369 664   |
| Employment changes: TES vs. PES     | 101      | -353      | -316      |
| Employment changes (%): TES vs. PES | 0.03%    | -0.10%    | -0.09%    |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Southeast Asia                                        | 2017                                             | 2030 (PES)                                       | 2050 (PES)                                       | 2030 (TES)                                       | 2050 (TES)                                       |
|-------------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Energy sector jobs (thousands)                        |                                                  |                                                  |                                                  |                                                  |                                                  |
| Nuclear power                                         | 1                                                | 5                                                | 10                                               | 10                                               | 20                                               |
| Fossil fuels                                          | 2 000                                            | 2 682                                            | 2 764                                            | 2 647                                            | 2 429                                            |
| Renewables                                            | 779                                              | 1 681                                            | 2 028                                            | 3 780                                            | 6 720                                            |
| Energy efficiency                                     | 1 005                                            | 645                                              | 564                                              | 978                                              | 703                                              |
| Power grids and energy flexibility                    | 308                                              | 474                                              | 451                                              | 501                                              | 638                                              |
| Total                                                 | 4092.7                                           | 5 487.5                                          | 5 817.2                                          | 7 915.2                                          | 10509.4                                          |
| Energy jobs in economy-wide employment (%)            |                                                  | 1.5%                                             | 1.6%                                             | 2.2%                                             | 2.8%                                             |
| Renewable energy jobs (thousands)                     | Renewable energy jobs (thousands)                |                                                  |                                                  |                                                  |                                                  |
| Bioenergy                                             | 502                                              | 1 302                                            | 1 457                                            | 2 752                                            | 4412                                             |
| Solar                                                 | 91                                               | 186                                              | 372                                              | 628                                              | 1 882                                            |
| Hydropower                                            | 155                                              | 139                                              | 154                                              | 285                                              | 283                                              |
| Wind                                                  | 15                                               | 18                                               | 19                                               | 40                                               | 45                                               |
| Geothermal                                            | 15                                               | 35                                               | 27                                               | 56                                               | 63                                               |
| Ocean                                                 | 0                                                | 0                                                | 0                                                | 18                                               | 34                                               |
| Total                                                 | 779                                              | 1 681                                            | 2 028                                            | 3 780                                            | 6720                                             |
| Renewable energy jobs in energy-sector employment (%) |                                                  | 30.6%                                            | 34.9%                                            | 47.8%                                            | 63.9%                                            |
| Job differential in 2050 (thousands) TES vs. PES      | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES |
| Economy-wide                                          | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | -316                                             |
| Changes in conventional energy (A)                    | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | -325                                             |
| Changes in transition related technologies (B)        | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | 5 018                                            |
| Net jobs (A+B)                                        | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | 4692                                             |

## Jobs in 2050: TES / Southeast Asia

| Technology jobs (thousands)   | Technology jobs (thousands)   | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      | 1 560                         | Construction & installation       | 805                               | Workers and technicians                 | 1 515                                   |
| Solar water heaters (SWH)     | 322                           | Manufacturing                     | 988                               | Experts                                 | 206                                     |
| Onshore wind                  | 45                            | Operation and maintenance         | 198                               | Engineers and higher degrees            | 176                                     |
| Offshore wind                 | -                             | Biofuel supply                    | -                                 | Marketing and administrative            | 94                                      |
| Geothermal                    | 63                            |                                   |                                   |                                         |                                         |
| Total                         | 1 991                         |                                   | 1 991                             |                                         | 1 991                                   |

| Welfare improvement (%): TES vs. PES   | 2030   | 2050   |
|----------------------------------------|--------|--------|
| Indicator                              |        |        |
| Economic                               | 0.1    | 0.0    |
| Social                                 | 1.5    | 7.7    |
| Environmental                          | 1.6    | 3.5    |
| Total                                  | 3.2    | 11.2   |

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply , Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world , www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition, International Energy Agency, Paris.

IRENA (2019a), Renewable Cost Database , 2019.

IRENA (2019b), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION

## REST OF ASIA

## Regional analysis covers 16 countries:

## West Asia

## Central Asia:

- • Armenia
- • Azerbaijan
- • Turkey
- • Kazakhstan
- • Kyrgyz Republic
- • Tajikistan
- • Turkmenistan

## South Asia:

- • Afghanistan
- • Bangladesh
- • Bhutan
- • India
- • Uzbekistan
- • Maldives

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

Current:

## 27% of global population,

mainly in India (68%) followed by Pakistan (11%), Bangladesh (8%) and Turkey (4%).

2050 outlook:

Average 0.7% per year increase to 2 602 million , or 28% of global population.

IRENA analysis based on E3ME.

<!-- image -->

IRENA analysis based on E3ME.

Current:

Well below the global average (10.9).

2050 outlook:

Rapid development;

<!-- image -->

PES:

CAGR = 4.9%

- • Nepal
- • Pakistan
- • Sri Lanka

<!-- image -->

Energy consumption per capita:

## Electricity access:

## Clean cooking access:

Current: well below the global average (51 GJ/year)..

Over 91% (2017) up from 75% (2010). Still, 178 million people in the region lack electricity access (IEA, IRENA, UNSD, WB, WHO, 2019).

Available to less than 50% of region's population (2017), with especially large access deficit in India (IEA, IRENA, UNSD, WB, WHO, 2019).

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019).

| Fossil fuel net import   | Current status:   | West and South Asian countries are net importers, while Central Asian countries are net exporters (mainly oil and gas). Rising air pollution and resource challenges; Large untapped renewable energy potential.   |
|--------------------------|-------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| high                     | 2050 outlook:     | PES: The total generation (est. 7514 TWh) represents 23% of overall renewable power potential.                                                                                                                     |

Note: Current status, IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

<!-- image -->

Source: IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Region's annual emissions: 3.8 Gt (2018).

11% of global energy-related CO2 emissions.

2050 outlook:

PES: Almost doubling to 7.2 Gt with enabling policies. CO2 emissions from transport are poised to triple to 1.4 Gt propelled by population growth and urbanization.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

Recent:

<!-- image -->

South Asia currently has the world's most toxic air, with 18 of the planet's 20 most-polluted cities found in India (15), Pakistan (2) and Bangladesh (1).

Record-high air pollution has periodically shut down regular activities and caused serious health issues in Delhi, India.

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

Electricity price:

## Renewables cost and auctions:

Among the lowest in the world, only in MENA is lower. Similar to Rest of Europe.

Onshore wind: Similar to G20 average levels of USD 0.05/ kWh (weighted average LCOE); Solar PV: Below G20 average (USD 0.096/kWh);

India: Solar PV cost-competitive compared to thermal power generation (USD 0.068/kWh for coal and USD 0.093/kWh for combined-cycle gas).

GLYPH&lt;143&gt;

GLYPH&lt;144&gt;

GLYPH&lt;143&gt;

GLYPH&lt;127&gt;

­

€

<!-- image -->

LCOE based on IRENA (2019a) and electricity prices based on Global Petrol Prices (2019).

Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

## ENERGY TRANSFORMATION: KEY BENEFITS

## REDUCED EMISSIONS

- Clean local air
- Lower CO2 output
- Improved health and well-being

1

<!-- image -->

2

- Distributed renewable power to isolated communities
- Diversified energy supply
- Improved clean cooking access

<!-- image -->

<!-- image -->

<!-- image -->

3

- Economic growth and poverty alleviation
- Modern energy job creation and skills development
- Transformative health impacts
- Active role for communities

## ENERGY INDEPENDENCE AND ACCESS

ECONOMIC AND SUSTAINABLE DEVELOPMENT

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading   | Where we are heading   | Where we are heading   | Where we need to be   | Where we need to be   | Where we need to be   |
|-----------------------------------------------|-----------------------------------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|
| Rest of Asia                                  | 2017                                          | 2030 (PES)             | 2040 (PES)             | 2050 (PES)             | 2030 (TES)            | 2040 (TES)            | 2050 (TES)            |
| Energy (EJ)                                   |                                               |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 64                                            | 89                     | 107                    | 124                    | 77                    | 82                    | 86                    |
| Consumption (TFEC)                            | 42                                            | 61                     | 75                     | 87                     | 51                    | 54                    | 55                    |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 8%                                            | 17%                    | 19%                    | 22%                    | 27%                   | 41%                   | 58%                   |
| Consumption (TFEC)                            | 8%                                            | 14%                    | 17%                    | 21%                    | 24%                   | 40%                   | 59%                   |
| Power generation                              | 18%                                           | 37%                    | 44%                    | 51%                    | 52%                   | 68%                   | 81%                   |
| Electricity share in final energy consumption | Electricity share in final energy consumption |                        |                        |                        |                       |                       |                       |
| End-use consumption                           | 18%                                           | 21%                    | 24%                    | 26%                    | 26%                   | 37%                   | 47%                   |
| Industry                                      | 21%                                           | 15%                    | 15%                    | 15%                    | 19%                   | 25%                   | 32%                   |
| Transport                                     | 1%                                            | 6%                     | 7%                     | 9%                     | 18%                   | 37%                   | 52%                   |
| Buildings                                     | 20%                                           | 45%                    | 57%                    | 66%                    | 51%                   | 63%                   | 75%                   |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |                        |                        |                        |                       |                       |                       |
| Bioenergy                                     | 12                                            | 30                     | 32                     | 35                     | 39                    | 45                    | 55                    |
| Hydropower                                    | 110                                           | 149                    | 175                    | 185                    | 154                   | 202                   | 240                   |
| Solar PV                                      | 24                                            | 216                    | 430                    | 733                    | 314                   | 706                   | 1 072                 |
| Wind                                          | 41                                            | 162                    | 254                    | 404                    | 223                   | 374                   | 541                   |
| Biofuels                                      | Biofuels                                      |                        |                        |                        |                       |                       |                       |
| Liquid biofuels (billions of litres per year) | 1                                             | 11                     | 29                     | 38                     | 14                    | 53                    | 81                    |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |                        |                        |                        |                       |                       |                       |
| Annual level (Gt CO 2 /yr)                    | 3.5                                           | 5.4                    | 6.4                    | 7.2                    | 3.8                   | 3.1                   | 2                     |
| Reduction vs. today                           | NA                                            | 53%                    | 81%                    | 105%                   | 8%                    | -11%                  | -43%                  |

## Rest of Asia

Where we are heading

Planned Energy

Scenario 2016/thinspace-/thinspace2050

(PES)

Where we need to be Transforming Energy Scenario 2016-2050 (TES)

## Energy system investments (average annual, 2016-50) USD billion/year

| Power                                |   122 |   151 |
|--------------------------------------|-------|-------|
| - Renewable                          |  46   |    84 |
| - Non-renewable                      |  30   |    16 |
| - Power grids and system flexibility |  45   |    52 |
| Industry (RE + EE)                   |  22   |    33 |
| Transport (electrification + EE)     |  37   |    70 |
| Buildings (RE + EE)                  |  78   |   114 |
| Biofuel supply                       |   2   |    12 |
| Renewable hydrogen - electrolysers   |   0.2 |     3 |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019b; 2019c) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| Rest of Asia                        | 2019e     | 2030       | 2050      |
|-------------------------------------|-----------|------------|-----------|
| Population (thousands) region-wide  | 2 088441  | 2 326 499  | 2 601 942 |
| GDP (USD 2015)                      |           |            |           |
| GDP (million): PES                  | 5 699443  | 11 092911  | 31 609299 |
| GDP (million): TES                  | 5 892 431 | 11 194 938 | 31 994075 |
| GDP changes (million): TES vs. PES  | 192 988   | 102 027    | 384776    |
| GDP changes (%): TES vs. PES        | 3.4       | 0.9        | 1.2       |
| Per capita GDP (thousand): PES      | 2.7       | 4.8        | 12.1      |
| Per capita GDP (thousand): TES      | 2.8       | 4.8        | 12.3      |
| Employment                          |           |            |           |
| Economy-wide employment (thousands) |           |            |           |
| Employment: PES                     | 1 020945  | 1 251 416  | 1 562 473 |
| Employment: TES                     | 1 021 164 | 1 250735   | 1 561 263 |
| Employment changes: TES vs. PES     | 219       | (681)      | (1 210)   |
| Employment changes (%): TES vs. PES | 0.02%     | -0.05%     | -0.08%    |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Rest of Asia

## Energy sector jobs (thousands)

Nuclear power

Fossil fuels

Renewables

Energy efficiency

Power grids and energy flexibility

Total

Energy jobs in economy-wide employment (%)

2030

(PES)

103

6 170

2 846

2 596

2 483

14 198

1.1%

2050

(PES)

86

6 621

3 577

1 034

3 009

14 326

0.9%

2030

(TES)

91

5 163

3 795

3 925

2 551

15 523

1.2%

2050

(TES)

65

4 495

5 164

1 815

3 220

14 759

0.9%

## Renewable energy jobs (thousands)

| Bioenergy                                             | 238   | 860   | 756   | 1 243   | 1 491   |
|-------------------------------------------------------|-------|-------|-------|---------|---------|
| Solar                                                 | 340   | 941   | 1 687 | 1 422   | 2 504   |
| Hydropower                                            | 760   | 821   | 798   | 821     | 774     |
| Wind                                                  | 80    | 220   | 333   | 305     | 386     |
| Geothermal                                            | 4     | 4     | 4     | 5       | 9       |
| Ocean                                                 | 0     | 0     | 0     | 0       | 0       |
| Total                                                 | 1 422 | 2 846 | 3 577 | 3 795   | 5 164   |
| Renewable energy jobs in energy-sector employment (%) |       | 20.0% | 25.0% | 24.4%   | 35.0%   |

## Job differential in 2050 (thousands) TES vs. PES

Economy-wide

Changes in conventional energy (A)

Changes in transition related technologies (B)

Net jobs (A+B)

-1 210

-2 147

2 579

432

2017

60

3 424

1 422

2 615

1 654

9 175

## Jobs in 2050: TES / Rest of Asia

| Technology jobs (thousands)   | Technology jobs (thousands)   | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      | 1 819                         | Construction & installation       | 1 580                             | Workers and technicians                 | 2 191                                   |
| Solar water heaters (SWH)     | 519                           | Manufacturing                     | 195                               | Experts                                 | 250                                     |
| Onshore wind                  | 295                           | Operation and maintenance         | 958                               | Engineers and higher degrees            | 253                                     |
| Offshore wind                 | 91                            | Biofuel supply                    | -                                 | Marketing and administrative            | 39                                      |
| Geothermal                    | 9                             |                                   |                                   |                                         |                                         |
| Total                         | 2 733                         |                                   | 2 733                             |                                         | 2 733                                   |

| Welfare improvement (%): TES vs. PES   | 2030   | 2050   |
|----------------------------------------|--------|--------|
| Indicator                              |        |        |
| Economic                               | 0.1    | 0.2    |
| Social                                 | 7.7    | 11.3   |
| Environmental                          | 2.0    | 4.2    |
| Total                                  | 9.8    | 15.7   |

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply , Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world (accessed 5 March 2020).

, www.globalpetrolprices.com/electricity\_prices/

IEA (2019), IEA Beyond 20/20 - 2019 edition, International Energy Agency, Paris.

IEA, IRENA, UNSD, WB, WHO (2019), Tracking SDG 7: The Energy Progress Report 2019, Washington DC. IRENA (2019a), Renewable Cost Database , 2019.

IRENA (2019b), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->

<!-- image -->

## GLOBAL RENEWABLES OUTLOOK

## ENERGY TRANSFORMATION

## EUROPEAN UNION

## Regional analysis covers 28 member countries*:

- •  Austria
- •  Estonia
- •  Italy
- •  Belgium
- •  Bulgaria
- •  Croatia
- •  Cyprus
- •  Czech Republic
- •  Finland
- •  France
- •  Hungary
- •  Germany
- •  Greece
- •  Latvia
- •  Lithuania
- •  Luxembourg
- •  Malta
- •  Poland
- •  Denmark
- •  Ireland
- •  Portugal

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

2050 outlook:

Current:

6.8% of global population, highest regional shares in Germany (16%), France (13%), UK (13%) and Italy (12%).

Average 0.1% per year decrease to 497  million , or 5.3% of global population.

IRENA analysis based on E3ME.

Slight development;

PES:

CAGR = 1.8%

<!-- image -->

IRENA analysis based on E3ME.

- *   The UK officially exited the European Union (EU) in January 2020. Since the analysis was based on developments until April 2019, this report considers the UK as part of the EU.
- •  Romania
- •  Slovakia
- •  Slovenia
- •  Spain
- •  Sweden
- •  Netherlands
- •    United Kingdom (UK)*

## Energy consumption per capita:

## Electricity access:

<!-- image -->

<!-- image -->

## Clean cooking access:

Current: well above the global average (51 GJ/year).

The region has long achieved full electrification and access to electricity.

There remains some marginal use of inefficient biomass cookstoves, particularly in rural areas.

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019), 2050 values based on IRENA analysis.

| Fossil fuel net import   | Current status:   | Very limited domestic fossil fuel resources compared to primary energy consumption; heavy dependence on imported oil (93% of oil supply)                                                |
|--------------------------|-------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| very high                | 2050 outlook:     | Improved regional energy security; the region has planned to be climate-neutral by 2050. PES: The total generation (est. 3796 TWh) represents 15% of overall renewable power potential. |

Note: IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

<!-- image -->

Current status:

Accounts for about 20% of global energy demand for pulp and paper, 17% for food and tobacco, about 11% for chemical and petrochemical industry and the share in the metals and minerals industry accounts to roughly 9% .

2050 outlook:

Need for urgent emissions reduction in heavy industries.

Note: Current status, IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Recent:

## Region's annual emissions: 3.3 Gt (2018).

10% of global energy-related emissions.

2050 outlook:

PES: Drop by 41% to 1.9 Gt with enabling policies; Reductions driven by improvements in energy intensity and the adoption of renewable energy.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

<!-- image -->

Air pollution moderate to unhealthy in about 75% of the EU cities, mainly from transport (passenger cars, trucks).

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

## Renewables cost and auctions:

Electricity price:

The highest values for households and the second-highest for industries compared to the other regions

Cost-competitive, or even least cost, when compared to coal or natural gas. Average prices for historical projects are around USD 0.08/kWh for solar and USD 0.05/kWh for wind. Lower than other regions; new solar projects showing costs of around USD 0.02-0.03/kWh, and wind projects at around USD 0.03-0.04/kWh.

GLYPH&lt;127&gt;

GLYPH&lt;144&gt;

­

GLYPH&lt;129&gt;

,

GLYPH&lt;143&gt;

ƒ

<!-- image -->

Note: LCOE based on IRENA (2019a) and electricity prices based on Global Petrol Prices (2019). Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

## ENERGY TRANSFORMATION: KEY BENEFITS

CLEAN TECHNOLOGY HUB

- Global leadership on energy transition
- Carbon neutrality by 2050 (EU target)
- High-efficiency levels
- Affordable energy supply
- Increased energy self-sufficiency
- Reduced oil and gas dependence
- Transformative shift to efficiency and renewables

<!-- image -->

<!-- image -->

3

- Economic growth driven by investment and supportive policies
- Job creation and skills development

## ENERGY SECURITY

ECONOMIC AND SOCIAL DEVELOPMENT

- Pollution reduction, improved health and well-being

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

2

1

European Union

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading                          | Where we are heading                          | Where we are heading                          | Where we need to be                           | Where we need to be                           | Where we need to be                           |
|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|
| European Union                                | 2017                                          | 2030 (PES)                                    | 2040 (PES)                                    | 2050 (PES)                                    | 2030 (TES)                                    | 2040 (TES)                                    | 2050 (TES)                                    |
| Energy (EJ)                                   |                                               |                                               |                                               |                                               |                                               |                                               |                                               |
| Supply (TPES)                                 | 68                                            | 62                                            | 57                                            | 55                                            | 54                                            | 49                                            | 45                                            |
| Consumption (TFEC)                            | 45                                            | 43                                            | 42                                            | 42                                            | 38                                            | 34                                            | 29                                            |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                                               |                                               |                                               |                                               |                                               |                                               |
| Supply (TPES)                                 | 15%                                           | 23%                                           | 28%                                           | 33%                                           | 39%                                           | 50%                                           | 71%                                           |
| Consumption (TFEC)                            | 17%                                           | 24%                                           | 30%                                           | 34%                                           | 36%                                           | 48%                                           | 70%                                           |
| Power generation                              | 31%                                           | 44%                                           | 50%                                           | 58%                                           | 55%                                           | 73%                                           | 86%                                           |
| Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption |
| End-use consumption                           | 22%                                           | 25%                                           | 27%                                           | 29%                                           | 30%                                           | 38%                                           | 49%                                           |
| Industry                                      | 31%                                           | 31%                                           | 37%                                           | 38%                                           | 40%                                           | 47%                                           | 54%                                           |
| Transport                                     | 2%                                            | 4%                                            | 6%                                            | 8%                                            | 7%                                            | 14%                                           | 32%                                           |
| Buildings                                     | 33%                                           | 35%                                           | 37%                                           | 39%                                           | 42%                                           | 48%                                           | 55%                                           |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |
| Bioenergy                                     | 34                                            | 45                                            | 44                                            | 47                                            | 55                                            | 82                                            | 107                                           |
| Hydropower                                    | 130                                           | 136                                           | 137                                           | 140                                           | 140                                           | 141                                           | 143                                           |
| Solar PV                                      | 107                                           | 204                                           | 243                                           | 281                                           | 284                                           | 512                                           | 784                                           |
| Wind                                          | 169                                           | 235                                           | 288                                           | 360                                           | 319                                           | 469                                           | 621                                           |
| Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      |
| Liquid biofuels (billions of litres per year) | 25                                            | 42                                            | 46                                            | 52                                            | 72                                            | 86                                            | 97                                            |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |
| Annual level (Gt CO 2 /yr)                    | 3.4                                           | 2.6                                           | 2.2                                           | 1.9                                           | 1.9                                           | 1.2                                           | 0.6                                           |
| Reduction vs. today                           | NA                                            | -22%                                          | -35%                                          | -42%                                          | -43%                                          | -64%                                          | -82%                                          |

## European Union

Where we are heading

Planned Energy

Scenario 2016/thinspace-/thinspace2050

(PES)

<!-- image -->

Where we need to be Transforming Energy Scenario 2016-2050 (TES)

## Energy system investments (average annual, 2016-50) USD billion/year

| Power                                |   98 |   145 |
|--------------------------------------|------|-------|
| - Renewable                          |   38 |  78   |
| - Non-renewable                      |   22 |  12   |
| - Power grids and system flexibility |   38 |  56   |
| Industry (RE + EE)                   |    6 |   8   |
| Transport (electrification + EE)     |   18 |  32   |
| Buildings (RE + EE)                  |   89 | 130   |
| Biofuel supply                       |    2 |   5   |
| Renewable hydrogen - electrolysers   |    0 |   0.7 |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019b; 2019c) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| European Union                      | 2019e      | 2030       | 2050       |
|-------------------------------------|------------|------------|------------|
| Population (thousands) region-wide  | 511 528    | 506687     | 496892     |
| GDP (USD 2015)                      |            |            |            |
| GDP (million): PES                  | 20903940   | 26 987 610 | 34800915   |
| GDP (million): TES                  | 21 279 174 | 27 940359  | 37 372 375 |
| GDP changes (million): TES vs. PES  | 375 234    | 952 749    | 2 571 460  |
| GDP changes (%): TES vs. PES        | 1.8        | 3.5        | 7.4        |
| Per capita GDP (thousand): PES      | 40.9       | 53.3       | 70.0       |
| Per capita GDP (thousand): TES      | 41.6       | 55.1       | 75.2       |
| Employment                          |            |            |            |
| Economy-wide employment (thousands) |            |            |            |
| Employment: PES                     | 237 331    | 241 626    | 228 604    |
| Employment: TES                     | 238 323    | 244026     | 234 073    |
| Employment changes: TES vs. PES     | 992        | 2 400      | 5 469      |
| Employment changes (%): TES vs. PES | 0.42%      | 0.99%      | 2.39%      |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

European Union

## Energy sector jobs (thousands)

Nuclear power

Fossil fuels

Renewables

Energy efficiency

Power grids and energy flexibility

Total

Energy jobs in economy-wide employment (%)

2030

(PES)

118

1 645

1 730

1 715

694

5 901

2.4%

2050

(PES)

73

1 135

1 636

1 496

574

4 914

2.1%

2030

(TES)

96

1 346

2 502

2 723

757

7 424

3.0%

2050

(TES)

27

726

2 701

1 717

821

5 993

2.6%

## Renewable energy jobs (thousands)

| Bioenergy                                             | 661   | 736   | 709   | 968   | 1 065   |
|-------------------------------------------------------|-------|-------|-------|-------|---------|
| Solar                                                 | 139   | 282   | 311   | 646   | 866     |
| Hydropower                                            | 136   | 245   | 151   | 280   | 144     |
| Wind                                                  | 344   | 456   | 454   | 592   | 608     |
| Geothermal                                            | 9     | 10    | 9     | 13    | 15      |
| Ocean                                                 | 1     | 1     | 2     | 2     | 4       |
| Total                                                 | 1 290 | 1 730 | 1 636 | 2 502 | 2 701   |
| Renewable energy jobs in energy-sector employment (%) |       | 29.3% | 33.3% | 33.7% | 45.1%   |

## Job differential in 2050 (thousands) TES vs. PES

Economy-wide

Changes in conventional energy (A)

Changes in transition related technologies (B)

Net jobs (A+B)

5 469

-454

1 533

1079

2017

104

1 113

1 290

312

483

3 303

## Jobs in 2050: TES / European Union

| Technology jobs (thousands)   | Technology jobs (thousands)   | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      | 629                           | Construction & installation       | 600                               | Workers and technicians                 | 1 101                                   |
| Solar water heaters (SWH)     | 221                           | Manufacturing                     | 549                               | Experts                                 | 164                                     |
| Onshore wind                  | 443                           | Operation and maintenance         | 324                               | Engineers and higher degrees            | 139                                     |
| Offshore wind                 | 165                           | Biofuel supply                    | -                                 | Marketing and administrative            | 69                                      |
| Geothermal                    | 15                            |                                   |                                   |                                         |                                         |
| Total                         | 1 473                         |                                   | 1 473                             |                                         | 1 473                                   |

Welfare improvement (%):

TES vs. PES

2030

2050

Indicator

Economic

Social

Environmental

Total

0.9

3.1

1.7

5.7

2.0

5.1

3.5

10.6

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply, Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world , www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition , International Energy Agency, Paris.

IRENA (2019a), Renewable Cost Database , 2019.

IRENA (2019b), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->

<!-- image -->

## GLOBAL RENEWABLES OUTLOOK

## ENERGY TRANSFORMATION

## REST OF EUROPE

Regional analysis covers:

- •  Albania
- •  Andorra
- •  Belarus
- •    Bosnia and Herzegovina
- •  Liechtenstein
- •  Monaco
- •  Montenegro
- •  Norway
- •  Iceland
- •    Republic of Moldova

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

Current:

3% of global population, mainly in the Russian Federation (61%) and Ukraine (19%).

2050 outlook:

Average 0.3% per year decrease to 208 million , or 2.2% of global population.

IRENA analysis based on E3ME.

Current:

Above the global average (10.9).

2050 outlook:

Slight development;

PES:

CAGR = 1.5%

<!-- image -->

IRENA analysis based on E3ME.

<!-- image -->

- •    Russian Federation
- •  Serbia
- •  Switzerland
- •  North Macedonia
- •  Ukraine

## Energy consumption per capita:

## Electricity access:

<!-- image -->

<!-- image -->

## Clean cooking access:

Current: well above the global average (51 GJ/year).

The region has long achieved full electrification.

8% lacks; marginal use of inefficient biomass stoves for cooking and home heating  continues, mainly in rural areas.

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019), 2050 values based on IRENA analysis.

## Fossil fuel net import

Current status:

<!-- image -->

Net fossil-fuel exporter, mainly due to the Russian Federation, the world's largest oil and gas exporter, covering almost 6% of energy consumption in the rest of the world (2018).

2050 outlook:

## Vast untapped renewable potential.

PES: The total generation (est. 1997 TWh) represents 7% of overall renewable power potential.

Source: IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

<!-- image -->

Current status:

Accounts for over 11% of global energy demand for iron and steel, around 8% for chemical and petrochemical industries and 7% for food and tobacco .

2050 outlook:

Need for alternative emission-free technological solutions.

Note: Current status, IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Recent:

Region's annual emissions: 2.1 Gt (2018).

6% of global energy-related emissions.

2050 outlook:

## PES: 7% increase to 2.3 Gt

based on current policies.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

<!-- image -->

Air pollution is problematic for some countries, such as in Southeast Europe, which have high levels of PM 2.5 compared to Norway and Switzerland that have better air quality.

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

## Electricity price:

## Renewables cost and auctions:

Among the lowest in the world, only in MENA is lower. Similar to Rest of Asia.

Average prices for historical projects are around USD 0.08/kWh and USD 0.05/kWh for solar and wind, respectively.

­

<!-- image -->

LCOE based on IRENA (2019a) and electricity prices based on Global Petrol Prices (2019). Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

## ENERGY TRANSFORMATION: KEY BENEFITS

## SUSTAINABLE DEVELOPMENT

- Affordable energy for citizens
- Economic growth and competitiveness
- Increase in energy sector jobs
- Improved welfare
- Reduce oil and gas dependence (net importers)
- Diversified economy and energy supply (net exporters, e.g. Russian Federation)
- Better air quality
- Increased use of renewables

<!-- image -->

## ENERGY SECURITY

## CLIMATE SUSTAINABILITY

- Cost-effective path to achieve climate goals

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

1

<!-- image -->

2

<!-- image -->

<!-- image -->

3

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading   | Where we are heading   | Where we are heading   | Where we need to be   | Where we need to be   | Where we need to be   |
|-----------------------------------------------|-----------------------------------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|
| Rest of Europe                                | 2017                                          | 2030 (PES)             | 2040 (PES)             | 2050 (PES)             | 2030 (TES)            | 2040 (TES)            | 2050 (TES)            |
| Energy (EJ)                                   |                                               |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 39                                            | 46                     | 46                     | 47                     | 38                    | 36                    | 33                    |
| Consumption (TFEC)                            | 24                                            | 29                     | 30                     | 30                     | 23                    | 21                    | 18                    |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 6%                                            | 10%                    | 10%                    | 12%                    | 19%                   | 34%                   | 54%                   |
| Consumption (TFEC)                            | 7%                                            | 9%                     | 11%                    | 12%                    | 20%                   | 37%                   | 61%                   |
| Power generation                              | 27%                                           | 28%                    | 28%                    | 31%                    | 42%                   | 63%                   | 82%                   |
| Electricity share in final energy consumption | Electricity share in final energy consumption |                        |                        |                        |                       |                       |                       |
| End-use consumption                           | 18%                                           | 18%                    | 20%                    | 22%                    | 23%                   | 28%                   | 38%                   |
| Industry                                      | 20%                                           | 22%                    | 24%                    | 25%                    | 27%                   | 30%                   | 35%                   |
| Transport                                     | 6%                                            | 6%                     | 8%                     | 12%                    | 12%                   | 21%                   | 37%                   |
| Buildings                                     | 21%                                           | 24%                    | 26%                    | 28%                    | 28%                   | 33%                   | 42%                   |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |                        |                        |                        |                       |                       |                       |
| Bioenergy                                     | 2                                             | 3                      | 6                      | 17                     | 27                    | 56                    | 83                    |
| Hydropower                                    | 111                                           | 105                    | 95                     | 94                     | 127                   | 140                   | 157                   |
| Solar PV                                      | 3                                             | 25                     | 25                     | 38                     | 39                    | 58                    | 107                   |
| Wind                                          | 2                                             | 16                     | 31                     | 45                     | 33                    | 57                    | 79                    |
| Biofuels                                      | Biofuels                                      |                        |                        |                        |                       |                       |                       |
| Liquid biofuels (billions of litres per year) | 1                                             | 12                     | 18                     | 23                     | 22                    | 34                    | 47                    |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |                        |                        |                        |                       |                       |                       |
| Annual level (Gt CO 2 /yr)                    | 2                                             | 2.4                    | 2.3                    | 2.3                    | 1.6                   | 1.2                   | 0.7                   |
| Reduction vs. today                           | NA                                            | 17%                    | 15%                    | 12%                    | -19%                  | -42%                  | -68%                  |

## Rest of Europe

Where we are heading

Planned Energy

Scenario 2016/thinspace-/thinspace2050

(PES)

<!-- image -->

Where we need to be Transforming Energy Scenario 2016-2050 (TES)

## Energy system investments (average annual, 2016-50) USD billion/year

| Power                                |   25 |   33 |
|--------------------------------------|------|------|
| - Renewable                          |  4   |   21 |
| - Non-renewable                      | 16   |    5 |
| - Power grids and system flexibility |  5   |    6 |
| Industry (RE + EE)                   |  5   |    7 |
| Transport (electrification + EE)     | 12   |   20 |
| Buildings (RE + EE)                  | 57   |   83 |
| Biofuel supply                       |  2   |    8 |
| Renewable hydrogen - electrolysers   |  0.1 |    1 |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019b; 2019c) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| Rest of Europe                      | 2019e     | 2030      | 2050    |
|-------------------------------------|-----------|-----------|---------|
| Population (thousands) region-wide  | 230174    | 223 224   | 208212  |
| GDP (USD 2015)                      |           |           |         |
| GDP (million): PES                  | 2 991 058 | 3 242 176 | 4289467 |
| GDP (million): TES                  | 3 150 705 | 3 181 845 | 4356940 |
| GDP changes (million): TES vs. PES  | 159 647   | -60 332   | 67 473  |
| GDP changes (%): TES vs. PES        | 5.3       | -1.9      | 1.6     |
| Per capita GDP (thousand): PES      | 13.0      | 14.5      | 20.6    |
| Per capita GDP (thousand): TES      | 13.7      | 14.3      | 20.9    |
| Employment                          |           |           |         |
| Economy-wide employment (thousands) |           |           |         |
| Employment: PES                     | 144 339   | 148 766   | 154 839 |
| Employment: TES                     | 144 472   | 148 635   | 154 527 |
| Employment changes: TES vs. PES     | 133       | -131      | -313    |
| Employment changes (%): TES vs. PES | 0.09%     | -0.09%    | -0.20%  |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Rest of Europe                                        | 2017                                             | 2030 (PES)                                       | 2050 (PES)                                       | 2030 (TES)                                       | 2050 (TES)                                       |
|-------------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Energy sector jobs (thousands)                        |                                                  |                                                  |                                                  |                                                  |                                                  |
| Nuclear power                                         | 167                                              | 181                                              | 184                                              | 148                                              | 65                                               |
| Fossil fuels                                          | 3 139                                            | 3 085                                            | 2 962                                            | 2 771                                            | 2 407                                            |
| Renewables                                            | 275                                              | 500                                              | 716                                              | 1 044                                            | 1 730                                            |
| Energy efficiency                                     | 420                                              | 373                                              | 435                                              | 577                                              | 940                                              |
| Power grids and energy flexibility                    | 927                                              | 964                                              | 1 001                                            | 978                                              | 1 063                                            |
| Total                                                 | 4928                                             | 5 103                                            | 5 298                                            | 5 518                                            | 6205                                             |
| Energy jobs in economy-wide employment (%)            |                                                  | 3.4%                                             | 3.4%                                             | 3.7%                                             | 4.0%                                             |
| Renewable energy jobs (thousands)                     | Renewable energy jobs (thousands)                |                                                  |                                                  |                                                  |                                                  |
| Bioenergy                                             | 97                                               | 228                                              | 395                                              | 579                                              | 1 049                                            |
| Solar                                                 | 31                                               | 82                                               | 169                                              | 193                                              | 450                                              |
| Hydropower                                            | 143                                              | 128                                              | 50                                               | 171                                              | 86                                               |
| Wind                                                  | 4                                                | 61                                               | 97                                               | 95                                               | 122                                              |
| Geothermal                                            | 1                                                | 1                                                | 5                                                | 5                                                | 23                                               |
| Ocean                                                 | 0                                                | 0                                                | 0                                                | 0                                                | 0                                                |
| Total                                                 | 275                                              | 500                                              | 716                                              | 1 044                                            | 1 730                                            |
| Renewable energy jobs in energy-sector employment (%) |                                                  | 9.8%                                             | 13.5%                                            | 18.9%                                            | 27.9%                                            |
| Job differential in 2050 (thousands) TES vs. PES      | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES |
| Economy-wide                                          | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | -313                                             |
| Changes in conventional energy (A)                    | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | -674                                             |
| Changes in transition related technologies (B)        | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | 1 581                                            |
| Net jobs (A+B)                                        | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | 908                                              |

## Jobs in 2050: TES / Rest of Europe

| Technology jobs (thousands)   | Technology jobs (thousands)   | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      | 311                           | Construction & installation       | 400                               | Workers and technicians                 | 485                                     |
| Solar water heaters (SWH)     | 138                           | Manufacturing                     | 34                                | Experts                                 | 49                                      |
| Onshore wind                  | 122                           | Operation and maintenance         | 160                               | Engineers and higher degrees            | 53                                      |
| Offshore wind                 | -                             | Biofuel supply                    | -                                 | Marketing and administrative            | 8                                       |
| Geothermal                    | 23                            |                                   |                                   |                                         |                                         |
| Total                         | 594                           |                                   | 594                               |                                         | 594                                     |

| Welfare improvement (%): TES vs. PES   | 2030   | 2050   |
|----------------------------------------|--------|--------|
| Indicator                              |        |        |
| Economic                               | (0.3)  | 0.2    |
| Social                                 | 4.2    | 7.8    |
| Environmental                          | 2.1    | 4.5    |
| Total                                  | 6.0    | 12.4   |

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply, Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world , www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition , International Energy Agency, Paris.

IRENA (2019a), Renewable Cost Database , 2019.

IRENA (2019b), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socioeconomic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION

## LATIN AMERICA AND THE CARIBBEAN

Regional analysis extends from the Caribbean Islands and Central America to the southernmost tip of South America.

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

Current:

## 6.1% of global population.

Highest regional share in Brazil (40%) followed by Colombia (10%) and Argentina (9%).

2050 outlook:

Average 0.4% per year increase to 536 million , or 5.7% of global population.

IRENA analysis based on E3ME.

Current:

Below the global average (10.9).

2050 outlook:

Swift development;

PES: CAGR = 3.8%

<!-- image -->

IRENA analysis based on E3ME.

<!-- image -->

<!-- image -->

## Energy consumption per capita:

## Electricity access:

## Clean cooking access:

Current: below global average (51 GJ/year).

Almost complete except for few countries such as Honduras and Haiti.

13% of region's population lack access; major concern in some countries.

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019).

## Fossil fuel net import

Current status:

<!-- image -->

Comparatively energy self-sufficiency region-wide; Central America imports fossil fuels, while Andean and Southern Cone sub-regions are net exporters.

2050 outlook:

Resource diversification; enormous untapped potential.

PES: The total generation (est. 3138 TWh) just represents 6% of overall renewable power potential.

Note: Current status, IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

<!-- image -->

Current status:

Accounts for 17% of the world's energy demand for food and tobacco and over 10% of global energy consumption in the paper industry .

2050 outlook:

Require significant efforts and specific solutions to decarbonise energy-intensive industries.

Note: Current status, IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Recent:

Region's annual emissions: 1.2 Gt (2018). 4% of global energy-related CO2 emissions.

2050 outlook:

PES: 39% increase to 1.7 Gt with enabling policies.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

<!-- image -->

Rising transport emissions with continued population growth and urbanisation.

Current plans would boost light-vehicle sales, but also intensify traffic jams and local pollution.

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

## Electricity price:

## Renewables cost and auctions:

Mid-range (for households and industries) compared to other regions.

Cost-competitive; Argentina attained wind price at an average of USD 0.041/kWh in 2017; Brazil attained solar price at an average of USD 0.021/kWh in 2019 (IRENA, 2019a). Hydropower projects remain highly competitive.

GLYPH&lt;129&gt;

GLYPH&lt;157&gt;

­

€

­

GLYPH&lt;141&gt;

ƒ

GLYPH&lt;144&gt;

'

<!-- image -->

Source: LCOE based on IRENA (2019b) and electricity prices based on Global Petrol Prices (2019). Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

## ENERGY TRANSFORMATION: KEY BENEFITS

## AFFORDABLE, ACCESSIBLE ENERGY

- Lower system costs
- Distributed power for isolated communities
- Clean cooking

1

<!-- image -->

2

- Resiliance to climate, other risks
- Diversified energy supply
- Reduced energy demand with improved efficiency measures
- Improved infrastructure
- Economic development
- rade gains by moving T away from fossil fuels
- Better air quality and reduced local pollution
- Improved education and empowered citizens

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

ENERGY SECURITY, CLIMATERESILIENCE

CLEAN, CLIMATE-SAFE ECONOMIES

<!-- image -->

<!-- image -->

3

Latin America &amp;

Caribbean

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading   | Where we are heading   | Where we are heading   | Where we need to be   | Where we need to be   | Where we need to be   |
|-----------------------------------------------|-----------------------------------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|
| Latin America & Caribbean                     | 2017                                          | 2030 (PES)             | 2040 (PES)             | 2050 (PES)             | 2030 (TES)            | 2040 (TES)            | 2050 (TES)            |
| Energy (EJ)                                   |                                               |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 27                                            | 35                     | 42                     | 46                     | 30                    | 32                    | 33                    |
| Consumption (TFEC)                            | 21                                            | 27                     | 31                     | 34                     | 22                    | 22                    | 21                    |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 30%                                           | 40%                    | 42%                    | 46%                    | 53%                   | 63%                   | 73%                   |
| Consumption (TFEC)                            | 30%                                           | 36%                    | 37%                    | 40%                    | 47%                   | 57%                   | 67%                   |
| Power generation                              | 65%                                           | 73%                    | 75%                    | 79%                    | 85%                   | 90%                   | 93%                   |
| Electricity share in final energy consumption | Electricity share in final energy consumption |                        |                        |                        |                       |                       |                       |
| End-use consumption                           | 18%                                           | 22%                    | 24%                    | 26%                    | 26%                   | 31%                   | 39%                   |
| Industry                                      | 21%                                           | 24%                    | 24%                    | 25%                    | 27%                   | 29%                   | 33%                   |
| Transport                                     | 0.2%                                          | 1%                     | 1%                     | 2%                     | 9%                    | 14%                   | 24%                   |
| Buildings                                     | 45%                                           | 58%                    | 63%                    | 67%                    | 61%                   | 70%                   | 78%                   |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |                        |                        |                        |                       |                       |                       |
| Bioenergy                                     | 19                                            | 45                     | 61                     | 79                     | 50                    | 72                    | 94                    |
| Hydropower                                    | 173                                           | 181                    | 201                    | 226                    | 186                   | 211                   | 240                   |
| Solar PV                                      | 5                                             | 76                     | 128                    | 177                    | 108                   | 196                   | 281                   |
| Wind                                          | 17                                            | 74                     | 111                    | 148                    | 93                    | 141                   | 188                   |
| Biofuels                                      | Biofuels                                      |                        |                        |                        |                       |                       |                       |
| Liquid biofuels (billions of litres per year) | 31                                            | 61                     | 74                     | 79                     | 61                    | 75                    | 73                    |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |                        |                        |                        |                       |                       |                       |
| Annual level (Gt CO 2 /yr)                    | 1.2                                           | 1.4                    | 1.6                    | 1.7                    | 1                     | 0.8                   | 0.6                   |
| Reduction vs. today                           | NA                                            | 19%                    | 35%                    | 38%                    | -21%                  | -35%                  | -54%                  |

<!-- image -->

## Latin America &amp; Caribbean

Where we are heading Planned Energy Scenario 2016/thinspace-/thinspace2050 (PES)

Where we need to be Transforming Energy Scenario 2016-2050 (TES)

## Energy system investments (average annual, 2016-50) USD billion/year

| Power                                |    39 |   45 |
|--------------------------------------|-------|------|
| - Renewable                          | 21    | 28   |
| - Non-renewable                      |  5    |  3   |
| - Power grids and system flexibility | 13    | 15   |
| Industry (RE + EE)                   |  7    | 11   |
| Transport (electrification + EE)     | 10    | 19   |
| Buildings (RE + EE)                  | 29    | 42   |
| Biofuel supply                       |  2.4  |  2.5 |
| Renewable hydrogen - electrolysers   |  0.03 |  0.5 |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019c; 2019d) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| Latin America & Caribbean           | 2019e     | 2030      | 2050       |
|-------------------------------------|-----------|-----------|------------|
| Population (thousands) region-wide  | 474 076   | 505546    | 535 802    |
| GDP (USD 2015)                      |           |           |            |
| GDP (million): PES                  | 3 679 104 | 5 158 950 | 13 240587  |
| GDP (million): TES                  | 3 700954  | 5 194 779 | 13 563 681 |
| GDP changes (million): TES vs. PES  | 21 850    | 35 828    | 323 093    |
| GDP changes (%): TES vs. PES        | 0.6       | 0.7       | 2.4        |
| Per capita GDP (thousand): PES      | 7.8       | 10.2      | 24.7       |
| Per capita GDP (thousand): TES      | 7.8       | 10.3      | 25.3       |
| Employment                          |           |           |            |
| Economy-wide employment (thousands) |           |           |            |
| Employment: PES                     | 272 097   | 282 324   | 251 102    |
| Employment: TES                     | 272 239   | 281 399   | 250700     |
| Employment changes: TES vs. PES     | 143       | -925      | -402       |
| Employment changes (%): TES vs. PES | 0.05      | -0.33     | -0.16      |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Latin America & Caribbean                             | 2017                                             | 2030 (PES)                                       | 2050 (PES)                                       | 2030 (TES)                                       | 2050 (TES)                                       |
|-------------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Energy sector jobs (thousands)                        |                                                  |                                                  |                                                  |                                                  |                                                  |
| Nuclear power                                         | 8                                                | 12                                               | 8                                                | 10                                               | 6                                                |
| Fossil fuels                                          | 1 180                                            | 1 104                                            | 953                                              | 962                                              | 700                                              |
| Renewables                                            | 2 027                                            | 2 575                                            | 2 585                                            | 3 295                                            | 3 212                                            |
| Energy efficiency                                     | 887                                              | 870                                              | 735                                              | 1 211                                            | 818                                              |
| Power grids and energy flexibility                    | 364                                              | 466                                              | 403                                              | 463                                              | 455                                              |
| Total                                                 | 4467                                             | 5 026                                            | 4685                                             | 5 941                                            | 5190                                             |
| Energy jobs in economy-wide employment (%)            |                                                  | 1.80%                                            | 1.90%                                            | 2.10%                                            | 2.10%                                            |
| Renewable energy jobs (thousands)                     | Renewable energy jobs (thousands)                |                                                  |                                                  |                                                  |                                                  |
| Bioenergy                                             | 1 620                                            | 1 971                                            | 1 875                                            | 2 331                                            | 2 133                                            |
| Solar                                                 | 64                                               | 173                                              | 301                                              | 474                                              | 570                                              |
| Hydropower                                            | 300                                              | 320                                              | 264                                              | 351                                              | 306                                              |
| Wind                                                  | 42                                               | 109                                              | 143                                              | 136                                              | 199                                              |
| Geothermal                                            | 1                                                | 2                                                | 2                                                | 2                                                | 4                                                |
| Ocean                                                 | 0                                                | 0                                                | 0                                                | 0                                                | 0                                                |
| Total                                                 | 2 027                                            | 2 575                                            | 2 585                                            | 3 295                                            | 3 212                                            |
| Renewable energy jobs in energy-sector employment (%) |                                                  | 51.2%                                            | 55.2%                                            | 55.5%                                            | 61.9%                                            |
| Job differential in 2050 (thousands) TES vs. PES      | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES |
| Economy-wide                                          | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | -402                                             |
| Changes in conventional energy (A)                    | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | -255                                             |
| Changes in transition related technologies (B)        | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | 761                                              |
| Net jobs (A+B)                                        | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | 506                                              |

## Jobs in 2050: TES / Latin America &amp; Caribbean

| Technology jobs (thousands)   |   Technology jobs (thousands) | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      |                           276 | Construction & installation       | 372                               | Workers and technicians                 | 631                                     |
| Solar water heaters (SWH)     |                           293 | Manufacturing                     | 225                               | Experts                                 | 64                                      |
| Onshore wind                  |                           195 | Operation and maintenance         | 174                               | Engineers and higher degrees            | 52                                      |
| Offshore wind                 |                             5 | Biofuel supply                    | -                                 | Marketing and administrative            | 25                                      |
| Geothermal                    |                             4 |                                   |                                   |                                         |                                         |
| Total                         |                           771 |                                   | 771                               |                                         | 771                                     |

| Welfare improvement (%): TES vs. PES   | 2030   | 2050   |
|----------------------------------------|--------|--------|
| Indicator                              |        |        |
| Economic                               | -0.1   | 0.2    |
| Social                                 | 2.8    | 10.0   |
| Environmental                          | 2.2    | 4.6    |
| Total                                  | 5.0    | 14.8   |
|                                        |        |        |

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply , Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world , www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition, International Energy Agency, Paris.

IRENA (2019a), Renewable energy auctions: Status and trends beyond price , International Renewable Energy Agency, Abu Dhabi

IRENA (2019b), Renewable Cost Database , 2019.

IRENA (2019c), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019d), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION

## MIDDLE EAST AND NORTH AFRICA

## STATUS/CHARACTERISTICS AND NEEDS:

Regional analysis covers major oil and gas exporters as well as net importers, spanning the Gulf States, other parts of the Middle East, and North Africa.

## Middle East:

## North Africa:

• Bahrain

• Iran (Islamic Republic of)

• Iraq

• Israel

• Jordan

• Kuwait

• Lebanon

• Oman

• Qatar

• Saudi Arabia

• State of Palestine

• Syrian Arab Republic

• United Arab Emirates

• Yemen

• Algeria

• Egypt

• Libya

• Morocco

• Tunisia

• Western Sahara

• Djibouti

<!-- image -->

IRENA analysis based on E3ME.

<!-- image -->

IRENA analysis based on E3ME.

Current:

## 6% of global population,

highest regional share in Egypt (22%), Iran (18%) and Algeria (9.4%).

Average 1.1% per year increase to 677 million , or 7% of global population.

Below the global average (10.9).

Adequate development;

<!-- image -->

PES: CAGR = 3%

2050 outlook:

Current:

2050 outlook:

Energy consumption per capita:

<!-- image -->

<!-- image -->

## Electricity access:

## Clean cooking access:

Current: in line with global average (51 GJ/year).

Countries reached high electrification (close to 100%).

Rural areas depend on traditional energy sources or diesel generators.

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019).

<!-- image -->

Current status:

Region contributes to 37% of global oil production and 35% of global natural gas production ; with oil production dominated by Saudi Arabia (35%), Iran (14%) and Iraq  (13%) and gas production dominated by Iran (28%), Qatar (22%) and Saudi Arabia (14%) (Tagliapietra, 2019).

2050 outlook:

## Vast untapped renewable energy potential.

PES: The total generation (est. 3477 TWh) just represents 5% of overall renewable power potential.

Note: Current status, IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

<!-- image -->

Current status:

Only a tiny share (2%) comes from energy intensive industries of the region (mainly from the chemical and petrochemical sector).

2050

outlook:

IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Need for alternative clean energy technological solutions and emission-capture measures.

Region's annual emissions: 2.6 Gt (2018).

8% of global energy-related emissions.

2050 outlook:

- PES: 27% increase to 3.2 Gt with enabling policies.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

Recent:

Middle East and

North Africa

<!-- image -->

Air quality has deteriorated dramatically in recent decades. Few cities (3%) with more than 100 000 inhabitants in low- and middle-income MENA countries meet WHO air quality guidelines (2018).

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

Electricity price:

## Renewables cost and auctions:

The lowest compared to the other regions due to fossil-fuel subsidies.

In 2019, Morocco auctioned an advanced hybrid (CSP/PV) plant for a record-low peak-hour tariff of USD 0.071/kWh (IRENA, 2019a). United Arab Emirates contracted solar power at USD 0.299/kWh (IRENA, 2017).

<!-- image -->

LCOE based on IRENA (2019b) and electricity prices based on Global Petrol Prices (2019). Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

## ENERGY TRANSFORMATION: KEY BENEFITS

## REDUCED EMISSIONS AND LOCAL AIR POLLUTION

## ENERGY SECURITY AND ECONOMIC SELF-RELIANCE

## SUSTAINABLE DEVELOPMENT

<!-- image -->

1

<!-- image -->

2

- Diversified energy supply
- Reduced import dependence (oil importers)
- Focus on high-value exports (oil exporters)
- Cross-border electricity trade

<!-- image -->

<!-- image -->

3

- Diversified economy and sustainable economic activities
- Local job creation
- Improved welfare
- Lower CO2 emissions
- Better local air quality
- Efficient energy services extended to rural areas

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading   | Where we are heading   | Where we are heading   | Where we need to be   | Where we need to be   | Where we need to be   |
|-----------------------------------------------|-----------------------------------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|
| Middle East and North Africa                  | 2017                                          | 2030 (PES)             | 2040 (PES)             | 2050 (PES)             | 2030 (TES)            | 2040 (TES)            | 2050 (TES)            |
| Energy (EJ)                                   |                                               |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 40                                            | 52                     | 60                     | 62                     | 39                    | 36                    | 30                    |
| Consumption (TFEC)                            | 23                                            | 33                     | 39                     | 41                     | 25                    | 24                    | 20                    |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 1%                                            | 4%                     | 6%                     | 7%                     | 9%                    | 16%                   | 26%                   |
| Consumption (TFEC)                            | 1%                                            | 4%                     | 4%                     | 5%                     | 8%                    | 15%                   | 26%                   |
| Power generation                              | 3%                                            | 14%                    | 17%                    | 20%                    | 27%                   | 39%                   | 53%                   |
| Electricity share in final energy consumption | Electricity share in final energy consumption |                        |                        |                        |                       |                       |                       |
| End-use consumption                           | 19%                                           | 16%                    | 18%                    | 20%                    | 20%                   | 27%                   | 38%                   |
| Industry                                      | 12%                                           | 8%                     | 8%                     | 9%                     | 12%                   | 15%                   | 20%                   |
| Transport                                     | 0.1%                                          | 0.3%                   | 1%                     | 2%                     | 2%                    | 7%                    | 15%                   |
| Buildings                                     | 43%                                           | 44%                    | 46%                    | 50%                    | 48%                   | 59%                   | 77%                   |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |                        |                        |                        |                       |                       |                       |
| Bioenergy                                     | 0                                             | 2                      | 2                      | 3                      | 2                     | 3                     | 3                     |
| Hydropower                                    | 20                                            | 18                     | 21                     | 23                     | 20                    | 23                    | 26                    |
| Solar PV                                      | 2                                             | 53                     | 71                     | 85                     | 66                    | 108                   | 147                   |
| Wind                                          | 2                                             | 51                     | 100                    | 138                    | 76                    | 158                   | 212                   |
| Biofuels                                      | Biofuels                                      |                        |                        |                        |                       |                       |                       |
| Liquid biofuels (billions of litres per year) | NA                                            | 3                      | 3                      | 4                      | 4                     | 5                     | 6                     |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |                        |                        |                        |                       |                       |                       |
| Annual level (Gt CO 2 /yr)                    | 2.5                                           | 2.9                    | 3.2                    | 3.2                    | 2                     | 1.6                   | 1.1                   |
| Reduction vs. today                           | NA                                            | 16%                    | 29%                    | 30%                    | -20%                  | -34%                  | -56%                  |

<!-- image -->

## Middle East and North Africa

Where we are heading Planned Energy Scenario 2016/thinspace-/thinspace2050 (PES)

Where we need to be Transforming Energy Scenario 2016-2050 (TES)

## Energy system investments (average annual, 2016-50) USD billion/year

| Power                                |   55 |   53 |
|--------------------------------------|------|------|
| - Renewable                          |  9   | 16   |
| - Non-renewable                      | 22   | 14   |
| - Power grids and system flexibility | 24   | 23   |
| Industry (RE + EE)                   |  8   | 11   |
| Transport (electrification + EE)     | 11   | 15   |
| Buildings (RE + EE)                  | 52   | 76   |
| Biofuel supply                       |  1.1 |  3   |
| Renewable hydrogen - electrolysers   |  0.3 |  2.8 |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019c; 2019d) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| Middle East and North Africa        | 2019e    | 2030      | 2050       |
|-------------------------------------|----------|-----------|------------|
| Population (thousands) region-wide  | 491 460  | 567 708   | 677 439    |
| GDP (USD 2015)                      |          |           |            |
| GDP (million): PES                  | 4516 464 | 7 372 988 | 15 494435  |
| GDP (million): TES                  | 4580811  | 7 358 619 | 15 112 505 |
| GDP changes (million): TES vs. PES  | 64347    | -14 368   | -381 930   |
| GDP changes (%): TES vs. PES        | 1.4      | -0.2      | -2.5       |
| Per capita GDP (thousand): PES      | 9.2      | 13.0      | 22.9       |
| Per capita GDP (thousand): TES      | 9.3      | 13.0      | 22.3       |
| Employment                          |          |           |            |
| Economy-wide employment (thousands) |          |           |            |
| Employment: PES                     | 175 696  | 187 016   | 186 184    |
| Employment: TES                     | 175 742  | 186 825   | 185 801    |
| Employment changes: TES vs. PES     | 46       | -191      | -382       |
| Employment changes (%): TES vs. PES | 0.03%    | -0.10%    | -0.21%     |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Middle East and North Africa                          | 2017                                             | 2030 (PES)                                       | 2050 (PES)                                       | 2030 (TES)                                       | 2050 (TES)                                       |
|-------------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Energy sector jobs (thousands)                        |                                                  |                                                  |                                                  |                                                  |                                                  |
| Nuclear power                                         | 15                                               | 56                                               | 70                                               | 55                                               | 42                                               |
| Fossil fuels                                          | 2 815                                            | 3 693                                            | 3 379                                            | 3 257                                            | 2 625                                            |
| Renewables                                            | 542                                              | 789                                              | 895                                              | 1 226                                            | 2 064                                            |
| Energy efficiency                                     | 1 113                                            | 1 809                                            | 1 328                                            | 2 731                                            | 1 537                                            |
| Power grids and energy flexibility                    | 622                                              | 927                                              | 885                                              | 900                                              | 1 014                                            |
| Total                                                 | 5 108                                            | 7 274                                            | 6557                                             | 8 168                                            | 7283                                             |
| Energy jobs in economy-wide employment (%)            |                                                  | 3.9%                                             | 3.5%                                             | 4.4%                                             | 3.9%                                             |
| Renewable energy jobs (thousands)                     |                                                  |                                                  |                                                  |                                                  |                                                  |
| Bioenergy                                             | 196                                              | 290                                              | 282                                              | 584                                              | 846                                              |
| Solar                                                 | 88                                               | 180                                              | 265                                              | 283                                              | 703                                              |
| Hydropower                                            | 250                                              | 262                                              | 250                                              | 266                                              | 239                                              |
| Wind                                                  | 7                                                | 55                                               | 93                                               | 90                                               | 273                                              |
| Geothermal                                            | 1                                                | 2                                                | 4                                                | 3                                                | 4                                                |
| Ocean                                                 | 0                                                | 0                                                | 0                                                | 0                                                | 0                                                |
| Total                                                 | 542                                              | 789                                              | 895                                              | 1 226                                            | 2 064                                            |
| Renewable energy jobs in energy-sector employment (%) |                                                  | 10.8%                                            | 13.6%                                            | 15.0%                                            | 28.3%                                            |
| Job differential in 2050 (thousands) TES vs. PES      | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES |
| Economy-wide                                          | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | -382                                             |
| Changes in conventional energy (A)                    | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | -782                                             |
| Changes in transition related technologies (B)        | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | 1 507                                            |
| Net jobs (A+B)                                        | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | 726                                              |

## Jobs in 2050: TES / Middle East and North Africa

| Technology jobs (thousands)          | Technology jobs (thousands)   | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|--------------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                             | 343                           | Construction & installation       | 559                               | Workers and technicians                 | 774                                     |
| Solar water heaters (SWH)            | 332                           | Manufacturing                     | 153                               | Experts                                 | 80                                      |
| Onshore wind                         | 273                           | Operation and maintenance         | 240                               | Engineers and higher degrees            | 76                                      |
| Offshore wind                        | 0                             | Biofuel supply                    | -                                 | Marketing and administrative            | 22                                      |
| Geothermal                           | 4                             |                                   |                                   |                                         |                                         |
| Total                                | 952                           |                                   | 952                               |                                         | 952                                     |
| Welfare improvement (%): TES vs. PES |                               | 2030                              |                                   |                                         |                                         |
| Indicator                            |                               |                                   |                                   |                                         |                                         |
| Economic                             |                               | 0.0                               |                                   |                                         |                                         |
| Social                               |                               | 4.3                               |                                   |                                         |                                         |
|                                      |                               | 1.9                               |                                   |                                         |                                         |
| Total                                |                               |                                   | 6.2                               |                                         |                                         |
|                                      |                               |                                   |                                   |                                         | 4.6                                     |
| Environmental                        |                               |                                   |                                   |                                         |                                         |

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply, Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world, www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition, International Energy Agency, Paris.

IRENA (2019a), Renewable energy auctions: Status and trends beyond price , International Renewable Energy Agency, Abu Dhabi

IRENA (2019b), Renewable Cost Database , 2019.

IRENA (2019c), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019d), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2017), Renewable Energy Auctions: Analysing 2016. IRENA, Abu Dhabi.

Tagliapietra, S. (2019), The impact of the global energy transition on MENA oil and gas producers, Energy Strategy Reviews 26, https://doi.org/10.1016/j.esr.2019.100397

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population), World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population), World Bank Group.

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION

## NORTH AMERICA

Regional analysis covers three countries:

- • Canada
- • Mexico
- • United States

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

Current:

6.5% of global population,

mainly in the United States (67%), Mexico (26%) and Canada (7%).

2050 outlook:

Average 0.6% per year increase to 591 million,

or 6.3% of global population.

IRENA analysis based on E3ME.

Current:

Well above the global average (10.9).

2050 outlook:

Slight development;

PES:

CAGR = 1.6%

<!-- image -->

IRENA analysis based on E3ME.

<!-- image -->

Energy consumption per capita:

## Electricity access:

<!-- image -->

<!-- image -->

## Clean cooking access:

Current: well above the global average (51 GJ/year).

Achieved in all the countries.

Near 100% except in Mexico (93%).

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019).

## Fossil fuel net import

Current status:

<!-- image -->

Largely self-sufficient; US, while still a net importer of crude oil, exports refined oil products and natural gas; Canada and Mexico have significant oil and gas reserves.

2050 outlook:

Continued negative health effects due to rising fossil fuel use; considerable untapped renewable potential.

- PES: The total generation (est. 7071 TWh) represents 13% of overall renewable power potential.

Note: Current status, IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

## Energy-intensive industries (% in global consumption)

Current status:

<!-- image -->

Over one-third of global paper energy demand is found in the region, as well as around one-fifth of global chemical and petrochemical and food and tobacco energy consumption.

2050 outlook:

IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Recent:

2050 outlook:

Urgent need for emissions reduction in heavy industries.

## Region's annual emissions: 6.3 Gt (2018).

19% of global energy-related CO2 emissions.

- · PES: 8% increase to 6.8 Gt based on current policies.
- · More renewables and continuing switch from coal to natural gas mitigate increase.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

North America

<!-- image -->

- ·   80% urban population, often concentrated in large cities.
- · Air pollution at moderate to unhealthy levels in 18% of cities mainly due to transport sector emissions.

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

Electricity price:

Renewable power costs:

## Auction prices:

Above the global average for both households and industries.

Competitive or least-cost compared to coal or natural gas, with solar PV averaging USD 0.08 cents/kWh and wind USD 0.05/kWh (2018).

## Lower than other regions;

new solar projects achieve around USD 0.02-0.03/kWh, and new wind projects around USD 0.03-0.04/kWh.

GLYPH&lt;143&gt;

GLYPH&lt;157&gt;

GLYPH&lt;157&gt;

GLYPH&lt;127&gt;

€

GLYPH&lt;141&gt;

,

<!-- image -->

LCOE based on IRENA (2019a) and electricity prices based on Global Petrol Prices (2019).

Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

## ENERGY TRANSFORMATION: KEY BENEFITS

## CUTTING-EDGE INNOVATION

- Advanced manufacturing and services
- Reduced energy system costs
- High-value job creation
- Regional energy self-sufficiency
- High energy efficiency
- Renewable power and end-use applications
- Improved interconnections

<!-- image -->

<!-- image -->

2

<!-- image -->

<!-- image -->

## ENERGY SECURITY

## SOCIOECONOMIC DEVELOPMENT

- Economic growth
- Higher economy-wide and energy sector jobs
- Improved environment and well-being

<!-- image -->

<!-- image -->

1

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading   | Where we are heading   | Where we are heading   | Where we need to be   | Where we need to be   | Where we need to be   |
|-----------------------------------------------|-----------------------------------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|
| North America                                 | 2017                                          | 2030 (PES)             | 2040 (PES)             | 2050 (PES)             | 2030 (TES)            | 2040 (TES)            | 2050 (TES)            |
| Energy (EJ)                                   |                                               |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 112                                           | 116                    | 120                    | 127                    | 90                    | 86                    | 82                    |
| Consumption (TFEC)                            | 79                                            | 86                     | 89                     | 93                     | 69                    | 64                    | 58                    |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 10%                                           | 13%                    | 14%                    | 17%                    | 30%                   | 50%                   | 67%                   |
| Consumption (TFEC)                            | 10%                                           | 12%                    | 13%                    | 15%                    | 29%                   | 48%                   | 68%                   |
| Power generation                              | 23%                                           | 30%                    | 33%                    | 38%                    | 60%                   | 79%                   | 85%                   |
| Electricity share in final energy consumption | Electricity share in final energy consumption |                        |                        |                        |                       |                       |                       |
| End-use consumption                           | 20%                                           | 21%                    | 21%                    | 22%                    | 28%                   | 40%                   | 52%                   |
| Industry                                      | 20%                                           | 19%                    | 19%                    | 19%                    | 20%                   | 25%                   | 28%                   |
| Transport                                     | 0.2%                                          | 1%                     | 2%                     | 2%                     | 13%                   | 35%                   | 57%                   |
| Buildings                                     | 48%                                           | 48%                    | 49%                    | 50%                    | 54%                   | 63%                   | 78%                   |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |                        |                        |                        |                       |                       |                       |
| Bioenergy                                     | 16                                            | 19                     | 18                     | 30                     | 22                    | 26                    | 25                    |
| Hydropower                                    | 177                                           | 182                    | 198                    | 238                    | 180                   | 192                   | 204                   |
| Solar PV                                      | 45                                            | 153                    | 296                    | 512                    | 485                   | 1 054                 | 1 728                 |
| Wind                                          | 104                                           | 174                    | 189                    | 191                    | 448                   | 946                   | 1 314                 |
| Biofuels                                      | Biofuels                                      |                        |                        |                        |                       |                       |                       |
| Liquid biofuels (billions of litres per year) | 64                                            | 63                     | 62                     | 70                     | 96                    | 144                   | 183                   |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |                        |                        |                        |                       |                       |                       |
| Annual level (Gt CO 2 /yr)                    | 6.2                                           | 6.6                    | 6.7                    | 6.8                    | 3.7                   | 2.5                   | 1.4                   |
| Reduction vs. today                           | NA                                            | 7%                     | 8%                     | 10%                    | -41%                  | -59%                  | -77%                  |

<!-- image -->

## North America

Where we are heading Planned Energy Scenario 2016/thinspace-/thinspace2050 (PES)

Where we need to be Transforming Energy Scenario 2016-2050 (TES)

## Energy system investments (average annual, 2016-50) USD billion/year

| Power                                |    117 |   195 |
|--------------------------------------|--------|-------|
| - Renewable                          |  31    | 108   |
| - Non-renewable                      |  45    |  22   |
| - Power grids and system flexibility |  41    |  65   |
| Industry (RE + EE)                   |  18    |  27   |
| Transport (electrification + EE)     |  29    |  97   |
| Buildings (RE + EE)                  | 118    | 177   |
| Biofuel supply                       |   0.5  |   5.9 |
| Renewable hydrogen - electrolysers   |   0.05 |   2.1 |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019b; 2019c) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| North America                       | 2019e      | 2030       | 2050       |
|-------------------------------------|------------|------------|------------|
| Population (thousands) region-wide  | 496175     | 536 927    | 590667     |
| GDP (USD 2015)                      |            |            |            |
| GDP (million): PES                  | 21 913 288 | 27 877 680 | 42 199 950 |
| GDP (million): TES                  | 22 188 303 | 28 117 917 | 42 814 939 |
| GDP changes (million): TES vs. PES  | 275 016    | 240237     | 614 990    |
| GDP changes (%): TES vs. PES        | 1.3        | 0.9        | 1.5        |
| Per capita GDP (thousand): PES      | 44.2       | 51.9       | 71.4       |
| Per capita GDP (thousand): TES      | 44.7       | 52.4       | 72.5       |
| Employment                          |            |            |            |
| Economy-wide employment (thousands) |            |            |            |
| Employment: PES                     | 250014     | 279 310    | 288 609    |
| Employment: TES                     | 251 639    | 281 435    | 291 621    |
| Employment changes: TES vs. PES     | 1 625      | 2 125      | 3 012      |
| Employment changes (%): TES vs. PES | 0.05       | -0.33      | -0.16      |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| North America                                         | 2017                                             | 2030 (PES)                                       | 2050 (PES)                                       | 2030 (TES)                                       | 2050 (TES)                                       |
|-------------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Energy sector jobs (thousands)                        |                                                  |                                                  |                                                  |                                                  |                                                  |
| Nuclear power                                         | 60                                               | 69                                               | 53                                               | 71                                               | 18                                               |
| Fossil fuels                                          | 1 126                                            | 1 380                                            | 1 318                                            | 1 053                                            | 816                                              |
| Renewables                                            | 992                                              | 1 197                                            | 1 367                                            | 2 335                                            | 2 987                                            |
| Energy efficiency                                     | 733                                              | 3 945                                            | 3 363                                            | 6 058                                            | 3 805                                            |
| Power grids and energy flexibility                    | 375                                              | 572                                              | 510                                              | 656                                              | 837                                              |
| Total                                                 | 3 285                                            | 7 163                                            | 6610                                             | 10 174                                           | 8463                                             |
| Energy jobs in economy-wide employment (%)            |                                                  | 2.56%                                            | 2.29%                                            | 3.61%                                            | 2.90%                                            |
| Renewable energy jobs (thousands)                     |                                                  |                                                  |                                                  |                                                  |                                                  |
| Bioenergy                                             | 449                                              | 431                                              | 422                                              | 625                                              | 764                                              |
| Solar                                                 | 269                                              | 390                                              | 601                                              | 1 137                                            | 1 520                                            |
| Hydropower                                            | 97                                               | 127                                              | 121                                              | 135                                              | 125                                              |
| Wind                                                  | 134                                              | 202                                              | 174                                              | 386                                              | 512                                              |
| Geothermal                                            | 43                                               | 47                                               | 49                                               | 52                                               | 61                                               |
| Ocean                                                 | -                                                | -                                                | -                                                | 0                                                | 5                                                |
| Total                                                 | 992                                              | 1 197                                            | 1 367                                            | 2 335                                            | 2 987                                            |
| Renewable energy jobs in energy-sector employment (%) |                                                  | 16.7%                                            | 20.7%                                            | 23.0%                                            | 35.3%                                            |
| Job differential in 2050 (thousands) TES vs. PES      | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES |
| Economy-wide                                          | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | 3 012                                            |
| Changes in conventional energy (A)                    | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | -537                                             |
| Changes in transition related technologies (B)        | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | 2 390                                            |
| Net jobs (A+B)                                        | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | Net jobs (A+B)                                   | 1 853                                            |

## Jobs in 2050: TES / North America

| Technology jobs (thousands)   | Technology jobs (thousands)   | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      | 991                           | Construction & installation       | 915                               | Workers and technicians                 | 1 639                                   |
| Solar water heaters (SWH)     | 516                           | Manufacturing                     | 561                               | Experts                                 | 199                                     |
| Onshore wind                  | 462                           | Operation and maintenance         | 604                               | Engineers and higher degrees            | 174                                     |
| Offshore wind                 | 49                            | Biofuel supply                    | -                                 | Marketing and administrative            | 67                                      |
| Geothermal                    | 61                            |                                   |                                   |                                         |                                         |
| Total                         | 2 079                         |                                   | 2 079                             |                                         | 2 079                                   |

| Welfare improvement (%): TES vs. PES   | 2030   | 2050   |
|----------------------------------------|--------|--------|
| Indicator                              |        |        |
| Economic                               | 0.3    | 0.6    |
| Social                                 | 4.0    | 8.4    |
| Environmental                          | 3.3    | 6.5    |
| Total                                  | 7.7    | 15.5   |

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply , Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world , www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition , International Energy Agency, Paris.

IRENA (2019a), Renewable Cost Database , 2019.

IRENA (2019b), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi. WHO (2020), Air pollution - Overview , World Health Organization, www.who.int/westernpacific/health-topics/air-pollution (accessed 6 March 2020).

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->

<!-- image -->

## GLOBAL RENEWABLES OUTLOOK

<!-- image -->

Regional analysis covers countries and territories between the Indian, Pacific and Southern Oceans.:

- • Australia
- • New Caledonia
- • French Polynesia
- • Christmas Island
- · Heard Island and McDonald Islands
- · Cocos (Keeling) Islands
- • New Zealand
- · The Federated States of Micronesia
- • Norfolk Island
- • Papua New Guinea
- • Fiji

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

2050 outlook:

Current:

0.5% of global population, mainly in Australia (60%) followed by Papua New Guinea (21%) and New Zealand (12%).

Average 0.7% per year increase to 52 million , or 0.6% of global population.

Source: IRENA analysis.

<!-- image -->

IRENA analysis based on E3ME.

*Due to data gaps, the economic analysis only includes Australia and New Zealand.

<!-- image -->

- • Solomon Islands
- • Vanuatu

<!-- image -->

## Energy consumption per capita:

## Electricity access:

## Clean cooking access:

Current: well above global average (51 GJ/year).

Only 54.4% in Papua New Guinea.

Less than 13% in Kiribati.

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019), 2050 values based on IRENA analysis.

## Fossil fuel net import

## Region produces 3.6% of global fossil fuels , with

Australia as leading coal and Liquefied Natural Gas (LNG) exporter; New Zealand's coal mines are closing; small island states import diesel for power generation.

Current status:

2050 outlook:

Enormous untapped renewable energy potential.

very low

- PES: The total generation (est. 477 TWh) just represents 1% of overall renewable power potential.

Note: Current status, IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

## Energy-intensive industries (% in global consumption)

Current status:

Concentrated mainly in Australia and New Zealand. At regional level, highest demand for non-ferrous metal and

<!-- image -->

2050 outlook:

IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

food and tobacco industries.

Need for alternative emission-free technological solutions.

Region's annual emissions: 0.45 Gt (2018).

1% of global energy-related emissions.

2050 outlook:

- PES: 36% increase to 0.61 Gt with enabling policies.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

Recent:

<!-- image -->

Mainly due to city transpor t; Light-vehicle sales set to grow with population; Ambitious plans promise to ramp up use of electric vehicles in New Zealand (IEA, 2017).

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

## Electricity price:

## Renewables cost and auctions:

The highest values for industries and the second-highest for households compared to the other regions.

In 2017, an auction for concentrated solar power (CSP) was held in the state of South Australia and 150 MW was awarded at a price of USD 0.061/kWh (IRENA, 2019a).

GLYPH&lt;28&gt;GLYPH&lt;22&gt;GLYPH&lt;21&gt;GLYPH&lt;20&gt;GLYPH&lt;19&gt;GLYPH&lt;18&gt;GLYPH&lt;17&gt;GLYPH&lt;20&gt;GLYPH&lt;17&gt;GLYPH&lt;19&gt;GLYPH&lt;16&gt;GLYPH&lt;27&gt;GLYPH&lt;15&gt;GLYPH&lt;18&gt;GLYPH&lt;17&gt;GLYPH&lt;20&gt;GLYPH&lt;21&gt;

0.23

<!-- image -->

€

GLYPH&lt;11&gt;GLYPH&lt;144&gt; GLYPH&lt;18&gt; GLYPH&lt;143&gt;

GLYPH&lt;157&gt;

GLYPH&lt;1&gt; GLYPH&lt;127&gt; GLYPH&lt;129&gt; GLYPH&lt;141&gt; GLYPH&lt;24&gt;GLYPH&lt;21&gt;GLYPH&lt;127&gt; GLYPH&lt;143&gt; GLYPH&lt;19&gt; GLYPH&lt;24&gt; GLYPH&lt;127&gt;GLYPH&lt;20&gt;GLYPH&lt;21&gt; GLYPH&lt;24&gt; GLYPH&lt;16&gt;GLYPH&lt;144&gt; GLYPH&lt;18&gt; GLYPH&lt;143&gt; GLYPH&lt;29&gt; ­ GLYPH&lt;141&gt; GLYPH&lt;21&gt; GLYPH&lt;127&gt; GLYPH&lt;16&gt;GLYPH&lt;24&gt; GLYPH&lt;7&gt;GLYPH&lt;23&gt;­GLYPH&lt;19&gt; GLYPH&lt;11&gt; GLYPH&lt;127&gt; GLYPH&lt;143&gt; GLYPH&lt;18&gt; GLYPH&lt;16&gt; GLYPH&lt;14&gt;GLYPH&lt;21&gt;GLYPH&lt;127&gt;GLYPH&lt;20&gt;GLYPH&lt;127&gt;GLYPH&lt;17&gt;GLYPH&lt;127&gt; GLYPH&lt;143&gt;GLYPH&lt;20&gt; GLYPH&lt;18&gt; GLYPH&lt;23&gt; GLYPH&lt;13&gt; Source: LCOE based on IRENA (2019b) and electricity prices based on Global Petrol Prices (2019). Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world. Small firm electricity price analysis is based only on Australia values.

GLYPH&lt;16&gt;GLYPH&lt;144&gt;

GLYPH&lt;30&gt;GLYPH&lt;29&gt;GLYPH&lt;28&gt;GLYPH&lt;27&gt; GLYPH&lt;3&gt;GLYPH&lt;20&gt;GLYPH&lt;21&gt;GLYPH&lt;27&gt;GLYPH&lt;14&gt;GLYPH&lt;24&gt;GLYPH&lt;16&gt;GLYPH&lt;13&gt;GLYPH&lt;24&gt;­GLYPH&lt;20&gt;GLYPH&lt;23&gt;GLYPH&lt;143&gt;GLYPH&lt;24&gt;

GLYPH&lt;30&gt;GLYPH&lt;29&gt;GLYPH&lt;28&gt;GLYPH&lt;27&gt;

GLYPH&lt;14&gt;GLYPH&lt;16&gt;GLYPH&lt;23&gt;GLYPH&lt;13&gt;GLYPH&lt;24&gt;GLYPH&lt;27&gt;

GLYPH&lt;30&gt;GLYPH&lt;29&gt;GLYPH&lt;28&gt;GLYPH&lt;27&gt;GLYPH&lt;3&gt;GLYPH&lt;20&gt;GLYPH&lt;21&gt;GLYPH&lt;27&gt;GLYPH&lt;14&gt;GLYPH&lt;24&gt;GLYPH&lt;16&gt;GLYPH&lt;13&gt;GLYPH&lt;24&gt;­GLYPH&lt;20&gt;GLYPH&lt;23&gt;GLYPH&lt;143&gt;GLYPH&lt;24&gt;

GLYPH&lt;26&gt;GLYPH&lt;25&gt;GLYPH&lt;24&gt;GLYPH&lt;23&gt;GLYPH&lt;22&gt;GLYPH&lt;21&gt;GLYPH&lt;20&gt;GLYPH&lt;24&gt;GLYPH&lt;19&gt;GLYPH&lt;27&gt;GLYPH&lt;18&gt;GLYPH&lt;17&gt;GLYPH&lt;24&gt;GLYPH&lt;16&gt;GLYPH&lt;18&gt;GLYPH&lt;22&gt;GLYPH&lt;24&gt;GLYPH&lt;15&gt;

GLYPH&lt;26&gt;GLYPH&lt;25&gt;GLYPH&lt;24&gt;GLYPH&lt;23&gt;GLYPH&lt;22&gt;GLYPH&lt;21&gt;GLYPH&lt;20&gt;GLYPH&lt;24&gt;GLYPH&lt;19&gt;GLYPH&lt;27&gt;GLYPH&lt;18&gt;GLYPH&lt;17&gt;GLYPH&lt;24&gt;GLYPH&lt;16&gt;GLYPH&lt;18&gt;GLYPH&lt;22&gt;GLYPH&lt;24&gt;GLYPH&lt;15&gt;

## ENERGY TRANSFORMATION: KEY BENEFITS

## AFFORDABILITY AND SUSTAINABILITY

- Diversified clean energy mix
- Lower CO2 emissions
- Lower prices
- Greater competition

<!-- image -->

2

- Increased renewable energy use
- Effective power generation
- Improved energy security
- Sustainable power to rural/remote areas
- Job creation
- Improved education and skills development
- Reduced respiratory disease and improved health

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY INDEPENDENCE AND ACCESS

## SOCIO-ECONOMIC DEVELOPMENT

<!-- image -->

1

<!-- image -->

<!-- image -->

3

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading   | Where we are heading   | Where we are heading   | Where we need to be   | Where we need to be   | Where we need to be   |
|-----------------------------------------------|-----------------------------------------------|------------------------|------------------------|------------------------|-----------------------|-----------------------|-----------------------|
| Oceania                                       | 2017                                          | 2030 (PES)             | 2040 (PES)             | 2050 (PES)             | 2030 (TES)            | 2040 (TES)            | 2050 (TES)            |
| Energy (EJ)                                   |                                               |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 7                                             | 10                     | 11                     | 12                     | 9                     | 10                    | 12                    |
| Consumption (TFEC)                            | 4                                             | 6                      | 7                      | 8                      | 6                     | 6                     | 5                     |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                        |                        |                        |                       |                       |                       |
| Supply (TPES)                                 | 10%                                           | 22%                    | 27%                    | 34%                    | 39%                   | 71%                   | 85%                   |
| Consumption (TFEC)                            | 11%                                           | 14%                    | 15%                    | 18%                    | 26%                   | 58%                   | 75%                   |
| Power generation                              | 25%                                           | 45%                    | 51%                    | 61%                    | 66%                   | 92%                   | 93%                   |
| Electricity share in final energy consumption | Electricity share in final energy consumption |                        |                        |                        |                       |                       |                       |
| End-use consumption                           | 23%                                           | 20%                    | 19%                    | 20%                    | 22%                   | 32%                   | 45%                   |
| Industry                                      | 27%                                           | 19%                    | 18%                    | 18%                    | 20%                   | 48%                   | 67%                   |
| Transport                                     | 1%                                            | 1%                     | 1%                     | 1%                     | 6%                    | 13%                   | 33%                   |
| Buildings                                     | 57%                                           | 60%                    | 60%                    | 61%                    | 64%                   | 36%                   | 34%                   |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |                        |                        |                        |                       |                       |                       |
| Bioenergy                                     | 1                                             | 1                      | 1                      | 2                      | 3                     | 2                     | 3                     |
| Hydropower                                    | 13                                            | 17                     | 14                     | 14                     | 21                    | 20                    | 22                    |
| Solar PV                                      | 6                                             | 11                     | 17                     | 27                     | 27                    | 84                    | 109                   |
| Wind                                          | 6                                             | 11                     | 18                     | 26                     | 25                    | 46                    | 65                    |
| Biofuels                                      | Biofuels                                      |                        |                        |                        |                       |                       |                       |
| Liquid biofuels (billions of litres per year) | 0.2                                           | 0.5                    | 1                      | 1                      | 3                     | 3                     | 3                     |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |                        |                        |                        |                       |                       |                       |
| Annual level (Gt CO 2 /yr)                    | 0.4                                           | 0.6                    | 0.6                    | 0.6                    | 0.4                   | 0.2                   | 0.1                   |
| Reduction vs. today                           | NA                                            | 32%                    | 38%                    | 37%                    | -8%                   | -54%                  | -73%                  |

| Oceania                                                              | Where we are heading Planned Energy Scenario 2016/thinspace-/thinspace2050 (PES)   | Where we need to be Transforming Energy Scenario 2016-2050 (TES)     |
|----------------------------------------------------------------------|------------------------------------------------------------------------------------|----------------------------------------------------------------------|
| Energy system investments (average annual, 2016-50) USD billion/year | Energy system investments (average annual, 2016-50) USD billion/year               | Energy system investments (average annual, 2016-50) USD billion/year |
| Power                                                                | 7                                                                                  | 16                                                                   |
| - Renewable                                                          | 3                                                                                  | 10                                                                   |
| - Non-renewable                                                      | 1                                                                                  | 1                                                                    |
| - Power grids and system flexibility                                 | 2                                                                                  | 4                                                                    |
| Industry (RE + EE)                                                   | 2                                                                                  | 3                                                                    |
| Transport (electrification + EE)                                     | 2                                                                                  | 5                                                                    |
| Buildings (RE + EE)                                                  | 6                                                                                  | 11                                                                   |
| Biofuel supply                                                       | 0.1                                                                                | 0.3                                                                  |
| Renewable hydrogen - electrolysers                                   | 0                                                                                  | 1.1                                                                  |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019c; 2019d) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050*

| Oceania                             | 2019e     | 2030      | 2050      |
|-------------------------------------|-----------|-----------|-----------|
| Population (thousands) region-wide  | 29 739    | 32 982    | 37 063    |
| GDP (USD 2015)                      |           |           |           |
| GDP (million): PES                  | 1 361 509 | 1 935 173 | 3 618 538 |
| GDP (million): TES                  | 1 311 801 | 1 936 844 | 3 595 574 |
| GDP changes (million): TES vs. PES  | -49 708   | 1 671     | -22 964   |
| GDP changes (%): TES vs. PES        | -3.7      | 0.1       | -0.6      |
| Per capita GDP (thousand): PES      | 45.8      | 58.7      | 97.6      |
| Per capita GDP (thousand): TES      | 44.1      | 58.7      | 97.0      |
| Employment                          |           |           |           |
| Economy-wide employment (thousands) |           |           |           |
| Employment: PES                     | 16 479    | 18 955    | 19 816    |
| Employment: TES                     | 16 471    | 19 020    | 19 923    |
| Employment changes: TES vs. PES     | -8        | 65        | 107       |
| Employment changes (%): TES vs. PES | -0.05%    | 0.34%     | 0.54%     |

- * Due to data gaps, only Australia and New Zealand are considered for the socio-economic analysis.

<!-- image -->

<!-- image -->

<!-- image -->

| Oceania                                               | 2017                                             | 2030 (PES)                                       | 2050 (PES)                                       | 2030 (TES)                                       | 2050 (TES)                                       |
|-------------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|--------------------------------------------------|
| Energy sector jobs (thousands)                        |                                                  |                                                  |                                                  |                                                  |                                                  |
| Nuclear power                                         | -                                                | -                                                | -                                                | -                                                | -                                                |
| Fossil fuels                                          | 215                                              | 266                                              | 227                                              | 240                                              | 193                                              |
| Renewables                                            | 37                                               | 54                                               | 61                                               | 116                                              | 293                                              |
| Energy efficiency                                     | 3                                                | 52                                               | 56                                               | 97                                               | 62                                               |
| Power grids and energy flexibility                    | 53                                               | 60                                               | 54                                               | 66                                               | 78                                               |
| Total                                                 | 307                                              | 432                                              | 398                                              | 519                                              | 626                                              |
| Energy jobs in economy-wide employment (%)            |                                                  | 2.3%                                             | 2.0%                                             | 2.7%                                             | 3.1%                                             |
| Renewable energy jobs (thousands)                     | Renewable energy jobs (thousands)                |                                                  |                                                  |                                                  |                                                  |
| Bioenergy                                             | 19                                               | 24                                               | 22                                               | 42                                               | 56                                               |
| Solar                                                 | 8                                                | 14                                               | 30                                               | 54                                               | 216                                              |
| Hydropower                                            | 8                                                | 9                                                | 2                                                | 9                                                | 3                                                |
| Wind                                                  | 1                                                | 4                                                | 5                                                | 9                                                | 12                                               |
| Geothermal                                            | 1                                                | 3                                                | 1                                                | 3                                                | 5                                                |
| Ocean                                                 | -                                                | -                                                | -                                                | 0                                                | 1                                                |
| Total                                                 | 37                                               | 54                                               | 61                                               | 116                                              | 293                                              |
| Renewable energy jobs in energy-sector employment (%) |                                                  | 12.5%                                            | 15.3%                                            | 22.4%                                            | 46.8%                                            |
| Job differential in 2050 (thousands) TES vs. PES      | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES | Job differential in 2050 (thousands) TES vs. PES |
| Economy-wide                                          | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | Economy-wide                                     | 107                                              |
| Changes in conventional energy (A)                    | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | Changes in conventional energy (A)               | -34                                              |
| Changes in transition related technologies (B)        | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | Changes in transition related technologies (B)   | 262                                              |
| Net energy sector jobs (A+B)                          | Net energy sector jobs (A+B)                     | Net energy sector jobs (A+B)                     | Net energy sector jobs (A+B)                     | Net energy sector jobs (A+B)                     | 228                                              |

## Jobs in 2050: TES / Oceania

| Technology jobs (thousands)          | Technology jobs (thousands)          | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|--------------------------------------|--------------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                             | 52                                   | Construction & installation       | 134                               | Workers and technicians                 | 203                                     |
| Solar water heaters (SWH)            | 159                                  | Manufacturing                     | 27                                | Experts                                 | 11                                      |
| Onshore wind                         | 11                                   | Operation and maintenance         | 67                                | Engineers and higher degrees            | 9                                       |
| Offshore wind                        | 0                                    | Biofuel supply                    | -                                 | Marketing and administrative            | 4                                       |
| Geothermal                           | 5                                    |                                   |                                   |                                         |                                         |
| Total                                | 227                                  |                                   | 227                               |                                         | 227                                     |
| Welfare improvement (%): TES vs. PES | Welfare improvement (%): TES vs. PES | 2030                              | 2030                              | 2050                                    | 2050                                    |
| Economic                             | Economic                             | 0.0                               | 0.0                               | 0.0                                     | 0.0                                     |
| Social                               | Social                               | 5.0                               | 5.0                               | 12.3                                    | 12.3                                    |
| Environmental                        | Environmental                        | 2.2                               | 2.2                               | 5.0                                     | 5.0                                     |
| Total                                | Total                                | 7.2                               | 7.2                               | 17.3                                    | 17.3                                    |

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply, Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world , www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition, International Energy Agency, Paris.

IEA (2017), Energy Policies of IEA Countries: New Zealand 2017 Review , IEA, Paris https://www.iea.org/reports/energy-policies-of-iea-countries-new-zealand-2017-review

IRENA (2019a) Renewable energy auctions: Status and trends beyond price , International Renewable Energy Agency, Abu Dhabi IRENA (2019b), Renewable Cost Database , 2019.

IRENA (2019c), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects, International Renewable Energy Agency, Abu Dhabi.

IRENA (2019d), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects, International Renewable Energy Agency, Abu Dhabi.

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION

## SUB-SAHARAN AFRICA

Regional analysis extends from the Sahel region to the continent's southernmost tip, in addition to associated island countries.

## STATUS/CHARACTERISTICS AND NEEDS:

<!-- image -->

Current:

14% of global population (end-2018), Highest regional shares in Nigeria (18%) and

Ethiopia (10%).

2050 outlook:

Average 2% per year increase to 1 947 million, or 21% of global population.

IRENA analysis based on E3ME.

<!-- image -->

IRENA analysis based on E3ME.

<!-- image -->

<!-- image -->

Energy consumption per capita:

## Electricity access:

## Clean cooking access:

Current: well below global average (51 GJ/year).

Lowest in the world, with two-thirds of region's population lacking access.

Expansion doubling annually since 2000, with about 18 million people now gaining access each year.

Growing numbers of people without access, resulting in substantial degradation of forests and indoor air pollution.

Source: Access to electricity, 2017 values (World Bank Group, 2019a), access to clean cooking, 2016 values (World Bank Group, 2019b), TFEC, 2017 values (IEA, 2019), 2050 values based on IRENA analysis.

<!-- image -->

Current status:

Holds over half the oil and gas reserves of the African continent. Bioenergy dominates the primary energy mix, accounting for 60% of primary energy demand but the share of energy supply from modern renewables is only about 10%.

2050 outlook:

Rising air pollution and resource challenges; Vast untapped renewable energy potential.

PES: The total generation (est. 975 TWh) just represents 1% of overall renewable power potential.

Note: Current status, IRENA analysis based on proportion of net imports of fossil fuels in TPES, 2017 values (IEA, 2019). 2050 outlook, IRENA analysis and potential based on Deng et al. (2015).

<!-- image -->

## Current status:

Only a tiny share (1%) of global consumption comes from the region's energy intensive industries.

2050 outlook:

IRENA analysis based on 2017 values (IEA, 2019).

<!-- image -->

Recent:

With accelerated demand growth, low carbon technologies will play a key role.

Region's annual emissions: 0.8 Gt (2018). 2% of global energy-related CO2 emissions.

2050 outlook:

PES: 23% increase to 0.97 Gt based on current policies.

Note: 2050 values based on IRENA analysis and historical data based on Global Carbon Atlas (2019).

<!-- image -->

Deteriorating urban air quality, with some cities having fine particle pollution (PM 2.5) among highest in world (dataset limited to 4 cities). Indoor biomass combustion causes thousands of premature deaths each year.

IRENA analysis based on PM 2.5 concentration, 2016 and 2017 values (WHO, 2019).

## Electricity prices and renewables costs

## Electricity price:

## Renewable cost and auctions:

Lower range for households and mid-range for industries (compared to other regions). The prices are very high compared to the average income.

Decentralised mini-grid systems attractive to reach rural/remote populations.

0

.

2

8

0

.

1

2

0

.

1

<!-- image -->

,

GLYPH&lt;143&gt;

GLYPH&lt;157&gt;

GLYPH&lt;157&gt;

GLYPH&lt;127&gt;

€

GLYPH&lt;141&gt;

…

LCOE based on IRENA (2019a) and electricity prices based on Global Petrol Prices (2019).

Note: The LCOE data is for projects commissioned in 2018. Real weighted average cost of capital (WACC) is 7.5% for OECD countries and China and 10% for the rest of the world.

## ENERGY TRANSFORMATION: KEY BENEFITS

SOCIAL AND ECONOMIC PROGRESS

- Economic growth leading to poverty alleviation
- Distributed power for isolated communities and local job creation
- Transformative health and education impacts

<!-- image -->

<!-- image -->

2

- Reduced network losses, improved financial performance
- Long-term finance for capital-intensive projects
- Robust regulatory frameworks

<!-- image -->

3

- Minimised reliance on traditional fuelwood
- Use of modern energy for productive uses

## INVESTMENTS TO BOOST ENERGY SECURITY

CLEAN AIR, LOWER EMISSIONS

- Clean cooking and electricity access

<!-- image -->

<!-- image -->

1

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## ENERGY TRANSFORMATION ROADMAP TO 2050

|                                               |                                               | Where we are heading                          | Where we are heading                          | Where we are heading                          | Where we need to be                           | Where we need to be                           | Where we need to be                           |
|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|-----------------------------------------------|
| Sub-Saharan Africa                            | 2017                                          | 2030 (PES)                                    | 2040 (PES)                                    | 2050 (PES)                                    | 2030 (TES)                                    | 2040 (TES)                                    | 2050 (TES)                                    |
| Energy (EJ)                                   |                                               |                                               |                                               |                                               |                                               |                                               |                                               |
| Supply (TPES)                                 | 25                                            | 17                                            | 19                                            | 20                                            | 13                                            | 24                                            | 35                                            |
| Consumption (TFEC)                            | 18                                            | 12                                            | 13                                            | 13                                            | 9                                             | 17                                            | 26                                            |
| Renewables shares (modern)                    | Renewables shares (modern)                    |                                               |                                               |                                               |                                               |                                               |                                               |
| Supply (TPES)                                 | 7%                                            | 24%                                           | 29%                                           | 34%                                           | 43%                                           | 75%                                           | 89%                                           |
| Consumption (TFEC)                            | 8%                                            | 22%                                           | 26%                                           | 29%                                           | 42%                                           | 72%                                           | 86%                                           |
| Power generation                              | 26%                                           | 48%                                           | 53%                                           | 51%                                           | 67%                                           | 88%                                           | 95%                                           |
| Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption | Electricity share in final energy consumption |
| End-use consumption                           | 7%                                            | 16%                                           | 20%                                           | 23%                                           | 23%                                           | 33%                                           | 48%                                           |
| Industry                                      | 26%                                           | 27%                                           | 28%                                           | 29%                                           | 31%                                           | 23%                                           | 29%                                           |
| Transport                                     | 1%                                            | 1%                                            | 1%                                            | 1%                                            | 2%                                            | 20%                                           | 47%                                           |
| Buildings                                     | 4%                                            | 26%                                           | 43%                                           | 58%                                           | 57%                                           | 78%                                           | 89%                                           |
| Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             | Renewable installed capacity (GW)             |
| Bioenergy                                     | 1                                             | 7                                             | 10                                            | 12                                            | 11                                            | 27                                            | 56                                            |
| Hydropower                                    | 27                                            | 44                                            | 72                                            | 54                                            | 55                                            | 95                                            | 108                                           |
| Solar PV                                      | 3                                             | 49                                            | 69                                            | 85                                            | 79                                            | 255                                           | 548                                           |
| Wind                                          | 3                                             | 20                                            | 28                                            | 35                                            | 33                                            | 131                                           | 314                                           |
| Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      | Biofuels                                      |
| Liquid biofuels (billions of litres per year) | 0.04                                          | 8                                             | 10                                            | 12                                            | 13                                            | 17                                            | 21                                            |
| CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               | CO 2 emissions (energy-related)               |
| Annual level (Gt CO 2 /yr)                    | 0.8                                           | 0.8                                           | 1.0                                           | 1.0                                           | 0.6                                           | 0.5                                           | 0.3                                           |
| Reduction vs. today                           | NA                                            | 6%                                            | 24%                                           | 26%                                           | -24%                                          | -35%                                          | -60%                                          |

Note: The findings presented in the table are based on IRENA's REmap (Renewable Energy Roadmap) approach which is consistent with the Paris climate targets. In addition, IRENA has also been conducting in-depth power sector analysis and long-term planning on the African continent, using a capacity expansion modelling tool that IRENA developed for 47 African countries - the SPLAT model. For more details, please visit https://irena.org/energytransition/Energy-Planning-Support/System-Planning-Test-Model

<!-- image -->

| Sub-Saharan Africa                                                   | Where we are heading Planned Energy Scenario 2016/thinspace-/thinspace2050 (PES)   | Where we need to be Transforming Energy Scenario 2016-2050 (TES)     |
|----------------------------------------------------------------------|------------------------------------------------------------------------------------|----------------------------------------------------------------------|
| Energy system investments (average annual, 2016-50) USD billion/year | Energy system investments (average annual, 2016-50) USD billion/year               | Energy system investments (average annual, 2016-50) USD billion/year |
| Power                                                                | 17                                                                                 | 56                                                                   |
| - Renewable                                                          | 7                                                                                  | 34                                                                   |
| - Non-renewable                                                      | 4                                                                                  | 4                                                                    |
| - Power grids and system flexibility                                 | 6                                                                                  | 18                                                                   |
| Industry (RE + EE)                                                   | 2                                                                                  | 10                                                                   |
| Transport (electrification + EE)                                     | 3                                                                                  | 20                                                                   |
| Buildings (RE + EE)                                                  | 13                                                                                 | 19                                                                   |
| Biofuel supply                                                       | 1                                                                                  | 3                                                                    |
| Renewable hydrogen - electrolysers                                   | 0.02                                                                               | 0.2                                                                  |

Note: RE = renewable energy; EE = energy efficiency

The findings in this report consider targets and developments as of April 2019. The wind and solar PV capacities in the Transforming Energy Scenario in 2030 in this report are slightly higher than the estimates presented in IRENA's reports (IRENA, 2019b; 2019c) which consider developments as of the third quarter of 2019.

## SOCIO-ECONOMIC OUTLOOK TO 2050

| Sub-Saharan Africa                  | 2019e     | 2030      | 2050       |
|-------------------------------------|-----------|-----------|------------|
| Population (thousands) region-wide  | 1 065761  | 1 352 421 | 1 947 326  |
| GDP (USD 2015)                      |           |           |            |
| GDP (million): PES                  | 2 562 424 | 4330057   | 12 582 520 |
| GDP (million): TES                  | 2 572 269 | 4354122   | 12 673 559 |
| GDP changes (million): TES vs. PES  | 9 846     | 24 065    | 91 039     |
| GDP changes (%): TES vs. PES        | 0.4       | 0.6       | 0.7        |
| Per capita GDP (thousand): PES      | 2.4       | 3.2       | 6.5        |
| Per capita GDP (thousand): TES      | 2.4       | 3.2       | 6.5        |
| Employment                          |           |           |            |
| Economy-wide employment (thousands) |           |           |            |
| Employment: PES                     | 280021    | 307 757   | 337 215    |
| Employment: TES                     | 279 997   | 307 688   | 337 240    |
| Employment changes: TES vs. PES     | -23       | -69       | 25         |
| Employment changes (%): TES vs. PES | -0.01%    | -0.02%    | 0.01%      |

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

| Sub-Saharan Africa                         | 2017                           | 2030 (PES)                     | 2050 (PES)                     | 2030 (TES)                     | 2050 (TES)                     |
|--------------------------------------------|--------------------------------|--------------------------------|--------------------------------|--------------------------------|--------------------------------|
| Energy sector jobs (thousands)             | Energy sector jobs (thousands) | Energy sector jobs (thousands) | Energy sector jobs (thousands) | Energy sector jobs (thousands) | Energy sector jobs (thousands) |
| Nuclear power                              | 6                              | 3                              | 3                              | 1                              | 2                              |
| Fossil fuels                               | 3 122                          | 3 060                          | 2 753                          | 2 929                          | 2 489                          |
| Renewables                                 | 306                            | 442                            | 519                            | 859                            | 2 023                          |
| Energy efficiency                          | 506                            | 758                            | 801                            | 1 217                          | 1 016                          |
| Power grids and energy flexibility         | 313                            | 462                            | 502                            | 462                            | 694                            |
| Total                                      | 4253                           | 4725                           | 4577                           | 5 468                          | 6224                           |
| Energy jobs in economy-wide employment (%) |                                | 1.5%                           | 1.4%                           | 1.8%                           | 1.8%                           |

## Renewable energy jobs (thousands)

| Bioenergy                                             | 176   | 243   | 279   | 581   | 1 270   |
|-------------------------------------------------------|-------|-------|-------|-------|---------|
| Solar                                                 | 44    | 97    | 135   | 154   | 583     |
| Hydropower                                            | 71    | 76    | 64    | 91    | 111     |
| Wind                                                  | 14    | 25    | 37    | 30    | 57      |
| Geothermal                                            | 1     | 2     | 3     | 3     | 3       |
| Ocean                                                 | 0     | 0     | 0     | 0     | 0       |
| Total                                                 | 306   | 442   | 519   | 859   | 2 023   |
| Renewable energy jobs in energy-sector employment (%) |       | 9.4%  | 11.3% | 15.7% | 32.5%   |

## Job differential in 2050 (thousands) TES vs. PES

| Economy-wide                                   | 25    |
|------------------------------------------------|-------|
| Changes in conventional energy (A)             | -265  |
| Changes in transition related technologies (B) | 1 911 |
| Net jobs (A+B)                                 | 1 647 |

## Jobs in 2050: TES / Sub-Saharan Africa

| Technology jobs (thousands)   |   Technology jobs (thousands) | Segment value chain (thousands)   | Segment value chain (thousands)   | Occupational requirements (thousands)   | Occupational requirements (thousands)   |
|-------------------------------|-------------------------------|-----------------------------------|-----------------------------------|-----------------------------------------|-----------------------------------------|
| Solar PV                      |                           257 | Construction & installation       | 380                               | Workers and technicians                 | 532                                     |
| Solar water heaters (SWH)     |                           311 | Manufacturing                     | 95                                | Experts                                 | 44                                      |
| Onshore wind                  |                            57 | Operation and maintenance         | 153                               | Engineers and higher degrees            | 39                                      |
| Offshore wind                 |                             0 | Biofuel supply                    | -                                 | Marketing and administrative            | 13                                      |
| Geothermal                    |                             3 |                                   |                                   |                                         |                                         |
| Total                         |                           628 |                                   | 628                               |                                         | 628                                     |

Welfare improvement (%):

TES vs. PES

Indicator

Economic

Social

Environmental

Total

2030

0.0

4.2

1.9

6.2

2050

0.1

9.2

4.2

13.5

## REFERENCES:

Deng, Y., Haigh, M., Pouwels, W., Ramaekers, L., Brandsma, R., Schimschar, S., Grözinger, J. &amp; de Jager, D. (2015), Quantifying a realistic, worldwide wind and solar electricity supply , Global Environmental Change 31, 239-52, https://doi.org/10.1016/j.gloenvcha.2015.01.005.

Global Carbon Atlas (2019), Global Carbon Atlas - CO2 emissions , https://doi.org/10.5194/essd-11-1675-2019.

Global Petrol Prices (2019), Electricity prices around the world , www.globalpetrolprices.com/electricity\_prices/ (accessed 5 March 2020).

IEA (2019), IEA Beyond 20/20 - 2019 edition, International Energy Agency, Paris.

IRENA (2019a), Renewable Cost Database , 2019.

IRENA (2019b), Future of solar photovoltaic - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

IRENA (2019c), Future of wind - Deployment, investment, technology, grid integration and socio-economic aspects , International Renewable Energy Agency, Abu Dhabi.

WHO (2019), WHO Global Ambient Air Quality Database (update 2018), World Health Organization, www.who.int/airpollution/data/cities/en/ (accessed 5 March 2020).

World Bank Group (2019a), Access to electricity (% of population) , World Bank Group.

World Bank Group (2019b), Access to clean fuels and technologies for cooking (% of population) , World Bank Group.

<!-- image -->

<!-- image -->