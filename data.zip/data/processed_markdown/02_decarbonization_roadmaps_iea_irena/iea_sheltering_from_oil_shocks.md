---
document_id: iea_sheltering_from_oil_shocks
title: "Sheltering from Oil Shocks: Energy Efficiency & Fuel Switching"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IEA"
year: 2024
original_file: "iea_sheltering_from_oil_shocks.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## Sheltering from Oil Shocks

Measures to reduce impacts on households and businesses

<!-- image -->

## INTERNATIONAL ENERGY AGENCY

The IEA examines the full spectrum of energy issues including oil, gas and coal supply and demand, renewable energy technologies, electricity markets, energy efficiency, access to energy, demand side management and much more. Through its work, the IEA advocates policies that will enhance the reliability, affordability and sustainability of energy in its 32 Member countries, 13 Association countries and beyond.

This publication and any map included herein are without prejudice to the status of or sovereignty over any territory, to the delimitation of international frontiers and boundaries and to the name of any territory, city or area.

Source: IEA. International Energy Agency Website: www.iea.org

## IEA M ember countries:

IEA A ssociation countries:

Australia Austria Belgium Canada Czech Republic Denmark Estonia Finland France Germany Greece Hungary Ireland Italy Japan Korea Latvia Lithuania Luxembourg Mexico Netherlands New Zealand Norway Poland Portugal Slovak Republic Spain Sweden Switzerland Republic of Türkiye United Kingdom

United States

Argentina

China

Egypt

India

Indonesia

Kenya

Morocco

Senegal

Singapore

South Africa

Thailand

Ukraine

Viet Nam

The European Commission also participates in the work of the IEA

<!-- image -->

## Summary

The conflict in the Middle East has created the largest supply disruption in the history of the global oil market , due to the near halt in shipping traffic through the Strait of Hormuz. Some 15 million barrels of crude oil and 5 million barrels of oil products typically traversed the Strait each day, equivalent to around 20% of global oil consumption. These flows have slowed to a trickle. The loss of supply is having significant  impacts  in  global  markets,  pushing  up  prices  for  crude  oil  above $100/barrel, and leading to much higher prices for some refined products - notably diesel, jet fuel and liquefied petroleum gas (LPG). Concerns are growing about the impacts of higher prices on households, businesses and the broader economy.

The resumption of transit through the Strait of Hormuz is the single most important action to return to stable oil and gas flows and reduce the strains on markets and prices. In the interim, countries around the world are taking a range of measures  to  increase  supply  and  to  reduce  the  impact  of  sharp  price  rises  on consumers. On the supply side, IEA member countries took a crucial step on 11 March by making 400 million barrels of oil from their emergency reserves available to the market, the largest stock release in IEA history. But the demand side is also a crucial part of the energy security equation.

In this report, the IEA details 10 demand-side options open to households, businesses and governments to shelter themselves from today's oil shock and  relieve  the  strains  on  affordability. These  are  based  on  the  IEA's longstanding  expertise  on  energy  security  and  on  specific  country  examples. Governments can take the lead, both by setting an example and by facilitating these actions, but many can be adopted by individuals and businesses directly. Most of these options relate to consumption of road transport fuels, but they also cover fuel use for air transport, cooking and industry.

For road transport, the key options are to:

- · Work from home where possible: Working from home can significantly reduce oil consumption from commuting. At the national level, three additional remote workdays, for those whose jobs allow for it, could cut oil consumption from cars by  2%-6%,  with  average  potential  reductions  of  around  20%  for  individual drivers.
- · Reduce speed limits on highways by at least 10 km/h : Lowering the speed limit on highways by 10 km/h can reduce an individual driver's oil consumption by 5% to 10% and overall oil use for private cars by 1% to 6%. Heavy freight trucks can save around 5% due to their already lower speeds.
- · Encourage public transport :  Shifting travel  away from private cars to public transport, such as buses and trains, can reduce national oil use for cars by 1% to 3%. Options like cycling and walking for shorter journeys can lead to further reductions.

- · Alternate  private  car  access  to  roads  in  large  cities  on  different  days : Limiting cars' access in designated zones to specific days based on their number plate could reduce traffic congestion, engine idling and fuel-intensive stop-andgo driving, with savings of 1% to 5% of national car oil use.
- · Increase  car  sharing  and  adopt  efficient  driving  practices : Carpooling increases car occupancy and relieves road congestion, reducing travel times and car usage. When combined with eco-driving measures, including checking tyre pressure, adjusting air conditioning settings, and efficient driving practices, fuel demand for cars can be reduced by around 5% to 8%.
- · Efficient driving for road commercial vehicles and delivery of goods : Ecodriving practices, including regular checks of tyre pressure, reduced idling, and reduction of braking and accelerating, combined with operational improvements, such  as  optimisation  of  vehicle  loads,  can  reduce  fuel  demand  for  road commercial vehicles by 3% to 5%.
- · Divert LPG use from transport : Around 2% of the global car fleet runs on LPG. Switching on gasoline in converted vehicles or bi-fuel ones can preserve LPG supplies for prioritised uses, such as cooking.

For air transport fuels, cooking fuels, and industry:

- · Avoid air travel where alternative options exist: A reduction of around 40% of flights taken for business purposes is feasible in the short term and, with very high  participation  in  work-related  flight  reduction  campaigns,  could  reduce  jet kerosene demand by 7% to15%.
- · Where possible, switch to other modern cooking solutions: As LPG supply becomes  increasingly  constrained,  greater  adoption  of  electric  and  other alternative  modern  cooking  solutions  could  manage  potential  cooking  fuel shortages  alongside  other  measures  to  conserve  LPG  in  other  non-essential applications.
- · Leverage flexibility with petrochemical feedstocks and implement shortterm efficiency and maintenance measures: Prioritising the processing of oil feedstocks  with  higher  volumes  available  can  release  pressure  on  other  oil products. Optimising equipment operations and maintenance can reduce oil use in individual facilities by up to 5%.

As  seen  in  2022,  governments  can  intervene  with  measures  to  help consumers with their energy bills during price spikes - but fiscal means are limited, and it is vital that measures target those most in need. Over the longer term,  the  report  also  provides  guidance  on  structural  measures  that  can  help improve energy security and limit exposure to future shocks.

The  IEA  was  founded  more  than  50  years  ago  with  a  core  mission  of upholding energy security in response to global oil shocks . The current crisis extends well beyond oil, and includes disruptions to natural gas flows, with knockon effects for electricity security and prices. The IEA continues to work closely with governments around the world as they consider and develop options for responding to the current disruption.

## Introduction and context

The conflict in the Middle East has created the largest supply disruption in the history of the global oil market. The volume of fuel supply offline now is higher than the supply loss during the oil shock of 1973 that led to the IEA's creation and any disruption since then. Beyond the direct damage to energy infrastructure in the region, the crisis has led to a near halt in tanker movements through the Strait of Hormuz. Crude and oil product flows through the Strait have fallen from around 20 million barrels per day (mb/d) before the conflict to a near standstill. With limited capacity to bypass the waterway and storage filling up, Gulf countries have cut oil production by at least 10 mb/d. In the absence of a rapid resumption of shipping flows, supply losses are set to increase.

This loss of supply is having major impacts in global oil and gas markets, with both producers and consumers feeling the strain. Oil prices have risen sharply since the conflict began. While Brent has drawn most attention, benchmarks for Middle Eastern  crudes  and  refined  products,  particularly  diesel  and  jet  fuel,  have increased even more. Many consumers around the world are still bruised from past price increases during the global energy crisis of 2021-2023, which pushed energy affordability  to  the  forefront  of  energy  policy  priorities.  A  succession  of turbulent years for the global economy and the energy sector has also depleted the fiscal means for governments to respond to a new crisis.

The resumption of transit through the Strait of Hormuz is indispensable to relieve the strains on markets and to allow for stable flows of oil and gas to international markets. In the interim, countries are taking or considering a range of measures to  mitigate  the  impacts  of  the  disruption,  whether  by  increasing  oil  supplies  or reducing demand.

On  the  supply  side,  IEA  member  countries  decided  on  11 March  to  make 400 million barrels of oil from their emergency reserves available to the market, the  largest  stock  release  in  IEA  history.  Other  short-term  options  to  increase supply,  aside  from  inventories,  are  being  explored.  They  are  quite  limited, however, as operators face constraints in terms of project cycle times, equipment availability, and takeaway capacity.

On the demand side, the products most immediately affected by the conflict are diesel, jet fuel, and LPG. Alongside its well-known role as a producer of crude oil, the  Middle  East  is  also  a  major  exporter  of  these  refined  products  and  the interruption to these flows has quickly tightened market balances. Jet fuel supplies are scarce despite the reduction in demand due to the suspension of flights at major airports across the Middle East. In addition to its use as a petrochemical feedstock, LPG is widely used as a cooking fuel.

Demand  restraint  is  one  of  the  emergency  response  measures  that  all  IEA member countries are required to have ready as a contingency - and that they can use to contribute to an IEA collective action in the event of an emergency like this  current  disruption.  Importantly,  opportunities  on  the  demand  side  are  not

limited to only IEA countries. Countries around the world need to consider how they react to today's extreme strains on oil markets.

Governments can support households and businesses to take actions to quickly reduce their oil demand and costs. In this report, the IEA offers 10 options that households, businesses, and governments across the world can pursue immediately to manage their oil demand and help shelter themselves from the oil shock.  All  10  options  can  be  implemented  quickly,  with  savings  achieved  in  a matter of weeks.

The description for each option includes estimates of the national savings possible for each  specific fuel as well as the implementation  levers available to governments and specific country examples. Not all options will apply equally to all countries, depending on their own circumstances in terms of energy markets, transport  infrastructure,  demand  for  specific  oil  products,  and  other  aspects. Nonetheless,  the  more  options  that  governments,  businesses  and  households adopt would further increase their national, regional and global impact, helping to alleviate the shock for everyone. Even if all 10 options were implemented in every country in the world, however, they would not replace the supply disrupted by the conflict. Only the resumption of transit through the Strait of Hormuz can do that.

The majority of these 10 options focus on road transport fuels, given cars and trucks' outsized influence on total oil consumption - roughly 45% globally and up to two-thirds in some regions. However, the options also consider use of oil for air transport and industry. In addition, they seek to prioritise and protect essential uses  of  LPG,  recognising  its  central  importance  as  a  cooking  fuel  in  many emerging and developing economies.

Following descriptions of the 10 options, the report outlines targeted measures governments can employ to support energy affordability, especially for their most vulnerable consumers,  and  help  offset higher expenditures for oil-related products. Finally, it identifies longer-term  structural measures  available  to governments to reduce exposure to future price shocks and volatility.

In responding to the current crisis, governments can take the lead, both through measures  they  implement  for  the  public  sector  and  through  regulations  and mandates,  complemented  by  public  information  and  awareness  campaigns. Ultimately, however, sheltering consumers from the impacts of the oil shock is not only  a  matter  for  national  governments.  Several  of  the  measures  can  be implemented directly by other layers of government - such as state, regional or local - or just voluntarily followed by households and companies, enabling them to reduce their consumption of oil and save money.

The IEA was founded more than 50 years ago with a core mission of upholding energy security in response to a global oil shock. The current crisis extends well beyond oil, and includes disruptions to natural gas flows, with knock-on effects for electricity  security  and  prices.  The  Agency  will  continue  to  work  closely  with governments  around  the  world  as  they  consider  and  develop  options  for responding to the current disruption.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

## Road transport fuels

Road transport accounts for around 45% of global oil demand, ranging from a third in  Korea  up  to  two-thirds  in  some  countries  in  Europe  and  Latin  America.  In advanced economies, passenger cars dominate road transport demand, accounting for  around  60% of road energy use. Trucks make up most of the remainder. In emerging  economies,  there  is  also  a  significant  role  for  two/three-wheelers (scooters, motorcycles and tricycles), which account for around 5% of road transport demand and are more numerous than cars in many countries. The share of energy use in medium and heavy freight trucks is also higher than in advanced economies.

There  are  several  key  actions  that  can  immediately  reduce  road  transport  fuel demand and, as a result, lower oil use.

## 1. Work from home where possible

Description : Working from home can reduce oil consumption from private vehicles used to commute. While not all jobs are suitable for working from home, it can be an effective measure when the job allows for it. In advanced economies, about onethird of jobs are suitable for remote work, while in emerging markets and developing economies,  this  figure  is  closer  to  one-fifth.  Working  from  home  affects  oil consumption  differently  across  regions,  depending  on  commute  distance,  car occupancy and average fuel consumption of the car. In most countries the impact is felt mainly on gasoline demand; however, in countries and regions such as Korea, India, and Europe, diesel use is also affected. The effects of working from home also vary by season, largely because of how air conditioning is used in cars. As a result, remote work helps conserve more oil during the warmer months.

Impact :  Commuting  accounts  for  between  5%  and  30%  of  car  activity  across regions. As not all jobs are suitable for working from home, at the national level, three additional remote working days, for those whose jobs allow for it, could reduce oil consumption from cars by 2%-6%. If an average individual driver shifts from no teleworking  to  three  remote  days  in  a  five-day  workweek,  their  personal  car  oil consumption could be reduced by up to 20%.

How can governments enable this : governments can encourage businesses to allow their employees to work from home, and can mandate public officials to work from home, where possible, and close public buildings on certain days.

Policy  examples :  In  response  to  the  2026  crisis  in  the  Middle  East,  several countries  have  announced  measures  to  encourage  working  from  home.  For example,  the  Philippines  and  Pakistan  have  mandated  4-day  workweeks  for government workers, while Sri Lanka has closed public offices on Wednesdays, and Lao PDR, Thailand and Viet Nam are all actively promoting remote work. Many European governments also encouraged working from home in response to the energy  crisis  in  2022-23,  including  through  the  joint  IEA-EU  Playing  my  Part Campaign. For example, France incentivised public officials working from home in 2022, and encouraged private companies to follow this example.

## 2. Reduce speed limits on highways by at least 10 km/h

Description : Lowering the speed limit on highways can reduce oil consumption for passenger cars, light commercial vehicles and trucks. Countries have different speed limits in place across the world, but these typically range from 100 km/h to 130 km/h.

Impact :  Reducing  its  speed  on  the  highway  by  10  km/h  can  cut  an  individual driver's oil use by 5% to 10%. Such speed limit reductions may decrease national oil use for private cars by 1% to 6%, depending on local infrastructure and driving habits. Heavy freight trucks save less fuel from a 10 km/h speed reduction due to their  already  lower  speeds,  but  because  they  use  highways  much  more  on average, each heavy freight truck can still cut oil use by around 5% when applying such a measure. This measure affecting heavy trucks primarily reduces diesel demand, as heavy trucks run mainly on diesel. It also lowers gasoline demand, since it affects passenger cars and light commercial vehicles, where around 85% of oil use is gasoline. In some markets, such as Korea, India, and Europe, the reduction in energy use from cars will have a noticeable impact on diesel demand due to the significant share of diesel-powered cars in the overall fleet.

How governments can enable this : Governments can mandate a reduction in speed limits by law or launch an information campaign asking drivers to voluntarily lower their speed. They can also use electronic signs to indicate the requested speed limit. Ahead of a nation-wide policy, governments can start by asking all public  workers  to  voluntarily  lower  their  maximum  speed  on  highways  and motorways by 10 km/h.

Policy examples :  This is a tried-and-tested policy response in many countries. Already during the first oil crisis in 1973, the French government decreased speed limits  to  90  km/h  on  overland  roads  and  120  km/h  on  motorways.  France encouraged reducing driving speed again in response to the 2022 energy crisis. Since the start of the 2026 crisis in the Middle East, Pakistan has reduced speed limits on motorways and national highways. On motorways, the limit for light-duty vehicles  has  been  reduced  from  120  km/h  to  100  km/h,  and  for  heavy-duty vehicles from 110 km/h to 90 km/h. On national highways, the limit for light-duty vehicles was reduced from 100 km/h to 80km/h, and for heavy-duty vehicles from 80km/h to 65 km/h. The government also launched an awareness campaign to ensure effective implementation and to inform commuters.

## 3. Encourage public transport

Description :  Shifting travel away from private cars to public transport, such as buses and trains, can reduce oil demand. Most public transport vehicles rely on electricity rather than liquid fuels, but even where they consume oil they are much more efficient modes of transport. Walking and cycling can further reduce car trips, where practical.

Impact : In some countries, short trips of less than 30 km within large cities can account  for  up  to  50%  of  oil  consumption  by  private  vehicles.  Depending  on infrastructure, encouraging public transportation could reduce national oil use for cars by 1% to 3%. This measure reduces gasoline demand in most countries, while in regions where diesel-powered cars make up a noticeable share of the car fleet - such as Korea, India, and Europe - it also has a noticeable impact on diesel consumption.

How  governments can enable this : In places where public transport infrastructure already exists, governments can reduce fares or make transport free for residents to incentivise a shift away from private cars. Care should be taken to ensure  such  supports  are  targeted  towards more  vulnerable  populations. Governments can also encourage public servants to prioritise public transport for commuting.

Policy examples : In response to the crisis in the Middle East, several countries are encouraging users to prioritise public transport. In Lao PDR, the Ministry of Public Works and Transport is studying ways to connect the Bus Rapid Transit system  with  train stations and  airports to improve  access.  Similarly, the government of Bangladesh has asked citizens to use public transport instead of private vehicles to conserve fuel. Several governments also implemented public transport measures in response to higher energy prices in 2022, such as reduced or zero-fare public transport schemes. Luxembourg has had free public transport since 2020 and Malta became fare free for all residents in 2022. Other countries implemented short-term measures, such as Germany's 9-euro ticket, which gave access to use all local transport and regional trains for a month. New Zealand's government halved public transport fares in March 2022 as a response to rising oil prices.

## 4. Alternate private car access to roads in large cities on different days

Description : Private vehicles are allowed into designated zones in large cities on specific  days  only  based  on  their  number  plate.  Vehicles  with  odd-numbered plates have access on different weekdays than those with even-numbered plates. This  measure reduces traffic congestion, engine idling and fuel-intensive stopand-go driving. It also reduces local air pollution and improves attractiveness of the city centre for the use of bicycles or walking.

Impact : Preventing half the car stock from circulating in cities for two days a week would save 1% to 5% of national car oil use. Like the previous measures, the impact is  stronger  on  gasoline,  except  in  countries  where  diesel-powered  cars make up a significant share of the car fleet.

How governments can enable this : Governments can designate specific zones with alternating traffic restrictions. Cars can be assigned to certain weekdays or dates based on their number plates. For example, even-numbered plates on some weekdays and odd-numbered plates on the other weekdays. Exceptions can be made for cars with many occupants, as well as taxis. Governments can refrain from granting exemptions to non-essential government fleet vehicles.

Policy examples : In response to the 2026 crisis in the Middle East, the Korean government  is  considering  putting  in  place  a  5-day  or  10-day  vehicle  rotation system, meaning each vehicle would be prohibited from use for one day every five or ten days. Looking further back, the measure has been used for a long time in many cities globally. During the first oil shock in 1973, the Italian government first introduced  car  free  Sundays  and  then  an  odd/even  number  plate  policy  on Sundays.  Since  then,  some  large  cities,  such  as  Beijing  and  São  Paulo, implemented  this measure  permanently,  while temporary schemes  during pollution or rush hour peaks were implemented in New Delhi, Jakarta and Manila. In recent years, many countries have had initiatives such as car-free Sundays in cities.

## 5. Increase car sharing and adopt efficient driving practices

Description :  Individual choices on driving styles, car sharing, and temperature settings can influence fuel consumption. People can choose to share a ride to reduce oil demand and save on other costs such as tolls. Carpooling contributes to oil demand  reduction  by  increasing  car  occupancy  and  relieving  road congestion,  thus  reducing  travel  times.  Efficient  driving  practices  such  as smoother acceleration, tyre pressure monitoring and higher vehicle air conditioning set points can increase fuel savings further.

Impact : Carpooling can reduce oil demand because it allows the same amount of energy to meet a greater share of mobility needs. Reducing car usage in rural areas, for instance, can potentially lower national car oil consumption by up to 4%. Adopting  eco-driving  measures  can  double  the  savings  in  most  regions,  while higher air-conditioning set-points mostly affects hot climate countries. Combining all these measures together: carpooling for rural trips, air conditioning measures, and eco-driving could lead to a reduction of car oil demand by around 5% to 8%. The impact is greater on gasoline, except in countries where diesel-powered cars constitute a significant portion of the fleet.

How  governments  can  enable  this :  Governments  can  designate  dedicated traffic  lanes,  dedicated  parking  spots,  reduced  road  tolls  for  higher  occupancy vehicles, and support the  use of ride-sharing apps. Information campaigns on eco-driving techniques, and on the impact of air-conditions on fuel consumption can prompt more drivers to change their driving behaviours.

Policy examples : Several countries and cities already promote car sharing and eco-driving to reduce fuel consumption. Carpool lanes have been implemented in various  urban  areas  to  incentivise  shared  travel,  such  as  Madrid,  Houston, Shenzhen and Los Angeles, among others, where exclusive lanes can be used by cars with more than two occupants. In response to the energy crisis in 2022, France  encouraged  citizens  to  adopt  more  economical  driving  habits,  and accelerated the deployment of eco-driving trainings. The Japanese government has  issued  recommendations  for  eco-driving,  including  gentle  acceleration, reduction  of  idling  and  reduced  use  of  car  air  conditioning.  The  measures  are actively promoted in cooperation programmes with ASEAN countries.

## 6. Efficient driving for road commercial vehicles and delivery of goods

Description :  Road  commercial vehicles are major consumers of diesel, an oil product strongly affected by the current crisis. Their fuel efficiency and mode of operation  can  significantly  impact  oil  use.  Measures  range  from  the  efficient operation of vehicles, including regular checks of tyre pressure, reduced idling and reduction  of  braking  and  accelerating,  to  operational  improvements  such  as optimisation  of  vehicle  loads  and  a  reduction  of  empty  travel  journeys.  Digital technologies can facilitate reaching these goals.

Impact :  If  the  information  campaigns  are  successful  and  there  is  widespread adoption by drivers, eco-driving practices could reduce national oil use for road freight by up to 4%. This measure in combination with an optimisation of delivery options (i.e. increasing load factors) could reduce their national oil demand by 3% to 5%, mainly reducing diesel demand.

How  governments  can  enable  this :  Governments  can  introduce  eco-driving techniques as part of the examinations to receive a driving licence. In the short term, they can offer information material to logistics companies or recommend driver scorecards that can set up a competition for most economic driving style within a company. Governments often operate their own vehicle fleets and can introduce training for eco-driving techniques and put special emphasis on vehicle maintenance, such as tyre pressure.

Policy examples : The UN Economic Commission for Europe Partnership on EcoDriving has published guidelines for local eco-driving initiatives. Private and public initiatives such as the AddSecure Eco-Driving Challenge have demonstrated fuel savings potential of eco-driving techniques. Peru has made regulatory changes to include  eco-driving  in  the  training  curriculum  as  a  requirement  for  a  driver's license. Under the Giro Limpio programme, Chile has implemented free efficient driving trainings and certifications for professional drivers.

## 7. Divert LPG use from transport

Description :  Given the current shortage of LPG for cooking in certain regions, governments could support a reduction in LPG used in transport. Around 2% of the global car fleet runs on LPG, with that proportion in some countries, such as Italy  and  Korea,  reaching  up  to  10%.  These  vehicles  are  either  retrofitted (converted from gasoline vehicles using LPG kits) or factory-built bi-fuel models capable of running on both gasoline and LPG, and Mono-fuel LPG vehicles are limited in number. Therefore, LPG consumption can be reduced with very limited operational consequences for drivers.

Impact: A temporary shift away from LPG use in road vehicles could divert almost all  LPG road consumption in most countries, or 20% to 30% in a few markets where mono-fuel LPG vehicles are present. This could lead to a rise of global gasoline demand of around 2%, with some countries - particularly in Europe, such as in the Balkans, experiencing a noticeable increase in national road gasoline consumption.

How governments can enable this : Most LPG usage is driven by its favourable price  relative  to  gasoline.  By  adjusting  taxation,  governments  can  temporarily encourage drivers to choose the gasoline option instead of LPG, particularly in converted vehicles or bi-fuel ones.

Policy examples :  Currently, most countries maintain low excise taxes on LPG compared to gasoline due to lower CO  and local air pollutant emissions, and in ₂ some cases even subsidise LPG conversions. Historically, there are few, if any, examples of policies that have led to a reverse trend favouring gasoline over LPG. However,  under  the  specific  circumstances  today,  such  measures  could  be considered to influence fuel choice.

## Air transport fuels

Jet fuel demand accounts for around 7% of global oil demand. Jet fuel markets look to be particularly vulnerable to an extended loss of Middle East production and exports, given limited flexibility elsewhere to increase output.

## 8. Avoid air travel where alternative options exist

Description : Travel for work accounts for a large share (between 20% and 40%) of aviation activity. In many cases, travel for work can be temporarily substituted by virtual meetings. A reduction of around 40% of flights taken for work purposes is feasible in the short term, while maintaining productivity.

Impact : Very high voluntary participation to work-related flight reduction campaigns could yield reductions in jet kerosene demand by between 7% and 15%.

How  governments  can  enable  this :  Governments  can  launch  campaigns  to encourage companies to limit air travel for work whenever possible. Governments lead by example by limiting air travel for public officials and encouraging more meetings to take place virtually.

Policy  examples :  In  response  to  the  2026  crisis  in  the  Middle  East,  several governments have limited travel for work by public officials. For example, Thailand has  suspended overseas trips  for  government  agencies  and  state  enterprises, while Egypt, Pakistan and Viet Nam have all announced measures to limit public official travel.

## Cooking fuels

LPG demand accounts for around 10% of global oil demand and is used by many households for cooking. The conflict has caused major disruptions to LPG supply chains. With natural gas processing operations halted in parts of the region and flows through the Strait of Hormuz having come to a standstill, LPG supplies for cooking use have been severely curtailed, both locally and at export destinations. Next to measures to free up LPG capacity from other uses, such as in transport or industry, to prioritise domestic use, there are also actions to directly reduce cooking fuel demand.

## 9. Where possible, switch to other modern cooking solutions

Description : Constrained  LPG  supply  could  have  significant  implications  for households  that  rely  on  this  fuel  for  cooking.  LPG  is  the  main  fuel  used  for  a fundamental service like cooking by 2.3 billion people in Asia. Some households own multiple modern cooking technologies, like LPG or electric stoves, and others could afford those with incentives. Targeted campaigns could help users switch to other modern cooking alternatives and reduce reliance on LPG. This could mitigate the risk of fuel shortages, which could pose significant challenges in households with limited ability to switch to alternative fuels and could also face rapidly rising prices for other cooking fuels, especially in urban areas. In many rural areas, rising fuel prices are already driving some households to revert to charcoal and wood, undermining longer-term objectives to extend universal access to clean cooking. This  has  implications  for  air  quality  and  health.  Using  biomass  as  a  traditional cooking fuel is associated with around 2.5 million premature deaths globally each year.

Impact : In the 20 countries that make up over 90% of LPG use for cooking, between 5% and 15% of households relying on LPG already have access to an alternative modern  cooking  solution  and  could  be  encouraged  to  prioritise  its  use.  For households that rely exclusively on LPG for cooking, facilitating access to alternative modern cooking solutions, such as electric stoves or electric pans, could further reduce  demand,  subject  to  available  equipment  stocks  and  grid  capacity.  For around  half  of  these  households,  a  basic  alternative  would  be  less  than  5%  of monthly  income,  and  targeted  incentives  can  improve  the  affordability,  provided supply chains can accommodate the increased demand.

How  governments  can  enable  this : Governments  can  encourage  those households to use their electric devices more when they own it or support greater electric appliances adoption with targeted incentives for lower-income families. Any incentive scheme should prioritise those with limited resources, and consideration should also be given to the availability of appliance stocks and grid capacity.

Policy  examples :  Indonesia  is  accelerating  the  conversion  of  LPG  to  induction stoves to  reduce fuel  imports  and  subsidy  burdens.  In  India,  the  government  of Andhra Pradesh, for example, is equipping local community centres with induction stoves, deploying over 44 000 units amid LPG supply concerns.

## Oil use in industry

Industry accounts for around 20% of global oil demand. Two-thirds of industrial oil demand is used as feedstock in the chemicals industry. There are options that can bring down oil demand in industry, and some flexibility on which oil products are used as petrochemical feedstocks.

## 10. Leverage flexibility with petrochemical feedstocks and implement short-term efficiency and maintenance measures

Description :  The majority of petrochemical production capacity in Asia and the European Union can technically switch between different oil products - such as LPG, naphtha,  ethane  or  gasoil  -  as  a  feedstock  without  requiring  equipment modifications. Prioritising the processing of oil feedstocks that are more available could help release pressure on the others. Meanwhile, industrial oil-consuming facilities can save additional fuel in the short-term through maintenance checks and optimising how equipment is operated. Measures vary by site but typically include  shutting  down  equipment  when  not  in  use,  reducing  temperature  and pressure setpoints to only what is necessary, fixing leaks and maintenance issues, and improving scheduling so processes run more efficiently.

Impact :  The  degree  of  flexibility  in  petrochemical  production  and  the  level  of stocks varies largely across regions. Most of the flexible chemical facilities are concentrated  in  Asia  and  Europe.  With  quick  maintenance  checks,  individual industrial facilities can often reduce overall oil use in their processes by up to 5% in the short-term.

How  governments  can  enable  this :  Governments  can  encourage  industrial facilities to replace LPG with other oil products to prioritise LPG for essential uses. They  can  set  up  incentives  to  compensate  for  the  change  in  production  mix occurred by the change of oil product feedstock. Governments can also provide guidance, and sector-specific benchmarks to help facilities make quick savings. A walk-through of a facility with operational staff, combined with the use of energy management  information  systems,  is  often  the  first  step  to  identify  these opportunities.

Policy  examples :  There  is  experience  dating  back  to  the  1970s  on  how  to encourage  urgent  energy  savings  in  industry.  Japan  promoted  quick  energy management, such as cleaning, measuring, and minor repairs, while the United Kingdom recommended operational improvements, maintenance and monitoring. Meanwhile,  the  United  States  created  Industrial  Assessment  Centers  to  help manufacturers  cut  back  on  energy  costs  through  free  energy  audits. More recently, in 2022, the European Union's REPowerEU Plan pushed to accelerate the adoption of efficiency measures in industry.

## Targeted consumer support to enhance energy affordability

Many governments around the world are reacting quickly to protect consumers from increasing fuel prices. In the days following the conflict in the Middle East, the IEA has  tracked  announcements  from  around  40  countries  that  are  deploying  or considering  deploying  emergency  measures  to  shelter  consumers  from  price increases. Immediate government responses have been to implement price caps, fuel subsidies and shifts in taxation, along with price stabilisation mechanisms that can quickly set limits on consumer price increases.

Previous  crises,  including  the  Covid-19  pandemic  and  the  2022  energy  crisis, demonstrated that impacts often fall disproportionately on the poorer segments of the population. On top of this general effect, consumers and small businesses in remote and Island territories are often very exposed to increases in oil prices. Even in normal times, electricity generation on islands can cost 10 times more than on mainland territories  where  they  are  often  dependent  on  diesel  generators.  As  a response to this issue, Barbados, for example, has locked in the price of heavy fuel oil which powers electricity generation, at USD 92 per barrel for the three months, starting from April 2026.

Experience from previous events can guide measures today. Between early 2022 and April 2023, governments had spent around USD 900 billion in direct grants, vouchers, tax reductions and price regulations, often resulting in additional costs to compensate energy companies for operating losses. Blanket measures such as price caps and energy tax reductions were widely used as they are relatively easy to administer and can alleviate pressure quickly. However, they can also represent high costs to government and be challenging to phase-out.

Designing  emergency  support  mechanisms  that  are  temporary  and  targeted towards consumers that most need assistance can ensure that government support is  deployed both quickly and efficiently in times of crisis. Investing in short-term measures  to  promote  energy  efficiency  and  demand  restraint  can  also  help  to quickly lower energy bills in cost-efficient ways. Some examples of mechanisms that have been used widely follow, with a specific attention to measures that target low-income and vulnerable households.

## Supporting consumers by reducing the pressure of high prices

Governments can support low-income households by reducing their energy costs or  giving  them  money  to  help  pay  for  energy.  Unlike  universal  subsidies  which benefit everyone, targeted programmes focus only on vulnerable or eligible groups making assistance more efficient and reducing government spending.

In response to the crisis in the Middle East, the United Kingdom has announced an allocation  of  GBP  53  million  to  support  vulnerable  heating  oil  customers  and  is committed to ensuring help reaches those who need it most. In 2022, learning from the Covid-19 crisis where universal payments led to increased energy consumption, Japan  made  targeted  cash  payments  to  16  million  low-income  households  to compensate them for rising electricity, gas and fuel costs. The Philippines recently launched a nationwide programme providing a PHP 5 000 cash subsidy (about USD 80) to public utility vehicle drivers starting with 139 000 tricycle drivers to help them cope with surging fuel prices. During the Covid-19 crisis, Pakistan delivered a cash transfer to low-income households including fuel support for low-income earners. In response to the current crisis, Pakistan is considering putting in place the same programme  as  a  relief  package  for  registered  recipients,  specifically  targeting motorcycle and rickshaw owners who rely on fuel for their daily income.

Additionally, governments can also set a maximum price that energy suppliers can charge consumers for energy. Such caps are intended to protect households and businesses from high  energy  prices,  especially  during  times  of  market  volatility. While not specifically targeted, price caps can provide immediate relief for lowerincome households who spend a higher share of their income on energy and ensure that they can still meet basic consumption needs. However, untargeted price caps can be costly and might reduce incentives for consumers to reduce their long-term energy demand.

## Adjusting household energy bills through taxation and tariffs

Governments can play a determining role in how energy related taxes and levies are distributed among utilities, industry and households. These policy choices can have  a  significant  impact  on  the  energy  price  for  end  users  and  can  also  be leveraged  in  times  of  crisis  to  provide  bill  relief  for  households.  For  example, governments can eliminate or reduce taxes (such as sales tax, VAT, import duties, or  excise  duties)  on  energy  bills  to  lower  costs  for  households.  Targeting  tax reductions on products that use less energy than standard versions is also a lever to reduce household energy bills. Governments can also design tariff bands that determine price thresholds by income brackets, to offer lower prices for those who consume less to ensure that they can meet minimum energy needs.

In response to the current crisis in the Middle East, Austria has announced that it will  return  extra tax  revenue from higher fuel prices to consumers by cutting the petrol tax, starting with a reduction of 5 euro cents per litre. Meanwhile, Türkiye has introduced a temporary fuel tax adjustment mechanism that offsets up to 75% of oil -price  increases  by  reducing  the  Special  Consumption  Tax,  aiming  to  protect consumers from rising pump prices. In 2022, Finland increased the tax reduction workers could claim for their commuting costs. This helped target benefits toward

daily commuters. In 2002, Brazil implemented a social tariff banding programme which  offered  progressive  subsidies  for  low-income  households  based  on  their consumption, starting with a 65% reduction for households consuming less than 30kWh. In 2025, this was reformed to provide 60 million low-income Brazilians a full subsidy for the first 80 kWh consumed.

## Combining these immediate actions with structural measures can help energy security and affordability in the longer term

Reducing  oil  consumption  in  the  short  term  can  help  shield  households  and businesses from high prices. Combining those immediate actions with longer-term, structural measures to lower oil use can enhance energy security and affordability. Governments have the required tools to make households and businesses more resilient against potential oil price shocks. Key actions include:

- · Reinforce the adoption of electric and more efficient vehicles and accelerate the installation of EV charging infrastructure: EVs now account for over 1 in 4 cars sold worldwide. Promoting EVs, hybrids, and other fuel-efficient vehicles - not just cars, but also two-wheelers,  buses,  and  trucks  -  alongside  expanded  charging infrastructure can help reduce global reliance on oil. Governments can accelerate adoption  through  tax  incentives, subsidies, low-emission  zones,  and  other supportive policies. Some countries have recently stepped up electrification efforts amid the current crisis: Indonesia is aiming to convert its two-wheeler fleet through targeted programmes, while Lao PDR is investing in EV charging and exploring further  measures.  Meanwhile,  integrating  EV  incentives  into  broader  industrial strategies  can  amplify  their  impact.  Brazil's  Green  Mobility  and  Innovation Programme illustrates this by combining fuel economy standards with incentives for domestic EV production.
- · Raise the ambition of fuel economy standards for road vehicles: While EV sales are growing, most vehicles on the road worldwide still rely on internal combustion engines. Many countries have set fuel economy standards to ensure new vehicles align with fuel efficiency and electrification targets. Today, most new cars sold are covered  by  such  standards.  Similarly,  improving  the  fuel  efficiency  of  trucks  is critical, especially  in  fast-growing  transport  sectors  in  emerging  economies. Notable policy examples include the EU's CO  standards for cars and heavy-duty ₂ vehicles, Japan's fuel efficiency standards for trucks and buses, and China's fuel consumption  limits  tied  to  vehicle  weight.  Other  countries  like  France  have expanded their use of weight-based road taxes with differentiated rates for ICEs and EVs. Complementary measures such as labelling can also have an impact.
- · Accelerate  the  deployment  of  alternative  modern  cooking  solutions:  LPG  has provided  a  key  avenue  in  many  countries  to  replace  traditional  biomass  and kerosene  stoves  for  cooking,  but  electricity  and  other  energy  sources  provide alternatives. Governments and organisations can support this transition through a range  of  measures,  such  as  providing  subsidies,  offering  microfinance  for

household  purchases,  or  coordinating  bulk  procurement  programmes  to  lower costs.  For  example,  Indonesia  is  supporting  households  adopt  electric  cooking equipment by setting ambitious targets, carrying out pilot projects and distributing units to households with reliable electricity connections currently using LPG.

- · Accelerate the deployment of energy management systems in industry: Energy management - the  proactive  and  systematic  monitoring,  analysis,  control,  and optimisation of energy - has been shown to deliver more than 10% energy savings on average within the first three years of implementation in industrial companies. A growing number of companies are demonstrating even larger savings of 30% or more, with many of the measures at low or no cost. Governments can encourage the adoption of energy management systems in industry by providing incentives, technical  support,  and  recognition  programmes  for  companies  implementing standards such as ISO 50001, which help monitor, optimise, and reduce energy use. For example, Japan combined incentives to implement energy management with  benchmarking  systems.  Meanwhile,  France  provides  tailored  information, incentives,  and  support  for  small  and  medium-sized  companies  seeking  to implement energy management practices.
- · Accelerate the replacement of oil heating systems and industrial boilers with heat pumps: Many countries still rely on oil for their residential space and water heating, and oil products are used for low-temperature heat in industry. Electrifying these end-uses with high efficiency heat pumps, combined with retrofits, can help reduce oil  demand.  Policy  examples  include  Canada's  Oil  to  Heat  Pump  Affordability Program, which provides upfront grants to low and median income households to help replace heating oil with heat pumps. In Finland, homeowners can replace their oil heating systems and obtain a grant of up to EUR 4 000 if installing a heat pump. In New England, a region where heating oil is still widely used, the New England Heat Pump Accelerator aims to support the installation of 580 000 units through targeted incentives.
- · Increase plastic waste collection, re-use and recycling: Many plastic products are single  use,  some  for  essential  purposes,  such  as  medical  supplies,  and  others mainly  for  convenience,  like  bottles,  cutlery,  and  food  containers.  Measures  to reduce their use have a modest impact on oil demand in the short term but can help  pave  the  way  for  larger  reductions.  Existing  recycling  facilities  can  be optimised to increase recycling rates, supported by improved waste management infrastructure.  Meanwhile,  collection  and  recycling  rates  can  also  be  gradually increased, alongside improvements in processing yield and material substitution.
- · Scale up the supply of sustainable fuels: The availability of sustainable feedstocks remains a constraint on how much biofuel production can expand. Even so, there is scope to increase output by making greater use of waste cooking oil, animal fats, and other non-food sources. Meanwhile, synthetic fuels, such as hydrogen and ammonia,  are  unlikely  to  significantly  reduce  oil  use  in  the  near  term,  but accelerating research, development, and demonstration will be important to help diversify future energy supply. Sustainable fuels can play a role in both transport and  industry,  particularly  in  applications  that  are  difficult  to  electrify,  such  as aviation, shipping, and high-temperature industrial processes.

## International Energy Agency (IEA)

This work reflects the views of the IEA Secretariat but does not necessarily reflect those of the IEA's individual M ember countries or of any particular funder or collaborator. The work does not constitute professional advice on any specific issue or situation. The IEA makes no representation or warranty, express or implied, in respect of the work's contents (including its completeness or accuracy) and shall not be responsible for any use of, or reliance on, the work.

<!-- image -->

Subject to the IEA's work is licenced under International Licence.

<!-- image -->

Unless otherwise indicated, all material presented in figures and tables is derived from IEA data and analysis.

IEA Publications International Energy Agency Website: www.iea.org Contact information: www.iea.org/contact

Typeset in France by IEA - March 2026 Cover design: IEA Photo credits: © ShutterStock

<!-- image -->