---
document_id: irena_green_hydrogen_cost_2020
title: "Green Hydrogen Cost Reduction: Scaling up Electrolysers to Meet the 1.5°C Climate Goal"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "IRENA"
year: 2020
original_file: "irena_green_hydrogen_cost_reduction_2020.pdf"
tables_detected: 67
converted_with: "Docling v2.32 (TableFormer)"
---

H 2

<!-- image -->

## GREEN HYDROGEN COST REDUCTION

SCALING UP ELECTROLYSERS

TO MEET THE 1.5°C CLIMATE GOAL

O2

2

GREEN  HYDROGEN

COST REDUCTION

## © IRENA 2020

Unless otherwise stated, material in this publication may be freely used, shared, copied, reproduced, printed and/or stored, provided that appropriate acknowledgement is given of IRENA as the source and copyright holder. Material in this publication that is attributed to third parties may be subject to separate terms of use and restrictions, and appropriate permissions from these third parties may need to be secured before any use of such material.

## ISBN: 978-92-9260-295-6

Citation: IRENA (2020), Green Hydrogen Cost Reduction: Scaling up Electrolysers to Meet the 1.50C Climate Goal , International Renewable Energy Agency, Abu Dhabi.

## Acknowledgements

This report benefited from input and review of the following experts: Katherine Ayers and Egil Rasten (NEL), Karan Bagga (ThyssenKrupp), Bart Biebuyck and Mirela Atanasiu (FCH JU), Luigi Crema and Martina Trini (Bruno Kessler Foundation), Tim Karlsson (IPHE), Ruud Kempener (European Commission), Francesco Massari (XBEC), Corky Mittelsteadt (Giner ELX), Samir Rachidi (IRESEN), Jan-Justus Schmidt (Enapter), Toshiyuki Shirai (METI/Japan), Andrew Smeltz (Denora), Denis Thomas (Cummins-Hydrogenics), Kasper Tipsmark (Green Hydrogen Systems), Eveline Weidner (EU JRC) and Frank Wouters (EU-GCC clean energy council). Emanuele Bianco, Paul Durrant, Barbara Jinks, Seungwoo Kang, Paul Komor and Stephanie Weckend (IRENA) also provided valuable inputs.

The report was edited by Jonathan Gorvett.

Authors: Emanuele  Taibi,  Herib  Blanco  and  Raul  Miranda  (IRENA)  and  Marcelo  Carmo  (Forschungszentrum  Jülich). The study was supervised by Dolf Gielen and Roland Roesch (IRENA).

Report available online: www.irena.org/publications

For questions or to provide feedback: publications@irena.org

IRENA is grateful for the support of the German Federal Ministry for Economic Affairs and Energy (BMWI) of the Federal Republic of Germany and the Ministry of Economy, Trade and Industry (METI) of Japan in producing this publication.

## Disclaimer

This publication and the material herein are provided 'as is'. All reasonable precautions have been taken by IRENA to verify the reliability of the material in this publication. However, neither IRENA nor any of its officials, agents, data or other thirdparty content providers provides a warranty of any kind, either expressed or implied, and they accept no responsibility or liability for any consequence of use of the publication or material herein.

The information contained herein does not necessarily represent the views of all Members of IRENA. The mention of specific companies or certain projects or products does not imply that they are endorsed or recommended by IRENA in preference to others of a similar nature that are not mentioned. The designations employed and the presentation of material herein do not imply the expression of any opinion on the part of IRENA concerning the legal status of any region, country, territory, city or area or of its authorities, or concerning the delimitation of frontiers or boundaries.

## FOREWORD

While  2020  may  be  remembered  for  the  tragic  COVID-19  crisis,  it  has  also been an unprecedented year for the global energy transition and the growing momentum of hydrogen technology. Many countries, in aligning their pandemic response  with  longer-term  goals,  have  announced  strategies  to  develop hydrogen as a key energy carrier. In parallel, numerous countries, cities and companies have adopted net-zero targets for energy-related carbon dioxide (CO ) emissions, bringing the need for hydrogen to the forefront. 2

But  not  all  types  of  hydrogen  are  compatible  with  sustainable,  climatesafe  energy  use  or  net-zero  emissions.  Only  'green'  hydrogen  -  produced with  electricity  from  renewable  sources  -  fulfils  these  criteria,  which  also entail   avoiding 'grey' and hybrid 'blue' hydrogen. Green hydrogen forms a cornerstone of the shift away from fossil fuels. Its uptake will be essential for sectors like aviation, international shipping and heavy industry, where energy intensity is high and emissions are hardest to abate.

Green hydrogen, however, cannot take off without widespread and co-ordinated  support  across  the  value  chain.  The  Collaborative  Framework on  Green  Hydrogen,  set  up  by  the  International  Renewable  Energy  Agency (IRENA) in mid-2020, offers a platform to strengthen support in co-operation with  IRENA's  member  countries  and  partners.  IRENA  studies  in  2018-19 highlighted the technical and economic feasibility, while a recent policy-making guide outlines key enabling policies for green hydrogen. Business models, for their part, require careful consideration.

The  present  study,  Green  hydrogen  cost  reduction,  adds  a  vital  strategic building  block,  providing  insights  on  how  to  make  this  clean  supply  option widely available and economical.

Only five countries had announced their hydrogen strategies by the end of 2019. A year on, nearly 20 have done so, with at least 10 more set to follow within months.  Industry  investors  plan  at  least  25  gigawatts  (GW)  of  electrolyser capacity  for  green  hydrogen  by  2026.  Still,  far  steeper  growth  is  needed  in  renewable power as well as green hydrogen capacity - to fulfil ambitious climate goals and hold the rise in average global temperatures at 1.5°C.

<!-- image -->

Energy  diversification,  when  based  on  renewables,  can  eliminate  emissions and fulfil climate pledges. Green hydrogen uptake, of course, would reduce the need for carbon capture by simply providing cleaner energy.

Yet  significant  barriers  remain.  Green  hydrogen  costs,  on  average,  between two and three times more to make than blue hydrogen, with the true potential and  viability  of  the  latter  requiring  further  investigation.  With  electricity input accounting for much of the production cost for green hydrogen, falling renewable power costs will narrow the gap. Attention, meanwhile, must shift to the second-largest cost component, electrolysers.

This report explores strategies and policies to drive innovation, cut costs for electrolysers and make green hydrogen a least-cost solution wherever needed. With larger production facilities, design standardisation and insights from early adopters, the proposed strategies could cut costs by 40% in the short term and up to 80% in the long term, this study finds.

In price terms, the resulting green hydrogen could fall below USD 2 per kilogram mark - low enough to compete - within a decade. This opens the way for largescale manufacturing capacity, new jobs and economic growth Already, green hydrogen's improving cost projections represent an amazing step forward; until just a few months ago, such results were not expected before mid-century. But getting there depends on defining the right business model, creating markets, and optimising the supply chain in a way that both developed and developing countries, equally, can enjoy the transition to a clean, resilient energy system.

Just as I hope 2021 will be a better year for humanity, I hope these findings will help to inspire the necessary action on green hydrogen. IRENA stands ready to help its member countries worldwide, whatever their energy challenges or level of economic development, make the leap.

Francesco La Camera

Director-General, IRENA

## CONTENTS

| EXECUTIVE SUMMARY                                                     | EXECUTIVE SUMMARY                                                                              |
|-----------------------------------------------------------------------|------------------------------------------------------------------------------------------------|
| ABOUT THIS REPORT                                                     | ABOUT THIS REPORT                                                                              |
| 1. INTRODUCTION                                                       | 1. INTRODUCTION                                                                                |
|                                                                       | 1.1/emspaceHydrogen and renewables                                                             |
|                                                                       | 1.2/emspaceLatest hydrogen policy developments                                                 |
| 2. ELECTROLYSER TECHNOLOGY CHARACTERISATION                           | 2. ELECTROLYSER TECHNOLOGY CHARACTERISATION                                                    |
|                                                                       | 2.1/emspace Electrolyser technologies                                                          |
|                                                                       | 2.2/emspace Cell level for each type of electrolyser                                           |
|                                                                       | 2.3/emspace System level for each type of electrolyser                                         |
|                                                                       | 2.4/emspace Trade-offs to consider in the design of the electrolyser                           |
|                                                                       | 2.5/emspace Flexibility of green hydrogen production facilities                                |
|                                                                       | 2.6/emspace Costs: Current status                                                              |
| 3. STRATEGIES FOR COST REDUCTION : STACK LEVEL                        | 3. STRATEGIES FOR COST REDUCTION : STACK LEVEL                                                 |
|                                                                       | 3.1/emspace Stack design: What can be done?                                                    |
|                                                                       | 3.2/emspace Setting targets for stack design: A key performance indicator (KPI)driven approach |
|                                                                       | 3.3/emspace Materials: Use, barriers and solutions                                             |
|                                                                       | 3.4/emspace Increasing module size                                                             |
| 4. STRATEGIES FOR COST REDUCTION: SYSTEM LEVEL                        | 4. STRATEGIES FOR COST REDUCTION: SYSTEM LEVEL                                                 |
|                                                                       | 4.1/emspace Manufacturing scale of electrolysers                                               |
|                                                                       | 4.2/emspaceLearning-by-doing                                                                   |
| 5. GREEN HYDROGEN PROJECT PIPELINE                                    | 5. GREEN HYDROGEN PROJECT PIPELINE                                                             |
|                                                                       | 5.1/emspace Key players                                                                        |
|                                                                       | 5.2/emspace Current relevant projects and expected key H 2 production sites beyond 2020        |
| 6. THE ROAD TO SCALING UP GREEN HYDROGEN: A MILESTONE-DRIVEN APPROACH | 6. THE ROAD TO SCALING UP GREEN HYDROGEN: A MILESTONE-DRIVEN APPROACH                          |
| 7. CONCLUSIONS AND ROLE FOR MULTIPLE STAKEHOLDERS IN SCALING UP       | 7. CONCLUSIONS AND ROLE FOR MULTIPLE STAKEHOLDERS IN SCALING UP                                |
| REFERENCES                                                            | REFERENCES                                                                                     |
| ABBREVIATIONS                                                         | ABBREVIATIONS                                                                                  |

6

GREEN  HYDROGEN

COST REDUCTION

## FIGURES

| Figure 1.   | Hydrogen production cost as a function of investment, electricity price and operating hours.                                                                                                      |   18 |
|-------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------|
| Figure 2.   | Recent hydrogen policies and strategies.                                                                                                                                                          |   20 |
| Figure 3 .  | Electrolyser capacity comparison between national strategies and IRENA's scenarios for 2030.                                                                                                      |   22 |
| Figure 4.   | Basic components of water electrolysers at different levels.                                                                                                                                      |   28 |
| Figure 5.   | Challenges and technological breakthroughs for each of the generation of electrolysers.                                                                                                           |   29 |
| Figure 6.   | Different types of commercially available electrolysis technologies.                                                                                                                              |   31 |
| Figure 7.   | Typical system design and balance of plant for an alkaline electrolyser.                                                                                                                          |   34 |
| Figure 8.   | Typical system design and balance of plant for a PEM electrolyser.                                                                                                                                |   35 |
| Figure 9.   | Typical system design and balance of plant for an AEM electrolyser.                                                                                                                               |   36 |
| Figure 10.  | Typical system design and balance of plant for a solid oxide electrolyser.                                                                                                                        |   36 |
| Figure 11.  | Energy losses for compression in a pressurized electrolyser as a function of delivery pressure and thickness of membrane.                                                                         |   37 |
| Figure 12.  | Energy losses for the multi-stage mechanical compression of hydrogen.                                                                                                                             |   38 |
| Figure 13.  | Plot size for an alkaline 1-GW electrolyser plant (left) and for a 100-MW alkaline electrolyser from Thyssenkrupp (right)                                                                         |   41 |
| Figure 14.  | Trade-offs between efficiency, durability and cost for electrolysers.                                                                                                                             |   42 |
| Figure 15.  | System schematic for green hydrogen production facility that includes electricity and hydrogen storage on site.                                                                                   |   46 |
| Figure 16.  | Power system services that can be provided by energy storage                                                                                                                                      |   48 |
| Figure 17 . | Seasonality of hydrogen production in Europe in the IRENA global power system model for 2050 (based on the Transforming Energy Scenario).                                                         |   48 |
| Figure 18.  | Cost breakdown for a 1-MW PEM electrolyser, moving from full system, to stack, to CCM.                                                                                                            |   52 |
| Figure 19.  | System components for a 1-MW PEM electrolyser classified based on contribution to total system cost and potential for cost reduction.                                                             |   53 |
| Figure 20.  | Cost breakdown for 1-MW alkaline electrolyser, moving from full system, to stack, to MEA.                                                                                                         |   54 |
| Figure 21.  | System components for a 1-MW alkaline electrolyser classified based on contribution to total system cost and potential for cost reduction.                                                        |   55 |
| Figure 22.  | Relationship between voltage (the higher, the lower the efficiency) and current density (the higher, the higher the production volume) for various diaphragm thickness of alkaline electrolysers. |   58 |
| Figure 23.  | Global warming potential and cumulative energy demand for critical materials used in electrolysers.                                                                                               |   67 |
| Figure 24.  | Top producers of critical materials in electrolysers.                                                                                                                                             |   69 |
| Figure 25.  | Cost breakdown by major component for alkaline electrolysers based on current costs.                                                                                                              |   71 |
| Figure 26.  | Electrolyser investment cost as a function of module size for various technologies.                                                                                                               |   72 |
| Figure 27.  | Cost breakdown for PEM electrolysers as a function of manufacturing scale (units of 1 MWper year).                                                                                                |   74 |

SCALING UP ELECTROLYSERS

TO MEET THE 1.5°C CLIMATE GOAL

| Figure 28.   | Cost breakdown for PEM electrolysers for a (a) 10 MW/year; (b) 1 GW/year production scale.                                               | 76   |
|--------------|------------------------------------------------------------------------------------------------------------------------------------------|------|
| Figure 29.   | Potential cost decrease for electrolysers based on a learning rate and costs achieved by deployment in IRENA scenarios by 2030 and 2050. | 79   |
| Figure 30.   | Variable learning rate based on components for three types of electrolysers.                                                             | 81   |
| Figure 31.   | (a) Historical and (b) Future (based on announcements and projects) electrolyser capacity.                                               | 84   |
| Figure 32.   | Estimated necessary electrolyser manufacturing capacity (GW/year) to meet different installed capacity targets by 2050                   | 85   |
| Figure 33.   | Milestones for four cost reduction strategies across three stages of deployment for electrolysers.                                       | 87   |
| Figure 34.   | Potential cost reduction by implementing strategies presented in this report across three stages of deployment.                          | 90   |
| Figure 35.   | Step changes for achieving green hydrogen competitiveness.                                                                               | 91   |
| Figure 36.   | Main actions and functions for key stakeholders influencing the scale up of green hydrogen.                                              | 93   |
| TABLES       | TABLES                                                                                                                                   |      |
| Table 1.     | Characterisation of the four types of water electrolysers.                                                                               | 32   |
| Table 2.     | Proposed activities to improve the performance of alkaline electrolysers.                                                                | 59   |
| Table 3.     | Proposed activities to improve the performance of PEM electrolysers.                                                                     | 61   |
| Table 4.     | Proposed activities to improve the performance of AEM electrolysers.                                                                     | 62   |
| Table 5.     | Proposed activities to improve the performance of solid oxide electrolysers.                                                             | 63   |
| Table 6.     | Stateoftheart and future KPIs for all electrolyser technologies.                                                                         | 65   |
| Table 7.     | Iridium and platinum loading for PEM electrolysers with increased performance and material reduction strategies.                         | 70   |
| Table 8.     | Economies of scale for PEM stack manufacturing.                                                                                          | 75   |
| Table 9.     | Learning rate estimates for electrolysers and fuel cells.                                                                                | 78   |
| Table 10.    | Learning rate by stack component for three types of electrolysers.                                                                       | 80   |
| Table 11.    | A nonexhaustive list of key players involved in the manufacturing of water electrolyser systems.                                         | 83   |

## BOXES

Box 1.

A brief look at the historical development of electrolysers

29

7

8

## EXECUTIVE SUMMARY

<!-- image -->

As more countries pursue deep decarbonisation strategies,  hydrogen  will  have  a  critical  role  to play.  This  will  be  particularly  so  where  direct electrification  is  challenging  and  in harder-toabate sectors, such as steel, chemicals, long-haul transport,  shipping  and  aviation .  In  this  context, hydrogen needs to be low carbon from the outset and ultimately green (produced by electrolysis of water using renewable electricity) .

and  is  the  focus  of  this  report,  which  identifies key  strategies  to reduce  investment  costs  for electrolysis plants from 40% in the short term to 80% in the long term. These strategies range from the fundamental design of the electrolyser stack to broader system-wide elements, including:

In  addition  to  regulations  and  market  design, the  cost  of  production  is  a  major  barrier  to  the uptake  of  green  hydrogen. Costs  are  falling  largely due to falling renewable power costs - but green hydrogen is still 2-3 times more expensive than  blue  hydrogen  (produced  from  fossil  fuels with carbon capture and storage) and further cost reductions are needed. 1

The  largest  single  cost  component  for  on-site production  of  green  hydrogen  is  the  cost  of the  renewable  electricity needed  to  power  the electrolyser unit. This renders production of green hydrogen  more  expensive  than  blue  hydrogen, regardless of the cost of the electrolyser. A low  cost  of  electricity  is  therefore  a  necessary condition for producing competitive green hydrogen. This creates an opportunity to produce hydrogen at locations around the world that have optimal renewable resources, in order to achieve competitiveness. 2

Low  electricity  cost  is  not  enough  by  itself  for competitive green hydrogen production, however, and reductions in the cost of electrolysis facilities are also needed. This is the second largest cost  component  of  green  hydrogen  production

-  Electrolyser design and construction: Increased module size and innovation with  increased  stack  manufacturing  have significant  impacts  on  cost.  Increasing  the plant  from  1  MW  (typical  today)  to  20 MW could  reduce  costs  by  over  a  third.  Cost, however,  is  not  the  only  factor  influencing plant  size,  as  each  technology  has  its  own stack  design,  which  also  varies  between manufacturers.  The  optimal  system  design also depends on the application that drives system  performance  in aspects such as efficiency and flexibility.
-  Economies of scale: Increasing stack production to automated production in GWscale  manufacturing  facilities  can  achieve a step-change cost reduction. At lower manufacture  rates,  the  stack  is  about  45% of  the  total  cost,  yet  at  higher  production rates,  it  can  go  down  to  30%.  For  Polymer Electrolyte  Membrane  (PEM)  electrolysers, the tipping point seems to be around 1 000 units (of 1 MW) per year, where this scale-up allows an almost 50% cost reduction in stack manufacturing. The cost of the surrounding plant  is  as  important  as  the  electrolyser stack and savings can be achieved through standardisation  of  system  components and plant design.

1

In the context of decarbonisation, hydrogen produced from fossil fuels without capturing most of the CO2 emissions does not fulfil the criteria of renewable energy, although it represents the vast majority of hydrogen production today.

2 The trend over the last decade of falling renewable electricity prices is expected to continue; 82%, 47% and 39% for solar photovoltaic (PV), offshore and onshore wind respectively (IRENA, 2020a).

-  Procurement of materials: Scarce materials can represent a barrier  to  electrolyser  cost and scale-up. Current production of iridium and platinum for PEM electrolysers will only support  an  estimated  3 GW-7.5 GW  annual manufacturing  capacity,  compared  to  an estimated annual manufacturing requirement of  around  100 GW  by  2030.  Solutions  that avoid the use of such materials are already being implemented by leading alkaline electrolyser manufacturers, however, and technologies  exist  to  significantly  reduce the requirements for such materials in PEM electrolysers. Anion  Exchange  Membrane (AEM)  electrolysers do  not  need  scarce materials in the first place.
-  Efficiency and flexibility in operations: Power  supply  represents  large  efficiency losses at low load, limiting system flexibility, from  an  economic  perspective.  A  modular plant design with multiple stacks and power supply units can address this problem. Compression could also represent a  bottleneck  for  flexibility,  since  it  might not  be  able  to  change  its  production  rate as  quickly  as  the  stack.  One  alternative  to deal with this is an integrated plant design with enough capacity to deal with variability of production through optimised and integrated electricity and hydrogen storage. Green  hydrogen  production can provide significant flexibility for the power system, if the value of such services is recognised and remunerated  adequately.  Where  hydrogen will play a key role in terms of flexibility, as it  does  not  have  any  significant  alternative sources  to  compete  with,  will  be  in  the seasonal  storage  of  renewables.  Although this comes at significant efficiency losses, it is a necessary cornerstone for achieving 100% renewable generation in power systems with heavy reliance on variable resources, such as solar and wind.

SCALING UP ELECTROLYSERS

TO MEET THE 1.5°C CLIMATE GOAL

-  Industrial  applications: Electrolysis  system design and operation can be optimised for specific applications. These can range from: large industry users requiring a stable supply and  with  low  logistics  costs;  large  scale, off-grid  facilities  with  access  to  low-cost renewables, but that incur in significant costs to  deliver  hydrogen  to  the  end-user;  and decentralised production that requires small modules for flexibility, which compensate for higher  investment  per  unit  of  electrolyser capacity  with  reduced  (or  nearzero  onsite) logistic costs.
-  Learning  rates: Several  studies  show  that potential  learning  rates  for  fuel  cells  and electrolysers are similar to solar PV and can reach  values  between  16%  and  21%.  This  is significantly  lower  than  the  36%  learning rates experienced over the last 10 years for PV (IRENA, 2020a). With such learning rates and  a  deployment  pathway  in  line  with  a 1.5°C climate target, a reduction in the cost of electrolysers of over 40% may be achievable by 2030.

Figure ES1 shows  how  up  to 85%  of  green hydrogen production costs can be reduced in the long term by a combination of cheaper electricity and electrolyser capex investment, in addition to increased  efficiency  and  optimised  operation  of the electrolyser .

9

## Figure ES1.

A combination of cost reductions in electricity and electrolysers, combined with increased efficiency and operating lifetime, can deliver 80% reduction in hydrogen cost.

<!-- image -->

Note: 'Today' captures best and average conditions. 'Average' signifies an investment of USD 770/kilowatt (kW), efficiency of 65% (lower heating value - LHV), an electricity price of USD 53/MWh, full load hours of 3200 (onshore wind), and a weighted average cost of capital (WACC) of 10% (relatively high risk). 'Best' signifies investment of USD 130/kW, efficiency of 76% (LHV), electricity price of USD 20/MWh, full load hours of 4200 (onshore wind), and a WACC of 6% (similar to renewable electricity today).

Based on IRENA analysis

Figure ES2 illustrates the potential green hydrogen production cost reduction between 2020 and 2050 for a range of electrolysers cost and deployment levels. In the best-case scenario, green hydrogen can already be produced at costs competitive with blue hydrogen today , using lowcost renewable electricity, i.e. around USD 20 per megawatt-hour (MWh).

A low electricity price is essential for the production of competitive green hydrogen, and, as illustrated in Figure ES2, cost reductions in electrolysers cannot  compensate  for  high electricity  prices .  Combined  with  low  electricity cost, an aggressive electrolyser deployment pathway 3 can make  green hydrogen cheaper than  any  low-carbon  alternative  ( i. e. &lt;  USD  1/kg), before 2040. If rapid scale-up takes place in the next decade, green hydrogen is expected to start becoming  competitive  with  blue  hydrogen  by 2030  in  a  wide  range  of  countries  e.g. those with  electricity  prices  of  USD 30/MWh  -  and  in applications.

## Figure ES2.

Cost of green hydrogen production as a function of electrolyser deployment, using an average (USD 65 /MWh) and a low (USD 20/MWh) electricity price, constant over the period 2020-2050.

<!-- image -->

Note: Efficiency at nominal capacity is 65%, with a LHV of 51.2 kilowatt hour/kilogramme of hydrogen (kWh/kg H2) in 2020 and 76% (at an LHV of 43.8 kWh/kg H2) in 2050, a discount rate of 8% and a stack lifetime of 80 000 hours. The electrolyser investment cost for 2020 is USD 650-1000/kW. Electrolyser costs reach USD 130-307/kW as a result of 1-5 TW of capacity deployed by 2050.

Based on IRENA analysis.

Today's  cost  and  performance  are  not  the  same for  all  electrolyser  technologies  (see  Table  ES1). Alkaline and  PEM  electrolysers are the most advanced  and  already  commercial,  while  each technology  has  its  own  competitive  advantage. Alkaline  electrolysers  have  the  lowest  installed cost, while PEM electrolysers have a much smaller footprint,  combined  with  higher  current  density and  output  pressure.  Meanwhile,  solid  oxide  has the highest electrical efficiency. As the cell stack is only part of the electrolyser facility footprint, a reduced  stack  footprint  of  around  60%  for  PEM compared  to  alkaline  translates  into  a  20%-24% reduction in the facility footprint, with an estimated footprint of 8 hectares (ha)-13 ha for a 1 GW facility using PEM, compared to 10 ha-17 ha using alkaline (ISPT,  2020). Gaps in cost and performance are expected  to  narrow  over  time  as  innovation and  mass  deployment  of  different  electrolysis technologies drive convergence towards similar costs. The wide range in system costs is expected to remain, however, as this is very much dependent on the scale, application and scope of delivery. For instance, a containerised system inside an existing facility with existing power supply is significantly lower cost than a new building in a plot of land to be purchased, with complete water and electricity supply system to be included, high purity

hydrogen for fuel cell applications and high output pressure. Normally,  numbers  for  system  costs include  not  only  cell  stack,  but  also  balance  of stacks, power rectifiers, the hydrogen purification system, water supply and purification, cooling and commissioning - yet exclude shipping, civil works and site preparations.

lowest value the price can be (on the limit of zero profit). As the market scales up rapidly, in the initial phase,  the  investment  in  manufacturing  facilities must be recovered, therefore the gap between cost and price is currently higher than in 10 or 20 years from now. As a reference, an estimated investment of EUR 45-69 million is required for each GW of manufacturing capacity (Cihlar et al., 2020).

Notably, the numbers for 2020 are cost estimates for  a  system  ordered  in  2020,  representing  the

Table ES1. Key performance indicators for four electrolyser technologies today and in 2050.

Cell pressure [bara]

Efficiency (system)

[kWh/KgH ]

2

Lifetime [thousand hours]

Capital costs estimate for large

stacks (stack-only, &gt;

1 MW) [USD/kW ]

el

Capital cost range estimate for the

entire system, &gt;10

MW [USD/kW ]

| 2020                | 2020                | 2020   | 2020    | 2050     | 2050    | 2050   | 2050   |
|---------------------|---------------------|--------|---------|----------|---------|--------|--------|
| Alkaline            | PEM                 | AEM    | SOEC    | Alkaline | PEM     | AEM    | SOEC   |
| < 30                | < 70                | < 35   | < 10    | > 70     | > 70    | > 70   | > 20   |
| 50-78               | 50-83               | 57-69  | 45-55   | < 45     | < 45    | < 45   | < 40   |
| 60                  | 50-80               | > 5    | < 20    | 100      | 100-120 | 100    | 80     |
| 270                 | 400                 | -      | > 2 000 | < 100    | < 100   | < 100  | < 200  |
| 500- 1/thinspace000 | 700- 1/thinspace400 | -      | -       | < 200    | < 200   | < 200  | < 300  |

el

Note: PEM =  Polymer Electrolyte Membrane (commercial technology); AEM = Anion Exchange Membrane (lab-scale today); SOEC = Solid Oxide Electrolysers (lab-scale today).

Based on IRENA analysis.

Innovation is crucial to reduce cost and improve the performance of the electrolyser. The ultimate goals are to: 1) reduce cost by standardising and simplifying  manufacturing  and  design  to  allow for industrialisation and scale-up; 2) improve efficiency  to  reduce  the  amount  of  electricity required  to  produce  one  unit  of  hydrogen;  and 3)  increase  durability  to  extend  the  equipment lifetime  and  spread  the  cost  of  the  electrolyser facility over a larger hydrogen production volume.

Governments can support innovation in electrolysers  by  issuing  clear  long-term  signals that support policy on:

-  Facilitating  investment  in  production,  logistics and utilisation of green hydrogen, including all areas that will help this low-carbon energy carrier  to  become  competitive;  technology cost and performance improvements, material supply, business models and trading using common standards and certifications.
-  Establishing regulations and design markets that support investments in innovation and scale-up the production of green hydrogen. This  includes  approaches  such  as  setting manufacturing  or  deployment  targets,  tax incentives, mandatory  quotas  in  hard  to decarbonise  sectors  and  other  de-risking mechanisms,  while  enabling  new  business models that can guarantee predictable revenues for the private sector to invest at scale.
-  Supporting research, development and demonstration  (RD&amp;D)  to:  reduce  the  use of iridium and platinum in the manufacture of  PEM  electrolysers;  transition  all  alkaline units to be platinum- and cobalt-free; and, in general,  mandate  reduced  scarce  materials utilisation  as  a  condition  for  manufacturing scale-up.
-  Fostering  coordination  and  common  goals along the hydrogen  value chain, across borders, across relevant sectors and between stakeholders.

13

## ABOUT THIS REPORT

<!-- image -->

<!-- image -->

<!-- image -->

This report is part of IRENA's ongoing programme of work to provide its member states and the wider community with expert analytical insights into the potential options and enabling conditions and policies that could deliver deep decarbonisation of economies.

<!-- image -->

<!-- image -->

<!-- image -->

This report complements a range of publications and activities produced and planned by IRENA, including its annual Global Renewable Outlook, which provides detailed global and regional roadmaps for emission reductions alongside assessment of the socio-economic implications.  The  2020  edition  includes  Deep  Decarbonisation  Perspectives,  detailing options for net-zero or zero emissions (IRENA, 2020b). The next edition is expected to include further detailed analysis of a pathway consistent with a 1.5°C goal.

Building  on  that  technical  and  socio-economic  assessment,  IRENA  is  assessing  specific facets of that pathway, including the policy and financial frameworks needed. This includes the roles of direct and indirect electrification, the implications for power systems, the role of green hydrogen and of biomass, and options for specific, challenging end-use sectors.

For  green  hydrogen,  some  of  the  relevant recent  and  upcoming  publications include: Hydrogen:  A  renewable  energy  perspective (IRENA,  2019a);  the Reaching  Zero  with Renewables report  and  its  briefs  on  industry  and  transport  (IRENA,  2020c);  the Green Hydrogen: A guide to policy making report and its associated briefs (IRENA, 2020d), which present a policy framework to promote green hydrogen across the entire energy sector and the key overarching policy pillars; reports on the potential of biojet fuels and on renewable methanol; Renewable energy policies in a time of transition: Heating and Cooling , and the subsequent briefs to this report (IRENA, 2020e).

This analytical work is complemented by IRENA's work to convene experts and stakeholders, including IRENA's Innovation Weeks, Policy Days and Policy Talks and IRENA's Collaborative Framework on Green Hydrogen, which brings together a broad range of member states and other stakeholders to exchange knowledge and experience.

Details of these and other related activities can be found at www.irena.org .

SCALING UP ELECTROLYSERS

TO MEET THE 1.5°C CLIMATE GOAL

## 1. INTRODUCTION

-  The major cost component for green hydrogen is the electricity supply. Cost  decline  in  this  is  already  underway  through  the  competitive deployment of renewables.

## KEY POINTS

-  There is a need to focus on reducing the procurement and construction cost and increasing the performance and durability of electrolysers, to achieve further cost reductions in green hydrogen production.
-  Green hydrogen can achieve cost-competitiveness with fossil-based hydrogen today in ideal locations with the lowest renewable electricity costs.  Cost  reductions  in  renewable  electricity  and  electrolysers  will continue to increase the number of sites where green hydrogen can be produced competitively, however.
-  Policy  support  in  recently  unveiled  hydrogen  strategies  in  many countries is mostly in the form of explicit electrolyser capacity targets and, to a more limited extent, cost targets. These have yet to translate into specific regulatory instruments. So far, these explicit targets are not enough to be in line with 1.5°C decarbonisation pathways.

## 1.1 HYDROGEN AND RENEWABLES

The world is undergoing a dramatic change in the way energy is produced, transformed, stored and used  in  its  various  forms.  People  are  becoming increasingly conscious of the need to move towards a society where energy stops contributing to  climate  change  and  local  pollution,  replacing fossil fuels with renewable energy.

As the deployment of renewable energy sources increases  all  over  the  globe  in  the  power  sector, solutions  that  leverage  renewable  electricity  to decarbonise end-use sectors using power-to-gas strategies, or to convert electricity into high-value chemicals or fuels, need to be quickly introduced (IRENA,  2020c).  In  addition,  as  electricity  needs to increase  from  around  20%  of  final  energy consumption  to  around  50%  by  2050  (IRENA, 2020b),  there is still a need  to decarbonise applications for which direct electrification is more  challenging  (the  so  called  'hard-to-abate' sectors).

Hydrogen  is  only  one  option  in  decarbonising hard-to-abate  sectors.  Energy  efficiency  is  key to  reducing  the  energy  supply  and  renewable capacity upstream,  while  bioenergy  might  be suitable, not only in the form of biofuels for those transport sectors that have limited fuel alternatives (especially aviation), but also as a source of carbon for  synthetic  fuels.  Direct  electrification  is  more efficient from a systems perspective, leading to lower  cost, with  this already  commercially deployed in many areas ( e.g. heating or passenger vehicles). Carbon capture and storage (CCS) might be  attractive  for  existing  assets  that  are  still  in early  stages  of  their  lifetime  (the  case  for  many assets  in  Asia)  and  process  emissions  ( e.g. from cement production). Even for the most ambitious scenarios,  these  technological  choices  might  not be  enough,  however,  and  behavioural  changes might  be  needed  to  push  energy  demand  even lower. Thus, for energy transition, hydrogen is one solution amongst others and should be tackled in parallel.  Hydrogen  is  part  of  a  wider  technology portfolio to be adapted to domestic conditions in each country, with this report further exploring this pathway.

Green  hydrogen  ( i.e. hydrogen  produced  from renewable  electricity)  links  renewable  electricity with a range of end-use applications acting as a complement of electrification, bioenergy and direct renewable energy use (IRENA, 2018). The potential for  green  hydrogen  is  much  higher  than  fossil fuels, since it is linked to solar and wind potential, which  far  exceeds  global  energy  demand  today and in any future scenario. Most importantly, in the context of decarbonisation, green hydrogen is the only zero-carbon option for hydrogen production, as carbon capture in CCS is 85%-95% at best and significantly lower to date.

Once  produced  at  scale  and  competitive  cost, green  hydrogen  can  also  be  further  converted into other  energy  carriers, such  as  ammonia, methanol,  methane  and  liquid  hydrocarbons.  As a fuel, hydrogen can be used in fuel cells ( i.e. an electrochemical  device  that  combines  hydrogen with oxygen from the air and produces electricity), but also combusted in engines and turbines. Fuel cells  can  be  used  for  stationary  applications  in large-scale  power  plants,  microgrid  or  backup generation ( e.g. in  data centres), or for a wide range of  transport  applications  -  as  is  already  done  in fuel cell electric vehicles (FCEV), trucks, light-duty vehicles,  forklifts,  buses,  ferries  and  ships.  As  a chemical, green hydrogen can reduce greenhouse gas (GHG) emissions from sectors where hydrogen from fossil fuel is widely used today, including oil refining, methanol and ammonia production.

Green  hydrogen  is  only  one  of  the  production pathways.  Hydrogen  can  also  be  produced  from bioenergy,  methane,  coal  or  even  directly  from solar  energy.  Most  of  the  production  today  is based on methane and coal (about 95%) (IRENA, 2019a)  and  could  be  made  low  carbon  with  the use of CCS. CCS might be suitable for regions with low-cost  natural  gas  and  suitable  underground reservoirs.  In  the  short  term,  CCS  might  also  be a good fit for large-scale applications in industry, given the relatively small scale of deployment for electrolysis.

Low-carbon hydrogen can also be produced from methane  pyrolysis,  where  the  carbon  ends  up as solid rather than as CO , with 4-5 times lower 2 electricity consumption than electrolysis and potentially lower hydrogen production cost. Each pathway has its own limitations. Bioenergy might be best suited for other applications, considering its  limited  nature  and the low inherent hydrogen yield. CCS  does  not  lead to zero emissions, requires significant infrastructure for the CO , does 2 not enable sector coupling, is still exposed to the price fluctuations characteristic of fossil fuels, and

could  face  social  acceptance  issues.  In  addition, methane leakages associated with production and transportation of the gas have been increasingly under  scrutiny  as  significant  contributors  to  the acceleration  of  climate  change.  Methane  has  86 times higher global warming potential compared to CO  over a 20-year time horizon (The CCAC Oil 2 &amp; Gas Methane Partnership, no date; Hmiel et al., 2020). Pyrolysis is still at the pilot scale stage and would require high-temperature renewable or lowcarbon heat. Hence, considering the sector, green hydrogen  is  one  of  the  most  attractive  options, given its nature and renewable character, and as such, it is the focus of this report.

Green hydrogen, similar to other production pathways, also has its challenges, however. These include: its current high cost across the entire value chain, from electrolysis to transport and fuel cells; the  lack  of  existing  infrastructure  for  transport and storage; the high energy losses (which in turn require higher wind/solar deployment rates); and the lack of value for the main benefit ( e.g. lower GHG  emissions)  that  green  hydrogen  can  have (IRENA, 2019a, 2020c).

Electricity is the dominant cost for on-site production of green hydrogen , but the journey to lower renewable costs is already underway. Efforts need to shift to the second largest cost for green hydrogen: electrolysers

Renewables  are  becoming  the  cheapest  source of  electricity  around  the  world,  with  significant potential for further cost reductions (IRENA, 2020a). This opens up the opportunity, in the longterm,  to  trade  globally  low-cost  green  hydrogen from  the  best  renewable  resources  to  regions with  limited  land  or  renewable  potential.  This trade can be done directly with liquid hydrogen, in the form of hydrogen carriers that increase the energy  density  for  transport,  or  in  the  form  of commodities  ( e.g. reduced  iron  and  chemicals). The  missing  element  in  this  equation  is  the  key facility  to  convert  renewable  power  into  green hydrogen:  the  electrolyser.  Electrolysers  are  the technology necessary to produce hydrogen using electricity and water as inputs. Electrolysis is a wellestablished technology that is deployed mostly in the chemical industry. While scale-up is needed to bring costs down, technological innovation is also needed to further improve the performance of the technology  ( i.e. its  efficiency  and  lifetime).  This can be done via new catalysts and configurations, the standardisation of designs and a move to mass production of the equipment.

Green hydrogen is already close to being competitive today in regions where all the favourable conditions align, but these are usually far from demand centres. For example, in Patagonia, wind  energy  could  have  a  capacity  factor  of almost 50%, with an electricity cost of USD 25-30/ MWh. This would be enough to achieve a green hydrogen  production  cost  of  about  USD  2.5/kg, which  is  close  to  the  blue  hydrogen  cost  range. In most locations, however, green hydrogen is still 2-3  times  more  expensive  than  blue  hydrogen. The  cost  of  the  former  is  defined  by  electricity costs, investment cost, fixed operating costs and the number of operating hours of the electrolyser facilities (see Figure 1).

With  low  operating  hours,  the  investment  cost dominates, as it is spread over a smaller amount of hydrogen. This could happen when using only curtailed  electricity,  or  coupling  with  PV  without any storage or backup. The electricity cost becomes  dominant  as  the  number  of  operating hours  increases.  Solar  projects  in  countries  such as Brazil, Portugal, the United Arab Emirates and the United States have been deployed with costs of electricity as low as USD 13.5-20/MWh due to supportive  policy  instruments,  such  as  auctions, to  guarantee  a  stable  payment  and  reduce  the investment risk.

Due  to  the  efficiency  of  the  current  process, any power cost that goes into the process translates into roughly 1.5 times this value in final production costs. This means that a power cost of USD  20/MWh  results  in  around  USD  31/MWh  in the final cost of the hydrogen, or a figure slightly above USD 1/kg H . 2

Under the optimal conditions of low-cost renewable electricity, low investment cost (achievable  through  the  strategies  suggested  in this report) and a high number of operating hours, green hydrogen could achieve cost competitiveness with fossil-based hydrogen, noting that only about 3000-4000  hours  per  year  may  be  enough  to achieve  the  largest  reduction  in  the  contribution of  the  investment.  This  can  be  achieved  by,  for instance, large scale hybrid PVwind plants, which, at  the  best  locations  in  the  world,  can  achieve capacity factors above 5000 hours.

Currently,  green  hydrogen  production  is  limited to  demonstration  projects.  By  September  2020, there  were  almost  320  of  these,  adding  up  to around  200  MW  of  electrolyser  capacity  (IEA TCP). Green hydrogen (through water electrolysis) contributed  to  less  than  0.02%  of  presentday global  pure  hydrogen  production.  Projects  are mostly  in  the  single-digit  MW  scale  with  the largest  project  in  operation  currently  a  10  MW alkaline electrolyser in Japan. A  20 MW  PEM electrolyser in Becancour (Canada) by Air Liquide is  expected  to  be  operational  before  the  end  of 2020. In spite of this small scale, the technology is already commercial and ready to scale up, with projects announced  between  2020  and  2025 adding up to more than 25 GW and new projects being  announced  on  almost  a  weekly  basis  (see Chapter 5, Section 2).

Figure 2 2

Figure

Figure 1. Hydrogen production cost as a function of investment, electricity price and operating hours.

Hydrogen production cost (USD/kg)

<!-- image -->

Hydrogen production cost (USD/kg)

Note: Efficiency at nominal capacity is 65% (with an LHV of 51.2 kWh/kg H ), the discount rate 8% and the stack lifetime 2 80 000 hours.

Based on IRENA analysis.

## 1.2 LATEST HYDROGEN POLICY DEVELOPMENTS

Previous waves  of interest in hydrogen  have been  triggered  by  oil  supply  shocks,  with  this technology seen as a way to diversify away from oil and improve energy security. In recent years, with the focus on net zero emissions and plummeting renewable  costs,  interest  in  other  sectors  has become more prominent. As a consequence, most of the existing policy support for hydrogen is for fuel  cell  electric  vehicles  and  refuelling  stations (IRENA, 2020d). This is set to change in the coming years  as  focus  changes  to  sectors  with  existing hydrogen demand (industry) and replacement of fossil-based hydrogen.

of  hydrogen  policies  in  such  a  short  period  of time  is  the  widespread  recognition  that  in  order to achieve the objectives of the Paris Agreement, green hydrogen has a key role to play in reaching zero  emissions  from  the  energy  sector  (IRENA, 2020b, 2020c).

Promoting hydrogen uptake across the various enduse sectors requires an integrated policy approach. The  main  pillars  of  this  are:  national  hydrogen strategies that bring all the elements together, set a long-term vision shared with industry and guide efforts  from  multiple  stakeholders;  setting  policy priorities  for  sectors  where  hydrogen  could  add the  most  value  according  to  national  conditions; governance  systems  and  enabling  policies  that remove barriers and facilitate growth; guarantees of  origin  systems  to  track  production  emissions and  be  able  to  value  the  lower  GHG  emissions (IRENA, 2019a, 2020c).

Over the last few years, an increasing number of countries  have  adopted  hydrogen  policies  and strategies. These differ in scope ( e.g. with a focus on green hydrogen, fossil-based, or a combination of  the  two)  and  scale  (from  no  targets  to  very ambitious, quantified hydrogen as well as electrolyser  targets).  What  emerges  clearly  from this  rapid  increase  in  the  number  and  ambition

While some strategies support fossil-based hydrogen  in  the short-term, as a transitional technology  for  scaling  up,  there  is  widespread support  for  green  hydrogen  as  the  long-term, sustainable solution. Support is also more widespread today, with more countries supporting green hydrogen compared  to blue. Amongst countries  that  support  only  one  technologyical pathway,  there  are  also  more  supporting  only green hydrogen than only blue. As recently as  2020,  eight  jurisdictions  around  the  world announced  hydrogen  strategies  and  at  least  ten more  are  expected  in  2021.  These  strategies, however, are neither the beginning nor the end of the role of hydrogen in decarbonising energy. They are the result of investment, starting in the 1970s, in  energy  application  research  and  development (R&amp;D)  that  has  enabled  technological  progress and close cooperation between private and public actors. This has taken place through partnerships, culminating in vision documents or roadmaps that pave the way for more concrete policy actions by aligning long-term views. These strategies are not the end of the process, however, since they must be followed by impact assessments, policy design, financial viability and implementation. In the last two  years,  though,  there  has  been  a  significant increase in public efforts towards achieving these goals (see Figure 2).

Figure 2. Recent hydrogen policies and strategies.

<!-- image -->

Source: (IRENA, 2020d).

Today,  most  countries  are  at  the  strategy  stage and have yet to move to concrete policy measures. Explicit  capacity  targets  for  electrolysis  are  the most  common  measure  for  green  hydrogen  and have  been  the  norm  across  Europe  (see  below). Specific policy instruments to achieve those targets  will only  be  crafted  over  the  coming months. For example, Japan was one of the earlier supporters of hydrogen and has already translated its strategy into concrete  cost  and  efficiency targets  per  application.  Japan  also  already  has multiple projects underway for international trade in hydrogen (import is a large part of their strategy) with the first liquid hydrogen ship having been delivered in December 2019 and the first blue ammonia ( i.e. ammonia from gas reforming with CCS)  shipment  in  September  2020.  Meanwhile, Australia and  Chile  have  opted  for  ambitious cost  targets  instead.  Australia  has  launched  the 'H 2 under 2' target (production cost below AUD  2/kg of hydrogen), which has already triggered AUD 370 million in State support (see  below)  and  consideration  in  the  country's Technology Investment Roadmap, while Chile has set a target of USD 1.5/kg of hydrogen by 2030, aiming to become the cheapest in the world.

Beyond capacity and cost targets, other possibilities are available to governments, including  incentives  for  the  domestic  production of  electrolysers  ( e.g. tax  breaks),  direct  grants, conditional  and  convertible  loans,  feed-in  tariffs, auctions  and  contracts  for  difference,  amongst others. Nevertheless, these have  insofar been limited  in  the  strategies  announced.  IRENA  has explored  trade-offs  to  consider  the  design  of these policy instruments in a separate publication (IRENA, 2020d).

The most ambitious strategies for green hydrogen are in the European Union (EU). The EU as a whole has a target of 40 GW 4  by 2030, which is supported by national targets from France, Germany, Netherlands,  Portugal  and  Spain.  These  targets are 6.5 GW, 5.0 GW, 3.0-4.0 GW respectively. The EU strategy also sets a target volume of 10 million tonnes of hydrogen  per  year  (MtH /year) 2 by

2030, which would require 40 GW of electrolysis in neighbouring countries (North Africa). Beyond the EU plans, Chile has a target of 25 GW by 2030 and  Australia  has  multiple  multi-GW  proposals ongoing.  Both  countries  are  aiming  to  satisfy local demand in the early stages of development, targeting exports in the long term.

Adding up these three targets for electrolysis would already  be  enough  to  satisfy  the  2030  target  of 100 GW in IRENA's Planned Energy Scenario. This is,  however, not yet compatible with a wellbelow 2°C trajectory, which would require at least 270 GW of capacity deployed by 2030 - as outlined in the Transforming Energy Scenario (TES - see Figure 3). The TES scenario still has about 9.5 gigatonnes of carbon dioxide (GtCO ) of remaining emissions 2 in 2050. Going further, a net zero world by 2050 would require an even larger role for hydrogen and a faster pace of deployment. On a positive note, 14 of 17 strategies already focus on green hydrogen by 2030, while only the EU (and several of its member states), Chile and Australia set specific electrolysis targets. Therefore, the large gap before the more ambitious  scenario  could  be  rapidly  closed  once the other countries that support green hydrogen set specific targets for electrolysis capacity.

Indeed,  the  translation  of  hydrogen  production targets into specific electrolyser capacity targets for  green  hydrogen  production  is  an  important element of a national hydrogen strategy. This give the right signal for industry to invest in electrolyser manufacturing plants, while showing the means by which such targets can be achieved ( i.e. government policies), which are a necessary condition to meet policy  targets  for  green  hydrogen.  Electrolyser costs will benefit from global deployment, which calls for coordinating  national  efforts  through international platforms to ensure that lessons are being transferred from one country to another.

Just  as  importantly,  green  hydrogen  production requires significant additional renewable electricity generation, which  also requires investment  in manufacturing capacity for renewable power generation.

In  the  absence  of  such  clear  policy  statements, including on the production pathway for hydrogen ( i.e. electrolysis or fossil fuels), the lack of certainty of  the  demand  for  electrolysers  and  additional renewable power generation will slow down the  growth  of  the  green  hydrogen  sector,  which is  already  very  ambitious  in  absence  of  supply bottlenecks.

Figure 3. Electrolyser capacity comparison between national strategies and IRENA's scenarios for 2030.

<!-- image -->

Based on IRENA analysis.

The  fulfilment  of  the  strategies  announced  so far  would  mean  going  from  around  0.2 GW  of water electrolysis  today  to  about  85 GW  in  2030 (see  Figure  3).  This  represents  an  annual  growth rate of almost 83% per year. As a reference, solar photovoltaic (PV) almost achieved such a pace in 2008-2011, but did so with a trained workforce in place  and  policy  support  (feed-in  tariffs),  while also being easier to install than electrolysers. This means that investments need to rapidly materialise to  allow  scale-up  of  electrolyser  manufacturing capacity.

A few selected hydrogen strategies are highlighted here,  in  particular  those  with  a  clear  focus  on electrolysers scale-up. For a comprehensive overview of hydrogen policies in place and recommendation for hydrogen policy development, as well as a number of insights into strategies to accelerate its development, refer to previous IRENA reports (IRENA, 2019a, 2020c).

Australia: National hydrogen strategy sets a vision for a clean, innovative, safe and competitive hydrogen industry, with the aim of positioning it as a  major player by 2030. The strategy outlines an adaptive  approach  that  equips  Australia  to  scale up  quickly  as  the  hydrogen  market  grows.  The strategy  includes  a  set  of  nationally  coordinated actions involving governments, industry and the community. Australia has adopted eight international standards to shape its hydrogen future, as it bids to use the fuel to enhance energy security  and  build  a  billiondollar  export  industry. The rules have the potential not only to support the safety of users - with guidance on storage, transport and refuelling - but also to facilitate international trade,  as  the  nation  aims  to  assume  a  major  role

in  the  global  hydrogen  economy.  As  mentioned above, one of the key targets is 'H  under 2', which 2 targets a production cost of AUD 2/kg (USD 1.4/ kg) for hydrogen to be competitive across various applications. By 2019, when the national strategy was  launched,  the  government  had  committed over  AUD 500  million  (USD 355  million)  towards hydrogen  projects.  Additionally,  the  government has announced an investment package of AUD 1.9  billion  (USD 1.35  billion)  to  support  new energy  technologies,  including  hydrogen,  with AUD 70.2  million (USD 49.8 million) dedicated specifically  to  hydrogen  export  hubs  (Australian Government, 2020).

Chile: This country has some of the best renewable  resources  in  the  world,  both  in  solar (desert in the north) and wind (Patagonia in the south).  Electricity  costs  from  solar  and  wind  are expected to fall, from USD 20-30/MWh today to USD 10-20/MWh by mid-century. The renewable potential is attractive, not only in terms of cost, but in quantity. Chile's renewable potential is equivalent to 70 times today's electricity generation capacity. Based on this, Chile's strategy is focused exclusively on green hydrogen and directed towards exports.

Hydrogen deployment in the country is expected in three waves:  first, domestic  use,  replacing fossilbased hydrogen in industry and heavy, longdistance transport; second, ammonia exports, blending into the grid and a larger share of road transport; and third, scale-up of hydrogen exports and  production  for  shipping  and  aviation.  The targets include 5 GW  of electrolysis capacity (operating and under development)  by  2025 with a production  of at least 0.2 MtH /year. 2 The  targets  for  2030  are  25 GW  of  electrolysis, with a hydrogen production cost less than USD  1.5/kg  -  the  cheapest  in  the  world    -  and exporting  the  equivalent  of  USD 2.5  billion  per year of hydrogen and derivatives. To achieve these targets, 15 actions have been identified across four main themes: promotion of domestic and export markets (including international collaboration, knowledge  exchange  and  guarantees  of  origin); standards,  safety  and  piloting  (including  market design to allow the participation of electrolysers in the various markets); social and local development

(social  acceptance  and  infrastructure);  capacity building and innovation.

European Union: On July 8, 2020, the European Commission published its hydrogen strategy for a climate neutral Europe. This aims to boost the clean production of hydrogen to be used as a feedstock, fuel, energy carrier, and ultimate storage alternative for European renewables. The drivers for hydrogen are carbon neutrality, job creation, economic growth and technology leadership (especially for electrolysers). the strategy has explicit electrolyser capacity targets of 6 GW by 2024 and 40 GW by 2030,  as  well  as  production  targets  of  1  million and 10 million tonnes of renewable hydrogen per year for those two milestone years. Reaching these production targets would require a larger capacity than the 6 GW and 40 GW specified, which implies additional  import  from  neighbouring  countries. Investments in renewable hydrogen are estimated to be in the order EUR 220-340 billion (USD 280430  billion)  for  the  electricity  production  and EUR  24-42  billion  (USD  30.5-53  billion)  for  the electrolysers by 2030.

Hydrogen  is  seen  by  the  European  Commission as  a  key  vector  across  energy  sectors  and  this strategy  was  released  together  with  a  strategy called  'Energy  System  Integration',  highlighting this function. The Clean Hydrogen Alliance (CHA),  a  platform  that  brings  together  multiple stakeholders from industry, government, civil society  and  academia,  was  also  launched  the same  day.  Besides  bringing  actors  together,  the CHA is also meant to provide a robust pipeline of projects  that  will  support  the  scale-up  process. The commission´s economic recovery plan, 'Next Generation EU', highlights hydrogen as an investment priority to boost economic growth and resilience,  creating  local  jobs  and  consolidating the  EU´s  global  leadership.  The  total  fund  is EUR 750 billion (about USD 950 million) and while only a small share of this is expected to be used for hydrogen, it could represent a large step towards the 2024 goal of 6 GW.

Germany: The  federal  government  of  Germany released  its  hydrogen  national  strategy  in  June 2020. Among the drivers for hydrogen it contains

are hydrogen's potential contribution towards GHG neutrality  and  the  need  for  action  in  hardto-abate  sectors,  along  with  economic  growth and the competitiveness of the domestic industry. Emphasis is given to the industrial and transport sectors. The need for potential hydrogen imports to complement domestic potential is also recognised.  The  German  government  will  only support hydrogen  produced  from  renewables, hence,  it  seeks  the  production  and  use  of  green hydrogen  by  promoting  its  rapid  market  rollout and establishing the necessary value chain within the country.

Germany has been a key proponent of hydrogen, having  already  invested  around  EUR  700  million (about USD 890 billion) between 2006 and 2016  under  the  National  Innovation  Programme in Hydrogen,  with  a  total of EUR  1.4 billion (USD  1.7  billion)  in  funding  set  to  be  provided within its Hydrogen  National  Strategy, up to 2026. The German  government expects that from 90 terawatt hours (TWh) up to 110 TWh of hydrogen will be needed by 2030. In order to cover part  of  this  demand,  Germany  plans  to  deploy up  to  5  GW  of  hydrogen  generation  capacity using water electrolysers coupled to onshore and offshore  wind  farms  by  2030,  with  this  rising  to 10 GW in total by 2035-2040. This corresponds to 14 TWh of green hydrogen production and would require 20 TWh of renewables.

German industry is highly dependent on hydrogen supplies, with more  than 80 TWh  of green hydrogen expected to be needed for GHG-neutral steel production by 2050. In addition, 22 TWh of demand  is  expected  from  German  refinery  and ammonia production. The EUR 130 billion (about USD  165 billion) economic recovery package proposed  as  a  response  to  the  COVID-19  crisis includes EUR  9  billion (USD  11.4 billion) for hydrogen, out of which, specifically, EUR 2 billion (USD 2.5 billion) will be targeted for international partnerships.  Germany  already  collaborates  with countries in North Africa and countries as far away as Australia, in view of the potential global market that can be developed in future.

5

Japan: This  was  the  first  country  to  adopt  a 'basic hydrogen strategy' and with specific plans to  become  a  'hydrogen  society'.  The  Japanese strategy  primarily  aims  to  achieve  cost  parity with  competing  fuels,  such  as  gasoline  in  the transportation sector or liquefied natural gas (LNG)  in  power  generation.  The  strategy  also covers the entire supply chain, from production to downstream market applications.

Given  limited  natural  resources  and  limited  land availability,  hydrogen  import  plays  a  key  role  in the  Japanese  strategy.  The  approach  has  been to  pursue  parallel  demonstration  projects  with multiple  sources,  hydrogen  carriers  and  enduse sectors  to  derisk  future  imports  and  increase the  flexibility  of  supply.  There  are  projects  with Australia  (coal  with  CCS  and  liquid  hydrogen 5 ), Saudi Arabia (oil and ammonia), Brunei (gas and liquid  organic carriers) and Norway (hydropower and liquid hydrogen). Japan's strategy could have a  positive  global  impact  and  contribute  to  the creation of new synergies regarding international energy  trading  and  business  cooperation.  These will be crucial in driving development and making technologies  more  affordable.  According  to  the roadmap  of  the  Japanese  Ministry  of  Economy, Trade and Industry (METI), Japan expects hydrogen technologies to become profitable by 2030. METI has set specific targets 6 for green  hydrogen  in  terms  of  electrolyser  cost (USD 475/kW),  efficiency  (70%,  or  4.3 kWh  per normal cubic metre [Nm 3 ]) and finally production cost (USD 3.3/kg) by 2030.

Morocco: In June 2020, Morocco signed a partnership agreement with Germany that aims to develop the production of green hydrogen and to set  up  related  research  and  investment  projects. The agreement represents the strong will of both countries  to  move  forward  in  the  development of  renewable  energies  and  their  commitment  to sustainable economic development, while making environmental protection a priority.

Two initial projects were announced in the declaration of intent. First, the 'Power-to-X' project  proposed  by  the  Moroccan  Solar  Energy Agency  (MASEN)  for  the  production  of  green hydrogen  and  the  establishment  of  a  research platform for this energy source. The second project  covers  knowledge  transfer,  which  is  one of the core activities of the 'Green Hydrogen and Applications' platform from the Research Institute on  Solar  Energy  and  New  Energies  (IRESEN). Morocco and Germany's plans are to develop the first  industrial green gas production plant on the African continent. The industrial hydrogen plant to be built in Morocco is expected to transform the country's renewable energy sector and thus reduce carbon dioxide emissions by 100 000 tonnes per year.

The Netherlands: The Ministry of Economic Affairs and  Climate  Policy  presented  the  government strategy on hydrogen in March 2020. With this, the Dutch government has underlined its ambitions to use its unique position to develop a strong position for the country in the hydrogen market.

In this strategy document, the Dutch government elaborates on the necessity of developing a clean hydrogen  economy,  on  the  role  of  hydrogen  in the energy transition and on its policy agenda in respect of the hydrogen market. The government notes that a completely sustainable energy supply in  2050  requires  that  at  least  30%  and  up  to 50% of final energy consumption be via gaseous energy carriers. Biogas and hydrogen are gaseous energy  carriers  which  can  be  produced  CO free, 2 but the government notes that there will not be sufficient biogas available, which makes hydrogen indispensable  for  meeting  the  expected  demand for  CO free  gas.  The  government  states  that  the 2 Netherlands  is  in  a  unique  position  to  develop large-scale hydrogen  infrastructure, specifically for the port of Rotterdam. Towards 2030, there is a desire from the industry to connect energy related clusters in order to scale-up electrolytic hydrogen production. In consultation with industrial clusters, the government will provide guidance with regard to the precise locations of electrolysers through its Main Energy Infrastructure Programme.

Portugal: Portugal has some of the best renewable resources in the world, setting a record of USD 13.1/MWh for solar in August 2020. As such, the country's  strategy  focuses  only  on  green hydrogen.  Targets  for  2030  include  an  explicit goal for electrolysers (2 GW-2.5 GW) and various blending and  quotas  that can drive demand uptake: 10%-15% blending in the gas grid; 2%-5% green hydrogen for industry; 1%-5% for transport, 3%-5%  for  shipping  and  1.5%-2%  in  final  energy demand. Hydrogen deployment is in line with the broader energy strategy that is part of the National Energy and Climate Plan, although this was issued just  before  the  EU  2030  GHG  reduction  target was raised from 40% to 55%, which would mean a more ambitious plan is expected in its revision. Deployment is also in line with climate neutrality by 2050.

The strategy foresees investments in the order of EUR 7 billion by 2030 (mostly from private capital). There are three phases of implementation: 20202023  for  setting  up  the  regulatory  framework and  the  governance  system;  2024-2030  as  a consolidation  phase  and  project  development; 2030-2050 for the growth of the market. Some of the shortterm measures the government will take to fulfil the strategy include: support mechanisms for  the  production  of  green  hydrogen;  financial resource guarantees; and a supportive regulatory framework.  Already,  in  August  2020,  hydrogen was included  in  the  guarantees  of  origin  system for  renewable  gases,  as  part  of  these  measures. Portugal has also signed a memorandum  of understanding with the Netherlands for large-scale trading of hydrogen. The 'Green Flamingo' project covers the export from the Port of Sines in Portugal to  the  Port  of  Rotterdam  in  the  Netherlands. The project has a size of 1 GW of electrolysis and requires an investment of EUR 57 billion (including the renewable capacity).

GREEN  HYDROGEN

COST REDUCTION

## 2. ELECTROLYSER TECHNOLOGY CHARACTERISATION

-  The electrolyser is composed of the stack (where the actual splitting of water into hydrogen and oxygen takes place) and the balance of plant, which comprises power supply, water supply and purification,  compression, possibly electricity and hydrogen buffers and hydrogen processing. Both components are important for the cost, since they have similar cost shares. The largest potential for near term cost reduction is in this balance of plant, while RD&amp;D is required to reduce stack cost and increase its performance and durability, as trade offs among these are significant.

## KEY POINTS

-  The flexibility of alkaline and PEM stacks is enough to follow fluctuations in wind and solar. The flexibility of the system is limited, however, by the balance of plant ( e.g. the compressors) rather than the stack. Furthermore, flexibility in the very short term time scales involved ( i.e. sub-second) is not the key value proposition for electrolysers, as their key system value lies in bulk energy storage. This effectively decouples variability of generation from stability of hydrogen and power to X (PtX) demand through hydrogen storage in gas infrastructure ( e.g. salt caverns, pipelines) and liquid e-fuels storage.
-  There  is  no  single  electrolyser  technology  that  performs  better  across  all  dimensions.  The future technology mix will depend on innovation and competition among key technologies and manufacturers, leading to technological improvements and a better fit for different technologies and system designs in each specific application.
-  Water and land use do not represent barriers to scaling up. In places with water stress, the source of water for hydrogen production should be explicitly considered in the strategies and further elaborated in project planning. Where access to sea water is available, desalination can be used with  limited  impact  on  cost  and  efficiency,  potentially  deploying  multi-purpose  desalination facilities to provide local benefits. A 1 GW plant could occupy about 0.17 square kilometres (km 2 ) of land, which means 1000 GW of electrolysis would occupy an area equivalent to Manhattan (New York).
-  Improving  the  performance  of  the  electrolyser  stack  in  one  dimension  usually  goes  along with  reduced performance in other parameters (efficiency, cost, lifetime, mechanical strength and manufacturing). This leads to trade offs to be tackled through innovation in materials and manufacturing,  leading  to  a  set  of  specific  system  designs  tailored  to  different  applications in  the  future.  Potential  breakthroughs  in  technology  development  can  be  disruptive  in  terms of  accelerating  cost  reductions  for  the  stack,  while  for  the  balance  of  plant,  it  is  more  about economies of scale, standardisation of design and supply chains, and learning-by-doing.

Water  electrolysers  are  electrochemical  devices used to split water molecules into hydrogen and oxygen by passage of an electrical current. They can be fragmented in three levels (see Figure 4):

-  The cell is the core of the electrolyser and it is  where  the  electrochemical  process  takes place. It is composed of the two electrodes (anode  and  cathode)  immersed  in  a  liquid electrolyte or adjacent to a solid electrolyte membrane, two porous transport layers (which  facilitate  the  transport  of  reactants and  removal  of  products),  and  the  bipolar plates that provide mechanical support and distribute the flow.
-  The stack has a broader scope, which includes multiple  cells  connected  in  series,  spacers (insulating  material  between  two  opposite electrodes), seals, frames (mechanical support) and end plates (to avoid leaks and collect fluids).
-  The system level (or balance of plant) goes beyond  the  stack to include equipment for  cooling,  processing  the  hydrogen  ( e.g. for purity and compression), converting the  electricity  input  ( e.g. transformer  and rectifier), treating  the  water  supply  ( e.g. deionization) and gas output ( e.g. of oxygen).

Purified water is fed into the system using circulating  pumps,  or  also  by  gravity.  The  water then reaches the electrodes by flowing through the bipolar  plates  and  through  the  porous  transport layers.  At  the  electrode,  the  water  is  split  into oxygen and hydrogen, with ions (typically H+ or OH-) crossing though a liquid or solid membrane electrolyte. The membrane or diaphragm between both electrodes is also responsible for keeping the produced gases (hydrogen and oxygen) separated and avoiding their mixture. This general principle has  remained  the  same  for  centuries,  but  the technology  has  evolved  since  William  Nicholson and Anthony Carlisle first developed it in 1800 (see Box 1).

Figure 4. Basic components of water electrolysers at different levels.

<!-- image -->

Based on IRENA analysis.

## Box 1. A brief look at the historical development of electrolysers

Electrolysers  have  been  known  for  over  two  centuries.  While  the  fundamental technology has remained the same (see Figure 5), different trends have affected its development, with these  splitting the period into roughly five generations.

1st generation (1800-1950): Electrolysers were mainly used for ammonia production using hydropower (low-cost electricity). By 1900, there were more than 400 industrial electrolysers in operation (Santos, Sequeira and Figueiredo, 2013). Electrolysers were used in Norway, Peru, Zimbabwe and Egypt for this purpose. Alkaline electrolyser was the only technology used. They operated at atmospheric pressure, using concentrated corrosive basic solutions ( e.g. potassium hydroxide [KOH]) and asbestos was used as gas separators (called diaphragms). Asbestos can pose large health hazards, but this was not known until late in the 20th century, when asbestos started to be replaced by other materials (such as ZIRFON®). While initially there were no good alternatives, composite zirconium oxide (ZrO2) separators became the trend from mid-century. At the end of this generation, in 1948, Lonza (later IHT) was the first company to introduce pressurized  alkaline  electrolyser  systems.  Electrolysers  were  also  used  for  chlorine production, which uses the same electrochemical principle, but uses high concentrate sodium chloride in water as raw material and produces hydrogen as a by-product. This was an important application of electrolysis from the beginning of the 19th century. 1

Figure 5. Challenges and technological breakthroughs for each of the generation of electrolysers.

<!-- image -->

Based on IRENA analysis.

7

## Box 1. A brief look at the historical development of electrolysers

2nd generation (1950-1980): This  generation  was  defined  by  a  polymer  chemistry breakthrough achieved in the last few years of the previous generation. In 1940, Dupont discovered a material  that had both excellent thermal and mechanical stability, as well as ionic properties (meaning good transport properties for protons). This was the basis for PEM electrolysers. PEM cells could be easily fed with pure water, instead of caustic solutions, as in alkaline systems, which provided a considerable reduction of system complexity, footprint, higher efficiencies and power densities. General Electric was one of the pioneers in developing PEM electrolysers, later joined by Hamilton Sundstrand in the United States and Siemens and ABB in Germany. Deployment and learning for PEM electrolysers were mainly driven by spaceship programs ( e.g. Gemini) and military life-support applications in submarines.

3rd generation (1980-2010): With the space race over, other business opportunities had to be found for PEM electrolysers. This required drastically simplifying the design, decreasing the cost and increasing the scale of the stacks to a few hundred kW. A higher system efficiency, lower capital costs and durability beyond 50 000 hours were the result of these changes. On the alkaline side, large units coupled to hydro-power plants had to be re designed to much smaller pressurised stacks, in order to introduce these into applications with less demand for hydrogen.

4th generation (2010-2020): Three trends characterise this generation. First, PV and wind installed capacity grew over 14 and 3 times respectively over this period, with costs dropping by 82%, 47% and 39% for PV, onshore wind and offshore wind, respectively (IRENA, 2020a). This made electricity, the main cost-component for green hydrogen, much cheaper, improving the business  case  for  green  hydrogen.  Second,  there  has been the central role that climate change has taken in the political agenda. This has created support for decarbonising sectors other than power. Third, is the ever increasing capacity of advanced electrolyser stacks, leading to lower capital expenditure (CAPEX) for electrolysers, allowing green hydrogen to move up the energy policy agenda.

5th generation (post-2020): This  period is expected to take electrolysis from niche to  mainstream,  from  MW  to  GW  scale,  from  potential  to  reality.  The  goals  for  this period include a lower (&lt; USD 200/kW) cost, high durability (&gt; 50 000 hours) and a high (approaching 80% LHV) efficiency. This will require economies of scale, a larger manufacturing capacity and technological breakthroughs through research.

## 2.1 ELECTROLYSER TECHNOLOGIES

The principle of water electrolysis is simple, yet it allows the construction of different technological variations based on various physicalchemical and  electrochemical aspects. Electrolysers are typically divided into four main  technologies. These are distinguished based on the electrolyte and temperature of operation, which in turn  will guide  the  selection  of  different  materials  and components.

Solid oxide and anion exchange membrane (AEM) have  high  potential,  but  are  much  less  mature technologies,  with  only  a  few  companies  and original equipment manufacturers (OEMs) involved in their manufacture and commercialisation. These are mostly based in Europe.

The principles of all commercially available types of electrolysis cells are displayed in Figure 6. Many variations within each technology exist, with most radical  differences  being  related  to  cell  design, variation within components, and degree of technology maturity.

There are four types of electrolyser: Alkaline and polymer electrolyte membrane (PEM) are already commercial, while anion exchange membrane (AEM) and solid oxide, now at lab scale, promise a major step forward

Figure 6.

Different types of commercially available electrolysis technologies.

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

Hence, the basic principle of a water electrolysis cell consists of two electrodes separated by an electrolyte. The electrolyte is the media responsible for transporting the generated chemical charges (anions (-) or cations (+)) from one electrode to the other. In the alkaline type, the electrolyte  responsible  for  transporting  the  OHanions is typically a highly concentrated potassium hydroxide solution. The electrodes and produced gases are physically separated by a porous inorganic  diaphragm  (also  called  a  separator) that  is  permeable  to  the  KOH  solution.  In  PEM, AEM, and solid oxide electrolysers, the electrodes are separated by an electron-insulating solid electrolyte,  which  is  responsible  for  transporting ions  from  one  electrode  to  the  other  and  at  the same  time  physically  separating  the  produced gases. For these, there is no need to add a liquid electrolyte solution, and the ion transport happens within the PEM, AEM or solid oxide component.

Table 1 summarizes the operating conditions and the most important components for the four types of electrolysers. The coloured cells represent conditions or components with significant variation  from  different  manufacturers  or  R&amp;D institutions. In this respect, it also gives a sense of the less mature technologies, which is clear for the AEM and solid oxide types.

Table 1. Characterisation of the four types of water electrolysers.

|                                      | Alkaline                                 | PEM                                      | AEM                                             | Solid Oxide                       |
|--------------------------------------|------------------------------------------|------------------------------------------|-------------------------------------------------|-----------------------------------|
| Operating temperature                | 70-90 °C                                 | 50-80 °C                                 | 40-60 °C                                        | 700-850 °C                        |
| Operating pressure                   | 1-30 bar                                 | < 70 bar                                 | < 35 bar                                        | 1 bar                             |
| Electrolyte                          | Potassium hydroxide (KOH) 5-7 molL -1    | PFSA membranes                           | DVB polymer support with KOH or NaHCO3 1molL -1 | Yttria-stabilized Zirconia (YSZ)  |
| Separator                            | ZrO 2 stabilized with PPS mesh           | Solid electrolyte (above)                | Solid electrolyte (above)                       | Solid electrolyte (above)         |
| Electrode / catalyst (oxygen side)   | Nickel coated perforated stainless steel | Iridium oxide                            | High surface area Nickel or NiFeCo alloys       | Perovskite-type ( e.g. LSCF, LSM) |
| Electrode / catalyst (hydrogen side) | Nickel coated perforated stainless steel | Platinum nanoparticles on carbon black   | High surface area nickel                        | Ni/YSZ                            |
| Porous transport layer anode         | Nickel mesh (not always present)         | Platinum coated sintered porous titanium | Nickel foam                                     | Coarse Nickel-mesh or foam        |
| Porous transport layer cathode       | Nickel mesh                              | Sintered porous titanium or carbon cloth | Nickel foam or carbon Cloth                     | None                              |
| Bipolar plate anode                  | Nickel-coated stainless steel            | Platinum-coated titanium                 | Nickel-coated stainless steel                   | None                              |
| Bipolar plate cathode                | Nickel-coated stainless steel            | Gold-coated titanium                     | Nickel-coated Stainless steel                   | Cobalt-coated stainless steel     |
| Frames and sealing                   | PSU, PTFE, EPDM                          | PTFE, PSU, ETFE                          | PTFE, Silicon                                   | Ceramic glass                     |

Note: Coloured cells represent conditions or components with significant variation among different companies. PFSA = Perfluoroacidsulfonic; PTFE = Polytetrafluoroethylene; ETFE = Ethylene Tetrafluorethylene; PSF = poly (bisphenol-A sulfone); PSU = Polysulfone; YSZ = yttriastabilized zirconia; DVB = divinylbenzene; PPS = Polyphenylene sulphide; LSCF = La 0.58 Sr 0.4 Co 0.2 Fe 0.8 O 3 -δ ; LSM = (La 1-x Sr ) x 1-y MnO 3 ; § = Crofer22APU with co-containing protective coating.

Based on IRENA analysis.

## 2.2 CELL LEVEL FOR EACH TYPE OF ELECTROLYSER

Alkaline electrolysers: These have a simple stack and  system  design  and  are  relatively  easy  to manufacture. Currently, they have electrode areas as  high  as  3  square  metres  (m2).  They  operate with high concentrate KOH (typically 57 moles of solute per litre of solution [mol*L -1 ]) as electrolyte, robust  ZrO   based  diaphragms  and  nickel  (Ni) 2 coated stainless-steel for the electrodes. The ionic charge carrier is the hydroxyl ion OH-, with KOH  and  water  permeating  through  the  porous structure of the diaphragm to provide functionality for  the  electrochemical  reaction.  This  allows  the intermixing  of the produced  gases  (hydrogen and oxygen - H  and O ) that are dissolved in the 2 2 electrolyte, limiting lower power-operating range and the ability to operate at higher pressure levels.

these conditions. Titanium-based materials, noble metal catalysts and protective coatings are necessary, not only to provide long-term stability to  cell  components,  but  also  to  provide  optimal electron  conductivity  and  cell  efficiency.  These requirements have caused PEM stacks to be more expensive  than  alkaline  electrolysers.  PEMs  have one  of  the  most  compact  and  simplest  system designs, yet they are sensitive to water impurities such  as  iron,  copper,  chromium  and  sodium  and can suffer from calcination. Today, electrode areas are quickly approaching 2 000 square centimetres (cm2), yet this is still far from future concepts of large MW stack units using single stack concepts. Last  but  not  least,  the  reliability  and  lifetime characteristics of large-scale, MW PEM stacks still have to be validated.

To  prevent  this,  thicker  (0.252  millimetre  [mm]) diaphragms  are  used,  but  this  creates  a  higher resistance and  lower efficiencies. Spacers  are sometimes included by some manufacturers between  electrodes  and  diaphragms  to  further avoid the intermixing of gases. These thick diaphragms  and  added  spacers  result  into  high ohmic resistances across the two electrodes, drastically  reducing  current  density  at  a  given voltage.  Today´s  advanced  designs,  using  zerogap electrodes, thinner diaphragms and different electrocatalyst concepts to increase current density,  have  already  reduced  their  performance gap  in  comparison  to  PEM  technology.  On  the other hand, classic and sturdy alkaline designs are known to behave very reliably, reaching lifetimes above 30 years.

## Polymer Electrolyte Membrane (PEM) electrolysers:

These use a thin (0.2 mm) PFSA membrane and electrodes with advanced architecture that allows achieving higher efficiencies ( i.e. less  resistance). The  perfluorosulfonic  acid  (PFSA)  membrane  is also  chemically  and  mechanically  robust,  which allows  for  high  pressure  differentials.  Thus,  the PEM cells  can  operate  at  up  to  70  bar  with  the oxygen side at atmospheric pressure.

The  acidic  environment  provided  by  the  PFSA membrane, high voltages, and oxygen evolution in the anode creates a harsh oxidative environment, demanding the use of materials that can withstand

## Each technology has its own

challenges , from critical materials to performance, durability and maturity; there is no clear winner across all applications, which leaves the door open for competition and innovation driving costs down

Solid oxide electrolysers (SOEC): These operate at high (700-850°C) temperatures. This enables: the favourable kinetics that allow the use of relatively cheap nickel electrodes; electricity demand decreases  and  part  of  the  energy  for  separation is provided through heat (waste heat can be used and apparent efficiencies based on electricity can be higher than 100%); the potential for reversibility (operating  as  fuel cell and  electrolyser) 8 ; coelectrolysis  of  CO   and  water  to  produce  syngas 2 (which is the basic building block for the chemical industry). On the downside, thermo-chemical cycling, especially under shutdown/ramping periods,  leads  to  faster  degradation  and  shorter lifetimes. Other issues related to stack degradation include:  challenges  related  to  sealing  at  higher differential pressure; electrode contamination by  silica  used  as  sealants;  and  other  additional contaminant  sources  from  piping,  interconnects and sealing. SOECs are today only deployed at the kW-scale,  although  some  current  demonstration projects have already reached 1 MW.

Anion  Exchange  Membranes  (AEM): This  is  the latest technology  with  only  a  few  companies commercialising it, with limited deployment. AEM's potential  lies  in  the  combination  of  a  less  harsh environment  from  alkaline  electrolysers  with  the simplicity and efficiency of a PEM electrolyser. It allows the use of non-noble catalysts, titanium-free components,  and,  as  with  PEM,  operation  under differential  pressure.  The  reality,  however,  is  that the AEM membrane has chemical and mechanical stability  problems,  leading  to  unstable  lifetime profiles. Moreover, performance is not yet as good as expected, mostly due to low AEM conductivity, poor  electrode  architectures  and  slow  catalyst kinetics.  Performance  enhancement  is  typically achieved by tuning membrane conductivity properties, or by adding a supporting electrolyte ( e.g. KOH, or sodium bicarbonate [NaHCO ]). Such 3 tuning could lead to decreased durability, however. The OH -  ion is intrinsically three-fold slower (lower conductivity) than H +   protons  within  PEM,  which forces  AEM  developers  to  either  make  thinner membranes, or ones with higher charge density.

## 2.3 SYSTEM LEVEL FOR EACH TYPE OF ELECTROLYSER

## System Components

Alkaline systems: As  for  the  other types, alkaline electrolysers  require  recirculating  the  electrolyte (KOH)  into  and  out  the  stack  components.  This creates a pressure  drop  that  requires specific pumping characteristics and negatively affects the efficiency,  which is typically less than 0.1% of the stack power consumption, but can be much higher for other manufacturers. Some alkaline systems are also operated without pumping peripherals. After leaving the stack, this alkaline solution needs to be separated from the gases produced. This is done in gas-water separators that are placed above the stack at a given height, and KOH/water flows back to  the  stack.  The  water  phase  can  be  removed at the bottom and the gas phase at the top (see Figure 7). The water column within the separator also serves as a buffer storage for changing load specifications.

The water management system regulates the filling level of each gas separator, and water permeation via the diaphragm needs to be considered.

Figure 7. Typical system design and balance of plant for an alkaline electrolyser.

<!-- image -->

Note: This configuration is for a generic system and might not be representative of all existing manufacturers.

Based on IRENA analysis.

Water can be transported to the anode side by the solvated species and charges. A mixing pipe is also installed between the anode and cathode water/gas separator to balance the OH- charges consumed/ produced along with the electrochemical reaction.

Equipment around the electrolyser is affected by technology choice. There needs to be an integrated design for various components to achieve a low cost while satisfying demand requirements

PEM systems are much simpler than alkaline. They typically require the use of circulation pumps, heat exchangers, pressure control and monitoring only at the anode (oxygen) side. At the cathode side, a gas-separator, a de-oxygenation component to remove  remnant  oxygen  (typically  not  needed for  differential  pressure),  gas  dryer,  and  a  final compressor step are required (see Figure 8).

The requirement to balance the charges between anode and cathode makes the stack more challenging  to  operate  at  differential  pressures, as in PEM. Nevertheless, pressurised operation is possible  and  available  in  designs  with  pressures as high as 200 bar. But such operations are made by  keeping  both  sides  of  the  stack  (hydrogen and  oxygen)  at  high  pressure  and  contained  in a high-pressure vessel. For the high-pressure configuration,  more  resistance  cell  frames  and balance of plant (BoP) materials are needed, which impact on CAPEX.

More importantly, PEM systems have more design choices:  atmospheric,  differential,  and  balanced pressure (design is fixed to a single one); reducing costs, system complexity, and maintenance. Under a balanced pressure operation, the anode and cathode are designed to run under the same pressure  level.  Atmospheric  pressure  operation (&lt; 1 standard  atmosphere  [ atm])  represents  a case  of  constant  pressure  operation  mode.  The PEM  membrane  electrolyte  allows  for  operation under  differential  pressure,  typically  30 bar to 70 bar. This, however, requires a thicker membrane to improve the mechanical stability and decreases gas permeation, which reduces efficiency. It could also  require  an  additional  catalyst  to  re-convert any  hydrogen,  which,  due  to  higher  pressures, would now permeate more, back to water.

## Figure 8. Typical system design and balance of plant for a PEM electrolyser.

<!-- image -->

Note: This configuration is for a generic system and might not be representative of all existing manufacturers.

Based on IRENA analysis.

AEM  electrolysers  have  similar system  design concepts to that of PEM electrolysers (see Figure 9).  Due  to  the  low  maturity  of  this  technology, however, there is limited information on the challenges  related  to  high  differential  pressure operation. At this early stage, improvements are  expected  in  the  mechanical  stability  of  AEM

membranes, gas purity, their ability to withstand high pressure differentials and their greater power range compared to alkaline. AEM electrolysers are still  limited  to  a  much  narrower  range  of  power input  in  comparison  to  PEM  electrolysers.  The limitation, therefore, is not in the stack itself, but in the sizing of the balance of plant.

Figure 9. Typical system design and balance of plant for an AEM electrolyser.

<!-- image -->

Note: This configuration is for a generic system and might not be representative of all existing manufacturers.

Based on IRENA analysis.

Figure 10. Typical system design and balance of plant for a solid oxide electrolyser.

<!-- image -->

Note: This configuration is for a generic system and might not be representative of all existing manufacturers.

Based on IRENA analysis.

Solid oxide electrolysers can be coupled with  heat-producing  technologies  for  a  higher system  efficiency,  as  the  electrolysis  of  water is increasingly endothermic with increasing temperature. Therefore, energy demand is rapidly reduced, due to the Joule heating of the cell, and then utilised in the water splitting reaction at high temperatures. When the cell runs endothermically, heat for water vaporisation can be supplied from other sources, such as waste-heat from industry or concentrated  solar  power  plants.  One  important and fully renewable option is coupling SOECs with concentrated solar power, which could supply both electricity and the heat to the SOEC electrolyser. A  typical  system  configuration  for  solid  oxide  is shown in Figure 10.

## Hydrogen processing unit: Compression

Hydrogen  from  the  electrolyser  is  in  gaseous form,  conventionally  from  atmospheric  pressure to 30 bar, while higher pressures are possible. To facilitate  hydrogen  transport,  a  lower  volume  is needed. This means either increasing the pressure, liquefying  the  gas 9 ,  or  converting  it  for  liquid  organic hydrogen carriers. Compression can make a large difference.  Going  from  atmospheric  to  70  bar  (a typical  pressure  for  transmission  pipelines)  can already reduce the gas volume by a factor of 65. Compressing it to 1 000 bar (a typical pressure for storage in tanks) can reduce the volume by a factor of 625 compared to atmospheric, and liquefaction by a factor of 870 (BNEF, 2019).

Compression  can  be  done  in  mainly  three  ways: using a standard separate compressor; by changing the  operating  pressure  of  the  electrolyser;  using a separate electrochemical device. From the perspective of equipment  count and process complexity, doing both the compression and the hydrogen  production  in  the  electrolyser  might be an attractive option. The downsides, however, are  the  design  of  the  electrolyser  to  be  able to  withstand  a  higher  pressure  (cost)  and  the potential increase in gas permeation through the membrane (efficiency and durability). With higher pressures in the electrolyser, the permeation losses increase,  which  means  more  hydrogen  ends  up on  the  oxygen  side  rather  than  on  the  product side, which in turn translates into a higher energy consumption for the same production rate and a higher safety risk for the anode (see Figure 11).

Energy losses for compression in a pressurized electrolyser as a function of

Figure 11. delivery pressure and thickness of membrane.

<!-- image -->

Source: Babic et al, 2017.

For  PEM  electrolysers,  there  are  two  modes  of pressurized  operation:  balanced  and  differential. In the balanced mode, there is a similar pressure on the anode and cathode sides. This means the membrane,  spacers  and  porous  transport  layer can all be thinner given the lower requirement for mechanical  strength.  This  in  turn  translates  into a higher efficiency, since there is less internal cell resistance. The downside of the pressurised mode is that the entire equipment needs to be designed for  a  higher  pressure,  resulting  in  a  penalty  cost and safety issues due to the pressurised oxygen. In the differential mode, only the anode is subject to the higher pressure, as it receives all the pressure from  the  cathode  side,  where  the  production  of pressurised hydrogen occurs.

Figure 12. Energy losses for the multi-stage mechanical compression of hydrogen.

<!-- image -->

Min

Max

Based on IRENA analysis based on BNEF, 2019.

From  an  efficiency  perspective,  compressing  to 30 bar  in  the  electrolyser  (or  even  100  bar,  depending on  the  specific  membrane)  has  a  relatively  small penalty  on  efficiencies  and  additional  costs  for pressure vessels, while this region is the one with the  steepest  losses  in  mechanical  compression 10 (see Figure 12). Therefore, it makes  sense  to perform this step with the electrolyser to generate the largest savings for the system and compress to the final delivery pressure in a separate compressor. This means PEM, or pressurised alkaline, is preferred from  this  perspective.  Otherwise,  the  additional energy penalty for compressing from 1 to 30 bar

(typical  operating  pressures  for  the  alkaline  and PEM electrolysers  respectively)  is  about  3.5%-4% equivalent  of  hydrogen  lower  heating  value  (this energy is used as electricity instead of directly from the hydrogen compressed).

Yet, efficiency is only one dimension. From a cost perspective,  for  a  100-MW  electrolyser,  a  compressor of about 4 MW would be needed to take the stream from  a  typical  atmospheric  alkaline  electrolyser to the typical operating pressure of a pressurised electrolyser  (30  bar).  This  size  already  benefits from  economies  of  scale  and  only  adds  about

USD  0.07/kg  H .  For  higher  pressures,  the  cost 2 penalty would be the same for both technologies. This price differential translates to about USD 50/kW 11 ,which represents the cost differential threshold for atmospheric alkaline stacks to be on a par with 30 bar (PEM) stacks. According  to  Saba  (Saba  et  al.,  2018),  the  cost increase  for  changing  the  design  pressure  from 1 bar to 15 bar is about USD 150/kW for an alkaline electrolyser.  Another  factor  affecting  cost  is  the type of design for the PEM electrolyser. Differential pressure mode  is preferable, as it eliminates balance-of-plant high-pressure components  on the oxygen side. Stack costs are at the same time increased,  however,  since  stack  components  on the oxygen side need to sustain the set operating pressure. A tradeoff sits between 30 bar and 70 bar, depending on each business case and application. Compression also has a cost associated with the disposal  of  the  compressor  condensate,  which can be as high as USD 1 000 per day for a 20 MW system.

Compression costs are relatively small compared to overall production costs, even when considering operation at atmospheric pressure, with further benefits of a simpler design with cheaper materials for the lower pressures

There are two other factors to consider. The first one is scale. Large compressors are more efficient than  small  ones  and  will  result  in  a  smaller  cost addition  to  the  hydrogen  produced.  Hence,  as the scale increases, it tends to favour mechanical compression  over  electrochemical.  The  second factor is final delivery pressure. In case a pressure higher than the operating pressure of the electrolyser is needed, mechanical compression will be needed, in any case. In this instance, making the compressor larger and being able to achieve a cost reduction in the electrolyser, might be attractive.

## Power supply system

Power supply for electrolysers represents a significant cost component (20%-30% of the total), yet there is a high potential for cost reductions (see Chapter 2, Section 6). For small-scale electrolysis plants,  power  supply  is  often  either  part  of  the package sold by electrolyser manufacturers, or a custom design from engineering, procurement and construction (EPC) contractors for each individual facility. As  the  scale  of  the  facility increases, standard utility scale power supply systems become available  from  leading  manufacturers  of electrical equipment. This can significantly reduce cost  and  increase  the  performance of the power supply for electrolysers. Further optimisation can be achieved by careful system integration of different  components  in  the  electrolyser  facility, optimising the entire facility rather than individual components  and  leveraging  efficiency  gains  in different  parts  of  the  balance  of  plant,  including the power supply.

The water electrolysis industry is benefiting significantly from the improvements made in the solar industry, and the power supply also has an important role to play in maximising the efficiency of  the  electrolysis  facility.  While  the  electrolyser stack  has  a  linear  efficiency  decrease  with  the increase in output, due to the increase in voltage, rectifiers have very low efficiency at low load (Kim et al., 2013). Depending on the expected operating regime  ( e.g. fixed  output,  variable  input  driven directly by solar or wind), the sizing and design of the power supply can be optimised to maximise system efficiency, defined as the minimisation of efficiency  losses  from  power  input  to  hydrogen output at the required pressure. Optimised design affects not only the efficiency, but also the flexibility of the system, as discussed in Chapter 3, Section 5.

Power supply system cost can decline through economies of scale , standardised designs and participation of specialised electrical equipment suppliers instead of electrolyser manufacturers

## Water and land use for green hydrogen production

Green  hydrogen  production  uses  water  as  a  key feedstock and renewable electricity as an energy source  to  separate  hydrogen  and  oxygen  from water in an electrolyser.

Water, as pure as possible, is therefore a key input. While  the  purity  level  required  varies  depending on the technology, the cost of water purification is  marginal,  starting  from  desalinated  sea  water (well  below  USD  1/cubic  metre  (m 3 )  of  water (Reddy  and  Ghaffour,  2007)).  Impurities  in  the water,  however,  will  have  a  major  impact  on  the lifetime  of  the  electrolyser  stack  (see  Chapter  2, Section 4), which can in turn affect hydrogen cost by  increasing  the  annuity  of  the  electrolyser  in the cost of hydrogen. In addition to desalination costs,  the  need  for  any  water  treatment  in  the electrolyser stack requires additional costs (e.g. deioniser).  These  can  potentially  become significant, depending on the purity level required, but  are  still  of  low  impact  on  the  overall  cost of  hydrogen,  as  in  general  they  remain  around USD 1/m 3  (Hand, Guest and Cusick, 2019), or less than USD 0.01/kg H . 2

Water use is not barrier to scaling up electrolysis. Even in places with water stress, sea water desalination can be used with limited penalties on cost or efficiency

From  a  pure,  stoichiometric  perspective,  1 kg  of hydrogen requires 9 kg of water as input. Due to some inefficiencies in the process, however, taking into account the process of water demineralisation, with  typical  water  consumption,  the  ratio  can range between 18 kg and 24 kg of water per kilo of  hydrogen.  The  largest  water  consumption  is actually upstream and it is the highest when the electrolyser is coupled with PV. Water consumption for  green  hydrogen  from  PV  can  vary  between 22 and  126 kg of water  per  kg  of hydrogen depending  on  the  solar  radiation,  lifetime  and silicon  content  (Shi,  2020).  The  water  scarcity  is highly  specific  to  a  region  since  it  compares  the water  use  to  the  replenishment  of  water  in  the area,  so  local  impact  assessments  are  needed when  there  is  hydrogen  production  in  waterstressed  regions.  One  of  the  methods  to  assess the impact from water use at the midpoint level is the Available WAter REmaining (AWARE) method developed by a working group of the UNEP-SETAC Life Cycle Initiative (Mehmeti, 2018).

In terms of the impact of hydrogen production on water availability, this is clearly not an issue, as long as the assumption is that desalinated sea water is used. If freshwater is the preferred water source, a comparison can be made with current freshwater consumption for thermal power plants. Considering a  very  large  1 GW electrolyser,  operating  with  an efficiency of 75% for 8 000 hours per year, the annual hydrogen production would be 0.15 million tonnes of hydrogen and 3 million tonnes of water (assuming 20 kg  of  water  use  per  kilo  of  hydrogen).  This corresponds to the consumption of water of a small city  (around  70 000  inhabitants)  with  a  consumption of 45 m3 per inhabitant. The acceptability of this will depend on the water availability at the location of the plant, with desalination remaining a key option to be part of the design of the plant, especially in water-stressed regions. The water source for large scale  hydrogen  production  should  be  explicitly accounted for in hydrogen strategies, as the volumes  might  be  significant  for  water-stressed regions.  Desalination  can,  however,  be  deployed jointly  for  hydrogen  production  as  well  as  other uses  ( e.g. human  consumption  and  agriculture), with hydrogen production helping to increase water supply by driving the deployment of multi-purpose desalination facilities in water-stressed regions.

For  the expected  19  exajoules  (EJ)  of  green hydrogen  (approximately  160  megatonnes  [Mt]) in the Transforming Energy Scenario of the IRENA Global  Renewables  Outlook,  we  would  require around  3  billion  m 3 of  water  per  year  in  2050. This  is  0.08%  of  the  current  global  consumption of freshwater. As freshwater is used for a multiplicity of non-energy uses ( e.g. agriculture), a  better  comparison  is  the  current  consumption of thermoelectric power plants, which is significantly  higher:  for  instance,  the  estimated water  consumption  by  thermal  power  plants  in the  United  States  in  the  2030  reference  case was  5.8  billion  m   (IRENA,  2015).  Even  for  more 3 ambitious scenarios, where  decarbonisation  is

faster and hydrogen plays a larger role, the overall water demand would be relatively small compared to  global  water  consumption.  Additionally,  any green  hydrogen  produced  that  is  used  in  fuel cells for transportation purposes, or eventually reelectrification,  will  produce  ultra-pure  water  that could  be  recovered  where  economically  feasible, in particular, in stationary applications.

For the land area, there are no real projects of more than 100 MW in water electrolysis 12 (the largest one, as  of  November  2020,  is  20 MW,  in  Becancour, Canada).  Thus,  so  far,  land  area  estimates  rely on engineering estimates, rather than plot optimisation based on real experience. Yet, there are a couple of estimates available:

-  A study funded by the German government in 2014 estimated that a 100 MW electrolyser plant  would  occupy  about  6 300 m 2   (DLR, 2014).
-  Siemens estimated back in 2017 that a 300  MW  electrolyser  plant  would  occupy about  180  metres  (m)  x  80 m  (15 000 m 2 ) (Bolhuis, 2017).
-  ITM  estimated  in  2017  that  one  100 MW electrolyser would occupy about 40 m x 87 m (3 500 m 2 ), with the possibility of using multiple layout options to fit different applications and of replicating this easily by having a standardised design (Bourne, 2017).
-  In  2018,  McPhy  proposed  a  100 MW  facility (composed of five modules of 20 MW each) with a plot size of 4 500 m 2 (McPhy, 2018).

More recently, given the various multi-GW national strategies,  there  are  studies  looking  at  what  it could mean to have these multi-GW facilities. One study  comes  from  the  Institute  for  Sustainable Process  Technology  (ISPT)  in  the  Netherlands, which made a detailed bottom-up study for a 1 GW alkaline  and PEM plant (ISPT, 2020). As a result, the  maximum area requirements were 13 ha and 17 ha (0.13 km 2 -0.17 km 2 ) for a PEM and an alkaline electrolyser  plant  respectively,  with  the  potential to decrease the land requirements with compact designs of 8 ha and 10 ha respectively (see Figure 13 left for the plot size of an alkaline electrolyser). The  bulk  of  this  space  (65%-75%)  is  for  the electrolyser building and the electrical equipment ( e.g. switchgears and transformers), with the least space used by the hydrogen processing section.

To  put  these  numbers  in  perspective,  a  global capacity of 1 000 GW of electrolysers, which would be enough to replace the entire current pure and mixed  hydrogen  fossil-based  production,  would occupy a land area of the size of Manhattan, New York,  using  the  most  conservative  estimate  ( i.e. 0.17  km 2 ).  Another  reference  is  that  this  energy density of almost 7 500 MW/km 2  is almost 1 500 times larger than a relatively good onshore wind density  of  5 MW/km 2   (Enevoldsen  et  al.,  2019), which  means  the  electrolyser  would  only  be  a fraction of the space occupied by the renewable electricity input,  highlighting  the  need  to  use hydrogen  only  for  applications  that  are  hard  to electrify and reduce the upstream  renewable capacity needed to satisfy the same demand.

Figure 13.

Plot size for an alkaline 1-GW electrolyser plant (left) and for a 100-MW alkaline electrolyser from Thyssenkrupp (right).

Figure13

<!-- image -->

<!-- image -->

Based on IRENA analysis based on ISPT, 2020.

## 2.4 TRADE-OFFS TO CONSIDER IN THE DESIGN OF THE ELECTROLYSER

On the supply side,  the  prospects  for  green  hydrogen depend  on  the  performance  of  the  electrolyser. The  key  dimensions  that  R&amp;D  strategies  need  to address are:

-  The efficiency increase at the cell, stack, and system level (this reduces operational cost).
-  The  current  to  the  stack  is  directly  related to  cell  and  stack  capacity  and  therefore  to hydrogen production.
-  A durability  increase  to  more  than  100 000 hours for any developed system concept.
-  An  investment  cost  reduction  (both  stack and system).

These  four  dimensions  are  related  to  each  other, however, and improvement in one of them usually leads  to  a  poorer  performance  in  another.  For example, a thicker membrane  is  mechanically stronger and leads to longer lifetime profiles, but it also increases the resistance to the transport of charges,  which  in  turn  decreases  the  efficiency. While  the  longer  lifetime  results  in  a  lower  cost contribution  of  the  investment  component,  the lower efficiency results in a higher operating cost given  the  higher  electricity  consumption.  Figure 14 shows the positive or negative effect (arrows + colour)  some  of  the  independent  choices  during manufacturing  and  research  (green  boxes)  can have  on  each  dimension.  Another  two  important aspects are the use of more active catalysts that are  able  to  improve  efficiency  levels,  but  could have negative impact on durability.  One  example is ruthenium  catalysts,  which  are  more  active than  iridium,  but  suffer  from  long-term  stability. Moreover, any catalyst free of critical raw materials needs to be aimed at higher efficiencies, but this typically result in catalysts that are less robust and more prone to dissolution.

Figure 14. Trade-offs between efficiency, durability and cost for electrolysers.

<!-- image -->

Note: The arrows represent a direct impact or effect from the R&amp;D of a given material or component over each relevant dimension. CAPEX = capital expenditure; OPEX = operational expenditure.

The specific business case for the electrolyser will also affect the optimisation of these parameters. For example, an electrolyser that is coupled with PV  could  only  operate  typically  less  than  2 000 hours in a year, making the capital cost a critical parameter to tackle. With such limited operating hours, durability might be less of an issue, since a short operating lifetime still translates into a longer actual lifetime. This could lead to using materials that are cheaper, but degrade faster. This case is different to one where the electrolyser is coupled with  a  concentrated  solar  power  that  has  higher operating hours in a year, but that delivers a higher electricity price, making efficiency more important to reduce the operational cost.

Improving the performance of the electrolyser in one dimension usually goes along with reduced performance in other parameters. This leads to trade -offs during the innovation process instead of having a single best-performing design

Broadening  the  scope  and  looking  beyond  cost also influences the tradeoffs between these parameters. Considering the revenue side could  lead  to  changing  the  operating  strategy of  the  electrolyser.  For  instance,  bidding  in  the balancing  market  to  complement  the  revenues from hydrogen sales. This could have a negative effect on durability, since it could result in faster membrane degradation, requiring a more frequent replacement of membranes and consequently all other related components, but could also slightly reduce the contribution of the capital cost given increased  operating  hours  ( i.e. times  when  the electrolyser  would  not  be  operating  based  on hydrogen  sales  only,  but  doing  so  based  on  the additional revenues  from  balancing). Similarly, increasing the current operating density can create  higher  production  flow  at  the  expense  of faster degradation.

## Lifetime aspects related to materials and components

The  lifetime of electrolyser technologies is a function of the cumulative current passing through  the  stack,  which  can  be  represented by the number of full load hours 13 s  well  as  the a number of operating hours - the number of hours during which the facility is on, regardless of load operating levels.

Alkaline  electrolysers  are  the  most  robust,  with proven  lifetimes  of  over  30  years.  Some  of  the factors that affect their lifetime are:

-  Gas permeation: The diaphragm is exposed to a continuous flow of KOH, gas permeation, and local hot spots created by the deposition of  impurities  on  electrode  coatings.  This eventually  causes  small,  pin-hole  failures that  increase  in  size  over  time  and  lead  to gas contamination. Since the stacks usually have  large  areas,  reaching  up  to  3  m  in diameter  and  hundreds  of  cells,  inspecting is not a feasible option. Instead, the oxygen stream is monitored and when the hydrogen concentration  reaches  2%  on  the  oxygen side, the stacks are sent for repair or disposal. One solution is to use polyphenylene sulphide fabric diaphragms. This negatively impacts the hydrogen production efficiency, but  has  a  positive  effect  on  lifetime,  since it limits gas  permeation.  These  negative aspects  have  been  constantly  changed  for new generation diaphragms and under low pressure  operation,  and  a  few  companies have  claimed  to  have  already  solved  these issues.
-  Electrodes: Deactivation of electrodes on the cathode and anode sides have been  prevented  in  some  systems  by  using small  idle  protective  currents  within  a  few microamperes of current to avoid reversal of potentials of cathodes, potentially leading to less active electrodes overtime.

-  Nickel  alloys: Highly  caustic  KOH  at  high concentrations requires inorganic ZrO 2 diaphragms, nickel- and zincbased materials. Nickel alloys need to be free from chromium and  iron,  which  could  leach  and  end  up contaminating the electrodes, which reduces efficiency and durability.
-  Water  impurities: Higher  degradation  due to  low-quality  water  circulation  has  been observed,  so  the  lifetime  of  the  plant  is affected  as  a  function  of  operating  hours. Many  elements,  including  the  diaphragm, catalysts,  and  other  components,  can  be adversely affected by water impurities such as  iron  (Fe),  chromium  (Cr),  copper  (Cu), silicon  (Si),  aluminium  (Al)  and  boron  (B).

PEM electrolysers have reported lifetimes of more than 50 000 hours. Some of the factors affecting their lifetime are:

-  Operating  conditions: Higher  temperature, pressure  and  current  density  can  have  a negative impact on lifetime. Mild conditions are 50-60°C, 10 bar and 2 ampere per square centimetre  (A/cm2)  respectively,  while  the next  generation  PEM  is  expected  to  run  at more  demanding  conditions  (80°C,  70 bar and 5 A/cm2). Some solutions to handle these conditions are overdesigned stacks with thick membranes, high catalyst loadings and protective  coatings  over  porous  transport layers (PTLs) and bipolar plates.
-  Variable load: Electrolysers were previously operated with almost constant power supply to  satisfy  a  fixed  demand.  The  coupling with variable renewable electricity will lead to  a  variable  load,  which  results  in  voltage fluctuations that can potentially trigger additional  corrosion  of  stack  components and  reduce  durability.  Though  very  true  in PEM fuel cells, there is little evidence of this in PEM electrolysers.
-  Gas permeation: The membrane is subject to a large differential pressure (if it is operated under this) that negatively affects membrane mechanical stability. This also increases gas permeation,  which  can  potentially  lead  to
- further  degradation  issues.  A  measure  to tackle this is to use an additional catalyst to reconvert  the  permeated  hydrogen  (to  the oxygen side) back to water.
-  Anode  dissolution: Iridium  oxide  on  the anode can be prone to dissolution depending on  the  temperature,  voltage  and  electrode architecture. One solution is to use a larger amount  of  catalyst  (&gt;  5  milligrammes  per square centimetre [mg/cm2] or 2.5 grammes per  kilowatt  [g/kW])  and  additional  high loadings  of  precious  metals  in  protective layers over the stack components. The anodic PTL  uses  porous  titanium  with  a  thickness above  1  mm  to  support  the  membrane, especially under differential pressure. This  PTL  is  typically  coated  with  platinum (&gt;  1  mg/cm2  or  0.5 g/kW)  to  minimise  or mask the titanium oxidation.
-  Water impurities: Poor water quality is one of  the  main  reasons  for  stack  failure  for PEM  electrolysers.  Higher  degradation  due to  water  circulation  is  seen  at  partial  load, so the lifetime of the plant is affected as a function of operating hours. Many elements are quickly affected due to impurities such as membrane, ionomer in the catalyst layer, catalysts,  and  PTLs.  The  water  purification unit, responsible for providing American Society  for  Testing  and  Materials  (ASTM) type II water, contributes to lower efficiency.

SOEC electrolysers can achieve lifetimes of 20 000 hours, but under constant power and well-defined operating conditions ( i.e. not  coupled to variable renewable energy [VRE]). The main degradation mechanism is the thermal cycling, due to the high operating temperatures and need to cool down in case  of  dynamic  operation.  Reversible  operation of solid oxide cells (electrolysis + fuel cell) could help increase the hours of operation and thus keep the  system  at  operating  temperature.  Deploying SOEC  at  large  scale  would  require  larger  cells than  currently  used  (up  from  300 cm 2   to  more than 1 000 cm 2 ), which renders them more prone to failure. Another important aspect is silica contamination and the instabilities of sealing concepts.

AEM  electrolysers  suffer  from  a  short  lifetime, while  limited  information  about  their  long-term operation,  reliability  and  robustness  is  available. The stability of the AEM polymer used to fabricate membrane and catalyst layers is well recognised as  a  major  issue,  especially  when  operated  with KOH  as  the  supporting  electrolyte.  The  main degradation mechanism is hydroxide (OH -) attack on the polymer backbone, which leads to membrane collapse and catalyst layer dissolution within  a  few  days.  One  solution  is  cross-linking chemical methods, but this comes at a cost of cell efficiency.  Another  approach  is  by  operating  the stack  without  a  supporting  electrolyte  ( i.e. using only  pure  water),  which  can  lead  to  a  durability beyond 5 000 hours, but this results in much lower efficiencies, or current densities.

## Efficiency of a hydrogen production facility

The system efficiency of a green hydrogen production  facility,  measured  in  units  of  kilowatt hours consumed per kilograms of hydrogen produced (kWh AC /kgH ), is a result of the individual 2 efficiencies of the cell, stack and balance of plant, as follows.

-  Cell: The efficiency profile decreases linearly from  lower  to  higher  load  levels,  so  the higher the current input, the lower the stack efficiency. Naturally, the higher the hours of operation, the lower will be the efficiency due to degradation, though the aforementioned dynamic remains. At the operational level, the cell voltage is the element actually measured to  infer  the  system  performance,  in  such  a way  that,  the  higher  the  cell  voltage,  the lower the stack efficiency. Alkaline and PEM operate  at  different  power  density  ranges, which has an impact on each technology's footprint:
-  Alkaline: Typically  operates  in  a  range of  0.2-0.8  A/cm 2 , since  the  diaphragm and electrodes are not manufactured to operate at higher current densities.
-  PEM: Operates at higher current densities compared to alkaline, of about 2.0-2.3  A/cm 2 ,  though  more  efficient  at 1.6 A/cm2 (with 1 MW as reference).
-  Balance of plant: A range of system elements such as cooling, purifiers, thermal management,  water  treatment  and  others, consume power in order to operate, which also needs to be considered in the facility's overall  efficiency.  Efficiency  losses  can  be minimised  by:  designing  the  electrolyser facility while taking a whole-of-system perspective; using commercially-available components rather than custom made ones; and maximising system efficiency including balance  of  plant,  tailored  for  the  specific application. Rectifiers are a key component of the balance of plant. Rectifiers generally have  very  low  efficiency  at  lower  loads, rapidly improving until 15%-20%, which then remains relatively high from this point on. For this  reason,  the  balance  of  stack  efficiency  can be improved by using the same rectifier for multiple stacks. This approach would reduce the number of rectifiers needed (investment costs)  while  also  maintaining  operation  at higher efficiency levels, suitable in particular for  hydrogen  facilities  of  20 MW  or  larger. As  a  drawback,  the  system  becomes  less flexible and, therefore, such a setting would be recommended for facilities operating at flat power input/hydrogen production levels.

At very low loads (marginally above zero), when water  starts  circulating,  the  system  efficiency  is low because equipment is already in operation, but production has not started yet, or is very minimal. From  this  stage  to  roughly  30%  load,  efficiency progressively  increases  and  peaks  at  this  level. Beyond  30%  load,  the  overall  system  efficiency starts to decrease towards the nominal rate value.

This  behaviour  is  different  than  in,  for  example, many thermal power plants, which exhibit reduced efficiency  with  lower  than  nominal  loads.  It  also presents a new feature that changes the operational strategy of the electrolyser. This can be operated at  a  lower-than-design  load,  benefiting  from  a higher efficiency ( i.e. lower electricity cost per unit of  hydrogen),  at  the  expense  of  lower  hydrogen production (and lower total revenues). Therefore, there is a tradeoff between capital and operational cost that should be considered at the project level.

As presented in Chapter 3, Section 3, compressors,

storage  and  subsequent  stages  of  the  hydrogen supply  chain  will naturally impact  the  overall efficiency, from renewable power to the hydrogen actually consumed. Naturally, the fewer the conversion  stages  over  the  chain  (compression, liquefaction, embedding in liquid organic hydrogen carriers and others), the higher will be the overall efficiency.

## 2.5 FLEXIBILITY OF GREEN HYDROGEN PRODUCTION FACILITIES

To  ensure  that  green  hydrogen  supply  cost  is  as low  as  possible,  a  holistic  approach  needs  to  be applied to system design and operations. System design  can  be  optimised  to  minimise  cost  and increase  flexibility  as  necessary,  depending  on  a variety of factors. These can include: the variability of electricity supply ( i.e. constant consumption of grid  electricity,  or  direct  feed  from  variable  solar or wind farms); the technology used for the stack ( e.g. alkaline,  PEM  and  AEM  being  more  flexible than  solid  oxide);  and  the  flexibility  of  hydrogen demand ( e.g. constant demand for chemical processes, general annual demand  for export without  hourly  or  daily  constraints).  Storage  can significantly help to decouple variable supply from hydrogen demand. This can come in the form of electrochemical storage for shortterm fluctuations (before  the  electrolyser  stack),  or  in  the  form of  hydrogen  storage  for  long-term  fluctuations (after the stack, before the downstream offtaker). Similarly,  hydrogen  storage  in  tanks,  caverns  and pipelines  can  help  decouple  variable  hydrogen production from inflexible hydrogen demand ( e.g. to  produce  ammonia).  No  single  blueprint exists, however, the type of electricity supply and hydrogen demand will drive system design, where no  single  electrolyser  technology  is  better  than any other, as the combination with electricity and hydrogen storage can effectively provide any level of flexibility, as illustrated in Figure 15.

System schematic for green hydrogen production facility that includes

Figure 15. electricity and hydrogen storage on site.

<!-- image -->

Electricity

Hydrogen

Based on IRENA analysis.

Both alkaline and PEM electrolyser systems have been  certified  to  provide  primary  reserves  ( i.e. the  most  rapid,  short  term  grid  service)  (IRENA, 2019b; thyssenkrupp, 2020), therefore highlighting how flexibility is more of a design issue related to balance  of  plant  components  and  sizing.  Many small modular stacks, for example, each one with its own rectifier, make a significantly more flexible electrolyser  plant  than  a  single  large  stack  with single rectifier, regardless of stack technology.

In  terms  of  hydrogen  storage,  hydrogen  in  a  gaseous form can be stored in two favoured approaches: pressurised steel tanks and underground reservoirs. Hydrogen can also be liquefied. This would deliver about  75%  higher  energy  density  than  gaseous hydrogen  stored  at  700  bar,  while  requiring  the equivalent  of  25%-30%  of  the  energy  contained in the hydrogen. Promising developments in large scale  facilities  show  energy  consumption  as  low as 6 kWh/kg of hydrogen (Walnum et al., 2013). Underground storage of hydrogen using, for instance, salt caverns is considered to be the most appropriate solution to store hydrogen on a large scale.  This  method  comprises  some  interesting storage  characteristics,  such  as  low  investment costs, high sealing potential, and low cushion gas requirement (Ozarslan, 2012). Salt caverns typically allow storing hydrogen from 100 bar up to 275 bar.

Hydrogen storage at output pressure from the  electrolyser  is  useful,  if  the  objective  is  to maximise  flexibility,  as  mechanical  compression can  limit  the  speed  at  which  electrolyser  output can  change.  The  use  of  pressurised  electrolysers ( e.g. 30 bar, achievable with both alkaline and PEM technologies today), in combination with a buffer to decouple the electrolyser operating regime from the compressor operating regime, helps to prevent the compressor from becoming the bottleneck for the flexibility of the electrolysis facility as a whole.

As  far  as  the  ability  of  electrolysers  to  provide flexibility to the power system, this can be achieved at  multiple  time  scales.  A  mapping  of  system services (IRENA, 2020f) is provided in Figure 16. Except  for  the  provision  of  inertia,  electrolyser facilities can provide all system services, if designed with this in mind. While PEM might eventually be more  effective  than  alkaline  for  fast  frequency response (FFR), batteries are clearly more efficient and effective in providing fast response to system operator's signals and can quickly saturate such a market, which makes any additional cost incurred for designing  electrolyser facilities capable  of providing FFR questionable in terms of potential return. For the remaining services, all electrolyser technologies can provide them effectively without technical challenges, provided they are designed with grid service provision in mind.

The electrolyser stack is fast enough to follow fluctuations from wind and solar. The limitation arises from the surrounding equipment. Seasonal rather than short-term may be hydrogen's highest value

Where hydrogen has a significant role to play in terms of flexibility provision in future decarbonised power  systems  is  in  long  duration  storage  and system  adequacy.  The  seasonality  of  solar,  wind and hydropower resources can provide challenges in terms of adequacy - if not every year, at least in unusual weather years ( e.g. dry years, or years with extended  periods  of  low  wind).  Hydrogen  from renewable  power  can  be  stored  cost  effectively - for example, in salt caverns - and can be used for  power  generation  in  these  particular  periods (Diesendorf and Elliston, 2018).

Notably, if hydrogen-to-power is performed using gas turbines or internal combustion engines, hydrogen can then also contribute to the provision of system inertia (unlike fuel cells).

Based  on  IRENA  analysis,  in  the  Transforming Energy Scenario (TES) of the Global Renewables Outlook a significant capacity of electrolysers will be deployed by 2050. IRENA developed a global power system model based on this scenario that includes electrolysers as purchasers that buy electricity  when  it  is  most  affordable,  with  the objective  of  producing  hydrogen.  In  the  2050 TES scenario, renewables will supply 86% of total electricity, with solar and wind alone providing over

60%. Due to the nearzero short run marginal cost of solar and wind, when they are reach significant generation  share  in  a  market  interval  ( e.g. in  a onehour period), they drive down electricity prices. Figure 17 shows how hydrogen production follows renewable electricity availability, highlighting an  important  seasonality  in  the  production  of hydrogen.

The key message is that hydrogen production from electrolysers can be uniquely positioned to provide seasonal flexibility to the power system - something that  no  other  resource  can  effectively  provide. 14 This  can  play  a  significant  role  in  balancing  a power  system  with high shares of solar and wind, not only instantaneously and intra-day, but  also  across  seasons.  To  be  able  to  provide such services, electrolysers must  be  designed not  to  operate  at  full  capacity  the  entire  year, but  rather  to  purchase  electricity  when  green 15 and  affordable.  This  is  only  possible  if  they  are sufficiently  oversized  to  avoid  purchasing  nonrenewable  electricity,  or  prohibitively  expensive electricity, just to be  able to meet  hydrogen demand.

Figure 16. Power system services that can be provided by energy storage.

<!-- image -->

Based on IRENA analysis, 2020f.

Figure 17. Seasonality of hydrogen production in Europe in the IRENA global power system model for 2050 (based on the TES).

<!-- image -->

14

Hydro power can provide seasonal flexibility. Uncertainty about future availability of water, however, makes multi-season hydro power scheduling one of the most complex stochastic problems in power systems, while electrolysers can simply respond to day ahead as well as intra day electricity prices and provide the same seasonal flexibility when coupled with hydrogen storage.

15 Appropriate mechanisms such as Guarantees of Origin are required to certify that green hydrogen is indeed produced exclusively with renewable electricity. New electrolysis capacity, however, must fundamentally be accompanied by new renewable capacity to provide the necessary green electricity.

Hydrogen can be stored and transported in multiple ways. In terms of flexibility services, electrolysers have been evaluated in terms of:

- 1. The time they take to respond to a change in power set-point.
- 2. The time they take to settle after a power set-point change.
- 3. The rate at which they can change power consumption.
- 4. The lower operation limit, or the minimum turndown level.
- 5. The  time  they  take  to  start  up  and  shut down.

A report (Eichman, Harrison and Peters, 2014) has found that:

- 1. Small electrolyser systems (around 40 kW units) begin changing their electricity demand within milliseconds of a set-point change.
- 2. The settling time after a set-point change is in the order of seconds.
- 3. Electrolysers  can  reduce  their  electrical consumption to zero for an unlimited amount of time.
- 4. Electrolysers exhibit low partload operation capabilities.
- 5. Electrolysers can start up and shut down in several minutes.

The study also concluded that electrolysers acting as demand response devices can respond sufficiently fast and for a long enough duration to participate  in  energy  management  on  the  utility scale and at end user facilities. This has also been presented  in  some  real  applications  by  IRENA (IRENA, 2019b).

From  the  point  of  view  of  short-term  flexibility, alkaline  and  PEM  water  electrolysers  still  present  the most interesting technical capability, as they have proven  to  provide  very  fast  dynamics  among  all available electrolysis process. Alkaline electrolysers have been successfully tested for primary control reserve in Germany,  which  demonstrates  that for  practical  purposes,  these  are  as  fast  as  PEM (thyssenkrupp,  2020)  .  All  manufacturers  have typically  guaranteed  ramping  up  and  down  to change  the consumption  of  electricity to be completed  in  less  than  one  second  (ITM  Power, 2017;  Siemens,  2020),    and  that  is  primarily  a function of the rectification system. They can also operate at partial load as low as 5%, which can be sustained  during  long  periods  of  time,  although this might lead to significant efficiency losses due to  the  rectifier's  characteristics.  In  addition,  PEM electrolysers  can  reach  cold  startup  in  less  than 5  minutes,  and  completely  shut  down  within  a few  seconds.  The  cited  technical  characteristics open  up  several  potential  demandside  response schemes  to  support  the  operation  of  electrical power systems. For instance, fleets of electrolysers could  be  controlled to quickly ramp-up  their consumption at times when there is a surplus of renewable energy generation, hence contributing to  the  minimisation  of  electricity  curtailment,  or simply  participating  in  balancing  markets  either individually (if sufficiently large) or through aggregators. On  top of that, they could be coordinated  with  renewable  energy  sources  to help  mitigate  the  fluctuations  of  the  generated power in offgrid applications.

For congestion management, large scale electrolysers  can  contribute  to  the  reduction  of critical  peak  loads  by  reducing  their  electricity demand, or even by completely interrupting operation.  This  service  should  be  remunerated adequately, however, to compensate for the economic incentive to operate the electrolyser as many hours as possible to reduce the contribution of the investment cost to the total cost. Moreover, such an application can also have its limitations, since several industrial processes cannot be stopped  when  integrated  with  the  electrolyser facility,  therefore  limiting  flexibility  of  operations based on the size of the hydrogen storage.

The  key  message  is  that  hydrogen  production through electrolysis can provide significant flexibility  to  match  the  seasonality  of  renewable energy  generation,  rather  than  follow  shortterm fluctuations, which can be provided by shortterm storage technologies like batteries (including those in battery electric vehicles). The coupling with gas infrastructure (including salt caverns and pipeline systems) can provide extremely large energy storage volumes to perform seasonal energy storage of renewable electricity in molecular form, effectively decoupling hydrogen (and Power-to-X) demand from variable renewable electricity supply.

This de facto provides the largest contribution to power system flexibility in terms of volume of all sources.  For  such  system  service,  the  speed  of response of different electrolyser  technologies  is irrelevant,  although  both  PEM  and  alkaline  have been certified to provide primary reserves.

Flexibility provided by large deployment of electrolysers  into  high  renewable  power  systems will be a fundamental pillar of the transformation of the power sector, in combination with a set of other technologies, such as batteries (including in electric vehicles [EVs]), hydropower and pumped hydro, and demand response.

## 2.6 COSTS: CURRENT STATUS

Despite  their  market  availability  and  maturity, PEM  and  alkaline  water  electrolysers are still considered  highly  expensive  from  both  CAPEX and OPEX perspectives, compared to fossil fuel-based hydrogen production. PEM water electrolysers  are  50%-60%  more  expensive  than alkaline  (see  Chapter  3,  Section  2),  representing an additional barrier to market penetration. Both are  still  considered  to  have  untapped  potential for  cost  decrease  when  considering  economies of scale, automation, an increase in availability of components from various OEMs, massive market demand  and  deployment for energy storage (coupling electrolysers with underground storage or tanks).

For AEM  and  solid  oxide  electrolysers, these cost  considerations  are  much  more  challenging, as  there  are  only  a  few  companies  responsible for  their  commercialisation.  Moreover,  many  of their  components  are  still  lab-scale  based,  with no OEM responsible for their manufacturing and commercialisation.  These  are  small  stacks,  and system sizes are only up to a few kilowatts. While these two technologies can still contribute to a low production  cost  of  green  hydrogen,  they  have  a longer way to go compared to alkaline or PEM. For these reasons, only the cost breakdown for these two technologies is explored in more detail below. Significantly, AEM can use less-expensive materials (in particular titanium, which can represent around half the stack cost for PEM) and therefore AEM has an advantage over PEM in cost-reduction potential.

There are two main problems with cost estimates for  electrolysers.  First,  the  availability  of  data, given its confidential nature and the retention of competitive  advantage.  Second,  the  boundaries for the cost estimates are not consistent ( e.g. stack, balance of plant, full system) and, in many cases, not even specified, which makes the comparison across  studies  more  difficult.  To  deal  with  these challenges, this report performed  a  thorough literature review validated by consultations and a peer  review  with  various  leading  manufacturers, which  informed  the  cost  breakdowns  shown  in Figure  18  and  Figure  20.  For  the  second  barrier (boundaries), different system scopes are analysed for the cost estimates in this report:

-  The  first  level  is  a  single cell unit.  This  is the core of the electrolyser where the main electrochemical  process  takes  place.  This includes the catalyst coated membrane where the catalyst layers are coated directly as  electrodes  onto  the  membrane  for  the PEM type and the electrodes and diaphragms for the alkaline type, plus the manufacturing of these components which can represent a large share of the costs.
-  The second level within stack costs includes the  cells  plus  the  PTLs,  bipolar  plates,  end plates and other small parts such as spacers, seals,  frames,  bolts  and  others.  This  level usually  represents  about  40%-50%  of  the total.
-  The third level is the system costs. The scope is  all  the  balance  of  plant  components and peripherals  responsible  for  operating  the electrolyser,  but  excluding  any  component responsible for further gas compression and storage. The major components for the balance of plant cost models typically include rectifier,  water  purification  unit,  hydrogen gas  processing  (compression  and  storage) and  cooling  components.  These  items  can constitute 50%-60% of the total cost.

Today, the main contributor to system costs is still the stack, which represents 40%-50% of the total, for both alkaline and PEM electrolysers. This share greatly depends on design, manufacturing strategy, business  case,  and  customer  specifications.  Cost breakdowns  for  AEMs  and  solid  oxide  systems are  still  not  available,  due  to  the  limited  number of systems that have been deployed commercially.

A  paper  published  in  2018  (Saba  et  al.,  2018) showed  a  comparison  of  cost  studies  from  the previous 30 years, and projections of these costs for PEM and alkaline electrolyser systems. The study showed there had been significant cost reductions over the period for both PEM and alkaline systems, but this reduction was more pronounced for PEM. Saba et al. depict a significantly large spread in the costs of PEM systems, ranging from USD 306/kW up to USD 4 748/kW, demonstrating the challenge of finding representative numbers for the current system costs (Saba et al., 2018).

Figure  18  and  Figure  20  show  a  breakdown  of cost components  for both PEM  and  alkaline electrolysers, while Figure 19 and Figure 21 combine this information with the potential for cost reduction of the various items in order to identify priority areas for innovation  and  deployment. First scalingup initiatives into systems larger than 1 MW will allow quick cost reduction of balance of plant  components,  as  discussed  above.  Beyond this point, innovation becomes key for any further significant cost reduction. Most of the stack components are still over designed, and significant potential for cost reduction can be found for PTLs, bipolar plates and the highly expensive protective coatings on these.

Figure  18  shows  that  for  PEM  electrolysers  the stack  represents  slightly  less  than  half  of  the electrolysis system cost. For the balance of plant, power  supply  represents  a  very  significant  cost component.

For  PEM  stacks,  bipolar  plates  are  a  significant cost component, as they are often built to provide multiple functions and require advanced materials such as gold or platinum coated titanium (Hermann, Chaudhuri and Spagnol, 2005). This is one of the areas where innovation can play an important role in both performance and durability enhancement, as well as cost reduction. Research is ongoing to replace  titanium  with  cheaper  materials,  relying on the coating for its functional characteristics to remain unaffected, while reducing cost.

## GREEN  HYDROGEN COST REDUCTION

For  the  core  of  the  stack,  the  catalyst  coated membrane (CCM), rare metals represent an important  part  of  the  cost.  Put  into  context, however, they represent less than 10% of the cost of  a  full  PEM  electrolysis  system.  Yet,  for  iridium in  particular,  they  might  represent  a  bottleneck for scaling up manufacturing of PEM electrolysers, in the absence of a significant scale-up of iridium supply (see Chapter 3, Section 3).

<!-- image -->

- Protective coating BPs

Note: The specific breakdown varies by manufacturer, application and location, but values in the figure represent an average.

Based on IRENA analysis.

When the dimension of potential for cost reduction is combined with the current share of total system cost of each component,  some  clear priority areas for innovation emerge. Power supply is the single largest area where cost reduction could be achieved (see Figure 19). Bipolar plates, although with a lower cost reduction potential, also represent almost  a  quarter  of  the  total  PEM  electrolysis system cost and should be a priority area.  Other balance of plant components, like water circulation and hydrogen processing, also represent important areas where cost reduction can be achieved.

Figure 19. System components for a 1 MW PEM electrolyser classified based on contribution to total system cost and potential for cost reduction.

<!-- image -->

Potential for cost reduction

Based on IRENA analysis.

For  alkaline electrolysers, the  same  reasoning in  reducing  the  costs  of  the  balance  of  plant components  applies.  As  illustrated  in  Figure  20, within the stack, over 50% of the costs relate to electrodes  and  diaphragms,  as  opposed  to  25% of  the  cost  in  the  CCM  for  PEM.  Significant  cost is associated with manufacturing of the electrodes (E4tech,  2014;  NOW,  2018)  where  learning-by- doing, automatisation of the manufacturing process  and  economies  of  scale  can  play  an important  role  in  cost  reduction.  Bipolar  plates for  alkaline,  however,  account  for  only  a  small part  of  stack  costs,  as  opposed  to  over  50%  in the case of PEM, due to a simpler design, simple manufacturing and cheaper materials (nickelcoated steel) for bipolar plates in alkaline stacks.

Figure 20. Cost breakdown for 1 MW alkaline electrolyser, moving from full system, to stack, to membrane electrode assembly (MEA).

<!-- image -->

Note: The specific breakdown varies by manufacturer, application and location, but values in the figure represent an average.

Based on IRENA analysis.

Similar  to  what  happens  with  PEM,  some  clear priority areas arise for alkaline electrolysers when the potential for cost reduction is combined with the  current  share  of  total  system  cost  of  each component  (see  Figure  21):  power  supply  is  the single largest area where cost reduction could be achieved,  followed  by  the  manufacturing  of  the electrodes and diaphragms. The strategy can be to completely reengineer them, demonstrating CCM concepts similar to the PEM type, where a single component comprised of membranes, electrodes, and  eventually  PTLs,  is  fabricated.  Balance  of plant items, such as lye circulation and hydrogen processing remain important for alkaline too, although no significant potential for reduction in the cost for materials has been observed.

Figure 21. System components for a 1-MW alkaline electrolyser classified based on contribution to total system cost and potential for cost reduction.

<!-- image -->

Based on IRENA analysis.

## KEY POINTS

GREEN  HYDROGEN

COST REDUCTION

<!-- image -->

## STRATEGIES FOR COST REDUCTION: STACK LEVEL

## 1 3.

-  Government support for research programmes is needed to continue improving commercially available  technologies  and  make  potential  breakthroughs  in  emerging  technologies.  The  key areas of focus for this research are identified in this section.
-  Given the difference in design and maturity for the different technologies, the use of comparable performance  indicators  seems  to  be  a  suitable  approach  to  guide  innovation  efforts.  These performance indicators, including the long term targets defined in this section, can be used by governments  to  benchmark  performance  of  funded  projects  and  to  set  research  programme goals.
-  To  prevent  critical  materials  from  becoming  a  barrier  to  scaling  up,  alkaline  systems  need  to transition to platinum and cobalt free designs. This is already commercially available from some manufacturers today; yet, it has to become a prerequisite for policy support before scaling up manufacturing capacity. For PEM electrolysers, further efforts are needed to reduce the platinum and iridium content by at least one order of magnitude and, if possible, in the future, replace these with more common materials. Titanium is also a significant cost component that should be  reduced  in  use.  Although  less  scarce  than  other  materials,  it  is  still  required  in  significant quantities for current PEM designs.
-  Increasing the facility size can have the largest cost reduction effect on the balance of plant. Yet, facility size is not defined based on cost only, but is also based on the application ( e.g. the residential or transport sectors use smaller sizes than industrial applications). Higher cost due to smaller scale can partly be offset by savings in the delivery of the hydrogen, due to on-site production.

<!-- image -->

At the stack level, there are mainly two strategies to achieve a lower costs:

-  Stack  design  and  cell  composition : This includes using less critical materials, redesigning  the  stack  to  achieve  a  higher efficiency ( i.e. lower electricity cost), higher durability  (longer  lifetime  to  distribute  the investment) and increase the current density (higher production rate).
-  Increase  the  module  size : This  can  bring economies of scale to some of the balance of  plant  components.  This  strategy  should consider a trade-off between a small module size that enables mass-manufacturing, standardisation and replication, and a large  module size that achieves larger cost reduction in balance of plant components at the expense of fewer units deployed and less learning by deployment.

## 3.1 STACK DESIGN: WHAT CAN BE DONE?

## Alkaline electrolysers

Concerning  stacks  for  alkaline  electrolysers,  the key areas to focus on are the electrodes and the diaphragms.  Bipolar  plates  and  PTLs  have  less priority, since they are based on stainless steel plates coated  with  nickel,  which  are  already  significant, cost-effective components. Strategies to integrate PTLs into electrodes and consequently diaphragms can also be of key importance in reducing costs, as outlined below:

Increase  current  densities: The  current  densities of  the  stacks  can  be  increased,  from  the  current, 0.5  A/cm2 to more advanced units of 2-3 A/cm2. This  current  density  increase  cannot  be  made, however, at the penalty of lower efficiency.

Higher current densities have already been accomplished  by  some  manufacturers,  too,  with electrode-separator  packages  that  can  deliver  a performance range as high as 1.2 A/cm 2  at 2 volts (V) now available. Power densities of 2-3 W/cm 2  could be achieved by demonstrating thinner diaphragms or  membranes  for  alkaline  electrolysers.  As  with PEM,  alkaline  electrolysers  also  need  to  improve their voltage efficiency levels, reducing  ohmic losses and increasing electrode kinetics.

Reducing diaphragm thickness: This could improve efficiency and reduce electricity consumption. The thinner  the  diaphragms,  the  lower  the  resistance to transporting the OH -  species from the cathode to the anode. Eventually, however, this comes at a cost of higher gas permeation, which contributes to higher safety concerns. The other downside is the lower durability, given the higher chance of pinhole formation  in  the  diaphragm  and  less  mechanical robustness. Overall, the diaphragm thickness should  reach  values  that  approach  those  of  PEM and  AEM.  State-of-the-art  membranes  for  PEM are about 125-175 micrometres ( µ m) (Babic, 2017) with a potential decrease to 20 µ m or lower. Below this  point  (for  PEM),  there  are  limited  efficiency benefits. For  alkaline electrolysers, the  current diaphragm thickness is about 460 µ m. Decreasing this to 50 µ m  would  contribute to improving the  efficiency  from  53%  to  75%  at  1 A/cm 2 (see Figure 22).

## Figure 22.

Relationship between voltage (the higher, the lower the efficiency) and current density (the higher, the higher the production volume) for various diaphragm thickness of alkaline electrolysers.

<!-- image -->

Source: Schalenbach et al., 2016.

Re-designing catalyst compositions and electrode architectures into electrodes with a high specific surface  area: Despite  using  cheap  and  widely available Nickelbased catalysts for their electrodes, alkaline electrolysers have traditionally encountered many challenges in moving away from rudimentary, or  archaic  electrode  designs  and  reaching  much higher efficiencies for both hydrogen and oxygen evolution reactions. Efficiency differences with other  technologies  are  small  and  best-in-class designs result  in  even  higher  efficiencies.  Table  2 shows a list  with  the  ten  main  R&amp;D  aspects  that need to be addressed, so that electrodes used in these stacks can be transformed and implemented in more advanced stack concepts.

Table 2. Proposed activities to improve the performance of alkaline electrolysers.

|                                                                           |                                                                                                                                             | CHALLENGE   | BENEFIT   |
|---------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------|-------------|-----------|
| 1.                                                                        | High catalyst surface area > 50 m 2 /g                                                                                                      | Easy        | Medium    |
| 2.                                                                        | High catalyst utilization > 80%                                                                                                             | Moderate    | Medium    |
| 3.                                                                        | Improved kinetics for both hydrogen and oxygen evolution with novel nickel-based alloys                                                     | Moderate    | High      |
| 4.                                                                        | Mitigate catalyst poisoning/deactivation by foreign elements from electrolyte, and components present in the system                         | Moderate    | Low       |
| 5.                                                                        | Design, create, and integrate forms of recombination catalysts for gas permeation (crossover)                                               | Moderate    | Medium    |
| 6.                                                                        | Mitigate critical degradation of catalysts on the anode side to avoid loss of surface area                                                  | Difficult   | High      |
| 7.                                                                        | Mitigate nickelhydrogen (NiH) formation on the cathode side                                                                                 | Difficult   | Low       |
| 8.                                                                        | Eliminate mechanical degradation of catalyst layers (delamination, dissolution)                                                             | Difficult   | High      |
| 9.                                                                        | Identify stable polymer chemistry that can be used as ionomer (OH- transport) to be used to fabricate electrodes for alkaline electrolysers | Difficult   | High      |
| 10. Identify and reduce interface resistances from catalyst layer to PTLs | 10. Identify and reduce interface resistances from catalyst layer to PTLs                                                                   | Difficult   | High      |

Based on IRENA analysis.

Apart  from  increasing  surface  area,  which  was traditionally  and  simply  achieved  with  Raney-Ni catalysts (nickel-aluminium [Ni-Al], or nickelzinc  [Ni-Zn]),  the  other  points  are  considered moderate  and  difficult challenges. In addition, any  novel  concept  still  needs  to  keep  long-term durability, comparable to those presented by current nickelcoated stainless steel perforated sheets. That is the reason why Raney-Ni electrodes have  not  been  commercially  deployed,  at  least not in large-scale electrodes, since they have presented some  critical durability aspects for long-term operation (low mechanical robustness) and much higher costs, due to the use of expensive manufacturing techniques.

Novel  PTL  concepts: Alkaline electrolysers are also  not  well  developed  in  the  use  of  efficient PTLs, potentially based on nickel. This is especially so  in  regard  to  optimising  these  for  reduction of mass  transport  limitations  ( e.g. gas  bubble resistance, trapped inside alkaline PTLs), and optimal protective coating alternatives to decrease interface resistances on the anode side.

## PEM electrolysers

For PEM stacks, the focus areas are bipolar plates and PTLs, given their large cost contribution and large potential for reduction. Based on these two criteria  (cost  share  and  potential),  the  catalystcoated membrane is the next priority.

Re-designing  the  stacks  can  achieve  large  cost reductions, since it enables the reaching of higher power densities, up from the current (conservative) 2 A/cm2  to  6 A/cm2  or  more  in  the  next  few decades.  Next,  electrodes  should  be  scaled  up from the current 1 500-2 000 cm2, up to 5 000 cm2 and eventually 10 000 cm2. The larger area should go  in  tandem  with  more  mechanically  robust membranes that can use the same thickness. Such a strategy would allow an increase in the size of the  PEM  stacks,  from  the  current  1 MW/unit  to next generation stacks of 5 MW or even 10 MW per stack. These need to run at much lower levels of cell  voltage  to  allow  for  an  increase  in  efficiency and the simplification of waste heat management.

Reducing membrane  thickness: This enables an  increase  in  efficiency,  which  in  turn  enables a reduction in electricity consumption. Thick membranes (Nafion N117 with approximately 180 µ m thickness, for example) are still state-ofthe-art and are responsible for efficiency losses of about 25% (at 2 A/cm2). There are much thinner membranes that are commercially available, with  thicknesses  as  low  as  20 µ m,  yet  these  are not  designed  for  electrolysis  requirements.  This thickness reduction would allow a reduction in  efficiency  losses  to  about  6%  (at  2 A/cm2). Further  reduction  of  membrane  thickness,  down to  5.0 µ m  or  lower  (membraneless  electrolysis), is  not  encouraged,  since  a  decrease  of  no  more than 0.5 kWh/Kg H  can be extrapolated. In this 2 case,  R&amp;D  is  therefore  not  justified.  Looking  at the experience in PEM fuel cells (reverse process of  electrolysis),  commercial  stacks  are  already equipped with membranes that are 810 µ m thick, as  gas  permeation  is  not  a  concern,  since  they operate a much lower pressures (36 bar) on the air side.

The two challenges that arise with thinner membranes are: their lower durability, given their potentially  lower  mechanical  strength  and  being more  prone  to  defects  and  pinhole  failures;  and the  manufacturing  of  such  membranes.  During manufacturing, the process of enlarging the catalystcoated  membranes  and  porous  transport layers  into  large  electrodes  is  challenging  and therefore of high R&amp;D risk. The thin membrane and electrodes need to be mechanically stabilised over the full area to avoid undesired mechanical stresses that  can  tear  these  films  and  delaminate  thin electrodes. This is especially critical at differential pressure operations, where one side is subjected to much higher pressures coming from the other electrode.  Re-designing  PTLs  will  be  crucial  i.e. with  finer  structures  at  the  catalyst  interface that can better support a thinner membrane and prevent creep failure, thereby enabling lower membrane thickness.

Removing  expensive  coatings  and  redesigning the PTLs and bipolar plates: On the anode side, commercial stacks  demand the use of  platinumcoated titanium porous sintered PTLs, which is not  possible  with  non-PGMs  at  this  stage. Platinum loadings on the anodic PTL vary from 1-5 milligrammes per square centimetre (mg/cm2) or 1 2.5 g/kW. Platinum has a dual purpose: to protect the  titanium  against  passivation 17 and  provide an  optimal  interface  resistance.  This  is  needed because  titanium  is  prone  to  severe  quick  and detrimental passivation. Studies have shown that interface  resistance  at  the  PTL  is  responsible  for an electricity consumption as high as 1.35 kWh/Kg H 2 (4% of hydrogen LHV) (Liu et al., 2018; Kang et al., 2020). The bipolar plates made of titanium also possess protective layers of platinum on the anode side,  and  gold  on  the  cathode.  Alternatives  are needed for titanium plates, based on such materials as niobium, tantalum and eventually stainless steel approaches, but using protective coatings that are stable and also free from platinum or gold.

Re-designing  catalyst-coated  membranes: For catalyst coated membranes (electrodes), the strategy  can  be  divided  into  different  timescale scenarios.  An  initial  approach  could  be  to  tackle

the  economies  of  scale  for  CCM  fabrication  via automation over manufacturing, establishing more  reliable  and  less  expensive  supply-chains for  catalysts  and  membranes,  and  implementing quality  control.  If  possible,  parallel  work  can  be done to reduce the amount of electrocatalysts by re-engineering the electrodes over the membrane.

components.  Moreover,  these  membranes  have been traditionally supplied at scale for chloroalkali electrolysers,  with  membranes  reaching  areas  as high as 3 m2. Therefore, significant cost reduction is  expected  as  soon  as  PEM  water  electrolysers reach high market volumes.

Supply  chain  for  PFSA  membranes:  For  PFSA membranes,  various  suppliers ( e.g. Chemours, Solvay, Asahi-Kasei, 3M and Gore) are available. This is also one of the most solid supply chains for PEM

Table 3 shows a list with the main R&amp;D aspects that need to be addressed, so that catalysts, electrodes, and  stack  components  can  be  transformed  and implemented in more advanced PEM electrolyser concepts.

Table 3. Proposed activities to improve the performance of PEM electrolysers.

|    |                                                                                                                     | CHALLENGE   | BENEFIT   |
|----|---------------------------------------------------------------------------------------------------------------------|-------------|-----------|
|  1 | Mitigate membrane poisoning/deactivation by foreign elements from components and system                             | Easy        | Medium    |
|  2 | Design, create, and integrate forms of recombination catalysts for gas permeation (crossover)                       | Easy        | Medium    |
|  3 | Increase catalyst utilisation of anode and cathode catalysts                                                        | Moderate    | High      |
|  4 | Identify and reduce interface resistances from catalyst layer to PTLs                                               | Moderate    | Medium    |
|  5 | Reduce the ohmic losses and gas permeation of PFSA membranes                                                        | Difficult   | High      |
|  6 | Improve kinetics for oxygen evolution using iridium-free catalysts and maintain stability comparable to iridium SoA | Difficult   | High      |
|  7 | Eliminate mechanical degradation of catalyst layers (delamination, dissolution)                                     | Difficult   | Medium    |
|  8 | Create noble metal free protective layers for PTLs                                                                  | Difficult   | High      |
|  9 | Create titanium free PTLs                                                                                           | Difficult   | High      |

## AEM electrolysers

In terms of components, the AEM membrane and ionomer  are  the  main  and  most  challenging.  In terms  of  performance,  the  most  critical  item  is durability,  but  also  conductivity.  Research  efforts are  targeted  to  finding  AEM  membranes  with desirable  properties  (high  mechanical,  thermal, and  chemical  stability, ionic conductivity, and lower permeability with respect to electrons and gases).  The  polymer backbone is responsible for mechanical  and  thermal  stability.  The  functional group that transports the OH -  anion is accountable for the ion exchange capacity, ionic conductivity, and transport number.

ionic  conductivity  is  challenging  and  therefore expensive. There are known chemical strategies to increase  the  AEM  ionic  conductivity,  but  it  leads to  loss  of  mechanical  strength  due  to  excessive water uptake. The AEM then becomes chemically unstable,  which  leads  to  poor  ionic  conductivity. Another major limitation of an AEM is degradation of the polymer due to KOH attack, which quickly reduces  the  conductivity  of  the  membrane  and ionomer within the catalyst layer. The ionic conductivity of an AEM plays a significant role in the performance of the AEM. Higher levels of ion conductivity allow much higher current densities to  be  achieved.  Tasks  to  increase  efficiency  and durability of electrodes and PTLs are analogous to those related to alkaline electrolysers.

The  trade-off  for  AEM  is  between  mechanical stability, ionic conductivity and cost. For instance, the production of commercial AEM that achieves  a  high  mechanical  stability  and  high

Table 4 has the key areas in the stack that can lead to  the  largest  performance  improvement in AEM electrolysers.

Table 4. Proposed activities to improve the performance of AEM electrolysers.

|    |                                                                                                                                 | CHALLENGE   | BENEFIT   |
|----|---------------------------------------------------------------------------------------------------------------------------------|-------------|-----------|
|  1 | Development of cost effective PTLs for AEM electrolysers                                                                        | Moderate    | Medium    |
|  2 | Identify and reduce interface resistances from catalyst layer to PTLs                                                           | Moderate    | Medium    |
|  3 | Control the oxidized state of electrocatalysts on the oxygen side (anode)                                                       | Moderate    | Medium    |
|  4 | Reducing the ohmic losses and gas permeation of AEM membranes                                                                   | Moderate    | High      |
|  5 | Improve kinetics for hydrogen and oxygen evolution and maintain long-term stability                                             | Moderate    | High      |
|  6 | Increase AEM membrane durability                                                                                                | Difficult   | High      |
|  7 | Eliminate mechanical degradation of catalyst layers (delamination, dissolution) and improve ionomer/catalyst binding properties | Difficult   | High      |

Based on IRENA analysis.

## Solid oxide electrolysers

The potential for this technology lies in its higher efficiency, while its main  challenge is durability.  Some  of  the  areas  to  focus  on  are: the improvement of electrolyte conductivity, optimisation of chemical and mechanical stability, matching  the  thermal  expansion  coefficient  to both  electrodes,  and  ensuring  minimal  reactant crossover. State-of-the-art  electrolytes used  in these  cells have  already  exhibited  remarkable conductivity  for  stack  operation  for  thousands of  hours,  but  the  degradation  of  the  electrolyte (which translates into a reduction in performance) is still of high importance for research. Structural changes  within the electrolyte accelerate the formation of voids within its structure, increasing electrolyte  resistance.  Moreover,  electrolyte  also reacts  with  vaporised  water  and  forms  volatile products such as nickel hydroxide (Ni(OH) ) that 2 also deactivates it.

As for the other electrolysis technologies, electrodes  used  for  solid  oxide  stacks  are  key components, and many key properties are required to provide high efficiency and durability. Table  5  provides  a  list  of  challenges  and  their respective ranking related to future R&amp;D tasks to improve them, both to reach higher efficiency and durability.

Table 5. Proposed activities to improve the performance of solid oxide electrolysers.

|    |                                                                                                                      | CHALLENGE   | BENEFIT   |
|----|----------------------------------------------------------------------------------------------------------------------|-------------|-----------|
|  1 | Stabilise the chemical structure and compatibility of the electrodes                                                 | Moderate    | Medium    |
|  2 | Control the oxidation state of electrocatalysts on the oxygen side (anode) or nickel agglomeration                   | Moderate    | Medium    |
|  3 | Increase the electro catalytic activity of electrodes at lower temperatures                                          | Moderate    | Low       |
|  4 | Solve challenges related to lanthanum manganite (LSM) or lanthanum ferrite (LSF) delamination from electrolyte       | Moderate    | High      |
|  5 | Improve kinetics for hydrogen and oxygen evolution and maintain long-term stability                                  | Difficult   | High      |
|  6 | Eliminate or reduce contamination issues related to silicon dioxide (SiO 2 ) dissolution from stack sealants         | Difficult   | Medium    |
|  7 | Eliminate thermal instability issues caused by an expansion coefficient mismatch between electrolytes and electrodes | Difficult   | High      |
|  8 | Scaling up of stack components towards larger stack MWunits                                                          | Difficult   | High      |

Based on IRENA analysis.

## 3.2 SETTING TARGETS FOR STACK DESIGN : A KEY PERFORMANCE INDICATOR (KPI) DRIVEN APPROACH

Table 6 lists KPIs for the four-electrolysis technologies considered here, both for the stateof-the-art  in  2020  and  as  targets  for  2050.  The table also displays which  main  component  is specifically related to, or individually affects a given KPI, and that can be used as guideline for both the electrolyser industry and OEMs to transform the technology by 2050 .

A parallel - and equally valid - approach is to focus on  designing  three  dimensional  (3D)  electrode structures, profiting from the high conductivity of KOH across the components, which goes against the development of electrodes similar to PEM.

For PEM water electrolysers , significant development  of  the  technology  can  be  obtained by:

-  replacing thick membranes,
-  reducing catalyst quantities after reengineering electrode concepts,
-  removing or substituting expensive coatings on PTLs,
-  developing novel concepts for recombination catalysts.

For alkaline electrolysers , the focus on increasing efficiency can be accomplished by:

-  increasing the limit for the operating temperature,
-  replacing thick diaphragms,
-  redesigning catalyst compositions,
-  moving electrode architectures into high area electrodes,
-  introducing novel PTL/electrode concepts.

Alkaline electrolysers need to reach similar concepts in catalyst coated membranes or membrane  electrode  assemblies  as  used  in  PEM electrolysers.  Such  a  strategy  works  to  reduce ohmic and interface resistances and improve electrode kinetics. Any novel diaphragm or membrane  concept  that  is  fabricated  needs  to respect  the  necessary  gas  permeation  threshold, not exceeding the current values already observed for classic alkaline electrolyser concepts.

While today, performance ranges widely by technology, these gaps are expected to close over time. A performance-driven approach serves as guidance for research and innovation

For AEM electrolysers , the main hurdle still lies in the complex, yet unstable polymer chemistry used in  the  membranes and ionomers. If a stable AEM membrane  is  found,  novel  membrane  electrode assemblies using anion exchange membranes need to  be  proven  for  acceptable  electrode  and  PTL concepts to be used within these stacks. These also need  to  be  envisioned  for  membrane  electrode assemblies  of  much  larger  cell  area,  similar  to that currently observed in stateoftheart PEM electrolysers.

For all technologies, a crucial challenge is related to the long-term characteristics of any novel material or component that needs to prove reliability beyond 50 000 hours. Hence, there is an intrinsic hurdle in running  durability  experiments  for  thousands  of hours, or even a few years, making R&amp;D of these components very slow and/or inefficient.

Prior to such long-term experiments, degradation mechanisms  should  be  unveiled  for  each  novel component,  along  with  accelerated  stress  tests and insitu/operando techniques to identify degradation issues. This challenge is related to the R&amp;D  of  all  electrolysis  technologies,  since  all  are aimed at stationary applications.

The research and development of materials, thin films, components,  cells, stacks, systems peripherals, and integration for water electrolysers is  very  much  dependent  on  the  definition  of  a solid and trustworthy stateoftheart that correctly represents  what  can  currently  be  found  at  the commercial  level.  Only  a  reliable  stateoftheart allows  the  implementation  of  solid  baselines  to different  metrics,  such  as  the  physicalchemical characteristics of materials, performance, selectivity, durability, cost, and so on.

PEM  and  alkaline  electrolysers  have  historically relatively  welldefined  benchmarks,  with  metrics fairly  well  known  by  the  R&amp;D  community  and industry.

This is unfortunately not the case for solid oxide and AEM electrolysers. These are of high potential, but are also much less mature technologies, with only a few companies and OEMs interested or involved in their manufacture and commercialisation.

Table 6. State-of-the-art and future KPIs for all electrolyser technologies.

|                                      | 2020                   | Target 2050            | R&D focus                                      |
|--------------------------------------|------------------------|------------------------|------------------------------------------------|
|                                      | PEM electrolysers      | PEM electrolysers      | PEM electrolysers                              |
| Nominal current density              | 1-2 A/cm2              | 4-6 A/cm2              | Design, membrane                               |
| Voltage range (limits)               | 1.4-2.5 V              | < 1.7 V                | Catalyst, membrane                             |
| Operating temperature                | 50-80°C                | 80°C                   | Effect on durability                           |
| Cell pressure                        | < 30 bar               | > 70 bar               | Membrane, reconversion catalysts               |
| Load range                           | 5%-120%                | 5%-300%                | Membrane                                       |
| H 2 purity                           | 99.9%-99.9999%         | Same                   | Membrane                                       |
| Voltage efficiency (LHV)             | 50%-68%                | >80%                   | Catalysts                                      |
| Electrical efficiency (stack)        | 47-66 kWh/Kg H 2       | < 42 kWh/Kg H 2        | Catalysts/membrane                             |
| Electrical efficiency (system)       | 50-83 kWh/Kg H 2       | < 45 kWh/Kg H 2        | Balance of plant                               |
| Lifetime (stack)                     | 50 000-80 000 hours    | 100 000-120 000 hours  | Membrane, catalysts, PTLs                      |
| Stack unit size                      | 1 MW                   | 10 MW                  | MEA, PTL                                       |
| Electrode area                       | 1 500 cm2              | > 10 000 cm2           | MEA, PTL                                       |
| Cold start (to nominal load)         | < 20 minutes           | < 5 minutes            | Insulation (design)                            |
| Capital costs (stack) minimum 1 MW   | USD 400/kW             | < USD 100/kW           | MEA, PTLs, BPs                                 |
| Capital Costs (system) minimum 10 MW | 700-1400 USD/kW        | < 200 USD/kW           | Rectifier, water purification                  |
|                                      | Alkaline electrolysers | Alkaline electrolysers | Alkaline electrolysers                         |
| Nominal current density              | 0.2-0.8 A/cm2          | > 2 A/cm 2             | Diaphragm                                      |
| Voltage range (limits)               | 1.4-3 V                | < 1.7 V                | Catalysts                                      |
| Operating temperature                | 70-90°C                | > 90°C                 | Diaphragm, frames, balance of plant components |
| Cell pressure                        | < 30 bar               | > 70 bar               | Diaphragm, cell, frames                        |
| Load range                           | 15%-100%               | 5%-300%                | Diaphragm                                      |
| H 2 purity                           | 99.9%-99.9998%         | > 99.9999%             | Diaphragm                                      |
| Voltage efficiency (LHV)             | 50%-68%                | > 70%                  | Catalysts, temperature                         |
| Electrical efficiency (stack)        | 47-66 kWh/Kg H 2       | < 42 kWh/Kg H 2        | Diaphragm, catalysts                           |
| Electrical efficiency (system)       | 50-78 kWh/Kg H 2       | < 45 kWh/Kg H 2        | Balance of plant                               |

|                                      | 2020                      | Target 2050     | R&D focus                        |
|--------------------------------------|---------------------------|-----------------|----------------------------------|
| Lifetime (stack)                     | 60 000 hours              | 100 000 hours   | Electrodes                       |
| Stack unit size                      | 1 MW                      | 10 MW           | Electrodes                       |
| Electrode area                       | 10 000-30 000 cm2         | 30 000 cm2      | Electrodes                       |
| Cold start (to nominal load)         | < 50 minutes              | < 30 minutes    | Insulation (design)              |
| Capital costs (stack) minimum 1 MW   | USD 270/kW                | < USD 100/kW    | Electrodes                       |
| Capital costs (system) minimum 10 MW | USD 500-1 000/kW          | < USD 200/kW    | Balance of plant                 |
|                                      | AEM electrolysers         |                 |                                  |
| Nominal current density              | 0.2-2 A/cm2               | > 2 A/cm2       | Membrane, reconversion catalysts |
| Voltage range (limits)               | 1.4-2.0 V                 | < 2 V           | Catalyst                         |
| Operating temperature                | 40-60°C                   | 80°C            | Effect on durability             |
| Cell pressure                        | < 35 bar                  | > 70 bar        | Membrane                         |
| Load range                           | 5%-100%                   | 5%-200%         | Membrane                         |
| H 2 purity                           | 99.9%-99.999%             | > 99.9999%      | Membrane                         |
| Voltage efficiency (LHV)             | 52%-67%                   | > 75%           | Catalysts                        |
| Electrical efficiency (stack)        | 51.5-66 kWh/Kg H 2        | < 42 kWh/Kg H 2 | Catalysts/membrane               |
| Electrical efficiency (system)       | 57-69 kWh/Kg H 2          | < 45 kWh/Kg H 2 | Balance of plant                 |
| Lifetime (stack)                     | > 5 000 hours             | 100 000 hours   | Membrane, electrodes             |
| Stack unit size                      | 2.5 kW                    | 2 MW            | MEA                              |
| Electrode area                       | < 300 cm2                 | 1 000 cm2       | MEA                              |
| Cold start (to nominal load)         | < 20 minutes              | < 5 minutes     | Insulation (design)              |
| Capital costs (stack) minimum 1 MW   | Unknown                   | < USD 100/kW    | MEA                              |
| Capital costs (system) minimum 10 MW | Unknown                   | < USD 200/kW    | Rectifier                        |
|                                      | Solid oxide electrolysers |                 |                                  |
| Nominal current density              | 0.3-1 A/cm2               | > 2 A/cm 2      | Electrolyte, electrodes          |
| Voltage range (limits)               | 1.0-1.5 V                 | < 1.48 V        | Catalysts                        |
| Operating temperature                | 700-850°C                 | < 600°C         | Electrolyte                      |
| Cell pressure                        | 1 bar                     | > 20 bar        | Electrolyte, electrodes          |
| Load range                           | 30%-125%                  | 0%-200%         | Electrolyte, electrodes          |
| H 2 purity                           | 99.9%                     | > 99.9999%      | Electrolyte, electrodes          |
| Voltage efficiency (LHV)             | 75%-85 %                  | > 85%           | Catalysts                        |
| Electrical efficiency (stack)        | 35-50 kWh/Kg H 2          | < 35 kWh/Kg H 2 | Electrolyte, electrodes          |
| Electrical efficiency (system)       | 40-50 kWh/Kg H 2          | < 40 kWh/Kg H 2 | Balance of plant                 |
| Lifetime (stack)                     | < 20 000 hours            | 80 000 hours    | All                              |
| Stack unit size                      | 5 kW                      | 200 kW          | All                              |
| Electrode area                       | 200 cm2                   | 500 cm2         | All                              |
| Cold start (to nominal load)         | > 600 minutes             | < 300 minutes   | Insulation (design)              |
| Capital costs (stack) minimum 1 MW   | > USD 2 000/kW            | < USD 200/kW    | Electrolyte, electrodes          |
| Capital costs (system) minimum 1 MW  | Unknown                   | < USD 300/kW    | All                              |

Based on IRENA analysis.

## 3.3 MATERIALS: USE, BARRIERS AND SOLUTIONS

Critical materials are mostly a limitation for PEM. The anode side is subject to a high potential for oxidising (&gt; 1.4 V) and  not  many  materials  can  provide long-term operation under these conditions. Because  of  this,  iridium  -    a  scarce  material  -  is used and the PTL requires significant amounts of titaniumbased  ( i.e. expensive)  materials,  coated with platinum. Although other options are available, platinum is used for the cathode, although tantalum seems to be a promising alternative for the coating. Titanium components are also responsible for the high costs of PEM, but this is mostly related to the expense  of  manufacturing  titanium  components, and less related to the raw cost of titanium.

Alkaline  electrolysers  mostly  use  nickel  to  resist the highly caustic environment.  Some  designs derived from the chlor-alkali industry include platinum and cobalt. For alkaline water electrolysis designs optimised for green hydrogen production, however, we have commercial examples available today that do not use these materials. Platinum and iridium, used in PEM, are two of the scarcest, most energy-intensive and emission-intensive metals (see Figure 23).

Figure 23.

Global warming  potential and  cumulative energy  demand  for  critical materials used in electrolysers.

<!-- image -->

Source: Nuss and Matthew, 2014.

Platinum  use  is currently about  1 g/kW  (FCH JU,  2019).  At  the  same  time,  primary  platinum production is in the order of 200 tonnes per year (t/year) 18 with  about  20%  more  coming  from the  recycling  of  catalytic  reformers  in  cars  and electronic  equipment.  Two  factors  that  further increase this number are the potential recycling of the platinum used by the industry and the expected decrease  in  platinum  content,  over  time.  These two  factors  are  discussed  further  below.  In  the hypothetical  case  of  using  the  entire  production of  platinum  for  electrolysers,  this  would  support the  deployment  of  200 GW  per  year  (GW/year). Considering  a  lifetime  of  at  least  ten  years  and full  recycling  of  platinum  from  decommissioned stacks,  this  pace  of  deployment  would  support the deployment of 2 000 GW in the next decade and 4 000 GW by the 2030s. Combined with the planned  reduction  of  platinum  requirements  in PEM electrolysers, this will further reduce the risk of material supply bottlenecks.

To avoid becoming a barrier to l arge-scale deployment, all the alkaline designs need to transition a platinum and cobalt free designs and platinum and iridium in PEM needs to be significantly reduced

Additionally, platinum and iridium are two of the most carbon and energy intensive materials in the electrolysers (see Figure 23). Platinum production emits about 12.5 tonnes of carbon dioxide (tCO 2 -eq ) per kilo of metal. This translates into about 0.01  kg  CO 2  -eq /kg  H 2 19 ,  which  is  relatively  small compared to the electricity input (only 10 grammes of  CO 2  -eq /kWh  would  be  equivalent  to  0.5  kg CO 2-eq /kg H ). Similarly, platinum production is the 2 most energy intensive among the critical materials in electrolysers with 243 gigajoules per kilo (GJ/kg). Given the high energy consumption of the electrolyser, however, the share of total electricity consumption  in  the  system  taken  by  producing these  metals  upstream  is  less  than  0.01%.  The supply of critical materials in electrolysers is mostly dominated  by  a  few  countries  (see  Figure  24). South Africa supplies over 70% of global platinum and over 85% of global iridium. This would strongly link PEM electrolyser deployment to supply from a few (mainly one) countries, with limited short-term alternatives in sight for replacing these materials for PEM.

Solid oxide electrolysers, which have the potential for much higher efficiencies, would also suffer from a similar risk, since almost 95% of the supply for all their critical materials (see Figure 24)  currently comes almost exclusively from China.

Iridium  use  is  currently  about  1-2.5 g/kW.  Global iridium  production  is  about  7-7.5 t/year  (Garside, 2019),  which  would  support  the  deployment  of 3-7.5 GW/year or 30-75 GW of electrolyser capacity in  the  next  decade,  reflecting  the  criticality  of reducing iridium content rapidly and significantly.

Alkaline  electrolysers  do  use  some  platinum  and cobalt, but there are already commercial designs that do not include these materials and the supply of nickel is more diversified when compared to the other metals.

The  same  applies  to  AEM,  which  does  not  use scarce  materials  and  mostly  requires  steel  and nickel.

Some 40% of this is used for catalytic converters in cars, so could eventually be available for other uses, as combustion engines are phased out.

19 Assuming a 10-year lifetime, a 50% capacity factor and platinum loading of 1 g/kW.

Figure 24. Top producers of critical materials in electrolysers.

<!-- image -->

Source: European Commission, 2020.

In terms of cost, the market for iridium is relatively small  (7-7.5  t/year),  illiquid  and  subject  to  high price volatility (European Comission, 2020). The  ratio  between  the  highest  and  lowest  price over  the  last  20  years  is  approximately  15  times. The  highest  price  was  in  2019,  with  USD  1 480 per  troy ounce,  which  is  equivalent  to  about USD46/kW  (considering  an  iridium  content  of 1g/kW). Furthermore, in the 2016-2018 period, the market  was  undersupplied  (European  Comission, 2020), which created an upward pressure on price, with  this  potentially  boosted  further  by  a  step demand  increase  coming  from  electrolysers.  For platinum,  the  market  is  larger  than  iridium,  but the price volatility is still high, with a ratio of five times between the highest and lowest price over the  last  20  years.  The  peak  price  in  that  period was just  before  the  2008  financial  crisis,  when  it was  USD  2 000  per  troy  ounce,  which  would  be equivalent to almost USD 60/kW (with an iridium content of 1 g/kW), while more recently the price has  stayed  in  the  USD  800-1 000  per  troy  ounce range.

There are three main strategies to reduce dependence on critical materials (Van Berkel et al., 2020):

-  Prevention  or  reduction  of  use:  This  covers substitution  of  the  materials,  reducing  their amount  per  unit  of  installed  capacity,  or varying  the  technology  mix  to  achieve  a lower use overall ( e.g. more alkaline instead of PEM that uses iridium). There are various options being investigated:
-  Use of high surface area supported catalysts  -  for  example,  titanium  or  tin oxide supports (Babic, 2017).
-  Increase the catalyst surface area through improved catalyst manufacturing techniques, for example using nanostructured thin film catalysts.
-  Use a thinner layer of coating material, for example through atomic layer deposition.
-  Reengineer  the  electrode  concept.  For example, support nanoparticles of iridium on high conductive semi-conductor oxides,  alloy  iridium  to  other  transition metals,  change  the  morphology  of  the electrode and shape the nanoparticle of iridium.

-  Extension  of  the  use  of equipment,  or increasing its efficiency : This includes achieving a higher productivity of the stack, which  translates  into  a  smaller  area  (and less material per kilo of hydrogen) or extend the lifetime of the electrolyser ( i.e. the same amount  of  material  allocated  over  greater production).
-  Recycling : There are various methods available for recovering noble metals from  electrochemical  devices  such  as  fuel cells and electrolysers. These include: hydrometallurgical treatment, transient dissolution, acid process and selective electrochemical dissolution. All of these can  be  used  for  platinum  in  PEM.  Further research is needed to estimate the potential benefit  of  recycling,  which  could  have  an impact on large-scale applications. It could also  have  an  impact  in  creating  a  parallel recycling industry to recover these materials and  would  be  fundamental  in  preventing potential materials bottlenecks, as we rapidly scale-up manufacturing.

almost  all  environmental  impact  categories  ( e.g. acidification, eutrophication, photochemical oxidation) and its lower use will also result in lower overall impact (Duclos et al. , 2017).

Implementing  these  strategies,  in  combination with  the  improved  electrolyser  performance,  can ultimately  reduce  the  specific  iridium  content  by 96% and the platinum content by 97.5% (see Table 7).  Parallel  to  this  development,  the  electrode area is  expected to increase almost fourfold and the current density by 2.5 times. This means the loading  per  unit  of  capacity  will  not  decrease as  drastically,  but  it  can  still  achieve  reductions of  70%  and  80%,  respectively,  for  iridium  and platinum. The electrolyser will also be developed in  terms  of  delivering  higher  current  densities (higher hydrogen production) for the same stack unit, which consequently means  less catalyst needed per unit produced.

Reducing platinum use is not only beneficial from the  perspective  of  scaling  up  electrolysers  and reducing  reliance  on  critical  materials,  but  also from  the  perspective  of  reducing  environmental impact. Platinum production dominates in

This is an area where the role for innovation will be increasingly important. Large players from the tech scene are getting involved in the context of leveraging their expertise to fight climate change. For instance, Facebook recently started a project focused  on  using  artificial  intelligence  to  find new  catalysts  to  improve  the  transformation  of renewable electricity into hydrogen (Wong, 2020).

Table 7. Iridium and platinum loading for PEM electrolysers with increased performance

and material reduction strategies.

|                             | TODAY   |   FUTURE |
|-----------------------------|---------|----------|
| Current density (A/cm 2 )   | 2       |     5    |
| Electrode area (cm 2 )      | 1 200   |  5000    |
| Iridium loading (mg/cm 2 )  | 5       |     0.2  |
| Iridium loading (g/kW)      | 1.3     |     0.4  |
| Platinum loading (mg/cm 2 ) | 2       |     0.05 |
| Platinum loading (g/kW)     | 0.5     |     0.1  |

Based on IRENA analysis.

## 3.4    INCREASING MODULE SIZE

The  largest  cost  share  is  the  balance  of  plant and  not  the  stack  itself  (see  Chapter  2,  Section 6).  Increasing  the  module  size  can  lead  to  some benefits in economies of scale, with these greater for  the  balance  of  plant.  The  stack  has  limited economies  of  scale  since  it  cannot  be  greatly increased in size, but will most likely be increased in number. This is due to problems that include, for example, leakage, limitations in the manufacturing of  large-scale  components,  mechanical  instability issues  for  large-scale  components,  the  maximum area of the cell, and others. The balance of plant, however, can have strong economies of scale. For instance, a compressor that is ten times larger ( e.g. going from 1 MW to 10 MW) is not ten times more expensive,  but  only  about  four  times.  This  would reduce the cost that such a compressor has on the overall  cost,  since  the  stack  would  be  9-10 times more  expensive  for  the  same  capacity  increase. This leads to the stack having a larger contribution to  the  total  cost,  as  module  size  increases  (see Figure 25).

<!-- image -->

Some studies have looked into the potential cost decrease for increasing the module  size and reaping these economies of scale (Saba et al., 2018; Böhm et al., 2020; Proost, 2020)a literature review was conducted to evaluate the published data on investment  costs  and  learning  rates  for  PEM  and alkaline electrolyzers from the 1990s until 2017 and the years beyond. The collected data are adjusted for inflation and specified in €2017 per kW-output using  the  higher  heating  value  (HHV.  Böhm  et al.  estimates  the  cost  exponent to be 0.60.75 for the  balance  of  plant  (Böhm  et  al.,  2020).  This would lead to a cost increase of 4-5.6 times when increasing  the  capacity  by  ten  times.  Saba  et  al. use  data  from  NEL  (one  of  the  main  electrolyser manufacturing  companies)  and  also  include  the cost penalty for increasing the operating pressure (Saba et al., 2018). Proost identifies  3-4 MW module size  as  a  tipping  point  to  go  from  a  single  stack to  a  multi-stack  and  achieve  a  significant  change in  the  cost  increase  for  every  additional  MW  of capacity (Proost, 2020). This is highly dependent on  stack  design,  however,  and  will  vary  from one  manufacturer  to  another.  Figure  26  shows  a comparison between the estimates of these studies plus the use of the cost shares in Section 3.6 and

the cost exponents from Böhm et al (Böhm et al., 2020). The largest economies of scale are reaped around  the  1 020 MW  module  size.  Beyond  this point,  the  marginal  cost  decrease  for  increasing the capacity is much lower than for module sizes in  the  12 MW  range.  The  'PlanDelyKad'  study  in Germany performed a bottom-up design and cost assessment finding close to 50% cost reduction for a 100 MW alkaline electrolyser (EUR 2014 520/kW input ) vs a 5MW  electrolyser (EUR 2014 1 070/kW input ) (Noack  et  al.,  2015).  One  of  the  manufacturers, Thyssenkrupp, claims significant cost benefits can still be achieved by going to 100 MW.

water electrolyser in Becancour-Canada, based on stack platforms of 2.5 MW. The plant is expected to be operational before the end of 2020.

Today, the largest electrolyser installed is a 10 MW facility in Fukushima, Japan, which is a single stack (FCW, 2020). Thyssenkrupp and NEL already offer designs  up  to  20 MW,  achieved  with  multiple stacks  (thyssenkrupp,  2018;  Nel,  2019)  without degradation in the efficiency or response capability of the electrolyser. The largest module from McPhy is 4 MW (McPhy, 2020), while the Sylizer 300 from Siemens is designed for 17.5 MW, constituted by 24 modules (of less than 1 MW each) (Bergen, 2019). Cummins (Hydrogenics) is building a 20 MW PEM

Another approach applied by some AEM manufactures is a strategy that focuses on design, achieving cost reduction by mass-manufacturing, standardisation,  and  supply  efforts  on  a  single stack  offering.  Larger  capacities  are  achieved  by using multiple stacks of this single size. Advantages include: the different flexibility response ( i.e. a set of smaller electrolysers can react more quickly than a single, large stack); a reduction in the impact of failure by a single unit; and a higher utilisation of the manufacturing equipment.

Figure26

Investment Cost  (USD/kW)

<!-- image -->

Source: Saba et al.

Alkaline 1 atm - 2014 (Saba et al., 2018)

, 2018; Proost, 2020.

Alkaline (Proost, 2020)

SCALING UP ELECTROLYSERS

TO MEET THE 1.5°C CLIMATE GOAL

## 4. STRATEGIES FOR COST REDUCTION: SYSTEM LEVEL

-  The largest benefits for economies of scale for electrolyser manufacturing seem to be reached around the 1 GW/year level. Several industrial players claim to have reached this  scale  or  are  working  towards  expansion.  One  measure  governments  could take  is  to  set  manufacturing  capacity  targets,  manufacturing  tax  benefits,  grants and loans for capacity expansion and work in close collaboration with industry. The Netherlands  and  the  UK  are  examples  of  where  this  is  happening.  A  predictable 5-10  year  pipeline  of  electrolysis  projects  -  driven  by  green  hydrogen  demand  will  be  key  for  manufacturers  to  invest  in  new,  larger  and  automated  production facilities.  Uncertainties  about  the  demand  for  green  hydrogen  versus  fossil-fuels based hydrogen is a key obstacle to the scaling up of electrolyser manufacturing: policy makers should carefully assess the balance, as learning from investments in green hydrogen versus blue hydrogen production are not interchangeable.
-  Water electrolysis deployment for green hydrogen has been limited so far, which introduces uncertainty around the cost reduction that can be achieved by scaling up. From this limited experience, it seems electrolysers have a similar relationship between cost decrease and global capacity as solar PV does - which could lead to 40% cost reduction, given the capacity targets governments have already announced. One action governments could take is to ensure cost is communicated transparently, in order to be able to track progress and identify potential.
-  Cost  decrease  is  greatest  during  the  current  early  stage  of  deployment,  when cumulative capacity deployed is still small and the market is relatively concentrated in a few companies. Current costs suffer from lack of transparency, due to the nascent stage  of  the  industry,  which  will  likely  be  resolved  as  large-scale  manufacturing facilities come online and large projects get commissioned. This, in turn, will facilitate price discovery and improve cost reduction forecasts.

Looking beyond the stack to include the balance of plant, there are two main strategies to reduce the cost:

-  Increasing the manufacturing scale of the  plant.  This  allows  reducing  the  cost contribution of each component by performing  a  high  throughput,  automated manufacturing  operation.  This  includes,  for example, rolltoroll manufacturing of the catalystcoated  membrane  (for  PEM)  and advanced coating processes for metal plates (Mayyas et al., 2019).
-  Learning-by-doing . This relates to standardisation, applying lessons learned from deployment and optimising the installation of equipment through the execution of multiple projects.

These  two  effects  are  not  independent,  since increasing the global cumulative deployment is  expected to be linked to an increase in global manufacturing  capacity.  Nevertheless,  applying both concepts separately allows us to draw different insights into the drivers of lower production costs.

## 4.1 MANUFACTURING SCALE OF ELECTROLYSERS

Increasing the manufacturing scale of the electrolyser plants can have a positive impact on their  specific  cost.  Large  manufacturing  volumes can  decrease  the  cost  contribution  of  buildings, improve the utilisation of equipment ( i.e. increasing the volume produced from each unit and reducing the  cost  contribution)  and  improve  the  process yield (reducing losses). Furthermore, for low volumes,  manual  assembly  might  be  necessary, while  higher  volumes  make  automatic  assembly attractive. These economies of scale during manufacturing have been assessed in the past for PEM  (NREL,  2019).  Figure  27  shows  the  system cost  for  producing  1 MW  units.  Two  aspects  to -note  are:  the  annual  production  rate  where  most of the cost benefits have been achieved; the cost categories  that  do  not  change  significantly  with the production rate and dominate the cost, even at high volumes.

Figure 27. Cost breakdown for PEM electrolysers as a function of manufacturing scale (units of 1 MW per year).

<!-- image -->

Note: Costs include material, labour, capital, energy, maintenance, buildings and scrap costs.

Source: Mayyas et al., 2019.

Focusing  on  the  stack  first,  Table  8  shows  that the  point  where  most  of  the  components  are dominated by the costs of material (and labour in the case of the assembly) is about 1 000 units per year ( i.e. 1  GW/year). Going from a 10 MW/year scale to 1 GW/year allows a 70% reduction in the stack cost, to about USD 70-80/kW. The largest benefit is for the stack assembly, which can experience a 90% cost reduction by going from a manual to a semi-automated  assembly  at  a  volume  of  about 1 GW/year,  with  a  subsequent  change  to  fully automated  at  2 GW/year.  This  automation  needs to happen at two levels: the cell and the stack, to have the highest cost impact. The cost saving is not only from automation of the process, but also from  using  advanced  coating  technologies,  such as rolltoroll and replacing current  processes,  such  as  spray  coating.  This allows  for  a  faster,  higher  throughput  process capable  of  producing  thicker  uniform  catalyst layers (Mayyas and Mann, 2019)material handling equipment (MHE. Frame manufacturing achieves a similar (85%-90%) cost reduction at the same scale ( i.e. 1GW/year). The cost reduction for components that  contain  rare  materials  is  less  pronounced, with the CCM and PTL only being able to achieve between 45%-55% cost reduction at the 1 GW/year scale.  This  results  in  stack  cost  being  dominated by the platinum, iridium, 20 membrane, titanium and gold costs, for large production volumes. Further cost reductions can only be achieved through the material reduction strategies presented in Section 4.3 of this report.

Table 8. Economies of scale for PEM stack manufacturing.

| Stack component             | Capacity to reap most of the economies of scale   | Dominant costs at high production rates   | Cost penalty for low production volumes   | Cost achieved at 1 000 units/ year   |
|-----------------------------|---------------------------------------------------|-------------------------------------------|-------------------------------------------|--------------------------------------|
| Catalyst coated membrane    | 1 000 units/year                                  | Platinum, iridium, (Nafion) membrane      | 75%-80%                                   | ≈ USD 46/kW                          |
| Porous transport layer      | 20-100 units/year                                 | Titanium powder, gold (coating material)  | 110%                                      | ≈ USD 26/kW                          |
| Frame                       | 1 000 units/year                                  | Materials (95%)                           | 800%-900%                                 | ≈ USD 1.8/kW                         |
| Membrane Electrode Assembly | 1 000 units 1 /year                               | Materials (90%)                           | 350%                                      | ≈ USD 11/kW                          |
| Assembly                    | 1 000 units/year                                  | Labour (50%)                              | 1 000%                                    | ≈ USD 2/kW                           |

Source: Mayyas et al. , 2019.

20 r(NREL, 2019) reflects assumptions of 7 g/m 2  for platinum loading in the anode, 4 g/m 2  for the anode (platinum-iridium), a platinum price of USD 1 500 per troy ounce, a Nafion 117 (membrane) and titanium plates coated with 100 nanometres (nm) of gold.

21 One unit requires about 50 MEA, assuming a 1 MW system, so 1 000 units is equivalent to 500 000 MEA/year, which is assumed to trigger the shift from manual to semi-automated assembly.

For the balance of plant, however, the cost reduction is smaller than for the stack. The same increase  in  production  rate,  from  10 MW/year  to 1 GW/year, leads to a cost reduction of about 40% in  the  balance  of  plant.  This  means  the  balance of plant goes from about 55% of the total cost to almost 75% on a 1 GW/year scale (see Figure 28).

The largest cost reductions - of 50%-60% - can be achieved in the deionized water circulation and the cooling systems. These, however, are relatively small and the dominant costs of the power supply and  hydrogen  processing  only  reduce  by  about 30%.

Figure 28. Cost breakdown for PEM electrolysers for a (a) 10 MW/year; (b) 1 GW/year production scale.

<!-- image -->

<!-- image -->

<!-- image -->

Based on IRENA analysis based on Mayyas et al., 2019.

Two years ago, the electrolyser market was about 135  MW/year,  with  the  largest  manufacturers  in the order of 10-20 MW/yr. As shown in the figures above, this is where the cost contribution of fixed costs is the largest. Today, various estimates and announcements point towards a higher manufacturing capacity. The World Bank estimates the capacity to be 2.1 GW/year with announcements on capacity expansion adding up to 4.5 GW/year (World Bank, 2020). The IEA estimates a capacity of  1.2  GW/year  just  in  Europe.  Looking  at  claims and announcements from manufacturers:

-  Thyssenkrupp has a manufacturing capacity of 1 GW/year that could be expanded.
-  NEL is expanding the capacity of their facility at Herøya  Industrial  Park  (Norway)  from 40 MW/year  to  360 MW/year,  with  future expansion plans of up to 1 GW/year.
-  ITM  is  part  of  the  Gigastack  project,  that aims  to  ramp  up  production  capacity  to 60 stacks per year (300 MW/year) by 2023 and  200 stacks  (1 GW/year) by 2025. This is  to  be  done with a simultaneous increase in  the  system  size  to  20 MW  to  achieve  a specific investment  cost  of  GBP 400/kW with a module size of 100 MW. The ramping up is 60 stacks per year (300 MW/year) by

## 4.2 LEARNING-BY-DOING

The experience curve or learning curve 22  refers to the  decline  in  production  cost  as  the  cumulative capacity  for  a  specific  technology  doubles.  This represents innovation by production and is driven by competition between firms in the market that complements innovation driven by research. There are multiple ways this cost decrease can be achieved. For example, a lower contribution from fixed  costs,  a  reduction  in  the  production  time, standardisation, specialised companies for certain parts of the value chain, and alternative processing steps, including simplification.

Larger  cumulative  deployment  not  only  leads  to more experience from project developers, but also financial institutions. This can in turn lead to lower risk perception, lower the cost of debt and further cost reduction.

Water  electrolysis  shares  the  same  principles  as chlor-alkali  production  (which  already  produces hydrogen today). This means, for learning purposes, the starting point for water electrolysis is not the 0.2 GW of PtX existing today, but instead the cumulative 20 GW of electrolyser capacity that

22 In a more nuanced differentiation, the learning curve refers to the relationships between cumulative capacity and lower production time, while the experience curve relates capacity to cost (Böhm, 2019).

2023 and 200 stacks (1 GW/year) by 2025. The  project  is currently in the frontend engineering and design (FEED) phase (Phase II),  with  the  design  of  the  100 MW facility, which is 5x20 MW, with this expected to be completed by the end of 2020.

A scale of 1 GW/year for the manufacturing plant might be enough to achieve economies of scale during production. Some manufacturers already claim to be at this scale or with plans to achieve such a production level

-  While  Siemens  does  not  have  an  explicit manufacturing  target,  it is also involved in various  100 MW+  projects  around  the globe,  putting  them  in  a  good  position  to expand capacity. One of these projects is the Murchison  Renewable  Hydrogen  Project  in Australia, which has scope for up to 5 GW of renewable capacity and is initially expected to  produce  hydrogen  for  transport  fuels, followed  by  blending  with  natural  gas  and exports.

has  been  deployed  for  chlor-alkali.  Similarly,  the learning rate for electrolysis can build upon existing studies that look at fuel cells, since these are the same  fundamental  process,  but  in  the  reverse direction 23 . Fuel cells and electrolysers can benefit from developments in batteries (IEA, 2020), since they also use the same principle and share the same component families (anodes, cathodes, membranes  and  assemblies).  This  would  allow electrolysers  to  indirectly  benefit  from  battery electric  vehicle  (BEV)  and  fuel  cell  deployment across the various transport modes and even on large-scale stationary use. These cumulative cost reductions can be captured in a learning rate.

Table  9  shows  a  survey  of  the  studies  that  have estimated learning rates for electrolysers and fuel cells, with data going back over 60 years in some cases. Most of the studies find a learning rate of 16%-21%, with several having the mid estimate at 18%. One of the studies (Wei, Sarah Josephine Smith and Sohn, 2017), which focuses on smallscale fuel cell  applications  in  California,  does  not,  however, demonstrate any learning throughout the period analysed (2007-2015).

Electrolysers have similar learning rates to solar PV and could experience similar cost decreases with large-scale deployment. This learning opportunity might decrease over time as deployment takes place

Reasons  for  the  lack  of  learning  in  that  study included  the  lack  of  a  competitive  market,  lack of favourable market conditions and lack of government targets for technology adoption. This  shows the importance of public support for both  deployment  and  learning.  Considering  the mid-estimate  of  18%  and  the  20 GW  of  existing capacity, the potential cost decrease from deployment is shown in Figure 29.

Table 9.

Learning rate estimates for electrolysers and fuel cells.

| Learning rate (%)   |                       | Notes                                                         | Reference                                   |
|---------------------|-----------------------|---------------------------------------------------------------|---------------------------------------------|
| 9                   | Electrolysis          | Alkaline for 2020-2030                                        | (Hydrogen Council, 2020)                    |
| 13                  | Electrolysis          | PEM for 2020-2030                                             | (Hydrogen Council, 2020)                    |
| 18 +/- 6            | Electrolysis          | 1956-2014 data (alkaline)                                     | (Schmidt et al. , 2017)                     |
| 18 +/- 13           | Electrolysis          | 1972-2004 data                                                | (Schoots et al. , 2008)                     |
| 8                   | Electrolysis          | Floor cost of USD 350/kW (alkaline)                           | (Gül et al. , 2009)                         |
| 18 +/- 2            | PEM fuel cell         | 1989-2012 data                                                | (Schmidt et al. , 2017)                     |
| 18                  | PEM fuel cell         | Initial capacity of 1.1 GW                                    | (McDowall, 2012)                            |
| 15                  | PEM fuel cell         | Based on proprietary data                                     | (McKinsey, 2010)                            |
| 21 +/- 3            | PEM fuel cell         | 1996-2006 data                                                | (Schoots, Kramer and van der Zwaan, 2010)   |
| 15                  | PEM fuel cell         | Floor cost of USD 50/kW                                       | (Gül et al. , 2009)                         |
| 0%                  | Solid oxide fuel cell | California self-generation incentive programme                | (Wei, Sarah Josephine Smith and Sohn, 2017) |
| 16 +/- 3            | µ CHP                 | Based on EneFarm, Korean demonstration and PEMFC manufacturer | (Staffell and Green, 2013)                  |
| 18 +/- 2            | µ CHP                 | Based on EneFarm                                              | (Wei, Sarah J. Smith and Sohn, 2017)        |

Source: See 'Reference' column.

## Figure 29. Potential cost decrease for electrolysers based on a learning rate and costs achieved by deployment in IRENA scenarios by 2030 and 2050.

Notes: 1 TW of installed capacity by 2050 is about 1.2 TW of cumulative capacity due to lifetime and replacement. Similarly, 5 TW by 2050 is equivalent to 5.48 TW of cumulative capacity deployed.

<!-- image -->

Based on IRENA analysis.

In the Planned  Energy  Scenario from IRENA, electrolysers could achieve about 40% cost reduction by 2030 with 100 GW of capacity deployed. In the case of the Transforming Energy  Scenario  that  requires  a  more  aggressive deployment  of  270 GW  of  electrolysers  by  2030, an  almost  55%  cost  reduction  is  achieved.  In  the long  term,  looking  at  a  closetozero  emissions system, where 1 700 GW of electrolysis is deployed by 2050, the cost reduction can be over 70%. This is  not  dramatically  different  from  the  Hydrogen Council  estimate  of  a  cost  reduction  of  60%  by 2030  through  a  combination  of  manufacturing scale,  learning  rate,  technological  improvements and  increase  in  the  module  size  from  2 MW  to 90 MW (Hydrogen Council, 2020).

Similar to the economies of scale for manufacturing, where components reduce their cost unevenly with scale,  the  potential  for  learning  is  also  different by  component.  A  recent  report  (Böhm,  Goers and  Zauner,  2019)  looked  into  the  learning  rate by  component  for  alkaline,  PEM  and  solid  oxide electrolysers (see Table 10). For this, components are assigned  one  of  three learning rates: 5% for technologyindependent standard parts ( e.g. flanges);  8%  for  peripheral  parts  that  are technology specific ( e.g. catalysts); and 18% for the core components of the electrolyser.

Table 10. Learning rate by stack component for three types of electrolysers.

| TECHNOLOGY                            | COMPONENT                             | LEARNING RATE (%)                     |
|---------------------------------------|---------------------------------------|---------------------------------------|
| Alkaline                              | Structural rings                      | 5%                                    |
| Alkaline                              | Polytetrafluoroethylene seal          | 8%                                    |
| Alkaline                              | Bipolar plates                        | 18%                                   |
| Alkaline                              | (Pre)electrodes                       | 18%                                   |
| Alkaline                              | Membrane                              | 18%                                   |
| Alkaline                              | Flanges                               | 5%                                    |
| Alkaline                              | Tie rods                              | 5%                                    |
| PEM                                   | Stack assembling                      | 8%                                    |
| PEM                                   | Small parts                           | 5%                                    |
| PEM                                   | MEA manufacturing                     | 8%                                    |
| PEM                                   | Catalysts                             | 8%                                    |
| PEM                                   | Membranes                             | 18%                                   |
| PEM                                   | Current collectors                    | 18%                                   |
| PEM                                   | Bipolar plates                        | 18%                                   |
| PEM                                   | End plates                            | 8%                                    |
| Solid oxide                           | Stack assembling                      | 8%                                    |
| Solid oxide                           | Electrolyte                           | 18%                                   |
| Solid oxide                           | Catalysts                             | 18%                                   |
| Solid oxide                           | Porous transport layer                | 18%                                   |
| Solid oxide                           | Interconnector                        | 18%                                   |
| Solid oxide                           | Sealings                              | 5%                                    |
| Solid oxide                           | End and pressure plates               | 8%                                    |
| Balance of plant                      | Power supply                          | 12%                                   |
| Balance of plant                      | Gas conditioning                      | 7%                                    |
| Balance of plant                      | Small purchased parts                 | 12-15%                                |
| Balance of plant                      | Machining                             | 10%                                   |
| Balance of plant                      | Welding                               | 10%                                   |
| Source: Böhm, Goers and Zauner, 2019. | Source: Böhm, Goers and Zauner, 2019. | Source: Böhm, Goers and Zauner, 2019. |

Components  that  have  a  high  learning  rate  will represent  a  smaller  share  of  the  overall  cost  as capacity  increases,  since  their  cost  decrease  is larger  than  components  with  a  low  rate.  This means the overall learning rate goes towards the lower values with larger capacities (see Figure 30). This approach indicates that using a fixed value for the learning rate can result in an overestimation of the potential cost decrease.

Figure 30. Variable learning rate based on components for three types of electrolysers.

<!-- image -->

Source: Böhm, Goers and Zauner, 2019.

<!-- image -->

## GREEN  HYDROGEN COST REDUCTION 2 Green hydrogen project pipeline 2.1 Key players As green hydrogen from renewables becomes a reality, more and more players from both 5. GREEN HYDROGEN PROJECT PIPELINE

-  Announcements of projects coming online in the next five years add up to a total that is two orders of magnitude greater than today's globally installed capacity. Yet, even steeper growth would be needed to be in line with 1.5°C pathways. This requires a further acceleration in the deployment of renewable power capacity, which needs to be at least ten times higher in 2050 than what it was in 2019. Therefore, hydrogen use should be limited to sectors where direct electrification is more difficult, to maximise the efficiency of renewable electricity use.

## 5.1 KEY PLAYERS

R&amp;D  institutions and  industry  will appear, increasing  competition  that  leads  to  much faster R&amp;D  and  a  significant  reduction  in costs.  Currently,  the  field  of  green  hydrogen generation is growing at such a fast rate that is  quite challenging to follow or identify new players.  Historically,  with  a  few  exceptions, water electrolysers were  manufactured  by small companies. Now, large enterprises are  currently  very  active  in  acquiring  and merging smallmedium sized electrolyser companies  into  their subsidiary portfolios. This  will  dramatically  and  positively  increase investment, much more rapidly changing the  technology  and  decreasing  costs.  Table 11  shows  a  non-exhaustive  list  of  companies, enterprises  and  key  players  involved  in  the manufacturing  and/or  commercialisation  of water electrolysers.

Table 11. A nonexhaustive list of key players involved in the manufacturing of water electrolyser systems.

| COMPANY                | MANUFACTURING SITE                     | ELECTROLYSER TYPE   |
|------------------------|----------------------------------------|---------------------|
| AQUAHYDREX             | AUSTRALIA, USA                         | ALKALINE            |
| ASAHI KASEI            | JAPAN                                  | ALKALINE            |
| AREVAH 2               | FRANCE, GERMANY                        | PEM                 |
| CARBOTECH              | GERMANY                                | PEM                 |
| COCKERILLL JINGLI      | CHINA                                  | ALKALINE            |
| CUMMINS - HYDROGENICS  | BELGIUM, CANADA, GERMANY               | PEM AND ALKALINE    |
| DENORA                 | ITALY, JAPAN, USA                      | PEM AND ALKALINE    |
| ENAPTER                | ITALY                                  | AEM                 |
| GINER ELX              | USA                                    | PEM                 |
| GREEN HYDROGEN SYSTEMS | DENMARK                                | ALKALINE            |
| HALDOR TOPSOE          | DENMARK                                | SOLID OXIDE         |
| HITACHI ZOSEN          | JAPAN                                  | ALKALINE AND PEM    |
| HONDA                  | JAPAN                                  | PEM                 |
| HYDROGENPRO            | NORWAY                                 | ALKALINE            |
| iGAS                   | GERMANY                                | PEM                 |
| ITM                    | UK                                     | PEM                 |
| KOBELCO                | JAPAN                                  | ALKALINE AND PEM    |
| KUMATEC                | GERMANY                                | ALKALINE            |
| MCPHY                  | FRANCE, ITALY, GERMANY                 | ALKALINE            |
| NEL Hydrogen           | DENMARK, NORWAY, USA                   | PEM AND ALKALINE    |
| PERIC                  | CHINA                                  | ALKALINE            |
| PLUG POWER             | USA                                    | PEM                 |
| SHANGHAI ZHIZHEN       | CHINA                                  | ALKALINE            |
| SIEMENS ENERGY         | GERMANY                                | PEM                 |
| SOLIDpower             | ITALY, SWITZERLAND, GERMANY, AUSTRALIA | SOLID OXIDE         |
| SUNFIRE                | GERMANY                                | SOLID OXIDE         |
| TIANJIN                | CHINA                                  | ALKALINE            |
| TELEDYNE               | USA                                    | PEM                 |
| THYSSENKRUPP UHDE      | GERMANY                                | ALKALINE            |
| TOSHIBA                | JAPAN                                  | SOLID OXIDE         |

Based on IRENA analysis.

## 5.2  PROJECT PIPELINE AND EXPECTED FUTURE MANUFACTURING CAPACITY

## Figure 31.

(a) Historical and (b) Future (based on announcements and projects)

electrolyser capacity.

<!-- image -->

Note: Only water electrolysis included.

Source: IEA TCP

With  such  a  challenging  background  in  mind, powertogas demonstration projects of current generation using electrolysis technologies are important. The number of demonstration projects using electrolysers at scale has significantly increased and evolved in recent years (see Figure 31), and most of these for PEM and alkaline electrolysers. In addition,  many  demo  projects have also tackled the hydrogentoefuels route, as a way of increasing the speed of hydrogen's market penetration, especially for transportation purposes and  other  important  markets.  A  consortium  of seven  private  companies  have  also  established  a target of 25 GW of electrolysers capacity by 2026 aiming to reduce the cost to less than USD 2/kg. This  coalition  is  called  Green  Hydrogen  Catapult and it is part of the Race to Zero Campaign from the United  Nations  Framework  Convention  on Climate Change.

Increasing manufacturing capacity at pace is going to  be  equally  important,  to  avoid  bottlenecks  in electrolyser  supply.  To  reach  an  estimated  15 TW of installed capacity in 2050, 24 a  rapid scale up of electrolysis capacity from an estimated 2 GW in  2020  to  at  least  10-60 GW/year  by  2030  and 70-360  GW/year  by  2040  -  as  estimated  in Figure  32  -  is  required.  This  necessitates  a  rapid acceleration in the industrialisation of electrolyser manufacturing.  This  also  has  to  happen  together with  development  of  the  necessary,  related  EPC capacity  to  design,  build  and  commission  such facilities  at  an  increasingly  rapid  pace.  To  reach net zero emissions by 2050, nothing less than the upper end of the range will be necessary.

Figure 32. Estimated necessary electrolyser manufacturing capacity (GW/year) to meet different installed capacity targets by 2050.

<!-- image -->

Based on IRENA analysis.

In  terms  of  the  investment  necessary  to  scale up manufacturing capacity, a recent report (Cihlar  et  al.,  2020)  estimates  a  cost  per  GW  of annual  manufacturing  capacity  in  the  range  of EUR 45-69 million, with the lower end for alkaline and  the  higher  end  for  PEM.  Combined  with  the estimated  manufacturing  capacity  requirements in Figure 32, this translates into a cumulative investment in manufacturing capacity of between USD 5-45 billion for the period 2020-2050, depending on the installed capacity target.

## GREEN  HYDROGEN COST REDUCTION 6. THE ROAD TO SCALING UP GREEN HYDROGEN : A MILESTONEDRIVEN APPROACH

## KEY POINTS

-  Progress towards a lower cost is not a time bound trajectory. The cost-reduction pathway will be defined by how quickly specific key milestones are achieved. This depends on governments setting time bound targets and measures to support green hydrogen demand, which in turn will promote scale up (explicitly or implicitly) and increased competition in electrolyser manufacturing and deployment.
-  No  single  cost  reduction  strategy  is  recommended  to  be  pursued,  as  the  four strategies presented in this report should be considered in parallel. A combination of government support for research programmes in parallel with the establishment of policies and targets, combined with private sector efforts towards standardisation and optimised designs will lead to lower electrolyser costs and ultimately cheaper green hydrogen.
-  A 40% cost decline could be achievable in the short term, with a final 80% cost reduction in the long term when all the targets are achieved.
-  Investment cost is only one component of the total green hydrogen cost. To achieve cost  competitiveness  with  fossil-based  hydrogen,  low  electricity  cost,  favourable regulation, higher efficiency and a longer lifetime will be needed.

The strategies for cost reduction presented in this report  are  highly  interrelated  and  pursuing  only one might not even be possible. Furthermore, this is not a sudden process involving abrupt changes. Instead,  it  is gradual,  with  multiple  reinforcing loops.

Larger  manufacturing  capacities  are  likely  to  be associated with the deployment of larger modules and will also favour more  deployment, since production  cannot  be  too  far  ahead  of  market demand. Therefore, to reach multi-GW production capacities,  a  multi-GW  market  also  has  to  exist. There is a positive feedback, similar to any other

part of the energy system, where research leads to improvement in performance (durability, efficiency and  cost),  which  makes  the  technology  more competitive, triggering deployment (learning-bydoing), which enables lower cost, attractive private capital for R&amp;D and further improvement.

In exploiting these  synergies, different stages of  development  can  be  identified,  where  each strategy reinforces changes taking place in other parts  of  the  value  chain  and  all  act  in  the  same direction to drive the cost down. Figure 33 splits the  period  from  where  we  are  today  to  a  future with a low cost of investment in electrolysers into three  stages.  Each  is  followed  by  a  description of what should happen in every stage and every strategy to achieve long-term, low-cost hydrogen. Progressing  from  one  stage  to  the  next  is  not  a timebound activity. Instead, how fast the end cost in Stage 3 is achieved will depend on how fast the milestones are reached. This will depend on policy support, capital invested and deployment.

Figure 33. Milestones for four cost reduction strategies across three stages of deployment for electrolysers.

<!-- image -->

Alkaline and PEM

AEM and solid oxide

## Stage 1: Market establishment

-  Manufacturing  scale : At this stage, the market  is  still  concentrated  in  the  hands of  a  few  players.  Most  of  them  are  in  the MWscale,  still  using  manual  assembly  and relying on individual projects to adjust production.  Most  manufacturers  are  in  a stalemate situation where funding and investment  is  needed  to  expand  capacity, but  project  capacities  cannot  be  met  with such  a  small  manufacturing  capacity.  The leading manufacturers are starting to expand capacity in anticipation of future growth and starting to discover some of the economies of scale. Companies that produce chlor-alkali have a head start for water electrolysis, given that a large part of the supply chain can be used as a springboard.
-  Module  size : Modules  are  relatively  small, with  most  of  the  options  available  in  the market in the MWscale. Projects that target 10, 20, 30 MW  are  mostly  numbering  up smaller  electrolysers  and  the  balance  of plant  is  not  fully  optimised.  These  small modules are ideal for onsite hydrogen generation in refuelling stations, which matches the relatively small requirements of transport applications, avoids infrastructure development  and  scales  much  better  than fossilbased hydrogen  production. Several manufacturers are starting to envision 100MW+ designs, but no experience of this creates  a gap  between  engineering  and reality to be closed in subsequent stages.
-  Learning-by-doing : There is limited experience in water electrolysis and most of the lessons are drawn from chlor-alkali. Water electrolysis  is  being  deployed  in  multiple new applications by multiple manufacturers, which  creates  custom  designs  that  need to be adjusted before being used in another  system.  These  demonstration  and firstofakind  plants  still  have  a  large  cost associated to engineering and installation and potentially with planning and execution delays.  On  the  positive  side,  the  learning rates are the highest at this stage, since there are multiple opportunities for optimisation.
-  R&amp;D :  Research  done  at  this  stage  has  the highest benefits, since the technology is at the earliest stage of development. The areas to focus on for alkaline electrolysers are: the current density (to achieve higher production rates); the diaphragm thickness (to achieve higher  efficiencies  and  lower  costs);  and the  design  of  the  electrodes  and  catalysts. For  PEM,  the  largest  cost  contribution  and potential for reduction comes  from  the bipolar  plates  (which  provide  mechanical support  and  distribute  the  flow)  and  the PTL  (which  facilitates  the  mass  transport of reactants). Fundamental research on AEM  membranes  could  potentially  deliver great  benefits  in  subsequent  stages,  if  a breakthrough is achieved. Similarly, research on  lifetime  and  electrolyte  conductivity  for solid  oxide  could  unlock  a  step  change  in electrolyser  performance in the next stage. At this stage, not all companies are familiar with  hydrogen  and  government  support  is needed  to  deploy  demonstration  projects that either provide the bridge between lab and commercial scale, or showcase applications that have been deployed elsewhere with different local conditions.

## Stage 2: Scaling up and improving design

-  Manufacturing scale : The project pipeline is growing quickly, and manufacturing capacity needs  to  be  expanded  to  support  such growth.  The  largest  players  are  benefiting from economies of scale, reaching the 1 GW/year mark and beyond. This enables a 60%-70% cost reduction in the stack, compared  to  a  MW-scale.  Assembly  goes from a manual to a semi or fully automated process.  Production  becomes  much  more efficient  with  less  wasted  materials.  Cost contribution from items such as buildings and capital in machinery becomes progressively a smaller share of the total manufacturing cost. Yet, these developments are not widespread and players who take the lead incur a higher risk,  with  the  higher  pay  out  of  achieving scale first and a lower manufacturing cost.

-  Module  size : Electrolysers  of  20 MW and even 100 MW are now the norm. The balance of  plant  has  now  been  optimised.  There are  dedicated  suppliers  for  the  electrical equipment,  and  this  is  no  longer  done  by electrolyser manufacturers. This enables standardisation and the achievement of lower costs. Power supply is also optimised, with stack  design  considering  variable  load  and efficiency.  Use  of  pressurised  electrolysers allows  a  reduction  in  compression  needs. The  combination  of  these  effects  unlocks a  lower  cost  for  the  auxiliary  equipment complementing the advances from R&amp;D for the stack.
-  Learning-by-doing :  Leading  manufacturers have built experience with project execution. Some  typical  business  cases  are  starting to  arise,  which  creates  the  opportunity  to both  standardise  and  optimise  the  design to satisfy requirements. International players and  organisations  serve  as platforms  to exchange lessons and work towards global standards.  New  manufacturing  plants  are constructed, which have a much  lower cost  than  their  predecessors.  Engineering, construction,  equipment  suppliers,  are  all familiar with electrolysis, which enables faster project development, leaner execution and lower costs.
-  R&amp;D :  Some  of  the  largest  cost  tickets  for electrolysers have been tackled before. Now, the focus shifts towards material optimisation.  If  electrolysers  are  to  achieve large scale, the materials used  need  to decrease in quantity, not only to reduce cost, but also to ensure sustainability and having to increase current supply by several orders of magnitude. For alkaline technology, this  means  a  transition  to  a  platinum  and cobaltfree  design.  This  has  already  been achieved today by some  manufacturers, but not all.  Keeping  these  two  materials  in the design could limit the role that alkaline electrolysers have in the future. For PEM, a combination  of  reduction,  higher  hydrogen production  and  recycling  strategies,  allows reducing  the  iridium  and  platinum  content by unit of installed capacity by 70% and 80% respectively.  This  is  particularly  important

for iridium, which has currently limited market  liquidity  ( i.e. high  price  volatility  of a  factor  of  15  times  between  the  minimum and maximum  over  the  last 20 years), limited  supply  diversification  (over  85%  of the current supply comes from South Africa) and a relatively small market (current supply could  only  support  a  capacity  of  about 75 GW of electrolysis).

## Stage 3: A global market

-  Manufacturing scale : Hydrogen use is growing  across  all  sectors,  from  planes  to ships  to  trucks  and  industry.  This  requires a  larger  electrolyser  production  upstream. This  creates  competition  and  attracts  new players.  What  in  the  previous  stage  was only  possible  for  a  few  companies,  is  now more widespread and accessible to multiple enterprises. This in turn creates competition to optimise manufacturing further and have an edge in what is now a market with tighter  margins.  This  race  benefits  project developers further, since the lowest cost can be achieved.
-  Module  size : There  are multiple choices available for project developers. From 100 MW+  modules  that are suitable for industrial applications to singledigit MW modules that, by this stage, also incorporate some  of  the  benefits  of  larger  modules. Higher current densities have been achieved for both alkaline and PEM electrolysers, which enables a smaller footprint for all the sizes. AEM and solid  oxide  have  already  crossed the boundary from lab to commercialisation and module sizes are in the multi-MW scale.
-  Learning-by-doing : Deployment  still  leads to  learning,  but  the  largest  cost  reduction has  been  achieved  by  now.  The  cost  starts being dominated by core materials, with an optimised stack and balance of plant. There is  still  potential  for  cost  reductions  in  the next  generation  of  electrolysers,  AEM  and solid oxide.

-  R&amp;D : By now, alkaline and PEM have reached maturity with high efficiency, durability and low material use. Research is now driven by private  funds  rather  than  public  support  in the search  for proprietary developments and a competitive advantage that delivers a higher market share. New AEM membranes could  have  been  developed  by  now  that combine  the  best  of  both  worlds  (alkaline and PEM), with no expensive titanium, no  expensive  membrane,  high  operating

pressure,  no  electrolyte  solution,  or  tight water requirements. AEM  are  taking an increasing  market  share  of  a  burgeoning hydrogen sector. Similarly, solid oxide is now commercial, offering a more efficient option that can be integrated with hydrogenderived products.

Applying these strategies would unlock the low-cost  potential  of  electrolysers,  achieving  a 40% reduction in the short term and an 80% one in the long-term (see Figure 34).

Figure 34. Potential cost reduction by implementing strategies presented in this report across three stages of deployment.

<!-- image -->

Based on IRENA analysis.

With the goal of achieving green hydrogen competitiveness in mind, the cost of the electrolyser is  not  the  only  factor  (see  Figure  35).  Once  the operating hours of the electrolyser reach the order of 3 000-4 000 hours per year, the main contributor to the production cost is the electricity price. The strategies shown in this report will enable a higher efficiency, decreasing the cost contribution of the electricity  input.  In  parallel,  renewable  electricity -already more  competitive than fossil-based electricity  in  many  jurisdictions  -  will  continue scaling up and achieving lower costs.

Figure 35. Step changes for achieving green hydrogen competitiveness.

<!-- image -->

Note: 'Today' captures best and average conditions, with an average investment of USD 770/kW, efficiency of 65% (LHV), an electricity price of USD 53/MWh, 3 200 full load hours (onshore wind), a WACC of 10% (relatively high risk). Best conditions are USD 130/kW, efficiency at 76% (LHV), electricity price at USD 20/MWh, 4 200 full load hours (onshore wind), and WACC of 6% (similar to renewable electricity today).

Based on IRENA analysis.

## GREEN  HYDROGEN COST REDUCTION 7. CONCLUSIONS : STAKEHOLDER ROLES I N SCALING UP

Today,  green  hydrogen  represents  only  a  limited share  of  global  supply.  The  transition  to  a  future where  green  hydrogen  has  not  only  displaced fossilbased  hydrogen,  but  also  gone  beyond  the industrial  sector  to  become  a  fuel  and  energy carrier, will therefore  not  happen  overnight.  It will  also  not  happen  without  the  participation  of multiple  stakeholders.  Coordination  is  key,  across four dimensions at least:

-  Across sectors : The green hydrogen covered in  this  report  will  benefit  from  combining different applications to aggregate demand, justifying larger projects and achieving economies  of  scale  that  benefit  production and, perhaps, infrastructure.
-  Across  the  value  chain : Hydrogen  supply (as covered in this report) has to be done in parallel with infrastructure development and, more  importantly,  demand.  At  least  during the early stages, when a market has not yet developed,  production  projects  need  to  be codeveloped with an offtaker, since there is no  grid  or  ubiquitous  established  sink  that can absorb all the production. While blending in  the  gas  grid,  if  combined  with  tracing and financial  compensation,  can  provide  an alternative, it is only an alternative for early stages of development.
-  Across borders :  All  sectors, from electrolysers to  fuel  cells, direct  reduction  of  steel  to ammonia  ships and synthetic fuels, will benefit from global collaboration. This applies to the deployment level - enabling learning from projects to drive costs down - and at the research level, enabling the coordination of national programmes.
-  Across  stakeholders : Green  hydrogen  will not  scale  up  without  support  from  multiple stakeholders.  Fortunately,  there  is  already widespread interest in hydrogen from energy utilities, steel makers, chemical companies, port authorities, car and airplane manufacturers, shipowners and airlines, amongst others, but their actions need to be in the same direction.

For  governments,  there  are  multiple  actions  that could  be  pursued  to  promote  green  hydrogen production.  Most  of  these  will  have  the  largest impact in the early stages of deployment (see Figure 36). Some, however, such as market regulation and financing, will be crucial once the market kicks off and  the  scale-up  process  begins.  Governments should  also  adopt  a  flexible  approach  in  which strategies  and  targets  are  frequently  reviewed  to give  consideration  to  the  latest  developments. For example, the Australian strategy includes this approach (Strategic Actions 2.1 and 2.2) to remove market barriers and support technology growth, as the market develops.

Figure 36. Main actions and functions for key stakeholders influencing the scale up of

green hydrogen.

<!-- image -->

Based on IRENA analysis.

## Enabling actions

-  Long-term signals and commitments : These are necessary to attract private capital, which will  be  needed  for  scaling  up.  For  conventional technologies,  investors  already  have  longterm horizons, covering the lifetime of assets, aiming to recover the cost and make a profit. For hydrogen production with water electrolysis - a nascent industry - additional certainty  from  governments  is  needed  to justify  the  additional  risk  and  investment. This can come in the form of commitment to netzero emissions targets, since hydrogen is the most useful for hardtoabate sectors that are required to achieve these targets, or in the form of strategies that set the direction for hydrogen deployment. This commitment to  develop  hydrogen  should  ultimately  be reflected  in  the  long-term  strategies  and nationally determined contributions of each country.
-  Market creation :  This will drive demand for green hydrogen. One measure in this is public procurement ( e.g. a  percentage of green steel for public infrastructure). Blending mandates or quotas are also an attractive alternative. Examples  include:  requiring  a  percentage of  industrial  hydrogen  to  shift  to  green,  as already  covered  in  French  and  Portuguese strategies;  requiring  a  percentage  of  gas demand  to  be  met  by  green  hydrogen, or  requiring  a  percentage  of  shipping  or aviation  fuel  to  be  sustainable.  Phase-out mandates,  similar  to  those  implemented  in fossil  fuel  or  nuclear  power,  or  to  internal combustion engines in transport, could be  used  to  promote  demand  by  setting  a timeline to phase out blast furnaces for steel or fossil fuelbased ships.
-  Standards  and  certifications : Uptake  for green hydrogen requires that the customer is able to know what the source of the hydrogen is to  be  able  to  link  it  to  an  additional premium or quota target, while the producer is  able to validate lower CO  emissions and 2 be  remunerated  accordingly.  This  needs  to be  transparent  to  be  able  to  communicate

the  emissions  that  have  been  accounted for  (upstream,  production,  transport,  and re-conversion).  It  also  needs  to  be  robust, potentially including more than CO 2 only, to ensure high sustainability standards that are internationally accepted,  compatible  with other schemes ( e.g. electricity and gas) and with an adaptable framework to be adjusted based on lessonslearned, once it is deployed.

Governments could also use specific policy instruments for green hydrogen production. Many  of  these  are  already  outlined  in  published strategies and the level of these instruments will be  better  defined  once  impact  assessments  are made.  The  tradeoffs  to  consider  in  the  policy design for these instruments, as well as examples from  around  the  world,  are  further  explained  in the associated briefs of another IRENA publication (IRENA, 2020d). Options include:

-  Capacity  targets : This  is the  most  used measure so far in hydrogen strategies (see Section 1.2). These should be deployed in  tandem  with  an  increase  in  renewable capacity targets (if any) to make  sure renewable electricity use for hydrogen does not  displace  more  efficient  uses  (such  as increasing the renewable share of the grid).
-  Financial support :  This  can  be  in  the  form of grants or concessional loans that decrease the  investment  risk  for  industry  and  close part of the cost differential with fossilbased  hydrogen.  One  example  is  Australia, where hydrogen is one of the technologies supported under the AUD  1.9 billion investment package for new energy technologies. The Clean Energy Finance Corporation will make AUD  300 million available  to  support  the  hydrogen  industry and  there  is  also  some  funding  through the  Australian  Renewable  Energy  Agency (ARENA), which has a AUD  70 million grant  programme  aimed  at  demonstrating the  technical  and  commercial  viability  of hydrogen production.
-  Recent  COVID-19  strategies  and  recovery packages  also  have  financial  support  for hydrogen (some of which could be used for

electrolysis).  Germany  has  a  EUR 7 billion support  package,  France  a  EUR 7.2 billion version (EUR 3.4 billion before 2023), while EUR 7 billion  is  expected  to  be  allocated to  the  Portuguese  strategy.  Some  of  the investment support has already been translated into concrete calls for proposals. These  include  the  solarelectrolysis  project in  the  port  of  Sines  (Portugal),  which  has received 74 expressions of interest, and the  EU  call  for  a  100 MW  electrolyser  for commercial and industrial applications.

-  Blending  quotas :  These  could  be  used  by either specifying a share of green hydrogen in existing uses, or shares of green hydrogen in final energy demand for specific applications ( e.g. similar to the renewable share in transport  in  the  EU).  France  has  already used this approach, specifying 10% of lowcarbon  hydrogen  (potentially  from  nuclear as well) in industry by 2023 and 20%-40% by 2028.  Portugal  has  also  specified  blending shares  for  most  enduse  sectors  from  2020 to 2050, including 2%-5% of green hydrogen in  industry by 2030, 10%-15% by 2040 and 20%-25% by 2050.
-  Manufacturing capacity targets : Some regions are aiming for technology leadership in  electrolysis  and  could  use  incentives  to promote domestic production. For instance, the UK government awarded USD 9.8million (GBP 7.5 million)  for  a  feasibility  study  to scale up the electrolyser size to 100 MW and the manufacturing capacity to 300 MW/year by 2023 and to 1 GW/year by 2025.
-  Tax  incentives : These  could  decrease  the impact  of  the  high  capital  cost  on  project profitability. Alternatives are lower income or sales taxes, or lower tax on the investment. One example is from the Netherlands, where investments resulting in the displacement of fossil  fuels  are  tax  deductible  (the  tax  rate  is  up to 41.5%). The incoming US administration is considering the introduction of a production tax credit of USD 0.42/kg for clean hydrogen and hydrogen carriers - based on emissions intensity - and a manufacturers production tax credit of USD 500/kW. Similar incentives

were fundamental for the deployment of wind and battery electric vehicles respectively.

-  Green hydrogen premium: This could be through feed-in tariffs or contracts for  difference.  An  example  where  this  is already  applied  is  the  SDE++  program  in the  Netherlands,  which  is  set  to  provide subsidies  for  the  production  of  hydrogen from electrolysis (RVO, 2020).

Governments  undertake  all  this  alone,  however. Industry and private capital are other key components (see Figure 36). One of the actions industry can take is to form joint ventures. These can  diversify  the  risk  for  large  projects  that  are firstofakind, while still allowing all parties to benefit from experience in the project.

A recent (November 2020) example is a 20 MW green hydrogen project in China, where hydrogen will be used for road transport as a joint venture between  Shell  and  Zhangjiakou  City  Transport. Industrial  manufacturers  can  contribute  to  the lower  cost  by  standardising  the  designs,  which can then be replicated from one project to another, reducing engineering costs, learning from  construction  and  reducing  delays.  Some companies could also invest in electrolysis, given its  good prospects for the future, aiming to take the lead and a high share of a burgeoning market. The reward for the high risk for being a front runner is that of becoming a dominant player in the future market.  Once  the  market  develops,  research  can transition to be  dominated  by  private  efforts aiming to improve competitiveness and achieving a larger market share.

In addition, international organisations can serve to: exchange knowledge; bring together governments and industry; set the global needs for electrolysis deployment;  track  progress  towards  deployment targets,  implement  policies  and  cost  decreases; support  the  development  of  national  strategies; perform scenario analysis to set the global needs for  electrolysis  to  be  in  line  with  a  sustainable future; identify new business models; and analyse specific case studies.

IRENA covers many of these activities under the Collaborative Framework  for Green Hydrogen and  will  continue  to  support  member  states  in these  aspects.  For  standards  and  certification, the  International  Partnership  for  Fuel  Cells  and Hydrogen in the Economy has a specific standing Working Group on Regulations, Codes, Standards and  Safety  and  has  a  dedicated  task  force  on hydrogen  production  analysis.  IRENA  aims  to support this initiative and bring together member states that are working on certification.

This  report  uses  a  single  representative  cost  for technology  today  to  estimate  the  potential  cost reduction in the future. This cost can vary widely, however, by manufacturer, country of origin, design,  location,  project  scope  and  application. Part  of  the  underlying  problem  is  limited  data availability, given an early stage market that sees strong  competition  between  manufacturers  and protection of intellectual property.

Another  issue  is  that  many  of  the  current  cost estimates are for small-scale projects with limited volumes  of manufacturing  capacity. Estimates for  large-scale  production  are  therefore  based on  engineering,  rather  than  actual  values  from implementation. Scale-up of manufacturing facilities will bring significant cost reduction, due to  automation  of  the  manufacturing  process,  as well as standardisation of components.

What governments can do is to promote transparency  and  openness  and  link  any  public support  with  a  disclosure  requirement  for  the project data. This would allow efforts from other parts of society, such as universities and research institutes, to be channelled towards analysing such data and working towards closing the gaps, rather than  leaving  this  effort  to  private  industry  and market competition alone.

This  would  not  be  unprecedented  for  hydrogen, with  such  practices  already  being  followed  in California through the Low-Carbon Fuel Standard (LCFS) 25 nd a Europe by the Fuel Cells and Hydrogen Joint Undertaking (FCH JU), but these are currently limited to the overseeing bodies and not fully public.

Most  of  the  attention,  notably,  is  currently  on projects with European manufacturers, while little  is  known  about  the  cost  and  performance of technologies  from  other  regions,  with  few exceptions.  In  the  years  to  come,  more  projects of larger scale will lead to better price discovery and will allow us to refine cost estimates, as well as cost projections.

At this stage, a floor cost is also difficult to establish, as many of the components are likely to undergo significant reengineering as manufacturing capacity and project scale increases rapidly. In the face of such uncertainties, governments can create stable demand through policies and regulation, to create  a  predictable  project  pipeline  that  would allow for investments in scaling up manufacturing, as well as the necessary investments in RD&amp;D.

A  current uncertainty that could turn into a potential upside  is the progress  that  can  be achieved  for  AEM  and  solid  oxide.  While  these two technologies are at their early stages today, they can represent a step change in performance. AEM has  the  promise  of  being  free  from  scarce raw  materials, is a less expensive and  more environmentally friendly membrane, and can operate at differential pressure. Solid oxide has the promise of much higher efficiency, which translates into lower electricity costs. What governments can do in this respect is to have these technologies as part of research programmes and not only focus scale-up efforts on technologies that are already commercial.

Finally,  ongoing  innovation  can  be  expected  to improve viability and even provide new alternatives. The main focus currently is on electrolysis as the key pathway for green hydrogen production, where innovation  is  likely  to  further  reduce  costs  and improve  electrolyser  performance.  This  may  also result  in  completely  new  technologies,  however, in  the  production  of  hydrogen  with  renewables (IRENA, 2018).

## REFERENCES

## Australian Government (2020) ,

## Diesendorf, M. and Elliston, B. (2018) ,

Technology investment roadmap: First low emissions technology statement - 2020 , Department of Industry, Science, Energy and Resources, pp. 44, www.industry.gov. au/sites/default/files/September%202020/ document/first-low-emissions-technologystatement-2020.pdf.

Babic, U. et al. (2017) , 'Critical reviewIdentifying critical gaps for polymer electrolyte water electrolysis development' , Journal of the Electrochemical Society, Vol. 164/4, pp. F387, https://dx.doi. org/10.1149/2.1441704jes.

Bergen, F. (2019) , Electricity-based fuels as a link between the electricity and transport sectors , ETIP Wind Workshop, https://etip wind.eu/wp-content/uploads/A5-Siemens.pdf

BNEF (2019) , Hydrogen: The economics of storage. Storing clean molecules at scale . Bloomberg New Energy Finance.

Böhm, H. et al. (2020) , 'Projecting cost development for future large-scale power-to-gas implementations by scaling effects' , Applied Energy, Vol. 264, pp. 114780,  https://dx.doi.org/10.1016/j. apenergy.2020.114780.

Böhm, H., S. Goers, and A. Zauner (2019) , 'Estimating future costs of powerto-gas - a component-based approach for technological learning' , International Journal of Hydrogen Energy, Vol. 44/59, pp. 3078930805, https://dx.doi.org/10.1016/j. ijhydene.2019.09.230.

Cihlar, J. et al. (2020) , Hydrogen generation in Europe: Overview of key costs and benefits , https://dx.doi. org/10.2833/122757.

'The feasibility of 100% renewable electricity systems: A response to critics' , Renewable and Sustainable Energy Reviews, Vol. 93, pp. 318330, https://dx.doi. org/10.1016/j.rser.2018.05.042.

Duclos, L. et al. (2017) , 'Environmental assessment of proton exchange membrane fuel cell platinum catalyst recycling' , Journal of Cleaner Production, Vol. 142, Part 4, pp. 26182628, https://dx.doi.

org/10.1016/j.jclepro.2016.10.197.

E4tech (2014) , Study on development of water electrolysis in the EU , E4tech Sàrl with Element Energy Ltd for the Fuel Cells and Hydrogen Joint Undertaking, https://www.fch.europa.eu/sites/default/files/ FCHJUElectrolysisStudy\_FullReport%20(ID%20 199214).pdf.

Eichman, J., K. Harrison and M. Peters (2014) , Novel electrolyzer applications: Providing more than just hydrogen , NREL/TP-5400-61758, National Renewable Energy Laboratory, Golden, CO, United States, https://dx.doi. org/10.2172/1159377.

European Commission (2020) , Study on the EU's list of critical raw materials (2020) ,European Commission, Brussels.

FCH JU (2019) , Fuel Cells and Hydrogen 2 Joint Undertaking - Addendum to the multi-annual work plan 2014 - 2020 , Fuel Cells and Hydrogen Joint Undertaking, www.fch.europa.eu/sites/default/files/MAWP

final version\_endorsed GB 15062018 %28ID 3712421%29.pdf.

FCW (2020) , Asahi Kasei's electrolysis system starts world's largest-scale hydrogen supply operation at the Fukushima Hydrogen Energy Research Field in Namie , Fuel Cells Works, https:// fuelcellsworks.com/news/asahi-kaseiselectrolysis-system-starts-worlds-largest-scalehydrogen-supply-operation-at-the-fukushimahydrogen-energy-research-field-in-namie/.

Garside, M. (2019) , Demand for iridium worldwide from 2010 to 2019 , Statista, www.statista.com/statistics/585840/demandfor-iridium-worldwide/ (accessed 16 October 2020).

Gül, T. et al. (2009) , 'An energy-economic scenario analysis of alternative fuels for personal transport using the Global Multiregional MARKAL model (GMM)' , Energy, Vol. 34/10, pp. 14231437, https://dx.doi. org/10.1016/j.energy.2009.04.010.

Hand, S., J.S. Guest and R.D. Cusick

(2019) , 'Technoeconomic analysis of brackish water capacitive deionization: Navigating tradeoffs between performance, lifetime, and material costs' , Environmental Science &amp; Technology, Vol. 53/22, pp. 1335313363, https://dx.doi.org/10.1021/ acs.est.9b04347.

Hermann, A., T. Chaudhuri and P. Spagnol (2005) , 'Bipolar plates for PEM fuel cells: A review' , International Journal of Hydrogen Energy, Vol. 30/12, pp. 12971302, https://dx.doi.org/10.1016/j. ijhydene.2005.04.016.

Hmiel, B. et al. (2020) , 'Preindustrial 14CH4 indicates greater anthropogenic fossil CH4 emissions' , Nature, Vol. 578/7795, pp. 409412, https://dx.doi. org/10.1038/s41586-020-1991-8.

Hydrogen Council (2020) , Path to hydrogen competitiveness - A cost perspective, Hydrogen Council , https:// hydrogencouncil.com/en/path-to-hydrogencompetitiveness-a-cost-perspective/.

IEA (2020) , Energy technology perspectives: Special report on clean energy innovation , International Energy Agency, Paris.

IEA TCP (n.d.) , Data provided by IEA Hydrogen Technology Collaboration Programme , Task 38.

IRENA (2020a) , Renewable Power Generation Costs in 2019 , International Renewable Energy Agency, Abu Dhabi, www.irena.org/publications/2020/Jun/ Renewable-Power-Costs-in-2019.

IRENA (2020b) , Global renewables outlook: Energy transformation 2050 (Edition 2020) , pp. 212, International Renewable Energy Agency, Abu Dhabi, https:// irena.org/publications/2020/Apr/GlobalRenewables-Outlook-2020.

IRENA (2020c) , Reaching zero with renewables: Eliminating CO2 emissions from industry and transport in line with the 1.5°C climate goal , International Renewable Energy Agency, Abu Dhabi, www.irena.org/ publications/2020/Sep/Reaching-Zero-withRenewables.

IRENA (2020d) , Green hydrogen: A guide to policy making, International Renewable Energy Agency , Abu Dhabi, https://irena. org/publications/2020/Nov/Green-hydrogen.

IRENA (2020e) , Renewable energy policies in a time of transition: Heating and cooling . International Renewable Energy Agency, Abu Dhabi, https://irena. org/publications/2020/Nov/RenewableEnergy-Policies-in-a-Time-of-TransitionHeating-and-Cooling

IRENA (2020f) , Electricity storage valuation framework: Assessing system value and ensuring project viability , pp. 112, International Renewable Energy Agency, Abu Dhabi, https://irena.org/ publications/2020/Mar/Electricity-StorageValuation-Framework-2020.

IRENA (2019a) , Hydrogen: A renewable energy perspective , International Renewable Energy Agency, Abu Dhabi, www.irena.org/publications/2019/Sep/ Hydrogen-A-renewable-energy-perspective.

IRENA (2019b) , Demand-side flexibility for power sector transformation, International Renewable Energy Agency, Abu Dhabi, www.irena.org/publications/2019/Dec/ Demand-side-flexibility-for-power-sectortransformation.

IRENA (2018) , Hydrogen from renewable power: Technology outlook for the energy transition , International Renewable Energy Agency, Abu Dhabi, www.irena. org/publications/2018/Sep/Hydrogen-fromrenewable-power.

IRENA (2015) , Renewable energy in the water, energy &amp; food nexus , International Renewable Energy Agency, Abu Dhabi, www.irena.org/publications/2015/Jan/ Renewable-Energy-in-the-Water-Energy--

Food-Nexus.

ITM Power (2017) , Scaling PEM electrolysis to 100 MW , Hannover Messe, Germany, https://cam1.h2fc-fair.com/hm17/images/ forum/tf/2017-04-25-1100.pdf.

Kang, Z. et al. (2020) , 'Effects of various parameters of different porous transport layers in proton exchange membrane water electrolysis' , Electrochimica Acta, Vol. 354, pp. 136641, https://dx.doi.org/10.1016/j. electacta.2020.136641.

Kim, H.-S. et al. (2013) , 'High-efficiency isolated bidirectional AC-DC converter for a DC distribution system' , IEEE Transactions on Power Electronics, Vol. 28/4, pp. 16421654, https://dx.doi. org/10.1109/TPEL.2012.2213347.

Liu, C. et al. (2018) , 'Performance enhancement of PEM electrolyzers through iridium-coated titanium porous transport layers' , Electrochemistry Communications, Vol. 97, pp. 9699, https://dx.doi.org/10.1016/j. elecom.2018.10.021.

Mayyas, A. et al. (2019) , Manufacturing cost analysis for proton exchange membrane water electrolyzers , Technical Report NREL/TP-6A20-72740, National Renewable Energy Laboratory, Golden, CO, United States.

## Mayyas, A. and M. Mann (2019) ,

'Emerging manufacturing technologies for fuel cells and electrolyzers' , Procedia Manufacturing, Vol. 33, pp. 508515, https:// dx.doi.org/10.1016/j.promfg.2019.04.063.

McDowall, W. (2012) , Endogenous technology learning for hydrogen and fuel cell technology in UKSHEC II: Literature review, research questions and data , UKSHEC Working Paper 8, https://www. lifestudy.ac.uk/bartlett/energy/research/ themes/energy-systems/hydrogen/WP8\_ McDowall\_ETL\_1\_.pdf

McKinsey (2010) , A portfolio of powertrains for Europe: A fact-based analysis , McKinsey &amp; Company, www.fch.europa.eu/ sites/default/files/Power\_trains\_for\_Europe\_0. pdf.

McPhy (2020) , Electrolyzers: The production of industrial hydrogen onsite, on demand, according to your specifications , McPhy Energy, https:// mcphy.com/en/equipment-services/ electrolyzers/?cn-reloaded=1.

Mehmeti, A. et al. (2018) , 'Life cycle assessment and water footprint of hydrogen production methods: From conventional to emerging technologies', Environments , Vol. 5, pp 19, http://dx.doi. org/10.3390/environments5020000.

## Nel (2019) , Nel hydrogen electrolysers,

Nel , https://nelhydrogen.com/wp-content/ uploads/2020/03/Electrolysers-BrochureRev-C.pdf.

Noack, C. et al. (2015) , 'Studie über die Planung einer Demonstrationsanlage zur Wasserstoff-Kraftstoffgewinnung durch Elektrolyse mit Zwischenspeicherung in Salzkavernen unter Druck' [Study on the planning of a demonstration system for hydrogen fuel production by electrolysis with intermediate storage in salt caverns under pressure], https://elib.dlr.de/94979/ (accessed 2 November 2020).

## van 't Noordende, H. and P. Ripson

(2020) , Gigawatt green hydrogen plant: State-of-the-art design and total installed capital costs , Institute for Sustainable Process Technology (ISPT), https://ispt.eu/ media/ISPT-public-report-gigawatt-greenhydrogen-plant.pdf.

NOW (2018) , 'Studie IndWEDe Industrialisierung der Wasserelektrolyse in Deutschland: Chancen und Herausforderungen für nachhaltigen Wasserstoff für Verkehr, Strom und Wärme' [Study IndWEDe industrialisation of water electrolysis in Germany: Opportunities and challenges for sustainable hydrogen for transport, electricity and heat], Nationale Organisation Wasserstoff- und Brennstoffzellentechnologie, Berlin, http:// publica.fraunhofer.de/eprints/urn\_nbn\_ de\_0011-n-5194940.pdf.

Nuss, P. and E. Matthew (2014) , 'Life cycle assessment of metals: A scientific synthesis' , Metals Environmental Impacts, Vol. 9/7, https://journals.plos.org/plosone/ article?id=10.1371/journal.pone.0101298 (accessed 16 October 2020).

Ozarslan, A. (2012) , 'Large-scale hydrogen energy storage in salt caverns' , International Journal of Hydrogen Energy, Vol. 37/19, pp. 1426514277, https://dx.doi. org/10.1016/j.ijhydene.2012.07.111.

Proost, J. (2020) , 'Critical assessment of the production scale required for fossil parity of green electrolytic hydrogen' , International Journal of Hydrogen Energy, Vol. 45/35, pp. 1706717075, https://dx.doi. org/10.1016/j.ijhydene.2020.04.259.

## Reddy, K.V. and N. Ghaffour (2007) ,

'Overview of the cost of desalinated water , Desalination, and costing methodologies' Vol. 205/1, pp. 340353, https://dx.doi. org/10.1016/j.desal.2006.03.558.

Saba, S.M. et al. (2018) , 'The investment costs of electrolysis - A comparison of cost studies from the past 30 years' , International Journal of Hydrogen Energy, Vol. 43/3, pp. 12091223, https://dx.doi. org/10.1016/j.ijhydene.2017.11.115.

Santos, D.M.F., C.A.C. Sequeira and J.L. Figueiredo (2013) , 'Hydrogen production by alkaline water electrolysis' , Química

Nova, Vol. 36, pp. 11761193.

Schalenbach, M. et al. (2016) , 'Acidic or alkaline? Towards a new perspective on the efficiency of water electrolysis' , Journal of the Electrochemical Society, Vol. 163/11, pp. F3197, https://dx.doi.

org/10.1149/2.0271611jes.

Schmidt, O. et al. (2017) , 'The future cost of electrical energy storage based on experience rates' , Nature Energy, Vol. 2/8, https://dx.doi.org/10.1038/nenergy.2017.110.

Schoots, K. et al. (2008) , 'Learning curves for hydrogen production technology: An assessment of observed cost reductions' , International Journal of Hydrogen Energy, Vol. 33/11, pp. 26302645, https://dx.doi. org/10.1016/j.ijhydene.2008.03.011.

## Schoots, K., G.J. Kramer and B.C.C. van

der Zwaan (2010) , 'Technology learning for fuel cells: An assessment of past and potential cost reductions' , Energy Policy, Vol. 38/6, pp. 28872897, https://dx.doi. org/10.1016/j.enpol.2010.01.022.

Siemens (2020) , Silyzer 300 electrolyser , Nuremberg, Germany, https://assets. siemens-energy.com/siemens/assets/api/ uuid:ffa44e5d-1207-46d3-808f-e759f03282b8/ datasheet-neu.pdf.

## Shi, X., Liao X. and L. Yanfei (2020) ,

' Quantification of fresh water consumption and scarcity footprints ofhydrogen from water electrolysis: A methodology framework ', Renewable Energy, Vol. 154, pp. 786-796, https://doi.org/10.1016/j. renene.2020.03.026.

Staffell, I. and R. Green (2013) , 'The cost of domestic fuel cell micro-CHP systems' , International Journal of Hydrogen Energy, Vol. 38/2, pp. 10881102, https://dx.doi. org/10.1016/j.ijhydene.2012.10.090.

## The CCAC Oil &amp; Gas Methane

Partnership (n.d.) , Climate &amp; Clean Air Coalition, https://www.ccacoalition.org/en/ activity/ccac-oil-gas-methane-partnership (accessed 17 November 2020).

Thyssenkrupp (2020) , Thyssenkrupp's water electrolysis technology qualified as primary control reserve - E.ON and thyssenkrupp bring hydrogen production to the electricity market , www.thyssenkrupp.com/en/newsroom/ press-releases/pressdetailpage/ thyssenkrupps-water-electrolysis-technologyqualified-as-primary-control-reserve--eon-andthyssenkrupp-bring-hydrogen-production-tothe-electricity-market-83355.

Thyssenkrupp (2018) , Hydrogen from large-scale electrolysis - Efficient solutions for sustainable chemicals and energy storage, Thyssenkrupp, https://ucpcdn.thyssenkrupp.com/\_binary/ CPthyssenkruppBAISUhdeChlorineEngineers/ en/products/water-electrolysis-hydrogenproduction/alkaline-water-electrolysis/link-thyssenkrupp\_Hydrogen\_Water\_Electrolysis\_ and\_green\_chemicals.pdf.

## Van Berkel, F. et al. (2020) , Green

hydrogen economy in the EU: The critical materials perspective. Strategies for the reduction of critical material used in electrolyser stacks , TNO.

Walnum, H.T. et al. (2013) , Report on modelling of large-scale high-efficiency IDEALHY hydrogen liquefier concept , FCH JU, www.idealhy.eu/uploads/documents/ IDEALHY\_D2-4\_Modelling\_High-Efficiency\_ Concept\_web.pdf.

## Wei, M., S.J. Smith and M.D. Sohn

(2017a) , 'Experience curve development and cost reduction disaggregation for fuel cell markets in Japan and the US' , Applied Energy, Vol. 191, pp. 346357, https://dx.doi. org/10.1016/j.apenergy.2017.01.056.

## Wei, M., S.J. Smith and M.D. Sohn

(2017b) , 'Non-constant learning rates in retrospective experience curve analyses and their correlation to deployment programs' , Energy Policy, Vol. 107, pp. 356369, https://dx.doi.org/10.1016/j. enpol.2017.04.035.

Wong, Q. (2020) , Facebook plans to use AI to help fight climate change , CNET, www.cnet.com/news/facebook-plans-to-useai-to-help-fight-climate-change/ (accessed 15 October 2020).

World Bank (2020) , Green hydrogen in developing countries, Energy Sector Management Assistance Program World Bank , Washington, DC, http:// documents1.worldbank.org/curated/ en/953571597951239276/pdf/GreenHydrogen-in-Developing-Countries.pdf (accessed 6 November 2020).

## ABBREVIATIONS

A/cm 2

Amperes per square centimetre

GW/year

Gigawatts per year

| AEM    | Anion exchange membrane                    | H 2        | Hydrogen                                                                                         |
|--------|--------------------------------------------|------------|--------------------------------------------------------------------------------------------------|
| Al     | Aluminium                                  | ha         | Hectares                                                                                         |
| ASTM   | American Society for Testing and Materials | IRESEN     | Research Institute on Solar Energy and New Energies (Institut de Recherche en Energie Solaire et |
| atm    | Standard atmospheres                       |            | Energies Nouvelles - Morocco)                                                                    |
| B      | Boron                                      | ISPT       | Institute for Sustainable Process                                                                |
| BEV    | Battery electric vehicle                   |            | Technology                                                                                       |
| BOP    | Bill of process                            | kg         | Kilogramme                                                                                       |
| CCM    | Catalystcoated membrane                    | km 2       | Square kilometre                                                                                 |
| CCS    | Carbon capture and storage                 | KOH        | Potassium hydroxide                                                                              |
| CHA    | Clean Hydrogen Alliance                    | KPI        | Key performance indicator                                                                        |
| cm 2   | Square centimetres                         | kW         | Kilowatt                                                                                         |
| Cr     | Chromium                                   | kWh/kg H 2 | Kilowatt hours per kilogramme of hydrogen                                                        |
| Cu     | Copper                                     |            |                                                                                                  |
|        |                                            | LCSF       | Low Carbon Fuel Standard                                                                         |
| EJ     | Exajoules                                  | LHV        | Lower heating value                                                                              |
| EPC    | Engineering, procurement and construction  | LNG        | Liquefied natural gas                                                                            |
| EU     | European Union                             | LSF        | Lanthanum ferrite                                                                                |
| EV     | Electric vehicle                           | LSM        | Lanthanum magnate                                                                                |
| FCEV   | Fuel cell electric vehicle                 | M 3        | Cubic metre                                                                                      |
| FCH JU | Fuel Cells and Hydrogen Joint Undertaking  | MASEN      | Moroccan Agency for Sustainable Energy                                                           |
| Fe     | Iron                                       | MEA        | Membrane electrode assembly                                                                      |
| FEED   | Front end engineering and design           | METI       | Ministry of Economy, Trade and Industry (Japan)                                                  |
| FFR    | Fast frequency response                    |            |                                                                                                  |
| GHG    | Greenhouse gas                             | mg         | Milligram                                                                                        |
| GJ     | Gigajoules                                 | μ m        | Micrometres                                                                                      |
| g/kW   | Grammes per kilowatt                       | mm         | Millimetre                                                                                       |
| GtCO   | Gigatonnes of carbon dioxide               | Mol* L-1   | Moles of solute per litre of solution                                                            |

MtH 2 /year

Million tonnes of hydrogen per year

MWh

Megawatt hour

NaHCO 3

Sodium bicarbonate

Ni

Nickel

NiAl

NickelAluminium

Ni(OH) 2

Nickel hydroxide

NiZn

NickelZinc

nm

Nanometres

O2

Oxygen

OEM

Original equipment manufacturer

OPEX

Operational expenditure

PEM

Polymer electrolyte membrane

PFSA

Perfluorosulfonic acid

PTL

Porous transport layer

PtX

PowertoX

PV

Photovoltaic

R&amp;D

Research and development

RD&amp;D

Research, design and development

Si

Silicon

SiO 2

Silicon dioxide

SOEC

Solid oxide electrolyser cell

tCO 2

Tonnes of carbon dioxide

TES

Transforming Energy Scenario (IRENA)

TW

Terawatt

TWh

Terawatt hour

t/year

Tonnes per year

V

Volt

VRE

Variable renewable energy

WACC

Weighted average cost of capital

Zirconium oxide

ZrO 2

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

<!-- image -->

106

GREEN  HYDROGEN

COST REDUCTION

<!-- image -->

<!-- image -->