---
document_id: iea_improving-the-fuel-economy-performance-of-trucks-in-indonesia
title: "Iea Improving-The-Fuel-Economy-Performance-Of-Trucks-In-Indonesia"
category_id: 2
category_name: "Decarbonization Roadmaps & Analytical Reports (IEA & IRENA)"
source_organization: "Institutional"
year: 2024
original_file: "iea_improving-the-fuel-economy-performance-of-trucks-in-indonesia.pdf"
tables_detected: 0
converted_with: "Docling v2.32 (TableFormer)"
---

<!-- image -->

## POLICY BRIEF

## Improving the fuel economy performance of trucks in Indonesia

## Key messages

## Contents

- · The energy demand of trucks is rising rapidly in Indonesia, and fleet is projected to almost triple by 2060 .
- · Fuel  economy or CO2 standards for  trucks  could support Indonesia's net zero ambitions , reduce fuel imports, improve air quality, and strengthen industrial competitiveness.
- · International experience shows  that phased  standards, flexible compliance mechanisms and targeted incentives can make  truck  efficiency  regulation  practical  and  effective. The  People's  Republic  of  China  (hereafter  'China'),  the European Union, the United States, and others demonstrate different approaches to combining performance standards with policies such as sales mandates and incentives.
- · A staged policymaking pathway can help Indonesia build the data, testing capacity, and regulatory expertise needed for effective  implementation. Initial steps  could  include developing an interagency taskforce, improved data collection, and  engine  testing.  Engine  minimum  energy  performance standards  could  then  help  to  build  the  capacity  required  to implement a simulation-based whole-vehicle standard, supported by labelling and policies to promote electric trucks.

The case for fuel economy or CO2 standards

Current regulatory frameworks for truck efficiency

International fuel economy and CO2 standards for trucks

Other complementary policies

Potential policymaking pathway

Implementation

<!-- image -->

## The case for fuel economy or CO2 standards

Between 2010 and 2021 the number of heavy trucks in Indonesia doubled to around 1.7 million, and is projected to reach around 2.5 million by 2030, and almost 5 million by 2060. Without stronger fuel efficiency policies, rising demand risks locking in high fuel consumption, meaning higher emissions and energy costs. In 2022, the average fuel consumption of new light duty vehicles sold in Indonesia was 35% higher than the world average. This is also above the level seen in many comparable middleincome countries. More strikingly, new vehicles are only marginally more efficient than the vehicles already on the road, implying limited progress over the past decade. The average fuel consumption of trucks in Indonesia is not yet well understood, so the energy efficiency of this segment of the market may be similarly lagging behind.

Establishing  fuel  economy  standards  (FES)  could  support  Indonesia's  efforts  to  reduce  carbon emissions in the transport sector and its ambition to reach net zero emissions by 2060. Improving the fuel economy of Indonesia's trucks could achieve other important benefits including: improved air quality and human health, reduced fuel imports and improved energy security; enhanced competitiveness of Indonesian truck manufacturing; and cost reductions for truck operators and consumers. This policy brief  presents  options  for  introducing  truck  FES  in  Indonesia  as  well  as  complementary  policies  to incentivise the supply of electric trucks to the Indonesian market.

## Current regulatory frameworks for truck efficiency

Indonesia  has  issued  several  strategic  documents  and  regulations  aiming  to  accelerate  energy efficiency improvements, including the adoption of more efficient trucks:

- · The  Law  on  Energy  promotes  responsible  energy  use  and  empowers  the  government  to introduce minimum efficiency standards, incentives, and penalties.
- · The National Industry Development Master Plan identifies the vehicle industry as a priority and encourages the production of more efficient powertrain technologies.
- · The National Energy Plan sets targets to reduce energy demand intensity and calls for FES to help meet energy and emissions goals.
- · The  Goods  Transportation  Regulation  imposes  technical  and  roadworthiness  standards  to reduce overloading and fuel waste.
- · The Energy Conservation regulation requires large transport operators to implement energy management strategies and report truck category-level fuel use and efficiency data.
- · Looking ahead, the National Long-Term Development Plan 2025-2045 outlines a national lowcarbon pathway, emphasising energy efficiency, electrification, and carbon pricing to enable sustainable mobility by 2045.

## International fuel economy and CO2 standards for trucks

While  approaches  vary,  most  policies  combine  short-,  medium,  and  long-term  targets  with  flexible compliance mechanisms to give manufacturers and fleet operators clear signals and time to adjust.

China has implemented a phased approach fuel consumption standards for trucks. Since Stage 1 in 2012, the rules have been progressively tightened. Stage 4 (2025) regulates diesel and gasoline engines and is 15% more stringent than Stage 3 (2020). The standard now also covers hybrid electric trucks and uses a Minimum Energy Performance Standard (MEPS)-style vehicle-level regulation with CO2-based performance comparisons.

The European Union applies fleet-average CO  standards for trucks and buses and has a target of a ₂ 45% reduction by 2030, and 90% by 2040. The standards initially applied to certain truck types and were expanded to include city buses, trailers, coaches, and vocational trucks. It promotes early adoption of zero-emission vehicles (ZEVs) by relaxing the CO2 target for manufacturers with higher shares of ZEVs.

In the United States , fuel economy standards were introduced in 2011. Phase 2 (2016) tightened the standards, and expanded the scope to other components such as trailers and tyres. Phase 3 (finalised in 2024) requires a CO  reduction of up to 40% for tractor trucks by 2032 compared to the 2027 standard. ₂ The scheme includes 'multipliers' to incentivise ZEV adoption.

<!-- image -->

## Other complementary policies

Many countries use broader policy packages that include mandates, industrial support, and financial incentives.  These  complementary  policies  help  accelerate  the  deployment  of  ZEVs,  create  market certainty, and support long-term compliance with regulatory targets.

The European Union CO2 standards directly set mandatory minimum ZEV sales requirements for urban buses of 90% by 2030 and 100% by 2035.

At  COP 26, the United Kingdom announced phase-out dates for the sale of  new  non-ZEV trucks weighing 26 tonnes or less by 2035, with all new trucks sold in the United Kingdom to be ZEVs by 2040. The government is developing regulations to meet these targets.

In 2024, China announced goals to reduce the carbon intensity of commercial transport by 9.5% by 2030  compared  with  2020  levels,  and  for  battery,  plug-in  hybrid  and  fuel-cell  electric  vehicles,  to comprise 45% of new vehicle sales by 2027.

California 's Advanced Clean Trucks  rule includes a minimum ZEV sales share of 30-50% in 2030. To support these targets California also introduced a range of economic incentives.

## Potential policymaking pathway

## Create taskforce and technical working groups

A taskforce with decision-making authority could bring together relevant ministries and agencies to clearly define responsibility for elements of the policy process, and to oversee the analytical outputs required to inform policy decisions. The taskforce could be supported by technical working groups comprising policymakers, industry representatives and technical experts.

International  experience  can  help  build  capacity  within  relevant  ministries  and  clarify  the  trade-offs associated  with  different  regulatory  designs.  Indonesia  could  assess  which  approaches  are  most suitable, including:

- · the adequacy of existing data sources and gaps in the foundational information
- · the selection of performance measures (i.e. fuel economy-based or CO2-based standard)
- · whether components or full vehicles should be tested, and which combination of simulation and physical testing should be used for type approval and certification
- · whether phased implementation would be appropriate
- · labelling design options
- · approaches to setting targets and increasing stringency over time
- · fleet-average compliance flexibilities
- · compliance measures, and monitoring and evaluation procedures.

Using  sales  data  from  Gaikindo,  paired  with  real-world  operations/usage  data  from  Aptrindo, Kamselindo,  and  POME,  Indonesia  can  develop  initial  estimates  of  fuel  consumption  by  segment. Segment  definitions  should  reflect  logical  operational  categories  and  should  be  developed  in consultation with industry stakeholders and technical experts. The goals of this action are to:

- 1) identify the segments representing the majority of fuel consumption
- 2) characterise the major operations within these segments (e.g. to develop test cycles)
- 3) pinpoint the main technology providers and technical characteristics of engines and other key components
- 4) inform subsequent analytical and designs steps, including testing/certification procedures and  test  cycles,  potential  simulation  models  and  modelling  specifications,  technology benchmarking and cost-benefit analysis.

<!-- image -->

## Fill gaps and implement engine fuel economy testing

Indonesia could undertake a dedicated assessment of the cost, infrastructure and administrative capacity needed to support future FES. This should cover physical equipment and facilities required for compliance testing given the various approaches that could be taken. As well as the legal and technical expertise required to administer the testing and certification schemes required as part of a FES. Indonesia could investigate recognising certified component performance from other countries, such as for tyres, transmissions, and other components. This assessment could proceed in parallel with the adoption of international testing methodologies.

However, as the component with the greatest effect on fuel economy and sensitivity to operating conditions, a robust FES would also require reliable data for engine performance, ideally using a local test cycle. Domestic manufacturers use engine dynamometer testing to verify compliance with pollution emissions standards (NOX, PM, CO), and government agencies monitor compliance, meaning adding fuel economy testing offers a practical solution. Policymakers could build capacity by focusing initially on engines, while also generating essential data for later implementation of a simulation-based whole-vehicle standard.

## Implement Minimum Engine Performance standards (MEPS)

Although full-vehicle fuel economy standards can be developed without component standards, MEPS could provide an effective early measure. These standards would set minimum efficiency thresholds for engines. By removing the least efficient products from the market, MEPS could deliver near-term fuel savings and emissions reductions while allowing manufacturers and regulators to build experience before more complex fleet-average regulation is introduced. Component standards could therefore provide an efficiency floor while supporting the gradual development of a broader regulatory framework.

## Promote efficient and electric trucks

Measures to promote efficient and zero-emission trucks could be integrated into the fuel economy standard or introduced as a parallel policy. Crediting mechanisms or gradually increasing minimum ZEV sales shares for manufacturers could provide clear market signals, support early deployment and build domestic capacity. This would complement the wider policymaking pathway and support a more ambitious transition to cleaner road freight.

## Develop whole-vehicle performance testing

The use of simulation tools in testing and certification can mitigate the need for physical whole-vehicle testing; which is expensive and resource heavy. Indonesia could streamline development while ensuring alignment with established international best practice by basing their tool on the European Union's opensource tool. Simulated whole-vehicle testing could then be applied at a low marginal cost to the wide range  of  truck  configurations  seen  on  the  market,  providing  a  robust  and  accurate  approach  to implementing the FES.

## Provide information and labelling.

Though not essential to the development of a FES, this step would raise truck consumer awareness and thereby encourage manufacturers to improve fuel economy. Labelling would be based upon the certified performance data, and therefore offers a potentially very low marginal cost to both manufacturers and the government.

## Implement Corporate Average Fuel Economy (CAFE) standard

A staged approach would allow Indonesia to align regulatory implementation with the development of testing capacity, data systems and administrative expertise. Rather than regulating all vehicle segments and technologies at once, Indonesia could introduce fleet-average FES as testing and certification systems mature.

POLICY BRIEF

<!-- image -->

A CAFE-style standard would allow manufacturers to balance lower-performing trucks with more efficient models, provided their overall fleet average meets the regulatory target. This would give manufacturers flexibility, encourage innovation and support progressive improvements in truck efficiency. If CAFE were to be combined with engine MEPS, the FES would establish both a minimum efficiency floor and an average performance requirement.

## Potential policymaking pathway to improve truck efficiency

<!-- image -->

IEA. CC BY 4.0

## Implementation

By sequencing governance, data collection, engine testing, simulation tool development, labelling, and finally  fleet-average  regulation,  Indonesia  could  develop  a  practical  approach  to  improving  truck efficiency while limiting implementation risks. Early action on engines could support near-term gains, while preparing the technical and institutional foundations for more comprehensive standards over time.